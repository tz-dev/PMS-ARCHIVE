# PMS-AXIOM

## Purpose

**PMS-AXIOM** is a corpus-form case-cartography repository for testing how classical closure-demands, apparent axioms, and proof-like expectations can be reconstructed across the PMS stack.

It collects Markdown/YAML case artefacts, model files, overlays, prompts, templates, and reader tooling. Its function is structural cartography, not proof production.

Compact boundary:

```text
case readability ≠ proof
operator fit ≠ validation
closure demand ≠ closure achievement
taxonomy ≠ rank
reader navigation ≠ authority
```

---

## Ecosystem Position

PMS-AXIOM belongs to the PMS corpus-form repository family.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies the Δ–Ψ operator grammar that AXIOM uses as a cartographic base. |
| PMS-LOGIC | Provides neighboring pressure around logic, non-closure, responsibility, and post-moral effects. |
| PMS-QC / QC-EXT | Provides bridge material for quantum-computational closure and governance cases. |
| MIP / AHP | May be used only under explicit stack routing where person-near or artefact-hardening questions arise. |
| PMS-STRATA | Can inspect composition, decomposition, projection, and chain movement in AXIOM cases without validating them. |
| PMS — UNDER LOAD | Critiques overfitting, false closure, case-corpus authority, and reader/schema drift. |

AXIOM is strongest when it stays a map of closure pressure, not a claim that PMS can close what rival systems leave open.

---

## Repository Form

This is a **corpus-form case-cartography repository**.

| Material | Function |
| --- | --- |
| `00_source/` | Legacy / source-level paper material. |
| `01_blocks/` | Rebuilt paper blocks and compact case-facing theory. |
| `02_cases/` | Markdown and YAML case artefacts, prompts, templates, and renderings. |
| `03_model/` | PMS-AXIOM model files, schemas, overlays, and case contract material. |
| `04_PMS-AXIOM reader/` | Optional local reader for corpus and case navigation. |

The repository should be read as a structured case corpus with explicit non-mixing discipline, not as a monolithic proof text.

---

## Reader / Navigation Tooling

![PMS-AXIOM Reader screenshot](04_PMS-AXIOM%20reader/screenshot.png)

The repository includes a single-file Tkinter reader:

```text
04_PMS-AXIOM reader/axiom_reader.py
```

Run:

```bash
python "04_PMS-AXIOM reader/axiom_reader.py"
python "04_PMS-AXIOM reader/axiom_reader.py" /path/to/PMS-AXIOM
python "04_PMS-AXIOM reader/axiom_reader.py" /path/to/PMS-AXIOM.zip
```

The reader supports local folder and ZIP loading, case-aware navigation by Part I–VIII, bounded case rendering, Markdown/YAML switching, heading navigation, corpus-wide search, lightweight YAML rendering, dark mode, and fullscreen use.

Boundary:

```text
reader case access ≠ case finding
YAML rendering ≠ schema validation
case navigation ≠ PMS validation
reader convenience ≠ closure proof
```

---

## Core Thesis

AXIOM tests how classical demands for closure can be rewritten as structured pressure rather than granted as final foundations.

It asks, in compressed form:

```text
Which demand for closure is being made?
Which PMS layer can read that demand?
Which stack route is admissible?
Which closure demand remains non-captured?
Which output type is actually permitted?
```

The repository is therefore not an axiom system for PMS. It is a case-cartography of closure-demands under PMS-compatible stack discipline.

---

## Rebuild Path

The old README included a rebuild path that should remain legible in compressed form:

```text
legacy full paper
→ source material
→ rebuilt paper blocks
→ YAML case artifacts
→ Markdown case notes
→ compact paper-facing renderings
```

This path matters because AXIOM separates source prose, block reconstruction, case artefacts, model contract, and reader navigation.

---

## Case Rebuild Workflow

AXIOM cases should be rebuilt through three linked artefact families.

| Artefact | Function |
| --- | --- |
| YAML case templates | Structured machine-readable fields for route, layer, claim, and output discipline. |
| Markdown case prompts | Human-readable reconstruction prompts and case notes. |
| Paper-facing renderings | Compact forms that can be cited or summarized in the paper layer. |

A case is not strengthened merely because it has all three artefacts. The artefacts increase inspection pressure only.

---

## Stack and Non-Mixing Discipline

AXIOM uses explicit stack routing. The route determines which concepts may be used.

| Route | Permitted use |
| --- | --- |
| PMS core | Δ–Ψ operator grammar only. |
| PMS core + add-on | PMS Base plus exactly one eligible PMS add-on. |
| PMS core + QC | PMS Base plus QC bridge layer. |
| PMS core + QC + QC-EXT | QC with explicitly extended QC material. |
| MIP | Adjacent praxeological anthropology use, not PMS Base validation. |
| MIP + AHP | Artefact-hardening and precision review, not evidentiary upgrade. |

Non-mixing rule:

```text
Do not combine layers because they are useful.
Combine them only when the route authorizes the combination.
```

Invalid shortcuts:

```text
PMS + all add-ons ≠ stronger analysis
MIP hook ≠ person evaluation
AHP hardening ≠ evidentiary upgrade
QC macro ≠ physical claim
```

---

## Case Suite

The case suite is organized as parts, not as a ranking.

| Part | Focus |
| --- | --- |
| Part I | PMS Core |
| Part II | PMS + LOGIC |
| Part III | PMS + ANTICIPATION |
| Part IV | PMS + CONFLICT |
| Part V | PMS + CRITIQUE |
| Part VI | PMS + EDEN |
| Part VII | PMS + SEX |
| Part VIII | PMS + QC / QC-EXT |

Use `02_cases/` and `03_model/` for the concrete YAML/Markdown case artefacts.

---

## Output Types and Misuse Boundaries

Typical AXIOM outputs include:

```text
Boundary
Taxonomy
Boundary / anti-drift policy
Regime taxonomy
Reach policy
Disclosure / publicness rule
Validity gate
Audit trace
```

Misuse boundaries:

```text
structural readability → not verdict
operator fit → not proof
coherence → not evidence
drift risk → not drift finding
taxonomy → not ranking
QC macro → not physical claim
MIP hook → not person evaluation
AHP hardening → not evidentiary upgrade
```

---

## Intended Use

PMS-AXIOM is intended for:

```text
case-cartography
closure-demand analysis
PMS stack-route discipline
boundary testing
model/schema inspection
teaching and research
controlled prompt/case design
```

It is not intended as an automated verdict system, proof engine, philosophical final-foundation system, legal instrument, person-evaluation framework, or claim that PMS has solved the closure problem.

---

## Reading Path

Recommended path:

```text
README
→ 00_source
→ 01_blocks
→ 02_cases
→ 03_model
→ optional reader
```

For case work, start in `02_cases/` and keep the selected route explicit before using any add-on, QC, MIP, or AHP material.

---

## Status

PMS-AXIOM exists as a rebuilt corpus-form case-cartography repository with paper blocks, Markdown/YAML cases, model/schema material, templates, prompts, overlays, and local reader support.

Its current status is:

```text
cartographic
experimental
case-oriented
route-bounded
non-verdictive
```

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS-AXIOM DOI | To be added or verified during the Zenodo release/check pass. |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing PMS-AXIOM, cite the repository release and DOI corresponding to the version used. Do not cite AXIOM cases as if they prove PMS Base or resolve closure demands conclusively.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
