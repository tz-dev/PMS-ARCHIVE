---
document_id: "MIP-APPENDIX-C"
title: "Case Examples"
source_role: "derived appendix case index"
source_file: "00_source/Maturity in practice - A praxeological anthropology.md"
target_file: "02_appendices/Appendix_C_Case_Examples.md"
status: "derived-reference"
version: "v2"
appendix_id: "C"
appendix_role: "case example index and corpus pointer"
canonical_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
model_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
  - "05_model/MIP - Maturity in Practice - AHP Module.yaml"
example_basis:
  - "05_model/examples"
claim_mode: "navigational, derived, non-expansive"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice may appear in examples under MIP guardrails; D₀ untouchable; no dignity score"
mip_status: "supporting appendix reference file; current examples live in 05_model/examples; not a replacement for canonical model, AHP module, or example YAML files"
generation_rule: "point to current schema-aligned example files; do not add new theory; do not omit current example locations"
---

# Appendix C — Case Examples

## Status of this appendix

This appendix is a **navigation and orientation file** for the maintained MIP example cases.

The current example cases are stored as structured files in:

```text
05_model/examples
````

The YAML files are the structured source versions.
The Markdown files are human-readable renderings of the same cases.

## Current maintained example cases

| No. | Case title                                      | Structured source                                                   | Human-readable rendering                                          | Add-on use | Role                                                                          |
| --: | ----------------------------------------------- | ------------------------------------------------------------------- | ----------------------------------------------------------------- | ---------- | ----------------------------------------------------------------------------- |
|  01 | Minimal Public Criticism in a Team Meeting      | `05_model/examples/01_Minimal_Public_Criticism.yaml`                | `05_model/examples/01_Minimal_Public_Criticism.md`                | none       | generic team-training case                                                    |
|  02 | Blurry Responsibility After a Decision          | `05_model/examples/02_Blurry_Responsibility_Org.yaml`               | `05_model/examples/02_Blurry_Responsibility_Org.md`               | none       | generic organisational training case                                          |
|  03 | Public Moral Criticism in Media or Social Media | `05_model/examples/03_Public_Moral_Critique_with_AHP.yaml`          | `05_model/examples/03_Public_Moral_Critique_with_AHP.md`          | AHP        | generic public-discourse training case with AHP overlay                       |
|  04 | Analysis of an Analysis (Meta / Expert Case)    | `05_model/examples/04_Meta_Analysis_with_AHP.yaml`                  | `05_model/examples/04_Meta_Analysis_with_AHP.md`                  | AHP        | generic meta-analysis and governance-readiness training case with AHP overlay |
|  05 | MIP Model Analysed by MIP (Self-Application)    | `05_model/examples/05_Self_Application_of_the_model_on_itself.yaml` | `05_model/examples/05_Self_Application_of_the_model_on_itself.md` | none       | generic self-application and model-review case                                |

## Reading rule

Use the example files in the following order:

1. Read the Markdown rendering if you want a human-readable version.
2. Read the YAML file if you need the exact structured case data.
3. Treat the YAML as the source of structure.
4. Treat the Markdown as a readable rendering, not as a separate theory layer.

## Relationship between YAML and Markdown examples

Each example pair consists of:

* one `.yaml` file containing the structured MIP case;
* one `.md` file containing a human-readable rendering of that same case.

The Markdown files should not add theory beyond the YAML.
They should not change A-scores, M-scores, IA-box results, D-profiles, guardrails, or transmission status.

If a discrepancy appears, the YAML file should be checked first.

## AHP examples

Examples 03 and 04 include AHP.

AHP means:

* Attack-surface visibility;
* Hardening for the next iteration;
* Precision Heuristic.

AHP is a second-order overlay for analysis quality. It does not rescore A, M, IA, or D. It does not activate the D-module. It does not create D-profiles. It does not make a non-transmittable analysis transmittable.

The maintained AHP examples are:

```text
05_model/examples/03_Public_Moral_Critique_with_AHP.yaml
05_model/examples/03_Public_Moral_Critique_with_AHP.md
05_model/examples/04_Meta_Analysis_with_AHP.yaml
05_model/examples/04_Meta_Analysis_with_AHP.md
```

## Non-AHP examples

Examples 01, 02, and 05 do not include AHP storage or AHP overlays.

They remain standard MIP case examples:

```text
05_model/examples/01_Minimal_Public_Criticism.yaml
05_model/examples/01_Minimal_Public_Criticism.md
05_model/examples/02_Blurry_Responsibility_Org.yaml
05_model/examples/02_Blurry_Responsibility_Org.md
05_model/examples/05_Self_Application_of_the_model_on_itself.yaml
05_model/examples/05_Self_Application_of_the_model_on_itself.md
```

## Example roles

### Example 01 — Minimal Public Criticism in a Team Meeting

This example demonstrates a small-scale publicness situation inside a team.

It is useful for reading:

* basic role/context mapping;
* minimal public criticism;
* asymmetry under ordinary organisational conditions;
* A/M score hygiene;
* dignity-in-practice without person labelling.

### Example 02 — Blurry Responsibility After a Decision

This example demonstrates responsibility diffusion after an organisational decision.

It is useful for reading:

* shared responsibility without guilt conversion;
* role-based M-score differentiation;
* decision ownership;
* IA risk under unclear responsibility;
* dignity risk through blame drift or abandonment.

### Example 03 — Public Moral Criticism in Media or Social Media

This example demonstrates public moral criticism under media or social-media amplification.

It is useful for reading:

* publicness and media-amplified asymmetry;
* moral criticism without person labelling;
* D-P and public dignity risk;
* reversibility and correction limits;
* AHP attack surfaces and hardening backlog.

### Example 04 — Analysis of an Analysis (Meta / Expert Case)

This example demonstrates second-order analysis of an analysis artifact.

It is useful for reading:

* meta-analysis without substantive re-decision;
* evidence-linking limits;
* governance-readiness;
* artifact authority effects;
* AHP as analysis-quality hardening.

### Example 05 — MIP Model Analysed by MIP (Self-Application)

This example demonstrates self-application of MIP to MIP as a procedure.

It is useful for reading:

* self-application as internal coherence check;
* model-as-procedure, not person;
* circularity and validation limits;
* guardrail reflection;
* distinction between internal consistency and external validation.

## Guardrail reminder

The examples are supporting files.

They must not be used as:

* person labels;
* clinical diagnoses;
* forensic findings;
* HR decision templates;
* public shaming tools;
* dignity rankings;
* maturity rankings of persons;
* automated decision rules.

All examples remain bound by the canonical MIP guardrails.

## Maintenance rule

When an example case is updated:

1. update the YAML file first;
2. then regenerate or manually update the Markdown rendering;
3. ensure that the Markdown does not add theory or change structured results;
4. update this appendix only if filenames, example titles, add-on status, or example roles change.

## Short conclusion

Appendix C serves as a corpus navigation file for current MIP examples.

The maintained examples are kept as paired YAML and Markdown files in `05_model/examples`, where they can remain schema-aligned, reviewable, and updateable.
