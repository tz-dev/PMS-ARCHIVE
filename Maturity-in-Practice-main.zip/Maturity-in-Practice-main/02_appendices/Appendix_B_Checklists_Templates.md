---
document_id: MIP-APPENDIX-B
title: "Checklists and Practice Templates"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical appendix extraction"
target_file: "02_appendices/Appendix_B_Checklists_Templates.md"
status: "split-full-version"
version: "v1"
appendix_id: "B"
appendix_role: "canonical practice templates"
source_appendix: "Appendix B"
source_appendix_title: "Checklists & practice templates"
core_references: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: ["Appendix A", "Appendix C", "Appendix D", "Appendix E"]
claim_mode: "procedural, template-based, practice-oriented, guardrail-bound, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice handled through optional D-Quick-Grid and D-profile; D₀ untouchable; not person score"
mip_status: "canonical appendix block; direct extraction; terminology and guardrail alignment; no new model logic"
split_rule: "include from Appendix B heading up to immediately before Appendix C heading"
---

# Maturity in practice — A praxeological anthropology: Appendix B — Checklists and Practice Templates

## Appendix B — Checklists & practice templates

> **Template boundary:**  
> These templates are **structuring aids**, not decision engines.  
> They do not replace the full model, guardrails, contextual judgement or professional responsibility.

> **Core hygiene:**  
> **A-score** = band, not person score.  
> **M-score** = shared structural responsibility, not guilt.  
> **D-profile** = qualitative dignity-in-practice description, not dignity score.  
> **IA-box (`T–J–TB–R`)** = asymmetry check, not verdict.

---

### B.1 Quick check: 60-second self-test before each application

**Purpose:**  
A short pre-application gate before using any `IA`, `A-score`, `M-score` or `D` template.

---

**1. Do I have my own role clear?**

* How much power, knowledge, reach do I currently have?
* Am I observer, party, affected person, authority, facilitator, public actor?
* What consequences could my analysis have for others?

---

**2. Am I currently in an affective position?**

* anger,
* loyalty,
* outrage,
* fear,
* hurt,
* shame,
* “I want to be right”.

→ If **yes**: read only structurally for now.  
→ **No scores, no D-profile, no public use.**  
→ Especially: do **not** actively use the **D-module**.

---

**3. Analysis instead of diagnosis?**

* Am I speaking about **roles**, **structures** and **enactments**?
* Or am I beginning to speak about “types”, “psyches”, “character” or “what someone is”?

Permitted:

> “In this role / under these conditions, this enactment shows …”

Not permitted:

> “This person is …”

---

**4. Are the guardrails active?**

* no use against children,
* no use against victims or structurally weaker persons,
* no use against marginalised groups,
* no labels (“3/10”, “inadult person”, “person without dignity”),
* no HR decisions,
* no separation decisions,
* no forensic use,
* no internet pillory,
* no humiliation diagnostics,
* explanation ≠ justification.

**Default:** `D` off.  
Activate the **D-module** only consciously, with clear purpose and safe frame.

If `D` is in play:

* describe only **D-enactments**,
* use **D-profile**, not dignity score,
* document role, context and time window,
* no person-level statements,
* `D₀` remains untouched.

---

**5. Can I pause if a guardrail breaks?**

If no:

> **Do not apply the model.**

Especially:

> Do not use the **D-module**.

---

### B.2 Case start template: 1-minute snapshot

**Purpose:**  
A neutral start before interpretation, scoring or dignity reading.

---

1. **Object under consideration**

   What are we looking at?

   * person **in role**,
   * relationship,
   * decision,
   * structure,
   * institution,
   * procedure,
   * rule,
   * discourse,
   * narrative.

   > Do not use `A` as shorthand for the object here; `A` is reserved for awareness / A-score notation.

2. **Context / setting**

   * place,
   * time,
   * relevant conditions,
   * existing rules,
   * pressures,
   * dependencies,
   * conflicts,
   * protection goods.

3. **Roles involved**

   Who is involved, **in which roles**?

   * not as “person profiles”,
   * not as character types,
   * not as moral ranks.

4. **Publicness**

   Private? Semi-public? Institutional? Public? Media-amplified?

   Consider:

   * `A-P` — awareness of publicness,
   * `P-PU` — public agency / power to act in public,
   * `D-P` — public dignity in practice, if applicable.

   Who is particularly exposed to:

   * public shaming,
   * reputational damage,
   * symbolic degradation,
   * self-branding pressure,
   * algorithmic amplification?

5. **Dominant asymmetry**

   Which asymmetry catches the eye first?

   * knowledge,
   * power,
   * responsibility,
   * risk,
   * public exposure,
   * interpretive authority,
   * dignity effects.

→ After this, move into the deeper structure.

---

### B.3 `A–C–R–P` analysis template — with optional `D` observation

**Purpose:**  
Basic structural profile before any band or decision.

`D` may be noted only when the guardrails are fulfilled.  
`D` is not folded into the **A-score**.

---

#### `A` — Awareness

* What did this role know?
* What could it realistically have known?
* Which information was available?
* Were there warning signals, alternatives, affected parties, foreseeable consequences?
* Was there self-blindness, role confusion, publicness blindness or bias?

---

#### `C` — Coherence

* Do words, promises, decisions and actions line up?
* Were breaks named or covered up?
* Are there patterns over time?
* Is context used to simulate coherence?
* Are role shifts made explicit or hidden?

---

#### `R` — Responsibility

* Which responsibility points existed?
* Were they taken up, shifted, refused or hidden?
* Which burdens did the role actually carry?
* Were affected persons taken into account?
* Where were costs shifted downward or outward?

---

#### `P` — Power / power to act

* Which real levers did this role have?
* What could it realistically have done — not ideally, but under actual conditions?
* Which options were formal only, and which were real?
* Where does the **ceiling rule** apply?
* Where were children, victims or structurally weaker parties protected from over-attribution?

---

#### Optional look at `D` — observation only

Use only when the frame is safe and `D` guardrails are fulfilled.

Possible observations:

* visible self-devaluation,
* self-neglect,
* shame dynamics,
* degradation of others,
* public shaming,
* protest,
* refusal,
* protection of others’ dignity.

Do **not** evaluate `D` here.  
Record only possible **D-enactments** for a separate **D-profile**.

→ Result: preliminary **A-band** only after `A–C–R–P` have been reasoned.  
→ Bandwidth only, with short justification.

---

### B.4 `IA-box` (`T–J–TB–R`) — template

**Purpose:**  
Check whether an asymmetry is functional, `IA`-risky or clearly inadult.

---

#### 1. `T` — Transparent?

* Do those involved know what the rule, asymmetry or decision logic is?
* Is there clear communication?
* Who knows what?
* Who could realistically know what?
* Or is the structure kept deliberately or advantageously vague?

---

#### 2. `J` — Justified?

* Are there reasons that can be checked?
* Which protected good or legitimate purpose is served?
* Is the logic factual — or mainly power, image, affect, tradition, status?
* Does the justification drift with context, mood or audience?

---

#### 3. `TB` — Time-bound?

* Are there conditions, review points, durations?
* Is the asymmetry limited by purpose or phase?
* Or is the structure effectively “forever”?
* Are emergency rules silently becoming normal rules?

---

#### 4. `R` — Reversible?

* Are there real ways back?
* Are adjustment, exit, appeal, correction or review possible?
* Or are dignity, status, opportunity or belonging irreversibly damaged?
* Are return paths only formal, but practically blocked?

---

#### Result

> `functional asymmetry` / `IA risk` / `inadult asymmetry`

Short justification:

* Which criteria are fulfilled?
* Which criteria fail?
* Which immediate change would improve `T`, `J`, `TB` or `R`?

---

### B.5 `A-score` & `M-score` — template

---

#### B.5.1 `A-score` — maturity in practice

> **A-score boundary:**  
> The **A-score** describes enactment, not essence.  
> It is assigned to cases / situations / structures / episodes, not persons.  
> It is a working value, not a moral verdict.

**A-band:**  
`A ≈ x–y / 10`

**Time / role / context:**  
`________________________`

**Justification in 3–5 bullet points based on `A–C–R–P`:**

1. `A` — awareness:  
2. `C` — coherence:  
3. `R` — responsibility:  
4. `P` — power / power to act:  
5. Modulators / context:

**Do not include `D` in the A-number.**

Optional note:

> Visible D-enactments may be collected separately for the **D-profile**  
> if purpose, frame and guardrails are clear.

---

#### B.5.2 `M-score` — shared structural responsibility

> **M-score boundary:**  
> `M` describes shared structural responsibility, not guilt, fault, blame or moral worth.

**M-band:**  
`M ≈ x–y / 10`

**Role / position / time frame:**  
`________________________`

**Justification based on five factors:**

1. **Knowledge** (`A`)  
   What was known or realistically knowable?

2. **Power / control** (`P`)  
   Which levers were available?

3. **Predictability**  
   Were consequences realistically recognisable?

4. **Access to alternatives**  
   Were there real alternatives, or only theoretical ones?

5. **Serious integration attempt**  
   Were risks named, mitigated, corrected, integrated?

---

#### Ceiling rule check

* `predictability ≈ 0`?
* `access to alternatives ≈ 0`?

If yes:

> `M ≤ 4`

No high shared responsibility without predictability and real options.

---

#### D-link

* low `M` + high harm → protection, not blame.
* self-devaluation = `D₁/D₂` phenomenon, not an increase in `M`.
* high subjective guilt → `M`-check, not `M`-increase.

---

### B.6 Trajectory template

#### `A(t)`, `M(t)`, `RVR(t)`, optional `D(t)`

**Purpose:**  
Make movement visible instead of labels.

---

#### Timeline

`t₀ → t₁ → t₂ → …`

For each point:

* **A-band**
* **M-band**
* central responsibility points
* major context shifts
* role shifts
* learning movements or refusals
* tipping points
* ceiling rule relevance
* review / correction moments

---

#### `A(t)` — maturity trajectory

* rising,
* falling,
* zigzagging,
* plateauing.

Short notes:

* What became more mature?
* What deteriorated?
* What stabilised?
* Which modulators changed?

---

#### `M(t)` / `RVR(t)` — responsibility trajectory

* When was knowledge present?
* When did leverage increase or decrease?
* When did alternatives become real or disappear?
* Which responsibility points were used, shifted or refused?
* Where did the ceiling rule cap `M`?

---

#### Optional `D(t)` — dignity enactment trajectory

Only when `D` guardrails are fulfilled.

Describe, without number:

* more self-care,
* more self-devaluation,
* less public shaming,
* more dignity protection,
* increased `D-P` risk,
* movement from Level 2 to Level 1 in the D-Quick-Grid.

> `D(t)` is descriptive.  
> It is not a dignity score and not a person label.

---

### B.7 Role / publicness mapping

---

#### B.7.1 Role matrix

| Role | `A` | `C` | `R` | `P` | Publicness | Notes |
|---|---|---|---|---|---|---|
| Role X |  |  |  |  | private / semi-public / institutional / public / media | structural particularities |
| Role Y |  |  |  |  | private / semi-public / institutional / public / media | structural particularities |

Use this table to clarify:

* role expectations,
* role power,
* built-in asymmetries,
* responsibility points,
* public reach,
* dignity exposure.

---

#### B.7.2 Levels of publicness

* **Private**  
  1–2 affected persons, low reach, high intimacy.

* **Semi-public / social**  
  small groups, teams, scenes, communities.

* **Institutional**  
  organisations, authorities, offices, formal mandates.

* **Public**  
  broad visibility, reputation risk, public accountability.

* **Media-amplified**  
  archiving, algorithmic spread, symbolic escalation, public shaming risk.

---

#### B.7.3 Publicness consequences

Higher publicness typically increases relevance of:

* `A-P` — awareness of publicity,
* `P-PU` — public agency,
* `R-P` — public responsibility,
* `D-P` — public dignity in practice.

> Higher publicness = stronger obligation to prevent shaming, mislabelling, irreversible exposure and dignity damage.

---

### B.8 Guardrail checklist — practice form

**Use before analysis, before transmission, and before decisions.**

---

**General guardrails**

* ☐ Focus on roles, structures and enactments — not persons.
* ☐ No clinical diagnostics.
* ☐ No forensic use.
* ☐ No HR decisions about individuals.
* ☐ No child/youth diagnostics.
* ☐ No public pillory.
* ☐ No internet escalation / doxing / ranking format.
* ☐ No labels for persons (“X has A=3”, “Y is without dignity”).
* ☐ Structural critique instead of moral tribunal.
* ☐ Explanation ≠ justification.
* ☐ Document observations and assumptions separately.
* ☐ Document results with justification, not just scores.
* ☐ Own role and co-responsibility disclosed.

---

**Score hygiene**

* ☐ A-score is an **A-band**, not a person score.
* ☐ M-score is shared structural responsibility, not guilt.
* ☐ D-profile is qualitative, not a dignity score.
* ☐ IA-box is an asymmetry check, not a verdict.
* ☐ Scores are revisable.

---

**Ceiling rule / protection**

* ☐ Ceiling rule checked.
* ☐ Children, victims and structurally weaker parties protected.
* ☐ No victim-blaming.
* ☐ No “they should have just…” without checking knowledge, levers and alternatives.
* ☐ Low `M` + high harm read as protection signal, not blame signal.

---

**D guardrails**

* ☐ `D₀` remains untouchable.
* ☐ `D₁/D₂` describe enactments only.
* ☐ D findings always scenic: role + context + time window.
* ☐ Default: `D` off.
* ☐ D-module activated only with clear purpose and safe frame.
* ☐ No D use for humiliation diagnostics.
* ☐ No D use as public label.
* ☐ No D use against children, acutely traumatised persons or highly vulnerable groups.
* ☐ In vulnerable contexts: use `D` at most as protection signal, not assessment.
* ☐ If `D` creates more shame than clarity: dial `D` down, work on structures and protection.

---

**Transmission**

* ☐ Analysis has passed the final checklist.
* ☐ Bias / norm assumptions documented.
* ☐ Counter-perspective considered.
* ☐ Review or revision path defined.
* ☐ If not: keep as **working note**, not decision basis.

---

### B.9 Mini-toolkit for ad-hoc situations

**Purpose:**  
Short tools for quick situations.  
The Mini-toolkit is not a substitute for the Case Lens.

---

**1. “What do I actually know?”**

→ Short check against projection, hindsight and interpretation inflation.

---

**2. “What is the task of the role here?”**

→ Separates personal likes/dislikes from role logic.

---

**3. “Who carries which burden?”**

→ View of responsibility points and burden distribution.

---

**4. “Which real power is in the room?”**

→ Prevents immature expectations:

> “Why didn’t they just …?”

---

**5. “What would be a functional asymmetry?”**

→ Alternative to moral black-and-white.

Ask:

* What asymmetry is needed?
* How can it become transparent?
* How can it be justified?
* How can it be time-bound?
* How can it remain reversible?

---

**Optional addition for D topics**

Use only under guardrails:

> “Who is experiencing loss of dignity in practice here — shaming, self-devaluation, public exposure — and who has levers to change that?”

Focus remains on:

* configurations,
* roles,
* structures,
* protection,
* realistic next steps,

not on the “worth” of persons.

---

### B.10 Documentation template — for cases, workshops, audits

*For case work, workshops, audits; slim overview of the analysis based on B.2–B.7, with optional reference to the D-module in B.11.*

---

#### 0. Header / metadata

* **Case name / title:**  
* **Date of documentation:**  
* **Person/team doing the work:**  
* **Context / setting:**  
  *e.g. enforcement, youth welfare, organisation, team, project, media, education …*
* **Purpose of this documentation:**  
  *e.g. internal reflection, supervision, audit, training, case discussion*
* **Intended readers:**  
  *Who is supposed to see this documentation, and in what form?*

---

#### Short guardrail check

* [ ] minimal adulthood of those doing the work reflected
* [ ] role of observers clarified
* [ ] public/semi-public risk considered
* [ ] no HR / forensic / diagnostic / pillory use
* [ ] possibility of revision provided for
* [ ] D-module default-off unless explicitly justified

---

#### 1. Snapshot

*1–5 sentences: what is the case about — without diagnosis, without judgement?*

* **Short description of the case / scene:**

* **Central actors and roles:**

* **Open guiding question of the analysis / documentation:**

---

#### 2. Role mapping

*Who is being observed? Who has which role, which power, which responsibility?*

* **Object under consideration:**  
  *person in role, team, organisation, procedure, rule, structure, discourse …*

* **Role description of the object under consideration:**  
  *function, mandate, typical asymmetries of the role*

* **Further relevant roles / actors:**

  * Role 1 / function:
  * Role 2 / function:
  * Role 3 / function:

* **Observer position:**  
  *Who is analysing? From which role? With which power?*

* **Degree of publicness:**  
  *private / semi-public / institutional / public / media-amplified*

---

#### 3. `A–C–R–P` profile

*Structured short profile: what was done — with what awareness, coherence, responsibility and power?*

---

**`A` — Awareness**

* Real knowledge at time X:
* Warning signals / alternative information:
* Presumed blind spots:
* Role awareness (`A-R`):
* Publicness awareness (`A-P`), if relevant:

---

**`C` — Coherence**

* Official self-descriptions / narratives:
* Visible enactments:
* Word–deed coherence / breaks:
* Role/context coherence:

---

**`R` — Responsibility**

* Central responsibility points:
* Taking on / shifting / refusing responsibility:
* Consequences for those affected / third parties:
* Responsibility gaps:

---

**`P` — Power / power to act**

* Formal vs. factual scope for action:
* Used vs. unused alternatives:
* Levers available:
* Relevant applications of the **ceiling rule**:

---

**Short conclusion `A–C–R–P`**

2–4 sentences:

> …

---

#### 4. `IA-box` (`T–J–TB–R`)

*Assessment of the asymmetry: functional or `IA`-suspect?*

---

**`T` — Transparent?**

* What is visible / understandable for whom?
* Is there intransparency, taboo or informal power?

---

**`J` — Justified?**

* Official justifications of the asymmetry / rule:
* Factual logic vs. logic of power / image / affect:
* Protected good named?

---

**`TB` — Time-bound?**

* Clear durations, review dates, conditions?
* Tendency towards expansion?
* Emergency becoming normal?

---

**`R` — Reversible?**

* Practical ways of correction / revision / appeal / restoration:
* Factual barriers:
* Dependency, stigma, cost, risk?

---

**Interim conclusion IA-box**

> Assessment: `functional asymmetry` / `IA risk` / `inadult asymmetry`

Short reason:

> …

---

#### 5. `A-score` / `M-score` bands

*Bands instead of labels — tied to role, context and time window.*

---

**A-band — maturity in practice**

* Rough estimate: `A ≈ ___–___ / 10`
* Time / role / context:
* Short justification, oriented to `A–C–R–P`:

  1. `A`:
  2. `C`:
  3. `R`:
  4. `P`:

**D note, if relevant:**  
Detailed D findings are not included in the A-band. Use B.11.

---

**M-band — shared structural responsibility**

* Rough estimate: `M ≈ ___–___ / 10`
* Time / role / context:
* Short justification, oriented to five factors:

  1. Knowledge:
  2. Power / control:
  3. Predictability:
  4. Access to alternatives:
  5. Serious integration attempt:

**Ceiling rule**

* `predictability ≈ 0`?  
* `access to alternatives ≈ 0`?  
* Result: `M ≤ 4`? yes / no

---

#### 6. Trajectory

*Movement over time: `A(t)`, `M(t)`, optionally `D(t)`.*

---

**Important points in time and turning points**

* `t₀` — short description:

  * `A ≈`
  * `M ≈`
  * key context / role / power situation:

* `t₁` — short description:

  * `A ≈`
  * `M ≈`
  * key context / role / power situation:

* `t₂` — short description:

  * `A ≈`
  * `M ≈`
  * key context / role / power situation:

---

**Course in words**

2–5 sentences:

* learning movement,
* stagnation,
* tipping points,
* changes of power,
* responsibility shifts,
* structural changes.

---

#### 7. Open questions, blind spots & Meta Notes

*Where is the documentation uncertain, incomplete or potentially distorted?*

---

**Open questions**

* What is unclear for us?
* Which data / perspectives are missing?
* Which assumptions are weak?

---

**Bias risks**

* confirmation bias:
* hindsight bias:
* loyalty / status quo bias:
* in-group / out-group bias:
* halo / horn effects:

---

**Norm assumptions**

* Which concepts of fairness, reasonableness, responsibility or dignity are guiding us?
* From which normative position are possible `D₁/D₂` readings made?

---

**Intuition**

* Where did intuition enter?
* Was it checked afterwards? yes / no
* What evidence supports or contradicts it?

---

**Possible alternative interpretations**

* How could the same case look from another role?
* How could it look from the affected side?
* How could it look from outside our institution / milieu?

---

#### 8. Possible steps towards maturity / alternatives

*Options for action — functional, realistic, not overambitious.*

---

**Functional next step**

* What would be one role-consistent, realistic, reversible next step?

---

**Short-term feasible**

* What can be done immediately?

---

**Medium-term feasible**

* What structural changes are realistic?

---

**Overambitious or risky**

* What should this analysis not do?
* Where would intervention become overreach?
* Where could this become `IA` itself?

---

#### 9. Optional: reference to the D-module

Here no detailed D form is filled in.  
Only indicate whether and where `D` was activated.

---

**D-module used?**

* [ ] no
* [ ] yes, for the following roles / scenes:

  * Role / scene 1:
  * Role / scene 2:

---

**Documentation of D in practice**

Reference to separate D-profile note according to B.11:

> …

---

**D guardrails checked?**

* [ ] yes — scenic, context-bound, without person label
* [ ] open — D-module not activated for now
* [ ] no — D-module must remain off

> All detailed D findings are recorded only according to B.11  
> and are not incorporated into A/M bands.

---

### B.11 D-module — short grid for praxeological dignity

**Purpose:**  
Fast, descriptive capturing of D-enactments as an addition to A- and M-related analysis.  
No dignity score for persons.  
Only orientation and alarm aid for situations in which `D₁` or `D₂` visibly become relevant.

> **Default: `D` off.**  
> Activation only with clear purpose and fulfilled guardrails.

Forbidden uses:

* diagnoses about persons,
* use against children,
* use against acutely traumatised persons,
* use against highly vulnerable groups,
* public pillory,
* HR / forensic / ranking contexts,
* humiliation diagnostics.

---

#### B.11.1 `D-Quick-Grid` (`0–3`)

For a concretely defined:

* role,
* scene,
* context,
* time window.

> **D-Quick-Grid boundary:**  
> The **D-Quick-Grid** is a movement tool, not a label.  
> It shows where dignity in practice stands and what can be minimally improved —  
> never what a person is.

Preferred wording:

> “This constellation currently shows **level-2 D stress**  
> in this role / context / time window.”

Not:

> “This person is level 2.”

---

| Level | Short description | Typical indicators in practice | Model consequence |
|---|---|---|---|
| **0** | D not in focus / neutral / unremarkable | everyday fluctuations; no stable self-devaluation; no systematic self-neglect; no noticeable shaming or devaluation | D not actively worked on; focus on `A–C–R–P`, IA-box, A-score, M-score |
| **1** | banal / everyday drift | mild self-neglect; ironic self-devaluation; rough interaction style; “mild” devaluation normalised in the milieu | mark as everyday drift; small self-care or language reflection; context check |
| **2** | marked D stress / recurrent self-devaluation | recurring self-devaluation; repeated boundary overriding; withdrawal from care; shaming others; deliberate exposure; entitling group images | relevant D zone; read explicitly in trajectory and structure; focus on protection, alternatives, structural levers |
| **3** | hard D breaks / extreme zone | humiliation; dehumanisation; self-harm; extreme neglect; “trash” self-images; public or structural pillory; dehumanising language/images/practices | alarm zone — no fine-tuning; focus on protection goods; D-profile as documentation of injustice, not coaching material |

---

#### Important clarifications

* Levels describe **D-enactments**, not persons.
* Level 3 is **no moral verdict**, but a protection signal.
* Every level is recorded with role, context and time window.
* The grid is **state, not essence**.
* `D₀` is never abandoned.
* Damage cannot simply be undone, but the analysis asks which structural or role changes can make `D₁/D₂` possible again.
* The D-Quick-Grid does not replace the D-profile.
* The D-Quick-Grid does not flow into A/M bands.

Guiding question after every classification:

> **What would be one small, real action  
> that could make this constellation one level more dignified —  
> and who has `A` and `M` levers for that?**

---

#### B.11.2 Template: short D-profile notes

Use only when `D` guardrails have been checked.

---

**Role / context:**  
**Date / phase:**  
**Time window:**  
**Communication space:** self-reflection / professional-confidential / not public  
**D-profile purpose:** protection / clarification / documentation / structural critique

---

##### 1. `D₁` — self-treatment (`D-I / D-B`)

Examples of:

* self-care,
* self-respect,
* self-devaluation,
* excessive guilt taking,
* boundary protection,
* boundary collapse,
* bodily/material self-care or self-neglect.

Observed enactments:

> …

Context notes:

> …

---

##### 2. `D₂` — dealing with others (`D-R`)

Examples of:

* dignifying treatment of others,
* shaming,
* ridicule,
* refusal to degrade,
* protective action,
* protest,
* withdrawal,
* handling of dependencies and power.

Observed enactments:

> …

Context notes:

> …

---

##### 3. `D-P` — relation to publicness / world

Examples of:

* adaptation to demeaning structures,
* public shaming,
* exposure,
* self-branding,
* self-objectification,
* protecting vulnerable persons from publicity,
* public protest or refusal.

Observed enactments:

> …

Context notes:

> …

---

##### 4. D-Quick-Grid orientation for this phase

Optional orientation only:

* Level: `0 / 1 / 2 / 3`
* Wording:

> “This constellation currently shows level-__ D stress  
> in this role / context / time window.”

**D guardrails checked?**

* [ ] scenic
* [ ] context-bound
* [ ] role-bound
* [ ] time-windowed
* [ ] no global statement about persons
* [ ] no dignity score
* [ ] `D₀` untouched

---

##### 5. Possible steps of maturation in D-enactment

Small, realistic actions towards a more dignifying way of dealing:

* with oneself,
* with others,
* with publicness,
* with structures.

Focus on:

* power to act (`P`),
* real alternatives,
* protection,
* relief,
* role clarification,
* structural responsibility (`M`).

No assigning of guilt.

Prompt:

> “What would be a gentler or more dignifying way of dealing with myself / others —  
> one percent of change?”

---

#### Frame of the D-module

The D-module is:

* optional,
* deliberately activated,
* tightly framed by D guardrails,
* linked to `A–C–R–P` and `M`,
* focused on visible enactments,
* separate from A/M bands,
* reversible,
* protection-oriented,
* never judgemental of persons.

The grid serves **orientation**, not labelling.

---

### B.12 Concluding usage note

Appendix B provides **practice templates**, not additional theory.

The templates help users:

* slow down,
* clarify roles,
* document assumptions,
* reason A/M bands,
* check asymmetries through `T–J–TB–R`,
* keep `D` separate and protected,
* identify revision needs.

Whenever a template conflicts with a guardrail, the guardrail wins.

The practical rule remains:

> **Better one analysis less  
> than one analysis that turns structure-reading into person-labelling.**

Thus Appendix B translates the model into usable forms  
without weakening its core boundary:

> **Recognise the enactment — not the person.**
