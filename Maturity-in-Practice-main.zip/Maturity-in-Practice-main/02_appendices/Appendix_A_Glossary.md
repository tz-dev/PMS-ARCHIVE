---
document_id: MIP-APPENDIX-A
title: "Glossary of Key Terms"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical appendix extraction"
target_file: "02_appendices/Appendix_A_Glossary.md"
status: "split-full-version"
version: "v1"
appendix_id: "A"
appendix_role: "canonical glossary"
source_appendix: "Appendix A"
source_appendix_title: "Glossary of key terms"
core_references: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: ["Appendix B", "Appendix C", "Appendix D", "Appendix E"]
claim_mode: "definitional, praxeological, terminology-stabilising, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity terminology defined with D₀/D₁/D₂ distinction; D₀ untouchable; not person score"
mip_status: "canonical appendix block; direct extraction; terminology update; no content expansion"
split_rule: "include from Appendix A heading up to immediately before Appendix B heading"
---

# Maturity in practice — A praxeological anthropology: Appendix A — Glossary of Key Terms

## Appendix A — Glossary of key terms

---

### Maturity, enactment, adultness / inadultness

**Maturity in practice**  
Maturity understood as **visible practice**: it shows itself in concrete action under real constraints — time pressure, costs, risk, resistance, dependencies, publicity. What counts is the coherence of awareness, word, responsibility, power to act and dignity in practice — not self-description, good intention or a person’s “essence”.

**Enactment**  
The actual enactment of a role, decision or structure in a concrete context: what was done or omitted, when, with whom, under which conditions? In contrast to plans, intentions, motives or self-images (“I would have…”).  
The model reads **enactments**, not persons.

**Adultness in the model**  
Not a perfect list of virtues, and not a person rank. Adultness means a sufficiently stable enactment pattern across `A–C–R–P`: awareness is used, coherence is maintained or restored, responsibility is carried, and power to act is handled realistically.  
Dignity in practice (`D₁/D₂`) may be described alongside this in a **D-profile**, but it is not a person score and does not affect `D₀`.

**Inadultness in the model**  
Zones of immature, unintegrated or impulsive patterns that can weaken awareness, coherence, responsibility, power handling or dignity in practice. Inadultness is not a flaw in ontological dignity (`D₀`), but a field of development and risk.  
It may also contain raw energy for movement and innovation: courage, protest, boundary-testing, nonconformity, creativity.

**Maturation**  
Process in which adult and inadult parts are brought into accountable channels:

* inadult energy — impulse, creativity, protest — is not suppressed,
* but framed by roles, structures and responsibility,
* so that it does not become degrading or entitling,
* and can enable development, correction and change.

---

### Core parameters `A–C–R–P–D`

**`A` — awareness**  
What a role, person, group or system knows, could know, notices or refuses to notice: facts, risks, alternatives, affected parties, power relations, own blind spots.  
`A` also includes awareness of structural asymmetries, role position, publicity and bias — not just inner experience.

**`C` — coherence**  
The consistency between word, decision and deed across time, roles and contexts. Coherence means that commitments, values and rules remain comprehensible when costs arise — or that breaks are named, explained and corrected.

**`R` — responsibility**  
The question of carried burdens and consequences: who stands for what, who takes on which consequences, who tries to limit, repair or prevent harm? Responsibility means answering and carrying — not simply “being at fault”.

**`P` — power / power to act**  
Real scope for influence and action in a situation: who can decide, stop, change, escalate, de-escalate, leave, protect, redistribute, intervene? What is meant are effective levers, not only formal titles. `P` can be individual, social, institutional, cultural or public.

**`D` — dignity in practice**  
Quality of dignity enactment in concrete behaviour: how someone deals with themselves, with others, with public visibility and with the social world.  
In the model, `D` refers to `D₁/D₂` — observable dignity in practice — not to a person’s worth. `D₀` remains untouched.

**`A–C–R–P–D`**  
The full model notation. `A–C–R–P` forms the standard structural analysis core. `D` may be added as a protected dignity-in-practice layer when the guardrails are fulfilled.

---

### Levels of dignity & D submodules

**`D₀` — ontological dignity**  
Unconditional human worth — regardless of performance, behaviour, status, role, ability, biography or group. `D₀` is not measured, not graded and not assessed in the model. It is the normative constant: a human being remains dignified even when acting in degrading or self-degrading ways.

**`D₁` — self-dignity in practice**  
How someone treats themselves in practice: self-care, self-respect, self-contact, self-protection, self-neglect, self-devaluation, boundary protection. Operationally visible through `D-I` and `D-B`.

**`D₂` — relational dignity in practice**  
How someone treats others, relates to their environment, handles publicness and responds to degrading structures: respect, boundaries, fairness, protest, mirroring, refusal, shaming, exclusion, protection. Operationally visible through `D-R` and `D-P`.

**`D-I` — inner dignity / inner self-relationship**  
Self-treatment in the inner dimension: self-respect, self-contact, inner clarity, harsh self-talk, excessive guilt, self-devaluation.

**`D-B` — bodily/material self-care**  
Dignity in the physical, material and everyday treatment of oneself: food, sleep, hygiene, medical care, financial basics, boundaries, bodily safety.

**`D-R` — relational dignity**  
Dignity in relational enactments: dealings with others, boundaries, fairness, respect, refusal of degrading practices, protest, mirroring, protection or shaming.

**`D-P` — public dignity in practice**  
Dignity enactment under public conditions: visibility, reputation, public shaming, self-presentation, self-branding, exposure, protection of others in public space.

**D-enactments**  
Observable enactments of dignity in practice: self-care, self-neglect, self-devaluation, shaming, protection, refusal, protest, degradation, public exposure, restoration attempts.  
D-enactments are **scene-bound, role-bound and context-bound**. They do not define personhood.

**Self-devaluation**  
Repeated, visible devaluation of oneself in practice: derogatory self-talk, excessive guilt taking, self-damaging decisions, withdrawal from care, “I am not worth it.”  
In the model this is neither a diagnosis nor a moral accusation, but a `D₁/D₂` signal. It often indicates structural pressure, `IA`, shame, overload or low `M`.

**Self-degradation**  
A practical pattern in which someone treats themselves below their own dignity in practice. This may express inner collapse, protest, mirroring, survival strategy or adaptation to degrading conditions.  
Self-degradation does **not** reduce `D₀` and does **not** raise `M`.

---

### Asymmetries, roles, publicness

**Asymmetry**  
Unequal distribution of `A`, `C`, `R`, `P` or dignity-related interpretive power between those involved. Asymmetries are not automatically bad. They must be transparent, justified, time-bound and reversible.

**Functional asymmetry**  
An asymmetry that is factually meaningful for a task or protection good. It is transparent, justified, time-bound and in principle reversible. Examples include role-based asymmetries in education, care, law, supervision or protection — provided they remain bounded and reviewable.

**Inadult asymmetry (`IA`)**  
An asymmetry that protects self-image, comfort, dominance or power interests of the stronger side more than the matter at hand or a protection good. Typical patterns: intransparency, pseudo-justification, unboundedness, irreversibility, blocked correction, dignity violations.

**Asymmetry of interpretation**  
A form of asymmetry in which one side has interpretive dominance over meanings: it decides how behaviour, motives, dignity, blame or normality are to be read.  
Asymmetries of interpretation are especially `IA`-prone because they do not only affect others — they define them.

**Role**  
A bundle of expectations, rights, duties and interpretive frames in a context: parent, manager, learner, patient, client, activist, public figure, observer.  
The model analyses the **role in the concrete setting**, not the whole personality.

**Role awareness (`A-R`)**  
Awareness of the role from which one is acting or speaking, and awareness of the role attributed by others. Low `A-R` produces role confusion, semantic drift and phantom intentions.

**Object of observation**  
The person, role, team, institution, procedure, rule, discourse or narrative being analysed. The object of observation must be clarified before any `IA`, `A-score`, `M-score` or `D` reading.

**Observer position**  
The role and power position from which analysis is conducted. Observers may be researchers, facilitators, leaders, affected persons, media publics or institutions.  
Every observer position creates its own asymmetry and therefore requires self-implication.

**Publicness (`A-P / P-PU / D-P`)**  
Degree of visibility, public reach and public dignity relevance of a role or enactment.

* `A-P` = awareness of publicity / public-media awareness.
* `P-PU` = power to act in public contexts / public agency.
* `D-P` = dignity in practice under public conditions.

The higher `A-P`, `P-PU` and `D-P`, the higher the need for role clarity, responsibility and protection against public degradation.

---

### `IA-box`, role logic, semantic drift

**IA-box (`T–J–TB–R`)**  
Four-question grid for evaluating asymmetries:

* **`T` — Transparent?**  
  Who knows what, and who could realistically know it?
* **`J` — Justified?**  
  Does the asymmetry serve a testable purpose or only one side’s advantage?
* **`TB` — Time-bound?**  
  Is the asymmetry limited by time, conditions or review points?
* **`R` — Reversible?**  
  Are there real ways back, or only theoretical ones?

Decision labels:

* `functional asymmetry`
* `IA risk`
* `inadult asymmetry`

**`T` — transparency**  
Visibility and understandability of rules, information, responsibility paths and decision logic.

**`J` — justification**  
Testable purpose of an asymmetry: protection, organisation, training, risk limitation, care, procedural fairness. Pure status, tradition or unilateral advantage are not sufficient.

**`TB` — time-boundedness**  
Limitation of an asymmetry by duration, condition, review point or exit criterion.

**`R` in the IA-box — reversibility**  
Real possibility of correction, return, exit, revision or appeal.  
This is different from `R` as responsibility in `A–C–R–P–D`.

**Role confusion**  
Situation in which one’s own role, the other’s role or the attributed role is unclear or unstable. Role confusion creates role vacuum, projection, conflicting expectations and responsibility breakdown.

**Phantom intention**  
An intention attributed to someone without being named, evidenced or clearly derivable from action — but felt as certain. Phantom intentions often arise from role confusion and semantic drift.

**Semantic drift**  
Systematic shift in the meaning of the same action when roles, contexts, relationships or power relations are not shared.  
Semantic drift is a central `IA` risk because interpretation itself becomes an act of power.

**Faulty dignity-interpretation**  
A dignity reading that confuses `D₁/D₂` with `D₀`, ignores relational or structural context, or turns a D-enactment into a person-level judgment. Faulty dignity-interpretation can itself become structural `IA`.

---

### Scores, bands, responsibility

**A-score**  
A structured working value for the maturity in practice of an enactment, case or situation. It describes **enactment**, not essence.

Formal notation:

> `A(H)` = maturity in practice of an enactment, case or situation `H`.

The A-score is assigned to cases, situations, structures or episodes — not persons. It is a **band**, not a precise digital value.

**A-band**  
Estimated maturity zone of an enactment, e.g. `3–4`, `5–6`, `6–7`. A-band expresses uncertainty and avoids fake precision.

**A-score boundary**  
The A-score describes how maturely something was enacted under given conditions. It does not measure worth, dignity, love, pain, biography or personhood.

**Subscore notation**  
The four maturity dimensions within the A-score:

* `A(A)` = maturity of awareness
* `A(C)` = maturity of coherence
* `A(R)` = maturity of responsibility
* `A(P)` = maturity of action / power

These are not the same as awareness submodules such as `A-R` or `A-P`.

**Calibration bands `0–10`**  
A-score zones from collapse to ideal limit value. They are **enactment zones**, not person ranks.

* `0–1` = collapse zone
* `2–3` = clearly inadult enactment
* `4–5` = everyday mixed zone
* `6–7` = solid adultness
* `8–9` = high adultness under severity
* `10` = ideal limit value / orientation, rarely a real case score

**M-score**  
Structured estimate of shared structural responsibility for the overall trajectory and consequences of a situation.

Formal notation:

> `M(A)` = shared responsibility of actor `A`.

Here `A` is an actor placeholder, not the `A` axis for awareness.

**M-score boundary**  
`M` describes shared structural responsibility, not guilt, fault, blame or moral worth.  
It evaluates roles, positions, leverage and access to alternatives — not persons.

**Shared responsibility**  
Responsibility for a course of events distributed across roles, structures and decision points: who knew what, who had levers, who could prevent, limit, protect, correct or make transparent?  
Shared responsibility is graded, not all-or-nothing.

**M-band**  
Estimated band of shared structural responsibility. Like the A-score, it is not exact measurement. It helps distinguish high leverage / responsibility from low responsibility viability.

**High `M`**  
High structural responsibility / leverage: strong knowledge, power, predictability, alternatives and weak or late integration attempts.

**Low `M`**  
Low responsibility viability / primarily affected: little knowledge, minimal leverage, low predictability, no real alternatives, recognisable attempts to cope or protect oneself.

**Five factors of shared responsibility**  
The M-score uses five structural factors:

1. **Knowledge** (`A`)
2. **Power / control** (`P`)
3. **Predictability**
4. **Access to alternatives**
5. **Serious integration attempt**

**Ceiling rule**  
Protection rule against victim blaming in responsibility attribution:

> `predictability ≈ 0` or `access to alternatives ≈ 0` → `M ≤ 4`

No high shared responsibility without predictability and real options.

**Responsibility points**  
Moments where a role or position could realistically have acted differently: deciding, stopping, warning, disclosing, protecting, redistributing, escalating, de-escalating.

**`RVR(t)` — responsibility–viability–range over time**  
Description of how responsibility viability changes over time: what was known, possible, permitted and done at each phase?  
`RVR(t)` creates a responsibility curve, not a point verdict.

**Self-devaluation does not raise `M`**  
A central rule: someone feeling guilty, making themselves small or treating themselves badly does not thereby gain structural responsibility for the system. High subjective guilt triggers an `M`-check, not an `M` increase.

---

### D-module, D-profile, D-Quick-Grid

**D-module**  
Optional, protected module for reading dignity in practice. It looks at `D₁/D₂`: self-treatment, relational treatment, public dignity enactments, degradation, protest, self-devaluation, restoration.  
It never evaluates `D₀`.

**D-module boundary**  
The D-module is a high-risk analytic layer. It is used only when it brings more clarity than shame, and only under guardrails. It is not a diagnostic tool, not a dignity score, not a pillory and not a ranking system.

**D-profile**  
Qualitative description of D-enactments in a case: self-care vs. self-neglect, self-respect vs. self-devaluation, protection vs. degradation of others, protest vs. adaptation, public dignity dynamics.  
The D-profile is separate from A-score and M-score.

**D-profile boundary**  
`D₀` remains outside the card. `D₁/D₂` describe D-enactments, not personhood. No numbers. Qualitative bands only.

**D-profile sheet**  
Practical template for documenting `D₁/D₂` under role, context and time window. It contains sections for:

* `D₁` — self-enactment / self-treatment (`D-I/D-B`)
* `D₂` — relational dignity (`D-R`)
* `D-P` — dignity under publicity
* linking `A–M–D` without mixing
* guardrails and use

**D-Quick-Grid**  
Compact quick orientation grid for visible D-enactments on the 1-pager. It does not replace the D-profile.

Levels:

* **Level 0** — D not in focus / neutral / unremarkable
* **Level 1** — banal / everyday drift
* **Level 2** — marked D stress / recurrent self-devaluation or shaming
* **Level 3** — hard D breaks / extreme zone / alarm zone

**D-Quick-Grid boundary**  
The D-Quick-Grid is a movement tool, not a label. It shows where dignity in practice stands in a specific role, context and time window — never what a person is.

Preferred wording:

> “This constellation currently shows level-2 D stress in this role / context / time window.”

Not:

> “This person is level 2.”

**D-break**  
An enactment or structure in which dignity in practice is clearly violated: humiliation, dehumanising language, deliberate shaming, forced exposure, degradation of others, extreme self-devaluation, self-harm, hard public degradation.  
A D-break is an alarm and protection signal, not a diagnosis.

**D₀ red zone**  
The zone in which ontological dignity is denied in language or practice — for example through dehumanising terms such as “subhuman”, “scum”, “worthless human being”.  
Where `D₀` is denied, legitimate `IA` analysis ends.

**Use-context red zone**  
Contexts in which the model itself must not be used: clinical diagnostics, HR decisions about individuals, forensics, public pillorying, child/youth diagnostics, humiliation diagnostics, doxing, ranking formats.  
This red zone concerns the use of the tool, not the content of a scene.

**D heatmap / `IA/D` heatmap**  
Visual or conceptual grid that marks concentrations of `IA` and dignity-in-practice problems in a field, organisation, milieu or political/cultural structure. It identifies reform and protection needs, not person rankings.

---

### Tools, sheets, quick access

**Case Lens**  
Step-by-step protocol for full `IA` analysis. It structures a case, but does not decide the case by itself.

Standard path:

1. Snapshot
2. Frame vs. variability
3. A-score trajectories
4. `IA` localisation
5. `RVR(t)`
6. Decision: maintain / balance / change–stop
7. KPIs & review date

**Case Lens boundary**  
The Case Lens is a structuring protocol, not an automated decision engine.

**Score sheets**  
Structuring aids for A-score, M-score, IA-box and D-profile. They organise observations, detect blind spots and keep decisions transparent.  
They are not rankings.

**A-score sheet**  
Template for documenting A-related observations and an integrated A-band.

**M-score sheet**  
Template for documenting knowledge, power/control, predictability, access to alternatives, integration attempt, raw `M`, ceiling rule and valid M-score.

**IA-box sheet (`T–J–TB–R`)**  
Template for examining one asymmetry through transparency, justification, time-boundedness and reversibility.

**D-profile sheet (`D₁/D₂`)**  
Template for qualitative dignity-in-practice description. No numbers. No personhood claims.

**Trajectories**  
Courses over time rather than point labels:

* `A(t)` — maturity in practice across time
* `M(t)` — shared responsibility across time
* `D(t)` — dignity enactment across time
* `RVR(t)` — responsibility viability across time

Guiding formula:

> We write trajectories, not labels.

**System-1 / System-2 micro-tool**  
Acute-situation tool that interrupts automatic reaction and inserts a minimal reflective moment.

Mnemonic:

> `STOP–FRAME–ROLE–STEP`

**Mini-toolkit**  
Middle layer between “nothing” and Full Lens. It may include context cards, light A/M bands, IA-box light and optional D-notes. It offers just enough structure to see more fairly without over-diagnosis.

**Visual quick access / 1-pager**  
Condensed access surface for everyday use: audit checklist, conflict loop, D-Quick-Grid. It functions as emergency brake and orientation aid.

**Quick-access boundary**  
The 1-pager does not replace the full model, guardrails or contextual judgement.

**Audit checklist**  
Five-point pre-transmission gate for checking whether an `IA` analysis is robust enough before it goes outward or becomes a basis for decisions.

**Conflict loop**  
Four-step orientation tool for conflict situations:

1. STOP & FRAME
2. ROLE
3. IA-spot
4. STEP & REVIEW

The conflict loop gives orientation under pressure. It does not guarantee resolution.

**Praxeological final checklist**  
Final filter before an analysis becomes actionable as decision, document, publication, internal communication, policy or guideline. It checks satisfaction, parameters, role clarity, projection, publicity, multi-context, D-cleanliness and the Grail sentence.

**Grail sentence**  
Core self-check question:

> “Am I touching behaviour — or beginning to negotiate dignity?”

It marks the boundary between praxeological description and the inviolable domain of `D₀`.

**Working note**  
Status of an analysis that is not mature for transmission. If guardrails fail, projection dominates or core questions remain open, the analysis may remain a working note but must not become a decision basis.

**Not mature for transmission**  
Status of an analysis that fails the final checklist or violates guardrails. It is not ready for publication, institutionalisation or third-party use.

---

### Language phenomena & interpretation risks

**D finding via language**  
Recognition that devaluing, degrading or dehumanising language itself counts as a problem of `IA` and `D₁/D₂` on the side of the speakers — especially when language denies or undermines `D₀`.

**Interpretation `IA`**  
Inadult asymmetry arising when readings of dignity, maturity or responsibility are distorted: `D₁` is diagnosed as defect, `D₂` protest is ignored, or a context-bound D-enactment is turned into a character judgment.

**Dignity bonus / dignity penalty**  
Bias effect in which favoured persons or groups are interpreted as more dignified and disfavoured persons or groups as less dignified, despite similar enactments.  
These are warning terms, not scores.

**Hindsight risk**  
Bias risk in which inflated predictability produces inflated M-score:

> inflated predictability → inflated `M-score`

**Normative position**  
The explicit cultural, moral, biographical or disciplinary lens from which `D₁/D₂` are being read. Every dignity reading must name its normative position.

**Cultural-lens rule**  
Rule for dignity reading across cultures and milieus:

> “I do not know what it feels like to be you in your culture —  
> I describe only what I see in the enactment  
> and name my own lens.”

**Meta Notes block**  
Documentation block for bias, intuition, norm assumptions and dignity readings. Typical fields:

* Bias risks
* Norm assumptions
* Intuition checked yes/no
* Dignity reading
* Possible alternative interpretations

**Meta-attitude**  
Use posture required for the model: no claim to final truth, willingness to revise, active search for counterexamples, invitation to critique, awareness that dignity readings are interpretations of enactments, not truth about persons.

**Meta-guardrail**  
Without meta-attitude, dignity language falls back into moral labelling.

---

### Bias, intuition, norm change

**Bias**  
Systematic, recurring distortion in perception, evaluation and memory. Bias is baseline noise, not an exception.

**Bias-awareness**  
Part of `A` — awareness. Ignoring bias means working ideologically, not praxeologically.

**Confirmation bias**  
Tendency to seek what confirms the starting hypothesis and overlook contradictory signals.

**Hindsight bias**  
Tendency to see outcomes as more predictable after the fact. In the model, this risks inflating `M-score`.

**Status quo / loyalty bias**  
Tendency to protect existing structures, groups or loyalties from critique.

**Halo / horn effects**  
Tendency to let one positive or negative trait colour the whole assessment. Can produce dignity bonus / dignity penalty.

**In-group / out-group bias**  
Tendency to judge “our” side more generously and “the others” more harshly.

**Intuition**  
Fast, dense impression or condensation of experience. In the model, intuition is a **sensor and trigger**, not a judge. It is hypothesis, not proof.

**Norm change**  
Movement of what counts as normal, acceptable, fair or dignified across time, generations, cultures and discourses. Norm change is not an obstacle to the model; it is subject matter.

---

### Domain modules

**Domain Modules**  
Field-specific lenses for applying the same core model to different contexts. They do not introduce a new model and do not replace domain expertise.

**Domain-module boundary**  
Domain Modules are lenses and hotspot maps, not new models, not expert substitutes and not domain authorities.

**Same axiomatic core. Different lens. Different depth. Different activated modules.**  
Formula for domain adaptation: the core remains `A–C–R–P–D`, but each field activates different questions and sensitivities.

**Psychology (performative)**  
Domain lens for observable patterns of enactment in conflict, closeness, stress, role mixing, self-treatment. It is not clinical diagnosis, disorder classification or therapy planning.

**Philosophy & Religion**  
Domain lens for interpretive authority, dignity norms, rituals, teachings and dignity in practice. It does not decide ultimate doctrine or monopolise dignity.

**Sociology & Politics**  
Domain lens for power, public responsibility, symbolic politics, institutional structures and dignity effects. It does not replace political judgement, social-scientific expertise or democratic process.

**Culture / Media**  
Domain lens for narratives, representation, publicity and dignity effects. Publicity is not truth; virality is not justification; visibility increases reversibility risk.

**Practice Ethics**  
Domain lens for institutionally intended asymmetries in law, organisation and education.

**Practice-ethics boundary**  
MIP may structure reflection. It does not replace legal judgement, organisational due process, educational responsibility or professional accountability.

---

### Meta structure: guardrails, red zones, critique, revision

**Guardrails**  
Mandatory use conditions of the model. They protect against misuse, person-ranking, diagnostic overreach, moral sorting and dignity violation. Without guardrails, any `IA` analysis is invalid.

Core guardrails include:

* structure before person,
* dignity protection and anti-ranking,
* duty of context and transparency,
* reciprocity and self-application,
* option for improvement instead of judgement,
* versioning and reversibility.

**Guardrail rule**  
Without guardrails, any `IA` analysis is invalid.

**Minimal adulthood**  
Entry condition for using the model: willingness to self-reflect, accept correction, avoid humiliation, protect dignity and see oneself as involved.

**Self-implication**  
Anyone using the model displays their own `A–C–R–P–D`: awareness, coherence, responsibility, power handling and dignity in practice. The analysis itself becomes an enactment.

**Profile ≠ person**  
Profiles describe structures and enactments. They do not describe the essence or worth of a human being.

**System axiom**  
No enactment is purely individual. Every `IA` or maturity finding must also identify structural co-causes: roles, organisations, modulators, framework conditions.

**Red zone**  
Forbidden use contexts: clinical diagnostics, therapy planning, HR decisions about individuals, child/youth diagnostics, forensics, public pillorying, doxing, ranking formats, humiliation diagnostics.

**Victim/child protection**  
Principle that analyses and interventions must not add further burdens to vulnerable persons. No adult norm benchmark is applied to children and young people. No “they should have just…” where knowledge, levers or alternatives were absent.

**Countercritique**  
Critique of the model and its assumptions. Countercritique is not an attack on the model but part of its maturity in practice.

**Critique readiness**  
The model remains open to objections, counterexamples, revisions and better proposals.

**Model limits**  
Explicit boundaries of what MIP does not promise: it does not determine inner life, guarantee justice, replace therapy, settle guilt, deliver morally correct politics or judge who is worthy.

**Working version**  
The model is a working version because maturity in practice must itself prove itself under conditions.

**Revision obligation**  
Revision is not optional. Analyses must be revised when counterexamples, other perspectives, structural critique or reality refute them.

**Toolbox with an ethics rider**  
MIP is not a doctrine. It is a toolbox with an ethics rider.

Core condition:

> Maturity in practice matters more than being right —  
> and dignity in practice more than winning.

**User commitments**  
Those who use the model commit to:

1. self-implication — seeing their own roles, biases, norm assumptions and dignity images,
2. revision under counter-evidence — revising analyses when reality or counter-voices refute them.

**Permanent task**  
Maturity in practice and dignity in practice remain ongoing work — for persons, structures and the model itself.
