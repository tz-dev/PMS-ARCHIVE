---
document_id: MIP-APPENDIX-D
title: "Modular Adaptation to Disciplines and Fields"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical appendix extraction"
target_file: "02_appendices/Appendix_D_Discipline_Adaptation.md"
status: "split-full-version"
version: "v1"
appendix_id: "D"
appendix_role: "canonical discipline adaptation map"
source_appendix: "Appendix D"
source_appendix_title: "Modular adaptation to disciplines/fields"
core_references: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: ["Appendix A", "Appendix B", "Appendix C", "Appendix E"]
claim_mode: "modular, field-adaptive, discipline-sensitive, lens-based, praxeological, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice adapted by field lenses; D₀ untouchable; not person score"
mip_status: "canonical appendix block; direct extraction; domain-boundary alignment; no new model logic"
split_rule: "include from Appendix D heading up to immediately before Appendix E heading"
---

# Maturity in practice — A praxeological anthropology: Appendix D — Modular Adaptation to Disciplines and Fields

## Appendix D — Modular adaptation to disciplines / fields

Praxeological anthropology is designed as a **domain-agnostic core framework**,  
but can be **profiled** differently depending on discipline and field.

The axiomatic core remains unchanged:

* `A–C–R–P–D`,
* `D₀` as untouchable ontological dignity,
* `D₁/D₂` as dignity in practice,
* `D-I`, `D-B`, `D-R`, `D-P` as operational D-submodules,
* role and context logic,
* **A-score**,
* **M-score**,
* **IA-box (`T–J–TB–R`)**,
* guardrails and red zones.

> **Appendix-D boundary:**  
> Discipline adaptation does **not** create new models.  
> It creates **field lenses** and **hotspot maps** for the same model core.

> **Non-replacement boundary:**  
> MIP may structure reflection.  
> It does **not** replace legal judgement, clinical judgement, social-scientific expertise, political judgement, educational responsibility, organisational due process, therapeutic work or professional accountability.

The following overview shows how the same core model generates different **use profiles**.

It is not exhaustive.  
It is a **working map** that can be extended with further fields and specialisations.

> **Same axiomatic core. Different lens. Different depth. Different activated modules.**

---

### D.0 Discipline adaptation map

The table below names **field lenses**, not new submodels.  
The “function mode” describes the typical use of the lens — not disciplinary authority.

| Discipline / field | Primary lens function | Secondary lens functions | Activated hotspots / modules | Typical questions |
|---|---|---|---|---|
| **Sociology** | structural description | reform orientation | `D-R`, `D-P`, **IA-box**, roles, micro–macro coupling | *How do structures generate certain dignity enactments?* |
| **Political science** | power/publicness analysis | norm visibility | `D-R`, `D-P`, **IA-box**, `A-P`, `P-PU`, public responsibility | *How do morally charged boundary dynamics arise?* |
| **Law** | procedural reflection | proportionality / dignity protection | `D₀`, **IA-box**, responsibility, role, reversibility | *Is a measure transparent, justified, time-bound and reversible?* |
| **Ethics** | normative clarification | intervention framing | `D₀`, `D₁/D₂`, responsibility, reversibility, guardrails | *Which interventions protect or violate dignity in practice?* |
| **Psychology (performative)** | pattern clarification | self-reflection / support | `D-I`, `D-B`, `A–C–R–P`, trajectories, modulators | *How does self-devaluation appear as enactment under conditions?* |
| **Coaching / supervision** | reflective intervention support | role clarification | `D-I`, `D-B`, conflict loop, roles, `A–C–R–P`, reversible steps | *How can self-contact and power to act be stabilised without diagnosis?* |
| **Pedagogy / education** | development support | protection / boundary design | `D-I`, `D-R`, role, responsibility, ceiling rule | *Which form of boundary-setting preserves dignity and learning?* |
| **Organisation / leadership** | structural clarification | intervention planning | roles, `P`, responsibility, `D-R`, **IA-box**, M-score | *Where does leadership become inadult over-power?* |
| **Corporate culture** | culture description | norm and process review | `D-R`, `D-B`, modulators, power, transparency | *How do we build a dignity-protective culture?* |
| **Media studies** | representation / publicity analysis | norm visibility | `D-P`, interpretive power, publicity scaling, semantic drift | *How do digital pillories and public degradation patterns work?* |
| **Public communication** | communication design | escalation prevention | `D-P`, role mechanics, `A-P`, `P-PU`, `A–C–R–P` | *How can one speak publicly without violating dignity?* |
| **AI governance / tech ethics** | asymmetry audit | responsibility mapping | **IA-box (`T–J–TB–R`)**, responsibility, transparency, `D-P`, M-score | *When is algorithmic asymmetry legitimate?* |
| **Philosophy / anthropology** | axiomatic clarification | conceptual critique | `D₀`, maturity in practice, base axioms, model limits | *How do we explain action without substantialising persons?* |

---

### D.0.1 Clarifying the function modes

The following terms are used strictly as **lens functions**:

* **structural description**  
  — making roles, asymmetries and enactments visible.

* **pattern clarification**  
  — identifying repeated enactment patterns without diagnosing persons.

* **norm visibility**  
  — naming which values, dignity concepts or responsibility assumptions are guiding an analysis.

* **intervention support**  
  — structuring possible next steps without replacing professional accountability.

* **proportionality / process reflection**  
  — checking whether procedures remain transparent, justified, time-bound and reversible.

Not meant:

* clinical diagnosis,
* disorder classification,
* therapy planning,
* forensic assessment,
* HR assessment,
* legal decision,
* political verdict,
* doctrinal judgement,
* educational labelling.

---

### D.0.2 General discipline-adaptation rule

Every discipline-specific use must answer four questions before application:

1. **Which field lens is active?**  
   Sociology, law, education, media, coaching, politics, etc.

2. **Which modules are activated?**  
   `A–C–R–P`, **A-score**, **M-score**, **IA-box**, **D-profile**, **D-Quick-Grid**, trajectories.

3. **Which professional boundary applies?**  
   Does the case touch legal, clinical, forensic, HR, child/youth, educational or therapeutic responsibility?

4. **Which guardrails limit the use?**  
   Red zones, no person ranking, no public pillory, no dignity score, `D₀` untouchable.

If a discipline lens would lead users to overstep their competence, the correct use is:

> **Stop the model at reflection.  
> Do not turn it into a decision instrument.**

---

### D.1 Example A — Political science & public communication

#### Mode: structural description → norm visibility

#### 1. Context and problem statement

Modern democratic publics increasingly exhibit **morally charged boundary dynamics** and **communicative exclusion loops**.

Actors publicly declare certain positions or groups “unacceptable” or “non-dialogue partners,” often coupled with moral attributions.

Typical effects:

* mutual **shaming** and **delegitimisation**,
* narrowing of negotiation space,
* escalation spirals in which each side frames the other as fundamentally “unworthy” of discourse.

Praxeological anthropology allows these dynamics to be analysed **structurally**, without taking substantive sides.

> **Boundary:**  
> This lens does not decide political truth.  
> It reads how public enactments handle power, responsibility and dignity in practice.

---

#### 2. Activated modules

**Primary:**

* `D-R` — relational dignity,
* `D-P` — public dignity in practice,
* **IA-box (`T–J–TB–R`)**.

**Secondary:**

* role mechanics,
* `A-P` — awareness of publicity,
* `P-PU` — public agency,
* public responsibility (`R-P`),
* micro–macro coupling,
* modulators such as publicity level, time pressure and power-preservation pressure.

---

#### 3. Analysis of the action situation

##### 3.1 Role clarification

Relevant roles include:

* **political actors**  
  — representatives of positions, parties, movements or institutions;

* **media actors**  
  — selection, framing, amplification of conflict;

* **public / audience**  
  — resonance field, amplifier, secondary actors in social media.

Praxeological anthropology begins with:

> Who acts here in which role, towards whom, before which audience, and with what expectations?

This reveals that political statements are rarely “private”.  
They function as **role enactments** with consequences for `D-R` and `D-P`.

---

##### 3.2 Relational dignity (`D-R`)

In political escalation phases, the following patterns are common:

* **delegitimising the opposing side**  
  (“no longer part of legitimate discourse”),

* **personalising attributions**  
  (“these people are …”),

* **moral elevation of one’s own side**  
  (“only our position preserves dignity / democracy / morality”).

In the model’s logic, these represent distortions in **relational dignity (`D-R`)**:

* the opposing side is no longer addressed as a legitimate conversational partner,
* recognition is withdrawn,
* relational dignity in practice decreases.

Important:

> The model is not evaluating the content of political positions.  
> It evaluates the manner in which dignity, role and power are handled in enactment.

---

##### 3.3 Public dignity (`D-P`)

Because political communication typically occurs in high publicity, **`D-P`** becomes crucial:

* actors stage themselves as moral authorities,
* opponents are publicly downgraded, mocked or symbolically excluded,
* media and social platforms intensify these patterns by prioritising polarising content,
* shaming becomes archived and difficult to reverse.

Praxeological anthropology reads these as **public dignity practices** affecting:

* self-presentation,
* the public dignity of addressees,
* the reversibility of reputational harm,
* the public’s expectations of legitimate disagreement.

---

#### 4. IA-box: evaluating asymmetrical communication

Political communication is inherently asymmetrical.  
Differences in reach, resources and institutional power are unavoidable.

Thus, the question is not:

> “Are there asymmetries?”

but:

> **Are these asymmetries functional and bounded —  
> or already inadult asymmetries (`IA`)?**

The **IA-box (`T–J–TB–R`)** tests:

1. **`T` — Transparent?**  
   Are criteria for exclusion, distancing or delegitimisation clear to actors and the public?

2. **`J` — Justified?**  
   Are there verifiable, substantive reasons — or do moral labels dominate?

3. **`TB` — Time-bound?**  
   Is distancing framed as temporary or condition-bound — or permanent?

4. **`R` — Reversible?**  
   Is it realistically possible to re-enter discourse through changed behaviour, clarification or correction?

Typical findings in escalated settings:

* **`T` low:** motives and criteria are vague.
* **`J` selective:** moral argumentation replaces structured justification.
* **`TB` missing:** distancing is presented as final.
* **`R` very low:** almost no pathway back to legitimacy.

In model terms, these are **IA hotspots**:

> Asymmetries are no longer limited by responsibility, transparency and correctability.

---

#### 5. Micro–macro feedback loops

Praxeological anthropology shows how **micro-level enactments** and **macro-level structures** reinforce each other:

* **Micro level:**  
  a speech, TV appearance or post publicly humiliates opponents (`D-R` ↓, `D-P` ↓).

* **Meso level:**  
  parties, movements and media replicate these moves, forming communication routines based on systematic downgrading.

* **Macro level:**  
  political culture shifts:

  * decreasing coalition and dialogue capacity,
  * entrenched polarisation,
  * framing compromise as betrayal.

The model highlights:

> What begins as a single enactment can, through repetition, become a structural dignity-constraining pattern.

---

#### 6. Result: what the model reveals

Applying praxeological anthropology to political and communicative contexts shows:

1. Political escalations can be reconstructed through `D-R`, `D-P` and the **IA-box** without judging substantive positions.

2. Morally charged boundary practices are not only political tactics, but **dignity practices** shaping relations.

3. **Inadult asymmetries** — non-transparent, unjustified, unbounded, irreversible — cause long-term structural damage:

   * loss of trust,
   * impoverished discourse,
   * reduced willingness to take responsibility or correct errors.

4. The model identifies possible intervention points, for example:

   * role clarification,
   * framing distancing as time-bound rather than final,
   * explicit criteria for reintegration,
   * separating critique of actions from devaluation of persons,
   * reducing public shaming and increasing reversibility.

---

#### 7. Short formula for this lens

> **Praxeological anthropology allows political conflict communication to be read as dignity practice.**  
> It shows how relational and public dignity are elevated or injured in enactment,  
> how inadult asymmetries emerge,  
> and where more responsible, reversible uses of power and boundary-setting are possible —  
> without evaluating ideological content itself.

---

### D.2 Example B — Psychology, coaching & supervision

#### Mode: performative pattern clarification → reflective intervention support

> **Boundary:**  
> This lens is **performative**, not clinical.  
> It does not replace diagnosis, psychotherapy, trauma therapy, treatment planning or clinical responsibility.

---

#### 1. Context and problem statement

Clients or participants in coaching, supervision or self-reflective settings frequently experience phenomena such as:

* **self-devaluation**,
* shame,
* inner harshness,
* overwhelm,
* decision paralysis,
* excessive compliance,
* conflict avoidance,
* self-optimisation pressure,
* exhaustion,
* role conflicts, such as leader vs. private self.

Clinical or psychological frameworks may have their own valid uses for such phenomena.  
Praxeological anthropology does **not** replace them.

Its question is narrower:

> **What is the pattern of enactment — under which roles, conditions and modulators?**

The basic boundary remains:

> The person is not reduced to the pattern.  
> `D₀` always remains intact.

---

#### 2. Activated modules

**Primary:**

* `D-I` — inner dignity / inner self-relationship,
* `D-B` — bodily/material self-care,
* `A–C–R–P`,
* trajectories.

**Secondary:**

* role mechanics,
* modulators,
* publicness where relevant,
* reversible steps,
* optional D-profile under guardrails.

---

#### 3. Analysis of the action situation

##### 3.1 Observable phenomena

Example starting point:

> A client reports “being constantly too harsh with myself,” avoiding decisions,  
> and “making myself small” in professional settings despite being objectively competent.

---

##### 3.2 Praxeological reconstruction

Praxeological anthropology does not analyse character traits or diagnose inner disorders.  
It describes **enactments**:

* **`D-I` low:** inner self-devaluation, harsh inner dialogue, lack of self-kindness.
* **`A` low or narrow:** low awareness of triggers and patterns.
* **`C` fragile:** self-image and behaviour do not align; decisions feel unstable.
* **`R` distorted:** over-assuming responsibility for others’ moods while relinquishing one’s own responsibility.
* **`P` low:** subjectively reduced options for action despite objective possibilities.
* **`D-B` low:** neglect of sleep, nutrition, bodily boundaries.

The key insight is not:

> “The person is deficient.”

but:

> **The enactment is narrowed by modulators, roles and structural conditions.**

Thus the problem becomes:

> How are awareness, coherence, responsibility and power narrowed —  
> and how does this affect dignity in practice?

---

#### 4. Modulators: why enactment becomes distorted

Praxeological anthropology shows that inadult patterns are often intensified by **modulators**:

* time pressure,
* emotional load,
* unclear expectations,
* power asymmetries,
* information gaps,
* dependency,
* publicness,
* biographical triggers — without pathologisation.

These modulators affect `A–C–R–P` directly.

Example:

> Time pressure → `A` ↓ → `C` ↓ → `R` distortion → `P` narrowing → `D-I/D-B` strain.

This is not a claim about the person’s essence.  
It is a description of a feedback loop under conditions.

---

#### 5. Reflective intervention support: maturity loop & reversible steps

Coaching or supervision in this lens is not about correcting “faults”.  
It is about making enactments more accountable, coherent and dignity-preserving.

##### 5.1 Maturity loop (`A → C → R → P → D`)

Possible reflective sequence:

1. **Increase awareness (`A`)**

   * identify triggers,
   * clarify roles,
   * mark: “This is a state, not an essence.”

2. **Stabilise coherence (`C`)**

   * align self-image and behaviour,
   * recognise contradictory narratives,
   * restore inner consistency.

3. **Unpack responsibility (`R`)**

   * What is actually mine?
   * What is delegated, assumed, projected?
   * Where is responsibility overreach or abdication?

4. **Expand power to act (`P`)**

   * identify small reversible steps,
   * surface real options,
   * avoid overwhelm.

5. **Renew dignity in practice (`D₁/D₂`)**

   * cultivate inner self-respect (`D-I`),
   * reconnect with bodily/material boundaries (`D-B`),
   * act more clearly in relation to others (`D-R`),
   * protect public dignity where relevant (`D-P`).

---

##### 5.2 Why reversible steps?

The model avoids radical overreach because it can:

* destabilise dignity enactments,
* increase `P` without sufficient `A`,
* provoke inadult counterreactions,
* exceed the person’s real alternatives.

Instead:

> **Change as little as possible, as much as necessary.**

Reversibility protects `D-I/D-B` and creates safety.

---

#### 6. Micro–macro linkage in coaching / supervision

The model shows:

* the micro-level — inner dialogue,
* affects the meso-level — role enactment,
* and is shaped by the macro-level — professional dynamics, organisational expectations, cultural scripts.

Example:

> A person with low `D-I` behaves defensively in meetings.  
> Others take over power.  
> This reinforces the person’s sense of inadequacy.  
> `D-I` declines further.

The cycle is not treated as a fixed psychological defect.  
It is read as a socially reinforced enactment pattern.

---

#### 7. Result: what the model reveals

In coaching, supervision or self-reflective contexts, praxeological anthropology shows:

1. Self-devaluation can be read as an **enactment state**, not as a person label.

2. Maturity is not fixed internally; it is situationally reconstructible.

3. `A–C–R–P` provides clear reflection points.

4. `D-I` and `D-B` offer careful indicators of self-treatment — not a dignity score.

5. Reversibility protects dignity and supports sustainable change.

6. The model links inner self-treatment, behaviour and social roles without psychologising the person.

7. The person remains fully dignified (`D₀`) at every moment — independent of patterns or errors.

---

#### 8. Short formula for this lens

> **Praxeological anthropology understands psychological and coaching-relevant difficulties as enactment patterns under conditions, not stable personal deficits.**  
> It provides structured reflection points (`D-I`, `D-B`, `A–C–R–P`)  
> and supports dignity-preserving, reversible steps —  
> without diagnosing, pathologising or devaluing the person.

---

### D.3 Conclusion

Appendix D shows how the model can be adapted across disciplines and fields without changing its core.

The adaptation rule is simple:

* same `A–C–R–P–D`,
* same dignity boundary,
* same guardrails,
* different field lens,
* different activated hotspots,
* different depth.

The model remains **domain-sensitive**, not **domain-authoritative**.

It may help disciplines ask sharper questions about roles, power, responsibility, publicness and dignity in practice.  
It does not replace their methods, responsibilities or judgement.

Thus discipline adaptation remains praxeological:

> **Use the model to structure reflection —  
> not to overrule the field.**
