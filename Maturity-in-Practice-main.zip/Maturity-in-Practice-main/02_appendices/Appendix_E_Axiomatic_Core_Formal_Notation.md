---
document_id: MIP-APPENDIX-E
title: "Axiomatic Core and Formal Notation"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical appendix extraction"
target_file: "02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md"
status: "split-full-version"
version: "v1"
appendix_id: "E"
appendix_role: "canonical axiomatic and formal notation appendix"
source_appendix: "Appendix E"
source_appendix_title: "Axiomatic core & formal notation"
core_references: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: ["Appendix A", "Appendix B", "Appendix C", "Appendix D"]
claim_mode: "axiomatic, formalising, notation-oriented, praxeological, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity formalised with D₀ as inviolable axiom; D₁/D₂ as dignity in practice; D-profile qualitative; not person score"
mip_status: "canonical appendix block; direct extraction; notation and boundary alignment; no new model logic"
split_rule: "include from Appendix E heading through end of source document"
---

# Maturity in practice — A praxeological anthropology: Appendix E — Axiomatic Core and Formal Notation

## Appendix E — Axiomatic core & formal notation

---

### E.1 Purpose and scope

This appendix summarises the **axiomatic core** of praxeological anthropology  
and provides a simple **formal notation** for practical use.

It answers three questions:

* On which **fundamental assumptions** does the model rest?
* For which **types of enactments** does it claim validity?
* How can an **action enactment** be formally represented  
  without disrupting the readability of the main text?

---

#### Scope

The model is designed as a **language of action** for:

* human social practice,
* in roles and contexts,
* under conditions of **power**, **responsibility**, **risk**, asymmetry and potential dignity damage.

It does **not** claim to cover every conceivable form of behaviour  
or every possible intelligent system.

Where the model is applied to non-human or technical systems,  
for example in AI governance or technology ethics, the scope is restricted:

* `IA`, transparency, responsibility and power asymmetry may be analysed,
* but **ontological dignity (`D₀`) applies to human persons**,
* and `D₁/D₂` are not used to assign dignity status to non-human systems.

Thus, technical or organisational applications remain **asymmetry audits**,  
not claims about machine personhood or machine dignity.

---

#### Formal-use boundary

> **Formal notation is a documentation aid.**  
> It does not replace context, guardrails, judgement or qualitative interpretation.

The notation is deliberately minimal.  
It helps make assumptions visible; it does not turn the model into a calculus.

---

### E.2 Axiomatic core

These axioms are not covert morality but **structural assumptions**  
about how we describe and evaluate enactments.

They operate implicitly throughout the main text;  
here they are made explicit.

---

#### Axiom 1 — `D₀` is inalienable

Every human person possesses **ontological dignity (`D₀`)**, which is:

* incomparable,
* immeasurable,
* non-increasable,
* non-losable,
* non-rankable.

> No matter how poor an enactment profile may be,  
> no inference may ever be drawn about someone’s ontological dignity.

`D₀` is not a parameter to be assessed.  
It is the boundary condition under which the model operates.

---

#### Axiom 2 — Strict separation of person and enactment

The model never evaluates **the person as such**, only:

* actions,
* role enactments,
* constellations,
* communicative practices,
* structural practices,
* dignity enactments in concrete settings.

> **“To act without dignity” ≠ “to be without dignity.”**

This distinction is not optional.  
It is constitutive for the entire model.

Permitted:

> “In this role / context / time window, this enactment shows …”

Not permitted:

> “This person is …”

---

#### Axiom 3 — Five parameters of maturity in practice: `A–C–R–P–D`

Every relevant enactment in a social context can be described along five axes:

* **`A` — awareness**  
  perception, knowledge, role awareness, publicness awareness, bias awareness.

* **`C` — coherence**  
  relation between claim, narrative, decision and deed across time and context.

* **`R` — responsibility**  
  assumption, refusal, redistribution or shifting of burdens and consequences.

* **`P` — power / power to act**  
  real room for action, levers, agency, dependency, overpower or helplessness.

* **`D` — dignity in practice**  
  qualitative enactment of dignity in self-treatment, relations and publicness.

`A–C–R–P` form the standard structural analysis core.  
`D` is the protected dignity-in-practice layer.

`D` may be activated only when the guardrails are fulfilled.

---

#### Axiom 4 — `D₁/D₂` are dignity in practice, not dignity itself

The model distinguishes:

* **`D₀` — ontological dignity**  
  inviolable personhood; never assessed.

* **`D₁` — self-dignity in practice**  
  how someone treats themselves in practice.

* **`D₂` — relational dignity in practice**  
  how someone treats others, the public, roles and the social world in practice.

Operational D-submodules:

* **`D-I`** — inner dignity / inner self-relationship,
* **`D-B`** — bodily/material self-care,
* **`D-R`** — relational dignity,
* **`D-P`** — public dignity in practice.

For `D₁/D₂`:

* readings are qualitative,
* situated,
* context-bound,
* role-bound,
* time-windowed,
* revisable.

There is no dignity score.

---

#### Axiom 5 — Role, context and publicness are indispensable

No maturity, `IA` or `D` finding exists without context.

Every analysis must clarify at least:

* the **object of observation**,
* the **role** of the object of observation,
* the **observer position**,
* the **context**,
* the **publicity level**,
* relevant dependencies and power asymmetries.

> The same observable act can have entirely different meaning  
> depending on role, context and publicness.

Mandatory pre-check:

> role + context + publicness before `A–C–R–P–D`.

---

#### Axiom 6 — Asymmetry is normal; `IA` requires failed justification

Asymmetries of power, knowledge, resources, status and responsibility  
are normal in human systems.

They become praxeologically problematic when they violate the **IA-box**:

* **`T` — transparent**
* **`J` — justified**
* **`TB` — time-bound**
* **`R` — reversible**

Systematic violation of `T`, `J`, `TB` or `R` constitutes  
**inadult asymmetry (`IA`)**.

> Asymmetry is not the problem.  
> Unbounded, unjustified or irreversible asymmetry is.

---

#### Axiom 7 — Maturity is an enactment state, not a person type

“Maturity” is observed **in enactment**, not as personality essence.

People can show different maturity levels:

* in different roles,
* under different modulators,
* at different times,
* in different publicness conditions.

There are no “immature persons” as types within the model.

There are:

* mature enactments,
* mixed enactments,
* inadult enactments,
* functional or inadult structures.

Development and change therefore remain open.

---

#### Axiom 8 — Scores are structured estimations, not exact measurements

The model uses score language only as structured estimation.

* **A-score** = maturity in practice of an enactment / case / situation.
* **M-score** = shared structural responsibility of a role / position / actor in a trajectory.

Both are **bands**, not exact digital values.

They are:

* auxiliary,
* revisable,
* context-bound,
* justified by observations,
* never person scores.

`D₀` is never measured.  
`D₁/D₂` are not scored.

---

#### Axiom 9 — Shared responsibility is not guilt

`M` describes **shared structural responsibility**, not guilt, fault, blame or moral worth.

The M-score is tied to:

1. knowledge,
2. power / control,
3. predictability,
4. access to alternatives,
5. serious integration attempt.

The **ceiling rule** applies:

> `predictability ≈ 0` or `access to alternatives ≈ 0` → `M ≤ 4`

No high shared responsibility without predictability and real options.

Self-devaluation does not raise `M`.

---

#### Axiom 10 — System axiom: no enactment is isolated

Every enactment is part of a network of:

* roles,
* rules,
* resources,
* dependencies,
* publicness,
* organisations,
* narratives,
* modulators.

A- and M-findings must never be treated as pure individual attributions.

If the systemic layer is omitted,  
the finding is **IA-shortened** by the model’s own standards.

---

#### Axiom 11 — Intersubjective documentation is mandatory for serious use

Any serious application requires minimal documentation of the evaluator’s standpoint:

* Which role does the evaluator occupy?
* Which norms or criteria are applied?
* Which context assumptions are made?
* What information is available?
* Which bias risks are evident?
* Which dignity readings are being made, and from which normative position?

> The analyst is always part of the picture.

The model becomes critique-ready only when the standpoint of analysis is visible.

---

#### Axiom 12 — Bias, intuition and norm change are method components

Bias, intuition and norm change are not appendix material or soft reflection.

They are analysis constraints:

* **Bias** is baseline noise.
* **Bias-awareness** is part of `A`.
* **Intuition** is a sensor and trigger, not a judge.
* **Intuition** is hypothesis, not proof.
* **Norm change** is not an obstacle, but subject matter.
* **Dignity readings** must name their normative position.

Without this meta-layer, dignity language easily falls back into moral labelling.

---

#### Axiom 13 — Tragic residual conflicts

Certain enactments involve irreducible clashes of central goods,  
even under high maturity.

Actions shaped by such tragic conflicts are **not automatically `IA`**.  
They may be expressions of structural tragedy.

`IA` analysis must therefore separate two questions:

* What was **unnecessarily degrading or asymmetrical**?
* What remains **painful despite maturity**?

---

#### Axiom 14 — Guardrails are constitutive

Guardrails are not external ethics added after the model.

They are part of the model’s validity.

Without guardrails:

> any `IA` / `D` analysis is invalid.

Guardrails include:

* structure before person,
* no person ranking,
* no dignity score,
* duty of context,
* reciprocity and self-application,
* improvement orientation,
* versioning and reversibility,
* red-zone exclusion.

---

### E.3 Formal minimal notation

For readers who prefer to “see” a structured representation,  
this section gives a simple notation.

It is not required to use the model.  
It may help in research, documentation or audit contexts.

---

#### E.3.1 Notational hygiene

Because `A` already denotes **awareness** and **A-score**,  
formal notation should avoid using `A` as the actor placeholder.

Preferred actor placeholders:

* `X` — actor / role-holder / object of observation,
* `Y` — second actor / counterpart,
* `H` — enactment, case or situation,
* `K` — context,
* `ρ` — role.

Thus:

* `A` = awareness or maturity notation,
* `X` = actor placeholder.

This avoids the ambiguity of `M(A)` in informal notation.

Where older notation writes:

> `M(A)`

read:

> `M(X)` = shared responsibility of actor / role-holder `X`.

---

#### E.3.2 Action tuple

An **action enactment** `H` can, in simplified form, be written as:

\[
H = (X, \rho, K, A_w, C_o, R_s, P_a, D_p, IA)
\]

where:

* `X` — actor / role-holder / object of observation,
* `ρ` — role in this context,
* `K` — context / setting / publicness frame,
* `A_w` — awareness profile,
* `C_o` — coherence profile,
* `R_s` — responsibility profile,
* `P_a` — power-to-act profile,
* `D_p` — D-profile (`D₁/D₂`; optional),
* `IA` — IA-box evaluation (`T–J–TB–R`).

In practice, a partial notation is often sufficient:

\[
H = (X, \rho, K, A_w, C_o, R_s, P_a)
\]

with `D_p` omitted when the D-module is not activated.

---

#### E.3.3 D-profile notation

If `D` is activated under guardrails, the D-profile may be notated:

\[
D_p(H) = (D_1, D_2)
\]

with:

\[
D_1 = (D_I, D_B)
\]

\[
D_2 = (D_R, D_P)
\]

where:

* `D_I` — inner dignity / inner self-relationship,
* `D_B` — bodily/material self-care,
* `D_R` — relational dignity,
* `D_P` — public dignity in practice.

Boundary:

> `D_p(H)` describes D-enactments in `H`.  
> It does not describe the value of `X`.

`D₀` is not included in `D_p(H)` because `D₀` is not a profile variable.

---

#### E.3.4 IA-box notation

An asymmetry `S` can be represented as:

\[
IA(S) = (T, J, TB, R)
\]

where:

* `T` — transparency,
* `J` — justification,
* `TB` — time-boundedness,
* `R` — reversibility.

Interpretive result:

\[
IA(S) \in \{functional,\ IA\ risk,\ inadult\ asymmetry\}
\]

Boundary:

> `IA(S)` evaluates the quality of an asymmetry,  
> not the worth of any person involved.

---

#### E.3.5 A-score notation

The A-score describes maturity in practice of an enactment, case or situation:

\[
A(H) \in [0,10]
\]

In practice:

\[
A(H) \approx x-y
\]

where `x–y` is a **band**, for example:

* `3–4`,
* `5–6`,
* `6–7`.

Subscore notation:

\[
A(H) = f(A(A), A(C), A(R), A(P))
\]

where:

* `A(A)` — maturity of awareness,
* `A(C)` — maturity of coherence,
* `A(R)` — maturity of responsibility,
* `A(P)` — maturity of action / power.

Boundary:

> `A(H)` is not a person score.  
> It describes how maturely `H` was enacted.

`D₁/D₂` do not flow into the A-score.  
They are recorded separately in the D-profile if activated.

---

#### E.3.6 M-score notation

The M-score describes shared structural responsibility of actor / role-holder `X`:

\[
M(X) \in [0,10]
\]

In practice:

\[
M(X) \approx x-y
\]

where `x–y` is a **band**.

Five-factor structure:

\[
M(X) = f(Kn, Pw, Pr, Alt, Int)
\]

where:

* `Kn` — knowledge,
* `Pw` — power / control,
* `Pr` — predictability,
* `Alt` — access to alternatives,
* `Int` — serious integration attempt.

Ceiling rule:

\[
Pr \approx 0 \lor Alt \approx 0 \Rightarrow M(X) \leq 4
\]

Boundary:

> `M(X)` is not guilt.  
> It describes shared structural responsibility under role, context and time.

---

#### E.3.7 Combined case notation

A case can be minimally notated as:

\[
H \Rightarrow (A(H), M(X), IA(S))
\]

If `D` is activated:

\[
H \Rightarrow (A(H), M(X), IA(S), D_p(H))
\]

Boundary:

* `A(H)` — maturity in practice,
* `M(X)` — shared structural responsibility,
* `IA(S)` — asymmetry quality,
* `D_p(H)` — dignity-in-practice profile,
* `D₀` — outside all measurement and profiling.

---

#### E.3.8 Trajectory notation

Maturity, responsibility and dignity in practice are trajectories, not labels.

A trajectory can be represented as:

\[
H_t = \{H_{t0}, H_{t1}, H_{t2}, ...\}
\]

with:

\[
A(t) = A(H_t)
\]

\[
M(t) = M(X_t)
\]

\[
D(t) = D_p(H_t)
\]

where `D(t)` is optional and qualitative.

Guiding formula:

> We write trajectories, not labels.

---

#### E.3.9 `RVR(t)` notation

Responsibility–viability–range over time can be represented as:

\[
RVR(t) = f(knowing_t, able_t, permitted_t, acting_t)
\]

under:

* the **ceiling rule**,
* role and context constraints,
* publicness conditions,
* `D₀` as inviolable boundary.

`RVR(t)` describes how responsibility viability changes over time.

It is a responsibility curve, not a point verdict.

---

#### E.3.10 Meta Notes notation

A documented analysis may include:

\[
Meta(H) = (B, N, I, L, Alt)
\]

where:

* `B` — bias risks,
* `N` — norm assumptions,
* `I` — intuition input and whether it was checked,
* `L` — lens / normative position of D-reading,
* `Alt` — possible alternative interpretations.

This formalises the requirement that analysis is situated and critique-ready.

---

### E.4 Formal red-zone boundary

The formal notation must not be used in contexts where the model itself is excluded.

Forbidden uses include:

* clinical diagnostics,
* therapy planning,
* forensic assessment,
* HR decisions about individuals,
* child/youth diagnostics,
* public pillorying,
* ranking formats,
* humiliation diagnostics,
* online shaming,
* person-level dignity labelling.

Formal notation does not soften these prohibitions.

> A formally neat misuse remains misuse.

If a guardrail fails, the formal result is:

\[
status(H) = working\ note
\]

not:

\[
status(H) = decision\ basis
\]

---

### E.5 Note on extensibility

This notation is deliberately minimal.

It can be extended to include, for example:

* multi-role contexts,
* multi-actor scenarios,
* institutional levels,
* media-amplification factors,
* domain-specific lenses,
* longitudinal trajectories,
* documented counter-perspectives.

But the purpose of Appendix E is not to transform the model into a full calculus.

Its purpose is to show:

> **Praxeological anthropology can, if needed, be translated into a formal language of enactment —  
> while remaining bounded by dignity, context, guardrails and revision.**

---

### E.6 Conclusion

Appendix E formalises the model without changing its nature.

The axiomatic core remains:

* `D₀` is inviolable.
* Persons and enactments are strictly separated.
* `A–C–R–P–D` are reading axes, not person labels.
* `A-score` and `M-score` are structured bands, not exact measurements.
* `D₁/D₂` are qualitative dignity-in-practice descriptions, not dignity scores.
* `IA-box` checks asymmetry, not person worth.
* Role, context and publicness are mandatory.
* Guardrails are constitutive.
* Revision remains required.

The formal notation may help document cases more precisely.  
It may not be used to bypass judgement, context, domain responsibility or dignity protection.

Thus the formal layer remains praxeological:

> **It makes action more readable —  
> without turning persons into formulas.**
