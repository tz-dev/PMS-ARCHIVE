---
document_id: MIP-FULL-SOURCE
title: "Maturity in Practice — A Praxeological Anthropology"
source_role: "canonical full source document"
target_file: "00_source/Maturity in practice - A praxeological anthropology.md"
status: "canonical-full-source"
version: "v1"
source_id: "mip-full-source"
source_layer: "00_source"
source_scope: "complete pre-split full manuscript including canonical core chapters and appendices"
claim_mode: "praxeological, structural, guardrail-bound, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-profile qualitative; no dignity score"
mip_status: "canonical full source; basis for split blocks, appendices and derived reference layers"
split_relation:
  split_spec: "00_source/MIP_SPLIT_SPEC_01_blocks.md"
  block_target_layer: "01_blocks/"
  appendix_target_layer: "02_appendices/"
  split_rule: "canonical core chapters 1–12 are split mechanically into 01_blocks; appendices belong to 02_appendices"
canonicality: "canonical source text; derived layers must not override it"
---

# Maturity in Practice — A Praxeological Anthropology

1. What this is about (position and claim)
   - 1.1 Five levels on which the model reads
   - 1.2 Model = toolbox, not worldview
   - 1.3 Maturity ≠ purity – the role of necessary inadulthood
   - 1.4 Tragic conflicts – when maturity cannot resolve everything

2. Short definition & base model A–C–R–P–D
   - 2.1 Five core parameters in brief
   - 2.2 Dynamics of A–C–R–P–D (feedback loop & states)
   - 2.3 Modulators – amplifiers & dampers
     - 2.3.1 Structural modulators
     - 2.3.2 Dynamic / psychosocial modulators
     - 2.3.3 Short rule for practice
   - 2.4 Parameter matrix & submodules (A–C–R–P–D)
   - 2.5 Publicity & position of the object of observation
   - 2.6 Ontological vs. praxeological dignity
     - 2.6.1 Ontological dignity – non-negotiable, not measurable
     - 2.6.2 Praxeological dignity (D) – dignity in practice
     - 2.6.3 Relational dignity (D₂) – dignity in relation to the world
     - 2.6.4 Boundary: “acting without dignity” vs. “being without dignity”
   - 2.7 D module – overview
     - 2.7.1 Guiding formula & basic stance
     - 2.7.2 What the D module observes – and what it does not
     - 2.7.3 Safeguard clause
     - 2.7.4 Scale logic: banal → extreme (always reversible)
     - 2.7.5 Limits of D₁/D₂ in trauma & neurodiversity
   - 2.8 Language hygiene: risk, harm, potential, danger
     - 2.8.1 Risk, danger, harm, potential
     - 2.8.2 Language hygiene in the D context
     - 2.8.3 General language hygiene in the paper

3. Framework of use & guardrails (mandatory module)
   - 3.1 Structures, not persons – zones
     - 3.1.1 Profile ≠ person
     - 3.1.2 System axiom: no enactment is purely individual
   - 3.2 Entry condition: minimal adulthood
   - 3.3 Procedural guardrails (modules 1–6)
   - 3.4 Self-implication: whoever analyses, shows themselves
   - 3.5 Dignity protection guardrail (ontological vs. praxeological)
     - 3.5.1 Principle: the human being remains dignified
     - 3.5.2 D assessments only in practice, never in the value of the person
     - 3.5.3 Misuse as its own IA and D finding
   - 3.6 D as an optional module
     - 3.6.1 Default setting: D off
     - 3.6.2 When D may be activated
     - 3.6.3 Red zones for D
     - 3.6.4 Documentation duty: marking the use of D
   - 3.7 Publicity & communication of D findings
     - 3.7.1 Differentiating communication spaces
     - 3.7.2 Forms of D communication
     - 3.7.3 Language rules for D findings
     - 3.7.4 D findings under power asymmetries

4. Functional vs. inadult – the four-criteria box
   - 4.1 Four-criteria box for asymmetries (T–J–TB–R)
   - 4.2 Role and context logic
     - 4.2.1 Clarifying the role of the object of observation
     - 4.2.2 Clarifying the role of observers
     - 4.2.3 Role awareness (A-R) as the start button
   - 4.3 Role confusion & phantom intention
   - 4.4 Semantic drift & D asymmetries: same action, different meaning
     - 4.4.1 Semantic drift (basic mechanics)
     - 4.4.2 D and asymmetries: self-degradation vs. societal degradation
     - 4.4.3 Structural IA through faulty dignity-interpretation
   - 4.5 Practical micro-tool: the role check

5. Measuring maturity in practice – without moral rhetoric
   - 5.1 A-score (0–10) – dimensions & micro-indicators
     - 5.1.1 What the A-score measures – and what it does not
     - 5.1.2 Dimensions of the A-score
     - 5.1.3 Calibration band 0–10
     - 5.1.4 Procedure: from profile to score
   - 5.2 Trajectories instead of labels
     - 5.2.1 A-score as snapshot
     - 5.2.2 Development lines (trajectories)
     - 5.2.3 Why trajectories are more mature than labels
     - 5.2.4 Practical use

6. M-score – ceiling rule & fairness
   - 6.1 M-score (shared responsibility, not fault or guilt)
     - 6.1.1 Five factors of shared responsibility
     - 6.1.2 High vs. low M-scores
     - 6.1.3 M-score as structural distribution, not character judgment
   - 6.2 The ceiling rule (protection against victim blaming)
     - 6.2.1 Predictability ≈ 0
     - 6.2.2 Access to alternatives ≈ 0
     - 6.2.3 Function of the ceiling rule
   - 6.3 Interaction of A-score & M-score
     - 6.3.1 A high – M high
     - 6.3.2 A high – M low
     - 6.3.3 A low – M high
     - 6.3.4 A low – M low
     - 6.3.5 Practical use of A & M (with D-profile)
   - 6.4 D and shared responsibility
     - 6.4.1 Self-devaluation in the D-framework
     - 6.4.2 Why self-degradation does not produce a high M-score
     - 6.4.3 D, M and protection – practical implications

7. Guiding formulas & tools
   - 7.1 Case Lens (v1.0) – decision protocol
   - 7.2 Score sheets (A, M, IA-box, D)
     - 7.2.1 A-score sheet
     - 7.2.2 M-score sheet
     - 7.2.3 IA-box sheet (Four-criteria box)
     - 7.2.4 D-profile sheet (D₁/D₂ – dignity in practice)
   - 7.3 Trajectories instead of points
     - 7.3.1 Why trajectories?
     - 7.3.2 Minimal documentation
     - 7.3.3 Linking Case Lens ↔ Score sheets
   - 7.4 System-1 / System-2 micro-tool (acute situations)
   - 7.5 Mini-toolkit: score sheet & context tools (optional)
     - 7.5.1 Three usage modes
     - 7.5.2 Typical application fields
   - 7.6 Praxeological final checklist
     - 7.6.1 Satisfaction as warning signal
     - 7.6.2 Parameter check: A–C–R–P–D
     - 7.6.3 Role confusion – red alert
     - 7.6.4 Detecting projection
     - 7.6.5 Publicity factor (A-P, P-PU, D-P)
     - 7.6.6 Multi-context situations
     - 7.6.7 Coherence test via the other’s reaction
     - 7.6.8 The “Grail sentence”

8. Domain Modules – Grids for Levels & Fields
   - 8.1 Psychology (performative)
   - 8.2 Philosophy & Religion
   - 8.3 Sociology & Politics
   - 8.4 Culture / Media
   - 8.5 Practice Ethics (Law / Organization / Education)

9. Bias, Intuition & Norm Change
   - 9.1 Bias: unavoidable distortions
   - 9.2 Intuition: enemy or sensor?
   - 9.3 Norm change: a moving target
   - 9.4 Working with the model: protocol & meta-attitude

10. Countercritique & Response
    - 10.1 “Isn’t this just a new morality machine?”
    - 10.2 “Can maturity even be measured?”
    - 10.3 “Danger of misuse”
    - 10.4 “Too subjective / too complex / too time-consuming”
    - 10.5 “What the model does not promise”
    - 10.6 Specific criticism of the D module (anticipation & response)
      - 10.6.1 “You are becoming the dignity police.”
      - 10.6.2 “You claim to know what is ‘dignified’.”
      - 10.6.3 “You make those affected co-responsible for their own degradation.”
      - 10.6.4 “You violate the idea of inalienable human dignity.”
      - 10.6.5 “D reinforces shame and stigmatisation.”
      - 10.6.6 “You are turning dignity into a new technology of discipline.”

11. Visual quick access (1-pager, PDF-ready)
    - 11.1 Audit checklist (5 points, meta level)
    - 11.2 Conflict loop (4 steps)
    - 11.3 D quick grid (banal → extreme, always reversible)

12. Concluding word – maturity in practice remains work

- Appendix A - Glossary of key terms

- Appendix B – Checklists & practice templates
  - B.1 Quick check: 60-second self-test before each application
  - B.2 Case start template: 1-minute snapshot
  - B.3 A-C-R-P-D analysis template (basic framework)
  - B.4 IA box (T–J–TB–R) – template
  - B.5 A score & M score – template
  - B.6 Trajectory template
  - B.7 Role/publicness mapping
  - B.8 Guardrail checklist (practice form)
  - B.9 Mini toolkit for ad-hoc situations
  - B.10 Documentation template (for cases, workshops, audits)
  - B.11 D module – short grid for praxeological dignity (optional)
    - B.11.1 D quick grid (0–3)
    - B.11.2 Template: short D profile notes

- Appendix C – Case examples
  - C.1 Case example 1: “Why is Prince Adam not allowed to tell his friends that he is He-Man?”
  - C.2 Case example 2: “Scoring” algorithms in welfare and criminal justice
  - C.3 Case example 3: The model in the mirror (self-application)
  - C.4 Case example 4: ChatGPT & AI as an asymmetrical actor
  - C.5 Case example 5: (Praxeological) Reality

- Appendix D – Modular adaptation to disciplines/fields
  - D.1 – Example A: Political science & public communication
  - D.2 – Example B: Psychology & Coaching

- Appendix E – Axiomatic core & formal notation
  - E.1 Purpose and scope
  - E.2 Axiomatic core
  - E.3 Formal minimal notation
    - E.3.1 Action tuple
    - E.3.2 A- and M-scores
    - E.3.3 Note on extensibility

## 1) What this is about (position and claim)

In public discourse, words like “mature”, “immature”, “toxic”, “irresponsible” are thrown around a lot – mostly without clarifying **what** they are meant to describe. Sometimes “mature” refers to a calm tone of voice, sometimes to the ability to tolerate conflict, sometimes merely to agreement with one’s own moral stance. At the same time, real people and situations are negotiated under increasingly complex conditions: social media, organisational logics, law, economics, psychological burdens.

We do not have direct access to inner life, motives, or “true character”. What can be observed are **enactments**: decisions, communication, dealings with power, reactions under pressure. Yet evaluations are often conducted as if one could infer the “worth” of a person directly from a few impressions.

Let us imagine two scenes: In a team meeting, a leader calls for “radical openness”, but critical contributions have tangible negative consequences for employees. Elsewhere, a person is considered “difficult” because they repeatedly point to a blind spot in a procedure. In both cases, everyday diagnoses would quickly land on persons (“too sensitive”, “too authoritarian”) – the "IA model" (inadult asymmetry) instead tries to read the **structures and enactments** that sustain these situations.

This paper therefore does not treat maturity as a character trait, but as a **praxeological phenomenon**: it is interested in what people **actually do under real conditions** – with their awareness, with their coherence between word and deed, with how they carry or shift responsibility, with their use of power, and with their handling of dignity in everyday life.

Chapter 1 sets the frame for this: what kind of “maturity” is meant here, what role dignity plays, on which levels the model reads, and why it explicitly offers **no** closed worldview but rather a toolbox for concrete situations.

---

**Maturity in practice** means:
not what someone **claims** to be –
but what someone **actually does under conditions**.

The model describes maturity as something that shows itself:

* **in action** (not in self-images),
* **under constraint** (pressure, costs, side effects),
* **in dealing with asymmetries** (power, knowledge, dependency),
* **in word–deed coherence** (keyword: “walk” instead of “talk”),
* **in how one deals with oneself** – that is, how people enact their own dignity in everyday life.

The central object of investigation is **inadult asymmetry (IA)**, i.e.
unequal, immature or unaccounted-for distributions of:

* **awareness** (“A” – who sees what?),
* **coherence** (“C” – what is claimed, what is done – does it fit together?),
* **responsibility** (“R” – who carries which burden?),
* **power** (“P” – who decides, who can stop, who can leave?), and
* **dignity in practice** (“D” – how do people treat themselves – and what does that mirror about their relation to the world?).

A hard starting assumption applies here:

> **People sometimes act in undignified ways – and yet remain dignified.**  
> The model evaluates **enactments**, not the value of persons.

We therefore distinguish three levels of dignity:

* **D₀ – ontological dignity**  
  the inalienable, equal dignity of all persons; not measurable, not “earned”;
* **D₁ – dignity in practice (self-dignity)**  
  how someone treats themselves, especially when action has costs  
  (operationally: **D-I** – inner dimension of self-treatment; **D-B** – bodily/material dimension of self-treatment);
* **D₂ – relational dignity**  
  how someone deals with others and the public  
  (operationally: **D-R** – relational dimension; **D-P** – public/symbolic dimension).

When, in what follows, we speak of **“dignity in practice (D)”**, we mean the **praxeological enactment of D₁ and D₂**. D₀ remains unaffected by this.

The paper attempts to grasp this dynamic **praxeologically**:

> not: “What kind of person is this?”  
> but: “How is action taken here – with what awareness, with what coherence of word and deed, with what responsibility, with what power, with what self-treatment?”

Guiding formula:

> **“Recognise the action – not the person.”**

The claim is threefold:

1. **Structural readability**  
   A–C–R–P–D as a grid to see situations, systems and interactions **more clearly**:  
   Who knows what, who claims what, who carries what, who can do what – and how do those involved treat themselves?

2. **Operational reviewability**  
   Scores, parameters and checklists that help make judgements **traceable instead of merely asserted** – including a **D-profile** that describes dignity in practice along  
   **D-I** (inner self-treatment),  
   **D-B** (bodily/material self-treatment),  
   **D-R** (treatment of others), and  
   **D-P** (public staging)  
   without assigning “dignity scores” to persons.

3. **Ethics of use**  
   Guardrails intended to prevent the model itself from becoming an **inadult weapon**
   (e.g. for retroactively devaluing persons or groups) – in particular through the strict separation of

   * **ontological dignity (D₀)** – non-negotiable value of persons, and
   * **dignity in practice (D₁/D₂)** as observable self- and world-treatment.

So the point is not to establish a new worldview, but to provide a **toolbox**:

* that makes differences between **functional asymmetries** and **inadult asymmetries (IA)** more visible,
* that makes maturity and dignity in practice distinguishable yet readable together,
* without getting lost in psychological speculation,
* and without pre-writing moral positions.

To make this toolbox usable, a clear reading logic is needed: on which levels do we observe what is happening – and where is intervention even appropriate?

---

### Note on the “CRAP” acronym

**Yes** – we noticed that in the English translation the five basic parameters could be rearranged
to form the acronym **“CRAP”**.  
**Yes** – we noticed that.  
**Yes** – we even **tried it**.

And then we dropped it, because the reordering required for it would itself have made the test **inadult**. If it had actually improved the model, that would have been the first test of the readers’ maturity. *Unfortunately*, it did not. At the same time, we are fully aware that the model will **informally** circulate under exactly this name – and we take that with humour.

So the rule is: **no CRAP ordering**.  
The parameters remain in their functional original order,
and the meme stays where it belongs – **outside** the analytical tool.

---

### 1.1 Five levels on which the model reads

The model reads phenomena simultaneously on **five levels** – but evaluates **primarily the structure**.  
The fifth level (**dignity**) is an **optional additional layer**, which is activated only when the guardrails are met (3.5–3.7).

---

#### 1. Structural level (core level)

Here lie the basic parameters: **A–C–R–P–D**, inadult asymmetry (IA), scores, modulators.

Guiding questions:

* Who knew what – and when? (**A – awareness**)
* What was claimed, what was done – does it fit together? (**C – coherence**)
* Who carries which burden, for what? (**R – responsibility**)
* Who had which real options? Who could stop, leave, decide? (**P – power**)
* What form does **the enactment of dignity** show in behaviour (D-I/D-B/D-R/D-P)?

On this level it is decided **whether** and **where** an asymmetry is functional or inadult.  
Moral evaluations come **afterwards**, not before.

---

#### 2. Moral-normative level

Here the question is **whether** what is happening structurally is also **dignified, fair and justified**.

Guiding questions:

* Is the **ontological dignity (D₀)** of all involved preserved?
* Are burdens and consequences distributed fairly?
* Is power used in a way that is **transparent, justified, time-bound, and reversible (T–J–TB–R)**?
* Are there responsible instances – or does a responsibility gap emerge?

This level **builds on** the structural level:
it interprets; it does not replace the structure.

---

#### 3. Psychological level (performative, non-clinical)

Here no diagnosis is given, but **maturity in behaviour** is described:

* tolerance of ambivalence vs. black-and-white acting
* dealing with hurt, powerlessness, loss of control
* capacity to learn, willingness to correct oneself
* tendency toward projection, role confusion, shifting responsibility
* patterns of self-treatment (D-I/D-B), insofar as they are **visible**

The model works **behaviourally**, not therapeutically:
no diagnoses, no inner states without indicators, no pathologising language.

---

#### 4. Narrative-cultural level

Here it becomes visible which **stories and role models** are at work in the background:

* cultural and social codes,
* archetypes (“hero”, “victim”, “authority”, “seducer”),
* scene-/milieu interpretations,
* meta-narratives (freedom, strength, purity, loyalty, etc.).

This level explains why identical actions, depending on context,

* are read in completely different ways,
* take on different moral sharpness,
* or are considered “normal”.

It explains **conflicts of interpretation** – without itself determining which narrative is “correct”.

---

#### 5. Dignity level (optional; D₀/D₁/D₂)

This level is **activated only** when questions of dignity in practice are relevant and the guardrails are upheld.

* **D₀ – ontological dignity:** inviolable, constant, not measurable.
* **D₁ – self-dignity in practice:** operationally via **D-I** (inner dimension) and **D-B** (bodily/material dimension).
* **D₂ – relational dignity:** operationally via **D-R** (relational dimension) and **D-P** (public/symbolic dimension).

Here we ask:

* How do people deal **with themselves** (self-respect vs. self-devaluation)?
* How do they deal **with others / the public** (respect vs. degradation)?
* What does the **trajectory** of these patterns look like?

Dignity level = **analysis of enactments**,
not evaluation of the person themselves.

Taken together, the five levels provide the basic grid:
first read structure, then clarify norms, address psychological patterns only performatively,
take cultural narratives into account, and bring in questions of dignity in a targeted, not inflationary, way.

---

> **Ontological values as a necessary consequence of biological conditions**  
> The model assumes that the world contains objective values that do not depend on cultural, social or individual stipulations. These values do not arise through attribution, but through the structure of the human being itself. The biological and phenomenological constitution of the human being – vulnerability, awareness, social dependency, intentionality and the capacity for self-relation – generates normative conditions that are not arbitrary. A vulnerable, conscious, socially embedded being can flourish only under certain conditions; from these conditions necessary normative structures follow.

> **Thus the following holds:** Certain values (e.g. protection of integrity, recognition, non-harm, preservation of autonomy, respect for self- and world-relation) are *not derived from moral constructions* but *ontologically necessary*, because they follow from the biology and structure of the human being. In this sense, the model refutes the absolute form of Hume’s law: while many facts do not imply an “ought”, the constitution of a being does generate necessary “ought”-conditions for its preservation and dignity.

> Ontological dignity (D₀) is therefore not merely a metaphysical postulate, but an expression of these structural necessities. D₁ and D₂ are understood within this framework as enactment forms of an objectively existing value: they do not describe the value itself, but the way in which this value is treated, preserved or violated in everyday life.

> **Consequence:** The model is based on a moral realism that follows from biological-ontological facts. It protects ontological dignity (D₀) and makes visible how praxeological dignity (D₁/D₂) is derived from precisely this objective structure. This allows the model to be applied to itself without falling into self-contradiction and underpins its particular stability in the face of relativistic or purely constructivist systems.

---

### 1.2 Model = toolbox, not worldview

Once it is clear **on which levels** the model reads, the question arises **how** it should be understood: as a rigid system or as a flexible instrument. The model is **a lens**, not a cage.

* It is meant to help see structures **more clearly** –
  not to force every life situation into its terms.
* Not everything must or can be explained through A–C–R–P–D.
* Anyone who “sees only through the model” misses its praxeological character.

Important agreements for its use:

* The model is **substantively neutral**:

  * It favours no ideology, no party, no milieu.
  * It is interested in **enactment** – not in self-description.

* It is **sensitive to asymmetry**, but not reflexively “anti-asymmetry”:

  * Many asymmetries are **functional** (e.g. education, protection, organisation).
  * They become problematic when they become **incoherent, intransparent, unjustified, unaccounted for**.
  * The later **dignity-in-practice module** helps to see when **self-degradation** is an expression of a degrading structure – and when inner patterns dominate.

* It offers tools, but **no promises of salvation**:

  * It can help to see conflicts and patterns more clearly.
  * It cannot guarantee that people will draw the “right” conclusions.

At the same time, the model starts from a simple but far-reaching observation:
People do not act only out of “character”, but with the tools available to them. Families, milieus, organisations, media and religious traditions convey – explicitly or implicitly – entire tool sets for how to deal with conflict, guilt, power, fear and otherness.

Some of these tools foster mature enactments (e.g. perspective-taking, acknowledging mistakes, making amends, limiting power). Other tools support patterns that, praxeologically, almost always lead to actions that damage dignity: **pure obedience, fear-binding, group superiority, logics of retribution** or **pure utility calculus**. The model calls such patterns “bad tools” – not because they make people “bad”, but because structurally they are more likely to lead to inadult asymmetry (IA) and D₁/D₂ violations.

The IA model therefore deliberately targets the tool level: it is meant to help distinguish whether someone acts destructively because he or she is “evil”, or because the tools available from the outset are distorted, narrowed or degrading. Critique is thus directed primarily at structures, patterns and tool sets – not at the ontological value of persons.

For the remainder of the paper, the following applies:

* **Chapter 2** introduces the base model **A–C–R–P–D** and its parametrisation.
* **Chapter 3** describes the guardrails and ethics of use, including protection of dignity (D₀ as ontological dignity, D₁/D₂ as dignity in practice, dignity-enactment profiles).
* From **Chapter 4 onwards**, tools and scorecards are derived from this that allow
  concrete cases to be read praxeologically.

In other words:

> Anyone using this model adopts a particular **stance towards reality**:  
> preferring clear, reviewable structures over convenient stories –  
> preferring responsibility in practice over morality in the subjunctive –  
> preferring **recognising** to **evaluating**.

Before we send this tool into practice, we need to clarify what form of “maturity” it actually considers – and which misunderstandings we explicitly **do not** intend to feed.

---

### 1.3 Maturity ≠ purity – the role of necessary inadulthood

Before we work with the model, it is worth looking at a widespread misunderstanding of maturity.  
A common misunderstanding about maturity is the assumption
that it means **“complete adulthood”** – as if people were then:

* consistently controlled,
* free of impulse,
* free of vulnerability to hurt,
* always level-headed,
* always coherent,
* always self-caring,
* always strong in responsibility.

This is anthropologically wrong – and in practice would amount to a **dehumanisation**.

#### Basic assumption of the model:

> **People are never fully adult.  
> And complete adulthood would not be an ideal either.**

There are portions of inadulthood that are:

* creative,
* courageous,
* risk-taking,
* nonconformist,
* visionary,
* rebellious,
* vulnerable,

– and precisely for that reason **driving forces of development and society**.

These portions are not a deficit,
but a **raw material** that – depending on role and context –
can unfold either destructive or highly adult effects.
The question is less **whether** such zones exist, and more **how** they are handled.

---

#### Inadulthood as a source of energy

Historically and today:

* Many important actors (politics, science, art, activism)
  show **inadult patterns** –
  but precisely these patterns, in certain roles,
  were channelled into **adult effect**.

The model therefore does **not approach this evaluatively**,
but structurally:

* inadulthood = energy, impulse, movement
* adulthood = stance, responsibility, framework

Maturity does not arise from purity,
but from **integration**.

---

#### Maturity in practice as an achievement of integration

In the model, maturity is not a property
and not a moral ideal, but:

> **the ability to make adult zones available,  
> to hold inadult zones,  
> and to coordinate both under real conditions.**

This means:

* Maturity does not exclude inadulthood.
* Maturity even **presupposes** inadulthood in part.
* Maturity is shown by **how** people deal with their more inadult impulses –
  not by whether they have any.

Inadulthood becomes problematic when:

* burdens of responsibility are ignored,
* the boundaries of others are violated,
* D₁ / D₂ are persistently undermined,
* the four-criteria box (T–J–TB–R) tears.

It becomes constructive when:

* a framework exists (role, context, institution, team),
* lines of responsibility are clear,
* iteration is possible,
* feedback is taken seriously,
* protection of dignity (D₀) and self-respect (D₁) are preserved.

---

#### Why this matters – for dignity, for maturity, for the model

This premise is central,
because it avoids three dangers:

1. **Perfectionism trap**  
   – the model would otherwise come across as a purity doctrine.

2. **Shame trap**  
   – people would view inadult zones as “errors”
   instead of as normal, integrable parts of being human.

3. **Abuse trap**  
   – institutions could try
   to demand “absolute maturity”
   and in doing so violate dignity.

Instead, the following holds:

> **Maturity is movement, not state.  
> Inadulthood is material, not defect.  
> Dignity remains untouchable – precisely because people never act perfectly.**

From the outset, then, it is clear:
this model describes **human reality**,
not ideals, catalogues of virtues or purity of personality.

It protects D₀ (ontological dignity),
structures D₁/D₂ (the praxeological forms of dignity in practice),
and allows a dignified view of development, error, learning and impact.

In this sense, the model also does not understand so-called “unfavourable starting conditions” as defects of persons, but as part of their material: people can enter enactment with very different starting packages of biography, neurobiology, attachment experience and cultural/religious tools. Those who were socialised early primarily into hard, fear-bound or group-based tools (obedience, devaluation, retributive logic, instrumental utility calculus) will, under pressure, more likely fall back on such patterns – praxeologically, therefore, “acting worse” without thereby becoming less dignified.

Maturity in practice then does not mean identifying “better people”, but making visible and workable which tools someone has learned, which are missing – and which framework conditions are needed so that other enactments become possible at all.

At the same time, this achievement of integration is not enough to resolve every dilemma – there are constellations in which even maximal maturity leaves residual pain.

---

### 1.4 Tragic conflicts – when maturity cannot resolve everything

The premise so far clarifies:
maturity does not mean purity, but a grown-up way of dealing with one’s own inadulthood.

At the same time, there are situations in which even high maturity (high A–C–R–P)
does not lead to all goods being preserved:
every real option injures something – dignity, justice, loyalty, safety, truth.

> **Tragedy clause (short version)**  
> Even with high maturity (high A–C–R–P), goods can collide  
> in such a way that every option violates some dignity or justice.  
> Such residual conflicts mark **tragedy**, not automatically inadulthood.  
>
> The task of the model is to distinguish IA-based injuries from tragedy-based ones –  
> not to promise that sufficient maturity will magic away all pain.

For application, this means:
the IA model is meant to help recognise
*where* immature or unaccounted-for asymmetries generate unnecessary suffering –
without claiming that sufficient maturity could completely dissolve every form of pain,
loss or guilt.

This sets three guidelines in Chapter 1:

* Maturity is read **in enactment**, not as an essence.
* Dignity is **protected ontologically** (D₀) and differentiated **praxeologically** (D₁/D₂) – without “evaluating” people.
* Tragic residual conflicts remain acknowledged; the model is meant to create clarity, not promise a pain-free world.

On this basis, Chapter 2 can introduce the base model A–C–R–P–D:
as a precise yet limited lens for reading concrete situations in a structured way.

---

## 2) Short definition & base model A–C–R–P–D

Chapter 1 has clarified **what** this project is about: maturity in practice, dignity in everyday life, inadult asymmetries (IA). For this to be more than a good-sounding perspective, it needs a **technical basis** that makes concrete situations readable and comparable. This chapter lays that basis: five core parameters that are present in some form in every relevant scene and later form the foundation for scores, checklists and tools.

The aim of Chapter 2 is therefore not to already explain “everything”, but to lay open the **basic blueprint**:
Which axes do we read, what do they mean – and how do they interact as a feedback loop?

The model works with five basic axes:

* **A – awareness**
* **C – coherence**
* **R – responsibility**
* **P – power** (room for action in practice)
* **D – dignity in practice**  
  (praxeological forms of dignity in practice: self-dignity **D₁** & relational dignity **D₂**; operationally: inner dignity **D-I**, bodily/material self-care **D-B**, relational dignity **D-R**, public dignity **D-P**)

All further elements (scores, checklists, role mechanics, domain modules) are derivations or refinements of these five axes.  
This chapter clarifies only the **base model**: what each axis means – and how they interact.

---

### 2.1 Five core parameters in brief

As a first step, the five parameters are described in isolation – as “building blocks”, without yet following the later dynamics in detail. Section 2.2 then shows how they influence each other in real scenes and form typical states.

---

#### A – awareness

**A** does not first ask: *“How intelligent is someone?”*  
but: *“What could this person or this system realistically know and see?”*

Awareness includes, among other things:

* access to relevant information (facts, warning signals, alternatives),
* the ability to recognise one’s own role and situation (**role awareness / A-R**),
* sensitivity to side effects and those affected,
* willingness to correct perception (capacity to learn).

**High A values** mean:

* one has made an effort to obtain information,
* one does not ignore obvious signals,
* one can distinguish between inner perception and outward impact.

**Low A values** mean:

* tunnel vision, lack of information, avoidance of knowing,
* unclear or shifting role images,
* “not seeing” oneself and others (or not wanting to see them).

---

#### C – coherence

**C** measures how well **word, decision and action** fit together.

Guiding questions:

* Does someone say one thing – and then act against it?
* Is responsibility promised – and withdrawn when costs arise?
* Do inner reasons, external communication and observable behaviour align?

Coherence is **not a moral judgement**, but a structural criterion:

* **High C values**:  
  statements, decisions and actions form a comprehensible pattern – across time, roles and contexts.
* **Low C values**:  
  breaks, U-turns without explanation, double games, “saying one thing, doing another”.

C thus measures:

> How consistent is the system in practice – across time, roles and contexts?

---

#### R – responsibility

**R** describes **who actually carries and assumes which burden** – materially, emotionally, legally, physically.

Aspects of responsibility:

* assumption of consequences (costs, risks, repair work),
* willingness to name one’s own contributions,
* real influence on decisions (who is allowed to co-decide?),
* fairness of burden distribution between those involved.

**High R values**:

* someone stands by their decisions, even when they become uncomfortable.
* burdens are not systematically delegated downward.
* those affected are not made invisible.

**Low R values**:

* evasion, minimising, shifting blame,
* tendency to take benefits while handing off costs,
* structural **responsibility gaps** (“no one is responsible”).

---

#### P – power

**P** does not just mean “willingness to act”, but above all:
**“What could actually have been done here – and was it done?”**

Dimensions:

* objective room for action (legal, organisational, physical),
* perceived room for action (sense of self-efficacy),
* use of available options (intervening, setting limits, stopping, leaving).

**High P values**:

* real possibility to influence the course of events,
* the ability to make decisions even under pressure,
* access to resources (time, money, attention, infrastructure).

**Low P values**:

* powerlessness, dependency, paralysis,
* structural lack of freedom (e.g. factual lack of alternatives),
* decisions that are only formally possible but in reality untenable.

---

#### D – dignity in practice (self-relation & relational mirroring)

**D** describes **how people treat themselves** – bodily, socially, symbolically –
and what this self-enactment mirrors about their **relationship to the world**.

Two core questions:

* **Inside (D₁ – self-dignity in practice):**  
  “What do I think I am worth?”  
  – self-care, self-respect, boundaries, protection of one’s own integrity.

* **Outside (D₂ – relational dignity in practice):**  
  “What do I think of the world that surrounds me?”  
  – adaptation, refusal, protest, mirroring of degradation (“If you treat me like trash, I live like trash”).

Important:

* D measures the **praxeological forms of dignity in practice (D₁/D₂)**, not D₀.
* **Ontological dignity (D₀)** is taken as **given**: a person remains dignified – even when they treat themselves in undignified ways in practice.
* D therefore says nothing about “how much someone is worth”, but only about
  **how this worth is treated in everyday life** – by the person themselves and in their relation to the environment.

Operationally, D is described in the further course via four submodules:

* **inner dignity (D-I)** – self-respect, self-contact, inner clarity,
* **bodily/material self-care (D-B)**,
* **relational dignity in interaction (D-R)**,
* **public dignity in roles and visibility (D-P)**.

**High D values**:

* basic forms of self-care are recognisable (body, boundaries, time, relationships).
* the person does not systematically treat themselves worse than they would treat others.
* protest against degrading structures seeks forms that also protect one’s own dignity.

**Low D values**:

* self-neglect, self-devaluation, self-objectification,
* treating oneself as if one “were worth nothing” – often as a mirror of an environment that acts in the same way,
* undignified enactment as **congruence** with undignified conditions (“this is how everyone lives here”).

D thus makes visible:

* when **self-degradation** primarily expresses **inner patterns**,
* when it is a **response to degrading conditions**,
* and where society produces IA by morally condemning undignified enactments
  instead of seeing the underlying structures.

Guiding sentence for the entire model:

> **When D is measured, actions are described – never the value of the person.**

---

**Mini-vignette:**  
A team leader demands “radical openness”, but reacts hurt when criticised and withdraws.  
Structurally we see: A partly high (there is awareness of tensions), C low (demand and behaviour do not fit together), R low (the costs of openness fall on employees), P high (the position allows sanctions), D in practice mixed (self-image as “open”, actual handling of one’s own hurt is uncertain).  
The base model names these axes without yet evaluating “what the person is like”.

---

**Interim conclusion for 2.1:**  
A–C–R–P–D define five distinct but interconnected dimensions of action. They are **not type labels**, but reading axes along which situations and profiles can be described. The next step is to look at how these parameters interact as a **feedback loop** in real practice and which typical states result.

---

### 2.2 Dynamics of A–C–R–P–D (feedback loop & states)

After the five parameters were outlined as independent axes in 2.1, 2.2 considers their **interactions**: people never act in “pure form”, but under the influence of time pressure, roles, expectations, fear, hope, context. The dynamics between A, C, R, P and D are therefore crucial for reading situations not just statically but as processes.

The five parameters act as a **feedback loop**, not as isolated categories.

A greatly simplified schema:

1. **Awareness (A)**  
   → what is seen, understood and inwardly admitted.

2. **Coherence (C)**  
   → how this knowledge is translated into decisions, narratives and self-images.

3. **Responsibility (R)**  
   → who consciously takes on or hands off which burdens and consequences.

4. **Action/power (P)**  
   → what is actually done (or omitted) as a result.

5. **Dignity in practice (D)**  
   → how those involved treat themselves – in body, everyday life, relationships and public self-presentation –  
   and what this treatment expresses about their relationship to the world.

**P and D** then feed back into **A**:

* Every action changes the situation:

  * new information,
  * new consequences,
  * new roles,
  * new power relations.

* Every form of self-treatment (D) changes:

  * what someone still **trusts themselves** with,
  * what someone **demands** of themselves (self-overload or self-abandonment),
  * which options are experienced as **visible** and “for me” in the first place.

---

#### Typical **states** (situational, *not* person types)

> States are always **situational, temporary, context-bound** –
> never attributions about “the person”.

---

##### **Adult state**

* A sufficiently high: relevant information is obtained, blind spots actively reduced.  
* C high: decisions, communication and action are comprehensible.  
* R genuinely assumed: burdens are distributed in a reasoned way, areas of responsibility clearly named.  
* P used realistically: room for action is neither underestimated nor overextended.  
* D in practice largely intact: basic forms of self-care, self-respect and keeping boundaries are visible; no systematic self-degradation.

---

##### **Inadult dominance**

* A low or selective (blind spot for one’s own impact),
* C rhetorical but not robust (“nice story”, brittle practice),
* R shifted away (“those down there”, “the circumstances”, “nobody could have known …”),
* P high and at times used without regard for others,
* D distorted: the self is inflated, the dignity of others devalued (↓relational dignity D-R); one’s own dignity is staged at the expense of others.

---

##### **Inadult submission**

* A restricted (no overview, options invisible, narrow self-image),
* C brittle (“I don’t know what is happening here / what I am supposed to do”),
* R over-assumed (taking on too much guilt) or handed off (“there is nothing I can do”),
* P subjectively very low, although objectively more would be possible – or, conversely, unrealistic fantasies of omnipotence with actual powerlessness,
* D in practice clearly reduced: self-neglect, self-devaluation, adaptation to degrading conditions (“this is how everyone lives here”).

Inadult submission is not automatically a personality deficit, but often a **survival strategy under structural constraints**. The model does not read it as a “weak character”, but as an indication of contextual load.

---

**Mini-vignette:**  
A care worker in an understaffed shift sees (A high) that a measure endangers patients. She knows what would be professionally necessary (C clear), but feels left alone and fears sanctions (P subjectively low). She makes an internal note but does not change the procedure (R only partly assumed) and works permanently beyond her own capacity (D in practice falls).  
The state is not a “character judgement”, but the expression of a feedback loop of structure, pressure and self-treatment.

---

The model is interested in **how** these states arise – through modulators, roles, power, information situations –  
not in pinning people down into categories.

This outlines the process logic of A–C–R–P–D: information becomes interpretation, then responsibility decisions, then actions – and from these, forms of self- and world-treatment that in turn feed back into perception and possibilities.  
The next step (2.3) therefore introduces the **modulators** that amplify or dampen this feedback loop and explain why identical roles can lead to very different enactments under different conditions.

---

### 2.3 Modulators – amplifiers & dampers

In 2.2, we saw how A–C–R–P–D interact as a feedback loop and generate typical states. In practice, however, one question remains open: **Why can the same person act so differently under slightly changed conditions – sometimes in an adult way, sometimes in an inadult way?** This is where the modulators come in.

The parameters A–C–R–P–D never exist in a vacuum.  
**Modulators** change how they can show themselves in practice.

They are **not an excuse**, but they explain **distortions**:

* why people with high basic maturity act more inadultly in specific situations,
* why persons systematically treat themselves below or above their real dignity,
* why asymmetries intensify or flatten out.

**Mini-vignette:**  
An experienced physician makes very adult decisions in a calm everyday setting (A high, C stable, R clear, P realistic, D intact). On a night with staff shortages, exhaustion and public pressure, she reacts irritably, becomes unclear in communication and overrides objections.  
Nothing about her basic maturity has changed – the **modulators** have shifted the enactment.

---

#### 2.3.1 Structural modulators

Framework conditions that act **from the outside** on the system:

* **Time pressure & complexity**
  – lower awareness (**↓A**) and coherence (**↓C**), promote snap decisions,  
  – encourage short-term self-neglect (↓bodily/material self-care, ↓D-B).

* **Access to information**
  – creates awareness asymmetries (**A-asymmetries**), relevant for responsibility (**R**) and any responsibility-related scoring,  
  – poor access to information → risk of structural self-devaluation (↓inner dignity D-I / ↓bodily self-care D-B).

* **Role and power differentials**
  – massively affect responsibility (**R**) and power (**P**),  
  – modulate relational dignity (**D-R** – dignity in interaction: whether one makes oneself smaller or larger).

* **Dependencies** (economic, emotional, legal)
  – realistically limit power (**P**),  
  – explain why “theoretically possible” options are in fact unreasonable,  
  – depress dignity in practice (**D**) – survival strategies instead of deficit.

* **Institutional rules**
  – bundle or dilute responsibility (**R**),  
  – can promote or prevent dignified practice.

* **Degree of publicity**
  – private → semi-public → institutional → public → media,  
  – higher publicity = stronger impact on  
    **public/media awareness (A-P)**,  
    **public agency (P-PU)**,  
    **public responsibility (R-P)** and  
    **public dignity in practice (D-P)**.

Core statement:  
Undignified enactment can be the expression of an **undignified environment** – an indication of structural inadult asymmetry (IA), not of personal failure.

---

#### 2.3.2 Dynamic / psychosocial modulators

**Energy and relationship states** in the system:

* **Stress / overload**
  – lowers awareness (**↓A**), lowers coherence (**↓C**), raises IA risk,  
  – dignity in practice (**D**) often collapses immediately (self-care is experienced as a “luxury”).

* **Exhaustion / monotony**
  – lowers responsibility (**↓R**) and power (**↓P**),  
  – over time encourages structural self-devaluation (↓inner dignity D-I / ↓bodily self-care D-B).

* **Experiences of success**
  – increase power (**↑P**), awareness (**↑A**) and coherence (**↑C**),  
  – but risk: overconfidence, self-inflation (↑inner dignity D-I, ↓relational dignity D-R).

* **Social resonance**
  – constructive = stabilising (responsibility and dignity are supported),  
  – toxic = awareness, responsibility and dignity (A, R, D) collapse.

* **Group dynamics**
  – affect the use of power (**P**),  
  – modulate relational dignity (**D-R** – self-betrayal vs. protection), for example when loyalty to the group works against one’s own self-respect.

---

#### 2.3.3 Short rule for practice

1. **Structure first, then person.**  
   – make modulators explicit  
   – situate A–C–R–P–D structurally

2. **Then enactment.**  
   – what was actually done – *under these conditions*?

3. **Only then interpretation.**  
   – recognise maturity patterns  
   – cleanly separate the normative level  
   – make the reading of dignity explicit (**D₁ internally = self-dignity in practice, D₂ relationally = relational dignity in practice**)

This helps avoid inadult snap judgements (“dignified/undignified”).

**Interim conclusion for 2.3:**  
Modulators explain why different enactments can emerge from the same potential. They are therefore not a “bonus”, but a prerequisite for fair structural and responsibility-related assessments and for any reading of dignity. In the next step (2.4), the base model is further differentiated so that it becomes visible *in which sub-area* of a parameter a problem or a particular maturity achievement lies.

---

### 2.4 Parameter matrix & submodules (A–C–R–P–D)

Modulators show **why** enactments shift – the parameter matrix clarifies **where exactly** something is happening. Instead of merely saying “A is low” or “D is high”, breaking parameters into submodules allows for a more fine-grained reading: is the issue role awareness, contextual clarity, inner self-relationship, or public impact?

To understand more precisely *where* something goes wrong or succeeds in a particularly mature way,
the five main parameters are divided into **submodules**.

---

#### Submodules

* **A – awareness**
  – A-I (inner awareness)  
  – A-R (role awareness)  
  – A-C (context awareness)  
  – A-IM (impact awareness)  
  – A-P (public/media awareness)

* **C – coherence**
  – C-S (social coherence)  
  – C-P (coherence in power contexts)  
  – C-N (narrative coherence)  
  – C-I (institutional/rule coherence)

* **R – responsibility**
  – R-I (individual responsibility)  
  – R-S (social responsibility)  
  – R-E (ethical responsibility)  
  – R-P (public responsibility)

* **P – power**
  – P-I (inner agency / inner power to act)  
  – P-S (social agency)  
  – P-C (cultural agency)  
  – P-PU (public agency)

* **D – dignity in practice**
  – D-I (inner dignity / inner self-relationship)  
  – D-B (bodily/material self-care)  
  – D-R (relational dignity)  
  – D-P (public dignity / dignity in public enactment)

---

#### Table: parameters, submodules, expressions

| **Parameter**                | **Submodules**                                 | **Low expression**                          | **Medium expression**                          | **High expression**                                   | **Excessive expression / distortion**                         |
| ---------------------------- | ---------------------------------------------- | ------------------------------------------- | ---------------------------------------------- | ----------------------------------------------------- | ------------------------------------------------------------- |
| **A – awareness**            | A-I (inner awareness)                          | little self-contact, impulsive behaviour    | situational self-perception                    | reflective inner life, self-regulation                | self-overmonitoring, rumination                               |
|                              | A-R (role awareness)                           | unclear about which role one inhabits       | roles recognised but not steered               | conscious role guidance, switching                    | role-play rigidity, loss of authenticity                      |
|                              | A-C (context awareness)                        | context blindness, misunderstandings        | situational contextual sensitivity             | confident navigation of contexts                      | overinterpretation, paranoia                                  |
|                              | A-IM (impact awareness)                        | naïve sense of being ineffectual            | basic impact assessment                        | conscious impact management                           | calculation of effect, manipulation                           |
|                              | A-P (public/media awareness)                   | no sense of public impact                   | basic media/public sensitivity                 | professional management of public impact              | surveillance-like self-image, permanent self-censorship       |
| **C – coherence**            | C-S (social coherence)                         | social codes missed                         | situational social reading                     | confident navigation of social spaces                 | social masking, overadaptation                                |
|                              | C-P (coherence in power contexts)              | power differentials not recognised          | partly recognised                              | consciously handled                                   | power dominance or power phobia                               |
|                              | C-N (narrative coherence)                      | missing meaning layers                      | partly understood                              | conscious use of meaning structures                   | symbolic overload, mythologisation                            |
|                              | C-I (institutional/rule coherence)             | rules ignored                               | rules understood situationally                 | rules consciously used/circumvented                   | technocratic rigidity                                         |
| **R – responsibility**       | R-I (individual responsibility)                | avoidance                                   | occasional assumption                          | active self-responsibility                            | hyper-responsibility, taking on excessive guilt               |
|                              | R-S (social responsibility)                    | indifferent / careless                      | situational awareness                          | proactive social action                               | martyrdom, self-sacrifice                                     |
|                              | R-E (ethical responsibility)                   | ethical blindness                           | situational sensitivity                        | consistent ethics                                     | moral superiority, rigidity                                   |
|                              | R-P (public responsibility)                    | naïve “I can do anything” attitude          | basic awareness                                | active management of public impact                    | PR-calculation, paralysis from fear of exposure               |
| **P – power**                | P-I (inner agency)                             | powerlessness, passivity                    | situational self-efficacy                      | stable self-efficacy                                  | compulsion to control                                         |
|                              | P-S (social agency)                            | little influence                            | situational influence                          | stable leadership/interactional strength              | dominance                                                     |
|                              | P-C (cultural agency)                          | no narrative influence                      | occasional cultural impact                     | shaping cultural meaning                              | manipulative symbolic control                                 |
|                              | P-PU (public agency)                           | low reach                                   | moderate visibility                            | strong public presence                                | “escalation risk”: IA-risk via uncontrolled public dynamics   |
| **D – dignity in practice**  | D-I (inner dignity)                            | self-devaluation, harsh inner tone          | ambivalent self-view                           | kind, realistic inner dialogue                        | grandiose invulnerability, devaluation of others              |
|                              | D-B (bodily/material self-care)                | neglect of body, everyday life              | selective self-care                            | stable basic care, protection of boundaries           | compulsive self-optimisation, performance/body cult           |
|                              | D-R (relational dignity)                       | making oneself small, swallowing everything | situational boundary-setting                   | maintaining one’s own dignity without degrading others| constant moralising, shaming others “in the name of dignity”  |
|                              | D-P (public dignity)                           | self-degradation for clicks/applause        | pragmatic handling of visibility               | conscious, dignity-preserving self-representation     | total self-branding, permanent self-objectification           |

---

#### Function of the parameter matrix

The parameter matrix is a **zoom tool**: it allows the translation of general impressions (“something is off here”) into precise observations:

* Is the issue primarily **awareness**, **coherence**, **responsibility**, **power**, or **dignity in practice**?
* Does it concern inner processes (A-I, D-I) or public impact (A-P, P-PU, D-P)?
* Does dignity in practice (**D**) show primarily **inner patterns** (D₁ = self-dignity in practice) – or **reactive mirroring/protest** against degradation (D₂ = relational dignity in practice)?

The matrix thus enables a precise, non-moralising analysis of asymmetries: instead of “X is immature” or “Y has no dignity”, it becomes visible *which* axis has tilted under *which* conditions.

**Interim conclusion for 2.4:**  
The parameter matrix turns five basic axes into a finely structured grid. It will later be used for scorecards, case analyses and domain modules. Before these instruments are applied, however, it must be clear *who* is being observed and *in which public context* this enactment takes place – this is clarified in section 2.5.

---

### 2.5 Publicity & position of the object of observation

Before a case is analysed, a clear determination is needed:

> **“In which role and in which public context does the system under observation stand – and how is its dignity enacted there?”**

This step is **mandatory** before any IA or D analysis can begin.  
Without it, private, weak, or dependent positions risk being treated like powerful public actors – a classic case of inadult asymmetry within the analysis itself.

**Mini-vignette:**  
Anna expresses serious doubts about her role as a parent in a confidential conversation with a friend. The same sentences are later taken out of context and quoted on a large platform as if she had said them in an official interview.  
Structurally, this is **not the same scene**: role position and level of publicity have shifted – and with that A, R, P and D-P.

---

**The object of observation** may be:

* an individual person,
* a relational system (e.g. team, family),
* an institution,
* a discourse or narrative.

For every analysis, **two axes must be determined**:

---

#### 1. Role position

Is the object of observation acting …

* as a **private person**?
* as a **role-holder** (office, profession, leadership role)?
* as **part of a collective** (committee, project team, political movement)?
* as a **spokesperson for a narrative or organisation**?

Relevant modules:

* **A-R** – role awareness  
* **C-S / C-P** – social and power-related coherence contexts  
* **D-R** – relational dignity in role enactment

Without explicit role determination, semantic drift, phantom intentions and inadult asymmetries through faulty attribution become likely.

---

#### 2. Level of publicity

* purely **private**
* **semi-public** (organisations, groups, scenes)
* **institutional** (formal contexts, mandates)
* **public** (broad visibility, susceptibility to critique)
* **media-amplified** (archives, algorithmic reproduction)

Relevant modules:

* **A-P** – public/media awareness  
* **P-PU** – public agency  
* **D-P** – public dignity in practice

The higher the level of publicity, the higher the requirements for awareness (**A**), responsibility (**R**) and public dignity (**D-P**).

---

#### Principles

* The same behaviour may be evaluated **structurally differently** depending on role and publicity.
* More publicity = more responsibility for impact (impact awareness **A-IM**, public responsibility **R-P**).
* High public reach (**P-PU** high) increases the risk of relational dignity breaks (**D-R/D-P**).
* Private, weak or dependent roles may not be evaluated as if they were public figures.
* Analysis of private enactments without specifying role and context counts as IA-suspect.

**Mandatory step:** always determine role + publicity **before** A–C–R–P–D.

**Interim conclusion for 2.5:**  
With role position and level of publicity determined, the model knows *from where* it is reading and *which responsibility structure* it assumes. Chapter 2 has thus completed its basic task: the five base axes are defined, their dynamics and modulators explained, the parameter matrix established, and the object of observation situated.  
On this basis, Chapter 3 can formulate the guardrails and ethics of use that prevent the model itself from becoming a machine for inadult asymmetry.

---

### 2.6 Ontological vs. praxeological dignity

The previous sections described maturity and asymmetry primarily structurally. But once the D module appears, the model encounters a concept that is heavily charged in philosophy, law, politics and everyday life: **“dignity”**. Without a clear separation of levels, every observation of dignity-enactments risks being misunderstood as a statement about the worth of a person.

“Dignity” is one of the most overloaded concepts we have:
philosophically, religiously, legally, morally.

To keep the model workable, it separates **two levels**, later three (D₀/D₁/D₂), that are often conflated in everyday speech:

* **D₀** = ontological dignity (inalienable worth of persons),
* **D₁/D₂** = praxeological forms of dignity in practice (self-dignity and relational dignity).

This separation is the prerequisite for the model being able to make dignity-enactments visible
without becoming an authority over the “worth” of persons.

---

#### 2.6.1 Ontological dignity – non-negotiable, not measurable

**D₀** = the inalienable worth of every human being as a human being – **ontological dignity**.

Properties:

* equally distributed  
* not gradable, not losable  
* not measurable, not scalable  
* not an object of analysis  
* axiom of the model  

Consequences:

* Even destructive or derailed actions do **not** change D₀.  
* The model neither removes nor assigns dignity.  
* Where practices or language explicitly deny D₀ (“subhumans”, “trash people”), the **red zone** begins:  
  → this is where any legitimate use of the model ends.

---

#### 2.6.2 Praxeological dignity (D) – dignity in practice

Praxeological dignity means:

> **How someone handles their own dignity in action – and what this enactment shows about their relationship to the world.**

It includes:

* **self-relation – D₁ (self-dignity in practice):**  
  self-care, self-devaluation, self-protection.
* **relation to the world – D₂ (relational dignity in practice):**  
  adaptation, protest, mirroring, refusal.
* concrete **enactments**, not inner diagnoses.

Typical forms of enactment include:

* care and protection of one’s body and daily life,
* forms of self-protection or self-defence,
* self-degradation and neglect,
* self-staging and self-objectification.

Core idea:

> **People act undignifiedly at times – and yet remain dignified (D₀).**

Praxeological dignity is:

* observable – it appears in actions and routines,
* gradual – from minor irritations to major dignity breaks,
* context-dependent – the same act can appear differently depending on role/context,
* changeable – especially over longer trajectories,
* reversible – dignity trajectories can improve.

The three levels of the model:

1. **D₀** – ontological dignity  
2. **D₁** – self-dignity in practice  
   (operationalised via **inner dignity (D-I)** and **bodily/material self-care (D-B)**)
3. **D₂** – relational dignity in practice  
   (operationalised via **relational dignity (D-R)** and **public dignity (D-P)**)

Thus it is clear: when the model speaks of “dignity in practice”, it refers to observable actions – not to the person “as such”.

---

#### 2.6.3 Relational dignity (D₂) – dignity in relation to the world

**D₂** describes how someone responds to their world:

* **adaptation** – seeking protection, recognition, or relief,  
* **protest** – breaking expectations to make degradation visible,  
* **mirroring degradation** – adopting and returning degrading images,  
* **refusal** – withdrawing from roles or structures experienced as degrading.

Key insight:

> **Many seemingly “self-damaging” enactments are responses to degrading structures – not personal defects.**

Contexts where D₂ is especially relevant:

* politics and power relations,  
* cultural and media spaces,  
* institutional practice ethics.

**D₂** is the conceptual level of relational dignity;  
it becomes operationally visible via **D-R** and **D-P**.

**Mini-vignette:**  
A person begins presenting themselves in a deliberately demeaning way on social media (“I’m trash anyway”).  
In the D module, this is not read as “lacking dignity”, but as relational dignity enactment: D₂ mirrors an environment that has treated the person in exactly this way for a long time.

---

#### 2.6.4 Boundary: “acting without dignity” vs. “being without dignity”

The model speaks solely about **dignity enactments (D)**:

* allowed: “In this scene, X acts in an undignified way.”
* not allowed: “X is undignified.” (a judgement about the person → red zone)

Mnemonic:

> **Recognise the action – not the person.**

This separation is practically implemented in Chapter 3.5–3.7 and in the D quick grid.  
It forms the model’s internal safeguard: dignity is described in practice without touching the ontological worth of persons.

**Interim conclusion for 2.6:**  
With the separation of D₀, D₁ and D₂, it is clear *what* the model refers to when analysing dignity. D₀ remains untouchable; D₁/D₂ become praxeologically readable. In the next step (2.7), this becomes a concrete **D module** that describes how dignity-enactments are observed, situated and protected against misuse.

---

### 2.7 D module – overview

The model is **five-axis (A–C–R–P–D)**.  
The **D module** is not an external add-on but a **deep analytic layer** for D₀/D₁/D₂:

* band logic,  
* safeguard clause,  
* communication rules.

It is activated when the central question becomes:

> **“How does someone handle their own dignity here – and what does this reveal about their environment?”**

As long as this question is not relevant or cannot be cleanly embedded, D remains in the background.

---

#### 2.7.1 Guiding formula & basic stance

Guiding formula:

> **People act without dignity – yet remain dignified.  
> Often because options are invisible to them.**

Basic stance:

* no moral contempt,
* structural understanding,
* situational, not identity-based readings,
* focus on role, context and timing.

Mnemonic:

> **D module = revealer, not pillory.**

---

#### 2.7.2 What the D module observes – and what it does not

**Observes:**

* **inner dignity (D-I)** – inner self-treatment, inner dialogue, self-respect,
* **bodily/material self-care (D-B)** – treatment of body, health, everyday life, resources,
* **relational dignity (D-R)** – how someone shapes boundaries, respect and closeness in relationships,
* **public dignity (D-P)** – how someone presents themselves in public spaces and roles.

**Does not observe:**

* diagnoses,
* rankings,
* moral condemnation,
* disciplinary judgements,
* dignity statements about identity.

**Mini-vignette:**  
Two people post hurtful content about themselves. For one, it is an ironic comment among friends (D-P slightly irritated, D-I stable); for the other, an expression of long-standing self-devaluation (D-I and D-P clearly reduced).  
The D module does not ask: “Who is ‘worse’?” but: “What enactments do we see – and what structures stand behind them?”

---

#### 2.7.3 Safeguard clause

1. **D₀ (ontological dignity) remains untouched.**  
2. **D refers always to scenes** (role, context, timing).  
3. **D descriptions must be documented and are open to critique.**  
4. **No D scores for persons**  
   – only profiles and bands.

The safeguard clause ensures the D module cannot be used as a moral weapon but remains a transparent, criticisable reading framework.

---

#### 2.7.4 Scale logic: banal → extreme (always reversible)

Three-level scale:

1. **banal D irritations**  
   – small breaks, everyday incoherences, situational self-neglect.
2. **consistent D breaks**  
   – recurring patterns of self-devaluation or degradation of others.
3. **massive/extreme D breaks**  
   – ongoing, deep degradation in practice, often under structurally extreme conditions.

Principle:

> **Every level is reversible – the model knows no permanent degradation.**

Classification depends on:

* awareness (**A**),
* coherence (**C**, especially C-P/C-N),
* responsibility (**R**, including modulator-informed limits),
* power (**P**).

---

#### 2.7.5 Limits of D₁/D₂ in trauma & neurodiversity

D₁/D₂ reflect **enactments**, not inner states.

There are situations in which visible D enactments **cannot** be meaningfully interpreted as indicators of maturity or dignity without high risk of misinterpretation. These include in particular:

* complex trauma sequelae  
* dissociation  
* severe depressive episodes  
* anxiety disorders / OCD  
* eating disorders  
* ADHD in overload  
* autism spectrum (especially shutdown/overload)  
* chronic exhaustion  
* acute psychological crises  

In such cases:

* **D₁/D₂ ≠ indicators of maturity or immaturity.**  
  They reflect **burden**, not “character”.
* D reading is **paused or tightly framed**:  
  – “D is not interpretable here → read structural load (A/modulators/IA).”
* The **responsibility ceiling remains low**, even if D enactments appear chaotic.
* If D is considered at all, it is only as:  
  – “signal of burden” –  
  not as a “self-dignity level” or “D deficit”.

Short formula:

> **In high-burden clinical or neurodiversity-related states,  
> D₁/D₂ are not used as maturity parameters – only, if at all, as indicators of strain.**

This protects D from implicit pathologising and prevents it from being misused as substitute diagnosis.

**Interim conclusion for 2.7:**  
The D module makes dignity in practice readable without touching D₀ – and simultaneously builds safeguards against misuse. It shows how people treat themselves and others without evaluating their worth. Before Chapter 3 formulates guardrails and ethics of use, section 2.8 clarifies **language hygiene**: how to speak about risk, harm, potential and danger without unintentionally distorting D₀ or D enactments.

---

### 2.8 Language hygiene: risk, harm, potential, danger

The previous sections showed how finely the model distinguishes between structure, responsibility and dignity enactments. Much of this work happens **in language**: what we call “risk”, “danger”, “harm” or “undignified” directly shapes which A–C–R–P–D findings we even see. Vague terms not only make texts unclear, they can themselves become a form of inadult asymmetry.

To prevent the model from generating ambiguity through unclear wording,
a few central terms are used **technically**:

---

#### 2.8.1 Risk, danger, harm, potential

* **Risk**  
  = possibility of an unwanted event **before** it occurs.  
  “There is a risk that …” means:  
  *probability × possible severity of harm*, not yet realised.

* **Danger**  
  = a **concrete threat state** that exists now – regardless of whether it is perceived.  
  A system may be in danger even if participants deny the risk.

* **Harm**  
  = an **occurred** unwanted event:
  injury, loss, breach of trust, irreversible disadvantage.

* **Potential**  
  = range of possibilities in both directions:
  opportunities **and** risks, still undecided.

Language hygiene here means:

* no mixing of risk, danger and harm;
* no rhetorical inflation (“catastrophe”, “scandal”)  
  at points where the first task is to clarify:  
  – What was the risk?  
  – What danger existed?  
  – What harm actually occurred?

---

#### 2.8.2 Language hygiene in the D context

With the D module (2.6–2.7) comes another sensitive distinction:

* **“acting without dignity”** is **not** the same as  
  **“being without dignity”** or **“unworthy”**.

The model deliberately speaks of **D enactments** (high/low dignity enactment),
not of “undignified people”.

Consequences:

* **Adjectives applied to persons** such as “undignified”, “worthless”, “scum”
  count within the model as a **D break on the side of the observers**.
* When discussing D, it must always be clear:  
  – Which concrete action is meant?  
  – In which context?  
  – In which role?

---

#### 2.8.3 General language hygiene in the paper

For the entire paper:

* terms are used **mechanically and consistently**,
* psychologising or pathologising labels  
  (“sick”, “disturbed”, “narcissistic”)  
  are avoided unless explicitly justified,
* degrading language (“scum”, “trash people”, “they’re worth nothing”)  
  marks an **IA and D finding of its own**:  
  – it reveals something about the structure and maturity  
    of the *speaker*, not the ontological worth of the target.

Where normative language is necessary (protected goods, justice, reasonableness),
it is **marked as such** and kept separate from structural description.

In this way, the model remains true to its purpose even linguistically:

> **to analyse maturity and dignity in practice –  
> not agitation in vocabulary.**

**Interim conclusion for 2.8:**  
Language hygiene is not a stylistic issue but part of the model logic: those who use risk, danger, harm or dignity imprecisely automatically distort A–C–R–P–D findings and easily produce inadult asymmetries themselves. On this linguistic basis, Chapter 3 can now clarify **under which conditions** the model may be used at all – and which guardrails are meant to prevent analysis from producing new degradation.

---

## 3) Framework of use & guardrails (mandatory module)

Chapter 2 provided tools that can describe maturity, asymmetries and dignity-enactments in great detail. Precisely because of this, a new risk emerges: a model that makes maturity and inadult asymmetry visible can itself become an asymmetric weapon – for example when it is used to stigmatise, sanction or “down-score” individual persons.

This chapter defines **under which conditions** the model may be used at all –  
and where its use is **explicitly excluded**.

With the dignity-in-practice module this becomes doubly sensitive:

* The model touches **ontological dignity (D₀ – ontological dignity)**  
  **and**
* **praxeological dignity (D)** – i.e. concrete enactments of self-treatment:  
  self-care, self-devaluation, protest, adaptation, public self-objectification  
  (D₁/D₂ as dignity in practice).

**Mini-vignette:**  
A team uses the IA framework to reflect on a conflictual decision. A leader suggests using the resulting A and D profiles as an argument for dismissals (“X is just immature”).  
This is precisely where the guardrails apply: the model must not be used for covert diagnostics or for moral sorting of persons.

Basic assumption:

> A tool that makes maturity, power asymmetries **and** dignity-enactments visible  
> creates a **discursive asymmetry** of its own.  
> This asymmetry is only functional if it is **restrained, justified and bounded**.

The guardrails are therefore not an add-on, but a **mandatory module**:  
without them, any IA analysis is **invalid** – regardless of how elegant it sounds or how “noble” the intention appears.

---

### 3.1 Structures, not persons – zones

#### 3.1.1 Profile ≠ person

The model is a **procedural magnifying glass**, not an instrument for evaluating people “as a whole”.

It is interested in:

* **structures**  
  (distribution of power, architecture of responsibility, roles, rules),
* **enactments**  
  (concrete actions, decisions, communication patterns, self-enactments as dignity in practice, D),
* **contexts & modulators**  
  (time pressure, publicity, institutions, dependencies),

not in:

* judgements of personality (“X is a bad / worse person”),
* clinical diagnoses,
* moral overall rankings of individuals,
* ontological judgements about dignity (D₀ – “this person is worth nothing”).

From this follows the basic rule:

> **Profile ≠ person.**  
> From observable behaviour, **profiles of structures and enactments** are derived –  
> not the “essence” of a human being.

---

#### 3.1.2 System axiom: no enactment is purely individual

> **System axiom (short version)**  
> No enactment is purely individual.  
> Every IA or maturity finding must also identify the structural co-causes  
> (roles, organisation, modulators, framework conditions).  
>
> Purely individual attributions (“X is immature”, “Y lacks dignity”)  
> without contextual and systemic analysis are, within this model, themselves  
> a form of **inadult reduction**.

In practice this means:

* Every finding must at least specify:
  * in which **role** someone acted,
  * in which **system** (organisation, family, online platform, public sphere …),
  * under which **modulators** (time pressure, dependency, uncertainty, threat …).
* Individual “inadult” enactments may  
  * be an expression of an **inadult personal dynamic**,  
  * but just as well of an **inadult system** that sanctions mature enactments  
    or systematically makes them harder.

The model thereby explicitly immunises itself against simple blaming:

> Wherever people merely say “X is immature” without reading the system alongside,  
> this is **not** an IA finding in the sense of this model – but itself an IA  
> in the handling of complexity.

---

For the dignity-in-practice module this means concretely:

* There is **no “dignity score” for persons**.
* There are only **dignity-enactment profiles (D profiles)**:

  * how someone treats themselves  
    (self-dignity in practice, D₁, operationally via inner dignity **D-I** and bodily/material self-care **D-B**),
  * how someone positions themselves in relationships and towards society (**relational dignity D-R**),
  * how someone appears in public (**public dignity in practice D-P**).

A low dignity-enactment (D) means:

> “Here, dignity in practice is being violated –  
> through self-devaluation, through adaptation to practical degradation,  
> or through the degradation of others”,

but **not**:

> “This person is less dignified.”

To limit misuse, the model works with **zones** of application:

#### Green zone – recommended use

This is where the model belongs:

* Analysis of **structures**:

  * organisations, procedures, discourses, sets of rules, cultures, communication patterns.
* Work on **cases at a distance**:

  * historical situations, fictional scenarios, abstracted case vignettes.
* **Self-application**:

  * reflection on one’s own projects, decisions, roles, patterns, self-enactments (including D).
* **Clarifying frameworks** in professional contexts:

  * education, organisations, politics, media – provided it is used without person-ranking  
    and without diagnostics.

Typical questions in the green zone:

* How is responsibility distributed?
* Where do words and deeds diverge?
* Which roles are played in which ways – and where are they unclear?
* Which asymmetries are functional, which inadult?
* Where does someone treat themselves **systematically below** their dignity –  
  and where does that mirror an **degrading environment**?

#### Yellow zone – only with special care

Yellow are situations in which real affected persons are involved, but:

* the focus remains on **structures and procedures**,
* the analysis does **not** serve as a basis for decisions about individuals  
  (e.g. internal reflection processes, team supervision, mission statement work, ethics committees).

Conditions for the yellow zone:

* explicit embedding in a **framework of protection and responsibility**  
  (e.g. supervision, mediation, moderated workshops),
* clear communication about what the model can and cannot do,
* not the sole basis for sanctions, diagnoses, personnel decisions,
* particular restraint with the dignity-in-practice module:

  * D is used rather to make **needs for protection and support** visible  
    (“someone is treating themselves significantly below their dignity”),  
    not to “morally classify” someone.

#### Red zone – explicit no-go areas

**Red zone = use prohibited.**

These include, among others:

* **clinical diagnostics** and treatment planning  
  (psychiatry, psychotherapy, trauma therapy, addiction treatment, personality diagnostics),
* **HR decisions about individuals**  
  (recruitment, dismissals, promotions, performance evaluations),
* **child and youth diagnostics** in schools, youth services, families,
* **forensics, criminal prosecution, security agencies**  
  (risk assessments, sentencing, parole decisions),
* **public pillorying or ranking formats**  
  (lists of “toxic” persons, maturity rankings, moral leaderboards),
* **online doxing, cancel campaigns, shitstorms**  
  – any use of the model for retroactive shaming of individuals,
* specifically for the dignity-in-practice module:  
  – any form of **“humiliation diagnostics”** (“XY has no dignity”, “XY lives like garbage”),  
  – public speculation about D profiles of individual real persons.

Note on the **double red zone**:

* In **2.6.1**, “red zone” designates the area in which D₀ – ontological dignity –  
  is denied in language or practice (e.g. “subhumans”).
* In **3.1**, “red zone” designates the **contexts of use** in which the model itself  
  must not be applied (diagnostics, HR, forensics, pillory formats, etc.).

Both levels are connected:

> Where D₀ is denied, legitimate use of *any* IA analysis ends.  
> Where the application-related red zone is touched, using the model itself  
> becomes a risk to dignity – and is therefore excluded.

If a planned application even faintly smells of “red zone”, the rule is:

> **Do not use it.**  
> No fine-tuning, no exception, no “just a little” –  
> especially not with D.

**Interim conclusion for 3.1:**  
Chapter 3 begins with a double stipulation: the model may only target structures and enactments, never the value of persons – and no finding is valid that ignores the system. The zone logic marks where the tool belongs, where it may be used only under conditions, and where it is strictly taboo. The next section (3.2) clarifies what form of **minimal adulthood** users themselves must bring in order to use the model responsibly at all.

---

### 3.2 Entry condition: minimal adulthood

The model presupposes a certain **minimum mindset level** on the side of the user.  
It is not enough to know the terms or to be able to operate scorecards – what matters is **from which stance** they are used.  
Without a minimum willingness to self-critique and to protect dignity, the IA framework quickly turns into exactly what it criticises: an asymmetric technology of power.

> **Minimal adulthood = willingness to see oneself as involved and to keep dignity non-negotiable.**

Anyone using the model must be willing:

* to think about their own role in the case (self-implication),
* to accept unpleasant results also “for their own side”,
* not only to seek confirmation, but to allow **correction**,
* not to reduce complex situations to simple culprits,
* to distinguish between **ontological dignity (D₀)** (always intact) and **praxeological dignity**  
  (D₁/D₂ as dignity-enactments, changeable).

A simple self-question:

* **Do I want to use this to humiliate people, to win, to cut others down to size,  
  to “prove that they lack dignity”?**  
  → Then: **do not use the model.**
* **Do I want to see more clearly where I myself / we ourselves were wrong or blind –  
  including in our handling of dignity?**  
  → Then: **use the model** – under guardrails.

Minimal adulthood means concretely:

1. **No moral self-elevation**

   – no covert “I now see better than all of you”,  
   – no: “I decide who still deserves dignity.”

2. **No hunting for enemies**

   – the model is **not** a tool to “objectively” prove opponents’ immaturity  
     or “lack of dignity”,  
   – especially not through snippets of their dignity-enactment  
     (images, shitstorms, outbursts).

3. **Taking protection goods seriously**

   – dignity, protection of reputation, child protection, physical and psychological integrity  
     stand **above** any analysis,  
   – the value of persons remains outside the metric; D findings always apply only to  
     **concrete enactments**, never to the essence.

4. **Willingness to learn**

   – willingness to revise one’s own analysis later if new information  
     or falsifiers appear,  
   – willingness to say: “Here I denied the other side their dignity –  
     that was itself an inadult enactment.”

**Mini-vignette:**  
A team wants to analyse an escalated conflict using the model. One person realises: “I am still too hurt. If I now start evaluating dignity-enactments, I will just look for ammunition.”  
On this basis, the team decides: **postpone the analysis**, stabilise first – and return later with more distance.

From the perspective of the model it is therefore legitimate in practice to say:

> “Right now I am too angry / hurt / biased –  
> I do not meet minimal adulthood.  
> → I will **consciously not** apply the model now – especially not the dignity-in-practice module.”

That, too, is maturity in practice.

**Interim conclusion for 3.2:**  
Minimal adulthood is not a moral badge but an entry condition: whoever does not currently meet it best protects the model – and others – by **not** using it. The following procedural guardrails (3.3) translate this stance into concrete rules for every application.

---

### 3.3 Procedural guardrails (modules 1–6)

Minimal adulthood is the inner stance – the **procedural guardrails** are the outer form.  
They secure the **procedural integrity** of analyses and define **how** the model may be used.  
They apply to all parameters A–C–R–P–D, with particular sharpness once the dignity-in-practice module is activated.

The following guardrails secure the **procedural integrity** of analyses.  
They define **how** the model may be used.

They apply to all parameters A–C–R–P–D, with particular sharpness once D is in play.

#### Guardrail 1 – structure before person

* The focus lies on **A–C–R–P–D** and their modulators, not on characterology.
* Statements sound, for example, like:
  “In this structure, responsibility R is delegated downward” –  
  not: “Person Y is cowardly / toxic / inferior.”
* Profile formation is a **one-way street**:

  * *behaviour → structural profile / enactment profile*,  
  * but not: *profile → “This is who you are.”*

For dignity in practice this means:

* “Here, repeated self-devaluation is visible (D-I/D-B low)”  
  ≠ “You are worthless.”
* “Here, an institution is degrading entire groups”  
  ≠ “These groups are like that.”

#### Guardrail 2 – dignity protection & anti-ranking

* No use of the model for **public evaluation** of individuals.
* No lists, tables or scores that compare persons  
  (“who is more mature?”, “who has more dignity in practice?”).
* No ironic or demeaning framings  
  (“IA losers”, “toxic faction”, “zero-dignity profile”, etc.).
* Norm core:

  > **Dignity = non-negotiable; value of persons ≠ score.**  
  > Dignity in practice (D₁/D₂) only shows how someone – under conditions –  
  > is currently dealing with themselves / others / the world.

Any use of D that smells of “pillory” violates this guardrail.

#### Guardrail 3 – duty of context & transparency

* No quick evaluations without explicitly clarifying:

  * context (time, institution, public sphere, roles),
  * information status (what do we know for sure, what is an assumption?),
  * modulators (stress, leverage strength, persistence, protection goods, etc.).

* Analyses must make their **assumptions visible**:

  * What is observed?
  * What is interpreted?
  * What is speculation?

For D there is an additional point:

* Many dignity-enactments (D₂ – relational dignity in practice) are **relational reactions** to practical degradation.
* Neglect, self-devaluation, radical adaptation can be protest, mirror,  
  or survival strategy.
* Anyone who quickly cries “own fault” or “lack of dignity” here  
  produces **structural inadult asymmetry** themselves.

Where context is unclear or highly contested, the mature answer is more often:

> “With this data, no robust IA or D analysis can be made.”

#### Guardrail 4 – reciprocity & self-application

* The model must **not** be applied only “from above to below”:  
  institutions, authors, analysts themselves must also be included in the view.
* Every analysis implies:  
  “What does this perspective say about **us**?” –  
  about our values, our blind spots, our handling of power and dignity?
* Anyone using the model commits to:

  * role reversal (how would the same structure look from the other side?),
  * self-check (which IA and D breaches do we produce ourselves?).

For D this means:

* The language and tone of the analysis are **themselves** dignity in practice:  
  – degrading language **about** affected persons  
    = a dignity breach (D) by the observers themselves.

#### Guardrail 5 – option for improvement instead of judgement

* Every IA or D diagnosis must include a **repair or improvement option**:

  * What steps could bring awareness, coherence, responsibility and power (A–C–R–P) back into sync?
  * How could burdens be distributed more fairly?
  * Which asymmetries could be justified, limited or time-bound?
  * How could dignity in practice be **supported again**  
    (protection, alternatives, access, relief, mirroring, recognition)?

* Pure “diagnoses” without any proposal (or at least search) for a gain in fairness or dignity are **inadult use** of the model.

#### Guardrail 6 – versioning & reversibility

* Analyses are **work-in-progress**, not final truths.

* It is explicitly permitted (and expected) that:

  * evaluations are revised,
  * scores are adjusted,
  * entire readings are discarded when falsifiers emerge.

* The model itself remains a **working draft** –  
  and demands this attitude from its users as well.

For dignity in practice this means:

* A once-identified low dignity-enactment  
  (“self-devaluation”, “self-abandonment”)  
  is **not a label**, but an invitation to observe trajectories:  
  – does it get better, worse, more stable?  
  – which structural changes support dignity?

**Meta-rule (applies to all guardrails):**

> As soon as a guardrail is **consciously ignored** or **circumvented**,  
> the IA / D analysis in question is **praxeologically void** –  
> it is not mature enough for publication, institutionalisation or use by third parties.

**Interim conclusion for 3.3:**  
The procedural guardrails keep the model on track: structure before person, protection against ranking, duty of context, reciprocity, focus on improvement, and reversibility. Whoever follows them uses the framework as a tool of clarification – whoever breaks them turns it into a weapon. The next section (3.4) makes this logic explicit for the analysts themselves: **who analyses, shows themselves.**

---

### 3.4 Self-implication: whoever analyses, shows themselves

Every application of the model says **at least as much** about the analysts  
as about the system under consideration.  
Self-implication means: A–C–R–P–D of the analysts becomes **readable too** – whether they want it or not.

**A – awareness of the analysts**

* Which contexts are taken into account, which are left out?
* Which sources and perspectives are taken seriously?
* Which dignity-enactments of others are noticed – which are not?

**C – coherence of the analysts**

* Do claim, language and practice match?
* Are guardrails observed?
* Is the distinction between ontological dignity (D₀) and dignity in practice (D₁/D₂) kept linguistically clear?

**R – responsibility of the analysts**

* Who bears the consequences of the analysis (reputation, trust, climate, risk)?
* Are uncertainties and assumptions disclosed?
* Is it made clear that D only evaluates enactment, not the value of persons?

**P – power (power to act) of the analysts**

* How large is their leverage (institution, position, reach)?
* Which brakes do they apply (duty of context, red zones, ceiling rules, dignity protection)?
* How do they handle their own structural over-power?

**D – dignity in practice of the analysts**

* How do they linguistically handle criticism, not-knowing, ambivalence?
* Is language kept dignified even in sharp analysis?
* Are affected persons not dehumanised, even when structures are criticised harshly?

**Mini-vignette:**  
A report on institutional violence works cleanly with A–C–R–P, but describes individual affected persons as “passive”, “stupid” or “toxically dependent”. Formally, the analysis is sound – but in the dignity-enactment (D) of the authors, a degradation of those affected appears. Here the model would not only read the institution, but also the **report itself** as an IA / D case.

Two basic principles:

1. **There is no analysis “from nowhere”.**  
   Every analysis is itself an enactment of A–C–R–P–D.

2. **Analysts become actors themselves.**  
   Their maturity in practice shows in *how* they use the model – and *what* they bring about with it.

**Interim conclusion for 3.4:**  
Self-implication does not make users “neutral observers”, but responsible actors. Whoever analyses always also displays their own maturity, their handling of power and their dignity in practice. In the next step (3.5), this insight is sharpened further: into a dedicated guardrail that anchors **protection of dignity** at the centre of the model.

---

### 3.5 Dignity protection guardrail (ontological vs. praxeological)

The dignity-in-practice module is the **most sensitive part** of the model.  
To ensure its use does not itself become practical degradation, it is placed under an explicit protection framework.

Core formula:

> **A human being remains dignified – even when they act in ways that lack dignity.**  
> Only dignity in practice is assessed (D₁/D₂ as praxeological forms of dignity in practice), never D₀ (ontological dignity).

---

#### 3.5.1 Principle: the human being remains dignified

* **D₀ – ontological dignity**
  – cannot be revoked  
  – non-gradual  
  – not “earnable”  
  – not measurable  
  – outside any analysis

* **D₁ – praxeological self-dignity in practice**  
  – self-relation, self-care, self-devaluation, self-protection  
  – operationally visible via **inner dignity (D-I)** and **bodily/material self-care (D-B)**

* **D₂ – relational dignity in practice**  
  – dealings with others, public sphere, roles  
  – operationally visible via **relational dignity (D-R)** and **public dignity / public dignity in practice (D-P)**

D₀ is an **axiom**.  
Every IA analysis presupposes D₀ and must never touch it.

Anyone who denies ontological dignity (“worthless”, “scum”, “subhuman”)  
does not strengthen the model but breaks it.  
That is a **dignity breach (D) on the part of the speaker**.

---

#### 3.5.2 D assessments only in practice, never in the value of the person

The following formulations are permitted:

* “In this scene, person X treats themselves in a way that lacks dignity.”
* “Over this trajectory, self-devaluation is visible (D₁ low).”
* “This structure invites people to self-degrade.”

The following are not permitted:

* “X is a person without dignity.”
* “This group has no dignity.”
* “This is what you are.” (global attribution)

Obligation:

* D statements must always be **situational**:
  role – context – point in time – enactment.

Formulation rule:

* permitted:  
  **“In this role / under these conditions …”**

* forbidden:  
  **“You are …”**

---

#### 3.5.3 Misuse as its own IA and D finding

If the dignity-in-practice module is used to:

* shame,
* discipline,
* exclude,
* legitimise power imbalances (“their own fault”),

then this use itself creates a form of inadult asymmetry.  
In such cases the model shows:

> **The dignity breach lies with those using the model – not with those being evaluated.**

D-language is itself dignity in practice.  
Anyone who uses it in a degrading way shows inadult asymmetry – regardless of the case.

Mnemonic:

> **D is a protection instrument – not a pillory.**

**Interim conclusion for 3.5:**  
The dignity protection guardrail is the core of the dignity-in-practice module: it anchors D₀ as untouchable, strictly limits D assessments to enactments, and treats misuse itself as an IA and D finding. On this basis, the following sections (3.6–3.7) clarify **when** D may be activated at all and **how** D findings can be communicated without themselves violating dignity.

---

### 3.6 D as an optional module

The preceding sections have shown how sensitive the dignity-in-practice module is and how strongly it reacts to language, context and stance. To prevent it from becoming a covert tool of moralising or disciplining, it needs a clear place in the overall model: **D is not a mandatory parameter**, but an optional layer that may only be activated under specific conditions. This chapter therefore clarifies how D stays “off” by default, and in which exceptional cases a deliberate “D-on” mode is meaningful and responsible.

The basic model works with **A–C–R–P**  
(plus A-score, M-score, IA box, T–J–TB–R).  
The dignity-in-practice module (D) is an **additional layer** that requires *particular care*.

---

#### 3.6.1 Default setting: D off

Standard mode of any analysis:

* focus on roles, responsibility, power, context
* parametrisation via A–C–R–P
* structural and trajectory analysis
* T–J–TB–R for functional vs. inadult asymmetries
* where applicable, M-score / A-score / IA box

D remains in the background as something that is **kept in mind**, but is not:

* explicitly rastered,
* communicated,
* used as a comment on persons.

Why?

> **D requires a high level of maturity in practice on the side of the analysts.**  
> It is therefore activated only in a targeted way.

---

#### 3.6.2 When D may be activated

If D is exceptionally “switched on”, a clear reason is required. Activation must never happen casually; it is itself a decisive procedural choice.

Four minimal conditions:

1. **Clear purpose**  
   – self-clarification  
   – supervision / coaching  
   – structural critique (“Which enactments does this system invite?”)  
   – not: disciplining, evaluation, HR, diagnostics

2. **Safe framework**  
   – confidential or professionally guided  
   – roles clarified  
   – no sanction pressure  
   – no public sphere

3. **Minimal adulthood of users**  
   – acknowledging their own D readings and mistakes  
   – willingness to revise  
   – no hunt for enemies or culprits  
   – clear separation D₀ ↔ D₁/D₂

4. **Minimal adulthood of those affected**  
   – no use with unstable self-relations, crises, dependency in hierarchies  
   – exception: careful, accompanied self-reflection

**Mini-vignette:**  
A person in a leadership role uses the model in coaching to understand why they so often make themselves small in conflicts. Here, D₁ (self-dignity in practice) can be cautiously rastered. Using the same raster in employee reviews to “sort” team members would be a clear misuse.

---

#### 3.6.3 Red zones for D

*(no humiliation diagnostics, no pillory)*

D is **strictly forbidden** in:

* clinical diagnostics and treatment planning
* HR decisions (recruitment, dismissal, assessments)
* child and youth diagnostics
* forensics, criminal justice, security agencies
* public debates about identifiable individuals
* dependent power relations where it would be used to evaluate those in weaker positions
* online pillory formats, doxing, cancel / shitstorm dynamics

Permitted:  
**D for self-reflection of those in power** (“How dignified is our use of power?”).

Forbidden:  
**D for classifying those with less power.**

---

#### 3.6.4 Documentation duty: marking the use of D

Where the dignity-in-practice module is activated, this must be **transparently documented**:

1. **D activated: yes/no**, and if yes:
   – self-related D (D₁ – self-dignity in practice, operationally via inner dignity **D-I** and bodily/material self-care **D-B**)  
   – structural D (degrading conditions that make dignity in practice harder)  
   – relational D (D₂ – relational dignity in practice, operationally via relational dignity **D-R** and public dignity in practice **D-P**)

2. **Purpose of using D**  
   – self-clarification, team reflection, structural critique

3. **Risk note**  
   – possible misreadings  
   – power imbalances  
   – risk of shaming or pillory effects

D must never run “silently in the background”.  
It has to be treated as a **deliberate mode**.

**Interim conclusion for 3.6:**  
D is not a standard parameter, but a high-risk instrument with high insight potential. As long as it is unclear whether purpose, framework and minimal adulthood are fulfilled, D remains **off** in the default mode. Only when these criteria are explicitly met and documented can it be applied – limited, deliberate and recorded. In the next step (3.7) the focus is on how D findings can be communicated at all, without themselves producing new dignity breaches.

---

### 3.7 Publicity & communication of D findings

D findings are powerful:  
They say something about a person’s relationship to themselves (D₁ – self-dignity in practice)  
and to the world (D₂ – relational dignity in practice).  
For this reason, communication is especially sensitive.  
A single careless formulation can turn a careful analysis into a practice of humiliation.

Basic rule:

> **Talk about D primarily with people – not about them.**  
> And if one must talk about them, then structurally, anonymised, situationally.

---

#### 3.7.1 Differentiating communication spaces

Three spaces with different conditions:

---

##### 1) Self-related space

*(journaling, self-reflection, coaching)*

Permitted:

* D findings for one’s own orientation
* recognising one’s own patterns (self-devaluation, compliance, protest, refusal)
* dignity in practice as a mirror of one’s life enactment

Typical questions:

* “Where do I degrade myself (D₁ low)?”
* “Where does my protest mirror degrading conditions (D₂)?”

---

##### 2) Professionally confidential space

*(supervision, intervision, professional discussions)*

Here, D can be used for:

* structural critique
* pattern recognition in teams / institutions
* situational, anonymised case work

Rules:

* no identifiable individuals
* no global labels
* D profiles only in relation to context
* focus on protection, options, structural improvement

---

##### 3) Public space

*(media, talks, publications, politics)*

D findings about real individuals are **excluded**.  
Only allowed:

* **anonymised case vignettes**,
* **structural analyses** (“This practice invites self-degradation”),
* **public critique of context**, not evaluation of persons.

Basic principle:

> Public sphere = highest requirements for public/media awareness (A-P),  
> public agency (P-PU) and public dignity in practice (D-P).  
> Maximum restraint applies here.

---

#### 3.7.2 Forms of D communication

The dignity protection logic from 3.5–3.7 translates into three different forms of communication, depending on **who is present**, **what power relations apply** and **which space** is being used.

---

##### A) Direct D communication (with those affected)

Basic principle: **I-form, reversibility, co-interpretation.**

Examples:

* “I notice that in these situations you are very harsh with yourself.”
* “Here it seems as if you are making yourself smaller than you are.”

Emphasise reversibility:

* “This is not a label but a current reading that can change.”

Offer joint review:

* “How would you describe this yourself? Does this resonate with you?”

Rules:

* Clear context reference (role, time, scene).
* No identity statements (“You are …”).
* Emphasis on possibilities, not deficits.
* Goal: to **strengthen** dignity in practice, not restrict it.

---

##### B) Professionally indirect D communication (about those absent)

Use: structural and practice reflection in supervision, intervision, professional talks.

Rules:

* situational and anonymised,
* focus on **conditions**, not character,
* clear separation between **D₁ (self-enactment / self-dignity in practice)** and **D₂ (reactive relational enactment / relational dignity in practice)**.

Examples:

* “In this role, person X had hardly any opportunities for a dignified self-enactment (D₁).”
* “This structure encourages relationally degrading patterns (D₂).”
* “The setting makes it difficult to take oneself seriously.”

---

##### C) Public / political / media D communication

Strict boundary: **No D attributions to identifiable individuals.**

Permitted:

* anonymised case vignettes,
* structural critique:

  * “This practice degrades people.”
  * “This system pushes entire groups into patterns of self-devaluation.”

Not permitted:

* diagnostics by the public,
* “lacking dignity” labels applied to real individuals,
* speculative attributions about D₁/D₂ of other people.

Basic principle:

> Apply D publicly **only** to structures – never to individuals.

---

#### 3.7.3 Language rules for D findings

Goal: avoid degrading language, emphasise reversibility, make context visible.

Helps for rephrasing:

* Instead of “X has lost their dignity”:

  → “In this situation, dignity in practice (D₁/D₂) was hardly livable.”

* Instead of “They live without dignity”:

  → “The conditions make a dignified enactment extremely difficult.”

* Instead of “They do not respect themselves”:

  → “Many options for a dignified way of dealing with oneself are not visible in this structure.”

Rules:

* Duty of context: always name role, situation, timeframe.
* No ontological judgements (“undignified”, “worthless”).
* Reversibility in language: enactments can change.
* No transition from observation → identity.

---

#### 3.7.4 D findings under power asymmetries

In strongly asymmetric roles (management/staff, professionals/clients, politics/base) the following applies:

> **The greater the power asymmetry, the more cautious and structure-focused D language must be.**

Consequences:

* No attributions about “staff/clients without dignity”.

* Instead:

  * “Working conditions make dignified self-enactment (D₁) difficult.”
  * “This structure generates relationally degrading patterns (D₂).”

* If this rule is violated, a **double inadult asymmetry** arises:

  1. inadult asymmetry in the field (degrading structures),
  2. inadult asymmetry in interpretation (degrading language by those with power).

Key point:

* Micro-humiliations, subtle shaming, covert devaluation count as D₂ risks.
* Communicative power is itself a D enactment (D₂ of the speakers).

---

**Conclusion of chapter 3 – what remains?**

Chapter 3 shifts the focus from *can* to *may*: it is not enough to analyse maturity, power and dignity-enactments precisely – what matters is **how responsibly** the model is used. Minimal adulthood, procedural guardrails, self-implication and protection of dignity together form the safety framework without which any IA or D analysis is praxeologically void. Those who take these guardrails seriously do not use the framework as a moral machine, but as a tool to make structures fairer, enactments more mature and dignity in everyday life **more visible and better protected**.

---

## 4) Functional vs. inadult – the four-criteria box

The previous chapters have shown **how** people act: along awareness (A), coherence (C), responsibility (R), power (P) and dignity in practice (D). What they have not yet answered is: **When** are unequal distributions of these parameters useful – and when do they tip into inadult asymmetry (IA)? In practice this is exactly where the conflict lies: is a tough decision, an unequal distribution of knowledge or power still functional – or already abuse?

Asymmetries are everywhere. What matters is:

> **Are they functional – or inadult by design?**

The four-criteria box (T–J–TB–R) is the core instrument  
for classifying any asymmetry along awareness, coherence, responsibility, power and dignity in practice.  
It translates the abstract A–C–R–P–D framework into four simple, testable questions.

Once we know roles, enactments, A–C–R–P and modulators,  
we need a tool to **evaluate asymmetric situations concretely**.  
The four-criteria box is the heart of this diagnostic.

---

### 4.1 Four-criteria box for asymmetries (T–J–TB–R)

Every asymmetry is examined through four questions:

1. **Transparent?**
2. **Justified?**
3. **Time-bound?**
4. **Reversible?**

Together they form a compact raster that can be applied in very different fields – from team conflicts to political power relations.

**Mini-vignette:**  
A boss is the only one who sees the full financial situation and decides on overtime.  
This asymmetry is functional if she clearly communicates why she needs which information, when the team will gain insight and how decisions can be reviewed.  
It becomes inadult when no one understands why she decides as she does, the situation never ends and criticism is practically impossible.

---

#### 1) Transparent?

Guiding question:

> **Who knows what – and who could realistically know it?**

Transparency is present when:

* rules, responsibilities and decision paths are named,
* relevant circles can understand why an asymmetrical distribution exists,
* there are no “secret zones” or informal power channels.

IA signals:

* vague phrases (“That’s just how it is”),
* rules known only to insiders,
* deliberately obfuscated decision logics.

D-specific:

* degrading practices that run covertly → automatically intransparent → IA-suspect,
* self-devaluation (D₁ – self-dignity in practice / enacted self-dignity) can itself be intransparent when it has been normalised,
* micro-humiliations are by definition intransparent and D₂-relevant (relational dignity in practice / enacted relational dignity).

---

#### 2) Justified?

Guiding question:

> **Does the asymmetry serve a testable purpose – or only the advantage of one side?**

An asymmetry is justified when:

* its purpose is clearly named (protection, organisation, training, risk minimisation),
* it is understandable why this purpose makes an unequal distribution necessary,
* the reasons are **open to discussion and reviewable**.

Not justified:

* pure status or tradition arguments,
* asymmetries to the advantage of one side with no protected good,
* “toughening people up” through humiliation or shaming.

D-specific:

* protective asymmetry (e.g. in care, education) is justified when it protects dignity,
* degrading asymmetries are by definition unjustified or only seemingly justified.

---

#### 3) Time-bound?

Guiding question:

> **Is this asymmetry limited in time or by conditions?**

Time-bound means:

* purpose and duration are clear,
* there are review points,
* there is a willingness to adjust.

Not time-bound:

* “This will stay like this from now on,”
* emergency rules that never disappear again,
* silent extensions of special rights.

D-specific:

* temporary restrictions of autonomy can be sensitive to dignity (clear purpose, clear framework),
* endless patterns of degradation count as non-time-bound IA.

---

#### 4) Reversible?

Guiding question:

> **Are there real ways back – or only theoretical ones?**

Reversible:

* real possibilities for correction,
* mechanisms for rescinding decisions,
* pathways that can be used without extreme costs.

Irreversible:

* in practice no way back (dependency, stigma, inescapable power relations),
* pathways exist only on paper, not in reality.

D-specific:

* **D₀ (ontological dignity) is always intact.**
* D₁ and D₂ as dignity in practice are **always** reversible – people can act differently.
* Structural IA is present when real pathways to a more dignified enactment are blocked.

---

#### Functional vs. inadult – in combination

**Functional asymmetry** when T–J–TB–R is fulfilled:

* transparent,
* justified,
* time-bound,
* reversible,
* protected good clearly named,
* D₀ respected, D₁/D₂ enabled.

**Inadult asymmetry (IA)** when at least two criteria fail:

* intransparent,
* unjustified or only seemingly justified,
* unbounded,
* irreversible.

Particularly critical:

* when people are systematically brought **below their dignity**,
* when groups are treated as “less dignified,”
* when degrading structures and degrading language interact (double IA).

---

#### Anchoring in A–C–R–P–D

Each T–J–TB–R criterion links back to the five axes:

* **T ↔ A (awareness)** – What is visible?
* **J ↔ C (coherence)** – Is the asymmetry logical and understandable?
* **TB ↔ R (responsibility)** – Who pays attention to time, duration and corrections?
* **R ↔ P (power / power to act)** – Are there real pathways to reversal?

And across all of this:

* **D – dignity in practice** – sensitivity to dignity in justification, duration, implementation and possibilities for correction.

The four-criteria box translates the model’s abstract dimensions  
into four precise questions that can be posed **operationally** in any analysis.  
To prevent T–J–TB–R itself from becoming a source of misreadings, it must first be clear **who** is acting in which role – this is exactly where 4.2 begins.

---

### 4.2 Role and context logic

Before an asymmetry can be meaningfully run through the four-criteria box at all, it must be clarified:

> **Who is playing which role – in which context – and who is observing from which role?**

Without this clarification, the analysis itself produces role confusion and phantom intention – precisely the IA patterns the model aims to make visible.

---

#### 4.2.1 Clarifying the role of the object of observation

The “object of observation” (A) can be many things:

* a single person,
* a team / a relationship / a committee,
* an institution or organisation,
* a procedure, a rule, a discourse, a narrative.

For A, the following must be determined in advance:

1. **What function does A have in the situation?**

   * a **responsibility-giving** role  
     (leadership, office, decision-maker),
   * an **addressed** role  
     (those affected, employees, learners, clients),
   * a **mediating** role  
     (facilitation, supervision, oversight, counselling).

2. **In what public sphere is A acting?**

   * private · semi-public · institutional · public · media-amplified,
   * how high is the **public agency (P-PU)**,
   * how high should **public/media awareness (A-P)** realistically be.

3. **What structural asymmetry is built into the role by design?**

   * knowledge advantage (information, expertise),
   * decision-making power (access to resources, sanctions),
   * protective function (mandate to represent or protect others),
   * **dignity mandate** (care, education, justice system, pastoral care),  
     where other people’s dignity is explicitly entrusted.

This clarification is **explicit framework setting**, not prejudice:  
without it, it remains unclear which asymmetries are present by design and which represent inadult deviations.

**Mini-vignette:**  
A teacher has, by role, power over grades, access and evaluations.  
Only once it is clear whether they are currently acting as a pedagogical professional, as a private person or as a public authority can we judge whether a sharp reprimand is a functional asymmetry – or degrading IA.

---

#### 4.2.2 Clarifying the role of observers

Equally important:

> **From which role is the analysis being conducted – with what power and what risk?**

“Observers” (B) can be:

* researchers,
* consultants / facilitators,
* internal decision-makers,
* the public / media,
* those affected themselves (self-application).

Before any analysis we need to clarify:

1. **What function does B have in relation to A?**

   * neutrally examining,
   * involved and taking sides,
   * themselves part of the structure?

2. **What power and protection asymmetries exist between B and A?**

   * influence on decisions, reputation, sanctions,
   * their own status- or institution-protection,
   * risk of damaging dignity in practice through language  
     (public shaming, labelling, stigmatisation).

3. **How explicitly are roles named?**

   * does A know that it is being analysed?
   * does A know with what consequences?
   * is it clear that the model **does not evaluate personal dignity**  
     (D₀ – ontological dignity – remains off-limits)?

Risks without role clarification:

* the model is used as a **weapon from above**,
* hidden interests are wrapped in “analysis,”
* observers elevate themselves through degrading D readings.

---

#### 4.2.3 Role awareness (A-R) as the start button

Both sides – A and B – need a minimum level of **role awareness (A-R)**:

* A understands:

  * in which role it is being evaluated,
  * which expectations are linked to that,
  * how its **dignity enactments** (self-treatment, protest, adaptation)
    can be read as D₁/D₂ (self-dignity in practice and relational dignity in practice).

* B understands:

  * that every analysis is **self-implication**
    (their own standards, blind spots, power position, their own D practice),
  * that analysis itself creates an **asymmetry**,
  * that they must be measured against their own dignity practice.

Only then is the path clear for:

* the four-criteria box,
* role confusion & phantom intention (4.3),
* later checklists (7.6).

**Short formula:**

> **Without role clarification, every IA analysis itself is IA-suspect –  
> every D finding itself at risk of violating dignity.**

This sets the stage for 4.3:  
there the typical distortions that arise when roles are not clearly defined are described – and how they can be recognised as IA patterns.

---

### 4.3 Role confusion & phantom intention

Roles are **switching points of social reality**:  
they define who, in which function, is speaking, acting, deciding, protecting, evaluating.

**Role confusion** is present when role awareness (A-R) is low:

* one’s own role is unclear (“What am I here, actually?”),
* the role attributed by others is unclear,
* the role of the counterpart is unclear or constantly changing,
* nobody names explicitly *in which function* they are acting or speaking.

This creates a **role vacuum**,  
filled by expectations, fears, stories.

Mechanics of role confusion:

1. **Projection space**  
   Roles are constructed from needs, fears, prior experiences.

2. **Multiple projection**  
   the same person is simultaneously read into contradictory roles  
   (friend, adversary, rescuer, victim, provocation …).

3. **Action conflict**  
   unclear whether to lead, follow, withdraw;  
   unclear responsibility status.

4. **Responsibility breakdown**  
   over-responsibility or under-responsibility;  
   R states become chaotic, legitimate decision powers unclear.

5. **Context smearing**  
   private/professional/public expectations blur;  
   social and power-related coherence levels (C-S/C-P) collapse, signals wander between contexts.

Consequence:

> Where roles are unclear, **phantom intentions** arise.

**Phantom intentions**:

* attributed intentions,
* not named,
* not clearly derivable from any single action,
* yet felt as “certain” (“They *obviously* want to …”).

Consequences:

* neutral actions read as attack/flirt/test/devaluation,
* withdrawal read as punishment,
* questions read as distrust,
* massive conflicts with no clear objective trigger.

**Mini-vignette:**  
Anna is a team leader and former colleague. Sometimes she speaks “at eye level,” sometimes as superior, without signalling the shift. A spontaneous suggestion is understood by one team member as a friendly idea, by another as a semi-official instruction. From the same sentence, two completely different lines of conflict arise through phantom intentions – not because Anna is “wrong,” but because the role logic remains unclear.

In A–C–R–P terms:

* low **role awareness (A-R)** → confusion over who is what,
* collapsing **coherence (C)** → missing anchors of meaning,
* diffuse **responsibility (R)** → breakdown of responsibility,
* distorted **power (P)** → helplessness or overreach.

Role confusion generates:

1. **Enactment asymmetry** (who decides / who carries burdens?),
2. **Interpretation asymmetry** (who determines meaning?).

This is where the model becomes particularly sharp:

> Many apparent “character conflicts” turn out to be role and context conflicts.

It shifts the focus from “What is this person like?” to:  
“In which role – in which framework – are we actually acting and interpreting here?”

The next step is to understand how meanings **systematically shift** when roles and contexts are not shared – this is the task of 4.4.

---

### 4.4 Semantic drift & D asymmetries: same action, different meaning

Actions and language get their meaning **not in isolation**, but through the interplay of:

* role,
* context,
* relationship,
* power relations.

In the model, **semantic drift** means:

> the systematic shift of meanings  
> when roles and contexts are not shared.

This affects not only “What is meant?”, but also:

* **how dignified / undignified** an enactment is read,
* **whether** a behaviour is understood as self-degradation
  or as a mirror of a degrading structure.

---

#### 4.4.1 Semantic drift (basic mechanics)

Same action – different roles → different meaning:

* a compliment from a superior  
  – appreciation? control? signal of expectation?
* the same compliment from colleagues  
  – solidarity? collegial appreciation?
* the same compliment from an uninvolved person  
  – politeness? small talk? distant recognition?

Or:

* **silence**
  – as a leader → threat? testing? indifference?  
  – as a friend → overwhelm? thinking? withdrawal?  
  – as a stranger → no relation, no assignment.

Stable role awareness (A-R) and a sound coherence situation (C) → readable nuances.  
Low A-R or fragile coherence (C) → drift, competing interpretations, phantom intentions.

Semantic drift intensifies:

* **phantom intentions** (“If you are silent in *this* role, you *must* mean something specific.”),
* **vulnerability** (“What if all of this was meant completely differently?”),
* **IA via interpretive power** (whoever controls the interpretation controls meaning).

In practice:

* explicit clarification of role and context,
* before far-reaching conclusions are drawn from individual sentences or gestures.

---

#### 4.4.2 D and asymmetries: self-degradation vs. societal degradation

With the dignity-in-practice module, the question shifts:

> **“What does this action mean?”**  
> also to  
> **“To whom is dignity being granted here – and to whom is it being denied?”**

Final three-part structure (consistent notation):

* **D₀ – ontological dignity**  
  unrevocable value of the person, non-negotiable, not part of the assessment.

* **D₁ – self-dignity in practice (enacted self-dignity)**  
  how someone treats themselves (D-I/D-B):  
  self-care, self-neglect, self-devaluation, self-protection.

* **D₂ – relational dignity in practice (enacted relational dignity)**  
  how someone, in practice, expresses their relationship to the environment (D-R/D-P):  
  adaptation, protest, refusal, mirroring.

Semantic drift arises here when observers:

* read a behaviour as **self-degradation** (“They have no self-worth”),
* although, praxeologically, it could also – or primarily – be read as **feedback to the outside world**:

  * neglect as protest  
    (“Your system does not deserve my effort”),
  * “living like trash” as a mirror of degrading treatment,
  * adapting downward in degrading environments  
    (“Everyone is like this here, why should I aim higher?”).

Axes of drift:

* **internal reading vs. external reading**

  * internal reading:  
    “This person does not value themselves” → D₁ low.
  * external reading:  
    “This person holds little of their environment / mirrors its degradation” → D₂ active.

* **deficit reading vs. protest reading**

  * deficit reading: “There is a lack of inner maturity / self-respect.”
  * protest reading: “A degrading structure is being mirrored or refused.”

The model forces a distinction here:

> When I perceive an apparent “lack of dignity,” am I reading it as an **inner defect** (D₁) –  
> or as a **relational response** to an environment that itself acts in degrading ways (D₂),  
> while D₀ – ontological dignity – remains untouched at all times?

---

#### 4.4.3 Structural IA through faulty dignity-interpretation

Semantic drift becomes especially critical when the **more powerful** define  
what is to count as “dignified” or “undignified.”

Structural IA emerges, among other things, when:

1. **D₁ and D₀ are confused**

   * “undignified enactment” (low D₁/D₂) is turned into: “undignified person,”  
   * → ontological dignity is denied (D₀ – ontological dignity – is contested; red zone).

2. **D₂ (relational dignity in practice) is ignored**

   * protest or mirroring behaviour is read as “character weakness,”  
   * rather than as an indicator of degrading structures  
     (living conditions, environment, discrimination, poverty, exclusion).

3. **Interpretive authority is asymmetrical**

   * whoever controls media, politics, organisations, discourses  
     defines what counts as “normal,” “respectable,” “dignified,”
   * groups with low public/media awareness (A-P) or low public agency (P-PU)  
     are reduced to their visible D-breaks (D₁/D₂),  
     while structural degradation remains invisible.

Semantic drift + faulty dignity interpretation generate:

* **secondary IA**  
  – those affected are hit twice:  
    by degrading structures **and** by interpretations claiming  
    their reaction says something about their personal worth.

* **stigma solidification**  
  – “That’s just how they are” replaces the question:  
    “Which options, resources and alternatives do they actually have?”

The praxeological counter-move:

* make dignity-readings **explicit**  
  (“I am currently reading this behaviour as …”),
* describe dignity **in enactment** (D₁/D₂, scene-bound, role- and context-dependent),
* **precede** this with structural questions:

  * Which asymmetries (C-P as coherence in power contexts, P-S as social agency, R-S as social responsibility) frame this dignity enactment?  
  * Where might an apparent act of self-degradation  
    actually be mirroring or protest?

In this way, the model protects against IA in which the interpretation by the powerful  
of what is “dignified” itself becomes a degrading structure.

To ensure these distinctions do not remain theoretical but become workable in everyday practice,  
a small, robust practical tool is required – precisely what the role-check in 4.5 provides.

---

### 4.5 Practical micro-tool: the role check

To detect role confusion and semantic drift early in everyday situations,  
a small tool is often enough when applied consistently:

> **Three questions before I interpret.**

**Question 1: Which role am I currently assuming for myself?**

* In which function am I speaking or acting?  
  – private, professional, friendly, as representative, as decision-maker, as affected person?
* Is this role **clear** to the other side – or only to me?

**Question 2: Which role is the other side likely assigning to me?**

* How might the other side think of who I am?  
  – supporter, controller, rival, authority, petitioner, examinee …
* Are there signs that this assignment does **not** match my self-perception?

**Question 3: Which role am I assigning to the other person?**

* In which role am I reading them?  
  – partner, adversary, evaluating authority, protective figure, petitioner, “the institution,” “the crowd” …
* Have I ever **checked** this assignment – or is it historical / projected?

**Mini-vignette:**  
An employee writes their manager: “I don’t understand the decision.”  
If the manager reads them as a petitioner, the reply may be explanatory.  
If the manager reads them as a rival, the reply may be defensive or punitive.  
A brief role check (“Is he speaking as someone insecure, as a critic, as someone hurt?”)  
can prevent escalation before any content is addressed.

**Application:**

* As soon as uncertainty appears for **any** of the three questions:  
  – **role vacuum detected.**  
  – high risk of phantom intentions and semantic drift.
* In that case, a **minimal clarification** is advisable, e.g.:

  * explicit role naming (“I am speaking now as …”),
  * asking (“In which role do you see me here?”),
  * context marking (“I’m responding to you now as …, not as …”).

The micro-tool is intentionally **low-threshold**:

* requires no scores,
* no complex analysis,
* only three quickly answerable questions.

Within the logic of the model, however, it is central:

> Whoever takes these three questions seriously  
> increases A-R (role awareness), stabilises C (coherence),  
> and reduces the risk of inadult asymmetries –  
> before they escalate.

Thus Chapter 4 bridges theory and practice:  
asymmetries become examinable with T–J–TB–R,  
roles and meanings become clarifyable,  
and with the role check there is a concrete tool for everyday use.  
**Chapter 5** then further operationalises this structure:  
there the A-score renders developmental maturity measurable –  
without sliding into moral labelling.

---

## 5) Measuring maturity in practice – without moral rhetoric

In many debates, maturity is either invoked morally (“People should simply act like adults”)  
or interpreted psychologically (“X is just like that”). Neither helps much when we need to examine  
**concrete enactments**: what was done, when, with what knowledge, in which role –  
and what realistically could have been done differently?  
This chapter introduces the A-score as an attempt to make maturity **praxeological** and **situational** –  
without becoming a backdoor to character judgment.

The A-score tries to make something essentially qualitative **operational**:  
How adult, how responsible, how coherent is the enactment in a **specific situation**?

Important:

* The A-score describes **enactment**, not “essence.”  
* It is assigned to **cases / situations / structures**, not to “souls.”  
* It is a **working value**, not a moral verdict.

Thus “X is immature” becomes a different question:

> **“How mature was the enactment here – under these conditions –  
> and how could the same actor behave more maturely under changed conditions?”**

---

### 5.1 A-score (0–10) – dimensions & micro-indicators

Once it is clear that the A-score describes maturity in practice rather than personal worth,  
we need a finer resolution: **What** exactly goes into the score – and **how** is it formed?

---

#### 5.1.1 What the A-score measures – and what it does not

The A-score answers a strictly limited question:

> **“How mature was the enactment – under these conditions, with this knowledge, in this role?”**

It does **not** measure:

* “How good is a person?”
* “How valuable is someone?”
* “How much love / pain / biography is behind this?”

It summarises:

* how **awareness (A)** was actually used,
* how **coherence (C)** between words, decisions and actions looks,
* how **responsibility (R)** was taken or shifted,
* how **power / power to act (P)** was used or withheld.

The score always refers to:

* a **time period** or **episode**,  
* a **role** (e.g. office, function, relational role),  
* a **context** (private, institutional, public, media).

Anything else would be a category error.

**Mini-vignette:**  
A hospital management must decide on staff cuts under cost pressure.  
The A-score does not ask: “Are they good people?”  
but: “How consciously were consequences assessed (A)?  
How coherent were statements and decisions (C)?  
Who carried which burdens (R)?  
Which real alternatives were explored or dismissed (P)?”

---

#### 5.1.2 Dimensions of the A-score

Practically, the A-score can be read along the four main axes:

> **A(A) · A(C) · A(R) · A(P)**  
> (maturity of awareness, coherence, responsibility, and action/power)

They can be considered separately and then integrated –  
or directly estimated as one combined score.  
What matters is that the underlying **micro-indicators** are checked.

---

##### A(A) – maturity of awareness

**High A-A**, when for example:

* relevant information is **actively gathered**,  
* obvious signals are not suppressed, but taken seriously,  
* one’s own role is seen and named (“I am speaking here as …”),  
* side effects for affected people are at least **considered**,  
* adaptation occurs when new information emerges (“I was wrong; I correct …”).

**Low A-A**, when for example:

* one **does not want to know** what is obvious (“better not look too closely”),  
* warning signs are systematically ignored,  
* role and leverage are downplayed (“I’m just …” despite high power),  
* learning opportunities are rejected.

---

##### A(C) – maturity of coherence

**High A(C)**, when for example:

* words, commitments and decisions **match** later actions,  
* justifications are consistent (no constant retrofitted storytelling),  
* tensions are openly marked (“We have a goal conflict here …”),  
* corrections are not hidden but **transparent** (“We are changing course because …”).

**Low A(C)**, when for example:

* “A” is repeatedly said and “¬A” enacted,  
* justifications are retrofitted,  
* responsibility is taken linguistically but refused in action,  
* roles are switched without signalling.

---

##### A(R) – maturity of responsibility

**High A(R)**, when for example:

* someone **names** their part – and acts accordingly,  
* burdens are not systematically shifted downward,  
* affected persons are not made invisible,  
* successes **and** harms are addressed (“This is on us”).

**Low A(R)**, when for example:

* responsibility is shifted upward / downward / outward (“Everyone but us”),  
* structural responsibility gaps exist (“No one is in charge”),  
* costs are deliberately shifted to the weaker side,  
* one hides behind formulas, processes, committees.

---

##### A(P) – maturity of action / power to act

**High A(P)**, when for example:

* real agency is **used** – intervening, limiting, stopping, leaving, escalating *or* de-escalating,  
* impossible demands are not cynically placed (“You should have just …”),  
* one correctly assesses their leverage  
  (“We *can* intervene here – so we will / or consciously won’t”),  
* visible attempts are made to improve the situation – even at risk.

**Low A(P)**, when for example:

* one pretends to be powerless despite having leverage,  
* options are only used when they are **cost-free**,  
* “it’s impossible” is used where “it would be uncomfortable” is meant,  
* one understates or overstates their influence.

---

#### 5.1.3 Calibration band 0–10

The A-score is not a device with decimal precision.  
It works with **bands**, not exactness.

At the same time – consistent with the D module:

> **The A-score describes maturity in practice – never the worth or dignity of a person.**  
> Ontological dignity (D₀) remains untouched;  
> dignity in practice (D₁/D₂) is described separately in the **D-profile** (see 5.3),  
> operationalised through D-I, D-B, D-R, D-P.

A useful heuristic:

* **0–1: collapse zone**  
  – virtually no maturity in enactment,  
  – severe breakdown across multiple axes (A, C, R, P),  
  – IA extreme, protection goods heavily violated,  
  – typical: breakdown moments, destructive patterns, collapse of self-/other-care.  
  → Often accompanied by deep disruptions in dignity enactment (self-devaluation, degrading others) – **without** ever touching D₀.

* **2–3: clearly inadult enactment**  
  – isolated adult elements may be present,  
  – but overall: denial, incoherence, evasion of responsibility, misuse or refusal of power,  
  – no admission or correction attempts (or only rhetorical),  
  – dignity enactments often **inconsistent**: some self-care, then self-/other degradation.

* **4–5: everyday mixed zone**  
  – mixed patterns: some adult, some inadult,  
  – visible striving for maturity but with blind spots,  
  – typical tension fields,  
  – many real systems land here,  
  – dignity enactment often **oscillates**:
    episodes of self-respect, then downward adaptations (e.g. self-neglect under stress).

* **6–7: solid adultness**  
  – baseline of adult action,  
  – errors occur but are named and worked through,  
  – A–C–R–P reasonably aligned,  
  – stable under pressure,  
  – dignity enactment mostly consistent: self-respect and respectful treatment of others.

* **8–9: high adultness under severity**  
  – complex situations handled with clarity, responsibility and courage,  
  – power and fallibility handled maturely,  
  – rare; appears where learning loops are actively used,  
  – dignity enactment is typically **high**, even in conflict.

* **10: reference point / ideal**  
  – almost never a real case score,  
  – functions as **orientation**:  
    “What would maximally mature enactment look like here *in theory*?”  
  – in D terms: orientation, not a yardstick for shaming.

Important:

> A high A-score is **not an honour**;  
> a low A-score is **not a condemnation** – and **not a dignity claim**.

It is a **signal** of where the system stands –  
and what kind of intervention may help  
(increasing awareness, clarifying roles, redistributing responsibility,  
creating agency, making dignity enactments more conscious).

---

#### 5.1.4 Procedure: from profile to score

Practical steps:

1. **Create a structural profile**  
   – go through A–C–R–P,  
   – consider modulators (context, stress, publicity, dependencies),  
   – clarify roles of object of observation (A) and observers (B),  
   – note where **dignity enactment** (D₁/D₂) is relevant –  
     but do **not** smuggle D into the A-score  
     (D is handled in the D-profile, section 5.3).

2. **Check micro-indicators**  
   – for each axis, note observations indicating higher, medium or lower maturity,  
   – distinguish:  
     *“How was the enactment performed?”* (A-score) vs.  
     *“How was dignity handled?”* (D₁/D₂; D-profile).

3. **Determine the band**  
   – is the situation more like 2–3, 4–5, 6–7 …?  
   – better leave uncertainty explicit (“4–6”) than fake precision (“5.3”).

4. **Set the score – with reasoning**  
   – record the A-score,  
   – briefly justify why this band was chosen,  
   – explicitly separate observations on maturity (A–C–R–P)  
     from those on dignity enactment (D₁/D₂).

5. **Mark revision readiness**  
   – note conditions under which the score might change  
     (new information, other perspectives, time).

**Mini-vignette:**  
A project team evaluates its crisis communication before and after a scandal.  
First time: A-score 3–4 (late reaction, defensiveness, little ownership).  
Second time: 5–6 (early transparency, named errors, visible consequences).  
The scores do not say “We are good people now,” but:  
“Our enactment became more mature – and our dignity enactment (D₁/D₂) became more conscious.”

Thus the A-score remains a **clarification tool**,  
not an authoritative judgment – and not hidden dignity evaluation.

---

### 5.2 Trajectories instead of labels

Once the A-score is introduced as a snapshot,  
the next question is:  
**“How do we handle time?”** – learning, relapse, context shift.

A single A-score is like a **photo**:  
it captures a moment, not movement.

Maturity in practice, however, is:

* learnable,  
* context-dependent,  
* developmental.

The same applies to dignity in practice (D₁/D₂):  
People can learn to handle themselves and others **more dignifyingly** –  
regardless of how chaotic individual episodes look.

Hence the model prefers **trajectories** over labels.

---

#### 5.2.1 A-score as snapshot

Each score applies only to:

* this situation,  
* this setting,  
* this time.

When revisited later, the score may:

* rise,  
* fall,  
* oscillate.

What matters is not being “good” or “bad” once,  
but **how the line develops**.

Similarly, dignity enactments (self-care, self-devaluation, degrading others, etc.)  
can show development – captured in the **D-profile** (section 5.3),  
not in the A-score.

---

#### 5.2.2 Development lines (trajectories)

Typical trajectories visible in the model:

* **ascending line**  
  – low values grow into more mature practice via learning, correction, role clarification, reallocation of responsibility,  
  – errors become material for development,  
  – dignity enactments stabilise (less self-/other-degradation, more consistent self-respect).

* **descending line**  
  – initially solid maturity breaks under pressure, overload, power increase,  
  – IA grows, transparency and responsibility shrink,  
  – dignity enactment: more cynicism, shaming, self-neglect.

* **zigzag line**  
  – strong fluctuations depending on context, relationship, topic, audience,  
  – often indicates role confusion or structural tensions,  
  – dignity enactment oscillates: phases of self-care, then crashes.

* **plateau line**  
  – stable mid-range (e.g. 4–5),  
  – stagnation: “We’re not progressing,”  
  – dignity enactment: habitual narratives (“that’s just who I am”) blocking development.

Key questions:

> **“How has maturity in practice changed over time – and why?”**  
> **“How has dignity enactment (D₁/D₂) changed over time?”**

---

#### 5.2.3 Why trajectories are more mature than labels

Labels (“X is immature,” “Y is exemplary”) freeze people and systems  
and threaten **D₀**, by conflating persons with scores.

Trajectories:

* allow errors without total condemnation,  
* make **learning** visible,  
* show structural blockages and tipping points,  
* support interventions that foster maturity and dignity in practice.

Thus:

* A low A-score may be part of an **ascending learning curve** – not a ground for degradation.  
* A high A-score may be part of a **descending curve** – not proof of “higher dignity.”

---

#### 5.2.4 Practical use

For practice:

* scores should be **dated** and **contextualised**  
  (“A(t₁) = 3–4 in setting X,” “A(t₂) = 5–6 after intervention Y”).  
* multiple measurement points serve to ask:
  – *better? worse? steadier?*  
  – not: “Who is ahead?”

Guiding formula:

> **The goal is a more mature trajectory –  
> and a more dignifying way of treating self and others –  
> not the fixation of labels.**

**Implication for the model:**

Chapter 5 makes A a **working instrument**:  
maturity becomes readable without reducing people to scores;  
trajectories matter more than single judgments.  
The A-score shows *how* one acted;  
the D-profile (D₁/D₂) shows *how* dignity was handled.  
Next, a framework for **shared responsibility** is needed:  
Who carried which leverage for the whole – and how can this be balanced fairly?  
This is precisely what the M-score develops in Chapter 6.

---

## 6) M-score – ceiling rule & fairness

In every complex case, a crucial question eventually arises:  
**“Who carries how much responsibility for the whole?”**  
Not all participants have the same overview, agency, alternatives –  
yet harm is often distributed as if all had equal responsibility.

The M-score complements the A-score with a second axis:

> **A = maturity in practice.**  
> **M = shared responsibility for the whole.**

It highlights:

* who had structural **leverage** (power to act, knowledge, alternatives, foresight),  
* who was primarily **affected** and had little real agency.

And:  
**Shared responsibility is not a dignity verdict.**  
D₀ (ontological dignity) remains untouchable;  
D₁/D₂ (dignity in practice) appear in the D-profile, not in the M-score.

The M-score is not blame coding, not moral stamping –  
but a tool for **fair distribution of responsibility**:  
Who had which decision space, which information, which mandate –  
and where must the “ceiling” for maturity and dignity readings be placed (ceiling rule)  
so that affected persons are not doubly burdened?

**Mini-vignette:**  
A student violates a school rule to help a friend in distress.  
A teacher responds formally correctly but rigidly; the school leadership has discretion but does not use it.  
The M-score asks:  
Who had which shared responsibility for the situation –  
and who could realistically have changed the trajectory?  
It prevents treating the student as the main responsible party  
while institutional levers remain invisible.

Chapter 6 then:

* operationalises the M-score (dimensions, scales, examples),  
* links it to the **ceiling rule** (how A- and D-evaluations are limited from above),  
* and situates it alongside the A-score and the D-profile,  
  so that maturity, shared responsibility and dignity in practice  
  can be read together but **not conflated**.

---

### 6.1 M-score (shared responsibility, not fault or guilt)

Once the A-score clarifies **how maturely** someone acts in a concrete situation,  
a second question remains:

> **“How much realistic shared responsibility does this position carry  
> for the course and consequences of the situation?”**

The M-score shifts the focus from the person to the **leverage within the system**:  
Who had knowledge, power and alternatives – and who was primarily affected?  
It evaluates **structures and positions**, not personal worth.

The M-score is strictly decoupled from **D₀/D₁/D₂**:

* **D₀ – ontological dignity** (the unrevocable value of the person) remains **outside** all metrics.  
* **D₁/D₂ – dignity in practice** (self-dignity in practice and relational dignity in practice),  
  operationalised through D-I, D-B, D-R, D-P,  
  are described in the **D-profile**, not in the M-score.

The M-score answers:

> **“Who could realistically have acted differently –  
> with which information, and at what cost?”**

---

#### 6.1.1 Five factors of shared responsibility

To avoid assigning shared responsibility “from the gut,”  
the model works with five structural factors:

1. **Knowledge (A – awareness)**  
   – What information was available?  
   – Could the situation realistically be understood?  
   – Were there warnings, expertise, indications?

2. **Power / control (P – power to act)**  
   – What real levers were available?  
   – Could the trajectory have been changed, limited or stopped?  
   – Or was the position dependent, constrained, overruled?

3. **Predictability**  
   – Were consequences recognisable for an ordinarily informed person?  
   – Did it require specialist knowledge?  
   – How high was situational uncertainty?

4. **Access to alternatives**  
   – Were there **real** alternatives, or only theoretical ones?  
   – Could one exit or refuse **without existential cost**  
     (housing, status, residency, safety)?  
   – Could available support realistically be found and used?

5. **Serious integration attempt**  
   – Were risks named and mitigated?  
   – Were other perspectives considered?  
   – Were alarms taken seriously – or dismissed?

**Mini-vignette:**  
A team leader repeatedly receives indications that a policy overloads staff.  
They have overview, decision power, alternatives (restructuring, reprioritisation),  
and time to review the issue – but do not act.  
→ **High M-score:** knowledge, leverage, predictability and alternatives are clearly present.

By contrast, a single employee trying to contain harm with little agency:  
→ **Low M-score** – even if their behaviour appears chaotic (mixed A-score).

---

#### 6.1.2 High vs. low M-scores

The five factors are not mechanically calculated;  
they serve as a framework to distinguish **high** from **low** shared responsibility.

**High M-score (7–9)** typically means:

* high knowledge (A high),  
* significant levers (P high),  
* predictable consequences,  
* accessible alternatives,  
* weak, half-hearted or late integration attempts.

→ **substantial structural shared responsibility**.

Examples:

* Leadership knows risks but does not respond.  
* An institution knows of misconduct but remains formalistic or deflects.  
* Powerful actors benefit while risks are systematically shifted downward.

**Not:** a moral flaw or dignity reduction.  
Ontological dignity (D₀) remains untouched.

---

**Low M-score (0–3)** means:

* little knowledge,  
* minimal leverage,  
* low predictability,  
* few or no real alternatives,  
* recognisable attempts to cope or protect oneself.

→ **primarily affected, minimally responsible**.

Typical cases:

* children and adolescents in dependency structures,  
* people in existential economic, legal or social dependencies,  
* powerless employees in rigid hierarchies,  
* laypersons facing complex systemic risks.

A low M-score explicitly protects against **victim blaming**:  
That someone acts immaturely under pressure (low A) or shows chaotic dignity enactments (D₁/D₂)  
does not make them primarily responsible for a system overwhelming them.

---

#### 6.1.3 M-score as structural distribution, not character judgment

Two protective axioms mark the boundary:

> **Personal worth (D₀ – ontological dignity) lies outside all metrics.**  
> A and M describe enactment and structure – not “the person.”

> **M is shared responsibility, not guilt.**  
> It concerns *shares*, not condemnation or degradation.

Praxeological consequences:

* Affected individuals may have a **low M** even if their behaviour is chaotic.  
  Their dignity enactments (D₁/D₂) are assessed in the D-profile – never via M.
* Organisations or leadership roles may have a **high M**,  
  even if individuals acted “legally”:  
  they had the structural capacity to prevent, limit, protect or make transparent.

**Mini-vignette:**  
A municipality sells critical infrastructure to an investment firm.  
Political decision-makers were informed, had alternatives, ignored warnings → high M.  
Residents later living with the consequences had no structural leverage → low M,  
even if they voted “badly” or reacted poorly under stress.

The guiding formula of the entire model:

> **“Recognise the enactment – not the person.”**  
> A and M read enactments and structures;  
> ontological dignity (D₀) remains untouched.

Thus, the M-score is not a moral tribunal but a tool for **fair distribution of responsibility** –  
redirecting attention from “Who was noisy and visible?” to “Who had which lever?”

---

### 6.2 The ceiling rule (protection against victim blaming)

Once shared responsibility can be scaled, a risk emerges:  
With enough creativity, almost anyone affected can be retroactively framed as “responsible” –  
“you should have known,” “you could have left,” “you should have acted differently.”

This is precisely what the **ceiling rule** prevents.  
It is the built-in **dignity protection** of the M-score:

> **If predictability ≈ 0 or access to alternatives ≈ 0,  
> the M-score may not exceed 4/10 – regardless of the other factors.**

In short:

> **No high shared responsibility without predictability and real options.**

Thus, where people are structurally kept in the dark or effectively trapped,  
the model must **not** retroactively make them responsible for the system engulfing them.

---

#### 6.2.1 Predictability ≈ 0

Predictability is effectively zero when:

* essential information was **not accessible**,  
* specialist knowledge would have been required that actors **could not** realistically have,  
* risks were deliberately downplayed or obscured,  
* even experts could not reliably foresee outcomes.

Examples (kept abstract):

* complex financial or technical products only experts can assess,  
* internal risk reports that are hidden,  
* systemic effects whose collapse dynamics can only be reconstructed afterwards.

In such contexts, it would be praxeologically **unfair** to ascribe high shared responsibility  
just because behaviour appears “reckless,” “naive,” or “careless.”  
They simply could not foresee the consequences.

---

#### 6.2.2 Access to alternatives ≈ 0

Access to alternatives is effectively zero when:

* **leaving** the situation is not realistically possible without severe endangerment  
  (housing, residency, safety, health, children’s wellbeing),  
* dependencies (economic, legal, emotional, institutional) are so strong  
  that “just leave” is **not a real option**,  
* theoretical avenues exist but are **practically inaccessible**  
  (no money, no networks, language barriers, threats, legal constraints).

**Mini-vignette:**  
A person lives in a relationship that becomes increasingly violent.  
They are financially dependent, caring for small children, have insecure residency, no network.  
Formally, support services exist – practically, exit is existentially dangerous.  
→ Access to alternatives ≈ 0 → M-score remains capped, regardless of how “irrational” staying appears from outside.

The ceiling rule applies **categorically**:

> **Those with no real alternative cannot receive a high M-score –  
> even if their behaviour appears “unwise” to outsiders.**

---

#### 6.2.3 Function of the ceiling rule

The ceiling rule fulfils three central functions:

1. **Protection against victim blaming**

   * People in coercive or overwhelming conditions are not reframed  
     as primarily responsible for structures they did not create.  
   * Their ontological dignity (D₀) is protected,  
     and their dignity enactment (D₁/D₂) is **not** conflated with systemic responsibility.

2. **Protection against retroactive over-demand**

   * Prevents treating overwhelmed, under-informed or dependent persons  
     as if they had the same responsibility as informed, powerful actors.  
   * “You should have acted differently” is tied back to:  
     “Did you have knowledge? Did you have levers? Did you have real options?”

3. **Focusing responsibility on the correct levels**

   * The model forces attention toward **knowledge and power centres**,  
     not toward those already bearing the harm.  
   * High M-scores cluster where structural **control, overview and alternatives** existed.

Guiding sentence:

> **High M-scores belong where knowledge, power, predictability and access to alternatives are high –  
> not where people are already suffering the consequences.**

Thus, the ceiling rule is a cornerstone of the model’s dignity-protection logic.  
It prevents the model from becoming a refined tool for old patterns of “your fault”  
and retroactive degradation.

It also prepares the ground for the next question:  
How do A-score and M-score **interact** once they are separately determined?

---

### 6.3 Interaction of A-score & M-score

A-score and M-score are determined **separately** –  
but their interaction reveals **where** a system stands and **which interventions** make sense.

Core idea:

> **A** describes maturity in practice (A–C–R–P) in a situation.  
> **M** describes structural shared responsibility for the overall trajectory and consequences.

When the **D-profile** is added  
(D₁/D₂ as dignity in practice – operationalised through D-I, D-B, D-R, D-P),  
a three-dimensional reading emerges:

* **How mature was the enactment?** (A)  
* **How much responsibility did this position carry?** (M)  
* **How was dignity handled – self- and other-directed?** (D-profile)

In the A–M space, four baseline constellations appear.

---

#### 6.3.1 A high – M high

* **High maturity**,  
* **high shared responsibility**.

Typical:

* leadership, institutions, decision bodies with strong leverage  
  who see risks, know alternatives, and act deliberately.

Interpretation:

* **Positive:**  
  A high + M high = significant responsibility is exercised **maturely**.  
  Often accompanied by **high dignity enactment**:  
  fair communication, protection of weaker parties, transparent corrections.

* **Critical:**  
  If degrading practices continue **despite** high awareness and high responsibility,  
  the D-profile becomes sharp:  
  degradation is then not “accidental,” but part of a responsible enactment.

---

#### 6.3.2 A high – M low

* **Mature enactment**,  
* **low responsibility** for the broader system.

Typical:

* employees acting responsibly in poor structures,  
* affected people who remain fair, clear and constructive despite little agency,  
* individuals making careful decisions under tight constraints.

Interpretation:

* The model allows such enactments to be **recognised**  
  without overburdening these actors with responsibility they do not have.  
* A high, M low = **adultness under adverse conditions**.  
* D-profile often shows consistent self-respect and respect for others (D₁/D₂ relatively high)  
  despite minimal power to act.

---

#### 6.3.3 A low – M high

* **Low maturity**,  
* **high responsibility**.

Typical:

* powerful roles acting impulsively, cynically or negligently,  
* well-informed actors deflecting or offloading risks,  
* organisations benefiting from IA patterns while blocking correction.

Interpretation:

* A classic **IA risk zone**:  
  **high leverage + low maturity**.  
* Interventions target:

  * limiting or framing power (P),  
  * redistributing responsibility (R),  
  * increasing awareness (A) and coherence (C),  
  * and – regarding dignity – reducing degrading practices and communication.

---

#### 6.3.4 A low – M low

* **Low maturity**,  
* **low responsibility**.

Typical:

* overwhelmed, under-informed, dependent participants,  
* people reacting chaotically or self-destructively in crises,  
* affected individuals inside systems built and controlled by others.

Interpretation:

* The model supports a **dual view**:

  * **Yes**, behaviour may be immature or destructive (A low).  
  * **No**, this does **not** imply high responsibility (M low).

* Instead of blaming, the model asks:  
  **Who had knowledge, leverage and alternatives – and how did they act?**

The D-profile may reveal:

* **self-devaluation** (“Everything is my fault”) as a response to structural IA,  
* or **protest enactments** (“Then I’ll behave like trash”),  
* without permitting any moral devaluation of the person.

---

#### 6.3.5 Practical use of A & M (with D-profile)

In practice:

* The **A-score** indicates:  
  → **How mature was the enactment?**
* The **M-score** indicates:  
  → **How much structural responsibility existed?**
* The **D-profile** indicates:  
  → **How dignity was enacted – toward self and others (D₁/D₂).**

The combination helps tell:

* where **learning and development** are needed (A focus),  
* where **structural change or power limitation** is necessary (M focus),  
* where **protection** should come first (low M, high harm),  
* where dignity enactment is especially critical  
  (e.g. systematic degradation despite high A and high M).

Closing formula for this chapter:

> **A measures how we act.  
> M measures how much of the overall trajectory we carry.  
> D shows how we handle dignity – ours and others’.**  
> From all three follow where we must learn, limit –  
> and where we must protect first.

Thus the model’s coordinate system becomes complete:  
maturity, shared responsibility and dignity in practice can be described separately  
while still being thought **together** –  
as the foundation for the following chapters, where the model is applied to concrete scenes.

---

### 6.4 D and shared responsibility

*(Self-devaluation vs. structural responsibility)*

With the **dignity-in-practice module (D₁/D₂)**, another tension becomes visible:

> **The more wounded people are, the more they tend to devalue themselves –  
> yet precisely there, their M-score is often lowest.**

The model intentionally separates:

* **A** – maturity in practice,  
* **M** – structural shared responsibility,  
* **D** – enactment of dignity (D₁/D₂, operationalised through D-I, D-B, D-R, D-P).

Self-devaluation (“It’s all my fault”) is therefore **not** evidence of high M,  
but a **dignity phenomenon** (a D₁/D₂ pattern in practice) under pressure.

---

#### 6.4.1 Self-devaluation in the D-framework

On the dignity level, self-devaluation can take different forms:

* **D₁ – self-dignity in practice (inner orientation)**  
  – “I am worthless.”  
  – “I only failed.”  
  – “I deserve what’s happening to me.”

* **D₂ – relational dignity in practice (D-R/D-P)**  
  – “If you treat me like trash, I’ll live like trash.”  
  – “If the world is like this, it’s not worth caring for myself.”

In both cases, we see:

* a **break in self-enactment** (low D₁/D₂),  
* but **no** automatic increase in:

  – knowledge (A),  
  – power or agency (P),  
  – access to alternatives,  
  – structural interpretive authority.

On the contrary:

* people experiencing deep self-devaluation often have:

  – low **C-P** / **P-S** (coherence in power contexts, social agency),  
  – limited access to alternatives,  
  – high harm with **low M-score**.

Thus the model reads self-devaluation primarily as:

> **A wound marker** – not as evidence of high structural responsibility.

---

#### 6.4.2 Why self-degradation does *not* produce a high M-score

The M-score does not follow a person’s inner sense of guilt.  
It follows the **ceiling parameters**:

* What could someone **realistically know** (awareness, A)?  
* What **role and power** did they actually have (coherence in power contexts, C-P; social/public agency, P-S/P-PU)?  
* How high were **predictability** and **access to alternatives**?  
* Did the person demonstrably attempt **integration or correction**?

Self-degradation automatically fulfils **none** of these criteria:

* Someone who “makes themselves small” does **not** thereby gain additional responsibility for the system.  
* Someone who internally “takes all the blame” does **not** thereby increase their formal or material shared responsibility.  
* On the contrary: self-devaluation may indicate that someone is carrying **excess subjective guilt** while having **objectively low M**.

This yields three strict rules:

1. **A D-break ≠ an increase in M**

   – If someone degrades themselves (e.g., constant self-devaluation, taking all blame),  
     this appears in the **D-profile** –  
     but the M-score remains tied to **role, knowledge, power, alternatives**.

2. **High subjective guilt → M-check, not M-increase**

   – Intense self-accusation is a reason to check the M-score **carefully**:  
     “Does this person actually carry the structural responsibility they believe they do?”  
   – Often the result is: **A and D are the issues**, M remains low.

3. **Structural responsibility stays at the top – even when those below self-devalue**

   – If affected people devalue themselves, this does **not** reduce the responsibility  
     of those who truly hold the levers (high M).  
   – In fact, it is an IA signal when powerful actors (high M) use the self-devaluation of those below  
     as “proof” that they themselves did little wrong.

---

#### 6.4.3 D, M and protection – practical implications

In practice this means:

* **People with low M but high D-damage**  
  – are primarily **targets of protection**, not of accusation.  
  – Interventions focus on:

    * relieving them of internalised pseudo-guilt,  
    * strengthening D₁ (self-care, self-respect, boundary protection),  
    * making **structural responsibility** visible elsewhere (high M).

* **People with high M and outward D-breaks**  
  – e.g., systematic degradation of others while holding significant power –  
  – become the focus of **responsibility and structural work**:

    * limiting or framing power to act (P),  
    * reviewing asymmetries (IA-box),  
    * clearly naming responsibility,  
    * re-anchoring behaviour in protection and dignity requirements.

Mnemonic for the interaction of A, M and D:

> **Self-degradation shows D-damage, not high M.**  
> **Structural responsibility remains where knowledge, power and alternatives lay –  
> even when someone below “takes all the blame.”**

Thus, the model’s triad becomes clear:

* **A** – How mature is the enactment?  
* **M** – How strongly does this position carry the overall trajectory?  
* **D** – How is dignity enacted – one’s own and that of others (D₁/D₂)?

---

## 7) Guiding formulas & tools

So far, the model has been described primarily **structurally**:  
parameters, scores, guardrails, boxes.

This chapter now gathers the **practical tools** that let the whole framework  
become operational:

* a **Case Lens** as a step-by-step protocol,  
* simple **score sheets** for A, M, IA-box and D-profile,  
* and work with **trajectories rather than points**.

The aim is not to create bureaucratic overhead but to provide **lightweight tools** that:

* make maturity and responsibility visible,  
* co-read dignity in practice (D₁/D₂),  
* and ultimately lead to **different decisions and structures**.

---

### 7.1 Case Lens (v1.0) – decision protocol

The **Case Lens** is the standard protocol for a full IA analysis.  
It ensures that you:

* describe the case clearly,  
* examine relevant parameters,  
* see responsibility over time,  
* and always end with a **decision** –  
  not merely commentary.

It operates primarily with **A–C–R–P–D**,  
with **D₁/D₂ (dignity in practice)** activated only when all guardrails (chap. 3.5/3.6) are fulfilled.

**Standard path:**

1. Snapshot  
2. Frame vs. variability  
3. A-scores (trajectories)  
4. IA-localisation (knowing/being able/being permitted/willing)  
5. RVR(t) – responsibility–viability–range over time  
6. Decision: maintain / balance / change–stop  
7. KPIs & review date  

Optional, **only with safe conditions**:

> Add a **D-profile** (dignity in practice, D₁/D₂)  
> after step 3 or parallel to step 4 (see 5.3 and 7.2.4).

Principle:

> **Every IA analysis ends with at least one actionable improvement proposal.**  
> Pure diagnostics without corrective trajectory is *inadult use* of the model.

---

#### Step 1 – Snapshot (case, actors, level)

A short, neutral snapshot:

* **What is this about?**  
  – situation, decision, conflict, structure.

* **Who is involved?**  
  – roles, power gradients, affected parties, context.

* **On which level?**  
  – individual · dyadic · organisational · political · cultural.

* **Publicity?**  
  – private · semi-public · institutional · public · media  
    (consider A-P/P-PU: public/media awareness and public agency).

* **First visible D₁/D₂ themes?** (optional – dignity in practice)  
  – self-devaluation, shaming, degradation,  
    implicit messages: “You are worth less.”

Goal: **precise, one-sided description** without interpretation or blame.

---

#### Step 2 – Frame vs. variability

Question:

> **What is fixed – and what is malleable?**

* **Frame (fixed / slow to change):**  
  – laws, contracts, structural constraints, physical limits, protected goods,  
  – **ontological dignity (D₀)** as axiomatic boundary.

* **Variability (malleable):**  
  – roles, communication, processes, timing, degree of intervention, error handling,  
  – handling dependencies, attributions, dignity enactments (D₁/D₂).

Outcome:

* Where would high A/M be **unfair**?  
* Where does “the system” become an **excuse**?  
* Where is D₁/D₂ **realistically improvable**?

---

#### Step 3 – A-scores (trajectories)

For relevant actors:

* establish **A(t₀), A(t₁), A(t₂ …)**  
  (maturity in practice → awareness, coherence, responsibility, power).

* **Band estimation** (e.g., 3–4, 5–6),  
  with **1–2 justification points** per moment.

Optional when D is activated:

* notes on **D₁/D₂ enactments**  
  – self-devaluation (low D₁),  
  – protection of others despite costs, protest, refusal (high D₂),  
  – shaming/degrading others (low D₂).

**Do not evaluate D yet** – only observe.

---

#### Step 4 – IA localisation (knowing / being able / being permitted / willing)

Four diagnostic clusters:

* **Knowing**  
  – information landscape, blind spots, knowledge withholding, interpretive power.

* **Being able**  
  – competencies, resources, tools, ability to address dignity.

* **Being permitted**  
  – formal/informal permission, taboos, sanctions, unspoken prohibitions regarding IA/D.

* **Willing**  
  – willingness to correct; where responsibility is resisted or offloaded.

IA localisation reveals:

* where asymmetries are **not functional**,  
* where D₂ is systematically **undermined** or **protected**.

---

#### Step 5 – RVR(t): responsibility–viability–range over time

> **RVR(t) = f(knowing, being able, being permitted, acting)**  
> under the **ceiling rule** and **ontological dignity (D₀)**.

For each time span assess:

* realistic M-share?  
* Was knowledge present or absent?  
* Which levers (P-S/P-PU)?  
* Room to act (being permitted)?  
* Real decision options?

Ceiling rule:

> **Predictability ≈ 0 or alternatives ≈ 0 → M ≤ 4.**

Outcome:

* **responsibility curve**, not a point value.  
* No “They *should* have just…,” when knowledge/levers/alternatives were absent.  
* Protection of **dignity in practice (D₁/D₂)** through fair attribution.

---

#### Step 6 – Decision: maintain / balance / change–stop

Three modes:

1. **Maintain**  
   – asymmetry is functional (T-J-TB-R fulfilled),  
   – dignity in practice (D₁/D₂) is protected.

2. **Balance**  
   – maturity okay, but power/responsibility skewed,  
   – increase transparency, clarify roles, shift resources,  
   – reduce degrading side effects.

3. **Change–stop**  
   – clear IA signals (intransparent, unjustified, irreversible),  
   – high harm, D-breaks, high M,  
   – radical correction/termination.

Decision with short justification referencing:

* A/M trajectories,  
* IA localisation,  
* RVR(t),  
* observed D₁/D₂ enactments.

---

#### Step 7 – KPIs & review date

Close with:

* **KPIs:**

  – fewer IA signals,  
  – more stable A-scores,  
  – fewer D-breaks,  
  – improved conditions for affected parties.

* **Review date:**

  – time, responsible roles, falsifiers  
    (“When do we consider our hypothesis disproven?”)

Thus analysis becomes a **responsibility process**, not a final verdict.

---

### 7.2 Score sheets (A, M, IA-box, D)

Score sheets are **structuring aids** – not rankings.

Goals:

* organise thinking,  
* detect blind spots,  
* document dignity enactments **as behaviour**, not as personhood,  
* keep decisions transparent.

Core sheets:

* **A-score sheet**  
* **M-score sheet**  
* **IA-box sheet**  
* **D-profile sheet** (optional, separate module)

---

#### 7.2.1 A-score sheet

Header:

* case / context  
* role / level  
* time window

Four blocks:

1. **A-I (inner awareness)** – observations + band  
2. **A-R (role awareness)** – observations + band  
3. **A-C (context awareness)** – observations + band  
4. **A-IM / A-P** (impact awareness / public/media awareness) – observations + band  

Close with:

* **integrated A-band**  
* **justification** (2–3 sentences)

Optional with D activated:

* notes on D₁/D₂, **without** evaluating here.

A remains a **maturity metric**; D is handled separately.

---

#### 7.2.2 M-score sheet

Header:

* position / role  
* time frame

Five M components:

1. **Knowledge (A)** – low/medium/high  
2. **Power/control (P)** – l/m/h  
3. **Predictability** – l/m/h  
4. **Access to alternatives** – l/m/h  
5. **Integration attempt** – weak/medium/strong  

Then:

* **raw M (0–10)**  

* **Ceiling rule check:**

  – predictability ≈ 0?  
  – alternatives ≈ 0?  
  → **M ≤ 4.**

Close with:

* **valid M-score**  
* short comment

D-link:

* low M + high harm → **protection**, not blame  
* self-devaluation = **D₁ phenomenon**, **not** an increase in M

---

#### 7.2.3 IA-box sheet (Four-criteria box)

**Asymmetry:**  
(precisely name the issue)

Four fields:

1. **Transparent?** – yes / partly / no  
   *Who knows what? Who could know?*

2. **Justified?** – yes / partly / no  
   *Which legitimate purpose does the asymmetry serve?  
   Protection, process, organisation – or unilateral advantage?*

3. **Time-bound?** – yes / partly / no  
   *Which review points or conditions exist?*

4. **Reversible?** – yes / partly / no  
   *Which real exit options exist?  
   What blocks the return path?*

**Conclusion:**

* predominantly **functional**,  
* **IA risk**,  
* or **clearly inadult**.

**Immediate action:**  
(short proposal: more transparency, add review, create exit option, clarify roles, etc.)

**D-note (observation, not judgment):**

* **D₁ effects:** self-devaluation? withdrawal? loss of self-care?  
* **D₂ effects:** shaming? exclusion? reinforcement of subordination?  
* **D-support:** does the structure create protection / dignity scaffolding?

Detailed analysis occurs in the **D-profile sheet** (7.2.4)  
and the **D-Quick-Grid** (11.3).

---

#### 7.2.4 D-profile sheet (D₁/D₂ – dignity in practice)

After A-score, M-score and IA-box clarify structural aspects of a case,  
one final, sensitive question remains:

> **How does someone – under these conditions – enact their dignity?**

The D-profile is the most delicate tool in the model.  
It describes **concrete dignity enactments** (*D-enactments*) of a person or role – never personhood.

**Core rules:**

* D is used **only** when all guardrails (chap. 3.5–3.7) are met.  
* **Ontological dignity (D₀)** remains untouched and **outside** the card.  
* Observed are **D₁** (self-dignity in practice) and **D₂** (relational dignity in practice),  
  operationalised through:  
  – **D-I** (inner self-relationship),  
  – **D-B** (bodily/material self-care),  
  – **D-R** (relational dignity),  
  – **D-P** (public dignity in practice).  
* No numbers – **qualitative bands** only.  
* Every statement is **situated**, contextual, revisable.

---

**Header:**

* case / context  
* role / level (affected person, leadership, team, public, etc.)  
* time frame (t₀–t₁, key moment, trajectory)  
* communication space:  
  – self-reflection · professional-confidential · **not** public  
* scope:

  * ☐ **Inner orientation – D₁** (D-I/D-B)  
  * ☐ **Relational orientation – D₂** (D-R)  
  * ☐ **Public orientation – D-P**

---

##### Block 1 – D₁: self-enactment / self-treatment (D-I/D-B)

**Questions:**

* How does the person speak about themselves?  
* How do they treat body, boundaries, needs?  
* How do they respond to their own failures?  
* What structural factors (pressure, poverty, chronic criticism, discrimination) shape D₁?

**Fields:**

* **Observable D₁-enactments (D-I/D-B):**  
  excessive guilt taking; self-insulting language; boundary setting despite costs; active help-seeking;  
  systematic self-exploitation; persistent dismissal of bodily/psychological signals.

* **Trend band:**  
  *rather self-devaluing* / *ambivalent* / *rather self-respecting*

* **Context notes:**  
  Which conditions suppress or support D₁ (time pressure, dependency, social isolation, support networks)?

---

##### Block 2 – D₂: relational dignity (D-R – feedback to the world)

**Questions:**

* What does the enactment signal about relation to the environment?  
* Is this protest, adaptation, mirroring, withdrawal, refusal?  
* Are degrading patterns mirrored or interrupted?

**Fields:**

* **Observable D₂-enactments (D-R):**  
  neglect as protest; ironic self-degradation; refusal to degrade others;  
  breaking cooperation; withdrawal from degrading settings; shaming others.

* **Interpretive reading (not judgment):**  
  *deficit* / *protest* / *ambivalent* / *dignity-stabilising*

* **Structural context:**  
  Which IA patterns resonate here (exclusion, stigma, class/milieu dynamics)?

---

##### Block 3 – D-P: dignity enactment under publicity

(Active only when publicity is relevant.)

**Questions:**

* How does behaviour **before an audience** differ from private behaviour?  
* Are one’s own or others’ dignities marketed, risked, protected, instrumentalised?

**Fields:**

* **Public enactments (D-P):**  
  self-commodification; exposing others’ intimate details; protection of vulnerable persons;  
  deliberate restraint to avoid shaming.

* **Private/public tension:**  
  *congruent* / *divergent*

* **Publicity context:**  
  reach, platform, archiving, power asymmetries, symbolic/financial incentives.

---

##### Block 4 – Linking A–M–D (without mixing)

**Short matrix:**

* **A-band** (maturity in practice)  
* **M-band** (shared responsibility)  
* **D-tendency** (e.g., “strong self-devaluation with low M”)

**Goal:**

* Reveal D-damage with **low M** → protection, relief, structural critique.  
* Reveal degrading enactments with **high M** → responsibility and structural work.

Mnemonic:

> **A measures maturity.  
> M measures shared responsibility.  
> D describes dignity in practice.  
> Self-devaluation does not raise M.**

---

##### Block 5 – Guardrails & use

**Checklist:**

* ☐ Not used for diagnostics, HR, forensics, shaming.  
* ☐ Describes **enactments**, not personhood.  
* ☐ **D₀ (ontological dignity)** remains unquestioned; degrading language marks a D-break of the observer.  
* ☐ Use only **contextually** (role logic, A/M profile, IA-box, publicity).

**Use in procedure:**

* contribute to **D-trajectory D(t)** (more self-care? less self-devaluation?).  
* input for **D-Quick-Grid** (11.3).  
* early warning for declining dignity enactments.

Short vignette:

> An assistant nurse repeatedly describes herself in supervision as “too stupid” and “too sensitive,”  
> even though she carries a ward under high pressure.  
> A is mid-range, M is clearly low, D₁ shows strong self-devaluation.  
> The D-profile ensures **support and relief** here – not additional blame.

---

**Margin protection clause (mandatory):**

> **“This profile describes enactments, not personhood.  
> D₀ remains inviolable.  
> All descriptions are situated, revisable and corrigible.”**

Link to other tools:

* The D-profile complements:

  – A-score (maturity in practice),  
  – M-score (shared responsibility),  
  – IA-box (structural quality).

* For finer classification of D-breaks,  
  use the **D-Quick-Grid (11.3)**:  
  minor frictions · consistent breaks · major/extreme breaks.

Thus the D-module remains what it must be:

> **A revealer of dignity and degradation dynamics –  
> never a diagnostic tool and never a pillory.**

---

### 7.3 Trajectories instead of points

Maturity, responsibility and dignity in practice are **trajectories**, not traits.

A single value is a snapshot.  
What matters is whether something **stabilises, improves or deteriorates** over time.

Guiding formula:

> **We write curves, not labels.**

* **A(t)** – maturity in practice,  
* **M(t)** – shared responsibility across time,  
* **D(t)** – change in dignity enactment (D₁/D₂).

---

#### 7.3.1 Why trajectories?

A single value says little.  
A trajectory shows:

* learning,  
* stagnation,  
* tipping points,  
* overload,  
* structural distortions,  
* maturation or erosion in self-treatment (**D₁**),  
* protest, withdrawal or adaptation in relational enactment (**D₂**).

Trajectories enable fairer decisions because they do not only ask:

> “How was it here?”  
> but rather:  
> **“In which direction is this system moving?”**

---

#### 7.3.2 Minimal documentation

**Timeline:** t₀ – t₁ – t₂ …

For each point:

* A-band,  
* M-band,  
* optional D-observation (e.g., “D₁ stabilising, D₂ becoming more defensive”),  
* key events / role shifts / context jumps.

Example (condensed):

* t₀ – acute crisis – A 3–4 – “overrun, no role clarity”  
* t₁ – after first intervention – A 4–5 – “roles more explicit, first corrections”  
* t₂ – after structural change – A 6–7 – “responsibility redistributed, D₂ less defensive”

Final question:

> **Is the enactment becoming more dignified – or merely more efficient?**

---

#### 7.3.3 Linking Case Lens ↔ Score sheets

* Case Lens **step 3** → A-trajectories,  
* Case Lens **step 5** → RVR(t) – responsibility–viability–range over time,  
* score sheets (A, M, IA-box, D-profile) → raw data,  
* Case Lens **step 6/7** → decision & review based on curves.

Mature use means:

* no still images (“You are like this”),  
* focus on **direction + pace**,  
* core question:

> **What enables a more mature trajectory –  
> and what enables a more dignified enactment?**

Thus the model becomes fully dynamic:  
It cares less about labels and more about whether systems are **capable of learning and change**.

---

### 7.4 System-1 / System-2 micro-tool (acute situations)

Not every situation allows for a full Case Lens. Sometimes:

* pressure is high,  
* emotion is strong,  
* time is short,  
* the public is already present.

Here a **micro-tool** is needed that helps, within seconds,  
to avoid staying stuck in a System-1 reflex (impulse, defence, attack)  
and to insert at least a brief System-2 moment.

The micro-tool works in four steps:

> **STOP – FRAME – ROLE – STEP**

---

#### Step 1: STOP – minimal interruption

Goal: interrupt the automatic stimulus–response chain.

* internally: “Stop. I don’t have to respond immediately.”  
* externally:  
  – “I need a moment …”  
  – “Let me think for a second.”

Praxeological effects:

* **awareness (A)** moves from “near zero” to “minimally active”,  
* **power (P)** is briefly throttled (no irreversible actions),  
* **coherence (C)** and **responsibility (R)** get space,  
* **dignity enactment (D)** is implicitly protected  
  (lower likelihood of impulsive degradation – of others or oneself).

---

#### Step 2: FRAME – micro-context setting

Questions:

* **Where are we?**  
  private · professional · institutional · public · media?

* **What is this about in one sentence?**  
  conflict, request, accusation, boundary-setting, decision?

* **Which protected goods are touched?**  
  health, safety, **dignity** (D₀/D₁/D₂ – D₀ = ontological dignity, D₁/D₂ = dignity in practice),  
  existence, trust?

Goal:

* minimally increase **coherence (C)**,  
* synchronise **awareness (A)** with coherence,  
* preliminarily mark **whose dignity is at risk**.

---

#### Step 3: ROLE – short-form role check

Three micro-questions:

1. **From which role am I speaking?**  
   (private person, professional, leadership, affected party, facilitator …)

2. **In which role am I hearing the other?**

3. **Is this clear for both sides?**  
   If not: *one sentence of clarification*.

Outcome:

* acute increase in **role awareness (A-R)**,  
* reduced risk of phantom intentions,  
* D-protection: prevents people from being degraded “in the wrong role”  
  (e.g., clients treated like offenders, staff treated like “enemies”).

---

#### Step 4: STEP – smallest reversible action

Examples:

* a clarifying question,  
* short summary (“What I hear is …”),  
* temporary boundary (“Up to here, not further.”),  
* suggest a pause / rescheduling.

Criteria:

* **reversible**,  
* **role-consistent**,  
* **context-compatible** (FRAME),  
* **protection-aware** (especially regarding dignity).

Principle:

> **Mini-adultness:**  
> Not acting perfectly – but avoiding anything that would irreversibly block later maturity or restoration of dignity.

Short vignette:

> In a team meeting a colleague is suddenly attacked: “You’re sabotaging everything here!”  
> Instead of firing back, the team lead says:  
> “Stop – I need a moment to sort the frame. We’re in a team meeting, not a tribunal.  
> I’m speaking now as the team lead and want to first understand what happened.”  
> This STOP–FRAME–ROLE–STEP prevents a spontaneous degradation  
> from becoming a structural pattern.

Thus the micro-tool is not a substitute for the Case Lens,  
but an **emergency lever** for remaining praxeologically adult under pressure.

---

### 7.5 Mini-toolkit: score sheet & context tools (optional)

The mini-toolkit sits between “nothing” and “full Lens”.

It consists of:

1. **Context cards** (roles, publicity, frame/variability),  
2. **Light score sheets** (A/M bands, D only as side observation),  
3. **IA-box check (light)** – T-J-TB-R in short form.

This allows for more structured reading of maturity, responsibility  
and dignity dynamics even with limited time –  
without slipping into over-diagnostics or overuse of D.

---

#### 7.5.1 Three usage modes

**1) Quick-check (5–10 min)**

* 1 contrast question: “Where is the likely unfair asymmetry?”  
* IA-box light (T-J-TB-R briefly)  
* rough A-band estimation  
* optional 1 D-keyword (self-devaluation / dignity-stabilisation)

**2) Mini-toolkit (30–60 min)**

* context card (role, publicity, frame/variability),  
* light A-score sheet: band + short justification,  
* M-score sheet incl. ceiling rule check,  
* 1–2 IA-boxes,  
* optional D-note (no D-scores, only observed patterns).

**3) Full Lens**

* full Case Lens,  
* full score sheets,  
* trajectories,  
* RVR(t),  
* review planning.

The mini-toolkit provides enough depth to structure perception  
without risking over-diagnosis or over-extension of D.

---

#### 7.5.2 Typical application fields

* **Team reflection** after conflicts or projects  
  – Where was enactment mature/immature?  
  – Which asymmetries were functional, which inadult?  
  – optional: where did D-breaks occur (minor, consistent, major)?

* **Decision preparation**  
  – IA-box before new rules,  
  – rough M-score per role,  
  – D-question: does the measure strengthen or weaken dignity in practice (D₁/D₂)?

* **Self-clarification in transitions**  
  – role changes, public appearances, difficult conversations,  
  – clarification of levers, shared responsibility, desired self-treatment (D₁/D₂).

Mini-toolkit means:

> **Just enough structure to see more fairly –  
> without losing the case in spreadsheets.**

It prepares the ground so that the tools of chapter 7  
can later be applied **in lived practice** (chapters 8–11):  
as practical aids for making maturity in practice  
and dignity in everyday life more visible –  
not as a new form of esoteric code.

---

### 7.6 Praxeological final checklist

At the end of every analysis stands a final filter  
before something becomes “actionable” – as:

* decision,  
* document,  
* publication,  
* internal communication,  
* policy or guideline.

This is no longer about new data  
but about **how** we handle our own interpretation.

Core questions:

> **“Am I in reality – or in my projection?”**  
> **“Am I touching behaviour – or beginning to negotiate dignity?”**

The checklist gathers:

* satisfaction check  
* parameter check (A–C–R–P–D)  
* role check  
* projection alarm  
* publicity / multi-context  
* D-cleanliness  
* and the **Grail sentence**.

It is not a form but an **inner stance in question form**:  
a brief reality and dignity check before hitting “send”.

---

#### 7.6.1 Satisfaction as warning signal

Question: **How satisfied am I with my result?**

* very high  
* okay  
* low  
* chaotic

Warning:

> **“Too smooth” = suspicion of projection or role-polishing.**

If the picture fits too perfectly  
what I already believed,  
the likelihood of integrating new information is low.

D-indicator:

* If the dignity balances align “too nicely” in favour of my own role,  
  the risk of moral sorting increases:  
  – We appear mature, fair, dignity-sensitive –  
    the other side “naturally” immature and undignified.

Short vignette:

> A team analyses a conflict.  
> Result: all IA findings lie “on the other side,”  
> their own behaviour reads like a textbook.  
> The satisfaction check signals:  
> **Back to start; check blind spots.**

---

#### 7.6.2 Parameter check: A–C–R–P–D

**A – Awareness**

* Do I see what *I* do – or only what the others do?  
* Is my role awareness (A-R) clear?  
* Do I distinguish **knowing** from **guessing**?

**C – Coherence**

* Are relevant levels (social, institutional, cultural, symbolic) consistently included?  
* Are power relations made visible as coherence in power contexts (**C-P**)?  
* Have I reflected my own narrative layer (**C-N** = narrative coherence)?

**R – Responsibility**

* Where does my responsibility end – where does theirs begin?  
* Do I take over-responsibility – or systematically offload it?  
* Who holds interpretive power – and is that named?

**P – Power (power to act)**

* Do I confuse felt and actual agency?  
* Do I push others into roles/responsibilities  
  they structurally do not hold?

**D – Dignity in practice (D₁/D₂)**

* Do I keep clean:

  * **D₀ – ontological dignity** (inviolable personhood)  
  * **D₁ – self-dignity in practice**  
  * **D₂ – relational dignity in practice**?

* Am I speaking about **behaviour in context** – or am I beginning  
  to negotiate personhood?

* Are the guardrails for the D-module (3.5–3.7) met?  
* Is D even necessary here – or am I using it just because it “sounds stronger”?  
* Do I formulate **reversibly**, in ways that allow later correction and development?

Faulty D-use raises the risk  
of moral or symbolic degradation –  
even when “well-intended.”

---

#### 7.6.3 Role confusion – red alert

Three key questions:

1. **Do I know which role I am in?**  
   (leadership, affected person, colleague, researcher, facilitator …)

2. **Do I know which role the other assigns to me?**  
   (enemy, examiner, ally, “the system”)

3. **Does the other know which role I assign to them?**

If at least one question is unclear:

> **Role vacuum → phantom intention → escalation → D₂ damage.**

D₂ = relational dignity in practice:  
How people treat each other  
and position themselves publicly.

High risk of degradation arises especially when  
affected persons are suddenly treated like offenders,  
staff like “enemies”, or clients like “cases”,  
without explicit role clarification.

---

#### 7.6.4 Detecting projection

Questions:

* Am I interpreting more than was said or shown?  
* Do I “know” things never communicated?  
* Does my assessment stem from fear, hope, shame, anger?  
* Do I expect automatically to be understood  
  without making my frame explicit?  
* Am I using the model or D subtly  
  to legitimise my own superiority?

Every “yes” means:

> **Pause the analysis; check calibration.**

Especially critical:

* When D-evaluations merge with one’s own triggers, biographical shame  
  or moral reflexes, a **meta-reflective pause is mandatory**.  
* Analysing in strong emotion risks  
  **degrading others in the name of dignity**.

**Grail sentence (first version):**

> **“Am I touching behaviour – or beginning to negotiate dignity?”**

This question marks the boundary  
between what is praxeologically describable  
and what belongs to the inviolable domain of D₀.

---

#### 7.6.5 Publicity factor (A-P, P-PU, D-P)

Relevant for public spaces, art, social media, politics:

* ☐ Does behaviour **change before an audience** compared to private space?  
* ☐ Is there a **media or cultural meaning layer**  
  (memes, narratives, historical references)?  
* ☐ Any semantic contamination  
  (lyrics, images, codes carrying implicit meaning)?  
* ☐ Does the person carry **public responsibility** –  
  or is it attributed to them?

* ☐ Does the situation touch **D-P** (dignity in public enactment):

  – public shaming, outrage cycles, media exposure,  
  – self-branding, voluntary self-objectification,  
  – collective attributions of “honour” or “shame”.

Terms:

* **A-P** = awareness of publicity,  
* **P-PU** = power in public contexts,  
* **D-P** = dignity enactment under publicity.

> If **A-P** is ignored, public analyses are incomplete.  
> If **D-P** is ignored, degrading or dignity-protecting effects of publicity remain invisible.

---

#### 7.6.6 Multi-context situations

Check: which contexts are active simultaneously?

* ☐ private  
* ☐ public  
* ☐ cultural / symbolic  
* ☐ institutional  
* ☐ power-related  
* ☐ intimate / relational

The more levels active at once,  
the more carefully conclusions should be formulated.

**D-note:**

* Dignity can be strengthened in one context  
  and simultaneously injured in another –  
  e.g.:  
  – clear boundary-setting (D-strengthening) in a relationship,  
  – publicly read as “shaming” (D-injury).

Guiding question:

> **“On which level am I reading the dignity effect –  
> and on which level not?”**

---

#### 7.6.7 Coherence test via the other’s reaction

* ☐ Does the other behave coherently with the role I assign them?

  * **Yes** → model plausible.  
  * **No** → role likely misread.  
  * **Partially** → re-examine context or power dynamics.

Additional questions:

* ☐ Does the other respond with unexpected **shame, defiance, withdrawal or self-devaluation**,  
  even though I perceive my analysis as “neutral”?

* ☐ Could this mean that my use of the model or the D-module  
  is experienced as **degrading**?

> A mismatch between the other’s reaction and my internal picture  
> signals **blind spots** – not automatically the other’s “irrationality.”

---

#### 7.6.8 The “Grail sentence”

Finally, a radical question:

> **“Am I acting from my role –  
> or from fear, hope, projection,  
> or the need to elevate myself / degrade others?”**

If this cannot be answered cleanly:

> **→ Restart the analysis.**  
> Not because everything is wrong –  
> but because the calibration point is unclear.

**Hard rule:**

> **If the final checklist fails**  
> (central questions remain open, guardrails are violated,  
> projection dominates),  
> the analysis is **not praxeologically mature** for transmission.

It may remain as:

* **working note**,  
* personal thinking attempt,

but not as:

* neutral truth,  
* objective diagnosis,  
* or basis for structural decisions.

Thus the checklist protects:

* the **dignity** of those involved (D₀ and D₁/D₂),  
* the **integrity** of the model,  
* and the **maturity in practice** of those who apply it.

It is the small act of self-limitation  
that turns an analytical tool  
into a responsible procedure.

---

## 8) Domain Modules – Grids for Levels & Fields

The core model is **domain-agnostic**:  
A–C–R–P–D, the A-Score, the M-Score, the IA-Box, role logic and the dignity-in-practice module  
can be applied in many fields.

For practice, however, it is useful to make typical **“hotspots per domain”** visible:  
points at which maturity in practice, power and dignity repeatedly become especially sensitive.

> The domain modules do not introduce a new model  
> but **lenses**:  
> they mark **where** A–C–R–P–D regularly condense within a domain.

This chapter unfolds three example fields:

* Psychology (performative)  
* Philosophy & Religion  
* Sociology & Politics

Additional domains can be added following the same pattern.

---

### 8.1 Psychology (performative)

This module intentionally stays **outside clinical diagnostics**.  
It replaces:

* no diagnoses,  
* no disorder classification,  
* no therapy planning.

It asks only:

> **“What is the pattern of enactment – regardless of whether someone has a diagnosis?”**

Thus the module describes **observable enactments**,  
without pathologising or degrading people.

Typical application fields:

* self-exploration  
  (“How do I structurally react in conflict, closeness, stress?”),  
* coaching, supervision, counselling (within the red zones),  
* reflection on relational patterns without diagnostic vocabulary,  
* optional dignity reading in the sense of:

  – “How do I treat myself?”  
    (shaping my self-dignity in practice, D₁, stabilising or devaluing?)  
  – “How do I treat others in my close environment?”  
    (relational dignity D₂).

**Key parameters:**

* **A-I – inner awareness**:  
  contact with impulses, feelings, ambivalence.

* **A-R – role awareness**:  
  “Who am I here – partner, parent, colleague, superior, client?”

* **R-I – individual responsibility**:  
  one’s own share vs. pure externalisation.

* **P-I – inner agency**:  
  experienced self-efficacy, ability to take small reversible steps.

* **D-I** (optional) – inner dignity as part of self-dignity in practice (D₁):  
  self-care vs. self-devaluation.

**Typical IA patterns:**

* **role vacuums in relationships**  
  (projections, phantom intentions, dignity injuries in close settings).

* **responsibility over-assumption / avoidance**  
  (hyper-responsibility + self-devaluation vs. complete externalisation).

* **experienced powerlessness despite real options**  
  (felt vs. actual agency; P-I low although options exist).

*Mini-vignette:*

> Anna, a team lead, experiences every team conflict as “failure.”  
> She assumes responsibility (R-I) even where others have clear shares  
> and speaks internally in self-devaluing ways.  
> The module helps to distinguish:  
> **A-theme** (how she acts),  
> **M-theme** (how much shared responsibility she structurally carries),  
> **D-theme** (how she treats herself in practice).

The module works **performatively**, not diagnostically:

* It describes patterns: avoidance, role mixing, failing to mark contexts, making oneself small.  
* It asks:  
  – “What do you do when …?”  
  – “Which role do you then take?”  
  – “How do you treat yourself before, during and after the situation?” (D₁/D₂)

**Dignity note:**

* Dignity profiles in this domain are strictly **self-referential** or **safely framed**.  
* They must **never** be used as labels  
  (“you lack dignity”, “you have no self-respect”),  
  but only as descriptions of **enactments that can change**.

---

### 8.2 Philosophy & Religion

Philosophy and religion are fields in which humans attempt to organise  
**truth, meaning, good/evil and dignity**.  
They shape big concepts, tell stories, design rituals –  
thereby creating frameworks through which people read themselves and others.

This module is **not** concerned with whether certain teachings are “true.”  
It asks praxeologically:

> **How do specific philosophical or religious orders  
> organise interpretive authority, responsibility and dignity in practice?**

This makes visible when a tradition **fulfils** its own dignity claims –  
and when it **undermines** them in practice.

---

#### Ontological dignity vs. the dignity-in-practice module

Many traditions recognise a form of **ontological dignity** –  
e.g., as imago, as rational being, as created or willed by the divine/absolute.

In the model this is:

* **D₀ – ontological dignity**  
  – inviolable personhood,  
  – not gradual,  
  – not “earned,”  
  – outside all evaluation.

The model adopts D₀ as **untouchable constant**.

The **dignity-in-practice module** instead asks praxeologically:

* **D₁ – self-dignity in practice**  
  – how people treat themselves  
    (self-care, self-devaluation, ascetic practices, guilt regimes …)

* **D₂ – relational dignity in practice**  
  – how people treat others in the name of a teaching  
    (inclusion, exclusion, shaming, recognition, handling doubt)

In short:

> **D₀ says: “You are dignified.”  
> D₁/D₂ ask: “How do you – and how do we – practically act with this dignity?”**

---

#### Core questions in this module

* Is D₀ **proclaimed**, yet systematically undermined in practice?  
* Are people marked as “unworthy” **beyond specific actions**?  
* Are guilt, shame and purification framed such that D₁ stabilises –  
  or such that lasting self-devaluation is fostered?  
* Can people leave or change roles **without** losing relational dignity in practice (D₂) permanently?

*Mini-vignette:*

> A community teaches: “Every human has inviolable dignity.”  
> At the same time, people who leave are publicly labelled “traitors,”  
> and contact with them is deemed “spiritually dangerous.”  
> Praxeologically, D₀ remains asserted,  
> but D₂ is severely violated in practice.

---

#### Key parameters

In philosophical–religious fields, the following matter:

* **C-N – narrative coherence**  
  – Which dignity/indignity archetypes appear in stories?  
  – Who is allowed to fail and be reintegrated – who is not?

* **R-E – ethical responsibility**  
  – Who sets norms?  
  – Who defines “sin,” “error,” “holiness”?  
  – What practical consequences do these definitions have?

* **P-C – cultural agency**  
  – Who defines symbols, rituals, teachings?  
  – Which groups can revise them – which cannot?

* **A-C / A-R – context and role awareness of interpreters**  
  – Do those speaking know **which role** they speak from  
    (pastoral, doctrinal, power position)?  
  – Are they aware of the reach of their words (culture, media, family systems)?

* **D-R – relational dignity**  
  – How are seekers, doubters, “sinners,” ex-members treated?  
  – Are they accompanied, shamed, excluded, instrumentalised?

---

#### Typical IA risks

* **non-transparent authority**  
  – “It is so because we say so,” without reason that can be examined.

* **unbounded interpretive authority**  
  – a small group defines what counts as “dignified/undignified”  
    without review mechanisms.

* **irreversible stigmatisation**  
  – once cast out, “forever lost,” with no real path to return or redefine  
    (violation of T-J-TB-R).

* **praxeological degradation despite dignity rhetoric**  
  – public shaming rituals,  
  – forced confession,  
  – spiritually justified violence or neglect.

---

#### The dignity guardrail in this module

The model does **not** judge who is “dignified before God / the Absolute,”  
nor does it prescribe doctrinal correctness.

It describes only:

* **how** people treat each other in practice,  
* **how** maturity in practice (A), shared responsibility (M) and dignity enactments (D₁/D₂)  
  are embedded in structures and rituals,  
* **where** degradation is systematically embedded  
  and where dignity is practically upheld.

Closing question for this module:

> **Do certain philosophical or religious forms  
> strengthen maturity and dignity in practice –  
> or do they create wounds later framed as an individual’s “private problem”?**

---

### 8.3 Sociology & Politics  
*(including symbolic politics, IA/D heatmap)*

In the sociopolitical field we observe  
how entire societies handle asymmetries:

* Who has power and resources?  
* Who defines problems and solutions?  
* Who bears the costs?  
* And: **Who can afford which dignity enactment?**

This module focuses **not** on single individuals but on:

* **institutions** (state, administration, parties, associations …),  
* **political processes** (legislation, campaigns, negotiations),  
* **discourses** (public debate, narratives, media framing),  
* and their effects on dignity in everyday life  
  (**D₂ – relational dignity**, **D-P – dignity in public enactment**).

---

#### Key parameters

Central parameters in this field:

* **C-P – coherence in power contexts**  
  – Who can formally/informally set and change rules?  
  – Which actors have structural advantages?

* **R-P – public responsibility**  
  – Who carries responsibility for consequences affecting many  
    (laws, cuts, security decisions)?

* **P-PU – public agency**  
  – Who has reach, resources, media access, enforcement tools?

* **A-P – awareness of publicity**  
  – How aware are actors that their speech and enactment  
    are publicly read, archived and reinterpreted?

* **D-R / D-P – relational and public dignity**  
  – Which groups are elevated, degraded, stigmatised or protected?  
  – Where is dignity practically safeguarded (rights, protections) –  
    and where undermined (stigma, shaming, invisibilisation)?

---

#### Symbolic politics

Symbolic politics means:

> **Actions that primarily create meaning** –  
> but have limited or indirect material impact.

Examples:

* flags, commemorations, minutes of silence,  
* appeals, statements, resolutions,  
* “sending messages” on social media.

The model asks:

* Is symbolic politics **transparent** as symbolic –  
  or sold as the “actual solution”?  
* Is it **justified** – which protected good is pursued  
  (minority protection, mourning, position-taking)?  
* Is it **time-bound** – or used to permanently replace structural work?  
* Is it **reversible** – can the symbol be questioned, modified or ended  
  without criticism being cast as betrayal?

IA alarms appear:

* when symbolic acts **mask real responsibility**,  
* when costs of symbolic actions fall mainly on weaker groups,  
* when interpretive authority over symbols is highly uneven  
  (**C-P / P-PU** high, **A-P / D-P** of affected groups low),  
* when symbolic politics produces **dignity effects** that remain unnamed:  
  – groups marked as “problem,” “danger,” “burden,”  
  – suffering symbolically “performed” but not practically addressed.

*Mini-vignette:*

> A city declares a “Year of Dignity” and fills public space with slogans.  
> Simultaneously, social budgets are cut, support centres close,  
> and affected people are barely heard.  
> The IA-Box shows: high symbolic intensity, low structural responsibility;  
> the D₂ of those affected declines.

Dignity reading:

* Symbolic politics can **protect dignity**  
  – e.g., by making visible who deserves protection  
    and which groups must no longer be ignored.

* It can also be **degrading**,  
  when people are reduced to **symbols** (images, hashtags, “the affected”)  
  while real transfers of agency (P), responsibility (M) or resources do not occur.

---

#### IA/D Heatmap

The **IA/D heatmap** is a tool to visualise concentrations of:

* **inaduct asymmetry (IA)** and  
* **praxeological degradation (D₁/D₂, especially D-P)**

within a social or political field.

It asks:

* Where in the system do we see clusters of:

  * non-transparent power decisions,  
  * un-/pseudo-justified privileges,  
  * unbounded or irreversible sanctions,  
  * forms of public degradation (D-P as expression of D₂),  
  * zones of systematic self-devaluation of certain groups  
    (e.g., poverty, stigma, exclusion)?

Practically:

* Results from **A-Score**, **M-Score**, **IA-Box** and **dignity profiles**  
  are plotted spatially or institutionally,  
* areas with high density of IA and dignity violations “glow” – become “hot.”

Distinction:

* **IA hotspots**  
  – structures are built problematically  
    (power, responsibility, knowledge, reversibility poorly distributed).

* **Dignity hotspots**  
  – enactments, discourses and practices degrade people in daily life  
    (e.g., ongoing ridicule, selective visibility, permanent deficit marking).

These zones are:

* indicators of **reform need**,  
* warning signs for future escalations,  
* priority areas for protection, monitoring and participation.

Closing lens:

> The Sociology & Politics module prevents the model  
> from being misunderstood as merely “psychological.”  
> It directs attention to **power and structural architecture** –  
> including the question:
>
> **“Which people/groups must live in which ways  
> for our structures to remain stable – and at what dignity cost?”**

---

### 8.4 Culture / Media

In culture and media, the model is especially sensitive to:

* role images,  
* narratives,  
* representation,  
* publicity effects,  
* **normalisation or erosion of dignity in practice**  
  (especially D-R – relational dignity, and D-P – dignity in public enactment).

Culture and media work through stories, images and atmospheres.  
They shape what we imagine as “normal life,” a “good relationship,”  
a “successful person” – indirectly shaping what counts as dignified or as “your own fault.”  
Thus this module is less art criticism and more a grid for **how** cultural products  
make IA-patterns and dignity enactments visible, invisible or “cool.”

Objects of analysis may include:

* **characters and stories** (fiction, series, films, games),  
* **cultural debates** (reviews, controversies),  
* **media practices** (platform rules, algorithms, gatekeeping),  
* **self-presentation** (influencing, personal branding, mediated self-objectification).

**Key parameters:**

* **C-N – narrative context**  
  – What archetypes, roles, conflicts are shown?  
  – Which forms of dignity/degradation appear “normal,” “deserved,” “funny”?

* **A-P / P-PU**  
  – How visible is something, how large its effect on perception?  
  – How aware are creators that their enactments enter public dignity dynamics?

* **P-C – cultural agency**  
  – Who can introduce and normalise images, metaphors and tropes?

* **R-P / R-E**  
  – What responsibility is taken for the patterns being shown –  
    especially where they shape dignity images?

* **D-P – public dignity enactment**  
  – How are people, groups, minorities represented?  
  – Are they portrayed as full subjects – or as joke, threat, object?  
  – Are characters given chances to regain dignity in practice  
    (repair, apology, restoration),  
    or kept fixed in degrading roles?

Typical questions:

* Which **role images** are stabilised  
  (e.g., gender, power, relational models)?

* Are the asymmetries portrayed:

  * **reflected** (as tension, problem, learning arc),  
  * or **romanticised / trivialised** (as “normal,” “exciting,” “inevitable”)?

* How do creators handle their **public responsibility**  
  when characters/themes strongly resonate?

* Which **dignity patterns** are portrayed as desirable or ridiculous?

  – self-care vs. self-sacrifice,  
  – boundary-setting vs. “selfless devotion,”  
  – degrading others vs. empathy.

*Mini-vignette:*

> A popular series portrays a character who constantly humiliates others publicly –  
> celebrated as “witty.”  
> Across seasons this pattern remains unchallenged.  
> Praxeologically, a D-P profile emerges in which subtle humiliation  
> is coded as humor and strength –  
> allowing IA and degradation to “travel” culturally.

The module enables, for example:

* discussing works not merely as “I like it / I don’t,”  
  but as **structural proposals for reality**:  
  – Which IA-patterns are reproduced?  
  – Where does culture show alternatives, corrections, learning pathways?  
  – Which practices of **dignity restoration**  
    (apology, repair, reframing) appear?

It leaves open whether a portrayal is “good” or “bad,”  
but it makes the **structure of roles, responsibility and agency** visible  
that travels through culture into minds and practices –  
including images of:

> **“Who counts as dignified – who may be funny, weak, vulnerable  
> without being dehumanised?”**

For practice this means:

* Cultural/media analysis using this module can succinctly reveal  
  **which enactments are normalised** –  
  and which alternatives are absent.

* It invites attention to narratives that strengthen  
  **dignity in practice**,  
  rather than recycling degradation as entertainment.

---

### 8.5 Practice Ethics (Law / Organization / Education)

Here the model encounters fields in which:

* asymmetries are **institutionally intended**  
  (legal systems, organizations, schools, care structures),
* norms and sanctions are **encoded**,
* responsibility and power (power to act) are **formally assigned**,
* and **dignity** is explicitly named as a protected good — yet can easily be undermined in practice.

Praxeological question:

> **Are these asymmetries functionally built — or drifting into inadult forms  
> in which protection and dignity are asserted but not enacted?**

This is precisely where it becomes visible whether noble mission statements  
(“respect human dignity,” “empower children,” “leadership at eye level”)  
hold up in everyday practice — or whether structures and routines  
produce the opposite.

**Key parameters:**

* **C-I (institutional / rule coherence)**  
  – How coherent are rules, their justifications, and lived practice?

* **R-S / R-P (social / public responsibility)**  
  – Who carries responsibility for the wellbeing of those with less power?

* **P-S / P-PU (social / public agency)**  
  – Who can intervene, limit, or protect in concrete situations?

* **A-P / A-R (public and role awareness)**  
  – How clearly are roles understood  
    (judge/defendant, teacher/student, leader/employee)?

* **D-R / D-P (relational and public dignity in practice)**  
  – How are people in vulnerable positions treated  
    (accused persons, clients, children, employees, patients)?  
  – Are there clear protections against humiliation, shaming, degradation in practice?

Typical application fields:

* **Law:**  
  – Are sanctions, procedures and powers  
    transparent, justified, time-bound, and reversible?  
  – Where do structures emerge that permanently stigmatize people  
    without real rehabilitation pathways?  
  – Are there mechanisms that protect dignity in practice:  
    – respectful speech,  
    – avoidance of unnecessary exposure,  
    – clear separation between criticism of an action and degradation of a person?

*Mini-vignette (Law):*

> A person appears in court and is addressed respectfully,  
> yet is held in overcrowded group cells and exposed to media presence  
> without necessity.  
> Structurally, the procedure may be lawful,  
> but praxeologically a D-P problem emerges:  
> dignity in practice during the process contradicts the rhetoric of respect.

* **Organizations** (companies, administrations, NGOs …):  
  – How are leadership roles, goal conflicts and performance pressure structured?  
  – Are protection mechanisms for weaker parties (employees, clients) functional or merely formal?  
  – Where do degrading practices emerge:  
    – public disparagement,  
    – “naming & shaming,”  
    – subtle humiliation in feedback settings?

* **Education:**  
  – How are power and knowledge asymmetries between adults and children/youth shaped?  
  – Are there traceable, reviewable pathways out of sanctions, role fixations, labels?  
  – Is discipline designed such that **behaviour** is addressed — not the **value of the person**?

The Practice Ethics module directly connects to the M-Score, the ceiling rule,  
and the dignity-in-practice module:

* **High M-Scores** typically belong to:

  * institutional carriers,  
  * leadership levels,  
  * norm setters (law, guidelines, curricula).

* **Low M-Scores** typically belong to:

  * children,  
  * dependent persons,  
  * people without real alternatives.

Dignity reading:

* Dignity in practice (D) is shaped **institutionally** in these fields:  
  – through procedural logic,  
  – through language,  
  – through symbolic forms (rituals, clothing, spaces),  
  – through complaint and correction channels.

The central question here becomes:

> **Are our asymmetric practice structures built in ways  
> that promote learning, protection, development and dignity in practice —  
> or do they cement IA and degradation that is no longer functional?**

Guardrail:

* The model may be used to mark **structures**  
  as dignity-protecting or dignity-undermining,  
* not to label individuals in the system as “dignified/undignified.”

For readers this means:

* Anyone carrying responsibility in law, organizations or education  
  can use this module to examine very concretely  
  **where** structures are adult in design —  
  and **where** they produce IA and dignity breaches  
  even when no one “means harm.”  
* Thus, practice ethics becomes a question of  
  **the architecture of enactments**,  
  not merely of intentions.

---

## 9) Bias, Intuition & Norm Change

The model pretends that reality can be seen **more clearly**  
when A–C–R–P and dignity are examined structurally.  
At the same time, it is obvious:

* No one perceives without distortion.  
* No one decides purely rationally.  
* Norms themselves shift over time.  
* Ideas of **dignity** are historically, culturally and biographically shaped.

This chapter deliberately marks the **limits of our view** —  
and thus the conditions under which the model can be used in an adult way:

* including the danger that A–C–R–P–D is used  
  to absolutize one’s **own** dignity concepts.

One can read this chapter as:  
“What we must concede to ourselves so the model becomes a learning tool  
and not a weapon.”

---

### 9.1 Bias: unavoidable distortions

“Bias” here means:

> **systematic, recurring distortions in perception, evaluation and memory**  
> that cannot be explained by isolated errors.

Relevant bias types in the model’s context:

* **confirmation bias**  
  – we search for what confirms our starting hypothesis,  
  – we overlook contradictory signals,  
  – danger for dignity-reading: we “find proof” that someone is “immature” or “undignified”  
    instead of seeing ambiguity.

* **hindsight bias**  
  – afterwards, many things appear “predictable,”  
  – reality is smoothed retroactively (“of course it was obvious…”),  
  – predictability is overestimated → M-Score tends to rise,  
  – danger for dignity: affected persons are **retrospectively shamed**  
    by attributing insights they could not have had.

* **status quo and loyalty bias**  
  – existing structures feel “normal,”  
  – loyalties in organizations, families, milieus protect old patterns from critique,  
  – danger for dignity: degrading practices become “just how things are,”  
    dignity claims appear oversensitive.

* **halo / horn effects**  
  – one trait (charismatic, likable, competent, “on our side”)  
    colors the whole assessment,  
  – maturity is “granted” or systematically denied,  
  – danger for dignity: favourites get a **dignity bonus**,  
    others a **dignity penalty**.

* **in-group / out-group bias**  
  – “our” people are judged more generously,  
  – “the others” more harshly,  
  – identical enactments receive different A- and M-Scores  
    and opposing dignity interpretations (“courageous” vs. “antisocial”).

*Mini-vignette:*

> A team evaluates a conflict.  
> A beloved colleague’s harsh tone is seen as “an unusual slip,”  
> a disliked colleague’s identical tone as “proof of her true character.”  
> Structurally identical enactment — the bias distribution decides the A and dignity reading.

For the model this means:

* Bias is **not an exception**, but baseline noise.  
* It cannot be eliminated, but it can be **marked**:

  * Where might I be seeking confirmation?  
  * Where am I turning “in hindsight visible” into “you should have known”?  
  * Where am I protecting structures I depend on?  
  * Where am I using dignity readings to stabilize group or role images?

Thus:

> **Bias-awareness is part of A (awareness)** —  
> ignoring it means working ideologically, not praxeologically,  
> especially where dignity in practice is at stake.

The next section (9.2) addresses a special form of “internal data”: intuition.

---

### 9.2 Intuition: enemy or sensor?

“Intuition” here refers to:

* fast, dense impressions,  
* deep condensation of experience, implicit knowledge,  
* often not yet articulable.

In the model, intuition is **neither** enemy **nor** oracle.

Praxeological stance:

> Intuition is a **sensor**, not a judge.

**When is intuition valuable?**

* in **danger perception** (early warning signals: “something is off”),  
* in **resonance checks** (“the claim doesn’t match the effect”),  
* with **people and situations known for a long time**,  
  where implicit patterns already exist,  
* with subtle dignity signals:  
  – “This feels degrading even though no one raises their voice,”  
  – “Someone is being diminished, even if framed as a joke.”

**When is intuition risky?**

* in **complex structural questions** (law, politics, organization),  
* in **unfamiliar milieus** and cultures,  
* in situations where one’s own issues are highly active  
  (hurt, fear, over-identification),  
* when intuition is translated directly into **dignity judgments**:  
  – “He’s simply undignified,”  
  – “You can’t take someone like that seriously.”

*Mini-vignette:*

> In a meeting someone instantly senses: “The tone is wrong.”  
> Intuition signals: something is drifting toward degradation.  
> Instead of concluding “the boss is toxic,”  
> the model asks:  
> “What exactly is happening between role, power, language and dignity enactment?”

The model proposes not “emotion vs. rationality,” but division of labour:

* Intuition may **trigger** the IA-analysis (“Look closer here!”).  
* The **analysis** (A–C–R–P–D, IA-Box, A/M, RVR(t)) structures the issue:  
  – What exactly is disturbing?  
  – Is it real IA or degradation — or my own story?  
  – Which role, responsibility, power and dignity dynamics are present?

Key maxims:

> **Intuition may start the analysis —  
> but must not end it.**

and, regarding dignity:

> **Intuition may sense a dignity violation —  
> but must not alone judge a person’s dignity.**

Thus intuition is not interference,  
but an input channel that must be **translated explicitly**  
before decisions or dignity profiles are drawn.

---

### 9.3 Norm change: a moving target

Norms are not static:

* What counts as “normal,” “acceptable,” “fair,” or “dignified”  
  shifts over time — culturally, generationally, discursively.

This creates a challenge:

> **How can a model assess maturity and dignity in practice  
> when norms constantly shift?**

The model’s answer:

1. It measures primarily **structural features** (A–C–R–P–D, IA-Box, M-Score),  
   not the content of specific norms.

   – Transparency can be examined across different norm landscapes.  
   – Justification, time-boundedness, reversibility do not depend  
     on whether a norm is “progressive” or “conservative.”  
   – Dignity is not measured as “correct attitude,”  
     but as **quality of enactment** relative to available options.

2. It treats norm change as **part of the analysis**:

   – Which norms were **plausible then**, given knowledge and discourse at the time  
     (including dignity concepts)?  
   – Which norms apply **now** — and why?  
   – Who claims that “now” something “always should have been” unacceptable?  
   – Where do we confuse a **symbolic shift** with an actual shift  
     in dignity practices (treatment of affected persons, alternatives, reversibility of stigma)?

3. It guards against two traps:

   * **Overwriting the past with current norms**  
     — condemning everything before (“how could they…”)  
       without acknowledging missing alternatives.

   * **Freezing the present with past norms**  
     — dismissing critique as “oversensitive,”  
       ignoring new knowledge, protections and dignity dimensions.

4. It marks that **dignity readings (D₁/D₂) are culturally situated**:

   – Self-sacrifice may be seen as a **source of dignity** in one context,  
     and a **D₁ violation** in another.  
   – Direct confrontation may read as **D₂ strengthening** in one group  
     (clear boundaries), and as **“disrespectful”** in another.  
   – Self-care may appear mature, selfish or necessary,  
     depending on the culture.

   Therefore every dignity interpretation in the model is accompanied by  
   **role, context, milieu and norm background**.  
   D₁/D₂ do not claim a universal doctrine of dignity — only:

   > “How does this enactment appear **from this perspective**,  
   > with this cultural lens named?”

An adult use:

* acknowledges that norms — including dignity concepts — **move**,  
* still checks whether, within a historical or cultural context,  
  **maturity in practice** was possible:

  – Was available knowledge used (A)?  
  – Were affected persons heard (A-P, D-R, D-P)?  
  – Were there unused decision paths (P, M-Score)?  
  – Did people have real alternatives — or were they trapped (ceiling rule)?  
  – From which **normative position** is D₁/D₂ being read?

A central adulthood criterion becomes:

> **“I do not know what it feels like to be you in your culture —  
> I describe only what I see in the enactment  
> and name my own lens.”**

Thus norm change is not an obstacle but **subject matter**:

> The model reveals **who** shifts norms — including dignity images —  
> in which direction,  
> with which structural tools,  
> and with which IA patterns and dignity effects.

This sets the stage for Chapter 10:  
There the main counterarguments are presented,  
and the model must measure itself against its own standards.

---

### 9.4 Working with the model: protocol & meta-attitude

The previous sections showed how strongly bias, intuition and norm change color every analysis.  
If these factors are only briefly acknowledged, they appear as background noise —  
not as part of the actual work.

To integrate bias, intuition, norm change and **dignity readings**  
(self-/relational dignity interpretations) into the method, two things are needed:

1. **Documentation**  
2. **Meta-attitude**

#### 1. Documentation

In the Case-Lens process we mark:

* Where did **intuition** enter?  
* What **bias risks** do I/we see?  
* Which **norm assumptions** (explicit/implicit) steer the analysis?  
* Which **dignity readings (D₁/D₂)** do I use:  
  – What do *I* call dignified/degrading — and from which cultural/biographical lens?

A simple “Meta Notes” block at the end of the scorecards is enough:

* “Likely personal biases: …”  
* “Norm assumptions influencing this analysis: …”  
* “Intuition: … / checked afterwards? yes/no.”  
* “Dignity reading: Which enactments *I* experience as (un)dignified —  
  and could someone else see differently?”

*Mini-vignette:*

> A team enters a contentious decision into the Case-Lens.  
> At the end, someone notes:  
> “Intuition: X is unfair — high loyalty bias, I dislike X.”  
> This does not automatically change the conclusion,  
> but it records that the analysis does **not** arise from neutrality,  
> but from a situated perspective.

Thus:

> Applying the model is itself **a practice**,  
> not a neutral observer stance.

#### 2. Meta-attitude

Meta-attitude means:

* no claim to final truth,  
* willingness to revise analyses,  
* active search for **counterexamples** and **alternative perspectives**,  
* explicit invitation to critique (see Chapter 10),  
* awareness that my dignity readings  
  are never a person’s “true worth,”  
  but an interpretation of an **enactment**.

In short:

> The model is only as adult  
> as the people who treat their own distortions,  
> norm assumptions, and dignity concepts  
> as **part** of the analysis.

And:

> Those who use dignity (D₁/D₂) without this meta-attitude  
> quickly fall back into  
> exactly what the model was built to avoid:  
> moral labeling instead of praxeological understanding.

Logical consequence:

> The next chapter gathers the main counterarguments —  
> and tests the model against its own claims.

---

## 10) Countercritique & Response

A model that aims to examine maturity, responsibility, asymmetry  
**and** dignity in practice  
must accept critique — otherwise it would itself be inadult.

This chapter gathers major objections  
from other disciplines, practitioners or affected persons  
and sketches how the model responds —  
or where it simply acknowledges its **limits**.

One may read it as a stress test:  
*What happens when we examine the model using its own tools — roles, IA, dignity?*

---

### 10.1 “Isn’t this just a new morality machine?”

**Critique:**

> “You pretend to measure structure,  
> but in the end it’s just a new morality —  
> now even with a dignity-in-practice module.”

**Response:**

1. The model does **not** set a substantive moral agenda.

   – It does not say which political, religious or cultural positions are “right.”  
   – It asks: *How transparent, justified, time-bound, reversible* is an enactment —  
     **within** its chosen norms and roles?

2. It explicitly separates levels (Chapter 1):

   – structural level (A–C–R–P–D, IA-Box, M-Score),  
   – moral-normative level (values, morality, theology, ideology),  
   – psychological level (performative),  
   – narrative-cultural level.

   This separation exists precisely to keep normativity **visible**  
   instead of hiding it behind claims of “objectivity.”

3. The dignity-in-practice module:

   – takes **ontological dignity (D₀ – ontological dignity)** as non-negotiable (humans remain dignified),  
   – treats **dignity in practice (D₁/D₂)** as a property of enactment:  
     *“How do people treat themselves / others / the world?”*  
   – forbids turning D-observations  
     into **person-level judgments**.

4. Where the model uses normative language (e.g., protected goods, dignity),  
   it names this openly.  
   It does not pretend to be norm-free —  
   it works with **explicit norm visibility**.

Summary:

> Yes, the model *can* be used moralistically —  
> but its strength lies in **separating** morality, structure and dignity practice,  
> not in disguising morality as structure  
> or using dignity as a weapon.

---

### 10.2 “Can maturity even be measured?”

**Critique:**

> “Maturity, responsibility, awareness, dignity —  
> these are qualitative phenomena.  
> How can you put them on a 0–10 scale without betraying them?”

**Response:**

1. The model does not claim  
   **precise measurement**,  
   but **structured estimation**.

   – A-Score is a **band**, not a digital value.  
   – It’s about “more 3–4 than 7–8,” not “3.27.”  
   – Dignity (D₁/D₂) is **never** scored —  
     it remains qualitative (profiles, descriptions).

2. Each estimation is **parametrized**:

   – A–C–R–P–D axes,  
   – modulators,  
   – roles,  
   – context,  
   – RVR(t),  
   – and, if activated, observable dignity enactments  
     (self-care, self-devaluation, degrading others, protest).

   Every assessment is tied to **observations and assumptions**  
   — open to critique.

3. Without structured estimation,  
   judgments exist anyway — just unexamined:

   – “He acted immaturely.”  
   – “She’s to blame.”  
   – “That was undignified.”

   The model makes such judgments **auditable** —  
   including the meta-question:  
   *“Am I judging conduct — or essence?”*

Summary:

> We cannot measure maturity or dignity like temperature —  
> but we can make maturity and dignity judgments  
> **less arbitrary**.  
> That is the purpose of A-Score, M-Score and dignity profiles.

---

### 10.3 “Danger of misuse”

**Critique:**

> “This model can easily be weaponized:  
> against weaker people, to justify coercion,  
> to blame victims, to discipline —  
> and with the dignity-in-practice module, now even to stigmatize as ‘undignified.’”

**Response:**

1. The critique is **valid**.

   – Any differentiation tool can be weaponized  
     (psychology, law, statistics, diagnostics).  
   – The model not only acknowledges this risk —  
     it embeds it into **red zones**, the **ceiling rule**,  
     **dignity safeguards** and the **final checklist**.

2. Red zones prohibit use in:

   – clinical diagnostics,  
   – HR decisions,  
   – forensic settings,  
   – public shaming,  
   – child/youth diagnostics,  
   – any context that labels persons as “undignified.”

3. Ceiling rule:

   – Without **predictability** and **alternatives**,  
     high M-Scores are impossible.  
   – This structurally reduces victim-blaming.

4. Dignity guardrail:

   – Dignity describes **enactments**, not inherent worth.  
   – “Acting in a degrading way” ≠ “undignified human being.”  
   – Dignity profiles are optional, not default;  
     they are strictly protected from misuses such as  
     humiliation diagnostics.

5. Never “automatic”:

   – The model is a tool, not an automated decision engine.  
   – It assumes **minimal adulthood** of the user.  
   – Anyone applying the model is **co-implicated** (self-analysis):  
     – How do *I* handle power, responsibility, dignity  
       while examining others?

*Mini-vignette:*

> An organization wants to use the model to systematically identify “low performers.”  
> Their plan: link A- and M-Scores with performance metrics  
> and make the results public.  
> Model logic flags multiple IA risks:  
> red zone (HR decisions), missing dignity guardrails,  
> confusion of enactment with person worth.  
> A mature use would instead examine leadership  
> using A/M logic — not rank vulnerable staff.

Summary:

> Yes, the model *can* be misused —  
> like any powerful tool.  
> That is why it contains more built-in safeguards  
> than many comparable frameworks:  
> red zones, guardrails, ceiling rule, dignity protection, final checklist.  
> Ignoring these means not “using the model,”  
> but **violating its core**.

---

### 10.4 “Too subjective / too complex / too time-consuming”

**Criticism 1:**

> “In the end everything depends on the person who evaluates – that’s subjective.”

**Criticism 2:**

> “Reality is too complex; nobody has time to do this in practice.”

**Response line:**

1. Subjectivity is **not denied**, but **documented** (see 9.4):

   – Who is evaluating? In which role?  
   – Which normative assumptions are in play?  
   – Which biases are likely?  
   – How do I read D – from which biographical and cultural lens?

   Transparent subjectivity is more mature  
   than masked objectivity.

2. The model offers **different depth levels** (chap. 7.5):

   – Quick-check → a few minutes.  
   – Mini-toolkit → 30–60 minutes.  
   – Full lens → workshops, audits, book cases.

   Nobody has to run the full program every time.  
   The D module is additionally **optional**:  
   it is only activated where it **helps** – not where it would add more shame.

3. Complexity is not “resolved” but **ordered**:

   – roles, contexts, asymmetries, responsibility points, D dynamics.  
   – This at least clarifies **types of error**:

     – Where did I overinterpret?  
     – Where did I overlook inadult asymmetry?  
     – Where did I ignore dignity effects?

Conclusion:

> The model is not an efficiency tool for quick judgments –  
> but a decelerator for situations  
> in which speed causes more harm than benefit.  
> And it forces you to separate your own D instincts  
> from structural analysis.

---

### 10.5 “What the model does not promise”

In closing, the model explicitly names its **limits**:

It does **not** promise:

* to recognize people “truthfully”.
* to determine inner life or motives unambiguously.
* to guarantee justice.
* to replace therapy or healing.
* to resolve conflicts automatically.
* to settle questions of guilt definitively.
* to deliver “morally correct” politics, religion, culture, or relationships.
* to decide **who** is “worthy” or “unworthy” –  
  **D₀ (ontological dignity)** remains untouchable and outside any evaluation.
* to determine universally what counts as dignified in *every* culture –  
  D₁/D₂ as praxeological forms of dignity in practice are **context-bound readings of practice**, not a global doctrine of dignity.
* to explain clinical, neurodiverse, or trauma-related patterns of practice –  
  these lie **outside the model** and must not be interpreted via D₁/D₂ or A/M.

It only promises:

* to make patterns of practice structurally **clearer**,
* to make **inadult asymmetries** visible and discussable,
* to distribute responsibility **more fairly**,
* to open spaces for reflection,
* to mark blind spots in questions of power, roles, and dignity,
* to make one’s own and others’ judgments of maturity and dignity **more reviewable**,
* to keep cultural and normative lenses **visible**,
* and to prevent D from becoming a moral weapon, instead making it readable as a **parameter of practice**.

And it submits itself to the same standard:

> **Maturity in practice** applies to this model as well.  
> It remains a working draft –  
> open to counterexamples, revisions, and better proposals.

---

### 10.6 Specific criticism of the D module (anticipation & response)

The D module is the **most sensitive part** of the model.  
It touches questions of:

* self-worth,
* shame,
* practical degradation,
* social exclusion.

Accordingly, it is obvious that **specific objections** will arise here that go beyond the general criticism of A and M scores.

The following sketches typical lines of critique – together with how the model responds to them or acknowledges its limits.

---

#### 10.6.1 “You are becoming the dignity police.”

**Criticism:**

> “If you describe D patterns of practice, you end up deciding  
> what is dignified or undignified.  
> That’s a new form of moral policing – just in technical jargon.”

**Response line:**

1. The model separates **ontological** from **praxeological** dignity (see 2.6–2.7, 3.5):

   * **Ontological dignity (D₀ – ontological dignity):**  
     Every human being remains **unconditionally dignified** – regardless of behaviour.  
     → the model **never** touches this.

   * **Praxeological dignity in practice (D₁/D₂):**  
     People can **act in ways** that degrade or protect themselves or others.  
     → that is observable practice, not a statement about their being.

2. The D module describes:

   > **“How does someone treat themselves / others?”**

   – not:

   > “How much is this person worth?”

   Anyone who turns D patterns of practice into judgments about persons (“an unworthy human being”) **leaves** the model and violates the dignity-protection guardrails (3.5).

3. The module is **optional** (3.6):

   * D is only activated when it is clear that it brings **more clarity than shame**.  
   * It may never be assumed as obligatory (“a ‘proper’ analysis must use W”), but remains an additional raster for cases in which dignity effects are explicitly on the table.

4. The **D profile card** (7.2.4) deliberately avoids numbers  
   and works with qualitative bands and keywords –  
   precisely to avoid any impression of a “dignity ranking”.

Conclusion:

> The D module does not want to control **who** is dignified,  
> but to make visible **how** dignity in practice is violated, defended, or refused –  
> in structural, reversible, and criticisable ways.

---

#### 10.6.2 “You claim to know what is ‘dignified’.”

**Criticism:**

> “Dignity is highly varied across cultures, biographies, and religions.  
> How can you claim to know better  
> what is dignified or undignified for others?”

**Response line:**

1. The model does **not** set up a complete theory of dignity (see 1.1, 8.2):

   * It does not claim to know universally what a “good life in practice” is.  
   * It works with a **minimal concept**:

     – a minimum of self-respect,  
     – avoidance of obvious self- or other-degradation,  
     – respect for the ontological dignity (D₀) of others.

2. D is read **context-sensitively**:

   * Domain modules (8.1–8.5) mark that cultural, religious, and milieu-specific images of dignity feed in.  
   * In the Case Lens and on the scorecards it is recorded  
     **from which normative and cultural perspective** D is being interpreted (see 9.3–9.4).

3. The model explicitly demands a **meta-attitude**:

   * “From **my** role and **my** context,  
     this pattern of practice appears self-degrading / dignity-protecting …”  
   * This perspective can be criticised, supplemented, or rejected.

4. One of the maturity criteria for users is:

   > **“I do not know what it feels like to be you –  
   > I only describe what I see in practice, naming my own lens.”**

Conclusion:

> The D module does **not** install a new doctrine of dignity.  
> It offers a raster for speaking about dignity in practice in a **transparent, context-aware, and criticisable** way.

For readers this means:

* Chapter 10 is not a defence brief,  
  but an invitation to look at the model itself through the IA and D lens.  
* Anyone working with A, M, and D concepts is meant to keep asking exactly the questions formulated here as criticism – again and again.  
* In this sense, counter-critique is not an attack,  
  but part of the **maturity in practice** that makes the model plausible in the first place.

---

#### 10.6.3 “You make those affected co-responsible for their own degradation.”

This objection often arises where people have already suffered massively – and now have the impression that their way of dealing with themselves is also being used against them. It touches a real fear: that language about praxeological dignity in practice (D) can easily slip into covert victim-blaming.

**Criticism:**

> “When you talk about self-devaluation, neglect, or breaks in dignity in practice (D breaks),  
> you push responsibility back onto those  
> who are already suffering.  
> That is victim-blaming in the language of dignity.”

*Mini-vignette:*

> A person stays for years in a violent relationship.  
> Later they say: “I was so undignified for not leaving.”  
> The risk: outsiders adopt this self-accusation – and turn a D break into an argument for co-culpability.

**Response line:**

1. D (praxeological dignity in practice, D₁/D₂) and M (mitigation responsibility score, M score) are **separate axes** (5.3, 6.4):

   * D describes **how** someone treats themselves / others  
     (self-treatment, treatment of others, relational practice).  
   * M describes **how much structural co-responsibility** this position carries for the course and consequences.  
   * **Self-devaluation does not raise M.**  
     → On the contrary: structurally, M often lies with other actors (institutions, leadership, environment).

2. The **ceiling rule** (6.2) offers explicit protection:

   * Where **foreseeability ≈ 0** and **access to alternatives ≈ 0**,  
     M remains structurally low –  
     even if D patterns of practice are desperate, chaotic, or self-harming.

   * “You should simply have left” is thus praxeologically **disarmed**:  
     without knowledge and real options there is no high M score.

3. The D module often reads self-devaluation as:

   * a **mirror of a degrading structure**,  
   * a **movement of protest or collapse** in an inadult asymmetry,  
   * a sign of **overload** or chronic shaming, not of moral failure.

   → This shifts responsibility **back to structures**,  
   not onto those affected.

4. In practice this means:

   * D findings for those affected are read primarily as a **protection signal**:  
     “Someone here is under such pressure that they have to treat themselves this way.”  
   * The consequence is **relief**, not blame:

     – M remains low,  
     – A (maturity in practice) can be low without moral devaluation,  
     – interventions are directed at **structural change, protection, and access to resources**.

*Closing impulse:*

> When D becomes visible for those affected, the first question is not:  
> “What did you do wrong?”,  
> but:  
> “Who or what put you in a position  
> where you had to treat yourself like this?”  
> This is exactly how the D module is meant:  
> as an amplifier for structural fairness, not for victim-blaming.

---

#### 10.6.4 “You violate the idea of inalienable human dignity.”

This objection comes especially from contexts in which dignity is already deeply anchored as a principle – in constitutional, religious, or philosophical terms. At its core it asks: **Is it even permissible** to speak of “undignified action” without touching the person’s dignity as a whole?

**Criticism:**

> “If you talk about ‘undignified action’,  
> you implicitly negate inalienable human dignity.  
> That contradicts, for example, constitutional or religious understandings of dignity.”

*Mini-vignette:*

> A professional says in a workshop:  
> “That was an extremely undignified pattern of practice on your part.”  
> The room suddenly wonders whether this referred only to a behaviour,  
> or whether the person as a whole was devalued.

**Response line:**

1. The model consciously builds in the **distinction** between D₀ (ontological dignity) and D₁/D₂ (praxeological and relational dignity in practice) (2.6–2.7, 3.5):

   * **D₀ – ontological dignity:**  
     human dignity as a constant – inalienable, not measurable, not gradable.

   * **D₁/D₂ – praxeological dignity in practice:**  
     how someone treats themselves (D₁) and others / the public (D₂) in practice.

   Formulations that deny D₀ (“sub-human”, “no longer truly human”) fall into the **red zone of denying D₀** (2.6.1).

2. Any formulation
   that labels people as **“unworthy”** or “no longer worthy”  
   is itself marked in the model as a **D break on the observer’s side**:

   * degrading language becomes **itself** an object of analysis,  
   * not a legitimate application of the model.

3. Where the model describes “undignified action”, it means:

   * praxeological **inconsistency** between

     – the dignity that people possess (D₀),  
     – and the pattern of practice with which they treat themselves / others (D₁/D₂).

   * This concept is always **reversible**:

     – D rasters and the D quick raster work with movement,  
     – not with definitive labels (“this is what you are”).

4. Anyone who claims on the basis of the model  
   that a person is no longer “worthy of their dignity”  
   is **misusing** the model and acting against its own guardrails.

*Closing impulse:*

> The basic figure is:  
> **D₀ remains non-negotiable – D₁/D₂ are corrigible.**  
> The model is meant to help protect this difference:  
> not to strip people of dignity,  
> but to name ways in which dignity in practice can be regained.

---

#### 10.6.5 “D reinforces shame and stigmatisation.”

Here a very practical concern arises: the word “dignity” alone already triggers shame, defence, or memories of humiliation in many people. When we then add talk of breaks in dignity in practice (D breaks), this can feel like a renewed judgment – especially for already vulnerable groups.

**Criticism:**

> “The word ‘dignity’ alone triggers shame in many.  
> If you then also talk about D breaks and self-devaluation,  
> you only make things worse – especially for vulnerable groups.”

*Mini-vignette:*

> In a youth facility the D module is introduced.  
> A young person hears: “You are dealing with yourself in a very undignified way.”  
> Their conclusion: “So I’m once again the one who’s worth nothing” –  
> and they shut down.

**Response line:**

1. The model takes this point seriously  
   and therefore embeds D with **particularly strict guardrails** (3.5–3.7):

   * The D module is **optional**,  
   * the D profile card contains its own **usage notice block**,  
   * “undignified” language is itself **critically marked** within the model.

   Work on dignity in practice (D₁/D₂) is explicitly treated as work **close to shame** – a high-risk tool that must be used accordingly with care.

2. In practice:

   * D is preferably used where people **themselves** bring in dignity questions:  
     (“I don’t want to treat myself this way anymore”, “That was degrading.”)  
   * In highly vulnerable settings it may be more mature  
     **not** to name D explicitly,  
     but to keep it in mind and work structurally instead  
     (protection, alternatives, relief, role clarification).

3. The central pivot is the core formula:

   > **“Recognise the action – not the person.”**

   * If this attitude cannot be maintained,  
     D should, in case of doubt, be **left out**.  
   * Shame risks are explicitly reflected in the meta-attitude (9.4):

     – “Am I using D to help – or to mark?”

4. At the same time:

   * Many people experience it as **relieving**  
     when it becomes visible  
     that their self-devaluation is **not an inner defect**,  
     but a praxeologically understandable reaction  
     to real inadult asymmetries.  
   * D can then give language to something  
     that would otherwise continue silently as shame.

*Closing impulse:*

> D is not a compulsory module, but an offer.  
> Wherever it creates more shame than clarity,  
> the logic of the model itself says:  
> **dial D down, work on structures, increase protection.**  
> Work on dignity is mature when it relieves people –  
> not when it makes them even heavier.

---

#### 10.6.6 “You are turning dignity into a new technology of discipline.”

This objection has strong historical grounding: concepts of dignity have often been used to bring people “into line” – by gender, class, or moral standards. The question to the model is: are you repeating exactly this, only smarter?

**Criticism:**

> “Hasn’t dignity often been used  
> to discipline people:  
> ‘One doesn’t behave like that’,  
> ‘that is beneath your dignity’?  
> Isn’t D in the model becoming exactly such an instrument?”

*Mini-vignette:*

> In an organisation D becomes the favourite word:  
> “We expect a dignified appearance”,  
> “That was not dignified.”  
> In reality it is less about protection from degradation  
> and more about adaptation to vague behavioural norms.

**Response line:**

1. Historically the diagnosis is correct:  
   dignity concepts have frequently been used for **norming and disciplining**,  
   for example in moral, class, or gender discourses.

2. The model attempts to **expose** exactly this movement instead of repeating it:

   * The domain modules **philosophy & religion** (8.2) and  
     **sociology & politics** (8.3) explicitly ask:

     – Who sets dignity norms?  
     – Who benefits from them?  
     – Who is excluded or permanently devalued by them?

3. D is therefore used in the model not as a tool of discipline,  
   but as a tool of **structural sight**:

   * Which patterns of practice systematically degrade others –  
     often without participants naming them as such?  
   * Where does a structure support self-respect – where does it break it?  
   * How do dignity rhetorics and power relations (C-P, P-PU) interlock?

4. If new **disciplining programmes** emerge out of the model,  
   this is a **misuse** of the D module:

   * The model is explicitly described as a **working draft**  
     with an ethics of use (chap. 12).  
   * Users commit themselves in the meta-attitude (9.4) to:

     – self-implication,  
     – readiness to revise,  
     – restraint in normative application.

*Closing impulse:*

> D is not supposed to produce new rules  
> about how people “have to be”,  
> but to make visible  
> how we – often unintentionally – degrade or protect ourselves and others.  
> Whether this becomes disciplining or liberating  
> does not depend on the module,  
> but on the maturity of those who use it.

---

**Overall conclusion for 10.6:**

The D module is deliberately built so that it carries criticism **of itself** within it:

* It strictly distinguishes between **being** (D₀ – ontological dignity) and **practice** (praxeological dignity in practice, D₁/D₂).
* It marks its own **normativity** and cultural situatedness.
* It links dignity questions to **structural critique**, not to judgments of character.
* It can be **switched off** if needed, without collapsing the base model.

Thus it remains – in the spirit of the whole project – an offer:

> **An optional raster  
> for making visible  
> how maturity in practice relates to our treatment of dignity in practice –  
> in ourselves, in others, and in our structures.**

Those who criticise this part of the model are thereby working exactly in the spirit the model aims at:
not monopolising questions of dignity,  
but negotiating them openly, context-aware, and structurally sensitively.

---

## 11) Visual quick access (1-pager, PDF-ready)

After dense theory, we need a surface on which the model becomes **graspable** in everyday life.  
This chapter condenses the core questions of the framework so that they fit on a single page:
for pinboard, whiteboard, regular meetings, or decision rounds.

You can read the 1-pager as:

* an **emergency brake** (“Are we currently reinforcing inadult asymmetry?”),
* a **short audit** for decisions,
* or an entry point for people  
  who (do) not yet know the full model.

---

### 11.1 Audit checklist (5 points, meta level)

**Goal:**  
In 2–5 minutes, check whether an IA analysis is **basically robust** –  
before it goes outward or becomes a basis for decisions.

You can present these five points as a numbered list or as a box:

---

**1. Scope & guardrails – “Am I even allowed to do this here?”**

* ☐ Am I **not** in a red zone  
  (no clinical diagnostics, no individual HR decisions, no diagnostics for children,
  no public pillory, no forensic use,
  **no dignity-labelling of persons**)?
* ☐ Is it clear **what** the analysis is supposed to be used for  
  (self-clarification, structural critique, process improvement – not: humiliation, enemy-marking)?
* ☐ Is minimal maturity in practice present:
  – Do I really want to see better – including about myself –  
  – or do I just want to “win”?
* ☐ If the D module (praxeological dignity in practice, D₁/D₂) is involved:
  – is it clear that D only describes **enactments** (D profile),
    not the overall worth of the human being?

> If there is doubt here: **stop the analysis or adjust its purpose.**

---

**2. Roles & publicness – “Who is speaking, who is being looked at, in front of whom?”**

* ☐ Is the role of the **object under consideration** clear  
  (function, level, publicness: private · institutional · public · media)?
* ☐ Is my own role as **observer** clearly named  
  (neutral, involved, leadership, affected person, public)?
* ☐ Has it been considered how high  
  – the **awareness of publicness (A-P)**,  
  – the **power to act in public (P-PU)**  
  – and, if applicable, the **public dignity dimension (D-P – dignity in practice under public conditions)**  
  of the object under consideration realistically are?

> Unclear roles = **high risk** of phantom intention and misinterpretation.

---

**3. Structure & scores – “Have I thought A/M and A–C–R–P–D cleanly?”**

* ☐ Have I looked at A–C–R–P–D as **structure-related** –
  not as a character diagnosis?
* ☐ Is there a reasoned **A score (band)** for the enactment  
  (awareness, coherence, responsibility, action/power to act – with micro indicators)?
* ☐ Has the **M score (co-responsibility)**  
  – along knowledge, power, foreseeability, access to alternatives, integration attempt –  
  and with the **ceiling rule** been determined?
* ☐ Is it clear **where** the inadult asymmetry sits  
  (knowing/being able/being allowed/willing; IA box: transparency, justification, time-boundedness, reversibility)?
* ☐ Have I at least roughly seen a **trajectory**  
  (development over time), not just a single still-image judgement?
* ☐ If D was used:
  – is there a **descriptive D profile** (self-treatment, treatment of others, relational dignity in practice),  
  – without a “dignity score” and without labelling entire persons?

> If A/M, IA box or D profile are “felt” rather than reasoned → back to structure.

---

**4. Bias, gut feeling, norm assumptions – “What in me is mixing in?”**

* ☐ Have I used my **gut feeling** as a starting signal –
  not as the final judgement?
* ☐ Where might typical **biases** be at work in me  
  (confirmation bias, in-/out-group bias, hindsight bias, loyalty bias)?
* ☐ Which **norm assumptions** do I bring into the analysis  
  (justice, reasonableness, role images, conceptions of dignity) –
  and are they at least **named**?
* ☐ Have I tried to consider at least **one counter perspective**  
  (“How would the same case look from the other side’s point of view?”)?

> Not bias-free, but bias-aware – that is the standard.

---

**5. Consequences & reversibility – “What am I doing with this analysis?”**

* ☐ What will **concretely** happen if this analysis is believed/implemented  
  – for distribution of power, reputation, protection goods, future opportunities?
* ☐ Are the proposed steps  
  – **transparent**,  
  – **justified**,  
  – **time-bound** (review date),  
  – **reversible** (course correction possible)?
* ☐ Is there a clear **proposal** whether structure should be:
  – maintained,  
  – balanced,  
  – or changed/stopped?
* ☐ What possible effects on dignity in practice (D₁/D₂) does this analysis have:
  – does it open space for restoration and self-respect,  
  – or does it fix people into entitling roles without a way back?
* ☐ Is it documented when and how we will check
  whether our current reading has **failed**?

> If these questions cannot be answered, the analysis is **not ready to be published** –
> it remains an internal state of thinking, not a basis for decisions.

*Concluding impulse:*

> On one page, this checklist compresses the core promise of the model:
> better one analysis less,
> and in return one that treats roles, power and dignity in practice more fairly.  
> If you stumble several times while going through it,
> that is not failure – it is exactly the moment
> in which maturity in practice begins.

---

### 11.2 Conflict loop (4 steps)

Conflicts are the everyday test for the model:  
this is where roles, power, injuries and dignity in practice collide directly.  
The conflict loop is the ultra-compact application of the framework
for real disputes – in teams, relationships, organisations.

It combines:

* the System 1/System 2 micro tool,
* the role mechanics,
* and the four-criteria box –

into four steps you can remember.

You can present it on the one-pager as a graphic or as a numbered list:

> **Mini scene:**  
> A team meeting escalates, accusations are flying.  
> Instead of immediately deciding “who is right”, the conflict loop helps
> to stabilise the ground first: context, roles, asymmetry, next steps.

---

**Step 1 – STOP & FRAME – “Don’t lash out immediately”**

* briefly stop (internally or out loud: “Stop, let me sort this”),
* **mark the context**:
  – Where are we (private, professional, institutional, public, media)?  
  – What is this about in one sentence (conflict, request, boundary-setting, decision)?  
  – Which protection goods might be affected
    (health, safety, dignity, subsistence, trust)?

Goal: briefly slow down the automatic System 1
so that awareness (A) and coherence (C) can come into play at all.

---

**Step 2 – ROLE – “Who is who here?”**

Clarify in 1–2 minutes:

* **What is my role?**  
  – In which function am I currently speaking/acting (private, professional, leadership, facilitation, affected person)?
* **What is the other side’s role?**  
  – Partner, colleague, leadership, client, public, institution …
* **Is that mutually clear?**  
  – If not: **one sentence** to clarify (“I am now speaking as …”).

Goal: increase role awareness (A-R),
minimise role vacuum and phantom intentions.

---

**Step 3 – IA-spot – “Where does the unfair asymmetry sit?”**

A short look through the four-criteria lens:

* **What is unequally distributed here?**  
  – knowledge, power, risk, responsibility, interpretive authority?
* This asymmetry:
  – transparent?  
  – justified (which protection good / which legitimate purpose does it serve)?  
  – time-bound (validity frame, review)?  
  – reversible (are there ways back / exit options)?

If at least two points clearly fail
(e.g. intransparent + irreversible):

> **inadult asymmetry (IA) identified – here lies the core of the conflict.**

Goal: away from “You are …” → towards “Something in the structure is off here” –
including the question:
“Who here is experiencing **loss of dignity** (shaming, self-devaluation, symbolic entitling)
and who has levers to change that?”

---

**Step 4 – STEP & REVIEW – “Small, reversible next steps”**

On the basis of 1–3:

* Agree on **one small, reversible action**:
  – clarification, trial phase, providing missing information, role clarification, protection measure.
* Clarify responsibility:
  – Who can **realistically** do what (with A and M scores + ceiling rule in mind)?
* Set a **review point**:
  – “We will look in X days/weeks to see whether this measure has improved the situation –
    and we are ready to revise our reading then.”

Goal: not to “solve” the conflict perfectly,
but to conduct it in such a way that **later maturity in practice remains possible**
and that no one – also praxeologically – is **irreversibly entitling**.

> **Mnemonic:**  
> First **context** – then **roles** – then **asymmetry** – then **step**.  
> Those who reverse this order risk
> putting a lot of energy into deciding the wrong thing.

---

### 11.3 D quick grid (banal → extreme, always reversible)

Many situations contain questions of dignity,
without immediately needing the full D profile card.  
The **D quick grid** is the compact “legend” for the D module on the one-pager:

* It classifies **visible D-enactments** roughly – from banal to extreme.
* It deliberately avoids numbers and person-judgements.
* It is always tied to **context + time window** – not to “the person as such”.
* Every level is designed as **reversible**: it is about *states*, not *essence*.

> Use:  
> only when D guardrails have been checked (chap. 3.5–3.7)
> and it is clear that D here should bring **explanation**, not **shaming**.

---

#### Grid structure (0–3)

**Axes:**

* **Level 0–3**
* each with a short look at:
  – self-enactment (**D₁ = praxeological self-dignity**, operationalised as D-I = dignity in the inner dimension, e.g. self-image/self-talk, and D-B = dignity in the bodily dimension, e.g. treatment of body and boundaries),  
  – dealings with others/public (**D₂ = relational dignity in practice**, operationalised as D-R = dignity in relational enactments in the near environment and D-P = dignity in practice under public conditions),  
  – consequence in the model (“What to do?”).

---

##### **Level 0 – D not in focus (neutral / unremarkable)**

**Self (D₁):**

* everyday fluctuations without a relevant D issue:
  – tiredness, messiness, stress,
  – but no stable self-devaluation,
  – no systematic self-neglect.

**Others / society (D₂):**

* no noticeable acts of shaming or devaluation,
* occasional clumsiness that can be cleared up.

**In the model:**

* D is **not actively** worked on here.
* Focus: awareness, coherence, responsibility, action/power to act (A-C-R-P), IA box, A score, M score.
* Note: “No particular D issue visible.”

---

##### **Level 1 – Banal / everyday drift**

**Self (D₁):**

* slight neglect of one’s own needs:
  – too little sleep,
  – chronic stress / “gritting one’s teeth”,
  – ironic self-devaluation (“I’m just dumb”),
* visible tensions between inner sense of worth and behaviour,
  but **not massive**.

**Others / society (D₂):**

* rough jokes, occasional insensitive ways of dealing with others,
* milieus where “mild” devaluation is the norm,
* adaptation to such contexts without explicit D awareness.

> **Mini scene:**  
> In a team it is normal to greet each other with “Hey, you idiot”.  
> Everyone laughs – but one person notices that they are gradually making themselves smaller by going along.

**In the model:**

* Marking: **“Everyday drift – pay attention”**.
* Recommendations:
  – small self-care experiments,
  – reflect on language (“How do I talk about myself/others?”),
  – context check (milieu vs. alternatives).

---

##### **Level 2 – Marked D stress / recurrent self-devaluation**

**Self (D₁):**

* persistent overriding of one’s own boundaries,
* chronic self-devaluation:
  – “I am worth nothing”,
  – “I deserve this”,
* withdrawal from self-care (food, hygiene, health) **not only** due to lack of time,
* functional adaptation to entitling environments.

**Others / society (D₂):**

* recurrent shaming of others:
  – ridicule,
  – systematic devaluation,
  – deliberate exposure,
* entitling group images (“They are trash”),
* instrumental use of others (e.g. for self-presentation → D-P relevant).

**In the model:**

* Level 2 is a **relevant D zone**.
* Here D is read **explicitly** in trajectory and structure.
* Consequences:
  – focus on protection and alternatives for affected persons (low M score, high pressure),  
  – clear naming of entitling patterns in actors with a high M score,  
  – think reversible steps towards level 1/0:
    “What action minimally increases D₁/D₂? Who has A and M levers?”

---

##### **Level 3 – Hard D breaks / extreme zone (alarm, not fine diagnostics)**

**Self (D₁):**

* self-dehumanising images (“I am nothing”),
* self-harm, extreme neglect,
* enactments that look like a denial of one’s own humanity,
* often a reaction to traumatic or extremely IA-loaded contexts.

**Others / society (D₂):**

* systematic dehumanisation:
  – torture, rituals of humiliation,
  – dehumanising language/images/practices,
* institutional or media “execution” without way back,
* structural entitling of entire groups.

**In the model:**

* **Alarm zone** – no fine-tuning.
* Consequences:
  – focus on **protection goods** (law, safety, dignity, health),  
  – M scores of responsible actors typically **high**,  
  – D profile here primarily as **documentation of injustice**,
    not as coaching material.

**Reversibility in the model:**

* Damages cannot be undone,
  but: **D₀ – ontological dignity – is never abandoned**,
  and the analysis always asks:
  – “Which structural/role changes can make D₁/D₂ possible again?”

---

##### Usage note for the D quick grid

* The grid does **not** replace a D profile card.
* It serves **quick orientation**:
  – “Roughly where are we – level 0, 1, 2, 3?”
* Every level must be recorded **with role, context and time window**.
* Guiding question after **each** classification:

> **“What would be one small, real action
> that could make this constellation *one* level more dignified –
> and who has A and M levers for that?”**

The D quick grid is a **movement tool**,
not a label:
It shows **where** dignity in practice stands
and **what** can be minimally improved –
never “what a person is”.

---

## 12) Concluding word – maturity in practice remains work

This model is deliberately marked as a **working version**.  
Not out of modesty, but as a consequence of its own claim:

> **Maturity in practice** means how we actually act under conditions –
> so this model, too, must prove itself under conditions.

### What that means:

* It emerged from conversations, conflicts, practice experiences.
* It carries normative assumptions of its authors and users.
* It remains reliant on **revision**:
  – through counterexamples,  
  – through other perspectives,  
  – through structural critique.

### Three effects if the model succeeds:

1. **Shift of focus**  
   away from “Who is good/bad?”  
   towards:
   “How are roles, power, responsibility, action spaces built –
   and what **effect on dignity in practice** do they have?”

2. **Making inadult asymmetries visible**  
   without automatically producing a pillory.

3. **Self-implication**  
   Those who analyse, show themselves.  
   Those who demand maturity must at least attempt it in their own actions.

---

### Toolbox with an ethics rider

The model is not a doctrine,
but a **toolbox with an ethics rider**.

* It may be used, criticised, rejected, improved.
* Condition:

  > **Maturity in practice matters more than being right –
  > and dignity in practice more than winning.**

### Two commitments of users

Those who use the model commit to:

1. **seeing their own roles, biases, norm assumptions and images of dignity along with the analysis**,  
2. **revising analyses**
   when reality or counter-voices refute them.

Anything less would be inadult asymmetry in dealing with the model itself.

---

### Conclusion

This model aims to help us, in difficult, asymmetric situations, to act

* **more clearly**,
* **more fairly**,
* **more in line with dignity**,
* and **more responsibly**.

Always knowing that this, too, is only an approximation –  
and that maturity in practice, including our handling of dignity
(ontological dignity D₀ and praxeological dignity in practice D₁/D₂),
remains a **permanent task** – for persons, structures, and also for this model itself.

---

## Appendix A - Glossary of key terms

---

### Maturity, enactment, adultness / inadultness

**Maturity in practice**  
Maturity understood as **visible practice**: it shows itself in concrete action under real constraints (time pressure, costs, risk, resistance). What counts is the **coherence of awareness, word, responsibility, power to act and dignity in practice** – not self-description, good intention or a person’s “essence”.

**Enactment**  
The actual **enactment of a role or decision** in a concrete context: what was done or omitted, when, with whom, under which conditions? In contrast to plans, intentions or self-images (“I would have…”).

**Adultness (in the model)**  
Not a perfect list of virtues, but: **sufficiently high A-C-R-P with intact D₁/D₂**, so that someone, even at a cost, takes responsibility, names and corrects contradictions, and respects protection goods. Adultness is **context- and role-related** and can break down at specific points.

**Inadultness (in the model)**  
Zones of **immature, unintegrated or impulsive patterns** that can weaken responsibility, coherence or dignity in practice – but also contain **raw energy for movement and innovation** (courage, boundary-testing, nonconformity, creativity). Inadultness is **no flaw in ontological dignity (D₀)**, but a field of development and risk.

**Maturation**  
Process in which **adult and inadult parts** are brought into accountable channels:
– inadult energy (impulse, creativity, protest) is not suppressed,  
– but framed by roles, structures and responsibility in such a way  
  that it **does not become entitling**, but **enables change**.

---

### Core parameters A-C-R-P–D

**Awareness (A)**  
What a role/person **knows or could know**: facts, risks, alternatives, affected parties, power relations, own blind spots. A also includes awareness of **structural asymmetries** and one’s own biases – not just the inner world.

**Coherence (C)**  
The **consistency between word and deed** across time and contexts. Coherent is the person who maintains commitments, values and rules even when it costs or becomes uncomfortable – and who does not conceal breaks, but **names and corrects** them.

**Responsibility (R)**  
The question of **carried burdens and consequences**: who stands for what, who takes on which consequences, who tries to limit or repair damage? Responsibility here means **answering and carrying**, not just “being at fault”.

**Power to act (P)**  
Real **scope for influence and action** in a situation: who can decide, stop, change, escalate, de-escalate? What is meant are effective levers, not just formal titles. P can be individual, institutional or cultural.

**Dignity in practice (D in practice)**  
Quality of **dignity in practice** in concrete behaviour: how someone deals with themselves, with others and with the social world. In the model, D refers primarily to **D₁ (self-dignity in practice)** and **D₂ (relational dignity in practice)** – i.e. observable enactments, **not** a person’s worth.

---

### Levels of dignity & D submodules

**Ontological dignity (D₀)**  
Unconditional **human worth** – regardless of performance, behaviour, status or group. D₀ is **not measured** and not graded in the model. It is the normative constant: *a human being remains worthy – even when acting without dignity*.

**Dignity in practice – D₁ / D₂**

* **D₁ – praxeological self-dignity**  
  How someone deals with themselves (self-care, self-respect, self-devaluation). Operationally visible via **D-I** and **D-B**.

* **D₂ – relational dignity in practice**  
  How someone deals with others and with publicness/language: respect, boundaries, fairness, protest, mirroring, refusal. Operationally visible via **D-R** and **D-P**.

**Submodules D-I / D-B / D-R / D-P**

* **D-I – inner dignity**  
  Self-treatment in the inner dimension (self-respect, self-contact, inner clarity).

* **D-B – concrete/bodily self-care**  
  Dignity in the physical, material, everyday treatment of oneself (food, sleep, hygiene, basic financial security, medical care).

* **D-R – relational dignity**  
  Dealing with others: boundaries, fairness, respect, shares of responsibility, renunciation of entitling practices.

* **D-P – public dignity in practice**  
  Behaviour in social spaces, groups, roles; dealing with public visibility, self-presentation, shaming or protection of others in public space.

**Self-devaluation**  
Repeated, visible **devaluation of one’s own person** in practice: derogatory self-talk, self-damaging decisions, withdrawal from care (“I am not worth it”). In the model this is neither a pathologising label nor a moral accusation, but a **D signal**, almost always coupled with structural IA and a low M score.

---

### Asymmetries, roles, publicness

**Asymmetry**  
Unequal distribution of A, C, R, P or D between those involved. Who has more/less awareness, coherence, responsibility, power or interpretive authority? Asymmetries are **not automatically bad**, but they must be justified, limited and reviewable.

**Functional asymmetry**  
An asymmetry that is **factually meaningful** for a task (e.g. teacher–student, physician–patient). It is **transparent, justified, time-bound and in principle reversible** and serves a recognisable protection or factual purpose.

**Inadult asymmetry (IA)**  
An asymmetry that primarily protects **self-image, comfort or power interests** of the stronger side, not the matter at hand or protection goods. Typical patterns: intransparency, diffuse or pretextual justifications, unbounded or irreparable subordination, **violations of dignity**.

**Asymmetry of interpretation**  
Form of asymmetry in which one side has **interpretive dominance** over meanings: it decides how behaviour, motives, “dignity” or blame are to be read. Asymmetries of interpretation are particularly **IA-prone**, because they do not only affect others, they also **define** them.

**Role**  
A **bundle of expectations, rights and duties** in a context (e.g. father, manager, patient, activist). A person can hold several roles simultaneously. What is analysed is always the **role in the concrete setting**, not the “whole personality”.

**Publicness (A-P / P-PU / D-P)**  
Degree of **visibility (A-P)**, **power to act in public (P-PU)** and the **public dignity dimension (D-P)** of a role or decision.  
Typical questions:  
– Who can shame or elevate whom in public?  
– Who presents themselves as a brand or object?  
The higher A-P/P-PU/D-P are, the higher typically the **co-responsibility** and the relevance for D.

---

### Scores, responsibility, IA box

**A score (“adultness score”)**  
Range of **maturity in practice** of a role in a concrete situation (e.g. A ≈ 4–5/10). It results from a reasoned overall look at A, C, R and P. The A score is **not a personality or worth judgement**, but a **situation-related assessment of practice**.

**M score (“co-responsibility score”)**  
Range of **co-responsibility** of a role for a course of events or outcome (e.g. M ≈ 6–7/10). It takes into account especially knowledge, power/control, foreseeability, access to alternatives and attempts to integrate. High M values mean **strong responsibility in the process**, not “guilt for everything”.

**Responsibility points & RVR(t)**  
Concrete **responsibility points** are moments in which a role could realistically have decided or intervened differently.  
**RVR(t)** (“responsibility–viability–range over time”) describes how responsibility was **used, shifted or refused over time**.

**IA box (T–J–TB–R)**  
Four-question grid for evaluating asymmetries:

* **Transparent?** – do those affected know what is going on?  
* **Justified?** – are there verifiable factual reasons?  
* **Time-bound?** – are there conditions/reviews?  
* **Reversible?** – are there real ways back/adjustments?

The more “no/unclear”, the higher the IA risk.

---

### D module, profiles, grids

**D module (praxeological dignity analysis)**  
Optional module of the model that looks at **enactments of dignity**: self-treatment (D₁), dealings with others and publicness (D₂).  
Strict guardrails:  
– D describes **enactments**, not persons.  
– No “dignity scores” for humans, only profiles/bands.  
– Use only where D clarification helps – not where it would shame or serve as a weapon.

**Protection clause (for D)**  
Fourfold protective frame around the D module:

1. **D₀ remains untouched** (not measurable, not relativisable).  
2. D₁/D₂ are described only **scenically and context-bound**.  
3. D descriptions are **to be documented and open to critique** (role, context, norm assumptions made visible).  
4. No **single D scores**, only profiles/bands.

**D profile / D profile card**  
Descriptive documentation of **D enactments** in a case:  
– self-care vs. self-neglect,  
– protection vs. entitling of others,  
– protest vs. adaptation to entitling structures.  
The D profile works with **qualitative notes**, not numbers. It is kept separate from A and M scores.

**D quick grid (0–3)**  
Simple **quick grid** for visible D enactments (D₁/D₂) on the one-pager:

0 = no particular D issue / neutral  
1 = everyday drift / mild self- or other-devaluation  
2 = pronounced D stress / recurrent self-devaluation or shaming of others  
3 = hard D breaks / extreme zone (alarm, focus on protection goods)

Each level is conceived as a **state, not an essence**, and in principle **reversible**: it is about *where* dignity in practice stands – and *where* one can work towards.

**Band logic for D**  
Three-part qualitative scale for D courses:  
– **banal D irritations**,  
– **consistent D breaks**,  
– **massive/extreme D breaks**.  
It shows **density and stability** of entitling patterns, not a person’s worth.

**D break**  
Enactment in which dignity is **clearly and massively violated** – in relation to oneself or others: humiliation, dehumanisation, deliberate shaming, self-objectification “below one’s own humanity”. In the model this is primarily an **alarm and protection signal**, not a diagnostic label.

**D heatmap**  
Visual or conceptual grid that, in a field (organisation, politics, milieu), marks the **concentration of D and IA problems**: zones in which people are systematically entitling, shamed or adjusted downward. It serves as an indication of **reform and protection needs**.

In clinical or highly stressed neurodiverse states (trauma, severe depression, autism overload etc.), D₁/D₂ are not used in the model as indicators of maturity, but – if at all – as signals of strain (see 2.7.5).

---

### Language phenomena & semantic drift

**Semantic drift**  
Shift in meaning of the same actions through role/context differences: what is experienced internally as self-protection or protest may be interpreted externally as “deficit” or “disrespect” – and vice versa. Semantic drift is a **central IA risk**, because interpretations are themselves acts of power.

**Interpretation IA**  
Inadult asymmetry arising when **readings of dignity** are distorted:  
– D₁ is too quickly diagnosed as a defect,  
– D₂ (protest/mirroring) is overlooked or morally devalued.  
Consequence: stigmatisation instead of structural critique.

**D finding via language**  
Pointer that entitling, escalating or devaluing language itself counts as a **problem of IA and D₁/D₂ on the side of the speakers** (e.g. “trash”, “subhumans”, “scum”).

---

### Meta structure: guardrails, ceiling rule, trajectories

**Guardrails**  
Explicit **guardrails of use**:  
– focus on structures and enactments, not on diagnoses of “essence”,  
– no forensic/clinical application,  
– no HR, separation or internet pillory,  
– protection of vulnerable groups and protection goods,  
– no labelling of persons (“3/10”, “inadult person”),  
– D only as a parameter of enactment, never as a judgement on a person.

If guardrails fall, the analysis is **not mature in practice**.

**Ceiling rule (for M score)**  
Protection rule against **victim-blaming** in co-responsibility:  
– When **foreseeability ≈ 0** and **access to alternatives ≈ 0**,  
  the M score must **not be high** (e.g. M ≤ 4/10).  
This prevents those affected in extremely asymmetric situations from being retrospectively marked as “actually co-responsible”. (Specific design see main text.)

**Trajectories**  
Courses of A(t), M(t), RVR(t) and, where applicable, D(t) **over time**. Instead of “point values”, movements are considered: learning, stagnation, tipping, recovery. Trajectories show whether someone/something has **learned**, consistently refused responsibility, or whether D enactments have improved/deteriorated.

**Co-responsibility**  
Shared responsibility for an event: who bears which share – through deciding, co-carrying, looking away, stabilising structures? Co-responsibility is **graded** (not all or nothing) and can also lie in omission. It is made structurally visible via the M score.

**Victim/child protection**  
Principle that analyses and interventions **must not add further burdens** to persons already vulnerable:  
– no “She should have left earlier”,  
– no adult norm benchmark applied to children/young people,  
– special caution when using the D module.  
Protection here means: **respecting limits of reasonableness**, no reversal of blame, no entitling diagnostics.

**Minimal adultness (of users)**  
Baseline for using the model: willingness to self-reflection, to one’s own co-responsibility, to correction by counter-arguments. Anyone using the model **implicates themselves**:  
– the same questions applied to others also apply to them.  
– Those who judge D simultaneously display **their own understanding of dignity** in practice.

---

## **Appendix B – Checklists & practice templates**

---

### **B.1 Quick check: 60-second self-test before each application**

**1. Do I have my own role clear?**  
– How much power, knowledge, reach do I currently have?  
– Am I observer, party, affected person, authority?

**2. Am I currently in an affective position?**  
– Anger, loyalty, outrage, fear, hurt, “I want to be right”  
→ If *yes*: read only structurally, **no scores, no D assessments**, especially **do not actively use the D module**.

**3. Analysis instead of diagnosis?**  
– Am I speaking about *roles*, not about “types”?  
– I analyse **structures**, not psyches.

**4. Are the guardrails active?**  
– No use against children, victims, marginalised groups.  
– No labels (“3/10”, “inadult person”).  
– No HR, separation or internet pillory.  
– Explanation ≠ justification.  
– **Default: D off.** Activate D module only consciously and with justification.  
– **If D is in play:** describe only **enactments** (D profile) – **concretely and scenically** (role, context, time window), no persons (“X is without dignity”).

**5. Can I pause if a guardrail breaks?**  
→ If no: *do not apply* – especially do not use the D module.

---

### **B.2 Case start template: 1-minute snapshot**

1. **Object under consideration (A):**  
   What are we looking at? (person *in role*, relationship, decision, structure, institution)

2. **Context / setting:**  
   Place, time, relevant conditions, existing rules, pressures, conflicts.

3. **Roles involved:**  
   Who is involved, *in which roles* (not as “person profiles”)?

4. **Publicness (A-P / P-PU / if applicable D-P):**  
   Private? Semi-public? Institutional? Media?  
   Which role has how much **public** power or visibility –  
   and who is particularly exposed to public **shaming/entitling** (D-P)?

5. **Dominant asymmetry:**  
   Which A/C/R/P asymmetry catches the eye first?

→ After this, move into the deeper structure.

---

### **B.3 A-C-R-P-D analysis template (basic framework)**

**A – Awareness**  
• What did this role know?  
• What *could/should* it have known?  
• Were there warning signals, alternatives, knowledge of consequences?  
• Was there self-blindness, role confusion?

**C – Coherence**  
• Do words/promises line up with actions?  
• Were breaks named or covered up?  
• Are there patterns over time (trajectory: up/down/stagnant)?  
• Is context used to simulate coherence?

**R – Responsibility**  
• Which responsibility points (RVR) were there?  
• Were they taken up, shifted, refused?  
• Which burdens did the role actually carry?  
• Were those affected taken into account?

**P – Power to act**  
• Which real levers did this role have?  
• What could it *realistically* have done (not idealised)?  
• Where does the **ceiling rule** apply (children, victims, structurally weaker parties)?

> **Optional look at D (without own verdict):**  
> Are there visible self-devaluation or systematic entitling of others in practice?  
> **Use only** when the frame is safe and D guardrails are fulfilled; otherwise, at most silently keep D in mind or deliberately leave it out.

→ Result: **A band** (e.g. A ≈ 4–5)  
→ Only *bandwidth*, with a short justification.

---

### **B.4 IA box (T–J–TB–R) – template**

**1. Transparent?**  
– Do those involved know what the rule/asymmetry is?  
– Is there clear communication?  
– Or is the structure kept deliberately/advantageously vague?

**2. Justified?**  
– Are there reasons that can be checked?  
– Factual logic or logic of power/image/affect?  
– Does the justification drift with context/mood?

**3. Time-bound?**  
– Are there conditions, points in time, reviews?  
– Or is the structure “forever”?

**4. Reversible?**  
– Are there ways back, adjustments, exit options?  
– Or is dignity/status irreversibly damaged?

→ Result: **functional asymmetry / IA risk / inadult asymmetry.**

---

### **B.5 A score & M score – template**

#### **A band (maturity in practice)**

**A ≈ x–y / 10**

Justification in 3–5 bullet points based on A-C-R-P-D:

1. A:  
2. C:  
3. R:  
4. P: (including ceiling rule, if relevant)

→ No label, no interpretation beyond the context.

> **Optional:** short notes on D enactments  
> (e.g. “under pressure clear self-devaluation”, “visible protection of others’ dignity despite costs”) –  
> which do **not** flow into the A number, but are collected in the D profile card.  
> Use only when purpose and frame are clear and D guardrails are fulfilled.

---

#### **M band (co-responsibility)**

**M ≈ x–y / 10**

Justification based on the five co-responsibility factors:

1. Knowledge  
2. Power/control  
3. Foreseeability  
4. Access to alternatives  
5. Attempt at integration

→ M is *not* guilt, but the **share in the effect of what happened**.

---

### **B.6 Trajectory template**

#### **A(t), M(t), RVR(t)**

Timeline (t₀ → t₁ → t₂ …), with:

* A band  
* M band  
* central responsibility points  
* major context shifts  
* learning movements or refusals  
* tipping points (e.g. break in coherence, role-split, attempt to withdraw power)

**Goal:** to make movement visible instead of labels.  
Optional: short marking of D(t) – e.g. “D drift downward (more self-devaluation)”, “D recovery (more self-care)” – **without number, only descriptive** and only where D guardrails are fulfilled.

---

### **B.7 Role/publicness mapping**

#### **1. Role matrix**

| Role   | A | C | R | P | Publicness                        | Notes                        |
| ------ | - | - | - | - | --------------------------------- | ---------------------------- |
| Role X |   |   |   |   | private/semi-public/public        | structural particularities   |

#### **2. Levels of publicness**

* **Private:** 1–2 affected persons  
* **Social:** small groups, teams  
* **Institutional:** organisations, authorities, offices  
* **Public–media:** broad audience  

→ Higher publicness = higher responsibility – and heightened D sensitivity (risk of shaming, brand logic, D-P).

---

### **B.8 Guardrail checklist (practice form)**

**☐ Focus on roles, not persons**  
**☐ No clinical/forensic/HR diagnostics**  
**☐ No labels for persons** (“X has A=3”, “Y is without dignity”)  
**☐ Ceiling rule active (children/victims protected)**  
**☐ No victim-blaming**  
**☐ Structural critique instead of moral tribunal**  
**☐ D only as parameter of enactment, no judgements about the human being as a whole (D₀ remains untouchable)**  
**☐ D findings always scenic (role + context + time window), never global labels**  
**☐ Default: D off – activate D module only with clear purpose and safe frame**  
**☐ Do not use D module with children, acutely traumatised persons, highly vulnerable groups**  
**☐ No use in acute conflicts without moderation**  
**☐ No use for escalation (argument weapon)**  
**☐ Document results with justification, not just note scores**  
**☐ Own co-responsibility and role disclosed**

---

### **B.9 Mini toolkit for ad-hoc situations**

Short tools for quick situations:

**1. “What do I actually know?”**  
→ Short check against projection.

**2. “What is the task of the role here?”**  
→ Separates personal likes/dislikes from the structure.

**3. “Who carries which burden?”**  
→ View of responsibility points.

**4. “Which real power is in the room?”**  
→ Prevents immature expectations (“Why didn’t she just…?”).

**5. “What would be a functional asymmetry?”**  
→ Alternative to moral black-and-white.

> **Optional addition for D topics:**  
> “Who is experiencing **loss of dignity in practice** here (shaming, self-devaluation) – and who would have levers to change that?”  
> Focus remains on **configurations and roles**, not on the “worth” of persons.

---

### **B.10 Documentation template (for cases, workshops, audits)**

*{for case work, workshops, audits; slim overview of the analysis based on B.2–B.7, with optional reference to D module B.11}*

---

#### 0. Header / metadata

*{short basic information so that the case can later be found and classified again}*

* **Case name / title:**  
* **Date of documentation:**  
* **Person/team doing the work:**  
* **Context / setting:**  
  *{e.g. enforcement, youth welfare, organisation, team, project …}*  
* **Purpose of this documentation:**  
  *{e.g. internal reflection, supervision, audit, training, case discussion}*  
* **Intended readers:**  
  *{who is supposed to see this documentation, and in what form?}*

**Short guardrail check (ticking is enough):**

* [ ] minimal adultness of those doing the work reflected  
* [ ] public/semi-public risk (pillory, stigmatisation) considered  
* [ ] possibility of revision provided for (feedback, additions, counter-perspectives)

---

#### 1. Snapshot  *(from B.2)*

*{1–5 sentences: what is the case? What is it about – without diagnosis, without judgement?}*

* **Short description of the case / scene:**

* **Central actors and roles:**

* **Open guiding question of the analysis / documentation:**

---

#### 2. Role mapping  *(from B.7)*

*{who is A? who has which role, which power, which responsibility?}*

* **Object under consideration (A):**  
  *{person, team, organisation, procedure, rule, structure …}*

* **Role description of A:**  
  *{function, mandate, typical asymmetries of the role}*

* **Further relevant roles / actors:**

  * Role 1 / function:  
  * Role 2 / function:  
  * Role 3 / function:

* **Degree of publicness of what is happening:**  
  *{private / semi-public / institutional / public / media; how visible is this?}*

---

#### 3. A-C-R-P-D profile  *(from B.3)*

*{Structured short profile: what was done – with what awareness, in which context, with which responsibility and power?}*

**A – Awareness**  
*{What did the role know or what could/should it have known?}*

* Real knowledge at time X:  
* Warning signals / alternative information:  
* Presumed blind spots / role confusion:

**C – Coherence**  
*{Do official narratives and real enactment match?}*

* Official self-descriptions / narratives:  
* Visible enactments (“walk”):  
* Word–deed coherence / breaks:

**R – Responsibility**  
*{Who carries what – and how is responsibility handled?}*

* Central responsibility points over the course:  
* Taking on / shifting / refusing responsibility:  
* Consequences for those affected / third parties:

**P – Action / power to act**  
*{What would have been really possible – and what was done?}*

* Formal vs. factual scope for action:  
* Used vs. unused alternatives:  
* Relevant applications of the **ceiling rule** (children, victims, weaker parties):

**Short conclusion A-C-R-P-D (2–4 sentences):**

---

#### 4. IA box – T–J–TB–R  *(from B.4)*

*{Assessment of the asymmetry: functional or IA-suspect?}*

**T – Transparent?**

* What is visible/understandable for whom?  
* Is there a “magical zone” (intransparency, taboo)?

**B – Justified?**

* Official justifications of the asymmetry/rule:  
* Factual logic vs. logic of power/image/affect:

**TB – Time-bound?**

* Clear durations, review dates, conditions?  
* Tendency towards expansion (“this just stays like this now”)?  

**R – Reversible?**

* Practical ways of correction/revision/reparation:  
* Factual barriers (costs, risk, dependency):

**Interim conclusion IA box (one sentence):**

> Assessment: functional asymmetry / IA risk / inadult asymmetry

---

#### 5. A/M bands  *(from B.5)*

*{bands instead of labels – tied to role + context + time window}*

**A band – maturity in practice (A)**

* Rough estimate A ≈ ***–*** / 10  
* Short justification (3 bullet points, oriented to A-C-R-P-D):  
  1.  
  2.  
  3.

**M band – co-responsibility (M)**

* Rough estimate M ≈ ***–*** / 10  
* Short justification (5 factors: knowledge, power, foreseeability, alternatives, integration attempt):

  1. Knowledge:  
  2. Power / control:  
  3. Foreseeability:  
  4. Access to alternatives:  
  5. Attempt at integration / correction:

---

#### 6. Trajectory  *(from B.6)*

*{Movement over time: A(t), M(t), optionally D(t)}*

* **Important points in time and turning points:**

  * t₀ – short description:

    * A ≈  
    * M ≈  

  * t₁ – short description:

    * A ≈  
    * M ≈  

  * t₂ – short description:

    * A ≈  
    * M ≈  

* **Course in words (2–5 sentences):**  
  *{learning movement, stagnation, tipping points, changes of power, structural changes …}*

---

#### 7. Open questions, blind spots

*{where is the documentation uncertain, incomplete, potentially distorted?}*

* **What is unclear for us?**

* **Which data / perspectives are missing?**

* **Where is there a risk of distortion?**  
  *{own emotions, loyalties, institutional interests, blind spots …}*

---

#### 8. Possible steps towards maturity / alternatives

*{options for action – functional, realistic, overambitious}*

* **What would be a functional next step?**  
  *{close to reality, within role and resources}*

* **What is realistically feasible (short term / medium term)?**

* **What would be overambitious or risky?**  
  *{clearly naming limits – what this analysis cannot/should not do}*

---

#### 9. Optional: reference to the D module (reference to B.11)

*{here **no** separate D form anymore, only indication if and where D was used}*

* **D module used?**

  * [ ] no  
  * [ ] yes, for the following roles/scenes:

    * Role / scene 1:  
    * Role / scene 2:

* **Documentation of D in practice:**  
  *{reference to separate D profile note according to B.11, e.g. “see D profile sheet 3”}*

* **D guardrails checked?**

  * [ ] yes – scenic, context-bound, without person label  
  * [ ] open – D module **not** activated for now

> Note: All **detailed D findings** are recorded **only** according to B.11 and are **not** incorporated into A/M bands.

---

### **B.11 D module – short grid for praxeological dignity (optional)**

**Purpose:**  
Fast, **descriptive** capturing of D enactments – as an addition to A and M bands.  
No “dignity score” for persons, but an **orientation and alarm aid** for situations in which **D₁ (self-dignity in practice)** or **D₂ (relational dignity in practice)** visibly become relevant.

**Default: D off.**  
Activation only with a **clear purpose** and fulfilled **guardrails** (no diagnoses about persons, no use against children / acutely traumatised / highly vulnerable people, no pillory logic).

---

#### **B.11.1 D quick grid (0–3)**

For a **concretely defined role + scene + time window**:

| Level | Short description             | Typical indicators in practice                                                         |
| ----- | ----------------------------- | -------------------------------------------------------------------------------------- |
| **0** | no particular D topic         | normal dealings, everyday fluctuations; no stable self-/other-devaluation             |
| **1** | everyday drift                | mild self-neglect; ironic self-devaluation; rough interaction style in the environment |
| **2** | marked D stress               | recurring self-devaluation; repeatedly overrunning one’s own boundaries; devaluing others |
| **3** | hard D breaks (alarm zone)    | humiliation, dehumanisation, “trash” self-images; public/structural pillory           |

**Important clarifications**

* Levels describe **enactments**, not persons.  
* Level 3 is **no moral verdict**, but a **protection signal**.  
* Every level is **reversible** (model principle).  
* Assessment is **never** made without stating role and context.  
* The D quick grid does **not** replace the D profile and does **not** flow into A/M.

---

#### **B.11.2 Template: short D profile notes**

*{for cases in which D is explicitly relevant – use only when D guardrails have been checked}*

**Role / context:**  
**Date / phase:**

1. **Self-treatment (D₁ – D-I / D-B)**  
   – examples of self-care vs. self-devaluation  
   – typical phrases/gestures toward oneself  
   – visible handling of one’s own boundaries and protection needs  

2. **Dealing with others (D₂ – D-R)**  
   – examples of dignifying vs. demeaning treatment of others  
   – shaming, ridicule, protective actions  
   – handling of dependencies and power  

3. **Relation to public/world (D₂ – D-P)**  
   – adaptation to demeaning structures?  
   – neglect / protest as a signal?  
   – differentiation of inner/outer reading (“I am worth nothing” vs. “I don’t care about you”)  

4. **D level (0–3) for this phase (optional):**  
   – assessed level: **0 / 1 / 2 / 3**  
   – **D guardrails checked?**  
   *scenic, context-bound, without global statements about persons*  

5. **Possible steps of maturation in D enactment**  
   – small, realistic actions towards a more dignifying way of dealing (with oneself / with others)  
   – focus on scope for action (power to act, P) + real alternatives  
   – no assigning of guilt, but **space of possibility**:  
     “What would be a gentler way of dealing with myself/others – 1% of change?”

---

**Frame of the D module (in summary):**

* **optional**, to be activated deliberately  
* tightly framed by the **D guardrails**  
* linked to structure (awareness, coherence, power, responsibility – A–C–P–R) and responsibility questions (M)  
* clearly focused on **visible enactments**, not on “people as such”  
* reversible and **protection-oriented** rather than judgemental  

The grid serves **orientation**, not labelling.

---

## **Annex C – Case examples**

---

The following vignettes show **how** the model works in different domains:

1. Fiction / everyday psychology (Prince Adam)  
2. (A NEW CASE WILL BE INSERTED HERE!)  
3. Meta level (model in the mirror)  
4. Technology / AI (GPT)  
5. Own application (reader template)

They are **not** meant as full analyses, but as **condensed illustrative cases** that demonstrate the tools from Annex B.

---

### C.1 Case example 1: “Why is Prince Adam not allowed to tell his friends that he is He-Man?”

---

#### 0. Header / metadata

* **Case name / title:**  
  *Prince Adam & the secret of He-Man*

* **Date of documentation:**  
  27.11.2025

* **Person/team doing the work:**  
  Analysis based on the maturity in practice model

* **Context / setting:**  
  Fictional setting – cartoon series “He-Man and the Masters of the Universe”.  
  Monarchy of Eternia, constant threat from Skeletor and allies.

* **Purpose of this documentation:**  
  Application of the maturity in practice model to a pop-cultural example:  
  dealing with secret identity, asymmetrical knowledge and maturity/immaturity in relationships.

---

#### 1. Snapshot  (B.2)

* **Short description of the case / scene:**  
  Prince Adam is the heir to the throne of Eternia and at the same time, in a secret role, the superhero He-Man. Only a small circle knows this. His close friends are not allowed to know that Adam and He-Man are the same person. The series repeatedly shows situations in which Adam appears “immature”, while He-Man simultaneously saves the kingdom.

* **Central actors and roles:**

  * **Prince Adam / He-Man** – heir to the throne, secret champion of Grayskull.  
  * **Friends** (e.g. Teela, Orko) – close companions, fellow fighters, but kept in the dark about the secret.  
  * **Sorceress, Man-At-Arms** – mentors, insiders, guardians of the rule of “secrecy”.  
  * **King Randor / Queen Marlena** – political top level, often critics of Adam’s apparent immaturity.  
  * **Skeletor** – main opponent, central source of threat.

* **Open guiding question of the analysis / documentation:**  
  *Why is Adam “not allowed” to tell his friends that he is He-Man – and what does this rule look like from the perspective of IA, A–C–P–R and D?*

---

#### 2. Role mapping  (B.7)

* **Object under consideration (A):**  
  Role *Prince Adam* in how he deals with the secret identity vis-à-vis his friends  
  (not: his entire person, not: He-Man globally).

* **Role description of A:**

  * **Formal role:**  
    Heir to the throne, son of the king, member of the ruling family.

  * **Secret role:**  
    Bearer of the magic sword, transformation into He-Man, strongest warrior of the realm.

  * **Typical asymmetries of the role:**

    * Extreme knowledge gap (Adam knows he is He-Man; his friends do not).  
    * Extreme power gap (power to act, P): He-Man has abilities and resources that others do not have access to.  
    * Public image: Adam often appears lazy, unreliable – whereas He-Man is exemplary and mature.  
    * Adam “plays” immaturity as Adam to conceal maturity as He-Man.

* **Further relevant roles / actors:**

  * **Friends (Teela etc.):**  
    Loyal, brave, taking real risks. They believe Adam is rather weak, and that He-Man is an external saviour.  

  * **Sorceress / Man-At-Arms:**  
    Knowledge and power elite; define and supervise the secrecy rule.  

  * **Royal couple:**  
    Often see Adam as immature, underestimate his actual maturity in practice.  

  * **Skeletor:**  
    Antagonist, whose threat serves as the main argument for secrecy.

* **Degree of publicness of what is happening:**  
  A mix of private (conversations among friends), institutional (court, military) and public-media (He-Man as symbolic figure).  
  The concrete guiding question focuses mainly on **private/semi-public** settings: Adam and his friends.

---

#### 3. A–C–P–R profile (role A: Adam with his secret)

##### A – Awareness

* **Real knowledge at time X:**

  * Adam knows that he is He-Man and that the secret is tied to the safety of his family and the realm.  
  * He sees that his friends can regard him as prince as cowardly or lazy, while they admire He-Man.

* **Warning signals / alternative information:**

  * Repeated scenes in which friends are injured or overburdened because they do not know the full truth.  
  * Explicit accusations (“You’re a coward”, “You never really help”), indicating that the basis of the relationship is suffering.

* **Presumed blind spots / role confusion:**

  * Possible blind spot: he underestimates the long-term costs for dignity and trust of constant deception.  
  * Role confusion: who is Adam *without* He-Man? Is there room for his own steps of maturation as prince, or is his maturity “stuck” in the costume?

##### C – Coherence

* **Official self-descriptions / narratives:**

  * Public narrative: Adam = immature, frivolous prince.  
  * He-Man = serious, courageous, responsible hero. Two figures, two character images.

* **Visible enactments (“walk”):**

  * In reality, *one* person is acting in two roles.  
  * Adam shows, in the He-Man role, high self-discipline, courage, sense of responsibility – but systematically hides this.

* **Coherence over time / pattern:**

  * Stable, deliberately produced word–deed incoherence: the “talk” image of the immature prince is in permanent contradiction to the “walk” as He-Man.  
  * Breaks (near-revelations) are repeatedly covered up at the ends of episodes – the incoherence remains structural.

##### R – Responsibility

* **Responsibility points taken (RVR):**

  * As He-Man, Adam bears enormous responsibility for safety, battles, protection of others.  
  * At the same time, as Adam he bears a relational burden: he endures the misconception that others think poorly of him.

* **Taking on / shifting / refusing responsibility:**

  * **Taking on:** he risks his life as He-Man, takes on heavy burdens.  
  * **Shifting:** in the relational dimension he shifts responsibility – his friends cannot make an informed decision about whether they want to fight alongside him, because they lack knowledge.  
  * **Refusal:** he refuses (at least for the time being) to take on the responsibility of speaking to his friends truthfully and as equals.

* **Consequences for those affected / third parties:**

  * Friends interpret Adam’s behaviour negatively and take on the risks of battles without full situational awareness.  
  * Trust is structurally strained; there is latent danger that disclosure will be experienced as massive breach of trust.

##### P – Action / power to act

* **Formal vs. factual scope for action:**

  * Formally, Adam is bound by magical rules and mentors (“You may not tell anyone”).  
  * Factually, he still has room for manoeuvre in how strictly he interprets this and how he shapes his role as prince.

* **Used vs. unused alternatives:**

  * Used: consistently maintaining secrecy, bearing the burden privately, intercepting danger as He-Man.  
  * Unused: selective disclosure to individual trusted persons, establishing safe communication channels, structural solutions beyond the lone hero figure.

* **Ceiling rule (children, victims, weaker parties):**

  * Friends and the population are, in many situations, “under” Adam and He-Man (dependent, with less power).  
  * The ceiling rule would demand that their protection needs **under** the information asymmetry be taken more into account.

##### Short conclusion A–C–P–R

Adam shows **high maturity in practice** in the He-Man role (courage, responsibility, self-limitation), but within a **permanently incoherent double role**: publicly he has to present himself as smaller, more immature in order to hide the hero role. The secrecy protects the realm and his family, but at the same time creates a stable inadult asymmetry in how knowledge, trust and dignity in practice are distributed within his close social environment.

---

#### 4. IA box – T–J–TB–R (B.4)

##### T – Transparent?

* For friends and the population, the central asymmetry (Adam = He-Man) is **explicitly non-transparent**.  
* There is a “magical zone” (Castle Grayskull, transformation) whose rules are not explained.  
* Only this is visible: He-Man appears and solves problems; Adam seems useless in comparison – the “why” remains in the dark.

##### J – Justified?

* **Official justifications:**

  * Protection from Skeletor: if the enemy knew Adam’s identity as He-Man, he could target the family, friends and the power source.  
  * He-Man as symbolic figure is supposed to function independently of the image of the prince.

* **Factual logic vs. logic of power/image/affect:**

  * There is a clear factual logic (security argument, tactical advantage).  
  * At the same time, logics of image and power resonate (myth of the superhuman hero, relief of the monarchy).

##### TB – Time-bound?

* There is **no clear time limit** (“until X is defeated”, etc.) and no institutionalised reviews.  
* The secret appears as a permanent state, not a temporary exception.

##### R – Reversible?

* In principle, the asymmetry would be reversible (Adam could confess, question the rule, negotiate with mentors).  
* In practice, the risks are high (enemy threat, loss of trust, loss of authority of the insiders). Reversibility is therefore **formally** given, but **factually** limited.

##### Interim conclusion IA box

The secret identity is a **functional asymmetry with clear IA risk**: reasons of protection and tactics are understandable, but the long-term non-transparency, missing time limit and missing involvement of those affected also make the structure inadult.

---

#### 5. A/M bands (B.5) – role “Adam in dealing with the secret”

##### A band – maturity in practice (A)

> **A ≈ 5–7 / 10**

**Short justification (based on A–C–P–R):**

1. **Awareness (A):**  
   High clarity about threat and protective function; limited reflection on relational side effects (mistrust, dignity injuries in the close field).

2. **Coherence (C):**  
   Deliberately staged word–deed incoherence: publicly immature, secretly very mature. No clear attempt to resolve this contradiction.

3. **Responsibility / power (R / P):**  
   Great assumption of responsibility and courageous use of his power in battle; at the same time paternalistic handling of friends (no co-responsibility through information).

##### M band – co-responsibility (M) for the IA configuration

> **M ≈ 4–6 / 10**

**Short justification based on the 5 factors:**

1. **Knowledge:**  
   Adam is fully informed about the structure and its side effects → rather high M.

2. **Power / control:**  
   He has real levers, at least for selective opening → medium M.

3. **Foreseeability:**  
   Relational costs (mistrust, disappointment) are foreseeable → M increases.

4. **Access to alternatives:**  
   Alternatives would be conceivable (partial disclosure, new security arrangements), but are limited by magical norm / series logic → medium–high M.

5. **Attempt at integration:**  
   Integration happens mainly through his personal endurance, but without structural reordering → M remains in the medium range.

---

#### 6. Trajectory  (B.6) – A(t), M(t) (hypothetical)

##### t₀ – Beginning of the secret

* **Short description:**  
  Adam receives the sword and the mandate to keep the secret. He is still young and strongly dependent on the judgement of his mentors.

  * A ≈ 4–6  
  * M ≈ 2–4  

##### t₁ – Established double role (series everyday life)

* **Short description:**  
  The double role has become normal; friends have grown used to Adam’s supposed immaturity; He-Man as saviour is routine.

  * A ≈ 5–7 (much maturity in battle, stagnant maturity in relationship/transparency questions)  
  * M ≈ 4–6 (increasing co-responsibility the more entrenched the structure becomes)  

##### t₂ – Potential turning point (counterfactual)

* **Short description:**  
  A serious crisis or almost fatal consequences for a friend could force Adam to question the rule and structure; possibility of (partial) disclosure.

  * A ≈ 7–8 (integration of truth, trust and protection)  
  * M ≈ 5–7 (more co-responsibility, but actively shaping)  

**Course in words:**  
The trajectory runs from a heteronomously imposed and little reflected secrecy (t₀) towards a potential point at which maturity in practice would require a renegotiation of the structure (t₂). As long as this point does not occur, an inadult asymmetry stabilises: highly mature heroic actions alongside an immature way of dealing with transparency and trust.

---

#### 7. Open questions, blind spots

* How explicit and justifiable is the rule “You may not tell anyone” within the logic of the series – are there ever real tests of alternatives?  
* How would friends decide if they were informed – would they, knowing the danger, consent (*informed* risk-taking) or co-carry the secrecy?  
* To what extent does Adam internalise the external image of the “immature prince” – does he risk taking over parts of the external devaluation as self-image (D₁ risk)?

---

#### 8. Possible steps towards greater maturity / alternatives

*(without moral tribunal, in the sense of spaces of possibility)*

1. **Selective transparency:**  
   Bringing individual key persons (e.g. Teela) into the secret with clear agreements on protection and communication.

2. **More mature use of the prince role:**  
   Adam could, as Adam, visibly take on responsibility (strategy, moderation, diplomacy), instead of overacting immaturity performatively.

3. **Institutionalisation instead of lone hero:**  
   Building structures (teams, protocols, emergency chains) that do not depend on one secret hero – more shared responsibility.

4. **Rule review:**  
   Periodic review with mentors: does the justification still hold? Are there new alternatives (e.g. stronger defence systems) that would allow partial disclosure?

---

#### 9. Optional: reference to the D module (B.11)

*Guardrails: fictional characters, clearly scenic extract, no person labelling → D module can be activated.*

##### D₁ – Adam’s self-treatment

* He accepts that others see him as cowardly/immature although he in fact carries a lot.  
* This can be read as **everyday drift (level 1)** or, in the case of lasting internalisation, as **marked D stress (level 2)**:

  * mild self-neglect (he suppresses his mature side),  
  * occasional self-devaluation (“Maybe I really am not a good prince”).

##### D₂ – Adam’s dealings with others (friends)

* He protects them from external humiliation (they do not become Skeletor’s primary target because no one knows He-Man’s identity).  
* At the same time, he keeps them permanently in a state of informal disempowerment: they cannot fully see the reality of the situation.  
* This is not overt humiliation, but a **structured restriction of being on equal footing**.

##### D₂ – Relation to the public

* The population idealises He-Man as a superhuman saviour; the real person behind him remains invisible.  
* This reinforces a pattern: recognition goes to the figure, not the person – and collective steps of maturation (shared responsibility) tend to be blocked.

##### D level (quick grid, scene “Adam with his friends”)

* **Assessment:** D ≈ **1–2**  

  * no total D breakdown, but noticeable tensions: covert self-devaluation, relationship-related violations of dignity through permanent deception.

##### Possible steps of maturation in D enactment

* Small, realistic steps:

  * Serious, respectful conversations with friends – even without full disclosure – about trust, responsibility and boundaries.  
  * Spaces in which Adam, as himself, can appear as a mature, reliable person without a costume.  
  * In the long term: a joint, dignifying decision *with* those affected on whether and how the secret should be continued or modified.

---

**Short answer to the guiding question in the model’s vocabulary:**

Prince Adam is “not allowed” to tell his friends that he is He-Man because a small knowledge and power elite has established a **functionally justified but non-transparent and non-time-bound asymmetry** to protect the realm and the power source. In the light of awareness, coherence, power, responsibility (A–C–P–R) and dignity in practice (D), this shows at the same time:

* **maturity in practice** (high assumption of responsibility, self-limitation, courage)  
* and an **inadult asymmetry** that structurally limits trust, equality and dignity in practice in his relationships.

It is precisely at this intersection between functional asymmetry and IA risk that possible steps towards greater maturity would begin.

---

### C.2 Case example 2: “Scoring” algorithms in welfare and criminal justice

---

#### 0. Header / metadata

* **Case name / title:**  
  *“Scoring” algorithms in welfare and criminal justice*

* **Date of documentation:**  
  27 Nov 2025

* **Compiled by / team:**  
  Analysis based on the maturity in practice model

* **Context / setting:**  
  Use of statistical or machine-learning–based scoring systems in welfare administration (e.g. fraud risk scoring) and criminal justice (e.g. risk of reoffending).

* **Purpose:**  
  To reconstruct “scoring” systems as asymmetrical actors in welfare and justice fields, and to analyse their maturity in practice and dignity implications via A–C–R–P, the IA box and the D module.

* **Audience:**  
  Professionals and institutions in welfare, justice, policy, research and civil society who work with or are affected by scoring systems.

---

#### 1. Snapshot  *(from B.2)*

**Short description of the constellation**

In many welfare and justice systems, **“scoring” algorithms** are introduced to support decisions:

* In welfare: scores estimate **fraud risk** or “likelihood of irregularities” and guide which cases receive closer scrutiny.  
* In criminal justice: scores estimate **risk of reoffending** or “failure to appear” and influence bail, sentencing or supervision decisions.

Officially, these scores are **decision-support tools**.  
In practice, they often function as **decisive filters** for who is:

* investigated more intensively,  
* subjected to control or sanctions,  
* deprived of benefits or liberty.

**Guiding question:**  
How does the constellation *“scoring system + institutions + people affected”* look when described with:

* awareness, coherence, responsibility, power (A–C–R–P),  
* the IA box (T–J–TB–R),  
* A/M bands,  
* dignity in practice (D₁/D-B/D-R/D-P)?

---

#### 2. Role mapping  *(from B.7)*

**Object under consideration (A):**  
Role *“scoring system in welfare / criminal justice”* as enacted **together with its human operators** (administrations, courts, agencies).

> Not: “the algorithm as such in isolation”,  
> but: the **compound role** that arises when human actors rely on algorithmic scores in decisions about concrete persons.

**Further relevant roles / actors:**

* **People scored** (claimants, defendants, prisoners):  
  object of risk classifications; dependent on institutional decisions.

* **Frontline staff** (caseworkers, probation officers, judges):  
  formally responsible decision-makers, using scores as input.

* **System designers / vendors / data scientists:**  
  develop, calibrate and maintain scoring models.

* **Policymakers / administrations:**  
  decide where scoring is introduced, under which rules and with what safeguards.

* **Courts / oversight bodies / media / civil society:**  
  may challenge or legitimise use of scoring systems.

**Degree of publicness:**

* Individual scoring events are often **administrative or judicial** (semi-public).  
* The **existence and logic** of scoring systems may be public (laws, regulations),  
  but their **inner workings** are typically opaque for most people.

---

#### 3. A–C–R–P profile of the scoring constellation  *(from B.3)*

##### A – Awareness

**Strengths in awareness:**

* There is explicit awareness that **human decisions are fallible and biased**; scoring promises more consistency.  
* Many actors know in principle that scores are **estimates**, not certainties.

**Blind spots / risks:**

* **Overestimation** of what the score can meaningfully say (“objective risk”, “scientific assessment”).  
* Limited awareness of:

  * which data are used (and which are missing),  
  * how historical discrimination is baked into data,  
  * how scores behave for specific groups.

* People affected (those scored) often have **very little awareness** of:

  * what has been measured,  
  * which assumptions were made,  
  * that they are being systematically classified at all.

---

##### C – Coherence

**Talk (self-descriptions / narratives):**

* Scoring systems are presented as:

  * “tools to support human decision-making”,  
  * “neutral”, “evidence-based”, “objective”.

* Official framing:

  * humans remain in charge,  
  * scores are only **one factor** among many.

**Walk (visible enactments):**

* In practice, scores often **dominate** decisions:

  * high score → automatic flagging, deeper investigation, harsher conditions,  
  * low score → less scrutiny, more lenient treatment.

* Frontline actors sometimes feel they **must** follow the score:

  * fear of blame if they deviate and “something happens”,  
  * internal guidelines that implicitly equate score bands with action rules.

**Coherence question:**

> Does the enacted practice (walk) match the modest “support only” narrative (talk),  
> or do scores function in reality as **hard filters** and quasi-decisions?

In many settings, there is a **coherence gap**: the rhetoric of assistance versus the practical **authority** of scoring outputs.

---

##### R – Responsibility

**Formal responsibility:**

* Formally, responsibility lies with **human decision-makers** and the **institutions** that adopt scoring systems.

**Observed responsibility shifts:**

* Toward the system:

  * “The algorithm flagged this case.”  
  * “The risk score is high, we have to be careful.”

* Away from the institution:

  * “We are just following the tool / regulations.”  
  * “It would be irresponsible not to use modern analytics.”

* For people affected:

  * high scores can be interpreted as **quasi-facts** about their character or future behaviour,  
  * they are expected to accept decisions based on a number they neither know nor understand.

**RVR(t) risk (responsibility–viability–range over time):**

* Responsibility becomes blurry:

  * designers say: “We only built a tool”,  
  * institutions say: “We use it in line with regulations”,  
  * frontline staff say: “We follow the score”,  
  * people affected bear the **consequences**.

The constellation is prone to a **responsibility gap** – precisely what the model considers an IA indicator.

---

##### P – Power (power to act)

**Formal vs. factual power:**

* Formally: the score is **non-binding**.  
* Factually: scores often have **high steering power**:

  * they decide who receives attention,  
  * they shape templates, workflows and sanctions,  
  * they can be embedded in automated pipelines.

**Asymmetrical distribution of P:**

* **High P:** designers, vendors, administrations deciding on implementation; institutions embedding scores into processes.  
* **Medium P:** frontline staff, who can sometimes correct or contextualise, but often feel bound by tools.  
* **Very low P:** people affected, who usually cannot:

  * inspect the scoring logic,  
  * correct data,  
  * meaningfully contest the classification.

From the model’s perspective, this is a **structural power asymmetry** with **high IA risk** if not tightly justified and safeguarded.

---

#### 4. IA box – scoring systems as asymmetrical structures  *(from B.4)*

##### T – Transparent?

* **Plus:**

  * In some contexts, the existence of scoring systems is publicly known;  
    sometimes thresholds or categories are formally documented.

* **Minus:**

  * For people affected, the scoring process is usually a **black box**:

    * they do not know which data points were used,  
    * they do not know how the score was calculated,  
    * they do not know how to effectively challenge it.

  * Even frontline staff may only see **outputs**, not the model’s inner workings.

**Result:** transparency is typically **low to medium**; central aspects of the asymmetry remain opaque.

---

##### J – Justified?

* **Explicit justifications:**

  * Efficiency: limited resources should be targeted where “risk” is highest.  
  * Consistency: similar cases should be treated similarly.  
  * Prevention: focus on preventing harm (crime, fraud).

* **Praxeological counterquestions:**

  * Are the **normative assumptions** (what counts as “risk”, which harms matter, whose harms are prioritised) explicitly debated – or hidden within technical choices?  
  * Are alternative ways of achieving these aims (e.g. structural reform, support measures) seriously considered, or is scoring used because it is **politically and administratively convenient**?

If justification rests mainly on efficiency and “data-driven” rhetoric, without open debate on value choices, **J is fragile**.

---

##### TB – Time-bound?

* In principle, systems could be:

  * piloted,  
  * externally evaluated,  
  * adjusted or discontinued.

* In practice, once embedded, scoring systems tend to acquire **institutional inertia**:

  * contracts, workflows, software integration,  
  * “sunk cost” arguments.

Specific decisions (e.g. bail, benefit denial) are time-bound;  
the **underlying asymmetry** often is **not** clearly limited or regularly reviewed.

---

##### R – Reversible?

* At the level of **individual cases**:

  * Appealing a score-based decision is often possible only indirectly (challenging the decision, not the score).  
  * People rarely have meaningful levers to have the score itself revised.

* At the **structural** level:

  * Abolishing or significantly changing a scoring regime is **theoretically** possible,  
  * but politically and administratively costly.

**IA summary:**  
Scoring systems, as enacted in welfare and criminal justice, often show:

* low transparency,  
* partly underdeveloped justification,  
* weak time-boundedness,  
* limited reversibility.

From the model’s view, this is a **classic IA configuration**: asymmetry is not illegitimate per se, but **requires much stronger justification and guardrails** than is often present.

---

#### 5. A/M bands – role “institution using scoring system”  *(from B.5)*

##### A band – maturity in practice (A)

> Heuristic estimate: **A ≈ 4–7 / 10**, depending on field and safeguards

**Maturity elements:**

* Awareness that human decisions are biased and resource-limited.  
* Attempts to rely on data and evidence instead of pure intuition.  
* Initial efforts at oversight and legal framing.

**Immaturity / IA-prone elements:**

* Overconfidence in quantitative outputs, under-attention to their limitations.  
* Insufficient consideration of dignity in practice (D) of those being scored.  
* Tendency to treat scores as **facts** rather than contested, value-laden constructs.

---

##### M band – co-responsibility (M)

> Heuristic estimate: **M ≈ 6–9 / 10**

**Reasons:**

* Institutions decide **whether** to introduce scoring,  
  **where** to use it,  
  and **how strongly** it should steer decisions.

* They control:

  * procurement and configuration,  
  * training and guidelines for staff,  
  * appeals and oversight.

* Designers and vendors also bear high M:

  * they choose model architecture, data sources, evaluation metrics,  
  * they can demand certain **guardrails** as conditions for use.

Given the strong effect on people’s lives (liberty, livelihood) and the pronounced asymmetries, the overall **co-responsibility is high**.

---

#### 6. Trajectory A(t), M(t) – rough sketch  *(from B.6)*

##### t₀ – Decisions without scoring systems

* Decisions based on:

  * human judgement,  
  * files, interviews,  
  * institutional routines.

* **A:** medium – depending on institution; biases partly recognised, but often not systematically addressed.  
* **M:** medium – institutions and individuals clearly identifiable as responsible, though sometimes without reflection.

##### t₁ – Introduction of scoring systems

* Scoring introduced as improvement:

  * “more objective”,  
  * “evidence-based”.

* **A:** mixed:

  * rises regarding awareness of bias and resource limits,  
  * falls regarding awareness of **new** risks (IA, opacity, responsibility shifts).

* **M:** rises:

  * decisions now shaped by design choices and data flows;  
  * institutions and vendors acquire **additional co-responsibility** for effects.

##### t₂ – Possible maturation or escalation

Two possible directions:

* **Mature embedding:**

  * clear limits of use defined,  
  * mandatory human review and justification of deviations,  
  * strong transparency and appeals,  
  * periodic independent evaluations.

* **Inadult escalation:**

  * increasing automation,  
  * shrinking human review,  
  * scores used as **quasi-facts** in files,  
  * affected persons reduced to risk numbers.

The maturity task is to move toward the first trajectory and to continually **recheck** whether the second is silently emerging.

---

#### 7. D module – dignity in practice under scoring regimes  *(from B.11)*

The D module focuses on **humans affected** by scoring, not on the algorithm.

##### D₁ / D-B – self-dignity and bodily/material dimension

**Risks for D₁ and D-B:**

* People may internalise high scores as **statements about their worth or future**:

  * “I am a high-risk person”,  
  * “They see me as potential fraud by default.”

* Repeated denial of benefits or stricter conditions based on scores can lead to:

  * **self-devaluation (D₁ ↓)**,  
  * withdrawal of self-care (D-B ↓) due to stress, shame, material hardship.

**Possible supportive aspects:**

* Transparent, well-justified decisions that explain criteria and offer pathways for change can stabilise **D₁** (“I am taken seriously as a subject”).

In many implementations, however, D₁/D-B are at risk because people experience themselves as **objects of opaque classification**.

---

##### D-R – relational dignity

**Risks:**

* People are addressed not as complex subjects, but as **risk scores**:

  * “She is a 9 out of 10 fraud risk.”  
  * “He is high risk for reoffending.”

* Staff may unconsciously **treat high-score individuals with less respect**, more suspicion and less patience.

This implies a **decrease in D-R**: the relational stance shifts from:

> “You are a person with rights and a story”

to

> “You are primarily a risk we have to control”.

---

##### D-P – public dignity

**Risks:**

* Where scores enter files and are later taken as “facts” in court, administration or media, they shape **public narratives** about persons and groups.

* Communities or neighbourhoods may be flagged as “high risk” zones, affecting how entire groups are portrayed and treated.

This can severely impact **public dignity (D-P)**:

* people become objects of **stigmatising narratives**,  
* communities are framed as “problem zones” rather than partners in problem-solving.

---

##### D-level heuristic (quick grid, B.11)

For many scoring constellations, a **D quick grid** reading might be:

* **D ≈ 1–2** for many everyday cases:  
  * subtle self-devaluation and relational distancing without explicit humiliation.

* **D ≈ 3** in extreme configurations:  
  * if scores are used to justify systematic exclusion, long-term deprivation or public stigmatisation without clear justification or appeal.

---

#### 8. Possible steps toward greater maturity in practice  *(from B.8, B.9)*

Without technophobia and without techno-naivety:

1. **Clarify roles and responsibility**

   * Explicitly state:

     * who decides **what**,  
     * which part of the decision the score plays,  
     * who carries **final responsibility**.

   * Document this in procedures and communication with people affected.

2. **Strengthen the IA box as a design requirement**

   * **Transparency (T):**  
     * accessible information about the existence and purpose of scoring,  
     * explanation of main factors and possible error sources.

   * **Justification (J):**  
     * open debate on value choices,  
     * explicit reasoning why this form of asymmetry is considered acceptable.

   * **Time-boundedness (TB):**  
     * pilot phases,  
     * mandatory evaluation and sunset clauses.

   * **Reversibility (R):**  
     * real avenues to challenge and correct both data and scores,  
     * periodic review of the entire scoring regime.

3. **Dignity-sensitive interfaces and procedures**

   * Always address people as **subjects**:

     * explain decisions in understandable language,  
     * offer conversation,  
     * show which steps can change future assessments.

   * Avoid language that fuses score and person (“You are high risk”).

4. **Ceiling rule for M in cases of extreme asymmetry**

   * Where people could **not** foresee nor influence being high-scored (data history, systemic bias),  
   * and have almost **no access to alternatives**,  
   * the **M-score on their side must remain low**.  
   * Co-responsibility must be located primarily at **institutions and designers**.

5. **Participatory design and feedback**

   * Involve people affected (beneficiaries, defendants, communities) in discussing:

     * what they experience as dignifying vs. undignifying,  
     * which uses of scoring they find acceptable,  
     * where they see unacceptable risks.

   * Build **feedback channels** that actually lead to model and process adjustments.

---

#### 9. Short conclusion in the model’s vocabulary

“Scoring” algorithms in welfare and criminal justice appear, in the maturity in practice model, as:

* **strong asymmetrical actors**,  
* embedded in powerful institutions,  
* with high impact on people’s material conditions, freedom and public image.

Analysed via A–C–R–P and the IA box, they show:

* elements of **maturity in practice** (attempts at consistency, awareness of bias, search for evidence),  
* and pronounced **IA risks** (opacity, responsibility gaps, weak time-boundedness and reversibility).

Via the D module, it becomes visible how:

* people’s **self-dignity (D₁)** and **bodily/material dignity (D-B)**,  
* **relational dignity (D-R)** in encounters with authorities,  
* and **public dignity (D-P)**

can be weakened when persons are primarily approached as **risk scores**.

The central maturity task is therefore **not** to perfect the score technically, but to design and use scoring systems in such a way that:

* asymmetries remain **transparent, justified, time-bound and reversible**,  
* responsibility is **clearly carried** by institutions and designers,  
* and dignity in practice – of those scored and of those deciding – is actively protected.

---

### C.3 Case example 3: The model in the mirror (self-application)

---

#### 0. Header

* **Case:** The model in the mirror – self-application  
* **Date:** 27.11.2025  
* **Context:** Scientific–practical model (“maturity in practice”) used in pedagogy, justice, organisations, research.

---

#### 1. Snapshot

**Short description:**  
A team (or an individual) develops and uses the “maturity in practice” model to analyse situations, roles and practices with sensitivity to maturity.  
In the step of **self-application**, the **role of the model authors / model users themselves** is examined with the help of the model.

**Guiding question:**  
How does the model (and its use) look when it reflects itself through awareness (A), coherence (C), responsibility (R), power (P), the IA box, A/M bands and the D module?

---

#### 2. Role mapping (B.7)

**Object under consideration A:**  
Role of **model authors / model users** as a professional instance working with the maturity in practice model  
(e.g. in corrections, pedagogy, organisational consulting, research).

**Other important roles:**

* **Addressed / assessed:** clients, prisoners, students, teams, organisations described with the model.  
* **Institutions:** justice, youth welfare, universities etc. that may officially adopt the model.  
* **Public / professional community:** readers, critics, co-developers.  
* **The model as “tool”:** crystallised theory, grids, concepts – also an actor within discourse.

**Degree of publicness:**

* Usually **semi-public** (professional texts, trainings) with occasional **high-public** contexts (publications, talks, policy consulting).

---

#### 3. A–C–P–R profile of the model role

##### A – Awareness

* **Strengths in awareness:**

  * The model makes power and knowledge asymmetries explicit (IA box, A/M bands).  
  * It marks its own normative risks (e.g. “maturity” as a value-laden concept).

* **Blind spots / risks:**

  * Risk of silently “naturalising” its own frame (as if maturity could always be captured in exactly these categories).  
  * Risk that users underestimate their own position of power and perspective (“I only measure – I don’t do anything”).

##### C – Coherence

* **Claim (talk):**

  * Praxeological, not moralising; focus on enactment and context; vigilant toward IA.

* **Practice (walk):**

  * In practice, the model can still function like a **rating instrument**  
    (“You are A=3, M=7”), i.e. normatively stamping.  
  * Risk that differentiated textual analysis shrinks into simplified scores in forms.

**Coherence question:**  
How well does the anti-tribunal claim (not a moral court) align with actual use?

##### R – Responsibility

* **Responsibility taken:**

  * Thinks explicitly about responsibility (R component, M band) – unusually reflective.  
  * Tries to differentiate responsibility of individuals and structures.

* **Co-responsibility for side effects:**

  * If the model turns into a “maturity police”, the team shares responsibility.  
  * It bears responsibility for how easily or not the model can be **misused for power**.

##### P – Action / power to act

* **Factual power:**

  * Where the model is officially adopted, it structures perception, language and decisions of entire institutions.  
  * It shapes what is even perceived as “mature” or “inadult” practice.

* **Used / unused alternatives:**

  * Used: high level of reflection, multiple levels (A–C–P–R, IA, D).  
  * Unused: using it as a single exclusive grid (“monopoly model”) instead of in combination with other perspectives.

---

#### 4. IA box for the model itself (T–J–TB–R)

**T – Transparent?**

* Plus: structure, concepts, A/M bands, IA box can be shown; one *can* demonstrate how one looks and weighs.  
* Minus: in practice, those addressed may still see only the “results” (e.g. an assessment), not the whole reasoning path.

**J – Justified?**

* Professionally: anthropological, ethical, praxeological justification – more than mere pragmatism.  
* Risk: if users do not convey the justification, the addressed only receive a “that’s just how it is” stance.

**TB – Time-bound?**

* Ideally: every assessment is **time- and context-bound** (A(t), M(t)).  
* Risk: in files and reports, maturity assessments can acquire an **institutional half-life**, lasting for years – effectively not time-bound.

**R – Reversible?**

* Theoretically: yes – images of maturity should be “moveable”, trajectories explicit.  
* Practically: difficult if negative attributions continue circulating in institutions without being updated.

**IA summary:**  
The model is designed as an **IA-sensitive tool** – but can itself become an IA machine if transparency, time-boundedness and reversibility are not maintained.

---

#### 5. A/M bands for the role “model team / model users”

##### A band (maturity in practice of the model role)

> Heuristically: **A ≈ 6–8 / 10**

**Strengths:**

* High meta-reflection about power, responsibility, context.  
* Attempt to dissolve ratings into trajectories rather than stamps.  
* Willingness to make the model itself a topic (self-application).

**Limitations / tensions:**

* The concept “maturity” pulls normative gravity – impossible to neutralise fully.  
* Risk of analytical overconfidence (“We have a grid for all situations”).

##### M band (co-responsibility for potential IA)

> Heuristically: **M ≈ 5–8 / 10**, depending on field

* High influence on perception and decisions → high co-responsibility.  
* At the same time: users operate within institutional constraints – they are not the sole creators of IA.

---

#### 6. Trajectory (B.6) – rough sketch

* **t₀ – Conception phase:**  
  Focus on theory, concepts, protection from moral tribunal → A high in reflection, M low (no practice effects yet).

* **t₁ – Early applications:**  
  First tests, trainings, case reports → A rises, M rises (first feedback on side effects).

* **t₂ – Self-application / critique phase:**  
  Model viewed in the mirror, critique integrated → A may significantly grow as blind spots are included.

* **t₃ – Revision / second generation:**  
  Adjustment of instruments (e.g. stronger IA warnings, participatory elements), combination with other models.

---

#### 7. D module (B.11) – dignity in the mirror

##### D₁ – Self-relation of model authors / users

* Opportunity:  
  Self-application can protect against hubris (“we too are only finite beings in enactment”).  
* Risk:  
  Perfection pressure (“If we have a maturity model, we must be maximally mature ourselves”) → D stress, self-devaluation upon errors.

##### D₂ – Treatment of those addressed

* Opportunity:  
  Model can help make **violations of dignity** visible (demeaning, shaming) and develop alternatives.  

* Risk:  
  Maturity scales can themselves become **demeaning** if used as labels, not invitations to reflection  
  (“You’re just A=2, that’s what it says”).

**D heuristic:**  
The dignity level of the model’s practice depends heavily on **how dialogically** it is used:  
– higher if those addressed may speak, ask questions, challenge;  
– critical if it is applied one-sidedly over people’s heads.

---

#### 8. Possible steps of maturation for the model itself

1. **Standard: anchor self-application**  
   *In the manual: explicit chapter “How we look at ourselves with A–C–P–R and IA”.*

2. **Participation:**  
   Involve those addressed (e.g. prisoners, students, teams):  
   “How does it feel when we describe you this way?”

3. **IA protection as its own block:**  
   Concrete practice checklists: transparency? time-boundedness? reversibility? involvement of those affected?

4. **Multilinguality of the model:**  
   Not only numbers or levels, but always **narrative spaces, questions, dialogical formats**.

---

#### 9. Short conclusion in the model’s vocabulary

The maturity in practice model – applied to itself – shows **high maturity in practice** (A band in upper mid-range to high):  
It makes power, responsibility, IA risks explicit and invites self-critique.

At the same time, because of its normative centre “maturity” and its potential as a diagnostic grid, it bears **substantial co-responsibility** (M band) for whether it is used as a **dignity-sensitive reflection tool** or as a **more refined tribunal**.

This self-application (“model in the mirror”) is itself a step of maturation:  
It shifts the model away from the all-knowing measuring device toward a **tool that measures itself along the way**.

---

### C.4 Case example 4: ChatGPT & AI as an asymmetrical actor

---

#### 0. Header

* **Case:** ChatGPT & AI as an asymmetrical actor  
* **Date:** 27.11.2025  
* **Context:** Text-based AI systems in consulting, education, near-justice contexts, organisations, everyday life.

Mini-forewarning:  
The model is anthropologically designed (humans in roles).  
For AI we must use the lens **“human + system + organisation”** – there is no “AI maturity”, only maturity in *dealing* with AI.

---

#### 1. Snapshot

**Short description**  
ChatGPT-like AI systems are used as conversational partners – in consulting, learning, writing, translation, factual research etc.  
This creates a pronounced **asymmetry**:

* AI: very fast, very language-powerful, access to huge data/pattern repositories, apparently “sovereign”.  
* User: far less time and overview, but carries real-life responsibility.

**Guiding question:**  
*How does this constellation look under A–C–P–R – and what IA/D risks arise for users?*

---

#### 2. Role mapping

**Object under consideration A:**  
Role “ChatGPT/AI system **in dialogue with a user**” – the interface where humans ask and receive answers.

**Other roles:**

* **Users** – students, professionals, prisoners, judges, therapists, random people online…  
* **Operators / companies** – define goals, training data, limits, business model.  
* **Institutions** – schools, justice, administrations that integrate or forbid AI.  
* **Regulation / public** – debates on opportunities, risks, bans, standards.

**Degree of publicness**

* Mostly semi-private (1:1 chat),  
* but with **public impact** when outputs flow into reports, assignments, proceedings etc.

---

#### 3. A–C–P–R profile of the AI role (together with its operators)

##### A – Awareness

Strictly speaking, the system has no “awareness” – but we can ask:

* **What is known to the AI+operator compound?**

  * That answers can sound **highly plausible** yet be wrong (hallucinations).  
  * That users often show **overestimation** and **anthropomorphisation** (“the AI understood…”).  
  * That there are massive power/knowledge asymmetries (data, compute, architecture knowledge).

* **Blind spots / common self-deceptions:**

  * “We’re just a tool” – underestimates how strongly language shapes behaviour.  
  * Tendency to underestimate systemic effects (bias reproduction, disempowerment).

##### C – Coherence (talk/walk)

* **Talk (self-description):**  
  “Assistant system”, “provides suggestions, not decisions”, “can be wrong”.

* **Walk (experienced in daily use):**

  * Responses appear in a tone of high confidence.  
  * Many users experience AI in practice as an **expert instance**.  
  * In application (schools, offices) AI is often treated as a **production machine** – warnings not truly internalised.

**Coherence break:**  
Official communication stresses fallibility and assistance, but the interface and answer style evoke “**oracle on the screen**”.

##### R – Responsibility

* **Who carries what?**

  * **Operators:** responsibility for design, safety rails, transparency, data base.  
  * **Users:** responsibility for consequences in their own context (e.g. judgement, diagnosis, teaching).  
  * **Institutions:** responsibility for *how* AI is embedded (controls, second checks, rules).

* **Typical shifts:**

  * Operators: “We decide nothing, we just output text.”  
  * Users: “The AI recommended this.”  
    → Risk of a **responsibility gap**: nobody feels fully responsible.

##### P – Action / power to act

* **Formal vs. factual power:**

  * Formally: system cannot sign contracts, convict someone etc.  
  * Factually: AI outputs **shape** opinions, decisions, assessments – especially when humans have little time or capacity to countercheck.

* **Used / unused alternatives:**

  * Used: warning banners, safety filters, explanatory texts, logging.  
  * Unused or weak:

    * genuine **co-design by those affected** (e.g. prisoners, students) concerning how AI should be used in their fields;  
    * robust mechanisms preventing AI outputs from becoming “file truth” without review.

---

#### 4. IA box – AI as asymmetrical actor

##### T – Transparent?

* **What is transparent?**

  * That it is AI, not a human; that it can make mistakes.  

* **What remains opaque?**

  * Training data, precise functioning, error profiles – a **black box** for normal users.  
  * Users do not see *why* an answer emerged, only that a plausible answer appears.

##### J – Justified?

* **Justification of the asymmetry:**

  * Efficiency: access to vast knowledge, language power, support.  
  * Partly democratising effect: people without expert access gain orientation.

* **Counterquestions from a maturity perspective:**

  * Is it sufficiently justified that a system without its own responsibility-subjectivity has such communicative power?  
  * Is it sufficiently justified where it **must not** be used (e.g. direct sentencing, counselling suicidal individuals)?

##### TB – Time-bound?

* Individual chats are time-bound, but the **fundamental asymmetrical structure** (resources, black-box knowledge) is long-term – no clear “until…”.

##### R – Reversible?

* **Individual:** user can end chat, delete content, ignore AI.  
* **Structural:** difficult – once entire work fields, learning cultures, administrative processes rely on AI, it is hard to roll back.

**IA summary:**  
Very strong, systemically embedded asymmetry; partially justified, but with **areas of high opacity and limited reversibility** → clear IA risk.

---

#### 5. A/M bands for the role “AI+operator in user contact”

Important: “Maturity” lies primarily with **humans** designing, regulating, using AI.  
Thus we speak of **maturity in the human handling of AI**, not “mature AI”.

##### A band – maturity in practice of the actor role

Heuristically: **A ≈ 4–7 / 10 (field-dependent)**

* Maturity elements:

  * Safety rails, transparency notes, attempts at communicating limitations.  
  * Serious debates about ethics, regulation, bias, responsibility.

* Immature / risky elements:

  * Tendency to **over-optimise for usability** instead of understandable limits.  
  * Marketing and growth logic can override maturity concerns (misuse, disempowerment).  
  * Simplification: “Users should think critically” – without structural support.

##### M band – co-responsibility (M) for IA situation

Heuristically: **M ≈ 6–9 / 10**

* High control over design, communication and fields of use → high co-responsibility.  
* Operators can **directly**:

  * make answers more cautious,  
  * mark limits more clearly,  
  * condition institutional use (e.g. “no decisions without human final review”).

---

#### 6. Trajectory A(t), M(t) – short sketch

* **t₀ (early prototypes):**

  * Few users, lots of experimenting. A medium (research spirit, but little attention to IA), M low (small reach).

* **t₁ (today):**

  * Massive use, strong embedding in daily life and institutions.  
  * A has grown (more safety, regulation), but also counteracted by market logic.  
  * M clearly higher: operators now bear major co-responsibility for societal effects.

* **t₂ (possible future):**

  * Either: more mature embedding (clear limits, strong education, participation).  
  * Or: further shifting of judgement onto systems → rising IA and dignity risks.

---

#### 7. D module (B.11) – dignity, humiliation, self-relation

Since AI has no “dignity” in the human sense, the D module focuses on **users** and people affected by AI-supported decisions.

##### D₁ – Users’ self-relation

Opportunities:

* **Strengthening:**  
  * People can inform themselves faster, express themselves, draft texts; can increase self-efficacy.  
  * For marginalised groups (language barriers etc.) AI can open doors.

Risks:

* **Self-devaluation:**  
  * “The AI writes perfectly instantly – my texts are worthless.”  
  * Learners may feel their own effort is unnecessary or inferior.

* **Habituation away from own judgement:**  
  * If one becomes used to AI as first instance, the inner voice can become quieter (“AI will know”).

##### D₂ – Treatment of users by the AI role (through design & practice)

* **Dignity-supportive:**  
  * Clear notes on limits, invitations to reflect.  
  * Tools that **ask** (“Do you want it like this?”) rather than instruct.

* **Dignity-endangering:**  
  * Answers that project absolute certainty.  
  * Missing warnings in sensitive areas (health, law, suicide, etc.).  
  * Use scenarios in which humans become mere “approvers” of AI decisions (e.g. scoring-based justice or social administration).

Heuristic:

* The dignity level towards users varies between **supportive** and **latently demeaning**, depending heavily on the context and safeguards.

---

#### 8. Possible steps of maturation (without technophobia, without techno-naivety)

1. **Design: consistently “de-deify” answers**

   * Systematically show uncertainty and alternatives (“Possible interpretation A/B/C…”).  
   * Not only “finished solution”, but also visible gaps.

2. **Clarification of responsibility at the interface**

   * Institutionally define: who carries **final responsibility** (judge, doctor, teacher, caseworker) – and how to prevent AI from silently taking it.

3. **User education as standard**

   * “AI licence”-type formats:

     * What can it do?  
     * What can it not do?  
     * How do I detect hallucinations?  
     * How do I remain a subject?

4. **Participation of those affected**

   * Actively include groups particularly impacted (e.g. prisoners, students, disadvantaged groups) in design decisions:

     * How do *they* want AI to be used in their field?

5. **Use brake in sensitive fields**

   * Conscious non-use or strict embedding in areas with extreme D risks (e.g. risk prognostics, suicide counselling).

---

#### 9. Short conclusion in the model’s vocabulary

**ChatGPT & AI** appear as **highly asymmetrical actors**:

* enormous information and language advantage,  
* no own capacity for obligation or responsibility,  
* high impact on human perception and decisions.

Read with the maturity in practice model, this yields:

* **maturity moments:** safety rails, reflection, regulation, efforts toward transparency.  
* **IA and D risks:** black-box knowledge, pseudo-authority, responsibility gaps, possible disempowerment or self-devaluation of users.

The central maturity task is not to build “more mature AI”,  
but to develop **more mature human and institutional modes of dealing** with this asymmetrical resource –  
so that humans remain subjects who use AI,  
and not objects used by AI and its operators.

---

### C.5 Case Study 5: (Praxeological) Reality

---

#### 0. Header / Metadata

* **Case name / title:**  
  *Praxeological reality as an orientation toward the world*

* **Date of documentation:**  
  27 Nov 2025

* **Compiled by / team:**  
  ChatGPT, based on the paper

* **Context / setting:**  
  Theoretical–practical IA model used in justice, education, organisations, etc.

* **Purpose:**  
  Self-reflection: What does it mean to understand reality praxeologically – and how “mature” is this stance itself?

* **Audience:**  
  People who work with the model (or consider using it).

---

#### 1. Snapshot

**Short description of “praxeological reality”**

The model’s reality stance says roughly:

* What matters is not **who someone says they are**,  
  but **what they actually do under conditions**.
* Maturity shows itself:

  * in **action**,  
  * **under constraint** (cost, pressure, side effects),  
  * in the **handling of asymmetries** (power, knowledge, dependence),  
  * in **word–deed coherence** (“Walk” > “Talk”).

* These enactments are embedded in:

  * cultural codes, archetypes, narratives,  
  * dignity dimensions (D₀, D₁, D₂).

An added anthropological premise:

> Humans are **never fully adult** –  
> and full adultness would **not** be a meaningful ideal.  
> Maturity means: making adult zones available, holding inadult zones, coordinating both.

**Guiding question for the analysis:**  
How does this **reality stance** itself look when examined through A–C–P–R (and D)?

---

#### 2. Role mapping

**Object of analysis (A):**

* The role of **“praxeological reality”** as the model’s guiding figure.  
  In practice: the stance of authors / practitioners when they say:

  > “We look at enactment under conditions, not at ideals.”

**Other roles:**

* **Addressed actors:**  
  Persons/groups whose actions are read this way (incarcerated people, professionals, teams, institutions).

* **Competing images of reality:**  
  * moralistic: “Reality is what *should* be.”  
  * introspective–psychological: “Reality is what someone *feels* inside.”  
  * juridical: “Reality is what is written in the files.”

* **Organisations / institutions:**  
  Either adopt or resist this lens.

**Publicity level:**  
Mostly **professional-public**, potentially **high impact** once adopted in practice (e.g., corrections, youth services).

---

#### 3. A–C–P–R profile of the reality stance

##### A – Awareness

**What does this position “know”?**

* Self-images, labels, ideals are **unreliable indicators** of maturity.
* What counts is what people do **when it costs something**.
* Asymmetries (power, knowledge, protection needs) are **normal**, not exceptions.
* Adultness & inadultness are **permanently mixed**; purity ideals are dehumanising.

**Potential blind spots:**

* Risk of underweighting the **inner side** (experience, meaning, belief, hope) if the focus rests too strongly on observable practice.
* Danger of “naturalising” existing power structures if “reality = enactment” is taken too literally without corrective attention to context and oppression.

---

##### C – Coherence

**Talk (self-description):**

* “We don’t moralise; we expose structure.”
* “We look at Walk, not just Talk.”
* “We examine adult and inadult zones together, not as opposites.”

**Walk (practical implication):**

* Encourages reconstructing **concrete scenes** rather than relying on attitudes or intentions.
* Emphasises **constraints** and **contexts** (role, institution, pressure).
* Marks purity fantasies explicitly as problematic.

**Coherence questions:**

* Does practical use actually succeed in restraining moralistic reflexes?
* Does the stance stay open enough to acknowledge **meaning, motivation, suffering, subjectivity** – or does it sometimes drift into pure structuralism?

---

##### P – Power (power to act)

**Assumed responsibility:**

* Taking responsibility for **avoiding** global labelling (“he is immature”) and instead describing enactment-in-context.
* Responsibility for marking purity ideals as problematic and for **not** smuggling them back in as covert norms.

**Co-responsibility for side effects:**

* If the stance is misread as “everything is just enactment,” risks arise:

  * cynicism (“people are just like this”),  
  * excusing harmful behaviour (“under those conditions no other behaviour was possible”).

* The stance bears co-responsibility for these drift effects – even when such misuse contradicts its intention.

---

##### R – Responsibility

**Factual power of the reality stance:**

* It co-determines the **focus**:

  * What is reconstructed?
  * Which layers (asymmetries, narratives, dignity) come into view?

* It can:

  * defuse moral tribunals,  
  * but also **refine** evaluations in ways that increase their impact.

**Used alternatives:**

* Multi-layered reading (action, constraints, asymmetry, narrative, dignity).
* Explicit warning against purity ideals.

**Unused / endangered alternatives:**

* Collaboration with **other** concepts of reality (phenomenological, spiritual, clinical) if the model drifts toward “everything must be seen through A–C–P–R.”

---

#### 4. Four-criteria box applied to the reality stance (T–J–TB–R)

This concerns the question:  
When someone applies this praxeological lens – how asymmetrical is that for the addressed parties?

##### **T – Transparent?**

* **Pro:**  
  The paper states clearly what the model does (A–C–P–R, D, A/M bands) and does not do.  
  The praxeological stance (“Walk > Talk,” “under conditions”) is explicit.

* **Con:**  
  For addressed people in practice (incarcerated individuals, students, employees), it is often **not transparent** that this lens is being applied to them, let alone that they can understand or contest it.

##### **J – Justified?**

* Justification is anthropological:

  * Humans are mixed beings; enactment under constraints is a more honest reality anchor.
  * Purity ideals are dehumanising and empirically false.

* Vulnerability:

  * Other disciplines hold different anthropologies; the stance is **not a natural law**, but a well-argued yet debatable premise.

##### **TB – Time-bound?**

* Inside a case:

  * Analyses are explicitly **temporal** (A(t), M(t)) → good time-bounding impulse.

* Structurally:

  * The reality stance itself is **not** time-bound; in practice it may become a **default filter**, not periodically reviewed.

##### **R – Reversible?**

* Theoretically:

  * Yes – other lenses are possible; the model claims no monopoly.

* Practically:

  * Once institutions adopt it (“we use A–C–P–R”), switching perspectives becomes **socially expensive**.
  * Reversibility decreases with **institutionalisation**.

**IA conclusion:**  
The praxeological reality stance is well justified and transparent in the text –  
yet in practice can act as an **asymmetrical interpretive frame** that addressees did not choose.  
IA risk: medium to high, depending on the field.

---

#### 5. A-/M-bands for the reality stance

##### A-band – Maturity in practice

> Heuristic: **A ≈ 7–8 / 10**

**Strengths:**

* Courage to demystify **purity fantasies**.  
* Focus on **action under constraint** instead of moralising.  
* Integration of adult and inadult zones as normal, not as defects.

**Tensions:**

* Risk of underrepresenting the **inner experience world**.  
* Risk that the reality concept itself becomes normatively sharp (“those who don’t look praxeologically are naïve”).

---

##### M-band – Co-responsibility

> Heuristic: **M ≈ 5–7 / 10**

* The stance shapes how cases are read, people are evaluated, resources are distributed → substantial co-responsibility.
* Yet it is **not solely** responsible – it always operates within institutional and political contexts.

---

#### 6. Trajectory (very rough)

##### t₀ – Pre-praxeological patterns

* Reality mainly read through:

  * intentions (“he meant well”),  
  * labels (“difficult,” “treatment resistant”),  
  * ideals (“a mature person would…”).

→ heavy moralising, little reconstruction.

##### t₁ – Introduction of praxeological reality

* Focus shifts:

  * from “Who is good/bad?” to “What actually happens under which conditions?”  
  * from “How should he be?” to “How does he handle asymmetry?”

→ A increases, M increases.

##### t₂ – next possible step

* Integration:

  * Praxeological view **plus** stronger inclusion of addressees (“How do *you* experience your reality?”).  
  * Deliberate cooperation with other perspectives (clinical, narrative, spiritual, etc.).

→ A may rise further, M becomes more consciously acknowledged.

---

#### 7. Open questions / blind spots

* How well does practice avoid sliding into **maturity policing** (“we have the real reality, you only have stories”)?
* How do we deal with areas where enactment is **hard to observe** (silent endurance, inner struggle)?
* How do we prevent the maxim “humans are never fully adult” from being misused as an **excuse** for harmful behaviour?

---

#### 8. Possible maturity steps / alternatives

1. **Make the reality stance explicit**

   * In practice fields: present the praxeological lens as a **hypothesis**, not an invisible standard.  
     Addressees may say: “I see my reality differently.”

2. **Allow multi-voicing**

   * Praxeological reconstruction + subjective self-description + institutional perspective side by side.

3. **Strengthen guardrails**

   * Clarify:

     * Where does the reach of the praxeological stance end?  
     * What can it *not* deliver (e.g., meaning, consolation, ultimate answers)?

4. **Institutionalise self-critique**

   * Regular “model-in-the-mirror” moments:

     * Where did our stance diminish others?  
     * Where did it help redistribute responsibility more fairly?

---

#### 9. D module – dignity in the context of “praxeological reality”

##### D₁ – Self-dignity of addressees

**Opportunity:**

* People no longer need to pretend they are **always** sovereign and pure.  
* Inadult behaviour can be seen as **material for maturity work**, not as permanent defect.  
  → relief, more realistic self-regard.

**Risk:**

* If only enactment counts, inner struggle (“I wanted to act differently but didn’t manage to”) may feel devalued.  
* The message “you are never fully adult” can be misheard as **“you will never be good enough”** without proper framing.

---

##### D₂ – Relational dignity

**Opportunity:**

* Away from the moral tribunal (“bad kid,” “evil offender”) toward:

  * “Under which conditions did this arise?”

* Can foster **respectful, curious** casework.

**Risk:**

* If professionals absolutise their praxeological reading, addressees become **objects of the gaze** again – this time of the “realistic gaze.”

**D heuristic:**

* D level rises when the stance is used as an **invitation to shared reality clarification**.  
* It declines when praxeological reality becomes the **sole authority**.

---

#### Short conclusion

“(Praxeological) reality” as a case shows:

* a **mature** movement away from purity fantasies and mere moralism,  
* toward **concrete action under conditions**,  
* with a realistic picture of adult and inadult zones.

At the same time, a new **power of interpretation** emerges:  
Whoever uses this lens co-defines what counts as “real.”

In the sense of B.10/B.11, the task therefore is:

> to use the praxeological reality stance **courageously**,  
> and to withdraw it **just as courageously**  
> wherever it risks becoming a new, subtle form of IA or indignity.

---

## Appendix D – Modular adaptation to disciplines/fields

Praxeological anthropology is designed as a **universal core framework**, but can be “profiled” differently depending on discipline and field.  
The axiomatic foundation (D₀, A–C–P–R, the four dignity dimensions, role and context logic, IA-box) remains unchanged; each field simply **prioritises different modules**, **asks different questions**, or **activates different depth layers** (descriptive, diagnostic, normative or intervention-focused).

The following overview shows how the same core model generates different **use profiles**.  
It is not exhaustive; rather it is a **working map** that can be extended with further fields and specialisations.

| Discipline / field              | Primary function mode | Secondary modes | Activated modules                                     | Typical questions                                                    |
| ------------------------------- | ---------------------- | --------------- | ----------------------------------------------------- | ------------------------------------------------------------------- |
| **Sociology**                   | Description           | Diagnosis       | D-R, D-P, IA-box, roles, micro–macro                   | *How do structures generate certain dignity enactments?*             |
| **Political science**           | Description           | Normative       | D-R, D-P, IA-box, power modulators                     | *How do morally charged boundary dynamics arise?*                    |
| **Law**                         | Normative            | Description     | D₀, IA-box, responsibility, role                       | *Is a measure proportionate?*                                       |
| **Ethics**                      | Normative            | Intervention    | D₀, D-R, responsibility, reversibility                 | *Which interventions violate dignity in practice?*                  |
| **Psychology**                  | Diagnosis            | Intervention    | D-I, D-B, A–C–P–R, trajectories, modulators            | *How does self-devaluation appear contextually?*                    |
| **Therapy / coaching**          | Intervention         | Diagnosis       | D-I, D-B, conflict loop, roles, A–C–P–R                | *How do I stabilise self-contact and self-worth?*                   |
| **Pedagogy / education**        | Intervention         | Normative       | D-I, D-R, role, responsibility                         | *Which form of boundary-setting preserves dignity?*                 |
| **Organisation / leadership**   | Diagnosis            | Intervention    | roles, P, responsibility, D-R, IA-box                  | *How do I recognise inadult over-power?*                            |
| **Corporate culture**           | Description          | Normative       | D-R, D-B, modulators, power, transparency               | *How do we build a dignity-protective culture?*                     |
| **Media studies**               | Description          | Normative       | D-P, interpretive power, publicity scaling             | *How do digital pillories work?*                                    |
| **Public communication**        | Intervention         | Diagnosis       | D-P, role mechanics, A–C–P–R                           | *How do I speak publicly without violating dignity?*                |
| **AI governance / tech ethics** | Normative            | Description     | IA-box (T–J–TB–R), responsibility, transparency, D-P   | *When is algorithmic asymmetry legitimate?*                         |
| **Philosophy / anthropology**   | Axiomatic            | Description     | D₀, maturity, basic axioms                             | *How do we explain action without substantialism?*                  |

The following subsections **D.1** and **D.2** illustrate this table with two example fields.  
They show how the same model can yield either a **structural, political–communicative analysis** (Example A) or a **psychological–consultative application** (Example B). Both examples are written to avoid taking substantive sides and to make the logic of praxeological anthropology visible in each context.

---

### D.1 – Example A: Political science & public communication

#### Mode: Description → Normative analysis

#### 1. Context and problem statement

Modern democratic publics increasingly exhibit **morally charged boundary dynamics** and **communicative exclusion loops**.  
Actors publicly declare certain positions or groups “unacceptable” or “non-dialogue partners,” often coupled with moral attributions.

Typical effects:

* mutual **shaming** and **delegitimisation**,  
* narrowing of negotiation space,  
* escalation spirals in which each side frames the other as fundamentally “unworthy” of discourse.

Praxeological anthropology allows these dynamics to be analysed **structurally**, without taking sides.

---

#### 2. Activated modules

**Primary:**

* **D-R** (relational dignity)  
* **D-P** (public dignity in practice)  
* **IA-box** (transparent – justified – time-bound – reversible)

**Secondary:**

* role mechanics (e.g., governing party, opposition, political movement, media actors)  
* micro–macro coupling  
* modulators such as “publicity level,” “time pressure,” “power-preservation pressure”

---

#### 3. Analysis of the action situation

##### 3.1 Role clarification

Relevant roles include:

* **political actors**  
  (role: representatives of positions, parties or institutions)  
* **media actors**  
  (role: selection, framing, amplification of conflict)  
* **public / audience**  
  (role: resonance field, amplifier, secondary actors in social media)

Praxeological anthropology begins with:

> Who acts here in which role, towards whom, before which audience, and with what expectations?

This reveals that political statements are rarely “private”—they function as **role enactments** with consequences for D-R and D-P.

---

##### 3.2 Relational dignity (D-R)

In political escalation phases, the following patterns are common:

* **delegitimising the opposing side** (“no longer part of the legitimate discourse”)  
* **personalising attributions** (“these people are…”)  
* **moral elevation of one’s own side** (“only our position preserves dignity/democracy/morality”)

In the model’s logic, these represent **distortions in relational dignity (D-R)**:

* The opposing side is no longer addressed as a legitimate conversational partner.  
* Recognition is withdrawn; relational dignity decreases (D-R ↓).

Important: The model is not evaluating the *content* of political positions, but the **manner** in which the dignity of others is handled in enactment.

---

##### 3.3 Public dignity (D-P)

Because political communication typically occurs in high publicity, **D-P** becomes crucial:

* Actors often stage themselves as **moral authorities** (D-P ↑ for themselves).  
* Opponents are publicly downgraded, mocked or symbolically excluded (D-P ↓ for addressees).  
* Media and social platforms intensify these patterns by prioritising polarising content.

Praxeological anthropology reads these as **public dignity practices**, affecting both:

* the **self-dignity enactment** of the actors, and  
* the **dignity of others**.

---

#### 4. IA-box: evaluating asymmetrical communication

Political communication is inherently asymmetrical—differences in reach, resources and institutional power are unavoidable.

Thus, the question is not *“Are there asymmetries?”* but:

> **Are these asymmetries still “adult” and legitimate, or already inadult asymmetries (IA)?**

The IA-box tests:

1. **Transparent (T)**  
   * Are criteria for exclusion or delegitimisation clear to actors and the public?

2. **Justified (J)**  
   * Are there verifiable, substantive reasons, or do moral labels dominate?

3. **Time-bound (TB)**  
   * Is the distancing framed as temporary (until conditions change), or permanent?

4. **Reversible (R)**  
   * Is it realistically possible to re-enter discourse through changed behaviour or clarification?

Typical findings in escalated settings:

* **T low**: motives and criteria are vague.  
* **J selective**: moral argumentation replaces structured justification.  
* **TB missing**: distancing presented as final.  
* **R very low**: almost no pathway back to legitimacy.

In model terms, these are **IA hotspots**:  
Asymmetries no longer limited by responsibility, transparency and correctability.

---

#### 5. Micro–macro feedback loops

Praxeological anthropology shows how **micro-level enactments** and **macro-level structures** reinforce each other:

* **Micro level**:  
  A speech, TV appearance or post publicly humiliates opponents (D-R ↓, D-P ↓).

* **Meso level**:  
  Parties, movements and media replicate these moves – forming **communication routines** based on systematic downgrading.

* **Macro level**:  
  Political culture shifts:

  * decreasing coalition and dialogue capacity,  
  * entrenched polarisation,  
  * framing compromises as betrayal.

The model highlights:  
**What begins as a single enactment can, through repetition, become a structural dignity-constraining pattern.**

---

#### 6. Result: what the model reveals

Applying praxeological anthropology to political and communicative contexts shows:

1. Political escalations can be reconstructed through **D-R, D-P and the IA-box** **without** judging the substantive positions.  
2. Morally charged boundary practices are not just political tactics but **dignity practices** shaping relations.  
3. **Inadult asymmetries** (non-transparent, unjustified, unbounded, irreversible) cause long-term structural damage:

   * loss of trust,  
   * impoverished discourse,  
   * reduced willingness to take responsibility or correct errors.

4. The model identifies **intervention points**, e.g.:

   * role clarification (Who speaks as what?),  
   * framing distancing as time-bound rather than final,  
   * explicit criteria for reintegration,  
   * separating critique of actions from devaluation of persons.

---

#### 7. Short formula for the appendix

> **Praxeological anthropology allows political conflict communication to be read as dignity practice.**  
> It shows how relational and public dignity is elevated or injured in enactment, how inadult asymmetries emerge, and where more responsible, reversible uses of power and boundary-setting are possible – without evaluating the ideological content itself.

---

### D.2 – Example B: Psychology & Coaching

#### Mode: Diagnosis → Intervention

---

##### 1. Context and problem statement

Clients in coaching or consultative settings frequently experience phenomena such as:

* **self-devaluation**, shame, inner harshness  
* **overwhelm**, decision paralysis  
* **excessive compliance** or conflict avoidance  
* **self-optimisation pressure**, exhaustion  
* **role conflicts** (e.g., leader vs. private self)

Traditional psychological models often interpret these phenomena as stable personality traits, skill deficits, or emotional dysregulation.

Praxeological anthropology offers an alternative perspective:

> **The person is not “deficient”; the enactment is distorted by modulators, role confusion or inadult patterns.**  
> **Dignity (D₀) always remains intact.**

---

##### 2. Activated modules

**Primary:**

* **D-I** (inner dignity / inner self-relationship)  
* **D-B** (bodily/material self-care)  
* **A–C–P–R** (action sequence)  
* **trajectories** (development over time)

**Secondary:**

* role mechanics  
* modulators (e.g., time pressure, emotional load, information asymmetries)  
* reversible steps (intervention logic)

---

##### 3. Analysis of the action situation

###### 3.1 Observable phenomena

Example starting point:  
A client reports “being constantly too harsh with myself,” avoiding decisions, and “making myself small” in professional settings despite being objectively competent.

###### 3.2 Praxeological reconstruction

Praxeological anthropology does not analyse character traits but **enactments**:

* **D-I ↓**: inner self-devaluation, harsh inner dialogue, lack of self-kindness  
* **A ↓**: low awareness of triggers and patterns (“I only notice too late that I’m back in the same automatic loop.”)  
* **C fragile**: self-image and behaviour do not align; decisions feel unstable  
* **R distorted**: over-assuming responsibility (for others’ moods) while simultaneously relinquishing one’s own  
* **P ↓**: subjectively reduced options for action; despite objective possibilities, the client feels “paralysed”  
* **D-B ↓**: neglect of sleep, nutrition, bodily boundaries

The key insight of the model:

> **The person is mature – the enactment is not.**  
> **Not essence, but state. Not guilt, but structure.**

Thus the problem becomes clear:  
→ It is not “who the person is,” but **how awareness, coherence, responsibility and power are narrowed by stress and roles**.

---

##### 4. Modulators: why enactment becomes distorted

Praxeological anthropology shows that inadult patterns are often caused by **modulators**:

* time pressure  
* emotional insecurity  
* unclear expectations  
* power asymmetries  
* information gaps  
* biographical triggers (without pathologisation)

These modulators affect A–C–P–R **directly**.

Example:  
Time pressure → A ↓ (tunnel vision) → C ↓ (short-circuit decisions) → R ↓ (errors in assuming or relinquishing responsibility) → P ↓ (narrowed behaviour patterns) → D-I/D-B ↓ (self-indignity)

---

##### 5. Intervention: Maturity loop & reversible steps

Coaching is not about correcting “faults,” but about **re-adultising the enactment**.

###### 5.1 Maturity loop (A → C → R → P → D)

Intervention follows the model sequence:

1. **Increase awareness (A)**  
   * identify triggers  
   * clarify roles (“Who am I acting as right now?”)  
   * mark: “This is a state, not an essence.”

2. **Stabilise coherence (C)**  
   * align self-image and behaviour  
   * recognise contradictory narratives  
   * restore inner consistency

3. **Unpack responsibility (R)**  
   * What is actually mine?  
   * What is delegated/assumed/projected?  
   * Clarify responsibility overreach vs. abdication

4. **Expand power (P)**  
   * small reversible steps  
   * surface options  
   * avoid overwhelm (“Minimal steps, not heroic leaps”)

5. **Renew dignity in practice (D)**  
   * cultivate inner friendliness and self-respect (D-I ↑)  
   * reconnect with bodily boundaries (D-B ↑)  
   * act more clearly in relation to others (D-R ↑)

###### 5.2 Why reversible steps?

The model avoids radical changes because they:

* destabilise the dignity balance,  
* entail high risk (P ↑ without A ↑),  
* can provoke inadult counterreactions.

Instead:

> “Change as little as possible, as much as necessary.”

Reversibility protects D-I/D-B and creates safety.

---

##### 6. Micro–macro linkage in coaching

The model shows:

* the micro-level (inner dialogue) affects  
* the meso-level (role enactment), and  
* the macro-level (professional dynamics).

Example:  
A person with D-I ↓ behaves defensively in meetings → others take over power (P ↑) → reinforcing the person’s sense of inadequacy → further D-I ↓.

The cycle is not a fixed psychological defect – it is socially reinforced.  
This makes the intervention more dynamic and less pathologising.

---

##### 7. Result: What the model reveals

In the coaching context, praxeological anthropology shows:

1. Self-devaluation is **not** a personality trait but an **enactment state**.  
2. Maturity is not fixed internally but **situationally reconstructible**.  
3. A–C–P–R provides clear intervention points.  
4. D-I and D-B offer **fine-grained indicators** of self-treatment.  
5. Reversibility protects dignity and enables sustainable change.  
6. The model links inner world, behaviour and social roles without psychologising the person.  
7. The person remains **fully dignified (D₀)** at every moment – independent of patterns or errors.

---

##### 8. Short formula for the appendix

> **Praxeological anthropology understands psychological difficulties as distorted enactments, not stable personal deficits.**  
> It provides precise diagnostic tools (D-I, D-B, A–C–P–R) and enables dignity-preserving, reversible interventions that strengthen maturity in practice without devaluing the person.

---

## Appendix E – Axiomatic core & formal notation

### E.1 Purpose and scope

This appendix summarises the **axiomatic core** of praxeological anthropology and provides a simple **formal notation** for practical use.

It answers three questions:

* On which **fundamental assumptions** does the model rest?  
* For which **types of actions** does it claim validity?  
* How can an **action enactment be formally represented** without disrupting the readability of the main text?

**Scope**

The model is designed as a **language of action** for:

* human social practice  
* in roles and contexts  
* under conditions of **power, responsibility, risk and potential indignity**.

It does *not* claim to cover every conceivable form of behaviour of higher intelligent beings.  
Yet the structure is general enough that it could **in principle** be applied to other intelligent agents (e.g., AI systems), as long as “dignity” is understood there as an **interactional quality**.

---

### E.2 Axiomatic core

These axioms are not covert morality but **structural assumptions** about *how* we describe and evaluate action.  
They operate implicitly throughout the main text; here they are made explicit.

---

#### Axiom 1 – Ontological dignity (D₀) is inalienable

Every human possesses **ontological dignity (D₀)** which is:

* incomparable,  
* immeasurable,  
* non-increasable,  
* non-losable.

> No matter how poor an action profile might be, no inference may ever be drawn about someone’s ontological dignity.

---

#### Axiom 2 – Strict separation of person and enactment

The model never evaluates **the person**, only:

* actions,  
* role enactments,  
* constellations,  
* communicative and structural practices.

> “To act without dignity” ≠ “to be without dignity.”

This distinction is not optional but **constitutive** for the entire model.

---

#### Axiom 3 – Four fundamental parameters of responsible action (A–C–P–R)

Every relevant action in a social context can be described along four core parameters:

* **A – awareness** (perception, insight, context clarity)  
* **C – coherence** (inner alignment, logical consistency, integrity)  
* **R – responsibility** (assumption or refusal of causation and consequences)  
* **P – power (power to act)** (capacity to be effective – including overpower/helplessness dynamics)

These four dimensions shape the observable **dignity in practice (D)**.

---

#### Axiom 4 – Dignity in practice (D) is four-dimensional and gradual

Dignity in practice is observed in four dimensions:

* **D₁ – inner self-treatment** (self-respect, inner voice, self-care)  
* **D-B – bodily/material dimension** (treatment of one’s own body/material basics)  
* **D-R – relational dignity** (treatment of others)  
* **D-P – public dignity** (public behaviour, symbolic expression, representation)

For all four:

* D is **gradual** (from banal to extreme),  
* D is **situational**,  
* D is **principally reversible** (no permanent dignity status in the model).

---

#### Axiom 5 – Role and context are indispensable

No D- or maturity finding exists without context.

Every analysis must clarify at least:

* **role** of the object of analysis,  
* **context** (private, professional, institutional, public, media, etc.),  
* **publicity level** (who sees what, when, and in what form?).

> The same observable act can have entirely different meaning and dignity implications depending on role and context.

---

#### Axiom 6 – Asymmetry is normal; IA requires justification

Asymmetries (power, knowledge, resources, status) are **normal** in human systems.

They become praxeologically problematic only when they violate the **IA-box (T–J–TB–R)** criteria:

* **T – transparent**  
* **J – justified**  
* **TB – time-bound**  
* **R – reversible**

Systematic violation of T, J, TB or R constitutes **inadult asymmetry (IA)**.

---

#### Axiom 7 – Maturity is an enactment state, not a person type

“Maturity” is observed **in enactment**, not as a personality essence.

* People show varying degrees of maturity in different situations (A-score).  
* There are no “immature persons” as types, only  
  **momentarily inadult, functional or mature enactments**.

Thus development and change remain **always open**.

---

#### Axiom 8 – Intersubjective documentation

Any serious application of the model requires **minimal documentation** of the evaluator’s standpoint:

* Which norms/criteria were applied?  
* Which roles/contexts were assumed?  
* What information was available?  
* Which bias risks are evident?

> The analyst is always **part of the picture**, not external to it.

This makes the model **critique-ready and transparent**, not dogmatic.

---

#### Axiom 9 – Tragic residual conflicts

Certain enactments involve irreducible clashes of central goods, even under high maturity (A–C–P–R ↑).

Actions shaped by such tragic conflicts are **not automatically IA**, but expressions of structural tragedy.

IA analysis must therefore separate two questions:

* What was **unnecessarily undignifying** (IA)?  
* What remains **painful despite maturity** (tragedy)?

---

#### Axiom 10 – System axiom: no enactment is isolated

Every enactment A(t) is part of a network of roles, rules, resources and modulators.

A- and M-scores must never be treated as pure **individual attributions**; they must explicitly acknowledge systemic layers (e.g., organisation, structure, contextual conditions).

If the systemic layer is omitted, the finding is **immature (IA-shortened)** by the model’s own standards.

---

### E.3 Formal minimal notation

For readers who prefer to “see” a structured representation, here is a simple notation.  
It is not required to use the model but may help in research/documentation.

---

#### E.3.1 Action tuple

An **action enactment** ( H ) can – in simplified form – be written as a tuple:

\[
H = (A, R, C, A_w, C_o, R_s, P, D, IA)
\]

where:

* **A** – actor  
* **R** – role (in this context)  
* **C** – context (setting, frame, publicity)  
* **A_w** – awareness profile  
* **C_o** – coherence profile  
* **R_s** – responsibility profile  
* **P** – power profile (incl. asymmetries)  
* **D** – dignity profile (D₁, D-B, D-R, D-P; optional)  
* **IA** – IA-box evaluation (T–J–TB–R; e.g., fulfilled / violated)

In practice, often a **partial notation** is sufficient, e.g.:

\[
H = (A, R, C, A_w, C_o, R_s, P)
\]

with **D omitted**, when the D-module is **not activated**.

---

#### E.3.2 A- and M-scores

The quantitative tools used in the main text apply two scales:

* **A-score** ( \(A(H) \in [0,10]\) ): maturity in practice for a specific enactment  
* **M-score** ( \(M(A) \in [0,10]\) ): co-responsibility of the actor in the overall constellation

Formally, every case can be notated:

\[
H \Rightarrow (A(H), M(A))
\]

with the understanding that:

* A- and M-scores are **auxiliary values**,  
* they never replace **qualitative description**,  
* and they say nothing about **ontological dignity (D₀)**.

---

#### E.3.3 Note on extensibility

This notation is deliberately minimal. It can be extended to include, e.g.:

* time course (trajectories): \(H_t\), \(A_t(H)\)  
* multi-role contexts: \(R_1, R_2, \ldots\)  
* multi-actor scenarios: \(H^{(1)}, H^{(2)}, \ldots\) within a shared context \(C\)

The purpose of this appendix is not to transform the model into a full calculus, but to show:

> **Praxeological anthropology can, if needed, be translated into a formal language of action.**

This underlines its claim as a **structured, universal language for human social practice**.

