---
document_id: MIP-SPLIT-SPEC-01-BLOCKS
title: "MIP Split Spec — 01 Blocks"
source_basis:
  - "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical split specification"
target_file: "00_source/MIP_SPLIT_SPEC_01_blocks.md"
target_layer: "01_blocks/"
status: "canonical-split-specification"
version: "v1"
spec_id: "mip-split-spec-01-blocks"
spec_role: "exact chapter extraction protocol from canonical full source into 12 block files"
claim_mode: "mechanical, extraction-bound, non-expansive, no-content-expansion"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀/D₁/D₂ notation preserved exactly as source text; no interpretive D changes"
mip_status: "source-layer split protocol; not a theory block; not an appendix; not model layer"
scope: "split canonical full source into 01_blocks/01–12 by exact chapter markers"
expansion_policy: "no rewriting, no summarising, no added theory, no paraphrase"
canonicality: "canonical for split procedure only"
---

# MIP Split Spec — 01_blocks

Status: canonical split specification  
Target layer: `01_blocks/`  
Source file: `00_source/Maturity in practice - A praxeological anthropology.md`  
Purpose: exact chapter extraction from canonical source into 12 block files  
Expansion policy: no content expansion, no theory additions, no paraphrase

---

## 0. Core rule

The 12 block files are direct chapter splits from the canonical source.

Do not rewrite.
Do not summarize.
Do not add transitions.
Do not add interpretation.
Do not normalize theory.
Do not move material across chapters unless explicitly specified here.

Each block file contains exactly one main chapter from the source.

---

## 1. Source and target

### Source

```text
00_source/Maturity in practice - A praxeological anthropology.md
```

### Target directory

```text
01_blocks/
```

### Target files

```text
01_blocks/01_position_claim.md
01_blocks/02_base_model_acrpd.md
01_blocks/03_guardrails_use.md
01_blocks/04_functional_vs_inadult.md
01_blocks/05_measuring_maturity.md
01_blocks/06_m_score_fairness.md
01_blocks/07_tools_case_lens.md
01_blocks/08_domain_modules.md
01_blocks/09_bias_intuition_norm_change.md
01_blocks/10_countercritique_response.md
01_blocks/11_visual_quick_access.md
01_blocks/12_conclusion.md
```

---

## 2. Global extraction rules

### 2.1 Include

For each block, include:

* the chapter heading itself;
* all text after that heading;
* all subsections belonging to that chapter;
* all tables, blockquotes, lists, code blocks, vignettes and horizontal rules inside that chapter;
* all original Markdown formatting.

### 2.2 Exclude

For each block, exclude:

* the initial table of contents before `## 1)`;
* all appendices A–E;
* material from previous or following chapters;
* generated navigation text;
* generated summaries;
* generated cross-reference comments.

### 2.3 Heading preservation

Keep the original heading text exactly as in the source.

Examples:

```markdown
## 1) What this is about (position and claim)
## 2) Short definition & base model A–C–R–P–D
```

Do not rename headings inside the block files.

### 2.4 File-local title rule

The first line of each block file must be the original chapter heading from the source.

No additional title above it.

Correct:

```markdown
## 1) What this is about (position and claim)
```

Incorrect:

```markdown
# 01_position_claim

## 1) What this is about (position and claim)
```

### 2.5 Pagebreak and horizontal-rule rule

If the source contains pagebreak markers or horizontal rules inside a chapter, preserve them.

If a pagebreak marker or horizontal rule appears directly between two chapters, keep it with the chapter that follows only if it is part of the source immediately before that chapter heading.

No artificial separators.

### 2.6 Encoding

Use UTF-8.

Preserve:

```text
A–C–R–P–D
D₀
D₁
D₂
T–J–TB–R
≈
→
```

Do not replace typographic symbols with ASCII substitutes.

---

## 3. Exact split map

---

### Block 01

Target file:

```text
01_blocks/01_position_claim.md
```

Start marker:

```markdown
## 1) What this is about (position and claim)
```

End marker:

```markdown
## 2) Short definition & base model A–C–R–P–D
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
1. What this is about (position and claim)
1.1 Five levels on which the model reads
1.2 Model = toolbox, not worldview
1.3 Maturity ≠ purity – the role of necessary inadulthood
1.4 Tragic conflicts – when maturity cannot resolve everything
```

Block function:

```text
Positioning, claim, reading levels, toolbox boundary, maturity-not-purity, tragedy clause.
```

---

### Block 02

Target file:

```text
01_blocks/02_base_model_acrpd.md
```

Start marker:

```markdown
## 2) Short definition & base model A–C–R–P–D
```

End marker:

```markdown
## 3) Framework of use & guardrails (mandatory module)
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
2. Short definition & base model A–C–R–P–D
2.1 Five core parameters in brief
2.2 Dynamics of A–C–R–P–D (feedback loop & states)
2.3 Modulators – amplifiers & dampers
2.3.1 Structural modulators
2.3.2 Dynamic / psychosocial modulators
2.3.3 Short rule for practice
2.4 Parameter matrix & submodules (A–C–R–P–D)
2.5 Publicity & position of the object of observation
2.6 Ontological vs. praxeological dignity
2.6.1 Ontological dignity – non-negotiable, not measurable
2.6.2 Praxeological dignity (D) – dignity in practice
2.6.3 Relational dignity (D₂) – dignity in relation to the world
2.6.4 Boundary: “acting without dignity” vs. “being without dignity”
2.7 D module – overview
2.7.1 Guiding formula & basic stance
2.7.2 What the D module observes – and what it does not
2.7.3 Safeguard clause
2.7.4 Scale logic: banal → extreme (always reversible)
2.7.5 Limits of D₁/D₂ in trauma & neurodiversity
2.8 Language hygiene: risk, harm, potential, danger
2.8.1 Risk, danger, harm, potential
2.8.2 Language hygiene in the D context
2.8.3 General language hygiene in the paper
```

Block function:

```text
Base model, parameter logic, D distinction, submodules, modulators, publicity and language hygiene.
```

---

### Block 03

Target file:

```text
01_blocks/03_guardrails_use.md
```

Start marker:

```markdown
## 3) Framework of use & guardrails (mandatory module)
```

End marker:

```markdown
## 4) Functional vs. inadult – the four-criteria box
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
3. Framework of use & guardrails (mandatory module)
3.1 Structures, not persons – zones
3.1.1 Profile ≠ person
3.1.2 System axiom: no enactment is purely individual
3.2 Entry condition: minimal adulthood
3.3 Procedural guardrails (modules 1–6)
3.4 Self-implication: whoever analyses, shows themselves
3.5 Dignity protection guardrail (ontological vs. praxeological)
3.5.1 Principle: the human being remains dignified
3.5.2 D assessments only in practice, never in the value of the person
3.5.3 Misuse as its own IA and D finding
3.6 D as an optional module
3.6.1 Default setting: D off
3.6.2 When D may be activated
3.6.3 Red zones for D
3.6.4 Documentation duty: marking the use of D
3.7 Publicity & communication of D findings
3.7.1 Differentiating communication spaces
3.7.2 Forms of D communication
3.7.3 Language rules for D findings
3.7.4 D findings under power asymmetries
```

Block function:

```text
Mandatory use conditions, guardrails, application zones, D-module activation, red zones and communication rules.
```

---

### Block 04

Target file:

```text
01_blocks/04_functional_vs_inadult.md
```

Start marker:

```markdown
## 4) Functional vs. inadult – the four-criteria box
```

End marker:

```markdown
## 5) Measuring maturity in practice – without moral rhetoric
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
4. Functional vs. inadult – the four-criteria box
4.1 Four-criteria box for asymmetries (T–J–TB–R)
4.2 Role and context logic
4.2.1 Clarifying the role of the object of observation
4.2.2 Clarifying the role of observers
4.2.3 Role awareness (A-R) as the start button
4.3 Role confusion & phantom intention
4.4 Semantic drift & D asymmetries: same action, different meaning
4.4.1 Semantic drift (basic mechanics)
4.4.2 D and asymmetries: self-degradation vs. societal degradation
4.4.3 Structural IA through faulty dignity-interpretation
4.5 Practical micro-tool: the role check
```

Block function:

```text
Functional vs. inadult asymmetry, IA-box, role logic, semantic drift and role-check tool.
```

---

### Block 05

Target file:

```text
01_blocks/05_measuring_maturity.md
```

Start marker:

```markdown
## 5) Measuring maturity in practice – without moral rhetoric
```

End marker:

```markdown
## 6) M-score – ceiling rule & fairness
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
5. Measuring maturity in practice – without moral rhetoric
5.1 A-score (0–10) – dimensions & micro-indicators
5.1.1 What the A-score measures – and what it does not
5.1.2 Dimensions of the A-score
5.1.3 Calibration band 0–10
5.1.4 Procedure: from profile to score
5.2 Trajectories instead of labels
5.2.1 A-score as snapshot
5.2.2 Development lines (trajectories)
5.2.3 Why trajectories are more mature than labels
5.2.4 Practical use
```

Block function:

```text
A-score, maturity bands, non-labelling logic, trajectory over static score.
```

---

### Block 06

Target file:

```text
01_blocks/06_m_score_fairness.md
```

Start marker:

```markdown
## 6) M-score – ceiling rule & fairness
```

End marker:

```markdown
## 7) Guiding formulas & tools
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
6. M-score – ceiling rule & fairness
6.1 M-score (shared responsibility, not fault or guilt)
6.1.1 Five factors of shared responsibility
6.1.2 High vs. low M-scores
6.1.3 M-score as structural distribution, not character judgment
6.2 The ceiling rule (protection against victim blaming)
6.2.1 Predictability ≈ 0
6.2.2 Access to alternatives ≈ 0
6.2.3 Function of the ceiling rule
6.3 Interaction of A-score & M-score
6.3.1 A high – M high
6.3.2 A high – M low
6.3.3 A low – M high
6.3.4 A low – M low
6.3.5 Practical use of A & M (with D-profile)
6.4 D and shared responsibility
6.4.1 Self-devaluation in the D-framework
6.4.2 Why self-degradation does not produce a high M-score
6.4.3 D, M and protection – practical implications
```

Block function:

```text
M-score, shared responsibility, ceiling rule, victim-blaming protection, A/M/D interaction.
```

---

### Block 07

Target file:

```text
01_blocks/07_tools_case_lens.md
```

Start marker:

```markdown
## 7) Guiding formulas & tools
```

End marker:

```markdown
## 8) Domain Modules – Grids for Levels & Fields
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
7. Guiding formulas & tools
7.1 Case Lens (v1.0) – decision protocol
7.2 Score sheets (A, M, IA-box, D)
7.2.1 A-score sheet
7.2.2 M-score sheet
7.2.3 IA-box sheet (Four-criteria box)
7.2.4 D-profile sheet (D₁/D₂ – dignity in practice)
7.3 Trajectories instead of points
7.3.1 Why trajectories?
7.3.2 Minimal documentation
7.3.3 Linking Case Lens ↔ Score sheets
7.4 System-1 / System-2 micro-tool (acute situations)
7.5 Mini-toolkit: score sheet & context tools (optional)
7.5.1 Three usage modes
7.5.2 Typical application fields
7.6 Praxeological final checklist
7.6.1 Satisfaction as warning signal
7.6.2 Parameter check: A–C–R–P–D
7.6.3 Role confusion – red alert
7.6.4 Detecting projection
7.6.5 Publicity factor (A-P, P-PU, D-P)
7.6.6 Multi-context situations
7.6.7 Coherence test via the other’s reaction
7.6.8 The “Grail sentence”
```

Block function:

```text
Case Lens, score sheets, D-profile sheet, trajectories, emergency tools, final checklist.
```

---

### Block 08

Target file:

```text
01_blocks/08_domain_modules.md
```

Start marker:

```markdown
## 8) Domain Modules – Grids for Levels & Fields
```

End marker:

```markdown
## 9) Bias, Intuition & Norm Change
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
8. Domain Modules – Grids for Levels & Fields
8.1 Psychology (performative)
8.2 Philosophy & Religion
8.3 Sociology & Politics
8.4 Culture / Media
8.5 Practice Ethics (Law / Organization / Education)
```

Block function:

```text
Domain lenses without adding a new model: psychology, philosophy/religion, sociology/politics, culture/media, practice ethics.
```

---

### Block 09

Target file:

```text
01_blocks/09_bias_intuition_norm_change.md
```

Start marker:

```markdown
## 9) Bias, Intuition & Norm Change
```

End marker:

```markdown
## 10) Countercritique & Response
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
9. Bias, Intuition & Norm Change
9.1 Bias: unavoidable distortions
9.2 Intuition: enemy or sensor?
9.3 Norm change: a moving target
9.4 Working with the model: protocol & meta-attitude
```

Block function:

```text
Limits of perception, bias, intuition, norm change, adult meta-attitude toward model use.
```

---

### Block 10

Target file:

```text
01_blocks/10_countercritique_response.md
```

Start marker:

```markdown
## 10) Countercritique & Response
```

End marker:

```markdown
## 11) Visual quick access (1-pager, PDF-ready)
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
10. Countercritique & Response
10.1 “Isn’t this just a new morality machine?”
10.2 “Can maturity even be measured?”
10.3 “Danger of misuse”
10.4 “Too subjective / too complex / too time-consuming”
10.5 “What the model does not promise”
10.6 Specific criticism of the D module (anticipation & response)
10.6.1 “You are becoming the dignity police.”
10.6.2 “You claim to know what is ‘dignified’.”
10.6.3 “You make those affected co-responsible for their own degradation.”
10.6.4 “You violate the idea of inalienable human dignity.”
10.6.5 “D reinforces shame and stigmatisation.”
10.6.6 “You are turning dignity into a new technology of discipline.”
```

Block function:

```text
Anticipated objections and responses, especially morality-machine critique, measurability, misuse, and D-module critique.
```

---

### Block 11

Target file:

```text
01_blocks/11_visual_quick_access.md
```

Start marker:

```markdown
## 11) Visual quick access (1-pager, PDF-ready)
```

End marker:

```markdown
## 12) Concluding word – maturity in practice remains work
```

Extraction:

Include from the start marker up to immediately before the end marker.

Expected internal structure:

```text
11. Visual quick access (1-pager, PDF-ready)
11.1 Audit checklist (5 points, meta level)
11.2 Conflict loop (4 steps)
11.3 D quick grid (banal → extreme, always reversible)
```

Block function:

```text
Quick-access one-pager material: audit checklist, conflict loop, D quick grid.
```

---

### Block 12

Target file:

```text
01_blocks/12_conclusion.md
```

Start marker:

```markdown
## 12) Concluding word – maturity in practice remains work
```

End marker:

```markdown
- Appendix A - Glossary of key terms
```

Alternative end marker, if Appendix A heading is normalized later:

```markdown
## Appendix A
```

Extraction:

Include from the start marker up to immediately before the first Appendix A marker.

Expected internal structure:

```text
12. Concluding word – maturity in practice remains work
```

Block function:

```text
Closing statement of the canonical core.
```

---

## 4. Validation rules

After splitting, validate the following.

### 4.1 File count

Exactly 12 files must exist in `01_blocks/`.

Expected:

```text
01_position_claim.md
02_base_model_acrpd.md
03_guardrails_use.md
04_functional_vs_inadult.md
05_measuring_maturity.md
06_m_score_fairness.md
07_tools_case_lens.md
08_domain_modules.md
09_bias_intuition_norm_change.md
10_countercritique_response.md
11_visual_quick_access.md
12_conclusion.md
```

### 4.2 First-heading validation

Each file must begin with the correct chapter heading:

```text
01_position_claim.md                  -> ## 1)
02_base_model_acrpd.md                -> ## 2)
03_guardrails_use.md                  -> ## 3)
04_functional_vs_inadult.md           -> ## 4)
05_measuring_maturity.md              -> ## 5)
06_m_score_fairness.md                -> ## 6)
07_tools_case_lens.md                 -> ## 7)
08_domain_modules.md                  -> ## 8)
09_bias_intuition_norm_change.md      -> ## 9)
10_countercritique_response.md        -> ## 10)
11_visual_quick_access.md             -> ## 11)
12_conclusion.md                      -> ## 12)
```

### 4.3 Forbidden-content validation

No `01_blocks/*` file may contain:

```text
Appendix A
Appendix B
Appendix C
Appendix D
Appendix E
```

Exception:

Only if one of these strings occurs as a cross-reference inside a chapter body.
It must not occur as an extracted appendix heading.

### 4.4 Boundary validation

Every chapter heading `## 1)` through `## 12)` must occur exactly once across all block files.

Appendix headings must occur zero times across all block files.

### 4.5 No generated additions

The split files must not contain:

```text
Generated by
Split note
Summary
This file contains
Canonical block
```

unless that text already existed in the source.

### 4.6 Reassembly validation

Concatenating the 12 block files in numeric order should reproduce the canonical core chapter sequence:

```text
Chapter 1
Chapter 2
Chapter 3
Chapter 4
Chapter 5
Chapter 6
Chapter 7
Chapter 8
Chapter 9
Chapter 10
Chapter 11
Chapter 12
```

This reassembled core should exclude:

```text
initial table of contents
Appendix A–E
```

---

## 5. Non-expansion policy

The split operation is mechanical.

Allowed:

```text
copy exact chapter ranges
preserve formatting
preserve headings
preserve tables
preserve lists
preserve examples
```

Not allowed:

```text
rewrite chapter intros
add summaries
add references
add cross-links
add glossary notes
move appendix material into blocks
move model-spec material into blocks
harmonize terminology beyond exact source text
```

---

## 6. Canonical status after split

After successful split:

```text
00_source/Maturity in practice - A praxeological anthropology.md
```

remains the canonical full source.

The directory:

```text
01_blocks/
```

contains the canonical core in chapter-block form.

Canonical core formula:

```text
README.md + 01_blocks/01–12 = canonical MIP core
```

Appendices are not part of `01_blocks/`.

They belong to:

```text
02_appendices/
```

Model YAML/spec/example files belong to:

```text
05_model/
```

---

## 7. Recommended splitter logic

A splitter may use these ordered heading markers:

```text
## 1) What this is about (position and claim)
## 2) Short definition & base model A–C–R–P–D
## 3) Framework of use & guardrails (mandatory module)
## 4) Functional vs. inadult – the four-criteria box
## 5) Measuring maturity in practice – without moral rhetoric
## 6) M-score – ceiling rule & fairness
## 7) Guiding formulas & tools
## 8) Domain Modules – Grids for Levels & Fields
## 9) Bias, Intuition & Norm Change
## 10) Countercritique & Response
## 11) Visual quick access (1-pager, PDF-ready)
## 12) Concluding word – maturity in practice remains work
- Appendix A - Glossary of key terms
```

The final marker is not extracted into `01_blocks/`.

---

## 8. Completion condition

The split is complete when:

```text
[ ] all 12 target files exist
[ ] each file starts with its correct original chapter heading
[ ] no file contains extracted appendix material
[ ] no source text inside chapters was rewritten
[ ] all typographic symbols are preserved
[ ] concatenated 01–12 sequence forms the canonical MIP core
```
