"""
MIP Reader — local navigation and inspection tool.

A single-file, dependency-free desktop reader for the Maturity in Practice
Markdown/YAML corpus.

Features:
- Loads the MIP repository from a folder or from a .zip file.
- Shows a project file navigator for README, source, canonical blocks,
  appendices, reference files, minified files, and model files.
- Shows a heading navigator for the current Markdown document.
- Renders Markdown/YAML into a styled Tk text view without external packages.
- Provides corpus-wide full-text search with jump-to-result behavior.
- Highlights search matches in the current document.

Boundary:
    The Reader is a convenience tool for local navigation and inspection.
    It does not replace canonical Markdown, modify the corpus, create claims,
    validate MIP, score persons, diagnose persons, rank persons, or measure
    ontological dignity.

Run:
    python mip_reader.py
    python mip_reader.py /path/to/Maturity In Practice
    python mip_reader.py /path/to/Maturity In Practice.zip

Note:
    Tkinter is part of Python's standard library, but some Linux distributions
    package it separately as python3-tk.
"""

from __future__ import annotations

import queue
import re
import signal
import sys
import threading
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

try:
    import tkinter as tk
    import tkinter.font as tkfont
    from tkinter import filedialog, messagebox, ttk
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "Tkinter is not available. Install the Tk bindings for your Python "
        "distribution, for example: sudo apt install python3-tk"
    ) from exc


APP_TITLE = "MIP Reader"
APP_VERSION = "0.1.0"

DEBUG = True  # set False to silence console output


CANONICAL_FILES: List[str] = [
    "README.md",

    "00_source/Maturity in practice - A praxeological anthropology.md",
    "00_source/MIP_SPLIT_SPEC_01_blocks.md",

    "01_blocks/01_position_claim.md",
    "01_blocks/02_base_model_acrpd.md",
    "01_blocks/03_guardrails_use.md",
    "01_blocks/04_functional_vs_inadult.md",
    "01_blocks/05_measuring_maturity.md",
    "01_blocks/06_m_score_fairness.md",
    "01_blocks/07_tools_case_lens.md",
    "01_blocks/08_domain_modules.md",
    "01_blocks/09_bias_intuition_norm_change.md",
    "01_blocks/10_countercritique_response.md",
    "01_blocks/11_visual_quick_access.md",
    "01_blocks/12_conclusion.md",

    "02_appendices/Appendix_A_Glossary.md",
    "02_appendices/Appendix_B_Checklists_Templates.md",
    "02_appendices/Appendix_C_Case_Examples.md",
    "02_appendices/Appendix_D_Discipline_Adaptation.md",
    "02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md",

    "03_reference/Audit_Checklist.md",
    "03_reference/Claim_Type_Table.md",
    "03_reference/Cross_Reference_Map.md",
    "03_reference/MIP_Update_To_Do.md",
    "03_reference/Misuse_Red_Zone_Map.md",
    "03_reference/Reader_Pathways.md",

    "04_minified/Block_Contracts.md",
    "04_minified/MIP_Claim_Boundary_Minified.md",
    "04_minified/MIP_Minified_Canonical.md",

    "05_model/MIP - Maturity in Practice.yaml",
    "05_model/MIP - Maturity in Practice - AHP Module.yaml",

    "05_model/examples/01_Minimal_Public_Criticism.md",
    "05_model/examples/01_Minimal_Public_Criticism.yaml",
    "05_model/examples/02_Blurry_Responsibility_Org.md",
    "05_model/examples/02_Blurry_Responsibility_Org.yaml",
    "05_model/examples/03_Public_Moral_Critique_with_AHP.md",
    "05_model/examples/03_Public_Moral_Critique_with_AHP.yaml",
    "05_model/examples/04_Meta_Analysis_with_AHP.md",
    "05_model/examples/04_Meta_Analysis_with_AHP.yaml",
    "05_model/examples/05_Self_Application_of_the_model_on_itself.md",
    "05_model/examples/05_Self_Application_of_the_model_on_itself.yaml",

    "05_model/model specification/Maturity in Practice - AHP Addon Specification.md",
    "05_model/model specification/Maturity in Practice - Model Specification.md",
]


SECTION_LABELS: Dict[str, str] = {
    "README.md": "Start",
    "00_source": "Source",
    "01_blocks": "Canonical Blocks",
    "02_appendices": "Appendices",
    "03_reference": "Reference",
    "04_minified": "Minified",
    "05_model": "Model Layer",
    "06_MIP Reader": "Reader",
}


MODEL_LAYER_LABELS: Dict[str, str] = {
    "05_model/__model__": "Model",
    "05_model/model specification": "Model Specs",
    "05_model/examples/__markdown__": "Markdown Examples",
    "05_model/examples/__yaml__": "YAML Examples",
}


IGNORED_REL_PATHS: set[str] = set()


HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
FENCE_RE = re.compile(r"^\s*(```|~~~)\s*([A-Za-z0-9_-]+)?(?:\s+.*)?\s*$")
LIST_RE = re.compile(r"^(\s*)([-*+])\s+(.+?)\s*$")
ORDERED_LIST_RE = re.compile(r"^(\s*)(\d+)[.)]\s+(.+?)\s*$")
FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.DOTALL)
WORD_RE = re.compile(r"\b\w+\b", re.UNICODE)

LARGE_DOC_LINE_THRESHOLD = 8000


def dbg(msg: str) -> None:
    if DEBUG:
        ts = time.strftime("%H:%M:%S")
        print(f"[{ts}] {msg}", flush=True)


@dataclass(frozen=True)
class Heading:
    level: int
    text: str
    line_number: int
    anchor: str


@dataclass
class Document:
    rel_path: str
    title: str
    text: str
    headings: List[Heading] = field(default_factory=list)
    frontmatter: Dict[str, str] = field(default_factory=dict)

    @property
    def line_count(self) -> int:
        return len(self.text.splitlines())

    @property
    def word_count(self) -> int:
        return len(WORD_RE.findall(self.text))


class CorpusError(RuntimeError):
    """Raised when a MIP corpus cannot be loaded."""


class CorpusSource:
    """Reads canonical MIP Markdown/YAML files from either a folder or a zip file."""

    def __init__(self, source_path: Path):
        self.source_path = source_path.expanduser().resolve()
        dbg(f"CorpusSource: resolving {self.source_path}")

        self.kind: str = "folder" if self.source_path.is_dir() else "zip"
        self._zip: Optional[zipfile.ZipFile] = None
        self._zip_prefix = ""
        self.root_dir: Optional[Path] = None

        if self.source_path.is_dir():
            self.root_dir = self._detect_folder_root(self.source_path)
            dbg(f"CorpusSource: folder root = {self.root_dir}")
        elif self.source_path.is_file() and self.source_path.suffix.lower() == ".zip":
            self._zip = zipfile.ZipFile(self.source_path)
            self._zip_prefix = self._detect_zip_prefix(self._zip)
            dbg(f"CorpusSource: zip prefix = '{self._zip_prefix}'")
        else:
            raise CorpusError(f"Unsupported source: {self.source_path}")

    def close(self) -> None:
        if self._zip is not None:
            self._zip.close()

    def describe(self) -> str:
        if self.kind == "folder" and self.root_dir is not None:
            return str(self.root_dir)
        return str(self.source_path)

    def exists(self, rel_path: str) -> bool:
        rel_path = normalize_rel_path(rel_path)
        if rel_path in IGNORED_REL_PATHS:
            return False

        if self.kind == "folder":
            assert self.root_dir is not None
            return (self.root_dir / rel_path).is_file()

        assert self._zip is not None
        return self._zip_name(rel_path) in self._zip.namelist()

    def read_text(self, rel_path: str) -> str:
        rel_path = normalize_rel_path(rel_path)

        if self.kind == "folder":
            assert self.root_dir is not None
            return (self.root_dir / rel_path).read_text(encoding="utf-8")

        assert self._zip is not None
        with self._zip.open(self._zip_name(rel_path), "r") as handle:
            raw = handle.read()
        return raw.decode("utf-8")

    def available_files(self) -> List[str]:
        result = [rel for rel in CANONICAL_FILES if self.exists(rel)]
        dbg(f"CorpusSource.available_files: {len(result)} of {len(CANONICAL_FILES)} found")
        return result

    def _zip_name(self, rel_path: str) -> str:
        rel_path = normalize_rel_path(rel_path)
        return f"{self._zip_prefix}{rel_path}" if self._zip_prefix else rel_path

    @staticmethod
    def _detect_folder_root(path: Path) -> Path:
        candidates = [
            path,
            path / "Maturity In Practice",
            path / "MIP",
        ]

        for candidate in candidates:
            has_readme = (candidate / "README.md").is_file()
            has_blocks = (candidate / "01_blocks").is_dir()
            dbg(f"  _detect_folder_root: {candidate}  readme={has_readme}  blocks={has_blocks}")

            if has_readme and has_blocks:
                return candidate

        raise CorpusError(
            "Could not find a MIP project root. "
            "Select the folder that contains README.md and 01_blocks/."
        )

    @staticmethod
    def _detect_zip_prefix(zf: zipfile.ZipFile) -> str:
        names = set(zf.namelist())

        if has_zip_project_root(names, ""):
            return ""

        prefixes = set()
        for name in names:
            parts = name.split("/")
            if len(parts) > 1 and parts[0]:
                prefixes.add(parts[0] + "/")

        for prefix in sorted(prefixes):
            if has_zip_project_root(names, prefix):
                return prefix

        raise CorpusError(
            "Could not find a MIP project root inside the zip file. "
            "Expected README.md and 01_blocks/."
        )


class Corpus:
    """Loaded MIP documents plus lightweight search helpers."""

    def __init__(self, source: CorpusSource):
        self.source = source
        self.documents: Dict[str, Document] = {}
        self.ordered_paths: List[str] = []
        self.load()

    def load(self) -> None:
        self.documents.clear()
        self.ordered_paths = self.source.available_files()
        dbg(f"Corpus.load: loading {len(self.ordered_paths)} documents ...")

        for rel_path in self.ordered_paths:
            dbg(f"  reading {rel_path}")
            text = self.source.read_text(rel_path)
            frontmatter, body = parse_frontmatter(text)

            if rel_path.lower().endswith((".yaml", ".yml")):
                title = Path(rel_path).name
                headings: List[Heading] = []
            else:
                headings = parse_headings(body)
                title = (
                    frontmatter.get("title")
                    or first_heading_title(headings)
                    or prettify_file_name(rel_path)
                )

            self.documents[rel_path] = Document(
                rel_path=rel_path,
                title=title,
                text=text,
                headings=headings,
                frontmatter=frontmatter,
            )

        dbg(f"Corpus.load: done — {len(self.documents)} documents loaded")

    def get(self, rel_path: str) -> Document:
        return self.documents[rel_path]

    def search(self, query: str, limit: int = 500) -> List[Tuple[str, int, str]]:
        query_norm = query.strip().lower()
        if not query_norm:
            return []

        results: List[Tuple[str, int, str]] = []

        for rel_path in self.ordered_paths:
            doc = self.documents[rel_path]
            for line_no, line in enumerate(strip_frontmatter(doc.text).splitlines(), start=1):
                if query_norm in line.lower():
                    snippet = line.strip() or "<blank line>"
                    results.append((rel_path, line_no, snippet[:300]))
                    if len(results) >= limit:
                        return results

        return results

    @property
    def document_count(self) -> int:
        return len(self.documents)

    @property
    def total_word_count(self) -> int:
        return sum(doc.word_count for doc in self.documents.values())

    @property
    def total_line_count(self) -> int:
        return sum(doc.line_count for doc in self.documents.values())


class MipReaderApp(tk.Tk):
    """Tkinter desktop app for browsing the MIP corpus."""

    def __init__(self, initial_source: Optional[Path] = None):
        super().__init__()
        dbg("App: __init__ start")

        self.title(f"{APP_TITLE} {APP_VERSION}")
        self.geometry("1380x860")
        self.minsize(960, 600)

        signal.signal(signal.SIGINT, signal.SIG_IGN)

        self.corpus: Optional[Corpus] = None
        self.current_path: Optional[str] = None
        self.heading_indices: Dict[str, str] = {}
        self.search_results: List[Tuple[str, int, str]] = []
        self._file_item_to_path: Dict[str, str] = {}
        self._heading_item_to_anchor: Dict[str, str] = {}
        self._search_entry: Optional[ttk.Entry] = None
        self.dark_mode = False

        self.reader_font_size = 10
        self.reader_fullscreen = False
        self._normal_geometry = ""

        self._suppress_file_select_event = False
        self._load_queue: queue.Queue = queue.Queue()

        self._configure_style()
        self._build_ui()
        self._bind_shortcuts()
        self.apply_theme()
        self._center_window()

        if initial_source is not None:
            self.after(100, lambda: self._start_load_thread(initial_source))
        else:
            self.after(100, self._start_discover_thread)

        dbg("App: __init__ done")

    # ------------------------------------------------------------------ #
    # Background loading
    # ------------------------------------------------------------------ #

    def _start_discover_thread(self) -> None:
        dbg("App: starting discover thread")
        self.status_var.set("Searching for MIP corpus ...")
        t = threading.Thread(target=self._bg_discover, daemon=True)
        t.start()
        self.after(100, self._poll_load_queue)

    def _start_load_thread(self, source_path: Path) -> None:
        dbg(f"App: starting load thread for {source_path}")
        self.status_var.set(f"Loading corpus from {source_path} ...")
        t = threading.Thread(target=self._bg_load, args=(source_path,), daemon=True)
        t.start()
        self.after(100, self._poll_load_queue)

    def _bg_discover(self) -> None:
        try:
            dbg("bg_discover: searching ...")
            source_path = discover_default_source()
            if source_path is None:
                dbg("bg_discover: no source found")
                self._load_queue.put(("no_source", None))
                return
            dbg(f"bg_discover: found {source_path}, loading ...")
            self._bg_load(source_path)
        except Exception as exc:
            dbg(f"bg_discover: exception: {exc}")
            self._load_queue.put(("error", str(exc)))

    def _bg_load(self, source_path: Path) -> None:
        try:
            dbg(f"bg_load: creating CorpusSource({source_path})")
            source = CorpusSource(source_path)
            dbg("bg_load: creating Corpus")
            corpus = Corpus(source)
            dbg("bg_load: done, posting result to queue")
            self._load_queue.put(("ok", corpus))
        except Exception as exc:
            dbg(f"bg_load: exception: {exc}")
            self._load_queue.put(("error", str(exc)))

    def _poll_load_queue(self) -> None:
        try:
            msg, payload = self._load_queue.get_nowait()
        except queue.Empty:
            self.after(100, self._poll_load_queue)
            return

        dbg(f"poll_load_queue: received '{msg}'")

        if msg == "ok":
            corpus: Corpus = payload
            if self.corpus is not None:
                self.corpus.source.close()

            self.corpus = corpus
            self.current_path = None
            self.populate_file_tree()
            self.clear_search()
            self.status_var.set(
                f"Loaded {corpus.document_count} documents, "
                f"{corpus.total_line_count:,} lines, "
                f"{corpus.total_word_count:,} words — {corpus.source.describe()}"
            )
            self.open_home()

        elif msg == "no_source":
            self.status_var.set("Open a MIP folder or zip file to begin.")

        elif msg == "error":
            error_msg: str = payload
            self.status_var.set(f"Error: {error_msg}")
            messagebox.showerror(APP_TITLE, error_msg)

    # ------------------------------------------------------------------ #
    # UI
    # ------------------------------------------------------------------ #

    def _configure_style(self) -> None:
        self.base_font = tkfont.Font(family="Segoe UI", size=10)
        self.bold_font = tkfont.Font(family="Segoe UI", size=10, weight="bold")
        self.italic_font = tkfont.Font(family="Segoe UI", size=10, slant="italic")
        self.bold_italic_font = tkfont.Font(family="Segoe UI", size=10, weight="bold", slant="italic")
        self.mono_font = tkfont.Font(family="Consolas", size=10)
        self.heading_font_1 = tkfont.Font(family="Segoe UI", size=18, weight="bold")
        self.heading_font_2 = tkfont.Font(family="Segoe UI", size=15, weight="bold")
        self.heading_font_3 = tkfont.Font(family="Segoe UI", size=13, weight="bold")
        self.heading_font_4 = tkfont.Font(family="Segoe UI", size=11, weight="bold")

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("Treeview", rowheight=24)
        style.configure("TButton", padding=(8, 4))
        style.configure("TEntry", padding=(4, 4))

    def _build_ui(self) -> None:
        self._build_toolbar()
        self._build_fullscreen_toolbar()

        self.main_pane = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.main_pane.pack(fill=tk.BOTH, expand=True)

        self.left_pane = ttk.PanedWindow(self.main_pane, orient=tk.VERTICAL)
        self.main_pane.add(self.left_pane, weight=1)

        file_frame = ttk.Frame(self.left_pane, padding=(6, 6, 6, 3))
        self.left_pane.add(file_frame, weight=3)
        ttk.Label(file_frame, text="Corpus", font=("Segoe UI", 10, "bold")).pack(anchor=tk.W)

        file_tree_wrap = ttk.Frame(file_frame)
        file_tree_wrap.pack(fill=tk.BOTH, expand=True, pady=(4, 0))

        self.file_tree = ttk.Treeview(file_tree_wrap, show="tree")
        self.file_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        file_scrollbar = ttk.Scrollbar(file_tree_wrap, orient=tk.VERTICAL, command=self.file_tree.yview)
        file_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.file_tree.configure(yscrollcommand=file_scrollbar.set)

        self.file_tree.bind("<<TreeviewSelect>>", self._on_file_selected)
        self._bind_mousewheel_scroll(self.file_tree)

        search_frame = ttk.Frame(self.left_pane, padding=(6, 3, 6, 6))
        self.left_pane.add(search_frame, weight=2)
        ttk.Label(search_frame, text="Search Results", font=("Segoe UI", 10, "bold")).pack(anchor=tk.W)

        search_tree_wrap = ttk.Frame(search_frame)
        search_tree_wrap.pack(fill=tk.BOTH, expand=True, pady=(4, 0))

        self.search_tree = ttk.Treeview(
            search_tree_wrap,
            show="headings",
            columns=("file", "line", "text"),
            height=9,
        )
        self.search_tree.heading("file", text="File")
        self.search_tree.heading("line", text="Line")
        self.search_tree.heading("text", text="Text")
        self.search_tree.column("file", width=150, stretch=False)
        self.search_tree.column("line", width=48, stretch=False, anchor=tk.E)
        self.search_tree.column("text", width=260, stretch=True)
        self.search_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        search_scrollbar = ttk.Scrollbar(search_tree_wrap, orient=tk.VERTICAL, command=self.search_tree.yview)
        search_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.search_tree.configure(yscrollcommand=search_scrollbar.set)

        self.search_tree.bind("<Double-1>", self._on_search_result_open)
        self.search_tree.bind("<Return>", self._on_search_result_open)
        self._bind_mousewheel_scroll(self.search_tree)

        self.heading_frame = ttk.Frame(self.main_pane, padding=(6, 6, 6, 6))
        self.main_pane.add(self.heading_frame, weight=1)
        ttk.Label(self.heading_frame, text="Headings", font=("Segoe UI", 10, "bold")).pack(anchor=tk.W)

        heading_tree_wrap = ttk.Frame(self.heading_frame)
        heading_tree_wrap.pack(fill=tk.BOTH, expand=True, pady=(4, 0))

        self.heading_tree = ttk.Treeview(heading_tree_wrap, show="tree")
        self.heading_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        heading_scrollbar = ttk.Scrollbar(heading_tree_wrap, orient=tk.VERTICAL, command=self.heading_tree.yview)
        heading_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.heading_tree.configure(yscrollcommand=heading_scrollbar.set)

        self.heading_tree.bind("<<TreeviewSelect>>", self._on_heading_selected)
        self._bind_mousewheel_scroll(self.heading_tree)

        self.content_frame = ttk.Frame(self.main_pane, padding=(6, 6, 6, 6))
        self.main_pane.add(self.content_frame, weight=4)

        self.document_label_var = tk.StringVar(value="No document loaded")
        self.document_label = ttk.Label(
            self.content_frame,
            textvariable=self.document_label_var,
            font=("Segoe UI", 11, "bold"),
        )
        self.document_label.pack(anchor=tk.W, padx=(2, 0), pady=(0, 4))

        self.reader_border = tk.Frame(
            self.content_frame,
            borderwidth=0,
            highlightthickness=1,
            highlightbackground="#cfcfcf",
            highlightcolor="#cfcfcf",
        )
        self.reader_border.pack(fill=tk.BOTH, expand=True)

        text_wrap = ttk.Frame(self.reader_border)
        text_wrap.pack(fill=tk.BOTH, expand=True)

        self.text = tk.Text(
            text_wrap,
            wrap=tk.WORD,
            undo=False,
            padx=18,
            pady=14,
            font=self.base_font,
            borderwidth=0,
            highlightthickness=0,
        )
        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        yscroll = ttk.Scrollbar(text_wrap, orient=tk.VERTICAL, command=self.text.yview)
        yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.text.configure(yscrollcommand=yscroll.set)

        self._configure_text_tags()

        self.status_var = tk.StringVar(value="Starting ...")
        self.status_label = ttk.Label(self, textvariable=self.status_var, anchor=tk.W, padding=(6, 3))
        self.status_label.pack(fill=tk.X, side=tk.BOTTOM)

    def _build_toolbar(self) -> None:
        self.toolbar = ttk.Frame(self, padding=(6, 6, 6, 3))
        self.toolbar.pack(fill=tk.X)

        ttk.Button(self.toolbar, text="Open Folder", command=self._open_folder).pack(side=tk.LEFT)
        ttk.Button(self.toolbar, text="Open ZIP", command=self._open_zip).pack(side=tk.LEFT, padx=(6, 10))

        ttk.Label(self.toolbar, text="Search").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self._search_entry = ttk.Entry(self.toolbar, textvariable=self.search_var, width=42)
        self._search_entry.pack(side=tk.LEFT, padx=(6, 4))
        self._search_entry.bind("<Return>", lambda event: self.run_search())

        ttk.Button(self.toolbar, text="Run", command=self.run_search).pack(side=tk.LEFT)
        ttk.Button(self.toolbar, text="Clear", command=self.clear_search).pack(side=tk.LEFT, padx=(4, 12))

        ttk.Button(self.toolbar, text="Reload", command=self.reload_source).pack(side=tk.LEFT)
        ttk.Button(self.toolbar, text="Home", command=self.open_home).pack(side=tk.LEFT, padx=(6, 12))

        ttk.Button(self.toolbar, text="A−", command=self.decrease_reader_font).pack(side=tk.LEFT)
        ttk.Button(self.toolbar, text="A+", command=self.increase_reader_font).pack(side=tk.LEFT, padx=(4, 12))

        self.fullscreen_button = ttk.Button(
            self.toolbar,
            text="Reader Fullscreen",
            command=self.toggle_reader_fullscreen,
        )
        self.fullscreen_button.pack(side=tk.LEFT, padx=(0, 12))

        self.theme_button = ttk.Button(self.toolbar, text="Dark Mode", command=self.toggle_dark_mode)
        self.theme_button.pack(side=tk.LEFT)

        ttk.Button(self.toolbar, text="Exit", command=self.destroy).pack(side=tk.RIGHT)
        ttk.Button(self.toolbar, text="Help", command=self.show_help).pack(side=tk.RIGHT, padx=(0, 6))

    def _build_fullscreen_toolbar(self) -> None:
        self.fullscreen_toolbar = ttk.Frame(self, padding=(8, 6, 8, 4))

        ttk.Button(self.fullscreen_toolbar, text="A−", command=self.decrease_reader_font).pack(side=tk.LEFT)
        ttk.Button(self.fullscreen_toolbar, text="A+", command=self.increase_reader_font).pack(side=tk.LEFT, padx=(4, 12))

        ttk.Label(
            self.fullscreen_toolbar,
            text="Reader Fullscreen",
            font=("Segoe UI", 10, "bold"),
        ).pack(side=tk.LEFT)

        ttk.Button(
            self.fullscreen_toolbar,
            text="Exit Fullscreen",
            command=self.exit_reader_fullscreen,
        ).pack(side=tk.RIGHT)

        ttk.Button(
            self.fullscreen_toolbar,
            text="Help",
            command=self.show_help,
        ).pack(side=tk.RIGHT, padx=(0, 6))

    def _configure_text_tags(self) -> None:
        self.text.tag_configure("h1", font=self.heading_font_1, spacing1=22, spacing3=12, lmargin1=14, lmargin2=14)
        self.text.tag_configure("h2", font=self.heading_font_2, spacing1=20, spacing3=10, lmargin1=14, lmargin2=14)
        self.text.tag_configure("h3", font=self.heading_font_3, spacing1=16, spacing3=8, lmargin1=14, lmargin2=14)
        self.text.tag_configure("h4", font=self.heading_font_4, spacing1=14, spacing3=7, lmargin1=14, lmargin2=14)
        self.text.tag_configure("h5", font=self.heading_font_4, spacing1=12, spacing3=6, lmargin1=14, lmargin2=14)
        self.text.tag_configure("h6", font=self.heading_font_4, spacing1=12, spacing3=6, lmargin1=14, lmargin2=14)

        self.text.tag_configure("body", font=self.base_font, lmargin1=8, lmargin2=8)
        self.text.tag_configure("bold", font=self.bold_font)
        self.text.tag_configure("italic", font=self.italic_font)
        self.text.tag_configure("bold_italic", font=self.bold_italic_font)
        self.text.tag_configure("list", font=self.base_font, lmargin1=28, lmargin2=46, spacing1=1, spacing3=1)
        self.text.tag_configure("code", font=self.mono_font, background="#f4f4f4", lmargin1=28, lmargin2=28, spacing1=8, spacing3=8)
        self.text.tag_configure("inline_code", font=self.mono_font, background="#f4f4f4")
        self.text.tag_configure("yaml_key", font=self.mono_font, background="#f4f4f4", foreground="#7a3e9d", lmargin1=28, lmargin2=28)
        self.text.tag_configure("yaml_value", font=self.mono_font, background="#f4f4f4", foreground="#555555", lmargin1=28, lmargin2=28)
        self.text.tag_configure("yaml_comment", font=self.mono_font, background="#f4f4f4", foreground="#777777", lmargin1=28, lmargin2=28)
        self.text.tag_configure("quote", lmargin1=24, lmargin2=24, foreground="#555555")
        self.text.tag_configure("table", font=self.mono_font, lmargin1=24, lmargin2=24, spacing1=4, spacing3=4)
        self.text.tag_configure("rule", foreground="#777777")
        self.text.tag_configure("search", background="#fff2a8")
        self.text.tag_configure("current_line", background="#eef5ff")

    # ------------------------------------------------------------------ #
    # Theme / font / fullscreen
    # ------------------------------------------------------------------ #

    def toggle_dark_mode(self) -> None:
        self.dark_mode = not self.dark_mode
        self.apply_theme()

    def apply_theme(self) -> None:
        if self.dark_mode:
            bg = "#1e1e1e"
            panel_bg = "#252526"
            fg = "#d4d4d4"
            muted_fg = "#a0a0a0"
            text_bg = "#1e1e1e"
            text_fg = "#d4d4d4"
            code_bg = "#2d2d2d"
            button_bg = "#333333"
            button_hover_bg = "#404040"
            selection_bg = "#3a3d41"
            current_line_bg = "#2a2d2e"
            search_bg = "#665c00"
            rule_fg = "#777777"
            yaml_key_fg = "#ce9178"
            yaml_value_fg = "#b5cea8"
            yaml_comment_fg = "#6a9955"
            reader_border_fg = "#3a3d41"
            self.theme_button.configure(text="Light Mode")
        else:
            bg = "#f0f0f0"
            panel_bg = "#ffffff"
            fg = "#000000"
            muted_fg = "#555555"
            text_bg = "#ffffff"
            text_fg = "#000000"
            code_bg = "#f4f4f4"
            button_bg = "#f0f0f0"
            button_hover_bg = "#e5e5e5"
            selection_bg = "#cde8ff"
            current_line_bg = "#eef5ff"
            search_bg = "#fff2a8"
            rule_fg = "#777777"
            yaml_key_fg = "#7a3e9d"
            yaml_value_fg = "#555555"
            yaml_comment_fg = "#777777"
            reader_border_fg = "#cfcfcf"
            self.theme_button.configure(text="Dark Mode")

        self.configure(background=bg)

        style = ttk.Style(self)
        style.configure(".", background=bg, foreground=fg)
        style.configure("TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg)
        style.configure("TButton", background=button_bg, foreground=fg)
        style.map(
            "TButton",
            background=[
                ("active", button_hover_bg),
                ("pressed", selection_bg),
                ("!active", button_bg),
            ],
            foreground=[
                ("active", fg),
                ("pressed", fg),
                ("!active", fg),
            ],
        )
        style.configure("TEntry", fieldbackground=text_bg, foreground=fg)
        style.configure(
            "Treeview",
            background=panel_bg,
            fieldbackground=panel_bg,
            foreground=fg,
        )
        style.map(
            "Treeview",
            background=[("selected", selection_bg)],
            foreground=[("selected", fg)],
        )

        if hasattr(self, "reader_border"):
            self.reader_border.configure(
                background=reader_border_fg,
                highlightbackground=reader_border_fg,
                highlightcolor=reader_border_fg,
            )

        self.text.configure(
            background=text_bg,
            foreground=text_fg,
            insertbackground=text_fg,
        )

        for tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self.text.tag_configure(tag, background=text_bg, foreground=text_fg)

        self.text.tag_configure("body", background=text_bg, foreground=text_fg)
        self.text.tag_configure("bold", background=text_bg, foreground=text_fg)
        self.text.tag_configure("italic", background=text_bg, foreground=text_fg)
        self.text.tag_configure("bold_italic", background=text_bg, foreground=text_fg)
        self.text.tag_configure("list", background=text_bg, foreground=text_fg)
        self.text.tag_configure("code", background=code_bg, foreground=text_fg)
        self.text.tag_configure("inline_code", background=code_bg, foreground=text_fg)
        self.text.tag_configure("yaml_key", background=code_bg, foreground=yaml_key_fg)
        self.text.tag_configure("yaml_value", background=code_bg, foreground=yaml_value_fg)
        self.text.tag_configure("yaml_comment", background=code_bg, foreground=yaml_comment_fg)
        self.text.tag_configure("quote", background=text_bg, foreground=muted_fg)
        self.text.tag_configure("table", background=text_bg, foreground=text_fg)
        self.text.tag_configure("rule", background=text_bg, foreground=rule_fg)
        self.text.tag_configure("search", background=search_bg, foreground=text_fg)
        self.text.tag_configure("current_line", background=current_line_bg)

    def increase_reader_font(self) -> None:
        self.set_reader_font_size(self.reader_font_size + 1)

    def decrease_reader_font(self) -> None:
        self.set_reader_font_size(self.reader_font_size - 1)

    def reset_reader_font(self) -> None:
        self.set_reader_font_size(10)

    def set_reader_font_size(self, size: int) -> None:
        self.reader_font_size = max(8, min(24, size))
        self._apply_reader_font_sizes()
        self.status_var.set(f"Reader font size: {self.reader_font_size}")

    def _apply_reader_font_sizes(self) -> None:
        size = self.reader_font_size

        self.base_font.configure(size=size)
        self.bold_font.configure(size=size)
        self.italic_font.configure(size=size)
        self.bold_italic_font.configure(size=size)
        self.mono_font.configure(size=size)

        self.heading_font_1.configure(size=size + 8)
        self.heading_font_2.configure(size=size + 5)
        self.heading_font_3.configure(size=size + 3)
        self.heading_font_4.configure(size=size + 1)

        self.text.configure(font=self.base_font)

    def toggle_reader_fullscreen(self) -> None:
        if self.reader_fullscreen:
            self.exit_reader_fullscreen()
        else:
            self.enter_reader_fullscreen()

    def enter_reader_fullscreen(self) -> None:
        if self.reader_fullscreen:
            return

        self.reader_fullscreen = True
        self._normal_geometry = self.geometry()

        self.toolbar.pack_forget()
        self.status_label.pack_forget()
        self.fullscreen_toolbar.pack(fill=tk.X, before=self.main_pane)

        try:
            self.main_pane.forget(self.left_pane)
        except tk.TclError:
            pass

        try:
            self.main_pane.forget(self.heading_frame)
        except tk.TclError:
            pass

        self.attributes("-fullscreen", True)
        self.fullscreen_button.configure(text="Exit Fullscreen")
        self.text.focus_set()

    def exit_reader_fullscreen(self) -> None:
        if not self.reader_fullscreen:
            return

        self.reader_fullscreen = False
        self.attributes("-fullscreen", False)
        self.fullscreen_toolbar.pack_forget()

        try:
            self.main_pane.forget(self.content_frame)
        except tk.TclError:
            pass

        self.main_pane.add(self.left_pane, weight=1)
        self.main_pane.add(self.heading_frame, weight=1)
        self.main_pane.add(self.content_frame, weight=4)

        self.toolbar.pack(fill=tk.X, before=self.main_pane)
        self.status_label.pack(fill=tk.X, side=tk.BOTTOM)

        if self._normal_geometry:
            self.geometry(self._normal_geometry)

        self.fullscreen_button.configure(text="Reader Fullscreen")
        self.text.focus_set()

    # ------------------------------------------------------------------ #
    # Help / shortcuts / scroll
    # ------------------------------------------------------------------ #

    def show_help(self) -> None:
        messagebox.showinfo(
            f"{APP_TITLE} Help",
            "MIP Reader controls\n\n"
            "Navigation:\n"
            "  Open Folder / Open ZIP  Load a MIP corpus\n"
            "  Home                    Open the preferred start document\n"
            "  Reload                  Reload the current corpus\n\n"
            "Search:\n"
            "  Ctrl+F                  Focus search field\n"
            "  Enter                   Run search from search field\n"
            "  Double-click result     Open search result\n\n"
            "Reader:\n"
            "  A+ / Ctrl++             Increase reader font size\n"
            "  A− / Ctrl+-             Decrease reader font size\n"
            "  Ctrl+0                  Reset reader font size\n"
            "  F11                     Toggle reader fullscreen\n"
            "  Esc                     Exit reader fullscreen\n\n"
            "Theme:\n"
            "  Dark Mode               Toggle light / dark mode\n\n"
            "Boundary:\n"
            "  The Reader navigates and inspects local Markdown/YAML.\n"
            "  It does not validate MIP, modify canonical files, create claims,\n"
            "  score persons, diagnose persons, rank persons, measure ontological dignity,\n"
            "  or replace the canonical corpus.\n\n"
            "Fullscreen mode keeps only the reading area and a compact control bar visible.",
        )

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-o>", lambda event: self._open_folder())
        self.bind("<Control-f>", self._focus_search)
        self.bind("<F5>", lambda event: self.reload_source())
        self.bind("<F1>", lambda event: self.show_help())

        self.bind("<Control-plus>", lambda event: self.increase_reader_font())
        self.bind("<Control-equal>", lambda event: self.increase_reader_font())
        self.bind("<Control-KP_Add>", lambda event: self.increase_reader_font())

        self.bind("<Control-minus>", lambda event: self.decrease_reader_font())
        self.bind("<Control-KP_Subtract>", lambda event: self.decrease_reader_font())

        self.bind("<Control-0>", lambda event: self.reset_reader_font())
        self.bind("<F11>", lambda event: self.toggle_reader_fullscreen())
        self.bind("<Escape>", lambda event: self.exit_reader_fullscreen())

    def _focus_search(self, event: tk.Event) -> str:
        if self._search_entry is not None:
            self._search_entry.focus_set()
            self._search_entry.selection_range(0, tk.END)
        return "break"

    def _bind_mousewheel_scroll(self, widget: tk.Widget) -> None:
        widget.bind("<MouseWheel>", lambda event, w=widget: self._on_mousewheel_scroll(event, w))
        widget.bind("<Button-4>", lambda event, w=widget: self._on_linux_mousewheel_scroll(event, w, -1))
        widget.bind("<Button-5>", lambda event, w=widget: self._on_linux_mousewheel_scroll(event, w, 1))

    def _on_mousewheel_scroll(self, event: tk.Event, widget: tk.Widget) -> str:
        delta = getattr(event, "delta", 0)

        if delta == 0:
            return "break"

        if abs(delta) >= 120:
            units = -int(delta / 120)
        else:
            units = -1 if delta > 0 else 1

        try:
            widget.yview_scroll(units, "units")
        except tk.TclError:
            pass

        return "break"

    def _on_linux_mousewheel_scroll(self, event: tk.Event, widget: tk.Widget, units: int) -> str:
        try:
            widget.yview_scroll(units, "units")
        except tk.TclError:
            pass

        return "break"

    def _center_window(self) -> None:
        self.update_idletasks()

        width = self.winfo_width()
        height = self.winfo_height()

        if width <= 1 or height <= 1:
            geometry = self.geometry().split("+", 1)[0]
            width_text, height_text = geometry.split("x", 1)
            width = int(width_text)
            height = int(height_text)

        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        x = max(0, (screen_width - width) // 2)
        y = max(0, (screen_height - height) // 2)

        self.geometry(f"{width}x{height}+{x}+{y}")

    # ------------------------------------------------------------------ #
    # Loading actions
    # ------------------------------------------------------------------ #

    def load_source(self, source_path: Path) -> None:
        self._start_load_thread(source_path)

    def reload_source(self) -> None:
        if self.corpus is None:
            return
        source_path = self.corpus.source.source_path
        self.load_source(source_path)

    def open_home(self) -> None:
        if self.corpus is None:
            return

        for candidate in [
            "README.md",
            "04_minified/MIP_Minified_Canonical.md",
            "03_reference/Reader_Pathways.md",
        ]:
            if candidate in self.corpus.documents:
                self.open_document(candidate)
                return

    def _open_folder(self) -> None:
        path = filedialog.askdirectory(title="Open MIP folder")
        if path:
            self.load_source(Path(path))

    def _open_zip(self) -> None:
        path = filedialog.askopenfilename(
            title="Open MIP zip file",
            filetypes=[("Zip files", "*.zip"), ("All files", "*.*")],
        )
        if path:
            self.load_source(Path(path))

    # ------------------------------------------------------------------ #
    # Tree population
    # ------------------------------------------------------------------ #

    def populate_file_tree(self) -> None:
        dbg("populate_file_tree: start")

        self.file_tree.delete(*self.file_tree.get_children())
        self._file_item_to_path.clear()

        if self.corpus is None:
            dbg("populate_file_tree: corpus is None, nothing to show")
            return

        section_items: Dict[str, str] = {}
        subsection_items: Dict[str, str] = {}

        for rel_path in self.corpus.ordered_paths:
            section_key = rel_path.split("/", 1)[0] if "/" in rel_path else rel_path
            section_label = SECTION_LABELS.get(section_key, section_key)

            if section_key not in section_items:
                section_items[section_key] = self.file_tree.insert(
                    "", tk.END, text=section_label, open=True
                )

            parent_item = section_items[section_key]

            if section_key == "05_model":
                model_group_key = model_layer_group_for_path(rel_path)

                if model_group_key is not None:
                    if model_group_key not in subsection_items:
                        subsection_items[model_group_key] = self.file_tree.insert(
                            parent_item,
                            tk.END,
                            text=MODEL_LAYER_LABELS.get(model_group_key, model_group_key),
                            open=True,
                        )

                    parent_item = subsection_items[model_group_key]

            doc = self.corpus.documents[rel_path]
            item = self.file_tree.insert(
                parent_item, tk.END, text=tree_display_title(doc), open=False
            )
            self._file_item_to_path[item] = rel_path

        dbg(f"populate_file_tree: inserted {len(self._file_item_to_path)} file items")

    def populate_heading_tree(self, doc: Document) -> None:
        self.heading_tree.delete(*self.heading_tree.get_children())
        self._heading_item_to_anchor.clear()

        parent_by_level: Dict[int, str] = {0: ""}

        for heading in doc.headings:
            parent_level = heading.level - 1
            while parent_level > 0 and parent_level not in parent_by_level:
                parent_level -= 1

            parent = parent_by_level.get(parent_level, "")
            label = f"{'  ' * max(0, heading.level - 1)}{heading.text}"
            item = self.heading_tree.insert(parent, tk.END, text=label, open=True)
            self._heading_item_to_anchor[item] = heading.anchor
            parent_by_level[heading.level] = item

            for deeper in list(parent_by_level):
                if deeper > heading.level:
                    del parent_by_level[deeper]

    # ------------------------------------------------------------------ #
    # Document rendering
    # ------------------------------------------------------------------ #

    def open_document(self, rel_path: str, line_number: Optional[int] = None) -> None:
        if self.corpus is None:
            dbg(f"open_document: corpus is None, cannot open {rel_path}")
            return

        if rel_path not in self.corpus.documents:
            dbg(f"open_document: {rel_path} not in corpus")
            return

        if self.current_path == rel_path and line_number is None:
            dbg(f"open_document: already open, skipping {rel_path}")
            return

        dbg(f"open_document: {rel_path}")
        doc = self.corpus.documents[rel_path]
        self.current_path = rel_path
        self.document_label_var.set(f"{doc.title} — {rel_path}")

        self.populate_heading_tree(doc)
        self.render_document(doc)
        self.highlight_query()
        self._select_file_tree_item(rel_path)

        if line_number is not None:
            self.scroll_to_source_line(line_number)
        else:
            self.text.yview_moveto(0)

        self.status_var.set(
            f"{rel_path} — {doc.line_count:,} lines, "
            f"{doc.word_count:,} words, {len(doc.headings):,} headings"
        )

    def render_document(self, doc: Document) -> None:
        dbg(f"render_document: {doc.rel_path} ({doc.line_count} lines)")

        self.heading_indices.clear()
        self.text.configure(state=tk.NORMAL)
        self.text.delete("1.0", tk.END)

        try:
            use_source_marks = doc.line_count <= LARGE_DOC_LINE_THRESHOLD

            if doc.rel_path.lower().endswith((".yaml", ".yml")):
                self._render_yaml_document(doc, use_source_marks=use_source_marks)
            else:
                body = strip_frontmatter(doc.text)
                self._render_markdown_blocks(doc, body, use_source_marks=use_source_marks)

        except Exception as exc:
            dbg(f"render_document: exception: {exc}")
            self.status_var.set(f"Render error: {exc}")
        finally:
            self.text.configure(state=tk.DISABLED)

    def _render_yaml_document(self, doc: Document, use_source_marks: bool) -> None:
        self.text.insert(tk.END, f"# {doc.title}\n\n", ("h1",))

        for line_no, raw_line in enumerate(doc.text.splitlines(), start=1):
            if use_source_marks:
                self.text.mark_set(f"source_line_{line_no}", self.text.index(tk.INSERT))
            self._insert_yaml_line(raw_line)

    def _render_markdown_blocks(self, doc: Document, body: str, use_source_marks: bool) -> None:
        lines = body.splitlines()
        i = 0
        heading_counter = 0

        while i < len(lines):
            raw_line = lines[i]
            source_line = i + 1
            line_start = self.text.index(tk.INSERT)

            if use_source_marks:
                self.text.mark_set(f"source_line_{source_line}", line_start)

            fence_match = FENCE_RE.match(raw_line)
            if fence_match:
                language = (fence_match.group(2) or "").lower()
                block_lines: List[str] = []
                i += 1

                while i < len(lines):
                    close_match = FENCE_RE.match(lines[i])
                    if close_match:
                        break
                    block_lines.append(lines[i])
                    i += 1

                if i < len(lines) and FENCE_RE.match(lines[i]):
                    i += 1

                self._insert_code_block(block_lines, language)
                continue

            heading_match = HEADING_RE.match(raw_line)
            if heading_match:
                level = min(len(heading_match.group(1)), 6)
                heading_text = clean_heading_text(heading_match.group(2))
                anchor = f"h-{heading_counter}-{slugify(heading_text)}"
                heading_counter += 1
                self.heading_indices[anchor] = line_start

                self._insert_inline_markdown(heading_text, (f"h{level}",))
                self.text.insert(tk.END, "\n", (f"h{level}",))
                i += 1
                continue

            if looks_like_table_line(raw_line):
                table_lines: List[str] = []
                while i < len(lines) and looks_like_table_line(lines[i]):
                    table_lines.append(lines[i])
                    i += 1
                self._insert_table_block(table_lines)
                continue

            list_match = LIST_RE.match(raw_line)
            if list_match:
                indent, _bullet, content = list_match.groups()
                level = max(0, len(indent.replace("\t", "    ")) // 2)
                prefix = "  " * level + "• "
                self.text.insert(tk.END, prefix, ("list",))
                self._insert_inline_markdown(content, ("list",))
                self.text.insert(tk.END, "\n", ("list",))
                i += 1
                continue

            ordered_match = ORDERED_LIST_RE.match(raw_line)
            if ordered_match:
                indent, number, content = ordered_match.groups()
                level = max(0, len(indent.replace("\t", "    ")) // 2)
                prefix = "  " * level + f"{number}. "
                self.text.insert(tk.END, prefix, ("list",))
                self._insert_inline_markdown(content, ("list",))
                self.text.insert(tk.END, "\n", ("list",))
                i += 1
                continue

            if raw_line.strip().startswith(">"):
                quote_text = re.sub(r"^\s*>\s?", "", raw_line)
                self._insert_inline_markdown(quote_text, ("quote",))
                self.text.insert(tk.END, "\n", ("quote",))
                i += 1
                continue

            if raw_line.strip() in {"---", "***", "___"}:
                self.text.insert(tk.END, "\u2500" * 80 + "\n", ("rule",))
                i += 1
                continue

            self._insert_inline_markdown(raw_line, ("body",))
            self.text.insert(tk.END, "\n", ("body",))
            i += 1

        dbg(f"_render_markdown_blocks: done ({heading_counter} headings rendered)")

    def _insert_code_block(self, block_lines: List[str], language: str) -> None:
        if not block_lines:
            self.text.insert(tk.END, "\n", ("code",))
            return

        self.text.insert(tk.END, "\n", ("body",))

        if language in {"yaml", "yml"}:
            for raw_line in block_lines:
                self._insert_yaml_line(raw_line)
        else:
            block = "\n".join(block_lines)
            self.text.insert(tk.END, block + "\n", ("code",))

        self.text.insert(tk.END, "\n", ("body",))

    def _insert_yaml_line(self, raw_line: str) -> None:
        comment_match = re.match(r"^(\s*)(#.*)$", raw_line)

        if comment_match:
            indent, comment = comment_match.groups()
            self.text.insert(tk.END, indent, ("code",))
            self.text.insert(tk.END, comment + "\n", ("yaml_comment",))
            return

        match = re.match(r"^(\s*)([A-Za-z0-9_.-]+)(\s*:\s*)(.*)$", raw_line)

        if not match:
            self.text.insert(tk.END, raw_line + "\n", ("code",))
            return

        indent, key, separator, value = match.groups()

        self.text.insert(tk.END, indent, ("code",))
        self.text.insert(tk.END, key, ("yaml_key",))
        self.text.insert(tk.END, separator, ("code",))
        self.text.insert(tk.END, value + "\n", ("yaml_value",)) 

    def _insert_inline_markdown(self, text: str, base_tags: Tuple[str, ...]) -> None:
        token_re = re.compile(
            r"(`[^`]+`|\*\*\*[^*]+\*\*\*|\*\*[^*]+\*\*|\*[^*\n]+\*)"
        )

        pos = 0

        for match in token_re.finditer(text):
            if match.start() > pos:
                self.text.insert(tk.END, text[pos:match.start()], base_tags)

            token = match.group(0)

            if token.startswith("`") and token.endswith("`"):
                self.text.insert(tk.END, token[1:-1], base_tags + ("inline_code",))
            elif token.startswith("***") and token.endswith("***"):
                self.text.insert(tk.END, token[3:-3], base_tags + ("bold_italic",))
            elif token.startswith("**") and token.endswith("**"):
                self.text.insert(tk.END, token[2:-2], base_tags + ("bold",))
            elif token.startswith("*") and token.endswith("*"):
                self.text.insert(tk.END, token[1:-1], base_tags + ("italic",))
            else:
                self.text.insert(tk.END, token, base_tags)

            pos = match.end()

        if pos < len(text):
            self.text.insert(tk.END, text[pos:], base_tags)

    def _insert_table_block(self, table_lines: List[str]) -> None:
        rows: List[List[str]] = []

        for line in table_lines:
            cells = [cell.strip() for cell in line.strip().strip("|").split("|")]

            if cells and all(re.fullmatch(r":?-{3,}:?", cell or "---") for cell in cells):
                continue

            rows.append(cells)

        if not rows:
            return

        column_count = max(len(row) for row in rows)
        normalized_rows: List[List[str]] = [
            row + [""] * (column_count - len(row))
            for row in rows
        ]

        widths = [
            max(len(row[column]) for row in normalized_rows)
            for column in range(column_count)
        ]

        rendered_lines: List[str] = []
        for row_index, row in enumerate(normalized_rows):
            rendered = "  │  ".join(
                row[column].ljust(widths[column])
                for column in range(column_count)
            )
            rendered_lines.append(rendered)

            if row_index == 0 and len(normalized_rows) > 1:
                rendered_lines.append("──┼──".join("─" * width for width in widths))

        self.text.insert(tk.END, "\n", ("body",))
        self.text.insert(tk.END, "\n".join(rendered_lines) + "\n", ("table",))
        self.text.insert(tk.END, "\n", ("body",))

    # ------------------------------------------------------------------ #
    # Search
    # ------------------------------------------------------------------ #

    def run_search(self) -> None:
        if self.corpus is None:
            return

        query = self.search_var.get().strip()
        self.search_tree.delete(*self.search_tree.get_children())
        self.search_results = self.corpus.search(query)

        for index, (rel_path, line_no, snippet) in enumerate(self.search_results):
            title = self.corpus.documents[rel_path].title
            self.search_tree.insert("", tk.END, iid=str(index), values=(title, line_no, snippet))

        self.highlight_query()

        if query:
            self.status_var.set(f"Search '{query}': {len(self.search_results):,} result(s).")
        else:
            self.status_var.set("Search cleared.")

    def clear_search(self) -> None:
        self.search_var.set("")
        self.search_tree.delete(*self.search_tree.get_children())
        self.search_results = []

        self.text.configure(state=tk.NORMAL)
        self.text.tag_remove("search", "1.0", tk.END)
        self.text.configure(state=tk.DISABLED)

    def highlight_query(self) -> None:
        query = self.search_var.get().strip()

        self.text.configure(state=tk.NORMAL)
        self.text.tag_remove("search", "1.0", tk.END)

        if query:
            start = "1.0"
            while True:
                pos = self.text.search(query, start, stopindex=tk.END, nocase=True)
                if not pos:
                    break
                end = f"{pos}+{len(query)}c"
                self.text.tag_add("search", pos, end)
                start = end

        self.text.configure(state=tk.DISABLED)

    def scroll_to_source_line(self, line_number: int) -> None:
        mark = f"source_line_{line_number}"

        try:
            index = self.text.index(mark)
        except tk.TclError:
            index = f"{max(1, line_number)}.0"

        self.text.configure(state=tk.NORMAL)
        self.text.tag_remove("current_line", "1.0", tk.END)
        self.text.tag_add("current_line", index, f"{index} lineend+1c")
        self.text.configure(state=tk.DISABLED)
        self.text.see(index)

    # ------------------------------------------------------------------ #
    # Events
    # ------------------------------------------------------------------ #

    def _on_file_selected(self, event: tk.Event) -> None:
        if self._suppress_file_select_event:
            dbg("_on_file_selected: suppressed programmatic selection")
            return

        selection = self.file_tree.selection()
        if not selection:
            return

        item = selection[0]
        rel_path = self._file_item_to_path.get(item)

        if rel_path:
            self.open_document(rel_path)

    def _on_heading_selected(self, event: tk.Event) -> None:
        selection = self.heading_tree.selection()
        if not selection:
            return

        item = selection[0]
        anchor = self._heading_item_to_anchor.get(item)

        if anchor and anchor in self.heading_indices:
            index = self.heading_indices[anchor]
            self.text.see(index)
            self.text.configure(state=tk.NORMAL)
            self.text.tag_remove("current_line", "1.0", tk.END)
            self.text.tag_add("current_line", index, f"{index} lineend+1c")
            self.text.configure(state=tk.DISABLED)

    def _on_search_result_open(self, event: tk.Event) -> None:
        selection = self.search_tree.selection()
        if not selection:
            return

        try:
            result_index = int(selection[0])
        except ValueError:
            return

        if result_index >= len(self.search_results):
            return

        rel_path, line_no, _snippet = self.search_results[result_index]
        self.open_document(rel_path, line_number=line_no)

    def _select_file_tree_item(self, rel_path: str) -> None:
        for item, item_path in self._file_item_to_path.items():
            if item_path == rel_path:
                self._suppress_file_select_event = True
                try:
                    self.file_tree.selection_set(item)
                    self.file_tree.see(item)
                finally:
                    self.after_idle(self._enable_file_select_events)
                break

    def _enable_file_select_events(self) -> None:
        self._suppress_file_select_event = False

    def destroy(self) -> None:
        if self.corpus is not None:
            self.corpus.source.close()
        super().destroy()


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def normalize_rel_path(path: str) -> str:
    return path.replace("\\", "/").lstrip("/")


def has_zip_project_root(names: set[str], prefix: str) -> bool:
    readme_exists = f"{prefix}README.md" in names
    blocks_exists = (
        f"{prefix}01_blocks/" in names
        or any(name.startswith(f"{prefix}01_blocks/") for name in names)
    )
    return readme_exists and blocks_exists


def parse_frontmatter(text: str) -> Tuple[Dict[str, str], str]:
    match = FRONTMATTER_RE.match(text)
    if not match:
        return {}, text

    raw = match.group(1)
    meta: Dict[str, str] = {}

    for line in raw.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip().strip('"\'')
        if key:
            meta[key] = value

    return meta, text[match.end():]


def strip_frontmatter(text: str) -> str:
    return FRONTMATTER_RE.sub("", text, count=1)


def parse_headings(text: str) -> List[Heading]:
    headings: List[Heading] = []
    in_code = False
    heading_counter = 0

    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        is_fence = bool(FENCE_RE.match(raw_line))

        if is_fence:
            in_code = not in_code
            continue

        if in_code:
            continue

        match = HEADING_RE.match(raw_line)
        if not match:
            continue

        text_value = clean_heading_text(match.group(2))
        anchor = f"h-{heading_counter}-{slugify(text_value)}"

        headings.append(
            Heading(
                level=len(match.group(1)),
                text=text_value,
                line_number=line_number,
                anchor=anchor,
            )
        )
        heading_counter += 1

    return headings


def first_heading_title(headings: List[Heading]) -> Optional[str]:
    return headings[0].text if headings else None


def clean_heading_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"\s+#*$", "", text)
    text = text.replace("`", "")
    return text


def slugify(text: str) -> str:
    value = text.lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = value.strip("-")
    return value or "heading"


def looks_like_table_line(line: str) -> bool:
    stripped = line.strip()
    return (
        stripped.startswith("|")
        and stripped.endswith("|")
        and stripped.count("|") >= 2
    )


def prettify_file_name(rel_path: str) -> str:
    name = Path(rel_path).name

    for suffix in [".md", ".yaml", ".yml"]:
        if name.lower().endswith(suffix):
            name = name[: -len(suffix)]
            break

    name = name.replace("_", " ").replace("-", " - ")
    name = re.sub(r"\s+", " ", name).strip()
    return name


def model_layer_group_for_path(rel_path: str) -> Optional[str]:
    rel_path = normalize_rel_path(rel_path)

    if not rel_path.startswith("05_model/"):
        return None

    if rel_path.startswith("05_model/examples/"):
        if rel_path.lower().endswith(".md"):
            return "05_model/examples/__markdown__"

        if rel_path.lower().endswith((".yaml", ".yml")):
            return "05_model/examples/__yaml__"

        return "05_model/examples/__markdown__"

    if rel_path.startswith("05_model/model specification/"):
        return "05_model/model specification"

    return "05_model/__model__"


def tree_display_title(doc: Document) -> str:
    rel_path = normalize_rel_path(doc.rel_path)

    if rel_path.startswith("05_model/examples/"):
        return Path(rel_path).stem

    if model_layer_group_for_path(rel_path) == "05_model/__model__":
        return Path(rel_path).name

    return doc.title


def walk_widgets(widget: tk.Widget) -> Iterable[tk.Widget]:
    yield widget
    for child in widget.winfo_children():
        yield from walk_widgets(child)


def discover_default_source() -> Optional[Path]:
    """Return the first valid MIP source path found, or None."""
    candidates: List[Path] = []

    if len(sys.argv) > 1:
        candidates.append(Path(sys.argv[1]))

    cwd = Path.cwd()
    script_dir = Path(__file__).resolve().parent
    repo_root_from_tool_dir = script_dir.parent

    candidates.extend(
        [
            cwd,
            cwd / "Maturity In Practice",
            cwd / "Maturity In Practice.zip",
            cwd / "MIP",
            cwd / "MIP.zip",
            script_dir,
            script_dir / "Maturity In Practice",
            script_dir / "Maturity In Practice.zip",
            script_dir / "MIP",
            script_dir / "MIP.zip",
            repo_root_from_tool_dir,
            repo_root_from_tool_dir / "Maturity In Practice",
            repo_root_from_tool_dir / "Maturity In Practice.zip",
            repo_root_from_tool_dir / "MIP",
            repo_root_from_tool_dir / "MIP.zip",
        ]
    )

    for candidate in candidates:
        dbg(f"discover: checking {candidate}")
        try:
            if candidate.is_dir():
                CorpusSource._detect_folder_root(candidate)
                dbg(f"discover: valid folder at {candidate}")
                return candidate

            if candidate.is_file() and candidate.suffix.lower() == ".zip":
                with zipfile.ZipFile(candidate) as zf:
                    CorpusSource._detect_zip_prefix(zf)
                dbg(f"discover: valid zip at {candidate}")
                return candidate

        except Exception as exc:
            dbg(f"discover: {candidate} rejected ({exc})")
            continue

    dbg("discover: no valid source found")
    return None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    dbg(f"main: argv={sys.argv}")
    initial_source = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    app = MipReaderApp(initial_source=initial_source)
    app.mainloop()
    dbg("main: mainloop exited")


if __name__ == "__main__":
    main()