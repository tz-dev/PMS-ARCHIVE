# Maturity in Practice

## Purpose

**Maturity in Practice** is a praxeological anthropology and model corpus for analysing maturity, responsibility, asymmetry, power, role enactment, and dignity in practice.

It reads enactments, roles, structures, trajectories, responsibility distributions, power conditions, and dignity-in-practice. It does not read the value, essence, moral rank, clinical state, legal guilt, HR suitability, or ontological dignity of persons.

Compact boundary:

```text
maturity-in-practice ≠ person diagnosis
D₀ dignity ≠ measurable variable
examples ≠ validation
scores ≠ hard truth
reader navigation ≠ authority
AI-assisted analysis ≠ decision authority
```

---

## Ecosystem Position

Maturity in Practice belongs to the PMS corpus-form repository family. It is adjacent to PMS rather than a PMS add-on.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies a compatible praxis grammar but does not turn MIP into PMS Base validation. |
| PMS-DISCIPLINE | Routes sensitive application, claim ceilings, stop conditions, and Case Record discipline when MIP is used in PMS workflows. |
| PMS-ORCHESTRATOR | May stage MIP/AHP routing after PMS-DISCIPLINE gates; it does not validate MIP findings. |
| PMS-STRATA | Can make composition, decomposition, projection, and score/claim retyping more inspectable without increasing authority. |
| PMS — UNDER LOAD | Critiques score drift, person-near overreach, publicness, and corpus/reader authority drift. |

MIP is strongest when it remains a disciplined reading of praxis under asymmetry, not a ranking instrument for persons.

---

## Repository Form

This is a **corpus-form praxeological anthropology repository**.

| Material | Function |
| --- | --- |
| `00_source/` | Source corpus and canonical book-level materials. |
| `01_blocks/` | Modular theory blocks for reading and reuse. |
| `02_appendices/` | Glossary, templates, examples, discipline adaptation, axiomatic core, and notation support. |
| `03_reference/` | Audit checklist, claim types, cross-reference map, misuse red zones, and reader pathways. |
| `04_minified/` | Compact claim boundaries and release-safe summaries. |
| `05_model/` | YAML model, AHP Precision add-on, rendered examples, and human-readable model specifications. |
| `06_MIP Reader/` | Optional local navigation and inspection tool. |

This README orients the corpus. The canonical content remains in the source, block, appendix, reference, minified, and model layers.

---

## Reader / Navigation Tooling

![MIP Reader screenshot](06_MIP%20Reader/screenshot.png)

The MIP Reader is a local navigation and inspection aid for the corpus.

It may support:

```text
canonical file navigation
heading navigation
corpus-wide search
model-layer navigation
Markdown example navigation
YAML example navigation
model specification navigation
guardrail search
D0 / D1 / D2 search
A–C–R–P–D search
IA-box search
red-zone search
AHP Module search
file statistics
audit-oriented inspection
```

Reader boundary:

```text
reader-assisted navigation ≠ model validation
reader visibility ≠ maturity finding
local convenience ≠ application authority
file statistics ≠ evidence weight
```

See `06_MIP Reader/mip_reader.py` and `03_reference/Reader_Pathways.md` for navigation details.

---

## Core Model

The active model axis is:

```text
A–C–R–P–D
```

| Axis | Reads |
| --- | --- |
| A | awareness / attention to praxis conditions |
| C | coordination / contextual enactment |
| R | responsibility / response-capability in practice |
| P | power / asymmetry / cost and role configuration |
| D | dignity-in-practice under protected boundary conditions |

The model is not a developmental ladder, personality typology, maturity ranking, moral score, diagnostic instrument, or automated evaluator.

---

## IA-Box and Dignity Boundary

The IA-Box is the model's inadult asymmetry module. It helps read situations in which dependency, power, developmental position, or structural vulnerability makes simple reciprocity language misleading.

Dignity language is bounded:

```text
D₀ = inviolable dignity
D₁ / D₂ = contextual dignity-in-practice readings
```

D₀ is not scored, ranked, reduced, increased, decreased, diagnosed, inferred from conduct, or made dependent on maturity-in-practice.

MIP may examine how practices affect dignity-in-practice. It may not convert dignity into a measurable property of persons.

---

## Model Layer

The main model files are:

| File | Function |
| --- | --- |
| `05_model/MIP - Maturity in Practice.yaml` | Main machine-readable model layer. |
| `05_model/MIP - Maturity in Practice - AHP Module.yaml` | Optional AHP Precision module for artefact hardening and misuse resistance. |
| `05_model/*Model Specification*.md` | Human-readable explanation of model structure and fields. |
| `05_model/*examples*` | Rendered examples and testable model applications. |

AHP evaluates the analysis artefact and its attack surface. It does not evaluate the case actors.

---

## Practical AI-Assisted Use

MIP can be used iteratively with an AI service as a structured trainer or analysis assistant, provided the output remains bounded and reviewed.

Recommended first-pass settings:

```text
reflection_mode: off
d_module_preference: auto
analysis_mode: full
output_format: text
discipline_profile: generic
```

A typical use cycle is:

| Step | Purpose |
| --- | --- |
| First structural pass | Map roles, information basis, A–C–R–P–D profile, A-band, M-band, IA-box, trajectory, open questions, and report form. |
| Guided refinement | Re-run with `reflection_mode: on` to clarify assumptions, missing perspectives, inference risks, and scope. |
| Optional AHP | Add the AHP Module to inspect attack surface, precision, misuse risk, iteration readiness, and transmission safety. |
| Hardened re-run | Refine case description, claim scope, definitions, evidence links, reversibility clauses, D-language, and transmission boundaries. |
| Transmission check | Review application zone, red-zone risk, participation, evidence limits, D₀ protection, publicity level, and decision-readiness. |

No MIP output should be transmitted into high-stakes decisions without independent procedure, evidence review, and affected-party safeguards.

For the full workflow, see `05_model/` and the relevant reference files in `03_reference/`.

---

## Application Zones

MIP uses an application-zone model.

| Zone | Permitted orientation |
| --- | --- |
| Green | Self-reflection, fictional cases, historical cases, training, research, teaching, and professional supervision without sanctions. |
| Yellow | Real affected persons, internal organisational reflection, moderated supervision, team learning, ethics review, or governance preparation under strict safeguards. |
| Red | Prohibited use: clinical diagnostics, forensics, individual HR decisions, child/youth diagnostics, public pillorying, public ranking, person-level dignity labelling, acute conflict weaponization, or automated decision enforcement. |

Red-zone rule:

```text
If a planned use smells like a red zone, do not use the model there.
```

---

## Examples

The example suite should be read as controlled application material, not proof of model validity.

| Example | Location |
| --- | --- |
| Minimal Public Criticism | `05_model/examples/` |
| Blurry Responsibility | `05_model/examples/` |
| Public Moral Critique with AHP | `05_model/examples/` |
| Meta Analysis with AHP | `05_model/examples/` |
| Self-Application of the Model on Itself | `05_model/examples/` |

Examples demonstrate structural use, claim ceilings, AHP hardening, and transmission boundaries.

---

## Reading Path

Recommended path:

```text
README
→ 00_source
→ 01_blocks
→ 02_appendices
→ 03_reference
→ 05_model
→ examples
→ optional Reader
```

For quick orientation, start with the source text and `03_reference/Reader_Pathways.md`.

For AI-assisted use, start with `05_model/MIP - Maturity in Practice.yaml`, then add the AHP Module only when precision hardening is needed.

---

## Status

Maturity in Practice currently exists as a modular corpus and model-layer specification.

Its current value is praxeological and structural:

```text
praxeological anthropology
maturity-in-practice framework
A–C–R–P–D model
IA-box asymmetry logic
dignity-in-practice safeguards
A/M band logic
trajectory orientation
guardrail corpus
red-zone discipline
machine-readable model
AHP module
rendered examples
local reader tooling
```

It is not published as a clinical instrument, legal assessment tool, HR tool, forensic tool, automated decision engine, or person-ranking system.

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| Maturity in Practice DOI | [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.17897159.svg)](https://doi.org/10.5281/zenodo.17897159) |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing Maturity in Practice, cite the repository release and DOI corresponding to the version used. Do not cite MIP as if it validates PMS Base, or cite PMS Base as if it validates MIP results.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
