---
document_id: MIP-MIN-CLAIM-BOUNDARY
title: "MIP Claim Boundary Minified"
source_basis:
  - "03_reference/Claim_Type_Table.md"
  - "03_reference/Misuse_Red_Zone_Map.md"
  - "03_reference/Audit_Checklist.md"
  - "02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md"
source_role: "minified boundary reference"
target_file: "04_minified/MIP_Claim_Boundary_Minified.md"
status: "minified-reference"
version: "v1"
minified_id: "claim-boundary"
minified_role: "short boundary contract for safe MIP claims"
claim_mode: "boundary-setting, misuse-preventive, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-profile qualitative; no dignity score; no person scoring"
mip_status: "minified from canonical corpus and reference layer; no content expansion"
---

# MIP Claim Boundary — Minified

MIP makes **bounded claims about practice**.

It reads:

```text
enactments
roles
structures
asymmetries
trajectories
responsibility
power
dignity-in-practice
```

It does **not** decide:

```text
person worth
ontological dignity
dignity score
IA verdict against a person
clinical status
legal guilt
HR suitability
child/youth maturity
moral essence
final truth about a person
```

---

## 1. Core boundary

```text
MIP reads enactments.
MIP does not rank persons.

D₀ remains inviolable.
D₁/D₂ describe dignity-in-practice.
D-profile is qualitative, not a dignity score.
A/M are contextual bands under conditions.
M-score is shared structural responsibility, not guilt.
IA-box is an asymmetry check, not a verdict.
Guardrails govern every application.
```

---

## 2. MIP may claim

MIP may claim:

```text
In this role, in this scene, this enactment shows certain A–C–R–P patterns.

This asymmetry is functional / IA-risk / inadult according to the IA-box (`T–J–TB–R`).

This role carries higher or lower shared structural responsibility under the M-score factors.

This scene shows qualitative dignity-in-practice effects such as self-devaluation,
public shaming, protection, degradation or dignity-stabilising conduct.

This trajectory shows learning, stagnation, escalation or repair.

This analysis is unsafe because guardrails or red-zone boundaries are violated.
```

---

## 3. MIP may not claim

MIP may not claim:

```text
This person is immature.
This person is inadult.
This person has low dignity.
This person has lost dignity.
This person is guilty.
This person is clinically diagnosable.
This person is HR-unsuitable.
This child ranks low in maturity.
This person is morally worth less.
```

---

## 4. A-score boundary

A-score means:

```text
contextual maturity-in-practice band
for a specific enactment / role / scene / time window
```

A-score does not mean:

```text
personality score
virtue score
adultness type
human worth
diagnosis
```

Valid:

```text
In this scene, the role enactment shows A ≈ 4–5.
```

Invalid:

```text
X is A=4.
X is an immature person.
```

---

## 5. M-score boundary

M-score means:

```text
shared structural responsibility under conditions
```

It checks:

```text
knowledge
power/control
predictability
access to alternatives
serious integration attempt
```

M-score does not mean:

```text
guilt
legal culpability
moral blame
punishment share
```

Ceiling rule:

```text
If predictability ≈ 0 or access to alternatives ≈ 0,
M must not exceed 4/10.
```

---

## 6. D boundary

D₀:

```text
ontological dignity
inviolable
immeasurable
non-gradable
non-losable
outside all scoring
```

D₁/D₂:

```text
dignity-in-practice
observable enactments
context-bound
revisable
qualitative D-profile only
not person worth
not dignity score
```

Valid:

```text
The scene shows a D₁ pattern of self-devaluation.
The public communication creates D-P risk.
```

Invalid:

```text
This person is undignified.
This person has no dignity.
```

Default:

```text
D-module off unless consciously activated with clear purpose, safe frame and fulfilled guardrails.
D-profile is qualitative, not a dignity score.
D-Quick-Grid, if used, is a movement tool, not a label.
```

---

## 7. IA boundary

IA-box (`T–J–TB–R`) belongs to:

```text
asymmetries
structures
role relations
knowledge/power distributions
communication patterns
```

IA-box is an asymmetry check, not a verdict.
IA does not belong to persons as type.

Valid:

```text
The asymmetry shows IA risk because transparency and reversibility are weak.
```

Invalid:

```text
The other side is inadult.
```

---

## 8. Red zones

MIP must not be used for:

```text
clinical diagnostics
therapy planning
forensic assessment or criminal-justice decision support about individuals
individual HR decisions
child/youth diagnostics
custody/separation weaponisation
public ranking
public pillory
online shaming or doxing
humiliation diagnostics
public D-readings of identifiable persons
automated verdicts
dignity ranking or dignity labelling of persons
```

If a red zone is active:

```text
stop
change purpose
or do not apply MIP
keep the result as working_note / not_mature_for_transmission
```

---

## 9. Transmission rule

Before any MIP-derived claim is shared, check:

```text
role named?
context named?
time window named?
guardrails active?
D₀ protected?
A/M justified as bands?
IA-box treated as asymmetry check, not verdict?
ceiling rule checked?
D-module off or safely activated?
D-profile qualitative and separate from A/M bands?
publicness considered?
vulnerability considered?
claim reversible?
observer role visible?
```

If not:

```text
working_note only
not_mature_for_transmission
not transmissible analysis
```

---

## 10. Final formula

```text
MIP may criticise enactments.
MIP may mark structures.
MIP may locate asymmetries through the IA-box.
MIP may distribute shared structural responsibility more fairly.
MIP may describe dignity-in-practice qualitatively.

MIP may not reduce a human being to any of these findings.
MIP may not turn D-profile into a dignity score.
MIP may not turn IA-box into a verdict against a person.
```
