---
document_id: MIP-MIN-BLOCK-CONTRACTS
title: "Block Contracts"
source_basis:
  - "01_blocks/01_position_claim.md"
  - "01_blocks/02_base_model_acrpd.md"
  - "01_blocks/03_guardrails_use.md"
  - "01_blocks/04_functional_vs_inadult.md"
  - "01_blocks/05_measuring_maturity.md"
  - "01_blocks/06_m_score_fairness.md"
  - "01_blocks/07_tools_case_lens.md"
  - "01_blocks/08_domain_modules.md"
  - "01_blocks/09_bias_intuition_norm_change.md"
  - "01_blocks/10_countercritique_response.md"
  - "01_blocks/11_visual_quick_access.md"
  - "01_blocks/12_conclusion.md"
  - "02_appendices/Appendix_A_Glossary.md"
  - "02_appendices/Appendix_B_Checklists_Templates.md"
  - "02_appendices/Appendix_C_Case_Examples.md"
  - "02_appendices/Appendix_D_Discipline_Adaptation.md"
  - "02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md"
  - "03_reference/Cross_Reference_Map.md"
  - "03_reference/Claim_Type_Table.md"
  - "03_reference/Misuse_Red_Zone_Map.md"
source_role: "minified block contract map"
target_file: "04_minified/Block_Contracts.md"
status: "minified-reference"
version: "v1"
minified_id: "block-contracts"
minified_role: "short use contract for each canonical block and appendix"
claim_mode: "contractual, navigational, guardrail-bound, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable across all blocks; D₁/D₂ only where guarded and context-bound"
mip_status: "minified from canonical corpus and reference layer; no content expansion"
---

# Block Contracts

This file gives a short contract for each canonical MIP block and appendix.

It does not replace the blocks.  
It states how each file may be used and where its boundary lies.

---

## Core rule for all blocks

Every block must be read under the same boundary:

```text
MIP reads enactments.
MIP does not rank persons.
D₀ remains inviolable.
A/M are contextual bands.
D₁/D₂ describe dignity-in-practice only.
D-profile is qualitative, not a score.
IA-box is an asymmetry check, not a verdict.
Tools structure perception; they do not decide cases.
If guardrails fail, the result remains working_note / not_mature_for_transmission.
Guardrails govern every application.
```

---

# 01_blocks

---

## Block 01 — Position and Claim

File:

```text
01_blocks/01_position_claim.md
```

Role:

```text
opens the model, states its claim, defines the basic stance
```

May be used for:

```text
orientation
citation of the model’s scope
distinguishing praxeological analysis from moralism or diagnosis
```

Must not be used for:

```text
expanding MIP into person diagnosis
turning maturity into personality essence
claiming total explanatory authority
```

Boundary:

```text
MIP is a praxeological anthropology of enactment, not a judgement on persons.
```

---

## Block 02 — Base Model A–C–R–P–D

File:

```text
01_blocks/02_base_model_acrpd.md
```

Role:

```text
defines the core model A–C–R–P–D
```

May be used for:

```text
explaining the axes
defining A, C, R, P and D
introducing D₀/D₁/D₂
grounding later tools
```

Must not be used for:

```text
scoring persons
using D as human worth metric
detaching axes from role/context
```

Boundary:

```text
A–C–R–P–D describes practice under conditions, not person essence.
```

---

## Block 03 — Framework of Use and Guardrails

File:

```text
01_blocks/03_guardrails_use.md
```

Role:

```text
defines mandatory safe-use conditions
```

May be used for:

```text
red-zone exclusion
D-module limits
safe-use checks
invalidating unsafe analyses
```

Must not be skipped when applying the model.

Boundary:

```text
If guardrails fail, the analysis is not mature MIP use.
```

---

## Block 04 — Functional vs. Inadult Asymmetry

File:

```text
01_blocks/04_functional_vs_inadult.md
```

Role:

```text
distinguishes functional asymmetry from inadult asymmetry
```

May be used for:

```text
IA-box logic
T–J–TB–R distinction
analysing power/knowledge asymmetries
```

Must not be used for:

```text
calling persons inadult
collapsing all asymmetry into abuse
ignoring justified functional asymmetry
```

Boundary:

```text
Asymmetry is not automatically bad; it must be transparent, justified, time-bound and reversible.
```

---

## Block 05 — Measuring Maturity in Practice

File:

```text
01_blocks/05_measuring_maturity.md
```

Role:

```text
defines A-score logic and maturity bands
```

May be used for:

```text
contextual A-band estimation
maturity-in-practice analysis
score justification through A–C–R–P
```

Must not be used for:

```text
person ranking
virtue scoring
diagnostic labelling
```

Boundary:

```text
A-score is a contextual band for enactment, not a person score.
```

---

## Block 06 — M-score, Ceiling Rule and Fairness

File:

```text
01_blocks/06_m_score_fairness.md
```

Role:

```text
defines shared responsibility and the ceiling rule
```

May be used for:

```text
M-score reasoning
responsibility distribution
victim-blaming protection
ceiling-rule checks
```

Must not be used for:

```text
assigning guilt
retroactive over-demand
making affected persons responsible where predictability or alternatives were absent
```

Boundary:

```text
No high M without predictability and real alternatives.
```

---

## Block 07 — Guiding Formulas and Tools

File:

```text
01_blocks/07_tools_case_lens.md
```

Role:

```text
provides the Case Lens, score sheets, trajectories and practical tools
```

May be used for:

```text
case analysis
templates
stepwise application
trajectory reading
review planning
```

Must not be used for:

```text
mechanical scoring
bureaucratic labelling
automated decision-making
analysis without corrective trajectory
transmission without final checklist
hidden assumptions in reports
```

Boundary:

```text
Case Lens, sheets and trajectories are structuring protocols, not decision engines.
Every IA analysis must move toward at least one actionable improvement or review path.
```

---

## Block 08 — Domain Modules

File:

```text
01_blocks/08_domain_modules.md
```

Role:

```text
shows domain-specific lenses
```

May be used for:

```text
psychology-performative reading
philosophy/religion
sociology/politics
culture/media
practice ethics
```

Must not be used for:

```text
creating new independent models
weakening the core guardrails
turning domain lenses into diagnostics
replacing legal, clinical, educational, organisational or domain-specific responsibility
```

Boundary:

```text
Domain modules are lenses and hotspot maps, not new models and not expert substitutes.
```

---

## Block 09 — Bias, Intuition and Norm Change

File:

```text
01_blocks/09_bias_intuition_norm_change.md
```

Role:

```text
marks limits of perception, intuition and norm stability
```

May be used for:

```text
bias checks
meta-notes
norm assumption documentation
intuition calibration
```

Must not be used for:

```text
relativising all guardrails
turning intuition into verdict
hiding normative assumptions
```

Boundary:

```text
Intuition may start analysis, but must not end it.
```

---

## Block 10 — Countercritique and Response

File:

```text
01_blocks/10_countercritique_response.md
```

Role:

```text
stress-tests the model against critique
```

May be used for:

```text
misuse critique
limits of measurement
D-module objections
anti-morality-machine clarification
distinguishing model critique from analysis-artifact critique
```

Must not be used for:

```text
claiming the model is immune to misuse
dismissing critique
weakening red zones
confusing model countercritique with AHP analysis-hardening
```

Boundary:

```text
The model must remain open to critique by its own standards.
Countercritique tests the model and its assumptions; AHP tests the precision of a concrete analysis artifact.
```

---

## Block 11 — Visual Quick Access

File:

```text
01_blocks/11_visual_quick_access.md
```

Role:

```text
provides one-page access, audit checklist, conflict loop and D quick grid
```

May be used for:

```text
quick orientation
team use
conflict loop
visual summary
light audit
```

Must not be used for:

```text
bypassing full guardrails in high-risk cases
using D quick grid as person label
reducing MIP to a checklist only
turning the audit checklist into a verdict mechanism
treating the conflict loop as conflict resolution
```

Boundary:

```text
Quick access is an emergency brake and orientation aid, not full analysis and not a guardrail bypass.
```

---

## Block 12 — Concluding Word

File:

```text
01_blocks/12_conclusion.md
```

Role:

```text
closes the model as working version and ethics-rider toolbox
```

May be used for:

```text
version humility
self-implication
revision commitment
ethics of use
```

Must not be used for:

```text
finalising the model as closed doctrine
claiming immunity from counterexamples
```

Boundary:

```text
Maturity in practice remains work for persons, structures and the model itself.
```

---

# 02_appendices

---

## Appendix A — Glossary of Key Terms

File:

```text
02_appendices/Appendix_A_Glossary.md
```

Role:

```text
canonical terminology reference
```

May be used for:

```text
definitions
term clarification
consistent language
```

Must not be used for:

```text
expanding definitions beyond the corpus
overriding the main text
```

Boundary:

```text
Glossary stabilises terms; it does not create new theory.
```

---

## Appendix B — Checklists and Practice Templates

File:

```text
02_appendices/Appendix_B_Checklists_Templates.md
```

Role:

```text
canonical practice-template appendix
```

May be used for:

```text
case documentation
guardrail checks
A/M templates
IA-box forms
optional D notes
Meta Notes
transmission checks
D-Quick-Grid orientation under guardrails
```

Must not be used for:

```text
diagnostic forms
HR forms
forensic checklists
public scoring sheets
professional replacement
sanction templates
```

Boundary:

```text
Templates structure reflection; they do not authorise verdicts, sanctions, diagnostics or professional replacement.
```

---

## Appendix C — Case Examples

File:

```text
02_appendices/Appendix_C_Case_Examples.md
```

Status:

```text
illustrative, pending final update
```

Role:

```text
canonical illustrative case appendix
```

May be used for:

```text
learning by example
training
case-method demonstration
```

Must not be used for:

```text
generalising examples into laws
treating fictional examples as evidence
expanding the model through cases
treating case examples as finalised reference logic before the final case-example pass
```

Boundary:

```text
Examples illustrate use; they do not prove, expand or stabilise the model until final case-example pass is complete.
```

---

## Appendix D — Discipline Adaptation

File:

```text
02_appendices/Appendix_D_Discipline_Adaptation.md
```

Role:

```text
canonical discipline and field adaptation map
```

May be used for:

```text
field-specific orientation
module prioritisation
discipline-sensitive reading
```

Must not be used for:

```text
creating separate discipline-specific models
weakening the axiomatic core
turning field use into diagnostics
replacing legal, clinical, educational, organisational or domain-specific responsibility
claiming domain authority from MIP alone
```

Boundary:

```text
Discipline adaptation changes emphasis, not the core model.
Domain adaptation provides field lenses and hotspot maps, not expert substitutes.
```

---

## Appendix E — Axiomatic Core and Formal Notation

File:

```text
02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md
```

Role:

```text
canonical axiomatic and formal notation appendix
```

May be used for:

```text
axioms
formal tuple notation
A/M formalisation
model boundary clarification
notational hygiene
M(X) instead of M(A)
formal red-zone boundary
```

Must not be used for:

```text
turning MIP into a full calculus
replacing qualitative description
formalising dignity as measurable worth
bypassing context, guardrails, judgement or qualitative interpretation
```

Boundary:

```text
Formal notation is a documentation aid; it does not replace context, guardrails, judgement or qualitative interpretation.
```

---

# 03_reference support contracts

The reference layer may:

```text
collect
order
cross-reference
condense
audit
stabilise boundaries
```

The reference layer may not:

```text
introduce new concepts
weaken guardrails
expand use cases
reinterpret D₀/D₁/D₂
create new scoring rules
```

---

# 04_minified rule

The minified layer may:

```text
summarise
compress
orient
support loading
support quick reading
```

The minified layer may not:

```text
replace canonical blocks
replace appendices
soften red zones
turn summaries into doctrine
```

---

# Final contract

```text
Use the block that owns the claim.

Use Block 02 for the base model.
Use Block 03 for guardrails.
Use Block 04 for asymmetry logic.
Use Block 05 for A-score.
Use Block 06 for M-score and ceiling rule.
Use Block 07 for tools.
Use Block 08 for domains.
Use Block 09 for bias and norm change.
Use Block 10 for critique and limits.
Use Block 11 for quick access.
Use Appendix A for terms.
Use Appendix B for templates.
Use Appendix C for examples.
Use Appendix D for discipline adaptation.
Use Appendix E for axioms and notation.

Use AHP only for analysis-artifact precision, not for first-order MIP findings.
If transmission guardrails fail, keep the result as working_note / not_mature_for_transmission.

When in doubt, return to guardrails.
```
