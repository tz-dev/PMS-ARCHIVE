---
document_id: MIP-MIN-CANONICAL
title: "MIP Minified Canonical"
source_basis:
  - "01_blocks/01_position_claim.md"
  - "01_blocks/02_base_model_acrpd.md"
  - "01_blocks/03_guardrails_use.md"
  - "01_blocks/05_measuring_maturity.md"
  - "01_blocks/06_m_score_fairness.md"
  - "01_blocks/07_tools_case_lens.md"
  - "01_blocks/11_visual_quick_access.md"
  - "02_appendices/Appendix_A_Glossary.md"
  - "03_reference/Misuse_Red_Zone_Map.md"
  - "03_reference/Audit_Checklist.md"
source_role: "minified canonical overview"
target_file: "04_minified/MIP_Minified_Canonical.md"
status: "minified-reference"
version: "v1"
minified_id: "canonical-minified"
minified_role: "short canonical orientation for MIP"
claim_mode: "summary, navigational, guardrail-bound, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-profile qualitative; D-module default-off; no dignity score"
mip_status: "minified from canonical corpus and reference layer; no content expansion"
---

# MIP — Minified Canonical

**Maturity in Practice (MIP)** is a praxeological anthropology of maturity in practice.

It analyses how enactments, roles, structures and asymmetries unfold under conditions of:

```text
awareness
coherence
responsibility
power to act
dignity-in-practice
```

MIP does not ask first:

```text
Who is good?
Who is bad?
Who is mature as a person?
```

It asks:

```text
What is enacted here?
In which role?
Under which conditions?
With which awareness, coherence, responsibility and power?
With which dignity-in-practice effects?
With which possibilities for correction?
```

---

## 1. Core formula

```text
MIP reads enactments.
MIP does not rank persons.

D₀ remains inviolable.
D₁/D₂ describe dignity-in-practice.
D-profile is qualitative, not a dignity score.
A/M are contextual bands under conditions.
M-score is shared structural responsibility, not guilt.
IA-box is an asymmetry check, not a verdict.
Guardrails govern every application.
```

---

## 2. Base model: A–C–R–P–D

### A — Awareness

What was known, knowable or ignored?

Includes:

```text
inner awareness
role awareness
context awareness
publicness awareness
bias awareness
```

### C — Coherence

How well do word, role, action and structure align?

Includes:

```text
social coherence
coherence under power
narrative coherence
institutional / rule coherence
```

### R — Responsibility

Who carries, shifts, refuses or repairs consequences?

Responsibility means:

```text
answering
carrying
repairing
not merely being blamed
```

### P — Power to act

What could realistically be done?

Includes:

```text
real levers
constraints
dependency
social agency
cultural agency
public agency
lack of alternatives
```

### D — Dignity in practice

How is dignity enacted toward self, others and publicness?

D is optional and guarded.

```text
D₀ = ontological dignity, untouchable
D₁ = self-dignity in practice
D₂ = relational dignity in practice
```

Operational subfields:

```text
D-I = inner self-treatment
D-B = bodily/material self-care
D-R = relational dignity
D-P = public dignity-in-practice
```

---

## 3. Person / enactment distinction

MIP never evaluates the person as essence.

It evaluates:

```text
actions
role enactments
patterns
situations
asymmetries
trajectories
structures
```

Forbidden shortcut:

```text
immature person
inadult person
undignified person
low dignity person
```

Required formulation:

```text
role-bound enactment
context-bound pattern
dignity-in-practice effect
IA risk
shared structural responsibility under conditions
```

---

## 4. A-score

The A-score is a banded estimate of maturity in practice.

It is:

```text
role-bound
scene-bound
time-bound
contextual
justified through A–C–R–P
separate from D-profile findings
```

It is not:

```text
person score
virtue score
diagnosis
rank
label
dignity score
```

Valid:

```text
In this scene, the role enactment shows A ≈ 5–6.
```

---

## 5. M-score

The M-score estimates shared structural responsibility for a trajectory or outcome.

It checks:

```text
knowledge
power/control
predictability
access to alternatives
serious integration attempt
```

M is not guilt, fault, blame or moral worth.

Ceiling rule:

```text
If predictability ≈ 0 or access to alternatives ≈ 0,
M must not exceed 4/10.
```

Purpose:

```text
prevent victim-blaming
prevent retroactive over-demand
locate responsibility where knowledge, power and alternatives existed
```

---

## 6. IA-box

Asymmetries are normal.

They become problematic when they fail the IA-box:

```text
T  transparent?
J  justified?
TB time-bound?
R  reversible?
```

Note:

```text
R in the IA-box means reversibility, not responsibility.
```

Assessment:

```text
functional asymmetry
IA risk
inadult asymmetry
```

IA-box is an asymmetry check, not a verdict.  
IA is a property of structures and asymmetries, not persons as type.

---

## 7. D-module

Default:

```text
D-module off
```

D may be used only when:

```text
purpose is clear
frame is safe
guardrails are fulfilled
shame risk is controlled
D₀ remains protected
```

D describes:

```text
self-devaluation
self-care
boundary protection
degrading treatment
public shaming
dignity-stabilising enactments
```

D never describes:

```text
human worth
person dignity as quantity
ontological dignity
clinical state
moral essence
```

D-profile:

```text
qualitative only
not a dignity score
separate from A/M bands
role/context/time-window-bound
```

D-Quick-Grid:

```text
movement tool
not a label
not a person classification
```

---

## 8. Case Lens

The Case Lens is the standard procedure for applied MIP analysis.

Minimal path:

```text
1. Snapshot
2. Frame vs. variability
3. A-bands / trajectories
4. IA-localisation
5. RVR(t) and M-score
6. Decision: maintain / balance / change_stop
7. Review point / falsifier
```

Every mature analysis should move toward:

```text
clarification
protection
repair
learning
structural correction
review
```

Pure diagnosis without corrective trajectory is inadult use.

If guardrails fail:

```text
working_note
not_mature_for_transmission
not decision basis
```

---

## 9. Trajectories

MIP writes curves, not labels.

Use:

```text
A(t)
M(t)
RVR(t)
optional qualitative D(t)
```

Question:

```text
Is the enactment learning, stagnating, escalating or repairing?
```

---

## 10. Red zones

MIP must not be used for:

```text
clinical diagnostics
therapy planning
forensic assessment or criminal-justice decision support about individuals
individual HR decisions
child/youth diagnostics
public pillory
public ranking
custody/separation weaponisation
online shaming or doxing
humiliation diagnostics
public D-readings of identifiable persons
automated verdicts
dignity ranking or dignity labelling of persons
```

If in doubt:

```text
do not score
keep D-module off
make no public D-reading
protect vulnerable parties
return to role/context/guardrails
```

---

## 11. Publicness rule

The more public the analysis, the stricter the guardrails.

Public analysis requires:

```text
role clarity
context limits
reversible wording
no person labels
no D-ranking
no public D-readings of identifiable persons
uncertainty markers
response/correction path
```

---

## 12. Minimal safe-use checklist

```text
[ ] enactment, not person
[ ] role named
[ ] context named
[ ] time window named
[ ] red zones excluded
[ ] D₀ protected
[ ] A/M justified as bands
[ ] IA-box treated as asymmetry check, not verdict
[ ] ceiling rule checked
[ ] D-module off or safely activated
[ ] D-profile, if used, qualitative and separate from A/M bands
[ ] publicness checked
[ ] vulnerability checked
[ ] observer role visible
[ ] revision path present
[ ] corrective/protective next step named
```

If several boxes fail:

```text
working_note
not_mature_for_transmission
not transmissible analysis
```

---

## 13. Final boundary

```text
MIP is not a morality machine.

It is a structured language for reading maturity, responsibility,
asymmetry and dignity-in-practice in enactments under conditions.

It does not diagnose persons.
It does not rank persons.
It does not measure ontological dignity.
It does not assign dignity scores.
It does not turn IA-box into verdicts.
It does not replace clinical, legal, forensic, HR or therapeutic judgement.

It is only mature when its own use remains guarded, revisable,
non-diagnostic and dignity-protective.
```