---
document_id: MIP-REF-AUDIT-CHECKLIST
title: "Audit Checklist"
source_basis:
  - "01_blocks/03_guardrails_use.md"
  - "01_blocks/07_tools_case_lens.md"
  - "01_blocks/11_visual_quick_access.md"
  - "02_appendices/Appendix_B_Checklists_Templates.md"
source_role: "derived reference checklist"
target_file: "03_reference/Audit_Checklist.md"
status: "derived-reference"
version: "v1"
reference_id: "audit-checklist"
reference_role: "safe-use and transmission-readiness checklist"
claim_mode: "procedural, guardrail-bound, audit-oriented, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-profile qualitative; D-module default-off; no dignity score"
mip_status: "derived from canonical core and appendices; no content expansion"
---

# Audit Checklist

This checklist is used before a MIP analysis is transmitted, published, operationalised or used as a basis for decisions.

It does not replace the canonical text.  
It condenses the guardrails, Case Lens logic, score-sheet rules and quick-access checks already present in the corpus.

Core audit question:

> **Is this analysis still reading enactments, roles, structures and trajectories —  
> or has it begun to rank persons, negotiate dignity or produce a verdict?**

---

## 1. Scope check

Before analysis, clarify:

```text
[ ] What exactly is being analysed?
[ ] Is the object an enactment, role, structure, asymmetry, trajectory or decision?
[ ] Is the analysis not aimed at diagnosing or ranking a person?
[ ] Is the purpose of the analysis explicitly named?
[ ] Is the intended use limited and reversible?
```

Allowed objects:

* concrete enactments
* role behaviour
* decision scenes
* organisational patterns
* asymmetries
* responsibility trajectories
* dignity-in-practice enactments, if D is safely activated

Not allowed:

* person essence
* personality type
* moral worth
* ontological dignity
* clinical condition
* legal culpability
* HR suitability
* child/youth maturity ranking

---

## 2. Red-zone check

A MIP analysis must not be used in red zones.

```text
[ ] No clinical diagnostics
[ ] No therapy planning
[ ] No forensic assessment or criminal-justice decision support about individuals
[ ] No individual HR decision
[ ] No child/youth diagnostics
[ ] No custody/separation weaponisation
[ ] No public ranking or pillory
[ ] No online shaming or doxing
[ ] No humiliation diagnostics
[ ] No automated verdict
[ ] No public D-readings of identifiable persons
[ ] No dignity ranking or dignity labelling of persons
```

If any red zone is active:

> **Stop or change the purpose.
> The analysis is not valid as MIP application.**

---

## 3. Role and context check

Every analysis requires role and context.

```text
[ ] Role of the analysed object is named.
[ ] Role of the observer or analyst is named.
[ ] Relevant power differences are named.
[ ] Context is named: private / social / institutional / public / media.
[ ] Time window is named.
[ ] Publicness is considered.
[ ] Affected parties are identified.
```

Guiding questions:

```text
Who acts?
In which role?
Toward whom?
Under which conditions?
Before which audience?
With which power and responsibility?
```

Unclear roles create high IA risk.

---

## 4. Guardrail check

```text
[ ] Focus remains on enactments, not persons.
[ ] No global labels are used.
[ ] No dignity of persons is questioned.
[ ] D₀ is explicitly protected.
[ ] D₁/D₂ are only used as dignity-in-practice descriptions.
[ ] D-profile remains qualitative and separate.
[ ] No dignity score is used.
[ ] A/M bands are justified, not asserted.
[ ] IA-box is treated as an asymmetry check, not a verdict.
[ ] Ceiling rule is checked where vulnerability or limited alternatives are present.
[ ] The observer’s own role and bias risks are visible.
[ ] The result remains revisable.
```

Core formula:

> **Recognise the enactment — not the person.**

---

## 5. A–C–R–P structure check

The analysis must show how the A-score or maturity reading was reached.

`A–C–R–P` is the standard analysis core.  
`D` is part of the full model notation `A–C–R–P–D`, but explicit D-findings are optional, protected and default-off.

```text
[ ] A — Awareness: what was known or knowable?
[ ] C — Coherence: did word, role and action align?
[ ] R — Responsibility: what was carried, shifted, refused or repaired?
[ ] P — Power to act: what real levers existed?
[ ] D — Dignity-in-practice: only if safely activated.
```

Minimum documentation:

```text
A:
C:
R:
P:
Optional D:
```

If A–C–R–P is only felt, not reasoned:

> **Back to structure.**

---

## 6. A-score check

The A-score must remain a contextual A-band.

```text
[ ] A-score is expressed as an A-band, not a precise value.
[ ] A-score refers to a role/enactment, not a person.
[ ] A-score includes short justification.
[ ] A-score is tied to scene and time window.
[ ] A-score does not include D as a dignity score.
[ ] D-profile findings remain separate from the A-band.
```

Correct:

```text
In this role and scene, the enactment shows A ≈ 4–5.
```

Incorrect:

```text
This person is A=4.
This is an immature person.
```

---

## 7. M-score check

The M-score must remain an M-band for shared structural responsibility, not guilt.

```text
[ ] Knowledge is checked.
[ ] Power/control is checked.
[ ] Predictability is checked.
[ ] Access to alternatives is checked.
[ ] Serious integration attempt is checked.
[ ] Ceiling rule is applied where needed.
[ ] M is not treated as guilt, fault, blame or moral worth.
```

Ceiling rule:

```text
If predictability ≈ 0 or access to alternatives ≈ 0,
M must not exceed 4/10.
```

Protection question:

> **Who realistically had knowledge, power, alternatives and levers —
> and who was primarily exposed to consequences?**

---

## 8. IA-box check

Every asymmetry should be checked through the **IA-box (`T–J–TB–R`)**.

```text
[ ] T — Transparent?
[ ] J — Justified?
[ ] TB — Time-bound?
[ ] R — Reversible?
```

Note:

```text
R in the IA-box means reversibility, not responsibility.
```

Assessment options:

```text
functional asymmetry
IA risk
inadult asymmetry
```

Audit question:

> **Is the asymmetry serving protection, task or process —
> or mainly preserving comfort, image or power?**

If transparency and reversibility are weak:

> **High IA risk.**

---

## 9. D-module check

Default:

> **D off.**

D may be activated only when purpose, frame and guardrails are clear.

```text
[ ] D is necessary for the case.
[ ] D brings more clarity than shame.
[ ] D is scenic, contextual and revisable.
[ ] D describes enactments, not persons.
[ ] D₀ remains untouched.
[ ] D-profile is qualitative, not a dignity score.
[ ] No D-score is assigned to humans.
[ ] D findings remain separate from A/M bands.
[ ] D-Quick-Grid, if used, is a movement tool, not a label.
[ ] No public D-readings of identifiable persons are made.
[ ] D is not used with children, acutely traumatised persons or highly vulnerable groups.
```

D may describe:

* self-devaluation
* self-care
* boundary protection
* degrading treatment of others
* public shaming
* dignity-stabilising enactments

D must not state:

```text
X has no dignity.
Y is undignified.
Z has low human worth.
```

---

## 10. Bias and projection check

Before transmission, mark bias risks.

```text
[ ] What do I already believe about the case?
[ ] What would confirm my preferred reading?
[ ] What would disconfirm it?
[ ] Am I in anger, loyalty, fear, hurt or self-protection?
[ ] Am I using intuition as a signal or as a verdict?
[ ] Have I considered at least one counter-perspective?
[ ] Have I named my norm assumptions?
[ ] Have I named my dignity lens if D is used?
```

Warning signal:

> **If the analysis feels too smooth, check projection.**

---

## 11. Publicness check

Public or semi-public analyses require stricter review.

```text
[ ] Could this analysis damage reputation?
[ ] Could it be used as public accusation?
[ ] Could it become a file truth?
[ ] Could it be quoted without context?
[ ] Are formulations reversible?
[ ] Is uncertainty visible?
[ ] Is there a path for response or correction?
```

Rule:

> **The more public the analysis, the more conservative the wording must be.**

---

## 12. Vulnerability check

Special caution applies when the analysed party is structurally vulnerable.

```text
[ ] Child or adolescent?
[ ] Dependent person?
[ ] Institutionally controlled person?
[ ] Economically trapped person?
[ ] Legally vulnerable person?
[ ] Traumatised or acutely overwhelmed person?
[ ] Socially marginalised person?
[ ] Person unable to respond?
```

If yes:

```text
default: no scoring
default: D-module off
default: no public D-reading
focus: protection, alternatives, structural responsibility elsewhere
```

Core rule:

> **Do not add analytical burden to those already carrying structural burden.**

---

## 13. Trajectory check

MIP should not freeze people or structures into labels.

```text
[ ] Is the analysis time-bound?
[ ] Are changes over time visible?
[ ] Are responsibility points identified?
[ ] Are learning, stagnation, escalation or repair described?
[ ] Is there a review point?
[ ] Is there a possibility of correction?
```

Preferred notation:

```text
A(t)
M(t)
RVR(t)
optional D(t)
```

Rule:

> **Write curves, not labels.**

---

## 14. Consequence check

Before use, ask what the analysis will do.

```text
[ ] What happens if this analysis is believed?
[ ] Who gains power?
[ ] Who loses reputation, options or voice?
[ ] Who becomes protected?
[ ] Who becomes fixed in a role?
[ ] Are proposed steps transparent?
[ ] Are proposed steps justified?
[ ] Are proposed steps time-bound?
[ ] Are proposed steps reversible?
```

If no corrective, protective or learning-oriented trajectory follows:

> **Do not transmit as completed analysis.**

---

## 15. Minimal transmission checklist

Before sharing externally:

```text
[ ] Source and scope are clear.
[ ] Role/context/time window are clear.
[ ] Red zones are excluded.
[ ] A/M are justified bands.
[ ] IA-box is documented as asymmetry check, not verdict.
[ ] Ceiling rule is checked.
[ ] D₀ is protected.
[ ] D is off or safely activated.
[ ] D-profile, if used, is qualitative and separate from A/M bands.
[ ] Bias/norm assumptions are named.
[ ] Publicness risk is considered.
[ ] Vulnerability is considered.
[ ] Wording avoids person labels.
[ ] Revision path exists.
[ ] Practical next step or review point is named.
```

If several boxes fail:

> **The analysis remains `working_note` / `not_mature_for_transmission`, not a transmissible MIP analysis.**

---

## 16. Optional AHP check

If the optional AHP module is used:

```text
[ ] AHP checks the analysis artifact, not the person or case directly.
[ ] AHP does not rescore A/M/IA/D.
[ ] AHP does not activate the D-module.
[ ] AHP does not change transmission status.
[ ] Attack Points describe analysis vulnerabilities, not person findings.
[ ] Hardening Actions feed the next MIP iteration.
```

---

## 17. Final audit formula

```text
MIP analysis is transmission-ready only if it:

- reads enactments, not persons;
- names role, context and time window;
- keeps D₀ inviolable;
- uses A/M as justified contextual bands;
- treats IA-box as an asymmetry check, not a verdict;
- applies the ceiling rule;
- treats D₁/D₂ only as optional dignity-in-practice descriptions;
- keeps D-profile qualitative and separate from A/M bands;
- excludes red zones;
- remains reversible and open to critique;
- leads toward protection, repair, learning or structural correction.
```
