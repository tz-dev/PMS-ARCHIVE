---
document_id: MIP-UPDATE-TO-DO
title: "MIP Update To Do"
source_role: "editorial update protocol and consistency checklist"
target_file: "03_reference/MIP_Update_To_Do.md"
status: "reference-working-note"
version: "v1"
reference_id: "mip-update-to-do"
reference_role: "editorial maintenance checklist"
claim_mode: "editorial, notation-stabilising, guardrail-bound, no-content-expansion"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-profile qualitative; no dignity score"
mip_status: "reference layer; update guidance; not canonical theory block"
scope: "editorial markup pass, notation cleanup, boundary consistency, misuse-resistance"
canonicality: "non-canonical support document"
---

# MIP Update To Do

## General editorial rule

Apply an editorial markup pass only.

No content expansion.

Allowed:

```text
bold / code / italics
consistent technical notation
clearer boundary labels
formula blockquotes
table/list cleanup
tool / gate / red-zone status clarification
correction of real typo / notation errors
removal of irrelevant aside material
```

Not allowed:

```text
new theory
new examples
new application rules
changed claims
changed score logic
changed D logic
softened guardrails
softened red zones
person-level labels
clinical diagnostic language as a positive MIP function
turning scores into validation
turning tools into verdicts
```

The purpose is to improve access, readability, notation discipline, and misuse resistance without expanding the theory.

---

## To do / to check in each block

Apply these checks to every block that is edited.

### Notation consistency

Use these forms consistently:

```text
A–C–R–P–D
IA-box
D-module
D-profile
D-Quick-Grid
D-enactments
A-score
M-score
A-band
M-band
ceiling rule
T–J–TB–R
D₀ / D₁ / D₂
```

Avoid these forms:

```text
IA box
IA-Box
D module
D profile
D quick grid
A score
M score
A Score
M Score
D score
dignity score
```

### Core boundary

Every block must remain compatible with the following boundary:

```text
MIP reads enactments.
MIP does not rank persons.
D₀ remains inviolable.
D₁/D₂ describe dignity-in-practice.
A-score and M-score are contextual working bands, not person scores.
D-profile describes dignity in practice separately.
Guardrails govern every application.
```

### Full model vs. standard analysis core

Use this rule consistently:

```text
A–C–R–P–D = full model axis notation.
A–C–R–P = standard analysis core when explicit D-reading is not activated.
D = model axis and protected optional layer; explicit D-findings are optional and default-off.
```

Do not imply that `D` is outside the model.

Do not imply that explicit D-readings are mandatory.

### Chapter / Block wording

Preserve book-origin wording in the main block prose where appropriate.

Rule:

```text
Main block prose may keep “Chapter”.
README, reference files, minified files, and reader navigation should use “Block”.
```

Do not globally replace “Chapter” with “Block”.

---

## Document-level cleanup for the update file

These instructions apply to the update document itself, not necessarily to the corpus blocks.

### Heading levels

The update document has one main title:

```markdown
# MIP UPDATE TO DO
```

All block sections should use level-two headings:

```markdown
## Block 01 — ...
## Block 02 — ...
## Block 03 — ...
```

Do not use level-one headings for individual blocks.

#### SEARCH

```markdown
# Block 09 — Bias, Intuition & Norm Change
```

#### REPLACE

```markdown
## Block 09 — Bias, Intuition & Norm Change
```

#### SEARCH

```markdown
# Block 10 — Countercritique & Response
```

#### REPLACE

```markdown
## Block 10 — Countercritique & Response
```

#### SEARCH

```markdown
# Block 11 — Visual quick access
```

#### REPLACE

```markdown
## Block 11 — Visual quick access
```

#### SEARCH

```markdown
# Block 12 — Concluding word
```

#### REPLACE

```markdown
## Block 12 — Concluding word
```

### Remove codefence IDs from the update document

Codefence IDs are not needed for repository Markdown.

Preferred regex cleanup:

````text
Search regex:
```([a-zA-Z]+) id="[^"]+"

Replace:
```\1
````

Use regex only.

Do not manually remove codefence IDs one by one if this risks breaking fences.

### Global notation cleanup

These are global notation cleanups and should not be repeated inside every block section.

#### SEARCH

```text
IA box
```

#### REPLACE

```text
IA-box
```

#### SEARCH

```text
IA-Box
```

#### REPLACE

```text
IA-box
```

#### SEARCH

```text
D module
```

#### REPLACE

```text
D-module
```

#### SEARCH

```text
D profile
```

#### REPLACE

```text
D-profile
```

#### SEARCH

```text
D quick grid
```

#### REPLACE

```text
D-Quick-Grid
```

#### SEARCH

```text
A score
```

#### REPLACE

```text
A-score
```

#### SEARCH

```text
A Score
```

#### REPLACE

```text
A-score
```

#### SEARCH

```text
M score
```

#### REPLACE

```text
M-score
```

#### SEARCH

```text
M Score
```

#### REPLACE

```text
M-score
```

#### SEARCH

```text
M-Score
```

#### REPLACE

```text
M-score
```

#### SEARCH

```text
A band
```

#### REPLACE

```text
A-band
```

#### SEARCH

```text
M band
```

#### REPLACE

```text
M-band
```

Use global replacements carefully where capitalization or heading context matters.

---

## Block 01 — Position and Claim

Target file:

```text
01_blocks/01_position_claim.md
```

### Editorial aim

Block 01 establishes the frame of the model.

The block must make visible that:

```text
MIP reads enactments, not persons.
D₀ remains inviolable.
D₁/D₂ describe dignity-in-practice.
The model is a toolbox, not a worldview.
Necessary inadulthood and tragic conflict are acknowledged.
```

Do not add theory.

Do not add examples.

Do not soften the boundary.

Improve only term visibility, notation consistency, and reader guidance.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
maturity in practice
enactment / enactments
praxeological phenomenon
inadult asymmetry (IA)
A–C–R–P–D
D₀ / D₁ / D₂
dignity in practice
functional asymmetry
toolbox, not worldview
bad tools
necessary inadulthood
integration
tragedy clause
moral realism
biological-ontological facts
guardrails
```

Preferred markup:

```markdown
**maturity in practice**
**enactment**
**inadult asymmetry (IA)**
`IA`
`A–C–R–P–D`
`D₀`, `D₁`, `D₂`
```

### Praxeological phenomenon

Where the text says that maturity is not a character trait but a praxeological phenomenon, mark the term visibly.

#### SEARCH

```markdown
not as a character trait, but as a praxeological phenomenon
```

#### REPLACE

```markdown
not as a character trait, but as a **praxeological phenomenon**
```

### IA notation

Use the full form at first technical stabilization:

```markdown
**inadult asymmetry (IA)**
```

After that, use:

```markdown
`IA`
```

Avoid inconsistent alternation between plain `IA`, bold `IA`, and quoted “IA model” unless the quotation is part of the original sentence.

### Dignity levels

The dignity distinction must be visually stable.

Preferred format:

```markdown
* **`D₀` – ontological dignity**  
  the inalienable, equal dignity of all persons; not measurable, not “earned”;
* **`D₁` – dignity in practice / self-dignity**  
  how someone treats themselves, especially when action has costs  
  (operationally: `D-I` – inner dimension of self-treatment; `D-B` – bodily/material dimension of self-treatment);
* **`D₂` – relational dignity**  
  how someone deals with others and the public  
  (operationally: `D-R` – relational dimension; `D-P` – public/symbolic dimension).
```

Use code formatting for:

```text
D₀
D₁
D₂
D-I
D-B
D-R
D-P
```

### Bad tools

Keep the concept, but mark it as a model term to avoid reading it as a person-level moral judgement.

#### SEARCH

```markdown
The model calls such patterns “bad tools”
```

#### REPLACE

```markdown
The model calls such patterns **“bad tools”**
```

If the exact sentence differs, apply the same markup only to the term:

```markdown
**“bad tools”**
```

### Moral-realist premise

Do not expand or shorten the moral-realist passage.

Add or preserve a clear label before the blockquote.

Preferred label:

```markdown
> **Moral-realist premise: ontological values as a necessary consequence of biological conditions**
```

If the existing blockquote already starts directly with “Ontological values as a necessary consequence of biological conditions”, strengthen the first line instead of adding new prose.

### Delete the CRAP passage completely

The CRAP aside is not needed for the canonical corpus. It interrupts the theoretical flow and does not add model function, claim discipline, or application value.

Remove the entire section beginning with:

```markdown
### Note on the “CRAP” acronym
```

and ending immediately before:

```markdown
### 1.1 Five levels on which the model reads
```

#### SEARCH

```markdown
### Note on the “CRAP” acronym

**Yes** – we noticed that in the English translation the five basic parameters could be rearranged
to form the acronym **“CRAP”**.  
**Yes** – we noticed that.  
**Yes** – we even **tried it**.

And then we dropped it, because the reordering required for it would itself have made the test **inadult**. If it had actually improved the model, that would have been the first test of the readers’ maturity. *Unfortunately*, it did not. At the same time, we are fully aware that the model will **informally** circulate under exactly this name – and we take that with humour.

So the rule is: **no CRAP ordering**.  
The parameters remain in their functional original order,
and the meme stays where it belongs – **outside** the analytical tool.

---

### 1.1 Five levels on which the model reads
```

#### REPLACE

```markdown
### 1.1 Five levels on which the model reads
```

If spacing differs, remove everything from the heading `### Note on the “CRAP” acronym` through the horizontal rule immediately before `### 1.1 Five levels on which the model reads`.

---

## Block 02 — Base Model A–C–R–P–D

Target file:

```text
01_blocks/02_base_model_acrpd.md
```

### Editorial aim

Block 02 introduces the technical density of the model.

The block must make visible:

```text
A–C–R–P–D
feedback loop
states
modulators
submodules
role position
publicity level
object of observation
D₀/D₁/D₂
D-I/D-B/D-R/D-P
D-module
D-profile
D-Quick-Grid
language hygiene
risk / danger / harm / potential
```

Do not add theory.

Improve visual structure, notation consistency, and technical term recognition.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
A – awareness
C – coherence
R – responsibility
P – power
D – dignity in practice
feedback loop
state
adult state
inadult dominance
inadult submission
modulators
structural modulators
dynamic / psychosocial modulators
submodule matrix
object of observation
role position
publicity level
D-module
D-profile
D-Quick-Grid
language hygiene
risk
danger
harm
potential
```

### Axis notation

Use code formatting for axis letters and strong formatting for the concept.

Preferred format:

```markdown
**`A` – awareness**
**`C` – coherence**
**`R` – responsibility**
**`P` – power**
**`D` – dignity in practice**
```

Use:

```markdown
`A–C–R–P–D`
```

for the full model axis notation.

### Submodule notation

All submodules must be code-formatted.

Examples:

```markdown
`A-I`, `A-R`, `A-C`, `A-IM`, `A-P`
`C-S`, `C-P`, `C-N`, `C-I`
`R-I`, `R-S`, `R-E`, `R-P`
`P-I`, `P-S`, `P-C`, `P-PU`
`D-I`, `D-B`, `D-R`, `D-P`
```

### States

State labels are situational, not person types.

If headings or list labels contain state terms, mark them as technical state labels.

Preferred formats:

```markdown
##### **State: adult state**
##### **State: inadult dominance**
##### **State: inadult submission**
```

or:

```markdown
##### **`adult state`**
##### **`inadult dominance`**
##### **`inadult submission`**
```

Do not allow these to read as person categories.

### Modulators

Mark modulators as a layer around the axes, not as replacement axes.

Preferred heading:

```markdown
### 2.3 **Modulators** – amplifiers and dampers
```

If adding a short boundary line is acceptable in the local edit, use:

```markdown
> **Function:** modulators do not replace `A–C–R–P–D`; they alter how strongly patterns appear.
```

If strict no-addition editing is required, only mark the existing terms.

### Role and publicity pre-check

The role/publicity step must appear as mandatory.

Preferred markup:

```markdown
**Mandatory step:** always determine **role + publicity** before `A–C–R–P–D`.
```

If the sentence already exists in different wording, only strengthen its visibility.

### Dignity terminology

Use the following distinction consistently:

```markdown
**`D₀` = ontological dignity**  
**`D₁/D₂` = dignity in practice**  
**`D-I/D-B/D-R/D-P` = operational submodules**
```

Use:

```text
D-module
D-profile
D-Quick-Grid
D-enactments
```

Do not use:

```text
D module
D profile
D quick grid
D score
dignity score
```

### Language hygiene

Mark “language hygiene” as model logic, not style advice.

Preferred heading:

```markdown
### 2.8 **Language hygiene**: risk, harm, potential, danger
```

Use code or strong formatting for the four key terms:

```markdown
`risk`
`danger`
`harm`
`potential`
```

or:

```markdown
**Risk**
**Danger**
**Harm**
**Potential**
```

Keep their meanings unchanged.

---

## Block 03 — Framework of Use and Guardrails

Target file:

```text
01_blocks/03_guardrails_use.md
```

### Editorial aim

Block 03 is the use-protection layer.

It must read like a binding use protocol, not like optional advice.

Do not expand the theory.

Do not soften the guardrails.

Make the mandatory status visually clear.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
guardrails
mandatory module
invalid IA analysis
Profile ≠ person
system axiom
minimal adulthood
entry condition
procedural integrity
self-implication
D₀ / D₁ / D₂
D-module
D off / D on
red zones
communication spaces
language rules
double inadult asymmetry
```

### Guardrail rule

Make the invalidity rule highly visible.

Preferred block:

```markdown
> **Guardrail rule:**  
> Without guardrails, any `IA` analysis is **invalid**.
```

Use this only where the underlying sentence already exists or where the edit is explicitly allowed as a formatting-boundary line.

### Profile boundary

Make the person-boundary visible:

```markdown
> **Profile ≠ person.**
```

Mark the key objects of analysis:

```markdown
**structures**
**enactments**
**contexts & modulators**
**Profile ≠ person**
`D₀`
```

### System axiom

Mark the system axiom as a rule, not an aside.

Preferred block:

```markdown
> **System axiom:** no enactment is purely individual.
```

If the surrounding text lists analytic requirements, mark:

```markdown
- **role**
- **system**
- **modulators**
```

### Minimal adulthood

Treat “minimal adulthood” as a technical entry condition, not a moral badge.

Preferred markup:

```markdown
**entry condition: minimal adulthood**
```

or:

```markdown
`minimal adulthood`
```

If the definition appears, mark it as a formula:

```markdown
> **Minimal adulthood = willingness to see oneself as involved and to keep dignity non-negotiable.**
```

If the two self-questions appear, label them:

```markdown
#### Self-check gate
```

### Procedural guardrails

Format procedural guardrails as audit-ready checklist items.

Preferred heading style:

```markdown
#### **Guardrail 1 — structure before person**
#### **Guardrail 2 — dignity protection and anti-ranking**
```

Continue the same style for all guardrails.

Do not alter the number, scope, or content of the guardrails.

### Self-implication

When the analysts’ own `A–C–R–P–D` becomes visible, format the axes as technical reflection points:

```markdown
**`A` – awareness of the analysts**
**`C` – coherence of the analysts**
**`R` – responsibility of the analysts**
**`P` – power of the analysts**
**`D` – dignity in practice of the analysts**
```

Keep the two core principles visible:

```markdown
1. **There is no analysis “from nowhere”.**
2. **Analysts become actors themselves.**
```

### Dignity protection

Make the dignity guardrail visually central.

Preferred block:

```markdown
> **Dignity guardrail:**  
> A human being remains dignified — even when they act in ways that lack dignity.  
> Only `D₁/D₂` are assessed in practice.  
> `D₀` is never assessed.
```

Use code formatting for:

```markdown
`D₀`
`D₁`
`D₂`
`D-I`
`D-B`
`D-R`
`D-P`
```

Preferred dignity list format:

```markdown
* **`D₀` – ontological dignity**
* **`D₁` – praxeological self-dignity in practice**
* **`D₂` – relational dignity in practice**
```

### D as protection instrument

Keep this formula visible:

```markdown
> **D is a protection instrument — not a pillory.**
```

### D optionality

Prevent the apparent contradiction between `D` as model axis and `D` as protected optional layer.

Use the consolidated rule:

```markdown
**Standard analysis core:** `A–C–R–P`  
**Full model notation:** `A–C–R–P–D`  
**Protected optional layer:** explicit `D` findings
```

Do not imply that `D` is absent from the model.

Do not imply that explicit D-readings are mandatory.

### Red zones

Distinguish the two red-zone meanings.

Preferred terms:

```markdown
`D₀ red zone`
`use-context red zone`
```

or:

```markdown
**D₀ red zone**
**use-context red zone**
```

Do not use “red zone” ambiguously where the distinction matters.

### Zone formatting

If green/yellow/red zones appear in prose, turn them into visible zone labels:

```markdown
#### **Green zone — recommended use**
#### **Yellow zone — caution**
#### **Red zone — forbidden**
```

Keep the content unchanged.

---

## Block 04 — Functional vs. Inadult Asymmetry

Target file:

```text
01_blocks/04_functional_vs_inadult.md
```

### Editorial aim

Block 04 is the operational bridge from the base model to IA analysis.

It must make clear:

```text
asymmetry is not automatically bad
functional asymmetry can be justified
IA requires failure in the four-criteria box
role and context must be clarified first
D-readings remain protected
```

Do not add theory.

Do not change the IA logic.

Improve tool visibility and notation consistency.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
asymmetry
functional asymmetry
inadult asymmetry
IA
IA-box
T–J–TB–R
D-specific
role and context logic
observer position
object of observation
role awareness
A-R
semantic drift
D asymmetry
asymmetry of interpretation
faulty dignity-interpretation
self-degradation
societal degradation
```

### IA-box notation

Use this notation everywhere:

```markdown
**IA-box (`T–J–TB–R`)**
```

Criteria format:

```markdown
**`T` – Transparent?**
**`J` – Justified?**
**`TB` – Time-bound?**
**`R` – Reversible?**
```

Do not use:

```text
IA box
IA-Box
T-J-TB-R
B – Justified?
```

### Correct Justified notation

“Justified” is always `J`.

#### SEARCH

```markdown
**`B` – Justified?**
```

#### REPLACE

```markdown
**`J` – Justified?**
```

#### SEARCH

```text
B – Justified?
```

#### REPLACE

```text
J – Justified?
```

### Decision labels

Where the text distinguishes outcomes of the four-criteria check, mark the decision set visibly.

Preferred block:

```markdown
> **Decision:**  
> `functional asymmetry` / `IA risk` / `inadult asymmetry`
```

### Asymmetry terms

Mark the core terms as technical terms at first or central use:

```markdown
**asymmetry**
**functional asymmetry**
**inadult asymmetry (`IA`)**
```

After first stabilization, `IA` may be code-formatted.

### D-specific bullets

Where D-specific notes appear under the four criteria, use a consistent label:

```markdown
**D-specific**
```

Use code formatting for:

```markdown
`D₀`
`D₁`
`D₂`
`D-I/D-B/D-R/D-P`
```

### Reversibility wording

Avoid wording that suggests all consequences can simply be undone.

Preferred formulation:

```markdown
**`D₀` is always intact.**  
**`D₁/D₂` are revisable as enactment forms; this does not erase consequences.**
```

#### SEARCH

```markdown
**`D₀` is always intact.**
**`D₁/D₂` are reversible as enactment forms, not as erased consequences.**
```

#### REPLACE

```markdown
**`D₀` is always intact.**  
**`D₁/D₂` are revisable as enactment forms; this does not erase consequences.**
```

If the original prose says:

```text
D₁/D₂ as dignity in practice are always reversible
```

replace with:

```text
D₁/D₂ as dignity in practice are revisable as enactment forms; this does not mean consequences are erased
```

### Mandatory role/context pre-check

Make the pre-check visible:

```markdown
> **Mandatory pre-check:**  
> Clarify **role**, **context**, and **observer position** before applying `T–J–TB–R`.
```

### Remove ambiguous object placeholder

Avoid `object of observation (A)` because `A` already denotes awareness.

#### SEARCH

```text
object of observation (A)
```

#### REPLACE

```text
object of observation
```

#### SEARCH

```text
Object of observation (A)
```

#### REPLACE

```text
Object of observation
```

If a placeholder is necessary, use:

```markdown
object of observation (`O`)
```

only if the placeholder is used consistently afterward.

### Role awareness

Mark `A-R` as a submodule code.

Preferred markup:

```markdown
**`A-R` – role awareness**
```

If the “start button” phrase appears, mark it as a formula:

```markdown
> **Start button:** `A-R` — clarify the role before scoring the scene.
```

### Semantic drift and D asymmetries

Mark the following as technical terms where they occur:

```markdown
**semantic drift**
**D asymmetry**
**asymmetry of interpretation**
**faulty dignity-interpretation**
**self-degradation**
**societal degradation**
```

Do not add new definitions.

### Diagnostic wording

Avoid using “diagnostic” as a positive label for MIP analysis.

#### SEARCH

```text
heart of this diagnostic
```

#### REPLACE

```text
heart of this analysis
```

Do not replace “diagnostic” when it appears in a negative or boundary phrase such as:

```text
without diagnostic vocabulary
not a diagnostic tool
no clinical diagnostics
```

---

## Follow-up checks after Blocks 01–04

After editing Blocks 01–04, check:

```text
Appendix B:
    IA-box notation must use J for Justified, not B.
    T–J–TB–R must be consistent.

Appendix A:
    Glossary entries should match core notation:
        IA-box
        D-module
        D-profile
        D-Quick-Grid
        A-score
        M-score
        D₀ / D₁ / D₂

Block 05:
    A(A) / A(C) / A(R) / A(P) must not be confused with awareness submodules.

Block 06:
    M(A) must be clarified as actor placeholder, not awareness axis.

Reference files:
    Reader pathways, audit checklist, and claim-type tables should use the same notation.
```

Priority:

```text
1. Block 02 — highest technical density; make terms and submodules visible.
2. Block 01 — stabilize first technical uses and delete the CRAP passage.
3. Block 03 — make guardrails read as binding use protocol.
4. Block 04 — stabilize IA-box, role/context pre-check, and object-of-observation wording.
5. Appendix B — check B/J typo in IA-box templates.
6. Appendix A — align glossary notation.
```

## Final consistency rule for Blocks 01–04

After editing, Blocks 01–04 should preserve the following boundary:

```text
MIP reads enactments.
MIP does not rank persons.
D₀ remains inviolable.
D₁/D₂ describe dignity-in-practice.
A–C–R–P–D is the full model notation.
A–C–R–P is the standard analysis core when explicit D-reading is not activated.
Explicit D-findings are protected, optional, and default-off.
Guardrails govern every application.
Without guardrails, IA analysis is invalid.
Asymmetry is not automatically IA.
IA requires failure or risk in the T–J–TB–R criteria.
Role, context, and observer position must be clarified before IA application.
```

---

## Block 05 — Measuring Maturity in Practice

Target file:

```text
01_blocks/05_measuring_maturity.md
```

### Editorial aim

Block 05 introduces the `A-score` as an operational working instrument.

The main risk is that readers may misread the `A-score` as:

```text
a person score
a maturity rank
a moral verdict
a stable identity label
an exact measurement
```

The editorial task is to make visible that the `A-score` is:

```text
enactment-based
contextual
band-based
revisable
trajectory-oriented
not a person label
not a dignity judgement
```

Do not add theory.

Do not add examples.

Do not change score bands.

Do not change the `A-score` logic.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
A-score
A(H)
A-band
A(t)
working value
enactment
specific situation
episode
role
context
micro-indicators
calibration band
collapse zone
clearly inadult enactment
everyday mixed zone
solid adultness
high adultness
ideal limit value
trajectory
snapshot
development line
ascending line
descending line
zigzag line
plateau line
```

Preferred markup:

```markdown
**A-score**
`A(H)`
`A-band`
`A(t)`
```

Recommended use:

```text
In prose:
    **A-score**

In formal notation / schema / timeline:
    `A(H)`, `A-band`, `A(t)`
```

### A-score boundary

The initial boundary must be visually prominent.

Preferred block:

```markdown
> **A-score boundary:**  
> The **A-score** describes **enactment**, not essence.  
> It is assigned to **cases / situations / structures**, not persons.  
> It is a **working value**, not a moral verdict.
```

If the existing wording differs, preserve the original meaning and apply the same boundary-box formatting.

Do not allow the `A-score` to read as a person-level maturity value.

### A-score notation

Use:

```markdown
`A(H)`
```

for maturity in practice of an enactment, case, or situation `H`.

Use:

```markdown
`A(t)`
```

for time-indexed maturity-in-practice readings.

Do not use `A-score` as a fixed property of a person.

Preferred trajectory notation:

```markdown
`A(t₁) = 3–4 in setting X`
`A(t₂) = 5–6 after intervention Y`
```

This supports the reading:

```text
This enactment constellation was in this band at this time and under this context.
```

It must not support the reading:

```text
This person is 3–4.
```

### Subscore notation

If the text uses the notation:

```text
A(A) · A(C) · A(R) · A(P)
```

mark it as technical notation.

Preferred block:

```markdown
> **Subscore notation:** `A(A) · A(C) · A(R) · A(P)`
```

Use the following interpretation consistently:

```text
`A(A)` = maturity of awareness
`A(C)` = maturity of coherence
`A(R)` = maturity of responsibility
`A(P)` = maturity of action / power
```

Do not use the following as replacements for these subscore terms:

```text
A-A
A-C
A-R
A-P
```

Reason:

```text
`A-C`, `A-R`, and `A-P` already function as awareness submodules elsewhere in the model.
```

### Specific search / replace for Block 05

Replace local inconsistent `A-A` wording only where it clearly refers to the `A(A)` subscore.

#### SEARCH

```text
High A-A
```

#### REPLACE

```text
High `A(A)`
```

#### SEARCH

```text
Low A-A
```

#### REPLACE

```text
Low `A(A)`
```

If other `A-A` occurrences exist, check manually before replacing.

Do not replace awareness submodule codes such as `A-C`, `A-R`, or `A-P`.

### Calibration bands

The 0–10 bands must read as enactment zones, not person ranks.

Preferred heading:

```markdown
#### 5.1.3 Calibration bands `0–10` — enactment zones, not person ranks
```

Preferred band formatting:

```markdown
**`0–1` — collapse zone**
**`2–3` — clearly inadult enactment**
**`4–5` — everyday mixed zone**
**`6–7` — solid adultness**
**`8–9` — high adultness**
**`10` — ideal limit value**
```

Keep the existing meanings unchanged.

Do not convert bands into exact scores.

Do not add decimal precision.

Do not imply that a band describes a person.

### Strong band labels

Terms such as:

```text
collapse zone
clearly inadult enactment
```

must remain clearly attached to enactments, situations, or constellations.

Preferred markup:

```markdown
**`0–1: collapse zone`**
**`2–3: clearly inadult enactment`**
```

Avoid any wording that implies:

```text
inadult person
collapsed person
low-value person
```

### Procedure from profile to score

The practical procedure should read like a work protocol, not like an essay.

If the section already contains steps, mark them clearly.

Preferred structure:

```markdown
#### 5.1.4 Procedure: from profile to score

**Step 1 — define episode / role / context**  
**Step 2 — describe `A–C–R–P`**  
**Step 3 — check micro-indicators**  
**Step 4 — choose band**  
**Step 5 — justify and mark uncertainty**
```

If the exact step order differs in the source text, preserve the source order and only improve the visible step labels.

### D separation in A-score contexts

Where dignity appears near the `A-score`, make sure it is not read as part of the `A-score`.

Preferred boundary line:

```markdown
**D is described separately in the `D-profile`.**
```

Use this only where the text already distinguishes `A`, `M`, and `D`, or where a short boundary line is explicitly permitted.

Do not imply that `D₀`, `D₁`, or `D₂` are included in the `A-score`.

### Trajectories instead of labels

Trajectory logic is a central anti-ranking mechanism.

Make the core formula prominent:

```markdown
> **We write trajectories, not labels.**
```

Alternative if closer to the existing wording:

```markdown
> **The goal is a more mature trajectory — not the fixation of labels.**
```

Use code formatting for time-indexed notation:

```markdown
`A(t₁)`
`A(t₂)`
```

Mark these terms as technical where they appear:

```markdown
**trajectory**
**snapshot**
**development line**
**ascending line**
**descending line**
**zigzag line**
**plateau line**
```

### Measurement language

The title “Measuring maturity in practice” can remain.

However, throughout the block, the term “measuring” must be held by the following concepts:

```text
working value
band
snapshot
situated
revisable
contextualised
trace-backed
```

Do not introduce language that suggests exact measurement, external validation, or person-level quantification.

---

## Block 06 — M-score, Ceiling Rule, and Fairness

Target file:

```text
01_blocks/06_m_score_fairness.md
```

### Editorial aim

Block 06 protects the model from unfair responsibility assignment.

The main risk is that readers may misread the `M-score` as:

```text
guilt
fault
blame
moral worth
personal failure
retroactive responsibility
```

The editorial task is to make visible that `M` describes:

```text
shared structural responsibility
responsibility viability
structural leverage
access to alternatives
predictability
power/control
knowledge
serious integration attempt
```

Do not add theory.

Do not change the `M-score` definition.

Do not change the ceiling rule.

Do not weaken victim-blaming protections.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
M-score
M(A)
M-band
shared responsibility
structural responsibility
structural leverage
responsibility viability
affectedness
fault
guilt
blame coding
ceiling rule
predictability ≈ 0
access to alternatives ≈ 0
M ≤ 4
victim blaming
retroactive over-demand
knowledge
power/control
predictability
access to alternatives
serious integration attempt
A high / M high
A high / M low
A low / M high
A low / M low
self-devaluation
self-degradation
D-profile
```

Preferred markup:

```markdown
**M-score**
`M(A)`
`M-band`
`M ≤ 4`
```

### M-score boundary

The responsibility boundary must be visually prominent.

Preferred block:

```markdown
> **M-score boundary:**  
> `M` describes **shared structural responsibility**, not guilt, fault, blame, or moral worth.
```

If the existing wording differs, preserve the original meaning and apply the same boundary-box formatting.

Do not allow the `M-score` to read as a guilt score.

### M(A) notation

`M(A)` may be kept if it is part of the model’s formal notation.

However, it must not be confused with `A` as the awareness axis.

At first formal occurrence, add or preserve a clarification:

```markdown
`M(A)` = shared responsibility of actor `A`  
Here, `A` denotes an actor placeholder, not the `A` axis for awareness.
```

If the local text does not allow this as a prose addition, add it as a parenthetical note at the first occurrence only.

Do not globally replace `M(A)` unless the whole model notation is being revised.

### Five responsibility factors

The five responsibility factors should be visually stable and always read as criteria, not moral impressions.

Preferred format:

```markdown
1. **Knowledge** (`A`)
2. **Power / control** (`P`)
3. **Predictability**
4. **Access to alternatives**
5. **Serious integration attempt**
```

When these factors appear in prose, mark them consistently:

```markdown
**knowledge**
**power / control**
**predictability**
**access to alternatives**
**serious integration attempt**
```

Use `A` and `P` only where the relation to awareness and power is explicit.

### High M / Low M labels

High and low `M` must not sound like moral upgrade or downgrade.

Preferred clarification:

```markdown
**High `M` = high structural responsibility / leverage**  
**Low `M` = low responsibility viability / primarily affected**
```

Do not imply:

```text
high M = morally better
low M = morally worse
```

### Ceiling rule

The ceiling rule is a core anti-misuse rule and must be visually prominent.

Preferred block:

```markdown
> **Ceiling rule:**  
> `predictability ≈ 0` or `alternatives ≈ 0` → `M ≤ 4`
```

Preferred protection formula:

```markdown
> **Those with no real alternative cannot receive a high `M-score`.**
```

Do not change the threshold logic.

Do not weaken the ceiling rule.

Do not add exceptions unless they already exist in the source.

### Predictability and alternatives headings

Where the block discusses predictability and access to alternatives, format the formula terms visibly.

Preferred headings:

```markdown
#### 6.2.1 `Predictability ≈ 0`
#### 6.2.2 `Access to alternatives ≈ 0`
```

If the section titles already exist in different wording, preserve the title structure and mark the formula terms with code formatting.

### Problematic outside labels

If the text uses terms such as:

```text
reckless
naive
careless
irrational
unwise
just leave
```

as outside interpretations, keep them in quotation marks.

Preferred formatting:

```markdown
“reckless”
“naive”
“careless”
“irrational”
“unwise”
“just leave”
```

These must read as problematic external framings, not as model labels.

### Function of the ceiling rule

Where the text lists the function of the ceiling rule, format it as a protection triad.

Preferred format:

```markdown
**Function 1 — protection against victim blaming**  
**Function 2 — protection against retroactive over-demand**  
**Function 3 — correct responsibility level**
```

Keep the meanings unchanged.

Make visible that the ceiling rule prevents the model from becoming a refined “your fault” instrument.

### A/M matrix

The A/M combinations should be formatted as quadrants.

Preferred format:

```markdown
#### Quadrant 1 — `A high / M high`
#### Quadrant 2 — `A high / M low`
#### Quadrant 3 — `A low / M high`
#### Quadrant 4 — `A low / M low`
```

Mark the key IA-risk constellation:

```markdown
> **IA risk zone:** `high leverage + low maturity`.
```

Do not change the underlying quadrant meanings.

### A/M/D separation

The separation of `A`, `M`, and `D` must be visually explicit.

Preferred block:

```markdown
> **Do not conflate:**  
> `A` = maturity in practice.  
> `M` = shared structural responsibility.  
> `D-profile` = dignity in practice.
```

This is especially important where `D` appears near `M`.

### D and shared responsibility

Self-devaluation and self-degradation must not increase `M`.

Preferred formula:

```markdown
> **Self-devaluation does not raise `M`.**
```

Alternative if closer to the local wording:

```markdown
> **`D₁` strain is not shared responsibility.**
```

Use code formatting for:

```markdown
`D₀`
`D₁`
`D₂`
`D-profile`
```

Do not imply that dignity strain creates guilt or increases structural responsibility.

### Should-have wording

Where the text uses “could and should have acted differently”, ensure that nearby criteria are visible:

```text
knowledge
power/control
predictability
real alternatives
serious integration attempt
```

Do not remove the phrase if it is part of the model definition.

Do not let “should” stand without the criteria that constrain responsibility.

### Victim-blaming protection

Any passage about low `M`, no alternatives, dependency, coercion, or affectedness should preserve the anti-victim-blaming function.

Make visible:

```markdown
**victim blaming**
**retroactive over-demand**
**no real alternative**
**low responsibility viability**
```

Do not add language that increases responsibility for actors who lacked predictability or real alternatives.

---

## Final consistency rule for Blocks 05–06

After editing, Blocks 05–06 should preserve the following core boundary:

```text
A-score = maturity in practice of enactments, not persons.
A-band = contextual working band, not exact measurement.
A(t) = situated snapshot in time, not identity.
Trajectories matter more than isolated score points.
M-score = shared structural responsibility, not guilt.
M-band = responsibility viability / leverage band, not blame.
Ceiling rule prevents victim blaming.
No real alternative means no high M-score.
Self-devaluation does not raise M.
D-profile describes dignity in practice separately.
D₀ remains inviolable.
D₁/D₂ are not person-worth measures.
Scores support structured reflection, not verdicts.
```

## Follow-up checks after Blocks 05–06

After editing Blocks 05–06, check:

```text
Block 07:
    Score sheets must use the same notation as Blocks 05–06:
        A-score
        M-score
        A-band
        M-band
        D-profile
        IA-box

Model specification:
    A/M wording must remain aligned with the block corpus.

Priority:
    1. Block 06 — ceiling rule and M ≠ guilt visibility
    2. Block 05 — A-score boundary and trajectory-over-label visibility
    3. Block 07 — score-sheet notation consistency
    4. Model specification — A/M wording consistency

---

## Block 07 — Guiding Formulas and Tools

Target file:

```text
01_blocks/07_tools_case_lens.md
```

### Editorial aim

Block 07 is the practical tool bridge of the corpus.

The main risk is that readers may misread the tools as:

```text
mechanical checklists
decision engines
diagnostic forms
ranking sheets
substitutes for judgement
```

The editorial task is to make visible that the tools are:

```text
orientation aids
structuring devices
bounded protocols
guardrail-dependent
not verdict machines
not diagnostic instruments
```

Do not add new tools.

Do not add new templates.

Do not change score logic.

Do not change D logic.

Do not turn the tool section into a diagnostic or ranking workflow.

### Terms to mark consistently

Mark these terms as technical tool labels at first or central occurrence:

```text
Case Lens
decision protocol
score sheets
A-score sheet
M-score sheet
IA-box sheet
D-profile sheet
D-enactments
trajectories
A(t)
M(t)
D(t)
System-1 / System-2 micro-tool
STOP–FRAME–ROLE–STEP
Mini-toolkit
Quick-check
Full Lens
Praxeological final checklist
Grail sentence
not mature for transmission
working note
```

Preferred markup:

```markdown
**Case Lens**
**decision protocol**
**score sheets**
`A(t)`
`M(t)`
`D(t)`
`STOP–FRAME–ROLE–STEP`
```

### Case Lens boundary

The Case Lens must read as a structuring lens, not as a decision engine.

Preferred boundary block:

```markdown
> **Case Lens boundary:**  
> The **Case Lens** structures a case.  
> It does not decide the case by itself.
```

If the local edit must avoid adding new sentences, mark only the existing terms:

```markdown
**Case Lens**
**decision protocol**
```

Do not allow the Case Lens to read as:

```text
case verdict
diagnosis
decision engine
automatic judgement
```

### Score sheet hygiene

The score sheets must read as structuring aids, not as ranking forms.

Preferred section labels:

```markdown
#### 7.2.1 **`A-score sheet`**
#### 7.2.2 **`M-score sheet`**
#### 7.2.3 **`IA-box sheet` (`T–J–TB–R`)**
#### 7.2.4 **`D-profile sheet` (`D₁/D₂`)**
```

Where the sheet logic is summarized, keep these distinctions visible:

```markdown
**A-band**, not person score  
**M-band**, not guilt score  
**D-profile**, not dignity score
```

Do not allow score sheets to become person-ranking sheets.

Do not allow D-profile fields to become dignity scores.

### D-profile sheet boundary

The D-profile sheet is the most sensitive tool in Block 07.

Preferred boundary block:

```markdown
> **D-profile boundary:**  
> `D₀` remains outside the card.  
> `D₁/D₂` describe **D-enactments**, not personhood.  
> No numbers. Qualitative bands only.
```

Use code formatting for:

```markdown
`D₀`
`D₁`
`D₂`
`D-I`
`D-B`
`D-R`
`D-P`
```

Use one stable term:

```markdown
**D-enactments**
```

Do not let the text drift into interchangeable labels such as:

```text
dignity score
person dignity
dignity rank
low-dignity person
```

### A/M/D separation

The A/M/D mnemonic is a core anti-conflation rule.

Make it prominent wherever it appears:

```markdown
> A-score describes maturity in practice.
> M-score describes shared structural responsibility.
> D-profile describes dignity in practice.
```

Do not conflate:

```text
A with responsibility
M with guilt
D with score
D₀ with D₁/D₂
self-devaluation with shared responsibility
```

### Trajectories instead of points

Trajectory logic is a core anti-ranking mechanism.

Preferred boundary block:

```markdown
> **We write curves, not labels.**
```

Use code formatting for trajectory notation:

```markdown
`A(t)` – maturity in practice
`M(t)` – shared responsibility across time
`D(t)` – change in dignity enactment (`D₁/D₂`)
```

If the text says that maturity, responsibility, and dignity in practice are trajectories, mark the formula visibly.

Do not turn isolated score points into identity labels.

### Micro-tool boundary

The System-1 / System-2 micro-tool must not read as therapy, self-help diagnosis, or a substitute for the Case Lens.

Preferred boundary block:

```markdown
> **Micro-tool boundary:**  
> `STOP–FRAME–ROLE–STEP` is an emergency lever, not a substitute for the **Case Lens**.
```

Use code formatting consistently:

```markdown
`STOP`
`FRAME`
`ROLE`
`STEP`
`STOP–FRAME–ROLE–STEP`
```

Preferred step formatting:

```markdown
#### Step 1 — `STOP`
#### Step 2 — `FRAME`
#### Step 3 — `ROLE`
#### Step 4 — `STEP`
```

Do not let this tool read as:

```text
therapy protocol
diagnostic self-test
full analysis replacement
```

### Mini-toolkit optionality

The Mini-toolkit must remain visibly optional.

Preferred heading:

```markdown
### 7.5 Mini-toolkit: score sheet and context tools **(optional)**
```

Preferred mode labels:

```markdown
#### Mode 1 — **Quick-check** (`5–10 min`)
#### Mode 2 — **Mini-toolkit** (`30–60 min`)
#### Mode 3 — **Full Lens**
```

Do not make the Mini-toolkit appear mandatory.

Do not let it replace the full Case Lens where full analysis is required.

### Final checklist as transmission gate

The final checklist is a transmission gate.

Preferred boundary block:

```markdown
> **Transmission rule:**  
> If the final checklist fails, the analysis is **not praxeologically mature for transmission**.
```

Where status options are listed, format them clearly:

```markdown
May remain:

- **working note**
- personal thinking attempt

May not become:

- neutral truth
- objective diagnosis
- basis for structural decisions
```

Do not allow a failed checklist to become publishable, institutionalized, or decision-bearing output.

### Grail sentence

Keep the term if it exists, but stabilize it as a tool label.

Preferred heading:

```markdown
#### 7.6.8 The **“Grail sentence”** — final self-implication check
```

The sentence should read as a final self-implication check, not as mystical language.

### Specific search / replace for Block 07

Use only for actual local occurrences.

#### SEARCH

```text
T-J-TB-R
```

#### REPLACE

```text
T–J–TB–R
```

#### SEARCH

```text
T/J/TB/R
```

#### REPLACE

```text
T–J–TB–R
```

Do not repeat global notation cleanup here. Global cleanup already covers `IA box`, `D profile`, `A score`, `M score`, and similar forms.

---

## Block 08 — Domain Modules

Target file:

```text
01_blocks/08_domain_modules.md
```

### Editorial aim

Block 08 adapts the same model logic to different fields.

The main risk is that readers may misread Domain Modules as:

```text
new specialist theories
domain diagnoses
replacement for field expertise
clinical, legal, educational, or organisational authority
```

The editorial task is to make visible that Domain Modules are:

```text
lenses
hotspot maps
field-sensitive activation profiles
not new models
not domain verdicts
not replacements for professional judgement
```

Do not add new domain theories.

Do not add new diagnostic claims.

Do not replace specialist judgement.

Do not introduce clinical, legal, HR, or educational decision authority.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
domain-agnostic
Domain Modules
lenses
hotspots per domain
discipline profiles
activated modules
typical questions
psychology (performative)
outside clinical diagnostics
observable enactments
philosophy and religion
sociology and politics
culture / media
practice ethics
law / organization / education
domain-specific dignity norms
context-sensitive D-reading
```

Preferred markup:

```markdown
**Domain Modules**
**lenses**
**discipline profiles**
**context-sensitive D-reading**
```

Use code formatting for parameter and submodule codes:

```markdown
`A-I`
`A-R`
`R-I`
`P-I`
`D-I`
`A-P`
`P-PU`
`D-P`
`C-N`
```

### Domain-module boundary

The core boundary must be visually prominent.

Preferred boundary block:

```markdown
> **Domain-module boundary:**  
> Domain Modules do not introduce a new model.  
> They are **lenses** for domain-specific hotspots.
```

Also preserve this meaning:

```text
same axiomatic core
different lens
different depth
different activated modules
```

Do not allow Domain Modules to read as independent models.

### Correct field count

If the introduction says “three example fields” while the block contains five modules, correct it.

#### SEARCH

```text
This chapter unfolds three example fields:
```

#### REPLACE

```text
This chapter unfolds five example fields:
```

Alternative if the local text is better kept flexible:

```text
This chapter unfolds several example fields:
```

Use the “five example fields” version if the block structure contains exactly:

```text
8.1 Psychology
8.2 Philosophy and Religion
8.3 Sociology and Politics
8.4 Culture / Media
8.5 Practice Ethics (Law / Organization / Education)
```

### Red-zone wording correction

The phrase “within the red zones” is misleading if it refers to legitimate coaching, supervision, or counselling contexts.

Preferred correction:

#### SEARCH

```text
coaching, supervision, counselling (within the red zones)
```

#### REPLACE

```text
coaching, supervision, counselling (respecting red-zone boundaries)
```

Alternative if closer to the local sentence:

```text
coaching, supervision, counselling (within the guardrails / outside red zones)
```

Do not imply that the model may be used inside red-zone contexts.

### Psychology-module boundary

The psychology module must read as performative and non-clinical.

Preferred boundary block:

```markdown
> **Psychology-module boundary:**  
> No clinical diagnoses.
> No disorder classification.
> No therapy planning.
```

Preferred formula:

```markdown
**performative**, not clinical
```

Use code formatting for key parameters:

```markdown
**`A-I` – inner awareness**
**`A-R` – role awareness**
**`R-I` – individual responsibility**
**`P-I` – inner agency**
**`D-I` – inner dignity** *(optional)*
```

Do not introduce clinical diagnostic vocabulary as a positive MIP function.

Boundary phrases such as “without diagnostic vocabulary” or “outside clinical diagnostics” may remain.

### A/M/D theme labels

If `A-theme`, `M-theme`, and `D-theme` appear, mark them as themes, not scores.

Preferred formatting:

```markdown
**`A-theme`** — how she acts  
**`M-theme`** — how much shared responsibility she structurally carries  
**`D-theme`** — how she treats herself in practice
```

Do not let these labels become a new scoring system.

Do not introduce “theme scores”.

### Domain Modules and discipline profiles

Align Block 08 terminology with the model layer where appropriate.

Preferred bridge sentence, if a local bridge is useful:

```markdown
**Domain Modules** correspond to field-specific **discipline profiles** in the model layer.
```

This bridge should not imply that the YAML creates new axioms.

The correct relation is:

```text
same axiomatic core
field-specific lens
field-specific activation set
field-specific typical questions
```

### Function / not-function labels

For each domain section, add or strengthen a short boundary label if suitable.

Preferred format:

```markdown
**Function:** lens / hotspot map  
**Not:** replacement for domain judgement
```

Use this especially for:

```text
Psychology
Law
Organization
Education
Practice Ethics
Culture / Media
Public Communication
```

### Philosophy / Religion and Sociology / Politics

These sections are sensitive because dignity norms can be culturally, religiously, politically, or historically shaped.

Make these formulas visible where the text already supports them:

```markdown
**context-sensitive D-reading**
**dignity norms**
**who sets the norm?**
**who benefits?**
**who is excluded?**
```

Keep the boundary:

```text
D reads practice.
D does not monopolise dignity.
D does not decide ultimate doctrine.
```

Do not let MIP appear to claim universal authority over religious, political, or cultural dignity language.

### Culture / Media

Where publicness, media, visibility, or platform dynamics appear, mark the relevant codes consistently:

```markdown
`A-P`
`P-PU`
`D-P`
`C-N`
```

Where the existing text supports it, make these warnings visible:

```text
publicity is not truth
virality is not justification
visibility increases reversibility risk
```

Do not add new media theory.

Do not turn media visibility into moral validity.

### Practice Ethics — Law / Organization / Education

This section needs the strongest non-replacement boundary.

Preferred boundary block:

```markdown
> **Practice-ethics boundary:**  
> MIP may structure reflection.  
> It does not replace legal judgement, organisational due process, educational responsibility, or professional accountability.
```

Do not allow MIP to function as:

```text
legal judgement
HR decision basis
educational diagnosis
organisational verdict
professional accountability replacement
```

### Diagnostic wording

Use “diagnostic” only as a boundary term unless the source explicitly frames it as a domain’s own terminology.

Allowed boundary uses:

```text
outside clinical diagnostics
no diagnoses
without diagnostic vocabulary
not a diagnostic tool
```

Avoid positive MIP-function wording such as:

```text
MIP diagnoses the person
MIP provides clinical diagnosis
MIP classifies disorders
```

### Specific search / replace for Block 08

Use only for actual local occurrences.

#### SEARCH

```text
This chapter unfolds three example fields:
```

#### REPLACE

```text
This chapter unfolds five example fields:
```

#### SEARCH

```text
coaching, supervision, counselling (within the red zones)
```

#### REPLACE

```text
coaching, supervision, counselling (respecting red-zone boundaries)
```

Do not repeat global notation cleanup here.

---

## Follow-up checks after Blocks 07–08

After editing Blocks 07–08, check:

```text
Appendix B:
    Practice templates must not contradict Block 07 tool boundaries.
    Score sheets must remain structuring aids, not ranking forms.
    D-profile templates must remain qualitative, not numeric dignity scoring.

Block 11:
    D-Quick-Grid naming must match Block 07.
    Quick-access tools must remain orientation aids, not shortcuts around guardrails.

Model specification:
    Discipline profile wording must remain aligned with Block 08.
    Domain Modules must correspond to lenses, not new model axioms.

Reader:
    Search/navigation labels should distinguish:
        tools
        domain modules
        model specifications
        examples
```

Priority:

```text
1. Block 07 — score sheets, D-profile sheet, and final checklist as gated tools.
2. Block 08 — Domain Modules as lenses, not specialist theories or domain authority.
3. Appendix B — template notation consistency.
4. Model specification — discipline profile wording alignment.
```

## Final consistency rule for Blocks 07–08

After editing, Blocks 07–08 should preserve the following boundary:

```text
Tools structure perception; they do not decide cases.
Score sheets are aids, not rankings.
A-band is not a person score.
M-band is not guilt.
D-profile is not a dignity score.
D-enactments describe practice, not personhood.
Final checklist failure blocks transmission.
Domain Modules are lenses, not new models.
Domain Modules do not replace domain expertise.
Psychology remains performative, not clinical.
Practice Ethics does not replace legal, organisational, educational, or professional judgement.
Guardrails remain active in every application.
```

---

## Block 09 — Bias, Intuition, and Norm Change

Target file:

```text
01_blocks/09_bias_intuition_norm_change.md
```

### Editorial aim

Block 09 is the epistemic self-discipline layer of the corpus.

The main risk is that readers may misread bias, intuition, and norm change as:

```text
soft reflection
optional commentary
background noise
personal humility language
appendix material
```

The editorial task is to make visible that these are:

```text
method components
analysis constraints
guardrails against model absolutism
requirements for D-reading
requirements for responsible application
```

Do not add theory.

Do not add new bias categories.

Do not add new norm-change doctrine.

Do not turn reflexivity into moral self-display.

### Terms to mark consistently

Mark these terms as technical terms at first or central occurrence:

```text
bias
bias-awareness
confirmation bias
hindsight bias
status quo / loyalty bias
halo / horn effects
in-group / out-group bias
intuition
sensor
trigger
not judge
hypothesis, not proof
norm change
dignity concepts
norm assumptions
dignity readings
cultural lens
meta notes
meta-attitude
counterexamples
alternative perspectives
situated perspective
```

Preferred markup:

```markdown
**bias**
**bias-awareness**
**intuition**
**norm change**
**meta-attitude**
```

Use code formatting where the term functions as a model role or notation:

```markdown
`sensor`
`trigger`
`not_judge`
`A`
`A-P`
`D-R`
`D-P`
`M-score`
`D₁/D₂`
```

### Opening formula

If the block contains the guiding sentence:

```text
What we must concede to ourselves so the model becomes a learning tool and not a weapon.
```

make it visible as a block formula.

Preferred formatting:

```markdown
> **What we must concede to ourselves so the model becomes a learning tool — not a weapon.**
```

Do not change the claim. Only make its function visible.

### Bias rule

Bias must read as baseline analytical noise, not as an exceptional moral failure.

Preferred boundary block:

```markdown
> **Bias rule:**  
> **Bias** is not an exception, but baseline noise.  
> **Bias-awareness** is part of `A` — **awareness**.
```

Do not frame bias as personal defect.

Do not imply bias can be fully eliminated.

### Bias risks

Where bias types are listed, format them as risk classes.

Preferred labels:

```markdown
#### Bias risk — **confirmation bias**
#### Bias risk — **hindsight bias**
#### Bias risk — **status quo / loyalty bias**
#### Bias risk — **halo / horn effects**
#### Bias risk — **in-group / out-group bias**
```

If local heading levels differ, preserve the local hierarchy and only strengthen the labels.

### Hindsight risk and M-score

Where hindsight bias is discussed, keep its relevance to the `M-score` visible.

Preferred formula:

```markdown
> **Hindsight risk:**  
> inflated predictability → inflated `M-score`
```

Do not change the `M-score` logic.

Do not add new responsibility factors.

### Dignity-bias effects

If the terms “dignity bonus” and “dignity penalty” appear, mark them as warning terms, not as scores.

Preferred formatting:

```markdown
**dignity-bias effect:** “dignity bonus” / “dignity penalty”
```

Do not introduce:

```text
dignity score
dignity ranking
dignity bonus as metric
dignity penalty as metric
```

### Intuition rule

Intuition must read as a sensor and trigger, not as a judge.

Preferred boundary block:

```markdown
> **Intuition rule:**  
> `intuition = sensor + trigger`  
> `intuition ≠ judge`
```

Alternative table if the section already uses role distinctions:

```markdown
| Role | Meaning |
|---|---|
| `sensor` | early signal / pattern detection |
| `trigger` | starting point for analysis |
| `not_judge` | may never replace `A–C–R–P–D` reading |
```

Do not let intuition replace structured analysis.

Do not frame intuition as proof.

### Hypothesis, not proof

If the text states that intuition must be treated as hypothesis, not proof, make this a visible formula.

Preferred block:

```markdown
> **Intuition = hypothesis, not proof.**
```

### Norm change

Norm change must read as methodologically central, not as relativistic background commentary.

Mark these concepts visibly where they occur:

```markdown
**dynamic norms**
**cultural variation**
**historical shift**
**field-specific practices**
```

If YAML-style terms appear, use code formatting:

```markdown
`dynamic_norms`
`cultural_variation`
`historical_shift`
`field_specific_practices`
```

Do not imply that norm change invalidates the model.

Do not imply that the model has no normative commitments.

### D-reading question

The normative position of a D-reading must remain explicit.

Preferred boundary block:

```markdown
> **D-reading question:**  
> From which **normative position** is `D₁/D₂` being read?
```

Do not allow D-readings to appear as universal dignity diagnoses.

### Cultural-lens rule

If the block contains the cultural-lens sentence, preserve it and make it visible.

Preferred formatting:

```markdown
> **Cultural-lens rule:**  
> “I do not know what it feels like to be you in your culture —  
> I describe only what I see in the enactment  
> and name my own lens.”
```

Do not alter the protective meaning of the sentence.

### Norm change as subject matter

If the text says that norm change is not an obstacle but subject matter, mark it as a formula.

Preferred block:

```markdown
> **Norm change is not an obstacle; it is subject matter.**
```

Where the block lists norm-change questions, stabilize the model codes:

```markdown
`A` — Was available knowledge used?  
`A-P`, `D-R`, `D-P` — Were affected persons heard?  
`P`, `M-score` — Were unused decision paths available?  
`ceiling rule` — Did people have real alternatives?  
`D₁/D₂` — From which normative position is dignity read?
```

### Protocol and meta-attitude

Section 9.4 should read as required method protocol, not as a soft reflective ending.

Preferred heading:

```markdown
### 9.4 Working with the model: **protocol and meta-attitude**
```

Preferred component headings:

```markdown
#### Required component 1 — **Documentation**
#### Required component 2 — **Meta-attitude**
```

If a Meta Notes section appears, stabilize it as a tool label:

```markdown
#### **Meta Notes block**
```

The Meta Notes block should preserve these fields where present:

```text
bias risks
norm assumptions
intuition checked yes/no
dignity reading
possible alternative interpretations
```

### Applying the model is itself a practice

If the block states that applying the model is itself a practice, mark it visibly.

Preferred block:

```markdown
> **Applying the model is itself a practice — not a neutral observer stance.**
```

This should align with the self-implication logic from Block 03.

### Meta-guardrail

The meta-attitude should read like a guardrail.

Preferred boundary block:

```markdown
> **Meta-guardrail:**  
> Without meta-attitude, dignity language falls back into moral labeling.
```

Keep the following commitments visible where present:

```markdown
**no claim to final truth**
**willingness to revise analyses**
**active search for counterexamples**
**alternative perspectives**
**explicit invitation to critique**
**dignity readings are not true worth**
```

### Specific search / replace for Block 09

Use only for actual local occurrences.

#### SEARCH

```text
consistent bias/intution/norm-change labels
```

#### REPLACE

```text
consistent bias/intuition/norm-change labels
```

Do not repeat global notation cleanup here.

---

## Block 10 — Countercritique and Response

Target file:

```text
01_blocks/10_countercritique_response.md
```

### Editorial aim

Block 10 is the external critique-readiness layer of the corpus.

The main risk is that readers may misread it as:

```text
defence brief
apologetics
model immunisation
rhetorical protection
dismissal of objections
```

The editorial task is to make visible that Block 10 is:

```text
a stress test
a self-application exercise
a critique-readiness layer
a limit-identification layer
a guardrail response layer
```

Do not add new objections.

Do not add new responses.

Do not expand the theory.

Do not soften critique.

Do not strengthen validation claims.

Do not turn countercritique into apology.

### Terms to mark consistently

Mark these terms as technical or structural terms at first or central occurrence:

```text
countercritique
response
stress test
model limits
morality machine
structured estimation
band, not digital value
dignity never scored
norm visibility
objectivity
psychologising
individualisation
power blindness
self-application
critique readiness
limits
remaining limit
```

Preferred markup:

```markdown
**countercritique**
**stress test**
**model limits**
**structured estimation**
**norm visibility**
**critique readiness**
```

Use code formatting for:

```markdown
`IA`
`T–J–TB–R`
`A-score`
`M-score`
`D₀`
`D₁/D₂`
`D-profile`
`RVR(t)`
```

### Stress-test frame

Block 10 should be visibly framed as a stress test.

Preferred boundary block:

```markdown
> **Stress-test frame:**  
> What happens when we examine the model using its own tools — **roles**, `IA`, and **dignity**?
```

Do not allow the block to read as defensive closure.

### Critique / Response / Summary structure

The internal structure should be consistent across objections.

Preferred format:

```markdown
#### Critique

#### Response

#### Summary
```

Alternative if the block uses inline labels:

```markdown
**Critique**

**Response**

**Summary**
```

Use one style consistently throughout Block 10.

### Not a morality machine

Where the “new morality machine” objection is answered, make the boundary explicit.

Preferred block:

```markdown
> **Not a morality machine:**  
> MIP does not set the moral agenda.  
> It makes normativity **visible** and checks enactments through `T–J–TB–R`.
```

Keep this phrase visible where it appears:

```markdown
**within its chosen norms and roles**
```

Optional formula if supported by the local wording:

```markdown
> **Norm visibility, not norm invisibility.**
```

Do not imply that MIP is norm-free.

Do not imply that MIP determines the correct political, religious, cultural, or moral position.

### Dignity-in-practice defence

Where Block 10 defends the D-module, keep the D-level distinction visually clean.

Preferred formatting:

```markdown
- **`D₀` — ontological dignity:** non-negotiable.
- **`D₁/D₂` — dignity in practice:** property of enactment.
```

Preferred boundary block:

```markdown
> **D-observations may not become person-level judgments.**
```

Do not allow D-observations to become person labels.

Do not conflate `D₀` with `D₁/D₂`.

### Score boundary

Where the “Can maturity even be measured?” objection is answered, make the score boundary prominent.

Preferred block:

```markdown
> **Score boundary:**  
> `A-score` = **band**, not digital value.  
> `D₁/D₂` = **profile**, not score.  
> Judgements become **auditable**, not final.
```

Keep demystifying examples such as:

```text
not “3.27”
```

if they already exist.

Do not introduce decimal precision.

Do not imply exact measurement.

Do not imply external validation.

### Maturity and dignity measurement formula

If the text contains the temperature comparison, preserve it as a central formula.

Preferred formatting:

```markdown
> We cannot measure maturity or dignity like temperature —  
> but we can make maturity and dignity judgments **less arbitrary**.
```

### Dignity measurement clarity

Where dignity is discussed alongside maturity, make this distinction visible:

```markdown
**ontological dignity (`D₀`) is never measured.**  
**dignity in practice (`D₁/D₂`) is described qualitatively.**
```

Do not let dignity appear as a score.

### Admitted-risk pattern

Where the text acknowledges misuse risk, make the admitted-risk structure visible.

Preferred block:

```markdown
> **Yes, misuse is possible.**  
> The model’s task is not to deny that risk, but to make it visible and guardrail-bound.
```

Use only if it matches the local content.

Do not add artificial concessions.

Do not turn the response into “yes, but” defensiveness.

### Remaining limits

If the block acknowledges limits, mark them consistently.

Preferred label:

```markdown
**Remaining limit:** ...
```

or:

```markdown
**Limit retained:** ...
```

Use only where a limit is already present or clearly implied.

Do not invent new limits.

### Countercritique vs. AH Precision

Keep the relationship between Block 10 and AH Precision clear.

Preferred distinction:

```text
Countercritique = critique of the model / model assumptions.
AH Precision = precision check of an analysis artefact.
```

Do not mix these layers.

Do not present AH as a first-order model extension.

Do not imply AH changes A/M/IA/D findings.

### RVR(t) accessibility check

If `RVR(t)` appears in Block 10, check whether it is accessible elsewhere.

To check:

```text
Appendix A:
    Is RVR(t) defined in the glossary?

Block 02 or Block 05:
    Is RVR(t) introduced or explained?

If not:
    add a glossary link or short notation clarification.
```

Do not add new theory around `RVR(t)`.

Do not leave unexplained notation in a critique-response block.

### Chapter / Block wording

If the block refers to “Chapter 10” in running prose, it may remain if preserving book-origin language is desired.

Rule:

```text
Main block prose may keep “Chapter”.
README, reference files, minified files, and reader navigation should use “Block”.
```

Do not globally replace “Chapter” with “Block”.

### Specific search / replace for Block 10

Use only for actual local occurrences not already covered by global notation cleanup.

#### SEARCH

```text
IA-Box
```

#### REPLACE

```text
IA-box
```

#### SEARCH

```text
A-Score
```

#### REPLACE

```text
A-score
```

#### SEARCH

```text
M-Score
```

#### REPLACE

```text
M-score
```

If these are already covered by global cleanup, do not duplicate the operation.

---

## Follow-up checks after Blocks 09–10

After editing Blocks 09–10, check:

```text
Block 03:
    Self-implication wording must remain aligned with Block 09:
        applying the model is itself a practice
        no analysis from nowhere
        analysts become actors themselves

Block 06:
    Hindsight bias must not inflate M-score logic.
    Ceiling rule must remain unchanged.

Block 08:
    Context-sensitive D-reading must align with norm-change logic.

AH Precision addon:
    Keep the layer distinction:
        Block 10 = model-level countercritique
        AH = analysis-artefact attack surface / hardening

Appendix A:
    Check glossary entries for:
        bias
        intuition
        norm change
        meta-attitude
        dignity bonus
        dignity penalty
        RVR(t)

Model specification:
    Align wording on:
        bias module
        intuition
        norm_change
        discipline profiles
        AH relation, if mentioned
```

Priority:

```text
1. Block 09 — mark Bias / Intuition / Norm Change as method, not appendix.
2. Block 10 — mark Countercritique as stress test, not defence.
3. Appendix A — check accessibility of RVR(t), dignity bonus/penalty, and meta-attitude.
4. Model specification — align wording on bias_module, intuition, norm_change, and AH relation.
```

## Final consistency rule for Blocks 09–10

After editing, Blocks 09–10 should preserve the following boundary:

```text
Bias is baseline noise, not exceptional failure.
Bias-awareness is part of awareness.
Intuition is sensor and trigger, not judge.
Intuition is hypothesis, not proof.
Norm change is subject matter, not obstacle.
D-readings must name their normative position.
Applying the model is itself a practice.
Meta-attitude is a guardrail.
Countercritique is a stress test, not apologetics.
MIP is not a morality machine.
Scores are structured estimations, not exact measurements.
D₀ is never measured.
D₁/D₂ are qualitative practice descriptions, not scores.
AH Precision checks analysis artefacts, not model assumptions or persons.
Guardrails remain active in every application.
```

---

## Block 11 — Visual Quick Access

Target file:

```text
01_blocks/11_visual_quick_access.md
```

### Editorial aim

Block 11 is the compressed quick-access layer of the corpus.

The main risk is that readers may misread quick-access tools as:

```text
shortcuts around guardrails
fast scoring instruments
summary verdicts
dignity labels
substitutes for full analysis
```

The editorial task is to make visible that Block 11 provides:

```text
orientation aids
emergency brakes
short audits
pre-transmission checks
movement tools
not full analysis
not verdicts
not person labels
```

Do not add new tools.

Do not add new checklist items.

Do not change D levels.

Do not change application rules.

Do not turn quick access into full analysis.

Do not turn quick access into a shortcut around guardrails.

### Terms to mark consistently

Mark these terms as technical quick-access or gate terms at first or central occurrence:

```text
Visual quick access
1-pager
emergency brake
short audit
red zone
scope & guardrails
roles & publicness
A-P
P-PU
D-P
A-score band
M-score
ceiling rule
IA-box
T–J–TB–R
conflict loop
D-Quick-Grid
movement tool
not a label
role / context / time window
pre-transmission gate
```

Preferred markup:

```markdown
**Visual quick access**
**1-pager**
**emergency brake**
**short audit**
`A-P`
`P-PU`
`D-P`
`IA-box`
`T–J–TB–R`
`D-Quick-Grid`
```

### Quick-access boundary

The 1-pager must read as an orientation aid, not as a replacement for the model.

Preferred boundary block:

```markdown
> **Quick-access boundary:**  
> The 1-pager is an **emergency brake** and **orientation aid**.  
> It does not replace the full model, the guardrails, or contextual judgement.
```

Do not let the 1-pager appear to be:

```text
full analysis
final assessment
fast verdict
guardrail bypass
```

### Audit checklist as pre-transmission gate

The audit checklist should read as a gate before external use or decision relevance.

Preferred heading:

```markdown
### 11.1 **Audit checklist** — pre-transmission gate
```

Preferred goal block:

```markdown
> **Goal:**  
> Check whether an `IA` analysis is basically robust  
> **before** it goes outward or becomes a basis for decisions.
```

Keep the pre-transmission function visible.

Do not allow the checklist to appear as a verdict mechanism.

### Scope and guardrails

The scope-and-guardrails check is the most important quick-access gate.

Preferred stop rule:

```markdown
> **Stop rule:**  
> If there is doubt here: **stop the analysis or adjust its purpose.**
```

Mark these terms visibly where they occur:

```markdown
**red zone**
**no dignity-labelling of persons**
**minimal maturity in practice**
**D only describes enactments**
**D-profile, not person-worth**
```

Use code formatting for:

```markdown
`D₀`
`D₁/D₂`
`D-profile`
```

Do not allow quick access to weaken red-zone discipline.

### Roles and publicness

Roles and publicness must read as a mandatory pre-check.

Preferred label:

```markdown
**Roles & publicness** — mandatory pre-check
```

Use code formatting for publicness-related submodules:

```markdown
`A-P`
`P-PU`
`D-P`
```

If the following warning appears, make it visible:

```markdown
> **Unclear roles = high risk of phantom intention and misinterpretation.**
```

Do not let role/publicness checks appear optional.

### Structure and score hygiene

Where quick access summarizes A/M scoring, keep score hygiene visible.

Preferred marking:

```markdown
**A-score (band)** — not character diagnosis  
**M-score (co-responsibility)** — not guilt  
**ceiling rule**  
**IA-box (`T–J–TB–R`)**
```

Do not allow Block 11 to suggest:

```text
A-score = person maturity
M-score = guilt
D-profile = dignity score
IA-box = verdict
```

### Conflict loop

The conflict loop must read as orientation, not as conflict resolution.

Preferred heading:

```markdown
### 11.2 **Conflict loop** — four-step orientation, not conflict resolution
```

Mark these terms where they occur:

```markdown
**loop**
**role**
**frame**
**small reversible step**
**repair**
**review**
```

If `STOP–FRAME–ROLE–STEP` or related short tools appear, use code formatting:

```markdown
`STOP–FRAME–ROLE–STEP`
```

Do not imply that the conflict loop guarantees resolution.

### D-Quick-Grid boundary

The D-Quick-Grid is especially label-risk sensitive.

Preferred boundary block:

```markdown
> **D-Quick-Grid boundary:**  
> The `D-Quick-Grid` is a **movement tool**, not a label.  
> It shows where dignity in practice stands and what can be minimally improved —  
> never “what a person is”.
```

The D-Quick-Grid must preserve these conditions:

```text
it does not replace a D-profile card
it serves quick orientation
every level must be recorded with role, context, and time window
```

Do not allow D-Quick-Grid levels to become person categories.

Do not allow D-Quick-Grid levels to become dignity scores.

### D-Quick-Grid level language

Levels must read as states of a constellation, not essences of persons.

Preferred protective formula:

```markdown
**state, not essence**
```

Avoid:

```text
This person is level 2.
```

Preferred wording pattern:

```text
This constellation currently shows level-2 D stress in this role/context/time window.
```

### Level 3 / extreme zone

Level 3 requires alarm language, not fine diagnosis.

Preferred formatting:

```markdown
##### **Level 3 — hard D breaks / extreme zone**
**Alarm zone — no fine-tuning.**
```

Keep this distinction visible:

```markdown
**documentation of injustice**, not coaching material
```

Preferred D₀/D₁/D₂ protection formula:

```markdown
> Damages cannot be undone, but `D₀` is never abandoned.  
> The analysis asks which structural / role changes can make `D₁/D₂` possible again.
```

Do not imply that consequences can simply be erased.

Do not use Level 3 as a person label.

### D-Quick-Grid notation

Avoid score-like D notation.

Preferred wording:

```text
D-Quick-Grid level 1–2
```

Avoid:

```text
D ≈ 1–2
```

### Specific search / replace for Block 11

Use only for actual local occurrences not already handled by global cleanup.

#### SEARCH

```text
D ≈ 1–2
```

#### REPLACE

```text
D-Quick-Grid level 1–2
```

#### SEARCH

```text
D ≈
```

#### REPLACE

```text
D-Quick-Grid level
```

Use the second replacement only with manual review, because it is broader.

Do not repeat global notation cleanup here. Global cleanup already covers `IA box`, `D quick grid`, `D profile`, `A score`, and `M score`.

---

## Block 12 — Concluding Word

Target file:

```text
01_blocks/12_conclusion.md
```

### Editorial aim

Block 12 is the closing self-limitation and commitment layer of the corpus.

The main risk is that readers may misread the conclusion as:

```text
poetic ending
soft final reflection
rhetorical humility
general closing language
```

The editorial task is to make visible that Block 12 contains:

```text
working-version discipline
revision obligation
self-implication
user commitments
toolbox boundary
ethics rider
final model boundary
```

Do not expand the conclusion.

Do not change the final claim.

Do not soften the revision obligation.

Do not turn the conclusion into doctrine.

### Terms to mark consistently

Mark these terms as technical closing or commitment terms at first or central occurrence:

```text
working version
prove itself under conditions
revision
counterexamples
other perspectives
structural critique
shift of focus
pillory
self-implication
toolbox with an ethics rider
two commitments of users
maturity in practice matters more than being right
dignity in practice matters more than winning
permanent task
```

Preferred markup:

```markdown
**working version**
**revision**
**self-implication**
**toolbox with an ethics rider**
**permanent task**
```

Use code formatting for:

```markdown
`IA`
`D₀`
`D₁/D₂`
```

### Working-version rule

The working-version statement must read as a consequence of the model, not as weakness.

Preferred boundary block:

```markdown
> **Working-version rule:**  
> The model is a **working version** because maturity in practice must itself prove itself **under conditions**.
```

Do not make “working version” sound like unfinishedness in a weak sense.

Do not turn it into a claim of finality.

### Revision obligation

Revision must read as an obligation, not optional openness.

Preferred formatting:

```markdown
**Revision sources:**

- **counterexamples**
- **other perspectives**
- **structural critique**
```

Optional formula if supported by the local wording:

```markdown
> **Revision is not optional.**
```

Do not add new revision mechanisms.

Do not weaken counterexample sensitivity.

### Three effects / success criteria

Where the conclusion lists the effects if the model succeeds, make them readable as success criteria.

Preferred structure:

```markdown
### Three effects if the model succeeds

1. **Shift of focus**
2. **Making IA visible without pillory**
3. **Self-implication**
```

Keep this phrase visible where it occurs:

```markdown
**without automatically producing a pillory**
```

Do not let IA visibility become public shaming.

### Toolbox with an ethics rider

This is a central closing formula.

Preferred boundary block:

```markdown
> **MIP is not a doctrine.  
> It is a toolbox with an ethics rider.**
```

Do not allow the model to read as:

```text
doctrine
moral machine
diagnostic system
neutral toy without responsibility
```

### Final value formula

The condition sentence should be made visible as a final formula.

Preferred formatting:

```markdown
> **Maturity in practice matters more than being right —  
> and dignity in practice more than winning.**
```

Do not weaken this sentence.

Do not turn it into motivational language detached from the model’s guardrails.

### User commitments

The two commitments of users should read as a commitment clause.

Preferred heading:

```markdown
### User commitments
```

Preferred formulation:

```markdown
Those who use the model commit to:

1. **self-implication**
2. **revision under counter-evidence**
```

Keep the final self-application sentence visible:

```markdown
> Anything less would be `IA` in dealing with the model itself.
```

Do not let user commitments appear optional.

### Final D-language

In the closing paragraph, stabilize dignity notation.

Use code formatting for:

```markdown
`D₀`
`D₁/D₂`
```

Mark the final task language:

```markdown
**permanent task**
```

Preferred final formula if the wording exists or is close:

```markdown
> Maturity in practice remains a **permanent task** —  
> for persons, structures, and also for this model itself.
```

Do not imply that the model escapes its own criteria.

### Specific search / replace for Block 12

No block-specific search / replace is required unless local text contains inconsistent D notation or outdated terminology.

Do not repeat global notation cleanup here.

---

## Follow-up checks after Blocks 11–12

After editing Blocks 11–12, check:

```text
Appendix B:
    Templates must not turn D-Quick-Grid into D-score.
    Practice templates must preserve role / context / time window.
    Score sheets must remain structuring aids, not rankings.

Block 07:
    Tool-boundary wording must align with Block 11:
        tools structure
        tools do not decide
        final checklist gates transmission

Block 09:
    Revision and counterexample language must align with meta-attitude.

Block 10:
    Stress-test / countercritique language must align with self-application in Block 12.

README / Minified:
    Mirror the final formulas consistently:
        MIP is not a doctrine.
        It is a toolbox with an ethics rider.
        Maturity in practice matters more than being right.
        Dignity in practice matters more than winning.
        MIP reads enactments.
        MIP does not rank persons.
        D₀ remains inviolable.
```

Priority:

```text
1. Block 11 — Quick-access boundary and D-Quick-Grid anti-label protection.
2. Block 12 — user commitments and revision obligation.
3. Appendix B — ensure templates do not turn D-Quick-Grid into D-score.
4. README / Minified — mirror final formulas consistently.
```

## Final consistency rule for Blocks 11–12

After editing, Blocks 11–12 should preserve the following boundary:

```text
Quick access is orientation, not full analysis.
The 1-pager is an emergency brake and short audit, not a verdict.
Audit checklist failure blocks transmission.
Roles and publicness must be checked before outward use.
A-score remains a band, not a person score.
M-score remains co-responsibility, not guilt.
D-Quick-Grid is a movement tool, not a label.
Every D level requires role, context, and time window.
Level 3 is alarm zone, not fine diagnostics.
The model is a working version by method, not by weakness.
Revision is part of the model’s own claim.
Users commit to self-implication and revision.
MIP is not a doctrine.
MIP is a toolbox with an ethics rider.
Maturity in practice matters more than being right.
Dignity in practice matters more than winning.
D₀ remains inviolable.
D₁/D₂ remain dignity-in-practice descriptions.
```
