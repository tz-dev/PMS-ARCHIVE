---
document_id: MIP-REF-CROSS-REFERENCE-MAP
title: "Cross Reference Map"
source_role: "derived reference map"
target_file: "03_reference/Cross_Reference_Map.md"
status: "derived-reference"
version: "v1"
reference_role: "navigation and corpus cross-reference"
canonical_basis:
  - "01_blocks"
  - "02_appendices"
model_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
  - "05_model/MIP - Maturity in Practice - AHP Module.yaml"
claim_mode: "navigational, derived, non-expansive"
mip_status: "supporting reference file; not a replacement for canonical blocks or appendices"
generation_rule: "derive links from existing block and appendix headers; do not add new theory"
---

# Cross Reference Map

This file maps the canonical MIP corpus across blocks, appendices, reference roles and the model layer. It is a navigational reference only: in case of conflict, the canonical block or appendix text takes precedence.

## 1. Canonical corpus rule

```text
canonical core:
    01_blocks/01–12

canonical appendices:
    02_appendices/Appendix_A–E

supporting layers:
    03_reference
    04_minified
    05_model
    06_MIP Reader
```

Boundary formula:

```text
MIP reads enactments.
MIP does not rank persons.
D₀ remains inviolable.
D₁/D₂ describe dignity-in-practice.
D-profile is qualitative, not a score.
A/M are contextual bands under conditions.
M-score is shared structural responsibility, not guilt.
IA-box is an asymmetry check, not a verdict.
Tools structure perception; they do not decide cases.
Guardrails govern every application.
```

## 2. Core blocks

| Block | File | Title | Primary role | Direct appendix links |
|---:|---|---|---|---|
| 01 | `01_blocks/01_position_claim.md` | Position and Claim | praxeological, structural, dignity-protective, non-diagnostic | — |
| 02 | `01_blocks/02_base_model_acrpd.md` | Base Model A–C–R–P–D | praxeological, structural, parameter-based, dignity-protective | — |
| 03 | `01_blocks/03_guardrails_use.md` | Framework of Use and Guardrails | praxeological, structural, guardrail-bound, dignity-protective, non-diagnostic | — |
| 04 | `01_blocks/04_functional_vs_inadult.md` | Functional vs. Inadult Asymmetry | praxeological, structural, asymmetry-focused, role-sensitive, dignity-protective | — |
| 05 | `01_blocks/05_measuring_maturity.md` | Measuring Maturity in Practice | praxeological, situational, score-banded, non-moralising, dignity-protective | — |
| 06 | `01_blocks/06_m_score_fairness.md` | M-Score, Ceiling Rule and Fairness | praxeological, responsibility-distributive, ceiling-rule-bound, victim-blaming-protective | — |
| 07 | `01_blocks/07_tools_case_lens.md` | Guiding Formulas and Tools | praxeological, procedural, tool-based, trajectory-oriented, dignity-protective | Appendix B |
| 08 | `01_blocks/08_domain_modules.md` | Domain Modules | praxeological, domain-adaptive, lens-based, non-expansive, dignity-protective | Appendix D |
| 09 | `01_blocks/09_bias_intuition_norm_change.md` | Bias, Intuition and Norm Change | praxeological, bias-aware, intuition-bounded, norm-sensitive, dignity-protective | — |
| 10 | `01_blocks/10_countercritique_response.md` | Countercritique and Response | praxeological, self-critical, counterargument-aware, limitation-explicit, dignity-protective | — |
| 11 | `01_blocks/11_visual_quick_access.md` | Visual Quick Access | praxeological, condensed, audit-oriented, conflict-practical, dignity-protective | Appendix B |
| 12 | `01_blocks/12_conclusion.md` | Concluding Word | praxeological, provisional, self-implicating, revision-oriented, dignity-protective | — |

## 3. Appendix map

| Appendix | File | Title | Canonical function | Core scope |
|---:|---|---|---|---|
| A | `02_appendices/Appendix_A_Glossary.md` | Glossary of Key Terms | canonical glossary | 1–12 |
| B | `02_appendices/Appendix_B_Checklists_Templates.md` | Checklists and Practice Templates | canonical practice templates | 1–12 |
| C | `02_appendices/Appendix_C_Case_Examples.md` | Case Examples | canonical case examples | 1–12 |
| D | `02_appendices/Appendix_D_Discipline_Adaptation.md` | Modular Adaptation to Disciplines and Fields | canonical discipline adaptation map | 1–12 |
| E | `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` | Axiomatic Core and Formal Notation | canonical axiomatic and formal notation appendix | 1–12 |

## 4. Reading sequence map

| Step | Primary file | Use |
|---|---|---|
| Orientation | `01_blocks/01_position_claim.md` | Position, claim, reading levels, toolbox status. |
| Base model | `01_blocks/02_base_model_acrpd.md` | A–C–R–P–D, dynamics, parameters, D distinction. |
| Use boundary | `01_blocks/03_guardrails_use.md` | Mandatory guardrails, zones, D protection, misuse boundaries. |
| Asymmetry test | `01_blocks/04_functional_vs_inadult.md` | Functional vs. inadult asymmetry; IA-box; role/context logic. |
| Maturity estimate | `01_blocks/05_measuring_maturity.md` | A-score as situated band; trajectories instead of labels. |
| Responsibility estimate | `01_blocks/06_m_score_fairness.md` | M-score, ceiling rule, fair responsibility distribution. |
| Operational tools | `01_blocks/07_tools_case_lens.md` | Case Lens, score sheets, D-profile, trajectories, final checklist. |
| Domain lenses | `01_blocks/08_domain_modules.md` | Domain lenses and hotspot maps; not new models and not expert substitutes. |
| Meta-calibration | `01_blocks/09_bias_intuition_norm_change.md` | Bias, intuition, norm change, situated dignity readings. |
| Stress test | `01_blocks/10_countercritique_response.md` | Countercritique, limits, misuse and D-module objections. |
| Quick access | `01_blocks/11_visual_quick_access.md` | 1-page audit, conflict loop, D quick grid. |
| Closure | `01_blocks/12_conclusion.md` | Working-version status, ethics rider, revision commitment. |

## 5. Concept-to-source index

| Concept / task | Primary sources |
|---|---|
| Position, claim, scope | `01_blocks/01_position_claim.md`, `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| A–C–R–P–D base model | `01_blocks/02_base_model_acrpd.md`, `02_appendices/Appendix_A_Glossary.md`, `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| D₀ / D₁ / D₂ distinction | `01_blocks/02_base_model_acrpd.md`, `01_blocks/03_guardrails_use.md`, `02_appendices/Appendix_A_Glossary.md`, `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| Guardrails and red zones | `01_blocks/03_guardrails_use.md`, `01_blocks/10_countercritique_response.md`, `02_appendices/Appendix_B_Checklists_Templates.md` |
| Functional vs. inadult asymmetry | `01_blocks/04_functional_vs_inadult.md`, `02_appendices/Appendix_A_Glossary.md`, `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| IA-box T–J–TB–R | `01_blocks/04_functional_vs_inadult.md`, `01_blocks/07_tools_case_lens.md`, `02_appendices/Appendix_B_Checklists_Templates.md`, `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| Role and context logic | `01_blocks/04_functional_vs_inadult.md`, `01_blocks/07_tools_case_lens.md`, `02_appendices/Appendix_B_Checklists_Templates.md` |
| A-score | `01_blocks/05_measuring_maturity.md`, `01_blocks/07_tools_case_lens.md`, `02_appendices/Appendix_B_Checklists_Templates.md`, `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| M-score and ceiling rule | `01_blocks/06_m_score_fairness.md`, `01_blocks/07_tools_case_lens.md`, `02_appendices/Appendix_B_Checklists_Templates.md` |
| A/M/D separation | `01_blocks/06_m_score_fairness.md`, `01_blocks/07_tools_case_lens.md`, `01_blocks/10_countercritique_response.md` |
| Case Lens and practice tools | `01_blocks/07_tools_case_lens.md`, `02_appendices/Appendix_B_Checklists_Templates.md` |
| D-profile and D-Quick-Grid | `01_blocks/07_tools_case_lens.md`, `01_blocks/11_visual_quick_access.md`, `02_appendices/Appendix_B_Checklists_Templates.md` |
| Domain modules | `01_blocks/08_domain_modules.md`, `02_appendices/Appendix_D_Discipline_Adaptation.md` |
| Bias, intuition, norm change | `01_blocks/09_bias_intuition_norm_change.md` |
| Countercritique and model limits | `01_blocks/10_countercritique_response.md` |
| Visual one-pager / audit | `01_blocks/11_visual_quick_access.md`, `02_appendices/Appendix_B_Checklists_Templates.md` |
| Glossary | `02_appendices/Appendix_A_Glossary.md` |
| Case examples | `02_appendices/Appendix_C_Case_Examples.md` |
| Formal notation and axioms | `02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md` |
| Machine-readable model layer | `05_model/MIP - Maturity in Practice.yaml`, `05_model/MIP - Maturity in Practice - AHP Module.yaml` |

## 6. Appendix functions

| Appendix | Function | Use when… |
|---:|---|---|
| A | Glossary of core terms. | definitions of A–C–R–P–D, D₀/D₁/D₂, IA, scores, guardrails or trajectories are needed. |
| B | Checklists and practice templates. | a case, workshop, audit, score sheet, trajectory note, D-profile note, Meta Notes or transmission check must be documented. |
| C | Case examples. | the model needs to be shown in applied, illustrative use without becoming a full analysis manual. |
| D | Discipline and field adaptation map. | the same core model must be profiled through field lenses / hotspot maps without replacing domain expertise. |
| E | Axiomatic core and formal notation. | axioms, notational hygiene, action tuple, `M(X)` notation, score notation or formal red-zone boundaries are needed. |

## 7. Model-layer relation

`05_model` is the machine-readable operational layer. It does not replace the canonical corpus.

| File / directory | Role | Relation to corpus |
|---|---|---|
| `05_model/MIP - Maturity in Practice.yaml` | Canonical YAML schema for model reference, case structure and agent interface. | Operationalises the `A–C–R–P–D` / IA-box / A-score / M-score / D-profile logic for structured case work under guardrails. |
| `05_model/MIP - Maturity in Practice - AHP Module.yaml` | Optional AHP module. | Second-order analysis-quality overlay for Precision Heuristic, Attack Points and Hardening Backlog; does not rescore A/M/IA/D and does not activate D. |
| `05_model/examples/*.yaml` | YAML runtime examples. | Model-layer examples, not replacements for Appendix C case examples. |
| `05_model/model specification/Maturity in Practice - Model Specification.md` | Human-readable technical specification of the base YAML. | Explains the canonical model layer without replacing the YAML or canonical corpus. |
| `05_model/model specification/Maturity in Practice - AH Addon Specification.md` | Human-readable technical specification of the optional AHP module. | Explains the AHP overlay as second-order analysis hardening, not first-order MIP analysis. |

AHP boundary:

```text
AHP checks the analysis artifact.
AHP does not rescore A/M/IA/D.
AHP does not activate the D-module.
AHP does not change transmission status.
Attack Points describe analysis vulnerabilities, not person findings.
```

## 8. Derivation rule for future reference files

| Future file | Should derive primarily from | Must not do |
|---|---|---|
| `03_reference/Audit_Checklist.md` | Blocks 03, 07, 11; Appendix B. | Must not create new application powers beyond guardrails; must keep D-profile qualitative and IA-box non-verdict. |
| `03_reference/Claim_Type_Table.md` | Blocks 01, 03, 09, 10; Appendix E. | Must not intensify claims beyond canonical wording; must keep `M(X)`, D-profile and IA-box boundaries intact. |
| `03_reference/Misuse_Red_Zone_Map.md` | Blocks 03 and 10; Appendix B; Appendix E. | Must not soften red zones. |
| `03_reference/Reader_Pathways.md` | Blocks 01, 02, 07, 08, 11; Appendices A and B. | Must not imply a single mandatory reading path. |
| `04_minified/*` | Canonical blocks and appendices after reference layer is stable. | Must not compress away D₀, guardrails, red zones or enactment/person separation. |

## 9. Non-replacement clause

This map is derived. It may support navigation, citation and corpus maintenance. It may not override:

- any canonical block in `01_blocks/`;
- any canonical appendix in `02_appendices/`;
- the canonical model YAML in `05_model/MIP - Maturity in Practice.yaml`;
- the dignity-protection rule that D₀ remains inviolable;
- the separation between enactment analysis and person judgement;
- the red-zone restrictions of the model;
- the rule that AHP is optional, second-order and non-rescoring.
