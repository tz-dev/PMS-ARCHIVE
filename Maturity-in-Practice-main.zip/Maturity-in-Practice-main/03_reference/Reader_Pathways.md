---
document_id: MIP-REF-READER-PATHWAYS
title: "Reader Pathways"
source_basis:
  - "01_blocks/01_position_claim.md"
  - "01_blocks/02_base_model_acrpd.md"
  - "01_blocks/03_guardrails_use.md"
  - "01_blocks/07_tools_case_lens.md"
  - "01_blocks/08_domain_modules.md"
  - "01_blocks/11_visual_quick_access.md"
  - "02_appendices/Appendix_A_Glossary.md"
  - "02_appendices/Appendix_B_Checklists_Templates.md"
  - "02_appendices/Appendix_C_Case_Examples.md"
  - "02_appendices/Appendix_D_Discipline_Adaptation.md"
  - "02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md"
  - "05_model/MIP - Maturity in Practice.yaml"
  - "05_model/MIP - Maturity in Practice - AHP Module.yaml"
source_role: "derived reader navigation"
target_file: "03_reference/Reader_Pathways.md"
status: "derived-reference"
version: "v1"
reference_id: "reader-pathways"
reference_role: "navigation guide for different reader purposes"
claim_mode: "navigational, corpus-oriented, guardrail-bound, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-profile qualitative; D-module default-off; no dignity score"
mip_status: "derived from canonical core, appendices and model layer; no content expansion"
---

# Reader Pathways

This file provides recommended reading paths through the **Maturity in Practice (MIP)** corpus.

It does not replace the canonical text.  
It helps different readers enter the corpus without losing the model’s boundaries.

Core orientation:

> **MIP reads enactments, roles, structures, asymmetries, trajectories, responsibility, power and dignity-in-practice.  
> It does not diagnose persons, rank persons or measure ontological dignity.  
> D-profile is qualitative, not a dignity score.  
> IA-box is an asymmetry check, not a verdict.**

---

## 1. Full canonical reading order

For readers who want the complete theory in order:

```text
01_blocks/01_position_claim.md
01_blocks/02_base_model_acrpd.md
01_blocks/03_guardrails_use.md
01_blocks/04_functional_vs_inadult.md
01_blocks/05_measuring_maturity.md
01_blocks/06_m_score_fairness.md
01_blocks/07_tools_case_lens.md
01_blocks/08_domain_modules.md
01_blocks/09_bias_intuition_norm_change.md
01_blocks/10_countercritique_response.md
01_blocks/11_visual_quick_access.md
01_blocks/12_conclusion.md

02_appendices/Appendix_A_Glossary.md
02_appendices/Appendix_B_Checklists_Templates.md
02_appendices/Appendix_C_Case_Examples.md
02_appendices/Appendix_D_Discipline_Adaptation.md
02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md
```

Recommended for:

* first full study
* citation work
* teaching preparation
* model critique
* derivative publication work

---

## 2. Minimal first-orientation path

For readers who want to understand the model quickly:

```text
01_blocks/01_position_claim.md
01_blocks/02_base_model_acrpd.md
01_blocks/03_guardrails_use.md
01_blocks/11_visual_quick_access.md
02_appendices/Appendix_A_Glossary.md
```

Purpose:

* understand what MIP is about
* learn A–C–R–P–D
* understand guardrails
* get the one-page quick access
* clarify key terms

Reader outcome:

```text
You should understand:
- MIP reads enactments, not persons.
- D₀ remains inviolable.
- A/M are contextual bands, not person scores.
- M-score is shared structural responsibility, not guilt.
- D₁/D₂ describe dignity-in-practice only.
- D-profile is qualitative, not a dignity score.
- IA-box is an asymmetry check, not a verdict.
- Guardrails govern every application.
```

---

## 3. Guardrail-first path

For readers who may apply the model in sensitive settings:

```text
01_blocks/03_guardrails_use.md
01_blocks/10_countercritique_response.md
02_appendices/Appendix_B_Checklists_Templates.md
03_reference/Misuse_Red_Zone_Map.md
03_reference/Audit_Checklist.md
```

Recommended for:

* practitioners
* trainers
* moderators
* organisational users
* AI-assisted analysis users
* anyone working near vulnerable groups or public communication

Key questions:

```text
Am I allowed to use the model here?
Is this a red zone?
Am I reading enactments or persons?
Is D off unless safely activated?
Could this become diagnosis, ranking, HR use, forensic use or public shaming?
```

Outcome:

> **If the guardrails fail, the analysis is not mature MIP use.  
> It remains `working_note` / `not_mature_for_transmission`, not decision basis.**

---

## 4. Practitioner path

For readers who want to apply the model in case work, supervision, organisation or structured reflection:

```text
01_blocks/02_base_model_acrpd.md
01_blocks/03_guardrails_use.md
01_blocks/05_measuring_maturity.md
01_blocks/06_m_score_fairness.md
01_blocks/07_tools_case_lens.md
01_blocks/11_visual_quick_access.md
02_appendices/Appendix_B_Checklists_Templates.md
03_reference/Audit_Checklist.md
```

Purpose:

* understand A-score and M-score
* apply the Case Lens
* use IA-box
* check ceiling rule
* work with trajectories
* close with review and corrective steps

Practical sequence:

```text
1. Snapshot
2. Role and context clarification
3. A–C–R–P analysis
4. IA-box as asymmetry check, not verdict
5. M-score and ceiling rule
6. Optional qualitative D-profile only if safe
7. Trajectory
8. Decision: maintain / balance / change_stop
9. Review point
```

---

## 5. D-module cautious path

For readers interested in dignity-in-practice:

```text
01_blocks/02_base_model_acrpd.md
01_blocks/03_guardrails_use.md
01_blocks/06_m_score_fairness.md
01_blocks/07_tools_case_lens.md
01_blocks/09_bias_intuition_norm_change.md
01_blocks/10_countercritique_response.md
01_blocks/11_visual_quick_access.md
02_appendices/Appendix_A_Glossary.md
02_appendices/Appendix_B_Checklists_Templates.md
03_reference/Misuse_Red_Zone_Map.md
```

Important order:

> **Read guardrails before using D.**

D-module rule:

```text
Default: D-module off.
Activate D only with clear purpose, safe frame and fulfilled guardrails.
D-profile remains qualitative, not a dignity score.
D-Quick-Grid, if used, is a movement tool, not a label.
```

D may describe:

* D₁ self-dignity in practice
* D₂ relational dignity in practice
* D-I inner self-treatment
* D-B bodily/material self-care
* D-R relational dignity
* D-P public dignity-in-practice

D may not describe:

* human worth
* ontological dignity
* person essence
* dignity rank
* clinical state
* moral value of a person

Core distinction:

```text
D₀ = ontological dignity, inviolable.
D₁/D₂ = dignity-in-practice, observable only as enactment.
```

---

## 6. Case-analysis path

For readers who learn best through examples:

```text
01_blocks/07_tools_case_lens.md
02_appendices/Appendix_B_Checklists_Templates.md
02_appendices/Appendix_C_Case_Examples.md
03_reference/Audit_Checklist.md
03_reference/Claim_Type_Table.md
```

Recommended sequence:

```text
1. Read the Case Lens in chapter 7.
2. Open Appendix B templates.
3. Read one case in Appendix C.
4. Compare the case against the Audit Checklist.
5. Classify claims using the Claim Type Table.
```

Best for:

* workshops
* training
* supervision
* teaching
* first applied attempts

Guardrail:

> **Examples illustrate use.
> They do not expand the model and do not prove general laws.**

---

## 7. Domain-module path

For readers interested in specific fields:

```text
01_blocks/08_domain_modules.md
02_appendices/Appendix_D_Discipline_Adaptation.md
02_appendices/Appendix_A_Glossary.md
03_reference/Claim_Type_Table.md
03_reference/Misuse_Red_Zone_Map.md
```

Useful for:

* sociology
* political science
* law
* ethics
* psychology
* coaching
* pedagogy
* organisation and leadership
* media studies
* AI governance
* philosophy / anthropology

Reading question:

```text
Which parts of A–C–R–P–D become especially sensitive in this field?
```

Boundary:

> **Domain modules are lenses and hotspot maps, not new models and not expert substitutes.  
> They prioritise different questions without changing the axiomatic core.**

---

## 8. Bias, critique and self-correction path

For readers concerned with misuse, subjectivity and critique:

```text
01_blocks/09_bias_intuition_norm_change.md
01_blocks/10_countercritique_response.md
01_blocks/12_conclusion.md
02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md
03_reference/Claim_Type_Table.md
03_reference/Audit_Checklist.md
```

Key questions:

```text
Where is my own role active?
Which norms do I bring in?
Which dignity lens do I use?
Where might intuition become verdict?
Where might MIP become a morality machine?
Where does the model need correction?
```

Outcome:

> **The model is only as adult as its use.**

---

## 9. Technical / model-layer path

For readers using the YAML model, AI agent, structured case schema or optional AHP module:

```text
05_model/MIP - Maturity in Practice.yaml
05_model/MIP - Maturity in Practice - AHP Module.yaml
05_model/examples/
05_model/model specification/
03_reference/Misuse_Red_Zone_Map.md
03_reference/Audit_Checklist.md
03_reference/Claim_Type_Table.md
```

Purpose:

* load the MIP schema
* understand `model_reference`
* use `case` structure
* activate `agent_interface`
* run examples
* optionally use AHP as second-order analysis hardening

Important distinction:

```text
05_model is the machine-readable operational layer.
It is not a replacement for the canonical corpus.
```

AHP rule:

```text
AHP evaluates the analysis artifact,
not the person and not the case itself.
AHP does not rescore A/M/IA/D.
AHP does not activate the D-module.
AHP does not change transmission status.
```

Integration rule:

```text
AHP is optional and additive only.
It does not mutate core scores.
It is removable without changing the core model.
```

Recommended workflow:

```text
1. Load MIP - Maturity in Practice.yaml.
2. Run first structural pass.
3. Refine with reflection mode if needed.
4. Optionally apply AHP for analysis-artifact precision and hardening.
5. Re-run with refined scope if hardening actions require it.
6. Audit before transmission.
```

---

## 10. Public communication path

For readers analysing or writing public-facing material:

```text
01_blocks/03_guardrails_use.md
01_blocks/09_bias_intuition_norm_change.md
01_blocks/10_countercritique_response.md
01_blocks/11_visual_quick_access.md
03_reference/Misuse_Red_Zone_Map.md
03_reference/Audit_Checklist.md
03_reference/Claim_Type_Table.md
```

Use when:

* analysing public discourse
* preparing publication
* discussing moral critique
* working with social media cases
* writing public reports
* using D-P or publicness categories

Checklist:

```text
[ ] Could this become shaming?
[ ] Could this damage reputation?
[ ] Could it be quoted without context?
[ ] Is publicness named?
[ ] Is role/context/time window clear?
[ ] Is wording reversible?
[ ] Is D₀ protected?
[ ] Are A/M claims contextual?
[ ] Is IA-box treated as asymmetry check, not verdict?
[ ] Is D-profile, if used, qualitative and non-public for identifiable persons?
[ ] Is there a response or correction path?
```

Rule:

> **The more public the analysis, the stricter the guardrails.**

---

## 11. Research / formalisation path

For readers interested in axioms, notation and research use:

```text
01_blocks/01_position_claim.md
01_blocks/02_base_model_acrpd.md
01_blocks/09_bias_intuition_norm_change.md
02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md
03_reference/Claim_Type_Table.md
05_model/MIP - Maturity in Practice.yaml
```

Focus:

* axiomatic core
* formal tuple notation
* notational hygiene
* `M(X)` instead of `M(A)`
* A/M notation
* role/context logic
* model boundaries
* machine-readable schema relation

Boundary:

> **Formal notation is a documentation aid, not a full calculus.  
> It does not replace context, guardrails, judgement or qualitative interpretation.**

---

## 12. Quick-use path

For a very short practical orientation:

```text
01_blocks/11_visual_quick_access.md
02_appendices/Appendix_B_Checklists_Templates.md
03_reference/Audit_Checklist.md
```

Use when:

* time is short
* a conflict is ongoing
* a quick self-check is needed
* a team needs a one-page orientation

Minimal loop:

```text
STOP
FRAME
ROLE
IA-SPOT
STEP & REVIEW
```

Do not use this path for:

* red-zone contexts
* high-stakes public accusations
* vulnerable persons
* clinical, legal, forensic or HR decisions
* D-module analysis without guardrails

---

## 13. Teaching path

For courses, workshops or guided reading groups:

```text
1. 01_blocks/01_position_claim.md
2. 01_blocks/02_base_model_acrpd.md
3. 01_blocks/03_guardrails_use.md
4. 01_blocks/04_functional_vs_inadult.md
5. 01_blocks/05_measuring_maturity.md
6. 01_blocks/06_m_score_fairness.md
7. 01_blocks/07_tools_case_lens.md
8. 02_appendices/Appendix_B_Checklists_Templates.md
9. 02_appendices/Appendix_C_Case_Examples.md
10. 03_reference/Audit_Checklist.md
```

Suggested workshop sequence:

```text
Session 1: What MIP is and is not
Session 2: A–C–R–P–D
Session 3: Guardrails and D₀/D₁/D₂
Session 4: Functional vs. inadult asymmetry
Session 5: A-score and M-score
Session 6: Case Lens and templates
Session 7: Case examples
Session 8: Misuse audit
```

Teaching rule:

> **Teach guardrails before scores.
> Teach D₀ before D₁/D₂.
> Teach role/context before interpretation.**

---

## 14. Critic’s path

For readers who want to challenge the model:

```text
01_blocks/01_position_claim.md
01_blocks/03_guardrails_use.md
01_blocks/09_bias_intuition_norm_change.md
01_blocks/10_countercritique_response.md
01_blocks/12_conclusion.md
02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md
03_reference/Claim_Type_Table.md
```

Questions for critique:

```text
Does the model smuggle morality into structure?
Does it over-formalise qualitative phenomena?
Can D be used without shame risk?
Are the red zones strong enough?
Does A/M language still invite ranking?
Does the model protect vulnerable parties sufficiently?
Does it account for cultural norm change?
Does it sufficiently expose its own standpoint?
```

Expected stance:

> **Countercritique is part of MIP use, not an attack from outside.**

---

## 15. Pathway by reader type

| Reader type               | Recommended path               |
| ------------------------- | ------------------------------ |
| First-time reader         | Minimal first-orientation path |
| Practitioner              | Practitioner path              |
| Trainer / workshop leader | Teaching path                  |
| Sensitive-case user       | Guardrail-first path           |
| D-module user             | D-module cautious path         |
| Researcher                | Research / formalisation path  |
| Critic                    | Critic’s path                  |
| Public communicator       | Public communication path      |
| AI/model implementer      | Technical / model-layer path   |
| Quick conflict user       | Quick-use path                 |
| Domain specialist         | Domain-module path             |
| Full corpus reader        | Full canonical reading order   |

---

## 16. Pathway by task

| Task                       | Start with                   |
| -------------------------- | ---------------------------- |
| Understand the whole model | Full canonical reading order |
| Apply the model safely     | Guardrail-first path         |
| Analyse a case             | Case-analysis path           |
| Use D carefully            | D-module cautious path       |
| Build a workshop           | Teaching path                |
| Work with YAML/AI/AHP      | Technical / model-layer path |
| Create public text         | Public communication path    |
| Critique the model         | Critic’s path                |
| Learn terms                | Appendix A                   |
| Use templates              | Appendix B                   |
| Read examples              | Appendix C                   |
| Adapt to fields            | Appendix D                   |
| Formalise                  | Appendix E                   |

---

## 17. Final navigation rule

```text
If in doubt:

1. Read guardrails first.
2. Clarify role, context and time window.
3. Keep D₀ inviolable.
4. Use A/M only as justified contextual bands.
5. Treat IA-box as an asymmetry check, not a verdict.
6. Activate D only when safe and necessary.
7. Keep D-profile qualitative and separate from A/M bands.
8. Prefer trajectories over labels.
9. Audit before transmission.
10. If guardrails fail, keep the result as working_note / not_mature_for_transmission.
```

Final formula:

> **The shortest safe path through MIP is never “score first”.
> It is always: guardrail → role/context → enactment → asymmetry → responsibility → trajectory → possible correction.**
