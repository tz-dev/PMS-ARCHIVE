---
document_id: MIP-REF-CLAIM-TYPE-TABLE
title: "Claim Type Table"
source_basis:
  - "01_blocks/01_position_claim.md"
  - "01_blocks/03_guardrails_use.md"
  - "01_blocks/09_bias_intuition_norm_change.md"
  - "01_blocks/10_countercritique_response.md"
  - "02_appendices/Appendix_A_Glossary.md"
  - "02_appendices/Appendix_E_Axiomatic_Core_Formal_Notation.md"
source_role: "derived reference table"
target_file: "03_reference/Claim_Type_Table.md"
status: "derived-reference"
version: "v1"
reference_id: "claim-type-table"
reference_role: "claim classification and boundary reference"
claim_mode: "classificatory, boundary-setting, praxeological, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice claims; no person scoring"
mip_status: "derived from canonical core and appendices; no content expansion"
---

# Claim Type Table

This reference table distinguishes the main kinds of claims used in **Maturity in Practice (MIP)**.

It does not add new theory.  
It clarifies how claims in the corpus should be read, cited and bounded.

Core distinction:

> **MIP does not claim to know what a person is.  
> MIP makes bounded claims about enactments, roles, structures, asymmetries, trajectories, responsibility and dignity-in-practice.  
> D-profile claims remain qualitative; IA-box claims remain asymmetry checks, not verdicts.**

---

## 1. Claim-type overview

| Claim type | What it does | Typical form | Boundary |
|---|---|---|---|
| Praxeological claim | Describes action under conditions | “In this role/scene, the enactment shows…” | Never person essence |
| Structural claim | Describes roles, asymmetries, power or responsibility | “The asymmetry is non-transparent / weakly reversible…” | Not moral condemnation |
| A-score claim | Estimates maturity in practice as contextual band | “A ≈ 4–5 in this scene” | Not personality score |
| M-score claim | Estimates shared responsibility under conditions | “M is high because knowledge, power and alternatives were present” | Not guilt or legal culpability |
| Dignity-in-practice claim | Describes D₁/D₂ enactments | “Self-devaluation appears in this scene” | D₀ untouched; D-profile qualitative; no dignity ranking |
| Guardrail claim | Defines safe-use boundaries | “This use falls into a red zone” | Not optional if violated |
| Axiomatic claim | States non-negotiable model premises | “D₀ is inalienable” | Not empirically scored |
| Method claim | Describes how to use the model | “Use IA-box before transmission” | Procedure, not verdict |
| Meta-claim | Reflects limits, bias, norm assumptions | “This reading is situated and revisable” | No final truth claim |
| Illustrative claim | Demonstrates the model through cases | “This vignette shows an IA risk pattern” | Not evidence for general law |
| Formal notation claim | Represents model structure symbolically | “H = (X, ρ, K, A_w, C_o, R_s, P_a, D_p, IA)” | Documentation aid, not full calculus |
| AHP overlay claim | Describes analysis-artifact precision, attack points or hardening actions | “This analysis has a dignity-language risk” | Second-order only; does not rescore A/M/IA/D |

---

## 2. Praxeological claims

Praxeological claims are the core claim type of MIP.

They describe:

- what is done or omitted
- by whom
- in which role
- under which conditions
- with which awareness, coherence, responsibility and power
- with which possible dignity-in-practice effects

Valid form:

```text
In this role, in this scene, under these conditions,
the enactment shows limited coherence and responsibility uptake.
```

Invalid form:

```text
This person is immature.
```

Boundary:

> **Praxeological claims concern enactment, not essence.**

---

## 3. Structural claims

Structural claims describe configurations.

They may refer to:

* role asymmetries
* knowledge asymmetries
* power gradients
* responsibility distribution
* publicness
* institutional settings
* IA-box results
* trajectories over time

Valid form:

```text
The structure shows IA risk because transparency and reversibility are weak.
```

Invalid form:

```text
The stronger side is bad.
```

Boundary:

> **Structural claims describe arrangements and effects, not moral worth.**

---

## 4. A-score claims

A-score claims estimate maturity in practice.

They are always:

* contextual
* role-bound
* scene-bound
* time-bound
* banded as A-bands
* justified through A–C–R–P
* separate from D-profile findings

Valid form:

```text
In this decision scene, the role enactment shows A ≈ 5–6.
```

Required justification:

```text
A — awareness:
C — coherence:
R — responsibility:
P — power to act:
```

Invalid forms:

```text
X is A=4.
X is an immature person.
X has low adultness.
```

Boundary:

> **A-score claims are A-band claims about enactments, not person scores.  
> D-profile findings do not become part of the A-band.**

---

## 5. M-score claims

M-score claims estimate shared responsibility for a course of events or outcome.

They must check:

* knowledge
* power/control
* predictability
* access to alternatives
* serious integration attempt

Valid form:

```text
This role carries high M because knowledge, control,
predictability and alternatives were present.
```

Invalid forms:

```text
High M means guilt.
Low M means innocent.
The affected person should have known.
```

Boundary:

> **M-score claims are M-band claims about shared structural responsibility, not guilt, fault, blame or moral worth.**

Ceiling rule:

```text
If predictability ≈ 0 or access to alternatives ≈ 0,
M must not exceed 4/10.
```

---

## 6. Dignity-in-practice claims

Dignity-in-practice claims describe D₁/D₂ enactments.

They may describe:

* self-devaluation
* self-care
* boundary protection
* shaming
* degradation
* public exposure
* dignity-stabilising behaviour
* dignity-undermining structures

Valid form:

```text
The scene shows a D₁ pattern of self-devaluation under high pressure.
```

Valid form:

```text
The public communication produces a D-P risk through shaming exposure.
```

Invalid forms:

```text
This person has no dignity.
This is an undignified person.
This group is low dignity.
```

Boundary:

> **D₀ remains untouched.  
> D₁/D₂ describe dignity-in-practice, not human worth.  
> D-profile claims are qualitative, not dignity scores.  
> D-Quick-Grid language, if used, describes a constellation in role/context/time window — not a person.**

---

## 7. Guardrail claims

Guardrail claims define whether a use is permissible within MIP.

They identify:

* red zones
* unsafe D-use
* person labelling
* missing role/context
* missing reversibility
* publicness risks
* vulnerability risks
* misuse of scores

Valid form:

```text
This planned use is outside the model because it would support an individual HR decision.
```

Invalid form:

```text
The model says this person is unsuitable.
```

Boundary:

> **If guardrails fail, the analysis is not mature MIP use.  
> It remains `working_note` / `not_mature_for_transmission`, not decision basis.**

---

## 8. Axiomatic claims

Axiomatic claims state the foundational premises of the model.

Examples:

```text
D₀ is inalienable.
Person and enactment must be separated.
Maturity is an enactment state, not a person type.
No enactment is isolated.
```

These claims are not generated by a case analysis.
They govern all applications.

Boundary:

> **Axiomatic claims are model premises, not empirical findings about a person.**

---

## 9. Method claims

Method claims tell users how to apply the framework.

Examples:

```text
Use the IA-box (`T–J–TB–R`) to test asymmetries.
Treat the IA-box as an asymmetry check, not a verdict.
Write trajectories, not labels.
End every IA analysis with at least one actionable improvement or review path.
Use D only when guardrails are fulfilled.
Keep D-profile qualitative and separate from A/M bands.
```

Boundary:

> **Method claims guide procedure; they do not decide the case by themselves.**  
> **Tools structure perception; they are not decision engines.**

---

## 10. Meta-claims

Meta-claims mark limits, bias and standpoint.

They include statements about:

* observer role
* norm assumptions
* intuition
* bias risks
* cultural situatedness
* revisability
* uncertainty
* counter-perspectives

Valid form:

```text
This reading depends on a professional-institutional lens and should be checked against affected perspectives.
```

Boundary:

> **Meta-claims protect the model from pretending to be view-from-nowhere objectivity.**

---

## 11. Illustrative claims

Illustrative claims occur in examples, vignettes and case studies.

They show how the model can be used.

They do not prove general laws.

Valid form:

```text
This vignette illustrates how a functional asymmetry can drift into IA risk.
```

Invalid form:

```text
This example proves that all such cases are IA.
```

Boundary:

> **Examples demonstrate use; they do not expand the model.**

---

## 12. Formal notation claims

Formal notation claims translate the model into symbolic form.

Because `A` already denotes awareness and A-score notation, formal notation avoids using `A` as actor placeholder.

Preferred actor placeholder:

```text
X = actor / role-holder / object of observation
```

Example:

```text
H = (X, ρ, K, A_w, C_o, R_s, P_a, D_p, IA)
```

Where older notation writes:

```text
M(A)
```

read:

```text
M(X)
```

Such notation may help in documentation, research or machine-readable representation.

Boundary:

> **Formal notation is a documentation aid.  
> It does not replace context, guardrails, judgement or qualitative interpretation.**

---

## 13. Normative claims

MIP contains limited normative commitments.

Central normative commitments:

* D₀ is inviolable.
* Persons must not be reduced to scores.
* D-profile must not become a dignity score.
* IA-box must not become a verdict.
* Analyses must not become pillory, diagnosis or verdict.
* Asymmetries require transparency, justification, time-bounding and reversibility.
* Vulnerable parties must not be burdened further through analysis.

Boundary:

> **MIP is not norm-free, but it makes its normative commitments explicit.**

Invalid expansion:

```text
MIP determines the morally correct political, religious or cultural position.
```

MIP does not do that.

---

## 14. Descriptive vs. normative vs. praxeological

MIP claims often combine descriptive and normative layers.
They should be kept distinguishable.

| Layer               | Question                               | Example                                                  |
| ------------------- | -------------------------------------- | -------------------------------------------------------- |
| Descriptive         | What happened?                         | “The rule was not explained.”                            |
| Praxeological       | How was it enacted under conditions?   | “The role used power without transparent justification.” |
| Structural          | What asymmetry exists?                 | “Knowledge and control were unevenly distributed.”       |
| Normative-minimal   | Which guardrail is violated?           | “The asymmetry was not reversible.”                      |
| Dignity-in-practice | How was dignity enacted or undermined? | “The public exposure produced D-P risk.”                 |
| Meta                | From which standpoint is this read?    | “This reading depends on an institutional perspective.”  |

Rule:

> **Do not hide normative claims inside descriptive language.**

---

## 15. Unsafe claim transformations

The following transformations are not allowed.

| From valid claim                     | Unsafe transformation                       |
| ------------------------------------ | ------------------------------------------- |
| “The enactment shows low coherence.” | “The person is incoherent.”                 |
| “A ≈ 3–4 in this role.”              | “The person is A=3.”                        |
| “The structure shows IA risk.”       | “The other side is inadult.”                |
| “D₁ self-devaluation is visible.”    | “The person lacks dignity.”                 |
| “M is structurally high.”            | “They are guilty.”                          |
| “The case raises D-P risk.”          | “They publicly humiliated themselves.”      |
| “The analysis is situated.”          | “Anything goes.”                            |
| “D is optional.”                     | “D can be ignored where dignity is harmed.” |
| “IA-box shows IA risk.”              | “The IA-box proves who is wrong.”           |
| “D-profile shows D stress.”          | “The person has a dignity deficit.”         |

---

## 16. Citation guidance

When citing MIP claims, prefer formulations such as:

```text
MIP describes this as a role-bound enactment pattern.
```

```text
The relevant claim is structural, not diagnostic.
```

```text
The D-claim concerns dignity-in-practice, not ontological dignity.
```

```text
The A/M claims are contextual bands and do not rank persons.
```

```text
The IA-box claim is an asymmetry check, not a verdict.
```

```text
The D-profile claim is qualitative and does not assign a dignity score.
```

Avoid:

```text
MIP says this person is immature.
MIP proves this actor is undignified.
MIP diagnoses the organisation.
MIP gives them a dignity score.
```

---

## 17. Minimal claim audit

Before including a claim in a MIP-derived document, check:

```text
[ ] What type of claim is this?
[ ] Is the role/context/time window clear?
[ ] Does the claim describe enactment rather than person essence?
[ ] Does it avoid person labels?
[ ] Does it protect D₀?
[ ] Does it keep D₁/D₂ separate from human worth?
[ ] Is D-profile, if used, qualitative rather than score-like?
[ ] Are A/M used only as justified bands?
[ ] Is IA-box treated as asymmetry check, not verdict?
[ ] Is the ceiling rule relevant?
[ ] Is the observer standpoint visible where needed?
[ ] Is the claim revisable?
[ ] Could the claim be misread as diagnosis, guilt, verdict or dignity ranking?
```

If yes:

> **Reformulate before use.**

---

## 18. Final formula

```text
MIP claims are bounded claims about practice.

They may describe:
- enactments
- roles
- structures
- asymmetries
- trajectories
- responsibility
- power
- dignity-in-practice

They may not decide:
- person worth
- ontological dignity
- dignity score
- IA verdict against a person
- clinical status
- legal guilt
- HR suitability
- moral essence
- final truth about a person
```
