---
document_id: MIP-BLOCK-12
title: "Concluding Word"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/12_conclusion.md"
status: "split-full-version"
version: "v1"
block_id: "12"
block_role: "canonical core block"
source_chapter: 12
source_chapter_title: "Concluding word – maturity in practice remains work"
secondary_references: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
appendix_references: []
claim_mode: "praxeological, provisional, self-implicating, revision-oriented, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice remains a permanent task; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 12 heading up to immediately before Appendix A"
---

# Maturity in practice — A praxeological anthropology: Concluding Word

## 12) Concluding word – maturity in practice remains work

This model is deliberately marked as a **working version**.  
Not out of modesty, but as a consequence of its own claim:

> **Working-version rule:**  
> The model is a **working version** because **maturity in practice** must itself prove itself **under conditions**.

> **Maturity in practice** means how we actually act under conditions –  
> so this model, too, must **prove itself under conditions**.

### What that means

* It emerged from conversations, conflicts, practice experiences.
* It carries normative assumptions of its authors and users.
* It remains reliant on **revision**:

  **Revision sources:**

  * **counterexamples**
  * **other perspectives**
  * **structural critique**

> **Revision is not optional.**

### Three effects if the model succeeds

1. **Shift of focus**  
   away from “Who is good/bad?”  
   towards:  
   “How are roles, power, responsibility, action spaces built –  
   and what **effect on dignity in practice** do they have?”

2. **Making `IA` visible without pillory**  
   making **inadult asymmetries (`IA`)** visible  
   **without automatically producing a pillory**.

3. **Self-implication**  
   Those who analyse, show themselves.  
   Those who demand maturity must at least attempt it in their own actions.

---

### Toolbox with an ethics rider

> **MIP is not a doctrine.  
> It is a toolbox with an ethics rider.**

The model is not a doctrine,  
but a **toolbox with an ethics rider**.

* It may be used, criticised, rejected, improved.
* Condition:

  > **Maturity in practice matters more than being right —  
  > and dignity in practice more than winning.**

---

### User commitments

Those who use the model commit to:

1. **Self-implication**  
   seeing their own roles, biases, norm assumptions and images of dignity along with the analysis.

2. **Revision under counter-evidence**  
   revising analyses when reality or counter-voices refute them.

> Anything less would be `IA` in dealing with the model itself.

---

### Conclusion

This model aims to help us, in difficult, asymmetric situations, to act

* **more clearly**,
* **more fairly**,
* **more in line with dignity**,
* and **more responsibly**.

Always knowing that this, too, is only an approximation –  
and that maturity in practice, including our handling of dignity  
(`D₀` as ontological dignity and `D₁/D₂` as praxeological dignity in practice),  
remains a **permanent task** – for persons, structures, and also for this model itself.

> Maturity in practice remains a **permanent task** —  
> for persons, structures, and also for this model itself.
