---
document_id: MIP-BLOCK-04
title: "Functional vs. Inadult Asymmetry"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/04_functional_vs_inadult.md"
status: "split-full-version"
version: "v1"
block_id: "04"
block_role: "canonical core block"
source_chapter: 4
source_chapter_title: "Functional vs. inadult – the four-criteria box"
secondary_references: [1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, structural, asymmetry-focused, role-sensitive, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice; context-bound enactment reading; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 4 heading up to immediately before chapter 5 heading"
---

# Maturity in practice — A praxeological anthropology: Functional vs. Inadult Asymmetry

## 4) Functional vs. inadult – the **IA-box** (`T–J–TB–R`)

The previous chapters have shown **how** people act: along awareness (`A`), coherence (`C`), responsibility (`R`), power (`P`) and dignity in practice (`D`). What they have not yet answered is: **When** are unequal distributions of these parameters useful – and when do they tip into **inadult asymmetry (`IA`)**? In practice this is exactly where the conflict lies: is a tough decision, an unequal distribution of knowledge or power still **functional** – or already abuse?

**Asymmetries** are everywhere. What matters is:

> **Are they functional – or inadult by design?**

The **IA-box (`T–J–TB–R`)** is the core instrument  
for classifying any **asymmetry** along awareness, coherence, responsibility, power and dignity in practice.  
It translates the abstract `A–C–R–P–D` framework into four simple, testable questions.

Once we know roles, enactments, `A–C–R–P` and modulators,  
we need a tool to **evaluate asymmetric situations concretely**.  
The **IA-box (`T–J–TB–R`)** is the heart of this analysis.

---

### 4.1 **IA-box (`T–J–TB–R`)** for asymmetries

Every **asymmetry** is examined through four questions:

1. **`T` – Transparent?**
2. **`J` – Justified?**
3. **`TB` – Time-bound?**
4. **`R` – Reversible?**

Together they form a compact raster that can be applied in very different fields – from team conflicts to political power relations.

**Mini-vignette:**  
A boss is the only one who sees the full financial situation and decides on overtime.  
This **asymmetry** is functional if she clearly communicates why she needs which information, when the team will gain insight and how decisions can be reviewed.  
It becomes **inadult** when no one understands why she decides as she does, the situation never ends and criticism is practically impossible.

---

#### **`T` – Transparent?**

Guiding question:

> **Who knows what – and who could realistically know it?**

Transparency is present when:

* rules, responsibilities and decision paths are named,
* relevant circles can understand why an asymmetrical distribution exists,
* there are no “secret zones” or informal power channels.

`IA` signals:

* vague phrases (“That’s just how it is”),
* rules known only to insiders,
* deliberately obfuscated decision logics.

**D-specific:**

* degrading practices that run covertly → automatically intransparent → `IA`-suspect,
* self-devaluation (`D₁` – self-dignity in practice / enacted self-dignity) can itself be intransparent when it has been normalised,
* micro-humiliations are by definition intransparent and `D₂`-relevant (relational dignity in practice / enacted relational dignity).

---

#### **`J` – Justified?**

Guiding question:

> **Does the asymmetry serve a testable purpose – or only the advantage of one side?**

An **asymmetry** is justified when:

* its purpose is clearly named (protection, organisation, training, risk minimisation),
* it is understandable why this purpose makes an unequal distribution necessary,
* the reasons are **open to discussion and reviewable**.

Not justified:

* pure status or tradition arguments,
* asymmetries to the advantage of one side with no protected good,
* “toughening people up” through humiliation or shaming.

**D-specific:**

* protective asymmetry (e.g. in care, education) is justified when it protects dignity,
* degrading asymmetries are by definition unjustified or only seemingly justified.

---

#### **`TB` – Time-bound?**

Guiding question:

> **Is this asymmetry limited in time or by conditions?**

Time-bound means:

* purpose and duration are clear,
* there are review points,
* there is a willingness to adjust.

Not time-bound:

* “This will stay like this from now on,”
* emergency rules that never disappear again,
* silent extensions of special rights.

**D-specific:**

* temporary restrictions of autonomy can be sensitive to dignity (clear purpose, clear framework),
* endless patterns of degradation count as non-time-bound `IA`.

---

#### **`R` – Reversible?**

Guiding question:

> **Are there real ways back – or only theoretical ones?**

Reversible:

* real possibilities for correction,
* mechanisms for rescinding decisions,
* pathways that can be used without extreme costs.

Irreversible:

* in practice no way back (dependency, stigma, inescapable power relations),
* pathways exist only on paper, not in reality.

**D-specific:**

* **`D₀` is always intact.**  
* **`D₁/D₂` are revisable as enactment forms; this does not erase consequences.**
* Structural `IA` is present when real pathways to a more dignified enactment are blocked.

---

#### Functional vs. inadult – in combination

> **Decision:**  
> `functional asymmetry` / `IA risk` / `inadult asymmetry`

**Functional asymmetry** when `T–J–TB–R` is fulfilled:

* transparent,
* justified,
* time-bound,
* reversible,
* protected good clearly named,
* `D₀` respected, `D₁/D₂` enabled.

**Inadult asymmetry (`IA`)** when at least two criteria fail:

* intransparent,
* unjustified or only seemingly justified,
* unbounded,
* irreversible.

Particularly critical:

* when people are systematically brought **below their dignity**,
* when groups are treated as “less dignified,”
* when degrading structures and degrading language interact (double `IA`).

---

#### Anchoring in `A–C–R–P–D`

Each `T–J–TB–R` criterion links back to the five axes:

* **`T` ↔ `A` (awareness)** – What is visible?
* **`J` ↔ `C` (coherence)** – Is the asymmetry logical and understandable?
* **`TB` ↔ `R` (responsibility)** – Who pays attention to time, duration and corrections?
* **`R` ↔ `P` (power / power to act)** – Are there real pathways to reversal?

And across all of this:

* **`D` – dignity in practice** – sensitivity to dignity in justification, duration, implementation and possibilities for correction.

The **IA-box (`T–J–TB–R`)** translates the model’s abstract dimensions  
into four precise questions that can be posed **operationally** in any analysis.  
To prevent `T–J–TB–R` itself from becoming a source of misreadings, it must first be clear **who** is acting in which role – this is exactly where 4.2 begins.

---

### 4.2 **Role and context logic**

Before an **asymmetry** can be meaningfully run through the **IA-box (`T–J–TB–R`)** at all, it must be clarified:

> **Mandatory pre-check:**  
> Clarify **role**, **context**, and **observer position** before applying `T–J–TB–R`.

Without this clarification, the analysis itself produces role confusion and phantom intention – precisely the `IA` patterns the model aims to make visible.

---

#### 4.2.1 Clarifying the role of the **object of observation**

The **object of observation** can be many things:

* a single person,
* a team / a relationship / a committee,
* an institution or organisation,
* a procedure, a rule, a discourse, a narrative.

For the object of observation, the following must be determined in advance:

1. **What function does the object of observation have in the situation?**

   * a **responsibility-giving** role  
     (leadership, office, decision-maker),
   * an **addressed** role  
     (those affected, employees, learners, clients),
   * a **mediating** role  
     (facilitation, supervision, oversight, counselling).

2. **In what public sphere is the object of observation acting?**

   * private · semi-public · institutional · public · media-amplified,
   * how high is the **public agency (`P-PU`)**,
   * how high should **public/media awareness (`A-P`)** realistically be.

3. **What structural asymmetry is built into the role by design?**

   * knowledge advantage (information, expertise),
   * decision-making power (access to resources, sanctions),
   * protective function (mandate to represent or protect others),
   * **dignity mandate** (care, education, justice system, pastoral care),  
     where other people’s dignity is explicitly entrusted.

This clarification is **explicit framework setting**, not prejudice:  
without it, it remains unclear which asymmetries are present by design and which represent inadult deviations.

**Mini-vignette:**  
A teacher has, by role, power over grades, access and evaluations.  
Only once it is clear whether they are currently acting as a pedagogical professional, as a private person or as a public authority can we judge whether a sharp reprimand is a **functional asymmetry** – or degrading `IA`.

---

#### 4.2.2 Clarifying the role of observers

Equally important:

> **From which role is the analysis being conducted – with what power and what risk?**

“Observers” can be:

* researchers,
* consultants / facilitators,
* internal decision-makers,
* the public / media,
* those affected themselves (self-application).

Before any analysis we need to clarify:

1. **What function do observers have in relation to the object of observation?**

   * neutrally examining,
   * involved and taking sides,
   * themselves part of the structure?

2. **What power and protection asymmetries exist between observers and the object of observation?**

   * influence on decisions, reputation, sanctions,
   * their own status- or institution-protection,
   * risk of damaging dignity in practice through language  
     (public shaming, labelling, stigmatisation).

3. **How explicitly are roles named?**

   * does the object of observation know that it is being analysed?
   * does the object of observation know with what consequences?
   * is it clear that the model **does not evaluate personal dignity**  
     (`D₀` – ontological dignity – remains off-limits)?

Risks without role clarification:

* the model is used as a **weapon from above**,
* hidden interests are wrapped in “analysis,”
* observers elevate themselves through degrading `D` readings.

---

#### 4.2.3 **`A-R` – role awareness** as the start button

Both sides – object of observation and observers – need a minimum level of **`A-R` – role awareness**:

* The object of observation understands:

  * in which role it is being evaluated,
  * which expectations are linked to that,
  * how its **D-enactments** (self-treatment, protest, adaptation)
    can be read as `D₁/D₂` (self-dignity in practice and relational dignity in practice).

* Observers understand:

  * that every analysis is **self-implication**
    (their own standards, blind spots, power position, their own `D` practice),
  * that analysis itself creates an **asymmetry**,
  * that they must be measured against their own dignity practice.

Only then is the path clear for:

* the **IA-box (`T–J–TB–R`)**,
* role confusion & phantom intention (4.3),
* later checklists (7.6).

**Short formula:**

> **Without role clarification, every `IA` analysis itself is `IA`-suspect –  
> every `D` finding itself at risk of violating dignity.**

This sets the stage for 4.3:  
there the typical distortions that arise when roles are not clearly defined are described – and how they can be recognised as `IA` patterns.

---

### 4.3 Role confusion & phantom intention

Roles are **switching points of social reality**:  
they define who, in which function, is speaking, acting, deciding, protecting, evaluating.

**Role confusion** is present when **`A-R` – role awareness** is low:

* one’s own role is unclear (“What am I here, actually?”),
* the role attributed by others is unclear,
* the role of the counterpart is unclear or constantly changing,
* nobody names explicitly *in which function* they are acting or speaking.

This creates a **role vacuum**,  
filled by expectations, fears, stories.

Mechanics of role confusion:

1. **Projection space**  
   Roles are constructed from needs, fears, prior experiences.

2. **Multiple projection**  
   the same person is simultaneously read into contradictory roles  
   (friend, adversary, rescuer, victim, provocation …).

3. **Action conflict**  
   unclear whether to lead, follow, withdraw;  
   unclear responsibility status.

4. **Responsibility breakdown**  
   over-responsibility or under-responsibility;  
   `R` states become chaotic, legitimate decision powers unclear.

5. **Context smearing**  
   private/professional/public expectations blur;  
   social and power-related coherence levels (`C-S/C-P`) collapse, signals wander between contexts.

Consequence:

> Where roles are unclear, **phantom intentions** arise.

**Phantom intentions**:

* attributed intentions,
* not named,
* not clearly derivable from any single action,
* yet felt as “certain” (“They *obviously* want to …”).

Consequences:

* neutral actions read as attack/flirt/test/devaluation,
* withdrawal read as punishment,
* questions read as distrust,
* massive conflicts with no clear objective trigger.

**Mini-vignette:**  
Anna is a team leader and former colleague. Sometimes she speaks “at eye level,” sometimes as superior, without signalling the shift. A spontaneous suggestion is understood by one team member as a friendly idea, by another as a semi-official instruction. From the same sentence, two completely different lines of conflict arise through phantom intentions – not because Anna is “wrong,” but because the **role logic** remains unclear.

In `A–C–R–P` terms:

* low **`A-R` – role awareness** → confusion over who is what,
* collapsing **coherence (`C`)** → missing anchors of meaning,
* diffuse **responsibility (`R`)** → breakdown of responsibility,
* distorted **power (`P`)** → helplessness or overreach.

Role confusion generates:

1. **enactment asymmetry** (who decides / who carries burdens?),
2. **asymmetry of interpretation** (who determines meaning?).

This is where the model becomes particularly sharp:

> Many apparent “character conflicts” turn out to be role and context conflicts.

It shifts the focus from “What is this person like?” to:  
“In which role – in which framework – are we actually acting and interpreting here?”

The next step is to understand how meanings **systematically shift** when roles and contexts are not shared – this is the task of 4.4.

---

### 4.4 **Semantic drift** & **D asymmetries**: same action, different meaning

Actions and language get their meaning **not in isolation**, but through the interplay of:

* role,
* context,
* relationship,
* power relations.

In the model, **semantic drift** means:

> the systematic shift of meanings  
> when roles and contexts are not shared.

This affects not only “What is meant?”, but also:

* **how dignified / undignified** an enactment is read,
* **whether** a behaviour is understood as **self-degradation**
  or as a mirror of a degrading structure.

---

#### 4.4.1 **Semantic drift** (basic mechanics)

Same action – different roles → different meaning:

* a compliment from a superior  
  – appreciation? control? signal of expectation?
* the same compliment from colleagues  
  – solidarity? collegial appreciation?
* the same compliment from an uninvolved person  
  – politeness? small talk? distant recognition?

Or:

* **silence**
  – as a leader → threat? testing? indifference?  
  – as a friend → overwhelm? thinking? withdrawal?  
  – as a stranger → no relation, no assignment.

Stable **`A-R` – role awareness** and a sound coherence situation (`C`) → readable nuances.  
Low `A-R` or fragile coherence (`C`) → drift, competing interpretations, phantom intentions.

**Semantic drift** intensifies:

* **phantom intentions** (“If you are silent in *this* role, you *must* mean something specific.”),
* **vulnerability** (“What if all of this was meant completely differently?”),
* `IA` via interpretive power (whoever controls the interpretation controls meaning).

In practice:

* explicit clarification of role and context,
* before far-reaching conclusions are drawn from individual sentences or gestures.

---

#### 4.4.2 `D` and asymmetries: **self-degradation** vs. **societal degradation**

With the **D-module**, the question shifts:

> **“What does this action mean?”**  
> also to  
> **“To whom is dignity being granted here – and to whom is it being denied?”**

Final three-part structure (consistent notation):

* **`D₀` – ontological dignity**  
  unrevocable value of the person, non-negotiable, not part of the assessment.

* **`D₁` – self-dignity in practice (enacted self-dignity)**  
  how someone treats themselves (`D-I/D-B`):  
  self-care, self-neglect, self-devaluation, self-protection.

* **`D₂` – relational dignity in practice (enacted relational dignity)**  
  how someone, in practice, expresses their relationship to the environment (`D-R/D-P`):  
  adaptation, protest, refusal, mirroring.

**Semantic drift** arises here when observers:

* read a behaviour as **self-degradation** (“They have no self-worth”),
* although, praxeologically, it could also – or primarily – be read as **feedback to the outside world**:

  * neglect as protest  
    (“Your system does not deserve my effort”),
  * “living like trash” as a mirror of degrading treatment,
  * adapting downward in degrading environments  
    (“Everyone is like this here, why should I aim higher?”).

Axes of drift:

* **internal reading vs. external reading**

  * internal reading:  
    “This person does not value themselves” → `D₁` low.
  * external reading:  
    “This person holds little of their environment / mirrors its degradation” → `D₂` active.

* **deficit reading vs. protest reading**

  * deficit reading: “There is a lack of inner maturity / self-respect.”
  * protest reading: “A degrading structure is being mirrored or refused.”

The model forces a distinction here:

> When I perceive an apparent “lack of dignity,” am I reading it as an **inner defect** (`D₁`) –  
> or as a **relational response** to an environment that itself acts in degrading ways (`D₂`),  
> while `D₀` – ontological dignity – remains untouched at all times?

---

#### 4.4.3 Structural `IA` through **faulty dignity-interpretation**

**Semantic drift** becomes especially critical when the **more powerful** define  
what is to count as “dignified” or “undignified.”

Structural `IA` emerges, among other things, when:

1. **`D₁` and `D₀` are confused**

   * “undignified enactment” (low `D₁/D₂`) is turned into: “undignified person,”  
   * → ontological dignity is denied (`D₀` – ontological dignity – is contested; red zone).

2. **`D₂` (relational dignity in practice) is ignored**

   * protest or mirroring behaviour is read as “character weakness,”  
   * rather than as an indicator of degrading structures  
     (living conditions, environment, discrimination, poverty, exclusion).

3. **Interpretive authority is asymmetrical**

   * whoever controls media, politics, organisations, discourses  
     defines what counts as “normal,” “respectable,” “dignified,”
   * groups with low public/media awareness (`A-P`) or low public agency (`P-PU`)  
     are reduced to their visible D-breaks (`D₁/D₂`),  
     while structural degradation remains invisible.

**Semantic drift** + **faulty dignity-interpretation** generate:

* **secondary `IA`**  
  – those affected are hit twice:  
    by degrading structures **and** by interpretations claiming  
    their reaction says something about their personal worth.

* **stigma solidification**  
  – “That’s just how they are” replaces the question:  
    “Which options, resources and alternatives do they actually have?”

The praxeological counter-move:

* make dignity-readings **explicit**  
  (“I am currently reading this behaviour as …”),
* describe dignity **in enactment** (`D₁/D₂`, scene-bound, role- and context-dependent),
* **precede** this with structural questions:

  * Which asymmetries (`C-P` as coherence in power contexts, `P-S` as social agency, `R-S` as social responsibility) frame this dignity enactment?  
  * Where might an apparent act of **self-degradation**  
    actually be mirroring or protest?

In this way, the model protects against `IA` in which the interpretation by the powerful  
of what is “dignified” itself becomes a degrading structure.

To ensure these distinctions do not remain theoretical but become workable in everyday practice,  
a small, robust practical tool is required – precisely what the role-check in 4.5 provides.

---

### 4.5 Practical micro-tool: the role check

To detect role confusion and **semantic drift** early in everyday situations,  
a small tool is often enough when applied consistently:

> **Three questions before I interpret.**

**Question 1: Which role am I currently assuming for myself?**

* In which function am I speaking or acting?  
  – private, professional, friendly, as representative, as decision-maker, as affected person?
* Is this role **clear** to the other side – or only to me?

**Question 2: Which role is the other side likely assigning to me?**

* How might the other side think of who I am?  
  – supporter, controller, rival, authority, petitioner, examinee …
* Are there signs that this assignment does **not** match my self-perception?

**Question 3: Which role am I assigning to the other person?**

* In which role am I reading them?  
  – partner, adversary, evaluating authority, protective figure, petitioner, “the institution,” “the crowd” …
* Have I ever **checked** this assignment – or is it historical / projected?

**Mini-vignette:**  
An employee writes their manager: “I don’t understand the decision.”  
If the manager reads them as a petitioner, the reply may be explanatory.  
If the manager reads them as a rival, the reply may be defensive or punitive.  
A brief role check (“Is he speaking as someone insecure, as a critic, as someone hurt?”)  
can prevent escalation before any content is addressed.

**Application:**

* As soon as uncertainty appears for **any** of the three questions:  
  – **role vacuum detected.**  
  – high risk of phantom intentions and **semantic drift**.
* In that case, a **minimal clarification** is advisable, e.g.:

  * explicit role naming (“I am speaking now as …”),
  * asking (“In which role do you see me here?”),
  * context marking (“I’m responding to you now as …, not as …”).

The micro-tool is intentionally **low-threshold**:

* requires no scores,
* no complex analysis,
* only three quickly answerable questions.

Within the logic of the model, however, it is central:

> Whoever takes these three questions seriously  
> increases `A-R` (role awareness), stabilises `C` (coherence),  
> and reduces the risk of **inadult asymmetries** –  
> before they escalate.

Thus Chapter 4 bridges theory and practice:  
asymmetries become examinable with `T–J–TB–R`,  
roles and meanings become clarifyable,  
and with the role check there is a concrete tool for everyday use.  
**Chapter 5** then further operationalises this structure:  
there the A-score renders developmental maturity measurable –  
without sliding into moral labelling.

---

### 4.6 Conclusion

Chapter 4 clarifies the operational boundary between **functional asymmetry** and **inadult asymmetry (`IA`)**.

The **IA-box (`T–J–TB–R`)** does not treat asymmetry as automatically wrong.  
It asks whether an asymmetry is:

* **`T` – transparent**
* **`J` – justified**
* **`TB` – time-bound**
* **`R` – reversible**

Before this box is applied, **role**, **context**, and **observer position** must be clarified. Without that pre-check, the analysis itself risks role confusion, phantom intention and `IA`-suspect interpretation.

`A-R` – role awareness – functions as the practical start point: clarify the role before interpreting the scene. Where roles remain unclear, **semantic drift** and **asymmetry of interpretation** become likely.

For dignity readings, the boundary remains strict: `D₀` is untouched; `D₁/D₂` describe dignity in practice as enactment forms. Apparent **self-degradation** must not be confused with reduced person-worth, and **faulty dignity-interpretation** can itself become structural `IA`.

Thus Chapter 4 provides the bridge from the base model to application:  
asymmetries become reviewable, role/context confusion becomes visible, and dignity readings remain protected against person-level judgement.
