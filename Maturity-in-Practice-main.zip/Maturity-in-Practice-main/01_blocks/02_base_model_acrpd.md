---
document_id: MIP-BLOCK-02
title: "Base Model A–C–R–P–D"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/02_base_model_acrpd.md"
status: "split-full-version"
version: "v1"
block_id: "02"
block_role: "canonical core block"
source_chapter: 2
source_chapter_title: "Short definition & base model A–C–R–P–D"
secondary_references: [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, structural, parameter-based, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice; deep analytic layer; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 2 heading up to immediately before chapter 3 heading"
---

# Maturity in practice — A praxeological anthropology: Base Model `A–C–R–P–D`

## 2) Short definition & base model `A–C–R–P–D`

Chapter 1 has clarified **what** this project is about: **maturity in practice**, dignity in everyday life, **inadult asymmetries (`IA`)**. For this to be more than a good-sounding perspective, it needs a **technical basis** that makes concrete situations readable and comparable. This chapter lays that basis: five core parameters that are present in some form in every relevant scene and later form the foundation for scores, checklists and tools.

The aim of Chapter 2 is therefore not to already explain “everything”, but to lay open the **basic blueprint**:
Which axes do we read, what do they mean – and how do they interact as a **feedback loop**?

The model works with five basic axes:

* **`A` – awareness**
* **`C` – coherence**
* **`R` – responsibility**
* **`P` – power** (room for action in practice)
* **`D` – dignity in practice**  
  (praxeological forms of dignity in practice: self-dignity `D₁` & relational dignity `D₂`; operationally: inner dignity `D-I`, bodily/material self-care `D-B`, relational dignity `D-R`, public dignity `D-P`)

All further elements (scores, checklists, role mechanics, domain modules) are derivations or refinements of these five axes.  
This chapter clarifies only the **base model**: what each axis means – and how they interact.

---

### 2.1 Five core parameters in brief

As a first step, the five parameters are described in isolation – as “building blocks”, without yet following the later dynamics in detail. Section 2.2 then shows how they influence each other in real scenes and form typical **states**.

---

#### **`A` – awareness**

**`A`** does not first ask: *“How intelligent is someone?”*  
but: *“What could this person or this system realistically know and see?”*

**Awareness** includes, among other things:

* access to relevant information (facts, warning signals, alternatives),
* the ability to recognise one’s own role and situation (**role awareness / `A-R`**),
* sensitivity to side effects and those affected,
* willingness to correct perception (capacity to learn).

**High `A` expressions** mean:

* one has made an effort to obtain information,
* one does not ignore obvious signals,
* one can distinguish between inner perception and outward impact.

**Low `A` expressions** mean:

* tunnel vision, lack of information, avoidance of knowing,
* unclear or shifting role images,
* “not seeing” oneself and others (or not wanting to see them).

---

#### **`C` – coherence**

**`C`** measures how well **word, decision and action** fit together.

Guiding questions:

* Does someone say one thing – and then act against it?
* Is responsibility promised – and withdrawn when costs arise?
* Do inner reasons, external communication and observable behaviour align?

**Coherence** is **not a moral judgement**, but a structural criterion:

* **High `C` expressions**:  
  statements, decisions and actions form a comprehensible pattern – across time, roles and contexts.
* **Low `C` expressions**:  
  breaks, U-turns without explanation, double games, “saying one thing, doing another”.

`C` thus measures:

> How consistent is the system in practice – across time, roles and contexts?

---

#### **`R` – responsibility**

**`R`** describes **who actually carries and assumes which burden** – materially, emotionally, legally, physically.

Aspects of **responsibility**:

* assumption of consequences (costs, risks, repair work),
* willingness to name one’s own contributions,
* real influence on decisions (who is allowed to co-decide?),
* fairness of burden distribution between those involved.

**High `R` expressions**:

* someone stands by their decisions, even when they become uncomfortable.
* burdens are not systematically delegated downward.
* those affected are not made invisible.

**Low `R` expressions**:

* evasion, minimising, shifting blame,
* tendency to take benefits while handing off costs,
* structural **responsibility gaps** (“no one is responsible”).

---

#### **`P` – power**

**`P`** does not just mean “willingness to act”, but above all:
**“What could actually have been done here – and was it done?”**

Dimensions:

* objective room for action (legal, organisational, physical),
* perceived room for action (sense of self-efficacy),
* use of available options (intervening, setting limits, stopping, leaving).

**High `P` expressions**:

* real possibility to influence the course of events,
* the ability to make decisions even under pressure,
* access to resources (time, money, attention, infrastructure).

**Low `P` expressions**:

* powerlessness, dependency, paralysis,
* structural lack of freedom (e.g. factual lack of alternatives),
* decisions that are only formally possible but in reality untenable.

---

#### **`D` – dignity in practice** (self-relation & relational mirroring)

**`D`** describes **how people treat themselves** – bodily, socially, symbolically –
and what this self-enactment mirrors about their **relationship to the world**.

Two core questions:

* **Inside (`D₁` – self-dignity in practice):**  
  “What do I think I am worth?”  
  – self-care, self-respect, boundaries, protection of one’s own integrity.

* **Outside (`D₂` – relational dignity in practice):**  
  “What do I think of the world that surrounds me?”  
  – adaptation, refusal, protest, mirroring of degradation (“If you treat me like trash, I live like trash”).

Important:

* `D` describes the **praxeological forms of dignity in practice (`D₁/D₂`)**, not `D₀`.
* **Ontological dignity (`D₀`)** is taken as **given**: a person remains dignified – even when they treat themselves in undignified ways in practice.
* `D` therefore says nothing about “how much someone is worth”, but only about
  **how this worth is treated in everyday life** – by the person themselves and in their relation to the environment.

Operationally, `D` is described in the further course via four submodules:

* **inner dignity (`D-I`)** – self-respect, self-contact, inner clarity,
* **bodily/material self-care (`D-B`)**,
* **relational dignity in interaction (`D-R`)**,
* **public dignity in roles and visibility (`D-P`)**.

**High `D` expressions**:

* basic forms of self-care are recognisable (body, boundaries, time, relationships).
* the person does not systematically treat themselves worse than they would treat others.
* protest against degrading structures seeks forms that also protect one’s own dignity.

**Low `D` expressions**:

* self-neglect, self-devaluation, self-objectification,
* treating oneself as if one “were worth nothing” – often as a mirror of an environment that acts in the same way,
* undignified enactment as **congruence** with undignified conditions (“this is how everyone lives here”).

`D` thus makes visible:

* when **self-degradation** primarily expresses **inner patterns**,
* when it is a **response to degrading conditions**,
* and where society produces `IA` by morally condemning undignified enactments
  instead of seeing the underlying structures.

Guiding sentence for the entire model:

> **When `D` is described, actions are described – never the value of the person.**

---

**Mini-vignette:**  
A team leader demands “radical openness”, but reacts hurt when criticised and withdraws.  
Structurally we see: `A` partly high (there is awareness of tensions), `C` low (demand and behaviour do not fit together), `R` low (the costs of openness fall on employees), `P` high (the position allows sanctions), `D` in practice mixed (self-image as “open”, actual handling of one’s own hurt is uncertain).  
The base model names these axes without yet evaluating “what the person is like”.

---

**Interim conclusion for 2.1:**  
`A–C–R–P–D` define five distinct but interconnected dimensions of action. They are **not type labels**, but reading axes along which situations and profiles can be described. The next step is to look at how these parameters interact as a **feedback loop** in real practice and which typical **states** result.

---

### 2.2 Dynamics of `A–C–R–P–D` (**feedback loop** & **states**)

After the five parameters were outlined as independent axes in 2.1, 2.2 considers their **interactions**: people never act in “pure form”, but under the influence of time pressure, roles, expectations, fear, hope, context. The dynamics between `A`, `C`, `R`, `P` and `D` are therefore crucial for reading situations not just statically but as processes.

The five parameters act as a **feedback loop**, not as isolated categories.

A greatly simplified schema:

1. **Awareness (`A`)**  
   → what is seen, understood and inwardly admitted.

2. **Coherence (`C`)**  
   → how this knowledge is translated into decisions, narratives and self-images.

3. **Responsibility (`R`)**  
   → who consciously takes on or hands off which burdens and consequences.

4. **Action/power (`P`)**  
   → what is actually done (or omitted) as a result.

5. **Dignity in practice (`D`)**  
   → how those involved treat themselves – in body, everyday life, relationships and public self-presentation –  
   and what this treatment expresses about their relationship to the world.

**`P` and `D`** then feed back into **`A`**:

* Every action changes the situation:

  * new information,
  * new consequences,
  * new roles,
  * new power relations.

* Every form of self-treatment (`D`) changes:

  * what someone still **trusts themselves** with,
  * what someone **demands** of themselves (self-overload or self-abandonment),
  * which options are experienced as **visible** and “for me” in the first place.

---

#### Typical **states** (situational, *not* person types)

> States are always **situational, temporary, context-bound** –
> never attributions about “the person”.

---

##### **State: adult state**

* `A` sufficiently high: relevant information is obtained, blind spots actively reduced.  
* `C` high: decisions, communication and action are comprehensible.  
* `R` genuinely assumed: burdens are distributed in a reasoned way, areas of responsibility clearly named.  
* `P` used realistically: room for action is neither underestimated nor overextended.  
* `D` in practice largely intact: basic forms of self-care, self-respect and keeping boundaries are visible; no systematic self-degradation.

---

##### **State: inadult dominance**

* `A` low or selective (blind spot for one’s own impact),
* `C` rhetorical but not robust (“nice story”, brittle practice),
* `R` shifted away (“those down there”, “the circumstances”, “nobody could have known …”),
* `P` high and at times used without regard for others,
* `D` distorted: the self is inflated, the dignity of others devalued (↓relational dignity `D-R`); one’s own dignity is staged at the expense of others.

---

##### **State: inadult submission**

* `A` restricted (no overview, options invisible, narrow self-image),
* `C` brittle (“I don’t know what is happening here / what I am supposed to do”),
* `R` over-assumed (taking on too much guilt) or handed off (“there is nothing I can do”),
* `P` subjectively very low, although objectively more would be possible – or, conversely, unrealistic fantasies of omnipotence with actual powerlessness,
* `D` in practice clearly reduced: self-neglect, self-devaluation, adaptation to degrading conditions (“this is how everyone lives here”).

**Inadult submission** is not automatically a personality deficit, but often a **survival strategy under structural constraints**. The model does not read it as a “weak character”, but as an indication of contextual load.

---

**Mini-vignette:**  
A care worker in an understaffed shift sees (`A` high) that a measure endangers patients. She knows what would be professionally necessary (`C` clear), but feels left alone and fears sanctions (`P` subjectively low). She makes an internal note but does not change the procedure (`R` only partly assumed) and works permanently beyond her own capacity (`D` in practice falls).  
The state is not a “character judgement”, but the expression of a feedback loop of structure, pressure and self-treatment.

---

The model is interested in **how** these states arise – through **modulators**, roles, power, information situations –  
not in pinning people down into categories.

This outlines the process logic of `A–C–R–P–D`: information becomes interpretation, then responsibility decisions, then actions – and from these, forms of self- and world-treatment that in turn feed back into perception and possibilities.  
The next step (2.3) therefore introduces the **modulators** that amplify or dampen this feedback loop and explain why identical roles can lead to very different enactments under different conditions.

---

### 2.3 **Modulators** – amplifiers & dampers

> **Function:** modulators do not replace `A–C–R–P–D`; they alter how strongly patterns appear.

In 2.2, we saw how `A–C–R–P–D` interact as a feedback loop and generate typical states. In practice, however, one question remains open: **Why can the same person act so differently under slightly changed conditions – sometimes in an adult way, sometimes in an inadult way?** This is where the **modulators** come in.

The parameters `A–C–R–P–D` never exist in a vacuum.  
**Modulators** change how they can show themselves in practice.

They are **not an excuse**, but they explain **distortions**:

* why people with high basic maturity act more inadultly in specific situations,
* why persons systematically treat themselves below or above their real dignity,
* why asymmetries intensify or flatten out.

**Mini-vignette:**  
An experienced physician makes very adult decisions in a calm everyday setting (`A` high, `C` stable, `R` clear, `P` realistic, `D` intact). On a night with staff shortages, exhaustion and public pressure, she reacts irritably, becomes unclear in communication and overrides objections.  
Nothing about her basic maturity has changed – the **modulators** have shifted the enactment.

---

#### 2.3.1 **Structural modulators**

Framework conditions that act **from the outside** on the system:

* **Time pressure & complexity**
  – lower awareness (**↓`A`**) and coherence (**↓`C`**), promote snap decisions,  
  – encourage short-term self-neglect (↓bodily/material self-care, ↓`D-B`).

* **Access to information**
  – creates awareness asymmetries (**`A`-asymmetries**), relevant for responsibility (**`R`**) and any responsibility-related scoring,  
  – poor access to information → risk of structural self-devaluation (↓inner dignity `D-I` / ↓bodily self-care `D-B`).

* **Role and power differentials**
  – massively affect responsibility (**`R`**) and power (**`P`**),  
  – modulate relational dignity (**`D-R`** – dignity in interaction: whether one makes oneself smaller or larger).

* **Dependencies** (economic, emotional, legal)
  – realistically limit power (**`P`**),  
  – explain why “theoretically possible” options are in fact unreasonable,  
  – depress dignity in practice (**`D`**) – survival strategies instead of deficit.

* **Institutional rules**
  – bundle or dilute responsibility (**`R`**),  
  – can promote or prevent dignified practice.

* **Degree of publicity**
  – private → semi-public → institutional → public → media,  
  – higher publicity = stronger impact on  
    **public/media awareness (`A-P`)**,  
    **public agency (`P-PU`)**,  
    **public responsibility (`R-P`)** and  
    **public dignity in practice (`D-P`)**.

Core statement:  
Undignified enactment can be the expression of an **undignified environment** – an indication of structural **inadult asymmetry (`IA`)**, not of personal failure.

---

#### 2.3.2 **Dynamic / psychosocial modulators**

**Energy and relationship states** in the system:

* **Stress / overload**
  – lowers awareness (**↓`A`**), lowers coherence (**↓`C`**), raises `IA` risk,  
  – dignity in practice (**`D`**) often collapses immediately (self-care is experienced as a “luxury”).

* **Exhaustion / monotony**
  – lowers responsibility (**↓`R`**) and power (**↓`P`**),  
  – over time encourages structural self-devaluation (↓inner dignity `D-I` / ↓bodily self-care `D-B`).

* **Experiences of success**
  – increase power (**↑`P`**), awareness (**↑`A`**) and coherence (**↑`C`**),  
  – but risk: overconfidence, self-inflation (↑inner dignity `D-I`, ↓relational dignity `D-R`).

* **Social resonance**
  – constructive = stabilising (responsibility and dignity are supported),  
  – toxic = awareness, responsibility and dignity (`A`, `R`, `D`) collapse.

* **Group dynamics**
  – affect the use of power (**`P`**),  
  – modulate relational dignity (**`D-R`** – self-betrayal vs. protection), for example when loyalty to the group works against one’s own self-respect.

---

#### 2.3.3 Short rule for practice

1. **Structure first, then person.**  
   – make modulators explicit  
   – situate `A–C–R–P–D` structurally

2. **Then enactment.**  
   – what was actually done – *under these conditions*?

3. **Only then interpretation.**  
   – recognise maturity patterns  
   – cleanly separate the normative level  
   – make the reading of dignity explicit (**`D₁` internally = self-dignity in practice, `D₂` relationally = relational dignity in practice**)

This helps avoid inadult snap judgements (“dignified/undignified”).

**Interim conclusion for 2.3:**  
**Modulators** explain why different enactments can emerge from the same potential. They are therefore not a “bonus”, but a prerequisite for fair structural and responsibility-related assessments and for any reading of dignity. In the next step (2.4), the base model is further differentiated so that it becomes visible *in which sub-area* of a parameter a problem or a particular maturity achievement lies.

---

### 2.4 **Parameter matrix & submodules** (`A–C–R–P–D`)

**Modulators** show **why** enactments shift – the **parameter matrix** clarifies **where exactly** something is happening. Instead of merely saying “`A` is low” or “`D` is high”, breaking parameters into **submodules** allows for a more fine-grained reading: is the issue role awareness, contextual clarity, inner self-relationship, or public impact?

To understand more precisely *where* something goes wrong or succeeds in a particularly mature way,
the five main parameters are divided into **submodules**.

---

#### **Submodules**

* **`A` – awareness**
  – `A-I` (inner awareness)  
  – `A-R` (role awareness)  
  – `A-C` (context awareness)  
  – `A-IM` (impact awareness)  
  – `A-P` (public/media awareness)

* **`C` – coherence**
  – `C-S` (social coherence)  
  – `C-P` (coherence in power contexts)  
  – `C-N` (narrative coherence)  
  – `C-I` (institutional/rule coherence)

* **`R` – responsibility**
  – `R-I` (individual responsibility)  
  – `R-S` (social responsibility)  
  – `R-E` (ethical responsibility)  
  – `R-P` (public responsibility)

* **`P` – power**
  – `P-I` (inner agency / inner power to act)  
  – `P-S` (social agency)  
  – `P-C` (cultural agency)  
  – `P-PU` (public agency)

* **`D` – dignity in practice**
  – `D-I` (inner dignity / inner self-relationship)  
  – `D-B` (bodily/material self-care)  
  – `D-R` (relational dignity)  
  – `D-P` (public dignity / dignity in public enactment)

---

#### Table: parameters, submodules, expressions

| **Parameter** | **Submodules** | **Low expression** | **Medium expression** | **High expression** | **Excessive expression / distortion** |
|---|---|---|---|---|---|
| **`A` – awareness** | `A-I` (inner awareness) | little self-contact, impulsive behaviour | situational self-perception | reflective inner life, self-regulation | self-overmonitoring, rumination |
|  | `A-R` (role awareness) | unclear about which role one inhabits | roles recognised but not steered | conscious role guidance, switching | role-play rigidity, loss of authenticity |
|  | `A-C` (context awareness) | context blindness, misunderstandings | situational contextual sensitivity | confident navigation of contexts | overinterpretation, paranoia |
|  | `A-IM` (impact awareness) | naïve sense of being ineffectual | basic impact assessment | conscious impact management | calculation of effect, manipulation |
|  | `A-P` (public/media awareness) | no sense of public impact | basic media/public sensitivity | professional management of public impact | surveillance-like self-image, permanent self-censorship |
| **`C` – coherence** | `C-S` (social coherence) | social codes missed | situational social reading | confident navigation of social spaces | social masking, overadaptation |
|  | `C-P` (coherence in power contexts) | power differentials not recognised | partly recognised | consciously handled | power dominance or power phobia |
|  | `C-N` (narrative coherence) | missing meaning layers | partly understood | conscious use of meaning structures | symbolic overload, mythologisation |
|  | `C-I` (institutional/rule coherence) | rules ignored | rules understood situationally | rules consciously used/circumvented | technocratic rigidity |
| **`R` – responsibility** | `R-I` (individual responsibility) | avoidance | occasional assumption | active self-responsibility | hyper-responsibility, taking on excessive guilt |
|  | `R-S` (social responsibility) | indifferent / careless | situational awareness | proactive social action | martyrdom, self-sacrifice |
|  | `R-E` (ethical responsibility) | ethical blindness | situational sensitivity | consistent ethics | moral superiority, rigidity |
|  | `R-P` (public responsibility) | naïve “I can do anything” attitude | basic awareness | active management of public impact | PR-calculation, paralysis from fear of exposure |
| **`P` – power** | `P-I` (inner agency) | powerlessness, passivity | situational self-efficacy | stable self-efficacy | compulsion to control |
|  | `P-S` (social agency) | little influence | situational influence | stable leadership/interactional strength | dominance |
|  | `P-C` (cultural agency) | no narrative influence | occasional cultural impact | shaping cultural meaning | manipulative symbolic control |
|  | `P-PU` (public agency) | low reach | moderate visibility | strong public presence | “escalation risk”: `IA` risk via uncontrolled public dynamics |
| **`D` – dignity in practice** | `D-I` (inner dignity) | self-devaluation, harsh inner tone | ambivalent self-view | kind, realistic inner dialogue | grandiose invulnerability, devaluation of others |
|  | `D-B` (bodily/material self-care) | neglect of body, everyday life | selective self-care | stable basic care, protection of boundaries | compulsive self-optimisation, performance/body cult |
|  | `D-R` (relational dignity) | making oneself small, swallowing everything | situational boundary-setting | maintaining one’s own dignity without degrading others | constant moralising, shaming others “in the name of dignity” |
|  | `D-P` (public dignity) | self-degradation for clicks/applause | pragmatic handling of visibility | conscious, dignity-preserving self-representation | total self-branding, permanent self-objectification |

---

#### Function of the parameter matrix

The **parameter matrix** is a **zoom tool**: it allows the translation of general impressions (“something is off here”) into precise observations:

* Is the issue primarily **awareness**, **coherence**, **responsibility**, **power**, or **dignity in practice**?
* Does it concern inner processes (`A-I`, `D-I`) or public impact (`A-P`, `P-PU`, `D-P`)?
* Does dignity in practice (**`D`**) show primarily **inner patterns** (`D₁` = self-dignity in practice) – or **reactive mirroring/protest** against degradation (`D₂` = relational dignity in practice)?

The matrix thus enables a precise, non-moralising analysis of asymmetries: instead of “X is immature” or “Y has no dignity”, it becomes visible *which* axis has tilted under *which* conditions.

**Interim conclusion for 2.4:**  
The parameter matrix turns five basic axes into a finely structured grid. It will later be used for scorecards, case analyses and domain modules. Before these instruments are applied, however, it must be clear *who* is being observed and *in which public context* this enactment takes place – this is clarified in section 2.5.

---

### 2.5 **Publicity & position of the object of observation**

Before a case is analysed, a clear determination is needed:

> **“In which role and in which public context does the system under observation stand – and how is its dignity enacted there?”**

This step is **mandatory** before any `IA` or `D` analysis can begin.  
Without it, private, weak, or dependent positions risk being treated like powerful public actors – a classic case of **inadult asymmetry** within the analysis itself.

**Mini-vignette:**  
Anna expresses serious doubts about her role as a parent in a confidential conversation with a friend. The same sentences are later taken out of context and quoted on a large platform as if she had said them in an official interview.  
Structurally, this is **not the same scene**: **role position** and **level of publicity** have shifted – and with that `A`, `R`, `P` and `D-P`.

---

**The object of observation** may be:

* an individual person,
* a relational system (e.g. team, family),
* an institution,
* a discourse or narrative.

For every analysis, **two axes must be determined**:

---

#### 1. **Role position**

Is the object of observation acting …

* as a **private person**?
* as a **role-holder** (office, profession, leadership role)?
* as **part of a collective** (committee, project team, political movement)?
* as a **spokesperson for a narrative or organisation**?

Relevant modules:

* **`A-R` – role awareness**  
* **`C-S / C-P` – social and power-related coherence contexts**  
* **`D-R` – relational dignity in role enactment**

Without explicit role determination, semantic drift, phantom intentions and inadult asymmetries through faulty attribution become likely.

---

#### 2. **Publicity level**

* purely **private**
* **semi-public** (organisations, groups, scenes)
* **institutional** (formal contexts, mandates)
* **public** (broad visibility, susceptibility to critique)
* **media-amplified** (archives, algorithmic reproduction)

Relevant modules:

* **`A-P` – public/media awareness**  
* **`P-PU` – public agency**  
* **`D-P` – public dignity in practice**

The higher the level of publicity, the higher the requirements for awareness (**`A`**), responsibility (**`R`**) and public dignity (**`D-P`**).

---

#### Principles

* The same behaviour may be evaluated **structurally differently** depending on role and publicity.
* More publicity = more responsibility for impact (impact awareness **`A-IM`**, public responsibility **`R-P`**).
* High public reach (**`P-PU`** high) increases the risk of relational dignity breaks (**`D-R/D-P`**).
* Private, weak or dependent roles may not be evaluated as if they were public figures.
* Analysis of private enactments without specifying role and context counts as `IA`-suspect.

**Mandatory step:** always determine **role + publicity** before `A–C–R–P–D`.

**Interim conclusion for 2.5:**  
With role position and level of publicity determined, the model knows *from where* it is reading and *which responsibility structure* it assumes. Chapter 2 has thus completed its basic task: the five base axes are defined, their dynamics and modulators explained, the parameter matrix established, and the object of observation situated.  
On this basis, Chapter 3 can formulate the guardrails and ethics of use that prevent the model itself from becoming a machine for inadult asymmetry.

---

### 2.6 Ontological vs. praxeological dignity

The previous sections described maturity and asymmetry primarily structurally. But once the **D-module** appears, the model encounters a concept that is heavily charged in philosophy, law, politics and everyday life: **“dignity”**. Without a clear separation of levels, every observation of **D-enactments** risks being misunderstood as a statement about the worth of a person.

“Dignity” is one of the most overloaded concepts we have:
philosophically, religiously, legally, morally.

To keep the model workable, it separates **two levels**, later three (`D₀/D₁/D₂`), that are often conflated in everyday speech:

* **`D₀` = ontological dignity** (inalienable worth of persons),
* **`D₁/D₂` = dignity in practice** (praxeological forms of dignity in practice: self-dignity and relational dignity).

This separation is the prerequisite for the model being able to make **D-enactments** visible
without becoming an authority over the “worth” of persons.

---

#### 2.6.1 Ontological dignity – non-negotiable, not measurable

**`D₀` = the inalienable worth of every human being as a human being – ontological dignity.**

Properties:

* equally distributed  
* not gradable, not losable  
* not measurable, not scalable  
* not an object of analysis  
* axiom of the model  

Consequences:

* Even destructive or derailed actions do **not** change `D₀`.  
* The model neither removes nor assigns dignity.  
* Where practices or language explicitly deny `D₀` (“subhumans”, “trash people”), the **red zone** begins:  
  → this is where any legitimate use of the model ends.

---

#### 2.6.2 Praxeological dignity (`D`) – dignity in practice

Praxeological dignity means:

> **How someone handles their own dignity in action – and what this enactment shows about their relationship to the world.**

It includes:

* **self-relation – `D₁` (self-dignity in practice):**  
  self-care, self-devaluation, self-protection.
* **relation to the world – `D₂` (relational dignity in practice):**  
  adaptation, protest, mirroring, refusal.
* concrete **enactments**, not inner diagnoses.

Typical forms of enactment include:

* care and protection of one’s body and daily life,
* forms of self-protection or self-defence,
* self-degradation and neglect,
* self-staging and self-objectification.

Core idea:

> **People act undignifiedly at times – and yet remain dignified (`D₀`).**

Praxeological dignity is:

* observable – it appears in actions and routines,
* gradual – from minor irritations to major dignity breaks,
* context-dependent – the same act can appear differently depending on role/context,
* changeable – especially over longer trajectories,
* revisable as enactment form.

The three levels of the model:

1. **`D₀` – ontological dignity**  
2. **`D₁` – self-dignity in practice**  
   (operationalised via **inner dignity (`D-I`)** and **bodily/material self-care (`D-B`)**)
3. **`D₂` – relational dignity in practice**  
   (operationalised via **relational dignity (`D-R`)** and **public dignity (`D-P`)**)

Thus it is clear: when the model speaks of “dignity in practice”, it refers to observable actions – not to the person “as such”.

---

#### 2.6.3 Relational dignity (`D₂`) – dignity in relation to the world

**`D₂`** describes how someone responds to their world:

* **adaptation** – seeking protection, recognition, or relief,  
* **protest** – breaking expectations to make degradation visible,  
* **mirroring degradation** – adopting and returning degrading images,  
* **refusal** – withdrawing from roles or structures experienced as degrading.

Key insight:

> **Many seemingly “self-damaging” enactments are responses to degrading structures – not personal defects.**

Contexts where `D₂` is especially relevant:

* politics and power relations,  
* cultural and media spaces,  
* institutional practice ethics.

**`D₂`** is the conceptual level of relational dignity;  
it becomes operationally visible via **`D-R`** and **`D-P`**.

**Mini-vignette:**  
A person begins presenting themselves in a deliberately demeaning way on social media (“I’m trash anyway”).  
In the **D-module**, this is not read as “lacking dignity”, but as relational dignity enactment: `D₂` mirrors an environment that has treated the person in exactly this way for a long time.

---

#### 2.6.4 Boundary: “acting without dignity” vs. “being without dignity”

The model speaks solely about **D-enactments (`D`)**:

* allowed: “In this scene, X acts in an undignified way.”
* not allowed: “X is undignified.” (a judgement about the person → red zone)

Mnemonic:

> **Recognise the action – not the person.**

This separation is practically implemented in Chapter 3.5–3.7 and in the **D-Quick-Grid**.  
It forms the model’s internal safeguard: dignity is described in practice without touching the ontological worth of persons.

**Interim conclusion for 2.6:**  
With the separation of `D₀`, `D₁` and `D₂`, it is clear *what* the model refers to when analysing dignity. `D₀` remains untouchable; `D₁/D₂` become praxeologically readable. In the next step (2.7), this becomes a concrete **D-module** that describes how **D-enactments** are observed, situated and protected against misuse.

---

### 2.7 **D-module** – overview

The model is **five-axis (`A–C–R–P–D`)**.  
The **D-module** is not an external add-on but a **deep analytic layer** for `D₀/D₁/D₂`:

* band logic,  
* safeguard clause,  
* communication rules.

It is activated when the central question becomes:

> **“How does someone handle their own dignity here – and what does this reveal about their environment?”**

As long as this question is not relevant or cannot be cleanly embedded, `D` remains in the background.

---

#### 2.7.1 Guiding formula & basic stance

Guiding formula:

> **People act without dignity – yet remain dignified.  
> Often because options are invisible to them.**

Basic stance:

* no moral contempt,
* structural understanding,
* situational, not identity-based readings,
* focus on role, context and timing.

Mnemonic:

> **D-module = revealer, not pillory.**

---

#### 2.7.2 What the **D-module** observes – and what it does not

**Observes:**

* **inner dignity (`D-I`)** – inner self-treatment, inner dialogue, self-respect,
* **bodily/material self-care (`D-B`)** – treatment of body, health, everyday life, resources,
* **relational dignity (`D-R`)** – how someone shapes boundaries, respect and closeness in relationships,
* **public dignity (`D-P`)** – how someone presents themselves in public spaces and roles.

**Does not observe:**

* diagnoses,
* rankings,
* moral condemnation,
* disciplinary judgements,
* dignity statements about identity.

**Mini-vignette:**  
Two people post hurtful content about themselves. For one, it is an ironic comment among friends (`D-P` slightly irritated, `D-I` stable); for the other, an expression of long-standing self-devaluation (`D-I` and `D-P` clearly reduced).  
The **D-module** does not ask: “Who is ‘worse’?” but: “What enactments do we see – and what structures stand behind them?”

---

#### 2.7.3 Safeguard clause

1. **`D₀` (ontological dignity) remains untouched.**  
2. **`D` refers always to scenes** (role, context, timing).  
3. **`D` descriptions must be documented and are open to critique.**  
4. **No `D` scores for persons**  
   - only profiles and bands.

The safeguard clause ensures the **D-module** cannot be used as a moral weapon but remains a transparent, criticisable reading framework.

---

#### 2.7.4 Scale logic: banal → extreme (always revisable)

Three-level scale:

1. **banal `D` irritations**  
   – small breaks, everyday incoherences, situational self-neglect.
2. **consistent `D` breaks**  
   – recurring patterns of self-devaluation or degradation of others.
3. **massive/extreme `D` breaks**  
   – ongoing, deep degradation in practice, often under structurally extreme conditions.

Principle:

> **Every level remains revisable as enactment form – the model knows no permanent degradation.**

Classification depends on:

* awareness (**`A`**),
* coherence (**`C`**, especially `C-P/C-N`),
* responsibility (**`R`**, including modulator-informed limits),
* power (**`P`**).

---

#### 2.7.5 Limits of `D₁/D₂` in trauma & neurodiversity

`D₁/D₂` reflect **enactments**, not inner states.

There are situations in which visible `D` enactments **cannot** be meaningfully interpreted as indicators of maturity or dignity without high risk of misinterpretation. These include in particular:

* complex trauma sequelae  
* dissociation  
* severe depressive episodes  
* anxiety disorders / OCD  
* eating disorders  
* ADHD in overload  
* autism spectrum (especially shutdown/overload)  
* chronic exhaustion  
* acute psychological crises  

In such cases:

* **`D₁/D₂` ≠ indicators of maturity or immaturity.**  
  They reflect **burden**, not “character”.
* `D` reading is **paused or tightly framed**:  
  – “`D` is not interpretable here → read structural load (`A`/modulators/`IA`).”
* The **responsibility ceiling remains low**, even if `D` enactments appear chaotic.
* If `D` is considered at all, it is only as:  
  – “signal of burden” –  
  not as a “self-dignity level” or “`D` deficit”.

Short formula:

> **In high-burden clinical or neurodiversity-related states,  
> `D₁/D₂` are not used as maturity parameters – only, if at all, as indicators of strain.**

This protects `D` from implicit pathologising and prevents it from being misused as substitute diagnosis.

**Interim conclusion for 2.7:**  
The **D-module** makes dignity in practice readable without touching `D₀` – and simultaneously builds safeguards against misuse. It shows how people treat themselves and others without evaluating their worth. Before Chapter 3 formulates guardrails and ethics of use, section 2.8 clarifies **language hygiene**: how to speak about `risk`, `harm`, `potential` and `danger` without unintentionally distorting `D₀` or **D-enactments**.

---

### 2.8 **Language hygiene**: `risk`, `harm`, `potential`, `danger`

The previous sections showed how finely the model distinguishes between structure, responsibility and **D-enactments**. Much of this work happens **in language**: what we call `risk`, `danger`, `harm` or “undignified” directly shapes which `A–C–R–P–D` findings we even see. Vague terms not only make texts unclear, they can themselves become a form of **inadult asymmetry**.

To prevent the model from generating ambiguity through unclear wording,
a few central terms are used **technically**:

---

#### 2.8.1 `Risk`, `danger`, `harm`, `potential`

* **`Risk`**  
  = possibility of an unwanted event **before** it occurs.  
  “There is a risk that …” means:  
  *probability × possible severity of harm*, not yet realised.

* **`Danger`**  
  = a **concrete threat state** that exists now – regardless of whether it is perceived.  
  A system may be in danger even if participants deny the risk.

* **`Harm`**  
  = an **occurred** unwanted event:
  injury, loss, breach of trust, irreversible disadvantage.

* **`Potential`**  
  = range of possibilities in both directions:
  opportunities **and** risks, still undecided.

**Language hygiene** here means:

* no mixing of `risk`, `danger` and `harm`;
* no rhetorical inflation (“catastrophe”, “scandal”)  
  at points where the first task is to clarify:  
  – What was the risk?  
  – What danger existed?  
  – What harm actually occurred?

---

#### 2.8.2 **Language hygiene** in the `D` context

With the **D-module** (2.6–2.7) comes another sensitive distinction:

* **“acting without dignity”** is **not** the same as  
  **“being without dignity”** or **“unworthy”**.

The model deliberately speaks of **D-enactments** (high/low dignity enactment),
not of “undignified people”.

Consequences:

* **Adjectives applied to persons** such as “undignified”, “worthless”, “scum”
  count within the model as a **D-break on the side of the observers**.
* When discussing `D`, it must always be clear:  
  – Which concrete action is meant?  
  – In which context?  
  – In which role?

---

#### 2.8.3 General **language hygiene** in the paper

For the entire paper:

* terms are used **mechanically and consistently**,
* psychologising or pathologising labels  
  (“sick”, “disturbed”, “narcissistic”)  
  are avoided unless explicitly justified,
* degrading language (“scum”, “trash people”, “they’re worth nothing”)  
  marks an **`IA` and `D` finding of its own**:  
  – it reveals something about the structure and maturity  
    of the *speaker*, not the ontological worth of the target.

Where normative language is necessary (protected goods, justice, reasonableness),
it is **marked as such** and kept separate from structural description.

In this way, the model remains true to its purpose even linguistically:

> **to analyse maturity and dignity in practice –  
> not agitation in vocabulary.**

**Interim conclusion for 2.8:**  
**Language hygiene** is not a stylistic issue but part of the model logic: those who use `risk`, `danger`, `harm` or dignity imprecisely automatically distort `A–C–R–P–D` findings and easily produce **inadult asymmetries** themselves. On this linguistic basis, Chapter 3 can now clarify **under which conditions** the model may be used at all – and which guardrails are meant to prevent analysis from producing new degradation.

---

### 2.9 Conclusion

Chapter 2 defines the base model of `A–C–R–P–D`:

* **`A` – awareness**
* **`C` – coherence**
* **`R` – responsibility**
* **`P` – power**
* **`D` – dignity in practice**

These axes do not describe persons as types, but make **enactments** readable under concrete conditions. They interact as a **feedback loop**, are shaped by **modulators**, and can be differentiated through the **submodule matrix**.

Before any analysis, **role position**, **publicity level** and the **object of observation** must be clarified. Without this, `A–C–R–P–D` readings risk becoming structurally unfair or `IA`-suspect themselves.

The dignity layer remains strictly bounded:

* `D₀` remains untouched.
* `D₁/D₂` describe dignity in practice.
* `D-I`, `D-B`, `D-R` and `D-P` operationalise visible D-enactments.
* The **D-module** is a protected analytic layer, not a dignity score.

Finally, **language hygiene** is part of the model logic: unclear use of `risk`, `danger`, `harm`, `potential` or dignity language can itself distort analysis.

Thus Chapter 2 provides the technical base of the model:  
a structured vocabulary for reading maturity, asymmetry and dignity in practice —  
without turning enactments into person labels.
