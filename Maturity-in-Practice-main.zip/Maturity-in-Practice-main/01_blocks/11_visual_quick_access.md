---
document_id: MIP-BLOCK-11
title: "Visual Quick Access"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/11_visual_quick_access.md"
status: "split-full-version"
version: "v1"
block_id: "11"
block_role: "canonical core block"
source_chapter: 11
source_chapter_title: "Visual quick access (1-pager, PDF-ready)"
secondary_references: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12]
appendix_references: ["Appendix B"]
claim_mode: "praxeological, condensed, audit-oriented, conflict-practical, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice represented through quick grid; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 11 heading up to immediately before chapter 12 heading"
---

# Maturity in practice — A praxeological anthropology: Visual Quick Access

## 11) **Visual quick access** (**1-pager**, PDF-ready)

After dense theory, we need a surface on which the model becomes **graspable** in everyday life.  
This chapter condenses the core questions of the framework so that they fit on a single page:
for pinboard, whiteboard, regular meetings, or decision rounds.

You can read the **1-pager** as:

* an **emergency brake** (“Are we currently reinforcing inadult asymmetry?”),
* a **short audit** for decisions,
* or an entry point for people  
  who do not yet know the full model.

> **Quick-access boundary:**  
> The **1-pager** is an **emergency brake** and **orientation aid**.  
> It does not replace the full model, the guardrails, or contextual judgement.

---

### 11.1 **Audit checklist** — pre-transmission gate

> **Goal:**  
> Check whether an `IA` analysis is basically robust  
> **before** it goes outward or becomes a basis for decisions.

You can present these five points as a numbered list or as a box:

---

**1. Scope & guardrails – “Am I even allowed to do this here?”**

* ☐ Am I **not** in a **red zone**  
  (no clinical diagnostics, no individual HR decisions, no diagnostics for children,
  no public pillory, no forensic use,
  **no dignity-labelling of persons**)?
* ☐ Is it clear **what** the analysis is supposed to be used for  
  (self-clarification, structural critique, process improvement – not: humiliation, enemy-marking)?
* ☐ Is **minimal maturity in practice** present:
  – Do I really want to see better – including about myself –  
  – or do I just want to “win”?
* ☐ If the **D-module** (praxeological dignity in practice, `D₁/D₂`) is involved:
  – is it clear that **D only describes enactments** (`D-profile`),
    not the overall worth of the human being?

> **Stop rule:**  
> If there is doubt here: **stop the analysis or adjust its purpose.**

---

**2. Roles & publicness – “Who is speaking, who is being looked at, in front of whom?”**

* ☐ Is the role of the **object under consideration** clear  
  (function, level, publicness: private · institutional · public · media)?
* ☐ Is my own role as **observer** clearly named  
  (neutral, involved, leadership, affected person, public)?
* ☐ Has it been considered how high  
  – the **awareness of publicness (`A-P`)**,  
  – the **power to act in public (`P-PU`)**  
  – and, if applicable, the **public dignity dimension (`D-P` – dignity in practice under public conditions)**  
  of the object under consideration realistically are?

> **Mandatory pre-check:**  
> Clarify **roles & publicness** before interpreting or transmitting the analysis.

> Unclear roles = **high risk** of phantom intention and misinterpretation.

---

**3. Structure & score hygiene – “Have I thought `A/M` and `A–C–R–P–D` cleanly?”**

* ☐ Have I looked at `A–C–R–P–D` as **structure-related** –
  not as a character diagnosis?
* ☐ Is there a reasoned **A-score (band)** for the enactment  
  (awareness, coherence, responsibility, action/power to act – with micro-indicators)?
* ☐ Has the **M-score (co-responsibility)**  
  – along knowledge, power, foreseeability, access to alternatives, integration attempt –  
  and with the **ceiling rule** been determined?
* ☐ Is it clear **where** the inadult asymmetry sits  
  (knowing / being able / being allowed / willing; **IA-box (`T–J–TB–R`)**: transparency, justification, time-boundedness, reversibility)?
* ☐ Have I at least roughly seen a **trajectory**  
  (development over time), not just a single still-image judgement?
* ☐ If `D` was used:
  – is there a descriptive **D-profile** (self-treatment, treatment of others, relational dignity in practice),  
  – without a “dignity score” and without labelling entire persons?

> **Score hygiene:**  
> **A-score (band)** — not character diagnosis.  
> **M-score (co-responsibility)** — not guilt.  
> **D-profile** — not dignity score.  
> **IA-box (`T–J–TB–R`)** — not verdict.

> If **A/M**, **IA-box** or **D-profile** are “felt” rather than reasoned → back to structure.

---

**4. Bias, gut feeling, norm assumptions – “What in me is mixing in?”**

* ☐ Have I used my **gut feeling** as a starting signal –
  not as the final judgement?
* ☐ Where might typical **biases** be at work in me  
  (confirmation bias, in-/out-group bias, hindsight bias, loyalty bias)?
* ☐ Which **norm assumptions** do I bring into the analysis  
  (justice, reasonableness, role images, conceptions of dignity) –
  and are they at least **named**?
* ☐ Have I tried to consider at least **one counter perspective**  
  (“How would the same case look from the other side’s point of view?”)?

> Not bias-free, but bias-aware – that is the standard.

---

**5. Consequences & reversibility – “What am I doing with this analysis?”**

* ☐ What will **concretely** happen if this analysis is believed/implemented  
  – for distribution of power, reputation, protection goods, future opportunities?
* ☐ Are the proposed steps  
  – **transparent**,  
  – **justified**,  
  – **time-bound** (review date),  
  – **reversible** (course correction possible)?
* ☐ Is there a clear **proposal** whether structure should be:
  – maintained,  
  – balanced,  
  – or changed/stopped?
* ☐ What possible effects on dignity in practice (`D₁/D₂`) does this analysis have:
  – does it open space for restoration and self-respect,  
  – or does it fix people into entitling roles without a way back?
* ☐ Is it documented when and how we will check
  whether our current reading has **failed**?

> If these questions cannot be answered, the analysis is **not ready to be published** –
> it remains an internal state of thinking, not a basis for decisions.

*Concluding impulse:*

> On one page, this checklist compresses the core promise of the model:
> better one analysis less,
> and in return one that treats roles, power and dignity in practice more fairly.  
> If you stumble several times while going through it,
> that is not failure – it is exactly the moment
> in which maturity in practice begins.

---

### 11.2 **Conflict loop** — four-step orientation, not conflict resolution

Conflicts are the everyday test for the model:  
this is where roles, power, injuries and dignity in practice collide directly.  
The **conflict loop** is the ultra-compact application of the framework
for real disputes – in teams, relationships, organisations.

> **Conflict-loop boundary:**  
> The **loop** gives orientation under pressure.  
> It does not guarantee resolution.

It combines:

* the **System-1 / System-2 micro-tool**,
* the **role** mechanics,
* and the four-criteria box –

into four steps you can remember.

You can present it on the **1-pager** as a graphic or as a numbered list:

> **Mini scene:**  
> A team meeting escalates, accusations are flying.  
> Instead of immediately deciding “who is right”, the **conflict loop** helps
> to stabilise the ground first: **frame**, **roles**, asymmetry, next steps.

---

**Step 1 – STOP & FRAME – “Don’t lash out immediately”**

* briefly stop (internally or out loud: “Stop, let me sort this”),
* **mark the frame**:
  – Where are we (private, professional, institutional, public, media)?  
  – What is this about in one sentence (conflict, request, boundary-setting, decision)?  
  – Which protection goods might be affected
    (health, safety, dignity, subsistence, trust)?

Goal: briefly slow down the automatic System 1
so that awareness (`A`) and coherence (`C`) can come into play at all.

---

**Step 2 – ROLE – “Who is who here?”**

Clarify in 1–2 minutes:

* **What is my role?**  
  – In which function am I currently speaking/acting (private, professional, leadership, facilitation, affected person)?
* **What is the other side’s role?**  
  – Partner, colleague, leadership, client, public, institution …
* **Is that mutually clear?**  
  – If not: **one sentence** to clarify (“I am now speaking as …”).

Goal: increase role awareness (`A-R`),
minimise role vacuum and phantom intentions.

---

**Step 3 – IA-spot – “Where does the unfair asymmetry sit?”**

A short look through the four-criteria lens:

* **What is unequally distributed here?**  
  – knowledge, power, risk, responsibility, interpretive authority?
* This asymmetry:
  – transparent?  
  – justified (which protection good / which legitimate purpose does it serve)?  
  – time-bound (validity frame, review)?  
  – reversible (are there ways back / exit options)?

If at least two points clearly fail
(e.g. intransparent + irreversible):

> **inadult asymmetry (`IA`) identified – here lies the core of the conflict.**

Goal: away from “You are …” → towards “Something in the structure is off here” –
including the question:
“Who here is experiencing **loss of dignity** (shaming, self-devaluation, symbolic entitling)
and who has levers to change that?”

---

**Step 4 – STEP & REVIEW – “Small, reversible next steps”**

On the basis of 1–3:

* Agree on **one small, reversible action**:
  – clarification, trial phase, providing missing information, role clarification, protection measure.
* Clarify responsibility:
  – Who can **realistically** do what (with **A-score** and **M-score** + **ceiling rule** in mind)?
* Set a **review** point:
  – “We will look in X days/weeks to see whether this measure has improved the situation –
    and we are ready to revise our reading then.”

Goal: not to “solve” the conflict perfectly,
but to conduct it in such a way that **later maturity in practice remains possible**
and that no one – also praxeologically – is **irreversibly entitling**.

> **Mnemonic:**  
> First **context** – then **roles** – then **asymmetry** – then **small reversible step**.  
> Those who reverse this order risk
> putting a lot of energy into deciding the wrong thing.

`STOP–FRAME–ROLE–STEP` remains an orientation tool, not a shortcut around the full model.

---

### 11.3 **D-Quick-Grid** (banal → extreme, always reversible)

Many situations contain questions of dignity,
without immediately needing the full **D-profile** card.  
The **D-Quick-Grid** is the compact “legend” for the **D-module** on the **1-pager**:

* It classifies **visible D-enactments** roughly – from banal to extreme.
* It deliberately avoids numbers and person-judgements.
* It is always tied to **role / context / time window** – not to “the person as such”.
* Every level is designed as **state, not essence**: it is about *states*, not *essence*.

> **D-Quick-Grid boundary:**  
> The `D-Quick-Grid` is a **movement tool**, not a label.  
> It shows where dignity in practice stands and what can be minimally improved —  
> never “what a person is”.

> Use:  
> only when `D` guardrails have been checked (chap. 3.5–3.7)
> and it is clear that `D` here should bring **explanation**, not **shaming**.

Preferred wording:

> “This constellation currently shows **level-2 D stress**  
> in this **role / context / time window**.”

Not:

> “This person is level 2.”

---

#### Grid structure (`0–3`)

**Axes:**

* **Level `0–3`**
* each with a short look at:
  – self-enactment (**`D₁` = praxeological self-dignity**, operationalised as `D-I` = dignity in the inner dimension, e.g. self-image/self-talk, and `D-B` = dignity in the bodily dimension, e.g. treatment of body and boundaries),  
  – dealings with others/public (**`D₂` = relational dignity in practice**, operationalised as `D-R` = dignity in relational enactments in the near environment and `D-P` = dignity in practice under public conditions),  
  – consequence in the model (“What to do?”).

---

##### **Level 0 — D not in focus (neutral / unremarkable)**

**Self (`D₁`):**

* everyday fluctuations without a relevant `D` issue:
  – tiredness, messiness, stress,
  – but no stable self-devaluation,
  – no systematic self-neglect.

**Others / society (`D₂`):**

* no noticeable acts of shaming or devaluation,
* occasional clumsiness that can be cleared up.

**In the model:**

* `D` is **not actively** worked on here.
* Focus: awareness, coherence, responsibility, action/power to act (`A–C–R–P`), **IA-box**, **A-score**, **M-score**.
* Note: “No particular `D` issue visible.”

---

##### **Level 1 — banal / everyday drift**

**Self (`D₁`):**

* slight neglect of one’s own needs:
  – too little sleep,
  – chronic stress / “gritting one’s teeth”,
  – ironic self-devaluation (“I’m just dumb”),
* visible tensions between inner sense of worth and behaviour,
  but **not massive**.

**Others / society (`D₂`):**

* rough jokes, occasional insensitive ways of dealing with others,
* milieus where “mild” devaluation is the norm,
* adaptation to such contexts without explicit `D` awareness.

> **Mini scene:**  
> In a team it is normal to greet each other with “Hey, you idiot”.  
> Everyone laughs – but one person notices that they are gradually making themselves smaller by going along.

**In the model:**

* Marking: **“Everyday drift – pay attention”**.
* Recommendations:
  – small self-care experiments,
  – reflect on language (“How do I talk about myself/others?”),
  – context check (milieu vs. alternatives).

---

##### **Level 2 — marked D stress / recurrent self-devaluation**

**Self (`D₁`):**

* persistent overriding of one’s own boundaries,
* chronic self-devaluation:
  – “I am worth nothing”,
  – “I deserve this”,
* withdrawal from self-care (food, hygiene, health) **not only** due to lack of time,
* functional adaptation to entitling environments.

**Others / society (`D₂`):**

* recurrent shaming of others:
  – ridicule,
  – systematic devaluation,
  – deliberate exposure,
* entitling group images (“They are trash”),
* instrumental use of others (e.g. for self-presentation → `D-P` relevant).

**In the model:**

* Level 2 is a **relevant D zone**.
* Here `D` is read **explicitly** in trajectory and structure.
* Consequences:
  – focus on protection and alternatives for affected persons (low **M-score**, high pressure),  
  – clear naming of entitling patterns in actors with a high **M-score**,  
  – think reversible steps towards level 1/0:
    “What action minimally increases `D₁/D₂`? Who has `A` and `M` levers?”

---

##### **Level 3 — hard D breaks / extreme zone**

**Alarm zone — no fine-tuning.**

**Self (`D₁`):**

* self-dehumanising images (“I am nothing”),
* self-harm, extreme neglect,
* enactments that look like a denial of one’s own humanity,
* often a reaction to traumatic or extremely `IA`-loaded contexts.

**Others / society (`D₂`):**

* systematic dehumanisation:
  – torture, rituals of humiliation,
  – dehumanising language/images/practices,
* institutional or media “execution” without way back,
* structural entitling of entire groups.

**In the model:**

* **Alarm zone** – no fine-tuning.
* Consequences:
  – focus on **protection goods** (law, safety, dignity, health),  
  – **M-scores** of responsible actors typically **high**,  
  – **D-profile** here primarily as **documentation of injustice**,  
    not as coaching material.

**Reversibility in the model:**

> Damages cannot be undone, but `D₀` is never abandoned.  
> The analysis asks which structural / role changes can make `D₁/D₂` possible again.

---

##### Usage note for the **D-Quick-Grid**

* The grid does **not** replace a **D-profile** card.
* It serves **quick orientation**:
  – “Roughly where are we – level 0, 1, 2, 3?”
* Every level must be recorded **with role, context and time window**.
* Guiding question after **each** classification:

> **“What would be one small, real action
> that could make this constellation *one* level more dignified –
> and who has `A` and `M` levers for that?”**

The **D-Quick-Grid** is a **movement tool**,
**not a label**:
It shows **where** dignity in practice stands
and **what** can be minimally improved –
never “what a person is”.

---

### 11.4 Conclusion

Chapter 11 compresses the model into **Visual quick access**: a **1-pager** for orientation, interruption and review under practical conditions.

Its tools are deliberately limited:

* the **Audit checklist** is a **pre-transmission gate**, not a verdict mechanism;
* the **Conflict loop** is a four-step orientation aid, not conflict resolution;
* the **D-Quick-Grid** is a **movement tool**, not a label.

Across all three tools, the same boundary holds:

* quick access does not replace the full model;
* guardrails remain active;
* roles and publicness must be clarified;
* `A-score` remains a band, not character diagnosis;
* `M-score` remains co-responsibility, not guilt;
* `D-profile` remains qualitative, not a dignity score;
* `D₀` remains untouched;
* `D₁/D₂` describe dignity in practice only within role, context and time window.

Thus Chapter 11 provides fast access without fast judgement:  
it helps stop, orient, structure and review —  
without turning compressed tools into shortcuts around dignity, responsibility or analysis.
