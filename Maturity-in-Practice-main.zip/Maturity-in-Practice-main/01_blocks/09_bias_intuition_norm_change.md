---
document_id: MIP-BLOCK-09
title: "Bias, Intuition and Norm Change"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/09_bias_intuition_norm_change.md"
status: "split-full-version"
version: "v1"
block_id: "09"
block_role: "canonical core block"
source_chapter: 9
source_chapter_title: "Bias, Intuition & Norm Change"
secondary_references: [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, bias-aware, intuition-bounded, norm-sensitive, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice culturally situated; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 9 heading up to immediately before chapter 10 heading"
---

# Maturity in practice — A praxeological anthropology: Bias, Intuition and Norm Change

## 9) **Bias, Intuition & Norm Change**

The model pretends that reality can be seen **more clearly**  
when `A–C–R–P–D` are examined structurally.  
At the same time, it is obvious:

* No one perceives without distortion.
* No one decides purely rationally.
* Norms themselves shift over time.
* Ideas of **dignity** are historically, culturally and biographically shaped.

This chapter deliberately marks the **limits of our view** —  
and thus the conditions under which the model can be used in an adult way:

* including the danger that `A–C–R–P–D` is used  
  to absolutize one’s **own** dignity concepts.

> **What we must concede to ourselves so the model becomes a learning tool — not a weapon.**

This is not appendix material.  
**Bias**, **intuition** and **norm change** are method components:

* **analysis constraints**,
* guardrails against model absolutism,
* requirements for D-reading,
* requirements for responsible application.

---

### 9.1 **Bias**: unavoidable distortions

**Bias** here means:

> **systematic, recurring distortions in perception, evaluation and memory**  
> that cannot be explained by isolated errors.

> **Bias rule:**  
> **Bias** is not an exception, but baseline noise.  
> **Bias-awareness** is part of `A` — **awareness**.

Relevant **bias risks** in the model’s context:

#### Bias risk — **confirmation bias**

* we search for what confirms our starting hypothesis,
* we overlook contradictory signals,
* danger for dignity-reading: we “find proof” that someone is “immature” or “undignified”  
  instead of seeing ambiguity.

#### Bias risk — **hindsight bias**

* afterwards, many things appear “predictable,”
* reality is smoothed retroactively (“of course it was obvious…”),
* predictability is overestimated → **M-score** tends to rise,

> **Hindsight risk:**  
> inflated predictability → inflated `M-score`

* danger for dignity: affected persons are **retrospectively shamed**  
  by attributing insights they could not have had.

#### Bias risk — **status quo / loyalty bias**

* existing structures feel “normal,”
* loyalties in organizations, families, milieus protect old patterns from critique,
* danger for dignity: degrading practices become “just how things are,”  
  dignity claims appear oversensitive.

#### Bias risk — **halo / horn effects**

* one trait (charismatic, likable, competent, “on our side”)  
  colors the whole assessment,
* maturity is “granted” or systematically denied,
* danger for dignity: favourites get a **dignity bonus**,  
  others a **dignity penalty**.

**dignity-bias effect:** “dignity bonus” / “dignity penalty”

#### Bias risk — **in-group / out-group bias**

* “our” people are judged more generously,
* “the others” more harshly,
* identical enactments receive different A- and M-scores  
  and opposing dignity interpretations (“courageous” vs. “antisocial”).

*Mini-vignette:*

> A team evaluates a conflict.  
> A beloved colleague’s harsh tone is seen as “an unusual slip,”  
> a disliked colleague’s identical tone as “proof of her true character.”  
> Structurally identical enactment — the bias distribution decides the A and dignity reading.

For the model this means:

* **Bias** is **not an exception**, but baseline noise.
* It cannot be eliminated, but it can be **marked**:

  * Where might I be seeking confirmation?
  * Where am I turning “in hindsight visible” into “you should have known”?
  * Where am I protecting structures I depend on?
  * Where am I using dignity readings to stabilize group or role images?

Thus:

> **Bias-awareness is part of `A` — awareness.**  
> Ignoring it means working ideologically, not praxeologically,  
> especially where dignity in practice is at stake.

The next section (9.2) addresses a special form of “internal data”: **intuition**.

---

### 9.2 **Intuition**: enemy or sensor?

**Intuition** here refers to:

* fast, dense impressions,
* deep condensation of experience, implicit knowledge,
* often not yet articulable.

In the model, **intuition** is **neither** enemy **nor** oracle.

Praxeological stance:

> **Intuition is a `sensor` and `trigger` — not a judge.**  
> **Intuition is hypothesis, not proof.**

**When is intuition valuable?**

* in **danger perception** (early warning signals: “something is off”),
* in **resonance checks** (“the claim doesn’t match the effect”),
* with **people and situations known for a long time**,  
  where implicit patterns already exist,
* with subtle dignity signals:  
  – “This feels degrading even though no one raises their voice,”  
  – “Someone is being diminished, even if framed as a joke.”

**When is intuition risky?**

* in **complex structural questions** (law, politics, organization),
* in **unfamiliar milieus** and cultures,
* in situations where one’s own issues are highly active  
  (hurt, fear, over-identification),
* when intuition is translated directly into **dignity judgments**:  
  – “He’s simply undignified,”  
  – “You can’t take someone like that seriously.”

*Mini-vignette:*

> In a meeting someone instantly senses: “The tone is wrong.”  
> Intuition signals: something is drifting toward degradation.  
> Instead of concluding “the boss is toxic,”  
> the model asks:  
> “What exactly is happening between role, power, language and dignity enactment?”

The model proposes not “emotion vs. rationality,” but division of labour:

* Intuition may **trigger** the `IA` analysis (“Look closer here!”).
* The **analysis** (`A–C–R–P–D`, **IA-box**, `A/M`, `RVR(t)`) structures the issue:  
  – What exactly is disturbing?  
  – Is it real `IA` or degradation — or my own story?  
  – Which role, responsibility, power and dignity dynamics are present?

Key maxims:

> **Intuition may start the analysis —  
> but must not end it.**

and, regarding dignity:

> **Intuition may sense a dignity violation —  
> but must not alone judge a person’s dignity.**

Thus intuition is not interference,  
but an input channel that must be **translated explicitly**  
before decisions or dignity profiles are drawn.

---

### 9.3 **Norm change**: a moving target

**Norm change** means: norms are not static.

* What counts as “normal,” “acceptable,” “fair,” or “dignified”  
  shifts over time — culturally, generationally, discursively.

This creates a challenge:

> **How can a model assess maturity and dignity in practice  
> when norms constantly shift?**

The model’s answer:

1. It measures primarily **structural features** (`A–C–R–P–D`, **IA-box**, **M-score**),  
   not the content of specific norms.

   – Transparency can be examined across different norm landscapes.  
   – Justification, time-boundedness, reversibility do not depend  
     on whether a norm is “progressive” or “conservative.”  
   – Dignity is not measured as “correct attitude,”  
     but as **quality of enactment** relative to available options.

2. It treats **norm change** as **part of the analysis**:

   – Which norms were **plausible then**, given knowledge and discourse at the time  
     (including dignity concepts)?  
   – Which norms apply **now** — and why?  
   – Who claims that “now” something “always should have been” unacceptable?  
   – Where do we confuse a **symbolic shift** with an actual shift  
     in dignity practices (treatment of affected persons, alternatives, reversibility of stigma)?

3. It guards against two traps:

   * **Overwriting the past with current norms**  
     — condemning everything before (“how could they…”)  
       without acknowledging missing alternatives.

   * **Freezing the present with past norms**  
     — dismissing critique as “oversensitive,”  
       ignoring new knowledge, protections and dignity dimensions.

4. It marks that **dignity readings (`D₁/D₂`) are culturally situated**:

   – Self-sacrifice may be seen as a **source of dignity** in one context,  
     and a **`D₁` violation** in another.  
   – Direct confrontation may read as **`D₂` strengthening** in one group  
     (clear boundaries), and as **“disrespectful”** in another.  
   – Self-care may appear mature, selfish or necessary,  
     depending on the culture.

   Therefore every dignity interpretation in the model is accompanied by  
   **role, context, milieu and norm background**.  
   `D₁/D₂` do not claim a universal doctrine of dignity — only:

   > “How does this enactment appear **from this perspective**,  
   > with this cultural lens named?”

> **D-reading question:**  
> From which **normative position** is `D₁/D₂` being read?

An adult use:

* acknowledges that norms — including **dignity concepts** — **move**,
* still checks whether, within a historical or cultural context,  
  **maturity in practice** was possible:

  – `A` — Was available knowledge used?  
  – `A-P`, `D-R`, `D-P` — Were affected persons heard?  
  – `P`, **M-score** — Were unused decision paths available?  
  – **ceiling rule** — Did people have real alternatives?  
  – `D₁/D₂` — From which **normative position** is dignity read?

> **Cultural-lens rule:**  
> “I do not know what it feels like to be you in your culture —  
> I describe only what I see in the enactment  
> and name my own lens.”

> **Norm change is not an obstacle; it is subject matter.**

The model reveals **who** shifts norms — including dignity images —  
in which direction,  
with which structural tools,  
and with which `IA` patterns and dignity effects.

This sets the stage for Chapter 10:  
There the main counterarguments are presented,  
and the model must measure itself against its own standards.

---

### 9.4 Working with the model: **protocol and meta-attitude**

The previous sections showed how strongly **bias**, **intuition** and **norm change** color every analysis.  
If these factors are only briefly acknowledged, they appear as background noise —  
not as part of the actual work.

To integrate **bias**, **intuition**, **norm change** and **dignity readings**  
(self-/relational dignity interpretations) into the method, two things are needed:

1. **Documentation**
2. **Meta-attitude**

---

#### Required component 1 — **Documentation**

In the Case-Lens process we mark:

* Where did **intuition** enter?
* What **bias risks** do I/we see?
* Which **norm assumptions** (explicit/implicit) steer the analysis?
* Which **dignity readings (`D₁/D₂`)** do I use:  
  – What do *I* call dignified/degrading — and from which cultural/biographical lens?

#### **Meta Notes block**

A simple **Meta Notes block** at the end of the scorecards is enough:

* **Bias risks:** “Likely personal biases: …”
* **Norm assumptions:** “Norm assumptions influencing this analysis: …”
* **Intuition checked yes/no:** “Intuition: … / checked afterwards? yes/no.”
* **Dignity reading:** “Which enactments *I* experience as (un)dignified —  
  and could someone else see differently?”
* **Possible alternative interpretations:** “What could be read differently from another situated perspective?”

*Mini-vignette:*

> A team enters a contentious decision into the Case-Lens.  
> At the end, someone notes:  
> “Intuition: X is unfair — high loyalty bias, I dislike X.”  
> This does not automatically change the conclusion,  
> but it records that the analysis does **not** arise from neutrality,  
> but from a **situated perspective**.

Thus:

> **Applying the model is itself a practice — not a neutral observer stance.**

---

#### Required component 2 — **Meta-attitude**

**Meta-attitude** means:

* **no claim to final truth**,
* **willingness to revise analyses**,
* active search for **counterexamples** and **alternative perspectives**,
* **explicit invitation to critique** (see Chapter 10),
* awareness that my **dignity readings**  
  are never a person’s “true worth,”  
  but an interpretation of an **enactment**.

In short:

> The model is only as adult  
> as the people who treat their own distortions,  
> norm assumptions, and dignity concepts  
> as **part** of the analysis.

> **Meta-guardrail:**  
> Without meta-attitude, dignity language falls back into moral labeling.

And:

> Those who use dignity (`D₁/D₂`) without this **meta-attitude**  
> quickly fall back into  
> exactly what the model was built to avoid:  
> moral labeling instead of praxeological understanding.

Logical consequence:

> The next chapter gathers the main counterarguments —  
> and tests the model against its own claims.

---

### 9.5 Conclusion

Chapter 9 defines the epistemic self-discipline layer of the model.

**Bias**, **intuition** and **norm change** are not soft commentary.  
They are method components and analysis constraints:

* **bias** is baseline noise, not exceptional failure;
* **bias-awareness** is part of `A` — awareness;
* **intuition** is a `sensor` and `trigger`, not a judge;
* **intuition** is hypothesis, not proof;
* **norm change** is not an obstacle, but subject matter;
* **dignity readings** must name their **normative position**.

This protects the model from becoming a morality machine.  
`D₀` is never measured.  
`D₁/D₂` remain culturally situated, qualitative practice descriptions — not scores and not universal dignity diagnoses.

The practical consequence is the **Meta Notes block** and the **meta-attitude**:

* document bias risks,
* document norm assumptions,
* document whether intuition was checked,
* document the dignity reading and possible alternative interpretations.

Thus applying the model remains itself a practice:  
situated, revisable, critique-ready, and bound to guardrails.