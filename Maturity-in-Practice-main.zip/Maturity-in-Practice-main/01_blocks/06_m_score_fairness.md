---
document_id: MIP-BLOCK-06
title: "M-Score, Ceiling Rule and Fairness"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/06_m_score_fairness.md"
status: "split-full-version"
version: "v1"
block_id: "06"
block_role: "canonical core block"
source_chapter: 6
source_chapter_title: "M-score – ceiling rule & fairness"
secondary_references: [1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, responsibility-distributive, ceiling-rule-bound, victim-blaming-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice handled separately in D-profile; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 6 heading up to immediately before chapter 7 heading"
---

# Maturity in practice — A praxeological anthropology: M-score, Ceiling Rule and Fairness

## 6) **M-score** – **ceiling rule** & fairness

In every complex case, a crucial question eventually arises:  
**“Who carries how much responsibility for the whole?”**  
Not all participants have the same overview, agency, alternatives –  
yet harm is often distributed as if all had equal responsibility.

The **M-score** complements the **A-score** with a second axis:

> **`A` = maturity in practice.**  
> **`M` = shared responsibility for the whole.**

It highlights:

* who had structural **leverage** (power to act, knowledge, alternatives, foresight),  
* who was primarily **affected** and had little real agency.

> **M-score boundary:**  
> `M` describes **shared structural responsibility**, not guilt, fault, blame, or moral worth.

And:  
**Shared responsibility is not a dignity verdict.**  
`D₀` (ontological dignity) remains untouchable;  
`D₁/D₂` (dignity in practice) appear in the **D-profile**, not in the **M-score**.

The **M-score** is not **blame coding**, not moral stamping –  
but a tool for **fair distribution of responsibility**:  
Who had which decision space, which information, which mandate –  
and where must the “ceiling” for maturity and dignity readings be placed (**ceiling rule**)  
so that affected persons are not doubly burdened?

Formal notation:

> **`M(A)` = shared responsibility of actor `A`.**  
> Here, `A` denotes an actor placeholder, not the `A` axis for awareness.

**Mini-vignette:**  
A student violates a school rule to help a friend in distress.  
A teacher responds formally correctly but rigidly; the school leadership has discretion but does not use it.  
The **M-score** asks:  
Who had which **shared responsibility** for the situation –  
and who could realistically have changed the trajectory?  
It prevents treating the student as the main responsible party  
while institutional levers remain invisible.

Chapter 6 then:

* operationalises the **M-score** (dimensions, scales, examples),  
* links it to the **ceiling rule** (how `A`- and `D`-evaluations are limited from above),  
* and situates it alongside the **A-score** and the **D-profile**,  
  so that maturity, **shared responsibility** and dignity in practice  
  can be read together but **not conflated**.

---

### 6.1 **M-score** (**shared responsibility**, not fault or guilt)

Once the **A-score** clarifies **how maturely** someone acts in a concrete situation,  
a second question remains:

> **“How much realistic shared responsibility does this position carry  
> for the course and consequences of the situation?”**

The **M-score** shifts the focus from the person to the **leverage within the system**:  
Who had knowledge, power and alternatives – and who was primarily affected?  
It evaluates **structures and positions**, not personal worth.

The **M-score** is strictly decoupled from `D₀/D₁/D₂`:

* **`D₀` – ontological dignity** (the unrevocable value of the person) remains **outside** all metrics.  
* **`D₁/D₂` – dignity in practice** (self-dignity in practice and relational dignity in practice),  
  operationalised through `D-I`, `D-B`, `D-R`, `D-P`,  
  are described in the **D-profile**, not in the **M-score**.

The **M-score** answers:

> **“Who could realistically have acted differently –  
> with which information, and at what cost?”**

---

#### 6.1.1 Five factors of **shared responsibility**

To avoid assigning **shared responsibility** “from the gut,”  
the model works with five structural factors:

1. **Knowledge** (`A` – awareness)  
   – What information was available?  
   – Could the situation realistically be understood?  
   – Were there warnings, expertise, indications?

2. **Power / control** (`P` – power to act)  
   – What real levers were available?  
   – Could the trajectory have been changed, limited or stopped?  
   – Or was the position dependent, constrained, overruled?

3. **Predictability**  
   – Were consequences recognisable for an ordinarily informed person?  
   – Did it require specialist knowledge?  
   – How high was situational uncertainty?

4. **Access to alternatives**  
   – Were there **real** alternatives, or only theoretical ones?  
   – Could one exit or refuse **without existential cost**  
     (housing, status, residency, safety)?  
   – Could available support realistically be found and used?

5. **Serious integration attempt**  
   – Were risks named and mitigated?  
   – Were other perspectives considered?  
   – Were alarms taken seriously – or dismissed?

**Mini-vignette:**  
A team leader repeatedly receives indications that a policy overloads staff.  
They have overview, decision power, alternatives (restructuring, reprioritisation),  
and time to review the issue – but do not act.  
→ **High M-score:** knowledge, leverage, predictability and alternatives are clearly present.

By contrast, a single employee trying to contain harm with little agency:  
→ **Low M-score** – even if their behaviour appears chaotic (mixed **A-score**).

---

#### 6.1.2 High vs. low **M-scores**

The five factors are not mechanically calculated;  
they serve as a framework to distinguish **high** from **low** **shared responsibility**.

**High `M` = high structural responsibility / leverage**  
**Low `M` = low responsibility viability / primarily affected**

**High M-score (`7–9`)** typically means:

* high knowledge (`A` high),  
* significant levers (`P` high),  
* predictable consequences,  
* accessible alternatives,  
* weak, half-hearted or late integration attempts.

→ **substantial structural shared responsibility**.

Examples:

* Leadership knows risks but does not respond.  
* An institution knows of misconduct but remains formalistic or deflects.  
* Powerful actors benefit while risks are systematically shifted downward.

**Not:** a moral flaw or dignity reduction.  
Ontological dignity (`D₀`) remains untouched.

---

**Low M-score (`0–3`)** means:

* little knowledge,  
* minimal leverage,  
* low predictability,  
* few or no real alternatives,  
* recognisable attempts to cope or protect oneself.

→ **primarily affected, minimally responsible**.

Typical cases:

* children and adolescents in dependency structures,  
* people in existential economic, legal or social dependencies,  
* powerless employees in rigid hierarchies,  
* laypersons facing complex systemic risks.

A low **M-score** explicitly protects against **victim blaming**:  
That someone acts immaturely under pressure (low `A`) or shows chaotic dignity enactments (`D₁/D₂`)  
does not make them primarily responsible for a system overwhelming them.

---

#### 6.1.3 **M-score** as structural distribution, not character judgment

Two protective axioms mark the boundary:

> **Personal worth (`D₀` – ontological dignity) lies outside all metrics.**  
> `A` and `M` describe enactment and structure – not “the person.”

> **`M` is shared responsibility, not guilt.**  
> It concerns *shares*, not condemnation or degradation.

Praxeological consequences:

* Affected individuals may have a **low `M`** even if their behaviour is chaotic.  
  Their dignity enactments (`D₁/D₂`) are assessed in the **D-profile** – never via `M`.
* Organisations or leadership roles may have a **high `M`**,  
  even if individuals acted “legally”:  
  they had the structural capacity to prevent, limit, protect or make transparent.

**Mini-vignette:**  
A municipality sells critical infrastructure to an investment firm.  
Political decision-makers were informed, had alternatives, ignored warnings → high `M`.  
Residents later living with the consequences had no structural leverage → low `M`,  
even if they voted “badly” or reacted poorly under stress.

The guiding formula of the entire model:

> **“Recognise the enactment – not the person.”**  
> `A` and `M` read enactments and structures;  
> ontological dignity (`D₀`) remains untouched.

Thus, the **M-score** is not a moral tribunal but a tool for **fair distribution of responsibility** –  
redirecting attention from “Who was noisy and visible?” to “Who had which lever?”

---

### 6.2 The **ceiling rule** (protection against **victim blaming**)

Once **shared responsibility** can be scaled, a risk emerges:  
With enough creativity, almost anyone affected can be retroactively framed as “responsible” –  
“you should have known,” “you could have left,” “you should have acted differently.”

This is precisely what the **ceiling rule** prevents.  
It is the built-in **dignity protection** of the **M-score**:

> **Ceiling rule:**  
> `predictability ≈ 0` or `access to alternatives ≈ 0` → `M ≤ 4`

In short:

> **No high shared responsibility without predictability and real options.**

Thus, where people are structurally kept in the dark or effectively trapped,  
the model must **not** retroactively make them responsible for the system engulfing them.

---

#### 6.2.1 `Predictability ≈ 0`

**Predictability** is effectively zero when:

* essential information was **not accessible**,  
* specialist knowledge would have been required that actors **could not** realistically have,  
* risks were deliberately downplayed or obscured,  
* even experts could not reliably foresee outcomes.

Examples (kept abstract):

* complex financial or technical products only experts can assess,  
* internal risk reports that are hidden,  
* systemic effects whose collapse dynamics can only be reconstructed afterwards.

In such contexts, it would be praxeologically **unfair** to ascribe high **shared responsibility**  
just because behaviour appears “reckless,” “naive,” or “careless.”  
They simply could not foresee the consequences.

---

#### 6.2.2 `Access to alternatives ≈ 0`

**Access to alternatives** is effectively zero when:

* **leaving** the situation is not realistically possible without severe endangerment  
  (housing, residency, safety, health, children’s wellbeing),  
* dependencies (economic, legal, emotional, institutional) are so strong  
  that “just leave” is **not a real option**,  
* theoretical avenues exist but are **practically inaccessible**  
  (no money, no networks, language barriers, threats, legal constraints).

**Mini-vignette:**  
A person lives in a relationship that becomes increasingly violent.  
They are financially dependent, caring for small children, have insecure residency, no network.  
Formally, support services exist – practically, exit is existentially dangerous.  
→ `Access to alternatives ≈ 0` → **M-score** remains capped, regardless of how “irrational” staying appears from outside.

The **ceiling rule** applies **categorically**:

> **Those with no real alternative cannot receive a high M-score –  
> even if their behaviour appears “unwise” to outsiders.**

---

#### 6.2.3 Function of the **ceiling rule**

The **ceiling rule** fulfils three central functions:

**Function 1 — protection against victim blaming**

* People in coercive or overwhelming conditions are not reframed  
  as primarily responsible for structures they did not create.  
* Their ontological dignity (`D₀`) is protected,  
  and their dignity enactment (`D₁/D₂`) is **not** conflated with systemic responsibility.

**Function 2 — protection against retroactive over-demand**

* Prevents treating overwhelmed, under-informed or dependent persons  
  as if they had the same responsibility as informed, powerful actors.  
* “You should have acted differently” is tied back to:  
  “Did you have knowledge? Did you have levers? Did you have real options?”

**Function 3 — correct responsibility level**

* The model forces attention toward **knowledge and power centres**,  
  not toward those already bearing the harm.  
* High **M-scores** cluster where structural **control, overview and alternatives** existed.

Guiding sentence:

> **High M-scores belong where knowledge, power, predictability and access to alternatives are high –  
> not where people are already suffering the consequences.**

Thus, the **ceiling rule** is a cornerstone of the model’s dignity-protection logic.  
It prevents the model from becoming a refined tool for old patterns of “your fault”  
and **retroactive degradation**.

It also prepares the ground for the next question:  
How do **A-score** and **M-score** **interact** once they are separately determined?

---

### 6.3 Interaction of **A-score** & **M-score**

**A-score** and **M-score** are determined **separately** –  
but their interaction reveals **where** a system stands and **which interventions** make sense.

Core idea:

> **`A` describes maturity in practice (`A–C–R–P`) in a situation.**  
> **`M` describes structural shared responsibility for the overall trajectory and consequences.**

When the **D-profile** is added  
(`D₁/D₂` as dignity in practice – operationalised through `D-I`, `D-B`, `D-R`, `D-P`),  
a three-dimensional reading emerges:

* **How mature was the enactment?** (`A`)  
* **How much responsibility did this position carry?** (`M`)  
* **How was dignity handled – self- and other-directed?** (**D-profile**)

> **Do not conflate:**  
> `A` = maturity in practice.  
> `M` = shared structural responsibility.  
> `D-profile` = dignity in practice.

In the `A–M` space, four baseline constellations appear.

---

#### Quadrant 1 — `A high / M high`

* **High maturity**,  
* **high shared responsibility**.

Typical:

* leadership, institutions, decision bodies with strong leverage  
  who see risks, know alternatives, and act deliberately.

Interpretation:

* **Positive:**  
  `A high / M high` = significant responsibility is exercised **maturely**.  
  Often accompanied by **high dignity enactment**:  
  fair communication, protection of weaker parties, transparent corrections.

* **Critical:**  
  If degrading practices continue **despite** high awareness and high responsibility,  
  the **D-profile** becomes sharp:  
  degradation is then not “accidental,” but part of a responsible enactment.

---

#### Quadrant 2 — `A high / M low`

* **Mature enactment**,  
* **low responsibility** for the broader system.

Typical:

* employees acting responsibly in poor structures,  
* affected people who remain fair, clear and constructive despite little agency,  
* individuals making careful decisions under tight constraints.

Interpretation:

* The model allows such enactments to be **recognised**  
  without overburdening these actors with responsibility they do not have.  
* `A high / M low` = **adultness under adverse conditions**.  
* **D-profile** often shows consistent self-respect and respect for others (`D₁/D₂` relatively high)  
  despite minimal power to act.

---

#### Quadrant 3 — `A low / M high`

* **Low maturity**,  
* **high responsibility**.

Typical:

* powerful roles acting impulsively, cynically or negligently,  
* well-informed actors deflecting or offloading risks,  
* organisations benefiting from `IA` patterns while blocking correction.

Interpretation:

> **IA risk zone:** `high leverage + low maturity`.

Interventions target:

* limiting or framing power (`P`),  
* redistributing responsibility (`R`),  
* increasing awareness (`A`) and coherence (`C`),  
* and – regarding dignity – reducing degrading practices and communication.

---

#### Quadrant 4 — `A low / M low`

* **Low maturity**,  
* **low responsibility**.

Typical:

* overwhelmed, under-informed, dependent participants,  
* people reacting chaotically or self-destructively in crises,  
* affected individuals inside systems built and controlled by others.

Interpretation:

* The model supports a **dual view**:

  * **Yes**, behaviour may be immature or destructive (`A` low).  
  * **No**, this does **not** imply high responsibility (`M` low).

* Instead of blaming, the model asks:  
  **Who had knowledge, leverage and alternatives – and how did they act?**

The **D-profile** may reveal:

* **self-devaluation** (“Everything is my fault”) as a response to structural `IA`,  
* or **protest enactments** (“Then I’ll behave like trash”),  
* without permitting any moral devaluation of the person.

---

#### 6.3.5 Practical use of `A` & `M` (with **D-profile**)

In practice:

* The **A-score** indicates:  
  → **How mature was the enactment?**
* The **M-score** indicates:  
  → **How much structural responsibility existed?**
* The **D-profile** indicates:  
  → **How dignity was enacted – toward self and others (`D₁/D₂`).**

The combination helps tell:

* where **learning and development** are needed (`A` focus),  
* where **structural change or power limitation** is necessary (`M` focus),  
* where **protection** should come first (low `M`, high harm),  
* where dignity enactment is especially critical  
  (e.g. systematic degradation despite high `A` and high `M`).

Closing formula for this chapter:

> **A measures how we act.  
> M measures how much of the overall trajectory we carry.  
> D shows how we handle dignity – ours and others’.**  
> From all three follow where we must learn, limit –  
> and where we must protect first.

Thus the model’s coordinate system becomes complete:  
maturity, **shared responsibility** and dignity in practice can be described separately  
while still being thought **together** –  
as the foundation for the following chapters, where the model is applied to concrete scenes.

---

### 6.4 `D` and **shared responsibility**

*(Self-devaluation vs. structural responsibility)*

With the **D-module** (`D₁/D₂`), another tension becomes visible:

> **The more wounded people are, the more they tend to devalue themselves –  
> yet precisely there, their M-score is often lowest.**

The model intentionally separates:

> **Do not conflate:**  
> `A` = maturity in practice.  
> `M` = shared structural responsibility.  
> `D-profile` = dignity in practice.

**Self-devaluation** (“It’s all my fault”) is therefore **not** evidence of high `M`,  
but a **dignity phenomenon** (a `D₁/D₂` pattern in practice) under pressure.

> **Self-devaluation does not raise `M`.**

---

#### 6.4.1 **Self-devaluation** in the `D` framework

On the dignity level, **self-devaluation** can take different forms:

* **`D₁` – self-dignity in practice (inner orientation)**  
  – “I am worthless.”  
  – “I only failed.”  
  – “I deserve what’s happening to me.”

* **`D₂` – relational dignity in practice (`D-R/D-P`)**  
  – “If you treat me like trash, I’ll live like trash.”  
  – “If the world is like this, it’s not worth caring for myself.”

In both cases, we see:

* a **break in self-enactment** (low `D₁/D₂`),  
* but **no** automatic increase in:

  – knowledge (`A`),  
  – power or agency (`P`),  
  – access to alternatives,  
  – structural interpretive authority.

On the contrary:

* people experiencing deep **self-devaluation** often have:

  – low `C-P` / `P-S` (coherence in power contexts, social agency),  
  – limited access to alternatives,  
  – high harm with **low M-score**.

Thus the model reads **self-devaluation** primarily as:

> **A wound marker** – not as evidence of high structural responsibility.

---

#### 6.4.2 Why **self-degradation** does *not* produce a high **M-score**

The **M-score** does not follow a person’s inner sense of guilt.  
It follows the **ceiling parameters**:

* What could someone **realistically know** (awareness, `A`)?  
* What **role and power** did they actually have (coherence in power contexts, `C-P`; social/public agency, `P-S/P-PU`)?  
* How high were **predictability** and **access to alternatives**?  
* Did the person demonstrably attempt **integration or correction**?

**Self-degradation** automatically fulfils **none** of these criteria:

* Someone who “makes themselves small” does **not** thereby gain additional responsibility for the system.  
* Someone who internally “takes all the blame” does **not** thereby increase their formal or material **shared responsibility**.  
* On the contrary: **self-devaluation** may indicate that someone is carrying **excess subjective guilt** while having **objectively low `M`**.

This yields three strict rules:

1. **A `D`-break ≠ an increase in `M`**

   – If someone degrades themselves (e.g., constant self-devaluation, taking all blame),  
     this appears in the **D-profile** –  
     but the **M-score** remains tied to **role, knowledge, power, alternatives**.

2. **High subjective guilt → `M`-check, not `M`-increase**

   – Intense self-accusation is a reason to check the **M-score** **carefully**:  
     “Does this person actually carry the structural responsibility they believe they do?”  
   – Often the result is: **`A` and `D` are the issues**, `M` remains low.

3. **Structural responsibility stays at the top – even when those below self-devalue**

   – If affected people devalue themselves, this does **not** reduce the responsibility  
     of those who truly hold the levers (high `M`).  
   – In fact, it is an `IA` signal when powerful actors (high `M`) use the self-devaluation of those below  
     as “proof” that they themselves did little wrong.

---

#### 6.4.3 `D`, `M` and protection – practical implications

In practice this means:

* **People with low `M` but high `D`-damage**  
  – are primarily **targets of protection**, not of accusation.  
  – Interventions focus on:

    * relieving them of internalised pseudo-guilt,  
    * strengthening `D₁` (self-care, self-respect, boundary protection),  
    * making **structural responsibility** visible elsewhere (high `M`).

* **People with high `M` and outward `D`-breaks**  
  – e.g., systematic degradation of others while holding significant power –  
  – become the focus of **responsibility and structural work**:

    * limiting or framing power to act (`P`),  
    * reviewing asymmetries (**IA-box**),  
    * clearly naming responsibility,  
    * re-anchoring behaviour in protection and dignity requirements.

Mnemonic for the interaction of `A`, `M` and `D`:

> **Self-degradation shows `D`-damage, not high `M`.**  
> **Structural responsibility remains where knowledge, power and alternatives lay –  
> even when someone below “takes all the blame.”**

Thus, the model’s triad becomes clear:

* **`A`** – How mature is the enactment?  
* **`M`** – How strongly does this position carry the overall trajectory?  
* **`D-profile`** – How is dignity enacted – one’s own and that of others (`D₁/D₂`)?

---

### 6.5 Conclusion

Thus, the model’s triad becomes clear:

* **`A`** – How mature is the enactment?  
* **`M`** – How strongly does this position carry the overall trajectory?  
* **`D-profile`** – How is dignity enacted – one’s own and that of others (`D₁/D₂`)?

The **M-score** protects responsibility reading from becoming blame coding.  
The **ceiling rule** protects affected persons from victim blaming and retroactive over-demand.  
The **D-profile** remains separate: self-devaluation, self-degradation or dignity strain do not increase `M`.

Chapter 6 therefore completes the fairness layer of the model:  
maturity, shared structural responsibility and dignity in practice can be read together,  
but must not be conflated.
