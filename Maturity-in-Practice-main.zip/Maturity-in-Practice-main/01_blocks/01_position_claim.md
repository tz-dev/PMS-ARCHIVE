---
document_id: MIP-BLOCK-01
title: "Position and Claim"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/01_position_claim.md"
status: "split-full-version"
version: "v1"
block_id: "01"
block_role: "canonical core block"
source_chapter: 1
source_chapter_title: "What this is about (position and claim)"
secondary_references: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, structural, dignity-protective, non-diagnostic"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice; optional module; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 1 heading up to immediately before chapter 2 heading"
---

# Maturity in practice — A praxeological anthropology: Position and Claim

## 1) What this is about (position and claim)

In public discourse, words like “mature”, “immature”, “toxic”, “irresponsible” are thrown around a lot – mostly without clarifying **what** they are meant to describe. Sometimes “mature” refers to a calm tone of voice, sometimes to the ability to tolerate conflict, sometimes merely to agreement with one’s own moral stance. At the same time, real people and situations are negotiated under increasingly complex conditions: social media, organisational logics, law, economics, psychological burdens.

We do not have direct access to inner life, motives, or “true character”. What can be observed are **enactments**: decisions, communication, dealings with power, reactions under pressure. Yet evaluations are often conducted as if one could infer the “worth” of a person directly from a few impressions.

Let us imagine two scenes: In a team meeting, a leader calls for “radical openness”, but critical contributions have tangible negative consequences for employees. Elsewhere, a person is considered “difficult” because they repeatedly point to a blind spot in a procedure. In both cases, everyday diagnoses would quickly land on persons (“too sensitive”, “too authoritarian”) – the **inadult asymmetry (IA)** model instead tries to read the **structures and enactments** that sustain these situations.

This paper therefore does not treat maturity as a character trait, but as a **praxeological phenomenon**: it is interested in what people **actually do under real conditions** – with their awareness, with their coherence between word and deed, with how they carry or shift responsibility, with their use of power, and with their handling of dignity in everyday life.

Chapter 1 sets the frame for this: what kind of “maturity” is meant here, what role dignity plays, on which levels the model reads, and why it explicitly offers **no** closed worldview but rather a **toolbox** for concrete situations.

---

**Maturity in practice** means:
not what someone **claims** to be –
but what someone **actually does under conditions**.

The model describes maturity as something that shows itself:

* **in action** (not in self-images),
* **under constraint** (pressure, costs, side effects),
* **in dealing with asymmetries** (power, knowledge, dependency),
* **in word–deed coherence** (keyword: “walk” instead of “talk”),
* **in how one deals with oneself** – that is, how people enact their own dignity in everyday life.

The central object of investigation is **inadult asymmetry (`IA`)**, i.e.
unequal, immature or unaccounted-for distributions of:

* **`A` – awareness** (“who sees what?”),
* **`C` – coherence** (“what is claimed, what is done – does it fit together?”),
* **`R` – responsibility** (“who carries which burden?”),
* **`P` – power** (“who decides, who can stop, who can leave?”), and
* **`D` – dignity in practice** (“how do people treat themselves – and what does that mirror about their relation to the world?”).

A hard starting assumption applies here:

> **People sometimes act in undignified ways – and yet remain dignified.**  
> The model evaluates **enactments**, not the value of persons.

We therefore distinguish three levels of dignity:

* **`D₀` – ontological dignity**  
  the inalienable, equal dignity of all persons; not measurable, not “earned”;
* **`D₁` – dignity in practice / self-dignity**  
  how someone treats themselves, especially when action has costs  
  (operationally: `D-I` – inner dimension of self-treatment; `D-B` – bodily/material dimension of self-treatment);
* **`D₂` – relational dignity**  
  how someone deals with others and the public  
  (operationally: `D-R` – relational dimension; `D-P` – public/symbolic dimension).

When, in what follows, we speak of **“dignity in practice (`D`)”**, we mean the **praxeological enactment of `D₁` and `D₂`**. `D₀` remains unaffected by this.

The paper attempts to grasp this dynamic **praxeologically**:

> not: “What kind of person is this?”  
> but: “How is action taken here – with what awareness, with what coherence of word and deed, with what responsibility, with what power, with what self-treatment?”

Guiding formula:

> **“Recognise the action – not the person.”**

The claim is threefold:

1. **Structural readability**  
   `A–C–R–P–D` as a grid to see situations, systems and interactions **more clearly**:  
   Who knows what, who claims what, who carries what, who can do what – and how do those involved treat themselves?

2. **Operational reviewability**  
   Scores, parameters and checklists that help make judgements **traceable instead of merely asserted** – including a **D-profile** that describes **dignity in practice** along  
   `D-I` (inner self-treatment),  
   `D-B` (bodily/material self-treatment),  
   `D-R` (treatment of others), and  
   `D-P` (public staging)  
   without assigning score-like dignity values to persons.

3. **Ethics of use**  
   **Guardrails** intended to prevent the model itself from becoming an **inadult weapon**
   (e.g. for retroactively devaluing persons or groups) – in particular through the strict separation of

   * **ontological dignity (`D₀`)** – non-negotiable value of persons, and
   * **dignity in practice (`D₁/D₂`)** as observable self- and world-treatment.

So the point is not to establish a new worldview, but to provide a **toolbox**:

* that makes differences between **functional asymmetries** and **inadult asymmetries (`IA`)** more visible,
* that makes maturity and **dignity in practice** distinguishable yet readable together,
* without getting lost in psychological speculation,
* and without pre-writing moral positions.

To make this toolbox usable, a clear reading logic is needed: on which levels do we observe what is happening – and where is intervention even appropriate?

---

### 1.1 Five levels on which the model reads

The model reads phenomena simultaneously on **five levels** – but evaluates **primarily the structure**.  
The fifth level (**dignity**) is an **optional additional layer**, which is activated only when the **guardrails** are met (3.5–3.7).

---

#### 1. Structural level (core level)

Here lie the basic parameters: `A–C–R–P–D`, **inadult asymmetry (`IA`)**, scores, modulators.

Guiding questions:

* Who knew what – and when? (**`A` – awareness**)
* What was claimed, what was done – does it fit together? (**`C` – coherence**)
* Who carries which burden, for what? (**`R` – responsibility**)
* Who had which real options? Who could stop, leave, decide? (**`P` – power**)
* What form does **the enactment of dignity** show in behaviour (`D-I/D-B/D-R/D-P`)?

On this level it is decided **whether** and **where** an asymmetry is functional or inadult.  
Moral evaluations come **afterwards**, not before.

---

#### 2. Moral-normative level

Here the question is **whether** what is happening structurally is also **dignified, fair and justified**.

Guiding questions:

* Is the **ontological dignity (`D₀`)** of all involved preserved?
* Are burdens and consequences distributed fairly?
* Is power used in a way that is **transparent, justified, time-bound, and reversible (`T–J–TB–R`)**?
* Are there responsible instances – or does a responsibility gap emerge?

This level **builds on** the structural level:
it interprets; it does not replace the structure.

---

#### 3. Psychological level (performative, non-clinical)

Here no diagnosis is given, but **maturity in behaviour** is described:

* tolerance of ambivalence vs. black-and-white acting
* dealing with hurt, powerlessness, loss of control
* capacity to learn, willingness to correct oneself
* tendency toward projection, role confusion, shifting responsibility
* patterns of self-treatment (`D-I/D-B`), insofar as they are **visible**

The model works **behaviourally**, not therapeutically:
no diagnoses, no inner states without indicators, no pathologising language.

---

#### 4. Narrative-cultural level

Here it becomes visible which **stories and role models** are at work in the background:

* cultural and social codes,
* archetypes (“hero”, “victim”, “authority”, “seducer”),
* scene-/milieu interpretations,
* meta-narratives (freedom, strength, purity, loyalty, etc.).

This level explains why identical actions, depending on context,

* are read in completely different ways,
* take on different moral sharpness,
* or are considered “normal”.

It explains **conflicts of interpretation** – without itself determining which narrative is “correct”.

---

#### 5. Dignity level (optional; `D₀/D₁/D₂`)

This level is **activated only** when questions of **dignity in practice** are relevant and the **guardrails** are upheld.

* **`D₀` – ontological dignity:** inviolable, constant, not measurable.
* **`D₁` – self-dignity in practice:** operationally via `D-I` (inner dimension) and `D-B` (bodily/material dimension).
* **`D₂` – relational dignity:** operationally via `D-R` (relational dimension) and `D-P` (public/symbolic dimension).

Here we ask:

* How do people deal **with themselves** (self-respect vs. self-devaluation)?
* How do they deal **with others / the public** (respect vs. degradation)?
* What does the **trajectory** of these patterns look like?

Dignity level = **analysis of enactments**,
not evaluation of the person themselves.

Taken together, the five levels provide the basic grid:
first read structure, then clarify norms, address psychological patterns only performatively,
take cultural narratives into account, and bring in questions of dignity in a targeted, not inflationary, way.

---

> **Moral-realist premise: ontological values as a necessary consequence of biological conditions**  
> The model assumes that the world contains objective values that do not depend on cultural, social or individual stipulations. These values do not arise through attribution, but through the structure of the human being itself. The biological and phenomenological constitution of the human being – vulnerability, awareness, social dependency, intentionality and the capacity for self-relation – generates normative conditions that are not arbitrary. A vulnerable, conscious, socially embedded being can flourish only under certain conditions; from these conditions necessary normative structures follow.

> **Thus the following holds:** Certain values (e.g. protection of integrity, recognition, non-harm, preservation of autonomy, respect for self- and world-relation) are *not derived from moral constructions* but *ontologically necessary*, because they follow from the biology and structure of the human being. In this sense, the model refutes the absolute form of Hume’s law: while many facts do not imply an “ought”, the constitution of a being does generate necessary “ought”-conditions for its preservation and dignity.

> Ontological dignity (`D₀`) is therefore not merely a metaphysical postulate, but an expression of these structural necessities. `D₁` and `D₂` are understood within this framework as enactment forms of an objectively existing value: they do not describe the value itself, but the way in which this value is treated, preserved or violated in everyday life.

> **Consequence:** The model is based on a **moral realism** that follows from **biological-ontological facts**. It protects ontological dignity (`D₀`) and makes visible how praxeological dignity (`D₁/D₂`) is derived from precisely this objective structure. This allows the model to be applied to itself without falling into self-contradiction and underpins its particular stability in the face of relativistic or purely constructivist systems.

---

### 1.2 Model = **toolbox, not worldview**

Once it is clear **on which levels** the model reads, the question arises **how** it should be understood: as a rigid system or as a flexible instrument. The model is **a lens**, not a cage.

* It is meant to help see structures **more clearly** –
  not to force every life situation into its terms.
* Not everything must or can be explained through `A–C–R–P–D`.
* Anyone who “sees only through the model” misses its praxeological character.

Important agreements for its use:

* The model is **substantively neutral**:

  * It favours no ideology, no party, no milieu.
  * It is interested in **enactment** – not in self-description.

* It is **sensitive to asymmetry**, but not reflexively “anti-asymmetry”:

  * Many asymmetries are **functional** (e.g. education, protection, organisation).
  * They become problematic when they become **incoherent, intransparent, unjustified, unaccounted for**.
  * The later **dignity-in-practice module** helps to see when **self-degradation** is an expression of a degrading structure – and when inner patterns dominate.

* It offers tools, but **no promises of salvation**:

  * It can help to see conflicts and patterns more clearly.
  * It cannot guarantee that people will draw the “right” conclusions.

At the same time, the model starts from a simple but far-reaching observation:
People do not act only out of “character”, but with the tools available to them. Families, milieus, organisations, media and religious traditions convey – explicitly or implicitly – entire tool sets for how to deal with conflict, guilt, power, fear and otherness.

Some of these tools foster mature enactments (e.g. perspective-taking, acknowledging mistakes, making amends, limiting power). Other tools support patterns that, praxeologically, almost always lead to actions that damage dignity: **pure obedience, fear-binding, group superiority, logics of retribution** or **pure utility calculus**. The model calls such patterns **“bad tools”** – not because they make people “bad”, but because structurally they are more likely to lead to **inadult asymmetry (`IA`)** and `D₁/D₂` violations.

The `IA` model therefore deliberately targets the tool level: it is meant to help distinguish whether someone acts destructively because he or she is “evil”, or because the tools available from the outset are distorted, narrowed or degrading. Critique is thus directed primarily at structures, patterns and tool sets – not at the ontological value of persons.

For the remainder of the paper, the following applies:

* **Chapter 2** introduces the base model `A–C–R–P–D` and its parametrisation.
* **Chapter 3** describes the **guardrails** and ethics of use, including protection of dignity (`D₀` as ontological dignity, `D₁/D₂` as dignity in practice, dignity-enactment profiles).
* From **Chapter 4 onwards**, tools and scorecards are derived from this that allow
  concrete cases to be read praxeologically.

In other words:

> Anyone using this model adopts a particular **stance towards reality**:  
> preferring clear, reviewable structures over convenient stories –  
> preferring responsibility in practice over morality in the subjunctive –  
> preferring **recognising** to **evaluating**.

Before we send this tool into practice, we need to clarify what form of “maturity” it actually considers – and which misunderstandings we explicitly **do not** intend to feed.

---

### 1.3 Maturity ≠ purity – the role of **necessary inadulthood**

Before we work with the model, it is worth looking at a widespread misunderstanding of maturity.  
A common misunderstanding about maturity is the assumption
that it means **“complete adulthood”** – as if people were then:

* consistently controlled,
* free of impulse,
* free of vulnerability to hurt,
* always level-headed,
* always coherent,
* always self-caring,
* always strong in responsibility.

This is anthropologically wrong – and in practice would amount to a **dehumanisation**.

#### Basic assumption of the model:

> **People are never fully adult.  
> And complete adulthood would not be an ideal either.**

There are portions of inadulthood that are:

* creative,
* courageous,
* risk-taking,
* nonconformist,
* visionary,
* rebellious,
* vulnerable,

– and precisely for that reason **driving forces of development and society**.

These portions are not a deficit,
but a **raw material** that – depending on role and context –
can unfold either destructive or highly adult effects.
The question is less **whether** such zones exist, and more **how** they are handled.

---

#### Inadulthood as a source of energy

Historically and today:

* Many important actors (politics, science, art, activism)
  show **inadult patterns** –
  but precisely these patterns, in certain roles,
  were channelled into **adult effect**.

The model therefore does **not approach this evaluatively**,
but structurally:

* inadulthood = energy, impulse, movement
* adulthood = stance, responsibility, framework

Maturity does not arise from purity,
but from **integration**.

---

#### Maturity in practice as an achievement of **integration**

In the model, maturity is not a property
and not a moral ideal, but:

> **the ability to make adult zones available,  
> to hold inadult zones,  
> and to coordinate both under real conditions.**

This means:

* Maturity does not exclude inadulthood.
* Maturity even **presupposes** inadulthood in part.
* Maturity is shown by **how** people deal with their more inadult impulses –
  not by whether they have any.

Inadulthood becomes problematic when:

* burdens of responsibility are ignored,
* the boundaries of others are violated,
* `D₁/D₂` are persistently undermined,
* the four-criteria box (`T–J–TB–R`) tears.

It becomes constructive when:

* a framework exists (role, context, institution, team),
* lines of responsibility are clear,
* iteration is possible,
* feedback is taken seriously,
* protection of dignity (`D₀`) and self-respect (`D₁`) are preserved.

---

#### Why this matters – for dignity, for maturity, for the model

This premise is central,
because it avoids three dangers:

1. **Perfectionism trap**  
   – the model would otherwise come across as a purity doctrine.

2. **Shame trap**  
   – people would view inadult zones as “errors”
   instead of as normal, integrable parts of being human.

3. **Abuse trap**  
   – institutions could try
   to demand “absolute maturity”
   and in doing so violate dignity.

Instead, the following holds:

> **Maturity is movement, not state.  
> Inadulthood is material, not defect.  
> Dignity remains untouchable – precisely because people never act perfectly.**

From the outset, then, it is clear:
this model describes **human reality**,
not ideals, catalogues of virtues or purity of personality.

It protects `D₀` (ontological dignity),
structures `D₁/D₂` (the praxeological forms of dignity in practice),
and allows a dignified view of development, error, learning and impact.

In this sense, the model also does not understand so-called “unfavourable starting conditions” as defects of persons, but as part of their material: people can enter enactment with very different starting packages of biography, neurobiology, attachment experience and cultural/religious tools. Those who were socialised early primarily into hard, fear-bound or group-based tools (obedience, devaluation, retributive logic, instrumental utility calculus) will, under pressure, more likely fall back on such patterns – praxeologically, therefore, “acting worse” without thereby becoming less dignified.

Maturity in practice then does not mean identifying “better people”, but making visible and workable which tools someone has learned, which are missing – and which framework conditions are needed so that other enactments become possible at all.

At the same time, this achievement of integration is not enough to resolve every dilemma – there are constellations in which even maximal maturity leaves residual pain.

---

### 1.4 Tragic conflicts – when maturity cannot resolve everything

The premise so far clarifies:
maturity does not mean purity, but a grown-up way of dealing with one’s own inadulthood.

At the same time, there are situations in which even high maturity (high `A–C–R–P`)
does not lead to all goods being preserved:
every real option injures something – dignity, justice, loyalty, safety, truth.

> **Tragedy clause (short version)**  
> Even with high maturity (high `A–C–R–P`), goods can collide  
> in such a way that every option violates some dignity or justice.  
> Such residual conflicts mark **tragedy**, not automatically inadulthood.  
>
> The task of the model is to distinguish `IA`-based injuries from tragedy-based ones –  
> not to promise that sufficient maturity will magic away all pain.

For application, this means:
the `IA` model is meant to help recognise
*where* immature or unaccounted-for asymmetries generate unnecessary suffering –
without claiming that sufficient maturity could completely dissolve every form of pain,
loss or guilt.

This sets three guidelines in Chapter 1:

* Maturity is read **in enactment**, not as an essence.
* Dignity is **protected ontologically** (`D₀`) and differentiated **praxeologically** (`D₁/D₂`) – without “evaluating” people.
* Tragic residual conflicts remain acknowledged; the model is meant to create clarity, not promise a pain-free world.

On this basis, Chapter 2 can introduce the base model `A–C–R–P–D`:
as a precise yet limited lens for reading concrete situations in a structured way.