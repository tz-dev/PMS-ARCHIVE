---
document_id: MIP-BLOCK-07
title: "Guiding Formulas and Tools"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/07_tools_case_lens.md"
status: "split-full-version"
version: "v1"
block_id: "07"
block_role: "canonical core block"
source_chapter: 7
source_chapter_title: "Guiding formulas & tools"
secondary_references: [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12]
appendix_references: ["Appendix B"]
claim_mode: "praxeological, procedural, tool-based, trajectory-oriented, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice handled through optional D-profile; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 7 heading up to immediately before chapter 8 heading"
---

# Maturity in practice — A praxeological anthropology: Guiding Formulas and Tools

## 7) Guiding formulas & tools

So far, the model has been described primarily **structurally**:  
parameters, scores, guardrails, boxes.

This chapter now gathers the **practical tools** that let the whole framework  
become operational:

* a **Case Lens** as a step-by-step protocol,
* simple **score sheets** for **A-score**, **M-score**, **IA-box** and **D-profile**,
* and work with **trajectories** rather than points.

The aim is not to create bureaucratic overhead but to provide **lightweight tools** that:

* make maturity and responsibility visible,
* co-read dignity in practice (`D₁/D₂`),
* and ultimately lead to **different decisions and structures**.

---

### 7.1 **Case Lens** (v1.0) – **decision protocol**

The **Case Lens** is the standard protocol for a full `IA` analysis.  
It ensures that you:

* describe the case clearly,
* examine relevant parameters,
* see responsibility over time,
* and always end with a **decision** –  
  not merely commentary.

> **Case Lens boundary:**  
> The **Case Lens** structures a case.  
> It does not decide the case by itself.

It operates primarily with `A–C–R–P–D`,  
with `D₁/D₂` (dignity in practice) activated only when all guardrails (chap. 3.5/3.6) are fulfilled.

**Standard path:**

1. Snapshot
2. Frame vs. variability
3. **A-score** trajectories
4. `IA` localisation (knowing / being able / being permitted / willing)
5. `RVR(t)` – responsibility–viability–range over time
6. Decision: maintain / balance / change–stop
7. KPIs & review date

Optional, **only with safe conditions**:

> Add a **D-profile** (dignity in practice, `D₁/D₂`)  
> after step 3 or parallel to step 4 (see Chapter 5 and 7.2.4).

Principle:

> **Every `IA` analysis ends with at least one actionable improvement proposal.**  
> Pure readings without corrective trajectory are *inadult use* of the model.

---

#### Step 1 – Snapshot (case, actors, level)

A short, neutral snapshot:

* **What is this about?**  
  – situation, decision, conflict, structure.

* **Who is involved?**  
  – roles, power gradients, affected parties, context.

* **On which level?**  
  – individual · dyadic · organisational · political · cultural.

* **Publicity?**  
  – private · semi-public · institutional · public · media  
    (consider `A-P` / `P-PU`: public/media awareness and public agency).

* **First visible `D₁/D₂` themes?** (optional – dignity in practice)  
  – self-devaluation, shaming, degradation,  
    implicit messages: “You are worth less.”

Goal: **precise, one-sided description** without interpretation or blame.

---

#### Step 2 – Frame vs. variability

Question:

> **What is fixed – and what is malleable?**

* **Frame (fixed / slow to change):**  
  – laws, contracts, structural constraints, physical limits, protected goods,  
  – **ontological dignity (`D₀`)** as axiomatic boundary.

* **Variability (malleable):**  
  – roles, communication, processes, timing, degree of intervention, error handling,  
  – handling dependencies, attributions, dignity enactments (`D₁/D₂`).

Outcome:

* Where would high `A` / `M` be **unfair**?
* Where does “the system” become an **excuse**?
* Where is `D₁/D₂` **realistically improvable**?

---

#### Step 3 – **A-score** trajectories

For relevant actors:

* establish **`A(t₀)`, `A(t₁)`, `A(t₂ …)`**  
  (maturity in practice → awareness, coherence, responsibility, power).

* **A-band estimation** (e.g., `3–4`, `5–6`),  
  with **1–2 justification points** per moment.

Optional when `D` is activated:

* notes on **D-enactments** (`D₁/D₂`)  
  – self-devaluation (low `D₁`),  
  – protection of others despite costs, protest, refusal (high `D₂`),  
  – shaming/degrading others (low `D₂`).

**Do not evaluate `D` yet** – only observe.

---

#### Step 4 – `IA` localisation (knowing / being able / being permitted / willing)

Four localisation clusters:

* **Knowing**  
  – information landscape, blind spots, knowledge withholding, interpretive power.

* **Being able**  
  – competencies, resources, tools, ability to address dignity.

* **Being permitted**  
  – formal/informal permission, taboos, sanctions, unspoken prohibitions regarding `IA` / `D`.

* **Willing**  
  – willingness to correct; where responsibility is resisted or offloaded.

`IA` localisation reveals:

* where asymmetries are **not functional**,
* where `D₂` is systematically **undermined** or **protected**.

---

#### Step 5 – `RVR(t)`: responsibility–viability–range over time

> **`RVR(t)` = f(knowing, being able, being permitted, acting)**  
> under the **ceiling rule** and **ontological dignity (`D₀`)**.

For each time span assess:

* realistic `M`-share?
* Was knowledge present or absent?
* Which levers (`P-S` / `P-PU`)?
* Room to act (being permitted)?
* Real decision options?

Ceiling rule:

> **Predictability ≈ 0 or alternatives ≈ 0 → `M ≤ 4`.**

Outcome:

* **responsibility curve**, not a point value.
* No “They *should* have just…,” when knowledge/levers/alternatives were absent.
* Protection of **dignity in practice (`D₁/D₂`)** through fair attribution.

---

#### Step 6 – Decision: maintain / balance / change–stop

Three modes:

1. **Maintain**  
   – asymmetry is functional (`T–J–TB–R` fulfilled),  
   – dignity in practice (`D₁/D₂`) is protected.

2. **Balance**  
   – maturity okay, but power/responsibility skewed,  
   – increase transparency, clarify roles, shift resources,  
   – reduce degrading side effects.

3. **Change–stop**  
   – clear `IA` signals (intransparent, unjustified, irreversible),  
   – high harm, D-breaks, high `M`,  
   – radical correction/termination.

Decision with short justification referencing:

* `A` / `M` trajectories,
* `IA` localisation,
* `RVR(t)`,
* observed `D₁/D₂` enactments.

---

#### Step 7 – KPIs & review date

Close with:

* **KPIs:**

  – fewer `IA` signals,  
  – more stable **A-scores**,  
  – fewer D-breaks,  
  – improved conditions for affected parties.

* **Review date:**

  – time, responsible roles, falsifiers  
    (“When do we consider our hypothesis disproven?”)

Thus analysis becomes a **responsibility process**, not a final verdict.

---

### 7.2 **Score sheets** (`A`, `M`, `IA-box`, `D-profile`)

**Score sheets** are **structuring aids** – not rankings.

Goals:

* organise thinking,
* detect blind spots,
* document **D-enactments** **as behaviour**, not as personhood,
* keep decisions transparent.

Core sheets:

* **A-score sheet**
* **M-score sheet**
* **IA-box sheet**
* **D-profile sheet** (optional, separate module)

Boundary distinctions:

> **A-band**, not person score.  
> **M-band**, not guilt score.  
> **D-profile**, not dignity score.

---

#### 7.2.1 **`A-score sheet`**

Header:

* case / context
* role / level
* time window

Four blocks:

1. **`A-I` (inner awareness)** – observations + band
2. **`A-R` (role awareness)** – observations + band
3. **`A-C` (context awareness)** – observations + band
4. **`A-IM / A-P`** (impact awareness / public/media awareness) – observations + band

Close with:

* **integrated A-band**
* **justification** (2–3 sentences)

Optional with `D` activated:

* notes on `D₁/D₂`, **without** evaluating here.

`A` remains a **maturity metric**; `D` is handled separately.

---

#### 7.2.2 **`M-score sheet`**

Header:

* position / role
* time frame

Five `M` components:

1. **Knowledge (`A`)** – low/medium/high
2. **Power/control (`P`)** – low/medium/high
3. **Predictability** – low/medium/high
4. **Access to alternatives** – low/medium/high
5. **Integration attempt** – weak/medium/strong

Then:

* **raw `M` (`0–10`)**

* **Ceiling rule check:**

  – predictability ≈ 0?  
  – alternatives ≈ 0?  
  → **`M ≤ 4`.**

Close with:

* **valid M-score**
* short comment

D-link:

* low `M` + high harm → **protection**, not blame
* self-devaluation = **`D₁` phenomenon**, **not** an increase in `M`

---

#### 7.2.3 **`IA-box sheet` (`T–J–TB–R`)**

**Asymmetry:**  
(precisely name the issue)

Four fields:

1. **`T` – Transparent?** – yes / partly / no  
   *Who knows what? Who could know?*

2. **`J` – Justified?** – yes / partly / no  
   *Which legitimate purpose does the asymmetry serve?  
   Protection, process, organisation – or unilateral advantage?*

3. **`TB` – Time-bound?** – yes / partly / no  
   *Which review points or conditions exist?*

4. **`R` – Reversible?** – yes / partly / no  
   *Which real exit options exist?  
   What blocks the return path?*

**Conclusion:**

* predominantly **functional**,
* **IA risk**,
* or **clearly inadult**.

**Immediate action:**  
(short proposal: more transparency, add review, create exit option, clarify roles, etc.)

**D-note (observation, not judgment):**

* **`D₁` effects:** self-devaluation? withdrawal? loss of self-care?
* **`D₂` effects:** shaming? exclusion? reinforcement of subordination?
* **D-support:** does the structure create protection / dignity scaffolding?

Detailed analysis occurs in the **D-profile sheet** (7.2.4)  
and the **D-Quick-Grid** (11.3).

---

#### 7.2.4 **`D-profile sheet` (`D₁/D₂`)** – dignity in practice

After **A-score**, **M-score** and **IA-box** clarify structural aspects of a case,  
one final, sensitive question remains:

> **How does someone – under these conditions – enact their dignity?**

The **D-profile** is the most delicate tool in the model.  
It describes **concrete dignity enactments** (*D-enactments*) of a person or role – never personhood.

> **D-profile boundary:**  
> `D₀` remains outside the card.  
> `D₁/D₂` describe **D-enactments**, not personhood.  
> No numbers. Qualitative bands only.

**Core rules:**

* `D` is used **only** when all guardrails (chap. 3.5–3.7) are met.
* **Ontological dignity (`D₀`)** remains untouched and **outside** the card.
* Observed are **`D₁`** (self-dignity in practice) and **`D₂`** (relational dignity in practice),  
  operationalised through:  
  – **`D-I`** (inner self-relationship),  
  – **`D-B`** (bodily/material self-care),  
  – **`D-R`** (relational dignity),  
  – **`D-P`** (public dignity in practice).
* No numbers – **qualitative bands** only.
* Every statement is **situated**, contextual, revisable.

---

**Header:**

* case / context
* role / level (affected person, leadership, team, public, etc.)
* time frame (`t₀–t₁`, key moment, trajectory)
* communication space:  
  – self-reflection · professional-confidential · **not** public
* scope:

  * ☐ **Inner orientation – `D₁`** (`D-I/D-B`)
  * ☐ **Relational orientation – `D₂`** (`D-R`)
  * ☐ **Public orientation – `D-P`**

---

##### Block 1 – `D₁`: self-enactment / self-treatment (`D-I/D-B`)

**Questions:**

* How does the person speak about themselves?
* How do they treat body, boundaries, needs?
* How do they respond to their own failures?
* What structural factors (pressure, poverty, chronic criticism, discrimination) shape `D₁`?

**Fields:**

* **Observable `D₁`-enactments (`D-I/D-B`):**  
  excessive guilt taking; self-insulting language; boundary setting despite costs; active help-seeking;  
  systematic self-exploitation; persistent dismissal of bodily/psychological signals.

* **Trend band:**  
  *rather self-devaluing* / *ambivalent* / *rather self-respecting*

* **Context notes:**  
  Which conditions suppress or support `D₁` (time pressure, dependency, social isolation, support networks)?

---

##### Block 2 – `D₂`: relational dignity (`D-R` – feedback to the world)

**Questions:**

* What does the enactment signal about relation to the environment?
* Is this protest, adaptation, mirroring, withdrawal, refusal?
* Are degrading patterns mirrored or interrupted?

**Fields:**

* **Observable `D₂`-enactments (`D-R`):**  
  neglect as protest; ironic self-degradation; refusal to degrade others;  
  breaking cooperation; withdrawal from degrading settings; shaming others.

* **Interpretive reading (not judgment):**  
  *deficit* / *protest* / *ambivalent* / *dignity-stabilising*

* **Structural context:**  
  Which `IA` patterns resonate here (exclusion, stigma, class/milieu dynamics)?

---

##### Block 3 – `D-P`: dignity enactment under publicity

(Active only when publicity is relevant.)

**Questions:**

* How does behaviour **before an audience** differ from private behaviour?
* Are one’s own or others’ dignities marketed, risked, protected, instrumentalised?

**Fields:**

* **Public enactments (`D-P`):**  
  self-commodification; exposing others’ intimate details; protection of vulnerable persons;  
  deliberate restraint to avoid shaming.

* **Private/public tension:**  
  *congruent* / *divergent*

* **Publicity context:**  
  reach, platform, archiving, power asymmetries, symbolic/financial incentives.

---

##### Block 4 – Linking `A–M–D` (without mixing)

**Short matrix:**

* **A-band** (maturity in practice)
* **M-band** (shared responsibility)
* **D-tendency** (e.g., “strong self-devaluation with low `M`”)

**Goal:**

* Reveal D-damage with **low `M`** → protection, relief, structural critique.
* Reveal degrading enactments with **high `M`** → responsibility and structural work.

Mnemonic:

> **A measures maturity.  
> M measures shared responsibility.  
> D describes dignity in practice.  
> Self-devaluation does not raise M.**

---

##### Block 5 – Guardrails & use

**Checklist:**

* ☐ Not used for diagnostics, HR, forensics, shaming.
* ☐ Describes **enactments**, not personhood.
* ☐ **`D₀` (ontological dignity)** remains unquestioned; degrading language marks a D-break of the observer.
* ☐ Use only **contextually** (role logic, `A` / `M` profile, IA-box, publicity).

**Use in procedure:**

* contribute to **D-trajectory `D(t)`** (more self-care? less self-devaluation?).
* input for **D-Quick-Grid** (11.3).
* early warning for declining dignity enactments.

Short vignette:

> An assistant nurse repeatedly describes herself in supervision as “too stupid” and “too sensitive,”  
> even though she carries a ward under high pressure.  
> `A` is mid-range, `M` is clearly low, `D₁` shows strong self-devaluation.  
> The **D-profile** ensures **support and relief** here – not additional blame.

---

**Margin protection clause (mandatory):**

> **“This profile describes enactments, not personhood.  
> `D₀` remains inviolable.  
> All descriptions are situated, revisable and corrigible.”**

Link to other tools:

* The **D-profile** complements:

  – **A-score** (maturity in practice),  
  – **M-score** (shared responsibility),  
  – **IA-box** (structural quality).

* For finer classification of D-breaks,  
  use the **D-Quick-Grid** (11.3):  
  minor frictions · consistent breaks · major/extreme breaks.

Thus the **D-module** remains what it must be:

> **A revealer of dignity and degradation dynamics –  
> never a diagnostic tool and never a pillory.**

---

### 7.3 **Trajectories** instead of points

Maturity, responsibility and dignity in practice are **trajectories**, not traits.

A single value is a snapshot.  
What matters is whether something **stabilises, improves or deteriorates** over time.

Guiding formula:

> **We write curves, not labels.**

* **`A(t)`** – maturity in practice,
* **`M(t)`** – shared responsibility across time,
* **`D(t)`** – change in dignity enactment (`D₁/D₂`).

---

#### 7.3.1 Why **trajectories**?

A single value says little.  
A trajectory shows:

* learning,
* stagnation,
* tipping points,
* overload,
* structural distortions,
* maturation or erosion in self-treatment (**`D₁`**),
* protest, withdrawal or adaptation in relational enactment (**`D₂`**).

Trajectories enable fairer decisions because they do not only ask:

> “How was it here?”  
> but rather:  
> **“In which direction is this system moving?”**

---

#### 7.3.2 Minimal documentation

**Timeline:** `t₀ – t₁ – t₂ …`

For each point:

* **A-band**,
* **M-band**,
* optional D-observation (e.g., “`D₁` stabilising, `D₂` becoming more defensive”),
* key events / role shifts / context jumps.

Example (condensed):

* `t₀` – acute crisis – `A 3–4` – “overrun, no role clarity”
* `t₁` – after first intervention – `A 4–5` – “roles more explicit, first corrections”
* `t₂` – after structural change – `A 6–7` – “responsibility redistributed, `D₂` less defensive”

Final question:

> **Is the enactment becoming more dignified – or merely more efficient?**

---

#### 7.3.3 Linking **Case Lens** ↔ **score sheets**

* **Case Lens** **step 3** → `A(t)` trajectories,
* **Case Lens** **step 5** → `RVR(t)` – responsibility–viability–range over time,
* **score sheets** (**A-score**, **M-score**, **IA-box**, **D-profile**) → raw data,
* **Case Lens** **step 6/7** → decision & review based on curves.

Mature use means:

* no still images (“You are like this”),
* focus on **direction + pace**,
* core question:

> **What enables a more mature trajectory –  
> and what enables a more dignified enactment?**

Thus the model becomes fully dynamic:  
It cares less about labels and more about whether systems are **capable of learning and change**.

---

### 7.4 **System-1 / System-2 micro-tool** (acute situations)

Not every situation allows for a full **Case Lens**. Sometimes:

* pressure is high,
* emotion is strong,
* time is short,
* the public is already present.

Here a **System-1 / System-2 micro-tool** is needed that helps, within seconds,  
to avoid staying stuck in a System-1 reflex (impulse, defence, attack)  
and to insert at least a brief System-2 moment.

The micro-tool works in four steps:

> **`STOP–FRAME–ROLE–STEP`**

---

#### Step 1: STOP – minimal interruption

Goal: interrupt the automatic stimulus–response chain.

* internally: “Stop. I don’t have to respond immediately.”
* externally:  
  – “I need a moment …”  
  – “Let me think for a second.”

Praxeological effects:

* **awareness (`A`)** moves from “near zero” to “minimally active”,
* **power (`P`)** is briefly throttled (no irreversible actions),
* **coherence (`C`)** and **responsibility (`R`)** get space,
* **dignity enactment (`D`)** is implicitly protected  
  (lower likelihood of impulsive degradation – of others or oneself).

---

#### Step 2: FRAME – micro-context setting

Questions:

* **Where are we?**  
  private · professional · institutional · public · media?

* **What is this about in one sentence?**  
  conflict, request, accusation, boundary-setting, decision?

* **Which protected goods are touched?**  
  health, safety, **dignity** (`D₀/D₁/D₂` – `D₀` = ontological dignity, `D₁/D₂` = dignity in practice),  
  existence, trust?

Goal:

* minimally increase **coherence (`C`)**,
* synchronise **awareness (`A`)** with coherence,
* preliminarily mark **whose dignity is at risk**.

---

#### Step 3: ROLE – short-form role check

Three micro-questions:

1. **From which role am I speaking?**  
   (private person, professional, leadership, affected party, facilitator …)

2. **In which role am I hearing the other?**

3. **Is this clear for both sides?**  
   If not: *one sentence of clarification*.

Outcome:

* acute increase in **role awareness (`A-R`)**,
* reduced risk of phantom intentions,
* D-protection: prevents people from being degraded “in the wrong role”  
  (e.g., clients treated like offenders, staff treated like “enemies”).

---

#### Step 4: STEP – smallest reversible action

Examples:

* a clarifying question,
* short summary (“What I hear is …”),
* temporary boundary (“Up to here, not further.”),
* suggest a pause / rescheduling.

Criteria:

* **reversible**,
* **role-consistent**,
* **context-compatible** (FRAME),
* **protection-aware** (especially regarding dignity).

Principle:

> **Mini-adultness:**  
> Not acting perfectly – but avoiding anything that would irreversibly block later maturity or restoration of dignity.

Short vignette:

> In a team meeting a colleague is suddenly attacked: “You’re sabotaging everything here!”  
> Instead of firing back, the team lead says:  
> “Stop – I need a moment to sort the frame. We’re in a team meeting, not a tribunal.  
> I’m speaking now as the team lead and want to first understand what happened.”  
> This `STOP–FRAME–ROLE–STEP` prevents a spontaneous degradation  
> from becoming a structural pattern.

Thus the **System-1 / System-2 micro-tool** is not a substitute for the **Case Lens**,  
but an **emergency lever** for remaining praxeologically adult under pressure.

---

### 7.5 **Mini-toolkit**: score sheet & context tools (optional)

The **Mini-toolkit** sits between “nothing” and “Full Lens”.

It consists of:

1. **Context cards** (roles, publicity, frame/variability),
2. **Light score sheets** (**A-band/M-band**, `D` only as side observation),
3. **IA-box check (light)** – `T–J–TB–R` in short form.

This allows for more structured reading of maturity, responsibility  
and dignity dynamics even with limited time –  
without slipping into over-diagnostics or overuse of `D`.

---

#### 7.5.1 Three usage modes

**1) Quick-check (5–10 min)**

* 1 contrast question: “Where is the likely unfair asymmetry?”
* IA-box light (`T–J–TB–R` briefly)
* rough **A-band** estimation
* optional 1 D-keyword (self-devaluation / dignity-stabilisation)

**2) Mini-toolkit (30–60 min)**

* context card (role, publicity, frame/variability),
* light **A-score sheet**: band + short justification,
* **M-score sheet** incl. **ceiling rule** check,
* 1–2 **IA-boxes**,
* optional D-note (no numeric D-ratings, only observed patterns).

**3) Full Lens**

* full **Case Lens**,
* full **score sheets**,
* **trajectories**,
* `RVR(t)`,
* review planning.

The **Mini-toolkit** provides enough depth to structure perception  
without risking over-diagnosis or over-extension of `D`.

---

#### 7.5.2 Typical application fields

* **Team reflection** after conflicts or projects  
  – Where was enactment mature/immature?  
  – Which asymmetries were functional, which inadult?  
  – optional: where did D-breaks occur (minor, consistent, major)?

* **Decision preparation**  
  – **IA-box** before new rules,  
  – rough **M-score** per role,  
  – D-question: does the measure strengthen or weaken dignity in practice (`D₁/D₂`)?

* **Self-clarification in transitions**  
  – role changes, public appearances, difficult conversations,  
  – clarification of levers, shared responsibility, desired self-treatment (`D₁/D₂`).

**Mini-toolkit** means:

> **Just enough structure to see more fairly –  
> without losing the case in spreadsheets.**

It prepares the ground so that the tools of chapter 7  
can later be applied **in lived practice** (chapters 8–11):  
as practical aids for making maturity in practice  
and dignity in everyday life more visible –  
not as a new form of esoteric code.

---

### 7.6 **Praxeological final checklist**

At the end of every analysis stands a final filter  
before something becomes “actionable” – as:

* decision,
* document,
* publication,
* internal communication,
* policy or guideline.

This is no longer about new data  
but about **how** we handle our own interpretation.

Core questions:

> **“Am I in reality – or in my projection?”**  
> **“Am I touching behaviour – or beginning to negotiate dignity?”**

The **Praxeological final checklist** gathers:

* satisfaction check
* parameter check (`A–C–R–P–D`)
* role check
* projection alarm
* publicity / multi-context
* D-cleanliness
* and the **Grail sentence**.

It is not a form but an **inner stance in question form**:  
a brief reality and dignity check before hitting “send”.

---

#### 7.6.1 Satisfaction as warning signal

Question: **How satisfied am I with my result?**

* very high
* okay
* low
* chaotic

Warning:

> **“Too smooth” = suspicion of projection or role-polishing.**

If the picture fits too perfectly  
what I already believed,  
the likelihood of integrating new information is low.

D-indicator:

* If the dignity balances align “too nicely” in favour of my own role,  
  the risk of moral sorting increases:  
  – We appear mature, fair, dignity-sensitive –  
    the other side “naturally” immature and undignified.

Short vignette:

> A team analyses a conflict.  
> Result: all `IA` findings lie “on the other side,”  
> their own behaviour reads like a textbook.  
> The satisfaction check signals:  
> **Back to start; check blind spots.**

---

#### 7.6.2 Parameter check: `A–C–R–P–D`

**`A` – Awareness**

* Do I see what *I* do – or only what the others do?
* Is my role awareness (`A-R`) clear?
* Do I distinguish **knowing** from **guessing**?

**`C` – Coherence**

* Are relevant levels (social, institutional, cultural, symbolic) consistently included?
* Are power relations made visible as coherence in power contexts (**`C-P`**)?
* Have I reflected my own narrative layer (**`C-N` = narrative coherence**)?

**`R` – Responsibility**

* Where does my responsibility end – where does theirs begin?
* Do I take over-responsibility – or systematically offload it?
* Who holds interpretive power – and is that named?

**`P` – Power (power to act)**

* Do I confuse felt and actual agency?
* Do I push others into roles/responsibilities  
  they structurally do not hold?

**`D` – Dignity in practice (`D₁/D₂`)**

* Do I keep clean:

  * **`D₀` – ontological dignity** (inviolable personhood)
  * **`D₁` – self-dignity in practice**
  * **`D₂` – relational dignity in practice**?

* Am I speaking about **behaviour in context** – or am I beginning  
  to negotiate personhood?

* Are the guardrails for the **D-module** (3.5–3.7) met?
* Is `D` even necessary here – or am I using it just because it “sounds stronger”?
* Do I formulate **reversibly**, in ways that allow later correction and development?

Faulty D-use raises the risk  
of moral or symbolic degradation –  
even when “well-intended.”

---

#### 7.6.3 Role confusion – red alert

Three key questions:

1. **Do I know which role I am in?**  
   (leadership, affected person, colleague, researcher, facilitator …)

2. **Do I know which role the other assigns to me?**  
   (enemy, examiner, ally, “the system”)

3. **Does the other know which role I assign to them?**

If at least one question is unclear:

> **Role vacuum → phantom intention → escalation → `D₂` damage.**

`D₂` = relational dignity in practice:  
How people treat each other  
and position themselves publicly.

High risk of degradation arises especially when  
affected persons are suddenly treated like offenders,  
staff like “enemies”, or clients like “cases”,  
without explicit role clarification.

---

#### 7.6.4 Detecting projection

Questions:

* Am I interpreting more than was said or shown?
* Do I “know” things never communicated?
* Does my assessment stem from fear, hope, shame, anger?
* Do I expect automatically to be understood  
  without making my frame explicit?
* Am I using the model or `D` subtly  
  to legitimise my own superiority?

Every “yes” means:

> **Pause the analysis; check calibration.**

Especially critical:

* When D-evaluations merge with one’s own triggers, biographical shame  
  or moral reflexes, a **meta-reflective pause is mandatory**.
* Analysing in strong emotion risks  
  **degrading others in the name of dignity**.

**Grail sentence** (first version):

> **“Am I touching behaviour – or beginning to negotiate dignity?”**

This question marks the boundary  
between what is praxeologically describable  
and what belongs to the inviolable domain of `D₀`.

---

#### 7.6.5 Publicity factor (`A-P`, `P-PU`, `D-P`)

Relevant for public spaces, art, social media, politics:

* ☐ Does behaviour **change before an audience** compared to private space?
* ☐ Is there a **media or cultural meaning layer**  
  (memes, narratives, historical references)?
* ☐ Any semantic contamination  
  (lyrics, images, codes carrying implicit meaning)?
* ☐ Does the person carry **public responsibility** –  
  or is it attributed to them?

* ☐ Does the situation touch **`D-P`** (dignity in public enactment):

  – public shaming, outrage cycles, media exposure,  
  – self-branding, voluntary self-objectification,  
  – collective attributions of “honour” or “shame”.

Terms:

* **`A-P`** = awareness of publicity,
* **`P-PU`** = power in public contexts,
* **`D-P`** = dignity enactment under publicity.

> If **`A-P`** is ignored, public analyses are incomplete.  
> If **`D-P`** is ignored, degrading or dignity-protecting effects of publicity remain invisible.

---

#### 7.6.6 Multi-context situations

Check: which contexts are active simultaneously?

* ☐ private
* ☐ public
* ☐ cultural / symbolic
* ☐ institutional
* ☐ power-related
* ☐ intimate / relational

The more levels active at once,  
the more carefully conclusions should be formulated.

**D-note:**

* Dignity can be strengthened in one context  
  and simultaneously injured in another –  
  e.g.:  
  – clear boundary-setting (D-strengthening) in a relationship,  
  – publicly read as “shaming” (D-injury).

Guiding question:

> **“On which level am I reading the dignity effect –  
> and on which level not?”**

---

#### 7.6.7 Coherence test via the other’s reaction

* ☐ Does the other behave coherently with the role I assign them?

  * **Yes** → model plausible.
  * **No** → role likely misread.
  * **Partially** → re-examine context or power dynamics.

Additional questions:

* ☐ Does the other respond with unexpected **shame, defiance, withdrawal or self-devaluation**,  
  even though I perceive my analysis as “neutral”?

* ☐ Could this mean that my use of the model or the **D-module**  
  is experienced as **degrading**?

> A mismatch between the other’s reaction and my internal picture  
> signals **blind spots** – not automatically the other’s “irrationality.”

---

#### 7.6.8 The **Grail sentence**

Finally, a radical question:

> **“Am I acting from my role –  
> or from fear, hope, projection,  
> or the need to elevate myself / degrade others?”**

If this cannot be answered cleanly:

> **→ Restart the analysis.**  
> Not because everything is wrong –  
> but because the calibration point is unclear.

**Hard rule:**

> **If the final checklist fails**  
> (central questions remain open, guardrails are violated,  
> projection dominates),  
> the analysis is **not mature for transmission**.

It may remain as:

* **working note**,
* personal thinking attempt,

but not as:

* neutral truth,
* objective diagnosis,
* or basis for structural decisions.

Thus the checklist protects:

* the **dignity** of those involved (`D₀` and `D₁/D₂`),
* the **integrity** of the model,
* and the **maturity in practice** of those who apply it.

It is the small act of self-limitation  
that turns an analytical tool  
into a responsible procedure.

---

### 7.7 Conclusion

Chapter 7 turns the model into a set of bounded practical tools.

The **Case Lens** structures cases, but does not decide them by itself.  
The **score sheets** organise observations, but do not rank persons.  
The **A-score sheet** works with **A-bands**, not person scores.  
The **M-score sheet** works with **M-bands**, not guilt scores.  
The **D-profile sheet** describes **D-enactments**, not dignity scores.

The tool logic remains trajectory-based:

* **`A(t)`** shows maturity in practice across time.
* **`M(t)`** shows shared responsibility across time.
* **`D(t)`** shows dignity enactment across time.

The **System-1 / System-2 micro-tool** and the **Mini-toolkit** provide limited orientation under pressure or with limited time. They do not replace the **Case Lens**, guardrails or judgement.

The **Praxeological final checklist** gates transmission:  
if the checklist fails, the analysis remains a **working note** and is **not mature for transmission**.

Thus Chapter 7 provides practical access to the model while preserving its core boundary:  
tools structure perception; they do not decide cases, diagnose persons, rank maturity or measure dignity.
