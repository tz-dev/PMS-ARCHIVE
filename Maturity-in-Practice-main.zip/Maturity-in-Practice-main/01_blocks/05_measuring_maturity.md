---
document_id: MIP-BLOCK-05
title: "Measuring Maturity in Practice"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/05_measuring_maturity.md"
status: "split-full-version"
version: "v1"
block_id: "05"
block_role: "canonical core block"
source_chapter: 5
source_chapter_title: "Measuring maturity in practice – without moral rhetoric"
secondary_references: [1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, situational, score-banded, non-moralising, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice handled separately in D-profile; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 5 heading up to immediately before chapter 6 heading"
---

# Maturity in practice — A praxeological anthropology: Measuring Maturity in Practice

## 5) Measuring maturity in practice – without moral rhetoric

In many debates, maturity is either invoked morally (“People should simply act like adults”)  
or interpreted psychologically (“X is just like that”). Neither helps much when we need to examine  
**concrete enactments**: what was done, when, with what knowledge, in which **role** –  
and what realistically could have been done differently?  
This chapter introduces the **A-score** as an attempt to make maturity **praxeological** and **situational** –  
without becoming a backdoor to character judgment.

The **A-score** tries to make something essentially qualitative **operational**:  
How adult, how responsible, how coherent is the **enactment** in a **specific situation**?

> **A-score boundary:**  
> The **A-score** describes **enactment**, not essence.  
> It is assigned to **cases / situations / structures**, not persons.  
> It is a **working value**, not a moral verdict.

Thus “X is immature” becomes a different question:

> **“How mature was the enactment here – under these conditions –  
> and how could the same actor behave more maturely under changed conditions?”**

---

### 5.1 **A-score** (`0–10`) – dimensions & **micro-indicators**

Once it is clear that the **A-score** describes maturity in practice rather than personal worth,  
we need a finer resolution: **What** exactly goes into the score – and **how** is it formed?

---

#### 5.1.1 What the **A-score** measures – and what it does not

The **A-score** answers a strictly limited question:

> **“How mature was the enactment – under these conditions, with this knowledge, in this role?”**

Formal notation:

> **`A(H)` = maturity in practice of an enactment, case, or situation `H`.**

It does **not** measure:

* “How good is a person?”
* “How valuable is someone?”
* “How much love / pain / biography is behind this?”

It summarises:

* how **awareness (`A`)** was actually used,
* how **coherence (`C`)** between words, decisions and actions looks,
* how **responsibility (`R`)** was taken or shifted,
* how **power / power to act (`P`)** was used or withheld.

The score always refers to:

* a **time period** or **episode**,  
* a **role** (e.g. office, function, relational role),  
* a **context** (private, institutional, public, media).

Anything else would be a category error.

**Mini-vignette:**  
A hospital management must decide on staff cuts under cost pressure.  
The **A-score** does not ask: “Are they good people?”  
but: “How consciously were consequences assessed (`A`)?  
How coherent were statements and decisions (`C`)?  
Who carried which burdens (`R`)?  
Which real alternatives were explored or dismissed (`P`)?”

---

#### 5.1.2 Dimensions of the **A-score**

Practically, the **A-score** can be read along the four main axes:

> **Subscore notation:** `A(A) · A(C) · A(R) · A(P)`  
> `A(A)` = maturity of awareness  
> `A(C)` = maturity of coherence  
> `A(R)` = maturity of responsibility  
> `A(P)` = maturity of action / power

They can be considered separately and then integrated –  
or directly estimated as one combined score.  
What matters is that the underlying **micro-indicators** are checked.

---

##### `A(A)` – maturity of awareness

**High `A(A)`**, when for example:

* relevant information is **actively gathered**,  
* obvious signals are not suppressed, but taken seriously,  
* one’s own role is seen and named (“I am speaking here as …”),  
* side effects for affected people are at least **considered**,  
* adaptation occurs when new information emerges (“I was wrong; I correct …”).

**Low `A(A)`**, when for example:

* one **does not want to know** what is obvious (“better not look too closely”),  
* warning signs are systematically ignored,  
* role and leverage are downplayed (“I’m just …” despite high power),  
* learning opportunities are rejected.

---

##### `A(C)` – maturity of coherence

**High `A(C)`**, when for example:

* words, commitments and decisions **match** later actions,  
* justifications are consistent (no constant retrofitted storytelling),  
* tensions are openly marked (“We have a goal conflict here …”),  
* corrections are not hidden but **transparent** (“We are changing course because …”).

**Low `A(C)`**, when for example:

* “A” is repeatedly said and “¬A” enacted,  
* justifications are retrofitted,  
* responsibility is taken linguistically but refused in action,  
* roles are switched without signalling.

---

##### `A(R)` – maturity of responsibility

**High `A(R)`**, when for example:

* someone **names** their part – and acts accordingly,  
* burdens are not systematically shifted downward,  
* affected persons are not made invisible,  
* successes **and** harms are addressed (“This is on us”).

**Low `A(R)`**, when for example:

* responsibility is shifted upward / downward / outward (“Everyone but us”),  
* structural responsibility gaps exist (“No one is in charge”),  
* costs are deliberately shifted to the weaker side,  
* one hides behind formulas, processes, committees.

---

##### `A(P)` – maturity of action / power to act

**High `A(P)`**, when for example:

* real agency is **used** – intervening, limiting, stopping, leaving, escalating *or* de-escalating,  
* impossible demands are not cynically placed (“You should have just …”),  
* one correctly assesses their leverage  
  (“We *can* intervene here – so we will / or consciously won’t”),  
* visible attempts are made to improve the situation – even at risk.

**Low `A(P)`**, when for example:

* one pretends to be powerless despite having leverage,  
* options are only used when they are **cost-free**,  
* “it’s impossible” is used where “it would be uncomfortable” is meant,  
* one understates or overstates their influence.

---

#### 5.1.3 Calibration bands `0–10` — enactment zones, not person ranks

The **A-score** is not a device with decimal precision.  
It works with **bands**, not exactness.

At the same time – consistent with the **D-module**:

> **The A-score describes maturity in practice – never the worth or dignity of a person.**  
> Ontological dignity (`D₀`) remains untouched;  
> dignity in practice (`D₁/D₂`) is described separately in the **D-profile** (see 5.3),  
> operationalised through `D-I`, `D-B`, `D-R`, `D-P`.

A useful heuristic:

* **`0–1` — collapse zone**  
  – virtually no maturity in enactment,  
  – severe breakdown across multiple axes (`A`, `C`, `R`, `P`),  
  – `IA` extreme, protection goods heavily violated,  
  – typical: breakdown moments, destructive patterns, collapse of self-/other-care.  
  → Often accompanied by deep disruptions in dignity enactment (self-devaluation, degrading others) – **without** ever touching `D₀`.

* **`2–3` — clearly inadult enactment**  
  – isolated adult elements may be present,  
  – but overall: denial, incoherence, evasion of responsibility, misuse or refusal of power,  
  – no admission or correction attempts (or only rhetorical),  
  – dignity enactments often **inconsistent**: some self-care, then self-/other degradation.

* **`4–5` — everyday mixed zone**  
  – mixed patterns: some adult, some inadult,  
  – visible striving for maturity but with blind spots,  
  – typical tension fields,  
  – many real systems land here,  
  – dignity enactment often **oscillates**:
    episodes of self-respect, then downward adaptations (e.g. self-neglect under stress).

* **`6–7` — solid adultness**  
  – baseline of adult action,  
  – errors occur but are named and worked through,  
  – `A–C–R–P` reasonably aligned,  
  – stable under pressure,  
  – dignity enactment mostly consistent: self-respect and respectful treatment of others.

* **`8–9` — high adultness** under severity  
  – complex situations handled with clarity, responsibility and courage,  
  – power and fallibility handled maturely,  
  – rare; appears where learning loops are actively used,  
  – dignity enactment is typically **high**, even in conflict.

* **`10` — ideal limit value**  
  – almost never a real case score,  
  – functions as **orientation**:  
    “What would maximally mature enactment look like here *in theory*?”  
  – in `D` terms: orientation, not a yardstick for shaming.

Important:

> A high **A-score** is **not an honour**;  
> a low **A-score** is **not a condemnation** – and **not a dignity claim**.

It is a **signal** of where the system stands –  
and what kind of intervention may help  
(increasing awareness, clarifying roles, redistributing responsibility,  
creating agency, making dignity enactments more conscious).

---

#### 5.1.4 Procedure: from profile to score

**Step 1 — create a structural profile**  
– go through `A–C–R–P`,  
– consider modulators (context, stress, publicity, dependencies),  
– clarify roles of object of observation and observers,  
– note where **dignity enactment** (`D₁/D₂`) is relevant –  
  but do **not** smuggle `D` into the **A-score**  
  (`D` is handled in the **D-profile**, section 5.3).

**D is described separately in the `D-profile`.**

**Step 2 — check micro-indicators**  
– for each axis, note observations indicating higher, medium or lower maturity,  
– distinguish:  
  *“How was the enactment performed?”* (**A-score**) vs.  
  *“How was dignity handled?”* (`D₁/D₂`; **D-profile**).

**Step 3 — determine the band**  
– is the situation more like `2–3`, `4–5`, `6–7` …?  
– better leave uncertainty explicit (`4–6`) than fake precision (`5.3`).

**Step 4 — set the score with reasoning**  
– record the **A-score**,  
– briefly justify why this **A-band** was chosen,  
– explicitly separate observations on maturity (`A–C–R–P`)  
  from those on dignity enactment (`D₁/D₂`).

**Step 5 — mark revision readiness**  
– note conditions under which the score might change  
  (new information, other perspectives, time).

**Mini-vignette:**  
A project team evaluates its crisis communication before and after a scandal.  
First time: **A-score** `3–4` (late reaction, defensiveness, little ownership).  
Second time: `5–6` (early transparency, named errors, visible consequences).  
The scores do not say “We are good people now,” but:  
“Our enactment became more mature – and our dignity enactment (`D₁/D₂`) became more conscious.”

Thus the **A-score** remains a **clarification tool**,  
not an authoritative judgment – and not hidden dignity evaluation.

---

### 5.2 **Trajectories** instead of labels

Once the **A-score** is introduced as a **snapshot**,  
the next question is:  
**“How do we handle time?”** – learning, relapse, context shift.

A single **A-score** is like a **photo**:  
it captures a moment, not movement.

Maturity in practice, however, is:

* learnable,  
* context-dependent,  
* developmental.

The same applies to dignity in practice (`D₁/D₂`):  
People can learn to handle themselves and others **more dignifyingly** –  
regardless of how chaotic individual episodes look.

Hence the model prefers **trajectories** over labels.

> **We write trajectories, not labels.**

---

#### 5.2.1 **A-score** as **snapshot**

Each score applies only to:

* this situation,  
* this setting,  
* this time.

When revisited later, the score may:

* rise,  
* fall,  
* oscillate.

What matters is not being “good” or “bad” once,  
but **how the line develops**.

Similarly, dignity enactments (self-care, self-devaluation, degrading others, etc.)  
can show development – captured in the **D-profile** (section 5.3),  
not in the **A-score**.

---

#### 5.2.2 **Development lines** (**trajectories**)

Typical trajectories visible in the model:

* **ascending line**  
  – low values grow into more mature practice via learning, correction, role clarification, reallocation of responsibility,  
  – errors become material for development,  
  – dignity enactments stabilise (less self-/other-degradation, more consistent self-respect).

* **descending line**  
  – initially solid maturity breaks under pressure, overload, power increase,  
  – `IA` grows, transparency and responsibility shrink,  
  – dignity enactment: more cynicism, shaming, self-neglect.

* **zigzag line**  
  – strong fluctuations depending on context, relationship, topic, audience,  
  – often indicates role confusion or structural tensions,  
  – dignity enactment oscillates: phases of self-care, then crashes.

* **plateau line**  
  – stable mid-range (e.g. `4–5`),  
  – stagnation: “We’re not progressing,”  
  – dignity enactment: habitual narratives (“that’s just who I am”) blocking development.

Key questions:

> **“How has maturity in practice changed over time – and why?”**  
> **“How has dignity enactment (`D₁/D₂`) changed over time?”**

---

#### 5.2.3 Why **trajectories** are more mature than labels

Labels (“X is immature,” “Y is exemplary”) freeze people and systems  
and threaten `D₀`, by conflating persons with scores.

**Trajectories**:

* allow errors without total condemnation,  
* make **learning** visible,  
* show structural blockages and tipping points,  
* support interventions that foster maturity and dignity in practice.

Thus:

* A low **A-score** may be part of an **ascending learning curve** – not a ground for degradation.  
* A high **A-score** may be part of a **descending curve** – not proof of “higher dignity.”

---

#### 5.2.4 Practical use

For practice:

* scores should be **dated** and **contextualised**  
  (`A(t₁) = 3–4 in setting X`, `A(t₂) = 5–6 after intervention Y`).  
* multiple measurement points serve to ask:
  – *better? worse? steadier?*  
  – not: “Who is ahead?”

Guiding formula:

> **The goal is a more mature trajectory –  
> and a more dignifying way of treating self and others –  
> not the fixation of labels.**

**Implication for the model:**

Chapter 5 makes `A` a **working instrument**:  
maturity becomes readable without reducing people to scores;  
**trajectories** matter more than single judgments.  
The **A-score** shows *how* one acted;  
the **D-profile** (`D₁/D₂`) shows *how* dignity was handled.  
Next, a framework for **shared responsibility** is needed:  
Who carried which leverage for the whole – and how can this be balanced fairly?  
This is precisely what the **M-score** develops in Chapter 6.

---

### 5.3 Conclusion

Chapter 5 defines the **A-score** as a working instrument for reading maturity in practice.

The **A-score** does not describe persons, essence or moral worth.  
It describes **enactments** in specific **episodes**, **roles** and **contexts**:

> **`A(H)` = maturity in practice of an enactment, case, or situation `H`.**

The score is built from the maturity of four enactment dimensions:

* **`A(A)`** – maturity of awareness
* **`A(C)`** – maturity of coherence
* **`A(R)`** – maturity of responsibility
* **`A(P)`** – maturity of action / power

It works through **bands**, not exact precision.  
The calibration zones from `0–1` to `10` are **enactment zones**, not person ranks.

The dignity layer remains separate:

* `D₀` remains untouched.
* `D₁/D₂` are not folded into the A-score.
* Dignity in practice is described separately in the **D-profile**.

Finally, Chapter 5 establishes the temporal logic of the model:

> **We write trajectories, not labels.**

A single A-score is only a snapshot.  
What matters is how maturity in practice develops over time: ascending, descending, zigzagging or plateauing.

Thus Chapter 5 makes maturity readable without moral labelling:  
the **A-score** shows *how maturely an enactment was performed*,  
while the **D-profile** shows *how dignity was handled*.
