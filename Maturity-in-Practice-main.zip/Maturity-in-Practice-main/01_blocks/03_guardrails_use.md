---
document_id: MIP-BLOCK-03
title: "Framework of Use and Guardrails"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/03_guardrails_use.md"
status: "split-full-version"
version: "v1"
block_id: "03"
block_role: "canonical core block"
source_chapter: 3
source_chapter_title: "Framework of use & guardrails (mandatory module)"
secondary_references: [1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12]
appendix_references: []
claim_mode: "praxeological, structural, guardrail-bound, dignity-protective, non-diagnostic"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice; optional high-risk module; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 3 heading up to immediately before chapter 4 heading"
---

# Maturity in practice — A praxeological anthropology: Framework of Use and Guardrails

## 3) Framework of use & **guardrails** (**mandatory module**)

Chapter 2 provided tools that can describe maturity, asymmetries and **D-enactments** in great detail. Precisely because of this, a new risk emerges: a model that makes maturity and **inadult asymmetry (`IA`)** visible can itself become an asymmetric weapon – for example when it is used to stigmatise, sanction or “down-score” individual persons.

This chapter defines **under which conditions** the model may be used at all –  
and where its use is **explicitly excluded**.

With the **D-module** this becomes doubly sensitive:

* The model touches **ontological dignity (`D₀`)**  
  **and**
* **praxeological dignity (`D`)** – i.e. concrete enactments of self-treatment:  
  self-care, self-devaluation, protest, adaptation, public self-objectification  
  (`D₁/D₂` as dignity in practice).

**Mini-vignette:**  
A team uses the `IA` framework to reflect on a conflictual decision. A leader suggests using the resulting `A` and `D` profiles as an argument for dismissals (“X is just immature”).  
This is precisely where the **guardrails** apply: the model must not be used for covert diagnostics or for moral sorting of persons.

Basic assumption:

> A tool that makes maturity, power asymmetries **and** **D-enactments** visible  
> creates a **discursive asymmetry** of its own.  
> This asymmetry is only functional if it is **restrained, justified and bounded**.

The **guardrails** are therefore not an add-on, but a **mandatory module**:  
without them, any `IA` analysis is **invalid** – regardless of how elegant it sounds or how “noble” the intention appears.

> **Guardrail rule:**  
> Without guardrails, any `IA` analysis is **invalid**.

---

### 3.1 **Structures, not persons** – zones

#### 3.1.1 **Profile ≠ person**

The model is a **procedural magnifying glass**, not an instrument for evaluating people “as a whole”.

It is interested in:

* **structures**  
  (distribution of power, architecture of responsibility, roles, rules),
* **enactments**  
  (concrete actions, decisions, communication patterns, self-enactments as dignity in practice, `D`),
* **contexts & modulators**  
  (time pressure, publicity, institutions, dependencies),

not in:

* judgements of personality (“X is a bad / worse person”),
* clinical diagnoses,
* moral overall rankings of individuals,
* ontological judgements about dignity (`D₀` – “this person is worth nothing”).

From this follows the basic rule:

> **Profile ≠ person.**  
> From observable behaviour, **profiles of structures and enactments** are derived –  
> not the “essence” of a human being.

---

#### 3.1.2 **System axiom:** no enactment is purely individual

> **System axiom:** no enactment is purely individual.  
> Every `IA` or maturity finding must also identify the structural co-causes  
> (**roles**, **organisation**, **modulators**, framework conditions).  
>
> Purely individual attributions (“X is immature”, “Y lacks dignity”)  
> without contextual and systemic analysis are, within this model, themselves  
> a form of **inadult reduction**.

In practice this means:

* Every finding must at least specify:
  * in which **role** someone acted,
  * in which **system** (organisation, family, online platform, public sphere …),
  * under which **modulators** (time pressure, dependency, uncertainty, threat …).
* Individual “inadult” enactments may  
  * be an expression of an **inadult personal dynamic**,  
  * but just as well of an **inadult system** that sanctions mature enactments  
    or systematically makes them harder.

The model thereby explicitly immunises itself against simple blaming:

> Wherever people merely say “X is immature” without reading the system alongside,  
> this is **not** an `IA` finding in the sense of this model – but itself an `IA`  
> in the handling of complexity.

---

For the **D-module** this means concretely:

* There is **no “dignity score” for persons**.
* There are only **dignity-enactment profiles (D-profiles)**:

  * how someone treats themselves  
    (self-dignity in practice, `D₁`, operationally via inner dignity `D-I` and bodily/material self-care `D-B`),
  * how someone positions themselves in relationships and towards society (**relational dignity `D-R`**),
  * how someone appears in public (**public dignity in practice `D-P`**).

A low **D-enactment** (`D`) means:

> “Here, dignity in practice is being violated –  
> through self-devaluation, through adaptation to practical degradation,  
> or through the degradation of others”,

but **not**:

> “This person is less dignified.”

To limit misuse, the model works with **zones** of application:

#### **Green zone — recommended use**

This is where the model belongs:

* Analysis of **structures**:

  * organisations, procedures, discourses, sets of rules, cultures, communication patterns.
* Work on **cases at a distance**:

  * historical situations, fictional scenarios, abstracted case vignettes.
* **Self-application**:

  * reflection on one’s own projects, decisions, roles, patterns, self-enactments (including `D`).
* **Clarifying frameworks** in professional contexts:

  * education, organisations, politics, media – provided it is used without person-ranking  
    and without diagnostics.

Typical questions in the green zone:

* How is responsibility distributed?
* Where do words and deeds diverge?
* Which roles are played in which ways – and where are they unclear?
* Which asymmetries are functional, which inadult?
* Where does someone treat themselves **systematically below** their dignity –  
  and where does that mirror a **degrading environment**?

#### **Yellow zone — caution**

Yellow are situations in which real affected persons are involved, but:

* the focus remains on **structures and procedures**,
* the analysis does **not** serve as a basis for decisions about individuals  
  (e.g. internal reflection processes, team supervision, mission statement work, ethics committees).

Conditions for the yellow zone:

* explicit embedding in a **framework of protection and responsibility**  
  (e.g. supervision, mediation, moderated workshops),
* clear communication about what the model can and cannot do,
* not the sole basis for sanctions, diagnoses, personnel decisions,
* particular restraint with the **D-module**:

  * `D` is used rather to make **needs for protection and support** visible  
    (“someone is treating themselves significantly below their dignity”),  
    not to “morally classify” someone.

#### **Red zone — forbidden**

**Red zone = use prohibited.**

These include, among others:

* **clinical diagnostics** and treatment planning  
  (psychiatry, psychotherapy, trauma therapy, addiction treatment, personality diagnostics),
* **HR decisions about individuals**  
  (recruitment, dismissals, promotions, performance evaluations),
* **child and youth diagnostics** in schools, youth services, families,
* **forensics, criminal prosecution, security agencies**  
  (risk assessments, sentencing, parole decisions),
* **public pillorying or ranking formats**  
  (lists of “toxic” persons, maturity rankings, moral leaderboards),
* **online doxing, cancel campaigns, shitstorms**  
  – any use of the model for retroactive shaming of individuals,
* specifically for the **D-module**:  
  – any form of **“humiliation diagnostics”** (“XY has no dignity”, “XY lives like garbage”),  
  – public speculation about D-profiles of individual real persons.

Note on the **double red zone**:

* In **2.6.1**, **D₀ red zone** designates the area in which `D₀` – ontological dignity –  
  is denied in language or practice (e.g. “subhumans”).
* In **3.1**, **use-context red zone** designates the **contexts of use** in which the model itself  
  must not be applied (diagnostics, HR, forensics, pillory formats, etc.).

Both levels are connected:

> Where `D₀` is denied, legitimate use of *any* `IA` analysis ends.  
> Where the use-context red zone is touched, using the model itself  
> becomes a risk to dignity – and is therefore excluded.

If a planned application even faintly smells of “red zone”, the rule is:

> **Do not use it.**  
> No fine-tuning, no exception, no “just a little” –  
> especially not with `D`.

**Interim conclusion for 3.1:**  
Chapter 3 begins with a double stipulation: the model may only target structures and enactments, never the value of persons – and no finding is valid that ignores the system. The zone logic marks where the tool belongs, where it may be used only under conditions, and where it is strictly taboo. The next section (3.2) clarifies what form of **minimal adulthood** users themselves must bring in order to use the model responsibly at all.

---

### 3.2 **Entry condition: minimal adulthood**

The model presupposes a certain **minimum mindset level** on the side of the user.  
It is not enough to know the terms or to be able to operate scorecards – what matters is **from which stance** they are used.  
Without a minimum willingness to self-critique and to protect dignity, the `IA` framework quickly turns into exactly what it criticises: an asymmetric technology of power.

> **Minimal adulthood = willingness to see oneself as involved and to keep dignity non-negotiable.**

Anyone using the model must be willing:

* to think about their own role in the case (**self-implication**),
* to accept unpleasant results also “for their own side”,
* not only to seek confirmation, but to allow **correction**,
* not to reduce complex situations to simple culprits,
* to distinguish between **ontological dignity (`D₀`)** (always intact) and **praxeological dignity**  
  (`D₁/D₂` as dignity-enactments, changeable).

#### Self-check gate

A simple self-question:

* **Do I want to use this to humiliate people, to win, to cut others down to size,  
  to “prove that they lack dignity”?**  
  → Then: **do not use the model.**
* **Do I want to see more clearly where I myself / we ourselves were wrong or blind –  
  including in our handling of dignity?**  
  → Then: **use the model** – under **guardrails**.

Minimal adulthood means concretely:

1. **No moral self-elevation**

   – no covert “I now see better than all of you”,  
   – no: “I decide who still deserves dignity.”

2. **No hunting for enemies**

   – the model is **not** a tool to “objectively” prove opponents’ immaturity  
     or “lack of dignity”,  
   – especially not through snippets of their D-enactment  
     (images, shitstorms, outbursts).

3. **Taking protection goods seriously**

   – dignity, protection of reputation, child protection, physical and psychological integrity  
     stand **above** any analysis,  
   – the value of persons remains outside the metric; `D` findings always apply only to  
     **concrete enactments**, never to the essence.

4. **Willingness to learn**

   – willingness to revise one’s own analysis later if new information  
     or falsifiers appear,  
   – willingness to say: “Here I denied the other side their dignity –  
     that was itself an inadult enactment.”

**Mini-vignette:**  
A team wants to analyse an escalated conflict using the model. One person realises: “I am still too hurt. If I now start evaluating D-enactments, I will just look for ammunition.”  
On this basis, the team decides: **postpone the analysis**, stabilise first – and return later with more distance.

From the perspective of the model it is therefore legitimate in practice to say:

> “Right now I am too angry / hurt / biased –  
> I do not meet minimal adulthood.  
> → I will **consciously not** apply the model now – especially not the D-module.”

That, too, is maturity in practice.

**Interim conclusion for 3.2:**  
Minimal adulthood is not a moral badge but an **entry condition**: whoever does not currently meet it best protects the model – and others – by **not** using it. The following procedural guardrails (3.3) translate this stance into concrete rules for every application.

---

### 3.3 Procedural **guardrails** (modules 1–6)

Minimal adulthood is the inner stance – the **procedural guardrails** are the outer form.  
They secure the **procedural integrity** of analyses and define **how** the model may be used.  
They apply to all parameters `A–C–R–P–D`, with particular sharpness once the **D-module** is activated.

The following guardrails secure the **procedural integrity** of analyses.  
They define **how** the model may be used.

They apply to all parameters `A–C–R–P–D`, with particular sharpness once `D` is in play.

#### **Guardrail 1 — structure before person**

* The focus lies on `A–C–R–P–D` and their modulators, not on characterology.
* Statements sound, for example, like:
  “In this structure, responsibility `R` is delegated downward” –  
  not: “Person Y is cowardly / toxic / inferior.”
* Profile formation is a **one-way street**:

  * *behaviour → structural profile / enactment profile*,  
  * but not: *profile → “This is who you are.”*

For dignity in practice this means:

* “Here, repeated self-devaluation is visible (`D-I/D-B` low)”  
  ≠ “You are worthless.”
* “Here, an institution is degrading entire groups”  
  ≠ “These groups are like that.”

#### **Guardrail 2 — dignity protection and anti-ranking**

* No use of the model for **public evaluation** of individuals.
* No lists, tables or scores that compare persons  
  (“who is more mature?”, “who has more dignity in practice?”).
* No ironic or demeaning framings  
  (“IA losers”, “toxic faction”, “zero-dignity profile”, etc.).
* Norm core:

  > **Dignity = non-negotiable; value of persons ≠ score.**  
  > Dignity in practice (`D₁/D₂`) only shows how someone – under conditions –  
  > is currently dealing with themselves / others / the world.

Any use of `D` that smells of “pillory” violates this guardrail.

#### **Guardrail 3 — duty of context and transparency**

* No quick evaluations without explicitly clarifying:

  * context (time, institution, public sphere, roles),
  * information status (what do we know for sure, what is an assumption?),
  * modulators (stress, leverage strength, persistence, protection goods, etc.).

* Analyses must make their **assumptions visible**:

  * What is observed?
  * What is interpreted?
  * What is speculation?

For `D` there is an additional point:

* Many D-enactments (`D₂` – relational dignity in practice) are **relational reactions** to practical degradation.
* Neglect, self-devaluation, radical adaptation can be protest, mirror,  
  or survival strategy.
* Anyone who quickly cries “own fault” or “lack of dignity” here  
  produces **structural inadult asymmetry** themselves.

Where context is unclear or highly contested, the mature answer is more often:

> “With this data, no robust `IA` or `D` analysis can be made.”

#### **Guardrail 4 — reciprocity and self-application**

* The model must **not** be applied only “from above to below”:  
  institutions, authors, analysts themselves must also be included in the view.
* Every analysis implies:  
  “What does this perspective say about **us**?” –  
  about our values, our blind spots, our handling of power and dignity?
* Anyone using the model commits to:

  * role reversal (how would the same structure look from the other side?),
  * self-check (which `IA` and `D` breaches do we produce ourselves?).

For `D` this means:

* The language and tone of the analysis are **themselves** dignity in practice:  
  – degrading language **about** affected persons  
    = a dignity breach (`D`) by the observers themselves.

#### **Guardrail 5 — option for improvement instead of judgement**

* Every `IA` or `D` reading must include a **repair or improvement option**:

  * What steps could bring awareness, coherence, responsibility and power (`A–C–R–P`) back into sync?
  * How could burdens be distributed more fairly?
  * Which asymmetries could be justified, limited or time-bound?
  * How could dignity in practice be **supported again**  
    (protection, alternatives, access, relief, mirroring, recognition)?

* Pure readings without any proposal (or at least search) for a gain in fairness or dignity are **inadult use** of the model.

#### **Guardrail 6 — versioning and reversibility**

* Analyses are **work-in-progress**, not final truths.

* It is explicitly permitted (and expected) that:

  * evaluations are revised,
  * scores are adjusted,
  * entire readings are discarded when falsifiers emerge.

* The model itself remains a **working draft** –  
  and demands this attitude from its users as well.

For dignity in practice this means:

* A once-identified low D-enactment  
  (“self-devaluation”, “self-abandonment”)  
  is **not a label**, but an invitation to observe trajectories:  
  – does it get better, worse, more stable?  
  – which structural changes support dignity?

**Meta-rule (applies to all guardrails):**

> As soon as a guardrail is **consciously ignored** or **circumvented**,  
> the `IA` / `D` analysis in question is **praxeologically void** –  
> it is not mature enough for publication, institutionalisation or use by third parties.

**Interim conclusion for 3.3:**  
The procedural guardrails keep the model on track: structure before person, protection against ranking, duty of context, reciprocity, focus on improvement, and reversibility. Whoever follows them uses the framework as a tool of clarification – whoever breaks them turns it into a weapon. The next section (3.4) makes this logic explicit for the analysts themselves: **who analyses, shows themselves.**

---

### 3.4 **Self-implication:** whoever analyses, shows themselves

Every application of the model says **at least as much** about the analysts  
as about the system under consideration.  
Self-implication means: `A–C–R–P–D` of the analysts becomes **readable too** – whether they want it or not.

**`A` – awareness of the analysts**

* Which contexts are taken into account, which are left out?
* Which sources and perspectives are taken seriously?
* Which D-enactments of others are noticed – which are not?

**`C` – coherence of the analysts**

* Do claim, language and practice match?
* Are guardrails observed?
* Is the distinction between ontological dignity (`D₀`) and dignity in practice (`D₁/D₂`) kept linguistically clear?

**`R` – responsibility of the analysts**

* Who bears the consequences of the analysis (reputation, trust, climate, risk)?
* Are uncertainties and assumptions disclosed?
* Is it made clear that `D` only evaluates enactment, not the value of persons?

**`P` – power of the analysts**

* How large is their leverage (institution, position, reach)?
* Which brakes do they apply (duty of context, red zones, ceiling rules, dignity protection)?
* How do they handle their own structural over-power?

**`D` – dignity in practice of the analysts**

* How do they linguistically handle criticism, not-knowing, ambivalence?
* Is language kept dignified even in sharp analysis?
* Are affected persons not dehumanised, even when structures are criticised harshly?

**Mini-vignette:**  
A report on institutional violence works cleanly with `A–C–R–P`, but describes individual affected persons as “passive”, “stupid” or “toxically dependent”. Formally, the analysis is sound – but in the D-enactment (`D`) of the authors, a degradation of those affected appears. Here the model would not only read the institution, but also the **report itself** as an `IA` / `D` case.

Two basic principles:

1. **There is no analysis “from nowhere”.**  
   Every analysis is itself an enactment of `A–C–R–P–D`.

2. **Analysts become actors themselves.**  
   Their maturity in practice shows in *how* they use the model – and *what* they bring about with it.

**Interim conclusion for 3.4:**  
Self-implication does not make users “neutral observers”, but responsible actors. Whoever analyses always also displays their own maturity, their handling of power and their dignity in practice. In the next step (3.5), this insight is sharpened further: into a dedicated guardrail that anchors **protection of dignity** at the centre of the model.

---

### 3.5 Dignity protection guardrail (ontological vs. praxeological)

The **D-module** is the **most sensitive part** of the model.  
To ensure its use does not itself become practical degradation, it is placed under an explicit protection framework.

Core formula:

> **Dignity guardrail:**  
> A human being remains dignified — even when they act in ways that lack dignity.  
> Only `D₁/D₂` are assessed in practice.  
> `D₀` is never assessed.

---

#### 3.5.1 Principle: the human being remains dignified

* **`D₀` – ontological dignity**
  – cannot be revoked  
  – non-gradual  
  – not “earnable”  
  – not measurable  
  – outside any analysis

* **`D₁` – praxeological self-dignity in practice**  
  – self-relation, self-care, self-devaluation, self-protection  
  – operationally visible via **inner dignity (`D-I`)** and **bodily/material self-care (`D-B`)**

* **`D₂` – relational dignity in practice**  
  – dealings with others, public sphere, roles  
  – operationally visible via **relational dignity (`D-R`)** and **public dignity / public dignity in practice (`D-P`)**

`D₀` is an **axiom**.  
Every `IA` analysis presupposes `D₀` and must never touch it.

Anyone who denies ontological dignity (“worthless”, “scum”, “subhuman”)  
does not strengthen the model but breaks it.  
That is a **dignity breach (`D`) on the part of the speaker**.

---

#### 3.5.2 `D` assessments only in practice, never in the value of the person

The following formulations are permitted:

* “In this scene, person X treats themselves in a way that lacks dignity.”
* “Over this trajectory, self-devaluation is visible (`D₁` low).”
* “This structure invites people to self-degrade.”

The following are not permitted:

* “X is a person without dignity.”
* “This group has no dignity.”
* “This is what you are.” (global attribution)

Obligation:

* `D` statements must always be **situational**:
  role – context – point in time – enactment.

Formulation rule:

* permitted:  
  **“In this role / under these conditions …”**

* forbidden:  
  **“You are …”**

---

#### 3.5.3 Misuse as its own `IA` and `D` finding

If the **D-module** is used to:

* shame,
* discipline,
* exclude,
* legitimise power imbalances (“their own fault”),

then this use itself creates a form of **inadult asymmetry**.  
In such cases the model shows:

> **The dignity breach lies with those using the model – not with those being evaluated.**

D-language is itself dignity in practice.  
Anyone who uses it in a degrading way shows **inadult asymmetry** – regardless of the case.

Mnemonic:

> **D is a protection instrument — not a pillory.**

**Interim conclusion for 3.5:**  
The dignity protection guardrail is the core of the **D-module**: it anchors `D₀` as untouchable, strictly limits `D` assessments to enactments, and treats misuse itself as an `IA` and `D` finding. On this basis, the following sections (3.6–3.7) clarify **when** explicit `D` findings may be activated at all and **how** `D` findings can be communicated without themselves violating dignity.

---

### 3.6 `D` as protected optional layer

The preceding sections have shown how sensitive the **D-module** is and how strongly it reacts to language, context and stance. To prevent it from becoming a covert tool of moralising or disciplining, it needs a clear place in the overall model: explicit `D` findings are not mandatory, but a protected optional layer that may only be activated under specific conditions. This chapter therefore clarifies how explicit `D` readings stay “off” by default, and in which exceptional cases a deliberate “`D` on” mode is meaningful and responsible.

**Standard analysis core:** `A–C–R–P`  
**Full model notation:** `A–C–R–P–D`  
**Protected optional layer:** explicit `D` findings

The **D-module** requires *particular care*.

---

#### 3.6.1 Default setting: `D` off

Standard mode of any analysis:

* focus on roles, responsibility, power, context
* parametrisation via `A–C–R–P`
* structural and trajectory analysis
* `T–J–TB–R` for functional vs. inadult asymmetries
* where applicable, M-score / A-score / IA-box

`D` remains in the background as something that is **kept in mind**, but is not:

* explicitly rastered,
* communicated,
* used as a comment on persons.

Why?

> **`D` requires a high level of maturity in practice on the side of the analysts.**  
> It is therefore activated only in a targeted way.

---

#### 3.6.2 When `D` may be activated

If `D` is exceptionally “switched on”, a clear reason is required. Activation must never happen casually; it is itself a decisive procedural choice.

Four minimal conditions:

1. **Clear purpose**  
   – self-clarification  
   – supervision / coaching  
   – structural critique (“Which enactments does this system invite?”)  
   – not: disciplining, evaluation, HR, diagnostics

2. **Safe framework**  
   – confidential or professionally guided  
   – roles clarified  
   – no sanction pressure  
   – no public sphere

3. **Minimal adulthood of users**  
   – acknowledging their own `D` readings and mistakes  
   – willingness to revise  
   – no hunt for enemies or culprits  
   – clear separation `D₀` ↔ `D₁/D₂`

4. **Minimal adulthood of those affected**  
   – no use with unstable self-relations, crises, dependency in hierarchies  
   – exception: careful, accompanied self-reflection

**Mini-vignette:**  
A person in a leadership role uses the model in coaching to understand why they so often make themselves small in conflicts. Here, `D₁` (self-dignity in practice) can be cautiously rastered. Using the same raster in employee reviews to “sort” team members would be a clear misuse.

---

#### 3.6.3 Red zones for `D`

*(no humiliation diagnostics, no pillory)*

`D` is **strictly forbidden** in:

* clinical diagnostics and treatment planning
* HR decisions (recruitment, dismissal, assessments)
* child and youth diagnostics
* forensics, criminal justice, security agencies
* public debates about identifiable individuals
* dependent power relations where it would be used to evaluate those in weaker positions
* online pillory formats, doxing, cancel / shitstorm dynamics

Permitted:  
**`D` for self-reflection of those in power** (“How dignified is our use of power?”).

Forbidden:  
**`D` for classifying those with less power.**

---

#### 3.6.4 Documentation duty: marking the use of `D`

Where the **D-module** is activated, this must be **transparently documented**:

1. **`D` activated: yes/no**, and if yes:
   – self-related `D` (`D₁` – self-dignity in practice, operationally via inner dignity `D-I` and bodily/material self-care `D-B`)  
   – structural `D` (degrading conditions that make dignity in practice harder)  
   – relational `D` (`D₂` – relational dignity in practice, operationally via relational dignity `D-R` and public dignity in practice `D-P`)

2. **Purpose of using `D`**  
   – self-clarification, team reflection, structural critique

3. **Risk note**  
   – possible misreadings  
   – power imbalances  
   – risk of shaming or pillory effects

`D` must never run “silently in the background”.  
It has to be treated as a **deliberate mode**.

**Interim conclusion for 3.6:**  
Explicit `D` findings are not standard output, but a high-risk instrument with high insight potential. As long as it is unclear whether purpose, framework and minimal adulthood are fulfilled, explicit `D` remains **off** in the default mode. Only when these criteria are explicitly met and documented can it be applied – limited, deliberate and recorded. In the next step (3.7) the focus is on how `D` findings can be communicated at all, without themselves producing new dignity breaches.

---

### 3.7 Publicity & communication of `D` findings

`D` findings are powerful:  
They say something about a person’s relationship to themselves (`D₁` – self-dignity in practice)  
and to the world (`D₂` – relational dignity in practice).  
For this reason, communication is especially sensitive.  
A single careless formulation can turn a careful analysis into a practice of humiliation.

Basic rule:

> **Talk about `D` primarily with people – not about them.**  
> And if one must talk about them, then structurally, anonymised, situationally.

---

#### 3.7.1 Differentiating **communication spaces**

Three spaces with different conditions:

---

##### 1) Self-related space

*(journaling, self-reflection, coaching)*

Permitted:

* `D` findings for one’s own orientation
* recognising one’s own patterns (self-devaluation, compliance, protest, refusal)
* dignity in practice as a mirror of one’s life enactment

Typical questions:

* “Where do I degrade myself (`D₁` low)?”
* “Where does my protest mirror degrading conditions (`D₂`)?”

---

##### 2) Professionally confidential space

*(supervision, intervision, professional discussions)*

Here, `D` can be used for:

* structural critique
* pattern recognition in teams / institutions
* situational, anonymised case work

Rules:

* no identifiable individuals
* no global labels
* D-profiles only in relation to context
* focus on protection, options, structural improvement

---

##### 3) Public space

*(media, talks, publications, politics)*

`D` findings about real individuals are **excluded**.  
Only allowed:

* **anonymised case vignettes**,
* **structural analyses** (“This practice invites self-degradation”),
* **public critique of context**, not evaluation of persons.

Basic principle:

> Public sphere = highest requirements for public/media awareness (`A-P`),  
> public agency (`P-PU`) and public dignity in practice (`D-P`).  
> Maximum restraint applies here.

---

#### 3.7.2 Forms of `D` communication

The dignity protection logic from 3.5–3.7 translates into three different forms of communication, depending on **who is present**, **what power relations apply** and **which space** is being used.

---

##### A) Direct `D` communication (with those affected)

Basic principle: **I-form, reversibility, co-interpretation.**

Examples:

* “I notice that in these situations you are very harsh with yourself.”
* “Here it seems as if you are making yourself smaller than you are.”

Emphasise reversibility:

* “This is not a label but a current reading that can change.”

Offer joint review:

* “How would you describe this yourself? Does this resonate with you?”

Rules:

* Clear context reference (role, time, scene).
* No identity statements (“You are …”).
* Emphasis on possibilities, not deficits.
* Goal: to **strengthen** dignity in practice, not restrict it.

---

##### B) Professionally indirect `D` communication (about those absent)

Use: structural and practice reflection in supervision, intervision, professional talks.

Rules:

* situational and anonymised,
* focus on **conditions**, not character,
* clear separation between **`D₁` (self-enactment / self-dignity in practice)** and **`D₂` (reactive relational enactment / relational dignity in practice)**.

Examples:

* “In this role, person X had hardly any opportunities for a dignified self-enactment (`D₁`).”
* “This structure encourages relationally degrading patterns (`D₂`).”
* “The setting makes it difficult to take oneself seriously.”

---

##### C) Public / political / media `D` communication

Strict boundary: **No `D` attributions to identifiable individuals.**

Permitted:

* anonymised case vignettes,
* structural critique:

  * “This practice degrades people.”
  * “This system pushes entire groups into patterns of self-devaluation.”

Not permitted:

* diagnostics by the public,
* “lacking dignity” labels applied to real individuals,
* speculative attributions about `D₁/D₂` of other people.

Basic principle:

> Apply `D` publicly **only** to structures – never to individuals.

---

#### 3.7.3 Language rules for `D` findings

Goal: avoid degrading language, emphasise reversibility, make context visible.

Helps for rephrasing:

* Instead of “X has lost their dignity”:

  → “In this situation, dignity in practice (`D₁/D₂`) was hardly livable.”

* Instead of “They live without dignity”:

  → “The conditions make a dignified enactment extremely difficult.”

* Instead of “They do not respect themselves”:

  → “Many options for a dignified way of dealing with oneself are not visible in this structure.”

Rules:

* Duty of context: always name role, situation, timeframe.
* No ontological judgements (“undignified”, “worthless”).
* Reversibility in language: enactments can change.
* No transition from observation → identity.

---

#### 3.7.4 `D` findings under power asymmetries

In strongly asymmetric roles (management/staff, professionals/clients, politics/base) the following applies:

> **The greater the power asymmetry, the more cautious and structure-focused `D` language must be.**

Consequences:

* No attributions about “staff/clients without dignity”.

* Instead:

  * “Working conditions make dignified self-enactment (`D₁`) difficult.”
  * “This structure generates relationally degrading patterns (`D₂`).”

* If this rule is violated, a **double inadult asymmetry** arises:

  1. inadult asymmetry in the field (degrading structures),
  2. inadult asymmetry in interpretation (degrading language by those with power).

Key point:

* Micro-humiliations, subtle shaming, covert devaluation count as `D₂` risks.
* Communicative power is itself a D-enactment (`D₂` of the speakers).

---

### 3.8 Conclusion

Chapter 3 shifts the focus from *can* to *may*: it is not enough to analyse maturity, power and D-enactments precisely – what matters is **how responsibly** the model is used. Minimal adulthood, procedural guardrails, self-implication and protection of dignity together form the safety framework without which any `IA` or `D` analysis is praxeologically void. Those who take these guardrails seriously do not use the framework as a moral machine, but as a tool to make structures fairer, enactments more mature and dignity in everyday life **more visible and better protected**.
