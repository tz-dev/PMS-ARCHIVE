---
document_id: MIP-BLOCK-08
title: "Domain Modules"
source: "00_source/Maturity in practice - A praxeological anthropology.md"
source_role: "canonical full-block extraction"
target_file: "01_blocks/08_domain_modules.md"
status: "split-full-version"
version: "v1"
block_id: "08"
block_role: "canonical core block"
source_chapter: 8
source_chapter_title: "Domain Modules – Grids for Levels & Fields"
secondary_references: [1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12]
appendix_references: ["Appendix D"]
claim_mode: "praxeological, domain-adaptive, lens-based, non-expansive, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "Dignity-in-practice domain lens; D₀ untouchable; not person score"
mip_status: "canonical core block; direct extraction; no content expansion"
split_rule: "include from chapter 8 heading up to immediately before chapter 9 heading"
---

# Maturity in practice — A praxeological anthropology: Domain Modules

## 8) **Domain Modules** – Grids for Levels & Fields

The core model is **domain-agnostic**:  
`A–C–R–P–D`, the **A-score**, the **M-score**, the **IA-box**, role logic and the dignity-in-practice module  
can be applied in many fields.

For practice, however, it is useful to make typical **hotspots per domain** visible:  
points at which maturity in practice, power and dignity repeatedly become especially sensitive.

> **Domain-module boundary:**  
> **Domain Modules** do not introduce a new model.  
> They are **lenses** for domain-specific hotspots.

**Same axiomatic core. Different lens. Different depth. Different activated modules.**

**Domain Modules** correspond to field-specific **discipline profiles** in the model layer:  
same axiomatic core, field-specific lens, field-specific activation set, field-specific typical questions.

This chapter unfolds five example fields:

* **psychology (performative)**
* **philosophy and religion**
* **sociology and politics**
* **culture / media**
* **practice ethics** — **law / organization / education**

Additional domains can be added following the same pattern.

---

### 8.1 **Psychology (performative)**

**Function:** performative lens / hotspot map  
**Not:** clinical diagnosis, disorder classification, therapy planning

This module intentionally stays **outside clinical diagnostics**.  
It replaces:

* no diagnoses,
* no disorder classification,
* no therapy planning.

It asks only:

> **“What is the pattern of enactment – regardless of whether someone has a diagnosis?”**

Thus the module describes **observable enactments**,  
without pathologising or degrading people.

Typical application fields:

* self-exploration  
  (“How do I structurally react in conflict, closeness, stress?”),
* coaching, supervision, counselling (**respecting red-zone boundaries**),
* reflection on relational patterns without diagnostic vocabulary,
* optional dignity reading in the sense of:

  – “How do I treat myself?”  
    (shaping my self-dignity in practice, `D₁`, stabilising or devaluing?)  
  – “How do I treat others in my close environment?”  
    (relational dignity `D₂`).

**Key parameters:**

* **`A-I` – inner awareness**:  
  contact with impulses, feelings, ambivalence.

* **`A-R` – role awareness**:  
  “Who am I here – partner, parent, colleague, superior, client?”

* **`R-I` – individual responsibility**:  
  one’s own share vs. pure externalisation.

* **`P-I` – inner agency**:  
  experienced self-efficacy, ability to take small reversible steps.

* **`D-I` – inner dignity** *(optional)* as part of self-dignity in practice (`D₁`):  
  self-care vs. self-devaluation.

**Typical `IA` patterns:**

* **role vacuums in relationships**  
  (projections, phantom intentions, dignity injuries in close settings).

* **responsibility over-assumption / avoidance**  
  (hyper-responsibility + self-devaluation vs. complete externalisation).

* **experienced powerlessness despite real options**  
  (felt vs. actual agency; `P-I` low although options exist).

*Mini-vignette:*

> Anna, a team lead, experiences every team conflict as “failure.”  
> She assumes responsibility (`R-I`) even where others have clear shares  
> and speaks internally in self-devaluing ways.  
> The module helps to distinguish:  
> **`A-theme`** — how she acts,  
> **`M-theme`** — how much shared responsibility she structurally carries,  
> **`D-theme`** — how she treats herself in practice.

The module works **performatively**, not clinical:

* It describes patterns: avoidance, role mixing, failing to mark contexts, making oneself small.
* It asks:  
  – “What do you do when …?”  
  – “Which role do you then take?”  
  – “How do you treat yourself before, during and after the situation?” (`D₁/D₂`)

**Dignity note:**

* Dignity profiles in this domain are strictly **self-referential** or **safely framed**.
* They must **never** be used as labels  
  (“you lack dignity”, “you have no self-respect”),
  but only as descriptions of **enactments that can change**.

---

### 8.2 **Philosophy & Religion**

**Function:** lens / hotspot map for interpretive authority, dignity norms and dignity in practice  
**Not:** replacement for doctrinal judgement, ultimate doctrine or domain expertise

Philosophy and religion are fields in which humans attempt to organise  
**truth, meaning, good/evil and dignity**.  
They shape big concepts, tell stories, design rituals –  
thereby creating frameworks through which people read themselves and others.

This module is **not** concerned with whether certain teachings are “true.”  
It asks praxeologically:

> **How do specific philosophical or religious orders  
> organise interpretive authority, responsibility and dignity in practice?**

This makes visible when a tradition **fulfils** its own dignity claims –  
and when it **undermines** them in practice.

**Context-sensitive D-reading:**  
D reads practice.  
D does not monopolise dignity.  
D does not decide ultimate doctrine.

---

#### Ontological dignity vs. the dignity-in-practice module

Many traditions recognise a form of **ontological dignity** –  
e.g., as imago, as rational being, as created or willed by the divine/absolute.

In the model this is:

* **`D₀` – ontological dignity**  
  – inviolable personhood,  
  – not gradual,  
  – not “earned,”  
  – outside all evaluation.

The model adopts `D₀` as **untouchable constant**.

The dignity-in-practice module instead asks praxeologically:

* **`D₁` – self-dignity in practice**  
  – how people treat themselves  
    (self-care, self-devaluation, ascetic practices, guilt regimes …)

* **`D₂` – relational dignity in practice**  
  – how people treat others in the name of a teaching  
    (inclusion, exclusion, shaming, recognition, handling doubt)

In short:

> **`D₀` says: “You are dignified.”  
> `D₁/D₂` ask: “How do you – and how do we – practically act with this dignity?”**

---

#### Core questions in this module

* Is `D₀` **proclaimed**, yet systematically undermined in practice?
* Are people marked as “unworthy” **beyond specific actions**?
* Are guilt, shame and purification framed such that `D₁` stabilises –  
  or such that lasting self-devaluation is fostered?
* Can people leave or change roles **without** losing relational dignity in practice (`D₂`) permanently?
* **Who sets the norm?**
* **Who benefits?**
* **Who is excluded?**

*Mini-vignette:*

> A community teaches: “Every human has inviolable dignity.”  
> At the same time, people who leave are publicly labelled “traitors,”  
> and contact with them is deemed “spiritually dangerous.”  
> Praxeologically, `D₀` remains asserted,  
> but `D₂` is severely violated in practice.

---

#### Key parameters

In philosophical–religious fields, the following matter:

* **`C-N` – narrative coherence**  
  – Which dignity/indignity archetypes appear in stories?  
  – Who is allowed to fail and be reintegrated – who is not?

* **`R-E` – ethical responsibility**  
  – Who sets norms?  
  – Who defines “sin,” “error,” “holiness”?  
  – What practical consequences do these definitions have?

* **`P-C` – cultural agency**  
  – Who defines symbols, rituals, teachings?  
  – Which groups can revise them – which cannot?

* **`A-C / A-R` – context and role awareness of interpreters**  
  – Do those speaking know **which role** they speak from  
    (pastoral, doctrinal, power position)?  
  – Are they aware of the reach of their words (culture, media, family systems)?

* **`D-R` – relational dignity**  
  – How are seekers, doubters, “sinners,” ex-members treated?  
  – Are they accompanied, shamed, excluded, instrumentalised?

---

#### Typical `IA` risks

* **non-transparent authority**  
  – “It is so because we say so,” without reason that can be examined.

* **unbounded interpretive authority**  
  – a small group defines what counts as “dignified/undignified”  
    without review mechanisms.

* **irreversible stigmatisation**  
  – once cast out, “forever lost,” with no real path to return or redefine  
    (violation of `T–J–TB–R`).

* **praxeological degradation despite dignity rhetoric**  
  – public shaming rituals,  
  – forced confession,  
  – spiritually justified violence or neglect.

---

#### The dignity guardrail in this module

The model does **not** judge who is “dignified before God / the Absolute,”  
nor does it prescribe doctrinal correctness.

It describes only:

* **how** people treat each other in practice,
* **how** maturity in practice (`A`), shared responsibility (`M`) and dignity enactments (`D₁/D₂`)  
  are embedded in structures and rituals,
* **where** degradation is systematically embedded  
  and where dignity is practically upheld.

Closing question for this module:

> **Do certain philosophical or religious forms  
> strengthen maturity and dignity in practice –  
> or do they create wounds later framed as an individual’s “private problem”?**

---

### 8.3 **Sociology & Politics**  
*(including symbolic politics, `IA/D` heatmap)*

**Function:** lens / hotspot map for power, public responsibility and dignity effects  
**Not:** replacement for political judgement, social-scientific expertise or democratic process

In the sociopolitical field we observe  
how entire societies handle asymmetries:

* Who has power and resources?
* Who defines problems and solutions?
* Who bears the costs?
* And: **Who can afford which dignity enactment?**

This module focuses **not** on single individuals but on:

* **institutions** (state, administration, parties, associations …),
* **political processes** (legislation, campaigns, negotiations),
* **discourses** (public debate, narratives, media framing),
* and their effects on dignity in everyday life  
  (**`D₂` – relational dignity**, **`D-P` – dignity in public enactment**).

**Context-sensitive D-reading:**  
Sociopolitical dignity norms are read as practice-bound.  
The module asks: **who sets the norm? who benefits? who is excluded?**

---

#### Key parameters

Central parameters in this field:

* **`C-P` – coherence in power contexts**  
  – Who can formally/informally set and change rules?  
  – Which actors have structural advantages?

* **`R-P` – public responsibility**  
  – Who carries responsibility for consequences affecting many  
    (laws, cuts, security decisions)?

* **`P-PU` – public agency**  
  – Who has reach, resources, media access, enforcement tools?

* **`A-P` – awareness of publicity**  
  – How aware are actors that their speech and enactment  
    are publicly read, archived and reinterpreted?

* **`D-R / D-P` – relational and public dignity**  
  – Which groups are elevated, degraded, stigmatised or protected?  
  – Where is dignity practically safeguarded (rights, protections) –  
    and where undermined (stigma, shaming, invisibilisation)?

---

#### Symbolic politics

Symbolic politics means:

> **Actions that primarily create meaning** –  
> but have limited or indirect material impact.

Examples:

* flags, commemorations, minutes of silence,
* appeals, statements, resolutions,
* “sending messages” on social media.

The model asks:

* Is symbolic politics **transparent** as symbolic –  
  or sold as the “actual solution”?
* Is it **justified** – which protected good is pursued  
  (minority protection, mourning, position-taking)?
* Is it **time-bound** – or used to permanently replace structural work?
* Is it **reversible** – can the symbol be questioned, modified or ended  
  without criticism being cast as betrayal?

`IA` alarms appear:

* when symbolic acts **mask real responsibility**,
* when costs of symbolic actions fall mainly on weaker groups,
* when interpretive authority over symbols is highly uneven  
  (**`C-P / P-PU`** high, **`A-P / D-P`** of affected groups low),
* when symbolic politics produces **dignity effects** that remain unnamed:  
  – groups marked as “problem,” “danger,” “burden,”  
  – suffering symbolically “performed” but not practically addressed.

*Mini-vignette:*

> A city declares a “Year of Dignity” and fills public space with slogans.  
> Simultaneously, social budgets are cut, support centres close,  
> and affected people are barely heard.  
> The **IA-box** shows: high symbolic intensity, low structural responsibility;  
> the `D₂` of those affected declines.

Dignity reading:

* Symbolic politics can **protect dignity**  
  – e.g., by making visible who deserves protection  
    and which groups must no longer be ignored.

* It can also be **degrading**,  
  when people are reduced to **symbols** (images, hashtags, “the affected”)  
  while real transfers of agency (`P`), responsibility (`M`) or resources do not occur.

---

#### `IA/D` heatmap

The **`IA/D` heatmap** is a tool to visualise concentrations of:

* **inadult asymmetry (`IA`)** and
* **praxeological degradation (`D₁/D₂`, especially `D-P`)**

within a social or political field.

It asks:

* Where in the system do we see clusters of:

  * non-transparent power decisions,
  * un-/pseudo-justified privileges,
  * unbounded or irreversible sanctions,
  * forms of public degradation (`D-P` as expression of `D₂`),
  * zones of systematic self-devaluation of certain groups  
    (e.g., poverty, stigma, exclusion)?

Practically:

* Results from **A-score**, **M-score**, **IA-box** and **D-profiles**  
  are plotted spatially or institutionally,
* areas with high density of `IA` and dignity violations “glow” – become “hot.”

Distinction:

* **`IA` hotspots**  
  – structures are built problematically  
    (power, responsibility, knowledge, reversibility poorly distributed).

* **Dignity hotspots**  
  – enactments, discourses and practices degrade people in daily life  
    (e.g., ongoing ridicule, selective visibility, permanent deficit marking).

These zones are:

* indicators of **reform need**,
* warning signs for future escalations,
* priority areas for protection, monitoring and participation.

Closing lens:

> The Sociology & Politics module prevents the model  
> from being misunderstood as merely “psychological.”  
> It directs attention to **power and structural architecture** –  
> including the question:
>
> **“Which people/groups must live in which ways  
> for our structures to remain stable – and at what dignity cost?”**

---

### 8.4 **Culture / Media**

**Function:** lens / hotspot map for narratives, representation, publicity and dignity effects  
**Not:** replacement for cultural judgement, art criticism, media expertise or public validity

In **culture / media**, the model is especially sensitive to:

* role images,
* narratives,
* representation,
* publicity effects,
* **normalisation or erosion of dignity in practice**  
  (especially `D-R` – relational dignity, and `D-P` – dignity in public enactment).

Culture and media work through stories, images and atmospheres.  
They shape what we imagine as “normal life,” a “good relationship,”  
a “successful person” – indirectly shaping what counts as dignified or as “your own fault.”  
Thus this module is less art criticism and more a grid for **how** cultural products  
make `IA` patterns and dignity enactments visible, invisible or “cool.”

Boundary warnings:

> **Publicity is not truth.**  
> **Virality is not justification.**  
> **Visibility increases reversibility risk.**

Objects of analysis may include:

* **characters and stories** (fiction, series, films, games),
* **cultural debates** (reviews, controversies),
* **media practices** (platform rules, algorithms, gatekeeping),
* **self-presentation** (influencing, personal branding, mediated self-objectification).

**Key parameters:**

* **`C-N` – narrative context**  
  – What archetypes, roles, conflicts are shown?  
  – Which forms of dignity/degradation appear “normal,” “deserved,” “funny”?

* **`A-P / P-PU`**  
  – How visible is something, how large its effect on perception?  
  – How aware are creators that their enactments enter public dignity dynamics?

* **`P-C` – cultural agency**  
  – Who can introduce and normalise images, metaphors and tropes?

* **`R-P / R-E`**  
  – What responsibility is taken for the patterns being shown –  
    especially where they shape dignity images?

* **`D-P` – public dignity enactment**  
  – How are people, groups, minorities represented?  
  – Are they portrayed as full subjects – or as joke, threat, object?  
  – Are characters given chances to regain dignity in practice  
    (repair, apology, restoration),  
    or kept fixed in degrading roles?

Typical questions:

* Which **role images** are stabilised  
  (e.g., gender, power, relational models)?

* Are the asymmetries portrayed:

  * **reflected** (as tension, problem, learning arc),
  * or **romanticised / trivialised** (as “normal,” “exciting,” “inevitable”)?

* How do creators handle their **public responsibility**  
  when characters/themes strongly resonate?

* Which **dignity patterns** are portrayed as desirable or ridiculous?

  – self-care vs. self-sacrifice,  
  – boundary-setting vs. “selfless devotion,”  
  – degrading others vs. empathy.

*Mini-vignette:*

> A popular series portrays a character who constantly humiliates others publicly –  
> celebrated as “witty.”  
> Across seasons this pattern remains unchallenged.  
> Praxeologically, a `D-P` profile emerges in which subtle humiliation  
> is coded as humor and strength –  
> allowing `IA` and degradation to “travel” culturally.

The module enables, for example:

* discussing works not merely as “I like it / I don’t,”  
  but as **structural proposals for reality**:  
  – Which `IA` patterns are reproduced?  
  – Where does culture show alternatives, corrections, learning pathways?  
  – Which practices of **dignity restoration**  
    (apology, repair, reframing) appear?

It leaves open whether a portrayal is “good” or “bad,”  
but it makes the **structure of roles, responsibility and agency** visible  
that travels through culture into minds and practices –  
including images of:

> **“Who counts as dignified – who may be funny, weak, vulnerable  
> without being dehumanised?”**

For practice this means:

* Cultural/media analysis using this module can succinctly reveal  
  **which enactments are normalised** –  
  and which alternatives are absent.

* It invites attention to narratives that strengthen  
  **dignity in practice**,  
  rather than recycling degradation as entertainment.

---

### 8.5 **Practice Ethics** (**Law / Organization / Education**)

**Function:** lens / hotspot map for institutionally intended asymmetries  
**Not:** replacement for legal, organisational, educational or professional judgement

> **Practice-ethics boundary:**  
> MIP may structure reflection.  
> It does not replace legal judgement, organisational due process, educational responsibility, or professional accountability.

Here the model encounters fields in which:

* asymmetries are **institutionally intended**  
  (legal systems, organizations, schools, care structures),
* norms and sanctions are **encoded**,
* responsibility and power (power to act) are **formally assigned**,
* and **dignity** is explicitly named as a protected good — yet can easily be undermined in practice.

Praxeological question:

> **Are these asymmetries functionally built — or drifting into inadult forms  
> in which protection and dignity are asserted but not enacted?**

This is precisely where it becomes visible whether noble mission statements  
(“respect human dignity,” “empower children,” “leadership at eye level”)  
hold up in everyday practice — or whether structures and routines  
produce the opposite.

**Key parameters:**

* **`C-I` (institutional / rule coherence)**  
  – How coherent are rules, their justifications, and lived practice?

* **`R-S / R-P` (social / public responsibility)**  
  – Who carries responsibility for the wellbeing of those with less power?

* **`P-S / P-PU` (social / public agency)**  
  – Who can intervene, limit, or protect in concrete situations?

* **`A-P / A-R` (public and role awareness)**  
  – How clearly are roles understood  
    (judge/defendant, teacher/student, leader/employee)?

* **`D-R / D-P` (relational and public dignity in practice)**  
  – How are people in vulnerable positions treated  
    (accused persons, clients, children, employees, patients)?  
  – Are there clear protections against humiliation, shaming, degradation in practice?

Typical application fields:

* **Law:**  
  – Are sanctions, procedures and powers  
    transparent, justified, time-bound, and reversible?  
  – Where do structures emerge that permanently stigmatize people  
    without real rehabilitation pathways?  
  – Are there mechanisms that protect dignity in practice:  
    – respectful speech,  
    – avoidance of unnecessary exposure,  
    – clear separation between criticism of an action and degradation of a person?

*Mini-vignette (Law):*

> A person appears in court and is addressed respectfully,  
> yet is held in overcrowded group cells and exposed to media presence  
> without necessity.  
> Structurally, the procedure may be lawful,  
> but praxeologically a `D-P` problem emerges:  
> dignity in practice during the process contradicts the rhetoric of respect.

* **Organizations** (companies, administrations, NGOs …):  
  – How are leadership roles, goal conflicts and performance pressure structured?  
  – Are protection mechanisms for weaker parties (employees, clients) functional or merely formal?  
  – Where do degrading practices emerge:  
    – public disparagement,  
    – “naming & shaming,”  
    – subtle humiliation in feedback settings?

* **Education:**  
  – How are power and knowledge asymmetries between adults and children/youth shaped?  
  – Are there traceable, reviewable pathways out of sanctions, role fixations, labels?  
  – Is discipline designed such that **behaviour** is addressed — not the **value of the person**?

The Practice Ethics module directly connects to the **M-score**, the **ceiling rule**,  
and the dignity-in-practice module:

* **High M-scores** typically belong to:

  * institutional carriers,
  * leadership levels,
  * norm setters (law, guidelines, curricula).

* **Low M-scores** typically belong to:

  * children,
  * dependent persons,
  * people without real alternatives.

Dignity reading:

* Dignity in practice (`D`) is shaped **institutionally** in these fields:  
  – through procedural logic,  
  – through language,  
  – through symbolic forms (rituals, clothing, spaces),  
  – through complaint and correction channels.

The central question here becomes:

> **Are our asymmetric practice structures built in ways  
> that promote learning, protection, development and dignity in practice —  
> or do they cement `IA` and degradation that is no longer functional?**

Guardrail:

* The model may be used to mark **structures**  
  as dignity-protecting or dignity-undermining,
* not to label individuals in the system as “dignified/undignified.”

For readers this means:

* Anyone carrying responsibility in law, organizations or education  
  can use this module to examine very concretely  
  **where** structures are adult in design —
  and **where** they produce `IA` and dignity breaches  
  even when no one “means harm.”
* Thus, practice ethics becomes a question of  
  **the architecture of enactments**,  
  not merely of intentions.

---

### 8.6 Conclusion

Chapter 8 translates the same model core into **Domain Modules**.

These modules are **lenses**, not new models.  
They identify **hotspots per domain**, field-specific **discipline profiles**, typical questions and activated modules — without replacing domain expertise.

Across all fields, the same boundary holds:

* **Psychology** remains **performative**, not clinical.
* **Philosophy & Religion** are read through **context-sensitive D-reading**, without deciding ultimate doctrine.
* **Sociology & Politics** focuses on power, public responsibility and dignity effects, without becoming a political verdict.
* **Culture / Media** reads narratives, publicity and representation, without treating visibility as truth or virality as justification.
* **Practice Ethics** may structure reflection, but does not replace legal judgement, organisational due process, educational responsibility or professional accountability.

Thus Chapter 8 makes the model field-sensitive without making it domain-authoritative:  
`A–C–R–P–D`, **A-score**, **M-score**, **IA-box** and **D-profile** remain the same tools —  
activated differently, bounded by guardrails, and always directed at enactments and structures rather than personhood.
