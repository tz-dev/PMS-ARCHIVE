---
document_id: "MIP-EXAMPLE-01-MINIMAL-PUBLIC-CRITICISM"
title: "Minimal Public Criticism in a Team Meeting"
source_role: "derived example markdown from case YAML"
source_file: "05_model/examples/01_Minimal_Public_Criticism.yaml"
target_file: "05_model/examples/01_Minimal_Public_Criticism.md"
status: "derived-example-markdown"
version: "v1"
example_role: "generic team-training case"
canonical_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
model_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
claim_mode: "case analysis, derived, non-expansive"
mip_status: "supporting example file; not a replacement for canonical model or paper blocks"
generation_rule: "render all existing YAML fields into human-readable markdown; do not add new theory or omit case information"
schema_version: "MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned"
source_file_name: "01_Minimal_Public_Criticism.yaml"
source_model: "MIP - Maturity in Practice.yaml"
---

# Minimal Public Criticism in a Team Meeting

> Derived Markdown rendering of the complete YAML case. Field names are preserved in backticks so the file remains traceable to the YAML structure.

## Source YAML Metadata

- **Schema Version (`schema_version`):** MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned
- **File Name (`file_name`):** 01_Minimal_Public_Criticism.yaml
- **Source Model (`source_model`):** MIP - Maturity in Practice.yaml

## 1. Meta

- **Case Id (`case_id`):** 01_Minimal_Public_Criticism
- **Case Title (`case_title`):** Minimal Public Criticism in a Team Meeting
- **Documentation Date (`documentation_date`):** 2026-05-23
### Analysts (`analysts`)

- **structural_case_analyst**
  - **Name (`name`):** ChatGPT
  - **Role (`role`):** structural_case_analyst
  - **Observer Position (`observer_position`):** external_model_application_to_generic_training_case

- **Language (`language`):** en
- **Confidentiality Level (`confidentiality_level`):** public_generalised
- **Analysis Mode (`analysis_mode`):** full
- **Intended Use (`intended_use`):** training_simulation
- **Application Zone (`application_zone`):** green
### Interaction Profile (`interaction_profile`)

- **Reflection Mode (`reflection_mode`):** off
- **D Module Preference (`d_module_preference`):** auto
- **Output Format (`output_format`):** yaml
- **Discipline Profile (`discipline_profile`):** generic
- **D Activation Decision (`d_activation_decision`):** activated_qualitatively_under_guardrails
- **Transmission Default (`transmission_default`):** working_note_until_checked


## 2. Guardrails

- **Profile Not Person (`profile_not_person`):** `true`
- **Focus On Roles Structures Enactments (`focus_on_roles_structures_enactments`):** `true`
- **Minimal Adulthood Checked (`minimal_adulthood_checked`):** `true`
- **Analyst Self Implication Acknowledged (`analyst_self_implication_acknowledged`):** `true`
- **System Axiom Applied (`system_axiom_applied`):** `true`
### Use Context (`use_context`)

- **Roles Clarified (`roles_clarified`):** `true`
- **Observer Position Clarified (`observer_position_clarified`):** `true`
- **Information Basis Clarified (`information_basis_clarified`):** `true`
- **Analysis Purpose Clarified (`analysis_purpose_clarified`):** `true`
- **Publicness Clarified (`publicness_clarified`):** `true`

### Red Zone Check (`red_zone_check`)

- **Clinical Diagnostics (`clinical_diagnostics`):** `false`
- **Therapy Planning (`therapy_planning`):** `false`
- **Forensics (`forensics`):** `false`
- **Individual Hr Decisions (`individual_HR_decisions`):** `false`
- **Child Youth Diagnostics (`child_youth_diagnostics`):** `false`
- **Public Pillory Or Ranking (`public_pillory_or_ranking`):** `false`
- **Online Shaming Or Doxing (`online_shaming_or_doxing`):** `false`
- **Humiliation Diagnostics (`humiliation_diagnostics`):** `false`
- **Public D Readings Of Identifiable Persons (`public_D_readings_of_identifiable_persons`):** `false`
- **Any Red Zone Touched (`any_red_zone_touched`):** `false`
- **If Any True (`if_any_true`):** do_not_apply_model

### Dignity Protection (`dignity_protection`)

- **D0 Untouched (`D0_untouched`):** `true`
- **D1/D2 Enactments Only (`D1_D2_enactments_only`):** `true`
- **No Dignity Score (`no_dignity_score`):** `true`
- **No Person Labels From D (`no_person_labels_from_D`):** `true`
- **D Default Off (`D_default_off`):** `true`
- **D Activated (`D_activated`):** `true`
- **If D Activated Guardrails Checked (`if_D_activated_guardrails_checked`):** `true`
- **If D Creates More Shame Than Clarity (`if_D_creates_more_shame_than_clarity`):** dial_D_down

### Score Hygiene (`score_hygiene`)

- **A Score Band Not Person Score (`A_score_band_not_person_score`):** `true`
- **M Score Shared Responsibility Not Guilt (`M_score_shared_responsibility_not_guilt`):** `true`
- **D Profile Not Dignity Score (`D_profile_not_dignity_score`):** `true`
- **Ia Box Not Verdict (`IA_box_not_verdict`):** `true`

- **Tragedy Clause Considered (`tragedy_clause_considered`):** `true`
- **Misuse As Own Finding Acknowledged (`misuse_as_own_finding_acknowledged`):** `true`

## 3. Information Basis

- **Primary Material (`primary_material`):** Generic case prompt: public criticism in a team meeting.
- **Secondary Material (`secondary_material`):** MIP model reference and case template from MIP - Maturity in Practice.yaml.
- **Assumptions And Inferences (`assumptions_and_inferences`):**
  > The case is treated as a generic, non-identifiable training constellation.
  > A team member is criticised in front of colleagues during a meeting.
  > The criticism is minimal: brief, task-related and not openly insulting, but still public enough to create dignity, role and asymmetry effects.
  > The criticising role-holder may be a team lead, project lead, senior colleague or meeting facilitator; where this matters, the analysis names the conditionality.
  > No clinical, forensic, HR-decisional or person-ranking use is intended.
- **Distinction Material Vs Inference Clear (`distinction_material_vs_inference_clear`):** `true`
### Quality And Limits (`quality_and_limits`)

- **Coverage Estimate (`coverage_estimate`):** medium
- **Reliability Estimate (`reliability_estimate`):** medium
- **Known Gaps (`known_gaps`):**
  - Exact wording of the public criticism is unknown.
  - Formal hierarchy between criticising role-holder and criticised team member is unspecified.
  - Prior history between the actors is unknown.
  - Team norms for feedback and error handling are unknown.
  - The affected person's own perspective is not available.
- **Main Bias Risks Here (`main_bias_risks_here`):**
  - over-reading a brief public correction as humiliation
  - under-reading publicness because the criticism is described as minimal
  - assuming hierarchy where the case may only involve peer interaction
  - hindsight inflation of predictability after harm is imagined


## 4. Snapshot

- **Short Case Description (`short_case_description`):**
  > In a team meeting, one role-holder publicly criticises another team member's work, contribution or mistake.
  > The criticism is brief and task-related, but it occurs in front of others rather than in a private or explicitly protected feedback setting.
  > The case examines the enactment, meeting structure and responsibility distribution, not the moral worth or character of any person.
### Central Actors And Roles (`central_actors_and_roles`)

- criticising_role_holder: person speaking criticism in the meeting; possibly lead, facilitator, senior colleague or peer
- criticised_team_member: person whose work or action is criticised in front of others
- meeting_participants: witnesses whose presence changes publicness, reputation and response options
- team_or_organisation: holder of feedback norms, meeting culture and repair mechanisms

- **Guiding Question (`guiding_question`):** How mature is the enactment of public criticism in this meeting context, and where does functional feedback risk becoming an inadult asymmetry?
### Level (`level`)

- individual_in_role
- dyadic
- team
- organisational
- cultural

- **First Visible Asymmetry (`first_visible_asymmetry`):**
  > The criticising role-holder controls the speaking moment and framing, while the criticised team member has reduced immediate room for response without appearing defensive.
### First Visible D Themes Optional (`first_visible_D_themes_optional`)

- public exposure
- possible shame dynamic
- relational dignity under correction
- reputation and standing inside the team
- dignity protection through repair and private follow-up


## 5. Role Mapping

### Object Of Observation (`object_of_observation`)

- **Type (`type`):** person_in_role
- **Description (`description`):** The enactment of the criticising role-holder within a semi-public team meeting.
- **Role (`role`):** feedback_giver_or_meeting_participant_with_temporary_framing_power
- **Not Person As Whole (`not_person_as_whole`):** `true`

### Observer Position (`observer_position`)

- **Role (`role`):** external_structural_observer
- **Power Relation To Object (`power_relation_to_object`):** No direct operational power over the actors; analysis could influence training, supervision or meeting design if transmitted.
- **Possible Effects Of Analysis (`possible_effects_of_analysis`):** May clarify safer feedback practices; may become harmful if misused to label the criticising role-holder or publicly shame either party.

### Involved Roles (`involved_roles`)

- **criticising_role_holder**
  - **Role (`role`):** criticising_role_holder
  - **Mandate (`mandate`):** Name relevant task issues, protect work quality, contribute to coordination and feedback.
  - **Built In Asymmetries (`built_in_asymmetries`):**
    - temporary_control_of_meeting_floor
    - framing_power_over_the_issue
    - possible_hierarchical_authority_if_lead_or_senior
    - ability_to_affect_reputation_in_front_of_witnesses
  - **Publicness Level (`publicness_level`):** semi_public
  - **Dignity Exposure (`dignity_exposure`):** Can expose another role-holder's mistake, competence or status in front of the team.
- **criticised_team_member**
  - **Role (`role`):** criticised_team_member
  - **Mandate (`mandate`):** Participate in work coordination, receive relevant feedback, maintain role contribution and voice.
  - **Built In Asymmetries (`built_in_asymmetries`):**
    - reduced_response_space_under_observation
    - risk_of_appearing_defensive_if_replying_immediately
    - possible_dependency_on_lead_or_group_evaluation
  - **Publicness Level (`publicness_level`):** semi_public
  - **Dignity Exposure (`dignity_exposure`):** May experience loss of standing, embarrassment or pressure to accept the framing without adequate voice.
- **meeting_participants**
  - **Role (`role`):** meeting_participants
  - **Mandate (`mandate`):** Witness, coordinate, learn from issues, maintain team norms.
  - **Built In Asymmetries (`built_in_asymmetries`):**
    - audience_effect
    - implicit_pressure_to_align_with_dominant_framing
    - potential_silence_as_norm_confirmation
  - **Publicness Level (`publicness_level`):** semi_public
  - **Dignity Exposure (`dignity_exposure`):** Can amplify or soften the exposure through reactions, silence, jokes, support or process correction.
- **team_or_organisation**
  - **Role (`role`):** team_or_organisation
  - **Mandate (`mandate`):** Provide feedback norms, escalation paths, meeting hygiene and repair routines.
  - **Built In Asymmetries (`built_in_asymmetries`):**
    - normalisation_of_public_correction
    - unclear_boundaries_between_coordination_and_evaluation
    - lack_of_private_feedback_channels
  - **Publicness Level (`publicness_level`):** institutional
  - **Dignity Exposure (`dignity_exposure`):** Structural culture can either protect role dignity during correction or make public diminishment routine.

### Publicness (`publicness`)

- **Level (`level`):** semi_public
- **A P Relevance (`A_P_relevance`):** The speaker needs awareness that a team meeting is not private; witnesses alter impact, reputation and reversibility.
- **P Pu Relevance (`P_PU_relevance`):** The speaker's words have amplified force because the group hears them simultaneously and may retain the framing.
- **D P Relevance If D Active (`D_P_relevance_if_D_active`):** D-P is relevant because public exposure, even at small scale, can affect standing and self-presentation inside the team.
- **Public Shaming Risk (`public_shaming_risk`):** Low to moderate in the minimal version; higher if repeated, sarcastic, personalised, hierarchical or not followed by repair.
- **Reversibility Risk (`reversibility_risk`):** Partly reversible through clarification and repair, but impressions formed in the group may persist.


## 6. Frame Vs Variability

### Frame Elements (`frame_elements`)

- **Team meeting as coordination space**
  - **Element (`element`):** Team meeting as coordination space
  - **Reason Fixed Or Slow (`reason_fixed_or_slow`):** Meetings require shared attention, agenda pressure and some public exchange.
  - **Protected Goods (`protected_goods`):**
    - work_quality
    - coordination
    - role_clarity
    - team_learning
- **D0_ontological_dignity**
  - **Element (`element`):** D0_ontological_dignity
  - **Reason Fixed Or Slow (`reason_fixed_or_slow`):** D0 is inviolable, non-rankable and outside all scoring.
  - **Protected Goods (`protected_goods`):**
    - person_worth_nonnegotiability
    - no_dignity_labelling
- **Need to address real work issues**
  - **Element (`element`):** Need to address real work issues
  - **Reason Fixed Or Slow (`reason_fixed_or_slow`):** Some task problems must be named for coordination, safety, quality or accountability.
  - **Protected Goods (`protected_goods`):**
    - truthfulness
    - responsibility
    - reliability
    - collective_learning
- **Role or hierarchy differential if the speaker is senior**
  - **Element (`element`):** Role or hierarchy differential if the speaker is senior
  - **Reason Fixed Or Slow (`reason_fixed_or_slow`):** Formal or informal status differences cannot be removed in the moment.
  - **Protected Goods (`protected_goods`):**
    - fair_process
    - voice
    - proportionality

### Variability Elements (`variability_elements`)

- **Feedback format**
  - **Element (`element`):** Feedback format
  - **Possible Change (`possible_change`):** Move evaluative criticism to private follow-up; keep public meeting comments factual, process-focused and non-personalising.
  - **Responsible Roles (`responsible_roles`):**
    - criticising_role_holder
    - meeting_facilitator
    - team_lead
- **Wording**
  - **Element (`element`):** Wording
  - **Possible Change (`possible_change`):** Replace person-focused criticism with specific, task-bound observation and invitation to clarify next steps.
  - **Responsible Roles (`responsible_roles`):**
    - criticising_role_holder
- **Meeting norm**
  - **Element (`element`):** Meeting norm
  - **Possible Change (`possible_change`):** Create a rule: public issue naming is allowed for coordination; personal evaluation or blame is moved to protected settings.
  - **Responsible Roles (`responsible_roles`):**
    - team
    - team_lead
    - organisation
- **Repair pathway**
  - **Element (`element`):** Repair pathway
  - **Possible Change (`possible_change`):** Add immediate or post-meeting repair: clarify intent, restore voice, acknowledge publicness and agree on next step.
  - **Responsible Roles (`responsible_roles`):**
    - criticising_role_holder
    - meeting_facilitator
    - criticised_team_member_if_safe
- **Participation and voice**
  - **Element (`element`):** Participation and voice
  - **Possible Change (`possible_change`):** Offer the affected role-holder a non-defensive response option, such as 'Do you want to clarify now or should we take it offline?'
  - **Responsible Roles (`responsible_roles`):**
    - meeting_facilitator
    - criticising_role_holder

### Unfair High M Zones (`unfair_high_M_zones`)

-
  > High M would be unfair if the speaker had no realistic awareness of the sensitivity, no hierarchy, no prior norm, and the comment was purely factual coordination.
- High M would be unfair if urgent operational risk required immediate public correction and private handling would have created greater harm.
- High M would be unfair for silent participants if they had no real permission or opportunity to intervene.

### System As Excuse Risk (`system_as_excuse_risk`)

- Calling it 'just our culture' may hide the speaker's real choice over wording and format.
- Agenda pressure may explain compression but not automatically justify public personalisation.
- Hierarchy may be treated as inevitable although leaders still have levers for proportionality and repair.

### D1 D2 Realistically Improvable Where (`D1_D2_realistically_improvable_where`)

- Use private settings for evaluative criticism where possible.
- Publicly separate issue, role, and person.
- Restore voice after a public correction.
- Avoid sarcasm, global labels and competence-shaming.
- Build team rituals for repair after awkward or exposing moments.


## 7. ACRP Profile

### A — Awareness (`A_awareness`)

- **Observations (`observations`):**
  > Awareness is mixed. The speaker may notice the task issue but under-notice the semi-public effect of naming it in front of the team.
  > The team may recognise discomfort but lack a shared language for distinguishing coordination from public criticism.
- **Available Information (`available_information`):** The speaker can see that other team members are present and that the criticised person is being addressed under observation.
- **Realistically Knowable (`realistically_knowable`):** It is realistically knowable that public criticism can affect standing, response freedom and emotional safety, especially under hierarchy.
- **Blind Spots (`blind_spots`):** Publicness, asymmetry, audience effect, reversibility and the difference between task correction and person-exposing criticism.
- **Role Awareness A R (`role_awareness_A_R`):** Partly present if the speaker aims at task quality; weakened if the speaker forgets the facilitation or seniority role.
- **Publicness Awareness A P (`publicness_awareness_A_P`):** Central and partly insufficient; a meeting is not a private feedback container.
- **Bias Awareness (`bias_awareness`):** Possible bias includes irritation, status protection, impatience, in-group norms around 'directness', and hindsight about the mistake.

### C — Coherence (`C_coherence`)

- **Observations (`observations`):**
  > Coherence depends on whether the team's stated values include psychological safety, respect or learning culture.
  > Public criticism may be coherent with a culture of direct operational correction, but incoherent with values of respectful feedback if no protective framing is used.
- **Word Deed Relation (`word_deed_relation`):** If the team claims to value trust while allowing public personalising criticism, word-deed coherence is weakened.
- **Role Context Coherence (`role_context_coherence`):** Task coordination may belong in the meeting; evaluative or status-affecting criticism fits better in a private or moderated context.
- **Narrative Coherence (`narrative_coherence`):** The narrative 'we are just being direct' may conceal dignity costs unless paired with proportionality and repair.
- **Breaks Named Or Hidden (`breaks_named_or_hidden`):** The break is often hidden as normal meeting behaviour unless someone names the publicness effect.

### R — Responsibility (`R_responsibility`)

- **Observations (`observations`):**
  > Responsibility is distributed. The speaker has responsibility for wording, timing and format.
  > The facilitator has responsibility for process protection.
  > The team and organisation share responsibility for feedback norms and repair channels.
- **Responsibility Points (`responsibility_points`):** Choice of public versus private format, task-specificity, tone, opportunity for response, follow-up and norm-setting.
- **Assumed Responsibility (`assumed_responsibility`):** Assumed if the speaker clarifies the issue, acknowledges publicness and offers repair or private follow-up.
- **Shifted Or Refused Responsibility (`shifted_or_refused_responsibility`):** Shifted if the speaker says the criticised person is simply too sensitive, or if the team hides behind 'this is how we talk here.'
- **Burdens And Consequences (`burdens_and_consequences`):** The criticised team member bears immediate exposure; the team bears trust effects; the speaker bears responsibility for repairable process impact.

### P — Power to Act (`P_power_to_act`)

- **Observations (`observations`):**
  > Power to act is present but uneven. The speaker can choose wording and timing.
  > The criticised person has limited immediate agency because any reply occurs in front of observers.
  > The facilitator and team can create or restore process options.
- **Real Levers (`real_levers`):** Pause, reframe, move offline, ask permission, make the feedback task-specific, invite response, acknowledge publicness, repair afterwards.
- **Formal Vs Real Options (`formal_vs_real_options`):** The criticised person may formally be able to answer, but real social cost may make that option constrained.
- **Used Options (`used_options`):** In the minimal public criticism scenario, the speaker uses the option of direct public naming but may not use protective framing.
- **Unused Options (`unused_options`):** Private follow-up, neutral process note, shared learning framing, invitation to clarify, or explicit separation of issue from person.
- **Ceiling Rule Relevance (`ceiling_rule_relevance`):**
  > The ceiling rule does not cap M by default because publicness and alternatives are normally foreseeable; it may reduce M if urgency or information limits were strong.


## 8. Optional D Observation

- **Use Only If Guardrails Fulfilled (`use_only_if_guardrails_fulfilled`):** `true`
- **D Not Folded Into A Score (`D_not_folded_into_A_score`):** `true`
- **Observations Only No Evaluation Here (`observations_only_no_evaluation_here`):** `true`
### Visible D Enactments (`visible_D_enactments`)

- **Self Devaluation (`self_devaluation`):** No direct evidence; possible risk for the criticised role-holder if the public comment is internalised as competence shame.
- **Self Neglect (`self_neglect`):** No evidence.
- **Shame Dynamics (`shame_dynamics`):** Mild to moderate shame dynamic is possible because criticism occurs under witness conditions.
- **Degradation Of Others (`degradation_of_others`):** Not necessarily present in the minimal version; risk increases if wording is sarcastic, global, mocking or person-focused.
- **Public Shaming (`public_shaming`):** Low to moderate risk; publicness is present even if the criticism is brief and task-related.
- **Protest Or Refusal (`protest_or_refusal`):** A mature protest could appear as a process request: 'Can we take evaluative feedback offline?'
- **Dignity Protection (`dignity_protection`):** Possible through task-specific wording, voice restoration, private follow-up and explicit non-personalisation.

- **Next Step If Relevant (`next_step_if_relevant`):** Use D-profile section below.

## 9. ACRPD Submodules Profile

### A (`A`)

- **A I (`A-I`):** The speaker may have insufficient awareness of irritation, impatience or stress before speaking.
- **A R (`A-R`):** Role awareness is mixed: task correction may be role-consistent, but public evaluation requires stronger role restraint.
- **A C (`A-C`):** Context awareness is partial: a team meeting supports coordination, not necessarily exposed evaluation.
- **A Im (`A-IM`):** Impact awareness is partial: the likely effect on standing, voice and trust may be under-recognised.
- **A P (`A-P`):** Publicness awareness is central; the audience changes the meaning and consequences of the criticism.

### C (`C`)

- **C S (`C-S`):** Social coherence is weakened if group norms of respect are bypassed by public correction.
- **C P (`C-P`):** Coherence in power contexts depends on whether hierarchy is handled with proportionality and voice protection.
- **C N (`C-N`):** The narrative of 'directness' is coherent only if it includes care for reversibility and dignity.
- **C I (`C-I`):** Institutional coherence depends on whether feedback rules distinguish public coordination from private evaluation.

### R (`R`)

- **R I (`R-I`):** The speaker has individual responsibility for wording, timing and repair.
- **R S (`R-S`):** The team has social responsibility for not letting silence turn exposure into accepted norm.
- **R E (`R-E`):** Ethical responsibility concerns proportionality, dignity protection and fair opportunity to respond.
- **R P (`R-P`):** Public responsibility is relevant at the semi-public team level, not media-public level.

### P (`P`)

- **P I (`P-I`):** The speaker's inner agency includes the ability to pause before criticising.
- **P S (`P-S`):** Social agency includes choosing a relationally safe feedback format.
- **P C (`P-C`):** Cultural agency includes shaping whether the team normalises public blame or protected learning.
- **P Pu (`P-PU`):** Public agency is limited to internal publicness but still affects reputation and group memory.

### D (`D`)

- **Active (`active`):** `true`
- **D I (`D-I`):** No reliable person-level reading; possible self-dignity stress for the criticised role-holder if the scene becomes self-devaluing.
- **D B (`D-B`):** No bodily or material self-care evidence; not central in this case.
- **D R (`D-R`):** Relational dignity is at stake in how correction is phrased, witnessed and repaired.
- **D P (`D-P`):** Public dignity in practice is active because the criticism occurs before a team audience.
- **Note (`note`):** D-submodules only if D-module is activated and guardrails are fulfilled.


## 10. Scores And Ia

### A-score (`A_score`)

- **A Band (`A_band`):** 4-5
- **Boundary Confirmed (`boundary_confirmed`):** A-score describes enactment, not essence.
- **Time Role Context (`time_role_context`):** Single minimal public criticism episode in a semi-public team meeting.
- **Justification (`justification`):**
  - **A — Awareness (`A_awareness`):** Awareness of the task issue is present, but awareness of publicness, asymmetry and impact is only partial.
  - **C — Coherence (`C_coherence`):** The enactment is partly coherent with task correction but may conflict with respectful feedback and psychological safety norms.
  - **R — Responsibility (`R_responsibility`):** Responsibility is only partly assumed unless the speaker protects voice and repairs the public exposure.
  - **P — Power to Act (`P_power_to_act`):** Real alternatives normally exist: pause, reframe, move offline or make the issue non-personal.
  - **Modulators Context (`modulators_context`):** Meeting pressure, team culture of directness, hierarchy, prior mistakes and unclear norms may modulate the reading.
- **D Excluded From A Number (`D_excluded_from_A_number`):** `true`

### M-score (`M_score`)

- **M Band (`M_band`):** 4-5
- **Boundary Confirmed (`boundary_confirmed`):** M-score describes shared structural responsibility, not guilt.
- **Role Position Time Frame (`role_position_time_frame`):** Criticising role-holder within the meeting episode; higher end if the speaker has formal authority or repeated pattern.
- **Five Factors (`five_factors`):**
  - **Knowledge (`knowledge`):** The presence of others and the public character of the moment are knowable.
  - **Power Control (`power_control`):** The speaker usually controls wording, timing and whether the issue is taken offline.
  - **Predictability (`predictability`):** Some dignity and reputation impact is realistically predictable, though severity is uncertain in the minimal case.
  - **Access To Alternatives (`access_to_alternatives`):** Alternatives are normally available unless urgent operational risk requires immediate public correction.
  - **Serious Integration Attempt (`serious_integration_attempt`):** Weak if the speaker does not provide protective framing, response space or repair; stronger if follow-up occurs.
- **Ceiling Rule Check (`ceiling_rule_check`):**
  - **Predictability Approx Zero (`predictability_approx_zero`):** `false`
  - **Access To Alternatives Approx Zero (`access_to_alternatives_approx_zero`):** `false`
  - **M Capped At 4 (`M_capped_at_4`):** `false`
  - **Explanation (`explanation`):** The ceiling rule does not automatically cap M because publicness and alternatives are normally foreseeable; specific urgency could lower M.
- **D Link (`D_link`):**
  - **Self Devaluation Does Not Raise M (`self_devaluation_does_not_raise_M`):** `true`
  - **High Subjective Guilt Triggers M Check Not M Increase (`high_subjective_guilt_triggers_M_check_not_M_increase`):** `true`
  - **Low M High Harm Means Protection Not Blame (`low_M_high_harm_means_protection_not_blame`):** `true`

### IA Box (`IA_box`)

- **Asymmetry Named (`asymmetry_named`):** Semi-public criticism creates an audience-backed asymmetry: the speaker frames the issue while the criticised role-holder has constrained response options.
- **Boundary Confirmed (`boundary_confirmed`):** IA-box is an asymmetry check, not a verdict.
- **T — Transparent (`T_transparent`):**
  - **Status (`status`):** partly
  - **Notes (`notes`):** The task issue may be visible, but the reason for addressing it publicly rather than privately is often not transparent.
- **J — Justified (`J_justified`):**
  - **Status (`status`):** partly
  - **Protected Good Or Purpose (`protected_good_or_purpose`):** Work quality, coordination, accountability and team learning.
  - **Notes (`notes`):** Naming a task issue can be justified; public criticism of a person or performance is justified only if proportionate and necessary for the meeting purpose.
- **TB — Time-Bound (`TB_time_bound`):**
  - **Status (`status`):** partly
  - **Review Points Or Conditions (`review_points_or_conditions`):** Should be closed by clarification, private follow-up or repair after the meeting.
  - **Notes (`notes`):** Without closure, the public framing may linger beyond the moment.
- **R — Reversible (`R_reversible`):**
  - **Status (`status`):** partly
  - **Real Return Or Exit Options (`real_return_or_exit_options`):** Clarification, apology, correction of group framing, private repair and explicit restoration of voice.
  - **Notes (`notes`):** The comment can be partly repaired, but the audience impression is not fully reversible.
- **Result (`result`):** IA_risk
- **Short Justification (`short_justification`):**
  > The asymmetry is not automatically inadult, because public task correction can be functional; it becomes IA risk when transparency, necessity, time-bounding or reversibility are weak.
- **Immediate Action (`immediate_action`):** Reframe the criticism as task-specific, move evaluative feedback offline, restore the criticised role-holder's voice and define a repair or follow-up point.


## 11. Ia Localisation

### Knowing (`knowing`)

- **Issue (`issue`):** The speaker may not fully know or notice the semi-public dignity and reputation effect.
- **Possible Intervention (`possible_intervention`):** Introduce a team norm distinguishing public coordination from private evaluative feedback.

### Being Able (`being_able`)

- **Issue (`issue`):** The speaker may feel agenda pressure or lack practiced alternatives.
- **Possible Intervention (`possible_intervention`):** Provide simple scripts for pausing, moving offline and making criticism task-specific.

### Being Permitted (`being_permitted`)

- **Issue (`issue`):** The team culture may implicitly permit public correction but not permit meta-commentary about process.
- **Possible Intervention (`possible_intervention`):** Make it explicitly permissible for anyone to request a private follow-up or process pause.

### Willing (`willing`)

- **Issue (`issue`):** The speaker may prefer directness, speed or authority display over slower repair.
- **Possible Intervention (`possible_intervention`):** Tie mature feedback to role responsibility, team trust and reversibility rather than to niceness.


## 12. Ia Protection

### Transparency Measures (`transparency_measures`)

- Name whether the comment is for immediate coordination or for later evaluative feedback.
- Clarify why the issue must be addressed in the meeting if it is not taken offline.

### Justification Measures (`justification_measures`)

- Keep criticism specific to task, process, deadline, risk or decision need.
- Avoid global competence claims, sarcasm, moralising or personal labels.

### Time Boundedness Measures (`time_boundedness_measures`)

- Close the public moment with a concrete next step.
- Schedule private follow-up if evaluative feedback is needed.

### Reversibility Measures (`reversibility_measures`)

- Correct any overstatement in front of the same audience if the criticism was inaccurate or disproportionate.
- Offer repair: 'I should have handled that more privately; the issue is the process, not your standing here.'

### Participation Or Voice Measures (`participation_or_voice_measures`)

- Ask whether the criticised role-holder wants to clarify now or offline.
- Allow non-defensive response space without forcing public self-justification.

### Dignity Protection Measures (`dignity_protection_measures`)

- Separate person, role contribution and specific issue.
- Protect the person's standing while still addressing the work issue.
- Make witness responsibility explicit: no jokes, pile-on or silent escalation.

### Review Or Falsifier (`review_or_falsifier`)

- **Date Or Interval (`date_or_interval`):** After the meeting or at the next team retrospective.
- **Falsifier Question (`falsifier_question`):** Did the public criticism lead to clearer coordination without reducing voice, trust or standing?
- **Responsible Roles (`responsible_roles`):**
  - criticising_role_holder
  - meeting_facilitator
  - team_lead
  - team


## 13. Trajectory

- **Principle (`principle`):** Trajectories, not labels.
### Timeline (`timeline`)

- **t0**
  - **Timepoint (`timepoint`):** t0
  - **Short Description (`short_description`):** Before the meeting, a task issue or mistake exists and requires some form of response.
  - **A Band (`A_band`):** 5-6
  - **M Band (`M_band`):** 3-4
  - **D Observation Optional (`D_observation_optional`):** D not yet visibly activated; feedback route still open.
  - **Key Context Role Power Situation (`key_context_role_power_situation`):** The team has a choice between public coordination, private feedback or hybrid handling.
- **t1**
  - **Timepoint (`timepoint`):** t1
  - **Short Description (`short_description`):** During the meeting, the issue is publicly criticised in front of colleagues.
  - **A Band (`A_band`):** 4-5
  - **M Band (`M_band`):** 4-5
  - **D Observation Optional (`D_observation_optional`):** Level-1 D stress: public exposure and possible shame dynamic, not a person label.
  - **Key Context Role Power Situation (`key_context_role_power_situation`):** Speaker holds the floor; criticised role-holder has constrained response space.
- **t2**
  - **Timepoint (`timepoint`):** t2
  - **Short Description (`short_description`):** After the comment, the situation either receives repair or becomes normalised as public criticism.
  - **A Band (`A_band`):** 5-7_if_repaired_or_3-4_if_normalised
  - **M Band (`M_band`):** 3-4_if_repaired_or_5-6_if_repeated_and_unaddressed
  - **D Observation Optional (`D_observation_optional`):** D stress decreases with repair; increases if repeated, mocked or left uncorrected.
  - **Key Context Role Power Situation (`key_context_role_power_situation`):** Repair, norm-setting and retrospection determine whether the trajectory becomes learning or humiliation drift.

### A(t) (`A_t`)

- **Pattern (`pattern`):** zigzagging
- **Notes (`notes`):** Initial awareness of the task issue may drop when publicness is under-noticed; it can rise again through repair and process reflection.

### M(t) / RVR(t) (`M_t_RVR_t`)

- **Rvr Description (`RVR_description`):** Responsibility rises as the speaker and team gain knowledge of the publicness effect and have viable alternatives.
- **Knowledge Over Time (`knowledge_over_time`):** At t0 the issue is known; at t1 the publicness effect becomes observable; at t2 the need for repair is knowable.
- **Leverage Over Time (`leverage_over_time`):** Leverage shifts from wording choice before the comment, to facilitation during the meeting, to repair and norm-setting afterward.
- **Alternatives Over Time (`alternatives_over_time`):** Before and during the meeting alternatives are strong; after the meeting alternatives become repair-oriented and less fully reversible.
- **Ceiling Rule Over Time (`ceiling_rule_over_time`):** No default cap where alternatives are available; cap may apply only under urgent operational necessity or severe information limits.

### D(t) Optional (`D_t_optional`)

- **Active (`active`):** `true`
- **Qualitative Course (`qualitative_course`):** D stress is low before exposure, rises during public criticism, and either declines through repair or consolidates into team-level dignity drift.
- **D Quick Grid Movement If Used (`D_quick_grid_movement_if_used`):** 0_or_1_at_t0 -> 1_at_t1 -> 0_or_1_if_repaired / 2_if_repeated_or_mocking
- **Note (`note`):** No D-score; only qualitative trajectory.


## 14. D Module Optional

- **Active (`active`):** `true`
- **Activation Reason (`activation_reason`):**
  > D is activated because the case centrally involves publicness, possible shame dynamics and relational dignity, and the case is generic, non-identifiable and guardrail-protected.
- **Communication Space (`communication_space`):** internal_structural_review
### Guardrails Checked (`guardrails_checked`)

- **Scenic (`scenic`):** `true`
- **Context Bound (`context_bound`):** `true`
- **Role Bound (`role_bound`):** `true`
- **Time Windowed (`time_windowed`):** `true`
- **No Global Statement About Persons (`no_global_statement_about_persons`):** `true`
- **No Dignity Score (`no_dignity_score`):** `true`
- **D0 Untouched (`D0_untouched`):** `true`

### D-profile (`D_profile`)

- **D1 Self-Treatment / D-I / D-B (`D1_self_treatment_D_I_D_B`):**
  - **Observed Enactments (`observed_enactments`):** No direct evidence of self-treatment; possible D-I stress for the criticised role-holder if the public criticism is internalised as shame.
  - **Context Notes (`context_notes`):** The analysis does not infer inner life; it only marks a plausible dignity-in-practice risk created by the scene.
  - **Trend Band Qualitative (`trend_band_qualitative`):** unclear
- **D2 Relational Dignity / D-R (`D2_relational_dignity_D_R`):**
  - **Observed Enactments (`observed_enactments`):** The relational enactment risks reducing the criticised role-holder to the publicly named issue unless wording and repair protect role dignity.
  - **Context Notes (`context_notes`):** A factual task correction can be dignity-compatible; person-focused or exposing criticism weakens relational dignity.
  - **Interpretive Reading Not Judgment (`interpretive_reading_not_judgment`):** ambivalent
- **D-P Public Dignity (`D_P_public_dignity`):**
  - **Active If Publicness Relevant (`active_if_publicness_relevant`):** `true`
  - **Observed Enactments (`observed_enactments`):** Publicness is internal to the scene: colleagues witness the criticism and may carry forward the framing.
  - **Private Public Tension (`private_public_tension`):** The issue may need team coordination, but evaluative criticism usually requires a more private or protected frame.
  - **Publicity Context (`publicity_context`):** semi_public_team_meeting
- **A/M/D Link Without Mixing (`A_M_D_link_without_mixing`):**
  - **A Band Reference (`A_band_reference`):** 4-5
  - **M Band Reference (`M_band_reference`):** 4-5
  - **D Tendency (`D_tendency`):** level_1_D_stress_with_escalation_risk_if_repeated_or_personalised
  - **Protection Or Responsibility Implication (`protection_or_responsibility_implication`):** D stress calls for protection and repair; it does not increase M by itself and does not alter D0.

### D Quick Grid (`D_Quick_Grid`)

- **Used (`used`):** `true`
- **Level (`level`):** 1
- **Preferred Wording (`preferred_wording`):** This constellation currently shows level-1 D stress in this role / context / time window.
- **Forbidden Wording Avoided (`forbidden_wording_avoided`):** `true`
- **Movement Question (`movement_question`):** What would be one small, real action that could make this constellation one level more dignified — and who has A and M levers for that?


## 15. Meta Notes

### Bias Risks (`bias_risks`)

- **Confirmation Bias (`confirmation_bias`):** The observer may search only for evidence that public criticism is harmful.
- **Hindsight Bias (`hindsight_bias`):** If harm is later reported, the observer may overstate how predictable it was at the moment.
- **Status Quo Loyalty Bias (`status_quo_loyalty_bias`):** The team may normalise the criticism as ordinary directness and minimise the dignity effect.
- **Halo Horn Effects (`halo_horn_effects`):** Prior liking or dislike of the speaker or criticised role-holder could distort the reading.
- **In Group Out Group Bias (`in_group_out_group_bias`):** Longstanding team members may excuse directness among themselves and judge newcomers as oversensitive.
- **Dignity Bias Effect (`dignity_bias_effect`):** D-language could become a dignity penalty against the speaker if guardrails are ignored.

### Norm Assumptions (`norm_assumptions`)

- **Explicit Norms (`explicit_norms`):**
  - Feedback should be task-specific, proportionate and role-aware.
  - Public coordination may be necessary, but public personal evaluation requires stronger justification.
  - D0 remains untouched and no person is scored.
- **Implicit Norms (`implicit_norms`):**
  - Team meetings should preserve voice and role dignity.
  - Directness is not sufficient justification for avoidable exposure.
  - Repair matters when publicness has created an unintended dignity effect.
- **Dignity Concepts (`dignity_concepts`):**
  - D1_self_dignity_in_practice
  - D2_relational_dignity_in_practice
  - D-P_public_dignity_in_practice
  - D0_ontological_dignity_untouched
- **Normative Position Of D Reading (`normative_position_of_D_reading`):**
  > The D-reading uses a dignity-protective, role-contextual lens: public exposure is treated as ethically relevant but not automatically as humiliation or person-level failure.

### Intuition (`intuition`)

- **Initial Intuition (`initial_intuition`):** The scene feels minor but risky: not necessarily severe, yet structurally capable of shame and asymmetry.
- **Used As Sensor Not Judge (`used_as_sensor_not_judge`):** `true`
- **Checked Afterwards (`checked_afterwards`):** `true`
- **Supporting Evidence (`supporting_evidence`):** Semi-public audience, constrained response space, possible hierarchy and partial reversibility support the IA-risk reading.
- **Contradicting Evidence (`contradicting_evidence`):** The criticism may have been factual, necessary, brief, non-sarcastic and accepted as normal coordination by the team.

### Possible Alternative Interpretations (`possible_alternative_interpretations`)

- Functional public correction: The issue had immediate relevance for the whole team and was handled without personalising.
- Necessary interruption: The criticism prevented ongoing risk or miscoordination that could not wait.
- Cultural directness: The team may share a norm of brief public correction, though this still requires dignity checks.
- Hidden pattern: The minimal episode may be one instance in a larger repeated pattern of public diminishment.
- Misread publicness: The observer may overstate exposure if the meeting group is small, trusting and repair-oriented.

### Counter Perspective (`counter_perspective`)

- **From Other Side (`from_other_side`):** The speaker might say the comment was necessary for project clarity and was about the work, not the person.
- **From Affected Side (`from_affected_side`):** The criticised role-holder might say the public format made it hard to respond and affected standing even if the words were mild.
- **From External Observer (`from_external_observer`):** An observer might see a mixed enactment: a legitimate task issue handled in a format with avoidable asymmetry risk.


## 16. Open Questions And Blind Spots

### Missing Information (`missing_information`)

- Exact wording and tone of the criticism.
- Whether the criticism was task-specific or person-focused.
- Whether the speaker had formal authority.
- Whether the criticised role-holder had a safe chance to respond.
- Whether the issue required immediate team-level handling.
- Whether a repair or private follow-up occurred.

### Uncertain Assumptions (`uncertain_assumptions`)

- The case is treated as minimal rather than severe.
- The team meeting is treated as semi-public, not fully private.
- Alternatives are assumed to have been available in ordinary conditions.
- No repeated pattern is assumed unless later evidence shows one.

### Weak Points In Analysis (`weak_points_in_analysis`)

- D-stress is inferred from publicness and not from reported subjective experience.
- M-band is conditional on hierarchy and available alternatives.
- The same enactment may be more functional in urgent operational contexts.

### Needed Perspectives (`needed_perspectives`)

- criticised_team_member
- criticising_role_holder
- meeting_facilitator
- neutral_meeting_observer
- team_norm_or_policy_context


## 17. Possible Steps Towards Maturity

- **Decision Mode (`decision_mode`):** balance
### Functional Next Step (`functional_next_step`)

- **Action (`action`):** Clarify the task issue without person-labelling, then move evaluative feedback to a private or protected follow-up.
- **Reversible (`reversible`):** `true`
- **Responsible Role (`responsible_role`):** criticising_role_holder_or_meeting_facilitator

### Short Term Feasible (`short_term_feasible`)

- Use a repair sentence if publicness was mishandled.
- Ask whether the affected role-holder wants to respond now or offline.
- Restate the issue as task-specific and future-oriented.
- Prevent pile-on by closing the public evaluation thread.

### Medium Term Feasible (`medium_term_feasible`)

- Create a feedback norm separating public coordination from private evaluation.
- Train meeting facilitators to spot IA-risk moments.
- Use retrospectives to review whether feedback practices protect voice and dignity.
- Define escalation channels for repeated mistakes that do not rely on public exposure.

### Overambitious Or Risky (`overambitious_or_risky`)

- Turning every public correction into a formal conflict process.
- Banning all public issue naming, which may block coordination.
- Using the model to accuse the speaker of being immature.
- Forcing the criticised role-holder to publicly describe their feelings.

### Protection First If Low M High Harm (`protection_first_if_low_M_high_harm`)

- If the affected person reports strong harm despite low M, prioritise repair, support and safer process without escalating blame.

### Structural Change If High M (`structural_change_if_high_M`)

- If public criticism is repeated, hierarchical and unaddressed, redesign team feedback norms and accountability for meeting facilitation.


## 18. Transmission Check

- **Pre Transmission Gate Passed (`pre_transmission_gate_passed`):** `true`
### Final Checklist (`final_checklist`)

- **Scope And Guardrails Checked (`scope_and_guardrails_checked`):** `true`
- **Roles And Publicness Checked (`roles_and_publicness_checked`):** `true`
- **Score Hygiene Checked (`score_hygiene_checked`):** `true`
- **Bias Norm Intuition Checked (`bias_norm_intuition_checked`):** `true`
- **Consequences And Reversibility Checked (`consequences_and_reversibility_checked`):** `true`
- **D Cleanliness Checked If Relevant (`D_cleanliness_checked_if_relevant`):** `true`

- **Status (`status`):** structurally_transmittable
- **If Not Transmittable Reason (`if_not_transmittable_reason`):** not_applicable
### Allowed Use Of This Analysis (`allowed_use_of_this_analysis`)

- internal_reflection
- training_simulation
- supervision
- process_improvement
- meeting_norm_design

### Not Allowed Use (`not_allowed_use`)

- person_label
- public_shaming
- individual_sanction
- HR_decision
- forensic_use
- clinical_diagnosis

### Review Required (`review_required`)

- **Required (`required`):** `true`
- **Review Date Or Condition (`review_date_or_condition`):** Review after adding exact wording, role hierarchy, affected perspective and whether repair occurred.
- **Falsifier (`falsifier`):**
  > If the comment was strictly factual, urgent, non-personal, necessary for all participants and followed by voice-protecting repair, the IA-risk reading should be downgraded.


## 19. Uniform Report

- **Generate Only From Structured Fields (`generate_only_from_structured_fields`):** `true`
- **Title (`title`):** Minimal Public Criticism in a Team Meeting
- **Overview 4 To 7 Sentences (`overview_4_to_7_sentences`):**
  > This generic case concerns a brief, task-related criticism made in front of a team.
  > The enactment is not analysed as a statement about any person's character, but as a role-context action under semi-public conditions.
  > The central maturity issue is the tension between legitimate task correction and avoidable public exposure.
  > The first asymmetry lies in the speaker's control over framing and the criticised role-holder's constrained response options.
  > The case shows IA risk rather than automatic inadult asymmetry, because public correction can be functional when transparent, justified, bounded and repairable.
  > D is activated only qualitatively because publicness and shame dynamics are relevant; D0 remains untouched and no dignity score is used.
### Key Findings (`key_findings`)

- The public format changes the meaning of even minimal criticism.
- The A-score band is 4-5 for the enactment because awareness of task relevance is present but awareness of publicness and impact is partial.
-
  > The M-score band is 4-5 for the criticising role-holder in the generic case, with higher responsibility if hierarchy, repetition or available alternatives are clear.
- The IA-box result is IA_risk, not a verdict.
- The main maturity movement is from public exposure toward task-specific, reversible and voice-protecting feedback.
- D-stress is level 1 in the minimal version, with escalation risk if the pattern becomes repeated, mocking or person-focused.

- **A Summary (`A_summary`):** A(H) ≈ 4-5: mixed maturity; task awareness is present, but publicness, audience effect and reversibility are under-integrated.
- **M Summary (`M_summary`):**
  > M(X) ≈ 4-5: shared structural responsibility is moderate because the speaker usually has real alternatives in wording, timing and format; this is not guilt or person blame.
- **Ia Box Summary (`IA_box_summary`):** IA(S) = partly transparent, partly justified, partly time-bound, partly reversible; result: IA_risk.
- **D Summary If Activated (`D_summary_if_activated`):** The D-profile shows qualitative level-1 D stress around public exposure and relational dignity; D0 is untouched and no person-level dignity judgement is made.
- **Trajectory Summary (`trajectory_summary`):** The trajectory can improve through repair and meeting norms, or deteriorate if public criticism is normalised and repeated.
- **Guardrail Status (`guardrail_status`):** Guardrails are fulfilled for a generic training case: no person labels, no HR decision, no public shaming, no clinical or forensic use.
- **Transmission Status (`transmission_status`):** structurally_transmittable
- **Practical Implications (`practical_implications`):** Use public meetings for coordination, not avoidable person-exposing evaluation; protect voice, clarify necessity, and repair public missteps.
- **Conclusion (`conclusion`):**
  > The mature direction is not silence about mistakes, but proportionate, role-aware and reversible feedback that preserves dignity while addressing the work issue.
