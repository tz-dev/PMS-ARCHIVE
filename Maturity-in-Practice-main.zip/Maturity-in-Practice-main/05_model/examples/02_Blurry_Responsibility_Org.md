---
document_id: "MIP-EXAMPLE-02-BLURRY-RESPONSIBILITY-ORG"
title: "Blurry Responsibility After a Decision"
source_role: "derived example markdown from case YAML"
source_file: "05_model/examples/02_Blurry_Responsibility_Org.yaml"
target_file: "05_model/examples/02_Blurry_Responsibility_Org.md"
status: "derived-example-markdown"
version: "v1"
example_role: "generic organisational training case"
canonical_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
model_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
claim_mode: "case analysis, derived, non-expansive"
mip_status: "supporting example file; not a replacement for canonical model or paper blocks"
generation_rule: "render all existing YAML fields into human-readable markdown; do not add new theory or omit case information"
schema_version: "MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned"
source_file_name: "02_Blurry_Responsibility_Org.yaml"
source_model: "MIP - Maturity in Practice.yaml"
---

# Blurry Responsibility After a Decision

> Human-readable Markdown rendering of `02_Blurry_Responsibility_Org.yaml`.
> This file preserves the full content of the YAML case while presenting it as a readable example document.

## Source Technical Fields

- **Schema Version:** MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned
- **File Name:** `02_Blurry_Responsibility_Org.yaml`
- **Source Model:** MIP - Maturity in Practice.yaml

## 1. Case Metadata

- **Case Id:** 02_Blurry_Responsibility_Org
- **Case Title:** Blurry Responsibility After a Decision
- **Documentation Date:** 2026-05-23

### Analysts

- **ChatGPT:**
  - **Role:** structural_case_analyst
  - **Observer Position:** external_model_application_to_generic_training_case

- **Language:** en
- **Confidentiality Level:** public_generalised
- **Analysis Mode:** full
- **Intended Use:** training_simulation
- **Application Zone:** green

### Interaction Profile

- **Reflection Mode:** off
- **D Module Preference:** auto
- **Output Format:** yaml
- **Discipline Profile:** organisation_leadership
- **D Activation Decision:** activated_qualitatively_under_guardrails
- **Transmission Default:** working_note_until_checked

## 2. Guardrails

- **Profile Not Person:** `true`
- **Focus On Roles Structures Enactments:** `true`
- **Minimal Adulthood Checked:** `true`
- **Analyst Self Implication Acknowledged:** `true`
- **System Axiom Applied:** `true`

### Use Context

- **Roles Clarified:** `true`
- **Observer Position Clarified:** `true`
- **Information Basis Clarified:** `true`
- **Analysis Purpose Clarified:** `true`
- **Publicness Clarified:** `true`

### Red Zone Check

- **Clinical Diagnostics:** `false`
- **Therapy Planning:** `false`
- **Forensics:** `false`
- **Individual Hr Decisions:** `false`
- **Child Youth Diagnostics:** `false`
- **Public Pillory Or Ranking:** `false`
- **Online Shaming Or Doxing:** `false`
- **Humiliation Diagnostics:** `false`
- **Public D Readings Of Identifiable Persons:** `false`
- **Any Red Zone Touched:** `false`
- **If Any True:** do_not_apply_model

### Dignity Protection

- **D0 Untouched:** `true`
- **D1 D2 Enactments Only:** `true`
- **No Dignity Score:** `true`
- **No Person Labels From D:** `true`
- **D Default Off:** `true`
- **D Activated:** `true`
- **If D Activated Guardrails Checked:** `true`
- **If D Creates More Shame Than Clarity:** dial_D_down

### Score Hygiene

- **A Score Band Not Person Score:** `true`
- **M Score Shared Responsibility Not Guilt:** `true`
- **D Profile Not Dignity Score:** `true`
- **IA Box Not Verdict:** `true`

- **Tragedy Clause Considered:** `true`
- **Misuse As Own Finding Acknowledged:** `true`

## 3. Information Basis

- **Primary Material:** Generic case prompt: blurry responsibility after a decision.
- **Secondary Material:** MIP model reference and case template from MIP - Maturity in Practice.yaml.
- **Assumptions And Inferences:** 
  > The case is treated as a generic, non-identifiable organisational training constellation.
  > A decision has been made by a group, leadership body, project board or informal decision circle.
  > After consequences, implementation friction or negative side effects appear, it becomes unclear who owns the decision, who should explain it, who should correct it and who carries the burdens.
  > No individual disciplinary, HR, forensic or clinical use is intended.
  > The analysis focuses on enactments, roles, decision architecture and organisational responsibility distribution.
- **Distinction Material Vs Inference Clear:** `true`

### Quality And Limits

- **Coverage Estimate:** medium
- **Reliability Estimate:** medium
- **Known Gaps:**
  - Exact decision content is unknown.
  - Formal decision rights are unspecified.
  - The documented decision record is unknown.
  - The affected parties and impact severity are unspecified.
  - Whether responsibility was intentionally blurred or merely neglected is unknown.
  - Whether the organisation has established review or escalation mechanisms is unknown.
- **Main Bias Risks Here:**
  - hindsight inflation of predictability after consequences appear
  - over-attributing responsibility to the most visible leader
  - under-attributing responsibility to decision structures and informal power
  - treating ambiguity as malicious when it may stem from complexity
  - treating complexity as an excuse when real levers existed

## 4. Snapshot

- **Short Case Description:** 
  > An organisational decision has been made, but after the decision takes effect, responsibility becomes blurry.
  > Participants may say that the decision was collective, delegated, forced by circumstances, inherited from prior agreements or simply operational.
  > Affected parties experience unclear ownership: they do not know who can explain, revise, repair or be addressed.
  > The case examines responsibility diffusion after a decision, not the character or worth of any individual actor.

### Central Actors And Roles

- decision_sponsor: role-holder or body that initiated or legitimised the decision
- decision_group: committee, leadership team, project board or informal circle involved in deciding
- implementing_roles: people expected to translate the decision into action
- affected_roles: people who carry consequences, workload, uncertainty or reputational effects
- organisation_or_governance_system: holder of decision rules, documentation norms and review mechanisms
- observer_or_review_role: person or function trying to reconstruct who knew, could act and should respond

- **Guiding Question:** How mature is the organisational handling of responsibility after the decision, and where does functional shared ownership slide into inadult responsibility diffusion?

### Level

- organisational
- team
- institutional
- procedural
- cultural

- **First Visible Asymmetry:** Those affected by the decision face consequences while the ownership of explanation, correction and burden-bearing remains unclear.

### First Visible D Themes Optional

- possible abandonment of affected roles
- scapegoating risk
- loss of voice under responsibility diffusion
- relational dignity under opaque governance
- protection through clarification, repair and fair process

## 5. Role Mapping

### Object Of Observation

- **Type:** procedure
- **Description:** The organisational enactment of post-decision responsibility when ownership, explanation and correction pathways become unclear.
- **Role:** decision_and_accountability_process
- **Not Person As Whole:** `true`

### Observer Position

- **Role:** external_structural_observer
- **Power Relation To Object:** No direct operational power over the organisation; analysis could shape training, supervision, governance review or decision hygiene.
- **Possible Effects Of Analysis:** May clarify responsibility architecture and repair needs; may become harmful if misused to blame individuals or retrospectively assign guilt without context.

### Involved Roles

- **decision_sponsor:**
  - **Mandate:** Initiate, frame or legitimate the decision and ensure that ownership, rationale and review paths are clear.
  - **Built In Asymmetries:**
    - agenda_setting_power
    - framing_power
    - access_to_decision_context
    - ability_to_make_or_obscure_accountability
  - **Publicness Level:** institutional
  - **Dignity Exposure:** Can protect affected roles through clear ownership or expose them to confusion, burden transfer and implicit blame.
- **decision_group:**
  - **Mandate:** Assess options, decide or recommend, document reasons and share responsibility for consequences within defined scope.
  - **Built In Asymmetries:**
    - collective_authority_can_dilute_individual_visibility
    - group_consensus_can_hide_dissent_or_uncertainty
    - members_may_later_disown_the_collective_result
  - **Publicness Level:** institutional
  - **Dignity Exposure:** Can stabilise fair responsibility or create dignity stress through anonymous collective force without reachable ownership.
- **implementing_roles:**
  - **Mandate:** Translate the decision into action, communicate practical implications and surface problems.
  - **Built In Asymmetries:**
    - responsibility_for_execution_without_control_over_decision
    - visibility_to_affected_parties
    - risk_of_becoming_buffer_or_blame_carrier
  - **Publicness Level:** institutional
  - **Dignity Exposure:** May be forced to defend or absorb a decision they did not own, weakening role dignity and voice.
- **affected_roles:**
  - **Mandate:** Work, comply, adapt or respond under the consequences of the decision.
  - **Built In Asymmetries:**
    - consequence_bearing_without_decision_power
    - unclear_route_for_questions_or_correction
    - dependency_on_decision_owners_for_repair
  - **Publicness Level:** institutional
  - **Dignity Exposure:** May experience abandonment, invisibility, disrespect or procedural exclusion if nobody takes responsibility.
- **organisation_or_governance_system:**
  - **Mandate:** Provide decision rights, documentation standards, escalation channels and review routines.
  - **Built In Asymmetries:**
    - rules_can_concentrate_or_hide_power
    - informal_authority_may_override_formal_process
    - responsibility_can_be_structurally_fragmented
  - **Publicness Level:** institutional
  - **Dignity Exposure:** Structural opacity can make dignity-protective correction difficult and allow blame to drift downward.

### Publicness

- **Level:** institutional
- **A P Relevance:** The decision may not be media-public, but it is visible within the organisation and symbolically interpreted by affected roles.
- **P PU Relevance:** Public agency is institutional rather than media-based: decision owners shape organisational narratives, reputations and perceived legitimacy.
- **D P Relevance If D Active:** D-P is relevant where organisational visibility, blame transfer or reputation effects affect role standing.
- **Public Shaming Risk:** Usually low in the minimal generic case, but rises if responsibility is blurred by publicly blaming implementers, dissenters or affected roles.
- **Reversibility Risk:** Moderate: a decision can often be reviewed or clarified, but consequences, lost trust and reputational effects may not be fully reversible.

## 6. Frame vs. Variability

### Frame Elements

- **Decision has already been made:**
  - **Reason Fixed Or Slow:** The organisation is analysing a post-decision constellation, not an abstract pre-decision choice.
  - **Protected Goods:**
    - continuity
    - implementation_reliability
    - learning_from_consequences
- **Organisational complexity:**
  - **Reason Fixed Or Slow:** Many decisions genuinely involve multiple roles, incomplete information and distributed authority.
  - **Protected Goods:**
    - fair_responsibility_distribution
    - non_scapegoating
    - accurate_contextual_judgement
- **Need for shared decision-making:**
  - **Reason Fixed Or Slow:** Not all decisions can or should be owned by one person; collective responsibility can be functional.
  - **Protected Goods:**
    - participation
    - expertise_integration
    - checks_and_balances
- **D0_ontological_dignity:**
  - **Reason Fixed Or Slow:** D0 is inviolable, non-rankable and outside all scoring.
  - **Protected Goods:**
    - person_worth_nonnegotiability
    - no_dignity_labelling
- **Consequences already exist or are emerging:**
  - **Reason Fixed Or Slow:** Some effects of the decision may already have occurred and cannot simply be undone.
  - **Protected Goods:**
    - repair
    - truthful_review
    - protection_of_affected_roles

### Variability Elements

- **Decision record:**
  - **Possible Change:** Document who decided what, on what basis, with which assumptions, known risks and review conditions.
  - **Responsible Roles:**
    - decision_sponsor
    - decision_group
    - governance_system
- **Ownership language:**
  - **Possible Change:** Replace vague formulations such as 'it was decided' with clear role-bound ownership and scope.
  - **Responsible Roles:**
    - decision_sponsor
    - communications_role
    - leadership_team
- **Review pathway:**
  - **Possible Change:** Create a defined post-decision review point with authority to adjust, pause or reverse.
  - **Responsible Roles:**
    - decision_group
    - governance_system
    - implementation_lead
- **Burden distribution:**
  - **Possible Change:** Map who carries workload, reputational risk, cost or uncertainty and adjust support accordingly.
  - **Responsible Roles:**
    - leadership_team
    - resource_owner
    - project_owner
- **Escalation and correction:**
  - **Possible Change:** Make it safe and procedurally legitimate to surface side effects without being treated as disloyal.
  - **Responsible Roles:**
    - team_lead
    - governance_system
    - affected_roles
- **Narrative coherence:**
  - **Possible Change:** Align internal communication with the real decision process rather than hiding disagreement or uncertainty.
  - **Responsible Roles:**
    - decision_sponsor
    - decision_group
    - organisation

### Unfair High M Zones

- High M would be unfair for implementers who had no decision power, no access to rationale and no realistic authority to change the outcome.
- High M would be unfair for decision participants who were present but had no real influence, were overruled, or had relevant information withheld.
- High M would be unfair where consequences were genuinely unforeseeable and no viable alternatives or review mechanisms were available at the time.
- High M would be unfair if a decision was legally, contractually or materially constrained and only narrow implementation options existed.

### System As Excuse Risk

- Calling the outcome 'a system decision' may hide concrete role-holders who had real levers.
- Collective decision-making can become a shield against ownership.
- Complexity may be used to avoid apology, repair or correction.
- Governance ambiguity may be maintained because it benefits powerful actors.
- Implementation pressure may be used to transfer responsibility downward.

### D1 D2 Realistically Improvable Where

- Name decision ownership without turning it into blame.
- Protect implementers from becoming scapegoats for decisions they did not own.
- Give affected roles a credible route for questions, protest and correction.
- Repair dignity stress caused by silence, evasion or blame drift.
- Acknowledge uncertainty and consequences without humiliating decision participants.

## 7. ACRP Profile

### A Awareness

- **Observations:** 
  > Awareness is partial and distributed.
  > Some actors may know the decision rationale, others know implementation consequences, and affected roles know lived impact.
  > The maturity issue lies in whether these partial awareness fields are integrated or kept fragmented after the decision.
- **Available Information:** Decision records, meeting memories, implementation signals, complaints, side effects, resource data and role feedback may be available but unevenly distributed.
- **Realistically Knowable:** It is realistically knowable that unclear ownership after a decision can create confusion, burden transfer, reduced trust and repair delay.
- **Blind Spots:** Responsibility diffusion, informal power, hidden dissent, implementation burden, affected-party voice and the difference between shared ownership and ownership evaporation.
- **Role Awareness A R:** Often weak: actors may remember their local role but not the responsibility implications of the whole decision chain.
- **Publicness Awareness A P:** Institutional publicness may be under-recognised; the decision becomes visible through consequences even if the original meeting was private.
- **Bias Awareness:** Relevant biases include hindsight bias, status quo loyalty, leader halo/horn effects, group loyalty, fear of blame and self-protective memory.

### C Coherence

- **Observations:** 
  > Coherence is strained when the organisation presents a decision as collective but lacks collective repair.
  > Word-deed coherence is weakened if leaders claim ownership in success but disperse responsibility when consequences become difficult.
- **Word Deed Relation:** Statements such as 'we decided together' are coherent only if the group also shares explanation, review and burden-bearing.
- **Role Context Coherence:** Decision rights, implementation duties and accountability channels need to match; otherwise implementers carry consequences without authority.
- **Narrative Coherence:** The post-decision story may become incoherent if different actors describe the decision as collective, delegated, forced or nobody's real choice.
- **Breaks Named Or Hidden:** Breaks are often hidden in passive language: 'it happened', 'it was aligned', 'the business decided', 'we had no choice.'

### R Responsibility

- **Observations:** 
  > Responsibility is the central axis.
  > Mature responsibility does not mean locating a single guilty person; it means mapping who knew what, who could act, who authorised, who implemented, who benefited and who now must repair.
- **Responsibility Points:** Decision initiation, option framing, risk assessment, dissent handling, final authorisation, implementation support, communication, review and correction.
- **Assumed Responsibility:** Assumed responsibility appears when decision owners explain the rationale, name uncertainty, protect implementers and define correction paths.
- **Shifted Or Refused Responsibility:** Responsibility is shifted when actors hide behind collectivity, blame implementers, invoke vague systems or treat affected roles as the problem.
- **Burdens And Consequences:** Affected and implementing roles may carry workload, reputational risk, emotional strain, operational confusion and loss of trust while decision ownership remains protected or invisible.

### P Power To Act

- **Observations:** 
  > Power to act is uneven but present.
  > Decision sponsors and governance roles can clarify ownership and review.
  > Implementers can surface implementation evidence but may lack authority to revise the decision.
  > Affected roles may have voice only if the organisation provides safe channels.
- **Real Levers:** Decision log, ownership statement, review meeting, escalation path, impact assessment, resource adjustment, apology or correction, revised communication and clarified governance rule.
- **Formal Vs Real Options:** Formal responsibility may sit with a committee, while real influence may sit with a sponsor, senior leader, budget owner or informal coalition.
- **Used Options:** In the blurry-responsibility scenario, the organisation used the option to decide but did not sufficiently use the option to document, own and review.
- **Unused Options:** Explicit RACI-like mapping, dissent record, assumptions log, review trigger, sunset condition, named accountable owner and affected-party feedback loop.
- **Ceiling Rule Relevance:** The ceiling rule may cap M for actors with low knowledge or no real alternatives, but not for roles that had foreseeable levers to clarify ownership and review.

## 8. Optional D Observation

- **Use Only If Guardrails Fulfilled:** `true`
- **D Not Folded Into A Score:** `true`
- **Observations Only No Evaluation Here:** `true`

### Visible D Enactments

- **Self Devaluation:** No direct evidence; possible risk if implementers or affected roles internalise responsibility for a decision they did not own.
- **Self Neglect:** No direct evidence; possible organisational drift if people overwork silently to compensate for unclear ownership.
- **Shame Dynamics:** Possible if the ambiguity leads people to defend themselves, avoid visibility or fear being blamed.
- **Degradation Of Others:** Not inherent in the minimal case; risk rises if actors use ambiguity to blame lower-power roles or dismiss affected concerns.
- **Public Shaming:** Usually not central, but institutional shaming risk arises if blame is redirected toward visible implementers.
- **Protest Or Refusal:** A mature protest may appear as a request for decision ownership, review authority or documented rationale.
- **Dignity Protection:** Dignity is protected by clear ownership, non-scapegoating, voice for affected roles and fair burden distribution.

- **Next Step If Relevant:** Use D-profile section below.

## 9. ACRPD Submodules Profile

### A

- **A I:** Actors may have partial awareness of fear, defensiveness or desire to avoid blame, without necessarily naming it.
- **A R:** Role awareness is often blurred: deciding, recommending, approving, implementing and communicating are not cleanly distinguished.
- **A C:** Context awareness is mixed; organisational complexity is real, but it does not remove the need for post-decision clarity.
- **A IM:** Impact awareness may lag behind the decision and become fragmented across those who decide and those who bear consequences.
- **A P:** Institutional publicness is relevant because the organisation observes who owns, avoids or repairs the decision.

### C

- **C S:** Social coherence weakens when teams experience a decision as imposed but no reachable owner appears.
- **C P:** Coherence in power contexts requires that authority and responsibility remain connected.
- **C N:** Narrative coherence is weak if different actors tell incompatible stories about who decided and why.
- **C I:** Institutional coherence depends on whether decision rules, documentation and review practices match lived responsibility.

### R

- **R I:** Individual responsibility applies to each role-holder's actionable share, not to total blame.
- **R S:** Social responsibility applies to the team's handling of shared ownership, dissent and repair.
- **R E:** Ethical responsibility concerns fair burden distribution, non-scapegoating and truthful correction.
- **R P:** Public responsibility is institutional: the organisation's visible handling affects trust and legitimacy.

### P

- **P I:** Inner agency includes resisting defensive evasion and naming one's actual share.
- **P S:** Social agency includes creating safe conversations about consequences without blame spirals.
- **P C:** Cultural agency includes changing norms from passive decisions to documented ownership.
- **P PU:** Public agency is organisation-internal: leaders and sponsors shape the visible account of responsibility.

### D

- **Active:** `true`
- **D I:** No person-level inference; possible self-dignity stress where actors carry blame or burden beyond their real share.
- **D B:** No direct bodily/material data; possible workload and boundary stress if unclear ownership produces compensatory overwork.
- **D R:** Relational dignity is at stake where responsibility diffusion leaves affected roles unheard or implementers unprotected.
- **D P:** Public dignity is institutionally relevant where blame, reputation or organisational standing are shaped by opaque ownership.
- **Note:** D-submodules only if D-module is activated and guardrails are fulfilled.

## 10. Scores and IA

### A Score

- **A Band:** 4-5
- **Boundary Confirmed:** A-score describes enactment, not essence.
- **Time Role Context:** Post-decision organisational responsibility handling in a generic institutional context.
- **Justification:**
  - **A Awareness:** The organisation may recognise that a decision happened but only partly integrates who knew, authorised, implemented and was affected.
  - **C Coherence:** Coherence is mixed: collective decision-making can be legitimate, but responsibility becomes incoherent when ownership disappears after consequences.
  - **R Responsibility:** Responsibility is insufficiently mapped; burden-bearing and decision authority are not yet fairly connected.
  - **P Power To Act:** Real levers exist for documentation, review, ownership clarification and repair, though not all roles have equal power.
  - **Modulators Context:** Complexity, time pressure, informal authority, missing records, legal constraints and fear of blame may modulate the reading.
- **D Excluded From A Number:** `true`

### M Score

- **M Band:** 4-6
- **Boundary Confirmed:** M-score describes shared structural responsibility, not guilt.
- **Role Position Time Frame:** Decision sponsor, decision group and governance system after a decision; lower for low-power implementers, higher for roles with real authority and knowledge.
- **Five Factors:**
  - **Knowledge:** Decision owners usually know, or can reconstruct, who framed, approved and communicated the decision; affected impacts may become knowable over time.
  - **Power Control:** Sponsors, governance roles and formal decision bodies have stronger levers to clarify ownership, while implementers and affected roles have weaker levers.
  - **Predictability:** Some confusion and trust damage from unclear responsibility is realistically predictable; specific consequences may not be fully predictable.
  - **Access To Alternatives:** Alternatives usually exist: decision log, accountable owner, review trigger, dissent record, impact review and correction pathway.
  - **Serious Integration Attempt:** Weak if ambiguity persists; stronger if the organisation reconstructs the decision chain, names shares and repairs burdens.
- **Ceiling Rule Check:**
  - **Predictability Approx Zero:** `false`
  - **Access To Alternatives Approx Zero:** `false`
  - **M Capped At 4:** `false`
  - **Explanation:** No general cap applies to high-authority roles because ownership clarification and review are normally available; the cap may apply to actors without knowledge, influence or alternatives.
- **D Link:**
  - **Self Devaluation Does Not Raise M:** `true`
  - **High Subjective Guilt Triggers M Check Not M Increase:** `true`
  - **Low M High Harm Means Protection Not Blame:** `true`

### IA Box

- **Asymmetry Named:** Decision authority and consequence-bearing are separated: some roles can avoid ownership while others must implement, explain or absorb consequences.
- **Boundary Confirmed:** IA-box is an asymmetry check, not a verdict.
- **T Transparent:**
  - **Status:** partly
  - **Notes:** The decision may be known, but who owns it, who can revise it and why it was made are unclear.
- **J Justified:**
  - **Status:** partly
  - **Protected Good Or Purpose:** Shared decision-making, organisational coordination, expertise integration and continuity.
  - **Notes:** Shared ownership can be justified; blurred ownership is not justified when it prevents explanation, review or repair.
- **TB Time Bound:**
  - **Status:** partly
  - **Review Points Or Conditions:** A review date, escalation trigger, implementation checkpoint or consequence threshold should limit the ambiguity.
  - **Notes:** Without a review point, responsibility diffusion can become permanent.
- **R Reversible:**
  - **Status:** partly
  - **Real Return Or Exit Options:** Decision review, correction, clarification of ownership, revised communication, resource repair and acknowledgement of burden transfer.
  - **Notes:** Some consequences may be reversible; trust loss, workload and reputational effects may only be partially repaired.
- **Result:** IA_risk
- **Short Justification:** The asymmetry is not automatically inadult because distributed decisions can be functional; it becomes IA risk when ownership, review and reversibility remain unclear.
- **Immediate Action:** Create a post-decision ownership map: who decided, who implements, who explains, who reviews, who can revise and who protects affected roles.

## 11. IA Localisation

### Knowing

- **Issue:** The organisation may not know, or may not want to know, the actual decision chain and consequence distribution.
- **Possible Intervention:** Reconstruct the decision timeline, assumptions, authorisations, dissent and affected roles.

### Being Able

- **Issue:** Some actors may lack authority to clarify or revise the decision even though they carry consequences.
- **Possible Intervention:** Assign a review owner with real authority and create escalation access for implementers and affected roles.

### Being Permitted

- **Issue:** The culture may not permit people to question a collective decision once it has been announced.
- **Possible Intervention:** Make post-decision review a normal governance step rather than a sign of disloyalty.

### Willing

- **Issue:** High-power actors may avoid responsibility because clarity could expose mistakes, conflict or cost.
- **Possible Intervention:** Frame ownership as maturity, repair and learning, not as blame admission.

## 12. IA Protection

### Transparency Measures

- Write a decision record naming decision owner, participating roles, rationale, assumptions, known uncertainties and review conditions.
- Replace passive formulations such as 'it was decided' with role-bound language.
- Clarify which role can answer questions and which role can revise the decision.

### Justification Measures

- State the protected goods served by the decision: coordination, safety, resource use, strategy, compliance or continuity.
- Distinguish genuine constraints from preference, convenience or avoidance.
- Record dissent, risk reservations and unresolved uncertainties without punishing them.

### Time Boundedness Measures

- Define a review point after implementation begins.
- Set thresholds that trigger reconsideration, pause or escalation.
- Limit temporary ambiguity by assigning interim ownership.

### Reversibility Measures

- Create routes to modify, reverse or compensate for the decision.
- Correct the public/institutional narrative if responsibility was misassigned.
- Provide repair for roles that carried disproportionate consequences.

### Participation Or Voice Measures

- Give implementers a safe channel to report friction without being blamed for the decision.
- Give affected roles a credible route for questions, objections and evidence.
- Include dissent or minority views in the review rather than erasing them.

### Dignity Protection Measures

- Prevent scapegoating of visible implementers.
- Acknowledge affected burdens without making affected roles appear resistant or immature.
- Separate responsibility mapping from humiliation, punishment or person labelling.
- Use D-language only as a protection signal, not as a moral weapon.

### Review Or Falsifier

- **Date Or Interval:** At the first post-implementation checkpoint or within the next governance review cycle.
- **Falsifier Question:** Can every affected role identify who owns explanation, who owns correction and what real route exists for review?
- **Responsible Roles:**
  - decision_sponsor
  - decision_group
  - implementation_lead
  - governance_system
  - affected_role_representatives

## 13. Trajectory

- **Principle:** Trajectories, not labels.

### Timeline

- **t0:**
  - **Short Description:** Before the decision, options, constraints and decision rights are framed.
  - **A Band:** 5-6
  - **M Band:** 3-5
  - **D Observation Optional:** D not yet central; dignity protection depends on inclusion, clarity and fair process.
  - **Key Context Role Power Situation:** Power lies in agenda-setting, option framing and deciding who is included.
- **t1:**
  - **Short Description:** The decision is made and communicated, but ownership, rationale or review path remains vague.
  - **A Band:** 4-5
  - **M Band:** 4-6
  - **D Observation Optional:** Level-1 D stress may emerge if affected roles feel unseen or implementers become buffers.
  - **Key Context Role Power Situation:** Authority has acted, but accountability architecture is not clear.
- **t2:**
  - **Short Description:** Consequences appear and responsibility becomes blurry; actors point to the system, the group or prior constraints.
  - **A Band:** 3-5
  - **M Band:** 5-6_for_high_leverage_roles / 2-4_for_low_power_roles
  - **D Observation Optional:** D stress may rise toward level 2 if blame drifts downward or affected roles are dismissed.
  - **Key Context Role Power Situation:** Burden-bearing separates from decision power; review and repair become urgent.
- **t3:**
  - **Short Description:** The organisation either reconstructs responsibility and repairs the process or normalises responsibility diffusion.
  - **A Band:** 6-7_if_repaired / 3-4_if_normalised
  - **M Band:** 3-4_if_repaired / 6-7_if_knowingly_left_blurry_by_high_power_roles
  - **D Observation Optional:** D stress decreases through clarification and non-scapegoating; it consolidates if ambiguity remains protective for powerful actors.
  - **Key Context Role Power Situation:** Trajectory depends on whether governance learns or defensive ambiguity becomes culture.

### A T

- **Pattern:** zigzagging
- **Notes:** Awareness may be sufficient at decision time but drop when consequences threaten reputation; it can rise through structured review.

### M T RVR T

- **RVR Description:** Responsibility–viability–range changes as knowledge of consequences increases and viable correction routes become clearer.
- **Knowledge Over Time:** At t0, assumptions and risks are partly known; at t1, ownership should be documentable; at t2, consequences become visible; at t3, refusal to clarify becomes more responsibility-relevant.
- **Leverage Over Time:** Leverage shifts from decision design to communication, then to review, repair and governance reform.
- **Alternatives Over Time:** Before the decision, alternatives include better framing and documentation; after consequences, alternatives include correction, compensation, ownership clarification and review.
- **Ceiling Rule Over Time:** Ceiling caps may apply early for low-information actors, but become less available for high-authority roles once consequences and correction options are visible.

### D T Optional

- **Active:** `true`
- **Qualitative Course:** D stress is initially low, rises with abandonment or blame drift, and decreases if the organisation clarifies ownership without scapegoating.
- **D Quick Grid Movement If Used:** 0_or_1_at_t0 -> 1_at_t1 -> 1_or_2_at_t2 -> 0_or_1_if_repaired / 2_if_blame_drift_persists
- **Note:** No D-score; only qualitative trajectory.

## 14. D-module Optional

- **Active:** `true`
- **Activation Reason:** D is activated because responsibility diffusion can expose affected roles and implementers to abandonment, blame drift and relational dignity stress; the case is generic and guardrail-protected.
- **Communication Space:** internal_structural_review

### Guardrails Checked

- **Scenic:** `true`
- **Context Bound:** `true`
- **Role Bound:** `true`
- **Time Windowed:** `true`
- **No Global Statement About Persons:** `true`
- **No Dignity Score:** `true`
- **D0 Untouched:** `true`

### D Profile

- **D1 Self Treatment D I D B:**
  - **Observed Enactments:** No direct self-treatment evidence; possible self-dignity stress where actors over-assume blame or compensate through silent overwork.
  - **Context Notes:** The analysis does not infer inner states; it marks risks created by blurred responsibility and burden transfer.
  - **Trend Band Qualitative:** unclear
- **D2 Relational Dignity D R:**
  - **Observed Enactments:** Relational dignity is strained where decision owners become unreachable and affected roles are left with consequences but no accountable counterpart.
  - **Context Notes:** Shared responsibility can be dignity-compatible when transparent; it becomes dignity-stressing when it erases voice, ownership or repair.
  - **Interpretive Reading Not Judgment:** ambivalent
- **D P Public Dignity:**
  - **Active If Publicness Relevant:** `true`
  - **Observed Enactments:** Institutional visibility matters: organisational members watch who is protected, blamed, believed or ignored after the decision.
  - **Private Public Tension:** The decision may have been made privately, but consequences and ownership become institutionally public.
  - **Publicity Context:** institutional
- **A M D Link Without Mixing:**
  - **A Band Reference:** 4-5
  - **M Band Reference:** 4-6
  - **D Tendency:** level_1_D_stress_with_level_2_risk_if_blame_drift_or_abandonment_persists
  - **Protection Or Responsibility Implication:** D stress calls for protection, clarification and non-scapegoating; it does not raise M by itself and does not affect D0.

### D Quick Grid

- **Used:** `true`
- **Level:** 1
- **Preferred Wording:** This constellation currently shows level-1 D stress in this role / context / time window.
- **Forbidden Wording Avoided:** `true`
- **Movement Question:** What would be one small, real action that could make this constellation one level more dignified — and who has A and M levers for that?

## 15. Meta Notes

### Bias Risks

- **Confirmation Bias:** The observer may look only for evidence of evasion and miss genuine complexity or constraint.
- **Hindsight Bias:** Once consequences are known, predictability may be inflated and M-score over-raised.
- **Status Quo Loyalty Bias:** Insiders may protect existing governance and understate the problem of blurred responsibility.
- **Halo Horn Effects:** A visible leader may receive excessive blame or excessive protection based on prior reputation.
- **In Group Out Group Bias:** Decision-group members may excuse their own ambiguity while judging implementers or affected roles as difficult.
- **Dignity Bias Effect:** D-language could become a dignity penalty against decision owners if used without guardrails.

### Norm Assumptions

- **Explicit Norms:**
  - Authority and responsibility should remain connected.
  - Shared decision-making requires shared explanation, review and repair.
  - Affected roles should have credible routes to ask, object and seek correction.
  - No person is scored, labelled or dignity-ranked.
- **Implicit Norms:**
  - Passive organisational language hides responsibility and should be treated with caution.
  - Complexity is real but does not remove the duty to clarify decision ownership.
  - Repair after consequences is part of mature decision practice.
- **Dignity Concepts:**
  - D1_self_dignity_in_practice
  - D2_relational_dignity_in_practice
  - D-P_public_dignity_in_practice
  - D0_ontological_dignity_untouched
- **Normative Position Of D Reading:** The D-reading uses a dignity-protective organisational lens: responsibility diffusion is treated as ethically relevant when it exposes lower-power roles to abandonment, blame drift or loss of voice.

### Intuition

- **Initial Intuition:** The case feels like a common organisational mixed zone: not necessarily malicious, but structurally risky because ownership dissolves exactly when consequences need repair.
- **Used As Sensor Not Judge:** `true`
- **Checked Afterwards:** `true`
- **Supporting Evidence:** Blurred ownership, separated decision authority and consequence-bearing, passive language and missing review pathways support the IA-risk reading.
- **Contradicting Evidence:** The decision may have been genuinely complex, constrained, collectively legitimate and difficult to attribute to a single role.

### Possible Alternative Interpretations

- Functional collective responsibility: ownership is distributed because the decision genuinely required many perspectives.
- Temporary ambiguity: responsibility is unclear only briefly while new information is being gathered.
- Tragic residual conflict: all options carried harm and the outcome is painful without being IA.
- Implementation failure: the decision itself may have been clear, but translation into practice created ambiguity.
- Governance failure: the main issue may not be individual evasion but missing institutional documentation.
- Strategic evasion: ambiguity may be maintained to protect powerful actors from accountability.

### Counter Perspective

- **From Other Side:** Decision owners might say the decision was collective, constrained and made with the best information available.
- **From Affected Side:** Affected roles might say they carry consequences but cannot find anyone who will explain, revise or repair the decision.
- **From External Observer:** An observer might see a mixed enactment: distributed decision-making with insufficient post-decision accountability architecture.

## 16. Open Questions and Blind Spots

### Missing Information

- What exactly was decided?
- Who formally had authority to decide?
- Who materially influenced the decision?
- Who documented the rationale, risks and dissent?
- Who communicated the decision?
- Who carries the consequences?
- What review or correction path exists?
- Were consequences foreseeable at the time?
- Were dissenting or affected perspectives included?

### Uncertain Assumptions

- The case is treated as organisational and generic.
- The responsibility blur is treated as post-decision rather than pre-decision.
- At least some levers for clarification and review are assumed to exist.
- No intentional scapegoating is assumed unless evidence later supports it.

### Weak Points In Analysis

- M-band varies strongly by role power and access to information.
- D-stress is inferred from structural exposure rather than reported experience.
- Without exact decision details, justification and reversibility cannot be fully assessed.
- The analysis may understate genuine external constraints.

### Needed Perspectives

- decision_sponsor
- decision_group_members
- implementing_roles
- affected_roles
- governance_or_compliance_function
- neutral_process_observer

## 17. Possible Steps Towards Maturity

- **Decision Mode:** balance

### Functional Next Step

- **Action:** Create a post-decision responsibility map naming decision owner, implementation owner, communication owner, review owner, affected roles and correction authority.
- **Reversible:** `true`
- **Responsible Role:** decision_sponsor_or_governance_system

### Short Term Feasible

- Document the decision chain and current ownership.
- Name who can answer questions and who can revise the decision.
- Protect implementers from carrying decision blame.
- Invite affected roles to report consequences without retaliation.
- Set a review point with real authority.
- Correct passive language in communication.

### Medium Term Feasible

- Introduce a standard decision log for consequential decisions.
- Define role distinctions between sponsor, approver, recommender, implementer and reviewer.
- Create a norm that collective decisions require collective repair.
- Build review triggers for decisions made under uncertainty.
- Train leaders in non-scapegoating responsibility mapping.
- Audit whether decision authority and consequence-bearing are structurally misaligned.

### Overambitious Or Risky

- Trying to assign total responsibility to one person without reconstructing the decision chain.
- Turning every decision into heavy bureaucracy.
- Using the model as a blame engine.
- Forcing affected roles to relive consequences in public without protection.
- Declaring the whole organisation immature from one episode.

### Protection First If Low M High Harm

- If harm is high but predictability or alternatives were low, prioritise protection, repair and learning rather than blame.

### Structural Change If High M

- If high-power roles knowingly preserve ambiguity to avoid accountability, redesign governance, documentation, review authority and escalation protection.

## 18. Transmission Check

- **Pre Transmission Gate Passed:** `true`

### Final Checklist

- **Scope And Guardrails Checked:** `true`
- **Roles And Publicness Checked:** `true`
- **Score Hygiene Checked:** `true`
- **Bias Norm Intuition Checked:** `true`
- **Consequences And Reversibility Checked:** `true`
- **D Cleanliness Checked If Relevant:** `true`

- **Status:** structurally_transmittable
- **If Not Transmittable Reason:** not_applicable

### Allowed Use Of This Analysis

- internal_reflection
- training_simulation
- professional_supervision
- structural_case_review
- organisational_audit
- process_improvement
- governance_review

### Not Allowed Use

- person_label
- public_shaming
- individual_sanction
- HR_decision
- forensic_use
- clinical_diagnosis

### Review Required

- **Required:** `true`
- **Review Date Or Condition:** Review after adding the actual decision record, role authority map, affected-party perspective and consequence timeline.
- **Falsifier:** If the decision ownership, review authority, rationale and correction route were already clear to all affected roles, the IA-risk reading should be downgraded.

## 19. Uniform Report

- **Generate Only From Structured Fields:** `true`
- **Title:** Blurry Responsibility After a Decision
- **Overview 4 To 7 Sentences:** 
  > This generic organisational case concerns a decision whose ownership becomes unclear after consequences appear.
  > The analysis focuses on roles, structures and enactments rather than individual character.
  > The central maturity issue is whether shared decision-making remains connected to shared explanation, burden-bearing, review and repair.
  > The first asymmetry lies between those who had authority to decide and those who must carry or explain the consequences.
  > The case shows IA risk because distributed responsibility can be functional, but becomes inadult when transparency, review and reversibility are missing.
  > D is activated only qualitatively as a protection signal against abandonment, scapegoating and loss of voice; D0 remains untouched.

### Key Findings

- Responsibility diffusion is the central R-axis problem.
- The A-score band is 4-5 because awareness is partial, fragmented and insufficiently integrated across roles.
- The M-score band is 4-6 because responsibility depends strongly on role power, knowledge and access to alternatives.
- The IA-box result is IA_risk, not a verdict.
- The main asymmetry is the separation of decision authority from consequence-bearing.
- D-stress is level 1 in the minimal case, with level-2 risk if blame drifts downward or affected roles are abandoned.
- The mature movement is toward documented ownership, review authority, non-scapegoating and repair.

- **A Summary:** A(H) ≈ 4-5: everyday mixed zone; the organisation knows a decision occurred but has not sufficiently integrated ownership, consequences and review.
- **M Summary:** M(X) ≈ 4-6: shared structural responsibility is moderate to elevated for decision sponsors, decision groups and governance roles with real levers; lower for actors without knowledge or alternatives.
- **IA Box Summary:** IA(S) = partly transparent, partly justified, partly time-bound, partly reversible; result: IA_risk.
- **D Summary If Activated:** The D-profile shows qualitative level-1 D stress around abandonment, blame drift and institutional visibility; no dignity score or person-level dignity judgement is made.
- **Trajectory Summary:** The trajectory can mature through ownership mapping and repair, or deteriorate if ambiguity protects authority while transferring burdens downward.
- **Guardrail Status:** Guardrails are fulfilled for a generic organisational training case: no person labels, no HR decision, no public shaming, no clinical or forensic use.
- **Transmission Status:** structurally_transmittable
- **Practical Implications:** Clarify who decided, who implements, who explains, who reviews, who can revise and who protects affected roles.
- **Conclusion:** The mature direction is not to hunt for a culprit, but to reconnect authority, responsibility, consequence awareness and repair in a reviewable organisational process.
