---
document_id: MIP-AHP-MODULE-SPECIFICATION
title: "Maturity in Practice – AHP Module Specification"
source_basis:
  - "05_model/MIP - Maturity in Practice - AHP Module.yaml"
  - "05_model/MIP - Maturity in Practice.yaml"
source_role: "human-readable module specification aligned with final MIP and AHP YAML"
target_file: "05_model/model specification/Maturity in Practice - AHP Module Specification.md"
status: "module-specification"
version: "2.0"
language: "EN"
author: "T. Zöller"
addon_status: "optional second-order overlay; default off"
relation: "analysis-quality overlay for MIP - Maturity in Practice.yaml"
claim_mode: "technical module specification, second-order, meta-analytic, guardrail-bound, non-rescoring"
active_axis_notation: "A–C–R–P–D"
d_status: "AHP does not activate D; does not create D-profiles; does not assign D-Quick-Grid levels; supports D₀-protective language discipline"
mip_status: "model-layer module specification; aligned with MIP - Maturity in Practice - AHP Module.yaml"
---

# Maturity in Practice – AHP Module Specification

*Attack-surface visibility, hardening backlog and precision heuristic for MIP analyses*

**Version:** 2.0  
**Spec basis:** `MIP - Maturity in Practice - AHP Module.yaml`  
**Compatible with:** `MIP - Maturity in Practice.yaml`  
**Author:** T. Zöller  
**Language:** EN  
**Status:** Optional module, default off  
**Module status:** `stable_working_overlay`  
**Model relation:** Optional second-order overlay for MIP analyses

---

# 1. Purpose and scope

The **AHP Module** is an optional second-order overlay for **MIP — Maturity in Practice** analyses.

AHP stands for:

- **A** — Attack-surface visibility;
- **H** — Hardening for the next iteration;
- **P** — Precision Heuristic.

Its purpose is to examine the **analysis artifact**, not the analysed case itself.

It asks:

- Where is this analysis still attackable?
- Where is the wording imprecise?
- Where is the scope too wide, too unclear or too leaky?
- Where could an inference be misunderstood?
- Where are score hygiene, D-language, transmission status or guardrails under-specified?
- What should be hardened in the next iteration?

The module does **not** judge content, cases, actors or persons.

It does **not** create a second first-order MIP analysis.

---

## 1.1 What AHP does

When loaded alongside `MIP - Maturity in Practice.yaml`, AHP enables:

1. **Precision Heuristic (PH)**  
   A compact summary of how precise and robust the analysis artifact currently is.

2. **Attack Points**  
   Explicitly marked vulnerabilities in the analysis artifact:
   wording, scope, evidence linkage, inference, reversibility, publicness, transmission risk or dignity language.

3. **Hardening Backlog**  
   Minimal next-iteration actions that make the analysis clearer, safer and more critique-ready.

These outputs are appended as an optional overlay to:

```text
case.uniform_report.addon_overlays.ah_precision
```

---

## 1.2 What AHP does not do

The module does **not**:

* change MIP axioms;
* change MIP parameters;
* change guardrails or red zones;
* rescore A-score;
* rescore M-score;
* change IA-box results;
* activate the D-module;
* create D-profiles;
* assign D-Quick-Grid levels;
* alter transmission status;
* make a non-transmittable analysis transmittable;
* evaluate persons;
* evaluate identities;
* evaluate ontological dignity (`D₀`);
* create hidden first-order findings.

Boundary:

> AHP hardens the analysis.
> It does not re-analyse the person, rescore the case, activate D, or upgrade transmission status.

---

# 2. Conceptual position within MIP

## 2.1 First-order MIP analysis

A first-order MIP analysis may include:

* `A–C–R–P` profile;
* optional `D` observation under guardrails;
* A-score;
* M-score;
* IA-box (`T–J–TB–R`);
* trajectory;
* RVR(t);
* D-profile, if D is explicitly activated;
* Meta Notes;
* transmission check;
* uniform report.

This first-order analysis belongs to `MIP - Maturity in Practice.yaml`.

---

## 2.2 Second-order AHP overlay

AHP operates one level above the case analysis.

It analyses:

* wording;
* scope;
* inference structure;
* evidence linkage;
* reversibility;
* publicness risk;
* dignity-language risk;
* score hygiene risk;
* transmission ambiguity;
* missing meta-notes;
* missing normative position;
* missing ceiling-rule checks.

It does **not** analyse the person, role or case directly.

AHP is therefore a **second-order analysis-quality overlay**.

---

## 2.3 Non-interference principle

The AHP module is non-interfering.

It may lower or raise confidence in the **quality of a reading**, but it may not change base results.

Non-interference means:

* does not modify axioms;
* does not modify guardrails;
* does not modify A-score;
* does not modify M-score;
* does not modify IA-box result;
* does not modify D-profile;
* does not activate D-module;
* does not assign D-Quick-Grid level;
* does not change transmission status;
* adds overlay only.

If AHP identifies a problem with the first-order analysis, the result is:

> create a hardening action for the next MIP iteration.

Not:

> silently change the base analysis.

---

## 2.4 Canonical module keys

The canonical AHP YAML uses the following top-level module keys:

* `schema_version`
* `file_name`
* `addon_meta`
* `AH_precision`
* `agent_addon_interface`
* `AH_precision_storage_spec`
* `case_schema_patch`
* `migration_notes`
* `validation_checklist`

The main output / template block remains named `AH_precision` for continuity with the A&H Precision lineage.

---

# 3. Activation and integration

## 3.1 Default state

AHP is **default off**.

It may be activated only when:

* an existing MIP analysis is present;
* structured case fields exist;
* the user or workflow explicitly requests AHP;
* or auto-mode suggests activation under defined triggers.

---

## 3.2 Activation modes

Allowed activation values:

```text
off | auto | on
```

Default:

```text
off
```

### Off

AHP is not used.

### Auto

The agent may **suggest** AHP activation when triggers are present.

Auto mode must not silently render AHP overlays without user or workflow permission.

### On

AHP is actively used and may render:

* PH summary;
* Attack Points;
* Hardening Backlog.

---

## 3.3 Activation triggers

AHP may be suggested when:

* the user requests a precision heuristic;
* the user requests attack points;
* the user requests a hardening backlog;
* contested terms are present;
* politically loaded terms are present;
* boundary-setting claims are made;
* exclusion claims are made;
* public or semi-public transmission is planned;
* D-language appears in the analysis;
* score hygiene could be misread;
* M ceiling-rule relevance is unclear;
* transmission status is uncertain;
* a next MIP iteration is planned.

---

## 3.4 Integration paths

Canonical case path:

```text
case.addons.ah_precision
```

Canonical report path:

```text
case.uniform_report.addon_overlays.ah_precision
```

Legacy paths may be retained only for migration.

Canonical output fields:

```text
precision_heuristic_summary
attack_surface_summary
hardening_backlog_summary
boundary_note
```

---

# 4. Core concepts

## 4.1 Precision Heuristic (PH)

PH is a **precision heuristic** for the analysis artifact.

It is not:

* an A-score;
* an M-score;
* a D-score;
* an IA verdict;
* a maturity score;
* a value score;
* a dignity score;
* a hidden second judgement layer.

PH indicates how well the analysis artifact satisfies defined precision dimensions.

---

## 4.2 Attack surface

The attack surface of an analysis is the set of points where its interpretation may be:

* distorted;
* misused;
* overextended;
* moralised;
* reified;
* transmitted prematurely;
* turned into person labelling;
* misread as dignity judgement;
* inflated through hindsight.

The attack surface belongs to the **analysis artifact**, not to persons.

---

## 4.3 Attack Point

An Attack Point marks a concrete vulnerability in the analysis artifact.

Possible targets include:

* terms;
* scope;
* inference;
* evidence linkage;
* reversibility;
* publicness;
* transmission status;
* D-language;
* M ceiling-rule handling;
* score hygiene;
* guardrail clarity;
* meta-notes.

Boundary:

> Attack Points are analysis vulnerabilities, not person findings.

---

## 4.4 Hardening Action

A Hardening Action is a minimal next-iteration instruction.

It improves the next analysis iteration.

It does not:

* repair the case;
* change persons;
* settle responsibility;
* change scores;
* change IA results;
* activate D.

Typical hardening actions include:

* define terms;
* add scope statement;
* add if/then criteria;
* separate observation from evaluation;
* add reversibility clause;
* add counter-reading;
* add publicity guardrails;
* tighten language hygiene;
* add role/context/publicness precheck;
* add score hygiene boundary;
* add ceiling rule check;
* add D-profile boundary;
* add normative position statement;
* add Meta Notes;
* add transmission status;
* downgrade to working note.

---

# 5. Precision Heuristic

## 5.1 PH boundary

PH is defined as:

> a precision heuristic for the analysis artifact.

It is not a base MIP score and must not be interpreted as:

* maturity;
* responsibility;
* dignity;
* IA quality;
* harm severity;
* moral fault.

---

## 5.2 PH dimensions

PH has six dimensions.

Each dimension has weight `1`.

Maximum points:

```text
6
```

### PD-1 — term definition

Key terms are defined with working definition, scope and exclusions.

### PD-2 — scope boundaries

Role, context, level and publicness are stated.

### PD-3 — conditions and thresholds

If/then criteria, IA-box thresholds, D-activation conditions or M ceiling-rule relevance are stated where needed.

### PD-4 — evidence linking

Observation vs. evaluation is separated; inferences are marked; no hidden assumptions.

### PD-5 — reversibility clause

Update, correction, review or working-note conditions are stated.

### PD-6 — language hygiene

No global person labels; no dignity labels; non-shaming, risk/potential phrasing; `D₀` untouched.

---

## 5.3 PH scoring

Method:

```text
weighted_checklist_sum
```

Band mapping:

| PH points | Band    |
| --------- | ------- |
| `0–2`     | `low`   |
| `3–4`     | `mixed` |
| `5–6`     | `high`  |

PH is rendered as:

```text
PH_band (PH_points / 6)
```

Example:

```text
mixed (4/6)
```

Again:

> PH is not an A/M/D/IA score.

---

## 5.4 Overlay effects

PH affects confidence in the **analysis artifact**, not the base score scales and not the underlying case.

Overlay effects may describe:

* A-reading confidence;
* C-reading confidence;
* IA-box decidability;
* D-R/D-P misreading risk.

Example language:

> A-reading confidence: mixed.
> IA-box decidability: partial.
> D-R/D-P misreading risk: down.

Not permitted:

> A improved.
> IA result changed.
> D is now safe.

---

# 6. Attack surface

## 6.1 Attack surface boundary

Attack Points identify vulnerabilities in the analysis artifact:

* wording;
* scope;
* inference;
* evidence linkage;
* reversibility;
* publicness;
* transmission risk;
* dignity language.

They never identify vulnerabilities, defects or dignity deficits in persons.

---

## 6.2 Severity

Severity values:

```text
low | medium | high
```

Meaning:

| Severity | Meaning                                   |
| -------- | ----------------------------------------- |
| `low`    | Minor noise / easy patch                  |
| `medium` | Relevant uncertainty / visible leverage   |
| `high`   | Structural vulnerability / likely misread |

Severity describes interpretive or communicative risk **inside the analysis**.

It is not:

* moral fault;
* harm severity in the case itself;
* person risk;
* dignity level.

---

## 6.3 Attack Point types

The storage spec defines the following note types:

* `term_ambiguity`;
* `scope_leakage`;
* `missing_conditions`;
* `weak_justification`;
* `missing_reversibility`;
* `evidence_gap`;
* `counter_reading_missing`;
* `publicity_context_collapse_risk`;
* `dignity_language_risk`;
* `role_context_publicness_gap`;
* `score_hygiene_risk`;
* `D_profile_boundary_risk`;
* `M_ceiling_rule_gap`;
* `normative_position_missing`;
* `meta_notes_missing`;
* `transmission_status_ambiguity`;
* `guardrail_ambiguity`.

---

## 6.4 Attack Point identity

Attack Points use stable IDs.

Format:

```text
AP-001
```

IDs must remain stable across:

* sorting;
* truncation;
* iteration;
* severity reordering.

Index-based references are not canonical.

---

# 7. Hardening backlog

## 7.1 Purpose

The Hardening Backlog translates attack points into next-iteration actions.

It is designed to feed the next MIP run.

It does not repair the case or settle responsibility.

---

## 7.2 Hardening Action types

The module defines these action types:

* `define_terms`;
* `add_scope_statement`;
* `add_if_then_criteria`;
* `separate_observation_vs_evaluation`;
* `add_reversibility_clause`;
* `add_counter_reading`;
* `add_publicity_guardrails`;
* `tighten_language_hygiene`;
* `add_role_context_publicness_precheck`;
* `add_score_hygiene_boundary`;
* `add_ceiling_rule_check`;
* `add_D_profile_boundary`;
* `add_normative_position_statement`;
* `add_meta_notes`;
* `add_transmission_status`;
* `downgrade_to_working_note`.

---

## 7.3 Hardening Action identity

Hardening Actions use stable IDs.

Format:

```text
HB-001
```

Each Hardening Action should link to exactly one primary Attack Point where possible.

Canonical linkage:

```text
linked_attack_ref: AP-001
```

---

## 7.4 Hardening boundary

Hardening actions improve the next analysis iteration.

They do not:

* repair the case;
* change persons;
* settle responsibility;
* change A-band;
* change M-band;
* change IA-box result;
* activate D.

---

# 8. Output contract

When active, AHP may render three standard report sections.

## 8.1 Precision Heuristic Summary

Canonical report field:

```text
case.uniform_report.addon_overlays.ah_precision.precision_heuristic_summary
```

English template:

```markdown
**Precision Heuristic (PH):** {PH_band} ({PH_points}/{PH_max})
- Satisfied precision dimensions: {PH_dims_true}/{PH_dims_total}
- Expected overlay effect: A-reading confidence {confidence_shift_for_A_reading}, C-reading confidence {confidence_shift_for_C_reading}, IA-box decidability {IA_box_decidability}, D-R/D-P misreading risk {D_R_D_P_misreading_risk}
- Boundary: PH does not rescore A, M, IA or D.
```

German template:

```markdown
**Präzisionsheuristik (PH):** {PH_band} ({PH_points}/{PH_max})
- Erfüllte Präzisionsdimensionen: {PH_dims_true}/{PH_dims_total}
- Erwartete Overlay-Wirkung: A-Lesart-Sicherheit {confidence_shift_for_A_reading}, C-Lesart-Sicherheit {confidence_shift_for_C_reading}, IA-box-Entscheidbarkeit {IA_box_decidability}, D-R/D-P-Fehlleserisiko {D_R_D_P_misreading_risk}
- Boundary: PH bewertet A, M, IA oder D nicht neu.
```

Legacy note:

> `precision_score_summary` is a legacy field name.
> It now refers to PH as a Precision Heuristic, not to a base score.

---

## 8.2 Attack Surface Summary

Canonical report field:

```text
case.uniform_report.addon_overlays.ah_precision.attack_surface_summary
```

English header:

```markdown
**Attack Points (analysis vulnerabilities, not person findings):**
```

German header:

```markdown
**Attack Points (Angriffsflächen der Analyse, keine Personenbefunde):**
```

Each item includes:

* severity label;
* title;
* Attack Point ID;
* target path;
* note type;
* note message;
* suggested patch.

If none:

```markdown
_No relevant attack points marked (or AHP disabled)._
```

---

## 8.3 Hardening Backlog Summary

Canonical report field:

```text
case.uniform_report.addon_overlays.ah_precision.hardening_backlog_summary
```

English header:

```markdown
**Hardening Backlog (next iteration):**
```

German header:

```markdown
**Hardening Backlog (nächste Iteration):**
```

Each item includes:

* severity label;
* action type;
* instruction;
* Hardening Action ID;
* linked Attack Point;
* expected effect.

If none:

```markdown
_No hardening backlog generated._
```

---

## 8.4 Boundary note

Canonical boundary note:

```text
AHP hardens the analysis; it does not rescore A, M, IA or D.
```

---

# 9. Storage specification

## 9.1 Canonical storage path

Canonical case path:

```text
case.addons.ah_precision
```

This block stores:

* enabled;
* mode;
* completed-analysis requirement;
* structured-field requirement;
* PH points;
* PH band;
* PH checklist;
* PH overlay effect;
* Attack Points;
* Hardening Actions;
* boundary checks.

---

## 9.2 Required fields

A minimal AHP storage block contains:

```yaml
case:
  addons:
    ah_precision:
      enabled: false
      mode: "off"
      requires_completed_mip_analysis: true
      requires_structured_case_fields: true
      PH_points_0_to_6: null
      PH_band: ""
      PH_boundary_confirmed: true
      PH_checklist:
        PD-1_term_definition: null
        PD-2_scope_boundaries: null
        PD-3_conditions_and_thresholds: null
        PD-4_evidence_linking: null
        PD-5_reversibility_clause: null
        PD-6_language_hygiene: null
      PH_overlay_effect:
        confidence_shift_for_A_reading: ""
        confidence_shift_for_C_reading: ""
        IA_box_decidability: ""
        D_R_D_P_misreading_risk: ""

      attack_surface_annotations:
        - attack_point_id: ""
          severity: ""
          title: ""
          target_path: ""
          note_type: ""
          message: ""
          suggested_action: ""
          source_fields:
            - ""
          person_level_finding: false

      hardening_actions:
        - hardening_action_id: ""
          severity: ""
          action_type: ""
          instruction: ""
          linked_attack_ref: ""
          expected_effect: ""
          feeds_next_iteration: true
```

---

## 9.3 Boundary checks

The storage block includes boundary confirmations:

* does not change A-band;
* does not change M-band;
* does not change IA-box result;
* does not activate D-module;
* does not create D-profile;
* does not assign D-Quick-Grid level;
* does not change transmission status;
* Attack Points describe analysis, not persons.

---

## 9.4 Legacy output fields

The legacy flat report fields are retained only for migration.

In the final AHP module these fields appear under:

```yaml
legacy_flat_uniform_report_fields:
  precision_score_summary: ""
  attack_surface_summary: ""
  hardening_actions_summary: ""
```

They are retained only for migration.

The canonical report path is:

```text
case.uniform_report.addon_overlays.ah_precision
```
The legacy field name `precision_score_summary` must not be read as a base MIP score.

---

# 10. Derivation and rendering rules

## 10.1 Derivation rule

All rendered outputs must be derived exclusively from:

```text
case.addons.ah_precision
```

and existing documented structured case fields.

AHP may not introduce:

* hidden assumptions;
* new evidence;
* independent first-order findings;
* hidden rescoring;
* hidden D-activation;
* hidden transmission upgrade.

---

## 10.2 Rendering controls

The module defines:

* maximum Attack Points in rendered text: `7`;
* maximum Hardening Actions in rendered text: `7`;
* severity display: enabled;
* target-path display: enabled;
* expected-effect display: enabled;
* bullet style: `-`;
* Attack Point ordering: high → medium → low;
* Hardening Action ordering: high → medium → low.

The rendered text limit is not identical with the internal recursion / workflow guard.

Rendering limit:

* maximum Attack Points shown in text: `7`;
* maximum Hardening Actions shown in text: `7`.

Agent recursion guard:

* maximum annotations: `12`;
* maximum hardening actions held in the addon workflow: `8`.

Thus the module may store or track slightly more items than it renders in the compact report.

---

## 10.3 Inline comments

Inline comments are allowed but limited.

Maximum inline comments:

```text
3
```

Boundary:

> Inline AHP notes may mark analysis-language risks only.
> They must not add person-level interpretations or D-readings.

If D context is active:

> Avoid public inline D-comments about identifiable persons.

---

## 10.4 Recursion guard

There are no annotations on annotations.

Attack Points are either:

* addressed in the next iteration;
* or consciously accepted as limits.

This prevents infinite meta-commentary and false closure.

---

# 11. Boundaries for A, M, IA and D

## 11.1 A-boundary

AHP may flag weak A-justification.

It may not change the A-band.

If weak A-justification is found, AHP creates a hardening action for the next iteration.

---

## 11.2 M-boundary

AHP may flag an M ceiling-rule gap.

It may not:

* change M-band;
* raise M;
* lower M.

Required next step:

> create a hardening action for the next MIP iteration.

---

## 11.3 IA-boundary

AHP may flag IA-box decidability gaps.

It may not change the IA-box result.

Required next step:

> create a hardening action for the next MIP iteration.

---

## 11.4 D-activation boundary

AHP may flag D-language risk.

It may not:

* activate D-module;
* create D-profile;
* assign D-Quick-Grid level.

Allowed formulation:

> The analysis wording may be read as a person-level dignity judgement.

Forbidden formulation:

> This person shows Level-2 D stress.

---

# 12. Transmission boundary

AHP cannot make an analysis transmittable.

If main MIP guardrails fail:

> AHP output may only mark the issue; the case remains `working_note` or `not_mature_for_transmission`.

If a red zone is detected:

> Do not render public AHP report.

If transmission status is unclear:

> mark Attack Point and add Hardening Action.

AHP supports the transmission check.

It does not override it.

---

# 13. Language guardrails

AHP language must remain:

* non-moralising;
* non-shaming;
* non-diagnostic;
* non-person-labelling;
* non-dignity-labelling.

It must not escalate severity language beyond the provided lexicon.

Attack Points describe:

```text
analysis_artifact
```

They do not describe:

```text
persons
```

---

# 14. Relationship to dignity

AHP does not assess dignity.

Its dignity function is preventive:

* reduce dignity-language risk;
* prevent D-language from becoming person-level judgement;
* keep interpretations contextual;
* keep transmission reversible;
* protect `D₀` indirectly by disciplining analysis language.

AHP may flag:

> dignity_language_risk

It may not produce:

* D-profile;
* D-Quick-Grid level;
* dignity score;
* person-level dignity judgement.

---

# 15. Relationship to Meta Notes and open questions

## 15.1 Distinction from open questions

Open questions and blind spots document gaps in:

* case material;
* evidence;
* perspectives;
* context.

Attack Surface annotations document vulnerabilities in:

* the analysis artifact;
* wording;
* scope;
* inference;
* transmission risk.

Both may coexist.

They are not the same field.

---

## 15.2 Relationship to Meta Notes

AHP may flag:

* `normative_position_missing`;
* `meta_notes_missing`;
* `counter_reading_missing`;
* `guardrail_ambiguity`.

It does not replace Meta Notes.

It can only point out that they are missing or under-specified.

---

# 16. Migration from previous version

## 16.1 File rename

Previous:

```text
MIPractice_addon_AH_precision.yaml
```

New:

```text
MIP - Maturity in Practice - AHP Module.yaml
```

---

## 16.2 Schema version

Previous:

```text
MIPractice_addon_AH_precision_v1.2
```

New:

```text
MIP_AHP_module_v2.0
```

---

## 16.3 Compatibility

Previous:

```text
MIPractice_case_v2.0_full_with_model_reference
```

New:

```text
MIP - Maturity in Practice.yaml
```

---

## 16.4 Canonical case path

Previous:

```text
case.ah_precision
```

New:

```text
case.addons.ah_precision
```

---

## 16.5 Canonical report path

Previous flat fields:

```text
case.uniform_report.precision_score_summary
case.uniform_report.attack_surface_summary
case.uniform_report.hardening_actions_summary
```

New path:

```text
case.uniform_report.addon_overlays.ah_precision
```

---

## 16.6 Terminology updates

* `MIPractice` → `MIP`
* `D0` → `D₀` in human-readable text
* `D1/D2` → `D₁/D₂` in human-readable text
* `D module` → `D-module`
* `D profile` → `D-profile`
* `IA box` → `IA-box`
* `A score` → `A-score`
* `M score` → `M-score`
* `Precision score` → `Precision Heuristic`

---

# 17. Validation checklist

Final validation must ensure:

* AHP is optional.
* Default activation is off.
* AHP requires existing structured MIP analysis fields.
* AHP derives outputs only from documented fields.
* AHP never invents hidden assumptions.
* AHP never changes base A/M/IA/D results.
* AHP never activates D.
* AHP never creates D-profiles.
* AHP never assigns D-Quick-Grid levels.
* AHP never creates person-level findings.
* AHP never upgrades transmission status.
* Attack Points describe analysis artifacts, not persons.
* Hardening Actions feed the next iteration.
* PH is a Precision Heuristic, not a score in the MIP sense.

Deprecated terms must not appear except in migration or legacy contexts.

---

# 18. Implementation notes

## 18.1 Required loading order

Load:

```text
MIP - Maturity in Practice.yaml
```

first.

Then optionally load:

```text
MIP - Maturity in Practice - AHP Module.yaml
```

AHP requires existing structured MIP case fields.

---

## 18.2 Agent behaviour

If AHP is active, an agent may render:

* Precision Heuristic Summary;
* Attack Surface Summary;
* Hardening Backlog Summary.

The agent must not:

* render AHP from hidden assumptions;
* use AHP in red-zone contexts;
* create person-level Attack Points;
* use AHP as a second judgement layer;
* rescore A, M, IA or D;
* activate D;
* upgrade transmission status.

---

## 18.3 Refusal and downgrade rules

If no structured case fields exist:

> Do not render AHP; ask for or generate base MIP structure first.

If a red zone is detected:

> Do not render public AHP report.

If the user requests person attack points:

> Refuse and reframe as analysis attack surface.

If the user requests rescoring via AHP:

> Refuse and reframe as next-iteration hardening.

If the user requests D activation via AHP:

> Refuse and reframe as D-language risk or main MIP D decision.

---

# 19. Citation and license

When referencing this module, cite the base model and the module.

**Base model reference:**

T. Zöller: *Maturity in Practice – A Praxeological Anthropology.*

**Technical base reference:**

*MIP - Maturity in Practice.yaml*
Schema version: `MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned`.

**Technical module reference:**

*MIP - Maturity in Practice - AHP Module.yaml*
Schema version: `MIP_AHP_module_v2.0`.

**License note:**

The license note is distribution-level metadata.

It is not defined inside the AHP YAML module itself.

Unless otherwise specified on the distribution page, the YAML and this module specification are released under a Creative Commons Attribution–NonCommercial–ShareAlike license.

Commercial use requires explicit permission.

Derivative works must attribute the original author and preserve the guardrails of the base model and the AHP module.

---

# 20. Closing formulation

AHP formalises one simple discipline:

> The more powerful an analysis becomes,
> the more visible its weak points must be.

Its task is not to close critique.

Its task is to make critique structurally usable.

AHP strengthens MIP not by adding authority, but by adding reviewability:

> Precision without person-labelling.
> Hardening without rescoring.
> Attack surfaces without attack on persons.
> Revision without dignity loss.
