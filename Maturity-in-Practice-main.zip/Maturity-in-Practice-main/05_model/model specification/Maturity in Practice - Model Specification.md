---
document_id: MIP-MODEL-SPECIFICATION
title: "Maturity in Practice – Model Specification"
source_basis:
  - "05_model/MIP - Maturity in Practice.yaml"
source_role: "human-readable model specification aligned with final MIP YAML"
target_file: "05_model/model specification/Maturity in Practice - Model Specification.md"
status: "model-specification"
version: "3.0"
language: "EN"
author: "T. Zöller"
schema_status: "stable_working_version"
claim_mode: "technical specification, schema-aligned, guardrail-bound, dignity-protective"
active_axis_notation: "A–C–R–P–D"
d_status: "D₀ untouchable; D₁/D₂ only as dignity-in-practice; D-module optional, protected and default-off"
mip_status: "model-layer specification; aligned with MIP - Maturity in Practice.yaml"
---

# Maturity in Practice – Model Specification

*A praxeological framework for maturity, responsibility, asymmetry and dignity in practice*

**Version:** 3.0  
**Spec basis:** `MIP - Maturity in Practice.yaml`  
**Schema version:** `MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned`  
**Author:** T. Zöller  
**Language:** EN  
**Status:** Public model specification, aligned with `schema_meta.status = "stable_working_version"`  
**Model status:** `working_version`

---

# 1. Purpose and scope of this specification

This document specifies the **MIP — Maturity in Practice** model in a concise, technical and human-readable form.

It is based on the YAML file:

```text
MIP - Maturity in Practice.yaml
```

The YAML file defines both:

1. the **normative / praxeological model reference** under `model_reference`, and
2. the **structured case template** under `case`.

This specification makes the YAML structure, concepts, guardrails and implementation logic transparent for human readers, practitioners, researchers and software systems.

---

## 1.1 What the specification covers

The specification covers:

* the **schema layer**:

  * `schema_version`,
  * `file_name`,
  * `schema_meta`,
  * application zones,
  * intended and excluded uses;

* the **agent layer**:

  * `agent_interface`,
  * welcome message,
  * pre-analysis questions,
  * defaults,
  * safe response rules;

* the **model reference layer**:

  * `A–C–R–P–D`,
  * submodule matrix,
  * modulators,
  * discipline profiles,
  * IA-box (`T–J–TB–R`),
  * A-score,
  * M-score,
  * D-module,
  * trajectories,
  * RVR(t),
  * bias / intuition / norm-change logic,
  * guardrails,
  * model limits,
  * formal notation;

* the **case layer**:

  * meta-information,
  * guardrails,
  * information basis,
  * snapshot,
  * role mapping,
  * frame vs. variability,
  * `A–C–R–P` profile,
  * optional D-observation,
  * submodule profile,
  * A-/M-bands,
  * IA-box,
  * IA-localisation and protection,
  * trajectory,
  * optional D-module,
  * Meta Notes,
  * open questions,
  * possible steps,
  * transmission check,
  * uniform report.

The schema basis is:

* core blocks: `01`–`12`;
* appendices: `A`, `B`, `D`, `E`;
* Appendix C status: pending final update.

---

## 1.2 Intended use of this specification

This specification is intended:

* as a **reference for practitioners** who apply MIP in supervision, organisational reflection, structural case review or ethics work;

* as a **research and teaching artefact** for philosophy, social sciences, psychology, ethics, law, education, organisation studies, media studies and AI governance;

* as a **governance layer for software and AI systems** that need a structured, guardrail-bound model for analysing enactments, roles, asymmetries and dignity in practice;

* as a **schema explanation** for implementers who need to understand how the YAML should be parsed, rendered or used in workflows.

---

## 1.3 Core idea

MIP analyses:

> **enactments, roles and structures — not persons.**

It asks how maturity, responsibility, power, asymmetry and dignity are enacted under real conditions.

It does **not** evaluate the ontological value of human beings.

Its central distinction is:

* `D₀` — ontological dignity, inviolable and outside all metrics;
* `D₁/D₂` — dignity in practice, qualitatively describable only within role, context and time window.

The model is a **toolbox with an ethics rider**, not a worldview.

---

# 2. High-level structure of the YAML model

## 2.1 Top-level keys

| Key               | Description                                                                                                                                                                                                             | Role in the model                       |
| ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------- |
| `schema_version`  | Identifies the YAML release: `MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned`.                                                                                                                                 | Versioning / compatibility              |
| `file_name`       | Canonical file name: `MIP - Maturity in Practice.yaml`.                                                                                                                                                                 | File identity                           |
| `schema_meta`     | Contains canonical name, version, status, model status, basis, intended uses, excluded uses, governing principles and application zones.                                                                                | Governance / safety / schema metadata   |
| `agent_interface` | Defines how interactive agents should behave before analysis: welcome message, pre-analysis questions, defaults and safe response rules.                                                                                | Interaction and AI-governance layer     |
| `model_reference` | Contains the normative / praxeological model: axioms, parameters, submodules, modulators, discipline profiles, IA-box, scores, D-module, trajectories, bias / intuition / norm change, guardrails, limits and notation. | Model definition                        |
| `case`            | Provides the structured template for applying MIP to concrete situations.                                                                                                                                               | Case documentation / application schema |

---

## 2.2 Conceptual separation

### `model_reference`

The `model_reference` block defines the model itself.

It contains:

* the axiomatic core;
* `A–C–R–P–D`;
* the canonical submodule matrix;
* modulators;
* discipline profiles;
* IA-box (`T–J–TB–R`);
* A-score and M-score logic;
* D-module and D-profile boundaries;
* trajectories and RVR(t);
* bias, intuition and norm-change logic;
* guardrails and red zones;
* model limits;
* formal notation.

In short:

> `model_reference` defines the conceptual grid.

---

### `case`

The `case` block defines how a concrete analysis is documented.

It contains:

* metadata and interaction settings;
* guardrails and red-zone checks;
* information basis;
* neutral snapshot;
* role mapping;
* frame vs. variability;
* `A–C–R–P` profile;
* optional D-observation;
* submodule profile;
* A-score / M-score bands;
* IA-box;
* IA localisation and protection;
* trajectory;
* optional D-module;
* Meta Notes;
* open questions;
* possible steps;
* transmission check;
* uniform report.

In short:

> `case` defines how a full analysis is structured, checked and reported.

---

## 2.3 Application zones

The YAML distinguishes three application zones.

### Green zone

Recommended uses:

* structural analysis;
* historical or fictional cases;
* self-application;
* team learning without individual sanctions;
* process improvement.

### Yellow zone

Caution zone.

Conditions:

* affected real persons may be involved;
* use only embedded or moderated;
* no direct basis for sanctions or HR decisions;
* D only as protection signal, not moral label;
* roles, context and publicness clarified;
* counter-perspective documented;
* review or revision path defined.

### Red zone

Forbidden use contexts:

* clinical diagnostics;
* therapy planning;
* forensic assessment or criminal-justice decision support about individuals;
* HR decisions about individuals;
* child/youth diagnostics;
* public pillorying or ranking;
* online shaming or doxing;
* humiliation diagnostics;
* public D-readings of identifiable persons;
* dignity labelling of persons.

If a use context falls into the red zone, the model must not be applied.

---

# 3. Core rules and guardrails

## 3.1 Governing principles

The YAML defines the following governing principles:

* **Recognise the enactment — not the person.**
* **Profile ≠ person.**
* **A-score = band, not person score.**
* **M-score = shared structural responsibility, not guilt.**
* **D-profile = qualitative dignity-in-practice description, not dignity score.**
* **D₀ remains inviolable.**
* **D₁/D₂ describe dignity in practice only within role, context and time window.**
* **Tools structure perception; they do not decide cases.**
* **Revision is not optional.**

These principles govern all use of the model.

---

## 3.2 Guardrail rule

The central guardrail rule is:

> **Without guardrails, any IA / D analysis is invalid.**

Guardrails are not external ethics added after the model.

They are part of the model’s validity.

---

## 3.3 Profile ≠ person

MIP does not evaluate people as wholes.

It analyses:

* structures;
* roles;
* enactments;
* decisions;
* communication patterns;
* responsibility distributions;
* dignity enactments in practice.

It does not analyse:

* person worth;
* essence;
* inner moral value;
* clinical status;
* permanent dignity status.

Permitted formulation:

> “In this role / context / time window, this enactment shows …”

Not permitted:

> “This person is …”

---

## 3.4 Dignity guardrails

The Dignity guardrails state:

* `D₀` is untouchable;
* `D₁/D₂` describe enactments only;
* there is no dignity score;
* there are no person-level D-judgements;
* the D-module is default-off;
* if D creates more shame than clarity, D must be dialled down and work must shift to structures and protection.

---

## 3.5 Score hygiene

Score hygiene means:

| Element   | Boundary                                    |
| --------- | ------------------------------------------- |
| A-score   | Band, not person score                      |
| M-score   | Shared structural responsibility, not guilt |
| D-profile | Qualitative, not dignity score              |
| IA-box    | Asymmetry check, not verdict                |

Scores and profiles are structured readings.

They are not rankings.

---

## 3.6 Transmission guardrail

A case analysis may remain:

* `working_note`;
* `not_mature_for_transmission`;
* `structurally_transmittable`.

If guardrails fail, the analysis may remain a working note, but it must not become a decision basis.

---

# 4. Parameter system: `A–C–R–P–D`

## 4.1 Overview

MIP reads enactments through five parameters:

| Parameter | Label                | Short definition                                                                                   |
| --------- | -------------------- | -------------------------------------------------------------------------------------------------- |
| `A`       | Awareness            | What a role, person, group or system knows, could know, notices or refuses to notice.              |
| `C`       | Coherence            | Consistency between word, decision and deed across time, roles and contexts.                       |
| `R`       | Responsibility       | How burdens and consequences are assumed, refused, shifted, distributed or repaired.               |
| `P`       | Power / power to act | Real scope for influence and action: levers, alternatives, dependencies and intervention capacity. |
| `D`       | Dignity in practice  | Qualitative dignity enactment in self-treatment, relations and publicness.                         |

`A–C–R–P` form the standard structural analysis core.

`D` is the protected dignity-in-practice layer and remains optional / guardrail-bound.

---

## 4.2 `A` — awareness

Awareness includes:

* information access;
* role awareness (`A-R`);
* context awareness;
* publicness awareness (`A-P`);
* impact awareness;
* bias awareness.

It asks:

> What was known, knowable, noticed, ignored or refused?

---

## 4.3 `C` — coherence

Coherence includes:

* word-deed coherence;
* role coherence;
* context coherence;
* narrative coherence;
* correction of breaks.

It asks:

> Do claims, roles, decisions and actions remain intelligible and consistent under conditions?

---

## 4.4 `R` — responsibility

Responsibility includes:

* individual responsibility;
* social responsibility;
* institutional responsibility;
* ethical responsibility;
* public responsibility.

It asks:

> Who carries which burden, consequence, answerability or repair obligation?

Responsibility is not identical with guilt.

---

## 4.5 `P` — power / power to act

Power / power to act includes:

* inner agency;
* social agency;
* institutional agency;
* cultural agency;
* public agency (`P-PU`);
* real levers and alternatives.

It asks:

> What could realistically be done, changed, stopped, protected, refused or revised?

---

## 4.6 `D` — dignity in practice

`D` describes dignity enactment in practice.

It includes:

* `D₁` — self-dignity in practice;
* `D₂` — relational dignity in practice;
* `D-I` — inner dignity / inner self-relationship;
* `D-B` — bodily/material self-care;
* `D-R` — relational dignity;
* `D-P` — public dignity in practice.

Boundary:

> `D` refers to `D₁/D₂`, not to `D₀`.

It is optional, protected and qualitative.

---

# 5. Submodule matrix and modulators

## 5.1 Purpose of the submodule matrix

The submodule matrix refines `A–C–R–P–D` into more precise reading fields.

It supports:

* structured observation;
* pattern clarification;
* IA localisation;
* role/context-sensitive analysis;
* optional D-profile work.

It must not be used as a personality grid.

---

## 5.2 Canonical submodule matrix

### Awareness submodules

| Code   | Name                    | Description                                                                                      |
| ------ | ----------------------- | ------------------------------------------------------------------------------------------------ |
| `A-I`  | Inner awareness         | Awareness of impulses, emotions, ambivalence and inner signals, without clinical interpretation. |
| `A-R`  | Role awareness          | Awareness of the role from which one acts and the role attributed by others.                     |
| `A-C`  | Context awareness       | Awareness of setting, norms, constraints, protected goods and active levels.                     |
| `A-IM` | Impact awareness        | Awareness of consequences, side effects and affected parties.                                    |
| `A-P`  | Awareness of publicness | Awareness that an enactment is public, media-amplified, archived or symbolically interpreted.    |

### Coherence submodules

| Code  | Name                           | Description                                                               |
| ----- | ------------------------------ | ------------------------------------------------------------------------- |
| `C-S` | Social coherence               | Coherence in social codes, relational settings and social navigation.     |
| `C-P` | Coherence in power contexts    | Coherence when power differentials, dependency or asymmetry are active.   |
| `C-N` | Narrative coherence            | Coherence of stories, justifications, meaning frames and symbolic layers. |
| `C-I` | Institutional / rule coherence | Coherence between rules, institutional logic and lived practice.          |

### Responsibility submodules

| Code  | Name                      | Description                                                                   |
| ----- | ------------------------- | ----------------------------------------------------------------------------- |
| `R-I` | Individual responsibility | One’s own actionable share without over- or under-assumption.                 |
| `R-S` | Social responsibility     | Responsibility in relationships, teams, groups and care structures.           |
| `R-E` | Ethical responsibility    | Responsibility for norms, protected goods and dignity effects.                |
| `R-P` | Public responsibility     | Responsibility under public reach, media effects or institutional visibility. |

### Power / power-to-act submodules

| Code   | Name                              | Description                                                                              |
| ------ | --------------------------------- | ---------------------------------------------------------------------------------------- |
| `P-I`  | Inner agency / inner power to act | Experienced and real capacity for small reversible steps.                                |
| `P-S`  | Social agency                     | Capacity to act in social or relational contexts.                                        |
| `P-C`  | Cultural agency                   | Power to shape symbols, narratives, norms and cultural meanings.                         |
| `P-PU` | Public agency                     | Power to act in public contexts: reach, platform, media visibility, reputational effect. |

### Dignity-in-practice submodules

| Code  | Name                                    | Description                                                                                                |
| ----- | --------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| `D-I` | Inner dignity / inner self-relationship | Self-respect, self-contact, harsh self-talk, excessive guilt, self-devaluation.                            |
| `D-B` | Bodily/material self-care               | Dignity in bodily, material and everyday self-treatment: sleep, food, hygiene, health, boundaries, safety. |
| `D-R` | Relational dignity                      | Dignity in relational enactments: fairness, respect, refusal of degradation, shaming, protection, protest. |
| `D-P` | Public dignity in practice              | Dignity under public visibility: shaming, exposure, self-branding, reputation, public protection.          |

---

## 5.3 Modulators

Modulators do not replace `A–C–R–P–D`.

They alter how strongly patterns appear.

They are a prerequisite for fair structural responsibility and D-readings.

Boundary:

> Modulators explain shifts in enactment; they are not excuses and not replacement axes.

---

## 5.4 Structural modulators

The YAML names structural modulators such as:

* time pressure and complexity;
* access to information;
* role and power differentials;
* dependencies;
* institutional rules;
* degree of publicity.

These affect:

* awareness;
* coherence;
* responsibility;
* power to act;
* dignity pressure;
* public risk;
* the fairness of M-attribution.

---

## 5.5 Dynamic psychosocial modulators

The YAML also names dynamic psychosocial modulators:

* stress and overload;
* exhaustion and monotony;
* experiences of success;
* social resonance;
* group dynamics.

These may intensify or weaken enactment patterns.

They do not determine personhood.

They modify the reading of enactment under conditions.

---

## 5.6 Short practice rule

The YAML gives the practical sequence:

1. Structure first, then person.
2. Then enactment.
3. Only then interpretation.

This prevents premature person-labelling.

---

# 6. Dignity framework: `D₀`, `D₁`, `D₂`

## 6.1 `D₀` — ontological dignity

`D₀` is ontological dignity.

It is:

* inviolable;
* not measurable;
* not gradable;
* not rankable;
* not withdrawable.

It is not included in any metric.

No A-score, M-score, IA-box or D-profile may alter `D₀`.

---

## 6.2 `D₁` — self-dignity in practice

`D₁` describes how someone treats themselves in practice.

It is operationalised through:

* `D-I` — inner dignity / inner self-relationship;
* `D-B` — bodily/material self-care.

`D₁` may show, for example:

* self-care;
* self-respect;
* self-devaluation;
* excessive guilt;
* boundary collapse;
* bodily neglect;
* material self-neglect.

It is never a person-worth judgement.

---

## 6.3 `D₂` — relational dignity in practice

`D₂` describes how someone treats others, publicness, roles and the social world in practice.

It is operationalised through:

* `D-R` — relational dignity;
* `D-P` — public dignity in practice.

`D₂` may show, for example:

* protection;
* respect;
* shaming;
* exposure;
* public degradation;
* refusal to degrade;
* protest;
* dignity-preserving public conduct.

It is not a global doctrine of dignity.

---

## 6.4 D-module

The D-module is:

* optional;
* default-off;
* activated only with clear purpose, safe frame and guardrails;
* focused on `D₁/D₂`;
* never directed at `D₀`.

Activation conditions:

* guardrails fulfilled;
* clear purpose;
* safe communication space;
* role / context / time window documented;
* D expected to bring more clarity than shame.

Forbidden uses:

* clinical diagnostics;
* therapy planning;
* forensics;
* individual HR decisions;
* child/youth diagnostics;
* public pillory;
* ranking formats;
* humiliation diagnostics;
* public D-readings of identifiable persons;
* person-level dignity labelling.

---

## 6.5 D-profile

The D-profile is qualitative.

It contains sections for:

* `D₁` self-enactment / self-treatment (`D-I/D-B`);
* `D₂` relational dignity (`D-R`);
* `D-P` public dignity;
* linking `A–M–D` without mixing;
* guardrails and use.

Boundary:

> `D₀` remains outside the card.
> `D₁/D₂` describe D-enactments, not personhood.
> No numbers. Qualitative bands only.

---

## 6.6 D-Quick-Grid

The D-Quick-Grid is a quick orientation tool.

It is a **movement tool**, not a label.

Preferred wording:

> “This constellation currently shows level-2 D stress in this role / context / time window.”

Forbidden wording:

> “This person is level 2.”

Levels:

| Level | Label                        | Meaning                                                                                                                |
| ----- | ---------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `0`   | D not in focus               | Neutral / unremarkable; no stable D issue visible.                                                                     |
| `1`   | Banal / everyday drift       | Mild self- or other-devaluation; everyday drift; pay attention.                                                        |
| `2`   | Marked D stress              | Recurrent self-devaluation, boundary overriding, shaming, deliberate exposure or entitling group images.               |
| `3`   | Hard D breaks / extreme zone | Alarm zone; no fine-tuning; focus on protection goods; D-profile as documentation of injustice, not coaching material. |

---

# 7. IA-box and asymmetry evaluation

## 7.1 Purpose of the IA-box

The IA-box (`T–J–TB–R`) checks whether an asymmetry is functional, risky or inadult.

It evaluates the quality of an asymmetry.

It does not evaluate person worth.

Boundary:

> IA-box = asymmetry check, not verdict.

---

## 7.2 Criteria

| Criterion    | Code | Guiding question                                                          |
| ------------ | ---- | ------------------------------------------------------------------------- |
| Transparent? | `T`  | Who knows what — and who could realistically know it?                     |
| Justified?   | `J`  | Does the asymmetry serve a testable purpose or only one side’s advantage? |
| Time-bound?  | `TB` | Is the asymmetry limited by time, conditions or review points?            |
| Reversible?  | `R`  | Are there real ways back — or only theoretical ones?                      |

Important notation note:

> `R` in the IA-box means **reversibility**.
> It is distinct from `R` as **responsibility** in `A–C–R–P–D`.

---

## 7.3 Results

Possible results:

* `functional_asymmetry`;
* `IA_risk`;
* `inadult_asymmetry`.

Failing criteria indicate IA risk.

The result remains a structured reading, not a person judgement.

---

## 7.4 IA localisation

The case schema supports IA-localisation through:

* knowing;
* being able;
* being permitted;
* willing.

This helps locate where the asymmetry sits:

* information asymmetry;
* power asymmetry;
* permission asymmetry;
* will / responsibility breakdown.

---

## 7.5 IA protection

The case schema contains `ia_protection` fields for:

* transparency measures;
* justification measures;
* time-boundedness measures;
* reversibility measures;
* participation or voice measures;
* dignity protection measures;
* review or falsifier.

IA analysis must lead toward protective or corrective structure.

Pure labelling is not enough.

---

# 8. Scoring: A-score, M-score and trajectories

## 8.1 A-score

The A-score describes maturity in practice of an enactment, case or situation `H`.

Formal notation:

```text
A(H)
```

Boundary:

> A-score describes enactment, not essence.
> It is assigned to cases / situations / structures / episodes, not persons.

The A-score is expressed as a band.

Example:

```text
A ≈ 5–6 / 10
```

It is not a hard value.

It is not a person score.

It does not include `D₀`.

It does not convert `D₁/D₂` into a numeric score.

---

## 8.2 A-score calibration bands

| Band  | Label                         | Meaning                                                                                                   |
| ----- | ----------------------------- | --------------------------------------------------------------------------------------------------------- |
| `0–1` | Collapse zone                 | Severe breakdown across multiple axes; protection goods may be heavily violated; no inference about `D₀`. |
| `2–3` | Clearly inadult enactment     | Denial, incoherence, evasion of responsibility, misuse or refusal of power.                               |
| `4–5` | Everyday mixed zone           | Mixed patterns, visible striving, blind spots, oscillation.                                               |
| `6–7` | Solid adultness               | Baseline adult enactment with errors that can be named and corrected.                                     |
| `8–9` | High adultness under severity | High maturity under pressure, cost, risk or complexity.                                                   |
| `10`  | Ideal limit value             | Orientation point; rarely a real case score.                                                              |

---

## 8.3 A-score subscore notation

The YAML uses subscore notation:

```text
A(A) — maturity of awareness
A(C) — maturity of coherence
A(R) — maturity of responsibility
A(P) — maturity of action / power
```

These are not independent person ratings.

They support the structured justification of an A-band.

---

## 8.4 M-score

The M-score describes shared structural responsibility of actor / role-holder `X` for the overall trajectory and consequences.

Formal notation:

```text
M(X)
```

Boundary:

> M-score describes shared structural responsibility, not guilt, fault, blame or moral worth.

The M-score is also expressed as a band.

Example:

```text
M ≈ 3–4 / 10
```

---

## 8.5 M-score factors

The M-score is based on five factors:

1. **Knowledge**
   What was known or realistically knowable?

2. **Power / control**
   Which real levers were available?

3. **Predictability**
   Were consequences realistically recognisable?

4. **Access to alternatives**
   Were real alternatives available?

5. **Serious integration attempt**
   Were risks named, mitigated, corrected or integrated?

---

## 8.6 Ceiling rule

The ceiling rule protects against victim blaming:

```text
predictability ≈ 0 or access_to_alternatives ≈ 0 -> M <= 4
```

Principle:

> No high shared responsibility without predictability and real options.

Protective rules:

* self-devaluation does not raise M;
* high subjective guilt triggers M-check, not M-increase;
* low M + high harm means protection, not blame.

---

## 8.7 Trajectories

MIP reads trajectories, not labels.

Trajectory fields include:

* `A(t)` — maturity in practice across time;
* `M(t)` — shared structural responsibility across time;
* `D(t)` — dignity enactment across time, optional and qualitative;
* `RVR(t)` — responsibility–viability–range over time.

---

## 8.8 RVR(t)

`RVR(t)` means:

```text
responsibility–viability–range over time
```

Formula:

```text
RVR(t) = f(knowing_t, able_t, permitted_t, acting_t)
```

Boundary:

> RVR(t) is a responsibility curve, not a point verdict.

---

# 9. Bias, intuition, norm change and meta-attitude

## 9.1 Bias

Bias is baseline noise, not an exception.

Bias-awareness is part of `A`.

Bias risks include:

* confirmation bias;
* hindsight bias;
* status quo / loyalty bias;
* halo / horn effects;
* in-group / out-group bias.

Specific warning terms:

* hindsight risk: inflated predictability → inflated M-score;
* dignity-bias effect: dignity bonus / dignity penalty.

Bias does not automatically invalidate an analysis.

But bias must be named and documented.

---

## 9.2 Intuition

Intuition is:

* sensor;
* trigger;
* not judge.

Principle:

> Intuition is hypothesis, not proof.

Rule:

> Intuition may start the analysis, but must not end it.

---

## 9.3 Norm change

Norm change is not an obstacle.

It is subject matter.

The YAML names two traps:

* overwriting the past with current norms;
* freezing the present with past norms.

Every D-reading must name its normative position.

---

## 9.4 Meta-attitude

Meta-attitude is required.

It includes:

* no claim to final truth;
* willingness to revise;
* search for counterexamples;
* alternative perspectives;
* critique readiness.

Meta-guardrail:

> Without meta-attitude, dignity language falls back into moral labelling.

---

## 9.5 Meta Notes

The case schema contains `meta_notes`.

It documents:

* bias risks;
* explicit and implicit norm assumptions;
* dignity concepts;
* normative position of D-reading;
* intuition and whether it was checked;
* possible alternative interpretations;
* counter-perspectives.

This makes the analysis situated and reviewable.

---

# 10. Axiomatic core

The axiomatic core defines the model’s structural assumptions.

It includes:

1. **`D₀` is inalienable**
   Every human person possesses ontological dignity.

2. **Strict separation of person and enactment**
   The model evaluates actions, roles and practices, not persons as such.

3. **Five parameters of maturity in practice**
   `A–C–R–P–D`.

4. **`D₁/D₂` are dignity in practice, not dignity itself**
   `D₀` remains outside all metrics.

5. **Role, context and publicness are indispensable**
   No finding exists without them.

6. **Asymmetry is normal; IA requires failed justification**
   Asymmetry becomes problematic when `T–J–TB–R` fail.

7. **Maturity is an enactment state, not a person type**
   There are no “immature persons” as model outputs.

8. **Scores are structured estimations, not exact measurements**
   They are bands and must be justified.

9. **M is not guilt**
   M describes shared structural responsibility.

10. **System axiom**
    No enactment is isolated.

11. **Intersubjective documentation is mandatory for serious use**
    The analyst is part of the picture.

12. **Bias, intuition and norm change are method components**
    They are analysis constraints.

13. **Tragic residual conflicts**
    Not all painful outcomes are IA.

14. **Guardrails are constitutive**
    Without guardrails, the analysis is invalid.

---

# 11. Minimal formal notation

## 11.1 Formal-use boundary

Formal notation is a documentation aid.

It does not replace:

* context;
* guardrails;
* judgement;
* qualitative interpretation.

It helps make assumptions visible.

It does not turn the model into a calculus.

---

## 11.2 Notational hygiene

The final YAML avoids using `A` as actor placeholder, because `A` already denotes awareness and A-score notation.

Preferred notation:

| Symbol | Meaning                                     |
| ------ | ------------------------------------------- |
| `A`    | Awareness / A-score notation                |
| `X`    | Actor / role-holder / object of observation |
| `Y`    | Second actor / counterpart                  |
| `H`    | Enactment, case or situation                |
| `K`    | Context                                     |
| `ρ`    | Role                                        |

Thus:

```text
M(X)
```

not:

```text
M(A)
```

---

## 11.3 Action tuple

An action enactment can be represented as:

```text
H = (X, ρ, K, A_w, C_o, R_s, P_a, D_p, IA)
```

Where:

* `X` — actor / role-holder / object of observation;
* `ρ` — role in this context;
* `K` — context / setting / publicness frame;
* `A_w` — awareness profile;
* `C_o` — coherence profile;
* `R_s` — responsibility profile;
* `P_a` — power-to-act profile;
* `D_p` — D-profile (`D₁/D₂`; optional);
* `IA` — IA-box evaluation (`T–J–TB–R`).

Reduced notation without D:

```text
H = (X, ρ, K, A_w, C_o, R_s, P_a)
```

---

## 11.4 D-profile notation

If D is activated under guardrails:

```text
D_p(H) = (D1, D2)
D1 = (D_I, D_B)
D2 = (D_R, D_P)
```

Boundary:

> `D_p(H)` describes D-enactments in `H`.
> It does not describe the value of `X`.
> `D₀` is not a profile variable.

---

## 11.5 IA-box notation

An asymmetry `S` can be represented as:

```text
IA(S) = (T, J, TB, R)
```

Result set:

```text
functional
IA_risk
inadult_asymmetry
```

Boundary:

> `IA(S)` evaluates the quality of an asymmetry, not the worth of any person involved.

---

## 11.6 A-score notation

```text
A(H) ≈ x–y
```

Boundary:

> `A(H)` is not a person score.

---

## 11.7 M-score notation

```text
M(X) ≈ x–y
```

Ceiling rule:

```text
Pr ≈ 0 or Alt ≈ 0 -> M(X) <= 4
```

Boundary:

> `M(X)` is not guilt.

---

## 11.8 Trajectory notation

```text
H_t = {H_t0, H_t1, H_t2, ...}
A(t) = A(H_t)
M(t) = M(X_t)
D(t) = D_p(H_t)
```

`D(t)` is optional and qualitative.

---

## 11.9 Meta Notes notation

```text
Meta(H) = (B, N, I, L, Alt)
```

Where:

* `B` — bias risks;
* `N` — norm assumptions;
* `I` — intuition input and check;
* `L` — lens / normative position of D-reading;
* `Alt` — possible alternative interpretations.

---

## 11.10 Formal red-zone boundary

A formally neat misuse remains misuse.

If guardrails fail:

```text
status(H) = working_note
```

not:

```text
status(H) = decision_basis
```

---

# 12. Case schema — `case`

## 12.1 `case.meta`

`case.meta` records the framework conditions of the analysis:

* case ID;
* case title;
* documentation date;
* analysts, roles and observer positions;
* language;
* confidentiality level;
* analysis mode;
* intended use;
* application zone;
* interaction profile.

The interaction profile records:

* reflection mode;
* D-module preference;
* output format;
* discipline profile;
* D-activation decision;
* transmission default.

---

## 12.2 `case.guardrails`

`case.guardrails` checks whether the model may be used.

It includes:

* profile-not-person confirmation;
* focus on roles, structures and enactments;
* minimal adulthood check;
* analyst self-implication;
* system axiom;
* use-context clarification;
* red-zone check;
* dignity protection;
* score hygiene;
* tragedy clause;
* misuse-as-own-finding acknowledgement.

If red-zone conditions apply, the model must not be applied.

---

## 12.3 `case.information_basis`

This block separates:

* primary material;
* secondary material;
* assumptions and inferences.

It also records:

* coverage estimate;
* reliability estimate;
* known gaps;
* main bias risks.

This prevents hidden assumptions from entering the report.

---

## 12.4 `case.snapshot`

The snapshot gives a short, neutral description of the case.

It records:

* short case description;
* central actors and roles;
* guiding question;
* level of analysis;
* first visible asymmetry;
* optional first visible D-themes.

No person judgement belongs here.

---

## 12.5 `case.role_mapping`

Role mapping clarifies:

* object of observation;
* observer position;
* involved roles;
* publicness.

The object of observation may be:

* person in role;
* team;
* institution;
* procedure;
* rule;
* discourse;
* narrative.

Boundary:

> The object is not the person as a whole.

Publicness fields include:

* publicness level;
* `A-P` relevance;
* `P-PU` relevance;
* `D-P` relevance if D is active;
* public shaming risk;
* reversibility risk.

---

## 12.6 `case.frame_vs_variability`

This section distinguishes:

* frame elements;
* variability elements.

Frame elements are fixed or slow-to-change conditions.

Variability elements are changeable processes, roles, communications or review points.

It also marks:

* unfair high-M zones;
* risk of using “the system” as excuse;
* where `D₁/D₂` are realistically improvable.

---

## 12.7 `case.acrp_profile`

The `acrp_profile` is the standard structural core.

It contains:

* `A_awareness`;
* `C_coherence`;
* `R_responsibility`;
* `P_power_to_act`.

This is the primary reading structure.

D is not folded into the A-score.

---

## 12.8 `case.optional_D_observation`

This section allows D-observation only if guardrails are fulfilled.

It records possible D-enactments such as:

* self-devaluation;
* self-neglect;
* shame dynamics;
* degradation of others;
* public shaming;
* protest or refusal;
* dignity protection.

Boundary:

> Observations only.
> No D-evaluation here.
> Use D-profile separately if needed.

---

## 12.9 `case.acrpd_submodules_profile`

This optional block documents submodule-level observations across:

* `A-I`, `A-R`, `A-C`, `A-IM`, `A-P`;
* `C-S`, `C-P`, `C-N`, `C-I`;
* `R-I`, `R-S`, `R-E`, `R-P`;
* `P-I`, `P-S`, `P-C`, `P-PU`;
* `D-I`, `D-B`, `D-R`, `D-P` if D is activated.

The D-submodules are only used when the D-module is active and guardrails are fulfilled.

---

## 12.10 `case.scores_and_ia`

This block contains:

* A-score;
* M-score;
* IA-box.

### A-score fields

* A-band;
* boundary confirmation;
* time / role / context;
* justification based on A, C, R, P and modulators;
* D excluded from A-number.

### M-score fields

* M-band;
* boundary confirmation;
* role / position / time frame;
* five factors;
* ceiling rule check;
* D-link.

### IA-box fields

* named asymmetry;
* boundary confirmation;
* `T_transparent`;
* `J_justified`;
* `TB_time_bound`;
* `R_reversible`;
* result;
* short justification;
* immediate action.

---

## 12.11 `case.ia_localisation`

This block locates IA risk across:

* knowing;
* being able;
* being permitted;
* willing.

It links each issue to possible intervention.

---

## 12.12 `case.ia_protection`

This block records protection measures:

* transparency measures;
* justification measures;
* time-boundedness measures;
* reversibility measures;
* participation or voice measures;
* dignity protection measures;
* review or falsifier.

It makes analysis actionable and revisable.

---

## 12.13 `case.trajectory`

Trajectory records movement over time.

It includes:

* timeline;
* `A(t)`;
* `M(t)` / `RVR(t)`;
* optional `D(t)`.

`D(t)` remains qualitative and optional.

There is no D-score.

---

## 12.14 `case.D_module_optional`

This block activates the D-module only if justified.

It records:

* activation reason;
* communication space;
* guardrails checked;
* D-profile;
* D-Quick-Grid;
* A/M/D link without mixing.

Communication spaces include:

* self-reflection;
* professional-confidential;
* moderated supervision;
* internal structural review;
* not public.

D-profile sections include:

* `D1_self_treatment_D_I_D_B`;
* `D2_relational_dignity_D_R`;
* `D_P_public_dignity`;
* `A_M_D_link_without_mixing`.

---

## 12.15 `case.meta_notes`

Meta Notes document:

* confirmation bias;
* hindsight bias;
* status quo / loyalty bias;
* halo / horn effects;
* in-group / out-group bias;
* dignity-bias effect;
* explicit and implicit norm assumptions;
* dignity concepts;
* normative position of D-reading;
* intuition;
* alternative interpretations;
* counter-perspectives.

This block is central for critique-readiness.

---

## 12.16 `case.open_questions_and_blind_spots`

This block records:

* missing information;
* uncertain assumptions;
* weak points in analysis;
* needed perspectives.

It prevents the analysis from pretending to be complete.

---

## 12.17 `case.possible_steps_towards_maturity`

This block records:

* decision mode;
* functional next step;
* short-term feasible steps;
* medium-term feasible steps;
* overambitious or risky steps;
* protection-first steps if low M / high harm;
* structural change if high M.

Decision modes include:

* maintain;
* balance;
* change_stop;
* unclear.

---

## 12.18 `case.transmission_check`

The transmission check decides whether an analysis may leave the internal thinking stage.

It contains:

* pre-transmission gate status;
* final checklist;
* status;
* reason if not transmittable;
* allowed use;
* not allowed use;
* review requirement.

Possible status values:

* `working_note`;
* `not_mature_for_transmission`;
* `structurally_transmittable`.

If the checklist fails, the analysis remains a working note or not mature for transmission.

---

## 12.19 `case.uniform_report`

The uniform report is generated only from structured fields.

It contains:

* title;
* 4–7 sentence overview;
* key findings;
* A-summary;
* M-summary;
* IA-box summary;
* D-summary if activated;
* trajectory summary;
* guardrail status;
* transmission status;
* practical implications;
* conclusion.

Rule:

> Generate reports only from documented fields, not hidden assumptions.

---

# 13. Discipline profiles

## 13.1 Function of discipline profiles

Discipline profiles are **field lenses** and **hotspot maps**.

They do not create new models.

They do not replace domain expertise.

They adapt:

* activated modules;
* typical questions;
* lens function;
* depth.

The axiomatic core remains unchanged.

Formula:

> Same axiomatic core. Different lens. Different depth. Different activated modules.

---

## 13.2 Available discipline profiles

The YAML defines the following profiles:

* `generic`;
* `sociology`;
* `political_science`;
* `law`;
* `ethics`;
* `psychology_performative`;
* `coaching_supervision`;
* `pedagogy_education`;
* `organisation_leadership`;
* `corporate_culture`;
* `media_studies`;
* `public_communication`;
* `ai_governance`;
* `philosophy_anthropology`.

---

## 13.3 Non-replacement boundaries

Examples:

* Psychology is performative, not clinical.
* Coaching and supervision support reflection, not diagnosis.
* Law does not replace legal judgement or due process.
* Political science does not replace political judgement or democratic process.
* Media studies does not replace cultural judgement or media expertise.
* AI governance may analyse IA and power asymmetry, but makes no machine dignity claims.

---

# 14. Agent interface

## 14.1 Purpose

The `agent_interface` defines how AI systems or interactive agents should prepare an analysis.

It includes:

* welcome message;
* pre-analysis questions;
* defaults;
* safe response rules.

---

## 14.2 Pre-analysis questions

If unspecified, the agent should clarify:

* reflection mode;
* D-module preference;
* analysis mode;
* output format;
* discipline / field lens;
* application zone;
* intended use.

---

## 14.3 Defaults

Default settings:

* reflection mode: `off`;
* D-module preference: `auto`;
* analysis mode: `full`;
* output format: `text`;
* discipline profile: `generic`;
* application zone: `yellow`;
* D activation rule: default-off, activate only if guardrails fulfilled;
* transmission default: working note until checked.

---

## 14.4 Safe response rules

The agent must:

* decline model application and offer structural/general reflection if red-zone use is detected;
* keep D off or use D only as protection signal if D-module use is unclear;
* mark open questions and blind spots if information is missing;
* set transmission status to working note if guardrails fail;
* refuse person labels and reframe as role/context/enactment.

---

# 15. Model limits

MIP does not promise:

* truthful recognition of persons;
* determination of inner life or motives;
* guaranteed justice;
* therapy or healing;
* automatic conflict resolution;
* definitive guilt settlement;
* morally correct politics, religion, culture or relationships;
* deciding who is worthy or unworthy;
* universal dignity doctrine for every culture;
* clinical, neurodiverse or trauma explanation.

It promises only to:

* make patterns of practice structurally clearer;
* make inadult asymmetries visible and discussable;
* distribute responsibility more fairly;
* open spaces for reflection;
* mark blind spots in power, roles and dignity;
* make judgements more reviewable;
* keep normative lenses visible;
* prevent D from becoming a moral weapon.

---

# 16. Implementation notes

## 16.1 YAML file and integration

The official YAML specification is:

```text
MIP - Maturity in Practice.yaml
```

It is the single source of truth for:

* the model reference;
* the case schema.

Implementations should consume the YAML directly rather than manually reproducing its logic.

---

## 16.2 Recommended bootstrap for LLM-based agents

A non-normative bootstrap instruction for LLM-based agents is:

> Load `MIP - Maturity in Practice.yaml`, parse it, and activate the `agent_interface`.
> Output the `agent_interface.welcome_message.message_text` if onboarding is required.
> Then use all defaults, guardrails, pre-analysis questions and safe response rules defined in the YAML.
> Do not operate in red-zone contexts.
> Generate reports only from documented case fields.

---

## 16.3 Optional AHP module

If present, the optional file:

```text
MIP - Maturity in Practice - AHP Module.yaml
```

may be loaded as a second-order overlay.

It may support:

* precision heuristic;
* attack points;
* hardening backlog.

It must not:

* rescore A, M, IA or D;
* activate the D-module;
* create D-profiles;
* assign D-Quick-Grid levels;
* make a non-transmittable analysis transmittable.

The AHP module is an analysis-quality overlay, not part of the first-order MIP reading.

---

# 17. Citation and license

When referencing this model, cite both the conceptual work and the technical YAML specification.

**Primary reference:**

T. Zöller: *Maturity in Practice – A Praxeological Anthropology.*

**Technical reference:**

*MIP - Maturity in Practice.yaml*
Schema version: `MIP_Maturity_in_Practice_v3.0_blocks_appendices_aligned`.

**Optional technical overlay:**

*MIP - Maturity in Practice - AHP Module.yaml*
If and only if the AHP module is used.

**License:**

The license note is distribution-level metadata.  
It is not defined inside `MIP - Maturity in Practice.yaml`.

Unless otherwise specified on the distribution page, the YAML and this model specification are released under a Creative Commons Attribution–NonCommercial–ShareAlike license.

Use is permitted for research, teaching and non-commercial applications.

Commercial use requires explicit permission.

Derivative works must attribute the original author and preserve the guardrails of the model.

---

# 18. Closing formulation

MIP is a working version.

It is stable enough to structure analysis, but not final enough to become doctrine.

Its core remains:

> **Recognise the enactment — not the person.**

And technically:

> `A–C–R–P` structures the analysis.
> `D` may be added only under guardrails.
> `A-score` and `M-score` are bands.
> `IA-box` checks asymmetry.
> `D-profile` describes dignity in practice qualitatively.
> `D₀` remains untouched.
> Guardrails decide whether an analysis may be transmitted.

Maturity in practice remains a permanent task — for persons, structures and the model itself.
