"""
PMS Example Script 03 – Project a Praxis Scene to Derived Axes
File: 03_project_scene_to_axes.py

Description:
    Shows how to interpret a simple praxis scene in terms of PMS operators
    and then project these operators onto the derived axes
    (Awareness A, Coherence C, Responsibility R, Action E, Dignity D).

    The example remains strictly structural and does not make psychological
    claims about persons.

Model:
    - PMS schema_version: PMS_1.3
    - Repository reference model file: ../model/PMS.yaml

PMS structures used:
    - derived_structures.derived_axes (A, C, R, E, D)

Usage:
    python 03_project_scene_to_axes.py

Dependencies:
    - PyYAML (yaml)

Notes:
    - The “scene” is a praxeological vignette, not a diagnosis.
    - Projection onto A/C/R/E/D is structural and approximate, for theory
      and model exploration only.
    - Do NOT use this pattern to assess individuals in clinical, forensic,
      HR, or person-ranking contexts.
    - Matching a scene to an axis formula does not prove exhaustive capture;
      it only shows structural correspondence under the current PMS encoding.
"""

import yaml

with open("../model/PMS.yaml", "r", encoding="utf-8") as f:
    pms = yaml.safe_load(f)

axes = pms["derived_structures"]["derived_axes"]

scene = {
    "description": "A colleague notices tension in a meeting, pauses, and waits before speaking.",
    "operators_detected": ["Δ", "□", "Θ", "Χ"]
}

def infer_axes(ops, axes_dict):
    """
    Return all derived axes whose formula operators are fully contained
    in the detected operator set.
    """
    ops_set = set(ops)
    active = []

    for axis_name, axis in axes_dict.items():
        formula = axis["formula"]
        if set(formula).issubset(ops_set):
            active.append({
                "axis_key": axis_name,
                "symbol": axis["symbol"],
                "formula": formula,
                "description": axis["description"],
            })

    return active

result = infer_axes(scene["operators_detected"], axes)

print("Scene:", scene["description"])
print("Operators detected:", scene["operators_detected"])
print()

if result:
    print("Projected derived axes:")
    for axis in result:
        print(
            f"- {axis['axis_key']} ({axis['symbol']}): "
            f"{axis['description']} | formula={axis['formula']}"
        )
else:
    print("No full derived-axis projection matched the detected operator set.")

print()
print("Note:")
print(
    "This projection is structural and repository-relative. "
    "It does not prove exhaustive capture of the scene."
)