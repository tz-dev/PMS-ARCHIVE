"""
PMS Example Script 04 – Detect an Asymmetry Drift Pattern (AD_A>>E)
File: 04_detect_asymmetry_drift_pattern.py

Description:
    Demonstrates how to use the PMS asymmetry drift pattern definitions to
    check whether a given scene structurally resembles the repository-level
    pattern AD_A>>E (Excessive Distance between Awareness and Enactment).

    The check is based solely on the structural basis encoded in PMS and on
    the operators marked as present in the scene. It does not constitute a
    psychological, clinical, moral, or person-level judgment.

Model:
    - PMS schema_version: PMS_1.3
    - Repository reference model file: ../model/PMS.yaml

PMS structures used:
    - derived_structures.asymmetry_drift_patterns.AD_A_much_greater_E
        - structural_basis.formula
        - generative_mechanism
        - axis_effects
        - status_note

Usage:
    python 04_detect_asymmetry_drift_pattern.py

Dependencies:
    - PyYAML (yaml)

Notes:
    - Asymmetry drift patterns describe structural praxeological
      distortion-patterns, not personality types or clinical categories.
    - Detection here is repository-relative and theory-guided: it checks
      whether the scene matches the currently encoded structural basis in PMS.
    - A positive match does not prove exhaustive capture of the scene, nor
      does a negative match prove the absence of related distortions under
      alternative formalisms.
    - This script is intended for theoretical, educational, and model-testing
      scenarios only.
    - Do NOT use asymmetry drift pattern detection as a diagnostic,
      sanctioning, forensic, or HR tool for real individuals.
"""

import yaml

with open("../model/PMS.yaml", "r", encoding="utf-8") as f:
    pms = yaml.safe_load(f)

drift = pms["derived_structures"]["asymmetry_drift_patterns"]["AD_A_much_greater_E"]
required_ops = set(drift["structural_basis"]["formula"])

scene = {
    "description": "A person continually evaluates and reframes a problem but never acts.",
    "operators_detected": ["Ω", "Α", "Φ", "Δ", "□", "Θ"]
}

scene_ops = set(scene["operators_detected"])
match = required_ops.issubset(scene_ops)

print("Scene:", scene["description"])
print("Operators detected:", sorted(scene_ops))
print("Required for AD_A>>E:", sorted(required_ops))
print()

if match:
    print("Result: Structural match with AD_A>>E under the current PMS repository reference.")
    print("Interpretation:")
    print(" -", drift["structural_basis"]["description"])
    print(" - awareness_axis:", drift["axis_effects"]["awareness_axis"])
    print(" - action_axis:", drift["axis_effects"]["action_axis"])
else:
    print("Result: No structural match with AD_A>>E under the current PMS repository reference.")

print()
print("Status note:")
print(drift["status_note"])