"""
PMS Example Script 05 – Visualize the Self-Model Operator Chain
File: 05_visualize_self_model.py

Description:
    Loads the PMS model and visualizes the repository-reference self-model
    operator chain:

        Ψ ∘ Σ ∘ Χ ∘ Φ ∘ Θ ∘ Ω ∘ Α ∘ Λ ∘ □ ∘ ∇ ∘ Δ

    The graph shows one derivational strategy encoded in the current PMS
    repository reference, illustrating how self-binding is structurally
    represented as grounded in preceding operators.

Model:
    - PMS schema_version: PMS_1.3
    - Repository reference model file: ../model/PMS.yaml

PMS structures used:
    - derived_structures.self_model.formula_sequence
    - derived_structures.self_model.chain_formula
    - derived_structures.self_model.interpretation_note
    - pms_model_reference.meta_axioms (optional labels)

Usage:
    python 05_visualize_self_model.py

Dependencies:
    - PyYAML (yaml)
    - networkx
    - matplotlib

Notes:
    - The self-model here is a structural representation within PMS, not a
      claim about inner experience or consciousness.
    - For artificial systems, Ψ should be read as policy / constraint
      stability, not as subjective selfhood.
    - This visualization represents the current repository derivational path.
      It should not be read as proving that all forms of selfhood reduce
      without remainder to this exact chain.
    - This visualization is a didactic and analytical tool for theory,
      teaching, and architecture design, not a diagnostic instrument.
"""

import yaml
import networkx as nx
import matplotlib.pyplot as plt

with open("../model/PMS.yaml", "r", encoding="utf-8") as f:
    pms = yaml.safe_load(f)

self_model = pms["derived_structures"]["self_model"]
seq = self_model["formula_sequence"]
chain_formula = self_model["chain_formula"]
interpretation_note = self_model["interpretation_note"]

axiom_lookup = {
    ax["id"]: ax["name"]
    for ax in pms["pms_model_reference"]["meta_axioms"]
}

G = nx.DiGraph()
for i in range(len(seq) - 1):
    G.add_edge(seq[i], seq[i + 1])

labels = {op: f"{op}\n{axiom_lookup.get(op, '')}" for op in seq}
pos = {seq[i]: (i, 0) for i in range(len(seq))}

plt.figure(figsize=(14, 3.8))
nx.draw(
    G,
    pos,
    labels=labels,
    with_labels=True,
    arrows=True,
    node_size=2600,
    font_size=9,
)

plt.title("PMS Self-Model Chain — Current Repository Reference Path")
plt.tight_layout()
plt.show()

print("Chain formula:")
print(chain_formula)
print()
print("Interpretation note:")
print(interpretation_note)