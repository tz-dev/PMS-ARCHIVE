"""
PMS Example Script 01 – Load and List Meta-Axioms
File: 01_load_and_list_meta_axioms.py

Description:
    Minimal example that loads the Praxeological Meta-Structure (PMS) model
    from the current repository reference YAML file and prints the list of
    meta-axioms Δ–Ψ with their basic dependency information.

Model:
    - PMS schema_version: PMS_1.3
    - Repository reference model file: ../model/PMS.yaml

PMS structures used:
    - pms_model_reference.meta_axioms (Δ–Ψ)
    - pms_model_reference.ordering_status

Usage:
    python 01_load_and_list_meta_axioms.py

Dependencies:
    - PyYAML (yaml)

Notes:
    - PMS is a structural, non-psychological, non-diagnostic meta-model.
    - This script is for theoretical and technical exploration only.
    - Do NOT use PMS for clinical diagnosis, personality typing, mental health
      risk assessment, automated moral judgment, or individual person evaluation.
    - The listed order is the current repository reference path, not a proof
      that no rival or revised formalization is possible.
"""

import yaml

with open("../model/PMS.yaml", "r", encoding="utf-8") as f:
    pms = yaml.safe_load(f)

schema_version = pms["schema_version"]
ordering_status = pms["pms_model_reference"]["ordering_status"]["interpretation"]
axioms = pms["pms_model_reference"]["meta_axioms"]

print(f"PMS schema version: {schema_version}")
print("Meta-Axioms (Δ–Ψ) in current repository reference order:")
print()

for ax in axioms:
    depends = ax.get("depends_on", [])
    status = ax.get("status_within_pms", "n/a")
    print(f"{ax['order']:>2}. {ax['id']} — {ax['name']}")
    print(f"    depends_on: {depends}")
    print(f"    status: {status}")
    print(f"    definition: {ax['definition']}")
    print()

print("Ordering note:")
print(ordering_status)