"""
PMS Example Script 02 – Validate an Operator Chain
File: 02_validate_operator_chain.py

Description:
    Loads the PMS model and uses the dependency table to validate whether
    a given operator chain is structurally admissible under the current PMS
    repository reference path.

    This demonstrates how PMS can be used to formally check operator
    compositions against the currently encoded dependency graph.

Model:
    - PMS schema_version: PMS_1.3
    - Repository reference model file: ../model/PMS.yaml

PMS structures used:
    - pms_model_reference.dependency_table
    - pms_model_reference.ordering_status

Usage:
    python 02_validate_operator_chain.py

Dependencies:
    - PyYAML (yaml)

Notes:
    - PMS works on structural operators, not mental states.
    - Validity here is purely formal (dependency-based), not ethical, empirical,
      or exhaustive.
    - This script must NOT be used to evaluate persons, only operator chains.
    - A valid chain under the current PMS repository reference is valid
      relative to the presently encoded dependency path, not proof that no
      alternative formalization exists.
"""

import yaml

with open("../model/PMS.yaml", "r", encoding="utf-8") as f:
    pms = yaml.safe_load(f)

dependency_table = {
    ax["axiom"]: set(ax["depends_on"])
    for ax in pms["pms_model_reference"]["dependency_table"]
}

ordering_note = pms["pms_model_reference"]["ordering_status"]["interpretation"]

def validate_chain(chain):
    """
    Check whether each operator is admissible given the operators
    that already appeared earlier in the chain.
    """
    seen = set()

    for op in chain:
        if op not in dependency_table:
            return False, f"Unknown operator: {op}"

        required = dependency_table[op]
        if not required.issubset(seen):
            missing = sorted(required - seen)
            return False, (
                f"Operator {op} requires {sorted(required)}, "
                f"but only {sorted(seen)} are available. Missing: {missing}"
            )

        seen.add(op)

    return True, "Valid chain under current PMS repository reference."

# Example chain:
# Awareness formula in derivational reading is ["Θ", "□", "Δ"].
# For dependency validation we check construction order from prerequisite to later operator.
chain = ["Δ", "∇", "□", "Λ", "Α", "Ω", "Θ"]

ok, msg = validate_chain(chain)

print("Chain:", chain)
print("Valid?", ok)
print("Message:", msg)
print()
print("Ordering note:")
print(ordering_note)