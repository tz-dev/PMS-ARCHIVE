# Praxeological Meta-Structure Theory (PMS)

## Purpose

**PMS — Praxeological Meta-Structure Theory** is the core theory repository for a formal praxeological grammar of action, non-action, asymmetry, temporality, responsibility, conflict, dignity, integration, and self-binding.

It makes praxis structurally legible without reducing it to psychology, morality, metaphysics, physics, diagnosis, person-ranking, or governance.

PMS Base defines the operator grammar:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

This repository is also the central router for the wider PMS ecosystem. It provides the base theory, model files, examples, and orientation documents from which the paper-form lenses, corpus-form repositories, implementation workspace, workflow tooling, application discipline, self-critique, and STRATA transformation discipline are positioned.

---

## First Orientation

Start here:

| Document | Function |
| --- | --- |
| [PMS — Short Introduction](doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Repository-form map, layer boundaries, claim types, and ecosystem navigation. |
| `Praxeological Meta-Structure Theory` | Full core theory text. |
| `model/PMS.yaml` | Repository-reference specification of PMS Base. |

Recommended path:

```text
Short Introduction
→ Overview of the PMS Ecosystem
→ PMS Base theory
→ model/PMS.yaml
→ relevant lens / corpus / tooling repository
```

---

## Ecosystem Position

PMS Base is the operator grammar. It is not one add-on among others and not a meta-authority over every possible use.

| Ecosystem area | Repositories | Function |
| --- | --- | --- |
| Core theory | PMS | Δ–Ψ operator grammar, derived axes, model reference, orientation. |
| Paper-form lenses | ANTICIPATION, CONFLICT, CRITIQUE, EDEN, LOGIC, SEX, QC | Bounded domain or bridge pressures applied to PMS. |
| Corpus-form repositories | MIP, PMS-AXIOM, PMS-STACK, PMS-EM | Canonical blocks, reference layers, cases, models, minified controls, readers, and inspection pressure. |
| Transformation-discipline corpus | PMS-STRATA | Granularity, composition, decomposition, projection, Loss, Stop, Non-Capture, and transformation audit. |
| Runtime / tooling projects | PMS-RUST, PMS-ORCHESTRATOR | Executable evidence spine and local workflow staging. |
| Application discipline / self-critique | PMS-DISCIPLINE, PMS — UNDER LOAD | Use-boundary, stop/handoff discipline, calibration, drift, publicness, and self-application critique. |

PMS does not become stronger merely because the ecosystem is larger.

```text
more layers ≠ more warrant
more artifacts ≠ more validation
more readability ≠ more truth
```

---

## Repository Form

This is the **core theory repository**.

| Material | Function |
| --- | --- |
| Main PMS theory text | Defines the operator grammar and structural reading method. |
| `model/PMS.yaml` and related model files | Machine-readable reference layer for PMS Base. |
| `examples/` | Bounded examples and test-style applications. |
| `doc/` | Orientation documents, including the short introduction and ecosystem overview. |
| README | Start point and routing layer, not a replacement for the theory. |

The README should make the repository navigable. It should not replace the PMS theory text or the model files.

---

## Core Grammar

The PMS sequence can be read compactly as:

| Operator | Short role |
| :-: | --- |
| Δ | Differentiation / initial distinction. |
| ∇ | Relevance or gradient pressure. |
| □ | Framing condition. |
| Λ | Latency / omission / unexpressed structural load. |
| Α | Attractor / focus formation. |
| Ω | Asymmetry / relation of unequal cost, burden, access, or force. |
| Θ | Temporality / sequence / timing pressure. |
| Φ | Recontextualization / transition under changed frame. |
| Χ | Distance, resistance, separation, or correction-bearing interval. |
| Σ | Integration / stabilization of a configuration. |
| Ψ | Self-binding / expectation / normative or practical closure pressure. |

PMS does not claim that every phenomenon must be reduced to this sequence. It claims that many praxis configurations become more inspectable when their operators, absences, transitions, and stabilizations are made explicit.

---

## PMS-Internal Use of Key Terms

Several terms in PMS are also used in neighboring projects or ordinary language. In this README they should first be read **PMS-internally**, through the Δ–Ψ grammar, not as imports from MIP, ethics, psychology, law, theology, or governance.

| Term | PMS-internal reading | Boundary |
| --- | --- | --- |
| Responsibility | Consequence-readability under frame, asymmetry, temporality, distance, integration, and self-binding pressure. | Not guilt, obligation, diagnosis, or moral verdict. |
| Dignity | A limit on how praxis may be rendered without reducing persons to rank, function, pathology, or exposure-object. | Not dignity measurement, worth allocation, or person evaluation. |
| Conflict | Stabilized incompatibility under cost, asymmetry, temporality, integration pressure, and binding. | Not mere disagreement, immaturity, pathology, or mediation mandate. |
| Integration | Stabilization of a configuration or relation of elements under a frame. | Not harmony, reconciliation, consensus, or truth. |
| Self-binding | Practical or normative closure-pressure through which a configuration binds itself into continuity. | Not legal duty, moral law, or final justification. |
| Asymmetry | Unequal distribution of cost, burden, access, exposure, power, or room for action. | Not hierarchy of human worth. |
| Dignity-in-practice language | Application-sensitive boundary language where PMS analysis risks becoming person-near. | Not an invitation to rank maturity or dignity. |

This matters because PMS can speak about responsibility, dignity, conflict, and self-binding without becoming MIP, moral philosophy, legal analysis, clinical diagnosis, or person assessment.

Compact rule:

```text
PMS terms are derived first from Δ–Ψ relations.
Neighboring models may dock later.
They do not supply PMS Base meanings.
```

---

## Project Trajectory

The PMS ecosystem developed through recurring pressure points rather than through a single closed design act:

| Developmental pressure | Later ecosystem form |
| --- | --- |
| concrete discourse and interpersonal cases | operator sensitivity to frames, asymmetry, distance, and self-binding |
| recurring structural distinctions | PMS Base and its Δ–Ψ grammar |
| dignity differentiation | relation to MIP and dignity-in-practice boundaries |
| non-events and restraint | ANTICIPATION and later STRATA granularity discipline |
| de-anthropologization pressure | formal PMS language, models, schemas, and computational analogies |
| domain stress | paper-form lenses and bridge papers |
| corpus formation | MIP, AXIOM, STACK, EM, STRATA |
| implementation pressure | PMS-STACK and PMS-RUST |
| application pressure | PMS-DISCIPLINE and PMS-ORCHESTRATOR |
| self-critique | PMS — UNDER LOAD |

This trajectory is historically relevant, but it is not proof. It shows how the ecosystem became progressively typed, bounded, and self-critical.

---

## Relation to Maturity in Practice

**Maturity in Practice (MIP)** is an adjacent praxeological anthropology model in the wider ecosystem. It is not the source of PMS Base meanings and does not validate PMS.

MIP works with its own A–C–R–P–D axis: Awareness, Coherence, Responsibility, Power / practical room for action, and Dignity in Practice. PMS works with the Δ–Ψ operator grammar.

The relation is therefore docking, not derivation.

```text
PMS Δ–Ψ ≠ MIP A–C–R–P–D
PMS responsibility ≠ MIP Responsibility axis
PMS dignity boundary ≠ MIP D axis
MIP docking ≠ PMS validation
MIP analysis ≠ person ranking
adjacent model ≠ foundation
```

MIP becomes relevant where a PMS-derived output approaches application, dignity-in-practice, person-nearness, publicness, maturity-language, or use-boundary questions. It may constrain applied use. It does not define PMS Base.

---

## Implementation and Tooling Relations

PMS has implementation-facing and workflow-facing projects, but these do not convert PMS into an externally proven system.

| Project | What it contributes | What it does not do |
| --- | --- | --- |
| PMS-STACK | Architecture specification for PMS as OS/CPU/language/runtime/security/distributed systems. | Validate PMS Base. |
| PMS-RUST | Bounded executable evidence spine: kernel, REPL, validation, JSONL traces, vFS, AI proposal gate. | Prove PMS true or complete PMS-STACK. |
| PMS-ORCHESTRATOR | Local runner for PMS-DISCIPLINE case workflows. | Decide meaning or replace human review. |
| PMS-STRATA | Transformation discipline for granularity, composition, decomposition, and projection. | Provide meta-PMS, ontology, proof, or immunity. |

---

## What PMS Is Not

PMS is not:

```text
psychological diagnosis
moral tribunal
legal finding
metaphysics
physics
ontology of persons
governance machinery
universal explanation
proof system
application authority
```

The core reductions remain:

```text
readability ≠ truth
coherence ≠ validation
operator fit ≠ evidence
portability ≠ equivalence
self-application ≠ final self-arbitration
implementation ≠ proof
corpus form ≠ validation
STRATA control ≠ authority
```

---

## Reading Path by Use

| Use | Recommended path |
| --- | --- |
| First orientation | `doc/PMS - Short Introduction.md` → ecosystem overview → README links. |
| Core theory reading | Main PMS theory text → `model/PMS.yaml` → selected examples. |
| Domain stress | PMS Base → one paper-form lens → UNDER LOAD boundary notes. |
| Corpus navigation | Ecosystem overview → selected corpus README → reader / case index / blocks. |
| Implementation interest | PMS-STACK → PMS-RUST → PMS-RUST acceptance gates. |
| Application interest | PMS-DISCIPLINE → PMS-ORCHESTRATOR only if a staged case workflow is needed. |
| Granularity / transformation interest | PMS-STRATA → operation records → audit and output classes. |

---

## Status

This repository functions as PMS Base and ecosystem router. It should remain conceptually stable, while documentation, links, release notes, Zenodo metadata, and neighboring repository references may be updated as the ecosystem is synchronized.

---

## Links and Resources

### Archive / DOI

| Resource | Description |
| --- | --- |
| PMS Theory DOI | [![DOI](https://zenodo.org/badge/1111604814.svg)](https://doi.org/10.5281/zenodo.17897220) |

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.

---

## Citation

When citing PMS, cite the repository release and DOI that correspond to the version used. Do not cite later ecosystem repositories as if they retroactively validate the PMS Base claim.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
