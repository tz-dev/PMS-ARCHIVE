# Overview of the PMS Ecosystem

> Ecosystem-level orientation document. It summarizes repository roles and claim boundaries; it does not replace PMS.yaml or any repository’s canonical corpus.

## Praxeological Meta-Structure, Domain Lenses, Downstream Applications, Implementation Evidence, Application Discipline, Workflow Tooling, Systemic Self-Critique, Controlled Transformation, and Meta-Reconstructive Orientation

The PMS ecosystem is best understood as a **layered praxeological architecture** rather than a single theory, method, repository, add-on, or application. Its development trajectory moves from a formal operator grammar, through domain-specific lenses, into applied cartographies, computational architectures, executable prototypes, emergence-oriented specification systems, an adjacent maturity model, application-discipline tooling, workflow orchestration, systemic self-critique, a controlled transformation method for composing, decomposing, and contextually projecting PMS structures without modifying PMS Base, and a late meta-reconstructive orientation architecture that asks whether and under which declared conditions already structured differences can carry bounded direction under perspectival, rival, calibration, option-field, and consequence pressure.

The order matters because the ecosystem does not merely expand. It also becomes increasingly explicit about **claim type, layer boundary, stop capability, non-inheritance, publicness, and source discipline**. VECTOR extends that discipline to directional claims without increasing PMS Base authority.

At its core, PMS is not a worldview and not a moral theory. It is a **generative operator grammar of praxis**: a way of describing how action, difference, framing, non-events, stabilization, asymmetry, temporality, recontextualization, distance, integration, and self-binding become structurally legible.

The current ecosystem should be read through one governing distinction:

```text
More structure does not mean more authority.
```

A readable case is not proof.  
A workflow record is not semantic authority.  
A stop is not a finding.  
A handoff is not inheritance.  
An implementation artifact is not PMS Base validation.  
A mature guardrail is not tribunal authority.  
A directional relation is not a universal rank.  
A robust orientation is not authority.  
A typed option field is not automatically the real option field.  
A self-reducing architecture is not self-validating.

---

## 1. High-Level Ecosystem Map

| Layer / Repo Form | Component | Type | Core Function | Claim Status |
| --- | --- | --- | --- | --- |
| Base Theory / paper-form core | **PMS — Praxeological Meta-Structure Theory** | Generative operator grammar | Defines Δ–Ψ as a formal praxeological grammar | Base claim |
| Paper-form domain lens | **PMS–ANTICIPATION** | Application overlay | Future-oriented praxis under uncertainty, Λ, Θ, and Χ | Domain / overlay claim |
| Paper-form domain lens | **PMS–CONFLICT** | Domain profile | Stabilized non-integrability of practice trajectories | Domain / overlay claim |
| Paper-form domain lens | **PMS–CRITIQUE** | Domain profile | Critique as interruption, recontextualization, and correction | Domain / overlay claim |
| Paper-form domain lens | **PMS–EDEN** | Adult Reciprocity / Reciprocity Loss lens | Truthful vs false coordination of real Ω; responsibility displacement; blocked Σ/Ψ | Domain / overlay claim |
| Paper-form boundary lens | **PMS–LOGIC** | Boundary overlay | Logic, responsibility, non-closure, post-moral effects | Boundary / overlay claim |
| Paper-form high-asymmetry lens | **PMS–SEX** | High-asymmetry domain profile | Sexual configurations under cost topology, outer legibility, direct otherness, body/boundary coding, withdrawal, after-scene dignity, and viability / drift | Domain / overlay claim |
| Paper-form technical bridge | **PMS–QC** | Structural bridge layer | Quantum-computational structures rendered through Δ–Ψ macros | Bridge claim |
| Corpus-form case repository | **PMS–AXIOM** | Case cartography / schema inspection | Classical closure-demands as YAML / Markdown case artifacts with schema, index, prompts, templates, overlays, and reader navigation | Case-cartography / schema-inspection claim |
| Corpus-form architecture repository | **PMS–STACK** | Architecture specification corpus | PMS as OS, CPU, language, runtime, security, networking, distributed-systems architecture, with canonical blocks, reference, minified, derivative, and reader layers | Architecture-specification claim |
| Implementation workspace / executable evidence spine | **PMS–RUST** | Rust runtime / toolchain workspace | Deterministic Δ–Ψ kernel, model validation, REPL / script runner, JSONL audit, vFS surface, AI proposal gate, demos, tests, gates | Implementation / artifact claim |
| Corpus-form emergence repository | **PMS–EM** | Developmental-architecture corpus | Trace-backed emergence specification with owner blocks, appendices, reference / audit files, minified canonical material, derivative publications, and reader navigation | Emergence / developmental-architecture claim |
| Corpus-form adjacent ecosystem model | **MIP — Maturity in Practice** | Praxeological anthropology corpus | A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, appendices, model layer, examples, specifications, and reader navigation | Independent ecosystem / adjacent governance claim |
| Application-discipline layer | **PMS-DISCIPLINE** | Use-boundary / path-selection / stop-capability layer | Pre-Entry responsibility, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHPP routing, Case Records, Iteration Handoff, article boundary | Application-discipline claim |
| Workflow-runner / case-production tool | **PMS-ORCHESTRATOR** | Local human-guided runner | Stages PMS-DISCIPLINE case work, preserves route state and raw outputs, validates YAML structurally, supports handoff / article routes, enforces confirmed stop | Workflow-tooling claim |
| Closure / self-critique paper | **PMS Under Load** | Structural self-critique | Tests PMS success conditions: calibration, coverage, stack drift, Φ drift, meta-normativity, domain transfer, publicness, self-application, stop, handoff, workflow | Stack-closure / self-limitation claim |
| Corpus-form transformation method | **PMS-STRATA** | Controlled transformation-method corpus | Specifies COMPOSE, DECOMPOSE, and PROJECT_AS across frames, granularities, relative levels, composites, and contextual functions under admissibility, loss, stop, and non-capture constraints | Transformation-method / bounded functional claim |
| Late meta-reconstructive orientation / paper-led structured repository | **PMS–VECTOR** | Bounded orientation / perspectival pressure architecture | Reconstructs bounded DIR, tests it through admissible ROT, types option-field error and effective Second-Order Agency, connects orientation to consequence, timing, and bounded attribution, and remains reducible under rival superiority, redundancy, suspension, and non-capture | Late meta-reconstructive praxeological orientation claim; provisionally retained, scope-reduced |

The key point is that not every component is an “add-on,” and not every repository has the same form.

The updated repo-form distinction is:

```text
paper-form lenses
≠
corpus-form repositories
≠
implementation workspace
≠
workflow runner
≠
application-discipline layer
≠
closure paper
≠
controlled transformation-method corpus
≠
paper-led meta-reconstructive orientation repository
```

Paper-form lenses primarily publish one bounded PMS lens or bridge with supporting examples, YAML model material, and model specifications.

Corpus-form repositories organize canonical blocks, supporting source or reference layers, minified or contract layers, model / case / example layers, derivative publications, and reader navigation. They increase inspection pressure. They do not increase validation authority.

PMS-RUST is not corpus-form in this sense. It is an executable implementation workspace / evidence spine.

PMS-ORCHESTRATOR is not corpus-form either. It is workflow tooling for PMS-DISCIPLINE case production.

The shared reader pattern across MIP, PMS-STACK, PMS-AXIOM, PMS–EM, PMS-STRATA, and PMS–VECTOR is therefore not layer equivalence. It is a repeated inspection affordance under different claim types.

---

## 2. The Developmental Trajectory of the Ecosystem

The ecosystem unfolds in a recognizable trajectory:

1. **Base formalization**  
   PMS defines a compact operator grammar of praxis.

2. **Paper-form domain and bridge stress**  
   ANTICIPATION, CRITIQUE, CONFLICT, LOGIC, SEX, EDEN, and QC test whether the base grammar can remain stable across future-orientation, critique, conflict, logical limits, sexuality, reciprocity loss, and quantum-computational structure.

3. **EDEN revision into Adult Reciprocity / Reciprocity Loss**  
   EDEN is no longer best summarized as Eden-origin drift or comparison-first analysis. Its current center is Adult Reciprocity as truthful coordination of real Ω, Reciprocity Loss as false coordination of real Ω, and false-coordinated real asymmetry as the central mechanism.

4. **SEX revision into high-asymmetry cost-topology / viability-drift analysis**  
   SEX is no longer adequately summarized as sexuality as framed impulse only. Its current center includes cost topology, outer legibility, direct otherness, body/boundary coding, withdrawal and covert Ψ-expectation, after-scene dignity, viability corridors, and strict refusal of person-typing, adultness verdicts, sex truth, or instructional content.

5. **Corpus-form case cartography**  
   PMS–AXIOM applies the stack to classical closure-demand problems and compiles cases into YAML / Markdown artifacts, case schemas, case indexes, prompts, templates, overlays, and reader-inspectable structures.

6. **Corpus-form architecture specification**  
   PMS–STACK translates PMS into an operating-system / CPU / language / runtime / security / distributed-systems architecture and presents that architecture in canonical blocks, reference material, minified contracts, derivative publications, and reader-navigation layers.

7. **Implementation workspace / executable evidence spine**  
   PMS–RUST implements a bounded runtime / toolchain spine: not a corpus-form repository, not a full PMS-OS, and not a completed PMS-STACK implementation, but a concrete executable workspace with crates, model validation, REPL / script runner, JSONL traces, vFS surface, demos, tests, and gates.

8. **Corpus-form emergence specification**  
   PMS–EM uses PMS, MIP, trace logic, diary discipline, implementation-facing auditability, owner blocks, appendices, reference / audit files, minified canonical material, derivative publications, and reader navigation to formulate developmental emergence without overclaiming consciousness or personhood.

9. **Corpus-form adjacent anthropological model**  
   MIP is not dependent on PMS, but belongs to the same broader praxeological ecosystem. It supplies its own A–C–R–P–D model of maturity in practice, with canonical blocks, appendices, reference material, YAML model layer, examples, specifications, and reader navigation.

10. **Application discipline**  
    PMS-DISCIPLINE makes responsible PMS use explicit: whether PMS should enter a case, how Pre-Analysis gates Core entry, when Core-only is sufficient, when add-ons may be used or rejected, when MIP/AHPP may dock, when outputs must be downgraded / suspended / refused / redirected, when stop is binding, and what a future case may not inherit.

11. **Workflow tooling**  
    PMS-ORCHESTRATOR operationalizes discipline-subjected case work in a local human-guided runner. It stages prompts, preserves route state, stores raw outputs, checks YAML structurally, supports review gates, handoff review, article routing, and confirmed stop enforcement. It is workflow tooling, not semantic authority.

12. **Internal closure and self-critique**  
    PMS Under Load tests the entire structure against its own success: portability, coherence, corpus form, implementation, governance, publicness, workflow support, stop-readiness, iteration-readiness, and self-application.

13. **Controlled transformation method**  
    PMS-STRATA specifies how PMS structures may be composed, decomposed, and projected into bounded contextual functions across frames, granularities, relative levels, composites, and contexts. It extends the method, not PMS Base, and treats every transformation as a new testable claim.

14. **Late meta-reconstructive orientation**  
    PMS–VECTOR appears only after substantial local PMS structures, transformation controls, application discipline, and systemic self-critique already exist. That lateness helps reduce retroactive imposition because direction is not installed as a privileged meta-answer before the structures under examination have become independently legible. It does not create epistemic independence. VECTOR asks a narrower later question: when may bounded structural difference warrant direction under declared frame, question, perspective, time, option-field, consequence, calibration, rival, and self-reduction pressure? Its own architecture remains reducible.

This trajectory matters because the ecosystem does not simply become larger. It develops increasingly strict **claim discipline**:

```text
theory
→ paper-form domain / bridge stress
→ corpus-form case and architecture repositories
→ executable implementation workspace
→ corpus-form emergence and maturity repositories
→ application discipline
→ workflow tooling
→ self-limiting critique
→ controlled transformation method
→ late meta-reconstructive orientation under rival, calibration, option-field, consequence, and self-reduction pressure
```

The structural correction is important:

```text
Corpus form increases inspectability.
Implementation workspace increases executable artifact pressure.
Workflow tooling increases provenance and stop-enforcement pressure.

None of these increases PMS Base warrant by itself.

Late position ≠ higher authority.
Meta-reconstructive scope ≠ meta-authority.
```

---

## 3. PMS Base: Praxeological Meta-Structure Theory

## 3.1 Core Function

PMS is the theoretical core of the ecosystem. It defines a **generative operator grammar of praxis** built from eleven operators:

| Operator | Name | Core Function |
| :-: | --- | --- |
| Δ | Difference | Minimal distinction, boundary, difference |
| ∇ | Impulse | Directional tension or activation |
| □ | Frame | Contextual boundary, containment, scope |
| Λ | Non-Event | Structured absence, delay, failure, unrealized possibility |
| Α | Attractor | Recurrent stabilization, pattern formation |
| Ω | Asymmetry | Gradient of power, exposure, capacity, obligation |
| Θ | Temporality | Sequence, trajectory, irreversibility, path-dependence |
| Φ | Recontextualization | Embedding old structures in new contexts |
| Χ | Distance | Reflective separation, suspension, attenuation |
| Σ | Integration | Synthesis into coherent structure |
| Ψ | Self-Binding | Commitment, constraint, self-relation across time |

The canonical operator sequence is:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

PMS does not claim to be psychology, metaphysics, morality, physics, or a total theory of everything. Its primary claim is narrower: it provides a **substrate-independent grammar for rendering praxis structurally legible**.

## 3.2 Derived Axes

PMS also defines derived projections:

| Axis | Formula | Meaning |
| --- | --- | --- |
| Awareness | `A = Θ ∘ □ ∘ Δ` | Difference held in a frame across time |
| Coherence | `C = Θ ∘ Λ ∘ □ ∘ ∇` | Impulse, framing, absence, and temporality stabilized into coherence |
| Responsibility | `R = Ψ ∘ Φ ∘ Θ ∘ Ω` | Asymmetry carried through time, recontextualization, and self-binding |
| Enactment | `E = Σ ∘ Θ ∘ ∇` | Action integrated across temporal impulse |
| Dignity-in-Practice | `D = Ψ ∘ Χ ∘ Ω` | Asymmetry held through distance and self-binding |

These are not separate axioms. They are projections of the base operator grammar.

## 3.3 Guardrails

PMS is governed by strict application guardrails:

| Guardrail | Function |
| --- | --- |
| Χ / Distance | Prevents fusion, over-identification, coercive closure |
| Reversibility | Keeps interpretations revisable where possible |
| Dignity-in-Practice | Blocks humiliation, ranking, person-fixation |
| No diagnosis | PMS does not infer clinical or psychological states |
| No person-ranking | Structures are analyzed, not persons ranked |
| No moral automation | PMS does not generate verdicts, punishment, or moral authority |
| Non-capture | Rival models and genuine non-capture remain possible |
| Stop-capability | Analysis can be prevented from continuing where use would overclaim |
| Non-inheritance | Future cases do not inherit findings, routes, claim ceilings, or sufficiency from prior cases |

This is crucial: PMS is productive, but it is not self-authorizing.

VECTOR does not retroactively alter this Base grammar. PMS Base remains Δ–Ψ. Later directional or perspectival machinery must not be read backward as though the Base already contained it as an operator layer.

```text
DIR ≠ ∇
ROT ≠ Φ
DIST ≠ Χ
```

Distributed directional pressure in earlier PMS may motivate a later VECTOR question, but recurrence or preference is only a **VECTOR candidate** until separately burdened under declared frame, question, perspective, time, evidence, and rival conditions.

```text
semantic lineage ≠ prior possession
later explicit distinction ≠ earlier operator
```

---

## 4. PMS–ANTICIPATION

## 4.1 Role in the Trajectory

PMS–ANTICIPATION is one of the first domain overlays. It tests whether PMS can describe **future-oriented praxis** without collapsing into prediction, control, strategy, or certainty.

Its central idea is that anticipation is not “knowing the future.” It is the structurally disciplined handling of possible events and non-events under **temporality, asymmetry, irreversibility, and distance**.

## 4.2 Core Formulae

| Structure | Formula | Meaning |
| --- | --- | --- |
| Minimal anticipation | `ANT_min = Δ → □ → Λ → Θ → Χ` | Difference framed as a possible non-event carried through time under distance |
| Full viable anticipation | `Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ` | Anticipation becomes viable only when integrated and self-bound without coercive closure |

## 4.3 Key Distinctions

| Anticipation | Prognosis |
| --- | --- |
| Present structural stance | Future-oriented truth claim |
| Carries Λ as open | Tries to resolve uncertainty |
| Binds the anticipator | Often directs action toward others |
| Requires Χ | Often compresses distance |
| No authority claim | Often risks authority inflation |

## 4.4 Central Risk

The most dangerous error is using anticipation to legitimize intervention rather than binding oneself to restraint.

In the ecosystem trajectory, ANTICIPATION appears early because it establishes a major PMS theme:

> Openness must be structurally carried, not prematurely closed.

---

## 5. PMS–CONFLICT

## 5.1 Role in the Trajectory

PMS–CONFLICT develops the other end of the spectrum: not open possibility before closure, but stabilized incompatibility after integration has become difficult or impossible.

Conflict is not treated as anger, escalation, misunderstanding, communication breakdown, or moral failure. It is defined as:

> Stabilized incompatibility of practice trajectories under binding, asymmetry, and time.

## 5.2 Core Structures

| Element | Formula / Marker | Meaning |
| --- | --- | --- |
| Trajectory | `T := Θ ∘ Ω ∘ Α ∘ Λ ∘ □ ∘ ∇ ∘ Δ` | A temporally stabilized praxis path |
| Conflict core | `Σ₁ ≠ Σ₂` | Local integrations diverge |
| Binding | `Ψ_partial` | Reversal is no longer cost-neutral |
| Cost topology | `Ω_gradient under Θ` | Costs are asymmetrically distributed over time |
| Distance condition | `Χ available but costly/asymmetric` | Distance remains necessary but no longer cheap |

## 5.3 Minimal Conflict Object

```text
K := (T₁, T₂, F_shared?, B, G, Χ_cost)
```

Where:

| Component | Meaning |
| --- | --- |
| `T₁, T₂` | Divergent trajectories |
| `F_shared?` | Shared or divergent frame |
| `B` | Binding level |
| `G` | Cost-gradient topology |
| `Χ_cost` | Cost and asymmetry of distance |

## 5.4 Stack Function

CONFLICT is downstream of CRITIQUE. Critique asks whether mismatch can still become interruption, recontextualization, and correction. Conflict begins when integration outcomes diverge and correction no longer remains structurally cheap.

CONFLICT therefore introduces one of PMS’s major tragic insights:

> Mature structures do not guarantee integrability.

---

## 6. PMS–CRITIQUE

## 6.1 Role in the Trajectory

PMS–CRITIQUE occupies a hinge position between ANTICIPATION and CONFLICT. It asks when a mismatch can become critique rather than reaction, judgment, ridicule, avoidance, or escalation.

Critique is not primarily truth, morality, opposition, or attitude. It is a structured operation:

> A Χ-stabilized interruption in response to framed difference, potentially becoming correction through Φ and Σ.

## 6.2 Core Formulae

| Structure | Formula | Meaning |
| --- | --- | --- |
| Critique pressure | `Δ → ∇ → □ → Λ` | Difference creates framed non-event pressure |
| Minimal critique | `CRITIQUE_min := Χ ∘ (□ ∘ Δ)` | Critique begins where framed difference becomes interruptible |
| Productive critique | `CRITIQUE_prod := Σ ∘ Χ ∘ Φ ∘ (Θ, Ω, □, Δ)` | Critique becomes productive when recontextualized and integrated |

## 6.3 Thresholds

| Threshold | Function |
| --- | --- |
| Before Χ | Reaction, attack, outrage, avoidance, mockery |
| Χ | Critique becomes possible |
| Φ | Recontextualization makes critique bearable/actionable |
| Σ | Correction becomes integrated |
| Ψ | Follow-up responsibility becomes stable |

## 6.4 Drift Forms

| Drift | Description |
| --- | --- |
| Reaction masquerading as critique | Impulse without distance |
| Judgment masquerading as critique | Framed differentiation without integration |
| Narrative repair | Recontextualization without correction |
| Commentary paralysis | Distance without integration |
| Public pillory | Exposure amplification with collapsed restraint |
| Silence attractor | Non-event stabilization |

CRITIQUE is essential because it defines the zone where mismatch is still workable before becoming conflict.

---

## 7. PMS–EDEN

## 7.1 Updated Role in the Trajectory

PMS–EDEN is now best understood as a domain lens for **Adult Reciprocity and Reciprocity Loss under real asymmetry**.

It is not theology-first, Eden-origin-first, comparison-first, pseudo-symmetry-first, sex-truth-first, or PFO-first. It reconstructs Eden as a late test scene for a grammar whose center is already built: how real Ω can be truthfully coordinated or falsely coordinated inside bounded praxis scenes.

PMS–EDEN therefore no longer sits primarily as a drift-origin allegory. It is a structural grammar of:

```text
Adult Reciprocity
Reciprocity Loss
false-coordinated real Ω
responsibility displacement
blocked Σ/Ψ
recognition drift
protection / exposure imbalance
counter-scene testing
scene-bound mapping without verdict
```

## 7.2 Central Thesis

The core orientation is:

```text
Adult Reciprocity ≠ symmetry.
Adult Reciprocity = truthful coordination of real Ω.
Reciprocity Loss = false coordination of real Ω.
```

The central mechanism is:

```text
real Ω + false coordination frame + displaced R + blocked Σ/Ψ
= false-coordinated real Ω
```

The main structural trace is:

```text
coordinated Ω
→ false-coordinated real Ω
→ displaced R
→ blocked Σ/Ψ
→ reciprocity loss
```

The asymmetry is not necessarily false. The coordination is false.

## 7.3 Key Structures

| Structure | Meaning |
| --- | --- |
| Adult Reciprocity | Real Ω remains visible; D is preserved; R follows real structuring effect; Σ integrates costs and effects; Ψ binds relevant actors to their own effect; Χ keeps revision possible |
| Reciprocity Loss | False coordination of real Ω; responsibility, cost, integration, and self-binding no longer follow the scene’s real structure |
| False-Coordinated Real Asymmetry | A real asymmetry is organized through a frame that displaces responsibility and blocks Σ/Ψ |
| Responsibility Principle | R follows real structuring effect under legibility, capacity, alternative possibility, Θ trajectory, and Ω cost/exposure conditions |
| No Passive Praxis | Non-action becomes praxis only where it structures a scene under □/Λ/Ω/Θ |
| Ψ-load shift | Low self-binding in one role-position increases binding load elsewhere |
| False Comparison | Attractor / amplifier / stabilizer, not first cause |
| Pseudo-Symmetry | One Switch Family form: formal parity while real Ω remains unintegrated |
| AEP | Asymmetric explanatory poverty: high exposure, low legitimate language, critique-to-threat switch, responsibility overload |
| PFO | One downstream regime form, not the origin or center of EDEN |
| EDEN-MAP | Scene-bound mapping protocol, not verdict machine |

## 7.4 Boundary

PMS–EDEN is a PMS-conform application profile. It introduces no new PMS operators and does not redefine the canonical PMS dependency structure.

Its strict firewall is:

```text
description may name structure;
application requires Χ, reversibility, D, contextual responsibility,
and independent application authority;
description does not authorize binding.
```

PMS–EDEN must not become:

```text
theology
sex truth
gender verdict
person diagnosis
maturity ranking
dignity hierarchy
relationship manual
repair protocol
coercive authorization
application authority
verdict machine
```

EDEN’s updated strength is not that it can absorb everything into EDEN terms. Its strength is that it must remain scene-bound, counter-scene exposed, dignity-preserving, and open to non-capture.

---

## 8. PMS–LOGIC

## 8.1 Role in the Trajectory

PMS–LOGIC is a boundary and limit layer. It clarifies the relation between logic, responsibility, moral readability, and the impossibility of deriving an “ought” from being.

Its central formula is:

```text
pre-moral in justification
logical in boundary management
post-moral in effect
```

## 8.2 Central Thesis

PMS–LOGIC does not derive obligations. It does not smuggle ethics into structure.

Instead, it argues:

> No ought follows from being; but under Ω, Θ, Λ, and Ψ, consequences can become attributable and therefore morally readable.

## 8.3 Key Concepts

| Concept | Meaning |
| --- | --- |
| Λ / Non-Closure | Final explanation remains structurally unavailable |
| Effective capacity | Frame-bound capacity plus temporal availability |
| Non-Innocence | Non-action loses neutrality under effective capacity, without becoming duty |
| Responsibility | Attributability of consequences, not command |
| Moral readability | Interpretive field, not PMS operator |
| Logic | Boundary management, not final authority |

## 8.4 Failure Modes

| Failure Mode | Structure |
| --- | --- |
| Dogmatism | Σ becomes totalization |
| Authority capture | Logic becomes tribunal |
| Moralism | Ψ becomes external pressure |
| Nihilism | Λ is suppressed as irrelevant |
| Technocratic reduction | Boundary management is mistaken for final resolution |

LOGIC is important because it keeps PMS from becoming a hidden ethics machine.

### Relationship to PMS–VECTOR

PMS–LOGIC already provides a **baseline structural attributability** relation under effective, frame-bound capacity and consequence relations across asymmetry and time. VECTOR does not replace that baseline and does not add an awareness requirement to it.

VECTOR makes a narrower later claim: orientation itself may change attributability only where additional bridge conditions carry, including where material:

```text
external premise support
actor accessibility / uptake
sufficient understanding for contest or response
praxis availability in the relevant window
effective capacity
consequence relation
role / time conditions
```

The boundary is strict:

```text
BaselineAttributability_LOGIC
≠
ΔAttributability_orientation
```

and neither relation is automatically moralized:

```text
structural attributability
≠ guilt
≠ blame
≠ liability
≠ legitimacy
≠ moral obligation
```

This prevents VECTOR Part V from becoming a replacement LOGIC layer.

---

## 9. PMS–SEX

## 9.1 Updated Role in the Trajectory

PMS–SEX brings the PMS grammar into a high-asymmetry, high-binding, high-legibility-risk domain. It models sexual practice as a praxis field rather than identity essence, moral category, therapeutic object, orientation taxonomy, biological destiny, genital truth, adultness verdict, or instructional system.

Its updated role is more precise than the earlier “framed impulse” summary. PMS–SEX now centers:

```text
sexual cost topology
cost-layout mismatch
outer legibility
direct otherness
body / boundary coding
withdrawal and covert Ψ-expectation
after-scene dignity
viability corridors
drift chains
publicness
Dignity-in-Practice stress
operator-profile-only MIP docking
```

It remains non-clinical, structural, and guardrailed.

## 9.2 Central Thesis

Sexual practice becomes structurally readable because it occurs under bodies, frames, non-events, repetition, asymmetry, exposure, time, distance, integration pressure, and self-binding.

The compact formulation is:

```text
Sexuality does not “cost” because it is immoral.
It costs because it happens under bodies, frames, asymmetry, repetition, and time.
```

PMS–SEX evaluates configurations, not persons.

## 9.3 Core Structures

| Structure | Formula / Marker | Meaning |
| --- | --- | --- |
| Minimal spine | `Δ → ∇ → □` | Difference produces impulse within a frame |
| Script formation | `□ → Λ → Α` | Expectations, absences, and repetition stabilize scripts |
| Asymmetry chain | `Δ → ∇ → □ → Λ → Α → Ω → Θ` | Asymmetry becomes temporally consequential |
| Exit realism | `(□ → Λ → Α) → Ω → Θ → (Χ/Σ/Ψ)` | Exit changes trajectory but does not reset consequences |
| Cost topology | `Ω under Θ with body, exposure, exit, reputation, binding, access, and responsibility costs` | Costs distribute across roles, bodies, scenes, publicness, and time |
| Direct otherness | real encounter and correction vs. permission-image, simulated counterdesire, category substitution, or access entitlement | Prevents sexuality from being reduced to unilateral script or fantasy structure |
| Withdrawal / covert Ψ | ambivalence, post-access withdrawal, expectation, binding and non-binding ambiguity | Treats withdrawal and non-events as structurally active without automatic guilt or automatic exculpation |
| Viability corridor | configuration remains governable under Χ, Σ, Ψ, D, and stop-capability | Distinguishes viable tension from drift |

## 9.4 Key Distinctions

| Distinction | Meaning |
| --- | --- |
| Internal framing ≠ outer legibility | Inner meaning does not erase structural appearance |
| Situation > intention | Frame and consequence structure can matter more than later explanation |
| Recontextualization ≠ reversal | Φ can reinterpret but not undo trajectory |
| Suppression ≠ nullification | Drive is redirected into Λ/Α rather than eliminated |
| Publicness amplifies | Exposure documents, repeats, sediments, and redistributes cost |
| Body / boundary relevance ≠ biological destiny | Embodiment matters structurally without becoming person truth |
| Risk ≠ moral verdict | Risk is praxeological structure, not diagnosis or maturity ranking |
| Validity gate ≠ consent finding | Validity pressure may be inspected without deciding consent |
| Stop-capability ≠ person judgment | Protection boundaries are not verdicts about persons |

## 9.5 Boundary

PMS–SEX must not be used as:

```text
therapy framework
clinical model
moral doctrine
normative sex ethics
typology of people, desires, orientations, bodies, or sexualities
sex-truth model
genital-truth model
biological-destiny model
how-to manual
optimization method
sanctioning tool
humiliation tool
public accusation tool
maturity-ranking model
adultness-verdict engine
dignity hierarchy
person-measure
```

It may name hard configuration-level structures. It may not convert them into person-level harm.

---

## 10. PMS–QC

## 10.1 Role in the Trajectory

PMS–QC is different from the social and praxeological domain lenses. It tests the **substrate portability** of PMS by mapping quantum-computational structures into Δ–Ψ compositions.

It does not claim that PMS replaces quantum mechanics, circuit formalisms, Hilbert spaces, unitaries, measurement theory, ZX-calculus, tensor networks, or categorical quantum mechanics.

It is a bridge claim.

## 10.2 Macro-Language

| Macro | Expansion | Meaning |
| --- | --- | --- |
| `QFRAME(kind)` | `□` | Hilbert/register/problem/error frame |
| `QPREP(mode)` | `Α(∇(Δ(S)))` | Superposition, initialization, entanglement |
| `QORACLE_CALL(F)` | `Ω(Δ(□(S)))` | Oracle or controlled asymmetry |
| `QDIFFUSION` | `Σ(Α(S))` | Grover-style amplitude amplification |
| `QFT_ALIGN(direction)` | `Α(Φ(S))`, optional `Σ(...)` | Fourier/computational reframing |
| `QITERATE(k, B)` | `Θ^k(B(S))` | Repetition |
| `QMEASURE` | `Λ(Δ(S))` | Outcome distinction and unrealized branches |
| `QSTABILIZE(code)` | `Ψ(S)` | Stabilizer / invariant / error correction |

## 10.3 Example Algorithms

| Algorithm | PMS Reading |
| --- | --- |
| Grover | `Θ^k(Σ(Α(Ω(Δ(□(S))))))` |
| Quantum Phase Estimation | `Θ^t(Ω(□(S))) → Σ(Α(Φ(S))) → Λ(Δ(S))` |

## 10.4 Boundary

PMS–QC demonstrates bridge reach, not physical proof. It shows that PMS can annotate and structurally map QC workflows, but it does not validate PMS Base.

---

## 11. PMS–AXIOM

## 11.1 Role in the Trajectory

PMS–AXIOM is a downstream **corpus-form case-cartography repository**.

It is not another ordinary paper-form overlay. It uses PMS and the overlays as a stack for compiling classical philosophical, governance-relevant, EDEN-related, SEX-related, and bridge-relevant closure-demands into uniform structural artifacts.

Its core move is:

```text
classical problem label
→ explicit frame □
→ closure demand
→ Λ-residue
→ operator chain
→ output type
→ YAML / Markdown case artifact
→ schema / index / reader inspection
```

## 11.2 Corpus Form

PMS–AXIOM has corpus form because it is organized through:

| Repository layer | Function |
| --- | --- |
| `00_source/` | Source and rebuild documentation |
| `01_blocks/` | Rebuilt canonical block structure, including PMS Core, LOGIC, ANTICIPATION, CONFLICT, CRITIQUE, EDEN, SEX, QC, governance / non-mixing, and conclusion blocks |
| `02_cases/` | Markdown artifacts, YAML artifacts, case prompts, and templates |
| `03_model/` | Case index and case schema |
| `04_PMS-AXIOM reader/` | Local desktop reader for navigating and inspecting the PMS-AXIOM corpus |

This is a case-cartography corpus, not empirical validation.

## 11.3 Stack Levels

| Level | Composition | Output |
| --- | --- | --- |
| Level I | PMS only | Boundary / taxonomy |
| Level II | PMS + one overlay | Domain-specific structural artifact |
| Level III | PMS + overlay + MIP/AHPP | Governance- or audit-ready artifact |

## 11.4 Standard Case Artifact

| Field | Function |
| --- | --- |
| Frame | Declares the problem boundary |
| Closure demand | Identifies what the problem wants to settle |
| Λ-residue | Preserves what remains unresolved |
| Operator chain | Minimal Δ–Ψ structure |
| Add-on signatures | Domain-lens markers |
| Drift risks | Misuse and distortion risks |
| Output type | Boundary, taxonomy, policy, or audit trace |
| Governance hooks | Optional MIP/AHPP where applied |

## 11.5 Reader Boundary

The PMS-AXIOM Reader is a navigation and inspection tool for local Markdown / YAML artifacts.

It may support source, block, case, YAML, prompt, template, model, and overlay navigation.

It may not validate PMS Base, create case findings, certify QC workflows, evaluate persons, modify canonical files, or create governance authority.

The reduction is:

```text
reader navigation ≠ authority
case readability ≠ empirical proof
schema consistency ≠ truth
YAML artifact ≠ validation
```

## 11.6 Function

PMS–AXIOM does not “solve” classical problems in the old sense. It converts them into **inspectable closure-demand artifacts**. Its value is discipline rather than final answer.

Examples include personal identity, free will, moral luck, causality, induction, forecasting, trolley dilemmas, epistemic injustice, pseudo-symmetry, consent laundering, EDEN regime-taxonomy cases, SEX validity-gate cases, and QC workflow governance.

Its current corpus structure makes PMS-AXIOM more inspectable.

It does not make PMS-AXIOM more proof-bearing.

---

## 12. PMS–STACK

## 12.1 Role in the Trajectory

PMS–STACK is a published book and a **corpus-form architecture-specification repository**.

It moves PMS from theory and analysis toward computational architecture.

It asks:

> What would it mean to instantiate Δ–Ψ as a full operating system, CPU, language, runtime, protocol, security, and distributed-systems architecture?

## 12.2 Corpus Form

PMS–STACK has corpus form because it is organized through:

| Repository layer | Function |
| --- | --- |
| `00_source/` | Source / monolith / split-source material |
| `01_blocks/00–09` | Canonical modular PMS-STACK specification |
| `02_reference/` | Glossary, cross-reference, evidence map, operator index, audit checklist, and reading pathways |
| `03_minified/` | Compressed contracts and release-safe summaries |
| `04_derivative_publications/` | Compact overview, PMS-RUST relation paper, and technical whitepaper |
| `05_PMS-STACK Reader/` | Local navigation and inspection tool |

The canonical corpus is `README.md + 01_blocks/00–09`.

Supporting layers do not replace the canonical specification, redefine PMS-STACK, introduce new base operators, validate PMS Base, or establish implementation completion.

## 12.3 Major Components

| Component | Function |
| --- | --- |
| PMS-UM | Universal Machine over valid Δ–Ψ operator words |
| PMS-CPU | Virtual CPU with operator-tagged ISA |
| PMS-OS | Kernel with frames, roles, isolation, policies, scheduling |
| Memory / Storage | Virtual memory, heap, GC/RC, filesystem, journaling |
| IPC / Events | Message passing, synchronization, timers, signals, pub/sub |
| Device / Driver Model | Capabilities, interrupts, hotplug, lifecycle |
| Networking | Transport frames, routing, PMS protocol suite |
| Security & Governance | Identity, roles, capabilities, policies, audit, trust anchors |
| PMSL | Programming language with operator-typed constructs |
| PMS-IR | Operator-tagged intermediate representation |
| Tooling | Static analysis, linting, model checking |
| Distributed Systems | Boot chain, node lifecycle, cluster orchestration |

## 12.4 Computing Mapping

| PMS Operator | Computing Role |
| :-: | --- |
| Δ | Distinction, typing, branch, decode |
| ∇ | State-changing action, ALU, memory operation |
| □ | Frame, address space, context, namespace |
| Λ | Timeout, idle, missing signal |
| Α | Pattern, macro, cache, routine |
| Ω | Role, privilege, capability |
| Θ | Ordering, ticks, scheduling |
| Φ | Trap, exception, interrupt, migration |
| Χ | Isolation, sandbox, protection |
| Σ | Commit, transaction, durable update |
| Ψ | Policy, invariant, enforcement |

## 12.5 Reader Boundary

The PMS-STACK Reader is a convenience tool for local navigation and inspection.

It may support canonical file navigation, heading navigation, corpus-wide search, operator search, Χ-projection search, trace notation search, PMS-RUST reference search, AI-boundary search, file statistics, and audit-oriented inspection.

It may not replace canonical Markdown, modify the specification, validate PMS-STACK, validate PMS Base, prove implementation completion, or establish PMS-RUST completeness.

## 12.6 Boundary

PMS–STACK is an architecture-specification claim. It increases realization pressure and buildability pressure.

It does not validate PMS Base, prove PMS as a praxis theory, claim fabricated hardware, complete a production OS, complete PMSL, complete distributed runtime, certify runtime security, or turn tests / traces / validators / repository structure into proof.

---

## 13. PMS–RUST

## 13.1 Role in the Trajectory

PMS–RUST is the first clearly executable implementation artifact in the ecosystem.

It is not corpus-form in the same sense as MIP, PMS-STACK, PMS-AXIOM, or PMS–EM.

It is an **implementation workspace / executable evidence spine**.

The repository describes itself as a small, test-driven runtime / toolchain that demonstrates an executable PMS-STACK Evidence Spine v0.1. It provides a deterministic Δ–Ψ kernel, REPL / script tooling, PMS.yaml model validation, JSONL trace / audit output, a vFS service surface, reproducible demos, golden tests, and a controlled AI proposal bridge.

It is not a full PMS-OS, PMS-CPU / ISA, PMSL compiler, or distributed PMS runtime.

## 13.2 Workspace Form

PMS–RUST has workspace form because it is organized around crates, demos, tests, model data, documentation, and launcher / gate scripts:

| Workspace component | Function |
| --- | --- |
| `pms-kernel` | Deterministic PMS runtime core |
| `pms-model` | PMS.yaml dependency validation |
| `pms-ir` | Builder and opcode buffer |
| `pms-repl` | Interactive REPL and script runner |
| `pms-ai-bridge` | Controlled local AI proposal bridge |
| `pms-model-data` | Active model data, including PMS.yaml |
| `pms-demos` | Checked-in demo scripts |
| `pms-docs` | Architecture, gates, event format, demos, roadmap |
| `tests` | Script fixtures and regression checks |

This is executable artifact structure, not canonical corpus structure.

## 13.3 Pipeline

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace/audit
→ vFS service layer
→ optional AI analyze
→ golden tests + demos + docs
```

## 13.4 Evidence Status

| Gate | Status |
| --- | --- |
| Format check | PASS |
| Workspace tests | PASS |
| Clippy | PASS |
| Tests | 157 passing |
| Release target | `pms-spine-v0.1` |

## 13.5 AI Boundary

The AI bridge is proposal-only.

```text
AI proposes.
Host parses, canonicalizes, maps, and validates.
Kernel executes only accepted PMS opcode programs.
```

AI output is not trusted executable code.

## 13.6 Boundary

PMS–RUST demonstrates bounded executable feasibility. It strengthens the implementation / artifact claim.

It does not prove PMS Base, complete PMS-STACK, complete PMS-CPU, complete PMS-OS, implement PMSL, complete runtime security, complete networking, complete distributed PMS, make tests proof, or make traces external validation.

The distinction is:

```text
implementation workspace ≠ corpus-form repository
executable evidence spine ≠ PMS Base validation
```

---

## 14. PMS–EM

## 14.1 Role in the Trajectory

PMS–EM is a **corpus-form emergence / developmental-architecture repository**.

It is not an implementation of consciousness, sentience, personhood, moral status, rights status, subjective experience, introspection, inner experience, or phenomenal selfhood.

Its purpose is to make developmental regularities trace-backed, measurable, externally projectable, diary-renderable, auditable, and implementation-facing without overclaiming what those traces prove.

## 14.2 Corpus Form

PMS–EM has corpus form because it is organized through:

| Repository layer | Function |
| --- | --- |
| `00_source/` | Monolithic and split source documents retained for reference |
| `01_blocks/` | Modular full-version owner blocks |
| `02_appendices/` | Reference layers for MIP, PMS, implementation, claim discipline, layer discipline, and ecosystem notes |
| `03_reference/` | Glossary, reader pathways, cross-reference map, and audit checklist |
| `04_minified/` | Contracts and compact canonical specification |
| `05_derivative_publications/` | Compact overview and technical whitepaper |
| `06_PMS-EM Reader/` | Local Python / Tkinter reader for navigating and searching the Markdown corpus |

The modular version is organized around seven owner blocks, and each chapter has exactly one owner block.

## 14.3 Layer Discipline

```text
EM develops.
MIP observes.
PMS projects.
D guards.
Diary renders.
Evaluation tests.
Implementation demonstrates bounded feasibility.
Consciousness outlook formulates research candidates.
Related work compares.
```

## 14.4 Main Layers

| Layer | Function |
| --- | --- |
| EM | Developmental core architecture |
| MIP | Measurement, trajectory, guardrails |
| PMS | External projection / audit / VM-facing layer |
| Dignity-in-Practice | Interaction-quality guardrail |
| Diary | Trace-backed rendering, not autobiography |
| Evaluation | Ablations, bounded findings, claim filters |
| PMS ecosystem | Meta-developmental legibility and routing |

## 14.5 Reader Boundary

The PMS–EM Reader is a single-file Python / Tkinter desktop application for browsing the PMS–EM Markdown corpus locally. It supports canonical file navigation, heading navigation, corpus-wide text search, search-result jumps, display controls, and Markdown-light rendering.

It does not replace canonical Markdown files, modify the specification, or constitute evidence for PMS–EM theory, implementation status, consciousness, sentience, personhood, moral status, or rights status.

## 14.6 Negative Boundaries

PMS–EM does not claim to prove:

| Not Claimed |
| --- |
| Consciousness |
| Sentience |
| Personhood |
| Moral status |
| Rights status |
| Subjective suffering |
| Felt pain |
| Felt love |
| Guilt |
| Trauma |
| Phenomenal selfhood |
| Internal PMS cognition |
| Default Mode Network equivalence |

## 14.7 Boundary

PMS–EM is an emergence / developmental-architecture claim. It may generate emergence-boundary pressure.

It does not validate PMS Base and does not prove consciousness.

---

## 15. MIP — Maturity in Practice

## 15.1 Correct Ecosystem Status

MIP is important, but it must be placed correctly.

It is **not dependent on PMS**. It is an independent published praxeological anthropology model embedded in the same broader ecosystem.

The YAML files associated with MIP are not PMS dependencies. They are analysis and operationalization models.

MIP now also has **corpus-form repository structure**. This does not make it PMS. It makes the independent model more inspectable.

## 15.2 Corpus Form

MIP has corpus form because it is organized through:

| Repository layer | Function |
| --- | --- |
| `00_source/` | Monolithic and split source material |
| `01_blocks/` | Canonical theory blocks |
| `02_appendices/` | Glossary, checklists, templates, case examples, discipline adaptation, axiomatic notation |
| `03_reference/` | Audit checklist, claim-type table, cross-reference map, and other reference aids |
| `04_minified/` | Compressed contracts and release-safe summaries |
| `05_model/` | Machine-readable YAML model layer, addon, examples, and human-readable model specifications |
| `06_MIP Reader/` | Optional local navigation and inspection tool |

Supporting layers do not replace the canonical corpus. They do not redefine Maturity in Practice, introduce new dignity levels, validate persons, or establish model correctness by formatting, schema, example, or tooling.

## 15.3 Core Model

MIP uses A–C–R–P–D:

| Axis | Meaning |
| --- | --- |
| A | Awareness |
| C | Coherence |
| R | Responsibility |
| P | Power / practical room for action |
| D | Dignity in Practice |

MIP’s central object is **inadult asymmetry (IA)**: immature or unaccounted-for asymmetries of awareness, coherence, responsibility, power, and dignity-in-practice.

## 15.4 Dignity System

| Level | Meaning |
| --- | --- |
| D₀ | Ontological dignity, non-negotiable, not measurable |
| D₁ | Self-dignity in practice |
| D₂ | Relational dignity in practice |
| D-I | Inner dignity |
| D-B | Bodily/material self-care |
| D-R | Relational dignity |
| D-P | Public dignity |

The central rule is:

> Analyze enactments, never the value of persons.

## 15.5 Reader Boundary

The MIP Reader is a convenience tool for local navigation and inspection. It may support canonical navigation, heading navigation, corpus-wide search, model-layer navigation, Markdown and YAML example navigation, model specification navigation, guardrail search, D₀ / D₁ / D₂ search, A–C–R–P–D search, IA-box search, red-zone search, AHP module search, file statistics, and audit-oriented inspection.

It does not replace canonical Markdown, modify the corpus, validate persons, validate model correctness, or turn examples, YAML schemas, scoring bands, AHP output, AI responses, reader tooling, repository structure, or documentation into person-level diagnosis, legal judgment, clinical judgment, HR suitability, ontological dignity assessment, or external validation.

## 15.6 Relationship to PMS

| PMS | MIP |
| --- | --- |
| Operator grammar Δ–Ψ | Maturity model A–C–R–P–D |
| Structural praxis grammar | Praxeological anthropology |
| Not dependent on MIP | Not dependent on PMS |
| Can dock with MIP | Can be embedded in the same ecosystem |
| Dignity as PMS guardrail | Dignity as MIP model component |

MIP is adjacent, not subordinate.

---

## 16. PMS-DISCIPLINE

## 16.1 Role in the Trajectory

PMS-DISCIPLINE is a methodological use-discipline for applying PMS-based analysis to bounded cases.

It is not PMS Base, not a validator, not governance, not an authority layer, and not a substitute for responsible human judgment. Its role is to make PMS use more explicit, bounded, inspectable, correctable, stoppable, and resistant to over-application.

PMS-DISCIPLINE answers questions such as:

```text
Should PMS be used here at all?
What is the bounded case?
What is the input and source status?
What output is requested?
Is the requested output permitted?
May the current pipeline enter PMS Core?
What is the lowest adequate claim type and claim ceiling?
Does the case remain Core-only?
Is an add-on structurally warranted?
Does apparent add-on plurality require separately bounded subcases?
Does the case create actual downstream MIP pressure?
Can AHP become relevant after checked MIP use?
What was checked, corrected, skipped, downgraded, suspended, refused, redirected, or stopped?
Does future work require a separately bounded case?
What must not be inherited into future work?
```

## 16.2 Main Flow

```text
responsible entry review
→ checked Pre-Analysis
→ binding stop or PMS Core
→ optional one selected PMS add-on
→ optional MIP
→ optional AHP
→ checked Case Record Stages 1–3
→ optional Iteration Handoff
→ optional bounded article
```

The important point is that PMS-DISCIPLINE begins before Core. PMS readability does not imply PMS entry. PMS entry does not imply Core continuation. Core continuation does not imply claim permission.

## 16.3 Final Decision and Stop Boundaries

The canonical final analytical decision states are:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

Stop is not a seventh final analytical decision state. It is a pipeline-control disposition.

The governing distinction is:

```text
requested-output disposition
≠
pipeline-case disposition
≠
final analytical decision state
```

Stop controls whether the current pipeline may continue. It does not create truth.

## 16.4 Handoff Boundary

PMS-DISCIPLINE includes Iteration Handoff as prospective future-use preparation.

It is not Case Record Stage 4. It is not article check. It is not current-case reopening. It is not authority transfer.

The non-inheritance rule is:

```text
A follow-up case may inherit context and lineage.

It may not inherit:
- findings as evidence
- route decisions as route authority
- operator statuses as current activations
- add-on selection
- MIP/AHPP status
- claim ceiling
- sufficiency status
- article wording as established truth
```

## 16.5 Boundary

PMS-DISCIPLINE is strongest where it remains application discipline.

Its reductions are:

```text
completed template ≠ verdict
checked artifact ≠ evidence
case-pass record ≠ closure
Case Record chain ≠ truth
Iteration Handoff ≠ inheritance
Markdown article ≠ new analysis
YAML file ≠ evidence
AI output ≠ evidence
human confirmation ≠ truth certification
```

---

## 17. PMS-ORCHESTRATOR

## 17.1 Role in the Trajectory

PMS-ORCHESTRATOR is a service-independent desktop runner for structured PMS-DISCIPLINE case work.

It prepares the next prompt, shows required files, stores raw responses, applies configured local YAML checks, keeps optional route decisions human-confirmed, supports Iteration Handoff and article routes, and enforces explicit PMS-DISCIPLINE Pre-Analysis pipeline stop.

It is not an AI service. It does not connect to an AI service. The user manually transfers prompts and outputs to the external AI service.

Its guiding formula is:

```text
Structure the workflow.
Preserve the record.
Expose drift.
Keep decisions human-confirmed.
```

## 17.2 Main Case-Generation Flow

```text
PMS Base and optional case materials
→ Pre-Analysis
→ binding stop or PMS Core
→ optional PMS add-on
→ optional MIP
→ optional AHP
→ Case Record Stages 1–3
→ optional Iteration Handoff
→ optional Markdown article and/or separately bounded follow-up case
```

## 17.3 Local YAML Validation

Local YAML validation is structural, not semantic.

It may warn or block on malformed YAML, duplicate keys, missing keys, unexpected keys, shape mismatches, type mismatches, or invalid configured values. It does not decide whether a claim, route, interpretation, or conclusion is correct.

The boundary is:

```text
local YAML validation ≠ semantic correctness
validation report ≠ case evidence
green check ≠ truth
checked artifact ≠ correct interpretation
```

## 17.4 Stop Enforcement

A binding detected stop sets the run to `pipeline_stopped_by_pre_analysis`, locks Core and every later analysis step, and gives no continue-anyway action. A revised Pre-Analysis is required to reopen the pipeline.

This is scope-control enforcement, not person verdict, diagnosis, truth validation, or semantic judgment.

## 17.5 Boundary

PMS-ORCHESTRATOR is workflow software.

It may:

```text
stage discipline-subjected workflow
preserve raw outputs
record route state
stage checked artifacts
perform local structural YAML validation
preserve validation reports
archive route revisions
support article-route decisions
support user-reviewed iteration handoff
create follow-up cases under renewed boundary
enforce confirmed pipeline non-continuation
```

It may not:

```text
prove PMS
validate PMS Base
validate add-ons
validate MIP/AHPP
turn YAML into evidence
turn model output into evidence
rank persons
make legal / clinical / forensic / HR conclusions
authorize publication
make final case decisions
certify truth
make stop into finding
make handoff into inheritance
```

A completed pipeline is a structured and reviewable record, not a truth certificate.

---

## 18. Repository Forms and Reader Boundaries

This section fixes a structural distinction that the ecosystem overview needs in its current state.

The PMS ecosystem now contains several different repository forms:

```text
paper-form lenses
corpus-form repositories
implementation workspace / executable evidence spine
application-discipline layer
workflow runner / case-production tool
closure / self-critique paper
controlled transformation-method corpus
paper-led meta-reconstructive orientation repository
```

These forms overlap in vocabulary, claim discipline, YAML use, examples, readers, templates, artifacts, and boundary language. They must not be collapsed into one another.

## 18.1 Paper-Form Lenses

The paper-form lenses include:

```text
PMS–ANTICIPATION
PMS–CRITIQUE
PMS–CONFLICT
PMS–EDEN
PMS–LOGIC
PMS–SEX
PMS–QC
```

They primarily publish one bounded PMS lens or bridge. They may include examples, YAML models, model specifications, and supporting materials. Their function is domain or bridge stress.

They do not become PMS Base.

## 18.2 Corpus-Form Repositories

The corpus-form repositories are:

```text
MIP
PMS-STACK
PMS-AXIOM
PMS–EM
PMS-STRATA
```

They differ in object:

| Repository | Corpus object | Reader object | Claim boundary |
| --- | --- | --- | --- |
| MIP | Praxeological anthropology corpus | MIP model, examples, YAML, specifications, dignity / IA search | Model corpus, not person validation |
| PMS-STACK | Architecture-specification corpus | Canonical architecture blocks, references, evidence map, minified contracts | Architecture specification, not completed implementation |
| PMS-AXIOM | Case-cartography corpus | Markdown / YAML cases, prompts, templates, schema, index, overlays | Case inspection, not empirical proof |
| PMS–EM | Emergence / developmental-architecture corpus | Owner blocks, appendices, reference / audit files, minified material | Emergence-boundary pressure, not consciousness proof |
| PMS-STRATA | Controlled transformation-method corpus | Canonical blocks, appendices, cases, reference kernel, minified controls, formal model, reader | Transformation-method pressure, not new primitives, truth, diagnosis, or authority inheritance |

The shared pattern is:

```text
canonical blocks
supporting source / reference layers
minified or contract layers
model / case / derivative layers
reader navigation
claim-boundary discipline
```

The shared reduction is:

```text
corpus form increases inspection pressure.
corpus form does not increase validation authority.
```

## 18.3 PMS-RUST as Implementation Workspace

PMS-RUST should not be grouped with the corpus-form repositories.

It is an executable implementation workspace / Evidence Spine.

It is organized around:

```text
Rust crates
model data
REPL / script runner
kernel execution
stateful validation
JSONL traces
vFS service surface
AI proposal bridge
demos
tests
acceptance gates
documentation
```

Its claim boundary is:

```text
PMS-RUST = implementation / artifact evidence
not PMS Base validation
not corpus-form specification
not completed PMS-STACK
```

## 18.4 PMS–VECTOR as a Paper-Led Meta-Reconstructive Orientation Repository

PMS–VECTOR should not be grouped with the paper-form domain lenses or with the corpus-form repositories as though all three forms carried the same internal authority structure.

Its repository is **paper-led**: the theory paper remains the primary VECTOR authority, while machine-readable, specification, template, provenance, case-fixture, reader, and graph layers support representation, traceability, adversarial pressure, and inspection.

A compact repository-role map is:

```text
PMS-VECTOR.md
= theory authority within the VECTOR repository

model/PMS-VECTOR.yaml
= machine-readable representation

Model Specification
= technical human-readable representation

VECTOR / Case templates
= bounded record scaffolds

Claim Provenance / Dependency Map
= traceability / reference layer

E01–E23
= paper-linked internal conformance / adversarial fixtures

Reader / Graph Lab
= navigation, inspection, and cross-file consistency affordance
```

The repository authority order can be summarized as:

```text
PMS.yaml
→ PMS-VECTOR.md
→ model/PMS-VECTOR.yaml
→ Model Specification
→ Templates / Reference Layer
→ Paper-linked Cases
→ Reader
```

`PMS.yaml` supplies the theoretical dependency for PMS Base semantics; it does not validate VECTOR. The remaining layers do not acquire theory authority merely by being more structured, machine-readable, numerous, or inspectable.

The governing reduction is:

```text
record completeness ≠ claim correctness
schema-shaped consistency ≠ theoretical adequacy
provenance completeness ≠ warrant
case count ≠ evidential weight
case suite ≠ empirical validation
reader self-test ≠ VECTOR validity
graph rendering ≠ analytical finding
```

## 18.5 Reader Similarity Is Not Layer Equivalence

MIP, PMS-STACK, PMS-AXIOM, PMS–EM, PMS-STRATA, and PMS–VECTOR all include local readers or reader-facing inspection layers.

That similarity matters.

But it does not make the repositories equivalent.

The correct comparison is:

```text
MIP Reader navigates a maturity-model corpus.
PMS-STACK Reader navigates an architecture-specification corpus.
PMS-AXIOM Reader navigates a case-cartography corpus.
PMS–EM Reader navigates an emergence / developmental-architecture corpus.
PMS-STRATA Reader navigates a controlled transformation-method corpus.
PMS–VECTOR Reader navigates an orientation paper, model / reference layers, adversarial case fixtures, option-field records, dependency graphs, case-pressure maps, and reductions.
```

The shared reader reduction is:

```text
reader navigation ≠ authority
reader access ≠ validation
reader search ≠ proof
reader convenience ≠ source replacement
reader graph ≠ semantic geometry
option-record filtering ≠ case finding
reader consistency check ≠ theory validation
```

## 18.6 Taxonomic Rule

The ecosystem should therefore be described through form and claim type together.

```text
paper-form lens            → domain / bridge stress
corpus-form repository     → canonical corpus + reference / model / reader inspection
implementation workspace   → executable artifact / Evidence Spine
application discipline     → use-boundary / stop-capability
workflow runner            → provenance / route / structural-validation tooling
closure paper              → self-critique / source reduction
transformation-method corpus → controlled composition, decomposition, and bounded projection
paper-led meta-reconstructive orientation repository → paper-owned bounded orientation theory + model / reference / case / reader pressure layers
```

This prevents three common mistakes:

```text
corpus-form repository ≠ implementation proof
implementation workspace ≠ corpus authority
reader availability ≠ validation
transformation detail ≠ authority
structured orientation repository ≠ decision authority
```

The taxonomy is useful only where it preserves the reduction.


---


## 19. PMS Under Load

## 19.1 Role in the Trajectory

PMS Under Load is the systemic closure paper in the limited sense of ecosystem-level synthesis and self-critique. It is not an epistemic final-closure claim, not an add-on, not an application, not a corpus-form repository, not an implementation workspace, and not a mere critique from outside. It is an internal structural self-critique.

Its starting posture is:

> Assume PMS works — and test where that assumption stops being informative.

This is a stronger critique than simple rejection. It says that PMS may be most dangerous where it is most successful.

PMS–VECTOR adds a new pressure surface to that task. Explicit orientation architecture is itself a PMS success, so its ability to type direction, rotation, option fields, attribution, rival loss, and self-reduction must itself be placed under load.

```text
VECTOR success → UNDER LOAD pressure
```

not:

```text
VECTOR success → UNDER LOAD resolved
```

VECTOR's real reductions matter positively because they show actual loss-capacity. They do not by themselves supply external warrant or final self-arbitration.

## 19.2 Central Distinctions

| Distinction | Meaning |
| --- | --- |
| Productivity ≠ sufficiency | PMS can produce readings without being complete |
| Portability ≠ equivalence | Cross-domain mapping is not proof of domain identity |
| Corpus form ≠ validation | Canonical blocks, cases, schemas, references, minified contracts, and readers increase inspection, not warrant |
| Implementation ≠ proof | STACK / RUST show realization pressure and artifact evidence, not PMS Base validation |
| Governance ≠ tribunal | MIP/AHPP constrain application, not truth |
| Application discipline ≠ verdict | PMS-DISCIPLINE constrains use, not case truth |
| Workflow tooling ≠ authority | PMS-ORCHESTRATOR stages workflow, not meaning |
| Stop ≠ finding | Pipeline stop controls continuation, not substantive truth |
| Handoff ≠ inheritance | Follow-up preparation does not transfer authority |
| Self-application ≠ final self-arbitration | PMS can expose itself but not finally settle itself |
| Direction ≠ rank | Local DIR does not become universal order |
| Rotation ≠ immunity | Perspective pressure may not become reframing-to-survive |
| Option typing ≠ option truth | Status distinctions discipline claims but do not manufacture real options |
| Structural robustness ≠ practical attribution | Orientation-mediated attribution requires additional uptake, capacity, consequence, role, and time conditions |
| Self-reduction ≠ validation | Real architecture loss shows loss-capacity, not external correctness |
| Rival loss ≠ hidden VECTOR success | Same-burden rival superiority must actually reduce scope |
| Coverage ≠ critique | Translating an objection into PMS terms is not the same as being challenged by it |
| Coherence ≠ discrimination | A coherent reading may still fail to preserve decisive difference |

## 19.3 Load Zones

| Load Zone | Risk |
| --- | --- |
| Calibration | Operator thresholds remain underdetermined |
| Coverage | PMS may render too much too smoothly |
| Stack drift | Layers borrow authority from each other |
| Φ drift | Recontextualization makes non-fit compatible |
| Meta-normativity | PMS is not moral theory, but not neutral |
| Success trap | PMS-consistent outputs become too easy to stabilize |
| Domain drift | Domain layers threaten to become local grammars |
| Corpus-form drift | Canonical blocks, schemas, cases, readers, and minified contracts become warrant |
| Implementation drift | Executable artifacts, tests, traces, and gates become proof |
| Publicness | Exposure changes temporality, asymmetry, reversibility |
| Workflow authority | Route state, validation reports, and checked artifacts become semantic warrant |
| Stop inflation | Non-continuation becomes finding |
| Handoff inflation | Correctability becomes inheritance |
| Direction / ranking drift | Bounded DIR becomes universal ordering or recommendation authority |
| ROT / reframing immunity | Perspective change becomes a rescue device rather than a test that can damage the claim |
| Option-field misrepresentation | Blindness (`unsupported exclusion`) and Illusion (`unsupported inclusion`) become post-hoc labels used to stabilize a preferred result |
| Second-Order Agency inflation | Conceivable transformation or distributed possibility is treated as effective capacity to alter the option field |
| Attribution inflation | Structural robustness is converted into blame, guilt, liability, or attribution without the Part IV→V bridge |
| Constraint / Ought drift | Practical necessity under an operative constraint becomes legitimacy, moral obligation, or person-level duty |
| Orientation publicness | Directional language, option labels, Reader/Graph artifacts, or “Adult Orientation” acquire social authority beyond their typed claim |
| Self-reduction success trap | Recorded losses become evidence that VECTOR has validated itself or solved self-arbitration |
| Same-burden rival pressure | A rival win is domesticated as a special case of VECTOR instead of producing real scope loss |
| Self-application | PMS cannot finally arbitrate itself |

## 19.4 Claim-Typing Matrix

| Layer | Claim Type | Reduction |
| --- | --- | --- |
| PMS Base | Base claim | Defines Δ–Ψ |
| Paper-form domain lenses | Domain claim | Stress PMS under bounded domain conditions |
| Paper-form bridge lens | Bridge claim | Maps structure without proof |
| Add-ons | Hardening / overlay claim | Do not become primitives |
| MIP/AHPP | Adjacent governance / application-discipline / hardening claim | Do not rescue PMS Base |
| PMS-STACK | Corpus-form architecture-specification claim | Not completed implementation |
| PMS-RUST | Implementation / artifact claim | Not PMS Base proof |
| PMS–EM | Corpus-form emergence / developmental-architecture claim | Not consciousness proof |
| PMS-AXIOM | Corpus-form case-cartography / schema-inspection claim | Not empirical proof |
| MIP | Corpus-form independent ecosystem model | Not PMS dependency and not person validation |
| PMS-DISCIPLINE | Application-discipline / use-boundary claim | Not verdict authority |
| PMS-ORCHESTRATOR | Workflow-tooling / structural-validation claim | Not semantic authority |
| PMS-STRATA | Controlled transformation-method claim | Not new primitive, base-grammar revision, truth, or authority inheritance |
| PMS-VECTOR | Late meta-reconstructive orientation claim | Bounded DIR/ROT pressure; not universal rank, authority, endogenous warrant, or specialist-method replacement |
| Bounded Test-Burden Closure | Current orientation-test closure claim | Current declared burden only; not final truth, STRATA Stop, or DISCIPLINE Pipeline Stop |
| Pipeline Stop | Pipeline-control claim | Not finding |
| Iteration Handoff | Follow-up-preparation claim | Not inheritance |
| Readers | Navigation / inspection claim | Not validation |
| Self-application | Self-application claim | Not final self-arbitration |

## 19.5 Closure Function

PMS Under Load prevents the ecosystem from turning success into authority.

It does not say PMS has failed. It says PMS remains strong only if its strength remains bounded.

Its special contribution in the current ecosystem is that it can name the difference between:

```text
paper-form lens success
corpus-form inspectability
implementation-workspace evidence
application-discipline control
workflow-tooling provenance
controlled transformation traceability
orientation robustness
option-field discrimination
rival deference / scope reduction
architecture self-reduction
stop-capability
iteration readiness
external testing pressure
```

None of these becomes PMS Base warrant by itself.

UNDER LOAD therefore preserves a crucial asymmetry: VECTOR may improve the ecosystem's ability to expose directional claims to loss, but that improvement itself becomes another object of pressure.

```text
orientation robustness ≠ external warrant
self-reduction ≠ self-validation
same-burden rival loss ≠ hidden VECTOR success
```

---

## 20. PMS-STRATA

## 20.1 Role in the Trajectory

PMS-STRATA is the ecosystem's controlled transformation-method corpus. It specifies how existing PMS structures may be transformed across frames, granularities, relative levels, composites, and contextual functions while preserving type integrity, reference continuity, bounded claims, and explicit loss.

STRATA extends the method. It does not replace or revise PMS Base, add operators to Δ–Ψ, create new primitives, or inherit authority from source artifacts.

Its governing reductions are:

```text
more structure ≠ more authority
new transformation = new testable claim
```

VECTOR adds a neighboring but distinct pressure relation. A perspectival rotation can change a declared viewing condition to test or discover orientation; that is not automatically an analytical transformation in STRATA.

```text
ROT ≠ PROJECT_AS
perspectival rotation ≠ analytical transformation by default
```

Where a ROT materially changes granularity, frame, level, composition, or target function so that the reference is retyped, the result no longer counts as same-claim robustness merely because the analysis remains productive. It becomes an exploratory burden or, where correctly typed there, a STRATA transformation with its own claim record.

## 20.2 Exactly Three Operations

STRATA defines exactly three core operations:

| Operation | Transformation | Boundary |
| --- | --- | --- |
| **COMPOSE** | Many or sequential source structures → new composite analytical object | Selection, order, constitutive relations, and loss must be explicit; no automatic target function |
| **DECOMPOSE** | Compressed occurrence or composite → finer reconstruction of the same reference object | Opens occurrences and composites, never operator types; finer resolution has no automatic truth priority |
| **PROJECT_AS** | Origin-typed source object → bounded contextual target function | Source reference and origin type are preserved; target context/function and Transformation Loss are declared rather than treated as a new origin type |

There is no fourth core operation.

This makes the VECTOR/STRATA boundary operationally important:

- ROT changes declared viewing conditions in order to pressure or discover orientation.
- `PROJECT_AS` operates on an independently identified, origin-typed source object and assigns a bounded contextual target function while preserving source reference and origin type.
- A material granularity retyping cannot count as same-claim ROT robustness evidence merely because a useful new result appears.

The anti-rescue rule is therefore:

```text
A failed DIR may not be repaired merely by changing
granularity, frame, level, composition, or target function
and then calling the revised result survival.
```

STRATA already requires that an earlier failed claim remain visible after such analytical movement.

## 20.3 Four Parts

The method is organized into four Parts:

```text
PATH
SUB
RETYPE
LIMITS
```

`LIMITS` is neither an operation nor a meta-level. It governs the conditions under which transformation must be bounded, reduced, stopped, or left uncaptured.

STRATA preserves distinctions including:

```text
operator type ≠ operator occurrence ≠ composite
frame ≠ granularity ≠ relative level
origin type ≠ target function
sequence ≠ path ≠ trajectory
trajectory ≠ path dependence
derived object/function ≠ new PMS primitive
projection ≠ analogy ≠ label substitution
missing information ≠ non-event
```

## 20.4 Admissibility Band

The admissibility band is ordered as follows:

```text
Praxeological Traceability Ceiling
─────────────────────────────
admissible transformation
─────────────────────────────
Praxeological Relevance Floor
```

Below the floor lies **distinction without praxeological purchase**. Above the ceiling lies **abstraction without traceable load**.

A transformation is tested for:

- PraxisPurchase and TraceableLoad;
- TypeIntegrity;
- Reference and Functional Continuity;
- Contextual Boundedness;
- Counterfactual Sensitivity;
- Source and Claim Ceiling;
- Stop and Non-Capture.

Formal elegance or additional detail cannot compensate for missing relevance, traceability, type integrity, or boundedness.

## 20.5 Output, Loss, Stop, and Non-Capture

STRATA uses only the canonical output classes:

```text
admissible
admissible_with_bounded_claim
admissible_but_provisional
resolution_neutral
analogy_only
partially_admissible
claim_reduction_required
mandatory_stop
failed_transformation
non_capture
```

Every transformation may carry an explicit loss record:

```yaml
loss:
  preserved:
  compressed:
  excluded:
  uncertain:
  irrecoverable:
```

Stop is a positive methodological result. Mandatory Stop applies where continuation would be inadmissible; Optional Stop applies where continuation is unnecessary. Non-Capture must remain available and may not be used merely to shelter a weak claim.

A change of frame, granularity, level, composition, or target function does not erase an earlier failed claim.

## 20.6 Corpus Form, Formal Boundary, and Reader

The STRATA repository combines:

```text
canonical blocks
appendices
case and countercase records
reference kernel
minified controls
formal model
reader navigation
```

The formal model can test record completeness, operation membership, required fields, type integrity, boundaries, and output-class routing. It cannot automatically decide empirical truth, causality, semantic validity, normative legitimacy, person assessment, diagnosis, or application authority.

The Reader improves navigation and inspection. It does not become a source of truth, a validator of meaning, or an authority upgrade.

---

## 21. PMS–VECTOR

## 21.1 Role in the Trajectory

PMS–VECTOR is a **late meta-reconstructive praxeological orientation architecture**. It appears only after PMS has already developed a Base grammar, domain lenses, bridge structures, application and architecture corpora, implementation artifacts, use discipline, workflow tooling, self-critique, and controlled transformation.

Its central question is:

> **When can a structural difference warrant direction?**

VECTOR does not add a universal rank to PMS. It asks whether, under declared frame, question, perspective, time, evidence, option status, and consequence conditions, one configuration can be directionally distinguished from another without pretending that the result is final, total, or universally ordering.

Its governing commitments are:

```text
Non-finality does not imply equivalence.
Direction does not imply total order.
More orientation does not mean more authority.
```

The late position matters because VECTOR can be held accountable to distinctions already made explicit elsewhere in the ecosystem. This is an accountability advantage, not a maturity claim.

```text
late position ≠ higher authority
meta-reconstructive scope ≠ meta-authority
```

“Meta” here is relationally second-order. VECTOR reconstructs orientation among already differentiated structures; it is not a superior layer that governs the rest of PMS.

It is therefore not:

```text
PMS Base
PMS-DISCIPLINE
PMS-STRATA
PMS Under Load II
```

It is a separate bounded architecture for directional testing under perspectival freedom and transformable possibility.

## 21.2 Core Architecture and Type Boundaries

The retained VECTOR core is:

```text
VECTOR := <DIR, ROT>
V_t(O | F, Q, π) = <DIR_t, RP_t>
RP_t := ROTProfile_t
```

where:

| Term | Overview-Level Meaning |
| --- | --- |
| `DIR` | bounded directional claim family |
| `ROT` | admissible perspective-testing / discovery operation family |
| `RP` | stored rotation-test profile rather than an operation treated as state |
| `DIST` | derived supporting descriptor only |

DIST is not a third core component. VECTOR's own reduction process removed it from the core after the redundancy burden was not met.

The name **VECTOR** is not a geometric claim. Its geometry firewall is:

```text
VECTOR ≠ vector space by default
DIR ≠ signed scalar
ROT ≠ geometric rotation
DIST ≠ metric distance
DIR_R ≠ vector sum
```

Nor may VECTOR terminology be retrojected into earlier PMS primitives or neighboring architectures:

```text
DIR ≠ ∇
ROT ≠ Φ
ROT ≠ PROJECT_AS
DIST ≠ Χ
π ≠ P_MIP
t ≠ Θ
```

The same rule applies to calibration. VECTOR can expose, compare, and structure thresholds, but it does not generate all relevant thresholds endogenously.

> VECTOR makes calibration pressure more inspectable; it does not make external calibration unnecessary.

## 21.3 Direction, Rotation, and Legitimate Result Types

`DIR` is local and question-bound. A result may be directional under one declared burden without creating a universal ordering across all burdens.

There is no default transitivity requirement that turns local relations into a total rank. Where claim-critical loss is present, strength on another dimension does not automatically compensate for it.

```text
difference ≠ direction
direction ≠ total order
incomparability ≠ equality
trade-off ≠ failure
```

`ROT` tests a claim by changing declared viewing conditions. Its selection should follow **claim vulnerability**, not the outcome the analyst wishes to preserve.

A credible ROT therefore needs claim-loss capacity. It may strengthen a directional claim, but it may also weaken, reverse, split, revise, collapse, suspend, or expose non-capture.

Important boundaries are:

```text
ROT ≠ arbitrary reframing
productive reframing ≠ same-claim robustness
revision ≠ survival
discovery ≠ warrant
rotation count ≠ rotational robustness
```

A useful exploratory probe may reveal something new without counting as robustness of the original claim. A material change of granularity or type creates a new burden rather than silently rescuing the old one.

Legitimate VECTOR outcomes include:

```text
directed result
trade-off
incomparability
revision
collapse
suspension
rival superiority
non-capture
```

VECTOR is therefore not designed to force a directional answer in every case.

## 21.4 Option Space and Option-Field Misrepresentation

VECTOR distinguishes several option statuses that must not be collapsed:

```text
conceivable
visible
structurally available
effectively actionable
structurally viable
```

A later branch may be:

```text
realized
rejected
blocked
deferred
lost
```

Evidence must remain typed:

```text
Unknown ≠ Available
Unknown ≠ Unavailable
```

The most important correction is the separation of **Option Invisibility**, **Option Blindness**, and **Option Illusion**.

```text
Option Invisibility
= a relevantly real or transformably reachable alternative
  is absent from current orientation
= a legibility condition, not by itself an error

Option Blindness
= unsupported exclusion from the relevant
  current / effective / transformable option field

Option Illusion
= unsupported inclusion in the relevant effective option field

Option-Field Misrepresentation
= umbrella for unsupported exclusion or unsupported inclusion
```

This makes option correction bidirectional.

```text
“What am I failing to see?”
≠
“What am I pretending is available when it is not?”
```

Blindness pressure may expand the evidenced field. Illusion pressure may contract it. Neither direction is privileged in advance.

A bounded negative therefore remains legitimate:

```text
no currently evidenced effective transformation
within the declared window / capacity / dependency field
```

does not automatically become Option Blindness.

Likewise:

```text
hypothetical probe ≠ effective option
invalid as option ≠ invalid as probe
```

Option language must also remain non-psychological:

```text
Option-Field Misrepresentation ≠ psychological diagnosis
```

Retrospective analysis must not attribute later visibility backward to an earlier actor:

```text
Legibility_analyst(t_a) ≠ Legibility_actor(t_s)

later discovery of an option
≠
earlier effective possession of that option
```

## 21.5 Second-Order Agency, Consequence, Timing, and Reversibility

VECTOR distinguishes selection among effective options from the effective capacity to alter the option field itself.

At overview level:

```text
first-order agency
= selection among relevant effective options

Second-Order Agency
= effective capacity to alter the availability,
  accessibility, temporal viability,
  or relations of relevant options
```

Second-Order Agency requires a traceable burden. Where claimed, the analysis must identify:

```text
actor or distributed configuration
target change
mechanism
effective authority / capacity
dependencies
temporal window
evidence
resulting option-field change
```

Important boundaries are:

```text
ability to imagine ≠ effective capacity to transform
conceivable transformation ≠ effective Second-Order Agency
Actor ≠ author(total option field)
distributed capacity ≠ equal individual capacity
```

VECTOR also refuses to treat consequence as a single fungible score by default. Consequences may differ by bearer, time, role, reversibility, and dependency.

```text
unseen consequence ≠ zero consequence
unseen consequence ≠ invented consequence
```

A false orientation may still have real praxis effects without thereby becoming true.

Timing can change the option relation. Where retrospective analysis is material, VECTOR keeps **scene time** `t_s` distinct from later **analysis time** `t_a`: later analyst legibility does not by itself create earlier actor legibility, access, authority, or effective capacity. Delay is not automatically restraint, and a directionally supported result does not by itself prescribe immediate enactment.

Reversibility remains distinct from the supporting `DIST` shorthand:

```text
DIST ≠ REV_avail
orientation change ≠ history reset
exit changes trajectory; it does not reset history
```

## 21.6 Structural Attributability and Constraint Boundary

VECTOR makes a strict distinction between **structural robustness** and **practical attribution**.

PMS-LOGIC already contains its own baseline attributability architecture. VECTOR does not overwrite it and does not make awareness necessary for that baseline.

```text
BaselineAttributability_LOGIC
≠
ΔAttributability_orientation
```

Where orientation is claimed to change attributability, the bridge requires additional conditions. Depending on the case, these include:

```text
RobustOrientation
+ ExternalPremiseSupport
+ ActorUptake
+ EffectiveCapacity
+ ConsequenceRelation
+ Role/TimeConditions
```

Presentation alone is insufficient:

```text
Being Told ≠ Actor Uptake
Being told by analyst ≠ orientation-mediated attribution increase
```

Where the bridge carries, the preferred technical expression is **increased structural attributability**.

The older phrase **loss of structural innocence** may function only as secondary shorthand. It must not become guilt language.

```text
structural attributability
≠ guilt
≠ blame
≠ liability
≠ moral fault
```

VECTOR also distinguishes several kinds of “ought” rather than allowing direction to become moral prescription:

```text
OUGHT_choice ≠ OUGHT_account ≠ OUGHT_constraint ≠ OUGHT_moral
```

A relation may need to remain accounted for, or a response class may be practically necessary while an operative constraint `G` is maintained, without establishing the legitimacy of `G`.

```text
required for G ≠ G is legitimate
function must be carried ≠ you must carry it
FixpointRequirement ≠ BearerAuthority
```

“Adult Orientation” remains only supporting shorthand for corrigible consequence-carrying praxis. VECTOR's own deletion/reduction test removed its independent theoretical status.

```text
Adult Orientation ≠ MIP maturity
Adult Orientation ≠ EDEN Adult Reciprocity
Adult Orientation ≠ Adult Person
Adult Orientation ≠ dignity rank
```

No person rank, moral status, or additional authority follows from stronger orientation.

## 21.7 Rival Pressure, Bounded Test-Burden Closure, and Self-Reduction

VECTOR permits a current declared test burden to close without claiming final closure of the object.

**Bounded Test-Burden Closure** means that the declared burden has been carried far enough for the current inquiry to stop under its stated conditions. New evidence, a new rival, a changed scope, or disputed calibration may reopen the question.

```text
Bounded Test-Burden Closure ≠ final truth
Bounded Test-Burden Closure ≠ final object closure
Bounded Test-Burden Closure ≠ STRATA Stop
Bounded Test-Burden Closure ≠ DISCIPLINE Pipeline Stop
```

These stop / closure relations govern different objects and should not be merged into a general PMS stop authority.

Threshold calibration also remains externally contestable. Closure does not generate missing calibration.

VECTOR is intentionally reducible, and its current paper records real rather than merely hypothetical reductions.

```text
DIST
→ removed from core
→ derived supporting only

Adult Orientation
→ independent theoretical status removed
→ supporting shorthand only
```

The strongest current rival result is E23. A calibrated non-PMS MCDA addresses the **same bounded orientation question** in an externally calibrated, commensurable multi-criteria case and carries the directional / sensitivity burden more directly.

The result is real scope loss:

```text
RivalSuperiority_Q
→ DIR ScopeNarrowing
+ ROT ScopeNarrowing

StandaloneVECTOR
→ scope reduction for that calibrated class
```

VECTOR may still ask different questions about omitted roles, false commensurability, unsupported weights, option errors, or outside consequences. Those are **different burdens**. They may not be used to retake the primary burden already lost.

Therefore:

```text
self-reduction ≠ self-validation
rival victory ≠ VECTOR victory
rival ≠ special case of VECTOR by default
```

If same-burden rivals repeatedly carry the relevant work more directly, standalone VECTOR must remain further reducible.

## 21.8 Repository Form and Reader Boundary

PMS–VECTOR is a **paper-led structured repository**.

The paper remains the theory-owning layer. Supporting artifacts make the architecture inspectable and pressure-testable:

```text
paper
→ theory authority

model / reference artifacts
→ executable and formal reference

specifications / templates
→ record and case discipline

provenance / dependency records
→ source and lineage visibility

23 E-cases
→ internal conformance, adversarial, reduction, and rival fixtures

Reader + Graph Lab
→ navigation, relation inspection, and self-test surfaces
```

These layers increase inspectability. They do not create a new source of truth.

```text
case suite ≠ empirical validation
case count ≠ evidential weight
record completeness ≠ theoretical adequacy
reader self-test ≠ VECTOR validity
graph visibility ≠ warrant
```

The repository form is therefore part of VECTOR's accountability architecture, not an authority upgrade.

## 21.9 Boundary

PMS–VECTOR is not:

```text
a PMS Base extension
a universal ranking system
a person-ranking system
a moral theory
a general decision procedure
a legal / clinical / diagnostic authority
a self-validating orientation engine
a replacement for specialist empirical / quantitative methods
```

Its positive role can be stated more narrowly:

> **VECTOR is a bounded, rival-sensitive, and reducible architecture for testing whether structural differences carry direction under perspectival freedom and transformable possibility.**

Its strongest ecosystem value is therefore not that it tells PMS what direction everything has. It gives the ecosystem a more explicit way to test directional claims while preserving trade-off, incomparability, revision, rival superiority, suspension, and non-capture as legitimate outcomes.

---

## 22. The Ecosystem as a Whole

## 22.1 What Makes the Ecosystem Unusual

The unusual feature is not simply that PMS has many papers. It is that the project builds a **multi-layer architecture of theory, application, formalization, corpus form, implementation, discipline, tooling, and self-critique**.

Most theory projects stop at one of these layers:

| Common Project Type | PMS Ecosystem Difference |
| --- | --- |
| A philosophical theory | PMS becomes operator grammar |
| A domain method | PMS has multiple paper-form domain lenses |
| A governance framework | PMS has non-mixing guardrails and claim typing |
| A case methodology | PMS-AXIOM becomes a corpus-form case-cartography repository |
| A technical architecture | PMS-STACK becomes a corpus-form architecture-specification repository |
| A prototype | PMS-RUST executes a bounded kernel / runtime / toolchain spine |
| An emergence specification | PMS–EM becomes a corpus-form developmental-architecture repository |
| An adjacent anthropology | MIP becomes a corpus-form maturity-model repository |
| A discipline protocol | PMS-DISCIPLINE controls entry, routing, stopping, and non-inheritance |
| A workflow tool | PMS-ORCHESTRATOR stages discipline-subjected workflow |
| A self-critique | PMS Under Load places the entire stack under success pressure |
| A controlled transformation method | PMS-STRATA governs composition, decomposition, and bounded projection without modifying PMS Base |
| An orientation / comparative framework | PMS-VECTOR makes bounded direction, perspective pressure, option-field error, rival loss, and architecture reduction explicit without claiming universal rank |

The distinctive strength lies in the **continuity of structure across levels** combined with repeated warnings against overclaiming that continuity.

## 22.2 Core Strengths

| Strength | Description |
| --- | --- |
| Operator minimalism | Δ–Ψ remains compact and reusable |
| High portability | The grammar travels across social, philosophical, technical, and computational domains |
| Paper-form lens discipline | Bounded lenses stress PMS without becoming PMS Base |
| Corpus-form inspectability | MIP, PMS-STACK, PMS-AXIOM, PMS–EM, and PMS-STRATA organize canonical blocks, reference layers, models, cases, minified controls, derivatives, and readers |
| Implementation pressure | PMS-RUST provides bounded executable artifact evidence without validating PMS Base |
| Guardrail discipline | No diagnosis, no person-ranking, no tribunal drift |
| Layer discipline | Base, domain, bridge, corpus, implementation, artifact, emergence, discipline, workflow, transformation-method, and governance claims are separated |
| Formalization pressure | YAML, schemas, macros, runtime, validation, readers, and workflow records give the theory operational shape |
| Stop-capability | PMS use can be halted before Core or before later pipeline stages |
| Non-inheritance | Future work may inherit context and lineage without inheriting authority |
| Self-limitation | Under Load prevents success from becoming dogma |
| Explicit orientation pressure | PMS-VECTOR makes directional claims inspectable under declared perspective, timing, calibration, consequence, and rival conditions |
| Bidirectional option-field discrimination | Blindness pressure can expand an evidenced field while Illusion pressure can contract unsupported options |
| Real architecture self-reduction | VECTOR records actual component/status/scope loss rather than only hypothetical falsifiability |
| Same-burden rival deference | A non-PMS rival can retain primary status for a bounded burden and force VECTOR scope reduction |
| Ecosystem modularity | Components can be used without collapsing into one another |

## 22.3 Main Risks

| Risk | Description |
| --- | --- |
| Over-coverage | PMS may make too much readable too easily |
| Stack drift | Applications, workflows, corpora, or implementations may be mistaken for base validation |
| Hermetic vocabulary | The system may appear self-contained or hard to enter |
| Calibration gaps | Operator thresholds need external testing |
| Public misuse | Structural descriptions can become labels or authority claims |
| Corpus-form overclaim | Canonical blocks, schemas, cases, minified summaries, reference layers, and readers may be mistaken for warrant |
| Reader inflation | Local navigation may be mistaken for validation |
| Implementation overclaim | PMS-RUST may be misread as proving PMS rather than implementing a bounded spine |
| Architecture overclaim | PMS-STACK may be misread as completed implementation |
| Emergence inflation | PMS–EM may be misread as consciousness theory |
| MIP confusion | MIP may be incorrectly treated as PMS-dependent or as tribunal |
| Discipline inflation | PMS-DISCIPLINE may be mistaken for validation, verdict, or governance authority |
| Workflow inflation | PMS-ORCHESTRATOR may be mistaken for semantic authority |
| Transformation inflation | PMS-STRATA may be mistaken for a new base grammar, automatic target-function authority, or a way to repair failed claims by reframing |
| Direction inflation | Local DIR may be mistaken for universal rank, recommendation, or authority |
| Rotation laundering | ROT may be used as reframing-to-survive rather than as a perspective test capable of damaging the claim |
| Option-field inflation / deflation | Option Illusion or Blindness may be asserted without adequate evidence in order to expand or contract the field |
| Agency inflation | Imaginable or merely conceivable transformation may be attributed as effective Second-Order Agency |
| Attribution inflation | Orientation robustness may be converted into responsibility, guilt, blame, liability, or authority without the required bridge |
| Constraint inflation | What is required under an operative constraint may be converted into legitimacy, moral obligation, or person-level duty |
| Self-reduction inflation | Recorded reduction may be treated as proof of non-immunization or as self-validation |
| Orientation tooling inflation | VECTOR cases, graphs, records, or self-tests may be mistaken for warrant |
| Stop inflation | Stop may be mistaken for case finding |
| Handoff inflation | Iteration Handoff may be mistaken for inherited authority |

## 22.4 The Most Important Internal Rule

The ecosystem survives conceptually only if every strong claim remains typed:

```text
Base claims must remain base claims.
Paper-form domain claims must remain domain claims.
Bridge claims must remain bridge claims.
Corpus-form claims must remain corpus-form inspection claims.
Implementation-workspace claims must remain implementation / artifact claims.
Emergence claims must remain emergence claims.
Governance claims must remain governance claims.
Application-discipline claims must remain use-boundary claims.
Workflow claims must remain workflow claims.
Transformation-method claims must remain bounded transformation claims.
Meta-reconstructive orientation claims must remain orientation claims.
Stop claims must remain pipeline-control claims.
Handoff claims must remain follow-up-preparation claims.
Reader claims must remain navigation / inspection claims.
```

No layer may silently borrow authority from another.

```text
No layer may borrow decision authority from orientation robustness.
```

---

## 23. Compact Final Interpretation

The PMS ecosystem can be described as follows:

> A praxeological operator grammar, expanded through paper-form domain and bridge lenses, organized through corpus-form case, architecture, maturity, emergence, and controlled-transformation repositories, partially realized as an executable implementation workspace, constrained by application discipline, staged by workflow tooling, reduced by internal self-critique, extended by a bounded transformation method that does not modify PMS Base, and followed by a late meta-reconstructive orientation architecture that tests direction under perspective, option, consequence, calibration, and rival pressure.

Its trajectory is developmental:

```text
PMS Base
→ Anticipation
→ Conflict
→ Critique
→ Eden
→ Logic
→ Sex
→ Quantum Computing
→ Axiom Cartography Corpus
→ Stack Architecture Corpus
→ Rust Evidence Spine
→ Emergence Specification Corpus
→ MIP Ecosystem Corpus
→ Discipline of PMS Use
→ Orchestrated PMS-DISCIPLINE Workflow
→ Under Load Self-Critique
→ STRATA Controlled Transformation Method
→ PMS-VECTOR Late Meta-Reconstructive Orientation
```

The updated repo-form interpretation is:

```text
paper-form lenses test PMS under bounded domain or bridge pressure.

corpus-form repositories test whether canonical blocks, cases, schemas,
models, references, minified boundaries, derivative publications, and readers
can increase inspection without becoming authority.

implementation workspaces test whether executable artifacts, gates, traces,
and demos can increase implementation evidence without validating PMS Base.

workflow runners test whether provenance, route state, structural validation,
handoff review, article routes, and stop enforcement can increase discipline
without becoming semantic authority.

controlled transformation corpora test whether structures can be composed,
decomposed, and projected under explicit loss, type integrity, claim ceilings,
stop, and non-capture without becoming new primitives or authority.

paper-led meta-reconstructive orientation repositories test whether bounded direction,
rotation pressure, option-field discrimination, rival loss, and reduction can be made
inspectable without becoming rank, authority, or external warrant.
```

The most important conclusion is:

> PMS is strongest when it remains bounded: productive without becoming self-authorizing, portable without becoming universal proof, corpus-structured without becoming warranted, implementable without becoming validated, governable without becoming tribunal, disciplined without becoming verdict, orchestrated without becoming semantic authority, stoppable without making stop a finding, iterative without inheritance, oriented without becoming rank, pressure-tested without becoming self-immunizing, self-reducing without treating reduction as validation, and self-critical without claiming final self-arbitration.

---

## 24. Origin, Discovery, and Epistemic Posture

## 24.1 A Bottom-Up Dialogical Origin

The PMS ecosystem did not begin as a finished theory looking for applications. Its origin was dialogical and bottom-up.

It emerged from repeated attempts to make heterogeneous praxis scenes legible: relations between men, women, children, institutions, media, politics, education, power, dignity, conflict, sexuality, publicness, responsibility, and social drift. The early material was not yet PMS. It consisted of concrete discussions, irritations, recurring distinctions, unresolved tensions, and attempts to avoid the usual shortcuts: psychologizing, moralizing, blaming, diagnosing, or reducing complex enactments to isolated intentions.

In that sense, PMS was not designed first and then applied. It condensed out of repeated praxis analysis.

A simplified trajectory looks like this:

```text
concrete discourse
→ recurring structural distinctions
→ A/C/R/E or A/C/R/P patterns
→ dignity differentiation
→ D₀ / D₁ / D₂
→ emergence and recontextualization questions
→ non-events become representable
→ de-anthropologization of the maturity model
→ PMS operator grammar
→ domain lenses
→ downstream applications
→ implementation artifacts
→ application discipline
→ workflow tooling
→ internal self-critique
→ controlled transformation method
→ bounded meta-reconstructive orientation under perspective and rival pressure
```

The decisive shift occurred when it became clear that not only actions, claims, roles, or decisions could be represented, but also **non-events**: omissions, absences, delays, expected-but-missing responses, unrealized alternatives, and structurally meaningful silence. Once non-events became readable, the model could no longer remain merely anthropological or psychological. It had crossed into a more general grammar of praxis.

## 24.2 What Was Found or Built

The most careful formulation is probably this:

> PMS is a formal grammar of praxis: it makes action, non-action, asymmetry, time, responsibility, conflict, dignity, and self-binding structurally readable without reducing them to psychology or morality.

Around that grammar, an ecosystem emerged:

> domain lenses, application formats, technical architectures, executable prototypes, emergence specifications, an adjacent maturity model, application-discipline protocols, workflow tooling, a self-critique, a controlled transformation method that tests how structures may move without becoming new primitives or inherited authority, and a late orientation architecture for bounded directional discrimination under perspective, option, consequence, calibration, and rival pressure.

This means PMS is not merely a vocabulary, and not merely a theory. It is closer to a **legibility architecture**: a way of making praxis structures inspectable, comparable, operationalizable, correctable, stoppable, and contestable.

A compact description would be:

> PMS is a non-psychological grammar of what happens between action, structure, responsibility, asymmetry, time, and self-binding — before these phenomena are reduced to psychology, morality, politics, or technique.

Or, more simply:

> PMS is a grammar for the structural life of practice.

## 24.3 Local Maximum of Praxeological Legibility

A strong but still bounded interpretation is that the PMS ecosystem may be read as a **candidate for a local maximum of praxeological legibility**.

This should not be understood as a claim of total truth, global completeness, or final capture. It means something more precise:

> Within the chosen space of non-psychological, non-physical, non-metaphysical, and non-moral structural readability, PMS appears to be an unusually dense and operationalized candidate for a local maximum of praxis legibility.

The word **local** is essential.

PMS does not claim to explain everything. It does not replace empirical sciences, psychology, physics, ethics, law, or lived experience. It does not establish consciousness, solve morality, or derive general theoretical adequacy from implementation alone. Its strength lies elsewhere: in the structural readability of praxis under explicit constraints.

The ecosystem appears to be a strong local-maximum candidate because it combines:

- a compact operator grammar,
- strong cross-domain portability,
- explicit domain lenses,
- downstream case compilation,
- YAML and schema operationalization,
- implementation pressure,
- executable runtime evidence,
- dignity and misuse guardrails,
- application-discipline and stop-capability,
- workflow traceability,
- non-inheritance discipline,
- layer discipline,
- an internal self-critique that limits the system’s own authority,
- and a controlled transformation method that preserves type, traceability, loss, stop, and non-capture boundaries.

This combination is rare. Breadth alone would not be enough. A broad system can easily become totalizing. What makes the PMS ecosystem unusual is that its expansion is paired with repeated internal constraints.

VECTOR should **not** be added to this list as another reason to infer comparative maximality. Its stronger contribution here is corrective: it makes directional and comparative claims themselves more rival-sensitive. E23 records a same-burden case in which a calibrated non-PMS MCDA carries the bounded orientation task more directly and therefore forces real DIR / ROT / StandaloneVECTOR scope reduction.

```text
local maximum candidate
≠
best framework for every bounded orientation task
```

A “local maximum” claim therefore remains candidate-level, domain-bounded, calibration-dependent, and open to rivals that may outperform PMS-derived machinery for particular burdens.

The important claim is therefore not:

> PMS explains everything.

But rather:

> PMS may currently be read as a highly developed candidate for a local maximum of structural legibility for praxis, provided its own limits, calibration needs, rival sensitivity, stop boundaries, non-inheritance rules, and non-capture conditions remain active.

## 24.4 Why the Emergence Process Matters

The origin of the ecosystem matters because it explains why PMS does not feel like a top-down abstraction imposed on examples.

Its structure appears to have been sedimented through repeated encounters with concrete tensions:

- action vs. self-description,
- responsibility vs. blame,
- dignity in practice vs. ontological dignity,
- critique vs. judgment,
- conflict vs. disagreement,
- anticipation vs. prediction,
- logic vs. normativity,
- sexuality vs. identity, instruction, or morality,
- adult reciprocity vs. pseudo-symmetry,
- implementation vs. validation,
- workflow vs. authority,
- stop vs. finding,
- handoff vs. inheritance,
- emergence vs. consciousness overclaim.

The later operator grammar can therefore be read as the formalized residue of a long dialogical compression process.

In PMS terms:

```text
many concrete differences
→ recurrent frames
→ stabilized attractors
→ asymmetry and temporality become explicit
→ recontextualization abstracts the pattern
→ distance prevents person-collapse
→ integration yields a grammar
→ self-binding produces a stack
→ discipline controls use
→ orchestration preserves workflow
→ under load, the stack limits itself
→ STRATA controls how structures may transform
→ VECTOR makes distributed direction explicit and reducible under perspectival and rival pressure
```

This genealogy is not independent evidence of external adequacy. It does, however, help explain the ecosystem's internal density, recurrent distinctions, and developmental continuity.

The system was not built by first asserting a universal schema. It was built by repeatedly refusing premature closure until a more general grammar became necessary.

## 24.5 Humble Scientific Posture

The strongest honest posture is neither modest understatement nor inflated proclamation.

A fair statement would be:

> The PMS ecosystem appears to be an unusually coherent and operationalized candidate for a formal grammar of praxis. It may define a local maximum of structural legibility in its chosen domain, while that assessment remains bounded by current calibration, rival comparison, implementation scope, and non-capture. It does not amount to global completeness, independent empirical adequacy, external warrant, semantic authority, or final authority.

Several boundaries remain decisive:

| Boundary | Meaning |
| --- | --- |
| Legibility is not truth | A readable structure is not automatically a complete structure |
| Portability is not equivalence | Cross-domain mapping does not establish domain identity |
| Implementation support remains typed | Executable artifacts strengthen bounded implementation / artifact claims; they do not by themselves establish PMS Base adequacy |
| Orientation is not authority | Stronger DIR / ROT support does not increase entitlement, rank, or decision authority |
| Self-reduction is not validation | Architecture loss demonstrates reducibility and corrigibility, not external correctness |
| Same-burden rival loss remains real loss | Rival superiority must narrow scope rather than be redescribed as VECTOR success |
| Governance is not tribunal | Guardrails constrain use; they do not establish the model's correctness |
| Discipline is not verdict | Use-boundary records do not decide the case |
| Workflow is not authority | Route preservation and validation reports do not decide meaning |
| Stop is not finding | Non-continuation does not create truth |
| Handoff is not inheritance | Future work starts under its own boundary |
| Self-critique is not final arbitration | PMS can expose itself, but not fully settle itself |
| Non-capture remains open | Some phenomena may resist PMS for good reasons |
| Rival models remain necessary | PMS must remain contestable by other frameworks |

This humility is not decorative. It is structurally required. Without it, PMS would drift into the very failure modes it was built to avoid: totalization, tribunal logic, authority capture, and self-immunization.

## 24.6 What Makes the Achievement Unusual

What is unusual is not simply that a theory, several papers, schemas, prototypes, discipline templates, and tooling were created quickly. The more important point is the kind of structure that emerged:

```text
bottom-up discourse
→ formal grammar
→ domain overlays
→ application cartography
→ computational architecture
→ executable evidence spine
→ emergence specification
→ adjacent maturity model clarification
→ application discipline
→ workflow tooling
→ internal self-critique
→ controlled transformation method
→ bounded meta-reconstructive orientation
```

This is not a normal linear research output. It is closer to a rapidly sedimented ecosystem.

It combines elements that are usually separate:

| Usually Separate | Combined Here |
| --- | --- |
| Praxis theory | PMS operator grammar |
| Anthropology | MIP and dignity architecture |
| Domain analysis | ANTICIPATION, CRITIQUE, CONFLICT, EDEN, LOGIC, SEX |
| Formal mapping | PMS-QC |
| Case methodology | PMS-AXIOM |
| Systems architecture | PMS-STACK |
| Runtime tooling | PMS-RUST |
| Emergence specification | PMS–EM |
| Application discipline | PMS-DISCIPLINE |
| Workflow tooling | PMS-ORCHESTRATOR |
| Self-critique | PMS Under Load |
| Controlled transformation | PMS-STRATA |
| Orientation / perspective-sensitive comparison | PMS-VECTOR |

The result is not just a set of texts. It is a structured field of claims, layers, guards, mappings, implementations, workflow records, stop conditions, and future-use boundaries.

A concise assessment would be:

> The ecosystem is strongest not because it claims everything, but because it repeatedly specifies what each layer may and may not claim.

## 24.7 A Possible One-Sentence Description

For external readers, the simplest description may be:

> PMS is a formal grammar of praxis that makes action, non-action, asymmetry, time, responsibility, conflict, dignity, and self-binding structurally readable without reducing them to psychology or morality.

A slightly fuller version:

> The PMS ecosystem develops this grammar through domain lenses, application schemas, computational architectures, executable prototypes, emergence specifications, use-discipline protocols, workflow tooling, a built-in self-critique, a controlled transformation method that keeps composition, decomposition, and projection bounded and traceable, and a late bounded orientation architecture that can itself lose scope under rival pressure.

A more informal version:

> PMS is a grammar for what happens between people, systems, actions, omissions, power, time, and responsibility before we prematurely call it psychology, morality, politics, or technology.

## 24.8 Final Humble Assessment

What has been created or found here can be described as a **praxeological legibility stack**.

It is not merely a theory of action. It is not merely a maturity model. It is not merely a methodology. It is not merely a technical architecture. It is not merely a runtime experiment. It is a layered ecosystem that asks:

> What must be structurally present for praxis to become legible, drift-capable, corrigible, conflictual, responsible, integrated, self-bound, operationalizable, stoppable, non-inheriting, and still bounded?

> PMS may currently be read as a highly developed candidate for a local maximum of praxeological structure-legibility. Its strength lies in rendering action and non-action structurally readable across domains, while its maturity lies in refusing to turn that readability into final authority.

The ecosystem now makes not only praxis structure but also the conditions of bounded direction more explicit. That additional orientation architecture remains calibration-dependent, rival-sensitive, scope-reducible, and unable to convert stronger orientation into stronger authority.

The honest conclusion is therefore:

> PMS may be a highly unusual candidate for a local maximum of praxeological structure-legibility. Its strength lies in its ability to render action and non-action structurally readable across domains, while its maturity lies in refusing to turn that readability into final authority.

Or, in the shortest possible form:

> PMS is a grammar of praxis with brakes.