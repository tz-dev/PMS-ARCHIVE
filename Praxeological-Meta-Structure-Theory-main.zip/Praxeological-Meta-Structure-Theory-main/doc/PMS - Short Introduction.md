# PMS — Short Introduction

> Ecosystem-level orientation document. PMS.yaml remains the authority source for PMS Base; repository-specific canonical corpora remain authoritative only within their stated scope.

**PMS** stands for **Praxeological Meta-Structure**.

It is an operator-based grammar for rendering praxis structurally legible.

Here, **praxis** does not simply mean action. It means action under conditions: within frames, under expectations, with asymmetries, temporal shifts, open residues, non-occurring events, recontextualizations, attempts at integration, distance requirements, and possible forms of self-binding.

PMS therefore does not begin by asking who is right, who is guilty, what should be morally judged, what a person really thinks, or what kind of person someone is.

It asks:

> Which difference is active?  
> In which frame does it become legible?  
> What remains unintegrated or did not occur?  
> Which attractor stabilizes the situation?  
> Which asymmetry is at work?  
> Which temporal structure changes the situation?  
> What is being recontextualized?  
> Where is distance needed?  
> What is being integrated?  
> What binds itself into future praxis?

The base model works with operators from Δ to Ψ. These operators do not denote psychological traits, moral judgments, diagnostic categories, or person types. They denote structural functions: difference, directed activation, frame, non-event / residue, attractor, asymmetry, temporality, recontextualization, distance, integration, and self-binding.

PMS is not a worldview.

It is not a moral theory.

It is not a psychology.

It is not a clinical diagnostic method.

It is not a legal, forensic, HR, therapeutic, or enforcement apparatus.

It is not a tribunal.

It is not a person-ranking system.

It also does not claim that all reality is ultimately PMS.

PMS is a reconstructive instrument: it makes praxis-shaped situations structurally legible without immediately moralizing them, psychologizing them, diagnosing them, or fixing them onto persons.

The claim of PMS is not to explain praxis once and for all. Its claim is to make recurring praxis structures visible, comparable, testable, typable, and discussable.

In short:

> **PMS is an operator-based grammar for the structural legibility of praxis.**

Or more compactly:

> **PMS is a formalized, generative, and testable reconstructive instrument for praxis-shaped reality.**

Further information, model materials, and repositories:

> [Praxeological Meta-Structure Theory — GitHub](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory)

---

## Where PMS-STRATA fits

**PMS-STRATA** is the controlled transformation-method corpus of the PMS ecosystem. It specifies how PMS structures may be composed, decomposed, and contextually projected across frames, granularities, relative levels, composites, and target functions without changing PMS Base.

STRATA has exactly three operations:

```text
COMPOSE
DECOMPOSE
PROJECT_AS
```

and four Parts:

```text
PATH
SUB
RETYPE
LIMITS
```

`LIMITS` is not an operation. STRATA creates no new PMS primitive, does not modify the canonical Δ–Ψ sequence, and does not inherit authority from a source object. Each transformation is a new bounded and testable claim.

---

## Where PMS-VECTOR fits

**PMS-VECTOR** is the late meta-reconstructive praxeological orientation architecture of the PMS ecosystem. It does not add new PMS Base operators and is not a universal decision system. It asks a narrower question:

> **When can a structural difference warrant bounded direction?**

Its retained core is:

```text
VECTOR := <DIR, ROT>
V_t(O | F, Q, π) := <DIR_t, RP_t>
```

At introduction level:

- `DIR` is a bounded structural direction under a declared comparison question.
- `ROT` is an admissible perspective-testing / discovery operation that must be able to damage the claim it tests.
- `RP` is the stored rotation-test profile, not the operation itself.
- `DIST` remains useful only as a **derived supporting shorthand** for effective orientation–enactment separation; it is not a third core component.

A VECTOR inquiry may end in:

```text
directed result
trade-off
incomparability
revision
suspension
rival superiority
non-capture
```

VECTOR has already undergone real reduction: `DIST` lost core status, **Adult Orientation** lost independent theory status and remains supporting shorthand only, and in **E23** a calibrated same-burden non-PMS rival reduced DIR / ROT / StandaloneVECTOR scope for externally calibrated commensurable multi-criteria orientation problems. Standalone VECTOR is therefore **provisionally retained and scope-reduced**, not protected from further reduction.

For orientation terminology, a few compact firewalls matter immediately:

```text
VECTOR ≠ vector space
DIR ≠ universal rank
ROT survival ≠ truth
orientation robustness ≠ external warrant

Option Invisibility = legibility condition
Option Invisibility ≠ Option Blindness
Option Blindness = unsupported exclusion error
Option Illusion = unsupported inclusion error
Option-Field Misrepresentation = umbrella for Blindness + Illusion
Option-Field Misrepresentation ≠ psychological diagnosis
Unknown ≠ Unavailable ≠ Available

conceivable transformation ≠ effective Second-Order Agency
structural robustness ≠ practical attribution
Being Told ≠ Actor Uptake
constraint-relative necessity ≠ moral obligation
Bounded Test-Burden Closure ≠ final closure
self-reduction ≠ self-validation
rival victory ≠ VECTOR victory
```

**Adult Orientation** means only supporting shorthand for corrigible consequence-carrying praxis. It is not MIP maturity, EDEN Adult Reciprocity, an adult person type, or a person rank.

```text
More orientation does not mean more authority.
```

> **VECTOR makes direction inspectable and pressure-testable; it does not turn direction into final rank, moral command, or external warrant.**

---

## What is PMS?

**PMS** is a praxeological structure grammar for describing, reconstructing, and comparing praxis.

Its central object is not isolated behavior, inner motivation, personality, morality, or factual causality in the narrow empirical sense. Its central object is **structured praxis under conditions**.

A PMS analysis asks how a situation is organized through:

```text
difference
directed activation
frame
non-event / residue
attractor
asymmetry
temporality
recontextualization
distance
integration
self-binding
```

The canonical operator sequence is:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

The operators can be summarized as follows:

| Operator | Name | Structural Function |
| --- | --- | --- |
| Δ | Difference | Minimal distinction, boundary, active difference |
| ∇ | Impulse / directed activation | Directional tension, activation, movement pressure |
| □ | Frame | Contextual boundary, containment, scope |
| Λ | Non-event / residue | Structured absence, delay, omission, unrealized possibility |
| Α | Attractor | Recurrent stabilization, pattern formation |
| Ω | Asymmetry | Gradient of power, exposure, capacity, role, burden, or cost |
| Θ | Temporality | Sequence, trajectory, irreversibility, path-dependence |
| Φ | Recontextualization | Embedding old structures in new contexts |
| Χ | Distance | Reflective separation, suspension, attenuation, stop-capability |
| Σ | Integration | Synthesis into coherent or workable structure |
| Ψ | Self-binding | Commitment, constraint, self-relation across time |

PMS Base remains exactly this Δ–Ψ operator grammar. VECTOR arrives later and asks when an already structured difference may carry bounded direction under declared conditions. `DIR` and `ROT` are not additional PMS Base operators.

```text
PMS structural legibility
≠
VECTOR directional warrant

DIR ≠ ∇
ROT ≠ Φ
```

A recurring PMS preference may become a **VECTOR candidate**. It is not thereby already a VECTOR result.

PMS does not treat these operators as psychological properties. It treats them as structural positions and functions inside praxis.

For example:

- A conflict is not first read as anger or bad communication.
- A critique is not first read as attitude or opposition.
- An omission is not first read as laziness or guilt.
- A sexual configuration is not first read as identity, morality, diagnosis, or person-type.
- A workflow record is not first read as proof.
- A stop is not first read as a verdict.
- A follow-up handoff is not first read as inherited authority.

Instead, PMS asks which structure has stabilized, which differences remain unintegrated, which asymmetries matter, which temporal effects are irreversible, where distance is still possible, and what kind of claim may legitimately be made.

This makes PMS more graspable:

> **PMS is not a worldview, but an operatorics of making-legible.**

It provides a controlled language for showing how praxis is structured under difference, frame, asymmetry, time, recontextualization, distance, integration, and self-binding.

---

## What PMS is not

PMS is easy to overclaim because it is highly portable. It can be used across philosophy, conflict analysis, anticipation, critique, logic, sexuality, mythic / textual reconstruction, case cartography, systems architecture, implementation evidence, emergence specification, maturity analysis, workflow tooling, controlled transformation, and self-critique.

That breadth is a strength.

It is also a risk.

The main reductions are:

```text
legibility ≠ truth
portability ≠ equivalence
coverage ≠ capture
coherence ≠ discrimination
implementation ≠ proof
corpus structure ≠ warrant
reader navigation ≠ authority
workflow completion ≠ epistemic authority
stop ≠ finding
iteration handoff ≠ inheritance
external testing pressure ≠ external warrant
direction ≠ total order
orientation ≠ authority
rotation ≠ proof
rotation survival ≠ truth
option visibility ≠ option availability
option-field typing ≠ option-field truth
structural robustness ≠ practical attribution
bounded test-burden closure ≠ final truth
self-reduction ≠ validation
```

PMS does not claim:

```text
the world is ultimately PMS
all praxis is fully captured by PMS
PMS proves its own correctness
PMS replaces empirical research
PMS replaces law, therapy, diagnosis, ethics, or politics
PMS can rank persons
PMS can certify maturity
PMS can decide dignity
PMS can prove consciousness
PMS can turn workflow records into truth
PMS can make stop records into verdicts
PMS/VECTOR can rank all praxis on one universal scale
PMS/VECTOR can infer real options from conceivable ones
PMS/VECTOR can infer lack of alternatives from invisibility alone
PMS/VECTOR can turn stronger orientation into decision authority
PMS/VECTOR can derive guilt, blame, liability, legitimacy, or moral obligation from structural attributability
```

PMS is strongest when it stays inside its proper scope:

> **productive without becoming self-authorizing, portable without becoming universal proof, corpus-structured without becoming externally warranted, implemented in parts without becoming validated, governable without becoming tribunal, disciplined without becoming verdict, orchestrated without becoming semantic authority, stoppable without making stop a finding, iterative without inheritance, oriented without becoming rank, perspectivally testable without becoming self-immunizing, reducible without treating self-reduction as validation, and self-critical without claiming final self-arbitration.**

---

## Falsifiability / Provability

**PMS is not simply “not proven and not falsified.”**

That would indeed be a bad sign if PMS appeared as an empirical world-thesis, for example:

> “Praxis always works exactly like this, and this is a true theory about the world.”

In that case, unfalsifiability would be fatal.

However, PMS is not best understood as a single empirical hypothesis. PMS is better understood as a **reconstructive grammar**, a **structural instrument**, or a **praxeological coordinate system**.

So not:

> PMS claims: the world is like this.

Rather:

> PMS provides a controlled grammar with which praxis structures can be made visible, comparable, typable, and testable.

This is a different type of object.

A grammar of language is not “proven” like a law of nature. A logic is not “proven” like a measurement hypothesis. A coordinate system is not proven by showing that the world is “really Cartesian.” It is assessed by whether it is consistent, remains discriminating, orders relevant phenomena better than alternatives, does not absorb everything arbitrarily, and remains productive in application.

For PMS, this means:

```text
PMS cannot be simply proven as a whole,
because it is not a single proposition.

But PMS can very well fail.
```

It can fail on several levels:

| Failure Level | Possible Failure |
| --- | --- |
| Formal | The operators are redundant, inconsistent, circular, or arbitrarily independent |
| Reconstructive | PMS merely renames cases without making additional structure visible |
| Discriminative | PMS reads everything but no longer distinguishes anything |
| Calibrational | It cannot be decided in an intersubjectively traceable way when Χ, Λ, Ω, Σ, or Ψ apply |
| Rival-sensitive | Other models explain the same cases more simply, more precisely, or less inflationarily |
| Orientation / rival-reduction | DIR merely renames prior preference; ROT cannot genuinely damage the claim; option errors are used post hoc; calibration is hidden; or a same-burden rival wins without forcing VECTOR scope reduction |
| Practical | YAMLs, reports, readers, Rust implementations, examples, or workflow records look orderly but do not produce robust differential performance |
| Ethical / public | PMS drifts into tribunal language, person-ranking, overclaim, humiliation, diagnosis, or authority apparatus |
| Attribution / normativity | Structural robustness is converted into attribution, obligation, legitimacy, guilt, blame, liability, or authority without the required bridge |
| Layer-specific | Corpus form, implementation, workflow, stop, handoff, orientation, or transformation layers borrow authority from the wrong claim type |

VECTOR strengthens this failure pressure by making direction, perspective dependence, rival loss, option-field error, and architecture reduction explicit. A ROT that only reframes until the claim survives is a failure of the architecture; so is a VECTOR vocabulary that hides external calibration or refuses same-burden rival loss.

This does not turn PMS into a monolithically falsifiable empirical hypothesis.

So PMS is not “unfalsifiable.”

But it is **not monolithically falsifiable** in the way that “All swans are white” is.

More precisely:

> **PMS cannot be defeated by a single counterexample, but it can lose validity through cumulative non-differentiation, poor calibratability, inferiority to rival models, overcoverage, public misuse, or layer drift.**

This is not automatically scientifically problematic. Many serious frameworks work in this way: logics, grammars, modeling languages, methodologies, statistical frameworks, or systems theories. They are not “true” in the same sense as a measurement hypothesis. They are useful, strong, weak, overstretched, elegant, calibratable, generative, rival-sensitive — or not.

What, then, is PMS in the end?

A precise formulation is:

> **PMS is a formal reconstructive grammar for praxis-legibility.**

It does not directly describe “what praxis ultimately is,” but provides operators with which praxis-events, non-events, frames, asymmetries, temporalities, recontextualizations, distances, integrations, and self-bindings can be made structurally legible.

Or, more concretely:

> **PMS is a type system for praxis.**

It does not primarily ask:

```text
What is morally right?
What does this person think?
What is the true cause?
Who is right?
Who is guilty?
```

It asks:

```text
Which difference is active?
In which frame does it become legible?
What remains unintegrated?
Which asymmetry is at work?
Which temporal structure changes the situation?
What is being recontextualized?
Where is distance needed?
What is being integrated?
What binds itself into future praxis?
```

The reduced *Under Load* position captures this status well: PMS is not “the final grammar of praxis,” but a highly productive, bounded, calibration-dependent, direction-bearing, meta-normative grammar for making praxis legible under layer discipline. VECTOR makes the directional burden more explicit and more vulnerable to perspective pressure, option-field correction, rival superiority, and scope reduction; that additional explicitness does not add external warrant.

Its scientific status is therefore:

```text
not proven truth
not mere speculation
not an empirical law
not a mere metaphor
rather: a formalized, applicable, testable reconstructive instrument
```

The testing mode is not:

> Is PMS true or false?

But rather:

> Where does PMS generate more distinction than its rivals?  
> Where does it merely stabilize elegantly?  
> Where do cases remain non-capturable?  
> Where are the operators too coarse?  
> Where are they surprisingly precise?  
> Where are applications intersubjectively traceable?  
> Where do drift, overclaim, workflow authority, stop inflation, or handoff inheritance emerge?

This is why **external testing pressure** is the correct formula.

PMS has not earned external warrant.

But the results already obtained are not epistemically empty: they support the bounded formal, reconstructive, corrective, repository, and implementation claims they actually carry. They do not establish finality, completeness, or unrestricted superiority.

PMS is structured enough to deserve external testing.

---

## Spectrum

PMS is not “universal” in the sense that everything is explained.

But PMS is unusually broad in the sense that many forms of praxis can be read as variants of structural tension under frame, asymmetry, time, residue, recontextualization, integration, and binding.

The hard core is:

> PMS applies wherever something becomes legible as **praxis under conditions**.

That means:

```text
difference
impulse / directed activation
frame
non-event / residue
attractor
asymmetry
temporality
recontextualization
distance
integration
self-binding
```

This is a large spectrum, but not a limitless one.

---

## Spectrum Already Represented

What PMS has already represented is not merely “a few applications,” but several levels of praxis and several repository forms.

| Area / Layer | Current Function | Boundary |
| --- | --- | --- |
| **PMS Base** | Base grammar of praxis-legibility: Δ–Ψ | Base claim, not worldview |
| **Critique** | How irritation, mismatch, or disturbance can become testable correction | Not judgment, attack, or public pillory |
| **Conflict** | Conflict as stabilized incompatibility, cost, binding, tragic non-integration | Not guilt tribunal or mediation automation |
| **Anticipation** | Praxis before the event: non-event, restraint, pre-structuring | Not prediction or control |
| **Logic** | Limits of ought, responsibility, non-closure, post-moral effects | Not hidden ethics machine |
| **EDEN** | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, blocked Σ/Ψ | Not theology, origin proof, gender truth, person typing, maturity ranking, or application authority |
| **SEX** | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, outer legibility, body/boundary coding, withdrawal, covert Ψ-expectation, after-scene dignity, viability / drift | Not sex truth, consent finding, adultness verdict, diagnosis, instruction, or person typing |
| **QC** | Quantum-computational structures rendered through Δ–Ψ macros | Bridge mapping, not proof |
| **AXIOM** | Case-cartography corpus: closure-demands as YAML / Markdown case artifacts with schema, index, overlays, prompts, templates, and reader navigation | Case readability, not empirical proof |
| **STACK** | Architecture-specification corpus: PMS as OS, CPU, language, runtime, security, networking, distributed-systems architecture | Architecture specification, not completed implementation |
| **RUST** | Implementation workspace / executable evidence spine: deterministic runtime, PMS.yaml validation, REPL, JSONL audit, vFS, AI proposal gate, tests, demos | Implementation / artifact evidence, not PMS Base validation |
| **EM** | Emergence / developmental-architecture corpus: trace-backed regularity, diary safety, measurement scaffolds, projection, auditability, reader | Emergence pressure, not consciousness proof |
| **MIP/AHP** | Adjacent maturity model, governance, application discipline, attack-surface visibility, hardening, precision | Not PMS dependency, not person ranking, not tribunal, not evidentiary upgrade |
| **DISCIPLINE** | Application-discipline / use-boundary layer: Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, stop-capability, Case Records, Iteration Handoff, article boundary | Use-boundary, not validation or verdict |
| **ORCHESTRATOR** | Workflow runner / case-production tool: prompt staging, route state, raw output preservation, structural YAML validation, review gates, handoff / article routes, confirmed stop enforcement | Workflow tooling, not semantic authority |
| **Under Load** | Self-critique of the whole system: calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, stop, handoff, workflow | External testing pressure, not external warrant |
| **STRATA** | Controlled transformation-method corpus for composing, decomposing, and contextually projecting PMS structures across frames, granularities, relative levels, composites, and functions | Method extension, not new base grammar, primitive, ontology, or inherited authority |
| **VECTOR** | Late meta-reconstructive orientation architecture for bounded direction, perspectival pressure, option-field discrimination, Second-Order Agency, consequence/timing relations, rival comparison, and reducible practical attribution | Not PMS Base, universal scale, decision procedure, moral authority, person rank, endogenous calibration source, or specialist-method replacement |

This is already a broad spectrum: individual, relational, conflictual, sexual, logical, anticipatory, philosophical, governance-adjacent, technical, implementation-adjacent, emergence-adjacent, workflow-supported, application-disciplined, transformation-controlled, and self-critical.

But breadth itself does not establish comparative superiority or external warrant.

It creates pressure.

The correct reading is:

```text
QC = bridge stress, not proof
STACK = architecture-specification pressure, not completed implementation
RUST = implementation / artifact evidence, not PMS Base validation
EM = emergence / developmental-architecture pressure, not consciousness proof
MIP/AHP = adjacent governance / application-discipline / hardening, not tribunal
AXIOM = case-cartography / schema-inspection corpus, not empirical warrant
DISCIPLINE = use-boundary / stop-capability layer, not validation
ORCHESTRATOR = workflow tooling, not semantic authority
STRATA = controlled transformation method, not a fourth operation, new primitive, or authority upgrade
VECTOR = bounded orientation / pressure architecture, not universal rank or authority
same-burden rival loss = scope reduction, not VECTOR validation
Reader = navigation / inspection, not validation
Under Load = testing pressure, not warrant
```

---

## Repository Forms

The PMS ecosystem no longer consists only of papers.

It now contains several different repository forms:

```text
paper-form lenses
corpus-form repositories, including controlled transformation-method corpora
implementation workspace / executable evidence spine
application-discipline layer
workflow runner / case-production tool
paper-led meta-reconstructive orientation repository
closure / self-critique paper
```

These forms overlap in vocabulary, examples, YAML, models, readers, case materials, validation language, and artifact structures.

They must not be collapsed into one another.

### Paper-form lenses

The paper-form lenses include:

```text
PMS–ANTICIPATION
PMS–CRITIQUE
PMS–CONFLICT
PMS–EDEN
PMS–LOGIC
PMS–SEX
PMS–QC
```

They primarily publish one bounded PMS lens or bridge. They may include examples, YAML models, model specifications, and supporting materials. Their function is domain or bridge stress.

They do not become PMS Base.

### Corpus-form repositories

The corpus-form repositories are:

```text
MIP
PMS-STACK
PMS-AXIOM
PMS–EM
PMS-STRATA
```

They differ in object:

| Repository | Corpus Object | Reader Object | Claim Boundary |
| --- | --- | --- | --- |
| MIP | Praxeological anthropology corpus | MIP model, examples, YAML, specifications, dignity / IA search | Model corpus, not person validation |
| PMS-STACK | Architecture-specification corpus | Canonical architecture blocks, references, evidence map, minified contracts | Architecture specification, not completed implementation |
| PMS-AXIOM | Case-cartography corpus | Markdown / YAML cases, prompts, templates, schema, index, overlays | Case inspection, not empirical proof |
| PMS–EM | Emergence / developmental-architecture corpus | Owner blocks, appendices, reference / audit files, minified material | Emergence-boundary pressure, not consciousness proof |
| PMS-STRATA | Controlled transformation-method corpus | Canonical blocks, appendices, cases, reference kernel, minified controls, formal model, reader | Transformation-method pressure, not new PMS primitives, truth, diagnosis, or authority |

The shared pattern is:

```text
canonical blocks
supporting source / reference layers
minified or contract layers
model / case / derivative layers
reader navigation
claim-boundary discipline
```

The shared reduction is:

```text
corpus form increases inspection pressure.
corpus form does not increase validation authority.
```

### Implementation workspace

PMS-RUST should not be grouped with the corpus-form repositories.

It is an implementation workspace / executable evidence spine.

It is organized around:

```text
Rust crates
model data
REPL / script runner
kernel execution
stateful validation
JSONL traces
vFS service surface
AI proposal bridge
demos
tests
acceptance gates
documentation
```

Its boundary is:

```text
PMS-RUST = implementation / artifact evidence
not PMS Base validation
not corpus-form specification
not completed PMS-STACK
```

### Application discipline

PMS-DISCIPLINE is not a paper-form lens, not a corpus-form repository, and not workflow software.

It is a methodological layer for responsible PMS use. It defines use-boundaries, path-selection, Core-entry discipline, add-on restraint, MIP/AHP routing, claim ceilings, stop-capability, Case Record discipline, human confirmation, article boundaries, and Iteration Handoff.

Its boundary is:

```text
PMS-DISCIPLINE = application discipline
not PMS Base validation
not governance authority
not verdict machinery
not person ranking
```

### Workflow runner

PMS-ORCHESTRATOR is not PMS Base, not PMS-DISCIPLINE theory, and not semantic review.

It is a local human-guided runner for discipline-subjected case work. It stages prompts, preserves route state, stores raw outputs, stages checked artifacts, performs local structural YAML validation, supports route decisions, handoff review, article routes, follow-up case creation under renewed boundary, and confirmed stop enforcement.

Its boundary is:

```text
PMS-ORCHESTRATOR = workflow tooling
not semantic authority
not source of truth
not validator
not follow-up authority
```

### Meta-reconstructive orientation repository

PMS-VECTOR is neither a paper-form domain lens nor a classical corpus-form repository. It is a **paper-led meta-reconstructive orientation repository**.

Its authority order is deliberately asymmetric:

```text
PMS-VECTOR.md
→ paper-owned theory

model/PMS-VECTOR.yaml
→ machine-readable representation

templates
→ audit / record scaffolds

claim provenance / dependency map
→ traceability

E01–E23
→ paper-linked internal conformance / adversarial fixtures

Reader / Graph Lab
→ navigation, inspection, and cross-file consistency pressure
```

The boundary is:

```text
model consistency ≠ theoretical adequacy
case count ≠ evidential weight
case suite ≠ empirical validation
provenance completeness ≠ warrant
reader self-test ≠ VECTOR validity
graph rendering ≠ analytical finding
```

### Reader boundary

Several repositories include readers. This similarity matters, but it does not make the repositories equivalent.

The correct comparison is:

```text
MIP Reader navigates a maturity-model corpus.
PMS-STACK Reader navigates an architecture-specification corpus.
PMS-AXIOM Reader navigates a case-cartography corpus.
PMS–EM Reader navigates an emergence / developmental-architecture corpus.
PMS-STRATA Reader navigates a controlled transformation-method corpus.
PMS-VECTOR Reader navigates and inspects a paper-led orientation repository, including declared case pressure, option-field records, dependencies, and reductions.
```

The shared reader reduction is:

```text
reader navigation ≠ authority
reader access ≠ validation
reader search ≠ proof
reader convenience ≠ source replacement
reader graph ≠ semantic geometry
option-record filtering ≠ option-field finding
reader self-test ≠ theory validation
```

---

## Possible Spectrum

The possible PMS spectrum is large, but it has a clear condition:

> PMS is strong where a field is **praxis-shaped**.

That means wherever actors, roles, frames, expectations, omissions, non-events, costs, bindings, escalations, integration attempts, recontextualizations, or self-bindings are involved.

Potentially suitable areas include:

```text
ethics / metaethics / responsibility / guilt / moral luck
pedagogy, maturity, development, learning
conflict analysis, mediation, organizations
political and institutional praxis
philosophy of law, but not as legal judgment
AI governance / AI alignment / human-AI interaction
workflow governance and tool authority analysis
developmental robotics / artificial life / synthetic agency
software and systems architecture, if read as praxis or runtime structure
religious, mythic, and textual analysis, insofar as these are read as praxis structures
cultural and social theory, but only with clean rival-sensitivity
bounded comparative orientation / option-space analysis under perspectival and rival pressure
```

Less suitable or only indirectly suitable areas include:

```text
pure physics without praxis-reference
mere statistics without action or frame structure
clinical diagnosis
legal decision-making
empirical causal claims without additional data
proof of consciousness
attribution of personhood or rights
moral tribunal
sexual instruction
person ranking
maturity verdicts
automated governance decisions
```

PMS–EM illustrates this boundary well: PMS–EM may make developmental regularities, traceability, diary safety, measurability, projection, and auditability visible; but it must not derive consciousness, sentience, personhood, subjective experience, or rights claims from them.

PMS–SEX illustrates the boundary in another way: PMS–SEX may make sexual-praxeological configurations inspectable under cost topology, asymmetry, body/boundary coding, direct otherness, withdrawal, and after-scene dignity; but it must not become sex truth, adultness verdict, consent finding, diagnosis, instruction, or person typing.

PMS-DISCIPLINE and PMS-ORCHESTRATOR illustrate the boundary at the level of use: a system may become more disciplined and workflow-supported without becoming more true.

PMS-STRATA illustrates the boundary at the level of transformation: composing, decomposing, or projecting a PMS structure creates a new testable claim. It does not modify PMS Base, erase an earlier failure, or inherit authority from the source object.

PMS-VECTOR illustrates the boundary at the level of orientation. It can pressure bounded comparative claims across perspectives and option fields, but it is not a general decision system. For externally calibrated, commensurable multi-criteria problems, a specialized MCDA model may carry the same burden more directly; in that case VECTOR itself requires rival deference and scope reduction.

---

## Why PMS Is Not Immediately Easy to Grasp

PMS is not an ordinary theory object.

It is not simply:

> A theory about X.

Rather:

> A grammar with which many X can be made legible as praxis structures.

This is why PMS can move between philosophy, ethics, conflict, sexuality, technology, emergence, organization, AI governance, workflow tooling, controlled transformation, and self-critique. At first, this can seem hard to grasp because PMS does not primarily have a domain of objects, but a **domain of form**.

Its domain is not “sex,” “conflict,” “AI,” “metaphilosophy,” “workflow,” “implementation,” or “emergence.”

Its domain is:

> **structured praxis under difference, frame, asymmetry, time, recontextualization, distance, integration, and binding.**

This is more abstract.

It is also why PMS is portable.

But portability creates risk. A highly portable grammar can begin to look stronger than it is. It can make many things readable without establishing that it has captured them. It can stabilize objections too quickly. It can generate coherence before discrimination has been externally tested.

Even after a situation has become structurally legible, a further question remains open: does the structured difference actually carry direction, and if so under which declared perspective, question, time, calibration, option field, and consequence relation?

```text
legibility precedes orientation;
orientation remains separately burdened.
```

PMS is therefore not a grammar plus a built-in ranking system.

This is why PMS must remain typed, bounded, calibratable, rival-sensitive, and interruptible.

---

## The Precise Boundary

The boundary is not:

> PMS can do everything.

Rather:

> PMS can make a great deal visible, as long as its own access remains typed, bounded, calibratable, rival-sensitive, and interruptible.

This is the *Under Load* reduction.

PMS remains strong only where its power remains:

```text
typed
bounded
calibratable
rival-sensitive
interruptible
orientation-bounded
perspectivally pressure-testable
option-status explicit
reducible under same-burden rivalry
non-authoritative by orientation
non-tribunal
non-validating by artifact
non-authoritative by workflow
non-verdictive by stop
non-inheriting by iteration
```

It has not earned external warrant.

It has earned external testing pressure.

It follows that:

```text
Spectrum already represented:
unusually broad and already strongly differentiated.

Possible spectrum:
very large wherever praxis structures are at work.

Boundary:
PMS must not confuse legibility with truth,
coverage with capture,
corpus form with warrant,
implementation with validation,
workflow with authority,
stop with finding,
structuring with proof,
direction with rank,
rotation with immunity,
option visibility with availability,
orientation robustness with attribution,
or self-reduction with validation.
```

A compact formula is:

> **PMS is not an everything-explainer, but a broadly applicable structural interface for praxis-shaped reality.**

The spectrum does not automatically determine where PMS should actually be used. A field may be praxis-shaped and therefore legible through PMS without PMS already being the best or most obvious tool for that field.

A distinction must therefore be made between **possible applicability** and **optimal use**.

PMS is not equally strong everywhere.

It is especially suitable where what is at stake is not merely events, data, opinions, or preferences, but structured situations: frames, roles, asymmetrical costs, unmet expectations, temporal shifts, stabilization moves, open residues, blocked integration, and binding costs.

---

## Use Areas

PMS is optimal wherever praxis must be read not simply as action, but as a structured situation under frame, asymmetry, time, residue, recontextualization, distance, integration, and binding.

The strongest use areas can be ordered as follows:

| Rank | Area | Why PMS is especially strong there |
| --- | --- | --- |
| **1** | **Metaphilosophy / persistent philosophical problems** | Almost an ideal field. Closure-demands, frames, Λ-residues, and Σ-closure moves fit very well. PMS does not necessarily solve problems; it maps their persistence. VECTOR can additionally distinguish local direction, trade-off, incomparability, suspension, and non-capture without turning them into a universal rank. |
| **2** | **Conflict analysis / mediation / escalation analysis** | Conflicts are often stabilized non-integration: asymmetrical costs, bound positions, lost reversibility, false symmetry. PMS can do a great deal here without becoming a guilt tribunal. VECTOR can make option invisibility, unsupported exclusion/inclusion, role-relative option fields, and transformability more explicit without becoming a decision engine. |
| **3** | **Organizational analysis / governance / process failure** | Very suitable for asking “What structurally happened here?” rather than “Who is to blame?” Especially where roles, responsibility diffusion, decision drift, failed integration, or stack / layer confusion are involved. VECTOR can additionally inspect option-field constraints, effective Second-Order Agency, consequence distribution, and orientation-mediated changes in structural attributability. |
| **4** | **AI governance / human-AI interaction / alignment-adjacent analysis** | PMS is strong where interaction, responsibility shifting, tool authority, prompt / system frames, publicness, implementation drift, workflow authority, and stop-capability must be distinguished. |
| **5** | **Metaethics / responsibility / moral luck / guilt without tribunal** | PMS can read responsibility structurally without immediately moralizing. It is especially strong for control vs. outcome, temporality, Ω-asymmetry, and retrospective evaluation. VECTOR can make orientation-mediated attribution changes more explicit, but only under uptake, capacity, consequence, role, and time conditions; structural attributability is not guilt, blame, liability, or moral obligation. |
| **6** | **Pedagogy / maturity / developmental observation** | With MIP/AHP, this is natural: trajectories instead of labels, maturity as enactment, dignity in practice, no person-ranking. Useful for learning, development, and reflection processes, as long as it is not misused diagnostically. |
| **7** | **Critique and discourse analysis** | PMS-CRITIQUE is especially fitting here: when does irritation become correction; when does critique become judgment, pose, shaming, or mere distance? Suitable for public debate, academic critique, and online discourse. |
| **8** | **Anticipation / risk / non-events / preventive praxis** | PMS is unusually strong with things that do not happen: avoidance, restraint, preparation, non-escalation, protection through structure. Many models are event-focused; PMS can read non-events. |
| **9** | **Intimacy, sexuality, consent-adjacent validity pressure, binding** | Strong, but publicly sensitive. PMS–SEX can read cost topology, direct otherness, outer legibility, withdrawal, boundary language, and after-scene dignity only under strict no-person, no-diagnosis, no-consent-finding, no-adultness-verdict discipline. |
| **10** | **Application discipline / analysis governance** | PMS-DISCIPLINE is strong where the issue is whether PMS should enter a case, which route is justified, whether claims must be reduced, when stop is binding, and what future work may not inherit. |
| **11** | **Workflow-supported case generation** | PMS-ORCHESTRATOR is useful where PMS-DISCIPLINE case work needs route-state preservation, raw-output preservation, structural YAML validation, checked artifacts, handoff review, article routing, and confirmed stop enforcement without semantic authority. |
| **12** | **Software / systems architecture, runtime, audit, spec design** | PMS is suitable where architecture is read as praxis structure: layers, dependencies, gating, traceability, validation, interface, drift. PMS-STACK and PMS-RUST already show this direction. |
| **13** | **Developmental robotics / artificial life / emergence testbeds** | PMS–EM is the relevant branch here: development, prediction, attachment dynamics, diary, MIP trajectories, auditability — but strictly without consciousness, sentience, personhood, or rights-status claims. |
| **14** | **Textual, mythic, religious, and cultural reconstruction** | PMS–EDEN shows that texts can be read as praxis structures: Adult Reciprocity, false-coordinated real Ω, responsibility displacement, pseudo-symmetry, Reciprocity Loss, blocked Σ/Ψ. Strong when not overloaded theologically or psychologically. |

The most suitable fields are therefore:

> **Metaphilosophy, conflict, organization / governance, metaethics / responsibility, AI governance, critique praxis, anticipation, application discipline, and workflow-supported case generation.**

PMS is especially strong in these areas because they all suffer from the same kind of problem: there are not only facts, but frames, asymmetrical roles, unmet expectations, residual structures, temporal shifts, stabilization moves, stop conditions, and binding costs. Across these areas, PMS-STRATA is relevant whenever structures must be composed, decomposed, or projected across frames, granularities, relative levels, composites, or contextual functions without losing type integrity, traceability, or claim boundaries. PMS-VECTOR is relevant where already structured alternatives must be compared under explicit perspective, option status, consequence, timing, reversibility, or rival pressure; it must yield where a calibrated same-burden specialist method carries that task more directly.

PMS is less optimal where something else is actually needed: measurement data, causal statistics, clinical diagnosis, legal judgment, technical performance benchmarks, natural-scientific explanation, sexual instruction, final moral evaluation, or automated decision authority.

> **PMS is optimal wherever a situation is not understood by asking “What happened?” but by asking “Which praxis structure has stabilized — and what remains unintegrated within it?”**

The use areas show two things at once: PMS is broad enough to make very different praxis fields structurally legible, and it is bounded enough not to appear as a general world-formula.

Its strength does not lie in explaining all fields in the same way, but in distinguishing where praxis under conditions is stabilized, shifted, blocked, integrated, stopped, handed off, or bound.

---

## Layer Discipline in One View

The current PMS ecosystem requires strict layer discipline.

| Layer | Correct Status | Not |
| --- | --- | --- |
| PMS Base | Source of truth for Δ–Ψ | Worldview, moral theory, total explanation |
| Domain lenses | Domain stress / application layers | New base grammars |
| Add-ons | Precision / hardening / application layers | Primitives or proof |
| MIP/AHP | Adjacent governance / application discipline / analysis hardening | Tribunal, rescue layer, evidentiary upgrade |
| QC | Bridge mapping | Physical proof |
| PMS-STACK | Architecture-specification corpus | Completed implementation |
| PMS-RUST | Implementation workspace / artifact evidence | PMS Base validation |
| PMS–EM | Emergence / developmental-architecture corpus | Consciousness proof |
| PMS-AXIOM | Case-cartography / schema-inspection corpus | Empirical warrant |
| PMS-DISCIPLINE | Application-discipline / use-boundary layer | Verdict authority |
| PMS-ORCHESTRATOR | Workflow runner / structural-validation tooling | Semantic authority |
| PMS-STRATA | Controlled transformation-method corpus | New PMS primitive, fourth operation, automatic target function, or authority inheritance |
| PMS-VECTOR | Late meta-reconstructive orientation / pressure architecture | PMS Base extension, universal rank, decision authority, moral engine, endogenous calibration source, or specialist-method replacement |
| Pipeline Stop | Pipeline-control / non-continuation disposition | Finding, diagnosis, verdict |
| Iteration Handoff | Follow-up preparation / non-inheritance discipline | Authority transfer |
| Readers | Navigation / inspection tools | Validation layers |
| Under Load | Self-critique / external testing pressure | External warrant |

The governing rule is:

```text
A claim becomes unstable when it borrows authority
from a layer other than the one in which it is made.
```

For VECTOR in particular:

```text
DIR ≠ ∇
ROT ≠ Φ
ROT ≠ PROJECT_AS
DIST ≠ Χ
```

This is the ecosystem’s most important internal discipline.

---

## Stop, Handoff, and Workflow Boundaries

The newer PMS ecosystem makes stop-capability and iteration boundaries explicit.

This is important because a grammar can be powerful and still be unsafe in use if it cannot stop, if stopped workflows can re-enter through reframing, or if future work inherits authority from prior work.

The current reductions are:

```text
Stop controls continuation.
It does not create truth.
```

```text
Iteration prepares future work.
It does not transfer authority.
```

```text
Workflow stages discipline-subjected work.
It does not decide meaning.
```

```text
A new STRATA transformation creates a new testable claim.
It does not repair, erase, or inherit an earlier claim.
```

VECTOR introduces a different closure type:

```text
Bounded Test-Burden Closure
≠
STRATA Stop
≠
PMS-DISCIPLINE Pipeline Stop
≠
final truth / final closure
```

Bounded Test-Burden Closure means that the declared current VECTOR test burden has been carried far enough for that claim under the stated conditions. New evidence, a new rival, changed scope, or disputed calibration may reopen it. A STRATA Stop governs transformation/admissibility; a Pipeline Stop governs whether the current DISCIPLINE workflow may continue. None is a truth certificate, and a confirmed DISCIPLINE stop may not be bypassed by VECTOR reframing.

The key distinctions are:

```text
requested-output disposition
≠
pipeline-case disposition
≠
final analytical decision state
```

```text
stop ≠ seventh final analytical decision state
Pre-Analysis stop ≠ Core finding
blocked Core entry ≠ analytical conclusion
confirmed stop ≠ truth certificate
person-near stop ≠ person judgment
protection stop ≠ diagnosis
```

```text
current sufficiency
≠
iteration value
≠
iteration urgency
≠
follow-up-case preparation
```

A follow-up case may inherit context and lineage.

It may not inherit:

```text
findings as evidence
route decisions as route authority
operator statuses as current activations
add-on selection
MIP/AHP status
claim ceiling
sufficiency status
article wording as established truth
```

Article outputs are not sources for Iteration Handoff.

This may sound procedural, but it is conceptually important. PMS becomes more responsible not because procedural records create stronger truth, but because it becomes better at reducing what may be carried forward and at keeping distinct kinds of stop from borrowing authority from one another.

---

## Controlled Transformation Boundary

PMS-STRATA specifies exactly three operations:

```text
COMPOSE
DECOMPOSE
PROJECT_AS
```

They operate under four Parts:

```text
PATH
SUB
RETYPE
LIMITS
```

`LIMITS` is not an operation and not a meta-level. STRATA does not alter Δ–Ψ, create new PMS primitives, or convert a contextual target function into an origin type.

Its admissibility band is ordered correctly as:

```text
Praxeological Traceability Ceiling
─────────────────────────────
admissible transformation
─────────────────────────────
Praxeological Relevance Floor
```

Below the floor lies distinction without praxeological purchase. Above the ceiling lies abstraction without traceable load. Formal elegance or additional detail cannot compensate for missing relevance, traceability, type integrity, or boundedness.

The governing reduction is:

```text
new transformation = new testable claim
more structure ≠ more authority
```

VECTOR remains adjacent but distinct:

```text
ROT ≠ PROJECT_AS
perspective change ≠ analytical retyping
```

ROT tests or explores orientation under a declared perspective change. `PROJECT_AS` gives an independently identified origin-typed source object a bounded contextual target function while preserving source reference and origin type and declaring target context/function and Transformation Loss.

If a supposed rotation materially changes granularity, level, composition, frame, or target function so that the reference is retyped, the new result is not same-claim robustness evidence. It becomes an exploratory probe or a separately burdened STRATA transformation.

```text
changing granularity or target function
cannot rescue a failed DIR
as though the same claim had survived.
```

---

## Conclusion

PMS is not a proof apparatus, not a world-formula, and not a moral tribunal.

It is a praxeological structure grammar that makes praxis legible where action, non-action, frame, asymmetry, time, residue, recontextualization, distance, integration, and self-binding interlock.

Its strength does not lie in explaining everything, but in precisely distinguishing recurring praxis structures, making them comparable, and keeping their respective claim-boundaries visible.

The current PMS ecosystem is now broader than a single theory paper. It includes:

```text
paper-form domain lenses
corpus-form repositories
controlled transformation-method corpus
implementation workspace / executable evidence spine
application-discipline layer
workflow runner
paper-led meta-reconstructive orientation repository
self-critique / closure paper
```

The ecosystem now also contains a late orientation architecture that asks when structural difference may carry bounded direction, how that direction survives relevant perspective pressure, how option fields can be misrepresented in both directions, and when the architecture itself must reduce under rival superiority or redundancy.

```text
orientation ≠ authority
perspectival robustness ≠ truth
option-field discrimination ≠ decision entitlement
architecture reduction ≠ validation
```

That ecosystem is strong.

But its strength is not warrant.

The appropriate assessment is therefore neither:

> PMS is finally proven.

nor:

> PMS is mere speculation.

More precisely:

> **PMS is a formalized, generative, and testable reconstructive instrument for praxis-shaped reality.**

The final reduced position is:

```text
PMS has not earned external warrant.
It has earned external testing pressure.
```

Or, in the shortest possible form:

> **PMS is a grammar of praxis with brakes.**

Further information, model materials, and repositories:

> [Praxeological Meta-Structure Theory — GitHub](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory)