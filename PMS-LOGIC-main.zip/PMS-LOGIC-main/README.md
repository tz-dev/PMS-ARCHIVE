# PMS–LOGIC

## Purpose

**PMS–LOGIC** is a paper-form PMS lens for structural responsibility, logical limits, non-closure, and post-moral effects.

It reads how responsibility and moral readability can become structurally legible without deriving obligation, moral law, person value, blame, or final justification.

Compact boundary:

```text
responsibility readability ≠ obligation
logical structure ≠ moral law
non-closure ≠ failure
post-moral effect ≠ verdict
```

---

## Ecosystem Position

PMS–LOGIC belongs to the PMS paper-form lens family.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies the Δ–Ψ operator grammar. |
| PMS-CRITIQUE | Neighboring lens for correction, interruption, and publicness drift. |
| PMS-ANTICIPATION | Neighboring lens for responsibility under future-oriented uncertainty. |
| PMS-CONFLICT | Neighboring lens where non-integration becomes terminal. |
| PMS-STRATA | Later discipline for reading level shifts, projections, and reduced signatures. |
| PMS-DISCIPLINE | Required where LOGIC is applied in person-near or decision-adjacent contexts. |

---

## Repository Form

This is a **paper-form PMS lens repository**.

| Material | Function |
| --- | --- |
| Main paper | Structural responsibility, logical limits, post-moral effects, and self-bindings. |
| `model/PMS-LOGIC.yaml` | Add-on specification. |
| Model specification | Human-readable explanation of model fields. |
| Example suite | Uniform structural stress tests. |

---

## Core Thesis

PMS–LOGIC treats responsibility as structural attributability under conditions of capacity, distance, frame, temporality, asymmetry, and binding.

It does not derive obligations. It reconstructs how moral readability and post-moral effects can appear after praxis structures have already made responsibility legible.

---

## What the Overlay Adds

`PMS.yaml` gives the operator grammar. `PMS-LOGIC.yaml` adds a bounded responsibility and logic profile.

| Addition | Function |
| --- | --- |
| Tripartition as reduced signatures | Named structural checkpoints without new PMS primitives. |
| Moral readability field | Moral language appears as derived interpretive field, not operator. |
| Effective capacity boundary | No effective capacity means no responsibility attribution inside the profile. |
| Drift typology | Tracks closure-authority, pseudo-normativity, blame drift, and moral overreach. |
| PMS-internal self-binding constraints | Reconstructs apparent norms as constraints, not imperatives from a lawgiver. |
| Axes projection | Allows structural compression without person evaluation. |
| Counter-readings | Adds misuse resistance and alternate readings. |
| Uniform test-vector schema | Supports examples and tooling-facing scene packets. |

---

## Scene Packet

A minimal scene packet should make the following explicit:

```text
scene boundary
actors / role-positions
source basis
frame
distinction
capacity conditions
asymmetry
temporality
distance
integration pressure
self-binding
non-closure residue
claim ceiling
```

The scene packet does not determine the answer. It prevents untracked moral or logical overreach.

---

## Structural Contributions

| Contribution | Short orientation | Where to read |
| --- | --- | --- |
| Logic with a Limit | Λ is carried rather than eliminated. | Main paper, non-closure sections. |
| Responsibility without Norms | Responsibility is reconstructable without deriving obligation. | Responsibility sections. |
| Morality as Readability Field | Moral phenomena are non-operator effects. | Moral readability sections. |
| Self-Bindings without Lawgiver | Self-bindings constrain praxis without becoming external commands. | Self-binding sections. |

---

## Validity Gate

Application use requires:

```text
Χ / Distance
reversibility
Dignity-in-Practice
effective capacity boundary
no global person labels
no moral verdict by structural shortcut
```

Invalid use:

```text
responsibility → guilt
readability → obligation
capacity → worth
moral field → moral law
self-binding → coercive command
```

---

## Model and Examples

The model layer contains the add-on specification and human-readable model materials.

The example suite functions as uniform structural stress tests for:

```text
capacity boundaries
responsibility attribution
non-closure
moral readability
self-binding
counter-readings
drift and misuse
```

Examples do not validate the theory and do not authorize judgments outside their scene boundary.

---

## Intended Use

PMS–LOGIC is intended for structural analysis of responsibility, logical limit, and post-moral effects.

It is not intended for moral judgment automation, legal guilt assignment, theology, normative proof, person ranking, clinical inference, or final closure.

---

## Reading Path

Recommended path:

```text
README
→ main paper
→ what the overlay adds
→ scene packet
→ structural contributions
→ model/PMS-LOGIC.yaml
→ examples/
```

---

## Status

PMS–LOGIC is a bounded paper-form PMS lens.

Its current status is:

```text
responsibility-oriented
non-closure-aware
post-moral
application-gated
non-prescriptive
non-validating
```


---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS–LOGIC DOI | [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19440215.svg)](https://doi.org/10.5281/zenodo.19440215) |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing this repository, cite the repository release and DOI corresponding to the version used. Do not cite this project as if it validates PMS Base, replaces neighboring PMS layers, or licenses claims beyond its declared scope.

---

## License

Unless otherwise noted, textual theory, papers, documentation, examples, prompts, diagrams, and non-executable model or specification materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
