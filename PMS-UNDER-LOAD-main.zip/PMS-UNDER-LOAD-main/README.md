# PMS — UNDER LOAD

## Purpose

**PMS — UNDER LOAD** is the structural self-critique repository for PMS.

It tests PMS under the conditions that make it powerful: calibration, coverage, stack drift, Φ drift, meta-normativity, success traps, domain drift, bridge stress, publicness, self-application, implementation pressure, workflow pressure, stop/handoff pressure, reader pressure, corpus pressure, STRATA pressure, and VECTOR pressure.

VECTOR adds a later orientation-specific burden: whether bounded direction, perspectival pressure, option-field discrimination, attribution changes, rival comparison, and architecture self-reduction remain discriminating under pressure rather than becoming new stabilization devices.

Guiding question:

```text
Where does PMS stop distinguishing — and start stabilizing?
```

Reduced result:

```text
PMS survives Under Load not as final grammar,
but as a highly productive, bounded, self-limiting grammar of praxis legibility.
```

The current VECTOR integration makes that reduction more concrete: PMS-VECTOR has already surrendered DIST core status, independent Adult-Orientation status, and part of DIR/ROT and standalone scope under same-burden rivalry.

---

## Ecosystem Position

UNDER LOAD is a **paper-form systemic self-critique and closure-pressure repository**. “Closure” here means ecosystem-level synthesis and pressure on development claims, not epistemic final closure.

It does not replace PMS Base, introduce new PMS operators, convert success into unrestricted warrant, or claim final self-arbitration. Its role is to ask where PMS becomes too productive, too portable, too public, too self-confirming, too orienting, or too well-tooled.

| Neighboring layer | UNDER LOAD pressure |
| --- | --- |
| PMS Base | Can the operator grammar over-stabilize what it reads? |
| PMS-STACK / PMS-RUST | Does architecture or executable evidence become mistaken for wider theoretical adequacy? |
| PMS-AXIOM / PMS-EM / MIP | Does corpus form become proof, developmental law, person ranking, or governance-hardening? |
| PMS-DISCIPLINE | Does application discipline become verdict authority? |
| PMS-ORCHESTRATOR | Does workflow completion become semantic authority? |
| PMS-STRATA | Does granularity control become meta-PMS, ontology, or immunity machinery? |
| PMS-VECTOR | Does bounded direction become rank, ROT become reframing immunity, option typing become option truth, self-reduction become self-validation, or rival loss become hidden VECTOR success? |

Compact relation:

```text
PMS-VECTOR makes bounded direction more inspectable.
UNDER LOAD asks whether that new orientation machinery
distinguishes under pressure
or becomes another stabilization device.
```

---

## Repository Form

This is a **paper-form systemic self-critique and closure-pressure repository**.

| Material | Function |
| --- | --- |
| `PMS - UNDER LOAD.md` | Main self-critique paper. |
| `PMS - UNDER LOAD.pdf` / `.html` | Publication-facing renderings. |
| README | Ecosystem orientation, boundary, and navigation layer. |

The README is not a shortened replacement for the paper. It marks the repository’s function and routes readers to the full argument.

---

## Current Layer Status

UNDER LOAD treats the expanded PMS ecosystem as a stack of bounded claims, not as cumulative proof.

```text
PMS Base          → operator grammar / theory core
PMS add-ons       → bounded paper-form lenses and bridge layers
MIP/AHP           → adjacent application / hardening layers under constraint
PMS-AXIOM         → downstream case-cartography / schema-inspection pressure
PMS-STACK         → architecture-specification / implementation-layer pressure
PMS-RUST          → bounded implementation / artifact evidence
PMS–EM            → emergence / developmental-architecture pressure
PMS-STRATA        → transformation / granularity / projection discipline
PMS-VECTOR        → late meta-reconstructive orientation / rival / option-field / reduction pressure
PMS-DISCIPLINE    → application-discipline / use-boundary / stop-capability layer
PMS-ORCHESTRATOR  → workflow-tooling / structural-validation / provenance-preservation layer
Pipeline Stop     → pipeline-control / non-continuation disposition, not finding
Iteration Handoff → bounded follow-up preparation / non-inheritance discipline
Readers           → navigation and inspection tools, not validation layers
```

VECTOR does not alter PMS Base. Its retained core is:

```text
VECTOR := <DIR, ROT>
V_t(O | F, Q, π) := <DIR_t, RP_t>
RP_t := ROTProfile_t
```

with:

```text
DIST              → derived supporting only
Adult Orientation → supporting shorthand only
Standalone VECTOR → provisionally retained; scope-reduced
```

---

## Distinguishing Function

UNDER LOAD does not ask whether PMS can produce readings. It asks what happens when PMS becomes successful enough that its outputs, artifacts, layers, workflows, readers, orientations, and self-applications begin to look stronger than they are.

Core stress families:

| Stress family | Question |
| --- | --- |
| Calibration | Can PMS distinguish genuine structure from over-reading? |
| Coverage | Does broad applicability become pseudo-universality? |
| Stack drift | Do derived layers begin to look like Base validation? |
| Φ drift | Does recontextualization become arbitrary transfer? |
| Meta-normativity | Does pre-moral structure quietly become normativity? |
| Success trap | Does productivity itself become evidence beyond the burden actually carried? |
| Domain drift | Does cross-domain use become equivalence? |
| Publicness | Do public artifacts become verdicts or authority tokens? |
| Self-application | Can PMS critique itself without final self-arbitration? |
| STRATA pressure | Does controlled level movement become proof, ontology, or immunity? |
| Direction / ranking drift | Does bounded DIR become universal rank, recommendation, or authority? |
| ROT pressure | Can rotation genuinely damage the claim, or does it become reframing-to-survive? |
| Option-field pressure | Are Blindness and Illusion evidence-typed, or used post hoc to expand or contract the field? |
| Attribution / constraint drift | Does orientation robustness become responsibility, guilt, legitimacy, or duty without the required bridge? |
| Rival pressure | Can a same-burden non-PMS rival remain primary where it carries the declared burden better? |
| Self-reduction pressure | Can recorded loss reduce VECTOR without becoming evidence that VECTOR validated itself? |

For the complete treatment, read the main paper by chapter rather than relying on this README.

---

## Core Reductions

UNDER LOAD works by reduction. The most important reductions are:

```text
PMS Base                              → operator grammar, not final explanation
PMS add-on                            → bounded lens, not validation of Base
PMS-STACK                             → architecture specification, not implementation proof
PMS-RUST                              → executable artifact evidence, not unrestricted PMS Base adequacy
PMS-AXIOM                             → case-cartography, not closure proof
PMS–EM                                → emergence readability, not developmental law
MIP/AHP                               → downstream governance / hardening, not rescue layer
PMS-DISCIPLINE                        → application discipline, not verdict authority
PMS-ORCHESTRATOR                      → workflow tooling, not semantic authority
PMS-STRATA                            → transformation discipline, not meta-PMS or ontology
PMS-VECTOR                            → bounded orientation / rival pressure, not universal rank or decision authority
DIST                                  → derived supporting shorthand, not VECTOR core or PMS Χ
Adult Orientation                     → supporting shorthand, not person type, dignity rank, or maturity scale
same-burden rival superiority         → real scope reduction, not hidden VECTOR victory
Bounded Test-Burden Closure           → current declared orientation burden only, not final truth or general stop authority
Pipeline Stop                         → non-continuation boundary, not analytical verdict
Iteration Handoff                     → follow-up preparation, not inheritance
Reader navigation                     → inspection, not validation
schema validity                       → structure check, not substantive truth
public artifact                       → traceability, not warrant
```

Compact formula:

```text
productivity ≠ sufficiency
portability ≠ equivalence
architecture specification ≠ implementation
implementation support ≠ unrestricted theoretical adequacy
workflow completion ≠ authority
reader visibility ≠ truth
orientation ≠ authority
self-reduction ≠ self-validation
rival victory ≠ VECTOR victory
more structure ≠ more warrant
```

Positive results still count where properly typed:

```text
successful implementation
→ bounded implementation / artifact support

real self-reduction
→ evidence that architecture loss is operationally possible

same-burden rival superiority
→ real local scope reduction

but none of these by itself
→ completeness
→ finality
→ unrestricted warrant
```

---

## Boundary Notes by Layer

### PMS-STACK

PMS-STACK may count as architecture-specification and implementation-layer pressure. It may not count as PMS Base validation or evidence that the full PMS stack is already implemented.

### PMS-RUST

PMS-RUST may count as bounded implementation and artifact evidence: operator representations, validation behavior, JSONL traces, vFS surface, demos, and acceptance gates. That supports bounded implementation claims. It may not by itself establish theory-wide adequacy, complete PMS-STACK realization, or external superiority.

### PMS-AXIOM

PMS-AXIOM may count as downstream case-cartography and schema-inspection pressure. It may not count as case proof, historical proof, final taxonomy, or closure-demand validation.

### PMS–EM

PMS–EM may count as emergence-boundary and developmental-architecture pressure. It may not count as developmental law, inevitability claim, diagnosis, or proof of future trajectories.

### MIP/AHP

MIP/AHP may constrain use, publicness, dignity language, reversibility, misuse risk, and artifact hardening. AHP hardening is not evidentiary upgrade, person ranking, or rescue of weak PMS claims.

### PMS-DISCIPLINE

PMS-DISCIPLINE may constrain PMS use through Pre-Entry responsibility, Pre-Analysis, Core-entry gates, add-on restraint, decomposition review, rivals, claim ceilings, human confirmation, stop-capability, and bounded follow-up preparation. It may not become application authority or tribunal.

### PMS-ORCHESTRATOR

PMS-ORCHESTRATOR may stage disciplined workflow, preserve raw outputs, record route state, run local YAML structural validation, support handoff and article routes, and enforce confirmed pipeline non-continuation. It may not become semantic authority, route truth, or proof.

### PMS-STRATA

PMS-STRATA may make composition, decomposition, projection, admissibility, Loss, Stop, and Non-Capture inspectable. It may not become PMS Base validation, meta-PMS, ontology of levels, proof, application authority, reader authority, or immunity machinery.

### PMS-VECTOR

PMS-VECTOR may make bounded direction, materially relevant perspective pressure, option-field status, Second-Order Agency, consequence/timing relations, rival comparison, structural-attribution change, constraint-relative necessity, and architecture reduction more explicit.

Its retained core is `<DIR, ROT>`. `RP` is stored rotation-profile state. `DIST` is derived supporting only. Adult Orientation remains supporting shorthand only.

VECTOR may not become:

```text
PMS Base extension
universal ranking system
general decision procedure
person-ranking system
moral / legal / clinical authority
endogenous calibration source
specialist-method replacement
self-validating orientation engine
```

Core type boundaries include:

```text
DIR ≠ ∇
ROT ≠ Φ
ROT ≠ PROJECT_AS
DIST ≠ Χ
```

Option-field distinctions remain evidence-sensitive:

```text
Option Invisibility
= legibility condition, not by itself error

Option Blindness
= unsupported exclusion

Option Illusion
= unsupported inclusion

Unknown ≠ Available
Unknown ≠ Unavailable
```

Orientation-mediated attribution remains separate from PMS-LOGIC baseline attribution:

```text
BaselineAttributability_LOGIC
≠
ΔAttributability_orientation
```

and:

```text
Being Told ≠ Actor Uptake
structural attributability ≠ guilt / blame / liability / moral fault
required for G ≠ G is legitimate
function must be carried ≠ you must carry it
```

E23 establishes a real same-burden rival loss: in a calibrated commensurable multi-criteria orientation problem, calibrated MCDA carries the declared burden more directly, so DIR, ROT, and standalone VECTOR scope narrow for that problem class.

---

## STRATA Pressure

STRATA introduces a self-critical burden for UNDER LOAD: a layer that controls analytical movement across levels can itself begin to look like a superior view of the system.

STRATA-specific drift families:

```text
granularity drift       → declared resolution becomes truth privilege
composition drift       → composite label becomes totality or higher authority
decomposition drift     → finer detail becomes presumed deeper truth
projection drift        → contextual function becomes origin type or semantic identity
traceability drift      → citation is mistaken for constitutive source trace
formalization drift     → schema validity becomes substantive validity
reader drift            → graph topology or visual depth becomes authority
anti-objection drift    → counterexamples are dissolved by changing level or frame
```

UNDER LOAD’s reduction:

```text
STRATA makes vertical movement inspectable.
It does not make vertical movement authoritative.
```

The STRATA/VECTOR operation boundary remains strict:

```text
ROT ≠ PROJECT_AS
perspective change ≠ analytical retyping
```

Material retyping through changed granularity, frame, level, composition, or target function creates a new claim burden. It may not rescue a failed DIR as same-claim survival.

---

## VECTOR Pressure

VECTOR introduces a further self-critical burden: explicit orientation machinery can itself begin to look like rank, decision authority, or proof that PMS has become resistant to criticism.

VECTOR-specific drift families:

```text
direction drift         → local DIR becomes universal rank
rotation drift          → ROT becomes reframing-to-survive
option blindness drift  → restrictive result is automatically called unsupported exclusion
option illusion drift   → hypothetical or conceivable alternatives become effective options
agency inflation        → imagination or distributed possibility becomes effective Second-Order Agency
attribution inflation   → robustness becomes blame, guilt, liability, or moral responsibility
constraint drift        → required-for-G becomes legitimacy or personal duty
rival domestication     → same-burden rival victory is redescribed as VECTOR coverage
reduction success trap  → real architecture loss becomes self-validation
reader / graph drift    → inspectability becomes analytical or evidential authority
```

UNDER LOAD’s reduction:

```text
VECTOR makes bounded direction more inspectable.
It does not make direction more authoritative.
```

And:

```text
real reduction matters
≠
real reduction settles external warrant
```

The current VECTOR architecture already records real loss:

```text
DIST core
→ supporting only

Adult Orientation independent theory status
→ supporting shorthand only

same-burden E23 rival superiority
→ DIR / ROT / StandaloneVECTOR scope reduction
```

Those losses are epistemically relevant as evidence that architecture reduction is real. They do not convert self-reduction into self-validation.

---

## Closure, Pipeline Stop, and Iteration Handoff

Several current PMS mechanisms can terminate or bound work, but they do not form a single general stop authority.

```text
Bounded Test-Burden Closure
≠
STRATA Stop
≠
PMS-DISCIPLINE Pipeline Stop
```

- **Bounded Test-Burden Closure** closes the current declared VECTOR orientation burden under its stated conditions. It is not final truth or final object closure.
- **STRATA Stop** belongs to transformation/admissibility control.
- **Pipeline Stop** controls continuation of a bounded application pass.

Pipeline Stop is not a seventh final analytical decision state.

The canonical final analytical decision states remain:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

Iteration Handoff may preserve a follow-up question, context, lineage, material needs, iteration value, urgency, current sufficiency status, and non-inheritance limits for possible future separately bounded work.

It may not count as Case Record Stage 4, article check, reopening by itself, new analysis layer, evidence transfer, route authority, claim authority, add-on preselection, MIP/AHP preselection, sufficiency inheritance, or automatic follow-up obligation.

Article outputs are not sources for Iteration Handoff.

---

## Reading Path

| Interest | Where to go |
| --- | --- |
| Main self-critique | `PMS - UNDER LOAD.md`, especially chapters on calibration, coverage, drift, publicness, self-application, orientation, rivalry, and reduction. |
| Implementation pressure | PMS-STACK and PMS-RUST sections in the main paper. |
| Workflow pressure | DISCIPLINE, ORCHESTRATOR, Pipeline Stop, and Iteration Handoff sections. |
| STRATA pressure | STRATA integration, stack-drift, Φ-drift, and self-application discussions. |
| VECTOR pressure | Direction/rank drift, ROT pressure, option-field misrepresentation, attribution, rival loss, and self-reduction discussions. |
| README-level orientation | This file plus the PMS ecosystem overview and Short Introduction. |

---

## Rule of Thumb

```text
PMS Base supplies grammar.
Add-ons stress the grammar.
Corpus repositories increase inspection pressure.
Implementation artifacts increase buildability pressure.
DISCIPLINE constrains application.
ORCHESTRATOR stages workflow.
STRATA controls bounded analytical transformation.
VECTOR pressures bounded orientation under perspective and rivalry.
UNDER LOAD asks when all of this becomes too strong.
```

---

## Final Boundary

UNDER LOAD does not “prove” or “disprove” PMS as a whole. It asks what the ecosystem’s successes, failures, reductions, rival comparisons, and artifacts actually support, and where those results are being escalated beyond the burden they carried.

The compact survivor result remains:

```text
PMS has not earned external warrant.
It has earned external testing pressure.
```

That does not make successful implementation, real reduction, rival survival, or corpus discipline epistemically null. It keeps each result tied to the claim type and pressure it actually bears.

---

## Status

This README reflects the current post-DISCIPLINE, post-ORCHESTRATOR, post-STRATA, post-VECTOR ecosystem position represented in the current UNDER LOAD paper.

The main paper remains the source for the complete argument.

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Late meta-reconstructive orientation repository for bounded DIR/ROT, perspective pressure, option fields, rival comparison, reduction, and non-capture. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, orientation, rivalry, workflow, stop, handoff, STRATA, and VECTOR pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS — UNDER LOAD DOI | To be added or verified after repository URL normalization and Zenodo release/check pass. |

---

## Citation

Cite the release and DOI corresponding to the version used. Do not cite UNDER LOAD as a validation of PMS Base; cite it as structural self-critique and boundary pressure.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
