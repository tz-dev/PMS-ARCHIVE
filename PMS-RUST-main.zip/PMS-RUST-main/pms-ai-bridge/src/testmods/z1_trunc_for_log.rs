use crate::{trunc_for_log, HTTP_ERR_BODY_TRUNC};

#[test]
fn trunc_for_log_no_trunc_when_small() {
    let s = "hello";
    let out = trunc_for_log(s, HTTP_ERR_BODY_TRUNC);
    assert_eq!(out, s);
}

#[test]
fn trunc_for_log_truncates_and_marks() {
    let s = "a".repeat(HTTP_ERR_BODY_TRUNC + 50);
    let out = trunc_for_log(&s, HTTP_ERR_BODY_TRUNC);

    assert!(out.chars().count() <= HTTP_ERR_BODY_TRUNC + "…<truncated>".chars().count());
    assert!(out.ends_with("…<truncated>"));
}
