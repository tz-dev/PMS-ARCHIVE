use crate::{ollama_tags_url_from_chat_endpoint, DEFAULT_ENDPOINT};

#[test]
fn ping_url_from_default_chat_endpoint_targets_ollama_tags() {
    assert_eq!(
        ollama_tags_url_from_chat_endpoint(DEFAULT_ENDPOINT),
        "http://localhost:11434/api/tags"
    );
}

#[test]
fn ping_url_from_base_endpoint_targets_ollama_tags() {
    assert_eq!(
        ollama_tags_url_from_chat_endpoint("http://localhost:11434"),
        "http://localhost:11434/api/tags"
    );
}

#[test]
fn ping_url_trims_trailing_slash() {
    assert_eq!(
        ollama_tags_url_from_chat_endpoint("http://localhost:11434/api/chat/"),
        "http://localhost:11434/api/tags"
    );
}
