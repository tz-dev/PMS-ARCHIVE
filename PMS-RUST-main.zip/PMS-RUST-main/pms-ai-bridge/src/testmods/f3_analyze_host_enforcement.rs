use crate::{
    enforce_analyze_response_shape, AiAnalyzeResult, AiCompileResult, AiError, AiOpcodeSpec,
    AiResponse, AiResult, TASK_ANALYZE_TRACE, TASK_COMPILE_SCENARIO,
};

#[test]
fn f_analyze_task_mismatch_is_blocked() {
    let r = AiResponse {
        ok: true,
        task: TASK_COMPILE_SCENARIO.to_string(),
        result: Some(AiResult::Analyze(AiAnalyzeResult {
            text: "ok".to_string(),
            findings: vec![],
            tags: vec![],
        })),
        warnings: vec![],
        error: None,
    };

    let out = enforce_analyze_response_shape(r);

    assert!(!out.ok);
    assert_eq!(out.task, TASK_ANALYZE_TRACE);
    assert_eq!(out.error.as_ref().unwrap().code, "task_mismatch");
    assert!(out.result.is_none());
}

#[test]
fn f_analyze_compile_result_is_rejected() {
    let r = AiResponse {
        ok: true,
        task: TASK_ANALYZE_TRACE.to_string(),
        result: Some(AiResult::Compile(AiCompileResult {
            opcodes: vec![AiOpcodeSpec {
                op: "Square".to_string(),
                params: serde_json::json!({}),
            }],
        })),
        warnings: vec![],
        error: None,
    };

    let out = enforce_analyze_response_shape(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "invalid_result_for_task");
    assert!(out.result.is_none());
    assert!(out
        .warnings
        .contains(&"analyze_trace_rejected_compile_result".to_string()));
}

#[test]
fn f_analyze_ok_false_without_error_gets_deterministic_error() {
    let r = AiResponse {
        ok: false,
        task: TASK_ANALYZE_TRACE.to_string(),
        result: None,
        warnings: vec![],
        error: None,
    };

    let out = enforce_analyze_response_shape(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "model_returned_ok_false");
}

#[test]
fn f_analyze_valid_result_passes() {
    let r = AiResponse {
        ok: true,
        task: TASK_ANALYZE_TRACE.to_string(),
        result: Some(AiResult::Analyze(AiAnalyzeResult {
            text: "trace analyzed".to_string(),
            findings: vec!["finding".to_string()],
            tags: vec!["tag".to_string()],
        })),
        warnings: vec![],
        error: None,
    };

    let out = enforce_analyze_response_shape(r);

    assert!(out.ok, "expected ok; got error={:?}", out.error);
    assert!(matches!(out.result, Some(AiResult::Analyze(_))));
}

#[test]
fn f_analyze_ok_true_with_error_becomes_not_ok() {
    let r = AiResponse {
        ok: true,
        task: TASK_ANALYZE_TRACE.to_string(),
        result: Some(AiResult::Analyze(AiAnalyzeResult {
            text: "trace analyzed".to_string(),
            findings: vec![],
            tags: vec![],
        })),
        warnings: vec![],
        error: Some(AiError {
            code: "model_error".to_string(),
            message: "model reported an error despite ok=true".to_string(),
        }),
    };

    let out = enforce_analyze_response_shape(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "model_error");
}
