use crate::{
    parse_ai_response_lenient, validate_and_canonicalize_opcodes, AiCompileResult, AiError,
    AiResponse, AiResult, TASK_COMPILE_SCENARIO,
};

fn enforce_compile_offline(mut r: AiResponse) -> AiResponse {
    // Mirror compile_scenario() host enforcement, but purely offline.
    if r.task != TASK_COMPILE_SCENARIO {
        return AiResponse {
            ok: false,
            task: TASK_COMPILE_SCENARIO.to_string(),
            result: None,
            warnings: vec![],
            error: Some(AiError {
                code: "task_mismatch".to_string(),
                message: format!("expected task=compile_scenario, got task={}", r.task),
            }),
        };
    }

    let compile = match r.result.take() {
        Some(AiResult::Compile(c)) => c,
        _ => {
            return AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "invalid_result_for_task".to_string(),
                    message: "compile_scenario requires result.opcodes".to_string(),
                }),
            };
        }
    };

    if compile.opcodes.is_empty() {
        return AiResponse {
            ok: false,
            task: TASK_COMPILE_SCENARIO.to_string(),
            result: None,
            warnings: vec![],
            error: Some(AiError {
                code: "empty_opcodes".to_string(),
                message: "compile_scenario returned no opcodes".to_string(),
            }),
        };
    }

    let validated = match validate_and_canonicalize_opcodes(compile.opcodes) {
        Ok(v) => v,
        Err(resp) => return *resp,
    };

    r.ok = r.ok && r.error.is_none();
    r.result = Some(AiResult::Compile(AiCompileResult { opcodes: validated }));
    r
}

fn parse_lenient_offline(content: &str) -> AiResponse {
    let (r, _coerced) = parse_ai_response_lenient(content).expect("must parse JSON");
    r
}

#[test]
fn f_compile_task_mismatch_is_blocked() {
    let assistant = r#"{
      "ok": true,
      "task": "analyze_trace",
      "result": { "opcodes": [ { "op": "Square", "params": {} } ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "task_mismatch");
}

#[test]
fn f_compile_missing_result_is_blocked() {
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": null,
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "invalid_result_for_task");
}

#[test]
fn f_compile_empty_opcodes_is_blocked() {
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "empty_opcodes");
}

#[test]
fn f_compile_unknown_op_is_blocked() {
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [ { "op": "NotAnOp", "params": {} } ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "unknown_op");
}

#[test]
fn f_compile_frame_alias_is_allowed_and_canonicalized() {
    // In this project, "Frame" is normalized to an allowed canonical op (likely "Square").
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [ { "op": "Frame", "params": {} } ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(out.ok, "expected ok; got error={:?}", out.error);

    let res = match out.result.unwrap() {
        AiResult::Compile(c) => c,
        _ => panic!("expected compile result"),
    };

    assert_eq!(res.opcodes.len(), 1);
    assert!(res.opcodes[0].params.is_object());

    // Must become a canonical allowed op after normalization.
    // If your normalize maps "Frame" -> "Square", this will pass.
    assert_eq!(res.opcodes[0].op, "Square");
}

#[test]
fn f_compile_params_not_object_is_blocked() {
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [ { "op": "Square", "params": [] } ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "params_not_object");
}

#[test]
fn f_compile_missing_op_field_lenient_parse_then_blocked() {
    // lenient parser sets op="" if missing; validator must fail closed.
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [ { "params": {} } ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(!out.ok);
    assert_eq!(out.error.as_ref().unwrap().code, "unknown_op");
}

#[test]
fn f_compile_missing_params_field_defaults_to_object_and_can_pass() {
    // current behavior: missing params => {} in lenient parse
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [ { "op": "Square" } ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(out.ok, "expected ok; got error={:?}", out.error);

    let res = match out.result.unwrap() {
        AiResult::Compile(c) => c,
        _ => panic!("expected compile result"),
    };

    assert_eq!(res.opcodes.len(), 1);
    assert_eq!(res.opcodes[0].op, "Square");
    assert!(res.opcodes[0].params.is_object());
}

#[test]
fn f_compile_valid_whitelisted_ops_pass_and_are_canonicalized() {
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [
        { "op": "square", "params": {} },
        { "op": "Sigma", "params": {} },
        { "op": "Psi", "params": {} }
      ] },
      "warnings": [],
      "error": null
    }"#;

    let r = parse_lenient_offline(assistant);
    let out = enforce_compile_offline(r);

    assert!(out.ok, "expected ok; got error={:?}", out.error);

    let res = match out.result.unwrap() {
        AiResult::Compile(c) => c,
        _ => panic!("expected compile result"),
    };

    assert_eq!(res.opcodes.len(), 3);
    assert_eq!(res.opcodes[0].op, "Square");
    assert_eq!(res.opcodes[1].op, "Sigma");
    assert_eq!(res.opcodes[2].op, "Psi");
}
