use crate::{parse_ai_response_lenient, AiResult};

#[test]
fn analyze_lenient_parse_coerces_nonstring_findings_to_strings() {
    let assistant = r#"{
      "ok": true,
      "task": "analyze_trace",
      "result": { "text": "OK", "findings": [{"a":1}], "tags": ["t"] },
      "warnings": [],
      "error": null
    }"#;

    let (r, coerced) = parse_ai_response_lenient(assistant).unwrap();
    assert!(r.ok);
    assert_eq!(r.task, "analyze_trace");
    assert!(coerced);

    match r.result.unwrap() {
        AiResult::Analyze(a) => {
            assert_eq!(a.text, "OK");
            assert_eq!(a.tags, vec!["t".to_string()]);
            assert_eq!(a.findings.len(), 1);
            assert!(a.findings[0].contains("\"a\":1"));
        }
        _ => panic!("expected analyze result"),
    }
}

#[test]
fn analyze_lenient_parse_coerces_and_sets_warning_like_bridge() {
    let assistant = r#"{
      "ok": true,
      "task": "analyze_trace",
      "result": { "text": "OK", "findings": [{"a":1}], "tags": ["t"] },
      "warnings": [],
      "error": null
    }"#;

    let (mut r, coerced) = parse_ai_response_lenient(assistant).unwrap();
    if coerced {
        r.warnings
            .push("coerced_nonstring_findings_to_strings".to_string());
    }

    assert!(r
        .warnings
        .iter()
        .any(|w| w == "coerced_nonstring_findings_to_strings"));
}
