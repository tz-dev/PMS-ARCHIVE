use crate::{AiError, AiResponse, AiResult};

#[test]
fn parses_valid_assistant_json_content() {
    let assistant = r#"{
      "ok": true,
      "task": "analyze_trace",
      "result": { "text": "OK", "findings": ["A"], "tags": ["summary"] },
      "warnings": [],
      "error": null
    }"#;

    let r: AiResponse = serde_json::from_str(assistant).unwrap();
    assert!(r.ok);
    assert_eq!(r.task, "analyze_trace");

    match r.result.unwrap() {
        AiResult::Analyze(a) => assert_eq!(a.text, "OK"),
        _ => panic!("expected analyze result"),
    }
}

#[test]
fn invalid_json_from_model_is_fail_closed() {
    let bad = "NOT JSON";
    let parsed = serde_json::from_str::<AiResponse>(bad);
    assert!(parsed.is_err());

    // emulate bridge behavior:
    let r = AiResponse {
        ok: false,
        task: "analyze_trace".to_string(),
        result: None,
        warnings: vec![],
        error: Some(AiError {
            code: "invalid_json_from_model".to_string(),
            message: "assistant content was not valid AiResponse JSON".to_string(),
        }),
    };
    assert!(!r.ok);
    assert_eq!(r.error.as_ref().unwrap().code, "invalid_json_from_model");
}

#[test]
fn parses_compile_result_shape() {
    let assistant = r#"{
      "ok": true,
      "task": "compile_scenario",
      "result": { "opcodes": [ { "op": "Square", "params": {} } ] },
      "warnings": [],
      "error": null
    }"#;

    let r: AiResponse = serde_json::from_str(assistant).unwrap();
    assert!(r.ok);
    assert_eq!(r.task, "compile_scenario");

    match r.result.unwrap() {
        AiResult::Compile(c) => {
            assert_eq!(c.opcodes.len(), 1);
            assert_eq!(c.opcodes[0].op, "Square");
            assert!(c.opcodes[0].params.is_object());
        }
        _ => panic!("expected compile result"),
    }
}
