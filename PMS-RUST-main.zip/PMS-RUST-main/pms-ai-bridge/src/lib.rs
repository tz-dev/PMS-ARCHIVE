// PMS-AI-BRIDGE v0
//
// Purpose:
// - Typed request/response layer for local LLM backend (e.g. Ollama) using strict JSON envelopes.
// - Enforces host-side safety: parses leniently, but ACCEPTS only whitelisted tasks/results/opcodes.
// - Returns structured errors (fail-closed) when shape/task/opcode constraints are violated.
//
// v0 Constraints / Guarantees:
// - Never execute anything: only produce AiResponse (text, findings, opcodes).
// - Fail-closed on malformed JSON, task mismatch, unknown op, invalid params shape.
// - Warnings are preserved and forwarded; callers can display them without trusting the content.
//
// Debugging:
// - PMS_TRACE=1 prints HTTP status + lengths; PMS_AI_DEBUG=1 may print raw assistant content (optional, truncated).

#![forbid(unsafe_code)]

use std::collections::BTreeMap;
use std::time::Duration;

use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};

/// Default Ollama chat endpoint.
/// v0 assumes local host usage; callers can override this upstream.
pub const DEFAULT_ENDPOINT: &str = "http://localhost:11434/api/chat";

/// Default model name (Ollama runtime).
/// Note: the bridge does not assume capabilities; it only enforces JSON envelope rules.
pub const DEFAULT_MODEL: &str = "llama3.1:8b";

/// Task identifiers understood by the host.
/// Important:
/// - These are "protocol" strings used in JSON envelopes.
/// - The system prompts must match these exactly.
pub const TASK_ANALYZE_TRACE: &str = "analyze_trace";
pub const TASK_COMPILE_SCENARIO: &str = "compile_scenario";

/// System prompt for analyze_trace (v0).
///
/// Hard rules:
/// - JSON only (no markdown).
/// - Envelope schema is fixed (no extra keys).
/// - Findings and tags MUST be arrays of strings (NOT objects).
///
/// Semantic guardrails:
/// - Do not claim execution.
/// - Treat "non_event" as an already-happened timeout.
/// - If integrate consumed=[...] then impulses are no longer pending.
/// - When insufficient evidence: ok=false with error.code="insufficient_evidence".
pub const SYSTEM_PROMPT_ANALYZE: &str = r#"
You are a PMS-STACK AI-Bridge worker.

You MUST reply with JSON only.
No markdown, no prose outside JSON, no extra keys.

Return EXACTLY this envelope schema:

{
  "ok": true|false,
  "task": "analyze_trace",
  "result": {
    "text": "Short, precise analysis in English",
    "findings": ["..."],   // IMPORTANT: findings MUST be an array of strings (NOT objects)
    "tags": ["..."]        // tags MUST be an array of strings
  },
  "warnings": [],
  "error": null | { "code": "string", "message": "string" }
}

Rules:
- You must not claim execution. Only analyze what is present in the input.
- Do not restate the full trace in findings (EXCEPT required_literals which must appear verbatim as standalone findings). Findings are short bullet strings.
- If ambiguous or insufficient evidence: set ok=false and set error.code="insufficient_evidence".
- Keep findings factual and traceable to the provided events.
- You must treat "non_event" as a timeout that already happened (not "waiting").
- If you see "integrate ... consumed=[...]", you must state that those impulses were consumed by Σ (not still pending).
- Never claim a current agent state (e.g. "waiting", "stable") unless it is directly supported by events after the last tick.
- Prefer mentioning: commits, seals, non_events, and consumed impulses as concrete facts.
- Do not attribute actions to the user (e.g. "as per user's command"). Only describe observed events.

- CRITICAL REQUIRED_LITERALS RULE:
  The user JSON may contain pms_meta.required_literals (array of strings).
  If present and non-empty, you MUST include EACH literal EXACTLY (verbatim)
  as its OWN standalone finding string in result.findings.
  That means: for every literal L, result.findings must contain an element that is exactly L.
  Do NOT add extra words around it. Do NOT change spacing, casing, or characters.
  If required_literals is non-empty, include them first in result.findings.
  If you cannot comply, set ok=false and set error.code="insufficient_evidence".

- CRITICAL NON_EVENT TOKEN RULE:
  If any input event message contains the exact substring "non_event",
  you MUST include a standalone finding string exactly equal to "non_event".
  (This is required even if required_literals is empty.)

- Tags MUST be trace-derived and specific (e.g. "integrate", "sigma", "consumed",
  "non_event", "commit", "advance", "theta").
  Do NOT output generic tags like "initial_state" unless the trace explicitly supports it.
"#;

/// System prompt for compile_scenario (v0).
///
/// Hard rules:
/// - JSON only, strict envelope, opcodes[] is required in result.
/// - Allowed operator set is an explicit whitelist (canonical theoretical keys).
/// - params must be a JSON object for every opcode.
///
/// Important:
/// - The bridge will validate and canonicalize ops on the host side anyway,
///   but the prompt reduces the probability of invalid output.
pub const SYSTEM_PROMPT_COMPILE: &str = r#"
You are a PMS-STACK AI-Bridge worker.

You MUST reply with JSON only.
No markdown, no prose outside JSON, no extra keys.

Return EXACTLY this envelope schema:

{
  "ok": true|false,
  "task": "compile_scenario",
  "result": {
    "opcodes": [
      { "op": "Square", "params": { } }
    ]
  },
  "warnings": [],
  "error": null | { "code": "string", "message": "string" }
}

Rules:
- You must not claim execution. You ONLY propose opcodes.
- Allowed ops whitelist (canonical keys only): Delta, Nabla, Square, Omega, Theta, Lambda, Phi, Chi, Sigma, Psi, Alpha.
- Each opcode entry MUST be: { "op": <string>, "params": <object> }.
- params MUST be a JSON object (not an array, not a primitive, not null).
- Do not invent kernel features. Use only op + params.
- If you are unsure how to compile: set ok=false and set error.code="cannot_compile".
"#;

/// Minimal tracing macro controlled by env PMS_TRACE.
/// This should remain low-risk: only prints metadata (status, lengths), not full content.
macro_rules! trace {
    ($($t:tt)*) => {
        if std::env::var("PMS_TRACE").ok().as_deref() == Some("1") {
            eprintln!($($t)*);
        }
    }
}

/// More sensitive debug macro controlled by PMS_AI_DEBUG.
/// Use with care: may print model output. Caller controls via env.
///
/// Note:
/// - The truncation helper exists to keep logs bounded.
macro_rules! ai_debug {
    ($($t:tt)*) => {
        if std::env::var("PMS_AI_DEBUG").ok().as_deref() == Some("1") {
            eprintln!($($t)*);
        }
    }
}

/// Default truncation limit for HTTP error bodies in logs/messages.
pub(crate) const HTTP_ERR_BODY_TRUNC: usize = 2000;

/// Truncate a string by *character count* (not bytes).
///
/// Rationale:
/// - Prevent massive dumps into stderr.
/// - Character-based truncation avoids cutting in the middle of UTF-8 codepoints.
///
/// Note:
/// - This is O(n) and intentionally simple; v0 uses it only in debug paths.
fn trunc(s: &str, max: usize) -> String {
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if i >= max {
            break;
        }
        out.push(ch);
    }
    out
}

/// Truncate helper for log-/CLI-safe error messages.
///
/// Behavior:
/// - `max == 0` => uses HTTP_ERR_BODY_TRUNC (default 2000).
/// - character-based truncation (UTF-8 safe).
/// - If truncated, appends "…<truncated>" marker.
pub(crate) fn trunc_for_log(s: &str, max: usize) -> String {
    let max = if max == 0 { HTTP_ERR_BODY_TRUNC } else { max };

    // Fast path: no truncation needed.
    if s.chars().count() <= max {
        return s.to_string();
    }

    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if i >= max {
            break;
        }
        out.push(ch);
    }
    out.push_str("…<truncated>");
    out
}

/// Minimal serializable view of KernelEvent for AI.
///
/// Contract:
/// - `op` is a *string* because the AI sees canonical/model keys, not Rust enums.
/// - `msg` is the stable kernel event line (source-of-truth).
/// - `meta` is optional structured view (derived), may be absent.
///
/// Important:
/// - This is intentionally independent of kernel internal types to keep the bridge boundary stable.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct KernelEventLite {
    pub tick: u64,
    pub op: String, // canonical key like "Omega", "Frame", ...
    pub msg: String,
    #[serde(default)]
    pub meta: Option<KernelEventMetaLite>,
}

/// Minimal meta view.
/// `kv` values are already unescaped in the kernel meta parser (if you mirrored that contract).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct KernelEventMetaLite {
    pub kind: String,
    #[serde(default)]
    pub kv: BTreeMap<String, String>,
}

/// Optional context field that can carry schema/guardrails/vocabulary.
///
/// v0:
/// - All fields are optional.
/// - The bridge must not depend on them for correctness.
/// - They are provided to the model to increase compliance, but host validation remains authoritative.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ModelContext {
    #[serde(default)]
    pub schema_version: Option<String>,
    #[serde(default)]
    pub guardrails: Option<serde_json::Value>,
    #[serde(default)]
    pub vocabulary: Option<serde_json::Value>,
}

/// v0 request envelope (supports analyze_trace and compile_scenario).
///
/// Key points:
/// - `task` selects which system prompt and which result shape is expected.
/// - `version` is a protocol version string, not tied to crate version.
/// - `pms_meta` is generic JSON for caller-defined metadata (defaulted to null/empty).
/// - `options` includes language + max_tokens; these map to backend-specific knobs.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiRequest {
    pub task: String,    // "analyze_trace" or "compile_scenario"
    pub version: String, // e.g. "pms-1.0"
    #[serde(default)]
    pub pms_meta: serde_json::Value,
    pub input: AiInput,
    #[serde(default)]
    pub options: AiOptions,
}

/// Input shape for analyze_trace.
///
/// - events: the stable kernel timeline (lite form)
/// - snapshot: optional commit snapshot or other host-provided anchor data
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiInputAnalyzeTrace {
    #[serde(default)]
    pub context: Option<ModelContext>,
    pub events: Vec<KernelEventLite>,
    #[serde(default)]
    pub snapshot: Option<serde_json::Value>,
}

/// Input shape for compile_scenario.
///
/// - description: human-level prompt describing desired scenario
/// - constraints: optional host-provided constraints (e.g. must include Ψ, max frames, etc.)
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiInputCompileScenario {
    #[serde(default)]
    pub context: Option<ModelContext>,
    pub description: String,
    #[serde(default)]
    pub constraints: Option<serde_json::Value>,
}

/// Untagged input union.
///
/// Why untagged:
/// - v0 wants a minimal envelope without extra nesting keys.
/// - The variant is inferred from the JSON structure.
///
/// Risk:
/// - Untagged enums can accept ambiguous shapes.
///
/// Mitigation:
/// - Task selection + host-side checks ensure we only accept the matching result shapes.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
pub enum AiInput {
    AnalyzeTrace(AiInputAnalyzeTrace),
    CompileScenario(AiInputCompileScenario),
}

/// Options passed through from host to backend.
///
/// v0:
/// - language is advisory (e.g. "en") and included in system/user messages.
/// - max_tokens maps to Ollama "num_predict" (set later in request builder).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct AiOptions {
    #[serde(default)]
    pub language: String, // e.g. "en"
    #[serde(default)]
    pub max_tokens: u32, // used as num_predict
}

/// Response envelope returned to callers.
///
/// Safety stance:
/// - Even if parsing is lenient, acceptance is strict:
///   - task must match expectation
///   - result shape must match task
///   - compile_scenario opcodes are validated and canonicalized
///
/// Note:
/// - warnings are strings: caller may display them, but must not treat them as trusted assertions.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiResponse {
    pub ok: bool,
    pub task: String,
    pub result: Option<AiResult>,
    #[serde(default)]
    pub warnings: Vec<String>,
    pub error: Option<AiError>,
}

/// Analyze result payload.
///
/// Requirements:
/// - findings and tags are arrays of strings.
/// - The bridge will coerce non-string array items to strings in lenient mode,
///   but can add warnings (and/or fail closed in other layers) if desired.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiAnalyzeResult {
    pub text: String,
    #[serde(default)]
    pub findings: Vec<String>,
    #[serde(default)]
    pub tags: Vec<String>,
}

/// One opcode proposal emitted by compile_scenario.
///
/// Contract:
/// - op is a string operator key (will be normalized + canonicalized on host side).
/// - params is JSON Value but MUST be an object for acceptance (checked later).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiOpcodeSpec {
    pub op: String,
    pub params: serde_json::Value, // MUST be object (host-check later)
}

/// Compile result payload.
/// v0 expects only a list of opcode specs (no prose).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiCompileResult {
    pub opcodes: Vec<AiOpcodeSpec>,
}

/// Untagged union for result payload.
///
/// Decision rule (implemented in parser below):
/// - If result contains "opcodes", interpret as compile_scenario.
/// - Otherwise interpret as analyze_trace.
///
/// This rule deliberately avoids needing an explicit result tag from the model.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
pub enum AiResult {
    Analyze(AiAnalyzeResult),
    Compile(AiCompileResult),
}

/// Error payload returned inside AiResponse.
///
/// v0 design:
/// - code is stable for programmatic handling.
/// - message is human-readable.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AiError {
    pub code: String,
    pub message: String,
}

/// Bridge-level hard errors that occur before we even have a usable AiResponse.
///
/// Examples:
/// - HTTP transport errors
/// - Ollama response missing assistant content
#[derive(thiserror::Error, Debug)]
pub enum AiBridgeError {
    #[error("http error: {0}")]
    Http(String),

    #[error("ollama response missing assistant content")]
    MissingAssistantContent,
}

/// Ollama options are passed as arbitrary JSON.
/// In v0 we keep this opaque and only set known keys (e.g. num_predict) when building requests.
type OllamaOptions = serde_json::Value;

/// Ollama /api/chat request payload.
///
/// Key points:
/// - stream=false: blocking request returns full message.
/// - format=Some("json"): asks Ollama to enforce JSON-only output (best-effort).
/// - options: backend-specific knobs (e.g. num_predict).
#[derive(Debug, Clone, serde::Serialize)]
struct OllamaChatRequest {
    model: String,
    stream: bool,
    messages: Vec<OllamaMessage>,

    // Force JSON output in message.content (best-effort).
    #[serde(skip_serializing_if = "Option::is_none")]
    format: Option<String>,

    #[serde(skip_serializing_if = "Option::is_none")]
    options: Option<OllamaOptions>,
}

/// A single chat message.
/// Ollama expects role + content.
#[derive(Debug, Clone, Serialize)]
struct OllamaMessage {
    role: String,
    content: String,
}

/// Ollama /api/chat response (partial).
///
/// We only need assistant message content.
/// If "message" is missing, that is a hard error (MissingAssistantContent).
#[derive(Debug, Clone, Deserialize)]
struct OllamaChatResponse {
    message: Option<OllamaMessageResp>,
}

#[derive(Debug, Clone, Deserialize)]
struct OllamaMessageResp {
    content: String,
}

/// Coerce a JSON array to Vec<String>.
///
/// v0 parsing stance:
/// - For fields like warnings/findings/tags we *prefer* string[],
///   but we can recover from object/number items by stringifying them.
/// - This supports "parse leniently" while still allowing "accept strictly" upstream.
fn coerce_string_list(v: &serde_json::Value) -> Option<Vec<String>> {
    let arr = v.as_array()?;
    let mut out = Vec::with_capacity(arr.len());

    for item in arr {
        if let Some(s) = item.as_str() {
            out.push(s.to_string());
        } else {
            // Stringify non-string items (objects, numbers, booleans, null).
            // v0: keep it compact, single-line JSON representation.
            out.push(item.to_string());
        }
    }

    Some(out)
}

/// Select system prompt by task string.
///
/// v0 default:
/// - Unknown tasks fall back to analyze prompt.
///
/// This is safe only if the caller also enforces expected task elsewhere.
/// Later layers should validate task exactly to avoid "prompt mismatch" surprises.
fn system_prompt_for_task(task: &str) -> &'static str {
    match task {
        TASK_COMPILE_SCENARIO => SYSTEM_PROMPT_COMPILE,
        _ => SYSTEM_PROMPT_ANALYZE,
    }
}

/// Whitelist for compile_scenario operator keys.
///
/// Canonical theoretical keys only:
/// - Delta, Nabla, Square, Omega, Theta, Lambda, Phi, Chi, Sigma, Psi, Alpha
///
/// Rationale:
/// - This matches `pms_model::normalize_op_name()` outputs.
/// - Host can map canonical keys to kernel runtime operators (e.g. Square->Frame, Alpha->Attractor)
///   in a separate compile step.
fn is_allowed_op_canonical(op: &str) -> bool {
    matches!(
        op,
        "Delta"
            | "Nabla"
            | "Square"
            | "Omega"
            | "Theta"
            | "Lambda"
            | "Phi"
            | "Chi"
            | "Sigma"
            | "Psi"
            | "Alpha"
    )
}

/// Validate and canonicalize a model-proposed opcode list.
///
/// This is the critical host-side "ACCEPT" gate for compile_scenario.
///
/// Steps per opcode:
/// 1) Normalize op name using model normalization (symbols, aliases, case).
/// 2) Check canonical op against explicit whitelist (fail-closed).
/// 3) Require params to be a JSON object (fail-closed).
/// 4) Replace spec.op with canonical string.
///
/// On first error:
/// - Returns Err(AiResponse) as a structured, safe envelope with ok=false.
///
/// Note:
/// - Returning AiResponse here (instead of AiBridgeError) keeps error handling uniform:
///   callers always receive a response envelope they can display/log.
fn enforce_analyze_response_shape(mut r: AiResponse) -> AiResponse {
    if r.task != TASK_ANALYZE_TRACE {
        let got = r.task;
        return AiResponse {
            ok: false,
            task: TASK_ANALYZE_TRACE.to_string(),
            result: None,
            warnings: r.warnings,
            error: Some(AiError {
                code: "task_mismatch".to_string(),
                message: format!("expected task=analyze_trace, got task={}", got),
            }),
        };
    }

    if r.ok && r.error.is_some() {
        r.ok = false;
    }

    if !r.ok {
        if r.error.is_none() {
            r.error = Some(AiError {
                code: "model_returned_ok_false".to_string(),
                message: "model returned ok=false without error object".to_string(),
            });
        }

        return r;
    }

    match r.result {
        Some(AiResult::Analyze(res)) => {
            r.result = Some(AiResult::Analyze(res));
            r
        }
        Some(AiResult::Compile(_)) => {
            let mut warnings = r.warnings;
            warnings.push("analyze_trace_rejected_compile_result".to_string());

            AiResponse {
                ok: false,
                task: TASK_ANALYZE_TRACE.to_string(),
                result: None,
                warnings,
                error: Some(AiError {
                    code: "invalid_result_for_task".to_string(),
                    message:
                        "analyze_trace requires result.text/findings/tags, got compile opcodes"
                            .to_string(),
                }),
            }
        }
        None => AiResponse {
            ok: false,
            task: TASK_ANALYZE_TRACE.to_string(),
            result: None,
            warnings: r.warnings,
            error: Some(AiError {
                code: "invalid_result_for_task".to_string(),
                message: "analyze_trace requires result.text/findings/tags".to_string(),
            }),
        },
    }
}

fn validate_and_canonicalize_opcodes(
    opcodes: Vec<AiOpcodeSpec>,
) -> Result<Vec<AiOpcodeSpec>, Box<AiResponse>> {
    let mut out: Vec<AiOpcodeSpec> = Vec::with_capacity(opcodes.len());

    for (idx, mut spec) in opcodes.into_iter().enumerate() {
        // 1) Normalize op name (symbols, aliases, case).
        let canon: &'static str = match pms_model::normalize_op_name(&spec.op) {
            Some(c) => c,
            None => {
                return Err(Box::new(AiResponse {
                    ok: false,
                    task: TASK_COMPILE_SCENARIO.to_string(),
                    result: None,
                    warnings: vec![],
                    error: Some(AiError {
                        code: "unknown_op".to_string(),
                        message: format!("opcode[{}].op unknown: {}", idx, spec.op),
                    }),
                }));
            }
        };

        // 2) Whitelist check (canonical only).
        if !is_allowed_op_canonical(canon) {
            return Err(Box::new(AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "op_not_allowed".to_string(),
                    message: format!("opcode[{}].op not allowed: {}", idx, canon),
                }),
            }));
        }

        // 3) params must be a JSON object.
        //
        // This prevents weird shapes like:
        // - params: null
        // - params: []
        // - params: "oops"
        // which would otherwise cause downstream panics or ambiguous interpretation.
        if !spec.params.is_object() {
            return Err(Box::new(AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "params_not_object".to_string(),
                    message: format!("opcode[{}].params must be JSON object", idx),
                }),
            }));
        }

        // 4) Canonicalize op string.
        spec.op = canon.to_string();
        out.push(spec);
    }

    Ok(out)
}

/// Parse an AI response "leniently", but still return a typed AiResponse envelope.
///
/// Returns:
/// - Ok((AiResponse, coerced_nonstring_findings))
///   where coerced_nonstring_findings indicates we had to stringify non-string items in findings.
///
/// Strategy:
/// 1) Attempt strict typed parse to AiResponse.
/// 2) If strict parse fails, parse into serde_json::Value and extract fields permissively:
///    - ok: bool default false
///    - task: string default analyze_trace
///    - warnings: array coerce to Vec<String>
///    - error: object {code,message} or null
///    - result: decide between compile vs analyze by presence of "opcodes"
///
/// Important:
/// - This is only parsing. Acceptance (task match, opcode whitelist, params shape)
///   must be enforced by higher-level gates.
fn parse_ai_response_lenient(content: &str) -> Result<(AiResponse, bool), serde_json::Error> {
    // returns (AiResponse, coerced_nonstring_findings)

    // 1) Try strict typed parse first.
    //
    // This is the happy path when the model follows the prompt exactly.
    if let Ok(r) = serde_json::from_str::<AiResponse>(content) {
        return Ok((r, false));
    }

    // 2) Lenient parse via generic Value.
    //
    // This path allows us to recover from slight schema drift and still produce
    // a structured envelope for callers, instead of "hard failing" on JSON shape.
    let v: serde_json::Value = serde_json::from_str(content)?;

    let ok = v.get("ok").and_then(|x| x.as_bool()).unwrap_or(false);

    // Default task to analyze_trace if missing (conservative default).
    // Note: acceptance should still require the expected task upstream.
    let task = v
        .get("task")
        .and_then(|x| x.as_str())
        .unwrap_or(TASK_ANALYZE_TRACE)
        .to_string();

    // warnings: accept array and coerce items to strings.
    // If warnings missing/wrong type => empty.
    let mut warnings = v
        .get("warnings")
        .and_then(coerce_string_list)
        .unwrap_or_default();

    // error: accept {code,message} object, or null/absent => None.
    let error = match v.get("error") {
        Some(serde_json::Value::Null) | None => None,
        Some(e) => {
            let code = e
                .get("code")
                .and_then(|x| x.as_str())
                .unwrap_or("unknown")
                .to_string();
            let message = e
                .get("message")
                .and_then(|x| x.as_str())
                .unwrap_or("unknown error")
                .to_string();
            Some(AiError { code, message })
        }
    };

    // Track whether we coerced findings entries from non-strings.
    // This can be used to add warnings or metrics upstream.
    let mut coerced = false;

    let result: Option<AiResult> = match v.get("result") {
        None | Some(serde_json::Value::Null) => None,
        Some(r) => {
            // ---- compile_scenario shape wins if "opcodes" exists ----
            //
            // This is a deliberate disambiguation rule for the untagged result enum.
            // Even if task says analyze_trace, presence of opcodes makes it compile-shaped.
            // Acceptance should still check task/result consistency later.
            if let Some(opcodes_val) = r.get("opcodes") {
                let arr = opcodes_val.as_array().cloned().unwrap_or_default();
                let mut opcodes: Vec<AiOpcodeSpec> = Vec::with_capacity(arr.len());

                // Lenient extraction:
                // - op: string default ""
                // - params: default {} if missing
                for item in arr {
                    let op = item
                        .get("op")
                        .and_then(|x| x.as_str())
                        .unwrap_or("")
                        .to_string();

                    let params = item
                        .get("params")
                        .cloned()
                        .unwrap_or_else(|| serde_json::json!({}));

                    opcodes.push(AiOpcodeSpec { op, params });
                }

                // Early return: compile result constructed.
                // Note: opcode whitelist + params object checks happen in validate_and_canonicalize_opcodes.
                return Ok((
                    AiResponse {
                        ok,
                        task,
                        result: Some(AiResult::Compile(AiCompileResult { opcodes })),
                        warnings,
                        error,
                    },
                    false,
                ));
            }

            // ---- otherwise analyze_trace shape ----
            //
            // text: missing => "" (caller can decide whether empty text is acceptable)
            let text = r
                .get("text")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_string();

            // findings: accept string[] OR object[] (coerce items to strings)
            //
            // UX rule:
            // - If findings exists but is NOT an array, we add warning findings_not_array and ignore it.
            let findings = match r.get("findings") {
                None | Some(serde_json::Value::Null) => Vec::new(),
                Some(v) => {
                    if let Some(arr) = v.as_array() {
                        if arr.iter().any(|i| !i.is_string()) {
                            coerced = true;
                        }
                        coerce_string_list(&serde_json::Value::Array(arr.clone()))
                            .unwrap_or_default()
                    } else {
                        warnings.push("findings_not_array".to_string());
                        Vec::new()
                    }
                }
            };

            // tags: intended string[], but we also coerce non-strings to strings for robustness.
            let tags = if let Some(arr) = r.get("tags").and_then(|x| x.as_array()) {
                coerce_string_list(&serde_json::Value::Array(arr.clone())).unwrap_or_default()
            } else {
                Vec::new()
            };

            Some(AiResult::Analyze(AiAnalyzeResult {
                text,
                findings,
                tags,
            }))
        }
    };

    Ok((
        AiResponse {
            ok,
            task,
            result,
            warnings,
            error,
        },
        coerced,
    ))
}

/// AiBridge is the host-side boundary around a local LLM backend (Ollama /api/chat).
///
/// Core contract:
/// - The bridge never executes code. It only returns an AiResponse envelope.
/// - It parses model output leniently but ACCEPTS only strict task/result constraints.
/// - Network/transport errors are represented as AiBridgeError (hard failure).
/// - Model errors and schema violations are represented as AiResponse { ok=false, error=... }.
///
/// Safety posture:
/// - analyze_trace: prefers to return output even if "weird", but adds warnings and enforces minimal invariants.
/// - compile_scenario: strict accept. Any task mismatch, wrong result shape, unknown op, or params not object => fail-closed.
///
/// Operational posture:
/// - Blocking HTTP with a fixed timeout (30s).
/// - Determinism knobs: temperature=0, num_predict from options.max_tokens (default 700).
pub struct AiBridge {
    endpoint: String,
    model: String,
    client: Client,
}

fn ollama_tags_url_from_chat_endpoint(endpoint: &str) -> String {
    let trimmed = endpoint.trim_end_matches('/');

    match trimmed.strip_suffix("/api/chat") {
        Some(base) => format!("{}/api/tags", base),
        None => format!("{}/api/tags", trimmed),
    }
}

impl AiBridge {
    /// Construct an AiBridge with explicit endpoint + model.
    ///
    /// v0 invariants:
    /// - A blocking reqwest client is created with a fixed timeout to prevent hangs.
    /// - Endpoint/model strings are stored as owned Strings (no lifetime coupling).
    pub fn new(
        endpoint: impl Into<String>,
        model: impl Into<String>,
    ) -> Result<Self, AiBridgeError> {
        let client = Client::builder()
            .timeout(Duration::from_secs(30))
            .build()
            .map_err(|e| AiBridgeError::Http(e.to_string()))?;

        Ok(Self {
            endpoint: endpoint.into(),
            model: model.into(),
            client,
        })
    }

    /// Construct from environment variables with stable defaults.
    ///
    /// Env:
    /// - PMS_AI_ENDPOINT overrides DEFAULT_ENDPOINT
    /// - PMS_AI_MODEL overrides DEFAULT_MODEL
    pub fn from_env() -> Result<Self, AiBridgeError> {
        let endpoint =
            std::env::var("PMS_AI_ENDPOINT").unwrap_or_else(|_| DEFAULT_ENDPOINT.to_string());
        let model = std::env::var("PMS_AI_MODEL").unwrap_or_else(|_| DEFAULT_MODEL.to_string());
        Self::new(endpoint, model)
    }

    /// Dispatch a request by task string.
    ///
    /// Important:
    /// - Unknown tasks default to analyze_trace (conservative).
    /// - The called method enforces its own input variant guard (fail-closed).
    pub fn call(&self, req: &AiRequest) -> Result<AiResponse, AiBridgeError> {
        match req.task.as_str() {
            TASK_COMPILE_SCENARIO => self.compile_scenario(req),
            _ => self.analyze_trace(req),
        }
    }

    /// v0: analyze_trace. Blocking HTTP.
    ///
    /// "Parse leniently, accept mostly":
    /// - We accept slight schema drift (lenient JSON parsing).
    /// - We DO NOT enforce task match here (unlike compile_scenario) because analyze is informational.
    /// - We add host-side sanity warnings that flag common model hallucinations (waiting/fulfilled/pending).
    ///
    /// Fail-closed conditions (return ok=false with structured error):
    /// - Wrong input variant (not AiInput::AnalyzeTrace).
    /// - Non-2xx HTTP status.
    /// - Ollama JSON response missing message.content (AiBridgeError).
    /// - Assistant content not valid JSON (invalid_json_from_model).
    pub fn analyze_trace(&self, req: &AiRequest) -> Result<AiResponse, AiBridgeError> {
        trace!(
            "ai_bridge start task={} model={} endpoint={}",
            TASK_ANALYZE_TRACE,
            self.model,
            self.endpoint
        );

        // Guard: this method only accepts analyze_trace input.
        // This is a host-side type safety fence: we do not trust the caller's task string alone.
        let input = match &req.input {
            AiInput::AnalyzeTrace(a) => a,
            _ => {
                return Ok(AiResponse {
                    ok: false,
                    task: TASK_ANALYZE_TRACE.to_string(),
                    result: None,
                    warnings: vec![],
                    error: Some(AiError {
                        code: "invalid_input_for_task".to_string(),
                        message: "analyze_trace requires input.events (AiInputAnalyzeTrace)"
                            .to_string(),
                    }),
                });
            }
        };

        // Determinism knobs (Ollama):
        // - temperature=0 reduces stochastic drift.
        // - num_predict sets an upper bound on assistant output length.
        let mut options = serde_json::json!({ "temperature": 0 });

        // v0 policy: if caller didn't set max_tokens, use a stable default.
        // This avoids "model returns empty" from overly small caps and avoids huge outputs.
        let max_tokens = if req.options.max_tokens == 0 {
            700
        } else {
            req.options.max_tokens
        };
        options["num_predict"] = serde_json::json!(max_tokens);

        // Defensive: ensure the task field embedded in the user JSON matches what we expect.
        // This prevents accidental cross-task prompting if caller passes mismatched req.task.
        let mut req_to_send = req.clone();
        req_to_send.task = TASK_ANALYZE_TRACE.to_string();

        // Ollama request body:
        // - format="json" is best-effort enforcement on the backend side.
        // - system message contains the strict schema prompt.
        // - user message contains the serialized AiRequest JSON.
        let body = OllamaChatRequest {
            model: self.model.clone(),
            stream: false,
            format: Some("json".to_string()),
            messages: vec![
                OllamaMessage {
                    role: "system".to_string(),
                    content: system_prompt_for_task(TASK_ANALYZE_TRACE).to_string(),
                },
                OllamaMessage {
                    role: "user".to_string(),
                    content: serde_json::to_string(&req_to_send)
                        .unwrap_or_else(|_| "{}".to_string()),
                },
            ],
            options: Some(options),
        };

        // === FULL HTTP REQUEST DUMP (ONLY WHEN ENABLED) ===
        if std::env::var("PMS_AI_DEBUG_RAW").ok().as_deref() == Some("1") {
            eprintln!("=== AI HTTP REQ BEGIN ===");
            match serde_json::to_string_pretty(&body) {
                Ok(s) => eprintln!("{}", s),
                Err(e) => eprintln!("(failed to pretty-print request body: {})", e),
            }
            eprintln!("=== AI HTTP REQ END ===");
        }

        trace!(
            "ai_bridge http send task={} max_tokens={}",
            TASK_ANALYZE_TRACE,
            max_tokens
        );

        // Blocking send. Transport errors are "hard" (AiBridgeError),
        // because we do not have a model response to wrap.
        let resp = self
            .client
            .post(&self.endpoint)
            .json(&body)
            .send()
            .map_err(|e| AiBridgeError::Http(e.to_string()))?;

        let status = resp.status();
        let text = resp
            .text()
            .map_err(|e| AiBridgeError::Http(e.to_string()))?;

        // === FULL HTTP RESPONSE DUMP (ONLY WHEN ENABLED) ===
        if std::env::var("PMS_AI_DEBUG_RAW").ok().as_deref() == Some("1") {
            eprintln!("=== AI HTTP RESP BEGIN ===");
            eprintln!("status={}", status);
            eprintln!("{}", text);
            eprintln!("=== AI HTTP RESP END ===");
        }

        trace!("ai_bridge http status={} body_len={}", status, text.len());

        // HTTP non-success:
        // We return an AiResponse error envelope (not AiBridgeError) so callers see a structured "model error".
        // Note: This includes body text, which may be large; consider truncation if logs become noisy.
        if !status.is_success() {
            let body_trunc = trunc_for_log(&text, 0);

            return Ok(AiResponse {
                ok: false,
                task: TASK_ANALYZE_TRACE.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "http_status".to_string(),
                    message: format!("ollama returned status {} body={}", status, body_trunc),
                }),
            });
        }

        // Parse the Ollama wrapper response.
        // If this JSON parse fails, it is treated as an HTTP-level failure (AiBridgeError),
        // because we cannot even reach assistant content.
        let parsed: OllamaChatResponse =
            serde_json::from_str(&text).map_err(|e| AiBridgeError::Http(e.to_string()))?;

        // Extract assistant content. Missing is a hard bridge error (protocol mismatch).
        let content = parsed
            .message
            .ok_or(AiBridgeError::MissingAssistantContent)?
            .content;

        // Optional debug output; truncated to avoid megadumps.
        ai_debug!("assistant_content_len={}", content.len());
        ai_debug!("assistant_content_trunc={}", trunc(&content, 2000));

        // Parse assistant content into AiResponse.
        // This function can recover from mild schema drift but requires valid JSON overall.
        match parse_ai_response_lenient(&content) {
            Ok((mut r, coerced)) => {
                trace!("ai_bridge parse ok coerced_findings={}", coerced);
                trace!(
                    "ai_bridge parsed ok={} warnings={} has_result={}",
                    r.ok,
                    r.warnings.len(),
                    r.result.is_some()
                );

                // If we had to coerce findings items from non-strings to strings,
                // surface this explicitly so the caller can treat output as lower confidence.
                if coerced {
                    r.warnings
                        .push("coerced_nonstring_findings_to_strings".to_string());
                }

                let mut r = enforce_analyze_response_shape(r);
                if !r.ok {
                    return Ok(r);
                }

                // --- v0 host-side sanity checks (warnings only) ---
                //
                // These checks do NOT fail the response; they produce warnings that indicate
                // the model likely contradicted trace semantics.
                //
                // Rationale:
                // - analyze_trace is informational. It's often useful to still return text,
                //   but with visible guardrail flags.

                // Detect whether the trace contains a Λ timeout non_event.
                // We look at msg string because msg is the stable source-of-truth.
                let has_non_event = input
                    .events
                    .iter()
                    .any(|e| e.msg.starts_with("non_event ") || e.msg.contains(" non_event "));

                // Detect integrate events with non-empty consumed list.
                let has_integrate_consumed_any = input.events.iter().any(|e| {
                    e.msg.starts_with("integrate ")
                        && e.msg.contains("consumed=[")
                        && !e.msg.contains("consumed=[]")
                });

                // Detect integrate events with explicit empty consumed list.
                let has_integrate_consumed_empty = input
                    .events
                    .iter()
                    .any(|e| e.msg.starts_with("integrate ") && e.msg.contains("consumed=[]"));

                if let Some(AiResult::Analyze(res)) = r.result.as_ref() {
                    // Build a lowercased "haystack" from text + findings for simple keyword checks.
                    // Note: This is heuristic; it should not be used to assert correctness,
                    // only to flag likely contradictions.
                    let mut haystack = String::new();
                    haystack.push_str(&res.text.to_lowercase());
                    for f in &res.findings {
                        haystack.push('\n');
                        haystack.push_str(&f.to_lowercase());
                    }

                    // If the trace includes a non_event timeout,
                    // the model must not describe the expectation as "waiting" or "awaiting".
                    if has_non_event
                        && (haystack.contains("waiting")
                            || haystack.contains("await")
                            || haystack.contains("awaiting")
                            || haystack.contains("waited")
                            || haystack.contains("still wait")
                            || haystack.contains("still waiting"))
                    {
                        r.warnings.push(
                            "sanity:trace_has_non_event_but_output_suggests_waiting".to_string(),
                        );
                    }

                    // If the trace includes a non_event timeout,
                    // the model must not claim the expectation was fulfilled/met.
                    if has_non_event
                        && (haystack.contains("met after")
                            || haystack.contains("expectation was met")
                            || haystack.contains("fulfilled")
                            || haystack.contains("satisfied"))
                    {
                        r.warnings.push(
                            "sanity:trace_has_non_event_but_output_suggests_fulfilled".to_string(),
                        );
                    }

                    // If integrate consumed=[], the model should not claim any consumption occurred.
                    if has_integrate_consumed_empty
                        && (haystack.contains("consumed")
                            || (haystack.contains("impulse")
                                && (haystack.contains("consum") || haystack.contains("used"))))
                    {
                        r.warnings.push(
                            "sanity:trace_consumed_empty_but_output_claims_consumption".to_string(),
                        );
                    }

                    // If integrate consumed non-empty, the model should not describe impulses as pending.
                    // This is coarse: it flags typical phrases "pending" or "still".
                    if has_integrate_consumed_any
                        && haystack.contains("impulse")
                        && (haystack.contains("pending") || haystack.contains("still"))
                    {
                        r.warnings.push(
                            "sanity:trace_has_consumed_impulses_but_output_suggests_pending"
                                .to_string(),
                        );
                    }
                }

                Ok(r)
            }

            // If assistant content is not valid JSON, we fail-closed with a stable error code.
            // This is a safe envelope return (not a hard AiBridgeError).
            Err(_) => Ok(AiResponse {
                ok: false,
                task: TASK_ANALYZE_TRACE.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "invalid_json_from_model".to_string(),
                    message: "assistant content was not valid AiResponse JSON".to_string(),
                }),
            }),
        }
    }

    /// v0: compile_scenario. Blocking HTTP. Proposes opcodes only.
    ///
    /// This path is "accept strictly":
    /// - task MUST match compile_scenario.
    /// - result MUST contain opcodes (AiResult::Compile).
    /// - opcodes must be non-empty.
    /// - each opcode must normalize to a known canonical operator and pass whitelist.
    /// - params MUST be JSON object.
    ///
    /// Any violation => fail-closed with ok=false and structured error.
    pub fn compile_scenario(&self, req: &AiRequest) -> Result<AiResponse, AiBridgeError> {
        trace!(
            "ai_bridge start task={} model={} endpoint={}",
            TASK_COMPILE_SCENARIO,
            self.model,
            self.endpoint
        );

        // Guard: this method only accepts compile_scenario input.
        // This prevents caller bugs (wrong enum variant) from reaching the model.
        let input = match &req.input {
            AiInput::CompileScenario(c) => c,
            _ => {
                return Ok(AiResponse {
                    ok: false,
                    task: TASK_COMPILE_SCENARIO.to_string(),
                    result: None,
                    warnings: vec![],
                    error: Some(AiError {
                        code: "invalid_input_for_task".to_string(),
                        message:
                            "compile_scenario requires input.description (AiInputCompileScenario)"
                                .to_string(),
                    }),
                });
            }
        };

        // Strong precondition: description must not be empty.
        // This is an easy deterministic guard to avoid garbage requests.
        if input.description.trim().is_empty() {
            return Ok(AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "empty_description".to_string(),
                    message: "compile_scenario requires non-empty input.description".to_string(),
                }),
            });
        }

        // Determinism knobs (Ollama): temperature=0, num_predict=max_tokens (if set).
        let mut options = serde_json::json!({ "temperature": 0 });

        let max_tokens = if req.options.max_tokens == 0 {
            700
        } else {
            req.options.max_tokens
        };
        options["num_predict"] = serde_json::json!(max_tokens);

        // Defensive: enforce correct task string inside the payload.
        let mut req_to_send = req.clone();
        req_to_send.task = TASK_COMPILE_SCENARIO.to_string();

        let body = OllamaChatRequest {
            model: self.model.clone(),
            stream: false,
            format: Some("json".to_string()),
            messages: vec![
                OllamaMessage {
                    role: "system".to_string(),
                    content: system_prompt_for_task(TASK_COMPILE_SCENARIO).to_string(),
                },
                OllamaMessage {
                    role: "user".to_string(),
                    content: serde_json::to_string(&req_to_send)
                        .unwrap_or_else(|_| "{}".to_string()),
                },
            ],
            options: Some(options),
        };

        if std::env::var("PMS_AI_DEBUG_RAW").ok().as_deref() == Some("1") {
            eprintln!("\n=== AI COMPILE HTTP REQ BEGIN ===");
            match serde_json::to_string_pretty(&body) {
                Ok(s) => eprintln!("{}", s),
                Err(e) => eprintln!("(cannot pretty-print request: {})", e),
            }
            eprintln!("=== AI COMPILE HTTP REQ END ===\n");
        }

        trace!(
            "ai_bridge http send task={} desc_len={} max_tokens={}",
            TASK_COMPILE_SCENARIO,
            input.description.len(),
            max_tokens
        );

        // Transport: hard failures are returned as AiBridgeError (no model envelope).
        let resp = self
            .client
            .post(&self.endpoint)
            .json(&body)
            .send()
            .map_err(|e| AiBridgeError::Http(e.to_string()))?;

        let status = resp.status();
        let text = resp
            .text()
            .map_err(|e| AiBridgeError::Http(e.to_string()))?;
        if std::env::var("PMS_AI_DEBUG_RAW").ok().as_deref() == Some("1") {
            eprintln!("\n=== AI COMPILE HTTP RESP BEGIN ===");
            eprintln!("status={}", status);
            eprintln!("{}", text);
            eprintln!("=== AI COMPILE HTTP RESP END ===\n");
        }

        trace!("ai_bridge http status={} body_len={}", status, text.len());

        // Non-success HTTP: return a structured AiResponse error envelope.
        if !status.is_success() {
            let body_trunc = trunc_for_log(&text, 0);

            return Ok(AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "http_status".to_string(),
                    message: format!("ollama returned status {} body={}", status, body_trunc),
                }),
            });
        }

        // Parse Ollama wrapper JSON.
        let parsed: OllamaChatResponse =
            serde_json::from_str(&text).map_err(|e| AiBridgeError::Http(e.to_string()))?;

        // Extract assistant message content.
        let content = parsed
            .message
            .ok_or(AiBridgeError::MissingAssistantContent)?
            .content;

        ai_debug!("assistant_content_len={}", content.len());
        ai_debug!("assistant_content_trunc={}", trunc(&content, 2000));

        // Parse AI response (lenient).
        // If JSON is invalid, fail-closed with stable error.
        let (mut r, _coerced) = match parse_ai_response_lenient(&content) {
            Ok(x) => x,
            Err(_) => {
                return Ok(AiResponse {
                    ok: false,
                    task: TASK_COMPILE_SCENARIO.to_string(),
                    result: None,
                    warnings: vec![],
                    error: Some(AiError {
                        code: "invalid_json_from_model".to_string(),
                        message: "assistant content was not valid AiResponse JSON".to_string(),
                    }),
                });
            }
        };

        trace!("ai_bridge parse ok coerced_findings={}", _coerced);
        trace!(
            "ai_bridge parsed ok={} warnings={} has_result={}",
            r.ok,
            r.warnings.len(),
            r.result.is_some()
        );

        // Host fix: ok=false without error => deterministic error object.
        if !r.ok && r.error.is_none() {
            r.error = Some(AiError {
                code: "model_returned_ok_false".to_string(),
                message: "model returned ok=false without error object".to_string(),
            });
        }

        // --- Host enforcement: task must match exactly ---
        //
        // This is critical because parse_ai_response_lenient defaults task to analyze_trace,
        // and we do not want to accept a compile result under an analyze task label (or vice versa).
        if r.task != TASK_COMPILE_SCENARIO {
            return Ok(AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "task_mismatch".to_string(),
                    message: format!("expected task=compile_scenario, got task={}", r.task),
                }),
            });
        }

        // --- Host enforcement: result must be Compile ---
        //
        // We *take()* the result to avoid cloning; after this point r.result is None.
        // Any wrong result shape => fail-closed.
        let compile = match r.result.take() {
            Some(AiResult::Compile(c)) => c,
            _ => {
                return Ok(AiResponse {
                    ok: false,
                    task: TASK_COMPILE_SCENARIO.to_string(),
                    result: None,
                    warnings: vec![],
                    error: Some(AiError {
                        code: "invalid_result_for_task".to_string(),
                        message: "compile_scenario requires result.opcodes".to_string(),
                    }),
                });
            }
        };

        // Strong requirement: opcodes must not be empty.
        // This avoids "successful" compile responses that do nothing.
        if compile.opcodes.is_empty() {
            return Ok(AiResponse {
                ok: false,
                task: TASK_COMPILE_SCENARIO.to_string(),
                result: None,
                warnings: vec![],
                error: Some(AiError {
                    code: "empty_opcodes".to_string(),
                    message: "compile_scenario returned no opcodes".to_string(),
                }),
            });
        }

        // Validate + canonicalize opcodes.
        //
        // This is the main acceptance gate:
        // - normalize operator names (symbols/aliases/case)
        // - whitelist canonical ops only
        // - require params to be JSON object
        //
        // If invalid: return the produced AiResponse error envelope (fail-closed).
        let validated = match validate_and_canonicalize_opcodes(compile.opcodes) {
            Ok(v) => v,
            Err(resp) => return Ok(*resp),
        };

        // Final consistency:
        // ok should only be true if there is no error.
        // If model said ok=true but error exists, this will force ok=false.
        r.ok = r.ok && r.error.is_none();

        // Reattach validated compile result.
        r.result = Some(AiResult::Compile(AiCompileResult { opcodes: validated }));
        Ok(r)
    }

    /// Health check: fails if the AI backend is not reachable.
    ///
    /// Contract:
    /// - Returns Ok(()) only if the backend responds to Ollama's /api/tags endpoint.
    /// - Returns Err(String) with a readable cause otherwise.
    ///
    /// Endpoint handling:
    /// - DEFAULT_ENDPOINT points to /api/chat.
    /// - ping derives the Ollama base URL and probes /api/tags.
    pub fn ping(&self) -> Result<(), String> {
        let url = ollama_tags_url_from_chat_endpoint(&self.endpoint);

        let resp = self
            .client
            .get(&url)
            .send()
            .map_err(|e| format!("ping: request failed: {}", e))?;

        if !resp.status().is_success() {
            return Err(format!("ping: backend returned HTTP {}", resp.status()));
        }

        Ok(())
    }
}

#[cfg(test)]
mod testmods {
    // a_envelope_basics:
    // - validates that AiResponse/AiRequest baseline serde roundtrips and default fields behave.
    mod a_envelope_basics;

    // f1_analyze_lenient_parse:
    // - exercises parse_ai_response_lenient() for analyze trace results:
    //   coercions, missing fields, findings_not_array warnings, etc.
    mod f1_analyze_lenient_parse;

    // f2_compile_host_enforcement:
    // - exercises compile_scenario strict host gates:
    //   task mismatch, wrong result shape, unknown ops, params not object, etc.
    mod f2_compile_host_enforcement;

    // f3_analyze_host_enforcement:
    // - exercises analyze_trace host gates:
    //   task mismatch, compile-shaped result rejection, missing errors.
    mod f3_analyze_host_enforcement;

    // trunc test
    mod z1_trunc_for_log;

    // ping URL derivation
    mod z2_ping_url;
}
