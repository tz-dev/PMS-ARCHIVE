@echo off
cls

echo === PMS-STACK Evidence Spine Gate Check ===
echo.

cargo fmt --all -- --check
if errorlevel 1 goto fail

cargo test --workspace
if errorlevel 1 goto fail

cargo clippy --workspace --all-targets -- -D warnings
if errorlevel 1 goto fail

echo.
echo === PASS ===
pause
exit /b 0

:fail
echo.
echo === FAIL ===
pause
exit /b 1