#![forbid(unsafe_code)]

use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::Path;

use serde::Deserialize;

/// Loose YAML schema for PMS dependency rules.
///
/// Motivation:
/// - The project may encounter different historical key names in PMS.yaml:
///   - dependency_table
///   - dependencies
///   - dependency_rules
///   - constraints
/// - We want to support these for compatibility without silently accepting multiple tables.
///
/// Design:
/// - We parse all optional keys into the same structure:
///   HashMap<NextOpName, Vec<AllowedPrevOpName>>
/// - We then enforce: at most one of these tables is non-empty (fail-fast).
#[derive(Debug, Clone, Deserialize)]
struct PmsYamlLoose {
    /// Preferred explicit key.
    #[serde(default)]
    dependency_table: Option<HashMap<String, Vec<String>>>,

    /// Legacy / alternative key.
    #[serde(default)]
    dependencies: Option<HashMap<String, Vec<String>>>,

    /// Legacy / alternative key.
    #[serde(default)]
    dependency_rules: Option<HashMap<String, Vec<String>>>,

    /// Legacy / alternative key.
    #[serde(default)]
    constraints: Option<HashMap<String, Vec<String>>>,
}

impl PmsYamlLoose {
    /// Count how many table-keys are present AND non-empty.
    ///
    /// We treat an absent key or an empty map as "not provided".
    /// This allows a YAML file to contain unused keys without changing behavior,
    /// while still failing if *multiple non-empty* tables exist.
    fn nonempty_tables_count(&self) -> usize {
        let mut n = 0usize;

        let is_nonempty = |opt: &Option<HashMap<String, Vec<String>>>| {
            opt.as_ref().map(|m| !m.is_empty()).unwrap_or(false)
        };

        if is_nonempty(&self.dependency_table) {
            n += 1;
        }
        if is_nonempty(&self.dependencies) {
            n += 1;
        }
        if is_nonempty(&self.dependency_rules) {
            n += 1;
        }
        if is_nonempty(&self.constraints) {
            n += 1;
        }

        n
    }

    /// Select the dependency table using a fixed precedence order.
    ///
    /// Important:
    /// - This is only safe because we already fail-fast when more than one non-empty table exists.
    /// - Without that guard, precedence would silently introduce "first wins" bugs.
    fn chosen_table(self) -> Option<HashMap<String, Vec<String>>> {
        // Choose the first non-empty table in a priority order.
        self.dependency_table
            .or(self.dependencies)
            .or(self.dependency_rules)
            .or(self.constraints)
    }
}

/// Parsed PMS model used for adjacency validation.
///
/// Interpretation:
/// - This model encodes adjacency rules (immediate predecessor constraints):
///   next_op -> set of allowed immediate predecessors
///
/// Note:
/// - This is intentionally "v1-style" validation only (local adjacency),
///   not stateful constraints like "frame must exist" or "sealed forbids Ω".
/// - Those stateful constraints belong in a separate pass (your v2 shadow-state validator).
#[derive(Debug, Clone)]
pub struct PmsModel {
    /// Adjacency validation rules (immediate predecessor check):
    /// next_op -> allowed immediate predecessors
    ///
    /// Representation:
    /// - Keys are canonical operator names (normalized).
    /// - Values are canonical operator names (normalized).
    pub dependency_table: HashMap<String, HashSet<String>>,
}

impl PmsModel {
    /// Load a PMS model from a YAML file.
    ///
    /// Steps:
    /// 1) Read file as string.
    /// 2) Parse via `PmsYamlLoose` to accept multiple possible key names.
    /// 3) Fail-fast if *more than one* non-empty table exists.
    /// 4) Normalize all operator keys + values into canonical names.
    /// 5) Store as HashMap<String, HashSet<String>> for fast membership tests.
    pub fn load_from_file(path: impl AsRef<Path>) -> Result<Self, String> {
        let text = fs::read_to_string(path.as_ref())
            .map_err(|e| format!("failed to read PMS.yaml: {}", e))?;

        let parsed: PmsYamlLoose =
            serde_yaml::from_str(&text).map_err(|e| format!("failed to parse yaml: {}", e))?;

        // Fail-fast if more than one non-empty table key is present.
        //
        // Why:
        // - Without this, a YAML author could accidentally provide two tables,
        //   and our selection order would silently ignore one.
        // - This guard makes model changes explicit and prevents precedence bugs.
        let nonempty = parsed.nonempty_tables_count();
        if nonempty > 1 {
            return Err("PMS.yaml contains multiple non-empty dependency tables. \
Keep exactly ONE of: dependency_table, dependencies, dependency_rules, constraints."
                .to_string());
        }

        // Select the one table (or None if YAML contains no table).
        let table_opt = parsed.chosen_table();

        // Internal normalized representation.
        let mut dep: HashMap<String, HashSet<String>> = HashMap::new();

        if let Some(table) = table_opt {
            for (k, v) in table {
                // Normalize the "next" operator key.
                //
                // We reject unknown operator strings here (fail-closed).
                // This prevents a typo in YAML from weakening validation unexpectedly.
                let nk = normalize_op_name(&k)
                    .ok_or_else(|| format!("unknown operator key in model: '{}'", k))?
                    .to_string();

                // Normalize the predecessor list into a set.
                let mut set: HashSet<String> = HashSet::new();
                for prev in v {
                    let np = normalize_op_name(&prev)
                        .ok_or_else(|| format!("unknown predecessor key in model: '{}'", prev))?
                        .to_string();
                    set.insert(np);
                }

                // Merge in case YAML contains multiple variants mapping to the same canonical op.
                //
                // Example:
                // - "Frame" and "Square" both normalize to "Square"
                // If YAML had both as keys, they converge here safely.
                dep.entry(nk).or_default().extend(set);
            }
        }

        Ok(Self {
            dependency_table: dep,
        })
    }

    /// Adjacency validation:
    /// returns true iff `prev` is allowed immediately before `next` according to the table.
    ///
    /// v0 policy (deliberate):
    /// - If `prev` or `next` are unknown (cannot be normalized) => reject (false).
    ///   This is fail-closed for identifiers to prevent typos from being treated as "open world".
    ///
    /// - If `next` is known but has no rule in the table => allow (open world for known operators).
    ///   This avoids needing to fully specify the table for every operator during early iterations.
    ///
    /// Interpretation detail:
    /// - The table is only consulted for `next`. If absent, we allow any known predecessor.
    pub fn allows_predecessor(&self, prev: &str, next: &str) -> bool {
        let p = match normalize_op_name(prev) {
            Some(x) => x,
            None => return false,
        };
        let n = match normalize_op_name(next) {
            Some(x) => x,
            None => return false,
        };

        match self.dependency_table.get(n) {
            // "No rule for this known next operator" => allow anything (open world).
            None => true,
            // Rule exists => must be contained in the allowed predecessor set.
            Some(set) => set.contains(p),
        }
    }

    /// Return the configured allowed immediate predecessors for `next`.
    ///
    /// Returns:
    /// - None if `next` is unknown or if the model has no explicit rule for it.
    /// - Some(sorted_vec) if a rule exists.
    ///
    /// Determinism:
    /// - The internal representation is a HashSet.
    /// - This API sorts before returning so diagnostics remain stable.
    pub fn expected_predecessors(&self, next: &str) -> Option<Vec<String>> {
        let n = normalize_op_name(next)?;
        let set = self.dependency_table.get(n)?;

        let mut out: Vec<String> = set.iter().cloned().collect();
        out.sort();
        Some(out)
    }

    /// Convenience: is the loaded model empty?
    ///
    /// Note:
    /// - Empty model means "open world for all known operators" under `allows_predecessor`.
    pub fn is_empty(&self) -> bool {
        self.dependency_table.is_empty()
    }
}

/// Normalize operator names used in YAML and runtime strings into canonical model keys.
///
/// Canonical output set:
/// - Delta, Nabla, Square, Lambda, Alpha, Omega, Theta, Phi, Chi, Sigma, Psi
///
/// Supported inputs:
/// 1) Symbol form: "Δ", "∇", "□", ...
/// 2) Case-insensitive word form: "delta", "NABLA", "Phi", ...
/// 3) Runtime aliases that map to theoretical canonical names:
///    - "frame"      -> "Square"
///    - "attractor"  -> "Alpha"
///
/// Returns:
/// - Some(&'static str) for known inputs
/// - None for unknown inputs (fail-closed for identifiers)
pub fn normalize_op_name(s: &str) -> Option<&'static str> {
    let t = s.trim();

    // Symbols (exact match).
    match t {
        "Δ" => return Some("Delta"),
        "∇" => return Some("Nabla"),
        "□" => return Some("Square"),
        "Λ" => return Some("Lambda"),
        "Α" => return Some("Alpha"),
        "Ω" => return Some("Omega"),
        "Θ" => return Some("Theta"),
        "Φ" => return Some("Phi"),
        "Χ" => return Some("Chi"),
        "Σ" => return Some("Sigma"),
        "Ψ" => return Some("Psi"),
        _ => {}
    }

    // Case-insensitive keys + runtime aliases.
    match t.to_ascii_lowercase().as_str() {
        // canonical keys
        "delta" => Some("Delta"),
        "nabla" => Some("Nabla"),
        "square" => Some("Square"),
        "lambda" => Some("Lambda"),
        "alpha" => Some("Alpha"),
        "omega" => Some("Omega"),
        "theta" => Some("Theta"),
        "phi" => Some("Phi"),
        "chi" => Some("Chi"),
        "sigma" => Some("Sigma"),
        "psi" => Some("Psi"),

        // runtime keys -> theoretical canonical
        //
        // Important:
        // - The kernel uses Operator::Frame and Operator::Attractor,
        //   but the theoretical PMS symbols are □ (Square) and Α (Alpha).
        // - The model operates in the theoretical canonical space.
        "frame" => Some("Square"),
        "attractor" => Some("Alpha"),

        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Write YAML to a temporary file path.
    ///
    /// Properties:
    /// - Unique filename by (test name, PID, nanos) to avoid collisions.
    /// - Uses OS temp_dir; caller is responsible for cleanup.
    fn write_temp_yaml(name: &str, contents: &str) -> std::path::PathBuf {
        let mut p = std::env::temp_dir();
        p.push(format!(
            "pms_model_{}_{}_{}.yaml",
            name,
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::write(&p, contents).unwrap();
        p
    }

    #[test]
    fn empty_model_allows_everything_for_known_ops_only() {
        let m = PmsModel {
            dependency_table: HashMap::new(),
        };

        // Known ops -> open world (because there is no rule for next).
        assert!(m.allows_predecessor("Delta", "Theta"));

        // Unknown ops rejected (strict for unknown identifiers).
        assert!(!m.allows_predecessor("Foo", "Bar"));
    }

    #[test]
    fn dependency_table_is_loaded_from_any_supported_key() {
        // Use "dependencies" key for this test.
        let yaml = r#"
dependencies:
  Theta: [Delta]
"#;

        let parsed: PmsYamlLoose = serde_yaml::from_str(yaml).unwrap();

        // Mirror the chosen-table logic explicitly in the test to ensure
        // that at least one supported key is recognized.
        let table_opt = parsed
            .dependency_table
            .or(parsed.dependencies)
            .or(parsed.dependency_rules)
            .or(parsed.constraints);

        assert!(table_opt.is_some());
        let table = table_opt.unwrap();
        assert_eq!(table.get("Theta").unwrap(), &vec!["Delta".to_string()]);
    }

    #[test]
    fn load_fails_fast_if_multiple_dependency_tables_present() {
        let yaml = r#"
dependency_table:
  Theta: [Delta]
dependencies:
  Omega: [Square]
"#;

        let p = write_temp_yaml("multi_tables", yaml);
        let res = PmsModel::load_from_file(&p);
        let _ = std::fs::remove_file(&p);

        assert!(res.is_err());
        let msg = res.err().unwrap();
        assert!(msg.contains("multiple non-empty dependency tables"));
    }

    #[test]
    fn normalize_symbols_and_runtime_aliases() {
        assert_eq!(normalize_op_name("□"), Some("Square"));
        assert_eq!(normalize_op_name("Frame"), Some("Square"));
        assert_eq!(normalize_op_name("Α"), Some("Alpha"));
        assert_eq!(normalize_op_name("Attractor"), Some("Alpha"));
        assert_eq!(normalize_op_name("Σ"), Some("Sigma"));
        assert_eq!(normalize_op_name("sigma"), Some("Sigma"));
    }

    #[test]
    fn normalize_unknown_returns_none() {
        assert_eq!(normalize_op_name("Whatever"), None);
    }

    #[test]
    fn allows_predecessor_works_across_aliases() {
        // dependency_table: next -> allowed prevs
        let mut dep: HashMap<String, HashSet<String>> = HashMap::new();
        dep.entry("Square".to_string())
            .or_default()
            .insert("Delta".to_string());

        let m = PmsModel {
            dependency_table: dep,
        };

        // next="Frame" normalizes to Square; prev="Δ" normalizes to Delta
        assert!(m.allows_predecessor("Δ", "Frame"));
        assert!(m.allows_predecessor("Delta", "Square"));
        assert!(!m.allows_predecessor("Theta", "Frame"));
    }

    #[test]
    fn expected_predecessors_are_sorted_and_normalized() {
        let mut dep: HashMap<String, HashSet<String>> = HashMap::new();
        dep.entry("Omega".to_string())
            .or_default()
            .extend(["Square".to_string(), "Alpha".to_string()]);

        let m = PmsModel {
            dependency_table: dep,
        };

        assert_eq!(
            m.expected_predecessors("Ω"),
            Some(vec!["Alpha".to_string(), "Square".to_string()])
        );

        assert_eq!(
            m.expected_predecessors("Omega"),
            Some(vec!["Alpha".to_string(), "Square".to_string()])
        );

        assert_eq!(m.expected_predecessors("Delta"), None);
        assert_eq!(m.expected_predecessors("Whatever"), None);
    }

    #[test]
    fn loads_real_pms_yaml_non_empty_dependency_table() {
        let pms_yaml =
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../pms-model-data/PMS.yaml");

        let model = PmsModel::load_from_file(&pms_yaml)
            .unwrap_or_else(|e| panic!("failed to load real PMS.yaml: {}", e));

        assert!(
            !model.is_empty(),
            "real pms-model-data/PMS.yaml must load a non-empty top-level dependency_table"
        );

        assert!(
            model.dependency_table.contains_key("Square"),
            "real PMS.yaml dependency_table must contain Square"
        );

        assert!(
            model.dependency_table.contains_key("Omega"),
            "real PMS.yaml dependency_table must contain Omega"
        );

        assert!(
            model.dependency_table.contains_key("Sigma"),
            "real PMS.yaml dependency_table must contain Sigma"
        );

        assert!(
            model.allows_predecessor("Attractor", "Omega"),
            "runtime alias Attractor should normalize to Alpha and allow Omega"
        );

        assert!(
            model.allows_predecessor("Alpha", "Omega"),
            "Alpha -> Omega should be valid"
        );

        assert!(
            !model.allows_predecessor("Delta", "Omega"),
            "Delta -> Omega should not be valid as direct adjacency"
        );

        assert!(
            model.allows_predecessor("Frame", "Lambda"),
            "runtime alias Frame should normalize to Square for Lambda"
        );

        assert!(
            model.allows_predecessor("□", "Lambda"),
            "symbol □ should normalize to Square for Lambda"
        );

        assert!(
            model.allows_predecessor("Nabla", "Sigma"),
            "Nabla -> Sigma should be valid for the Rust v0.1 runtime adjacency profile"
        );
    }
}
