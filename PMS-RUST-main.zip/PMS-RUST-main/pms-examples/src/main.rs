use pms_ir::PmsBuilder;
use pms_kernel::Kernel;

fn main() {
    let mut b = PmsBuilder::new();
    b.entity("agent");
    b.advance(1);
    b.advance(2);

    let program = b.finish();

    let mut k = Kernel::new(program);
    match k.run_until_finished(None) {
        Ok(()) => {
            println!("OK. tick={}", k.state.tick);
            for e in k.state.events {
                println!("[tick {}] {:?} {}", e.tick, e.op, e.msg);
            }
        }
        Err(e) => {
            eprintln!("Kernel error: {}", e);
            std::process::exit(1);
        }
    }
}
