#![forbid(unsafe_code)]

use std::collections::HashMap;

use pms_kernel::{OpCode, OpParams, Operator};

/// Logical entity handle used by the builder.
///
/// Note:
/// - In kernel v0, entities are not persisted as kernel state.
/// - This id exists purely in the builder to allow future ops to reference
///   entities in a stable way (once kernel-side entity state exists).
pub type EntityId = u32;

/// Builder for small PMS programs (kernel v0).
///
/// What this builder does:
/// - Accumulates a sequence of opcodes (`Vec<OpCode>`) to be executed by the kernel.
/// - Maintains a local symbol table (name -> EntityId) so calls can be made by name
///   while keeping stable ids for later expansion.
///
/// v0 notes:
/// - The kernel emits Δ events but does not persist entity state yet.
/// - We still emit Δ opcodes to keep the program timeline canonical and tool-friendly.
/// - The builder's entity map is purely a convenience layer (not kernel truth).
///
/// Runtime note (kernel v0):
/// - Χ is currently used as an *isolation* operator in the runtime (controlled deviation
///   from the theoretical PMS meaning "Distance").
/// - Therefore we expose `isolation_enter/exit`, plus REPL-friendly aliases
///   (`chi_enter/chi_exit` and `chi`) for ergonomics.
#[derive(Debug, Default)]
pub struct PmsBuilder {
    /// The buffered opcode program in construction order.
    program: Vec<OpCode>,

    /// Monotonic id source for builder-local entity ids.
    /// Saturating add keeps deterministic behavior on overflow (though practically unreachable).
    next_entity_id: EntityId,

    /// Builder-local symbol table: entity name -> builder-local id.
    /// This does not affect kernel state in v0; it's for future-proofing and ergonomics.
    entities_by_name: HashMap<String, EntityId>,
}

impl PmsBuilder {
    /// Create an empty builder.
    pub fn new() -> Self {
        Self::default()
    }

    /// Δ: Create (or return existing) entity id.
    ///
    /// Semantics:
    /// - If `name` already exists, returns the existing id and emits no opcode.
    /// - Otherwise allocates a new id, stores it, and emits a Δ opcode.
    ///
    /// Why emit Δ even if the kernel doesn't persist entities yet?
    /// - The opcode stream is the canonical execution timeline.
    /// - Tooling/analysis can rely on the Δ event being present for "entity introduction".
    pub fn entity(&mut self, name: &str) -> EntityId {
        if let Some(id) = self.entities_by_name.get(name).copied() {
            return id;
        }

        let id = self.next_entity_id;
        self.next_entity_id = self.next_entity_id.saturating_add(1);

        self.entities_by_name.insert(name.to_string(), id);

        // Emit Δ opcode (timeline truth), even if kernel doesn't persist entities yet.
        self.program.push(OpCode::new(
            Operator::Delta,
            OpParams::NewEntity {
                name: name.to_string(),
            },
        ));

        id
    }

    /// Ω: Add an asymmetry edge in the current frame (minimal v0).
    ///
    /// Kernel constraints:
    /// - Requires an active frame at runtime.
    /// - Forbidden after Ψ sealing the current frame (B8).
    pub fn omega(&mut self, from: &str, to: &str, weight: f32, desc: &str) {
        self.program.push(OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: from.to_string(),
                to: to.to_string(),
                weight,
                desc: desc.to_string(),
            },
        ));
    }

    /// Θ: Advance time.
    ///
    /// Encoding rule:
    /// - dt == 0 => emit Θ with `None` (kernel interprets as dt=1 in v0)
    /// - dt  > 0 => emit Θ with `Advance { dt }`
    ///
    /// Rationale:
    /// - `None` acts as a compact "default tick" step.
    /// - Preserves a stable, low-friction REPL/program authoring experience.
    pub fn advance(&mut self, dt: u64) {
        if dt == 0 {
            self.program
                .push(OpCode::new(Operator::Theta, OpParams::None));
        } else {
            self.program
                .push(OpCode::new(Operator::Theta, OpParams::Advance { dt }));
        }
    }

    /// ∇: Add an impulse (minimal v0).
    ///
    /// Kernel constraints:
    /// - Requires an active frame at runtime.
    /// - Impulses are frame-scoped (recorded with Some(frame_id)).
    pub fn impulse(&mut self, entity: &str, intensity: f32, desc: &str) {
        self.program.push(OpCode::new(
            Operator::Nabla,
            OpParams::Impulse {
                entity: entity.to_string(),
                intensity,
                desc: desc.to_string(),
            },
        ));
    }

    /// Σ: Integrate current frame (minimal v0).
    ///
    /// Kernel constraints:
    /// - Requires an active frame.
    /// - v0 decision: allowed even after Ψ sealing the frame (variant B).
    pub fn integrate(&mut self, note: &str) {
        self.program.push(OpCode::new(
            Operator::Sigma,
            OpParams::Integrate {
                note: note.to_string(),
            },
        ));
    }

    /// Λ: Create an expectation that may time out into a non-event.
    ///
    /// Kernel semantics:
    /// - Expectations can be frame-affine (if a frame is active at creation time).
    /// - Θ advancement triggers timeout checks and emits "non_event" records.
    pub fn expect(&mut self, horizon: u64, desc: &str) {
        self.program.push(OpCode::new(
            Operator::Lambda,
            OpParams::Expectation {
                horizon,
                desc: desc.to_string(),
            },
        ));
    }

    /// Append a raw opcode (escape hatch).
    ///
    /// Use this sparingly:
    /// - It bypasses builder-level ergonomics and invariants.
    /// - It is still useful for tests and for experimenting with new params.
    pub fn push(&mut self, opcode: OpCode) {
        self.program.push(opcode);
    }

    /// Take the currently built program and reset the internal buffer.
    ///
    /// Intended for REPL-style usage:
    /// - You can keep using the builder (entity table stays intact)
    /// - but "commit" the currently buffered opcodes into a standalone program.
    pub fn take_program(&mut self) -> Vec<OpCode> {
        std::mem::take(&mut self.program)
    }

    /// Finish building and return the program.
    ///
    /// Note:
    /// - This consumes the builder, freezing its symbol table and buffered program.
    #[must_use]
    pub fn finish(self) -> Vec<OpCode> {
        self.program
    }

    /// Optional helper: how many opcodes currently buffered?
    pub fn len(&self) -> usize {
        self.program.len()
    }

    /// Optional helper: is the opcode buffer empty?
    pub fn is_empty(&self) -> bool {
        self.program.is_empty()
    }

    /// Read-only view of the currently buffered opcode program.
    ///
    /// Important:
    /// - This does NOT drain the buffer.
    /// - REPL `show`/`show json` use this to inspect the pending program before `run`.
    #[must_use]
    pub fn program(&self) -> &[OpCode] {
        &self.program
    }

    /// □: Create a new frame (minimal v0).
    ///
    /// Kernel semantics:
    /// - Pushes a new frame onto the frame stack.
    /// - New frames start unsealed.
    pub fn frame(&mut self, kind: &str) {
        self.program.push(OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: kind.to_string(),
            },
        ));
    }

    /// □: Alias for `frame` (symbol-oriented naming).
    pub fn square(&mut self, kind: &str) {
        self.frame(kind);
    }

    /// Α: Add/increment an attractor in the current frame.
    ///
    /// Kernel constraints:
    /// - Requires an active frame.
    /// - Forbidden after Ψ sealing the current frame (B8).
    pub fn attractor(&mut self, label: &str) {
        self.program.push(OpCode::new(
            Operator::Attractor,
            OpParams::Attractor {
                label: label.to_string(),
            },
        ));
    }

    /// Φ: Recontextualize / reframe (minimal v0).
    ///
    /// Kernel semantics:
    /// - Allowed without an active frame (frame_id is optional in events).
    pub fn reframe(&mut self, from: &str, to: &str) {
        self.program.push(OpCode::new(
            Operator::Phi,
            OpParams::Reframe {
                from: from.to_string(),
                to: to.to_string(),
            },
        ));
    }

    /// Χ: Enter a new isolation scope.
    ///
    /// Kernel semantics:
    /// - Isolation is a stack (LIFO).
    /// - B8: entering a new isolation is forbidden if the current isolation is sealed.
    pub fn isolation_enter(&mut self, label: &str) {
        self.program.push(OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter {
                label: label.to_string(),
            },
        ));
    }

    /// Χ: Exit current isolation scope (LIFO).
    ///
    /// Kernel semantics:
    /// - Error if no isolation is active.
    /// - Allowed even if the isolation was sealed by Ψ (B8).
    pub fn isolation_exit(&mut self) {
        self.program
            .push(OpCode::new(Operator::Chi, OpParams::IsolationExit));
    }

    /// Χ: REPL-style alias for entering isolation.
    pub fn chi_enter(&mut self, label: &str) {
        self.isolation_enter(label);
    }

    /// Χ: REPL-style alias for exiting isolation.
    pub fn chi_exit(&mut self) {
        self.isolation_exit();
    }

    /// Χ: Backwards-compatible alias for entering isolation (REPL ergonomics).
    pub fn chi(&mut self, label: &str) {
        self.isolation_enter(label);
    }

    /// Ψ: Commit / self-binding (minimal v0).
    ///
    /// Kernel semantics:
    /// - Records a commit event.
    /// - B8: seals the current frame and current isolation (if present).
    /// - Creates a commit snapshot anchor for tests/tooling.
    pub fn commit(&mut self, note: &str) {
        self.program.push(OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: note.to_string(),
            },
        ));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn entity_is_idempotent_and_emits_single_delta() {
        let mut b = PmsBuilder::new();
        let a1 = b.entity("agent");
        let a2 = b.entity("agent");
        assert_eq!(a1, a2);

        let program = b.finish();
        let delta_count = program.iter().filter(|op| op.op == Operator::Delta).count();
        assert_eq!(delta_count, 1);
    }

    #[test]
    fn advance_emits_theta() {
        let mut b = PmsBuilder::new();
        b.advance(1);
        b.advance(5);

        let program = b.finish();
        assert_eq!(program.len(), 2);
        assert_eq!(program[0].op, Operator::Theta);
        assert_eq!(program[1].op, Operator::Theta);
    }

    #[test]
    fn chi_aliases_emit_chi() {
        let mut b = PmsBuilder::new();
        b.chi_enter("iso");
        b.chi_exit();

        let program = b.finish();
        assert_eq!(program.len(), 2);
        assert_eq!(program[0].op, Operator::Chi);
        assert_eq!(program[1].op, Operator::Chi);
    }

    #[test]
    fn program_view_does_not_drain_buffer() {
        let mut b = PmsBuilder::new();
        b.frame("ctx");
        b.commit("done");

        let view = b.program();
        assert_eq!(view.len(), 2);
        assert_eq!(view[0].op, Operator::Frame);
        assert_eq!(view[1].op, Operator::Psi);

        assert_eq!(b.len(), 2);

        let program = b.take_program();
        assert_eq!(program.len(), 2);
        assert!(b.is_empty());
    }
}
