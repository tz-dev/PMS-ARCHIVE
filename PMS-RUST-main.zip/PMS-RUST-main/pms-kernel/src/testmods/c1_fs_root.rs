use crate::*;

#[test]
fn c1_fs_root_exists_on_new_state() {
    let s = KernelState::new();

    // root id is stored
    assert_eq!(s.fs_root, 0, "expected fs_root to be 0");

    // nodes contain root
    let root = s
        .fs_nodes
        .iter()
        .find(|n| n.id == s.fs_root)
        .expect("expected root node to exist in fs_nodes");

    assert_eq!(root.name, "/", "root name must be '/'");
    assert_eq!(root.parent, None, "root parent must be None");
}

#[test]
fn c1_fs_root_is_directory() {
    let s = KernelState::new();
    let root = s
        .fs_nodes
        .iter()
        .find(|n| n.id == s.fs_root)
        .expect("expected root node to exist in fs_nodes");

    assert_eq!(root.kind, FsNodeKind::Directory, "root must be a Directory");
    assert!(
        root.data.is_none(),
        "directory must not store data (data=None)"
    );
}
