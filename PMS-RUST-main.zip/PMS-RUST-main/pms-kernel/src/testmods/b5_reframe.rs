use crate::{Kernel, OpCode, OpParams, Operator};

#[test]
fn phi_records_reframe_with_optional_frame() {
    // with frame (matches your REPL output style)
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Phi,
            OpParams::Reframe {
                from: "threat".into(),
                to: "challenge".into(),
            },
        ),
        OpCode::new(Operator::Theta, OpParams::Advance { dt: 1 }),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.tick, 1);

    // ensure event exists and is Φ
    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Phi && e.msg.contains("reframe"))
    );
}

#[test]
fn phi_works_without_frame() {
    // optional frame_id should be None
    let program = vec![OpCode::new(
        Operator::Phi,
        OpParams::Reframe {
            from: "a".into(),
            to: "b".into(),
        },
    )];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Phi && e.msg.contains("frame_id=None"))
    );
}
