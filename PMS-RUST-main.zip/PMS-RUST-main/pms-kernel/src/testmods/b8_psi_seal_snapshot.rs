use crate::{Kernel, OpCode, OpParams, Operator};

// helper: run program and return (result, kernel)
fn run_prog(program: Vec<OpCode>) -> (Result<(), String>, Kernel) {
    let mut k = Kernel::new(program);
    let res = k.run_until_finished(None);
    (res, k)
}

fn frame(kind: &str) -> OpCode {
    OpCode::new(
        Operator::Frame,
        OpParams::NewFrame {
            kind: kind.to_string(),
        },
    )
}
fn psi(note: &str) -> OpCode {
    OpCode::new(
        Operator::Psi,
        OpParams::Commit {
            note: note.to_string(),
        },
    )
}
fn omega(from: &str, to: &str, w: f32, desc: &str) -> OpCode {
    OpCode::new(
        Operator::Omega,
        OpParams::Asymmetry {
            from: from.to_string(),
            to: to.to_string(),
            weight: w,
            desc: desc.to_string(),
        },
    )
}
fn attractor(label: &str) -> OpCode {
    OpCode::new(
        Operator::Attractor,
        OpParams::Attractor {
            label: label.to_string(),
        },
    )
}
fn chi_enter(label: &str) -> OpCode {
    OpCode::new(
        Operator::Chi,
        OpParams::IsolationEnter {
            label: label.to_string(),
        },
    )
}
fn chi_exit() -> OpCode {
    OpCode::new(Operator::Chi, OpParams::IsolationExit)
}
fn entity(name: &str) -> OpCode {
    OpCode::new(
        Operator::Delta,
        OpParams::NewEntity {
            name: name.to_string(),
        },
    )
}
fn impulse(entity: &str, intensity: f32, desc: &str) -> OpCode {
    OpCode::new(
        Operator::Nabla,
        OpParams::Impulse {
            entity: entity.to_string(),
            intensity,
            desc: desc.to_string(),
        },
    )
}
fn integrate(note: &str) -> OpCode {
    OpCode::new(
        Operator::Sigma,
        OpParams::Integrate {
            note: note.to_string(),
        },
    )
}

#[test]
fn b8_psi_seals_current_frame() {
    // Arrange
    let program = vec![frame("training"), psi("seal")];

    // Act
    let (res, k) = run_prog(program);

    // Assert
    assert!(res.is_ok(), "expected ok run, got: {:?}", res);

    let frame_id = k.state.current_frame_id().expect("frame should exist");
    let f = k
        .state
        .frames
        .iter()
        .find(|f| f.id == frame_id)
        .expect("frame in frames vec");

    // requires: Frame { sealed: bool }
    assert!(f.sealed, "expected current frame sealed=true after psi");

    // commit event exists
    assert!(
        k.state
            .commits
            .iter()
            .any(|c| c.frame_id == Some(frame_id) && c.note == "seal"),
        "expected CommitEvent recorded"
    );
}

#[test]
fn b8_psi_seals_current_isolation_if_active() {
    let program = vec![frame("training"), chi_enter("iso1"), psi("seal")];
    let (res, k) = run_prog(program);
    assert!(res.is_ok(), "expected ok run, got: {:?}", res);

    let iso_id = k
        .state
        .current_isolation_id()
        .expect("isolation should exist");
    let iso = k
        .state
        .isolations
        .iter()
        .find(|i| i.id == iso_id)
        .expect("iso in vec");

    // requires: Isolation { sealed: bool }
    assert!(
        iso.sealed,
        "expected current isolation sealed=true after psi"
    );

    assert!(
        k.state
            .commits
            .iter()
            .any(|c| c.isolation_id == Some(iso_id) && c.note == "seal"),
        "expected CommitEvent with isolation_id recorded"
    );
}

#[test]
fn b8_sealed_frame_forbids_omega() {
    let program = vec![frame("training"), psi("seal"), omega("A", "B", 0.7, "x")];
    let (res, k) = run_prog(program);

    assert!(res.is_err(), "expected error, got ok");
    let err = res.err().unwrap();
    assert!(
        err.contains("sealed"),
        "error should mention sealed, got: {}",
        err
    );
    assert!(
        err.contains("Ω") || err.to_lowercase().contains("omega"),
        "error should mention omega, got: {}",
        err
    );

    // no new asymmetry added
    assert_eq!(
        k.state.asymmetries.len(),
        0,
        "asymmetry must not be recorded when forbidden"
    );
}

#[test]
fn b8_sealed_frame_forbids_attractor() {
    let program = vec![frame("training"), psi("seal"), attractor("X")];
    let (res, k) = run_prog(program);

    assert!(res.is_err(), "expected error, got ok");
    let err = res.err().unwrap();
    assert!(
        err.contains("sealed"),
        "error should mention sealed, got: {}",
        err
    );
    assert!(
        err.contains("Α") || err.to_lowercase().contains("attractor"),
        "error should mention attractor, got: {}",
        err
    );

    assert_eq!(
        k.state.attractors.len(),
        0,
        "attractor must not be recorded when forbidden"
    );
}

#[test]
fn b8_sealed_isolation_forbids_chi_enter() {
    let program = vec![
        frame("training"),
        chi_enter("iso1"),
        psi("seal"),
        chi_enter("iso2"),
    ];
    let (res, k) = run_prog(program);

    assert!(res.is_err(), "expected error, got ok");
    let err = res.err().unwrap();
    assert!(
        err.contains("sealed"),
        "error should mention sealed, got: {}",
        err
    );
    assert!(
        err.contains("Χ") || err.to_lowercase().contains("chi"),
        "error should mention chi, got: {}",
        err
    );

    // still only one isolation on stack
    assert_eq!(k.state.isolation_stack.len(), 1);
    let top = k.state.current_isolation_id().unwrap();
    let iso = k.state.isolations.iter().find(|i| i.id == top).unwrap();
    assert_eq!(iso.label, "iso1");
}

#[test]
fn b8_sealed_isolation_allows_chi_exit() {
    let program = vec![
        frame("training"),
        chi_enter("iso1"),
        psi("seal"),
        chi_exit(),
    ];
    let (res, k) = run_prog(program);

    assert!(res.is_ok(), "expected ok, got: {:?}", res);
    assert_eq!(
        k.state.isolation_stack.len(),
        0,
        "should be able to exit sealed isolation"
    );
}

#[test]
fn b8_sealed_frame_allows_integrate() {
    // We choose "Seal freezes structure, not integration"
    let program = vec![
        frame("training"),
        entity("e"),
        impulse("e", 0.5, "i1"),
        psi("seal"),
        integrate("n"),
    ];
    let (res, k) = run_prog(program);

    assert!(res.is_ok(), "expected ok, got: {:?}", res);
    assert_eq!(
        k.state.integration_log.len(),
        1,
        "integration should be allowed after seal"
    );
}

#[test]
fn b8_psi_creates_commit_snapshot() {
    // Requires: KernelState.commit_snapshots and CommitSnapshot struct
    let program = vec![frame("training"), chi_enter("iso1"), psi("snap")];
    let (res, k) = run_prog(program);
    assert!(res.is_ok(), "expected ok, got: {:?}", res);

    assert_eq!(k.state.commit_snapshots.len(), 1, "expected one snapshot");
    let snap = &k.state.commit_snapshots[0];

    assert_eq!(snap.note, "snap");
    assert_eq!(snap.frame_id, k.state.current_frame_id());
    assert_eq!(snap.isolation_id, k.state.current_isolation_id());

    // cheap anchors make this snapshot useful later
    assert!(snap.event_len >= 1);
}

#[test]
fn b8_sealed_frame_allows_new_frame_and_new_frame_is_not_sealed() {
    // frame A; psi => A sealed
    // frame B must still be allowed and must start unsealed.
    // omega must succeed in frame B.
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "A".to_string(),
            },
        ),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "seal_A".to_string(),
            },
        ),
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "B".to_string(),
            },
        ),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "x".to_string(),
                to: "y".to_string(),
                weight: 0.7,
                desc: "ok_in_B".to_string(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    let res = k.run_until_finished(None);
    assert!(res.is_ok(), "expected program to succeed, got: {:?}", res);

    // assert: we have 2 frames and stack top is B
    assert_eq!(k.state.frames.len(), 2);
    let a = &k.state.frames[0];
    let b = &k.state.frames[1];

    // A is sealed
    assert_eq!(a.kind, "A");
    assert!(a.sealed, "expected frame A sealed after psi");

    // B is not sealed by default
    assert_eq!(b.kind, "B");
    assert!(!b.sealed, "expected new frame B to start unsealed");

    // omega edge should exist and belong to B (current frame at the time of omega)
    assert_eq!(k.state.asymmetries.len(), 1);
    let edge = &k.state.asymmetries[0];
    assert_eq!(
        edge.frame_id, b.id,
        "expected omega edge recorded in frame B"
    );
}

#[test]
fn b8_multiple_psi_create_multiple_snapshots_in_order() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".to_string(),
            },
        ),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "c1".to_string(),
            },
        ),
        OpCode::new(Operator::Theta, OpParams::Advance { dt: 1 }),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "c2".to_string(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    let res = k.run_until_finished(None);
    assert!(res.is_ok(), "expected program to succeed, got: {:?}", res);

    assert_eq!(k.state.commit_snapshots.len(), 2);

    let s0 = &k.state.commit_snapshots[0];
    let s1 = &k.state.commit_snapshots[1];

    // ids increment (because CommitId increments in record_commit)
    assert_eq!(s0.id, 0);
    assert_eq!(s1.id, 1);

    // tick ordering (first psi at tick 0, theta advances to 1, second psi at tick 1)
    assert_eq!(s0.tick, 0);
    assert_eq!(s1.tick, 1);

    // notes preserved
    assert_eq!(s0.note, "c1");
    assert_eq!(s1.note, "c2");

    // both snapshots should reference the same current frame (training)
    assert_eq!(s0.frame_id, Some(0));
    assert_eq!(s1.frame_id, Some(0));
}

#[test]
fn b8_snapshot_event_len_is_pre_commit_emit() {
    let program = vec![frame("training"), psi("snap")];

    let (res, k) = run_prog(program);
    assert!(res.is_ok(), "expected ok, got: {:?}", res);

    let snap = k.state.commit_snapshots.last().expect("snapshot exists");

    // Snapshot is taken BEFORE emit(Psi), therefore it is exactly one behind
    // the final event count (which includes the Ψ event).
    assert_eq!(
        snap.event_len + 1,
        k.state.events.len(),
        "expected snapshot.event_len to be pre-Ψ emit"
    );
}
