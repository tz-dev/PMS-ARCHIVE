use crate::*;

#[test]
fn omega_event_weight_format_stable() {
    let program = vec![
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "A".into() }),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "x".into(),
                to: "y".into(),
                weight: 0.7,
                desc: "d".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    let msg = k
        .state
        .events
        .iter()
        .find(|e| e.op == Operator::Omega)
        .unwrap()
        .msg
        .clone();

    assert!(msg.contains("weight=0.700000"), "msg={}", msg);
}
