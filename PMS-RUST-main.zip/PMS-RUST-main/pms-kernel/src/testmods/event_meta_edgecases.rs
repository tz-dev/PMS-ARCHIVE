// pms-kernel/src/testmods/event_meta_edgecases.rs
#![forbid(unsafe_code)]

use crate::KernelState;

#[test]
fn event_meta_parses_kind_only() {
    let meta = KernelState::parse_event_meta("commit").expect("meta must exist");
    assert_eq!(meta.kind, "commit");
    assert!(meta.kv.is_empty());
}

#[test]
fn event_meta_ignores_tokens_without_equals() {
    let meta = KernelState::parse_event_meta("commit foo a=b bar").expect("meta must exist");
    assert_eq!(meta.kind, "commit");
    assert_eq!(meta.kv.get("a").map(|s| s.as_str()), Some("b"));

    // "foo" and "bar" have no '=' => must not appear
    assert!(!meta.kv.contains_key("foo"));
    assert!(!meta.kv.contains_key("bar"));
}
