use crate::{Kernel, OpCode, OpParams, Operator};

#[test]
fn psi_records_commit_with_optional_frame_and_isolation() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter {
                label: "isoA".into(),
            },
        ),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "checkpoint1".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.commits.len(), 1);
    let c = &k.state.commits[0];
    assert_eq!(c.id, 0);
    assert_eq!(c.frame_id, Some(0));
    assert_eq!(c.isolation_id, Some(0));
    assert_eq!(c.note, "checkpoint1");

    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Psi && e.msg.contains("commit"))
    );
}

#[test]
fn psi_works_without_frame_or_isolation() {
    let program = vec![OpCode::new(
        Operator::Psi,
        OpParams::Commit {
            note: "bare".into(),
        },
    )];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.commits.len(), 1);
    assert_eq!(k.state.commits[0].frame_id, None);
    assert_eq!(k.state.commits[0].isolation_id, None);
}

#[test]
fn psi_ids_increment() {
    let program = vec![
        OpCode::new(Operator::Psi, OpParams::Commit { note: "a".into() }),
        OpCode::new(Operator::Psi, OpParams::Commit { note: "b".into() }),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.commits.len(), 2);
    assert_eq!(k.state.commits[0].id, 0);
    assert_eq!(k.state.commits[1].id, 1);
}
