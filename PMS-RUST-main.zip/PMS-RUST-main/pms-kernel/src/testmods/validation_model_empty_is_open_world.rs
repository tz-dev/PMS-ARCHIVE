// pms-kernel/src/testmods/validation_model_empty_is_open_world.rs

#![forbid(unsafe_code)]

use std::fs;
use std::path::PathBuf;

use crate::{Kernel, OpCode, OpParams, Operator};
use pms_model::PmsModel;

fn write_temp_yaml(filename: &str, yaml: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    let uniq = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    p.push(format!("{}_{}_{}.yaml", filename, std::process::id(), uniq));
    fs::write(&p, yaml).expect("failed to write temp yaml");
    p
}

#[test]
fn kernel_validation_allows_any_adjacent_known_ops_when_model_is_empty() {
    // Model with NO dependency table at all -> PmsModel.dependency_table == empty.
    // Policy: open-world for known ops => Kernel.validate_program() should not block.
    let yaml = r#"
schema_version: "PMS_1.1"
schema_meta:
  model_name: "Praxeological Meta-Structure"
"#;

    let path = write_temp_yaml("pms_model_empty_open_world", yaml);
    let model = PmsModel::load_from_file(&path).expect("model load failed");
    let _ = fs::remove_file(&path);

    // Build a program with multiple adjacent transitions (all known ops)
    // without caring whether they "should" be allowed by a strict table.
    let program = vec![
        OpCode::new(
            Operator::Delta,
            OpParams::NewEntity {
                name: "agent".to_string(),
            },
        ),
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "scene".to_string(),
            },
        ),
        OpCode::new(
            Operator::Nabla,
            OpParams::Impulse {
                entity: "agent".to_string(),
                intensity: 1.0,
                desc: "go".to_string(),
            },
        ),
        OpCode::new(
            Operator::Sigma,
            OpParams::Integrate {
                note: "integrate".to_string(),
            },
        ),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "commit".to_string(),
            },
        ),
    ];

    let k = Kernel::new(program);

    assert!(
        k.validate_program(&model).is_ok(),
        "empty model should not block adjacency validation for known ops"
    );
}
