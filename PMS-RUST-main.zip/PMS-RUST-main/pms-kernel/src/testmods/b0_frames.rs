use crate::*;

#[test]
fn frame_pushes_stack() {
    let program = vec![OpCode::new(
        Operator::Frame,
        OpParams::NewFrame {
            kind: "training".into(),
        },
    )];
    let mut k = Kernel::new(program);

    k.run_until_finished(None).unwrap();
    assert_eq!(k.state.frames.len(), 1);
    assert_eq!(k.state.frame_stack.len(), 1);
    assert_eq!(k.state.current_frame_id(), Some(0));
    assert!(k.state.events.iter().any(|e| e.op == Operator::Frame));
}

#[test]
fn b0_multiple_frames_current_is_last() {
    let program = vec![
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "A".into() }),
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "B".into() }),
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "C".into() }),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.frame_stack.len(), 3);
    assert_eq!(k.state.current_frame_id(), Some(2));

    let last = k.state.frames.iter().find(|f| f.id == 2).unwrap();
    assert_eq!(last.kind, "C");
}
