use crate::{Kernel, OpCode, OpParams, Operator};

#[test]
fn chi_pushes_isolation_and_logs_event() {
    let program = vec![
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter {
                label: "iso_training".into(),
            },
        ),
        OpCode::new(Operator::Theta, OpParams::Advance { dt: 1 }),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.isolations.len(), 1);
    assert_eq!(k.state.isolation_stack.len(), 1);
    assert_eq!(k.state.current_isolation_id(), Some(0));

    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Chi && e.msg.contains("enter_isolation"))
    );
}

#[test]
fn chi_ids_increment() {
    let program = vec![
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter { label: "a".into() },
        ),
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter { label: "b".into() },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.isolations.len(), 2);
    assert_eq!(k.state.isolation_stack, vec![0, 1]);
}

#[test]
fn chi_exit_pops_isolation_stack_lifo() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter { label: "A".into() },
        ),
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter { label: "B".into() },
        ),
        OpCode::new(Operator::Chi, OpParams::IsolationExit),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    // After pushing A(id0), B(id1), exiting pops id1 => top should be id0
    assert_eq!(k.state.current_isolation_id(), Some(0));

    // log contains exit
    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Chi && e.msg.contains("exit_isolation"))
    );
}

#[test]
fn chi_exit_without_enter_errors() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(Operator::Chi, OpParams::IsolationExit),
    ];

    let mut k = Kernel::new(program);
    let err = k.run_until_finished(None).unwrap_err();
    assert!(err.contains("exit requires an active isolation"));
}
