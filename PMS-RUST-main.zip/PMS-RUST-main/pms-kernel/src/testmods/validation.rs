#![forbid(unsafe_code)]

use crate::*;
use std::path::PathBuf;

use pms_model::PmsModel;

#[test]
fn validate_program_detects_disallowed_transition() {
    // Model: Theta may only be preceded by Delta (for this test)
    let mut dep = std::collections::HashMap::new();
    dep.insert(
        "Theta".to_string(),
        std::collections::HashSet::from(["Delta".to_string()]),
    );

    let model = PmsModel {
        dependency_table: dep,
    };

    let program = vec![
        OpCode::new(Operator::Delta, OpParams::NewEntity { name: "x".into() }),
        OpCode::new(Operator::Sigma, OpParams::None),
        OpCode::new(Operator::Theta, OpParams::None),
    ];

    let k = Kernel::new(program);
    let err = k.validate_program(&model).unwrap_err();
    assert!(err.contains("not allowed"));
}

fn write_temp_yaml(name: &str, contents: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!(
        "pms_kernel_{}_{}_{}.yaml",
        name,
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    std::fs::write(&p, contents).unwrap();
    p
}

#[test]
fn kernel_validation_is_adjacency_immediate_predecessor_only() {
    // Only allow: Delta immediately before Square.
    let yaml = r#"
dependencies:
  Square: [Delta]
"#;

    let p = write_temp_yaml("adjacency_only", yaml);
    let model = PmsModel::load_from_file(&p).unwrap();
    let _ = std::fs::remove_file(&p);

    // Δ -> □ allowed
    let k_ok = Kernel::new(vec![
        OpCode::new(Operator::Delta, OpParams::NewEntity { name: "e".into() }),
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "k".into() }),
    ]);
    assert!(k_ok.validate_program(&model).is_ok());

    // Θ -> □ not allowed (because rule only allows Delta immediately before Square)
    let k_bad = Kernel::new(vec![
        OpCode::new(Operator::Theta, OpParams::Advance { dt: 1 }),
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "k".into() }),
    ]);
    assert!(k_bad.validate_program(&model).is_err());
}

fn real_pms_model() -> PmsModel {
    let pms_yaml =
        std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../pms-model-data/PMS.yaml");

    PmsModel::load_from_file(&pms_yaml)
        .unwrap_or_else(|e| panic!("failed to load real PMS.yaml: {}", e))
}

#[test]
fn real_pms_yaml_rejects_delta_before_omega() {
    let model = real_pms_model();

    let program = vec![
        OpCode::new(Operator::Delta, OpParams::NewEntity { name: "x".into() }),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "a".into(),
                to: "b".into(),
                weight: 1.0,
                desc: "invalid direct omega".into(),
            },
        ),
    ];

    let k = Kernel::new(program);

    let err = k
        .validate_program(&model)
        .expect_err("Delta -> Omega should fail under real PMS.yaml model validation");

    assert!(
        err.contains("Omega") || err.contains("Ω"),
        "error should mention Omega, got: {}",
        err
    );
}

#[test]
fn real_pms_yaml_accepts_alpha_before_omega() {
    let model = real_pms_model();

    let program = vec![
        OpCode::new(
            Operator::Attractor,
            OpParams::Attractor {
                label: "stable-pattern".into(),
            },
        ),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "a".into(),
                to: "b".into(),
                weight: 1.0,
                desc: "valid omega after alpha".into(),
            },
        ),
    ];

    let k = Kernel::new(program);

    k.validate_program(&model)
        .expect("Attractor/Alpha -> Omega should pass under real PMS.yaml model validation");
}

#[test]
fn validation_error_reports_expected_predecessor_set() {
    let mut table = std::collections::HashMap::new();
    table.insert(
        "Omega".to_string(),
        ["Alpha".to_string(), "Square".to_string()]
            .into_iter()
            .collect(),
    );

    let model = PmsModel {
        dependency_table: table,
    };

    let program = vec![
        OpCode::new(Operator::Delta, OpParams::NewEntity { name: "x".into() }),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "a".into(),
                to: "b".into(),
                weight: 1.0,
                desc: "invalid direct omega".into(),
            },
        ),
    ];

    let k = Kernel::new(program);

    let err = k
        .validate_program(&model)
        .expect_err("Delta -> Omega should fail");

    assert!(
        err.contains("previous: Delta"),
        "error should report previous op, got: {}",
        err
    );
    assert!(
        err.contains("next: Omega"),
        "error should report next op, got: {}",
        err
    );
    assert!(
        err.contains("expected previous one of: [Alpha, Square]"),
        "error should report expected predecessor set, got: {}",
        err
    );
    assert!(
        err.contains("transition: Delta -> Omega not allowed"),
        "error should report rejected transition, got: {}",
        err
    );
}
