use crate::*;

#[test]
fn lambda_creates_expectation_with_due_tick() {
    let program = vec![OpCode::new(
        Operator::Lambda,
        OpParams::Expectation {
            horizon: 2,
            desc: "x".into(),
        },
    )];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.expectations.len(), 1);
    assert_eq!(k.state.expectations[0].created_tick, 0);
    assert_eq!(k.state.expectations[0].due_tick, 2);
    assert!(!k.state.expectations[0].timed_out);
}

#[test]
fn theta_triggers_non_event_when_due_tick_passed() {
    let program = vec![
        OpCode::new(
            Operator::Lambda,
            OpParams::Expectation {
                horizon: 1,
                desc: "x".into(),
            },
        ),
        OpCode::new(Operator::Theta, OpParams::Advance { dt: 1 }),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.expectations.len(), 1);
    assert!(k.state.expectations[0].timed_out);
    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Lambda && e.msg.contains("non_event"))
    );
}
