use crate::*;

#[test]
fn attractor_requires_frame() {
    let program = vec![OpCode::new(
        Operator::Attractor,
        OpParams::Attractor {
            label: "focus".into(),
        },
    )];

    let mut k = Kernel::new(program);
    let err = k.run_until_finished(None).unwrap_err();
    assert!(err.contains("requires an active frame"));
}

#[test]
fn attractor_upserts_by_label_in_frame() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Attractor,
            OpParams::Attractor {
                label: "focus".into(),
            },
        ),
        OpCode::new(
            Operator::Attractor,
            OpParams::Attractor {
                label: "focus".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.attractors.len(), 1);
    let a = &k.state.attractors[0];
    assert_eq!(a.frame_id, 0);
    assert_eq!(a.label, "focus");
    assert_eq!(a.count, 2);
    assert!(a.strength >= 2.0);

    assert!(
        k.state
            .events
            .iter()
            .any(|e| e.op == Operator::Attractor && e.msg.contains("upsert"))
    );
}
