use crate::*;
use std::collections::HashSet;

#[test]
fn operator_model_keys_are_unique_and_nonempty() {
    let ops = [
        Operator::Delta,
        Operator::Nabla,
        Operator::Frame,
        Operator::Lambda,
        Operator::Attractor,
        Operator::Omega,
        Operator::Theta,
        Operator::Phi,
        Operator::Chi,
        Operator::Sigma,
        Operator::Psi,
    ];

    let mut seen = HashSet::new();
    for op in ops {
        let k = op.model_key();
        assert!(
            !k.trim().is_empty(),
            "model_key must be non-empty for {:?}",
            op
        );
        assert!(seen.insert(k), "duplicate model_key '{}' for {:?}", k, op);
    }

    assert_eq!(
        seen.len(),
        ops.len(),
        "expected all operator keys to be unique"
    );
}

#[test]
fn operator_model_keys_match_expected() {
    assert_eq!(Operator::Delta.model_key(), "Delta");
    assert_eq!(Operator::Nabla.model_key(), "Nabla");
    assert_eq!(Operator::Frame.model_key(), "Frame");
    assert_eq!(Operator::Lambda.model_key(), "Lambda");
    assert_eq!(Operator::Attractor.model_key(), "Attractor");
    assert_eq!(Operator::Omega.model_key(), "Omega");
    assert_eq!(Operator::Theta.model_key(), "Theta");
    assert_eq!(Operator::Phi.model_key(), "Phi");
    assert_eq!(Operator::Chi.model_key(), "Chi");
    assert_eq!(Operator::Sigma.model_key(), "Sigma");
    assert_eq!(Operator::Psi.model_key(), "Psi");
}
