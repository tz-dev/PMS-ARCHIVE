use crate::*;

#[test]
fn omega_requires_frame() {
    let program = vec![OpCode::new(
        Operator::Omega,
        OpParams::Asymmetry {
            from: "a".into(),
            to: "b".into(),
            weight: 0.5,
            desc: "test".into(),
        },
    )];

    let mut k = Kernel::new(program);
    let err = k.run_until_finished(None).unwrap_err();
    assert!(err.contains("requires an active frame"));
}

#[test]
fn omega_adds_edge_to_current_frame() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "agent".into(),
                to: "system".into(),
                weight: 0.9,
                desc: "info_advantage".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.asymmetries.len(), 1);
    assert_eq!(k.state.asymmetries[0].frame_id, 0);
    assert!(k.state.events.iter().any(|e| e.op == Operator::Omega));
}
