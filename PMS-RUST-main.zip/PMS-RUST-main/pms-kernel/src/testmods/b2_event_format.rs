use crate::*;

fn has_kv(msg: &str) -> bool {
    // mindestens ein key=value
    msg.split_whitespace()
        .any(|tok| tok.contains('=') && !tok.starts_with('=') && !tok.ends_with('='))
}

#[test]
fn events_are_key_value_style() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(Operator::Theta, OpParams::Advance { dt: 1 }),
        OpCode::new(
            Operator::Nabla,
            OpParams::Impulse {
                entity: "agent".into(),
                intensity: 0.5,
                desc: "desc with spaces".into(),
            },
        ),
        OpCode::new(
            Operator::Sigma,
            OpParams::Integrate {
                note: "note with spaces".into(),
            },
        ),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "commit with spaces".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    let _ = k.run_until_finished(None); // kann failen wegen ∇ requires frame, also vorher frame ok

    for e in &k.state.events {
        assert!(
            has_kv(&e.msg),
            "event msg must contain key=value token; got: op={:?} msg={}",
            e.op,
            e.msg
        );
    }
}
