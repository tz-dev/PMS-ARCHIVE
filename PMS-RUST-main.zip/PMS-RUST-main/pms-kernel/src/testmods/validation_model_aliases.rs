// pms-kernel/src/testmods/validation_model_aliases.rs

#![forbid(unsafe_code)]

use std::fs;
use std::path::PathBuf;

use crate::{Kernel, OpCode, OpParams, Operator};
use pms_model::PmsModel;

/// Write YAML into a temp file and return the path.
/// (No external deps; works on Windows too.)
fn write_temp_yaml(filename: &str, yaml: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    // add a little uniqueness to avoid collisions across parallel test runs
    let uniq = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    p.push(format!("{}_{}_{}.yaml", filename, std::process::id(), uniq));

    fs::write(&p, yaml).expect("failed to write temp yaml");
    p
}

#[test]
fn validate_program_accepts_symbol_keys_and_runtime_ops() {
    // Rule: Δ -> □ is allowed.
    // We express □ in YAML as the symbol "□".
    let yaml = r#"
dependencies:
  "□": ["Δ"]
"#;

    let path = write_temp_yaml("pms_model_alias_symbols", yaml);
    let model = PmsModel::load_from_file(&path).expect("model load failed");
    // best-effort cleanup
    let _ = fs::remove_file(&path);

    let program = vec![
        OpCode::new(
            Operator::Delta,
            OpParams::NewEntity {
                name: "agent".to_string(),
            },
        ),
        // runtime op is Operator::Frame (kernel key "Frame") — must normalize to Square
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "test".to_string(),
            },
        ),
    ];

    let k = Kernel::new(program);
    assert!(
        k.validate_program(&model).is_ok(),
        "expected validation to accept Δ -> Frame when YAML uses □"
    );
}

#[test]
fn validate_program_accepts_runtime_keys_in_yaml() {
    // Rule: Delta -> Frame is allowed.
    // YAML uses runtime key "Frame"; model must normalize it to "Square".
    let yaml = r#"
dependencies:
  Frame: [Delta]
"#;

    let path = write_temp_yaml("pms_model_alias_runtime", yaml);
    let model = PmsModel::load_from_file(&path).expect("model load failed");
    let _ = fs::remove_file(&path);

    let program = vec![
        OpCode::new(
            Operator::Delta,
            OpParams::NewEntity {
                name: "agent".to_string(),
            },
        ),
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "test".to_string(),
            },
        ),
    ];

    let k = Kernel::new(program);
    assert!(
        k.validate_program(&model).is_ok(),
        "expected validation to accept Δ -> Frame when YAML uses Frame"
    );
}
