use crate::*;

#[test]
fn nabla_requires_frame() {
    let program = vec![OpCode::new(
        Operator::Nabla,
        OpParams::Impulse {
            entity: "agent".into(),
            intensity: 0.7,
            desc: "test".into(),
        },
    )];

    let mut k = Kernel::new(program);
    let err = k.run_until_finished(None).unwrap_err();
    assert!(err.contains("∇ requires an active frame"));
}

#[test]
fn nabla_records_impulse_with_frame_id() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Nabla,
            OpParams::Impulse {
                entity: "agent".into(),
                intensity: 0.7,
                desc: "test".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.impulses.len(), 1);
    assert_eq!(k.state.impulses[0].frame_id, Some(0));
    assert!(k.state.events.iter().any(|e| e.op == Operator::Nabla));
}

#[test]
fn sigma_requires_frame() {
    let program = vec![OpCode::new(
        Operator::Sigma,
        OpParams::Integrate { note: "x".into() },
    )];

    let mut k = Kernel::new(program);
    let err = k.run_until_finished(None).unwrap_err();
    assert!(err.contains("Σ requires an active frame"));
}

#[test]
fn sigma_consumes_frame_impulses_and_logs_integration() {
    let program = vec![
        OpCode::new(
            Operator::Frame,
            OpParams::NewFrame {
                kind: "training".into(),
            },
        ),
        OpCode::new(
            Operator::Nabla,
            OpParams::Impulse {
                entity: "agent".into(),
                intensity: 0.8,
                desc: "a".into(),
            },
        ),
        OpCode::new(
            Operator::Nabla,
            OpParams::Impulse {
                entity: "agent".into(),
                intensity: 0.3,
                desc: "b".into(),
            },
        ),
        OpCode::new(
            Operator::Sigma,
            OpParams::Integrate {
                note: "integrate".into(),
            },
        ),
    ];

    let mut k = Kernel::new(program);
    k.run_until_finished(None).unwrap();

    assert_eq!(k.state.impulses.len(), 0);
    assert_eq!(k.state.integration_log.len(), 1);
    assert_eq!(k.state.integration_log[0].frame_id, 0);
    assert_eq!(k.state.integration_log[0].consumed_impulse_ids.len(), 2);
    assert!(k.state.events.iter().any(|e| e.op == Operator::Sigma));
}
