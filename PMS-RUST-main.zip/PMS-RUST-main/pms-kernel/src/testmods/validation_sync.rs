use crate::*;

#[test]
fn validation_v2_matches_runtime_for_sealed_frame_omega() {
    let program = vec![
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "A".into() }),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "seal".into(),
            },
        ),
        OpCode::new(
            Operator::Omega,
            OpParams::Asymmetry {
                from: "x".into(),
                to: "y".into(),
                weight: 0.7,
                desc: "should_fail".into(),
            },
        ),
    ];

    // v2 should reject
    let k_v2 = Kernel::new(program.clone());
    let err_v2 = k_v2.validate_program_stateful().unwrap_err();
    assert!(err_v2.contains("sealed frame") && (err_v2.contains("Ω") || err_v2.contains("Omega")));

    // runtime should reject
    let mut k_rt = Kernel::new(program);
    let err_rt = k_rt.run_until_finished(None).unwrap_err();
    assert!(
        err_rt.contains("sealed frame")
            && (err_rt.contains("Ω") || err_rt.to_lowercase().contains("omega"))
    );
}

#[test]
fn validation_v2_matches_runtime_for_sealed_iso_chi_enter() {
    let program = vec![
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter {
                label: "iso1".into(),
            },
        ),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "seal".into(),
            },
        ),
        OpCode::new(
            Operator::Chi,
            OpParams::IsolationEnter {
                label: "iso2".into(),
            },
        ),
    ];

    // v2 should reject
    let k_v2 = Kernel::new(program.clone());
    let err_v2 = k_v2.validate_program_stateful().unwrap_err();
    assert!(
        err_v2.contains("sealed isolation")
            && (err_v2.contains("Χ") || err_v2.to_lowercase().contains("chi"))
    );

    // runtime should reject
    let mut k_rt = Kernel::new(program);
    let err_rt = k_rt.run_until_finished(None).unwrap_err();
    assert!(
        err_rt.contains("sealed isolation")
            && (err_rt.contains("Χ") || err_rt.to_lowercase().contains("chi"))
    );
}

#[test]
fn validation_v2_allows_sigma_on_sealed_frame_and_runtime_allows() {
    let program = vec![
        OpCode::new(Operator::Frame, OpParams::NewFrame { kind: "A".into() }),
        OpCode::new(
            Operator::Psi,
            OpParams::Commit {
                note: "seal".into(),
            },
        ),
        OpCode::new(Operator::Sigma, OpParams::Integrate { note: "ok".into() }),
    ];

    // v2 should allow
    let k_v2 = Kernel::new(program.clone());
    k_v2.validate_program_stateful().unwrap();

    // runtime should allow
    let mut k_rt = Kernel::new(program);
    k_rt.run_until_finished(None).unwrap();
    assert_eq!(k_rt.state.integration_log.len(), 1);
}
