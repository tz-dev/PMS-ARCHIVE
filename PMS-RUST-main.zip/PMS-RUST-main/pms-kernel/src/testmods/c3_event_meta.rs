use crate::*;

#[test]
fn c3_event_meta_parses_kind_and_kv_and_unescapes_spaces() {
    let mut s = KernelState::new();

    // Emit an event with escaped spaces
    s.emit(Operator::Delta, "fs_write_file path=/a.txt len=5 note=hello\\sworld");

    assert_eq!(s.events.len(), 1);

    let ev = &s.events[0];
    let meta = ev.meta.as_ref().expect("meta should be present");

    assert_eq!(meta.kind, "fs_write_file");
    assert_eq!(meta.kv.get("path").unwrap(), "/a.txt");
    assert_eq!(meta.kv.get("len").unwrap(), "5");
    assert_eq!(meta.kv.get("note").unwrap(), "hello world");
}
