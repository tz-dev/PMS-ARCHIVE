use crate::{Kernel, OpCode, OpParams, Operator};

fn frame(kind: &str) -> OpCode {
    OpCode::new(
        Operator::Frame,
        OpParams::NewFrame {
            kind: kind.to_string(),
        },
    )
}
fn omega() -> OpCode {
    OpCode::new(
        Operator::Omega,
        OpParams::Asymmetry {
            from: "a".to_string(),
            to: "b".to_string(),
            weight: 0.7,
            desc: "d".to_string(),
        },
    )
}
fn attractor() -> OpCode {
    OpCode::new(
        Operator::Attractor,
        OpParams::Attractor {
            label: "x".to_string(),
        },
    )
}
fn integrate() -> OpCode {
    OpCode::new(
        Operator::Sigma,
        OpParams::Integrate {
            note: "n".to_string(),
        },
    )
}
fn chi_enter(label: &str) -> OpCode {
    OpCode::new(
        Operator::Chi,
        OpParams::IsolationEnter {
            label: label.to_string(),
        },
    )
}
fn chi_exit() -> OpCode {
    OpCode::new(Operator::Chi, OpParams::IsolationExit)
}
fn psi(note: &str) -> OpCode {
    OpCode::new(
        Operator::Psi,
        OpParams::Commit {
            note: note.to_string(),
        },
    )
}

#[test]
fn v2_rejects_omega_without_frame() {
    let k = Kernel::new(vec![omega()]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 0"));
    assert!(err.contains("Ω"));
    assert!(err.to_lowercase().contains("requires an active frame"));
}

#[test]
fn v2_rejects_attractor_without_frame() {
    let k = Kernel::new(vec![attractor()]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 0"));
    assert!(err.contains("Α"));
    assert!(err.to_lowercase().contains("requires an active frame"));
}

#[test]
fn v2_rejects_integrate_without_frame() {
    let k = Kernel::new(vec![integrate()]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 0"));
    assert!(err.contains("Σ"));
    assert!(err.to_lowercase().contains("requires an active frame"));
}

#[test]
fn v2_rejects_chi_exit_without_enter() {
    let k = Kernel::new(vec![chi_exit()]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 0"));
    assert!(err.contains("Χ"));
    assert!(
        err.to_lowercase()
            .contains("exit requires an active isolation")
    );
}

#[test]
fn v2_rejects_omega_in_sealed_frame() {
    // frame A; psi seals A; omega in A is forbidden
    let k = Kernel::new(vec![frame("A"), psi("s"), omega()]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 2"));
    assert!(err.contains("Ω"));
    assert!(err.to_lowercase().contains("sealed frame"));
}

#[test]
fn v2_rejects_attractor_in_sealed_frame() {
    let k = Kernel::new(vec![frame("A"), psi("s"), attractor()]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 2"));
    assert!(err.contains("Α"));
    assert!(err.to_lowercase().contains("sealed frame"));
}

#[test]
fn v2_rejects_chi_enter_in_sealed_isolation() {
    // enter iso1; psi seals iso1; entering iso2 is forbidden
    let k = Kernel::new(vec![chi_enter("iso1"), psi("s"), chi_enter("iso2")]);
    let err = k.validate_program_stateful().unwrap_err();
    assert!(err.contains("index 2"));
    assert!(err.contains("Χ"));
    assert!(err.to_lowercase().contains("sealed isolation"));
}

#[test]
fn v2_allows_new_frame_after_seal_variant_b() {
    // frame A; psi seals A; frame B starts unsealed; omega allowed in B
    let k = Kernel::new(vec![frame("A"), psi("s"), frame("B"), omega()]);
    assert!(k.validate_program_stateful().is_ok());
}

#[test]
fn v2_allows_integrate_even_if_frame_sealed() {
    // frame A; psi seals A; integrate still allowed
    let k = Kernel::new(vec![frame("A"), psi("s"), integrate()]);
    assert!(k.validate_program_stateful().is_ok());
}

#[test]
fn v2_allows_chi_exit_even_if_isolation_sealed() {
    // enter iso1; psi seals iso1; exit still allowed
    let k = Kernel::new(vec![chi_enter("iso1"), psi("s"), chi_exit()]);
    assert!(k.validate_program_stateful().is_ok());
}
