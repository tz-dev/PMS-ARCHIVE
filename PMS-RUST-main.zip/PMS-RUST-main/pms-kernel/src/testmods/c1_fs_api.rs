use crate::*;

#[test]
fn c1_fs_create_file_requires_absolute_path() {
    let mut s = KernelState::new();

    let err = s.fs_create_file("a.txt").unwrap_err();
    assert!(err.contains("absolute"), "err={}", err);
}

#[test]
fn c1_fs_create_file_creates_node_and_parent_links() {
    let mut s = KernelState::new();

    let id = s.fs_create_file("/a.txt").unwrap();
    assert!(id > 0);

    // root must list a.txt
    let names = s.fs_list_dir("/").unwrap();
    assert_eq!(names, vec!["a.txt".to_string()]);

    // node parent must be root, and kind must be file
    let node = s.fs_nodes.iter().find(|n| n.id == id).unwrap();
    assert_eq!(node.kind, FsNodeKind::File);
    assert_eq!(node.name, "a.txt");
    assert_eq!(node.parent, Some(s.fs_root));
}

#[test]
fn c1_fs_write_then_read_roundtrip() {
    let mut s = KernelState::new();

    s.fs_create_file("/a.txt").unwrap();
    s.fs_write_file("/a.txt", b"hello").unwrap();
    let out = s.fs_read_file("/a.txt").unwrap();

    assert_eq!(out, b"hello".to_vec());
}

#[test]
fn c1_fs_write_errors_if_missing() {
    let mut s = KernelState::new();

    let err = s.fs_write_file("/missing.txt", b"x").unwrap_err();
    assert!(err.contains("not found"), "err={}", err);
}

#[test]
fn c1_fs_read_errors_if_missing() {
    let mut s = KernelState::new();

    let err = s.fs_read_file("/missing.txt").unwrap_err();
    assert!(err.contains("not found"), "err={}", err);
}

#[test]
fn c1_fs_write_errors_if_directory() {
    let mut s = KernelState::new();

    // writing to "/" must fail
    let err = s.fs_write_file("/", b"x").unwrap_err();
    assert!(err.contains("file"), "err={}", err);
}

#[test]
fn c1_fs_list_dir_shows_children() {
    let mut s = KernelState::new();

    s.fs_create_file("/b.txt").unwrap();
    s.fs_create_file("/a.txt").unwrap();

    let names = s.fs_list_dir("/").unwrap();
    assert_eq!(names, vec!["a.txt".to_string(), "b.txt".to_string()]);
}

#[test]
fn c1_fs_delete_file_ok() {
    let mut s = KernelState::new();

    s.fs_create_file("/a.txt").unwrap();
    s.fs_write_file("/a.txt", b"hello").unwrap();

    s.fs_delete("/a.txt").unwrap();

    let names = s.fs_list_dir("/").unwrap();
    assert_eq!(names, Vec::<String>::new());

    let err = s.fs_read_file("/a.txt").unwrap_err();
    assert!(err.contains("not found"), "err={}", err);
}

#[test]
fn c1_fs_delete_empty_dir_ok() {
    let mut s = KernelState::new();

    s.fs_create_dir("/d").unwrap();
    s.fs_delete("/d").unwrap();

    let names = s.fs_list_dir("/").unwrap();
    assert_eq!(names, Vec::<String>::new());
}

#[test]
fn c1_fs_delete_missing_errors() {
    let mut s = KernelState::new();

    let err = s.fs_delete("/missing.txt").unwrap_err();
    assert!(err.contains("not found"), "err={}", err);
}

#[test]
fn c1_fs_delete_root_is_protected() {
    let mut s = KernelState::new();

    let err = s.fs_delete("/").unwrap_err();
    assert!(err.contains("root"), "err={}", err);
}

#[test]
fn c1_fs_delete_non_empty_dir_errors() {
    let mut s = KernelState::new();

    s.fs_create_dir("/d").unwrap();
    s.fs_create_file("/d/a.txt").unwrap();

    let err = s.fs_delete("/d").unwrap_err();
    assert!(err.contains("non-empty"), "err={}", err);

    let names = s.fs_list_dir("/d").unwrap();
    assert_eq!(names, vec!["a.txt".to_string()]);
}
