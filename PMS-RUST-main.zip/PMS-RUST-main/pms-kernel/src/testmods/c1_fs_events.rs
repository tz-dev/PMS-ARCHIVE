use crate::{KernelState, Operator};

#[test]
fn c1_fs_events_are_emitted_on_create_write_read() {
    let mut s = KernelState::new();

    // create
    let id = s.fs_create_file("/a.txt").expect("create must succeed");

    // write
    let data = b"hello";
    s.fs_write_file("/a.txt", data).expect("write must succeed");

    // read
    let out = s.fs_read_file("/a.txt").expect("read must succeed");
    assert_eq!(out, data);

    // delete
    s.fs_delete("/a.txt").expect("delete must succeed");

    // collect FS events by msg prefix (operator is intentionally reused; no new operator)
    let fs_msgs: Vec<String> = s
        .events
        .iter()
        .filter(|e| e.op == Operator::Delta)
        .map(|e| e.msg.clone())
        .filter(|m| m.starts_with("fs_"))
        .collect();

    assert!(
        fs_msgs
            .iter()
            .any(|m| m == &format!("fs_create_file path=/a.txt id={}", id)),
        "missing create event; fs_msgs={:?}",
        fs_msgs
    );
    assert!(
        fs_msgs
            .iter()
            .any(|m| m == "fs_write_file path=/a.txt len=5"),
        "missing write event; fs_msgs={:?}",
        fs_msgs
    );
    assert!(
        fs_msgs
            .iter()
            .any(|m| m == "fs_read_file path=/a.txt len=5"),
        "missing read event; fs_msgs={:?}",
        fs_msgs
    );
    assert!(
        fs_msgs
            .iter()
            .any(|m| m == &format!("fs_delete path=/a.txt id={}", id)),
        "missing delete event; fs_msgs={:?}",
        fs_msgs
    );
}
