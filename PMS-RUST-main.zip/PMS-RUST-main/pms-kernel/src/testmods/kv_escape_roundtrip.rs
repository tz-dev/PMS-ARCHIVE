#![forbid(unsafe_code)]

use crate::KernelState;

#[test]
fn kv_escape_roundtrip_samples() {
    let samples = [
        "plain",
        "has space",
        r"has\backslash",
        r"mix \ and space",
        r"endswith\",
        r"two \\ backslashes",
        "tabs\tare_not_spaces", // should remain a literal tab (escape only handles space + backslash)
    ];

    for s in samples {
        let e = KernelState::kv_escape(s);
        let u = KernelState::kv_unescape(&e);
        assert_eq!(u, s, "roundtrip failed for input: {:?}", s);
    }
}
