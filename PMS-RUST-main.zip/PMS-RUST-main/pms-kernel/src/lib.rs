// PMS-KERNEL v0 (Trace Kernel)
//
// Purpose:
// - Deterministic interpreter for PMS opcodes (Δ..Ψ) that emits a stable, machine-readable event timeline.
// - Enforces runtime invariants (frames, isolation, sealing) and exposes two validation layers:
//   - v1: adjacency validation against PMS model dependency rules (PMS.yaml via `pms_model`).
//   - v2: stateful structural validation via a shadow-state pass (no execution).
//
// v0 Guarantees:
// - Tick/event ordering is deterministic (no wall-clock, no IO, no randomness).
// - Post-Ψ sealing rules are enforced at runtime (and mirrored by v2 validation).
// - Event messages use a stable key=value format (not free prose) to support tooling/AI parsing.
//
// Kernel Dialect v0:
// - Symbols follow PMS for familiarity, but semantics are execution-defined where needed.
// - Notable mapping: Χ is an isolation/boundary scope primitive (enter/exit + sealing), not theoretical PMS “Distance”.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Operator {
    Delta,     // Δ Distinction
    Nabla,     // ∇ Impulse
    Frame,     // □ Frame
    Lambda,    // Λ Non-Event / Expectation
    Attractor, // Α Attractor
    Omega,     // Ω Asymmetry
    Theta,     // Θ Temporality
    Phi,       // Φ Reframing
    Chi,       // Χ Isolation (boundary; NOT distance)
    Sigma,     // Σ Integration
    Psi,       // Ψ Self-Binding / Commitment
}

impl Operator {
    /// Canonical key used by PMS.yaml / PmsModel dependency rules.
    ///
    /// Invariant:
    /// - These strings are part of the public contract between the kernel and `pms_model`.
    /// - Keep them stable; tooling + validation depend on exact spelling.
    pub fn model_key(self) -> &'static str {
        match self {
            Operator::Delta => "Delta",
            Operator::Nabla => "Nabla",
            Operator::Frame => "Frame",
            Operator::Lambda => "Lambda",
            Operator::Attractor => "Attractor",
            Operator::Omega => "Omega",
            Operator::Theta => "Theta",
            Operator::Phi => "Phi",
            Operator::Chi => "Chi",
            Operator::Sigma => "Sigma",
            Operator::Psi => "Psi",
        }
    }
}

/// Model-facing operator naming helper.
/// Keep this a thin wrapper so `Operator::model_key()` remains the single source of truth.
fn op_name(op: Operator) -> &'static str {
    op.model_key()
}

#[derive(Debug, Clone, PartialEq)]
pub enum OpParams {
    /// No parameters (used by some ops as a default case, e.g. Θ defaults dt=1).
    None,

    // --- v0 minimal: expand later ---
    /// Δ: declare a new entity label/name (pure event emission in v0).
    NewEntity { name: String }, // Δ

    /// Θ: advance deterministic time by `dt` ticks.
    Advance { dt: u64 }, // Θ

    // --- B0: minimal frame support ---
    /// □: open/push a new frame with a caller-defined kind label.
    NewFrame { kind: String }, // □

    // --- B1: minimal asymmetry support ---
    /// Ω: record a directed edge within the current frame.
    /// v0 enforcement:
    /// - requires an active frame
    /// - forbidden after the frame is sealed by Ψ (B8)
    Asymmetry {
        from: String,
        to: String,
        weight: f32,
        desc: String,
    }, // Ω

    // --- B2: impulses + integration ---
    /// ∇: record an impulse in the current frame (requires active frame).
    Impulse {
        entity: String,
        intensity: f32,
        desc: String,
    }, // ∇

    /// Σ: integrate the current frame (consumes pending impulses belonging to that frame).
    Integrate { note: String }, // Σ

    // --- B3: expectations (Λ) which can time out into non-events ---
    /// Λ: register an expectation that times out after `horizon` ticks if unfulfilled.
    /// v0 semantics: only timeouts are supported; Θ triggers timeout checks.
    Expectation { horizon: u64, desc: String }, // Λ

    // --- B4: attractor ---
    /// Α: upsert an attractor in the current frame by label.
    /// v0 enforcement:
    /// - requires an active frame
    /// - forbidden after the frame is sealed by Ψ (B8)
    Attractor { label: String }, // Α

    // --- B5: reframing ---
    /// Φ: record a reframing relation; frame context is optional in v0.
    Reframe { from: String, to: String }, // Φ

    // --- B6: isolation ---
    /// Χ: enter a new isolation scope.
    /// v0 enforcement:
    /// - forbidden if the current isolation is sealed (B8)
    IsolationEnter { label: String }, // Χ

    /// Χ: exit the current isolation scope (requires an active isolation).
    IsolationExit, // Χ

    // --- B7: commitment ---
    /// Ψ: commit note; seals current frame and current isolation (if present), and creates snapshot anchors (B8).
    Commit { note: String }, // Ψ
}

// =========================
// C1: Virtual FS (in-memory)
// =========================
//
// Contract:
// - Kernel-internal, deterministic filesystem model used for tests and event emission.
// - Must NOT depend on host filesystem state.
// - Path semantics are enforced by KernelState fs_* helpers (canonical absolute paths, etc.).
//
// Note:
// - FS events are emitted via the kernel event stream (typically as Δ "fs_*" messages).

pub type FsNodeId = u32;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsNodeKind {
    File,
    Directory,
}

#[derive(Debug, Clone, PartialEq)]
pub struct FsNode {
    pub id: FsNodeId,
    pub kind: FsNodeKind,
    pub name: String,
    pub parent: Option<FsNodeId>,
    pub children: Vec<FsNodeId>,
    pub data: Option<Vec<u8>>, // Some for File, None for Directory
}

// =========================
// Program representation
// =========================

/// One executable instruction in the kernel program.
#[derive(Debug, Clone, PartialEq)]
pub struct OpCode {
    pub op: Operator,
    pub params: OpParams,
}

impl OpCode {
    /// Convenience constructor used heavily by tests/DSL compilation.
    pub fn new(op: Operator, params: OpParams) -> Self {
        Self { op, params }
    }
}

/// Minimal execution context: program + program counter.
/// Invariant: deterministic stepping given `program` (no external input).
#[derive(Debug, Clone, PartialEq)]
pub struct ExecutionContext {
    pub program: Vec<OpCode>,
    pub pc: usize,
}

impl ExecutionContext {
    pub fn new(program: Vec<OpCode>) -> Self {
        Self { program, pc: 0 }
    }

    pub fn is_finished(&self) -> bool {
        self.pc >= self.program.len()
    }
}

// =========================
// Core runtime state records
// =========================

pub type FrameId = u32;

#[derive(Debug, Clone, PartialEq)]
pub struct Frame {
    pub id: FrameId,
    pub kind: String,
    /// Ψ sets this to true for the current frame (if any).
    /// Once sealed, Ω and Α are forbidden in that frame (B8 rules).
    pub sealed: bool,
}

/// A directed Ω edge. Always frame-scoped (captured at creation time).
#[derive(Debug, Clone, PartialEq)]
pub struct AsymmetryEdge {
    pub frame_id: FrameId,
    pub from: String,
    pub to: String,
    pub weight: f32,
    pub desc: String,
}

/// An impulse record.
/// v0: impulses are recorded with a frame_id when created via ∇ (requires active frame),
/// but the struct allows Option<> for future extensions.
#[derive(Debug, Clone, PartialEq)]
pub struct Impulse {
    pub id: u32,
    pub frame_id: Option<FrameId>,
    pub entity: String,
    pub intensity: f32,
    pub desc: String,
}

/// A Σ integration event.
/// v0: integration is frame-scoped and consumes all pending impulses in that frame.
#[derive(Debug, Clone, PartialEq)]
pub struct IntegrationEvent {
    pub tick: u64,
    pub frame_id: FrameId,
    pub note: String,
    pub consumed_impulse_ids: Vec<u32>,
}

/// An expectation record.
/// v0: only timeout behavior is supported (fulfilled stays false unless extended later).
#[derive(Debug, Clone, PartialEq)]
pub struct Expectation {
    pub id: u32,
    pub frame_id: Option<FrameId>,
    pub created_tick: u64,
    pub due_tick: u64,
    pub desc: String,

    // v0: reserved for v1 "fulfillment" semantics (e.g. explicit completion op / external signal).
    // In v0 we only support timeouts (non-events) via Θ-driven checks.
    pub fulfilled: bool,

    pub timed_out: bool,
}

/// An attractor record.
/// v0: upserted by (frame_id, label) and uses simple deterministic counters.
#[derive(Debug, Clone, PartialEq)]
pub struct Attractor {
    pub id: u32,
    pub frame_id: FrameId,
    pub label: String,
    pub count: u32,
    pub strength: f32,
}

use std::collections::BTreeMap;

/// Parsed metadata view of a KernelEvent message.
/// Invariant:
/// - `msg` remains the source of truth.
/// - `meta` is best-effort and may be None.
#[derive(Debug, Clone, PartialEq)]
pub struct KernelEventMeta {
    /// First token of msg, e.g. "commit", "integrate", "fs_create_file".
    pub kind: String,

    /// Parsed key=value fields (values are unescaped: "\s" -> " ", "\\\\" -> "\\").
    pub kv: BTreeMap<String, String>,
}

/// Stable event record emitted by the kernel.
/// Invariants:
/// - `tick` is taken from KernelState at emission time.
/// - `msg` is stable key=value style (machine-readable).
/// - `meta` is derived from `msg` and optional.
#[derive(Debug, Clone, PartialEq)]
pub struct KernelEvent {
    pub tick: u64,
    pub op: Operator,
    pub msg: String,

    /// Optional structured view for tooling/AI (non-breaking, msg remains source of truth).
    pub meta: Option<KernelEventMeta>,
}

pub type IsolationId = u32;

/// Isolation scope record.
/// v0: isolation is a stack; Ψ seals the current isolation (if any).
#[derive(Debug, Clone, PartialEq)]
pub struct Isolation {
    pub id: IsolationId,
    pub label: String,
    pub sealed: bool,
}

// B7: commitments
pub type CommitId = u32;

/// Logical commit record created by Ψ.
/// Note:
/// - The kernel also emits a stable KernelEvent ("commit ...") in the event stream.
#[derive(Debug, Clone, PartialEq)]
pub struct CommitEvent {
    pub id: CommitId,
    pub tick: u64,
    pub frame_id: Option<FrameId>,
    pub isolation_id: Option<IsolationId>,
    pub note: String,
}

// =========================
// KernelState definition
// =========================
//
// IMPORTANT:
// - This struct definition is required for the crate to compile (`Kernel` and tests reference it).
// - Methods (`impl KernelState { ... }`) are provided separately.
// - Here we keep only the struct + field-level invariants.

#[derive(Debug, Clone, PartialEq)]
pub struct KernelState {
    /// Deterministic logical clock. Only Θ advances this in v0 (via Kernel::step).
    pub tick: u64,

    /// Append-only event timeline (stable order, stable formatting).
    pub events: Vec<KernelEvent>,

    // B0: minimal frame stack state
    pub next_frame_id: FrameId,
    pub frames: Vec<Frame>,
    pub frame_stack: Vec<FrameId>,

    // B1: minimal asymmetry state (all edges are frame-scoped at insertion time)
    pub asymmetries: Vec<AsymmetryEdge>,

    // B2: impulses + integration log
    pub next_impulse_id: u32,
    pub impulses: Vec<Impulse>,
    pub integration_log: Vec<IntegrationEvent>,

    // B3: expectations + non-events
    pub next_expectation_id: u32,
    pub expectations: Vec<Expectation>,

    // B4: attractors
    pub next_attractor_id: u32,
    pub attractors: Vec<Attractor>,

    // B6: isolation
    pub next_isolation_id: IsolationId,
    pub isolations: Vec<Isolation>,
    pub isolation_stack: Vec<IsolationId>,

    // B7: commitments
    pub next_commit_id: CommitId,
    pub commits: Vec<CommitEvent>,

    // B8-A: snapshot anchors at each commit (used by tests/tooling to assert monotonicity)
    pub commit_snapshots: Vec<CommitSnapshot>,

    // C1: virtual filesystem (in-memory)
    pub next_fs_node_id: FsNodeId,
    /// Root directory node id (must exist in fs_nodes).
    pub fs_root: FsNodeId,
    /// Node store; ids are stable and referenced by parent/children links.
    pub fs_nodes: Vec<FsNode>,
}

impl Default for KernelState {
    fn default() -> Self {
        Self::new()
    }
}

impl KernelState {
    // --- Construction ---
    //
    // Invariants:
    // - Deterministic zero-state (no hidden randomness, no host IO).
    // - `tick` starts at 0 and only Θ advances it in v0 (via `advance_tick`).
    // - Event timeline starts empty; all events are appended in strict execution order.
    // - Frame/impulse/expectation/attractor/isolation/commit counters start at 0.
    // - vFS root node always exists at id=0 and is a directory named "/".
    pub fn new() -> Self {
        Self {
            // Deterministic clock.
            tick: 0,

            // Stable, append-only event timeline.
            events: Vec::new(),

            // -------------------------
            // B0: frames (stack + store)
            // -------------------------
            // next_frame_id is a monotonic id allocator for Frame records.
            next_frame_id: 0,
            // frames stores all created frames (lookup by id).
            frames: Vec::new(),
            // frame_stack tracks the "current" frame (top-of-stack).
            frame_stack: Vec::new(),

            // -------------------------
            // B1: asymmetry edges (Ω)
            // -------------------------
            // Edges are always frame-scoped (frame_id stored in edge).
            asymmetries: Vec::new(),

            // -------------------------
            // B2: impulses + integrations
            // -------------------------
            next_impulse_id: 0,
            // impulses holds pending impulses; Σ consumes impulses for the current frame.
            impulses: Vec::new(),
            // integration_log is append-only; each Σ produces one IntegrationEvent.
            integration_log: Vec::new(),

            // -------------------------
            // B3: expectations + non-events
            // -------------------------
            next_expectation_id: 0,
            // expectations persist; Θ marks timed_out and emits non_event records.
            expectations: Vec::new(),

            // -------------------------
            // B4: attractors (Α)
            // -------------------------
            next_attractor_id: 0,
            // attractors are upserted by (frame_id, label).
            attractors: Vec::new(),

            // -------------------------
            // B6: isolation (Χ)
            // -------------------------
            next_isolation_id: 0,
            // isolations stores all created isolation records.
            isolations: Vec::new(),
            // isolation_stack tracks the current isolation (top-of-stack).
            isolation_stack: Vec::new(),

            // -------------------------
            // B7: commitments (Ψ)
            // -------------------------
            next_commit_id: 0,
            // commits stores logical commit records (separate from KernelEvent emissions).
            commits: Vec::new(),

            // -------------------------
            // B8: snapshots (Ψ anchors)
            // -------------------------
            // commit_snapshots are cheap anchors used by tests/tooling for ordering and monotonicity checks.
            commit_snapshots: Vec::new(),

            // -------------------------
            // C1: virtual filesystem (vFS)
            // -------------------------
            // next_fs_node_id starts at 1 because id=0 is reserved for root.
            next_fs_node_id: 1,
            // Root node id is always 0.
            fs_root: 0,
            // Root node bootstrap: always present; parent None; children empty.
            fs_nodes: vec![FsNode {
                id: 0,
                kind: FsNodeKind::Directory,
                name: "/".to_string(),
                parent: None,
                children: Vec::new(),
                data: None,
            }],
        }
    }

    // --- Event emission ---
    //
    // Invariants:
    // - `KernelEvent.msg` is the source of truth and remains stable across versions.
    // - `meta` is best-effort derived structure (optional) and must not be required for correctness.
    // - `tick` is captured from `self.tick` at emission time.
    fn emit(&mut self, op: Operator, msg: impl Into<String>) {
        let msg: String = msg.into();
        let meta = Self::parse_event_meta(&msg);

        self.events.push(KernelEvent {
            tick: self.tick,
            op,
            msg,
            meta,
        });
    }

    // --- v0 event-message hygiene ---
    //
    // KernelEvent.msg uses a stable "tokens + key=value tokens" format.
    // Constraint: values must be single tokens (no spaces).
    //
    // Escape rules (v0):
    // - ' '  -> "\s"
    // - '\'  -> "\\"
    //
    // This makes parsing possible with trivial whitespace splitting while still allowing
    // spaces and backslashes inside values.
    fn kv_escape(v: &str) -> String {
        // Order matters: escape backslashes first so we do not accidentally create escape sequences.
        v.replace('\\', "\\\\").replace(' ', "\\s")
    }

    fn kv_unescape(v: &str) -> String {
        // Important ordering: unescape backslashes first, then spaces.
        // "\\\\" -> "\" then "\s" -> " "
        v.replace("\\\\", "\\").replace("\\s", " ")
    }

    // Fixed-format float rendering for v0 event stability.
    //
    // Invariant:
    // - Always 6 fractional digits.
    // - No locale-dependent formatting.
    fn kv_f32(v: f32) -> String {
        format!("{:.6}", v)
    }

    // --- Event meta parsing ---
    //
    // Expected msg structure:
    // - First token: kind (e.g. "commit", "integrate", "fs_create_file")
    // - Remaining tokens: key=value
    //
    // Notes:
    // - Best-effort: non "key=value" tokens are ignored.
    // - Values are unescaped using kv_unescape (reverse of kv_escape).
    pub(crate) fn parse_event_meta(msg: &str) -> Option<KernelEventMeta> {
        let mut it = msg.split_whitespace();
        let kind = it.next()?.to_string();

        let mut kv = BTreeMap::new();
        for tok in it {
            if let Some((k, v)) = tok.split_once('=') {
                kv.insert(k.to_string(), Self::kv_unescape(v));
            }
        }

        Some(KernelEventMeta { kind, kv })
    }

    // =========================
    // C1.2 vFS-v0 (kernel-internal, in-memory)
    // =========================
    //
    // v0 contract:
    // - Paths must be absolute and canonical:
    //   - must start with "/"
    //   - no "//"
    //   - no trailing "/"
    //   - no "." or ".."
    // - Errors are deterministic and must not leak host FS details.
    // - FS actions emit Δ "fs_*" events where applicable.

    fn fs_validate_and_split_path(path: &str) -> Result<Vec<&str>, String> {
        if !path.starts_with('/') {
            return Err("vFS: path must be absolute (start with '/')".to_string());
        }
        if path == "/" {
            return Ok(Vec::new()); // root
        }

        // Reject ambiguous spellings:
        // - empty components ("//")
        // - trailing slash ("/a/b/")
        if path.contains("//") {
            return Err("vFS: invalid path (empty component)".to_string());
        }
        if path.ends_with('/') {
            return Err("vFS: invalid path (trailing '/')".to_string());
        }

        let comps: Vec<&str> = path.trim_start_matches('/').split('/').collect();
        if comps.is_empty() {
            return Err("vFS: invalid path".to_string());
        }

        for c in &comps {
            if c.is_empty() {
                return Err("vFS: invalid path (empty component)".to_string());
            }
            if *c == "." || *c == ".." {
                return Err("vFS: invalid path component '.' or '..'".to_string());
            }
        }

        Ok(comps)
    }

    // Resolve an absolute canonical path to a node id by walking from fs_root.
    //
    // Errors:
    // - path not found
    // - intermediate component is not a directory
    fn fs_find_node_id(&self, path: &str) -> Result<FsNodeId, String> {
        let comps = Self::fs_validate_and_split_path(path)?;
        let mut cur = self.fs_root;

        for name in comps {
            let cur_node = self
                .fs_nodes
                .iter()
                .find(|n| n.id == cur)
                .ok_or_else(|| "vFS: internal error: missing node".to_string())?;

            if cur_node.kind != FsNodeKind::Directory {
                // Deterministic error: we report the actual node name (not host path info).
                return Err(format!("vFS: '{}' is not a directory", cur_node.name));
            }

            let mut next: Option<FsNodeId> = None;
            for &child_id in &cur_node.children {
                let child = self
                    .fs_nodes
                    .iter()
                    .find(|n| n.id == child_id)
                    .ok_or_else(|| "vFS: internal error: missing child node".to_string())?;
                if child.name == name {
                    next = Some(child.id);
                    break;
                }
            }

            cur = next.ok_or_else(|| format!("vFS: path not found: {}", path))?;
        }

        Ok(cur)
    }

    // Search for a direct child inside a directory node by name.
    //
    // Returns:
    // - Ok(Some(id)) if found
    // - Ok(None) if not found
    // - Err if dir_id does not exist or is not a directory
    fn fs_find_child_in_dir(
        &self,
        dir_id: FsNodeId,
        name: &str,
    ) -> Result<Option<FsNodeId>, String> {
        let dir = self
            .fs_nodes
            .iter()
            .find(|n| n.id == dir_id)
            .ok_or_else(|| "vFS: internal error: missing dir node".to_string())?;

        if dir.kind != FsNodeKind::Directory {
            return Err("vFS: parent is not a directory".to_string());
        }

        for &cid in &dir.children {
            let child = self
                .fs_nodes
                .iter()
                .find(|n| n.id == cid)
                .ok_or_else(|| "vFS: internal error: missing child node".to_string())?;
            if child.name == name {
                return Ok(Some(child.id));
            }
        }

        Ok(None)
    }

    // Append a child node id to a parent directory.
    //
    // Invariants:
    // - Only directories may have children.
    // - This does not check for duplicate child ids (caller enforces "doesn't exist" rules).
    fn fs_push_child(&mut self, parent_id: FsNodeId, child_id: FsNodeId) -> Result<(), String> {
        let parent = self
            .fs_nodes
            .iter_mut()
            .find(|n| n.id == parent_id)
            .ok_or_else(|| "vFS: internal error: missing parent node".to_string())?;

        if parent.kind != FsNodeKind::Directory {
            return Err("vFS: parent is not a directory".to_string());
        }

        parent.children.push(child_id);
        Ok(())
    }

    // Create a directory at `path`.
    //
    // v0 rule:
    // - creating "/" is a no-op returning root id
    // - parent must exist
    // - leaf must not exist
    // - emits Δ "fs_create_dir ..."
    pub fn fs_create_dir(&mut self, path: &str) -> Result<FsNodeId, String> {
        let comps = Self::fs_validate_and_split_path(path)?;
        if comps.is_empty() {
            return Ok(self.fs_root); // creating "/" is a no-op
        }

        let (parent_comps, leaf) = comps.split_at(comps.len() - 1);
        let leaf_name = leaf[0];

        let parent_path = if parent_comps.is_empty() {
            "/".to_string()
        } else {
            format!("/{}", parent_comps.join("/"))
        };

        let parent_id = self.fs_find_node_id(&parent_path)?;

        // Ensure leaf doesn't exist (fail-closed).
        if self.fs_find_child_in_dir(parent_id, leaf_name)?.is_some() {
            return Err(format!("vFS: node already exists: {}", path));
        }

        // Allocate id (monotonic, saturating for determinism on overflow).
        let id = self.next_fs_node_id;
        self.next_fs_node_id = self.next_fs_node_id.saturating_add(1);

        // Create directory node.
        self.fs_nodes.push(FsNode {
            id,
            kind: FsNodeKind::Directory,
            name: leaf_name.to_string(),
            parent: Some(parent_id),
            children: Vec::new(),
            data: None,
        });

        // Link into parent directory.
        self.fs_push_child(parent_id, id)?;

        // Emit deterministic FS event (Δ).
        self.emit(
            Operator::Delta,
            format!("fs_create_dir path={} id={}", path, id),
        );

        Ok(id)
    }

    // Create a file at `path`.
    //
    // v0 rules:
    // - cannot create file at "/" (root is always a directory)
    // - parent must exist and be a directory
    // - leaf must not exist
    // - emits Δ "fs_create_file ..."
    pub fn fs_create_file(&mut self, path: &str) -> Result<FsNodeId, String> {
        let comps = Self::fs_validate_and_split_path(path)?;
        if comps.is_empty() {
            return Err("vFS: cannot create file at '/'".to_string());
        }

        let (parent_comps, leaf) = comps.split_at(comps.len() - 1);
        let leaf_name = leaf[0];

        let parent_path = if parent_comps.is_empty() {
            "/".to_string()
        } else {
            format!("/{}", parent_comps.join("/"))
        };

        let parent_id = self.fs_find_node_id(&parent_path)?;

        // Parent must be a directory (defensive check).
        {
            let parent = self
                .fs_nodes
                .iter()
                .find(|n| n.id == parent_id)
                .ok_or_else(|| "vFS: internal error: missing parent node".to_string())?;
            if parent.kind != FsNodeKind::Directory {
                return Err("vFS: parent is not a directory".to_string());
            }
        }

        // Ensure leaf doesn't exist.
        if self.fs_find_child_in_dir(parent_id, leaf_name)?.is_some() {
            return Err(format!("vFS: node already exists: {}", path));
        }

        // Allocate id.
        let id = self.next_fs_node_id;
        self.next_fs_node_id = self.next_fs_node_id.saturating_add(1);

        // Create file node (data starts empty).
        self.fs_nodes.push(FsNode {
            id,
            kind: FsNodeKind::File,
            name: leaf_name.to_string(),
            parent: Some(parent_id),
            children: Vec::new(),
            data: Some(Vec::new()),
        });

        self.fs_push_child(parent_id, id)?;

        self.emit(
            Operator::Delta,
            format!("fs_create_file path={} id={}", path, id),
        );

        Ok(id)
    }

    // Overwrite file contents.
    //
    // v0 rules:
    // - path must exist
    // - target must be a file
    // - emits Δ "fs_write_file ..."
    pub fn fs_write_file(&mut self, path: &str, data: &[u8]) -> Result<(), String> {
        let id = self.fs_find_node_id(path)?;

        let node = self
            .fs_nodes
            .iter_mut()
            .find(|n| n.id == id)
            .ok_or_else(|| "vFS: internal error: missing node".to_string())?;

        if node.kind != FsNodeKind::File {
            return Err(format!("vFS: write requires a file: {}", path));
        }

        node.data = Some(data.to_vec());

        self.emit(
            Operator::Delta,
            format!("fs_write_file path={} len={}", path, data.len()),
        );

        Ok(())
    }

    // Read file contents.
    //
    // Note:
    // - takes &mut self only because it emits a Δ event (deterministic side-channel).
    pub fn fs_read_file(&mut self, path: &str) -> Result<Vec<u8>, String> {
        let id = self.fs_find_node_id(path)?;

        let node = self
            .fs_nodes
            .iter()
            .find(|n| n.id == id)
            .ok_or_else(|| "vFS: internal error: missing node".to_string())?;

        if node.kind != FsNodeKind::File {
            return Err(format!("vFS: read requires a file: {}", path));
        }

        let out = node.data.clone().unwrap_or_default();

        self.emit(
            Operator::Delta,
            format!("fs_read_file path={} len={}", path, out.len()),
        );

        Ok(out)
    }

    // Delete a file or an empty directory.
    //
    // v0 rules:
    // - file exists -> delete
    // - empty dir exists -> delete
    // - non-empty dir -> error
    // - "/" -> error
    // - missing path -> error
    // - emits Δ "fs_delete ..."
    pub fn fs_delete(&mut self, path: &str) -> Result<(), String> {
        let id = self.fs_find_node_id(path)?;

        if id == self.fs_root {
            return Err("vFS: cannot delete root '/'".to_string());
        }

        let node_idx = self
            .fs_nodes
            .iter()
            .position(|n| n.id == id)
            .ok_or_else(|| "vFS: internal error: missing node".to_string())?;

        if self.fs_nodes[node_idx].kind == FsNodeKind::Directory
            && !self.fs_nodes[node_idx].children.is_empty()
        {
            return Err(format!("vFS: cannot delete non-empty directory: {}", path));
        }

        let parent_id = self.fs_nodes[node_idx]
            .parent
            .ok_or_else(|| "vFS: internal error: node without parent".to_string())?;

        let parent = self
            .fs_nodes
            .iter_mut()
            .find(|n| n.id == parent_id)
            .ok_or_else(|| "vFS: internal error: missing parent node".to_string())?;

        parent.children.retain(|&child_id| child_id != id);

        self.fs_nodes.remove(node_idx);

        self.emit(
            Operator::Delta,
            format!("fs_delete path={} id={}", path, id),
        );

        Ok(())
    }

    // List directory children by name (sorted for deterministic output).
    //
    // v0 rules:
    // - path must exist
    // - target must be a directory
    // - sorting is done to ensure stable test output independent of insertion order.
    pub fn fs_list_dir(&self, path: &str) -> Result<Vec<String>, String> {
        let id = self.fs_find_node_id(path)?;

        let node = self
            .fs_nodes
            .iter()
            .find(|n| n.id == id)
            .ok_or_else(|| "vFS: internal error: missing node".to_string())?;

        if node.kind != FsNodeKind::Directory {
            return Err(format!("vFS: list requires a directory: {}", path));
        }

        let mut names: Vec<String> = Vec::new();
        for &cid in &node.children {
            let child = self
                .fs_nodes
                .iter()
                .find(|n| n.id == cid)
                .ok_or_else(|| "vFS: internal error: missing child node".to_string())?;
            names.push(child.name.clone());
        }

        names.sort();
        Ok(names)
    }

    // --- Time ---
    //
    // v0 time model:
    // - Θ is the only driver of tick advancement.
    // - Saturating add ensures deterministic behavior on overflow.
    pub fn advance_tick(&mut self, dt: u64) {
        self.tick = self.tick.saturating_add(dt);
    }

    // --- Frames (B0) ---
    //
    // Invariants:
    // - Pushing a frame always makes it current.
    // - New frames always start unsealed; Ψ applies sealing.
    pub fn push_new_frame(&mut self, kind: String) -> FrameId {
        let id = self.next_frame_id;
        self.next_frame_id = self.next_frame_id.saturating_add(1);

        self.frames.push(Frame {
            id,
            kind,
            sealed: false,
        });
        self.frame_stack.push(id);
        id
    }

    // Read-only current frame id (top of frame_stack).
    pub fn current_frame_id(&self) -> Option<FrameId> {
        self.frame_stack.last().copied()
    }

    // Mutable handle to the current frame record (looked up in `frames` by id).
    fn current_frame_mut(&mut self) -> Option<&mut Frame> {
        let id = self.current_frame_id()?;
        self.frames.iter_mut().find(|f| f.id == id)
    }

    // Convenience: reads the seal flag of the current frame (if any).
    fn is_current_frame_sealed(&self) -> bool {
        let id = match self.current_frame_id() {
            Some(id) => id,
            None => return false,
        };
        self.frames
            .iter()
            .find(|f| f.id == id)
            .map(|f| f.sealed)
            .unwrap_or(false)
    }

    // --- Impulses (B2) ---
    //
    // v0 invariant:
    // - impulses are append-only until consumed by Σ integration.
    fn record_impulse(
        &mut self,
        frame_id: Option<FrameId>,
        entity: String,
        intensity: f32,
        desc: String,
    ) -> u32 {
        let id = self.next_impulse_id;
        self.next_impulse_id = self.next_impulse_id.saturating_add(1);

        self.impulses.push(Impulse {
            id,
            frame_id,
            entity,
            intensity,
            desc,
        });

        id
    }

    // --- Integration (B2) ---
    //
    // v0 semantics:
    // - Requires an active frame.
    // - Consumes all impulses associated with the current frame.
    // - Leaves impulses from other frames intact.
    fn integrate_current_frame(&mut self, note: String) -> Result<IntegrationEvent, String> {
        let frame_id = self
            .current_frame_id()
            .ok_or_else(|| "Σ requires an active frame (use: frame <kind>)".to_string())?;

        // Consume impulses belonging to this frame.
        let mut kept: Vec<Impulse> = Vec::with_capacity(self.impulses.len());
        let mut consumed_ids: Vec<u32> = Vec::new();

        for imp in self.impulses.drain(..) {
            if imp.frame_id == Some(frame_id) {
                consumed_ids.push(imp.id);
            } else {
                kept.push(imp);
            }
        }

        self.impulses = kept;

        let ev = IntegrationEvent {
            tick: self.tick,
            frame_id,
            note,
            consumed_impulse_ids: consumed_ids,
        };

        // Append-only integration log.
        self.integration_log.push(ev.clone());
        Ok(ev)
    }

    // --- Expectations (B3) ---
    //
    // v0 semantics:
    // - due_tick is computed at creation time (created_tick + horizon).
    // - Θ advancement drives timeout checks (non-events).
    fn record_expectation(&mut self, frame_id: Option<FrameId>, horizon: u64, desc: String) -> u32 {
        let id = self.next_expectation_id;
        self.next_expectation_id = self.next_expectation_id.saturating_add(1);

        let created_tick = self.tick;
        let due_tick = self.tick.saturating_add(horizon);

        self.expectations.push(Expectation {
            id,
            frame_id,
            created_tick,
            due_tick,
            desc,
            fulfilled: false,
            timed_out: false,
        });

        id
    }

    // Check for expectation timeouts and emit Λ "non_event" entries.
    //
    // Important implementation detail:
    // - We collect messages first to avoid holding a mutable borrow across `emit()`.
    fn check_non_events(&mut self) {
        let now = self.tick;

        // Collect messages first to avoid double mutable borrow (expectations + emit).
        let mut msgs: Vec<String> = Vec::new();

        for ex in &mut self.expectations {
            if !ex.fulfilled && !ex.timed_out && now >= ex.due_tick {
                ex.timed_out = true;

                let d = Self::kv_escape(&ex.desc);

                msgs.push(format!(
                    "non_event expectation_id={} frame_id={:?} desc={} due_tick={}",
                    ex.id, ex.frame_id, d, ex.due_tick
                ));
            }
        }

        for msg in msgs {
            self.emit(Operator::Lambda, msg);
        }
    }

    // --- Attractors (B4) ---
    //
    // v0 semantics:
    // - Requires an active frame.
    // - Upsert by (frame_id, label).
    // - Strength/count follow a simple deterministic increment rule.
    fn upsert_attractor(
        &mut self,
        label: String,
    ) -> Result<(u32, FrameId, String, u32, f32), String> {
        let frame_id = self
            .current_frame_id()
            .ok_or_else(|| "Α requires an active frame (use: frame <kind>)".to_string())?;

        // 1) Try update existing record.
        if let Some(a) = self
            .attractors
            .iter_mut()
            .find(|a| a.frame_id == frame_id && a.label == label)
        {
            a.count = a.count.saturating_add(1);
            // Deterministic strength update rule (v0): +1 per upsert.
            a.strength += 1.0;

            return Ok((a.id, a.frame_id, a.label.clone(), a.count, a.strength));
        }

        // 2) Otherwise insert new record.
        let id = self.next_attractor_id;
        self.next_attractor_id = self.next_attractor_id.saturating_add(1);

        self.attractors.push(Attractor {
            id,
            frame_id,
            label: label.clone(),
            count: 1,
            strength: 1.0,
        });

        Ok((id, frame_id, label, 1, 1.0))
    }

    // --- Isolation (B6) ---
    //
    // Invariants:
    // - Isolation is a LIFO stack (`isolation_stack` stores ids).
    // - Exit without an active isolation is an error (caller decides policy).
    pub fn pop_isolation(&mut self) -> Result<IsolationId, String> {
        self.isolation_stack
            .pop()
            .ok_or_else(|| "Χ exit requires an active isolation".to_string())
    }

    // Push a new isolation scope (unsealed).
    // Sealing is applied only by Ψ at the enforcement point in Kernel::step.
    pub fn push_isolation(&mut self, label: String) -> IsolationId {
        let id = self.next_isolation_id;
        self.next_isolation_id = self.next_isolation_id.saturating_add(1);

        self.isolations.push(Isolation {
            id,
            label,
            sealed: false,
        });
        self.isolation_stack.push(id);
        id
    }

    // Read-only current isolation id (top of isolation_stack).
    pub fn current_isolation_id(&self) -> Option<IsolationId> {
        self.isolation_stack.last().copied()
    }

    // Mutable handle to current isolation record (looked up in `isolations` by id).
    fn current_isolation_mut(&mut self) -> Option<&mut Isolation> {
        let id = self.current_isolation_id()?;
        self.isolations.iter_mut().find(|i| i.id == id)
    }

    // Convenience: reads the seal flag of the current isolation (if any).
    fn is_current_isolation_sealed(&self) -> bool {
        let id = match self.current_isolation_id() {
            Some(id) => id,
            None => return false,
        };
        self.isolations
            .iter()
            .find(|i| i.id == id)
            .map(|i| i.sealed)
            .unwrap_or(false)
    }

    // --- Commit (B7) ---
    //
    // record_commit only records the commit object.
    // Sealing and snapshot creation are performed at the Ψ enforcement point in `Kernel::step`.
    pub fn record_commit(&mut self, note: String) -> CommitEvent {
        let id = self.next_commit_id;
        self.next_commit_id = self.next_commit_id.saturating_add(1);

        let ev = CommitEvent {
            id,
            tick: self.tick,
            frame_id: self.current_frame_id(),
            isolation_id: self.current_isolation_id(),
            note,
        };

        self.commits.push(ev.clone());
        ev
    }
}

// =========================
// B8 snapshots
// =========================

/// Snapshot captured at Ψ time as a cheap anchor for:
/// - test assertions (monotonic growth, ordering)
/// - tooling (fast indexing without deep copying)
#[derive(Debug, Clone, PartialEq)]
pub struct CommitSnapshot {
    pub id: CommitId,
    pub tick: u64,
    pub frame_id: Option<FrameId>,
    pub isolation_id: Option<IsolationId>,
    pub note: String,

    // Cheap anchors: lengths of logs at snapshot time.
    // These enable "no mutation past seal" and ordering checks in tests without heavy diffing.
    pub event_len: usize,
    pub integration_len: usize,
    pub asymmetry_len: usize,
    pub impulse_len: usize,
    pub expectation_len: usize,
    pub attractor_len: usize,
}

// =========================
// Execution outcomes
// =========================

/// Single-step interpreter outcome.
#[derive(Debug, Clone, PartialEq)]
pub enum StepOutcome {
    Ok,
    Finished,
    Error(String),
}

// =========================
// Kernel (interpreter)
// =========================

/// Kernel = execution context + mutable state.
/// Invariant: behavior is entirely determined by the program (no hidden IO).
pub struct Kernel {
    pub state: KernelState,
    pub ctx: ExecutionContext,
}

impl Kernel {
    pub fn new(program: Vec<OpCode>) -> Self {
        Self {
            state: KernelState::new(),
            ctx: ExecutionContext::new(program),
        }
    }

    /// v1 validation: adjacent operator transitions using PMS model dependency rules.
    ///
    /// Notes:
    /// - This checks ONLY immediate predecessor constraints (local adjacency).
    /// - It does NOT validate stateful properties (frames, sealing, isolation stack correctness).
    pub fn validate_program(&self, model: &pms_model::PmsModel) -> Result<(), String> {
        let program = &self.ctx.program;

        if program.len() <= 1 {
            return Ok(());
        }

        for i in 1..program.len() {
            let prev = program[i - 1].op;
            let next = program[i].op;

            let prev_name = op_name(prev);
            let next_name = op_name(next);

            if !model.allows_predecessor(prev_name, next_name) {
                let expected = model
                    .expected_predecessors(next_name)
                    .unwrap_or_default()
                    .join(", ");

                return Err(format!(
                    "Validation failed at index {}:\n  previous: {}\n  next: {}\n  expected previous one of: [{}]\n  transition: {} -> {} not allowed",
                    i, prev_name, next_name, expected, prev_name, next_name
                ));
            }
        }

        Ok(())
    }

    /// v2 validation: stateful structural constraints via a shadow-state pass (no execution).
    ///
    /// Goal:
    /// - Catch structural violations early, before running the interpreter.
    /// - Mirrors key runtime enforcement decisions (especially B8 sealing rules).
    ///
    /// Enforced in v2:
    /// - Ω requires a frame and is forbidden after Ψ sealed the frame.
    /// - Α requires a frame and is forbidden after Ψ sealed the frame.
    /// - Σ requires a frame (and is allowed even if sealed: v0 decision).
    /// - Χ enter is forbidden if the current isolation is sealed.
    /// - Χ exit requires an active isolation.
    pub fn validate_program_stateful(&self) -> Result<(), String> {
        #[derive(Debug, Clone)]
        struct Shadow {
            has_frame: bool,
            frame_sealed: bool,
            iso_stack: Vec<bool>, // sealed flags per isolation stack frame
        }

        impl Shadow {
            fn current_iso_sealed(&self) -> bool {
                self.iso_stack.last().copied().unwrap_or(false)
            }
            fn has_iso(&self) -> bool {
                !self.iso_stack.is_empty()
            }
        }

        let mut s = Shadow {
            has_frame: false,
            frame_sealed: false,
            iso_stack: Vec::new(),
        };

        for (i, op) in self.ctx.program.iter().enumerate() {
            // 1) Preconditions and B8 constraints (checked BEFORE applying this op's effects).
            match op.op {
                Operator::Omega => {
                    if !s.has_frame {
                        return Err(format!(
                            "Validation v2 failed at index {}: Ω requires an active frame",
                            i
                        ));
                    }
                    if s.frame_sealed {
                        return Err(format!(
                            "Validation v2 failed at index {}: sealed frame: Ω forbidden",
                            i
                        ));
                    }
                }
                Operator::Attractor => {
                    if !s.has_frame {
                        return Err(format!(
                            "Validation v2 failed at index {}: Α requires an active frame",
                            i
                        ));
                    }
                    if s.frame_sealed {
                        return Err(format!(
                            "Validation v2 failed at index {}: sealed frame: Α forbidden",
                            i
                        ));
                    }
                }
                Operator::Sigma => {
                    if !s.has_frame {
                        return Err(format!(
                            "Validation v2 failed at index {}: Σ requires an active frame",
                            i
                        ));
                    }
                    // v0 decision: Σ is allowed even if the frame is sealed.
                }
                // Kernel dialect note:
                // Χ models an executable isolation boundary (not theoretical PMS distance).
                Operator::Chi => match op.params {
                    OpParams::IsolationEnter { .. } => {
                        if s.current_iso_sealed() {
                            return Err(format!(
                                "Validation v2 failed at index {}: sealed isolation: Χ enter forbidden",
                                i
                            ));
                        }
                    }
                    OpParams::IsolationExit => {
                        if !s.has_iso() {
                            return Err(format!(
                                "Validation v2 failed at index {}: Χ exit requires an active isolation",
                                i
                            ));
                        }
                    }
                    _ => {}
                },
                _ => {}
            }

            // 2) Update shadow state based on this op's structural effects (no execution).
            match op.op {
                Operator::Frame => {
                    // Variant B: opening a new frame is always allowed and starts unsealed.
                    s.has_frame = true;
                    s.frame_sealed = false;
                }
                Operator::Psi => {
                    // B8: Ψ seals current frame (if present) and current isolation (if present).
                    if s.has_frame {
                        s.frame_sealed = true;
                    }
                    if let Some(top) = s.iso_stack.last_mut() {
                        *top = true;
                    }
                }
                Operator::Chi => match op.params {
                    OpParams::IsolationEnter { .. } => s.iso_stack.push(false),
                    OpParams::IsolationExit => {
                        s.iso_stack.pop();
                    }
                    _ => {}
                },
                _ => {}
            }
        }

        Ok(())
    }

    /// Execute exactly one opcode.
    ///
    /// Invariants:
    /// - pc advances by exactly 1 per dispatch attempt.
    /// - Fail-closed runtime enforcement: on invariant violation return Error and do not emit events.
    /// - Only Θ advances tick in v0 (deterministic time model).
    pub fn step(&mut self) -> StepOutcome {
        if self.ctx.is_finished() {
            return StepOutcome::Finished;
        }

        let opcode = self.ctx.program[self.ctx.pc].clone();
        self.ctx.pc += 1;

        match opcode.op {
            Operator::Theta => {
                // Θ: deterministic tick advancement.
                // v0 default: Θ + None advances by dt=1.
                let dt = match opcode.params {
                    OpParams::Advance { dt } => dt,
                    OpParams::None => 1,
                    other => {
                        return StepOutcome::Error(format!(
                            "Θ expects Advance{{dt}} or None, got: {:?}",
                            other
                        ));
                    }
                };

                self.state.advance_tick(dt);
                self.state
                    .emit(Operator::Theta, format!("advance dt={}", dt));

                // B3 coupling: Θ drives non-event detection (expectation timeouts).
                self.state.check_non_events();
                StepOutcome::Ok
            }

            Operator::Delta => {
                // Δ: declaration-style event (v0: no state mutation beyond event stream).
                if let OpParams::NewEntity { name } = opcode.params {
                    let n = KernelState::kv_escape(&name);
                    self.state
                        .emit(Operator::Delta, format!("new_entity name={}", n));
                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("Δ expects NewEntity{name}".to_string())
                }
            }

            Operator::Frame => {
                // □: open a new frame and make it current.
                // v0: frames start unsealed; Ψ is the only seal operation.
                if let OpParams::NewFrame { kind } = opcode.params {
                    let id = self.state.push_new_frame(kind.clone());
                    let k = KernelState::kv_escape(&kind);
                    self.state
                        .emit(Operator::Frame, format!("push_frame id={} kind={}", id, k));
                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("□ expects NewFrame{kind}".to_string())
                }
            }

            Operator::Omega => {
                // Ω: requires active frame; forbidden after Ψ sealed the current frame (B8).
                if self.state.is_current_frame_sealed() {
                    return StepOutcome::Error("sealed frame: Ω forbidden".to_string());
                }

                let frame_id = match self.state.current_frame_id() {
                    Some(id) => id,
                    None => {
                        return StepOutcome::Error(
                            "Ω requires an active frame (use: frame <kind>)".to_string(),
                        );
                    }
                };

                if let OpParams::Asymmetry {
                    from,
                    to,
                    weight,
                    desc,
                } = opcode.params
                {
                    self.state.asymmetries.push(AsymmetryEdge {
                        frame_id,
                        from: from.clone(),
                        to: to.clone(),
                        weight,
                        desc: desc.clone(),
                    });

                    // Event formatting is stable key=value:
                    // - floats via kv_f32
                    // - strings escaped via kv_escape
                    let w = KernelState::kv_f32(weight);
                    let d = KernelState::kv_escape(&desc);
                    let f = KernelState::kv_escape(&from);
                    let t = KernelState::kv_escape(&to);

                    self.state.emit(
                        Operator::Omega,
                        format!(
                            "asymmetry frame_id={} from={} to={} weight={} desc={}",
                            frame_id, f, t, w, d
                        ),
                    );
                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("Ω expects Asymmetry{from,to,weight,desc}".to_string())
                }
            }

            Operator::Nabla => {
                // ∇: requires active frame; impulse is recorded frame-scoped in v0.
                let frame_id = match self.state.current_frame_id() {
                    Some(id) => id,
                    None => {
                        return StepOutcome::Error(
                            "∇ requires an active frame (use: frame <kind>)".to_string(),
                        );
                    }
                };

                if let OpParams::Impulse {
                    entity,
                    intensity,
                    desc,
                } = opcode.params
                {
                    let id = self.state.record_impulse(
                        Some(frame_id),
                        entity.clone(),
                        intensity,
                        desc.clone(),
                    );

                    let i = KernelState::kv_f32(intensity);
                    let d = KernelState::kv_escape(&desc);
                    let ent = KernelState::kv_escape(&entity);

                    self.state.emit(
                        Operator::Nabla,
                        format!(
                            "impulse id={} frame_id={} entity={} intensity={} desc={}",
                            id, frame_id, ent, i, d
                        ),
                    );

                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("∇ expects Impulse{entity,intensity,desc}".to_string())
                }
            }

            Operator::Sigma => {
                // Σ: integrate current frame.
                // v0 decision: Σ is allowed even after Ψ sealed the frame (B8 variant).
                if let OpParams::Integrate { note } = opcode.params {
                    match self.state.integrate_current_frame(note.clone()) {
                        Ok(ev) => {
                            let note = KernelState::kv_escape(&ev.note);

                            // Stable, no spaces: [1,2,3]
                            let consumed = ev
                                .consumed_impulse_ids
                                .iter()
                                .map(|x| x.to_string())
                                .collect::<Vec<_>>()
                                .join(",");
                            let consumed = format!("[{}]", consumed);

                            self.state.emit(
                                Operator::Sigma,
                                format!(
                                    "integrate frame_id={} note={} consumed={}",
                                    ev.frame_id, note, consumed
                                ),
                            );
                            StepOutcome::Ok
                        }
                        Err(e) => StepOutcome::Error(e),
                    }
                } else {
                    StepOutcome::Error("Σ expects Integrate{note}".to_string())
                }
            }

            Operator::Lambda => {
                // Λ: register an expectation. Θ advances time and triggers timeout checks into non-events.
                if let OpParams::Expectation { horizon, desc } = opcode.params {
                    let frame_id = self.state.current_frame_id(); // optional
                    let id = self
                        .state
                        .record_expectation(frame_id, horizon, desc.clone());

                    let d = KernelState::kv_escape(&desc);

                    self.state.emit(
                        Operator::Lambda,
                        format!(
                            "expectation id={} frame_id={:?} horizon={} due_tick={} desc={}",
                            id,
                            frame_id,
                            horizon,
                            self.state
                                .expectations
                                .last()
                                .map(|e| e.due_tick)
                                .unwrap_or(0),
                            d
                        ),
                    );
                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("Λ expects Expectation{horizon,desc}".to_string())
                }
            }

            Operator::Attractor => {
                // Α: requires active frame; forbidden after Ψ sealed the frame (B8).
                if self.state.is_current_frame_sealed() {
                    return StepOutcome::Error("sealed frame: Α forbidden".to_string());
                }

                if let OpParams::Attractor { label } = opcode.params {
                    match self.state.upsert_attractor(label.clone()) {
                        Ok((id, frame_id, label, count, strength)) => {
                            let s = KernelState::kv_f32(strength);
                            let l = KernelState::kv_escape(&label);

                            self.state.emit(
                                Operator::Attractor,
                                format!(
                                    "upsert frame_id={} id={} label={} count={} strength={}",
                                    frame_id, id, l, count, s
                                ),
                            );
                            StepOutcome::Ok
                        }
                        Err(e) => StepOutcome::Error(e),
                    }
                } else {
                    StepOutcome::Error("Α expects Attractor{label}".to_string())
                }
            }

            Operator::Phi => {
                // Φ: reframing is allowed without a frame; event carries optional frame_id for context.
                if let OpParams::Reframe { from, to } = opcode.params {
                    let frame_id = self.state.current_frame_id(); // optional
                    let f = KernelState::kv_escape(&from);
                    let t = KernelState::kv_escape(&to);

                    self.state.emit(
                        Operator::Phi,
                        format!("reframe frame_id={:?} from={} to={}", frame_id, f, t),
                    );
                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("Φ expects Reframe{from,to}".to_string())
                }
            }

            Operator::Chi => match opcode.params {
                OpParams::IsolationEnter { label } => {
                    // Χ enter is forbidden if the current isolation is already sealed (B8).
                    if self.state.is_current_isolation_sealed() {
                        return StepOutcome::Error(
                            "sealed isolation: Χ enter forbidden".to_string(),
                        );
                    }

                    let id = self.state.push_isolation(label.clone());
                    let frame_id = self.state.current_frame_id(); // optional
                    let l = KernelState::kv_escape(&label);

                    self.state.emit(
                        Operator::Chi,
                        format!(
                            "enter_isolation id={} frame_id={:?} label={}",
                            id, frame_id, l
                        ),
                    );
                    StepOutcome::Ok
                }
                OpParams::IsolationExit => {
                    // Χ exit requires an active isolation. Exiting a sealed isolation is allowed (B8 variant).
                    let frame_id = self.state.current_frame_id(); // optional
                    match self.state.pop_isolation() {
                        Ok(id) => {
                            self.state.emit(
                                Operator::Chi,
                                format!("exit_isolation id={} frame_id={:?}", id, frame_id),
                            );
                            StepOutcome::Ok
                        }
                        Err(e) => StepOutcome::Error(e),
                    }
                }
                other => StepOutcome::Error(format!(
                    "Χ expects IsolationEnter{{label}} or IsolationExit, got: {:?}",
                    other
                )),
            },

            Operator::Psi => {
                // Ψ: record commit + seal current frame/isolation (if any) + snapshot anchors (B8).
                if let OpParams::Commit { note } = opcode.params {
                    let ev = self.state.record_commit(note.clone());

                    // B8-B: seal current frame/isolation (if present).
                    if let Some(f) = self.state.current_frame_mut() {
                        f.sealed = true;
                    }
                    if let Some(i) = self.state.current_isolation_mut() {
                        i.sealed = true;
                    }

                    // B8-A: snapshot anchor captured before emitting the commit event.
                    let snap = CommitSnapshot {
                        id: ev.id,
                        tick: ev.tick,
                        frame_id: ev.frame_id,
                        isolation_id: ev.isolation_id,
                        note: ev.note.clone(),

                        event_len: self.state.events.len(),
                        integration_len: self.state.integration_log.len(),
                        asymmetry_len: self.state.asymmetries.len(),
                        impulse_len: self.state.impulses.len(),
                        expectation_len: self.state.expectations.len(),
                        attractor_len: self.state.attractors.len(),
                    };
                    self.state.commit_snapshots.push(snap);

                    let n = KernelState::kv_escape(&ev.note);

                    self.state.emit(
                        Operator::Psi,
                        format!(
                            "commit id={} frame_id={:?} isolation_id={:?} note={}",
                            ev.id, ev.frame_id, ev.isolation_id, n
                        ),
                    );
                    StepOutcome::Ok
                } else {
                    StepOutcome::Error("Ψ expects Commit{note}".to_string())
                }
            }
        }
    }

    /// Deterministic run loop until:
    /// - Finished (pc >= program.len())
    /// - Error
    /// - Optional max_steps cap (test safety)
    pub fn run_until_finished(&mut self, max_steps: Option<usize>) -> Result<(), String> {
        let mut steps = 0usize;

        loop {
            if let Some(max) = max_steps
                && steps >= max
            {
                return Err(format!("Max steps reached: {}", max));
            }

            match self.step() {
                StepOutcome::Ok => steps += 1,
                StepOutcome::Finished => return Ok(()),
                StepOutcome::Error(e) => return Err(e),
            }
        }
    }
}

#[cfg(test)]
mod testmods {
    // Each module is a focused regression guard for a kernel rule or formatting invariant.
    mod b0_frames;
    mod b1_omega;
    mod b2_event_format;
    mod b2_impulse_sigma;
    mod b3_lambda_nonevent;
    mod b4_attractor;
    mod b5_reframe;
    mod b6_isolation;
    mod b7_commit;
    mod b8_psi_seal_snapshot;

    // C1: FS + model key stability.
    mod c1_fs_api;
    mod c1_fs_events;
    mod c1_fs_root;
    mod c1_operator_model_keys;

    // Formatting stability guards.
    mod c2_omega_event_weight_format_stable;

    // Validation layers.
    mod validation;
    mod validation_model_aliases;
    mod validation_model_empty_is_open_world;
    mod validation_sync;
    mod validation_v2;

    // Parser/escaping edge cases.
    mod event_meta_edgecases;
    mod kv_escape_roundtrip;
}
