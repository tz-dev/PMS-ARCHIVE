# PMS-STACK Evidence Spine Roadmap

This roadmap separates the v0.1 Evidence Spine Release from Release+ work.

The v0.1 release target is:

```text
PMS-STACK Evidence Spine Release
```

It is not:

```text
full PMS-OS
PMS-CPU / ISA
PMSL compiler
distributed PMS
trusted AI execution
PMS 1.3 semantic migration
```

---

# v0.1 Release Scope

v0.1 proves the executable spine:

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ pms-model-data/PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace/audit
→ vFS service layer
→ optional AI analyze
→ golden tests + demos + docs
```

Accepted v0.1 claim:

```text
PMS-Rust is a tested, documented, deterministic PMS-STACK evidence spine:
a runtime/DSL/REPL/vFS/validation/JSONL/AI-bridge implementation that demonstrates
the Δ–Ψ operator model can be executed, validated, traced, and inspected
as a bounded computational spine, without claiming to implement the full PMS-STACK OS/CPU/PMSL architecture yet.
```

---

# v0.1 Complete / Gate-Backed

The following are part of the v0.1 Evidence Spine:

```text
deterministic kernel execution
PMS opcode buffer
PmsBuilder
interactive REPL
.pms script runner
active pms-model-data/PMS.yaml adjacency validation
stateful kernel validation
runtime/theory/symbol key normalization
JSONL schema pms.events.v0
JSONL control-char escaping
optional JSONL meta export
golden tests
vFS service layer
fs_create / fs_mkdir / fs_write / fs_read / fs_ls / fs_delete
fs_state / fs_events / fs_clear_events / fs_dump
script-mode fs_* rejection
show / show json program buffer inspection
ai_ping
ai_analyze advisory path
ai_compile fail-closed path
ai_compile --dry-run
ai_compile --show-json
AI trust boundary documentation
acceptance gates
reproducible demo scripts
```

---

# Release+ Work

The following items are explicitly post-v0.1.

They may be implemented later without changing the v0.1 evidence-spine claim.

## PMS-OS

Future scope:

```text
process model
scheduler
capability model
resource policies
persistent service registry
kernel/user boundary
real host isolation mappings
```

v0.1 status:

```text
not implemented
not claimed
```

## PMS-CPU / ISA

Future scope:

```text
instruction set
assembler
simulator
register/memory model
opcode lowering
trace equivalence tests
```

v0.1 status:

```text
not implemented
not claimed
```

## PMSL Compiler

Future scope:

```text
source language
parser
type/effect model
lowering to PMS opcodes
compiler diagnostics
standard library
```

v0.1 status:

```text
not implemented
not claimed
```

## Distributed PMS

Future scope:

```text
node model
distributed trace protocol
consensus / reconciliation semantics
network transport
distributed validation
```

v0.1 status:

```text
not implemented
not claimed
```

---

# vFS Release+ Items

v0.1 includes a minimal service-layer vFS.

Release+ candidates:

```text
fs_write_b64
fs_exists
fs_stat
fs_tree
fs_move
fs_copy
file-backed persistence
permissions
journaling
mount-like service surfaces
```

Recommended order:

```text
1. fs_exists
2. fs_stat
3. fs_tree
4. fs_write_b64
5. fs_move
6. fs_copy
7. persistence / journaling
8. permissions
```

Rationale:

```text
fs_exists/stat/tree improve demos and diagnostics without changing lifecycle semantics.
fs_move/fs_copy introduce more edge cases and should remain post-v0.1.
```

---

# AI Release+ Items

v0.1 AI is proposal-only and fail-closed.

Release+ candidates:

```text
AI-generated ChiExit
file-based AI backend for deterministic CI fixtures
required_literals host enforcement
redundant Delta diagnostics
addon-aware advisory analysis
multi-model compare mode
structured prompt templates
offline fixture replay
```

## AI-generated ChiExit

v0.1 status:

```text
manual chi_exit exists
AI compile supports Chi enter-only
AI-generated ChiExit is not whitelisted
```

Release+ path:

```text
add ChiExit to compile whitelist
map ChiExit to builder.isolation_exit()
validate balanced isolation
reject unbalanced ChiExit fail-closed
add golden tests for AI-generated balanced isolation
document behavior in AI_BRIDGE.md
```

## File-based AI backend

Purpose:

```text
deterministic AI bridge tests without requiring Ollama
stable CI fixtures for compile_scenario and analyze_trace
```

Possible interface:

```text
PMS_AI_BACKEND=file
PMS_AI_RESPONSE_FIXTURE=path/to/fixture.json
```

---

# Frame Lifecycle Release+

v0.1 status:

```text
frames are push-only
Psi seals the current frame
new frame after sealed frame is allowed
FrameExit is not implemented
```

Do not add `FrameExit` casually.

A future frame-exit design must define:

```text
stack pop semantics
sealed-frame behavior
interaction with Psi snapshots
interaction with active isolation
validation v2 shadow-state
golden trace changes
JSONL compatibility
```

---

# Add-ons Release+

Add-ons are not kernel execution regimes in v0.1.

Future add-on support should remain advisory:

```text
JSONL trace
→ AI bridge / analyzer
→ addon schema as analysis context
→ advisory findings
```

Add-ons must not:

```text
redefine PMS operators
alter kernel execution
alter validation pass/fail
become diagnosis/policy/runtime truth
silently mutate traces
```

Possible future command:

```text
ai_analyze --addon conflict trace.jsonl
```

---

# PMS 1.1 → PMS 1.3 Alignment

v0.1 intentionally remains a PMS 1.1-compatible Rust runtime subset.

The current theory line has moved toward PMS 1.3 concepts. This is not a v0.1 blocker.

Important boundary:

```text
Rust v0.1 Chi / Χ = isolation/boundary scope
PMS 1.3 Chi / Χ = Distance axis
```

This shared symbol/key must be treated as a migration boundary, not as accidental equivalence.

## Current v0.1 policy

```text
do not migrate operator semantics mid-release
document PMS 1.1-compatible runtime subset
keep JSONL runtime keys stable
keep pms-model normalization explicit
keep PMS 1.3 alignment as Release+ work
```

## Future migration work

A PMS 1.1 → PMS 1.3 migration should define:

```text
operator semantic diffs
dependency table diffs
YAML schema diffs
normalization changes
JSONL compatibility policy
golden fixture migration policy
AI compile whitelist changes
AI prompt/envelope schema changes
stateful validation impact
runtime behavior impact
documentation impact
```

## Acceptance for future migration

A future PMS 1.3 alignment should include:

```text
migration notes
updated PMS.yaml or versioned model files
compatibility tests
golden trace diff review
updated KEY_WORLDS.md
updated EVENT_FORMAT.md if keys/schema change
updated AI_BRIDGE.md if compile operators change
explicit release note
```

Until then, the v0.1 release statement is:

```text
PMS-Rust implements a PMS 1.1-compatible executable evidence spine subset.
PMS 1.3 alignment is Release+.
```

---

# Suggested Release+ Order

Recommended after `pms-spine-v0.1`:

```text
1. documentation polish from first external read-through
2. fs_exists / fs_stat / fs_tree
3. file-based AI backend
4. redundant Delta diagnostics
5. required_literals enforcement
6. AI-generated ChiExit
7. add-on advisory analysis
8. PMS 1.1 → PMS 1.3 migration plan
9. PMSL parser/compiler prototype
10. PMS-CPU/ISA simulator prototype
11. OS/process/capability layer
```

---

# Release Boundary

The v0.1 release is complete when:

```text
Gate A PASS
Gate B PASS
Gate C PASS
Gate D PASS
Gate E PASS
Gate F PASS
Gate G PASS
Gate H PASS
```

Defined in:

```text
pms-docs/ACCEPTANCE_GATES.md
```

Recommended tag:

```text
pms-spine-v0.1
```