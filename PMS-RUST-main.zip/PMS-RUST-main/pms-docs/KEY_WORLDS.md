# PMS Key Worlds

PMS-RUST v0.1 intentionally distinguishes several key worlds.

This prevents naming drift between theory notation, runtime events, YAML validation, REPL commands, and JSONL audit output.

---

# Summary

The project uses four related but distinct naming worlds:

```text
Symbol keys   → Δ, □, Α, Ω, Θ, Φ, Χ, Σ, Ψ
Theory keys   → Delta, Square, Alpha, Omega, Theta, Phi, Chi, Sigma, Psi
Runtime keys  → Delta, Frame, Attractor, Omega, Theta, Phi, Chi, Sigma, Psi
REPL aliases  → entity, frame, attractor, omega, theta, phi, integrate, psi, ...
```

The important rule:

```text
JSONL emits runtime keys.
pms-model validates through normalized theory keys.
```

---

# Runtime Keys

Runtime keys are emitted by the Rust runtime and JSONL traces.

Examples:

```text
Delta
Frame
Nabla
Lambda
Attractor
Omega
Theta
Phi
Chi
Sigma
Psi
```

Runtime keys answer:

```text
What did the Rust kernel execute or log?
```

Example event:

```text
[tick 0] Frame push_frame id=0 kind=ctx
```

Example JSONL:

```json
{"schema":"pms.events.v0","tick":0,"op":"Frame","msg":"push_frame id=0 kind=ctx"}
```

Runtime keys are the stable event/audit surface for v0.1.

---

# Theory Keys

Theory keys are the canonical model/theory names used by `pms-model`.

Examples:

```text
Delta
Square
Nabla
Lambda
Alpha
Omega
Theta
Phi
Chi
Sigma
Psi
```

Theory keys answer:

```text
What PMS model operator is this normalized to?
```

Important runtime-to-theory mappings:

```text
Runtime Frame      → Theory Square
Runtime Attractor  → Theory Alpha
Runtime Delta      → Theory Delta
Runtime Omega      → Theory Omega
Runtime Theta      → Theory Theta
Runtime Phi        → Theory Phi
Runtime Chi        → Theory Chi
Runtime Sigma      → Theory Sigma
Runtime Psi        → Theory Psi
```

---

# Symbol Keys

Symbol keys are compact PMS operator symbols.

Examples:

```text
Δ → Delta
□ → Square
∇ → Nabla
Λ → Lambda
Α → Alpha
Ω → Omega
Θ → Theta
Φ → Phi
Χ → Chi
Σ → Sigma
Ψ → Psi
```

Symbol keys may appear in theory-facing docs or future model files.

They are normalized by `pms-model` where accepted.

---

# REPL / DSL Aliases

The REPL exposes user-facing commands.

Examples:

```text
entity      → Delta
frame       → Frame runtime key → Square theory key
impulse     → Nabla
expect      → Lambda
attractor   → Attractor runtime key → Alpha theory key
omega       → Omega
theta       → Theta
phi         → Phi
chi         → Chi enter
chi_exit    → Chi exit
integrate   → Sigma
psi         → Psi
```

The `.pms` script format uses the same program DSL commands.

Important boundary:

```text
fs_* commands are not PMS program DSL commands.
fs_* commands are REPL service commands.
fs_* commands are rejected in .pms scripts.
```

---

# Model Validation Normalization

`pms-model` normalizes input operator names before validation.

The active model file is:

```text
pms-model-data\PMS.yaml
```

Validation uses a top-level machine-readable dependency table:

```yaml
dependency_table:
  Square: [Delta, Nabla]
  Alpha: [Delta, Nabla, Square, Lambda]
  Omega: [Alpha]
```

Runtime validation therefore works even when runtime event/operator names differ from theory names.

Example:

```text
Runtime pair: Frame -> Attractor
Normalized:   Square -> Alpha
Model check:  Square is an allowed predecessor of Alpha
```

Example failure:

```text
Runtime pair: Delta -> Omega
Normalized:   Delta -> Omega
Model check:  Omega expects Alpha
Result:       rejected
```

Observed failure:

```text
Validation failed at index 1:
  previous: Delta
  next: Omega
  expected previous one of: [Alpha]
  transition: Delta -> Omega not allowed
```

---

# JSONL Key Policy

JSONL emits runtime keys.

This is intentional.

Example:

```json
{"schema":"pms.events.v0","tick":0,"op":"Frame","msg":"push_frame id=0 kind=ctx"}
```

The JSONL key is:

```text
Frame
```

not:

```text
Square
```

Reason:

```text
JSONL mirrors what the Rust runtime emitted.
Model validation normalizes runtime keys separately.
```

This keeps audit output faithful to runtime behavior while preserving theory validation.

---

# AI Compile Key Policy

AI compile accepts canonical compile operators, then host code canonicalizes and maps them into `PmsBuilder`.

Allowed compile operator names include:

```text
Delta
Nabla
Square
Omega
Theta
Lambda
Phi
Chi
Sigma
Psi
Alpha
```

Mapping examples:

```text
Square → builder.frame(...)
Alpha  → builder.attractor(...)
Chi    → builder.isolation_enter(...)
```

Important v0.1 limitation:

```text
AI compile supports Chi enter-only.
AI-generated ChiExit is Release+.
```

AI compile output is not trusted executable code.

The host still performs:

```text
JSON parse
task/result-shape enforcement
opcode whitelist
params validation
builder mapping
model validation if enabled
stateful validation if enabled
```

---

# Chi / Χ Version Boundary

In PMS-RUST v0.1:

```text
Chi / Χ = isolation/boundary scope
```

In later PMS theory work, PMS 1.3 uses:

```text
Χ = Distance
```

This is a known version/scope boundary.

Do not silently equate the two semantics.

v0.1 policy:

```text
Rust remains PMS 1.1-compatible.
Chi remains runtime isolation/boundary in this release.
PMS 1.3 alignment is Release+ work.
```

Migration notes are tracked in:

```text
pms-docs\ROADMAP.md
```

---

# Practical Rules

Use these rules when editing code, fixtures, or docs:

```text
1. Runtime events and JSONL should use runtime keys.
2. PMS model files should use theory keys or supported symbols/aliases.
3. Validation must normalize runtime/theory/symbol keys explicitly.
4. Golden fixtures should not be casually rewritten from runtime keys to theory keys.
5. AI compile operators must pass through host-side canonicalization.
6. Chi semantics must state whether they refer to v0.1 runtime isolation or later theory Distance.
7. fs_* commands are service commands, not PMS program operators.
```

---

# v0.1 Stable Surface

For v0.1, the stable public surfaces are:

```text
runtime JSONL op keys
.pms script DSL commands
pms-model-data\PMS.yaml dependency_table
AI envelope task/result shapes
DEMO.md smoke commands
ACCEPTANCE_GATES.md gate definitions
```

Changing any of these requires checking:

```text
pms-docs\EVENT_FORMAT.md
pms-docs\DEMO.md
pms-docs\ACCEPTANCE_GATES.md
golden fixtures
workspace tests
```

