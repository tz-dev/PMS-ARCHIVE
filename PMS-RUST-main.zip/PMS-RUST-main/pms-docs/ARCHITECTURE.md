# PMS-STACK Architecture v0.1

This repository implements a bounded PMS-STACK Evidence Spine.

It is a deterministic runtime/toolchain slice, not a complete PMS-OS.

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ pms-model-data/PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace/audit
→ vFS service layer
→ optional AI analyze
```

The architectural goal of v0.1 is evidence:

```text
The Δ–Ψ operator model can be authored, validated, executed, traced, inspected, and optionally analyzed through a controlled AI proposal layer.
```

---

## Design goals

v0.1 prioritizes:

```text
deterministic execution
deterministic event logging
active model validation
stateful pre-execution validation
strict program/service separation
JSONL auditability
small testable crates
fail-closed AI integration
Windows-first CPU-only workflow
```

v0.1 does not implement:

```text
full PMS-OS
PMS-CPU/ISA
PMSL compiler
distributed PMS
full vFS permissions/journaling
addon-driven runtime policies
trusted AI execution
PMS 1.3 semantic migration
```

---

# Crate Architecture

## `pms-kernel/`

`pms-kernel` is the deterministic execution core.

Responsibilities:

```text
execute Vec<OpCode>
emit KernelEvent records
maintain frame/isolation runtime state
apply runtime guards
validate adjacency through pms-model
validate stateful constraints through shadow-state
host vFS state primitives used by the REPL service layer
```

Core runtime concepts:

```text
Delta      entity/distinction event
Frame      runtime frame push
Nabla      impulse
Lambda     expectation
Attractor  attractor/upsert
Omega      asymmetry/edge
Theta      time advance
Phi        reframe
Chi        isolation/boundary enter/exit
Sigma      integration
Psi        commit/seal
```

## Kernel dialect note

The kernel uses PMS symbols and names for continuity with the theory, but v0.1 is an executable runtime subset.

Important dialect distinction:

```text
Chi / Χ in this Rust runtime means isolation/boundary scope.
```

It is not the later PMS 1.3 theoretical Χ = Distance axis.

The shared key is intentionally documented as a version/scope boundary. PMS 1.3 alignment is Release+ work.

---

## `pms-model/`

`pms-model` loads machine-readable model constraints from:

```text
pms-model-data/PMS.yaml
```

Responsibilities:

```text
load dependency_table
reject multiple competing non-empty dependency tables
normalize operator names
answer adjacency questions
report expected predecessor sets
```

Normalization bridges:

```text
symbol keys:   Δ, □, Α, Ω, Θ, Φ, Χ, Σ, Ψ
theory keys:   Delta, Square, Alpha, Omega, Theta, Phi, Chi, Sigma, Psi
runtime keys:  Delta, Frame, Attractor, Omega, Theta, Phi, Chi, Sigma, Psi
aliases:       frame -> Square, attractor -> Alpha
```

Policy:

```text
known op with no dependency rule → open-world allowed
unknown op identifier            → rejected
known op with rule               → predecessor must be allowed
```

---

## `pms-ir/`

`pms-ir` provides `PmsBuilder`, the convenience builder for PMS opcode programs.

Responsibilities:

```text
build small PMS programs
offer ergonomic methods for each operator
maintain a program buffer
allow read-only buffer inspection
drain buffer transactionally on run
```

Builder semantics relevant to tools:

```text
entity(name) is idempotent
program() views the current buffer without draining
take_program() drains the current buffer
advance(0) emits Theta with runtime default behavior
```

---

## `pms-repl/`

`pms-repl` is the main user-facing tool.

Responsibilities:

```text
interactive REPL
.pms script runner
DSL line mapping into PmsBuilder
show / show json buffer inspection
run program buffer through kernel
dump/load JSONL traces
vFS service commands
AI commands through pms-ai-bridge
```

Main command families:

```text
program DSL: entity, frame, impulse, integrate, expect, attractor, omega, theta, phi, chi, chi_exit, psi
buffer UX:   show, show json, clear, run
model UX:    model <path>, validate on/off
trace UX:    dump <path>, ai_analyze <path>
vFS UX:      fs_create, fs_mkdir, fs_write, fs_read, fs_ls, fs_delete, fs_state, fs_events, fs_clear_events, fs_dump
AI UX:       ai_ping, ai_compile, ai_compile --dry-run, ai_compile --show-json
```

---

## `pms-ai-bridge/`

`pms-ai-bridge` is an optional local AI proposal layer.

Responsibilities:

```text
build typed AI request envelopes
parse typed AI response envelopes
support analyze_trace
support compile_scenario
enforce task/result shape
canonicalize whitelisted compile opcodes
reject malformed or wrong-shaped outputs
check backend readiness via ai_ping
```

Trust boundary:

```text
LLM text
→ JSON parse
→ task/result-shape enforcement
→ opcode whitelist/canonicalization
→ REPL mapping into temporary builder
→ optional model validation
→ stateful validation
→ buffer replacement only after success
→ deterministic kernel execution
```

AI never executes code directly.

AI output is never trusted executable code.

---

# Program Timeline vs Service Calls

The architecture has two separate event worlds.

## Program timeline

Program timeline events are produced only by kernel execution.

Inputs:

```text
REPL DSL lines
.pms script lines
AI compile proposals accepted through host gates
```

Path:

```text
input
→ PmsBuilder
→ OpCode buffer
→ validation
→ Kernel
→ KernelEvent timeline
→ JSONL
```

Program events answer:

```text
What PMS program did the kernel execute?
```

## Service calls

Service calls are host/tooling actions.

Examples:

```text
fs_mkdir
fs_create
fs_write
fs_read
fs_ls
fs_delete
fs_events
fs_dump
```

Service calls:

```text
mutate vFS service state
emit service event log entries
do not enter the PMS program buffer
do not execute as kernel opcodes
are rejected in .pms scripts
```

Service events answer:

```text
What host/tooling service action happened?
```

This split is intentional and release-critical.

---

# Validation

Validation has two layers.

## v1: model adjacency validation

Source:

```text
pms-model-data/PMS.yaml
```

For every adjacent operator pair:

```text
(prev, next)
```

the validator asks whether `prev` is an allowed predecessor of `next`.

Example validated failure:

```text
Validation failed at index 1:
  previous: Delta
  next: Omega
  expected previous one of: [Alpha]
  transition: Delta -> Omega not allowed
```

This proves the release is not silently using open-world validation.

## v2: stateful validation

v2 validates runtime-state constraints before execution.

Examples:

```text
Omega requires an active frame
Omega is forbidden in a sealed frame
Attractor requires an active frame
Attractor is forbidden in a sealed frame
Sigma requires an active frame
Sigma is allowed in a sealed frame by v0.1 policy
Chi enter is forbidden in a sealed isolation
Chi exit requires an active isolation
new frame after sealed frame is allowed
```

v2 uses shadow-state validation and is kept in sync with runtime guards by tests.

---

# Sealing Semantics

`Psi` / Ψ commits and seals current runtime scopes.

On commit:

```text
records a commit event
seals the current frame if present
seals the current isolation if present
```

After sealing:

```text
Omega is forbidden in the sealed frame
Attractor is forbidden in the sealed frame
Sigma remains allowed in the sealed frame
Chi enter is forbidden in the sealed isolation
Chi exit from the sealed isolation remains allowed
starting a new frame is allowed
```

Frames are push-only in v0.1.

There is no `FrameExit` in v0.1.

---

# JSONL Trace / Audit Spine

JSONL is the audit format for kernel and service traces.

Current event schema:

```json
{"schema":"pms.events.v0","tick":0,"op":"Frame","msg":"push_frame id=0 kind=ctx"}
```

Optional meta:

```json
{
  "schema": "pms.events.v0",
  "tick": 0,
  "op": "Delta",
  "msg": "fs_create path=/x id=1",
  "meta": {
    "kind": "fs_create",
    "kv": {
      "path": "/x",
      "id": "1"
    }
  }
}
```

Rules:

```text
one JSON object per line
runtime keys are used in emitted events
control characters are escaped
known schema is accepted
missing schema is accepted for backward compatibility
unknown schema is rejected
meta is optional
```

Details:

```text
pms-docs/EVENT_FORMAT.md
```

---

# Key Worlds

The project intentionally distinguishes key worlds.

```text
runtime keys: emitted by Rust runtime and JSONL
theory keys:  used by PMS model/theory docs
symbol keys:  Δ, □, Ω, etc.
aliases:      human-friendly REPL/model variants
```

Examples:

```text
Runtime Frame     → normalized to theory Square for model validation
Runtime Attractor → normalized to theory Alpha for model validation
Symbol □          → normalized to Square
```

Details:

```text
pms-docs/KEY_WORLDS.md
```

---

# AI Boundary

AI integration is advisory/proposal-based.

Supported commands:

```text
ai_ping
ai_analyze last|<path.jsonl>
ai_compile <scenario>
ai_compile --dry-run <scenario>
ai_compile --show-json <scenario>
ai_compile --dry-run --show-json <scenario>
```

Compile support is intentionally bounded.

Allowed AI compile operators:

```text
Delta
Nabla
Square
Omega
Theta
Lambda
Phi
Chi
Sigma
Psi
Alpha
```

Important v0.1 cap:

```text
AI compile supports Chi enter-only.
AI-generated ChiExit is Release+.
FrameExit is not part of v0.1.
```

Details:

```text
pms-docs/AI_BRIDGE.md
```

---

# Demo and Acceptance Gates

Release acceptance is defined in:

```text
pms-docs/ACCEPTANCE_GATES.md
```

Reproducible demos are defined in:

```text
pms-docs/DEMO.md
pms-demos/
```

Minimum non-AI smoke:

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d3_stateful_invalid_sigma_no_frame.pms --run
cargo run -p pms-repl -- --file pms-demos\d4_script_rejects_fs.pms --run
```

Expected:

```text
first command succeeds
next three commands fail for documented reasons
```

---

# Platform Boundary

v0.1 is Windows-first and CPU-only.

Core functionality does not require:

```text
Linux namespaces
GPU backend
distributed runtime
external database
full OS process isolation
```

Release+ platform work may add Linux mappings, process isolation, GPU backends, distributed PMS components, or PMS-CPU/ISA simulation.

These do not change the v0.1 evidence-spine claim.