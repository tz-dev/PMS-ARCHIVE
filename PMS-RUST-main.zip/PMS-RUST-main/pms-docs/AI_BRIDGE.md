# PMS-AI-BRIDGE v0.1

`pms-ai-bridge` is the controlled AI proposal layer of the PMS-STACK Evidence Spine.

It provides typed request/response envelopes for a local LLM backend, currently Ollama-compatible, while keeping execution authority entirely outside the model.

```text
AI proposes.
Host parses, normalizes, validates, and gates.
Kernel executes only validated PMS opcode programs.
```

## Scope

This bridge is part of the PMS-STACK Evidence Spine, not a general autonomous agent runtime.

It supports:

```text
ai_ping
ai_analyze
ai_compile
ai_compile --dry-run
ai_compile --show-json
ai_compile --dry-run --show-json
```

It does not claim:

```text
AI output is trusted executable code.
AI directly mutates kernel state.
AI bypasses model/stateful validation.
AI implements a full PMS compiler.
AI implements PMS-OS, PMS-CPU, or PMSL.
```

---

## Trust Boundary

The model is never trusted as an executor.

The trust boundary is:

```text
LLM text
→ JSON envelope parse
→ task/result-shape enforcement
→ opcode whitelist and canonicalization
→ REPL mapping into temporary builder
→ optional model validation
→ stateful kernel validation
→ buffer replacement only after success
→ deterministic kernel run
```

The bridge and REPL are fail-closed:

```text
unknown task        → reject
task mismatch       → reject
wrong result shape  → reject
unknown opcode      → reject
bad params          → reject
empty opcode list   → reject
mapping failure     → reject
validation failure  → reject
transport failure   → reject
```

---

## Tasks

## `analyze_trace`

Intent:

```text
Summarize and extract advisory findings from an existing kernel trace.
```

Input:

```text
KernelEventLite[]
optional context
optional snapshot
```

Output shape:

```json
{
  "ok": true,
  "task": "analyze_trace",
  "result": {
    "text": "short advisory summary",
    "findings": [],
    "tags": []
  },
  "warnings": [],
  "error": null
}
```

Host rules:

```text
task must be "analyze_trace"
result must be analyze-shaped
compile-shaped result is rejected
ok=false without error receives deterministic host error
ok=true with error is treated as not ok
HTTP error bodies are truncated before surfacing
```

`analyze_trace` is advisory only. It never executes opcodes and never mutates program buffers or kernel state.

Additional sanity warnings may be emitted when the analysis appears to contradict the trace, for example:

```text
trace contains non_event but output suggests still waiting
trace contains non_event but output suggests fulfilled/satisfied
trace shows consumed=[] but output claims consumption
trace shows consumed=[...] but output suggests impulses are still pending
```

These sanity checks are warnings only.

---

## `compile_scenario`

Intent:

```text
Convert a free-text scenario into proposed PMS opcodes.
```

Input:

```text
free-text scenario description
```

Accepted output shape:

```json
{
  "ok": true,
  "task": "compile_scenario",
  "result": {
    "opcodes": [
      {
        "op": "Square",
        "params": { "kind": "ctx" }
      }
    ]
  },
  "warnings": [],
  "error": null
}
```

Host rules:

```text
task must be "compile_scenario"
result must be compile-shaped
result.opcodes must be non-empty
each op must normalize to an allowed canonical operator
each params value must be a JSON object
warnings are preserved and displayed
```

Allowed canonical compile operators:

```text
Delta
Nabla
Square
Omega
Theta
Lambda
Phi
Chi
Sigma
Psi
Alpha
```

Rejected examples:

```text
unknown op
op not in whitelist
params is null/array/string/number
missing result
empty opcodes
task mismatch
compile response shaped as analyze response
```

---

## Lenient Parsing and Strict Acceptance

The bridge may parse model JSON leniently to recover from minor formatting inconsistencies.

Lenient parsing does not mean lenient acceptance.

The effective policy is:

```text
parse leniently
then enforce task/result shape strictly
then enforce opcode/params gates strictly
```

Shape priority during parsing:

```text
if result.opcodes exists → parsed as compile-shaped
otherwise                → parsed as analyze-shaped
```

Safety is provided by later task-specific enforcement:

```text
compile_scenario requires compile-shaped result
analyze_trace requires analyze-shaped result
```

Therefore, a compile-shaped result returned for `analyze_trace` is rejected.

---

## REPL `ai_compile` Pipeline

Interactive `ai_compile` uses the bridge as a proposal source only.

Normal mode:

```text
ai_compile <scenario...>
```

Pipeline:

```text
call AI
parse envelope
enforce compile task/result shape
canonicalize opcodes
map opcodes into temporary PmsBuilder
run validation gates if validation is ON
replace active buffer only after all gates pass
```

Success:

```text
AI compile: N opcode(s)
OK. compiled program loaded into buffer. Use: run
```

Failure:

```text
active buffer remains unchanged
error includes trace chain where available
```

---

## `ai_compile --dry-run`

Dry-run mode:

```text
ai_compile --dry-run <scenario...>
```

Semantics:

```text
AI call happens
host parsing happens
canonicalization happens
REPL mapping happens
validation happens if ON
active buffer is not replaced
```

Success:

```text
OK. dry-run succeeded. Buffer unchanged.
```

This is the recommended preview path for demos and debugging.

---

## `ai_compile --show-json`

Show-json mode:

```text
ai_compile --show-json <scenario...>
```

Semantics:

```text
prints the canonical host-accepted compile envelope
normal mode still replaces the buffer after success
```

Combined preview mode:

```text
ai_compile --dry-run --show-json <scenario...>
ai_compile --show-json --dry-run <scenario...>
```

Semantics:

```text
prints canonical accepted compile JSON
does not replace the buffer
```

The JSON shown is not raw model text. It is the host-accepted compile result after parsing and bridge-side canonicalization.

Example shape:

```json
{
  "error": null,
  "ok": true,
  "result": {
    "opcodes": [
      {
        "op": "Square",
        "params": {
          "kind": "ctx"
        }
      }
    ]
  },
  "task": "compile_scenario",
  "warnings": []
}
```

---

## `ai_ping`

`ai_ping` checks backend reachability without sending scenario text or trace data.

Default backend behavior:

```text
chat endpoint: http://localhost:11434/api/chat
ping target:   http://localhost:11434/api/tags
```

Success:

```text
OK. AI backend reachable.
```

Failure:

```text
Error: ai ping failed: <reason>
```

---

## REPL Mapping Contract

After bridge acceptance, compile opcodes are mapped into `PmsBuilder`.

Mapping is strict and fail-closed.

```text
Delta   params: { name: string }
Square  params: { kind: string }
Theta   params: { dt?: u64 }              # default 1 if absent
Omega   params: { from: string, to: string, weight: number, desc: string }
Nabla   params: { entity: string, intensity: number, desc: string }
Lambda  params: { horizon: u64, desc: string }
Alpha   params: { label: string }
Chi     params: { label: string }         # enter only
Phi     params: { from: string, to: string }
Sigma   params: { note: string }
Psi     params: { note: string }
```

Any missing field, wrong field type, unsupported op, or non-object params value rejects the whole compile.

The active buffer is not modified on mapping failure.

---

## Mapping Caps

## Chi is enter-only in AI compile v0.1

Manual `chi_exit` exists in the DSL/REPL/kernel path.

AI compile v0.1 intentionally supports only:

```text
Chi { label } → isolation_enter(label)
```

It does not support AI-generated ChiExit.

Consequences:

```text
compiled scenarios can enter or nest isolation scopes
compiled scenarios cannot pop isolation scopes
balanced isolation can be authored manually
AI-generated balanced isolation is Release+
```

This is a v0.1 scope decision, not a kernel limitation.

Release+ option:

```text
add ChiExit to AI whitelist
map ChiExit to builder.isolation_exit()
validate unbalanced exit fail-closed
add golden tests for balanced AI isolation
```

## FrameExit is not v0.1

Frame lifecycle remains push-only by design.

Do not add `FrameExit` as part of AI compile v0.1. It would change frame-stack lifecycle, sealing semantics, validation state, and golden traces.

## Delta idempotence

`Delta` opcodes are mapped through:

```text
PmsBuilder::entity(name)
```

`entity(name)` is idempotent.

Consequences:

```text
repeated Delta("X") proposals may collapse to one emitted Delta in the buffer
this is intentional builder behavior
AI proposal count and final buffer count may differ for duplicate entities
```

A future diagnostic may warn on redundant Delta proposals, but this is not required for v0.1.

---

## Validation Gates

When validation is ON, `ai_compile` validates the proposed program before buffer replacement.

Validation layers:

```text
v1: PMS.yaml adjacency/model validation
v2: stateful kernel validation
```

Examples of rejected programs:

```text
invalid adjacency under PMS.yaml
Omega without required predecessor context
Attractor in sealed frame
Omega in sealed frame
Sigma without frame
ChiExit without open isolation
Chi enter in sealed isolation
```

Validation failures do not replace the active buffer.

Dry-run also executes validation when validation is ON.

---

## Error Trace Chain

REPL `ai_compile` errors may include a compact trace chain.

Example:

```text
Trace: repl.request_built -> bridge.http_sent -> bridge.http_ok -> bridge.parse_ok
```

Typical milestones:

```text
repl.request_built
bridge.http_sent
bridge.http_ok
bridge.parse_ok
repl.map_ok
validate.v1_start
validate.v1_ok
validate.v2_start
validate.v2_ok
repl.dry_run_ok
repl.buffer_replace_start
repl.buffer_replaced
```

This is diagnostic metadata only. It is not part of the PMS event trace.

---

## Environment Variables

## `PMS_AI_ENDPOINT`

Overrides the Ollama chat endpoint.

Default:

```text
http://localhost:11434/api/chat
```

## `PMS_AI_MODEL`

Overrides the model name.

Default:

```text
llama3.1:8b
```

## `PMS_TRACE`

Enables minimal stage tracing where trace sites are present.

Typical use:

```bat
set PMS_TRACE=1
cargo run -p pms-repl
```

Trace output may include:

```text
AI request started
HTTP status
parse result
opcode count
mapping stages
validation stages
buffer replacement stages
```

## `PMS_AI_DEBUG`

Enables heavier AI debug output where debug sites are present.

Debug output is intended for local development and may include truncated assistant/request details.

---

## Security and Safety Notes

Hard guarantees in v0.1:

```text
AI does not execute code
AI does not directly mutate kernel state
AI does not directly mutate vFS state
AI does not bypass host validation
AI does not bypass kernel validation
AI compile output is only a proposal
kernel execution remains deterministic
```

Risk is limited to incorrect suggestions, mitigated by:

```text
strict JSON task/result gates
operator whitelist
params object enforcement
REPL mapper type checks
temporary builder mapping
optional PMS.yaml model validation
stateful kernel validation
atomic-ish buffer replacement
dry-run preview mode
show-json audit mode
```

---

## Release+ Items

These are explicitly not required for the PMS-STACK Evidence Spine v0.1 release:

```text
AI-generated ChiExit
FrameExit
required_literals host enforcement
file-based AI backend for deterministic offline AI tests
redundant Delta warning
addon-based AI analysis
AI-generated filesystem service commands
```
