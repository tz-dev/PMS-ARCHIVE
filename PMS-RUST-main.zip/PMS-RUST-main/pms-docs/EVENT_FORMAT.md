# PMS Event Format

This document defines the PMS-RUST v0.1 JSONL event/audit format.

JSONL is the audit spine of the Evidence Spine Release.

---

# Summary

The runtime emits events as `KernelEvent` records.

Each event can be dumped as one JSON object per line:

```json
{"schema":"pms.events.v0","tick":0,"op":"Frame","msg":"push_frame id=0 kind=ctx"}
```

Format properties:

```text
one JSON object per line
schema field is emitted for current events
known schema is accepted
missing schema is accepted for backward compatibility
unknown schema is rejected
all JSON control characters are escaped
meta is optional
runtime keys are used for op
```

---

# Current Schema

Current schema ID:

```text
pms.events.v0
```

Minimal event:

```json
{"schema":"pms.events.v0","tick":0,"op":"Theta","msg":"advance dt=1"}
```

Fields:

```text
schema  string  current schema identifier
tick    number  runtime tick
op      string  runtime operator key
msg     string  event message
meta    object  optional structured metadata
```

---

# Runtime Operator Keys

The `op` field uses runtime keys.

Examples:

```text
Delta
Frame
Nabla
Lambda
Attractor
Omega
Theta
Phi
Chi
Sigma
Psi
```

Example:

```json
{"schema":"pms.events.v0","tick":0,"op":"Attractor","msg":"upsert frame_id=0 id=0 label=focus count=1 strength=1.000000"}
```

The event format intentionally does not rewrite runtime keys into theory keys.

For example:

```text
Frame is emitted as Frame, not Square.
Attractor is emitted as Attractor, not Alpha.
```

Model validation normalizes keys separately through `pms-model`.

See:

```text
pms-docs\KEY_WORLDS.md
```

---

# Event Messages

The `msg` field is a stable human-readable event message.

Examples:

```text
new_entity name=agent
push_frame id=0 kind=ctx
asymmetry frame_id=0 from=agent to=goal weight=1.000000 desc=asymmetry
advance dt=1
reframe frame_id=Some(0) from=old_context to=new_context
integrate frame_id=0 note=synthesized consumed=[]
commit id=0 frame_id=Some(0) isolation_id=None note=demo_done
```

Messages are useful for:

```text
human inspection
golden fixture comparison
loose advisory AI analysis
meta extraction when key=value tokens are present
```

---

# Optional Meta

Events may include optional structured metadata.

Example:

```json
{
  "schema": "pms.events.v0",
  "tick": 0,
  "op": "Delta",
  "msg": "fs_create path=/demo/a.txt id=2",
  "meta": {
    "kind": "fs_create",
    "kv": {
      "path": "/demo/a.txt",
      "id": "2"
    }
  }
}
```

Meta fields:

```text
kind  string  first token / event kind
kv    object  parsed key=value tokens
```

Meta is optional.

Events without meta remain compact:

```json
{"schema":"pms.events.v0","tick":1,"op":"Theta","msg":"advance dt=1"}
```

---

# Service Events

vFS service events use the same JSONL event format when dumped.

Important boundary:

```text
vFS service events are service-layer evidence.
They are not PMS program timeline opcodes.
```

Examples of service event messages:

```text
fs_mkdir path=/demo id=1
fs_create path=/demo/a.txt id=2
fs_write path=/demo/a.txt bytes=5
fs_read path=/demo/a.txt bytes=5
fs_ls path=/demo count=1
fs_delete path=/demo/a.txt id=2
```

Service events typically use:

```text
op: Delta
```

because they are host/service evidence events, not PMS script opcodes.

The important distinction is the message/meta kind:

```text
meta.kind = fs_create
meta.kind = fs_write
meta.kind = fs_delete
```

---

# Escaping Rules

All emitted JSON strings must be valid JSON.

The dumper escapes:

```text
quote             → \"
backslash         → \\
newline           → \n
carriage return   → \r
tab               → \t
control < U+0020  → \u00xx
```

This includes control characters such as:

```text
U+0008
U+001F
```

Acceptance requirement:

```text
Every emitted JSONL line parses as JSON.
```

---

# Loader Compatibility

The loader accepts:

```text
current schema pms.events.v0
missing schema for backward compatibility
```

The loader rejects:

```text
unknown schema values
malformed JSONL
invalid required event fields
```

This policy allows older golden fixtures without schema while protecting the current event format from silent drift.

---

# Golden Fixtures

Golden fixtures are used to verify deterministic behavior.

Rules:

```text
golden JSONL uses runtime op keys
golden JSONL should include schema for current generated output
older missing-schema fixtures may still load
golden diffs must not be accepted casually
```

Only update golden fixtures when one of these intentionally changes:

```text
kernel event semantics
event message format
JSONL schema
runtime operator keys
demo script contents
validation behavior
```

When updating golden fixtures, also check:

```text
pms-docs\KEY_WORLDS.md
pms-docs\DEMO.md
pms-docs\ACCEPTANCE_GATES.md
workspace tests
```

---

# Demo Trace Example

Demo script:

```text
pms-demos\d1_valid_trace.pms
```

Observed smoke output:

```text
OK. tick=1
[tick 0] Delta new_entity name=agent
[tick 0] Frame push_frame id=0 kind=ctx
[tick 0] Attractor upsert frame_id=0 id=0 label=focus count=1 strength=1.000000
[tick 0] Omega asymmetry frame_id=0 from=agent to=goal weight=1.000000 desc=asymmetry
[tick 1] Theta advance dt=1
[tick 1] Phi reframe frame_id=Some(0) from=old_context to=new_context
[tick 1] Sigma integrate frame_id=0 note=synthesized consumed=[]
[tick 1] Psi commit id=0 frame_id=Some(0) isolation_id=None note=demo_done
OK. dumped JSONL: demo-out\d1_valid_trace.jsonl
```

Expected JSONL properties:

```text
one event per line
schema pms.events.v0
runtime op keys
valid JSON
deterministic output for same script/model
```

---

# AI Analyze Input

`ai_analyze` can read JSONL traces.

Boundary:

```text
AI analyze is advisory only.
AI analyze does not execute opcodes.
AI analyze does not mutate kernel state.
AI analyze does not replace the program buffer.
```

This makes JSONL the bridge between deterministic runtime evidence and optional advisory analysis.

---

# Non-Claims

The event format does not claim:

```text
full OS audit format
PMS-CPU trace format
PMSL compiler IR format
distributed trace protocol
security audit log with permissions
forensic-grade tamper-proof log
```

It is the v0.1 deterministic runtime/service evidence format.

---

# v0.1 Acceptance

The event format is accepted for v0.1 when:

```text
all emitted JSONL parses as JSON
schema pms.events.v0 is emitted
missing schema remains loadable
unknown schema is rejected
control chars are escaped
meta exports when present
golden roundtrip tests pass
runtime keys remain stable
DEMO.md smoke output matches current behavior
```

Defined in:

```text
pms-docs\ACCEPTANCE_GATES.md
```

