# PMS-STACK Evidence Spine Demos

This document contains reproducible demos for the PMS-RUST / PMS-STACK Evidence Spine Release.

The checked-in demo scripts live in:

```text
pms-demos/
```

The demos show the bounded release claim:

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ pms-model-data\PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace/audit
→ vFS service layer
→ optional AI analyze
```

This is not a PMS-OS demo.

This is an executable PMS-STACK Evidence Spine demo.

---

# 0. Baseline Check

Run from the workspace root:

```bat
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

Expected:

```text
fmt check passes
workspace tests pass
clippy passes with -D warnings
```

Current release baseline:

```text
workspace tests: 157 passing
```

---

# 1. Deterministic Valid Trace

## Script

```text
pms-demos\d1_valid_trace.pms
```

Contents:

```text
entity agent
frame ctx
attractor focus
omega agent goal 1.0 asymmetry
theta 1
phi old_context new_context
integrate synthesized
psi demo_done
```

## Run

```bat
mkdir demo-out
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
```

## Expected

The command succeeds.

Observed smoke output:

```text
OK. tick=1
[tick 0] Delta new_entity name=agent
[tick 0] Frame push_frame id=0 kind=ctx
[tick 0] Attractor upsert frame_id=0 id=0 label=focus count=1 strength=1.000000
[tick 0] Omega asymmetry frame_id=0 from=agent to=goal weight=1.000000 desc=asymmetry
[tick 1] Theta advance dt=1
[tick 1] Phi reframe frame_id=Some(0) from=old_context to=new_context
[tick 1] Sigma integrate frame_id=0 note=synthesized consumed=[]
[tick 1] Psi commit id=0 frame_id=Some(0) isolation_id=None note=demo_done
OK. dumped JSONL: demo-out\d1_valid_trace.jsonl
```

Inspect output:

```bat
type demo-out\d1_valid_trace.jsonl
```

Expected JSONL properties:

```text
one JSON object per line
schema is pms.events.v0
ops use runtime keys
trace includes Delta, Frame, Attractor, Omega, Theta, Phi, Sigma, Psi
file parses as JSONL
```

This demonstrates:

```text
DSL script → builder → model validation → stateful validation → kernel → JSONL
```

---

# 2. Model Validation Failure

## Script

```text
pms-demos\d2_model_invalid_delta_omega.pms
```

Contents:

```text
entity agent
omega agent goal 1.0 invalid_without_alpha
```

## Run

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
```

## Expected

The command fails.

Observed expected error:

```text
Validation failed at index 1:
  previous: Delta
  next: Omega
  expected previous one of: [Alpha]
  transition: Delta -> Omega not allowed
```

This demonstrates:

```text
pms-model-data\PMS.yaml dependency_table is active
validation is not silently open-world
invalid adjacency is rejected before execution
```

---

# 3. Stateful Validation Failure

## Script

```text
pms-demos\d3_stateful_invalid_sigma_no_frame.pms
```

Contents:

```text
integrate no_active_frame
```

## Run

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d3_stateful_invalid_sigma_no_frame.pms --run
```

## Expected

The command fails.

Observed expected error:

```text
Validation v2 failed at index 0: Σ requires an active frame
```

This means:

```text
stateful validation rejects Sigma / integrate without an active frame
program is not executed after validation failure
```

---

This demonstrates:

```text
stateful kernel validation is separate from PMS.yaml adjacency validation
```

---

# 4. Script Mode Rejects fs_* Service Commands

## Script

```text
pms-demos\d4_script_rejects_fs.pms
```

Contents:

```text
entity agent
fs_write /demo/a.txt hello
frame ctx
```

## Run

```bat
cargo run -p pms-repl -- --file pms-demos\d4_script_rejects_fs.pms --run
```

## Expected

The command fails early.

Observed expected error:

```text
Script error on line 18: fs_* service commands are not supported in scripts.
  >> fs_write /demo/a.txt hello
```

This demonstrates:

```text
.pms script mode is program-timeline only
vFS host-calls are service-layer commands
fs_* commands do not enter the PMS program timeline
```

---

# 5. Interactive vFS Service Separation

## Start REPL

```bat
cargo run -p pms-repl
```

## Commands

```text
show
fs_mkdir /demo
fs_create /demo/a.txt
fs_write /demo/a.txt hello
fs_read /demo/a.txt
fs_ls /demo
fs_events
show
entity agent
frame ctx
show
run
show
exit
```

## Expected

Initial `show`:

```text
<empty>
```

`fs_read /demo/a.txt` prints the stored file content:

```text
hello
```

`fs_ls /demo` shows:

```text
a.txt
```

`fs_events` shows service events for the vFS calls.

The second `show`, after vFS calls but before PMS commands, is still:

```text
<empty>
```

After:

```text
entity agent
frame ctx
show
```

the program buffer contains PMS opcodes only:

```text
0: Delta ...
1: Frame ...
```

After:

```text
run
show
```

the buffer is empty again:

```text
<empty>
```

This demonstrates:

```text
vFS service state exists
vFS service events are separate
fs_* commands do not mutate the PMS program buffer
run drains the program buffer transactionally
```

---

# 6. Interactive vFS Delete

## Start REPL

```bat
cargo run -p pms-repl
```

## Commands

```text
fs_mkdir /tmp
fs_create /tmp/a.txt
fs_write /tmp/a.txt hello
fs_ls /tmp
fs_delete /tmp/a.txt
fs_ls /tmp
fs_delete /tmp
fs_events
exit
```

## Expected

Before deletion:

```text
fs_ls /tmp
```

shows:

```text
a.txt
```

After:

```text
fs_delete /tmp/a.txt
fs_ls /tmp
```

`a.txt` is gone.

`fs_events` includes service events for:

```text
fs_mkdir
fs_create
fs_write
fs_ls
fs_delete
```

This demonstrates:

```text
vFS supports create/write/list/delete
delete is service-only
delete does not create PMS program opcodes
```

---

# 7. Program Buffer Introspection

## Start REPL

```bat
cargo run -p pms-repl
```

## Commands

```text
show
entity agent
frame ctx
impulse agent 0.5 observed
integrate done
psi committed
show
show json
run
show
exit
```

## Expected

Initial `show`:

```text
<empty>
```

Before `run`, `show` lists buffered opcodes:

```text
0: Delta ...
1: Frame ...
2: Nabla ...
3: Sigma ...
4: Psi ...
```

`show json` prints a valid JSON array with opcode objects.

After `run`, `show` prints:

```text
<empty>
```

This demonstrates:

```text
the program buffer is inspectable
show does not drain the buffer
show json is machine-readable
run drains the buffer transactionally
```

---

# 8. AI Backend Readiness

Requires a local Ollama-compatible backend.

## Start REPL

```bat
cargo run -p pms-repl
```

## Command

```text
ai_ping
```

## Expected

If backend is available:

```text
OK. AI backend reachable.
```

If backend is unavailable:

```text
Error: ai ping failed: ...
```

This demonstrates:

```text
AI backend health can be checked explicitly
ai_ping does not send scenario or trace content
```

---

# 9. AI Compile Dry-Run and Show-JSON

Requires a local Ollama-compatible backend.

## Start REPL

```bat
cargo run -p pms-repl
```

## Commands

```text
entity keepme
show
ai_compile --dry-run --show-json Create a framed action and commit it
show
exit
```

## Expected

Before AI:

```text
0: Delta name="keepme"
```

The AI command prints:

```text
AI compile: N opcode(s)
{...canonical accepted compile JSON...}
OK. dry-run succeeded. Buffer unchanged.
```

Final `show` still contains the original buffer:

```text
0: Delta name="keepme"
```

This demonstrates:

```text
AI proposes
host parses and canonicalizes
host maps into a temporary builder
validation runs if enabled
dry-run does not replace the active buffer
show-json displays the canonical accepted compile envelope
```

---

# 10. AI Compile Accepted Path

Requires a local Ollama-compatible backend.

## Start REPL

```bat
cargo run -p pms-repl
```

## Commands

```text
clear
ai_compile --show-json Create a framed action and commit it
show
run
dump demo-out\d10_ai_compile.jsonl
exit
```

## Expected

The AI command prints:

```text
AI compile: N opcode(s)
{...canonical accepted compile JSON...}
OK. compiled program loaded into buffer. Use: run
```

`show` displays the accepted PMS program buffer.

`run` executes the kernel.

`dump` writes JSONL:

```bat
type demo-out\d10_ai_compile.jsonl
```

This demonstrates:

```text
AI output is a proposal
host gates decide whether it becomes a buffer
kernel execution remains deterministic after acceptance
JSONL audit still comes from the kernel
```

---

# 11. AI Analyze Is Advisory Only

Requires:

```text
demo-out\d1_valid_trace.jsonl
```

from Demo 1 and a local Ollama-compatible backend.

## Start REPL

```bat
cargo run -p pms-repl
```

## Command

```text
ai_analyze demo-out\d1_valid_trace.jsonl
```

## Expected

Output resembles:

```text
AI: ...
Findings:
  - ...
Tags: [...]
```

Important properties:

```text
ai_analyze does not execute opcodes
ai_analyze does not replace the program buffer
ai_analyze does not mutate kernel state
ai_analyze is advisory only
```

---

# Demo Coverage Matrix

| Demo | Gate | External AI required | Purpose |
|---|---:|---:|---|
| 1 | A/B/C/D | No | Valid deterministic trace + JSONL |
| 2 | B | No | Model validation failure |
| 3 | C | No | Stateful validation failure |
| 4 | E | No | Script rejects service commands |
| 5 | E | No | vFS service separation |
| 6 | E | No | vFS delete lifecycle |
| 7 | D/E | No | Buffer show/show json |
| 8 | F | Yes | AI backend readiness; optional manual smoke |
| 9 | F | Yes | AI dry-run + show-json; optional manual smoke |
| 10 | F | Yes | AI accepted compile path; optional manual smoke |
| 11 | F | Yes | AI advisory analyze; optional manual smoke |

---

# Release Demo Smoke

Minimum non-AI smoke before release:

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d3_stateful_invalid_sigma_no_frame.pms --run
cargo run -p pms-repl -- --file pms-demos\d4_script_rejects_fs.pms --run
```

Expected:

```text
first command succeeds
next three commands fail for the documented reasons
```

Observed non-AI smoke status:

```text
d1_valid_trace: PASS
d2_model_invalid_delta_omega: PASS as expected failure
d3_stateful_invalid_sigma_no_frame: PASS as expected failure
d4_script_rejects_fs: PASS as expected failure
```

---

Recommended AI smoke if backend is available:

```text
ai_ping
ai_compile --dry-run --show-json Create a framed action and commit it
ai_compile --show-json Create a framed action and commit it
ai_analyze demo-out\d1_valid_trace.jsonl
```

---

# What This Demonstrates

These demos support the release claim:

```text
PMS-Rust is an executable PMS-STACK evidence spine.
```

They demonstrate:

```text
PMS operator programs can be authored
programs can be inspected before execution
model validation is active
stateful validation is active
kernel execution is deterministic
trace output is auditable JSONL
vFS exists as a separate service layer
AI proposals are controlled by host gates
AI analysis is advisory only
```

---

# What This Does Not Claim

These demos do not claim:

```text
PMS-STACK OS is complete
PMS-CPU/ISA is implemented
PMSL compiler is implemented
AI output is trusted executable code
vFS is a full filesystem
Add-ons are runtime policies
PMS 1.3 migration is complete
```
