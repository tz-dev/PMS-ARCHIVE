# PMS-STACK Evidence Spine v0.1

PMS-RUST is a small, test-driven runtime/toolchain that demonstrates an executable PMS-STACK Evidence Spine.

It is a deterministic Δ–Ψ kernel plus REPL/script tooling, model validation, JSONL trace/audit output, a vFS service surface, and a controlled AI proposal bridge.

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ pms-model-data/PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace/audit
→ vFS service layer
→ optional AI analyze
→ golden tests + demos + docs
```

This release is **not** a full PMS-OS, PMS-CPU/ISA, PMSL compiler, or distributed PMS runtime.

AI output is never trusted executable code. AI may propose PMS opcode programs; host-side parsing, mapping, validation, and the kernel decide what can execute.

---

## What exists in v0.1

- `pms-kernel`
  - Executes PMS opcodes from Δ through Ψ.
  - Emits deterministic `KernelEvent`s.
  - Provides runtime guards and stateful validation.
  - Includes vFS state/service primitives used by the REPL service layer.

- `pms-model`
  - Loads `pms-model-data/PMS.yaml`.
  - Reads active adjacency/dependency rules.
  - Normalizes operator names across symbols, theory names, runtime aliases, and case variants.

- `pms-ir`
  - Provides `PmsBuilder`.
  - Builds small opcode programs for kernel execution.
  - Keeps builder-level conveniences such as idempotent `entity(name)`.

- `pms-repl`
  - Interactive REPL.
  - `.pms` script runner.
  - Program buffer inspection via `show` and `show json`.
  - JSONL dump/load support.
  - vFS host/service commands.
  - AI commands via `pms-ai-bridge`.

- `pms-ai-bridge`
  - Strict JSON envelope protocol for local LLM integration.
  - Supports advisory trace analysis and scenario-to-opcode proposals.
  - Enforces task/result shape and opcode whitelists.
  - Keeps the host/kernel as the authority.

---

## Non-goals for v0.1

This repository does not claim:

```text
PMS-STACK OS is complete.
PMS-CPU/ISA is implemented.
PMSL is implemented.
Distributed PMS is implemented.
AI output is trusted executable code.
Add-ons are runtime/validation/policy engines.
PMS 1.3 migration is complete.
```

Release+ work is tracked separately in the roadmap.

---

## Quick start

Run from the workspace root.

### Check the workspace

```bat
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

Expected current baseline:

```text
157 workspace tests passing
fmt check passing
clippy -D warnings passing
```

### Start the REPL

```bat
cargo run -p pms-repl
```

Example REPL session:

```text
entity agent
frame ctx
attractor focus
omega agent goal 1.0 asymmetry
theta 1
phi old_context new_context
integrate synthesized
psi demo_done
show
run
dump demo-out\trace.jsonl
exit
```

### Run a script

```bat
cargo run -p pms-repl -- --file pms-demos\d1_valid_trace.pms --run
```

### Run with model + stateful validation

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run
```

### Dump JSONL

```bat
mkdir demo-out
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
```

### Demonstrate validation failure

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
```

Expected failure:

```text
Validation failed at index 1:
  previous: Delta
  next: Omega
  expected previous one of: [Alpha]
  transition: Delta -> Omega not allowed
```

---

## Demo Pack

Checked-in demo scripts live in:

```text
pms-demos/
```

Main demo documentation:

```text
pms-docs/DEMO.md
```

Minimum non-AI smoke:

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d3_stateful_invalid_sigma_no_frame.pms --run
cargo run -p pms-repl -- --file pms-demos\d4_script_rejects_fs.pms --run
```

Expected:

```text
first command succeeds
next three commands fail for the documented reasons
```

---

## vFS service layer

The REPL exposes `fs_*` host/service commands.

Examples:

```text
fs_mkdir /demo
fs_create /demo/a.txt
fs_write /demo/a.txt hello
fs_read /demo/a.txt
fs_ls /demo
fs_delete /demo/a.txt
fs_events
fs_clear_events
```

Important boundary:

```text
fs_* commands are service calls.
fs_* commands do not enter the PMS program buffer.
fs_* commands are not supported in .pms scripts.
```

---

## AI bridge

AI support is optional and local-backend oriented.

Default backend:

```text
http://localhost:11434/api/chat
```

Useful REPL commands:

```text
ai_ping
ai_compile --dry-run --show-json Create a framed action and commit it
ai_compile --show-json Create a framed action and commit it
ai_analyze demo-out\d1_valid_trace.jsonl
```

Trust model:

```text
AI proposes.
Host parses, canonicalizes, maps, and validates.
Kernel executes only accepted PMS opcode programs.
```

Details:

```text
pms-docs/AI_BRIDGE.md
```

---

## Documentation

Core release docs:

```text
pms-docs/ARCHITECTURE.md
pms-docs/KEY_WORLDS.md
pms-docs/EVENT_FORMAT.md
pms-docs/AI_BRIDGE.md
pms-docs/ACCEPTANCE_GATES.md
pms-docs/DEMO.md
pms-docs/ROADMAP.md
pms-docs/PMS_1_1_TO_1_3_NOTES.md
```

Acceptance gates:

```text
pms-docs/ACCEPTANCE_GATES.md
```

---

## Platform status

v0.1 is Windows-first and CPU-only.

The core path is deterministic and does not require Linux namespaces, GPU backends, distributed runtimes, or OS-level process isolation.

Linux process/namespace mappings, GPU backends, PMS-CPU/ISA, PMSL, distributed PMS, and richer vFS features are Release+ work.

---

## License

See `LICENSE`.