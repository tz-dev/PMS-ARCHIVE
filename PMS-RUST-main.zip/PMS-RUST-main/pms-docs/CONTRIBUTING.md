# Contributing (v0)

## Principles

- Determinism over convenience.
- Fail-closed host enforcement for AI integration.
- Program timeline vs host/service calls must remain separate.

## Expectations

- New kernel behavior must include tests.
- If you change event formats, update `pms-docs/EVENT_FORMAT.md` and add/adjust tests.
- If you touch operator keys/aliases, update `pms-docs/KEY_WORLDS.md`.
