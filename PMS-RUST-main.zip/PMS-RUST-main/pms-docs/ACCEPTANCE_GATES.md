# PMS-STACK Evidence Spine Acceptance Gates

This document defines the acceptance gates for the PMS-RUST / PMS-STACK Evidence Spine Release.

The release target is:

```text
PMS-STACK Evidence Spine Release
```

This is not a full PMS-OS, PMS-CPU, PMSL compiler, or distributed PMS runtime.

It is a tested, documented, deterministic computational spine:

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace/audit
→ vFS service layer
→ optional AI analyze
→ golden tests + demo scripts + docs
```

---

## Release Claim

Accepted release statement:

```text
PMS-Rust is a tested, documented, deterministic PMS-STACK evidence spine:
a runtime/DSL/REPL/vFS/validation/JSONL/AI-bridge implementation that demonstrates
the Δ–Ψ operator model can be executed, validated, traced, and inspected
as a bounded computational spine, without claiming to implement the full PMS-STACK OS/CPU/PMSL architecture yet.
```

Explicit non-claims:

```text
PMS-STACK OS is complete.
PMS-CPU/ISA is implemented.
PMSL is implemented.
AI output is trusted executable code.
PMS.yaml by itself implements praxis.
Distributed PMS is implemented.
Add-ons are kernel execution regimes.
```

---

# Gate A — Build / Test / Lint

## Requirement

The workspace must build and test reproducibly.

Required commands:

```bat
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

## Acceptance Criteria

```text
fmt check passes
workspace tests pass
clippy passes with -D warnings
no known compile blocker remains
no unsafe code is introduced
```

## Current Evidence

Current green baseline:

```text
workspace tests: 157 passing
cargo fmt --all -- --check: passing
cargo clippy --workspace --all-targets -- -D warnings: passing
```

## Status

```text
Gate A: PASS
```

---

# Gate B — Model Validation

## Requirement

`PMS.yaml` must provide active machine-readable model validation.

The project must not silently fall back to open-world validation because of schema mismatch.

## Acceptance Criteria

```text
PMS.yaml contains a top-level dependency_table
pms-model loads a non-empty dependency table from PMS.yaml
runtime/theory/symbol key normalization is tested
invalid adjacency is rejected
valid PMS sequences pass
validation errors show got/expected predecessor information
```

## Required Evidence

Tests must cover:

```text
load real PMS.yaml with non-empty dependency table
normalize symbol keys, theory keys, and runtime aliases
reject unknown operator names
accept runtime aliases such as Frame → Square and Attractor → Alpha
reject invalid adjacency such as Delta → Omega
accept valid adjacency such as Alpha → Omega
```

## Status

```text
Gate B: PASS
```

---

# Gate C — Stateful Kernel Validation

## Requirement

The kernel must validate stateful PMS runtime constraints before execution when validation is enabled.

This gate is separate from model adjacency validation.

## Acceptance Criteria

```text
sealed frame misuse is rejected
sealed isolation misuse is rejected
unbalanced ChiExit is rejected
Sigma without active frame is rejected
Omega without active frame is rejected
Attractor without active frame is rejected
manual ChiEnter/ChiExit behavior is tested
FrameExit is not implemented in v0.1
frames remain push-only by design
AI-generated ChiExit is not required for v0.1
```

## Required Evidence

Tests must cover:

```text
Omega requires frame
Nabla requires frame
Sigma requires frame
Attractor requires frame
Omega in sealed frame is rejected
Attractor in sealed frame is rejected
Sigma in sealed frame remains allowed by v0 decision
ChiExit without enter is rejected
ChiExit from sealed isolation is allowed
ChiEnter in sealed isolation is rejected
new frame after sealed frame is allowed
```

## Status

```text
Gate C: PASS
```

---

# Gate D — JSONL Trace / Audit Format

## Requirement

Kernel and service traces must be emitted as stable, valid JSONL.

JSONL is the audit spine of the release.

## Acceptance Criteria

```text
all emitted JSONL lines parse as JSON
schema field is emitted for current events
known schema is accepted
missing schema is accepted for backward compatibility
unknown schema is rejected clearly
all JSON control chars are escaped
optional meta is exported when present
events without meta remain compact
golden roundtrip tests pass
runtime event keys remain stable
```

## Current Schema

```json
{"schema":"pms.events.v0","tick":0,"op":"Frame","msg":"..."}
```

Optional meta:

```json
{
  "schema": "pms.events.v0",
  "tick": 0,
  "op": "Delta",
  "msg": "fs_create path=/x id=1",
  "meta": {
    "kind": "fs_create",
    "kv": {
      "path": "/x",
      "id": "1"
    }
  }
}
```

## Required Evidence

Tests must cover:

```text
dump one event per JSONL line
escape newline, tab, quote, backslash
escape all control characters below U+0020
load known schema
load missing schema
reject unknown schema
roundtrip golden fixture JSONL
export meta when present
```

## Status

```text
Gate D: PASS
```

---

# Gate E — vFS Service Layer

## Requirement

The vFS layer must remain a service surface, separate from the PMS program timeline.

`fs_*` commands must not become PMS opcodes in the active program buffer.

## Acceptance Criteria

```text
fs_create works
fs_mkdir works
fs_write works
fs_read works
fs_ls works
fs_state works
fs_events works
fs_clear_events works
fs_dump works
fs_delete works
fs_delete protects root
fs_delete rejects missing paths
fs_delete rejects non-empty directories
fs_* service events do not enter the kernel program timeline
fs_* commands do not affect show/show json program buffer
fs_* commands in script mode fail early with line number
fs_move/fs_copy are not required for v0.1
```

## Required Evidence

Tests must cover:

```text
root exists on KernelState::new
create file links parent and child
write/read roundtrip
list dir shows children
delete file ok
delete empty dir ok
delete missing fails
delete root fails
delete non-empty dir fails
vFS events are emitted into service log
fs_clear_events clears service log but not vFS state
REPL fs_* commands are service-only
script fs_* rejection includes line number and original line
```

## Status

```text
Gate E: PASS
```

---

# Gate F — AI Bridge

## Requirement

AI integration must be controlled, inspectable, and fail-closed.

AI output is a proposal only.

The host, validators, and kernel remain authoritative.

## Acceptance Criteria

```text
ai_ping checks backend readiness
compile_scenario is fail-closed
analyze_trace rejects compile-shaped result
analyze_trace HTTP errors are truncated
dry-run does not replace buffer
show-json displays canonical accepted compile envelope
host validation gates all compiled opcodes
mapping failure does not replace buffer
validation failure does not replace buffer
warnings are preserved and displayed
Chi compile support is enter-only in v0.1
AI-generated ChiExit is Release+
FrameExit is not part of v0.1
AI output is never trusted executable code
AI_BRIDGE.md documents the trust boundary
```

## Required Evidence

Tests must cover:

```text
ping URL maps /api/chat endpoint to /api/tags
compile rejects task mismatch
compile rejects unknown op
compile rejects op not allowed
compile rejects params not object
compile rejects empty opcodes
compile canonicalizes allowed ops
analyze rejects task mismatch
analyze rejects compile-shaped result
analyze ok=false without error receives deterministic error
ai_compile mapping failure keeps old buffer
ai_compile dry-run keeps old buffer
ai_compile show-json emits valid JSON
ai_compile flag parser accepts --dry-run and --show-json in any order
trace chain appears on bridge/mapping failures
```

## Status

```text
Gate F: PASS
```

---

# Gate G — Demo Evidence

## Requirement

The release must be demonstrable in a few minutes.

The demos must show that the project is executable, validated, traceable, service-separated, and AI-gated.

## Required Demos

```text
Demo 1: Deterministic valid trace
Demo 2: Model validation failure
Demo 3: Stateful validation failure
Demo 4: Script mode rejects fs_* service commands
Demo 5: Interactive vFS service separation
Demo 6: Interactive vFS delete
Demo 7: Program buffer introspection
Demo 8: AI backend readiness
Demo 9: AI compile dry-run + show-json
Demo 10: AI compile accepted path
Demo 11: AI analyze advisory path
```

## Acceptance Criteria

```text
demo commands are documented in DEMO.md
demo commands are copy/paste friendly
demos avoid claiming full OS/PMSL/PMS-CPU completion
demos show the evidence spine pipeline
at least non-AI demos run without external services
AI demos are marked as requiring local Ollama-compatible backend
```

## Current Evidence

Checked-in demo scripts:

```text
pms-demos\d1_valid_trace.pms
pms-demos\d2_model_invalid_delta_omega.pms
pms-demos\d3_stateful_invalid_sigma_no_frame.pms
pms-demos\d4_script_rejects_fs.pms
```

Verified non-AI smoke:

```text
d1_valid_trace: PASS
d2_model_invalid_delta_omega: PASS as expected failure
d3_stateful_invalid_sigma_no_frame: PASS as expected failure
d4_script_rejects_fs: PASS as expected failure
```

AI demos are documented as optional manual smoke requiring a local Ollama-compatible backend.

## Status

Gate G: PASS

---

---

# Gate H — Documentation

## Requirement

Documentation must describe the exact release scope and avoid inflated claims.

## Acceptance Criteria

Required docs:

```text
README.md
pms-docs/ARCHITECTURE.md
pms-docs/KEY_WORLDS.md
pms-docs/EVENT_FORMAT.md
pms-docs/AI_BRIDGE.md
pms-docs/ACCEPTANCE_GATES.md
pms-docs/DEMO.md
pms-docs/ROADMAP.md
```

Required documentation points:

```text
README states exact scope
README includes quickstart
ARCHITECTURE describes Evidence Spine layers
ARCHITECTURE states trust boundary
KEY_WORLDS explains runtime/theory/symbol keys
EVENT_FORMAT documents JSONL schema and meta
AI_BRIDGE documents threat model and host gates
AI_BRIDGE documents Chi enter-only compile limitation
ACCEPTANCE_GATES defines release gates
DEMO contains runnable demos
ROADMAP separates v0.1 from Release+
PMS 1.1 vs PMS 1.3 status is documented in ROADMAP.md
add-ons are documented as advisory only
no doc claims full PMS-OS completion
no doc claims trusted AI execution
```

## Status

```text
Gate H: PASS
```

---

# Release+ Items

The following are explicitly not required for the Evidence Spine v0.1 release:

```text
full PMS-OS kernel
PMS-CPU / ISA simulator
PMSL compiler
distributed PMS runtime
FrameExit / frame pop semantics
AI-generated ChiExit
fs_move
fs_copy
fs_write_b64
fs_exists
fs_stat
fs_tree
file-based AI backend
required_literals host enforcement
addon analyzer integration
PMS 1.3 semantic migration
role/capability/power security layer
full vFS journaling/permissions
```

These may be implemented later without changing the v0.1 release claim.

---

# Final Release Checklist

Before tagging:

```bat
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

Required manual checks:

```text
Gate A PASS
Gate B PASS
Gate C PASS
Gate D PASS
Gate E PASS
Gate F PASS
Gate G PASS
Gate H PASS
README scope is accurate
AI_BRIDGE trust boundary is accurate
DEMO commands are current
ROADMAP separates v0.1 from Release+ and documents PMS 1.1 → PMS 1.3 alignment
no full-OS / PMSL / PMS-CPU claim appears in release docs
```

Recommended tag:

```bat
git tag pms-spine-v0.1
```

---

# Current Gate Summary

```text
Gate A — Build/Test/Clippy:       PASS
Gate B — Model Validation:        PASS
Gate C — Stateful Validation:     PASS
Gate D — JSONL Trace/Audit:       PASS
Gate E — vFS Service Layer:       PASS
Gate F — AI Bridge:               PASS
Gate G — Demo Evidence:           PASS
Gate H — Documentation:           PASS
```

The project is release-complete when all gates are PASS.