@echo off
cls
cargo run -p pms-repl -- --file pms-docs/golden/scripts/g1_non_event.pms --run --dump pms-docs/golden/fixtures/g1_non_event.events.jsonl
cargo run -p pms-repl -- --file pms-docs/golden/scripts/g2_integrate_consumes.pms --run --dump pms-docs/golden/fixtures/g2_integrate_consumes.events.jsonl
cargo run -p pms-repl -- --file pms-docs/golden/scripts/g3_commit_seals_frame.pms --run --dump pms-docs/golden/fixtures/g3_commit_seals_frame.events.jsonl
cargo run -p pms-repl -- --file pms-docs/golden/scripts/g4_commit_seals_isolation.pms --run --dump pms-docs/golden/fixtures/g4_commit_seals_isolation.events.jsonl
cargo run -p pms-repl -- --file pms-docs/golden/scripts/g5_min_timeline.pms --run --dump pms-docs/golden/fixtures/g5_min_timeline.events.jsonl  
