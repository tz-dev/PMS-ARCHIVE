// PMS-REPL v0
//
// Purpose:
// - Interactive REPL + script runner for building PMS-IR programs and executing them in the kernel.
// - Hosts "service commands" (vFS host-calls) that are NOT part of the program timeline.
// - Provides AI-assisted compile/analyze entry points via pms-ai-bridge.
//
// v0 Constraints / Guarantees:
// - Program timeline is only produced via DSL -> PmsBuilder (or AI opcode mapping -> PmsBuilder).
// - Service commands (fs_*) mutate only the service state + service log, never the program buffer.
// - ai_compile is fail-closed: unknown ops / invalid params / mapping errors do NOT alter the existing buffer.
// - When validation is ON: ai_compile validates the compiled program (v1 adjacency + v2 stateful) BEFORE replacing the buffer.
//
// Debugging:
// - PMS_TRACE=1 enables minimal stage tracing for ai_compile / mapping / validation (stderr).

use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};

use pms_ir::PmsBuilder;
use pms_kernel::{Kernel, KernelEvent, KernelEventMeta, KernelState, OpCode, OpParams};
use pms_model::PmsModel;

// ------------------------------------------------------------
// PMS-REPL v0 — Contract + Sharp Edges (documented behavior)
// ------------------------------------------------------------
//
// This file is the reference implementation of the REPL contract.
// It is intentionally conservative and deterministic.
//
// Key invariants (v0):
// - Program timeline is produced only via DSL -> PmsBuilder (or AI opcode mapping -> PmsBuilder).
// - Service commands (fs_*) mutate only service state + service log; never the program buffer.
// - `run` is transactional: it drains the program buffer via take_program().
// - Script mode is timeline-only: fs_* commands are not supported in scripts.
// - ai_compile is fail-closed: mapping/validation failures DO NOT alter an existing buffer.
// - If validation is ON, ai_compile validates (v1 adjacency + v2 stateful) BEFORE replacing the buffer.
//
// Operator key worlds:
// - Kernel events log runtime keys (Operator::model_key()).
// - PMS.yaml adjacency rules operate on theory keys; tooling must normalize via pms-model.
//   See pms-docs/KEY_WORLDS.md.
//
// See also:
// - pms-docs/ARCHITECTURE.md
// - pms-docs/AI_BRIDGE.md
// - pms-docs/EVENT_FORMAT.md

// ------------------------------------------------------------
// Minimal tracing (v0) — enabled via PMS_TRACE=1
// ------------------------------------------------------------
//
// Design goal:
// - Keep tracing opt-in and non-invasive.
// - Never affect program semantics, state, or output formats.
// - Use stderr so the REPL stdout remains scriptable.
macro_rules! trace {
    ($($t:tt)*) => {
        if std::env::var("PMS_TRACE").ok().as_deref() == Some("1") {
            eprintln!($($t)*);
        }
    }
}

// ------------------------------------------------------------
// Heavy AI debug (v0) — enabled via PMS_AI_DEBUG=1
// ------------------------------------------------------------
//
// Design goal:
// - Allow inspecting assistant content and intermediate payloads,
//   but only when explicitly enabled.
// - Uses stderr so it won't pollute JSONL dumps or stdout pipelines.
macro_rules! ai_debug {
    ($($t:tt)*) => {
        if std::env::var("PMS_AI_DEBUG").ok().as_deref() == Some("1") {
            eprintln!($($t)*);
        }
    }
}

// ------------------------------------------------------------
// Trunc helper (for debug output only)
// ------------------------------------------------------------
//
// v0 invariant:
// - Never truncate for "real" output. Truncation is ONLY for debug printing.
// - Char-based truncation avoids cutting in the middle of UTF-8 codepoints.
fn trunc(s: &str, max: usize) -> String {
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if i >= max {
            break;
        }
        out.push(ch);
    }
    out
}

fn clear_screen_if_interactive() -> Result<(), String> {
    if io::stdout().is_terminal() {
        print!("\x1B[2J\x1B[H");
        io::stdout().flush().map_err(|e| e.to_string())?;
    }

    Ok(())
}

fn print_startup_screen(flag_validate: bool, model_path: Option<&str>) {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║                 PMS-STACK Evidence Spine                     ║");
    println!("║                         REPL v0.1                            ║");
    println!("╠══════════════════════════════════════════════════════════════╣");
    println!("║             Δ  ∇  □  Λ  Α  Ω  Θ  Φ  Χ  Σ  Ψ                  ║");
    println!("║                                                              ║");
    println!("║  deterministic kernel · JSONL audit · vFS · AI proposal gate ║");
    println!("╚══════════════════════════════════════════════════════════════╝");
    println!();
    println!("Type 'help' for commands.");
    println!("Validation: {}", if flag_validate { "ON" } else { "OFF" });
    println!("Model: {}", model_path.unwrap_or("<none>"));
    println!();
}

fn print_help() {
    // CLI help is intentionally plain stdout: users can pipe/grep it.
    // The help text documents the *contract* for DSL parsing and service commands.
    println!("PMS-REPL v0");
    println!();
    println!("Usage:");
    println!("  pms-repl                               Interactive REPL");
    println!("  pms-repl --run                         Read stdin until EOF, then run");
    println!("  pms-repl --file <path> --run           Load a script file and run");
    println!(
        "  pms-repl --model <PMS.yaml> --validate Enable validation (model + stateful) before run"
    );
    println!();
    println!("Options:");
    println!("  --model <path>                         Load PMS model (YAML) for validation");
    println!(
        "  --validate                             Validate program (model adjacency + stateful constraints) before executing"
    );
    println!("  --file <path>                          Load script file");
    println!("  --run                                  Execute after loading/reading");
    println!("  --help / -h                            Show this help");
    println!("  --dump <path>                          After run, write events as JSONL to <path>");
    println!(
        "  --dump-fs <path>                       Dump vFS service events as JSONL to <path> (on exit)"
    );
    println!();
    println!("Commands (interactive):");
    println!("  help                                   Show this help");
    println!("  clear                                  Clear current program buffer");
    println!("  show                                   Show current program buffer");
    println!("  show json                              Show current program buffer as JSON");
    println!("  run                                    Validate (optional) + run buffered program");
    println!("  state                                  Show last kernel state (tick + events)");
    println!("  quit / exit                            Exit REPL");
    println!("  status                                 Show validation/model status");
    println!("  model <path...>                        Load PMS model (YAML) during session");
    println!("  validate on|off                        Toggle validation during session");
    println!("  dump <path>                            Dump last run events as JSONL to <path>");
    println!("  ai_ping                                Check AI backend readiness");
    println!(
        "  ai_analyze last                        Analyze last run KernelEvents via Ollama (JSON-only)"
    );
    println!(
        "  ai_analyze <path.jsonl>                Analyze events loaded from JSONL (dump format)"
    );
    println!(
        "  ai_compile <free text...>              Compile scenario via Ollama into a new program buffer (validated)"
    );
    println!(
        "  ai_compile --dry-run <free text...>    Compile + validate but do not replace the buffer"
    );
    println!("  ai_compile --show-json <free text...>  Print canonical accepted compile JSON");
    println!(
        "  ai_compile --dry-run --show-json <...> Preview compile JSON without replacing the buffer"
    );
    println!();
    println!("DSL lines (v0):");
    println!("  entity <name>                          Δ new entity");
    println!(
        "  frame <kind>                           □ new frame (always allowed; new frames start unsealed)"
    );
    println!("  square <kind>                          □ alias of frame");
    println!("  theta [dt]                             Θ advance time (default dt=1)");
    println!(
        "  omega <from> <to> <weight> <desc...>   Ω asymmetry (requires active frame; forbidden if current frame is sealed)"
    );
    println!("  impulse <entity> <intensity> <desc...> ∇ impulse (desc can contain spaces)");
    println!(
        "  integrate <note...>                    Σ integrate (requires active frame; allowed even if frame is sealed)"
    );
    println!("  expect <horizon> <desc...>             Λ expectation (desc can contain spaces)");
    println!(
        "  attractor <label>                      Α attractor (requires active frame; forbidden if current frame is sealed)"
    );
    println!(
        "  chi_enter <label>                      Χ enter isolation (forbidden if current isolation is sealed)"
    );
    println!("  chi <label>                            Χ enter isolation (alias of chi_enter)");
    println!(
        "  chi_exit                               Χ exit isolation (LIFO; allowed even if isolation is sealed)"
    );
    println!("  phi <from> <to>                        Φ reframe");
    println!("  psi <note...>                          Ψ commit + seal (note can contain spaces)");
    println!();
    println!("Service commands (vFS host-calls, not part of program timeline):");
    println!("  fs_create <path>                       create empty file at <path>");
    println!("  fs_mkdir <path>                        create directory at <path> (optional v0)");
    println!("  fs_write <path> <data_no_spaces>       write bytes (utf8) to file");
    println!("  fs_read <path>                         read bytes (utf8) from file");
    println!("  fs_delete <path>                       delete file or empty directory");
    println!("  fs_ls <path>                           list directory children (sorted)");
    println!("  fs_state                               show vFS node counts/root id");
    println!("  fs_events                              print vFS service event log");
    println!("  fs_clear_events                        clear vFS service event log");
    println!("  fs_dump <path>                         Dump vFS service events as JSONL to <path>");
    println!();
    println!("Notes:");
    println!(
        "  After Ψ: Ω and Α are forbidden in the sealed frame; Χ enter is forbidden in the sealed isolation."
    );
    println!("  Starting a new frame after Ψ is allowed; the new frame starts unsealed.");
    println!("  v0: frames are push-only (no frame exit); frame pop/exit is deferred.");
    println!();
}

/// Print kernel events in a human-readable REPL format.
///
/// Important:
/// - This is *not* the stable machine format (JSONL dump is).
/// - We keep it simple: one line per event, including tick, op, and msg.
fn print_events(events: &[KernelEvent]) {
    for e in events {
        println!("[tick {}] {:?} {}", e.tick, e.op, e.msg);
    }
}

/// JSON string escaping for JSONL dump output.
///
/// v0.1 constraint:
/// - The dump format is intentionally tiny and dependency-free.
/// - JSON allows UTF-8 directly, so non-ASCII characters are preserved.
/// - All JSON-forbidden control characters `< 0x20` are escaped.
///
/// Escaping policy:
/// - Common escapes use their short forms: `\n`, `\r`, `\t`, `\\`, `\"`.
/// - Other control chars are emitted as `\u00xx`.
fn json_escape(s: &str) -> String {
    use std::fmt::Write as _;

    let mut out = String::with_capacity(s.len() + 8);
    for ch in s.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c.is_control() => {
                write!(&mut out, "\\u{:04x}", c as u32).expect("writing to String should not fail");
            }
            _ => out.push(ch),
        }
    }
    out
}

/// Stable JSONL schema identifier for PMS event dumps.
///
/// Loader policy:
/// - Missing schema is accepted for backward compatibility.
/// - This exact schema is accepted.
/// - Unknown schema values fail closed.
const EVENT_SCHEMA: &str = "pms.events.v0";

/// Encode KernelEventMeta as a tiny JSON object.
///
/// Output shape:
/// {"kind":"...","kv":{"k":"v",...}}
///
/// Notes:
/// - BTreeMap order from KernelEventMeta::kv gives deterministic key order.
/// - Keys and values are escaped with the same JSON string escaper as msg.
/// - This helper intentionally avoids adding serde derives to pms-kernel.
fn json_event_meta(meta: &KernelEventMeta) -> String {
    let mut out = String::from("{\"kind\":\"");
    out.push_str(&json_escape(&meta.kind));
    out.push_str("\",\"kv\":{");

    for (i, (k, v)) in meta.kv.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }

        out.push('"');
        out.push_str(&json_escape(k));
        out.push_str("\":\"");
        out.push_str(&json_escape(v));
        out.push('"');
    }

    out.push_str("}}");
    out
}

/// Dump KernelEvents as JSONL.
///
/// v0.1 dump schema (one JSON object per line):
/// {"schema":"pms.events.v0","tick":<u64>,"op":"<runtime_key>","msg":"<escaped>","meta":{...}}
///
/// `meta` is optional and emitted only when KernelEvent.meta is Some(...).
///
/// Stability contract:
/// - "op" uses Kernel's model_key() (runtime key string) so tooling can normalize reliably.
/// - "msg" is the stable kernel message string; we only JSON-escape it.
/// - Meta is currently not dumped; load side keeps forward-compat for future meta.
///
/// Fail-closed:
/// - Any file create/write error returns Err(String) and does not partially hide it.
/// - Partial writes can still happen if OS fails mid-stream; caller can delete and retry if desired.
///
/// v0.1:
/// - Includes `"meta":{...}` only when present (backward compatible).
fn dump_events_jsonl(path: &str, events: &[KernelEvent]) -> Result<(), String> {
    use std::path::Path;

    // v0.1: ensure parent directories exist so --dump is reliable
    if let Some(parent) = Path::new(path).parent()
        && !parent.as_os_str().is_empty()
    {
        fs::create_dir_all(parent).map_err(|e| {
            format!(
                "dump_events_jsonl: failed to create parent dir {}: {}",
                parent.display(),
                e
            )
        })?;
    }

    let mut f =
        fs::File::create(path).map_err(|e| format!("dump: cannot create {}: {}", path, e))?;

    for e in events {
        // Kernel Operator already defines canonical model keys used in the PMS model.
        let op = e.op.model_key();
        let msg = json_escape(&e.msg);

        let line = match e.meta.as_ref() {
            Some(meta) => format!(
                "{{\"schema\":\"{}\",\"tick\":{},\"op\":\"{}\",\"msg\":\"{}\",\"meta\":{}}}\n",
                EVENT_SCHEMA,
                e.tick,
                op,
                msg,
                json_event_meta(meta)
            ),
            None => format!(
                "{{\"schema\":\"{}\",\"tick\":{},\"op\":\"{}\",\"msg\":\"{}\"}}\n",
                EVENT_SCHEMA, e.tick, op, msg
            ),
        };

        f.write_all(line.as_bytes())
            .map_err(|e| format!("dump: write failed {}: {}", path, e))?;
    }

    Ok(())
}

/// Load events from JSONL produced by dump_events_jsonl.
///
/// Input contract:
/// - Each non-empty line must be valid JSON.
/// - Required keys: tick (u64), op (string), msg (string).
/// - Optional key: schema (string) is accepted if missing or equal to EVENT_SCHEMA.
/// - Optional key: meta (object) is accepted if present (forward-compatible).
///
/// Output type:
/// - Uses pms_ai_bridge::KernelEventLite, the minimal "AI-safe" event view.
///
/// Fail-closed:
/// - Any malformed line returns Err with line number for debugging.
/// - The loader does not attempt partial recovery: if a file is corrupted, fix it or re-dump.
fn load_events_jsonl(path: &str) -> Result<Vec<pms_ai_bridge::KernelEventLite>, String> {
    let raw =
        fs::read_to_string(path).map_err(|e| format!("ai_analyze: read {} failed: {}", path, e))?;
    let mut out = Vec::new();

    for (idx, line) in raw.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }

        let v: serde_json::Value = serde_json::from_str(line)
            .map_err(|e| format!("ai_analyze: invalid json on line {}: {}", idx + 1, e))?;

        if let Some(schema) = v.get("schema") {
            let schema = schema
                .as_str()
                .ok_or_else(|| format!("ai_analyze: invalid schema on line {}", idx + 1))?;

            if schema != EVENT_SCHEMA {
                return Err(format!(
                    "ai_analyze: unsupported schema '{}' on line {}",
                    schema,
                    idx + 1
                ));
            }
        }

        let tick = v
            .get("tick")
            .and_then(|x| x.as_u64())
            .ok_or_else(|| format!("ai_analyze: missing tick on line {}", idx + 1))?;

        let op = v
            .get("op")
            .and_then(|x| x.as_str())
            .ok_or_else(|| format!("ai_analyze: missing op on line {}", idx + 1))?
            .to_string();

        let msg = v
            .get("msg")
            .and_then(|x| x.as_str())
            .ok_or_else(|| format!("ai_analyze: missing msg on line {}", idx + 1))?
            .to_string();

        // meta is optional:
        // - current dump does not include it,
        // - but we accept it to remain compatible if you later dump meta.
        let meta = match v.get("meta") {
            None => None,
            Some(m) => serde_json::from_value(m.clone()).ok(),
        };

        out.push(pms_ai_bridge::KernelEventLite {
            tick,
            op,
            msg,
            meta,
        });
    }

    Ok(out)
}

/// Join the remaining whitespace-separated tokens into a single string.
///
/// This is used for DSL commands where the tail is "free text" (desc/note),
/// e.g. omega/impulse/integrate/expect/psi.
///
/// v0 behavior:
/// - Preserves token boundaries by joining with a single space.
/// - Does not attempt quoting; if you need quoting later, extend the parser.
fn rest_joined(parts: &mut std::str::SplitWhitespace<'_>) -> String {
    parts.collect::<Vec<_>>().join(" ")
}

/// Apply a single DSL line to the program builder.
///
/// Safety posture:
/// - This function is "pure" with respect to the REPL outside the builder:
///   it does not run the kernel, does not touch files, does not mutate service state.
/// - It is fail-closed: invalid syntax returns Err and does not partially apply an opcode
///   (except for already-emitted opcodes in the builder if you extend it—currently each command
///   emits at most one opcode and only after all required args are validated).
///
/// Parsing posture:
/// - Whitespace tokenization only.
/// - Lines starting with '#' are comments.
/// - Commands that accept trailing free text use rest_joined().
fn apply_line(builder: &mut PmsBuilder, line: &str) -> Result<(), String> {
    let line = line.trim();
    if line.is_empty() || line.starts_with('#') {
        return Ok(());
    }

    let mut parts = line.split_whitespace();
    let cmd = parts.next().unwrap_or("");

    match cmd {
        // Δ: entity <name>
        //
        // v0 note:
        // - Builder tracks ids; kernel emits Δ events but may not persist entity state yet.
        "entity" => {
            let name = parts
                .next()
                .ok_or_else(|| "entity requires a name: entity <name>".to_string())?;
            builder.entity(name);
            Ok(())
        }

        // Θ: theta [dt]
        //
        // v0 semantics:
        // - Missing dt => dt=1.
        // - dt is parsed as u64 (negative values rejected by parse).
        //
        // Note:
        // - PmsBuilder::advance uses a special rule: dt==0 emits Θ None (kernel treats as dt=1).
        // - However, this parser never passes 0 by default; a user can still type theta 0.
        "theta" => {
            let dt = match parts.next() {
                None => 1u64,
                Some(s) => s
                    .parse::<u64>()
                    .map_err(|_| "theta dt must be an integer".to_string())?,
            };
            builder.advance(dt);
            Ok(())
        }

        // □: frame <kind>
        //
        // v0: new frames are always allowed and start unsealed.
        // The kernel enforces all "requires active frame" constraints for other ops.
        "frame" => {
            let kind = parts
                .next()
                .ok_or_else(|| "frame requires a kind: frame <kind>".to_string())?;
            builder.frame(kind);
            Ok(())
        }

        // □ alias: square <kind>
        //
        // Implementation note:
        // - This currently calls builder.frame(kind) directly.
        // - Using builder.square(kind) would be equivalent and slightly clearer.
        "square" => {
            let kind = parts
                .next()
                .ok_or_else(|| "square requires a kind: square <kind>".to_string())?;
            builder.frame(kind); // could also be: builder.square(kind);
            Ok(())
        }

        // Ω: omega <from> <to> <weight> <desc...>
        //
        // Parsing details:
        // - Requires at least 4 tokens after command.
        // - weight is parsed as f32. Non-float => error.
        // - desc is free text (joined).
        //
        // Runtime enforcement:
        // - Kernel requires an active frame and forbids Ω if current frame is sealed.
        "omega" => {
            let from = parts
                .next()
                .ok_or_else(|| "omega requires: omega <from> <to> <weight> <desc>".to_string())?;
            let to = parts
                .next()
                .ok_or_else(|| "omega requires: omega <from> <to> <weight> <desc>".to_string())?;
            let w = parts
                .next()
                .ok_or_else(|| "omega requires: omega <from> <to> <weight> <desc>".to_string())?;

            let desc = rest_joined(&mut parts);
            if desc.is_empty() {
                return Err("omega requires: omega <from> <to> <weight> <desc>".to_string());
            }

            let weight = w
                .parse::<f32>()
                .map_err(|_| "omega weight must be a float".to_string())?;
            builder.omega(from, to, weight, &desc);
            Ok(())
        }

        // ∇: impulse <entity> <intensity> <desc...>
        //
        // Parsing details:
        // - intensity is parsed as f32.
        // - desc is free text.
        //
        // Runtime enforcement:
        // - Kernel requires an active frame for ∇.
        "impulse" => {
            let entity = parts.next().ok_or_else(|| {
                "impulse requires: impulse <entity> <intensity> <desc>".to_string()
            })?;
            let s = parts.next().ok_or_else(|| {
                "impulse requires: impulse <entity> <intensity> <desc>".to_string()
            })?;

            let desc = rest_joined(&mut parts);
            if desc.is_empty() {
                return Err("impulse requires: impulse <entity> <intensity> <desc>".to_string());
            }

            let intensity = s
                .parse::<f32>()
                .map_err(|_| "impulse intensity must be a float".to_string())?;
            builder.impulse(entity, intensity, &desc);
            Ok(())
        }

        // Σ: integrate <note...>
        //
        // Parsing details:
        // - note is free text and must be non-empty.
        //
        // Runtime enforcement:
        // - Kernel requires an active frame.
        // - v0 decision: Σ is allowed even after Ψ sealed the frame.
        "integrate" => {
            let note = rest_joined(&mut parts);
            if note.is_empty() {
                return Err("integrate requires: integrate <note>".to_string());
            }
            builder.integrate(&note);
            Ok(())
        }

        // Λ: expect <horizon> <desc...>
        //
        // Parsing details:
        // - horizon parsed as u64.
        // - desc is free text and must be non-empty.
        //
        // Runtime semantics:
        // - Kernel records expectation with due_tick = now + horizon.
        // - Θ advancement triggers non_event timeouts.
        "expect" => {
            let h = parts
                .next()
                .ok_or_else(|| "expect requires: expect <horizon> <desc>".to_string())?;

            let desc = rest_joined(&mut parts);
            if desc.is_empty() {
                return Err("expect requires: expect <horizon> <desc>".to_string());
            }

            let horizon = h
                .parse::<u64>()
                .map_err(|_| "expect horizon must be an integer".to_string())?;
            builder.expect(horizon, &desc);
            Ok(())
        }

        // Α: attractor <label>
        //
        // Parsing details:
        // - label is a single token (no spaces).
        //
        // Runtime enforcement:
        // - Kernel requires an active frame and forbids Α if current frame is sealed.
        "attractor" => {
            let label = parts
                .next()
                .ok_or_else(|| "attractor requires a label: attractor <label>".to_string())?;
            builder.attractor(label);
            Ok(())
        }

        // Φ: phi <from> <to>
        //
        // v0 constraint:
        // - from/to are single tokens.
        // - If you need multi-word reframes later, extend parser with quoting.
        //
        // Runtime semantics:
        // - Kernel allows Φ even without an active frame (frame_id optional).
        "phi" => {
            let from = parts
                .next()
                .ok_or_else(|| "phi requires: phi <from> <to>".to_string())?;
            let to = parts
                .next()
                .ok_or_else(|| "phi requires: phi <from> <to>".to_string())?;
            builder.reframe(from, to);
            Ok(())
        }

        // Χ: chi <label>
        //
        // REPL ergonomics:
        // - `chi` is defined as an alias of `chi_enter`.
        // - χ enter is forbidden if current isolation is sealed (enforced by kernel).
        "chi" => {
            let label = parts
                .next()
                .ok_or_else(|| "chi requires: chi <label>".to_string())?;
            builder.chi(label);
            Ok(())
        }

        // Χ: chi_enter <label>
        //
        // Explicit entry command. Same as `chi`.
        "chi_enter" => {
            let label = parts
                .next()
                .ok_or_else(|| "chi_enter requires a label: chi_enter <label>".to_string())?;
            builder.isolation_enter(label);
            Ok(())
        }

        // Χ: chi_exit
        //
        // Exit is always emitted; kernel enforces that an isolation exists.
        // If user calls chi_exit without a prior enter, kernel will error at runtime or validation.
        "chi_exit" => {
            builder.isolation_exit();
            Ok(())
        }

        // Ψ: psi <note...>
        //
        // Parsing details:
        // - note is free text and must be non-empty.
        //
        // Runtime semantics:
        // - Kernel records commit, seals current frame and isolation (if any),
        //   and creates a snapshot anchor (CommitSnapshot).
        "psi" => {
            let note = rest_joined(&mut parts);
            if note.is_empty() {
                return Err("psi requires: psi <note>".to_string());
            }
            builder.commit(&note);
            Ok(())
        }

        // Unknown DSL command:
        // - Fail-closed (do not mutate builder).
        _ => Err(format!("Unknown command: '{}'", cmd)),
    }
}

fn json_f32(value: f32) -> String {
    if value.is_finite() {
        value.to_string()
    } else {
        format!("\"{}\"", json_escape(&value.to_string()))
    }
}

fn quoted(value: &str) -> String {
    format!("\"{}\"", json_escape(value))
}

fn opcode_param_summary(params: &OpParams) -> String {
    match params {
        OpParams::None => "{}".to_string(),
        OpParams::NewEntity { name } => format!("name={}", quoted(name)),
        OpParams::Advance { dt } => format!("dt={}", dt),
        OpParams::NewFrame { kind } => format!("kind={}", quoted(kind)),
        OpParams::Asymmetry {
            from,
            to,
            weight,
            desc,
        } => format!(
            "from={} to={} weight={} desc={}",
            quoted(from),
            quoted(to),
            weight,
            quoted(desc)
        ),
        OpParams::Impulse {
            entity,
            intensity,
            desc,
        } => format!(
            "entity={} intensity={} desc={}",
            quoted(entity),
            intensity,
            quoted(desc)
        ),
        OpParams::Integrate { note } => format!("note={}", quoted(note)),
        OpParams::Expectation { horizon, desc } => {
            format!("horizon={} desc={}", horizon, quoted(desc))
        }
        OpParams::Attractor { label } => format!("label={}", quoted(label)),
        OpParams::Reframe { from, to } => {
            format!("from={} to={}", quoted(from), quoted(to))
        }
        OpParams::IsolationEnter { label } => {
            format!("action=enter label={}", quoted(label))
        }
        OpParams::IsolationExit => "action=exit".to_string(),
        OpParams::Commit { note } => format!("note={}", quoted(note)),
    }
}

fn opcode_params_json(params: &OpParams) -> String {
    match params {
        OpParams::None => "{}".to_string(),
        OpParams::NewEntity { name } => {
            format!("{{\"name\":\"{}\"}}", json_escape(name))
        }
        OpParams::Advance { dt } => {
            format!("{{\"dt\":{}}}", dt)
        }
        OpParams::NewFrame { kind } => {
            format!("{{\"kind\":\"{}\"}}", json_escape(kind))
        }
        OpParams::Asymmetry {
            from,
            to,
            weight,
            desc,
        } => format!(
            "{{\"from\":\"{}\",\"to\":\"{}\",\"weight\":{},\"desc\":\"{}\"}}",
            json_escape(from),
            json_escape(to),
            json_f32(*weight),
            json_escape(desc)
        ),
        OpParams::Impulse {
            entity,
            intensity,
            desc,
        } => format!(
            "{{\"entity\":\"{}\",\"intensity\":{},\"desc\":\"{}\"}}",
            json_escape(entity),
            json_f32(*intensity),
            json_escape(desc)
        ),
        OpParams::Integrate { note } => {
            format!("{{\"note\":\"{}\"}}", json_escape(note))
        }
        OpParams::Expectation { horizon, desc } => {
            format!(
                "{{\"horizon\":{},\"desc\":\"{}\"}}",
                horizon,
                json_escape(desc)
            )
        }
        OpParams::Attractor { label } => {
            format!("{{\"label\":\"{}\"}}", json_escape(label))
        }
        OpParams::Reframe { from, to } => {
            format!(
                "{{\"from\":\"{}\",\"to\":\"{}\"}}",
                json_escape(from),
                json_escape(to)
            )
        }
        OpParams::IsolationEnter { label } => {
            format!(
                "{{\"action\":\"enter\",\"label\":\"{}\"}}",
                json_escape(label)
            )
        }
        OpParams::IsolationExit => "{\"action\":\"exit\"}".to_string(),
        OpParams::Commit { note } => {
            format!("{{\"note\":\"{}\"}}", json_escape(note))
        }
    }
}

fn show_program_text(program: &[OpCode]) -> String {
    if program.is_empty() {
        return "<empty>".to_string();
    }

    let mut out = String::new();

    for (idx, opcode) in program.iter().enumerate() {
        if idx > 0 {
            out.push('\n');
        }

        out.push_str(&format!(
            "{}: {} {}",
            idx,
            opcode.op.model_key(),
            opcode_param_summary(&opcode.params)
        ));
    }

    out
}

fn show_program_json(program: &[OpCode]) -> String {
    let mut out = String::from("[");

    for (idx, opcode) in program.iter().enumerate() {
        if idx > 0 {
            out.push(',');
        }

        out.push_str(&format!(
            "{{\"idx\":{},\"op\":\"{}\",\"params\":{}}}",
            idx,
            opcode.op.model_key(),
            opcode_params_json(&opcode.params)
        ));
    }

    out.push(']');
    out
}

/// Handle "service commands" that operate on a kernel-internal service state (vFS).
///
/// Key invariant:
/// - These commands MUST NOT mutate the program builder / program buffer.
/// - They use a dedicated KernelState (`svc`) as an in-memory service model.
///
/// Why KernelState?
/// - You reuse the vFS implementation that lives inside KernelState.
/// - vFS operations emit KernelEvent lines via KernelState.emit().
/// - But those events are *service-side* and must be kept separate from the program timeline.
///
/// Therefore:
/// - We drain svc.events after each service call and append them into svc_events.
/// - This keeps svc.events empty between calls and keeps svc_events as the stable service log.
///
/// Return value:
/// - Ok(true)  => the line was recognized as a service command and handled.
/// - Ok(false) => not a service command; caller may treat it as DSL or REPL meta-command.
/// - Err(...)  => recognized command but failed (invalid args or vFS error).
fn handle_fs_service_line(
    svc: &mut KernelState,
    svc_events: &mut Vec<KernelEvent>,
    line: &str,
) -> Result<bool, String> {
    let mut parts = line.split_whitespace();
    let cmd = parts.next().unwrap_or("");

    match cmd {
        // fs_create <path>
        //
        // v0 semantics:
        // - Creates an empty file node at an absolute canonical path (vFS enforces).
        // - Emits a Δ fs_create_file event into svc.events (then drained into svc_events).
        "fs_create" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_create requires: fs_create <path>".to_string())?;
            if parts.next().is_some() {
                return Err("fs_create requires exactly 1 arg: fs_create <path>".to_string());
            }

            let id = svc.fs_create_file(path)?;

            // Move newly-emitted service events into the dedicated service log.
            // This prevents mixing service events with future service events in svc.events
            // and avoids accidental reuse of svc.events as program timeline.
            svc_events.append(&mut svc.events);

            println!("OK. created file id={} path={}", id, path);
            Ok(true)
        }

        // fs_mkdir <path>
        //
        // v0 semantics:
        // - Creates a directory node at path.
        // - Creating "/" is a no-op returning root id.
        // - Emits a Δ fs_create_dir event into svc.events.
        "fs_mkdir" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_mkdir requires: fs_mkdir <path>".to_string())?;
            if parts.next().is_some() {
                return Err("fs_mkdir requires exactly 1 arg: fs_mkdir <path>".to_string());
            }

            let id = svc.fs_create_dir(path)?;
            svc_events.append(&mut svc.events);

            println!("OK. created dir id={} path={}", id, path);
            Ok(true)
        }

        // fs_write <path> <data_no_spaces>
        //
        // v0 semantics:
        // - Writes UTF-8 bytes to an existing file path.
        // - Data token cannot contain spaces (by parser design).
        // - Emits a Δ fs_write_file event.
        "fs_write" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_write requires: fs_write <path> <data_no_spaces>".to_string())?;
            let data = parts
                .next()
                .ok_or_else(|| "fs_write requires: fs_write <path> <data_no_spaces>".to_string())?;
            if parts.next().is_some() {
                return Err(
                    "fs_write requires exactly 2 args: fs_write <path> <data_no_spaces>"
                        .to_string(),
                );
            }

            svc.fs_write_file(path, data.as_bytes())?;
            svc_events.append(&mut svc.events);

            println!("OK. wrote len={} path={}", data.len(), path);
            Ok(true)
        }

        // fs_read <path>
        //
        // v0 semantics:
        // - Reads file bytes and prints them as UTF-8 lossy text (REPL convenience).
        // - Emits a Δ fs_read_file event.
        //
        // Note:
        // - Using from_utf8_lossy is deliberate: it avoids panics on non-UTF8 data,
        //   but it also means binary data will be rendered with replacement chars.
        "fs_read" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_read requires: fs_read <path>".to_string())?;
            if parts.next().is_some() {
                return Err("fs_read requires exactly 1 arg: fs_read <path>".to_string());
            }

            let bytes = svc.fs_read_file(path)?;
            svc_events.append(&mut svc.events);

            let s = String::from_utf8_lossy(&bytes);
            println!("OK. read len={} path={} data={}", bytes.len(), path, s);
            Ok(true)
        }

        // fs_delete <path>
        //
        // v0 semantics:
        // - Deletes a file or empty directory.
        // - Refuses missing paths, root "/", and non-empty directories.
        // - Emits a Δ fs_delete service event.
        "fs_delete" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_delete requires: fs_delete <path>".to_string())?;
            if parts.next().is_some() {
                return Err("fs_delete requires exactly 1 arg: fs_delete <path>".to_string());
            }

            svc.fs_delete(path)?;
            svc_events.append(&mut svc.events);

            println!("OK. deleted path={}", path);
            Ok(true)
        }

        // fs_ls <path>
        //
        // v0 semantics:
        // - Lists directory children (names) sorted deterministically by vFS.
        // - vFS list currently does not emit events, but we still drain svc.events
        //   to keep behavior consistent if vFS later adds events for list.
        "fs_ls" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_ls requires: fs_ls <path>".to_string())?;
            if parts.next().is_some() {
                return Err("fs_ls requires exactly 1 arg: fs_ls <path>".to_string());
            }

            let items = svc.fs_list_dir(path)?;
            // Should be no events, but keep behavior consistent if it changes later.
            svc_events.append(&mut svc.events);

            println!("OK. ls path={} -> {:?}", path, items);
            Ok(true)
        }

        // fs_state
        //
        // Introspection helper:
        // - Prints basic vFS counters.
        // - Does not mutate state.
        // - Does not produce service events.
        "fs_state" => {
            println!(
                "vFS: root_id={} nodes={} next_id={}",
                svc.fs_root,
                svc.fs_nodes.len(),
                svc.next_fs_node_id
            );
            Ok(true)
        }

        // fs_events
        //
        // Prints the accumulated service event log (svc_events), not the program events.
        // This separation is critical for deterministic program timelines.
        "fs_events" => {
            print_events(svc_events);
            Ok(true)
        }

        // fs_clear_events
        //
        // Clears the service event log. This does not touch svc (the filesystem state).
        "fs_clear_events" => {
            svc_events.clear();
            println!("OK. vFS service events cleared.");
            Ok(true)
        }

        // fs_dump <path>
        //
        // Dumps the service event log as JSONL using the same schema as kernel event dumps.
        // This is useful for testing vFS service behavior separately from program execution.
        "fs_dump" => {
            let path = parts
                .next()
                .ok_or_else(|| "fs_dump requires: fs_dump <path>".to_string())?;
            if parts.next().is_some() {
                return Err("fs_dump requires exactly 1 arg: fs_dump <path>".to_string());
            }

            dump_events_jsonl(path, svc_events)?;
            println!("OK. dumped vFS JSONL: {}", path);
            Ok(true)
        }

        // Not a service command. Caller decides what to do next (DSL/REPL command).
        _ => Ok(false),
    }
}

/// Apply AI-compiled opcode specs to a PmsBuilder.
///
/// Context:
/// - ai_bridge::compile_scenario returns canonicalized opcodes (op + params JSON object).
/// - The REPL must translate those opcodes into the local DSL IR (PmsBuilder calls).
///
/// Safety posture (critical):
/// - Fail-closed: any unknown op / missing param / wrong type => Err, and the caller must not
///   mutate the “real” program buffer (caller uses a temporary builder first).
/// - Host-side type checks are repeated here even though the bridge already validates some shape,
///   because the REPL also supports test injection / alternate call() implementations.
///
/// Important semantic limitation (v0):
/// - There is no explicit "ChiExit" opcode in the compile_scenario whitelist.
///   Therefore, AI compilation can only *enter* isolation, not exit it.
///   This is consistent with the current compile whitelist but means:
///   - isolation scopes are one-way in compiled output (potentially nested).
///   - any "balanced isolation" behavior must be expressed by ending the program or
///     by future extension of the opcode vocabulary.
///
/// Mapping contract:
/// - "Delta"  params: { name: string }
/// - "Square" params: { kind: string }
/// - "Theta"  params: { dt?: u64 } (optional dt; default 1)
/// - "Omega"  params: { from: string, to: string, weight: number, desc: string }
/// - "Nabla"  params: { entity: string, intensity: number, desc: string }
/// - "Lambda" params: { horizon: u64, desc: string }
/// - "Alpha"  params: { label: string }
/// - "Chi"    params: { label: string }  (enter only)
/// - "Phi"    params: { from: string, to: string }
/// - "Sigma"  params: { note: string }
/// - "Psi"    params: { note: string }
fn apply_compiled_opcodes(
    builder: &mut PmsBuilder,
    opcodes: &[pms_ai_bridge::AiOpcodeSpec],
) -> Result<(), String> {
    /// Extract an object map reference from a serde_json::Value.
    ///
    /// Fail-closed:
    /// - If params is not a JSON object, return Err.
    ///
    /// Note:
    /// - The bridge already enforces params.is_object() for compile_scenario,
    ///   but keeping this here protects against:
    ///   - alternate callers / tests that bypass the bridge
    ///   - future changes that weaken upstream validation
    // Mapping caps (v0, documented behavior):
    // - Documented in pms-docs/AI_BRIDGE.md ("Mapping Caps").
    // - `Chi` is enter-only in compiled output (no exit opcode).
    // - `Delta(name)` is idempotent through PmsBuilder mapping.
    fn get_obj(
        v: &serde_json::Value,
    ) -> Result<&serde_json::Map<String, serde_json::Value>, String> {
        v.as_object()
            .ok_or_else(|| "opcode.params must be a JSON object".to_string())
    }

    /// Extract a required string field from a params map.
    ///
    /// Fail-closed:
    /// - Missing key or non-string => Err("missing/invalid param '<k>'")
    fn get_str(
        map: &serde_json::Map<String, serde_json::Value>,
        k: &str,
    ) -> Result<String, String> {
        map.get(k)
            .and_then(|v| v.as_str())
            .map(|s| s.to_string())
            .ok_or_else(|| format!("missing/invalid param '{}'", k))
    }

    /// Extract a required numeric field and convert to f32.
    ///
    /// Behavior:
    /// - Reads JSON numbers via as_f64() and casts to f32.
    ///
    /// v0 implications:
    /// - Precision can be lost (expected for f32).
    /// - Very large numbers may become inf or lose detail; this is acceptable for v0.
    /// - If the model emits an integer, as_f64() still works (serde_json treats numbers uniformly).
    fn get_f32(map: &serde_json::Map<String, serde_json::Value>, k: &str) -> Result<f32, String> {
        map.get(k)
            .and_then(|v| v.as_f64())
            .map(|x| x as f32)
            .ok_or_else(|| format!("missing/invalid param '{}'", k))
    }

    /// Extract a required u64 integer field.
    ///
    /// Fail-closed:
    /// - Missing key or non-u64 => Err.
    ///
    /// Note:
    /// - as_u64 rejects floats and negatives (desired for horizons/dt).
    fn get_u64(map: &serde_json::Map<String, serde_json::Value>, k: &str) -> Result<u64, String> {
        map.get(k)
            .and_then(|v| v.as_u64())
            .ok_or_else(|| format!("missing/invalid param '{}'", k))
    }

    /// Extract an optional u64 integer field.
    ///
    /// Used for Theta.dt:
    /// - If absent => default handled by caller (unwrap_or(1)).
    fn get_u64_opt(map: &serde_json::Map<String, serde_json::Value>, k: &str) -> Option<u64> {
        map.get(k).and_then(|v| v.as_u64())
    }

    // Apply in-order: opcode order is the program timeline order.
    for (i, spec) in opcodes.iter().enumerate() {
        let op = spec.op.as_str();

        // Defensive: re-check params object and annotate errors with index + op.
        let params = get_obj(&spec.params).map_err(|e| format!("opcode[{}] {}: {}", i, op, e))?;

        match op {
            // Δ — entity creation / declaration
            //
            // Builder behavior:
            // - entity() is idempotent per name; a second Delta with same name will not create a new id
            //   and will not emit a second Δ opcode.
            //   This is deliberate for builder ergonomics but means:
            //   - AI output that repeats Delta(name=...) does not necessarily produce repeated Δ in program.
            //
            // v0: kernel only logs Δ events; builder still maintains ids for later expansion.
            "Delta" => {
                let name =
                    get_str(params, "name").map_err(|e| format!("opcode[{}] Delta: {}", i, e))?;
                builder.entity(&name);
            }

            // □ — frame
            //
            // Runtime semantics:
            // - Starts a new frame, unsealed.
            // - Frame stack is push-only in v0.
            "Square" => {
                let kind =
                    get_str(params, "kind").map_err(|e| format!("opcode[{}] Square: {}", i, e))?;
                builder.frame(&kind);
            }

            // Θ — time advance
            //
            // Mapping:
            // - dt optional: {dt} if present else default 1.
            //
            // Subtlety:
            // - Builder.advance(0) emits Θ None (kernel treats as dt=1).
            // - This mapping defaults to 1 but does not prevent dt=0 if AI emits it.
            "Theta" => {
                let dt = get_u64_opt(params, "dt").unwrap_or(1);
                builder.advance(dt);
            }

            // Ω — asymmetry edge (requires active frame at runtime)
            "Omega" => {
                let from =
                    get_str(params, "from").map_err(|e| format!("opcode[{}] Omega: {}", i, e))?;
                let to =
                    get_str(params, "to").map_err(|e| format!("opcode[{}] Omega: {}", i, e))?;
                let weight =
                    get_f32(params, "weight").map_err(|e| format!("opcode[{}] Omega: {}", i, e))?;
                let desc =
                    get_str(params, "desc").map_err(|e| format!("opcode[{}] Omega: {}", i, e))?;
                builder.omega(&from, &to, weight, &desc);
            }

            // ∇ — impulse (requires active frame at runtime)
            "Nabla" => {
                let entity =
                    get_str(params, "entity").map_err(|e| format!("opcode[{}] Nabla: {}", i, e))?;
                let intensity = get_f32(params, "intensity")
                    .map_err(|e| format!("opcode[{}] Nabla: {}", i, e))?;
                let desc =
                    get_str(params, "desc").map_err(|e| format!("opcode[{}] Nabla: {}", i, e))?;
                builder.impulse(&entity, intensity, &desc);
            }

            // Λ — expectation
            "Lambda" => {
                let horizon = get_u64(params, "horizon")
                    .map_err(|e| format!("opcode[{}] Lambda: {}", i, e))?;
                let desc =
                    get_str(params, "desc").map_err(|e| format!("opcode[{}] Lambda: {}", i, e))?;
                builder.expect(horizon, &desc);
            }

            // Α — attractor (requires active frame at runtime)
            "Alpha" => {
                let label =
                    get_str(params, "label").map_err(|e| format!("opcode[{}] Alpha: {}", i, e))?;
                builder.attractor(&label);
            }

            // Χ — isolation enter (enter-only in compile_scenario v0)
            //
            // Important:
            // - Builder uses isolation_enter(label).
            // - There is no corresponding exit opcode here.
            "Chi" => {
                let label =
                    get_str(params, "label").map_err(|e| format!("opcode[{}] Chi: {}", i, e))?;
                builder.isolation_enter(&label);
            }

            // Φ — reframe (frame_id optional at runtime)
            "Phi" => {
                let from =
                    get_str(params, "from").map_err(|e| format!("opcode[{}] Phi: {}", i, e))?;
                let to = get_str(params, "to").map_err(|e| format!("opcode[{}] Phi: {}", i, e))?;
                builder.reframe(&from, &to);
            }

            // Σ — integrate (requires active frame at runtime; allowed even if frame is sealed per your v0 decision)
            "Sigma" => {
                let note =
                    get_str(params, "note").map_err(|e| format!("opcode[{}] Sigma: {}", i, e))?;
                builder.integrate(&note);
            }

            // Ψ — commit + seal
            "Psi" => {
                let note =
                    get_str(params, "note").map_err(|e| format!("opcode[{}] Psi: {}", i, e))?;
                builder.commit(&note);
            }

            // Fail-closed:
            // - Even though the bridge whitelists canonical ops, keeping this branch ensures the REPL
            //   remains robust if:
            //   - a future bridge change expands op whitelist without updating REPL mapping,
            //   - or the REPL is fed opcodes from other sources (tests / fixtures).
            other => {
                return Err(format!(
                    "opcode[{}] unsupported op for REPL builder mapping: {}",
                    i, other
                ));
            }
        }
    }

    Ok(())
}

/// Read stdin until EOF and return the entire contents as a String.
///
/// Used for:
/// - --run mode (script via stdin)
///
/// Failure mode:
/// - IO read errors return Err with the std::io error string.
fn read_all_stdin() -> Result<String, String> {
    let mut buf = String::new();
    io::stdin()
        .read_to_string(&mut buf)
        .map_err(|e| e.to_string())?;
    Ok(buf)
}

fn reject_service_command_in_script(raw: &str, line_no: usize) -> Result<(), String> {
    let trimmed = raw.trim_start();

    if trimmed.starts_with("fs_") {
        return Err(format!(
            "Script error on line {}: fs_* service commands are not supported in scripts.\n  >> {}",
            line_no, raw
        ));
    }

    Ok(())
}

/// Execute the currently buffered program in the kernel and return the final tick and events.
///
/// Control flow:
/// - take_program() drains the builder’s buffer (so repeated `run` in a session does not re-run old code).
/// - Kernel is instantiated with that program.
/// - Optional validation runs before execution (two layers):
///   - v1 adjacency validation against PMS.yaml model rules
///   - v2 stateful "shadow" validation (frame sealed constraints, isolation constraints, etc.)
/// - Kernel runs until finished (no max step limit in v0).
///
/// Return:
/// - (final_tick, events) from the kernel state.
/// - Caller decides how/where to print or dump.
///
/// Fail-closed:
/// - If validate=true but model=None => explicit error message.
/// - Validation errors return before executing any kernel step.
#[cfg(test)]
fn run_program(
    builder: &mut PmsBuilder,
    model: Option<&PmsModel>,
    validate: bool,
) -> Result<(u64, Vec<KernelEvent>), String> {
    let program = builder.take_program();
    let mut k = Kernel::new(program);

    if validate {
        let m = model.ok_or_else(|| {
            "Validation is ON but no model is loaded. Use: model <path> (or restart with --model <path>)."
                .to_string()
        })?;

        // v1: adjacency validation (PMS.yaml rules)
        k.validate_program(m)?;

        // v2: stateful constraints (shadow-state)
        k.validate_program_stateful()?;
    }

    k.run_until_finished(None)?;
    Ok((k.state.tick, k.state.events))
}

/// Execute the currently buffered program in the kernel and return tick + events,
/// even if execution fails.
///
/// v0.1 rationale:
/// - Golden fixtures want to capture the deterministic prefix that the kernel produced
///   before hitting a runtime guard (e.g. sealed frame forbids Ω).
/// - We keep fail-closed behavior by returning Err(...) on failure,
///   but we still surface the partial event list.
///
/// Fail-closed:
/// - Validation errors return before executing any kernel step and return empty events.
pub(crate) enum RunOutcome {
    Ok {
        tick: u64,
        events: Vec<KernelEvent>,
    },
    Err {
        tick: u64,
        events: Vec<KernelEvent>,
        error: String,
    },
}

pub(crate) fn run_program_outcome(
    builder: &mut PmsBuilder,
    model: Option<&PmsModel>,
    validate: bool,
) -> RunOutcome {
    let program = builder.take_program();
    let mut k = Kernel::new(program);

    if validate {
        let m = match model {
            Some(m) => m,
            None => {
                return RunOutcome::Err {
                    tick: 0,
                    events: Vec::new(),
                    error:
                        "Validation is ON but no model is loaded. Use: model <path> (or restart with --model <path>)."
                            .to_string(),
                };
            }
        };

        // v1: adjacency validation (PMS.yaml rules)
        if let Err(e) = k.validate_program(m) {
            return RunOutcome::Err {
                tick: 0,
                events: Vec::new(),
                error: e,
            };
        }

        // v2: stateful constraints (shadow-state)
        if let Err(e) = k.validate_program_stateful() {
            return RunOutcome::Err {
                tick: 0,
                events: Vec::new(),
                error: e,
            };
        }
    }

    let res = k.run_until_finished(None);

    let tick = k.state.tick;
    let events = k.state.events;

    match res {
        Ok(()) => RunOutcome::Ok { tick, events },
        Err(e) => RunOutcome::Err {
            tick,
            events,
            error: e,
        },
    }
}

/// REPL-local "success output" for ai_compile.
///
/// Why keep both compile + warnings?
/// - warnings should be shown to the user even if later steps fail,
///   but in the success case we also return them for reporting/logging.
/// - compile result is useful to display opcodes or debug what AI returned.
#[derive(Debug, Clone)]
struct AiCompileOut {
    compile: pms_ai_bridge::AiCompileResult,
    warnings: Vec<String>,
}

fn ai_compile_out_json(out: &AiCompileOut) -> String {
    let v = serde_json::json!({
        "ok": true,
        "task": pms_ai_bridge::TASK_COMPILE_SCENARIO,
        "result": {
            "opcodes": &out.compile.opcodes,
        },
        "warnings": &out.warnings,
        "error": null,
    });

    serde_json::to_string(&v).expect("serializing accepted ai_compile result should not fail")
}

fn parse_ai_compile_flags(raw: &str) -> Result<(bool, bool, &str), String> {
    let mut dry_run = false;
    let mut show_json = false;
    let mut rest = raw.trim();

    loop {
        let Some((head, tail)) = rest.split_once(char::is_whitespace) else {
            match rest {
                "--dry-run" => {
                    dry_run = true;
                    rest = "";
                    continue;
                }
                "--show-json" => {
                    show_json = true;
                    rest = "";
                    continue;
                }
                _ => break,
            }
        };

        match head {
            "--dry-run" => {
                dry_run = true;
                rest = tail.trim_start();
            }
            "--show-json" => {
                show_json = true;
                rest = tail.trim_start();
            }
            flag if flag.starts_with("--") => {
                return Err(format!(
                    "unknown ai_compile flag: {} (expected --dry-run and/or --show-json)",
                    flag
                ));
            }
            _ => break,
        }
    }

    Ok((dry_run, show_json, rest))
}

/// REPL ai_compile implementation with dependency injection for the bridge call.
///
/// Why this signature?
/// - It enables unit tests to pass a fake `call` closure (no HTTP).
/// - It keeps the REPL logic (mapping + validation + buffer replacement) testable.
///
/// Atomicity goal:
/// - The existing builder buffer MUST remain unchanged unless:
///   1) AI returns ok=true with compile result,
///   2) mapping succeeds,
///   3) and (if validate=ON) both validations succeed.
/// - Only then do we replace the active buffer.
///
/// Telemetry goal:
/// - `steps` is a minimal “span chain” to make failures diagnosable without a logging framework.
/// - The caller receives errors with "Trace: a -> b -> c" appended.
fn repl_ai_compile_with_call_inner<F>(
    builder: &mut PmsBuilder,
    model: Option<&PmsModel>,
    validate: bool,
    dry_run: bool,
    desc: &str,
    call: F,
) -> Result<AiCompileOut, String>
where
    F: FnOnce(&pms_ai_bridge::AiRequest) -> Result<pms_ai_bridge::AiResponse, String>,
{
    // Step-chain (“Span” telemetry without a framework)
    //
    // Contract:
    // - Append meaningful milestones in order.
    // - On error, include the steps chain so users/devs can see where it failed.
    let mut steps: Vec<&'static str> = Vec::new();

    // Helper: format an error string, optionally with the step trace suffix.
    // Note:
    // - This closure borrows `steps` by reference to preserve the current chain at failure time.
    let fail = |msg: String, steps: &Vec<&'static str>| -> Result<AiCompileOut, String> {
        if steps.is_empty() {
            Err(msg)
        } else {
            Err(format!("{} Trace: {}", msg, steps.join(" -> ")))
        }
    };

    // Basic input guard: do not call the AI with empty text.
    if desc.trim().is_empty() {
        return Err("ai_compile requires: ai_compile <desc...>".to_string());
    }

    trace!(
        "ai_compile start desc_len={} validate={} dry_run={}",
        desc.len(),
        validate,
        dry_run
    );

    // Heavy debug (truncated): keeps ai_debug! + trunc() "used" and avoids printing massive text.
    ai_debug!("ai_compile desc_trunc={}", trunc(desc, 400));

    // Milestone: request built (conceptual)
    steps.push("repl.request_built");

    // Build the bridge request.
    //
    // Notes:
    // - task is compile_scenario.
    // - language is forced to "en" in v0 (consistent with system prompt).
    // - max_tokens is fixed to 700 here; bridge itself also defaults if zero.
    let req = pms_ai_bridge::AiRequest {
        task: pms_ai_bridge::TASK_COMPILE_SCENARIO.to_string(),
        version: "pms-1.0".to_string(),
        pms_meta: serde_json::json!({ "model": "PMS_STACK", "schema_version": "1.1" }),
        input: pms_ai_bridge::AiInput::CompileScenario(pms_ai_bridge::AiInputCompileScenario {
            context: None,
            description: desc.to_string(),
            constraints: None,
        }),
        options: pms_ai_bridge::AiOptions {
            language: "en".to_string(),
            max_tokens: 700,
        },
    };

    // Milestone: "HTTP sent" (or generally: bridge call started)
    steps.push("bridge.http_sent");

    // Execute the injected call (bridge or test stub).
    let resp = match call(&req) {
        Ok(r) => r,
        Err(e) => return fail(format!("ai_compile: bridge call failed: {}", e), &steps),
    };

    // Milestone: bridge call returned without transport error.
    steps.push("bridge.http_ok");

    trace!(
        "ai_compile resp ok={} warnings={} has_result={}",
        resp.ok,
        resp.warnings.len(),
        resp.result.is_some()
    );

    // Heavy debug (truncated) — prints only when PMS_AI_DEBUG=1.
    ai_debug!(
        "ai_compile resp_task={} warnings={} has_error={}",
        resp.task,
        resp.warnings.len(),
        resp.error.is_some()
    );

    // AI-level failure handling:
    // - ok=false => surface error code/message.
    // - Use fail(...) so we keep the step chain.
    if !resp.ok {
        let code = resp
            .error
            .as_ref()
            .map(|e| e.code.as_str())
            .unwrap_or("unknown");
        let msg = resp
            .error
            .as_ref()
            .map(|e| e.message.as_str())
            .unwrap_or("<no message>");
        return fail(
            format!("AI: ok=false code={} message={}", code, msg),
            &steps,
        );
    }

    // Milestone: AI response considered "ok" at envelope level.
    steps.push("bridge.parse_ok");

    // Preserve warnings even if mapping/validation fails later:
    // - This is helpful because warnings may explain why compilation was fragile.
    // - Caller can show them alongside an error.
    let warnings = resp.warnings.clone();
    trace!("ai_compile warnings preserved={}", warnings.len());

    // Extract compile result (fail-closed if wrong shape).
    //
    // Note:
    // - compile_scenario must return result.opcodes; analyze result is an invariant violation.
    let compile = match resp.result {
        Some(pms_ai_bridge::AiResult::Compile(c)) => c,
        Some(pms_ai_bridge::AiResult::Analyze(_)) => {
            return fail(
                "AI: ok=true but result was analyze_trace (unexpected for ai_compile)".to_string(),
                &steps,
            );
        }
        None => return fail("AI: ok=true but result=null".to_string(), &steps),
    };

    trace!("ai_compile opcodes={}", compile.opcodes.len());

    // Map opcodes -> temporary builder (fail-closed).
    //
    // This is the critical "atomic buffer replacement" strategy:
    // - If mapping fails, we do NOT touch the user's current buffer.
    let mut tmp = PmsBuilder::new();

    // Trace opcode ops for debugging (no side effects).
    for (i, spec) in compile.opcodes.iter().enumerate() {
        trace!("map opcode[{}] op={}", i, spec.op);
    }

    // Apply mapping into tmp.
    if let Err(e) = apply_compiled_opcodes(&mut tmp, &compile.opcodes) {
        // Mapping fail-close: real buffer stays untouched.
        return fail(format!("ai_compile: opcode mapping failed: {}", e), &steps);
    }
    steps.push("repl.map_ok");

    // D11: validations always when validate=ON
    //
    // Behavior:
    // - Validate the newly compiled program *before* it becomes the active buffer.
    // - Uses the real kernel validators (v1 adjacency + v2 stateful).
    if validate {
        trace!("validate v1 start");
        steps.push("validate.v1_start");

        let m = match model {
            Some(m) => m,
            None => {
                return fail(
                    "Validation is ON but no model is loaded. Use: model <path> (or restart with --model <path>)."
                        .to_string(),
                    &steps,
                );
            }
        };

        // Convert tmp builder program into a kernel instance for validation.
        //
        // Important subtlety:
        // - tmp.take_program() drains tmp. That is OK because tmp is temporary.
        // - We do not need tmp afterward.
        let program = tmp.take_program();
        let k = Kernel::new(program);

        // v1 adjacency validation against model dependency table.
        if let Err(e) = k.validate_program(m) {
            trace!("validate v1 fail");
            steps.push("validate.v1_fail");
            return fail(format!("validate_program (v1) failed: {}", e), &steps);
        }

        trace!("validate v1 ok");
        steps.push("validate.v1_ok");

        // v2 shadow-state validation (sealed frame/isolation constraints etc.).
        trace!("validate v2 start");
        steps.push("validate.v2_start");

        if let Err(e) = k.validate_program_stateful() {
            trace!("validate v2 fail");
            steps.push("validate.v2_fail");
            return fail(
                format!("validate_program_stateful (v2) failed: {}", e),
                &steps,
            );
        }

        trace!("validate v2 ok");
        steps.push("validate.v2_ok");
    }

    if dry_run {
        trace!("dry-run ok; buffer unchanged");
        steps.push("repl.dry_run_ok");

        return Ok(AiCompileOut { compile, warnings });
    }

    // Only now replace the REPL buffer (atomic-ish).
    //
    // Implementation strategy:
    // 1) Reset builder to a fresh builder (clears prior buffer and entity map).
    // 2) Re-apply the same opcodes into the real builder.
    //
    // Why re-apply rather than reusing tmp?
    // - tmp was drained by tmp.take_program() during validation.
    // - Also: this ensures the final buffer is built using the same mapping function,
    //   providing consistent behavior (and consistent failure mode).
    trace!("buffer replace start");
    steps.push("repl.buffer_replace_start");

    *builder = PmsBuilder::new();

    if let Err(e) = apply_compiled_opcodes(builder, &compile.opcodes) {
        // This should not happen because mapping already succeeded once.
        // If it does, it's a determinism or shared-state bug and should be surfaced loudly.
        return fail(
            format!(
                "ai_compile: unexpected mapping failure during buffer replace: {}",
                e
            ),
            &steps,
        );
    }

    trace!("buffer replace ok");
    steps.push("repl.buffer_replaced");

    Ok(AiCompileOut { compile, warnings })
}

fn repl_ai_compile_with_call<F>(
    builder: &mut PmsBuilder,
    model: Option<&PmsModel>,
    validate: bool,
    desc: &str,
    call: F,
) -> Result<AiCompileOut, String>
where
    F: FnOnce(&pms_ai_bridge::AiRequest) -> Result<pms_ai_bridge::AiResponse, String>,
{
    repl_ai_compile_with_call_inner(builder, model, validate, false, desc, call)
}

fn repl_ai_compile_dry_run_with_call<F>(
    builder: &mut PmsBuilder,
    model: Option<&PmsModel>,
    validate: bool,
    desc: &str,
    call: F,
) -> Result<AiCompileOut, String>
where
    F: FnOnce(&pms_ai_bridge::AiRequest) -> Result<pms_ai_bridge::AiResponse, String>,
{
    repl_ai_compile_with_call_inner(builder, model, validate, true, desc, call)
}

fn main() -> Result<(), String> {
    // CLI args (excluding argv[0]).
    //
    // v0 design:
    // - Keep CLI parsing minimal and dependency-free (no clap).
    // - Fail fast on unknown args.
    let args: Vec<String> = env::args().skip(1).collect();

    // Flags / options.
    //
    // Semantics:
    // - flag_run: in script mode, execute after loading (from stdin or --file).
    // - flag_validate: enable validation gates before executing or buffer replacement (ai_compile).
    // - file_path: script file path (used in script mode).
    // - model_path: PMS.yaml path for adjacency validation.
    // - dump_path: dump kernel events after run (script mode and interactive run).
    // - dump_fs_path: dump vFS service log upon exit (interactive).
    let mut flag_run = false;
    let mut flag_validate = false;
    let mut file_path: Option<String> = None;
    let mut model_path: Option<String> = None;
    let mut dump_path: Option<String> = None;
    let mut dump_fs_path: Option<String> = None;

    // ------------------------------------------------------------
    // Manual argument parsing (v0).
    //
    // Policy:
    // - Recognize a small fixed set of flags.
    // - Options that require values (`--dump`, `--file`, `--model`, `--dump-fs`) must have a next arg.
    // - Unknown args -> error with hint.
    // ------------------------------------------------------------
    let mut i = 0usize;
    while i < args.len() {
        match args[i].as_str() {
            "--help" | "-h" => {
                // Print full help text (includes DSL, service commands, and AI commands).
                print_help();
                return Ok(());
            }
            "--run" => {
                // Script mode trigger when reading stdin or using --file:
                // - If file_path is set: load file then run.
                // - Else: read stdin then run.
                flag_run = true;
                i += 1;
            }
            "--dump" => {
                // Dump kernel events (JSONL) after a successful run.
                // Used in both script-mode `--run` and interactive `run` (as a "default dump target").
                let p = args.get(i + 1).ok_or("--dump requires a path")?;
                dump_path = Some(p.clone());
                i += 2;
            }
            "--validate" => {
                // Enable validation:
                // - v1 adjacency validation against PMS model YAML.
                // - v2 stateful validation (shadow-state constraints).
                //
                // Note:
                // - Validation requires a model to be loaded at runtime,
                //   but v2 stateful validation itself is model-independent.
                // - In this REPL, we enforce "if validate=ON then model must be present" (explicit guard).
                flag_validate = true;
                i += 1;
            }
            "--file" => {
                // Script file input.
                // Script mode is entered if file_path.is_some() OR --run is requested.
                let p = args.get(i + 1).ok_or("--file requires a path")?;
                file_path = Some(p.clone());
                i += 2;
            }
            "--model" => {
                // Load PMS.yaml dependency model at startup (optional but required if validation is ON).
                let p = args
                    .get(i + 1)
                    .ok_or("--model requires a path to PMS.yaml")?;
                model_path = Some(p.clone());
                i += 2;
            }
            "--dump-fs" => {
                // Dump the vFS service log (JSONL) on REPL exit.
                //
                // Important:
                // - vFS host-calls are NOT part of the program timeline.
                // - We therefore keep a separate svc_events log and optionally dump it.
                let p = args.get(i + 1).ok_or("--dump-fs requires a path")?;
                dump_fs_path = Some(p.clone());
                i += 2;
            }
            other => return Err(format!("Unknown arg: {} (try --help)", other)),
        }
    }

    // ------------------------------------------------------------
    // Model loading (optional).
    //
    // - If model_path provided: load YAML into PmsModel.
    // - Else: model stays None.
    // ------------------------------------------------------------
    let mut model: Option<PmsModel> = match model_path.as_deref() {
        None => None,
        Some(p) => Some(PmsModel::load_from_file(p)?),
    };

    // UX warning:
    // - If model loads but dependency table is empty, adjacency validation is open-world for known ops.
    // - This is NOT an error: it can be used as a “no restrictions” model with strict unknown-op rejection.
    if let Some(m) = model.as_ref()
        && m.is_empty()
    {
        println!(
            "Warning: Model loaded but dependency table is empty -> validation is open-world for known ops."
        );
    }

    // ------------------------------------------------------------
    // Script mode:
    //
    // Trigger:
    // - If a script file is provided OR --run is requested.
    //
    // Inputs:
    // - If --file: read file.
    // - Else: read stdin until EOF.
    //
    // Behavior:
    // - Always parse script lines into a fresh PmsBuilder.
    // - If --run is present: validate (optional) + execute + print events + optional dump.
    // - Else: just confirm load and exit.
    //
    // Rationale:
    // - Allows use as both a script runner and an interactive REPL without duplicating parsing logic.
    // ------------------------------------------------------------
    if file_path.is_some() || flag_run {
        let script = if let Some(p) = file_path {
            fs::read_to_string(&p).map_err(|e| format!("Failed to read {}: {}", p, e))?
        } else {
            read_all_stdin()?
        };

        // Script parsing uses the same DSL handler as interactive mode.
        // Service commands (fs_*) are not supported here — script mode is “program timeline only”.
        // (If you want fs_* in script mode, you'd need to route lines through handle_fs_service_line first,
        // similar to interactive.)
        let mut builder = PmsBuilder::new();
        for (idx, raw) in script.lines().enumerate() {
            reject_service_command_in_script(raw, idx + 1)?;

            if let Err(e) = apply_line(&mut builder, raw) {
                // Provide line index + original line for actionable debugging.
                return Err(format!(
                    "Script error on line {}: {}\n  >> {}",
                    idx + 1,
                    e,
                    raw
                ));
            }
        }

        if flag_run {
            // Execute the parsed program.
            // Note:
            // - run_program_outcome drains the builder via take_program(), so the builder is empty afterward.
            match run_program_outcome(&mut builder, model.as_ref(), flag_validate) {
                RunOutcome::Ok { tick, events } => {
                    println!("OK. tick={}", tick);
                    print_events(&events);

                    // Optional dump: JSONL kernel events.
                    if let Some(p) = dump_path.as_deref() {
                        dump_events_jsonl(p, &events)?;
                        println!("OK. dumped JSONL: {}", p);
                    }
                }
                RunOutcome::Err {
                    tick: _,
                    events,
                    error,
                } => {
                    // v0.1: still dump partial events so failure cases are fixtureable
                    if let Some(p) = dump_path.as_deref() {
                        dump_events_jsonl(p, &events)?;
                        println!("OK. dumped JSONL: {}", p);
                    }

                    // Preserve fail-closed behavior (non-zero exit) by returning Err here.
                    return Err(error);
                }
            }
        } else {
            // Script loaded but not executed.
            println!(
                "OK. loaded script ({} lines). Use --run to execute.",
                script.lines().count()
            );
        }

        return Ok(());
    }

    // ------------------------------------------------------------
    // Interactive mode:
    //
    // State:
    // - builder: current program buffer (PMS IR)
    // - last_tick/last_events: last executed kernel run results (for 'state', 'dump', 'ai_analyze last')
    // - svc/svc_events: vFS “service state” + separate service log (host-calls, non-timeline)
    //
    // v0 separation principle:
    // - Program timeline state is in builder and kernel runs.
    // - Service state is separate and persists across commands; it never touches builder.
    // ------------------------------------------------------------
    let mut builder = PmsBuilder::new();
    let mut last_tick: Option<u64> = None;
    let mut last_events: Vec<KernelEvent> = Vec::new();

    // C1-A: vFS host-call service state (persists across commands)
    //
    // Important:
    // - KernelState is reused as a convenient container for vFS nodes and its internal emit() logging.
    // - We DO NOT run kernel programs on `svc`; we only call fs_* APIs on it.
    // - Any events emitted by vFS ops are drained into svc_events to keep them separate from program events.
    let mut svc = KernelState::new();
    let mut svc_events: Vec<KernelEvent> = Vec::new();

    clear_screen_if_interactive()?;
    print_startup_screen(flag_validate, model_path.as_deref());

    // UX warning: validation ON but no model loaded => user will hit an error at run/ai_compile time.
    // We warn immediately to reduce confusion.
    if flag_validate && model.is_none() {
        println!(
            "Warning: Validation is ON but no model is loaded. Use: model <path> (or restart with --model <path>)."
        );
    }

    // ------------------------------------------------------------
    // REPL loop:
    // - Prompt, read line, trim.
    // - Match “service commands” first where appropriate (but note: in this code, the service command
    //   check happens AFTER the command dispatch block; see below).
    //
    // v0 note:
    // - This REPL uses a two-phase dispatch:
    //   1) handle built-in REPL meta-commands (help/run/status/model/validate/dump/ai_*)
    //   2) try vFS host-call commands (fs_*)
    //   3) otherwise treat as DSL opcode line (apply_line)
    //
    // This preserves the separation: only apply_line mutates builder.
    // ------------------------------------------------------------
    loop {
        print!("pms> ");
        io::stdout().flush().map_err(|e| e.to_string())?;

        let mut line = String::new();
        if io::stdin()
            .read_line(&mut line)
            .map_err(|e| e.to_string())?
            == 0
        {
            // EOF in interactive mode: exit cleanly.
            println!();
            break;
        }

        let line = line.trim();
        if line.is_empty() {
            continue;
        }

        // ------------------------------------------------------------
        // Built-in REPL commands (control plane).
        //
        // These do NOT go into the program buffer.
        // They mutate REPL state, model state, or call the kernel/AI bridge.
        // ------------------------------------------------------------
        match line {
            "help" => {
                print_help();
                continue;
            }

            "clear" => {
                // Reset the program buffer (and builder entity map).
                // Does NOT affect vFS service state.
                builder = PmsBuilder::new();
                println!("OK. program cleared.");
                continue;
            }

            "show" => {
                println!("{}", show_program_text(builder.program()));
                continue;
            }

            "show json" => {
                println!("{}", show_program_json(builder.program()));
                continue;
            }

            "state" => {
                // Print last run kernel output, if any.
                match last_tick {
                    Some(t) => {
                        println!("last tick={}", t);
                        print_events(&last_events);
                    }
                    None => println!("No state yet. Run a program first."),
                }
                continue;
            }

            "run" => {
                // Execute the currently buffered program.
                //
                // Important:
                // - run_program drains builder.take_program().
                // - So after a successful or failed run, the buffer is empty (because it was taken).
                //   *This is intended behavior for v0.* It prevents accidental re-running.
                //
                // Error handling:
                // - Errors are printed and REPL continues.
                match run_program_outcome(&mut builder, model.as_ref(), flag_validate) {
                    RunOutcome::Ok { tick, events } => {
                        println!("OK. tick={}", tick);
                        last_tick = Some(tick);
                        last_events = events.clone();
                        print_events(&events);

                        // Optional post-run dump if --dump was set at startup.
                        // This is a convenience “auto dump after every run”.
                        if let Some(p) = dump_path.as_deref() {
                            if let Err(e) = dump_events_jsonl(p, &events) {
                                println!("Error: {}", e);
                            } else {
                                println!("OK. dumped JSONL: {}", p);
                            }
                        }
                    }
                    RunOutcome::Err {
                        tick,
                        events,
                        error,
                    } => {
                        // v0.1: keep partials as last_* so `dump` works after failures (fixtureable G3/G4).
                        last_tick = Some(tick);
                        last_events = events.clone();

                        println!("Error: {}", error);

                        // Optional: print partial events if any were produced before the failure.
                        if !events.is_empty() {
                            print_events(&events);
                        }

                        // Optional post-run dump if --dump was set at startup.
                        // This is a convenience “auto dump after every run”.
                        if let Some(p) = dump_path.as_deref() {
                            if let Err(e) = dump_events_jsonl(p, &events) {
                                println!("Error: {}", e);
                            } else {
                                println!("OK. dumped JSONL: {}", p);
                            }
                        }
                    }
                }
                continue;
            }

            "status" => {
                // Report current validation config and model status.
                println!("Validation: {}", if flag_validate { "ON" } else { "OFF" });
                println!("Model: {}", model_path.as_deref().unwrap_or("<none>"));
                match model.as_ref() {
                    None => println!("Model status: <none>"),
                    Some(m) if m.is_empty() => {
                        println!("Model status: loaded but EMPTY (open-world)")
                    }
                    Some(_) => println!("Model status: loaded"),
                }
                continue;
            }

            // validate on|off toggling at runtime.
            line if line.starts_with("validate ") => {
                let arg = line["validate ".len()..].trim();
                match arg {
                    "on" => {
                        flag_validate = true;
                        println!("OK. Validation: ON");
                        if model.is_none() {
                            println!(
                                "Warning: Validation is ON but no model is loaded. Use: model <path>."
                            );
                        }
                    }
                    "off" => {
                        flag_validate = false;
                        println!("OK. Validation: OFF");
                    }
                    _ => {
                        println!("Error: validate expects: validate on|off");
                    }
                }
                continue;
            }

            // Load model during session.
            //
            // Policy:
            // - Replaces current model (model_path + model).
            // - Prints a warning if dependency table is empty (open-world).
            line if line.starts_with("model ") => {
                let p = line["model ".len()..].trim();
                if p.is_empty() {
                    println!("Error: model requires a path: model <path>");
                    continue;
                }

                match PmsModel::load_from_file(p) {
                    Ok(m) => {
                        model_path = Some(p.to_string());
                        model = Some(m);

                        if let Some(mm) = model.as_ref()
                            && mm.is_empty()
                        {
                            println!(
                                "Warning: Model loaded but dependency table is empty -> validation is open-world for known ops."
                            );
                        }

                        println!("OK. Model loaded: {}", p);
                        if flag_validate {
                            println!("Validation: ON");
                        }
                    }
                    Err(e) => {
                        println!("Error: failed to load model: {}", e);
                    }
                }
                continue;
            }

            // Dump last run events on-demand (independent of startup --dump).
            line if line.starts_with("dump ") => {
                let p = line["dump ".len()..].trim();
                if p.is_empty() {
                    println!("Error: dump requires a path: dump <path>");
                    continue;
                }

                if last_tick.is_none() {
                    println!("No state yet. Run a program first.");
                    continue;
                }

                match dump_events_jsonl(p, &last_events) {
                    Ok(()) => println!("OK. dumped JSONL: {}", p),
                    Err(e) => println!("Error: {}", e),
                }
                continue;
            }

            // ------------------------------------------------------------
            // ai_ping:
            // - Checks whether the configured AI backend is reachable.
            // - Does not send trace data or user scenario text.
            // ------------------------------------------------------------
            "ai_ping" => {
                let bridge = match pms_ai_bridge::AiBridge::from_env() {
                    Ok(b) => b,
                    Err(e) => {
                        println!("Error: ai bridge init failed: {}", e);
                        continue;
                    }
                };

                match bridge.ping() {
                    Ok(()) => println!("OK. AI backend reachable."),
                    Err(e) => println!("Error: ai ping failed: {}", e),
                }

                continue;
            }

            // ------------------------------------------------------------
            // ai_analyze:
            // - "ai_analyze last": analyze last_events (from last run).
            // - "ai_analyze <path.jsonl>": load JSONL and analyze it.
            //
            // Host-side safety:
            // - Uses ai-bridge analyze_trace strict envelope.
            // - Prints warnings and fails closed on ok=false.
            // ------------------------------------------------------------
            line if line.starts_with("ai_analyze ") => {
                let arg = line["ai_analyze ".len()..].trim();

                // Gather events input for the AI.
                let events: Vec<pms_ai_bridge::KernelEventLite> = if arg == "last" {
                    if last_tick.is_none() {
                        println!("No state yet. Run a program first.");
                        continue;
                    }

                    // Convert KernelEvent -> KernelEventLite:
                    // - op becomes canonical model_key string.
                    // - meta is forwarded if present (future-proof; dump currently omits it).
                    last_events
                        .iter()
                        .map(|e| pms_ai_bridge::KernelEventLite {
                            tick: e.tick,
                            op: e.op.model_key().to_string(),
                            msg: e.msg.clone(),
                            meta: e.meta.as_ref().map(|m| pms_ai_bridge::KernelEventMetaLite {
                                kind: m.kind.clone(),
                                kv: m.kv.clone(),
                            }),
                        })
                        .collect()
                } else {
                    // Load from JSONL file (dump format).
                    match load_events_jsonl(arg) {
                        Ok(ev) => ev,
                        Err(e) => {
                            println!("Error: {}", e);
                            continue;
                        }
                    }
                };

                // Build analyze_trace request.
                // - context and snapshot are optional; v0 doesn’t send them.
                let req = pms_ai_bridge::AiRequest {
                    task: "analyze_trace".to_string(),
                    version: "pms-1.0".to_string(),
                    pms_meta: serde_json::json!({ "model": "PMS_STACK", "schema_version": "1.1" }),
                    input: pms_ai_bridge::AiInput::AnalyzeTrace(
                        pms_ai_bridge::AiInputAnalyzeTrace {
                            context: None,
                            events,
                            snapshot: None,
                        },
                    ),
                    options: pms_ai_bridge::AiOptions {
                        language: "en".to_string(),
                        max_tokens: 700,
                    },
                };

                // Initialize bridge from env:
                // - PMS_AI_ENDPOINT / PMS_AI_MODEL or defaults.
                let bridge = match pms_ai_bridge::AiBridge::from_env() {
                    Ok(b) => b,
                    Err(e) => {
                        println!("Error: ai bridge init failed: {}", e);
                        continue;
                    }
                };

                // Execute call and render response.
                match bridge.analyze_trace(&req) {
                    Ok(r) => {
                        // Fail-closed on ok=false.
                        if !r.ok {
                            let code = r
                                .error
                                .as_ref()
                                .map(|e| e.code.as_str())
                                .unwrap_or("unknown");
                            let msg = r
                                .error
                                .as_ref()
                                .map(|e| e.message.as_str())
                                .unwrap_or("<no message>");
                            println!("AI: ok=false code={} message={}", code, msg);

                            // Always print warnings (even on failure).
                            for w in &r.warnings {
                                println!("AI warning: {}", w);
                            }
                            continue;
                        }

                        // ok=true requires a result.
                        // If result is missing, treat as a soft failure and show warnings.
                        let res_any = match r.result {
                            Some(x) => x,
                            None => {
                                println!("AI: ok=true but result=null");
                                for w in &r.warnings {
                                    println!("AI warning: {}", w);
                                }
                                continue;
                            }
                        };

                        // Task-specific result shape.
                        match res_any {
                            pms_ai_bridge::AiResult::Analyze(res) => {
                                println!("AI: {}", res.text);

                                if !res.findings.is_empty() {
                                    println!("Findings:");
                                    for f in res.findings {
                                        println!("  - {}", f);
                                    }
                                }

                                if !res.tags.is_empty() {
                                    println!("Tags: {:?}", res.tags);
                                }
                            }

                            pms_ai_bridge::AiResult::Compile(_res) => {
                                // Should not happen for ai_analyze.
                                // Treat as fail-close-ish UX: do not attempt to interpret compile output here.
                                println!(
                                    "AI: ok=true but result was compile_scenario (unexpected for ai_analyze)"
                                );
                            }
                        }

                        // Print warnings after the main output as well (consistent behavior).
                        for w in &r.warnings {
                            println!("AI warning: {}", w);
                        }
                    }
                    Err(e) => println!("Error: ai call failed: {}", e),
                }

                continue;
            }

            // ------------------------------------------------------------
            // ai_compile:
            // - Calls AI compile_scenario, maps opcodes -> builder, validates (optional),
            //   and replaces the current buffer only on full success.
            //
            // Safety:
            // - repl_ai_compile_with_call implements atomic-ish buffer replacement and fail-closed behavior.
            // ------------------------------------------------------------
            line if line.starts_with("ai_compile ") => {
                let raw_desc = line["ai_compile ".len()..].trim();

                let (dry_run, show_json, desc) = match parse_ai_compile_flags(raw_desc) {
                    Ok(x) => x,
                    Err(e) => {
                        println!("Error: {}", e);
                        continue;
                    }
                };

                if desc.is_empty() {
                    match (dry_run, show_json) {
                        (true, true) => println!(
                            "Error: ai_compile --dry-run --show-json requires: ai_compile --dry-run --show-json <desc...>"
                        ),
                        (true, false) => println!(
                            "Error: ai_compile --dry-run requires: ai_compile --dry-run <desc...>"
                        ),
                        (false, true) => println!(
                            "Error: ai_compile --show-json requires: ai_compile --show-json <desc...>"
                        ),
                        (false, false) => {
                            println!("Error: ai_compile requires: ai_compile <desc...>");
                        }
                    }
                    continue;
                }

                let bridge = match pms_ai_bridge::AiBridge::from_env() {
                    Ok(b) => b,
                    Err(e) => {
                        println!("Error: ai bridge init failed: {}", e);
                        continue;
                    }
                };

                // Compile using injected call closure (bridge.compile_scenario).
                let result = if dry_run {
                    repl_ai_compile_dry_run_with_call(
                        &mut builder,
                        model.as_ref(),
                        flag_validate,
                        desc,
                        |req| bridge.compile_scenario(req).map_err(|e| e.to_string()),
                    )
                } else {
                    repl_ai_compile_with_call(
                        &mut builder,
                        model.as_ref(),
                        flag_validate,
                        desc,
                        |req| bridge.compile_scenario(req).map_err(|e| e.to_string()),
                    )
                };

                match result {
                    Ok(out) => {
                        // Print the opcodes returned (debug-friendly).
                        // Note:
                        // - params prints as JSON Value; this is helpful for inspecting what the model produced.
                        println!("AI compile: {} opcode(s)", out.compile.opcodes.len());
                        for (i, o) in out.compile.opcodes.iter().enumerate() {
                            println!("  {:02}: op={} params={}", i, o.op, o.params);
                        }

                        if show_json {
                            println!("{}", ai_compile_out_json(&out));
                        }

                        // Always surface warnings.
                        for w in &out.warnings {
                            println!("AI warning: {}", w);
                        }

                        if dry_run {
                            println!("OK. dry-run succeeded. Buffer unchanged.");
                        } else {
                            println!("OK. compiled program loaded into buffer. Use: run");
                        }
                    }
                    Err(e) => println!("Error: {}", e),
                }

                continue;
            }

            // Exit commands.
            "quit" | "exit" => break,

            // Any other line falls through to:
            // - fs_* service handler
            // - or DSL apply_line
            _ => {}
        }

        // ------------------------------------------------------------
        // C1-A: vFS host-calls (service mode)
        //
        // Behavior:
        // - handle_fs_service_line mutates svc state and drains svc.events into svc_events.
        // - If handled (Ok(true)): do NOT fall through to apply_line.
        // - If not handled (Ok(false)): treat as DSL and append to program buffer.
        // - If error: print and continue.
        // ------------------------------------------------------------
        match handle_fs_service_line(&mut svc, &mut svc_events, line) {
            Ok(true) => continue, // handled
            Ok(false) => {}       // not an fs_* command; fall through
            Err(e) => {
                println!("Error: {}", e);
                continue;
            }
        }

        // ------------------------------------------------------------
        // DSL line:
        // - apply_line mutates the program buffer via PmsBuilder.
        // - On success: prints "OK." (simple interactive feedback).
        // ------------------------------------------------------------
        match apply_line(&mut builder, line) {
            Ok(()) => println!("OK."),
            Err(e) => println!("{} (Type 'help'.)", e),
        }
    }

    // ------------------------------------------------------------
    // Exit handling: optional vFS service log dump.
    //
    // Rationale:
    // - In interactive mode, users might want the service log even if they never call fs_dump manually.
    // - dump_fs_path comes from --dump-fs at startup.
    // ------------------------------------------------------------
    if let Some(p) = dump_fs_path.as_deref() {
        if let Err(e) = dump_events_jsonl(p, &svc_events) {
            println!("Error: {}", e);
        } else {
            println!("OK. dumped vFS JSONL: {}", p);
        }
    }

    Ok(())
}

// Test module wiring (compilation + unit tests).
//
// The tests referenced here are intended as regression guards for:
// - rest-of-line parsing
// - validation UX
// - frames push-only semantics
// - vFS host-call behavior and dumps
// - ai_compile mapping + REPL integration
#[cfg(test)]
mod testmods {
    mod a3_restofline;
    mod a4_frames_push_only;
    mod b1_validation_ux;
    mod b2_show_buffer;
    mod c1_fs_hostcalls;
    mod c2_dump_jsonl;
    mod c3_dump_fs_jsonl;
    mod c3_fs_clear_events;
    mod f1_ai_compile_mapper;
    mod f2_ai_compile_repl;
    mod golden;
}
