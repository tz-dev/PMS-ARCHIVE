use crate::*;
use pms_kernel::{KernelEvent, KernelState};

#[test]
fn c1_repl_fs_commands_are_not_part_of_dsl_apply_line() {
    let mut builder = pms_ir::PmsBuilder::new();

    // fs_* lines must NOT be accepted by the DSL parser
    assert!(apply_line(&mut builder, "fs_create /a.txt").is_err());
    assert!(apply_line(&mut builder, "fs_write /a.txt hello").is_err());
    assert!(apply_line(&mut builder, "fs_read /a.txt").is_err());
    assert!(apply_line(&mut builder, "fs_delete /a.txt").is_err());
}

#[test]
fn c1_repl_fs_hostcalls_do_not_modify_program_timeline() {
    let mut svc = KernelState::new();
    let mut svc_events: Vec<KernelEvent> = Vec::new();

    // Run host-calls
    handle_fs_service_line(&mut svc, &mut svc_events, "fs_create /a.txt").unwrap();
    handle_fs_service_line(&mut svc, &mut svc_events, "fs_write /a.txt hello").unwrap();
    handle_fs_service_line(&mut svc, &mut svc_events, "fs_read /a.txt").unwrap();

    // Host-calls should not touch any "program" state (builder is separate),
    // but they should have created service events.
    assert!(!svc_events.is_empty());
}

#[test]
fn c1_repl_fs_delete_is_service_only() {
    let mut svc = KernelState::new();
    let mut svc_events: Vec<KernelEvent> = Vec::new();

    handle_fs_service_line(&mut svc, &mut svc_events, "fs_create /a.txt").unwrap();
    handle_fs_service_line(&mut svc, &mut svc_events, "fs_delete /a.txt").unwrap();

    let names = svc.fs_list_dir("/").unwrap();
    assert_eq!(names, Vec::<String>::new());

    assert!(
        svc_events
            .iter()
            .any(|e| e.msg.starts_with("fs_delete path=/a.txt")),
        "expected fs_delete service event, got: {:?}",
        svc_events
    );
}

#[test]
fn c1_script_rejects_fs_service_commands_with_actionable_error() {
    let err = reject_service_command_in_script("  fs_write /a.txt hello", 7).unwrap_err();

    assert!(err.contains("Script error on line 7"), "err={}", err);
    assert!(
        err.contains("fs_* service commands are not supported in scripts"),
        "err={}",
        err
    );
    assert!(err.contains(">>   fs_write /a.txt hello"), "err={}", err);
}

#[test]
fn c1_script_service_rejector_allows_regular_dsl_and_comments() {
    assert!(reject_service_command_in_script("frame ctx", 1).is_ok());
    assert!(reject_service_command_in_script("  omega a b 1.0 edge", 2).is_ok());
    assert!(reject_service_command_in_script("# fs_write /a.txt hello", 3).is_ok());
    assert!(reject_service_command_in_script("", 4).is_ok());
}
