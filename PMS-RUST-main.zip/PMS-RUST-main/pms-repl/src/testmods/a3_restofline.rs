use crate::apply_line;
use pms_ir::PmsBuilder;
use pms_kernel::{OpParams, Operator};

#[test]
fn repl_integrate_allows_spaces_in_note() {
    let mut b = PmsBuilder::new();
    apply_line(&mut b, "frame training").unwrap();
    apply_line(&mut b, "integrate this is a note").unwrap();

    let program = b.finish();
    let last = program.last().unwrap();
    assert_eq!(last.op, Operator::Sigma);
    match &last.params {
        OpParams::Integrate { note } => assert_eq!(note, "this is a note"),
        other => panic!("expected Integrate, got {:?}", other),
    }
}

#[test]
fn repl_psi_allows_spaces_in_note() {
    let mut b = PmsBuilder::new();
    apply_line(&mut b, "psi commit with spaces").unwrap();

    let program = b.finish();
    let last = program.last().unwrap();
    assert_eq!(last.op, Operator::Psi);
    match &last.params {
        OpParams::Commit { note } => assert_eq!(note, "commit with spaces"),
        other => panic!("expected Commit, got {:?}", other),
    }
}

#[test]
fn repl_expect_allows_spaces_in_desc() {
    let mut b = PmsBuilder::new();
    apply_line(&mut b, "expect 3 needs more words here").unwrap();

    let program = b.finish();
    let last = program.last().unwrap();
    assert_eq!(last.op, Operator::Lambda);
    match &last.params {
        OpParams::Expectation { horizon, desc } => {
            assert_eq!(*horizon, 3);
            assert_eq!(desc, "needs more words here");
        }
        other => panic!("expected Expectation, got {:?}", other),
    }
}

#[test]
fn repl_impulse_allows_spaces_in_desc() {
    let mut b = PmsBuilder::new();
    apply_line(&mut b, "frame training").unwrap();
    apply_line(&mut b, "impulse agent 0.5 something with spaces").unwrap();

    let program = b.finish();
    let last = program.last().unwrap();
    assert_eq!(last.op, Operator::Nabla);
    match &last.params {
        OpParams::Impulse {
            entity,
            intensity,
            desc,
        } => {
            assert_eq!(entity, "agent");
            assert!((*intensity - 0.5).abs() < 1e-6);
            assert_eq!(desc, "something with spaces");
        }
        other => panic!("expected Impulse, got {:?}", other),
    }
}

#[test]
fn repl_omega_allows_spaces_in_desc() {
    let mut b = PmsBuilder::new();
    apply_line(&mut b, "frame training").unwrap();
    apply_line(&mut b, "omega a b 0.7 power imbalance described").unwrap();

    let program = b.finish();
    let last = program.last().unwrap();
    assert_eq!(last.op, Operator::Omega);
    match &last.params {
        OpParams::Asymmetry {
            from,
            to,
            weight,
            desc,
        } => {
            assert_eq!(from, "a");
            assert_eq!(to, "b");
            assert!((*weight - 0.7).abs() < 1e-6);
            assert_eq!(desc, "power imbalance described");
        }
        other => panic!("expected Asymmetry, got {:?}", other),
    }
}
