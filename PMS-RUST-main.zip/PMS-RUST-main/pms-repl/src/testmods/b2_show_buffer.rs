use crate::*;
use pms_ir::PmsBuilder;

#[test]
fn b2_show_text_lists_buffer_without_draining() {
    let mut builder = PmsBuilder::new();

    apply_line(&mut builder, "frame ctx").unwrap();
    apply_line(&mut builder, "impulse agent 0.75 observed movement").unwrap();
    apply_line(&mut builder, "psi done").unwrap();

    let text = show_program_text(builder.program());

    assert!(text.contains("0: Frame kind=\"ctx\""), "text={}", text);
    assert!(
        text.contains("1: Nabla entity=\"agent\" intensity=0.75 desc=\"observed movement\""),
        "text={}",
        text
    );
    assert!(text.contains("2: Psi note=\"done\""), "text={}", text);

    assert_eq!(builder.len(), 3, "show must not drain the buffer");
}

#[test]
fn b2_show_json_is_valid_json_and_lists_buffer() {
    let mut builder = PmsBuilder::new();

    apply_line(&mut builder, "entity agent").unwrap();
    apply_line(&mut builder, "frame ctx").unwrap();
    apply_line(&mut builder, "theta 3").unwrap();

    let raw = show_program_json(builder.program());
    let v: serde_json::Value = serde_json::from_str(&raw).expect("show json must be valid JSON");

    let arr = v.as_array().expect("show json must be an array");
    assert_eq!(arr.len(), 3);

    assert_eq!(arr[0]["idx"], 0);
    assert_eq!(arr[0]["op"], "Delta");
    assert_eq!(arr[0]["params"]["name"], "agent");

    assert_eq!(arr[1]["idx"], 1);
    assert_eq!(arr[1]["op"], "Frame");
    assert_eq!(arr[1]["params"]["kind"], "ctx");

    assert_eq!(arr[2]["idx"], 2);
    assert_eq!(arr[2]["op"], "Theta");
    assert_eq!(arr[2]["params"]["dt"], 3);

    assert_eq!(builder.len(), 3, "show json must not drain the buffer");
}

#[test]
fn b2_show_is_empty_after_run_drains_buffer() {
    let mut builder = PmsBuilder::new();

    apply_line(&mut builder, "frame ctx").unwrap();
    apply_line(&mut builder, "psi done").unwrap();

    assert!(!builder.is_empty());

    let out = run_program_outcome(&mut builder, None, false);
    assert!(matches!(out, RunOutcome::Ok { .. }));

    assert!(builder.is_empty());
    assert_eq!(show_program_text(builder.program()), "<empty>");
    assert_eq!(show_program_json(builder.program()), "[]");
}
