use crate::*;
use pms_ir::PmsBuilder;
use pms_kernel::Operator;

#[test]
fn a4_frames_push_only_current_is_last() {
    let mut b = PmsBuilder::new();

    // push A then B
    apply_line(&mut b, "frame A").unwrap();
    apply_line(&mut b, "frame B").unwrap();

    // run without validation/model needed
    let (_tick, events) = run_program(&mut b, None, false).unwrap();

    // collect all Frame events
    let frames: Vec<_> = events.iter().filter(|e| e.op == Operator::Frame).collect();

    // exactly two frames must have been pushed
    assert_eq!(
        frames.len(),
        2,
        "expected exactly 2 frame events, got {}",
        frames.len()
    );

    // the last pushed frame must be B
    assert!(
        frames[1].msg.contains("kind=B"),
        "expected last frame to be B, got msg={}",
        frames[1].msg
    );
}
