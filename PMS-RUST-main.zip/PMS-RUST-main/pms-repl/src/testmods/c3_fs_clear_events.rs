use crate::*;
use pms_kernel::{KernelEvent, KernelState};

#[test]
fn c3_fs_clear_events_only_clears_service_log_not_state() {
    let mut svc = KernelState::new();
    let mut svc_events: Vec<KernelEvent> = Vec::new();

    handle_fs_service_line(&mut svc, &mut svc_events, "fs_create /a.txt").unwrap();
    handle_fs_service_line(&mut svc, &mut svc_events, "fs_write /a.txt hello").unwrap();

    assert!(
        !svc_events.is_empty(),
        "expected service events to exist before clearing"
    );

    handle_fs_service_line(&mut svc, &mut svc_events, "fs_clear_events").unwrap();

    assert!(
        svc_events.is_empty(),
        "fs_clear_events must clear only the service event log"
    );

    // Ensure internal vFS state remains intact
    let bytes = svc.fs_read_file("/a.txt").unwrap();
    assert_eq!(String::from_utf8_lossy(&bytes), "hello");
}
