use pms_ai_bridge::{
    AiBridge, AiInput, AiInputAnalyzeTrace, AiOptions, AiRequest, AiResult, KernelEventLite,
};
use pms_ir::PmsBuilder;
use pms_kernel::KernelEvent;
use std::env;
use std::path::{Path, PathBuf};

fn repo_root() -> PathBuf {
    // CARGO_MANIFEST_DIR = .../project files/pms-repl
    Path::new(env!("CARGO_MANIFEST_DIR")).join("..")
}

fn golden_fixtures_dir() -> PathBuf {
    repo_root().join("pms-docs").join("golden").join("fixtures")
}

fn golden_scripts_dir() -> PathBuf {
    repo_root().join("pms-docs").join("golden").join("scripts")
}

fn fixture_path(name: &str) -> PathBuf {
    golden_fixtures_dir().join(format!("{}.events.jsonl", name))
}

fn script_path(name: &str) -> PathBuf {
    golden_scripts_dir().join(format!("{}.pms", name))
}

fn temp_jsonl_path(name: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!(
        "pms_repl_golden_{}_{}_{}.jsonl",
        name,
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    p
}

use serde::Deserialize;
use std::fs;

#[derive(Debug, Clone, Deserialize, PartialEq, Eq)]
struct DumpEvent {
    tick: u64,
    op: String,
    msg: String,
    #[serde(default)]
    meta: Option<serde_json::Value>, // forward-compatible
}

fn load_events_jsonl(path: &Path) -> Result<Vec<DumpEvent>, String> {
    let s = fs::read_to_string(path)
        .map_err(|e| format!("load_events_jsonl: cannot read {}: {}", path.display(), e))?;

    let mut out = Vec::new();
    for (i, line) in s.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        let ev: DumpEvent = serde_json::from_str(line).map_err(|e| {
            format!(
                "load_events_jsonl: {} line {}: {}",
                path.display(),
                i + 1,
                e
            )
        })?;
        out.push(ev);
    }
    Ok(out)
}

#[derive(Debug, Clone, Deserialize)]
struct AiLooseSpec {
    required_tags_any: Vec<String>,
    required_findings_substrings: Vec<String>,
    forbidden_substrings: Vec<String>,
    #[serde(default)]
    required_literals: Vec<String>,
}

fn ai_spec_path(name: &str) -> PathBuf {
    repo_root()
        .join("pms-docs")
        .join("golden")
        .join("spec")
        .join(format!("{}.ai.json", name))
}

fn load_ai_spec(path: &Path) -> Result<AiLooseSpec, String> {
    let s = fs::read_to_string(path)
        .map_err(|e| format!("load_ai_spec: cannot read {}: {}", path.display(), e))?;
    serde_json::from_str(&s)
        .map_err(|e| format!("load_ai_spec: invalid json {}: {}", path.display(), e))
}

fn lower(s: &str) -> String {
    s.to_ascii_lowercase()
}

fn contains_ci(hay: &str, needle: &str) -> bool {
    lower(hay).contains(&lower(needle))
}

fn any_alt_contains_ci(hay: &str, need: &str) -> bool {
    // supports "a|b|c" meaning OR
    for alt in need.split('|').map(|s| s.trim()).filter(|s| !s.is_empty()) {
        if contains_ci(hay, alt) {
            return true;
        }
    }
    false
}

fn any_alt_in_list_contains_ci(list_lc: &[String], need: &str) -> bool {
    // supports "a|b|c" meaning OR against list items (already lowercased outside or not)
    let need_lc = lower(need);
    for alt in need_lc
        .split('|')
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
    {
        if list_lc.iter().any(|t| t.contains(alt)) {
            return true;
        }
    }
    false
}

fn join_text_and_findings(text: &str, findings: &[String]) -> String {
    let mut s = String::new();
    s.push_str(text);
    s.push('\n');
    for f in findings {
        s.push_str(f);
        s.push('\n');
    }
    s
}

fn dump_events_to_ai_events(events: Vec<DumpEvent>) -> Vec<KernelEventLite> {
    events
        .into_iter()
        .map(|e| KernelEventLite {
            tick: e.tick,
            op: e.op,
            msg: e.msg,
            meta: None, // fixture v0 schema has no meta; forward-compat ok
        })
        .collect()
}

fn load_script_text(path: &Path) -> Result<String, String> {
    fs::read_to_string(path)
        .map_err(|e| format!("load_script_text: cannot read {}: {}", path.display(), e))
}

fn apply_script_into_builder(builder: &mut PmsBuilder, script: &str) -> Result<(), String> {
    for (idx, raw) in script.lines().enumerate() {
        // IMPORTANT: use the REPL's real DSL parser (apply_line) to avoid divergence.
        if let Err(e) = super::super::apply_line(builder, raw) {
            return Err(format!(
                "script apply error on line {}: {}\n  >> {}",
                idx + 1,
                e,
                raw
            ));
        }
    }
    Ok(())
}

fn normalize_jsonl_text(s: &str) -> String {
    // minimal normalization for Windows line endings
    s.replace("\r\n", "\n")
}

fn dump_events_jsonl_string(events: &[DumpEvent]) -> String {
    // deterministic: one JSON object per line, trailing newline
    let mut s = String::new();
    for ev in events {
        let line = format!(
            "{{\"tick\":{},\"op\":{},\"msg\":{}}}\n",
            ev.tick,
            serde_json::to_string(&ev.op).unwrap(),
            serde_json::to_string(&ev.msg).unwrap()
        );
        s.push_str(&line);
    }
    s
}

fn map_kernel_events_to_dump(events: Vec<KernelEvent>) -> Vec<DumpEvent> {
    events
        .into_iter()
        .map(|e| DumpEvent {
            tick: e.tick,
            op: e.op.model_key().to_string(), // runtime key string (matches dump schema)
            msg: e.msg,
            meta: None, // REPL dump currently omits meta; fixtures are v0 schema
        })
        .collect()
}

#[test]
fn golden_fixture_roundtrip_load_dump_preserves_events() {
    let cases = [
        "g1_non_event",
        "g2_integrate_consumes",
        "g3_commit_seals_frame",
        "g4_commit_seals_isolation",
        "g5_min_timeline",
    ];

    for c in cases {
        let p = fixture_path(c);
        let loaded = load_events_jsonl(&p).expect("fixture load failed");

        let redumped = dump_events_jsonl_string(&loaded);

        let original = std::fs::read_to_string(&p).expect("fixture read failed");
        assert_eq!(
            normalize_jsonl_text(&original),
            normalize_jsonl_text(&redumped),
            "roundtrip mismatch for {}",
            c
        );
    }
}

const GOLDEN_CASES: [(&str, bool); 5] = [
    ("g1_non_event", true),
    ("g2_integrate_consumes", true),
    ("g3_commit_seals_frame", false),
    ("g4_commit_seals_isolation", false),
    ("g5_min_timeline", true),
];

#[test]
fn golden_kernel_run_matches_fixture_g1_to_g5() {
    for (name, should_succeed) in GOLDEN_CASES {
        let sp = script_path(name);
        let fp = fixture_path(name);

        let script = load_script_text(&sp).expect("script read failed");

        let mut b = PmsBuilder::new();
        apply_script_into_builder(&mut b, &script).expect("script apply failed");

        // v0 golden harness: validation OFF.
        // We are testing kernel runtime + guards, not model validation.
        let outcome = super::super::run_program_outcome(&mut b, None, false);

        let (ok, events) = match outcome {
            super::super::RunOutcome::Ok { tick: _, events } => (true, events),
            super::super::RunOutcome::Err {
                tick: _,
                events,
                error: _,
            } => (false, events),
        };

        assert_eq!(
            ok, should_succeed,
            "golden case {}: success mismatch (ok={}, expected={})",
            name, ok, should_succeed
        );

        // Compare produced events to fixture.
        let got = dump_events_jsonl_string(&map_kernel_events_to_dump(events));
        let expected = fs::read_to_string(&fp).expect("fixture read failed");

        assert_eq!(
            normalize_jsonl_text(&expected),
            normalize_jsonl_text(&got),
            "golden case {}: events mismatch",
            name
        );
    }
}

#[test]
fn golden_generated_jsonl_uses_current_schema_and_roundtrips_g1_to_g5() {
    for (name, _should_succeed) in GOLDEN_CASES {
        let sp = script_path(name);
        let script = load_script_text(&sp).expect("script read failed");

        let mut b = PmsBuilder::new();
        apply_script_into_builder(&mut b, &script).expect("script apply failed");

        // Golden harness: validation OFF.
        // We are testing current JSONL dump/load behavior for produced kernel events.
        let outcome = super::super::run_program_outcome(&mut b, None, false);

        let events = match outcome {
            super::super::RunOutcome::Ok { tick: _, events } => events,
            super::super::RunOutcome::Err {
                tick: _,
                events,
                error: _,
            } => events,
        };

        let path = temp_jsonl_path(name);
        let path_str = path.to_string_lossy().to_string();

        super::super::dump_events_jsonl(&path_str, &events)
            .unwrap_or_else(|e| panic!("dump_events_jsonl failed for {}: {}", name, e));

        let raw = fs::read_to_string(&path)
            .unwrap_or_else(|e| panic!("failed to read generated JSONL for {}: {}", name, e));

        let lines: Vec<&str> = raw.lines().filter(|l| !l.trim().is_empty()).collect();
        assert_eq!(
            lines.len(),
            events.len(),
            "generated JSONL line count mismatch for {}",
            name
        );

        for (i, line) in lines.iter().enumerate() {
            let v: serde_json::Value = serde_json::from_str(line).unwrap_or_else(|e| {
                panic!(
                    "generated JSONL for {} line {} must parse as JSON: {}\n{}",
                    name,
                    i + 1,
                    e,
                    line
                )
            });

            assert_eq!(
                v.get("schema").and_then(|x| x.as_str()),
                Some("pms.events.v0"),
                "generated JSONL for {} line {} must contain current schema",
                name,
                i + 1
            );

            assert!(
                v.get("meta").is_some(),
                "generated JSONL for {} line {} should export meta when KernelEvent.meta is present",
                name,
                i + 1
            );
        }

        let loaded = super::super::load_events_jsonl(&path_str)
            .unwrap_or_else(|e| panic!("load_events_jsonl failed for {}: {}", name, e));

        assert_eq!(
            loaded.len(),
            events.len(),
            "loaded event count mismatch for {}",
            name
        );

        for (i, (expected, got)) in events.iter().zip(loaded.iter()).enumerate() {
            assert_eq!(got.tick, expected.tick, "tick mismatch for {}[{}]", name, i);
            assert_eq!(
                got.op,
                expected.op.model_key(),
                "op mismatch for {}[{}]",
                name,
                i
            );
            assert_eq!(got.msg, expected.msg, "msg mismatch for {}[{}]", name, i);

            assert!(
                got.meta.is_some(),
                "meta should roundtrip for {}[{}]",
                name,
                i
            );
        }

        let _ = fs::remove_file(&path);
    }
}

#[test]
fn golden_ai_analyze_matches_loose_spec_g1_to_g5() {
    // Gate: this test MUST NOT run unless explicitly enabled.
    if env::var("PMS_GOLDEN_AI").ok().as_deref() != Some("1") {
        eprintln!(
            "skipping golden_ai_analyze_matches_loose_spec_g1_to_g5 (set PMS_GOLDEN_AI=1 to enable)"
        );
        return;
    }

    let bridge =
        AiBridge::from_env().expect("ai bridge init failed (check PMS_AI_ENDPOINT / PMS_AI_MODEL)");

    // --- SMOKE ---
    // Hard requirement: backend must be callable and must execute a real inference.
    {
        let smoke_req = AiRequest {
            task: "analyze_trace".to_string(),
            version: "pms-1.0".to_string(),
            pms_meta: serde_json::json!({
                "model": "PMS_STACK",
                "schema_version": "1.1",
                "required_literals": []
            }),
            input: AiInput::AnalyzeTrace(AiInputAnalyzeTrace {
                context: None,
                events: vec![KernelEventLite {
                    tick: 0,
                    op: "theta".to_string(),
                    msg: "advance dt=1".to_string(),
                    meta: None,
                }],
                snapshot: None,
            }),
            options: AiOptions {
                language: "en".to_string(),
                max_tokens: 2000,
            },
        };

        let smoke = bridge.analyze_trace(&smoke_req).unwrap_or_else(|e| {
            panic!(
                "PMS_GOLDEN_AI=1 but AI backend is not callable (analyze_trace failed): {}",
                e
            )
        });

        eprintln!("=== SMOKE RAW RESP === {:?}", smoke);

        assert!(
            smoke.ok,
            "PMS_GOLDEN_AI=1 but AI analyze_trace returned ok=false: {:?}",
            smoke.error
        );
    }

    // --- Run golden AI checks ---
    for (name, _should_succeed) in GOLDEN_CASES {
        let fixture = fixture_path(name);
        let specp = ai_spec_path(name);

        let fixture_events = load_events_jsonl(&fixture).expect("fixture load failed");
        let ai_events = dump_events_to_ai_events(fixture_events);

        let spec = load_ai_spec(&specp).expect("ai spec load failed");

        let req = AiRequest {
            task: "analyze_trace".to_string(),
            version: "pms-1.0".to_string(),
            pms_meta: serde_json::json!({
                "model": "PMS_STACK",
                "schema_version": "1.1",
                "required_literals": spec.required_literals.clone()
            }),
            input: AiInput::AnalyzeTrace(AiInputAnalyzeTrace {
                context: None,
                events: ai_events,
                snapshot: None,
            }),
            options: AiOptions {
                language: "en".to_string(),
                max_tokens: 2000,
            },
        };

        eprintln!("\n========================================");
        eprintln!("=== GOLDEN AI ANALYZE CASE: {} ===", name);
        eprintln!("========================================");

        if std::env::var("PMS_AI_DEBUG_RAW").ok().as_deref() == Some("1") {
            eprintln!("=== AIREQUEST (host -> bridge) BEGIN ===");
            eprintln!("{}", serde_json::to_string_pretty(&req).unwrap());
            eprintln!("=== AIREQUEST (host -> bridge) END ===");
        }

        let resp = bridge
            .analyze_trace(&req)
            .unwrap_or_else(|e| panic!("AI call failed for {}: {}", name, e));

        assert!(resp.ok, "AI ok=false for {}: {:?}", name, resp.error);

        let result = match resp.result {
            Some(AiResult::Analyze(r)) => r,
            other => panic!("AI returned non-analyze result for {}: {:?}", name, other),
        };

        // --- tags check (ANY) ---
        let tags_lc: Vec<String> = result.tags.iter().map(|t| lower(t)).collect();

        let mut tag_ok = false;
        for need in &spec.required_tags_any {
            if any_alt_in_list_contains_ci(&tags_lc, need) {
                tag_ok = true;
                break;
            }
        }

        assert!(
            tag_ok,
            "AI tags mismatch for {}: required_tags_any={:?}, got_tags={:?}",
            name, spec.required_tags_any, result.tags
        );

        // --- findings/text substring checks ---
        let combined = join_text_and_findings(&result.text, &result.findings);

        for need in &spec.required_findings_substrings {
            let ok = any_alt_contains_ci(&combined, need);

            assert!(
                ok,
                "AI missing required substring for {}: {:?}\n--- combined ---\n{}",
                name, need, combined
            );
        }

        for bad in &spec.forbidden_substrings {
            assert!(
                !contains_ci(&combined, bad),
                "AI contains forbidden substring for {}: {:?}\n--- combined ---\n{}",
                name,
                bad,
                combined
            );
        }
    }
}
