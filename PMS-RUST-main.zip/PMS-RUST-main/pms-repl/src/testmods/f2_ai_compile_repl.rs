use crate::*;

/// Helper: build a minimal successful compile response (no warnings)
fn ok_compile(opcodes: Vec<pms_ai_bridge::AiOpcodeSpec>) -> pms_ai_bridge::AiResponse {
    pms_ai_bridge::AiResponse {
        ok: true,
        task: pms_ai_bridge::TASK_COMPILE_SCENARIO.to_string(),
        result: Some(pms_ai_bridge::AiResult::Compile(
            pms_ai_bridge::AiCompileResult { opcodes },
        )),
        warnings: vec![],
        error: None,
    }
}

/// Helper: build a successful compile response with warnings
fn ok_compile_with_warnings(
    opcodes: Vec<pms_ai_bridge::AiOpcodeSpec>,
    warnings: Vec<&str>,
) -> pms_ai_bridge::AiResponse {
    pms_ai_bridge::AiResponse {
        ok: true,
        task: pms_ai_bridge::TASK_COMPILE_SCENARIO.to_string(),
        result: Some(pms_ai_bridge::AiResult::Compile(
            pms_ai_bridge::AiCompileResult { opcodes },
        )),
        warnings: warnings.into_iter().map(|s| s.to_string()).collect(),
        error: None,
    }
}

#[test]
fn f2_ai_compile_loads_buffer_when_validation_off() {
    // start with a non-empty buffer (so we can assert it gets replaced)
    let mut builder = PmsBuilder::new();
    builder.entity("preexisting");

    // fake compile output: Delta + Square + Psi
    let opcodes = vec![
        pms_ai_bridge::AiOpcodeSpec {
            op: "Delta".to_string(),
            params: serde_json::json!({ "name": "e1" }),
        },
        pms_ai_bridge::AiOpcodeSpec {
            op: "Square".to_string(),
            params: serde_json::json!({ "kind": "k" }),
        },
        pms_ai_bridge::AiOpcodeSpec {
            op: "Psi".to_string(),
            params: serde_json::json!({ "note": "done" }),
        },
    ];

    // IMPORTANT: clone, because the closure consumes the Vec
    let out = repl_ai_compile_with_call(
        &mut builder,
        None,
        false, // validation OFF
        "whatever scenario",
        |_req| Ok(ok_compile(opcodes.clone())),
    )
    .expect("ai_compile should succeed with validation off");

    assert_eq!(out.compile.opcodes.len(), 3);

    // buffer must now contain the compiled program, not the old one
    let program = builder.take_program();
    assert_eq!(
        program.len(),
        3,
        "buffer should be replaced by compiled program"
    );
}

#[test]
fn f2_ai_compile_does_not_replace_buffer_if_mapping_fails() {
    // existing buffer
    let mut builder = PmsBuilder::new();
    builder.entity("keepme");
    let before = builder.take_program().len();

    // put it back (so we can observe replacement behavior)
    builder = PmsBuilder::new();
    builder.entity("keepme");

    // invalid opcode: Omega missing desc -> mapper must fail
    let opcodes = vec![pms_ai_bridge::AiOpcodeSpec {
        op: "Omega".to_string(),
        params: serde_json::json!({ "from": "a", "to": "b", "weight": 1.0 }),
    }];

    let err = repl_ai_compile_with_call(&mut builder, None, false, "scenario", |_req| {
        Ok(ok_compile(opcodes))
    })
    .unwrap_err();

    assert!(err.contains("Omega"), "error should mention the failing op");
    assert!(err.contains("desc"), "error should mention missing desc");

    // buffer must remain unchanged (still has the original 'keepme' delta)
    let after_program = builder.take_program();
    assert_eq!(
        after_program.len(),
        before,
        "buffer must not be replaced on failure"
    );
}

#[test]
fn f2_ai_compile_preserves_warnings_in_response() {
    let mut builder = PmsBuilder::new();
    builder.entity("preexisting");

    let opcodes = vec![pms_ai_bridge::AiOpcodeSpec {
        op: "Delta".to_string(),
        params: serde_json::json!({ "name": "e1" }),
    }];

    let out = repl_ai_compile_with_call(&mut builder, None, false, "scenario", |_req| {
        Ok(ok_compile_with_warnings(
            opcodes.clone(),
            vec!["be careful"],
        ))
    })
    .expect("ai_compile should succeed");

    assert_eq!(out.warnings, vec!["be careful".to_string()]);
}
#[test]
fn f2_ai_compile_trace_chain_includes_bridge_call_fail_steps() {
    use crate::*;

    let mut builder = PmsBuilder::new();

    let err = repl_ai_compile_with_call(
        &mut builder,
        None,  // model
        false, // validate
        "do something",
        |_req| Err("network down".to_string()),
    )
    .unwrap_err();

    assert!(err.contains("ai_compile: bridge call failed"));
    assert!(err.contains("Trace:"));
    assert!(err.contains("repl.request_built"));
    assert!(err.contains("bridge.http_sent"));
}

#[test]
fn f2_ai_compile_trace_chain_includes_parse_ok_but_not_map_ok_on_mapping_fail() {
    use crate::*;

    let mut builder = PmsBuilder::new();

    // Valid envelope, but invalid opcode params for REPL mapping:
    // Omega requires params: from,to,weight,desc. We'll omit "desc" so mapping fails.
    let resp = pms_ai_bridge::AiResponse {
        ok: true,
        task: pms_ai_bridge::TASK_COMPILE_SCENARIO.to_string(),
        result: Some(pms_ai_bridge::AiResult::Compile(
            pms_ai_bridge::AiCompileResult {
                opcodes: vec![pms_ai_bridge::AiOpcodeSpec {
                    op: "Omega".to_string(),
                    params: serde_json::json!({
                        "from": "a",
                        "to": "b",
                        "weight": 1.0
                    }),
                }],
            },
        )),
        warnings: vec!["w1".to_string()],
        error: None,
    };

    let err = repl_ai_compile_with_call(
        &mut builder,
        None,  // model
        false, // validate
        "do something",
        |_req| Ok(resp),
    )
    .unwrap_err();

    assert!(err.contains("ai_compile: opcode mapping failed"));
    assert!(err.contains("Trace:"));
    assert!(err.contains("repl.request_built"));
    assert!(err.contains("bridge.http_sent"));
    assert!(err.contains("bridge.http_ok"));
    assert!(err.contains("bridge.parse_ok"));
    assert!(!err.contains("repl.map_ok"));
}

#[test]
fn f2_ai_compile_dry_run_does_not_replace_buffer() {
    let mut builder = PmsBuilder::new();
    builder.entity("keepme");

    let before = show_program_json(builder.program());

    let opcodes = vec![
        pms_ai_bridge::AiOpcodeSpec {
            op: "Delta".to_string(),
            params: serde_json::json!({ "name": "new_entity" }),
        },
        pms_ai_bridge::AiOpcodeSpec {
            op: "Square".to_string(),
            params: serde_json::json!({ "kind": "ctx" }),
        },
        pms_ai_bridge::AiOpcodeSpec {
            op: "Psi".to_string(),
            params: serde_json::json!({ "note": "done" }),
        },
    ];

    let out = repl_ai_compile_dry_run_with_call(
        &mut builder,
        None,
        false,
        "create a framed action and commit it",
        |_req| Ok(ok_compile(opcodes.clone())),
    )
    .expect("dry-run compile should succeed");

    assert_eq!(out.compile.opcodes.len(), 3);

    let after = show_program_json(builder.program());
    assert_eq!(after, before, "dry-run must not replace the buffer");

    let program = builder.take_program();
    assert_eq!(program.len(), 1);
    assert_eq!(program[0].op.model_key(), "Delta");
}

#[test]
fn f2_ai_compile_dry_run_still_fails_mapping_errors() {
    let mut builder = PmsBuilder::new();
    builder.entity("keepme");

    let before = show_program_json(builder.program());

    let opcodes = vec![pms_ai_bridge::AiOpcodeSpec {
        op: "Omega".to_string(),
        params: serde_json::json!({ "from": "a", "to": "b", "weight": 1.0 }),
    }];

    let err = repl_ai_compile_dry_run_with_call(&mut builder, None, false, "bad omega", |_req| {
        Ok(ok_compile(opcodes))
    })
    .unwrap_err();

    assert!(err.contains("opcode mapping failed"), "err={}", err);
    assert!(err.contains("Omega"), "err={}", err);
    assert!(err.contains("desc"), "err={}", err);

    let after = show_program_json(builder.program());
    assert_eq!(after, before, "failed dry-run must not replace the buffer");
}

#[test]
fn f2_ai_compile_out_json_is_valid_canonical_compile_envelope() {
    let out = AiCompileOut {
        compile: pms_ai_bridge::AiCompileResult {
            opcodes: vec![pms_ai_bridge::AiOpcodeSpec {
                op: "Square".to_string(),
                params: serde_json::json!({ "kind": "ctx" }),
            }],
        },
        warnings: vec!["be careful".to_string()],
    };

    let raw = ai_compile_out_json(&out);
    let v: serde_json::Value =
        serde_json::from_str(&raw).expect("ai_compile --show-json must print valid JSON");

    assert_eq!(v["ok"], true);
    assert_eq!(v["task"], pms_ai_bridge::TASK_COMPILE_SCENARIO);
    assert_eq!(v["result"]["opcodes"][0]["op"], "Square");
    assert_eq!(v["result"]["opcodes"][0]["params"]["kind"], "ctx");
    assert_eq!(v["warnings"][0], "be careful");
    assert!(v["error"].is_null());
}

#[test]
fn f2_ai_compile_flag_parser_accepts_show_json_and_dry_run_any_order() {
    let (dry_run, show_json, desc) =
        parse_ai_compile_flags("--dry-run --show-json create framed action").unwrap();

    assert!(dry_run);
    assert!(show_json);
    assert_eq!(desc, "create framed action");

    let (dry_run, show_json, desc) =
        parse_ai_compile_flags("--show-json --dry-run create framed action").unwrap();

    assert!(dry_run);
    assert!(show_json);
    assert_eq!(desc, "create framed action");
}

#[test]
fn f2_ai_compile_flag_parser_rejects_unknown_flags() {
    let err = parse_ai_compile_flags("--wat create framed action").unwrap_err();

    assert!(err.contains("unknown ai_compile flag"), "err={}", err);
    assert!(err.contains("--wat"), "err={}", err);
}
