use crate::run_program;
use pms_ir::PmsBuilder;

#[test]
fn b1_run_program_validate_without_model_errors_with_actionable_message() {
    let mut b = PmsBuilder::new();
    b.frame("training"); // irgendwas, damit das Programm nicht leer ist

    let err = run_program(&mut b, None, true).unwrap_err();
    assert!(
        err.contains("Validation is ON but no model is loaded"),
        "got: {}",
        err
    );
    assert!(err.contains("Use: model <path>"), "got: {}", err);
}
