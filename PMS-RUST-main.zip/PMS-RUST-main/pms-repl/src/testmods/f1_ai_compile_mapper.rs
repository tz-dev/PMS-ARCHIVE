use super::super::*;

fn op(op: &str, params: serde_json::Value) -> pms_ai_bridge::AiOpcodeSpec {
    pms_ai_bridge::AiOpcodeSpec {
        op: op.to_string(),
        params,
    }
}

#[test]
fn f1_mapper_accepts_minimal_happy_path() {
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![
        op("Delta", serde_json::json!({ "name": "E" })),
        op("Square", serde_json::json!({ "kind": "work" })),
        op(
            "Nabla",
            serde_json::json!({ "entity": "E", "intensity": 1.0, "desc": "ping" }),
        ),
        op("Sigma", serde_json::json!({ "note": "integrate" })),
        op("Psi", serde_json::json!({ "note": "commit" })),
    ];

    apply_compiled_opcodes(&mut b, &ops).expect("mapper should succeed");
    let program = b.take_program();
    assert!(!program.is_empty(), "program should contain opcodes");
}

#[test]
fn f1_mapper_fails_if_params_not_object() {
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![op("Square", serde_json::json!(["not", "an", "object"]))];

    let e = apply_compiled_opcodes(&mut b, &ops).unwrap_err();
    assert!(e.contains("params must be a JSON object"), "got: {}", e);
}

#[test]
fn f1_mapper_fails_if_square_missing_kind() {
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![op("Square", serde_json::json!({}))];

    let e = apply_compiled_opcodes(&mut b, &ops).unwrap_err();
    assert!(e.contains("Square"), "got: {}", e);
    assert!(e.contains("kind"), "got: {}", e);
}

#[test]
fn f1_mapper_fails_if_omega_missing_desc() {
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![
        op("Square", serde_json::json!({ "kind": "k" })),
        op(
            "Omega",
            serde_json::json!({ "from": "a", "to": "b", "weight": 1.0 }),
        ),
    ];

    let e = apply_compiled_opcodes(&mut b, &ops).unwrap_err();
    assert!(e.contains("Omega"), "got: {}", e);
    assert!(e.contains("desc"), "got: {}", e);
}

#[test]
fn f1_mapper_fails_on_unknown_op() {
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![op("NotAnOp", serde_json::json!({}))];

    let e = apply_compiled_opcodes(&mut b, &ops).unwrap_err();
    assert!(e.contains("unsupported op"), "got: {}", e);
}

#[test]
fn f1_mapper_accepts_theta_default_dt() {
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![
        op("Theta", serde_json::json!({})), // dt defaults to 1
    ];

    apply_compiled_opcodes(&mut b, &ops).expect("theta without dt should default");
    let program = b.take_program();
    assert!(!program.is_empty());
}

#[test]
fn f1_mapper_accepts_chi_and_exit_is_not_supported_here() {
    // This test documents current v0 mapping: we map Chi enter only.
    // (Chi exit is not an opcode in the compile whitelist anyway.)
    let mut b = pms_ir::PmsBuilder::new();

    let ops = vec![op("Chi", serde_json::json!({ "label": "iso" }))];

    apply_compiled_opcodes(&mut b, &ops).expect("chi enter should map");
}
