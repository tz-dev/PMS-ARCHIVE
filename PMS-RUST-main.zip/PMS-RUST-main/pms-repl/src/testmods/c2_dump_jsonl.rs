use crate::*;
use pms_ir::PmsBuilder;
use pms_kernel::{KernelEvent, Operator};

fn tmp_path(name: &str) -> String {
    let mut p = std::env::temp_dir();
    // Windows-safe: keine ":" etc.
    p.push(format!("pms_repl_{}_{}.jsonl", name, std::process::id()));
    p.to_string_lossy().to_string()
}

#[test]
fn c2_dump_jsonl_writes_one_line_per_event() {
    let mut b = PmsBuilder::new();
    apply_line(&mut b, "frame A").unwrap();
    apply_line(&mut b, "impulse agent 0.5 hello").unwrap();
    apply_line(&mut b, "integrate note").unwrap();

    let (_tick, events) = run_program(&mut b, None, false).unwrap();
    assert!(
        events.len() >= 3,
        "expected at least 3 events, got {}",
        events.len()
    );

    let path = tmp_path("lines");
    dump_events_jsonl(&path, &events).unwrap();

    let s = std::fs::read_to_string(&path).unwrap();
    let lines: Vec<&str> = s.lines().collect();

    assert_eq!(lines.len(), events.len(), "line count mismatch");
    assert!(
        lines[0].starts_with("{\"schema\":\"pms.events.v0\","),
        "line0={}",
        lines[0]
    );
    assert!(lines[0].contains("\"tick\":"), "line0={}", lines[0]);
    assert!(lines[0].contains("\"op\":\""), "line0={}", lines[0]);
    assert!(lines[0].contains("\"msg\":\""), "line0={}", lines[0]);

    let parsed: serde_json::Value =
        serde_json::from_str(lines[0]).expect("dumped JSONL line must parse as valid JSON");
    assert_eq!(parsed["schema"].as_str(), Some("pms.events.v0"));

    // cleanup best-effort
    let _ = std::fs::remove_file(&path);
}

#[test]
fn c2_dump_jsonl_escapes_newlines_and_quotes() {
    let events = vec![KernelEvent {
        tick: 1,
        op: Operator::Delta,
        msg: "hello \"x\"\nline2".to_string(),
        meta: None,
    }];

    let path = tmp_path("escape");
    dump_events_jsonl(&path, &events).unwrap();

    let s = std::fs::read_to_string(&path).unwrap();
    assert!(
        s.contains("\\\"x\\\""),
        "expected escaped quotes, got: {}",
        s
    );
    assert!(s.contains("\\n"), "expected escaped newline, got: {}", s);

    let _ = std::fs::remove_file(&path);
}

#[test]
fn c2_dump_jsonl_escapes_all_control_chars() {
    let mut msg = String::from("controls:");
    for b in 0u8..=0x1f {
        msg.push(char::from(b));
    }
    msg.push_str(":end");

    let events = vec![KernelEvent {
        tick: 7,
        op: Operator::Delta,
        msg,
        meta: None,
    }];

    let path = tmp_path("all_controls");
    dump_events_jsonl(&path, &events).unwrap();

    let s = std::fs::read_to_string(&path).unwrap();

    assert!(
        s.contains("\\u0000"),
        "expected NUL to be escaped as \\u0000, got: {:?}",
        s
    );
    assert!(
        s.contains("\\u0008"),
        "expected backspace to be escaped as \\u0008, got: {:?}",
        s
    );
    assert!(
        s.contains("\\u001f"),
        "expected unit separator to be escaped as \\u001f, got: {:?}",
        s
    );

    assert!(
        s.contains("\\n"),
        "expected newline short escape, got: {:?}",
        s
    );
    assert!(
        s.contains("\\r"),
        "expected carriage-return short escape, got: {:?}",
        s
    );
    assert!(s.contains("\\t"), "expected tab short escape, got: {:?}", s);

    let line = s.lines().next().expect("expected one JSONL line");
    let parsed: serde_json::Value =
        serde_json::from_str(line).expect("dumped JSONL line must parse as valid JSON");

    assert_eq!(parsed["schema"].as_str(), Some("pms.events.v0"));
    assert_eq!(parsed["tick"].as_u64(), Some(7));
    assert_eq!(parsed["op"].as_str(), Some("Delta"));

    let _ = std::fs::remove_file(&path);
}

#[test]
fn c2_load_jsonl_accepts_missing_schema_for_backward_compat() {
    let path = tmp_path("load_missing_schema");
    std::fs::write(&path, "{\"tick\":1,\"op\":\"Delta\",\"msg\":\"legacy\"}\n").unwrap();

    let events = load_events_jsonl(&path).unwrap();

    assert_eq!(events.len(), 1);
    assert_eq!(events[0].tick, 1);
    assert_eq!(events[0].op, "Delta");
    assert_eq!(events[0].msg, "legacy");

    let _ = std::fs::remove_file(&path);
}

#[test]
fn c2_load_jsonl_accepts_known_schema() {
    let path = tmp_path("load_known_schema");
    std::fs::write(
        &path,
        "{\"schema\":\"pms.events.v0\",\"tick\":2,\"op\":\"Frame\",\"msg\":\"frame kind=A\"}\n",
    )
    .unwrap();

    let events = load_events_jsonl(&path).unwrap();

    assert_eq!(events.len(), 1);
    assert_eq!(events[0].tick, 2);
    assert_eq!(events[0].op, "Frame");
    assert_eq!(events[0].msg, "frame kind=A");

    let _ = std::fs::remove_file(&path);
}

#[test]
fn c2_load_jsonl_rejects_unknown_schema() {
    let path = tmp_path("load_unknown_schema");
    std::fs::write(
        &path,
        "{\"schema\":\"pms.events.future\",\"tick\":3,\"op\":\"Delta\",\"msg\":\"x\"}\n",
    )
    .unwrap();

    let err = load_events_jsonl(&path).expect_err("unknown JSONL schema should fail closed");

    assert!(
        err.contains("unsupported schema"),
        "expected unsupported schema error, got: {}",
        err
    );

    let _ = std::fs::remove_file(&path);
}
