use crate::*;
use pms_kernel::{KernelEvent, KernelEventMeta, Operator};
use std::collections::BTreeMap;
use std::fs as stdfs;
use std::path::PathBuf;

fn temp_jsonl_path(name: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    // unique-ish: include PID
    p.push(format!("pms_repl_{}_{}.jsonl", name, std::process::id()));
    p
}

#[test]
fn c3_dump_fs_jsonl_writes_one_line_per_service_event() {
    // Arrange: vFS service state
    let mut svc = KernelState::new();

    // Emit some vFS service events
    svc.fs_create_file("/a.txt").unwrap();
    svc.fs_write_file("/a.txt", b"hello").unwrap();
    let _ = svc.fs_read_file("/a.txt").unwrap();

    assert_eq!(svc.events.len(), 3, "expected 3 vFS events");

    // Dump to temp file
    let path = temp_jsonl_path("fs_dump");
    let path_str = path.to_string_lossy().to_string();
    dump_events_jsonl(&path_str, &svc.events).unwrap();

    // Assert: file exists and has exactly N lines
    let content = stdfs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("failed to read dump file {:?}: {}", path, e));

    let lines: Vec<&str> = content.lines().collect();
    assert_eq!(
        lines.len(),
        svc.events.len(),
        "expected exactly one JSONL line per event"
    );

    // Basic schema sanity
    assert!(lines[0].contains("\"tick\":"), "line={}", lines[0]);
    assert!(lines[0].contains("\"op\":\""), "line={}", lines[0]);
    assert!(lines[0].contains("\"msg\":\""), "line={}", lines[0]);

    // Cleanup best-effort (ignore errors)
    let _ = stdfs::remove_file(&path);
}

#[test]
fn c3_dump_fs_jsonl_contains_fs_prefix_messages() {
    let mut svc = KernelState::new();

    svc.fs_create_file("/a.txt").unwrap();
    svc.fs_write_file("/a.txt", b"hello").unwrap();

    let path = temp_jsonl_path("fs_dump_prefix");
    let path_str = path.to_string_lossy().to_string();
    dump_events_jsonl(&path_str, &svc.events).unwrap();

    let content = stdfs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("failed to read dump file {:?}: {}", path, e));

    // In euren Events ist op=Delta und msg enthält "fs_*"
    assert!(
        content.contains("fs_create_file"),
        "expected fs_create_file in dump, got:\n{}",
        content
    );
    assert!(
        content.contains("fs_write_file"),
        "expected fs_write_file in dump, got:\n{}",
        content
    );

    let _ = stdfs::remove_file(&path);
}

#[test]
fn c3_dump_fs_jsonl_exports_meta_when_present() {
    let mut kv = BTreeMap::new();
    kv.insert("id".to_string(), "1".to_string());
    kv.insert("label".to_string(), "a b\\c".to_string());
    kv.insert("path".to_string(), "/demo/a.txt".to_string());

    let events = vec![KernelEvent {
        tick: 9,
        op: Operator::Delta,
        msg: "fs_create_file path=/demo/a.txt id=1".to_string(),
        meta: Some(KernelEventMeta {
            kind: "fs_create_file".to_string(),
            kv,
        }),
    }];

    let path = temp_jsonl_path("meta_export");
    let path_str = path.to_string_lossy().to_string();
    dump_events_jsonl(&path_str, &events).unwrap();

    let s = stdfs::read_to_string(&path).unwrap();
    let line = s.lines().next().expect("expected one JSONL line");

    let parsed: serde_json::Value =
        serde_json::from_str(line).expect("dumped JSONL line must parse as valid JSON");

    assert_eq!(parsed["schema"].as_str(), Some("pms.events.v0"));
    assert_eq!(parsed["tick"].as_u64(), Some(9));
    assert_eq!(parsed["op"].as_str(), Some("Delta"));
    assert_eq!(parsed["meta"]["kind"].as_str(), Some("fs_create_file"));
    assert_eq!(parsed["meta"]["kv"]["id"].as_str(), Some("1"));
    assert_eq!(parsed["meta"]["kv"]["path"].as_str(), Some("/demo/a.txt"));
    assert_eq!(parsed["meta"]["kv"]["label"].as_str(), Some("a b\\c"));

    let loaded = load_events_jsonl(&path_str).unwrap();
    assert_eq!(loaded.len(), 1);

    let meta = loaded[0]
        .meta
        .as_ref()
        .expect("meta should roundtrip through load_events_jsonl");

    assert_eq!(meta.kind, "fs_create_file");
    assert_eq!(meta.kv.get("id").map(String::as_str), Some("1"));
    assert_eq!(meta.kv.get("path").map(String::as_str), Some("/demo/a.txt"));
    assert_eq!(meta.kv.get("label").map(String::as_str), Some("a b\\c"));

    let _ = stdfs::remove_file(&path);
}
