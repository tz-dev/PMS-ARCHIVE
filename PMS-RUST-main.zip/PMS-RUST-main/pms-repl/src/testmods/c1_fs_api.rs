use crate::*;

#[test]
fn c1_fs_create_file_errors_if_parent_missing() {
    let mut s = KernelState::new();

    let err = s.fs_create_file("/nope/a.txt").unwrap_err();
    assert!(
        err.contains("path not found") || err.contains("not found"),
        "expected not found error, got: {}",
        err
    );
}

#[test]
fn c1_fs_create_dir_then_create_file_in_dir_works_and_links_parent() {
    let mut s = KernelState::new();

    let dir_id = s.fs_create_dir("/d").unwrap();
    let file_id = s.fs_create_file("/d/a.txt").unwrap();

    // Parent/child link check
    let dir = s.fs_nodes.iter().find(|n| n.id == dir_id).unwrap();
    assert_eq!(dir.kind, FsNodeKind::Directory);
    assert!(
        dir.children.contains(&file_id),
        "expected dir to contain file_id, dir.children={:?}",
        dir.children
    );

    let file = s.fs_nodes.iter().find(|n| n.id == file_id).unwrap();
    assert_eq!(file.kind, FsNodeKind::File);
    assert_eq!(file.parent, Some(dir_id));
    assert_eq!(file.name, "a.txt");
}

#[test]
fn c1_fs_create_file_duplicate_name_in_same_dir_errors() {
    let mut s = KernelState::new();

    s.fs_create_file("/a.txt").unwrap();
    let err = s.fs_create_file("/a.txt").unwrap_err();
    assert!(
        err.contains("already exists"),
        "expected already exists error, got: {}",
        err
    );
}
