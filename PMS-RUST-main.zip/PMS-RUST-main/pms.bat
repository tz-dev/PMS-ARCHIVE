@echo off
cls

cd /d "%~dp0"

echo === PMS-STACK Evidence Spine ===
echo Starting PMS REPL with model validation ON...
echo.

cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate %*
if errorlevel 1 goto fail

echo.
echo === PMS exited ===
pause
exit /b 0

:fail
echo.
echo === PMS failed to start or exited with error ===
pause
exit /b 1