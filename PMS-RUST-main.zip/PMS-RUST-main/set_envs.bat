@echo off
cls

rem ------------------------------------------------------------
rem PMS-RUST local AI/debug environment
rem ------------------------------------------------------------
rem This setup is optional.
rem It is only needed for local Ollama/AI smoke tests and debug logs.
rem Core tests and non-AI demos do not require these variables.
rem ------------------------------------------------------------

set PMS_AI_ENDPOINT=http://localhost:11434/api/chat
set PMS_AI_MODEL=mistral

rem Trace/debug flags.
set PMS_TRACE=1
set PMS_AI_DEBUG=1
set PMS_AI_DEBUG_RAW=1

rem Optional/manual AI golden behavior where supported.
set PMS_GOLDEN_AI=1

echo ------------------
echo env variables set.
echo ------------------
echo PMS_AI_ENDPOINT=%PMS_AI_ENDPOINT%
echo PMS_AI_MODEL=%PMS_AI_MODEL%
echo PMS_TRACE=%PMS_TRACE%
echo PMS_AI_DEBUG=%PMS_AI_DEBUG%
echo PMS_AI_DEBUG_RAW=%PMS_AI_DEBUG_RAW%
echo PMS_GOLDEN_AI=%PMS_GOLDEN_AI%
echo ------------------