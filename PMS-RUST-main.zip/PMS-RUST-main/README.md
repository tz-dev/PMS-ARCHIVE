# PMS-RUST

## Purpose

**PMS-RUST** is the Rust implementation workspace and executable evidence spine for the PMS ecosystem.

It demonstrates a bounded, test-driven runtime/toolchain around PMS operator execution, model validation, REPL/script use, JSONL traces, a vFS service surface, reproducible demos, golden tests, and a controlled AI proposal bridge.

It is intentionally bounded:

```text
executable artifact evidence ≠ PMS Base validation
implementation completeness ≠ theory truth
traceability ≠ warrant
```

---

## Interface

![PMS-STACK Evidence Spine REPL startup screen](screenshot.png)

The screenshot shows the REPL startup screen with the Δ ∇ □ Λ Α Ω Θ Φ Χ Σ Ψ operator banner.

---

## Ecosystem Position

PMS-RUST belongs to PMS implementation and workflow tooling, not to paper-form or corpus-form theory.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Provides the operator grammar and model reference. PMS-RUST does not validate PMS Base. |
| PMS-STACK | Supplies the architecture-specification pressure that PMS-RUST partially implements. |
| PMS-ORCHESTRATOR | Separately stages PMS-DISCIPLINE workflows; it is not the Rust runtime. |
| PMS-STRATA | Clarifies implementation-layer granularity and projection boundaries where needed. |
| PMS — UNDER LOAD | Critiques implementation boundary pressure and executable-evidence drift. |

---

## Repository Form

This is a **runtime/tooling project**.

| Component | Function |
| --- | --- |
| `pms-kernel` | Deterministic Δ–Ψ runtime core and event emission. |
| `pms-model` | PMS model-data loading and validation. |
| `pms-ir` | Intermediate representation, parsing, canonicalization, and lowering. |
| `pms-repl` | REPL and checked-in script execution. |
| `pms-ai-bridge` | AI proposal bridge with host-side parsing and validation. |
| `pms-demos/` | Reproducible scripts for valid and invalid traces. |
| `pms-docs/` | Demo, AI bridge, acceptance gates, and implementation notes. |
| tests / golden fixtures | Regression and release-gate evidence. |

For maintenance details, use `pms-docs/`, acceptance gates, tests, and crate-level documentation.

---

## Requirements

Recommended local setup:

```text
Rust stable toolchain
Windows shell / CMD / PowerShell
Optional: local Ollama-compatible backend for AI demos
```

The project is currently Windows-first and CPU-only.

Core functionality does not require:

```text
Linux namespaces
GPU backend
distributed runtime
external database
full OS process isolation
```

---

## Quick Start

Run from the workspace root.

### 1. Check the workspace

```bat
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

Expected:

```text
fmt check passes
workspace tests pass
clippy passes with -D warnings
```

### 2. Start the REPL

```bat
cargo run -p pms-repl
```

Example interactive session:

```text
entity agent
frame ctx
attractor focus
omega agent goal 1.0 asymmetry
theta 1
phi old_context new_context
integrate synthesized
psi demo_done
show
run
dump demo-out	race.jsonl
exit
```

### 3. Run a checked-in script

```bat
cargo run -p pms-repl -- --file pms-demos\d1_valid_trace.pms --run
```

### 4. Run with model + stateful validation

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run
```

### 5. Dump JSONL

```bat
mkdir demo-out
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
type demo-out\d1_valid_trace.jsonl
```

### 6. Demonstrate expected failures

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d3_stateful_invalid_sigma_no_frame.pms --run
cargo run -p pms-repl -- --file pms-demos\d4_script_rejects_fs.pms --run
```

Expected:

```text
d2 fails because the model transition is invalid
d3 fails because Σ requires an active frame
d4 fails because fs_* service commands are not supported in .pms scripts
```

---

## Demo Pack

Checked-in demo scripts live in:

```text
pms-demos/
```

Current smoke scripts:

```text
pms-demos\d1_valid_trace.pms
pms-demos\d2_model_invalid_delta_omega.pms
pms-demos\d3_stateful_invalid_sigma_no_frame.pms
pms-demos\d4_script_rejects_fs.pms
```

Main demo documentation:

```text
pms-docs/DEMO.md
```

Minimum non-AI smoke:

```bat
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d1_valid_trace.pms --run --dump demo-out\d1_valid_trace.jsonl
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d2_model_invalid_delta_omega.pms --run
cargo run -p pms-repl -- --model pms-model-data\PMS.yaml --validate --file pms-demos\d3_stateful_invalid_sigma_no_frame.pms --run
cargo run -p pms-repl -- --file pms-demos\d4_script_rejects_fs.pms --run
```

The first command should succeed. The next three should fail for the documented reasons.

---

## REPL Command Overview

Start:

```bat
cargo run -p pms-repl
```

Core REPL commands:

```text
help
status
model
validate on
validate off
show
show json
clear
run
dump <path>
state
exit
```

Common DSL commands:

```text
entity
frame
square
theta
omega
impulse
integrate
expect
attractor
chi_enter
chi
chi_exit
phi
psi
```

REPL aliases are convenient authoring forms. JSONL emits runtime keys. Use `pms-docs/` and crate documentation for the current exact command grammar.

---

## vFS Service Layer

The REPL exposes `fs_*` host/service commands, including:

```text
fs_mkdir /demo
fs_create /demo/a.txt
fs_write /demo/a.txt hello
fs_read /demo/a.txt
fs_ls /demo
fs_delete /demo/a.txt
fs_state
fs_events
fs_clear_events
fs_dump demo-outs_events.jsonl
```

Important boundary:

```text
fs_* commands are service calls.
fs_* commands do not enter the PMS program buffer.
fs_* commands are not supported in .pms scripts.
```

This separation is part of the evidence spine: runtime service surface does not silently become PMS operator language.

---

## JSONL Trace / Audit Output

JSONL is the audit spine of the current implementation.

It can record operator execution, runtime keys, validation results, vFS events, and demo traces. Trace output is evidence that the implementation emitted and stored a specific runtime sequence. It is not evidence that PMS Base is true.

Boundary:

```text
trace(...) ∈ L_PMS
≠
PMS is validated
```

---

## AI Proposal Bridge

The AI bridge is optional and fail-closed. It can propose PMS programs or analyze traces, but host-side parsing, validation, and rejection remain decisive.

Useful commands:

```text
ai_ping
ai_compile --dry-run --show-json <instruction>
ai_compile --show-json <instruction>
ai_analyze demo-out\d1_valid_trace.jsonl
```

Optional local environment variables:

```text
PMS_AI_ENDPOINT   Ollama-compatible chat endpoint
PMS_AI_MODEL      local model name, e.g. mistral / mistral:latest / llama3.1:8b
PMS_TRACE         enables PMS trace logging where trace sites exist
PMS_AI_DEBUG      enables additional AI bridge debug output
PMS_AI_DEBUG_RAW  enables raw AI debug output where supported
PMS_GOLDEN_AI     enables golden AI tests where configured
```

A failed `ai_compile` caused by malformed model output is not a release failure. It confirms the AI trust boundary:

```text
AI proposal ≠ accepted program
model output ≠ executable authority
host validation ≠ semantic truth
```

---

## Acceptance Gates

Release evidence should include at least:

```text
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
non-AI demo smoke
JSONL dump inspection
expected validation failures
script/service separation failure
golden fixture checks where applicable
```

Gate details belong in:

```text
pms-docs/ACCEPTANCE_GATES.md
pms-docs/AI_BRIDGE.md
pms-docs/DEMO.md
```

---

## Current Evidence Spine

The intended execution path is:

```text
.pms script / REPL / AI proposal
→ host-side parse and validation
→ deterministic kernel execution
→ JSONL trace / audit
→ optional vFS service events
→ optional golden comparison
```

This demonstrates buildability and traceability under bounded conditions. It does not complete PMS-STACK or validate PMS Base.

---

## What PMS-RUST Is Not

PMS-RUST is not:

```text
PMS Base
PMS-STACK in full
an operating system
a distributed PMS runtime
a semantic validator
proof of PMS
AI authority
```

Core reductions:

```text
tests pass ≠ PMS is true
trace exists ≠ trace is adequate
validator accepts ≠ external adequacy
AI proposes ≠ PMS authorizes
implementation works ≠ theory is proven
```

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS-RUST DOI | To be added or verified during the Zenodo release/check pass. |

---

## Citation

Cite PMS-RUST as executable implementation evidence for bounded PMS runtime behavior. Do not cite passing tests, traces, or demos as PMS Base validation.

---

## License

Unless otherwise noted, source code, executable tools, scripts, validators, schemas, and software-adjacent technical files in this repository are licensed under the Apache License 2.0.

Textual theory, documentation, case materials, prompts, templates, diagrams, and non-executable explanatory materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).
