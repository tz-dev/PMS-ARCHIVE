# PMS-ORCHESTRATOR

## Purpose

**PMS-ORCHESTRATOR** is a service-independent desktop workflow runner for PMS-DISCIPLINE case work.

It prepares the next prompt, shows required files, stores raw responses, applies configured local YAML checks, keeps route decisions human-confirmed, supports handoff/article routes, and enforces explicit PMS-DISCIPLINE Pre-Analysis pipeline stops.

The application does not connect to an AI service and does not treat attached files, YAML completion, or model output as evidence by presence alone.

```text
Structure the workflow.
Preserve the record.
Expose drift.
Keep decisions human-reviewed.
Enforce confirmed non-continuation.
```

---

## Interface

![PMS-ORCHESTRATOR screenshot](img/screenshot.png)

The screenshot shows the local runner interface. It is a workflow and record-staging aid, not an analysis authority.

---

## Ecosystem Position

ORCHESTRATOR belongs to PMS implementation and workflow tooling.

| Neighboring layer | Relation |
| --- | --- |
| PMS-DISCIPLINE | Supplies the workflow grammar, gates, stop logic, templates, and review requirements. |
| PMS Base | Supplies theory material read by configured steps. The app does not validate PMS Base. |
| PMS add-ons / MIP / AHP | Can be staged only under DISCIPLINE route state. |
| PMS-STRATA | May later provide transformation-discipline material, but reader/graph/schema output remains non-authoritative. |
| PMS — UNDER LOAD | Critiques workflow-tooling drift, structural-validation drift, and artifact authority. |

---

## Repository Form

This is a **runtime/tooling project**.

| Material | Function |
| --- | --- |
| `orchestrator/` | Local desktop application code. |
| `templates/` | Route, YAML, handoff, article, and case-production templates. |
| `tests/` | Workflow, stop, validation, and route-boundary tests. |
| `TECHNICAL.md` | Architecture, implementation, and maintenance notes. |
| Embedded PMS/MIP YAMLs | Local structural reference material; not evidence by presence. |

This README explains the tool’s role and operating boundaries. Technical behavior belongs in `TECHNICAL.md` and tests.

---

## Quick Start

Typical manual runner sequence:

```text
1. Start the application.
2. Create a new case.
3. Enter title, material, source status, requested output, and intended use.
4. Attach or describe optional case materials.
5. Choose Full Review Mode or Fast Mode.
6. Choose local YAML validation behavior.
7. Copy each generated prompt to the external AI service.
8. Paste or import the AI output into the runner.
9. Resolve Pre-Analysis stop before Core entry.
10. Complete Core and any routed add-on / MIP / AHP steps.
11. Complete Case Record Stages 1–3.
12. Review Iteration Handoff.
13. Choose follow-up case, article route, finish, or decide later.
14. If article route is chosen, review source setup, draft, examples, and final patch diff.
```

No API key is required. The runner does not automate the external AI call.

---

## Main Case-Generation Flow

```text
PMS Base and optional case materials
→ Pre-Analysis
→ binding stop or PMS Core
→ optional PMS add-on
→ optional MIP
→ optional AHP
→ Case Record Stages 1–3
→ optional Iteration Handoff
→ optional Markdown article and/or separately bounded follow-up case
```

The runner guides one active step at a time. It preserves raw outputs and route state, but the user remains responsible for review and confirmation.

---

## Discipline Options Inside a Case

### Case packet and materials

Each case starts with:

```text
case title
case description or material
source status
requested output
intended use
```

Optional materials may be attached, described, and assigned a purpose. Their presence does not upgrade them into evidence.

### Startup splash

At startup the runner may show `resources/splash.png`. If the file is absent or cannot be loaded, the main window opens normally.

### Review mode

A case can run in **Full Review** or **Fast Mode**.

| Mode | Behavior |
| --- | --- |
| Full Review | Keeps semantic AI check steps active and requires Pre-Analysis stop review before Core. |
| Fast Mode | Skips unfinished semantic review steps by explicit user choice and marks forwarded outputs as unchecked by that choice. |

Fast Mode reduces calls and time while accepting higher semantic-drift risk.

---

## Discipline Stop

The primary stop key is:

```yaml
scope_and_pipeline_disposition:
  pipeline_case_disposition: stop
```

The runner also recognizes corresponding final-status stop fields and configured mandatory person-near hard-stop combinations.

In Full Review, a stop signal in Pre-Analysis opens a prominent warning and still requires the review step to confirm or correct the Pre-Analysis. If the effective checked result still contains a stop, the runner terminates before Core.

In Fast Mode, the review step is skipped, so the Pre-Analysis stop is evaluated immediately and a detected stop terminates the run at once.

A binding detected stop sets the run to `pipeline_stopped_by_pre_analysis`, locks Core and later analysis steps, and offers no continue-anyway action. Only a revised Pre-Analysis through the proper review path can reopen the pipeline.

This is PMS-DISCIPLINE scope-control enforcement, not an autonomous truth decision.

---

## Local YAML Validation

Local YAML validation is structural, not semantic.

It can warn or block on:

```text
malformed YAML
duplicate keys
missing keys
unexpected keys
shape mismatches
type mismatches
invalid configured values
```

It does not decide whether a claim, route, interpretation, or conclusion is correct.

```text
local YAML validation ≠ semantic correctness
validation report ≠ case evidence
green check ≠ truth
```

Semantic review prompts may receive the local result as authoritative for deterministic structure, but not as substantive adequacy.

---

## Add-on, MIP, and AHP Routes

After Core, the runner asks whether exactly zero or one PMS add-on should be used.

Supported add-ons:

```text
ANTICIPATION
CRITIQUE
CONFLICT
LOGIC
EDEN
SEX
```

Add-on selection follows structural burden, not surface vocabulary. A user override is preserved as user-requested, not as proof that the gate recommended the add-on.

MIP remains downstream and non-add-on. Its runner route is binary:

```text
no_mip
use_mip
```

AHP is available only after an actual checked MIP branch and remains a second-order analysis-quality overlay. It does not rescore MIP, activate D, upgrade evidence, or authorize stronger claims.

---

## Case Record Stages

The Case Record stages preserve the run:

```text
#20 Stage 1 Artifact Index
#21 Stage 1 Check
#22 Stage 2 Layer Digest Extraction
#23 Stage 2 Check
#24 Stage 3 Full Record Integration
#25 Stage 3 Check
```

Stage 1 indexes actual selected or produced artifacts and route states. Stage 2 compresses layer-specific digests without changing the checked analysis. Stage 3 integrates the checked record without creating new substantive findings.

---

## Iteration Handoff

After checked Case Record Stage 3, step #26 prepares optional **Iteration Handoff and Follow-up Preparation**.

The user can review model recommendation, current analytical depth, sufficiency for original intended use, urgency, reasons, minimum follow-up coverage, and proposed follow-up targets.

For each proposed target, the user can:

```text
accept
refine
replace
split
merge
reject
annotate
```

The saved YAML keeps model proposal, user response, and effective follow-up target separate. User notes guide future preparation; they do not become verified facts, evidence, route authorization, or confirmation of the prior analysis.

A follow-up case starts again at step #1 and must confirm its own boundary, source status, intended use, and material roles.

---

## Optional Article Generation

Article generation begins only after the Iteration Handoff step.

Typical route:

```text
#27 Article Source Setup and Rendering Contract
#28 Base Markdown Case Article Draft
#29 Example Decision and Optional Example Generation
#30 Final Article Assembly
#31 Final Article Check
```

Article outputs are publication-facing renderings, not sources for Iteration Handoff and not evidence for future cases by presence.

The runner can support a Case article or a Full analysis article. The final patch diff must be reviewed before use.

---

## Technical Documentation

Implementation details, maintenance notes, packaging assumptions, internal step numbering, tests, and technical constraints belong in:

```text
TECHNICAL.md
tests/
templates/
orchestrator/
```

Use this README for orientation and operating boundaries, not for full implementation documentation.

---

## What ORCHESTRATOR Is Not

PMS-ORCHESTRATOR is not:

```text
PMS Base
PMS-DISCIPLINE theory
semantic validator
truth authority
governance authority
route authority
checked-artifact authority
publication authority
follow-up authority
AI service
```

Core reductions:

```text
workflow completion ≠ proof
local YAML validation ≠ semantic correctness
checked artifact ≠ correct interpretation
stop enforcement ≠ truth
follow-up case creation ≠ authority transfer
```

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS-ORCHESTRATOR DOI | To be added or verified during the Zenodo release/check pass. |

---

## Citation

Cite PMS-ORCHESTRATOR as workflow tooling for PMS-DISCIPLINE case work. Do not cite the app, route state, validation report, or article rendering as substantive validation.

---

## License

Unless otherwise noted, source code, executable tools, scripts, validators, schemas, and software-adjacent technical files in this repository are licensed under the Apache License 2.0.

Textual theory, documentation, case materials, prompts, templates, diagrams, and non-executable explanatory materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).
