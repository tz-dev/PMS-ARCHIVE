# PMS–CRITIQUE

## Purpose

**PMS–CRITIQUE** is a paper-form PMS lens for critique as interruption, recontextualization, distance, correction, and the drift from irritation into judgment, exposure, or sanction.

It analyses when a mismatch becomes a structurally valid critique rather than mere reaction, taste, blame, or public punishment.

Compact boundary:

```text
critique ≠ reaction
correction ≠ verdict
exposure ≠ argument
drift label ≠ sanction
```

---

## Ecosystem Position

PMS–CRITIQUE belongs to the PMS paper-form lens family.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies the Δ–Ψ operator grammar. |
| PMS-ANTICIPATION | Neighboring lens for future-oriented restraint before mismatch becomes explicit. |
| PMS-CONFLICT | Neighboring lens for terminal incompatibility after critique no longer integrates. |
| PMS-LOGIC | Neighboring lens for responsibility and post-moral effects without deriving ought. |
| PMS-STRATA | Later discipline for inspecting level shifts, projection, and composition in critique sequences. |
| PMS-DISCIPLINE | Required for person-near or decision-adjacent critique applications. |

---

## Repository Form

This is a **paper-form PMS lens repository**.

| Material | Function |
| --- | --- |
| Main paper | Theoretical account of critique thresholds, drift, scale, publicness, and docking. |
| Model YAML | Machine-readable critique overlay. |
| Model specification | Human-readable explanation of overlay fields. |
| Examples | Scene-bound structural stress tests. |

---

## Core Thesis

Critique becomes structurally legible when a distinction under a frame is held at enough distance to interrupt, recontextualize, and possibly integrate a correction without collapsing into verdict, exposure, coercion, or status attack.

PMS–CRITIQUE therefore treats critique as a configuration, not as a mood, moral superiority, or mere negativity.

---

## Validity Gate

Application use requires:

| Gate | Requirement |
| --- | --- |
| Χ / Distance | Maintained meta-position and stop-capability; no fusion into verdict. |
| Reversibility | Scene-bound, revisable readings; no global person labels. |
| Dignity-in-Practice | No shaming, humiliation, actor-ranking, or exposure-as-sanction. |

Practical prohibitions:

```text
no person labeling
no motive attribution by model shortcut
no psychological diagnosis
no coercive binding
no sanction by drift label
no evaluative verdict smuggled into structural language
```

---

## Critique Thresholds

PMS–CRITIQUE distinguishes three threshold levels.

| Threshold | Signature | Meaning |
| --- | --- | --- |
| Minimal Critique | `Δ + □ + Χ` | A mismatch becomes legible in a frame and remains interruptible. |
| Productive Critique | `Δ + □ + Χ + Φ + Σ` | Recontextualization and integration consolidate a corrective step. |
| Stable Critique | `Δ + □ + Χ + Φ + Σ + Ψ` | Correction becomes durably bound without coercive other-binding. |

Strict non-equivalence:

```text
reaction without Χ ≠ critique
exposure without reversibility ≠ critique
correction without D-boundary ≠ valid application
```

---

## Drift and Publicness

Critique drifts when interruption becomes identity, exposure, coercion, or public punishment.

Typical drift patterns:

```text
irritation drift
verdict drift
exposure drift
purity drift
moralization drift
publicness amplification
authority capture
correction-to-control drift
```

Public critique adds special pressure because visibility increases cost, reversibility burden, and dignity risk.

---

## Derived Axes and MIP Docking

PMS–CRITIQUE may derive axes for critique quality, stability, publicness, and correction viability.

Where critique becomes person-near, maturity-near, dignity-near, or role-evaluation-adjacent, it should not intensify internally. It should route outward to MIP/AHP only under explicit application discipline.

Boundary:

```text
derived axis ≠ person score
MIP docking ≠ person evaluation
AHP hardening ≠ evidentiary upgrade
```

---

## Model and Examples

The model layer records critique thresholds, drift typology, application gates, scale/publicness logic, derived-axis support, and example-suite schemas.

The example suite contains structural stress tests, not verdicts. Examples are designed to test:

```text
reaction versus critique
publicness pressure
correction viability
exposure drift
moralization drift
distance failure
MIP-docking triggers
```

---

## Intended Use

PMS–CRITIQUE is intended for structural analysis of critique, correction, interruption, publicness, and drift.

It is not intended for shaming, diagnosing, ranking, sanctioning, motive-reading, reputational punishment, or automated moderation decisions.

---

## Reading Path

Recommended path:

```text
README
→ main paper
→ validity gate
→ critique thresholds
→ drift typology
→ model layer
→ example suite
```

---

## Status

PMS–CRITIQUE is a bounded paper-form PMS lens.

Its current status is:

```text
critique-specific
threshold-oriented
publicness-aware
application-gated
non-verdictive
non-validating
```


---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS–CRITIQUE DOI | [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19443043.svg)](https://doi.org/10.5281/zenodo.19443043) |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing this repository, cite the repository release and DOI corresponding to the version used. Do not cite this project as if it validates PMS Base, replaces neighboring PMS layers, or licenses claims beyond its declared scope.

---

## License

Unless otherwise noted, textual theory, papers, documentation, examples, prompts, diagrams, and non-executable model or specification materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
