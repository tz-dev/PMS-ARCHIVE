# PMS-DISCIPLINE

## Application Discipline for PMS-Based Use

## Abstract

PMS-DISCIPLINE is an application discipline for PMS-based use. It governs the passage from PMS readability to responsible PMS use under conditions of incomplete input, situated interpretation, claim risk, human judgment, AI-assisted processing, template mediation, person-nearness, publicness, correctability, closure, and possible iteration.

The need for PMS-DISCIPLINE arises not from a weakness of PMS, but from its strength. PMS can produce strong structural readability. Such readability can become risky when it hardens too quickly into claim authority, add-on escalation, person capture, workflow completion, article-level confidence, or model-generated certainty. PMS-DISCIPLINE therefore does not strengthen PMS authority; it constrains PMS use.

This document regulates how PMS Core and optional add-on lenses are selected, bounded, withheld, downgraded, suspended, refused, or redirected. It addresses input status, claim type, operator salience, add-on triggering, add-on non-use, rival pressure, person-nearness, AI-assisted work, templates, case-pass records, correctability, closure, stop-capability, and bounded follow-up preparation.

A PMS-DISCIPLINE pass begins before Core application. Pre-Analysis establishes the case and use boundary, reviews the requested output, and determines whether entry into Core analysis is permitted. It may prepare a bounded Core path, require correction, or stop the current pass before Core. Refusal of the requested output and stopping the current pipeline case are distinct dispositions, but they may occur together. Where a protective stop also indicates that another frame or differently bounded question may be appropriate, that redirection does not continue the stopped case. It requires a new, separately bounded pass.

PMS-DISCIPLINE is not an extension of PMS Base. It does not add operators, replace PMS.yaml, validate PMS, certify truth, govern cases, rank persons, authorize automated decisions, or provide a complete PMS application method. Its function is to make PMS-based use bounded, inspectable, correctable, stoppable, and iteratively accountable rather than stronger, final, or certified.

A disciplined PMS output is therefore not a verdict. It is a bounded record of what was read, what was not read, which claims are licensed, which claims are not licensed, which risks remain, which rival accounts matter, whether the requested output is permitted, whether the current application may enter or continue through the analytical path, and whether the final decision is to proceed, revise, downgrade, suspend, refuse, or redirect.

Where future work remains possible, the record must also distinguish reopening from separately bounded follow-up. A current case may stop while a different future case remains possible. That future case does not inherit the present findings as evidence, the present route as authority, or the present claim ceiling as an established starting point.

## How to Read This Document

This document should be read as a discipline of PMS use, not as an extension of PMS Base. It does not define new PMS operators, revise the PMS operator order, replace PMS.yaml, or provide a second foundation for PMS. Its concern is not only whether PMS can make something structurally readable, but whether the requested use may enter PMS analysis at all, how any permitted reading must be bounded, and when the current application must be corrected, stopped, or redirected.

Responsible entry review begins before the formal PMS-DISCIPLINE pass. Before initiating Pre-Analysis, the responsible analyst should ask why PMS is being used, why the material is being treated in the requested form, what output and practical effect are sought, who may be affected, whether another frame or domain process carries the burden better, and whether the application should begin at all.

Where the application remains under consideration, the formal PMS-DISCIPLINE path begins with Pre-Analysis. Pre-Analysis establishes the scene or case boundary, marks input and source status, records intended use, distinguishes the requested output from the pipeline case, and determines whether Core entry is permitted. Core remains primary among analytical layers, but it does not precede the DISCIPLINE Entry Gate.

A pre-entry refusal or redirect means that the formal pass does not begin. A confirmed stop in the effective checked Pre-Analysis ends the current pass before Core. No Core, add-on, MIP, AHP, Case Record, iteration, or article step may be treated as continuation of that stopped pass. A redirect may identify a safer frame, domain process, source-gathering step, or differently bounded analytical question, but entering that direction requires a new case boundary rather than a same-pass reframing.

This distinction is essential. A PMS reading may be structurally possible and still not be licensed for the requested output or intended use. A requested output may be refused while a safer separately bounded question remains possible. A Core pass may be sufficient. An add-on may be relevant but still not selected. A template may make a reading more inspectable without making it more authoritative. A case-pass record may preserve accountability without becoming a verdict. A follow-up indication may be useful without reopening, strengthening, or extending the current case result.

Accordingly, PMS-DISCIPLINE should not be read as a validator, governance layer, automated workflow authority, software protocol, institutional tribunal, completeness method, or iteration engine. Routing is not governance. Review is not certification. A checked artefact is not evidence. An integration record is not a verdict. A completed workflow is not proof of adequacy. A follow-up handoff is not a further Case Record stage, not a new finding, and not authorization to inherit claim authority into a future case.

References to YAML, templates, review gates, trigger maps, threshold tables, case-pass records, or iteration handoffs should be understood in this limited sense. Such artefacts may support disciplined use by making assumptions, limits, non-use, risks, correction paths, stop conditions, follow-up needs, and boundary conditions more visible. They may not authorize a claim, certify truth, settle a case, rank a person, execute an unreviewed final judgment, or treat future work as already licensed by the current pass.

PMS-DISCIPLINE therefore constrains PMS use without becoming an authority above PMS. Its task is to make PMS-based application harder to overclaim, easier to inspect, easier to correct, able to stop before analysis where necessary, and able to continue only under the boundary actually licensed by the current pass.

## Compact Usage Overview

PMS-DISCIPLINE is used to discipline a PMS application path. It does not complete the case, maximize PMS coverage, authorize the strongest possible reading, or convert follow-up potential into current-case authority. The disciplined question is not how much PMS can be applied, but whether the requested use may enter PMS analysis, how much PMS use the claim can responsibly bear now, and what must remain separate if further work is needed later.

A PMS-DISCIPLINE pass begins by declaring the scene or case boundary, the available input, the source status, and the intended use. Pre-Analysis then examines the requested output, the protection and entry conditions, the preliminary claim ceiling, and the eligibility of the current case for Core analysis.

The requested output and the pipeline case must remain distinct. A requested output may be refused because its form would overclaim, capture a person, delegate a non-delegable judgment, or violate another guardrail. The pipeline case may simultaneously be stopped because no later step in the current pass is permitted. Conversely, a requested formulation may require revision without ending the entire case. These outcomes must not be collapsed.

If the checked Pre-Analysis permits analytical entry, PMS Core comes first among analytical layers. Core may be sufficient, and Core-only may be the disciplined result. At most one PMS add-on may be selected within a single bounded pass. Where several add-on questions are materially relevant, they should normally be separated into distinct subcases and integrated only at the record level.

MIP and AHP are not ordinary PMS add-ons. MIP may follow Core or a selected add-on only where its own gate and claim boundary are met. AHP may follow only an actually produced and checked MIP branch. Neither layer becomes automatic through vocabulary, workflow momentum, or the mere presence of evaluative pressure.

Operator use must remain disciplined. The PMS operator order is a dependency discipline, not a hierarchy of truth, maturity, or authority. Local salience may guide a reading, but salience is not sovereignty. Operators must be assigned because they perform structural work, not because their names can be associated with the topic.

The pass must also test rival accounts and preserve correctability. Rival pressure is not decorative. A rival explanation may currently discriminate better than PMS, in which case the application should be downgraded, suspended, refused, or redirected rather than forced into PMS terms. Coherence, elegance, recognition, template completion, workflow completion, follow-up availability, or AI fluency cannot replace correction.

A confirmed stop before Core ends the current pass. A later analytical or rendering step cannot retrospectively neutralize that stop. Where a safer question or receiving frame is identified, it must begin as a new, separately bounded case rather than as a same-run continuation.

Closure is allowed, but only within scope. The final analytical decision state must be explicit: proceed, revise, downgrade, suspend, refuse, or redirect. These outcomes are not a scale of success and failure. They must also remain distinct from the pipeline-control state that determines whether the current pass may continue.

A completed PMS-DISCIPLINE pass is therefore not a complete PMS application. It is a bounded record of entry control, path selection, reasons, limits, risks, non-use, rival pressure, correctability, permitted next steps, final analytical decision state, and—where needed—the boundary between the current result and any separately bounded future case.

## Miniature Orientation Example

Consider a team disagreement. Two members of a project team disagree about whether a planned release should proceed. One person says the release is responsible because the core functionality works. Another says the release should be delayed because unresolved edge cases may expose users to avoidable failure.

A PMS reading may make this scene structurally legible. It may identify differences in framing, competing impulses, expectations around non-events, asymmetries of responsibility, temporal pressure, and possible integration problems. But the fact that PMS can read the scene does not yet determine which application path is disciplined.

The disagreement does not automatically trigger PMS-CONFLICT. A disagreement is not yet a conflict in the PMS-CONFLICT sense. CONFLICT would require more than opposed views. It would require a stable divergence of integration paths under relevant asymmetry, temporality, distance, and cost pressure. If that threshold is not met, refusing CONFLICT is the disciplined result.

The scene may instead remain Core-only. If the intended use is only to orient the discussion, identify the relevant frame differences, and keep the claim low, PMS Core may be sufficient. Core-only is not a failure of application. It may be the most disciplined outcome when the input and intended use do not justify a more specific lens.

Alternatively, the scene may justify a CRITIQUE-oriented path if the central issue is not stable conflict but interruptible correction: whether one release claim can answer to object, reason, standard, and possible disconfirmation. In that case, CRITIQUE may sharpen the reading without turning the team disagreement into a conflict classification.

The point of the example is not to offer a theory of team conflict. It is to show routing discipline. The same surface topic can lead to different PMS paths depending on operator-load, risk-shape, claim-shape, input status, rival pressure, and intended use. Add-on selection follows structural load, not surface vocabulary.

A false add-on trigger is not harmless. It changes the reading corridor. Calling the scene CONFLICT too early may make the case appear more terminal, adversarial, or determinate than the input supports. Refusing an add-on, remaining Core-only, downgrading the claim, or redirecting the reading may therefore be the disciplined outcome.

---

## Part I — Position and Boundary

## 1. Why PMS-DISCIPLINE Exists

### 1.1 Strong Readability Requires Restraint

PMS-DISCIPLINE exists because PMS can read strongly. The problem addressed here is not a lack of structural readability, but the premature hardening of readability into use.

PMS is designed as a generative operator grammar of praxis. It can make action, asymmetry, temporality, recontextualization, distance, integration, and self-binding structurally legible across a wide range of scenes. This productivity is a strength. But the same strength creates a risk: a reading that feels clear, deep, or structurally elegant can begin to appear more licensed than it is.

Strong readability can harden into claim authority. It can become person capture, add-on escalation, template ritualization, artefact authority, YAML authority, or model-generated confidence. A PMS reading may organize a scene powerfully and still not be justified for the intended use. It may illuminate a structure without licensing a stronger claim, a public output, a person-near judgment, an institutional decision, or an automated workflow.

PMS-DISCIPLINE therefore does not begin from distrust of PMS. It begins from the opposite condition: PMS is strong enough to require disciplined use. The risk addressed by PMS-DISCIPLINE is not PMS failure, but premature confidence produced by PMS success.

PMS-DISCIPLINE governs the transition from reading to use. It asks when a reading may proceed, when it must be revised, when a claim must be downgraded, when an application must be suspended, when use must be refused, and when a rival or domain-specific frame should redirect the application. In this sense, DISCIPLINE is a restraint layer, not a replacement layer. It constrains PMS use without replacing PMS Base.

### 1.2 From PMS Readability to PMS Use

The central threshold of this document is simple:

```text
Can PMS read this?
≠
May this reading be used?
```

A PMS reading may be structurally possible and still not be licensed for the intended use. Readability is not yet permission. Mapping is not yet use. Use is not yet publication. Publication is not yet authority. Authority is not granted by PMS-DISCIPLINE.

This distinction matters because use adds burden. A private exploratory reading does not carry the same burden as a public claim. A conceptual illustration does not carry the same burden as a person-near interpretation. A structural sketch does not carry the same burden as an institutional recommendation, technical implementation, automated output, or article-level synthesis. The stronger, more public, more irreversible, more person-near, or more technically mediated the use becomes, the more discipline the reading must bear.

That burden depends on input status, claim type, person-nearness, publicness, irreversibility, automation, rival pressure, and correctability. Weak input may support orientation but not intervention. Strong structural coherence may support a hypothesis but not certify truth. A precise add-on may sharpen a reading but also overdetermine a case. A model output may organize material but not become evidence.

PMS-DISCIPLINE governs this burden transition. Its question is not only whether PMS can read a case, but what kind of use that reading can responsibly bear. PMS readability may open a possible use-path; it does not license that use-path.

### 1.3 Corpus Position: UNDER LOAD and EDEN V2

PMS-DISCIPLINE is not an improvised disclaimer added from outside the PMS corpus. It is prepared by pressures already present in the development of the broader PMS project.

UNDER LOAD exposes PMS to non-sovereign self-critique. It prevents PMS from mistaking its own productivity for final authority. It keeps visible the possibility that a strong PMS reading may become too assimilative, too coherent, too confident, or insufficiently answerable to what resists capture.

EDEN V2 prepares correctability as a central concern. It develops the question of how structure, error, transformation, and repair remain possible without turning coherence into immunity. Correctability is therefore not imported into PMS-DISCIPLINE from an external moral or procedural framework. It is generalized from tensions already active within the corpus.

PMS-DISCIPLINE inherits both pressures. From UNDER LOAD it inherits non-sovereignty: PMS must not become protected by its own explanatory power. From EDEN it inherits correctability: structure remains disciplined only where correction can still matter. PMS-DISCIPLINE turns these pressures into a corpus-wide discipline of use.

This does not make PMS-DISCIPLINE a YAML version of UNDER LOAD, nor an extension of EDEN into a general theory. It remains a distinct document with a distinct function. UNDER LOAD prevents sovereignty. EDEN prepares correctability. PMS-DISCIPLINE generalizes both into application discipline.

### 1.4 Discipline Without Sovereignty

PMS-DISCIPLINE may constrain PMS use, but it cannot become sovereign over the case.

This distinction is essential. A discipline of use is not an authority of truth. PMS-DISCIPLINE can require weaker claims, clearer input status, stronger rival pressure, add-on restraint, person-nearness caution, template non-ritualization, correctability preservation, downgrade, suspension, refusal, or redirection. It can stop a PMS application from proceeding in a given form. It can require that a reading remain exploratory. It can require that a claim be revised before use.

But PMS-DISCIPLINE cannot certify PMS as true. It cannot validate PMS Base. It cannot certify maturity, dignity, safety, justice, neutrality, or reality. It cannot rank persons. It cannot become a tribunal. It cannot turn a review gate, template, YAML file, threshold table, or case-pass record into an authority layer.

Its force lies in constraint, not sovereignty. It can limit, weaken, stop, or redirect PMS application. It cannot convert disciplined use into guaranteed truth.

This also means that refusal is within DISCIPLINE. Suspension is within DISCIPLINE. Redirection is within DISCIPLINE. A disciplined application does not succeed by always proceeding. It succeeds when the chosen decision state fits the burden of the claim, the status of the input, the risk of the use context, the presence of rival accounts, and the availability of correction.

PMS-DISCIPLINE is therefore strongest where it remains non-sovereign. It protects PMS use not by elevating PMS authority, but by preserving the possibility that PMS use can be bounded, corrected, stopped, or redirected.

### 1.5 Adult, but Not Neutral

PMS-DISCIPLINE is not neutral.

It selects.

It selects for weaker claims where burden is insufficient, for scene-boundness over person capture, for correctability over coherence, for rival pressure over PMS overfit, for add-on restraint over add-on maximization, for stop-capability over workflow completion, and for answerability over claim authority.

This selectivity is not an error in the document.

It is the document’s function.

A discipline of PMS use cannot be neutral between overclaim and restraint, between correction and immunity, between person capture and scene-bound interpretation, between template completion and actual adequacy, or between AI fluency and accountable review. To govern PMS use is already to prefer certain application forms over others.

But this non-neutrality is not tribunal authority.

PMS-DISCIPLINE does not rank persons.

It does not rank dignity.

It does not diagnose maturity.

It does not certify adultness (adult direction = application-path direction, not adultness verdict).

It does not decide who is more mature, more rational, more responsible, or more worthy.

Its adult direction is not a person-ranking direction. It is a use-discipline direction.

Adultness is not an additional PMS axis, score, or person attribute.

“Adult” here means that an application becomes more disciplined when it can carry its own limits, expose its own burden, preserve correction, remain answerable to rival accounts, weaken itself where needed, and stop where stopping is the responsible outcome.

Adultness therefore names the direction of the application path, not the worth of a person.

A PMS-DISCIPLINE pass may be adult in this sense when it refuses a stronger reading, stays Core-only, rejects an add-on, lowers the claim type, suspends application, redirects to a rival account, or preserves unresolved status instead of forcing closure.

The relevant invariance is not that independent reviewers produce identical readings.

The relevant invariance is that independent disciplined passes should converge toward compatible constraint outcomes: lower overclaim, clearer input status, more explicit claim boundaries, preserved rival pressure, stronger correctability, and visible stop-capability.

Two disciplined passes may differ in emphasis.

They may assign different local salience.

They may route through different add-on scans.

They may preserve different rival accounts.

But if both passes become less overclaiming, less person-capturing, more bounded, more answerable, and more correctable, then they converge in the direction PMS-DISCIPLINE requires.

This is the sense in which PMS-DISCIPLINE is adult, but not neutral.

It is not neutral because it prefers responsible use over fluent use.

It is adult because its preference is not domination, certification, ranking, or verdict, but bounded answerability under conditions where PMS readability could otherwise become authority.

The compact formula is:

```text
PMS-DISCIPLINE is adult, but not neutral.

Adult:
because it selects for claim restraint, correctability, rival pressure,
scene-boundness, stop-capability, and accountable use.

Not neutral:
because it refuses to treat overclaim, person capture, template completion,
AI fluency, and workflow authority as equally admissible use paths.

Not tribunal:
because this direction does not rank persons, certify maturity,
measure dignity, decide truth, or validate PMS Base.
```

### 1.6 Guiding Sentence

PMS-DISCIPLINE begins where PMS readability becomes strong enough to require restraint.

---

## 2. Status, Non-Authority, and Relation to PMS.yaml

### 2.1 What PMS-DISCIPLINE Is

PMS-DISCIPLINE is a discipline of application. It is not a new layer of PMS, not an additional operator set, and not a replacement for the base grammar. Its task is to govern how PMS-based readings are used once they move beyond structural readability.

PMS-DISCIPLINE performs several functions in any responsible PMS use. It governs path selection, claim boundaries, input status, operator use, add-on triggering, add-on non-use, rival pressure, person-nearness, AI-assisted work, template mediation, correctability, closure, and stop-capability. These are not separate modules added to PMS. They are use-disciplines for PMS-based application.

Its categories therefore govern use; they do not extend the operator grammar. PMS-DISCIPLINE does not add new PMS operators, redefine existing operators, or change the dependency structure of PMS Base. It names the conditions under which PMS-based readings may be responsibly bounded, revised, downgraded, suspended, refused, or redirected. Where weakening is required, it occurs within revision or downgrade rather than as a separate final decision state.

This positive status matters. PMS-DISCIPLINE is not defined only by what it excludes. It has force because it can constrain use. It can require that a claim remain exploratory, that an add-on not be used, that a rival account be tested, that person-nearness lower the claim ceiling, that AI output remain marked as model output, or that an output preserve explicit correctability. But this force remains application-bound. It disciplines PMS use without becoming a new source of PMS authority.

### 2.2 What PMS-DISCIPLINE Is Not

The exclusions that define PMS-DISCIPLINE are not rhetorical disclaimers. They are its use-boundary.

PMS-DISCIPLINE does not define PMS Base. It does not add operators. It does not revise the PMS operator order. It does not replace PMS.yaml. It does not validate PMS as true, complete, final, safe, or superior to rival systems. It does not certify correctness. It does not validate cases. It does not govern users. It does not rank persons. It does not authorize automated decisions. It does not formalize UNDER LOAD. It does not turn EDEN, templates, YAML routing, review gates, or case-pass records into authority layers.

This boundary is necessary because review layers can become dangerous when they are mistaken for authority layers. A routing aid can be mistaken for governance. A review gate can be mistaken for certification. A threshold table can be mistaken for proof. A template can be mistaken for adequacy. A case-pass record can be mistaken for a verdict. A YAML interface can be mistaken for an automated decision layer.

PMS-DISCIPLINE may discipline use, but it does not become the source of PMS validity. It may constrain an application, but it cannot certify the truth of the case. It may require downgrade, suspension, refusal, or redirection, but it cannot become a tribunal. Its exclusions define the boundary that keeps application discipline from becoming sovereignty.

### 2.3 Relation to PMS.yaml

PMS.yaml remains the reference specification of the PMS base grammar. It records the current operator inventory, dependency path, derived constructs, and repository-level application guardrails for PMS-based use. PMS-DISCIPLINE does not replace that function.

The relation is therefore:

```text
PMS.yaml
= reference specification of the PMS base grammar

PMS-DISCIPLINE paper
= conceptual and methodological account of disciplined PMS use

PMS-DISCIPLINE.yaml
= possible production-support and application-flow interface derived from the paper
```

PMS.yaml defines the grammar. PMS-DISCIPLINE governs the responsibility of its use. A discipline of use does not revise the grammar it disciplines unless the base specification itself is explicitly revised.

This distinction prevents a common drift. PMS-DISCIPLINE may constrain how PMS is applied, but it does not become a second base schema. It may weaken, stop, suspend, refuse, or redirect an application, but it may not redefine PMS operators while claiming to discipline their use. It may require add-on restraint, but it may not convert add-on routing into grammar revision. It may support future YAML workflows, but PMS-DISCIPLINE.yaml must not be confused with PMS.yaml.

PMS-DISCIPLINE also cannot certify PMS as true, complete, final, or superior. The role of PMS.yaml as a repository reference does not become epistemic finality; the role of PMS-DISCIPLINE as an application discipline does not become authority over reality. The distinction between grammar reference and use discipline must remain visible throughout the document.

### 2.4 Relation to PMS Core, Add-ons, Downstream Layers, and the Wider Corpus

PMS-DISCIPLINE governs responsible movement through the PMS corpus. It does not stand above that corpus as sovereign.

The application order begins with a DISCIPLINE Entry Gate rather than with Core analysis. Pre-Analysis establishes the case boundary, input and source status, intended use, requested-output disposition, preliminary claim ceiling, protection conditions, and eligibility for Core entry. It may prepare a bounded analytical path, require correction, or stop the current pass before Core.

Core remains primary among analytical layers. This means that no PMS add-on, MIP layer, AHP layer, Case Record integration, Iteration Handoff, or article rendering may substitute for or bypass Core where Core entry has been permitted. It does not mean that Core precedes the Pre-Analysis decision about whether analytical entry is allowed.

The disciplined layer order is:

```text
1. Pre-Analysis / DISCIPLINE Entry Gate
2. PMS Core
3. At most one selected PMS add-on
4. Optional MIP under its own gate, source discipline, and claim boundary
5. Optional AHP after an actually produced and checked MIP application
6. Case Record Stages 1–3
7. Optional Iteration Handoff
8. Optional Markdown article workflow
```

This order is a discipline of dependency and responsibility, not a hierarchy of truth or authority. Later layers do not become more authoritative because they occur later, contain more detail, or integrate more artefacts.

Add-ons remain optional precision lenses. ANTICIPATION, CRITIQUE, CONFLICT, LOGIC, EDEN, and SEX may become relevant under specific operator-load, risk-shape, or claim-shape conditions. An add-on may sharpen use, but it does not authorize it. The more specific the lens, the more carefully its trigger, non-trigger conditions, overuse risks, rival pressure, and claim boundaries must be marked.

Within one bounded PMS-DISCIPLINE pass, at most one PMS add-on is selected. Where several add-on perspectives appear relevant, the first question is whether the material contains several analytically distinct subproblems. Such subproblems should normally be treated as separately bounded subcases, each with its own Core reading, add-on gate, claim ceiling, rivals, and stop conditions. Their records may later be integrated without converting them into a single mixed-add-on analysis pass.

MIP and AHP require a separate distinction. They are not ordinary PMS add-ons in the DISCIPLINE routing sense. They are downstream own-output layers that may follow a Core-only or Core-plus-one-add-on case only where their own dependency, gate, source, and claim conditions are met.

MIP does not become relevant merely because the material contains:

```text
maturity vocabulary
routine process pressure
a deadline
delay
loss of options
workflow friction
ordinary responsibility language
a hypothetical reference to a real person
a general concern about practice quality
```

These conditions may justify attention, but they do not by themselves establish a MIP route.

MIP pressure becomes structurally relevant only where the current case or intended output places material load on one or more of the following:

```text
person-evaluative judgment
responsibility attribution
role-capability assessment
practice under consequential burden
dignity, face, or status exposure
reputational consequence
maturity-in-practice claims
person-affecting evaluative transmission
```

The trigger must be actual to the case or intended use. A merely hypothetical real-person possibility does not activate MIP unless the present output would itself evaluate a person, shape how a person is treated, or create a materially person-near evaluative artefact.

MIP Source Reading and MIP Case Application must remain semantically distinct.

**MIP Source Reading** means reading the MIP source on its own terms in order to preserve its internal concepts, limits, non-use conditions, and possible application modes. It does not itself apply MIP to the case, produce MIP findings, or establish a MIP route.

**MIP Case Application** means applying MIP to the current bounded case after the checked MIP Gate and the responsible route decision have selected MIP use.

The human route after the checked MIP Gate remains binary:

```text
do not use MIP

or

use MIP
```

A recommendation to read the MIP source does not create a third analytical route. Source Reading may prepare responsible MIP use, but the case route remains either non-use or use.

Where MIP is used, it may operate either as a fully supported case application or in a limited Conditional Transfer / Boundary Use mode.

Conditional Transfer / Boundary Use allows MIP to examine:

```text
burden conditions
application boundaries
red zones
non-use conditions
claim restraint
person-nearness risk
misuse risk
requirements for responsible practice
```

without evaluating the maturity or developmental status of a real person.

In this limited mode:

```text
no hard A/M scoring is permitted
no D activation is permitted
no IA/D verdict is permitted
no maturity ranking is permitted
no developmental evaluation is permitted
no whole-person assessment is permitted
```

Conditional Transfer / Boundary Use is still a form of MIP use. It does not create a third route between MIP non-use and MIP use. Its limitation belongs to the application mode and claim boundary within the `use MIP` route.

AHP remains subordinate to MIP. AHP does not become available because MIP was mentioned, because MIP Source Reading occurred, because the MIP Gate recommended attention, or because the case contains evaluative pressure.

AHP is available only after:

```text
a MIP route was selected
a MIP Case Application was actually produced
that MIP output was checked
the checked MIP output is eligible for downstream use
```

AHP remains a second-order analysis-quality overlay. It may examine how the MIP analysis was constructed, bounded, transmitted, hardened, or exposed to misuse.

It may not:

```text
correct or replace the MIP analysis
reanalyze the underlying person or case
rescore MIP
activate D
change an IA/D status
upgrade evidence
raise the claim ceiling
certify maturity
become an authority layer
```

The Case Record follows the checked analytical route. It indexes eligible artefacts, extracts bounded layer digests, and integrates the current record without creating new case claims. The optional Iteration Handoff follows the checked Case Record and prepares possible future work without becoming Case Record Stage 4, reopening the present case, or inheriting its authority. The optional article workflow follows the record and renders it into prose without performing new analysis.

The same non-authority rule applies to templates, checked outputs, case-pass artefacts, article records, and iteration handoffs. They may make PMS use more repeatable, inspectable, comparable, and transferable. They may preserve operator omissions, add-on non-use, rival accounts, unresolved risks, stop decisions, downstream-layer non-use, and future questions. But they do not prove adequacy.

A completed template is not a verdict. A checked artefact is not evidence. A MIP output is not a maturity certificate. An AHP output is not an authority layer. A case-pass record is not closure. An integration record is not authority. An Iteration Handoff is not a license to inherit findings, routes, evidence status, claim ceiling, or claim authority into a future case.

If PMS-DISCIPLINE is operationalized in YAML-supported workflows or service-independent tooling, non-authority must remain visible at every relevant gate. An Entry Gate, Core check, add-on routing step, add-on check, MIP Gate, MIP Source Reading, MIP application or check, AHP gate or check, Case Record stage, Iteration Handoff, article rendering contract, or final article check may support disciplined use. It may not govern the case, certify the output, replace responsible judgment, or treat workflow completion as authorization.

A confirmed Entry-Gate stop nevertheless has procedural force within the current pass. It prevents later workflow steps from treating the stopped case as eligible input. This does not make the template, AI system, YAML field, or review artefact an authority over truth. It means only that the discipline cannot preserve stop-capability while allowing the same workflow to ignore its checked protection boundary.

The more useful PMS-DISCIPLINE becomes as a workflow interface, the more explicitly it must repeat that workflow is not authority, downstream specificity is not stronger warrant, a stop is not a verdict about the whole case or person, and iteration is not inheritance.

### 2.5 Required Output Orientation

PMS-DISCIPLINE changes the form of legitimate PMS output. A disciplined output must not be a bare label, a fluent interpretation, a completed template, a strong PMS vocabulary applied to a case, or a follow-up suggestion that silently extends the current result. It must be a bounded record of reasons, limits, risks, permitted next steps, and non-permitted uses.

A DISCIPLINE output must keep three different status dimensions separate:

```text
requested-output disposition
pipeline-case disposition
final analytical decision state
```

**Requested-output disposition** states whether the output requested by the user or use context may be produced in the requested form. The requested output may be permitted, require revision or weakening, or be refused because its form exceeds the available burden or violates a protection boundary.

**Pipeline-case disposition** states whether the current bounded pass may enter or continue through the next workflow stage. A case may remain eligible to proceed, require correction before proceeding, or be stopped. `stop` is a control state of the current application path. It is not a seventh analytical decision state.

**Final analytical decision state** states the substantive bounded outcome reached by the DISCIPLINE pass:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

These three dimensions may interact, but they must not collapse into one another. A requested output may be refused while the pipeline case is stopped. In that situation, `refuse` names the analytical boundary and `stop` prevents later steps from continuing the current pass. A requested output may also require revision while the pipeline remains conditionally open. A redirect may identify another frame or question, but after a protective stop it does not continue the same pipeline case. The receiving direction must begin as a new, separately bounded pass.

At minimum, a DISCIPLINE output should therefore state:

```text
status of the reading
requested-output disposition
pipeline-case disposition
final analytical decision state, where reached
reasons for each controlling status
limits of the claim
unresolved risks
input- and source-status constraints
claim type and claim ceiling
permitted next step
prohibited next steps
reopening conditions
```

In more complex cases, it should also state which add-on was used, which add-ons were explicitly not used, which were rejected as over-application, whether MIP or AHP were separately gated, which rival accounts remain relevant, what person-nearness or publicness risks are present, whether correctability has been preserved, and whether any future work requires a separately bounded follow-up case.

The output must make clear not only what PMS read, but what the reading may not claim and what the current workflow may not do. A PMS output overclaims when it hides its non-use, leaves input status unmarked, treats model output as evidence, collapses rival pressure into PMS vocabulary, converts a requested-output refusal into an unmarked weaker substitute, treats a stopped case as eligible for Core, turns a Case Record into a verdict, or treats an Iteration Handoff as confirmation that the current analysis is incomplete, stronger than stated, or transferable as evidence.

The six analytical outcomes are not a hierarchy from success to failure. A disciplined output may proceed. It may also require revision, downgrade, suspension, refusal, or redirection. Refusal and redirection are not failures merely because they prevent the requested use. A pipeline stop is likewise not a failed workflow. It is the control consequence required when the current case must not enter or continue through later stages.

In person-near, public, institutional, technical, automated, or article-level contexts, the output may also require explicit human confirmation of the final analytical decision state and permitted use boundary. Human confirmation does not turn a stopped case into an eligible case, certify truth, or override a protection boundary. It locates responsibility for accepting the bounded result, correcting the case inputs, or beginning a new separately bounded pass.

Where the current pass indicates possible further work, that indication must be separated from the current result. Current sufficiency, iteration value, iteration urgency, and follow-up-case preparation are different questions. A case may be provisionally sufficient for its original intended use and still generate a useful follow-up question. A case may also be insufficient or stopped for its intended use without thereby authorizing a stronger current claim or an inherited continuation.

Follow-up preparation is prospective. It does not change the current case result, claim ceiling, source status, pipeline disposition, route state, or sufficiency assessment. Where a protective stop has occurred, a possible redirect or follow-up target may orient a future case, but it cannot reopen or continue the current one without a new case boundary and renewed input, route, rival, claim, and protection review.

A disciplined output preserves the possibility of correction at the point where it closes operationally. It is not final because it is complete. It is disciplined because its reasons, limits, risks, non-use, correction conditions, control state, and iteration boundaries remain inspectable.

### 2.6 Guiding Sentence

PMS-DISCIPLINE may constrain PMS use, but it does not become an authority above PMS.

---

## Part II — PMS Application as Path Selection

## 3. No Complete PMS Application

### 3.1 Incomplete Application Manifold

There is no complete PMS application. Every PMS use is a scene-bound, purpose-bound path through an incomplete application manifold.

This is not a defect of PMS-DISCIPLINE. It is the condition that makes discipline necessary. PMS is a generative operator grammar with broad structural reach, but no application of that grammar exhausts PMS, the case, reality, or the person under consideration. Any actual use of PMS must select a scene, an input boundary, a frame, a depth of reading, locally salient operators, possible omissions, possible add-ons, rival accounts, claim limits, and a stopping point.

A PMS application is not incomplete because it failed to include everything. It is incomplete because application itself requires path selection. To use PMS is not to execute the total grammar. It is to move through a bounded corridor of relevance under a specific intended use.

This means that incompleteness is unavoidable. The question is not whether a PMS application leaves something out. Every application does. The disciplined question is whether the application marks what it leaves out, what it does not claim, what it does not cover, and where correction remains possible.

A PMS use becomes disciplined only when its path-selection is visible.

### 3.2 Path Selection Instead of Total Application

PMS application is path selection, not total execution.

A disciplined PMS use must decide what scene is being read, what input is available, which frame is operative, which operators are locally salient, which operators may be omitted, which claim type is intended, which add-ons are justified, which add-ons are not justified, which rival accounts remain relevant, and which final decision state is justified: proceed, revise, downgrade, suspend, refuse, or redirect.

Path selection therefore includes both selection and non-selection. Not using an operator may be disciplined. Not using an add-on may be disciplined. Leaving a rival account open may be disciplined. Suspending a reading may be disciplined. Redirecting to a rival or domain-specific frame may be disciplined.

This prevents a common misunderstanding: non-use is not necessarily omission failure. It may be the form discipline takes. A PMS application overclaims not only when it says too much, but also when it hides the paths it did not take. A disciplined PMS use must justify both the path it takes and the paths it does not take.

Path selection is not arbitrary choice. It is constrained by input status, intended use, claim burden, operator-load, rival pressure, person-nearness, publicness, correctability, and stop-capability. The point is not to apply as much PMS as possible. The point is to make the chosen PMS path bounded, inspectable, and answerable.

### 3.3 No Add-on Maximization

Add-on maximization is not disciplined PMS use.

Add-ons are optional precision lenses. They are not completion layers, authority sources, or quality signals. More add-ons do not make a PMS application more adequate. They may instead make a bounded reading appear more determinate than the input, risk, or intended use can support.

Core-only may be the most disciplined result. If the intended claim is low-burden, if the input does not justify a specialized lens, if the use is exploratory, or if an add-on would create false precision, PMS Core may be sufficient. Core-only is not a failure of application. It may be the clearest sign that the application has not overreached.

Unnecessary add-ons can overdetermine a case. They can import absent assumptions, intensify person-capture, inflate claim strength, suppress rival accounts, or shift a reading into the wrong corridor. A disagreement may be forced into CONFLICT. A complaint may be forced into CRITIQUE. A future reference may be forced into ANTICIPATION. A sexual term may be forced into SEX. In each case, the surface cue may justify a scan, but not an add-on.

The question is therefore not how many add-ons can be applied, but which add-on, if any, the case can responsibly bear. Add-on use must increase accountability, not interpretive volume. Add-on non-use may be the disciplined outcome.

### 3.4 Bounded Adequacy Replaces Completeness

Completeness is not the standard of disciplined PMS use. Bounded adequacy is.

A PMS reading is adequate only relative to the claim it is asked to carry. A partial reading may be adequate for orientation, structural sketch, hypothesis, or bounded reconstruction. The same reading may be inadequate for evaluation, recommendation, intervention, institutional use, technical implementation, or public claim. Adequacy is therefore not measured by how much PMS has been applied, but by whether the reading fits its claim type, input status, risk, use context, rival pressure, and correctability conditions.

This distinction matters because a reading can be coherent but still inadequate for the intended use. It can be elegant but unsupported. It can be structurally rich but too strong for the input. It can use many operators and still miss the operator that would weaken it. It can complete a template and still fail to preserve correction. It can use an add-on and become less adequate by exceeding the burden the case can bear.

Bounded adequacy replaces the fantasy of complete application. It allows PMS-DISCIPLINE to say that a limited reading may be adequate, while a more complete-looking reading may be undisciplined. Adequacy is not internal elegance. It is bounded fit between claim, input, risk, rival pressure, use context, and correctability.

### 3.5 Marked Incompleteness

Incomplete PMS application is unavoidable. Unmarked incompleteness is the defect.

A disciplined application must show what was read and what was not read. It must show which operators were assigned, which operators were locally salient, and which possible omissions might materially change the reading. It must show which add-ons were used, which add-ons were explicitly not used, and which add-ons were rejected as over-application. It must show which rival frames remain possible, which claim strength is not licensed, and where correction remains possible.

Marked incompleteness is not modesty added after the analysis. It is part of the analysis. It prevents PMS coherence from hiding what the reading did not test, did not cover, did not justify, or did not have the burden to claim.

This is especially important in template- or YAML-supported use. A completed form can conceal incompleteness if it marks fields as filled while leaving input weakness, add-on non-use, rival pressure, or reopening conditions invisible. A case-pass record becomes disciplined only when it preserves what remains missing, contested, unresolved, not licensed, or correctable.

The defect is not that a PMS application leaves something out. The defect is that it hides what it leaves out.

### 3.6 Guiding Sentence

Incomplete PMS application is not a defect; unmarked incompleteness is the defect.

---

## 4. Core, Add-ons, and Non-Mixing

### 4.1 Core Primacy

PMS Core remains primary among analytical layers.

This does not mean that Core decides everything or that Core precedes entry discipline. It means that, where the effective checked Pre-Analysis permits analytical entry, Core supplies the grammar-bound starting condition for any PMS analytical layer that follows. Any PMS use that moves toward a PMS add-on, MIP, or AHP must first pass through a Core reading sufficient to establish the relevant scene, frame, operator field, source boundary, and claim ceiling.

PMS add-ons presuppose Core. They cannot replace Core, bypass Core, or become a substitute for Core calibration. MIP and AHP likewise cannot bypass Core where analytical entry has been permitted. Without a sufficiently stable Core reading, later specificity becomes unbound use: a specialized vocabulary begins to lead the reading before the base grammar has established what is structurally at stake.

Core may also remain sufficient. If the input is limited, the claim is low-burden, the intended use is exploratory, or no later-layer threshold is met, Core-only may be the disciplined outcome. Core primacy therefore does not mean Core maximalism. It means that no specialized analytical path should be entered before the base reading has been made answerable.

No PMS add-on or downstream own-output layer can substitute for a missing or ineligible Core pass.

### 4.2 PMS Add-ons as Precision Lenses

A PMS add-on is a precision lens, not an authority source.

The PMS add-on set used in DISCIPLINE consists of:

```text
ANTICIPATION
CRITIQUE
CONFLICT
LOGIC
EDEN
SEX
```

These add-ons may sharpen accountability within the specific corridors of future burden and present commitment, answerable disturbance, stable conflict structure, inference and consistency, correction and repair, or sexuality and intimacy. They do not make the case more true by themselves.

Maturity-in-practice and analysis-hardening pressure do not belong to this PMS add-on list. They are handled, where separately gated, through the downstream MIP and AHP layers.

A PMS add-on does not add authority. It does not create a stronger claim merely by being used. It does not classify the case. It does not become a new primitive. It does not repair an unclear Core reading. It does not turn thematic proximity into structural warrant.

The positive function of an add-on is narrower and more demanding. It increases accountability within a specific risk corridor by making trigger conditions, non-trigger conditions, overuse risks, claim limits, rival pressure, and possible downgrades more explicit. In disciplined use, the more specific lens is not automatically the better lens. It may also be the more dangerous lens if it overdetermines the case.

PMS add-ons increase accountability; they do not increase claim authority by themselves.

### 4.3 Non-Mixing Rule

Add-ons may sharpen a Core reading. They may not switch the grammar while claiming PMS conformity.

The Non-Mixing Rule protects PMS Core from being silently rewritten by its own applications. An add-on may not redefine PMS operators, introduce new meta-axioms as if they were PMS Base, or smuggle domain assumptions into PMS while presenting them as grammar-conformant. It may not make a weak Core reading appear stronger by adding specialized vocabulary.

This rule is especially important where an add-on is domain-sensitive. A domain lens may contain useful distinctions, risk markers, thresholds, or case-pass refinements. But those distinctions remain application supports. They do not become PMS primitives unless the base specification itself is explicitly revised.

A domain lens becomes undisciplined when it imports assumptions without marking them as assumptions. It becomes undisciplined when it turns domain familiarity into PMS authority. It becomes undisciplined when specialized vocabulary performs precision theatre: making a reading appear sharper without making its input, operator-load, claim boundary, or rival pressure more answerable.

Non-mixing is therefore not a restriction on refinement. It is the condition under which refinement remains honest. An add-on may sharpen the reading, but it may not change the grammar while pretending only to apply it.

### 4.4 Add-ons and Base Calibration

Add-on precision cannot compensate for Core underdetermination.

If the Core reading is unclear, the disciplined move is not immediate specification. The application must not proceed into add-on precision as if the base were stable. It must be revised, downgraded, suspended, refused, redirected, or kept explicitly exploratory. Where weakening is required, it belongs inside revision or downgrade, not beside the final decision states.

A precise add-on on top of an unstable Core produces false precision. It can hide uncertainty, launder weak input, intensify premature classification, or make a structurally underdetermined reading appear domain-confirmed. In such cases, add-on use does not repair the reading. It amplifies the defect.

This is why Core calibration must remain visible before add-on routing. The application must be able to say what the Core reading has established, what remains underdetermined, which operators are locally salient, which possible omissions matter, and what claim burden the reading can currently bear. Only then can an add-on be considered responsibly.

If Core remains unstable, the application may still continue in a weaker form. It may remain exploratory. It may ask for clearer input. It may test a rival account. It may downgrade the claim. It may suspend application. It may redirect to a non-PMS frame. What it may not do is use add-on specificity to make unclear Core calibration look precise.

### 4.5 Add-on Use as Accountability, Not Completion

Add-on use is accountability, not completion.

Because there is no complete PMS application, no add-on can complete one. An add-on does not finish the case, close the reading, or certify adequacy. It increases accountability relative to a specific trigger, risk-shape, claim-shape, or operator-load pattern.

A disciplined add-on may sharpen the reading. It may also sharpen the limits of the reading. It may show why a stronger claim is not licensed, why an apparent trigger is insufficient, why another frame remains necessary, or why the application should be downgraded, suspended, refused, or redirected.

This means that successful add-on use is not measured by how much it adds. It is measured by whether it makes the application more answerable. The add-on must clarify why it was used, what it contributes, what it does not authorize, what risks it introduces, and what claims remain unavailable.

An add-on is therefore not a completion badge. It is not a final interpretive layer. It is not proof of adequacy. Its function is to make a risk-specific reading more accountable within the limits of the case.

### 4.6 Add-on Plurality, Decomposition, and Non-Mixing

A single bounded PMS-DISCIPLINE pass uses at most one PMS add-on.

The default form of a pass is therefore:

```text
Core-only

or

Core plus one justified PMS add-on
```

This rule does not assume that cases are simple or that only one structural question can arise from the same material. It distinguishes material complexity from analytical boundary. A complex case packet may support several legitimate questions, but those questions do not thereby belong inside one undifferentiated add-on application.

Each PMS add-on introduces its own trigger burden, non-trigger burden, claim boundary, rival pressure, person-nearness risk, over-application risk, and correction conditions. Applying several add-ons inside one pass can make it unclear which question triggered which lens, which claim belongs to which layer, which rival defeats which reading, and which limitation controls the result.

Several add-ons may often appear relevant in a loose or exploratory sense. A future-oriented dispute may suggest ANTICIPATION, CONFLICT, CRITIQUE, and LOGIC. A public institutional case may suggest CRITIQUE, LOGIC, or EDEN. A person-near practice case may suggest EDEN or SEX and may separately create possible downstream MIP pressure.

This apparent plurality is not a reason to mix add-ons. It is a signal that the case boundary or analytical question may be too broad.

Where several PMS add-ons appear relevant, PMS-DISCIPLINE requires decomposition review.

The disciplined question is not:

```text
How many add-ons could usefully say something about this material?
```

The disciplined questions are:

```text
Which distinct analytical questions are present?

Which case boundary belongs to each question?

Which single add-on, if any, is justified for each bounded question?
```

The same body of material may therefore support several separately bounded subcases. Each subcase must declare its own:

```text
case boundary
analytical question
intended use
input and source status
Pre-Analysis
Core reading
claim ceiling
add-on trigger and non-trigger review
selected add-on or Core-only result
rival pressure
person-nearness burden
correctability and reopening conditions
final analytical decision state
```

A decomposition-first approach may produce, for example:

```text
Shared source material

Subcase A:
future burden and present commitment
→ Core + ANTICIPATION

Subcase B:
stable divergence of practical paths
→ Core + CONFLICT

Subcase C:
answerability of a contested claim
→ Core + CRITIQUE

Subcase D:
inference, contradiction, or standard consistency
→ Core + LOGIC

Later integration:
comparison and integration of the separately checked Case Records
```

This is not fragmentation for its own sake. It preserves analytical accountability. It prevents one add-on from laundering another and prevents the apparent completeness of a mixed reading from hiding distinct burdens.

Decomposition makes visible:

```text
which question each add-on answers
which trigger was actually established
which claims belong only to one subcase
which rivals remain live for each reading
which limits and stop conditions control each subcase
where the subcase results support one another
where they remain independent
where they conflict
where integration must preserve unresolved tension
```

A later Full Case Record may perform record-level integration of several separately bounded subcase records. Such integration does not retroactively create a multi-add-on analysis pass. It does not merge claim ceilings, treat one add-on’s findings as evidence for another, erase differences in source burden, rival pressure, non-use, or final analytical decision state, or generate a new whole-case conclusion from the mere coexistence of the subcase records.

Record-level integration may compare only findings already stated in the effective checked subcase records. It may preserve agreement, tension, independence, incompatibility, dependency, or sequence only where that relation is already explicit in, or directly supported by, those records. It may not infer a new cross-subcase causal, structural, evaluative, or person-level finding.

Conceptual interaction between add-on structures may still be discussed. An anticipatory commitment may contribute to a later conflict structure. A critique may expose a logical inconsistency. An EDEN-oriented correction process may alter the conditions under which a conflict remains stable. These interactions may be theoretically important, but theory-level interaction does not authorize record-level inference.

Where the relation between several subcases is itself a new analytical question, record integration must stop at that boundary. The relation requires a new, separately bounded analytical integration case with its own pre-entry review, checked Pre-Analysis, source status, intended use, Core pass, at most one selected PMS add-on, rival review, person-nearness review, claim ceiling, correctability conditions, and final analytical decision state.

Structural interaction does not require operational mixing. Record integration is not a substitute for a newly bounded analysis.

MIP and AHP remain outside the Single-Add-on Rule because they are not ordinary PMS add-ons. They are downstream own-output layers.

This does not mean that they are automatic completion layers after Core or a selected add-on.

MIP may follow a Core-only or Core-plus-one-add-on case only where its own checked gate establishes an actual downstream burden involving:

```text
person-evaluative pressure
responsibility attribution
role-capability assessment
practice under consequential burden
dignity, face, or status exposure
reputational consequence
maturity-in-practice claims
person-affecting evaluative transmission
```

Routine process, deadline pressure, delay, option loss, workflow difficulty, ordinary practical judgment, or a merely hypothetical real-person reference do not by themselves trigger MIP.

MIP Source Reading may be recommended where the MIP source must be understood before a responsible MIP Case Application or application-mode selection can occur. Source Reading is not itself MIP Case Application, does not decide the binary MIP route, and does not create a third route.

After the checked MIP Gate, the responsible route remains:

```text
do not use MIP

or

use MIP
```

Where the route is `use MIP`, the application may be:

```text
a supported MIP Case Application

or

a limited Conditional Transfer / Boundary Use
```

Conditional Transfer / Boundary Use may inspect burden, boundaries, red zones, claim restraint, and misuse risk. It may not perform real-person maturity evaluation, hard A/M scoring, D activation, IA/D verdicting, or developmental ranking.

AHP may follow only an actually produced and checked MIP application. MIP Source Reading, a gate recommendation, or MIP vocabulary is insufficient.

AHP may inspect the quality, boundaries, hardening risks, transmission risks, and misuse surface of the MIP analysis. It may not correct or replace MIP, rescore MIP, activate D, change IA/D status, upgrade evidence, raise the claim ceiling, or become an authority layer.

The compact rule is:

```text
One bounded pass:
Core-only or Core plus one PMS add-on.

If several PMS add-ons appear relevant:
decompose the material into distinct analytical subcases.

Each subcase:
receives its own Pre-Analysis, Core pass, add-on decision,
claim ceiling, rivals, correction conditions, and final decision state.

Later integration:
may compare and connect checked subcase records,
but does not create a mixed-add-on pass.

MIP:
is a separately gated downstream own-output layer.
Routine pressure and hypothetical person reference are not sufficient triggers.
The checked route remains MIP non-use or MIP use.

Conditional Transfer / Boundary Use:
is a limited MIP application mode,
not a third route and not a person evaluation.

AHP:
requires an actual checked MIP application
and remains subordinate to its limits.
```

Add-on plurality is therefore handled through decomposition and record integration, not through accumulation inside one analytical pass.

Downstream MIP or AHP use is handled through separate gates, source discipline, application boundaries, and checks—not through add-on maximization.

The aim is not to produce the fullest possible lens stack. It is to preserve the clearest accountable relation between question, trigger, analysis, claim, rival, and limit.

### 4.7 Guiding Sentence

An add-on is a precision lens, not an authority source.

---

## 5. Operator Order, Salience, and Non-Hierarchical Use

### 5.1 Dependency Order Is Not Hierarchy

The PMS operator order records dependency discipline. It is not a hierarchy of truth, maturity, dignity, or authority.

The repository order may be written as:

```text id="vldl30"
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

This sequence matters. It disciplines how operators become praxeologically intelligible in relation to one another. Δ (difference), ∇ (impulse), □ (frame), Λ (non-event), Α (attractor), Ω (asymmetry), Θ (temporality), Φ (recontextualization), Χ (distance), Σ (integration), and Ψ (self-binding) do not appear as an arbitrary list. Their order records dependencies in the grammar.

But dependency order is not hierarchy. Later does not mean higher. Later does not mean truer. Later does not mean more mature. A reading that reaches Ψ (self-binding) is not automatically deeper, more complete, or more authoritative than a reading that remains at Δ (difference), □ (frame), Λ (non-event), Ω (asymmetry), or Θ (temporality). More operators do not make a reading better. Operator count is not adequacy.

This distinction is essential because operator order can easily be misread as a ladder. Ψ (self-binding) can be mistaken for final authority. Dignity-in-Practice can be mistaken for a moral verdict. Coherence can be mistaken for truth. Responsibility can be mistaken for person judgment. Such readings confuse dependency discipline with evaluative hierarchy.

PMS-DISCIPLINE therefore keeps three things separate:

```text id="djfb65"
dependency order
local salience
claim authority
```

Dependency order disciplines derivation. Local salience guides a scene-bound reading. Claim authority depends on input status, claim type, use context, rival pressure, and correctability. These three must not collapse into one another.

Operator order disciplines use; it does not authorize claims.

### 5.2 Operators as Application Relations

Operators are not decorative labels added to a case. They are structural relations through which a case becomes praxeologically readable.

An operator is present when it does structural work. It is not present merely because its name can be associated with the topic. Difference is not assigned because something differs in ordinary speech. Non-event is not assigned because something is absent in a loose sense. Asymmetry is not assigned because a situation feels unfair. Self-binding is not assigned because a person appears committed. Operator assignment requires justification at the level of the reading.

A disciplined PMS use must therefore ask:

```text id="452tpg"
Which operators are structurally required?
Which operators are locally salient?
Which operators are doing interpretive work?
Which operators are overused?
Which operators are omitted?
Which omitted operators would materially change the reading?
```

Both overuse and omission matter. A reading can overclaim by assigning too many operators. It can also overclaim by omitting the operator that would weaken, qualify, complicate, or redirect the reading. PMS-DISCIPLINE therefore does not ask which operators can be mentioned. It asks which operators are doing work.

Operator assignment must be justified by structural work, not by symbolic availability.

### 5.3 Frame and Retroactive Legibility

Frame requires special care because it can easily be mistaken for a container added around an already given event.

□ (frame) is not a container added after Δ (difference) and ∇ (impulse); it is a condition of their praxeological determinacy. Difference and impulse become readable within a frame. The frame does not merely package them from outside. It helps determine how they become intelligible as differences and impulses in a practical field.

This means that frame can alter the legibility of what came before it in the reading. A later frame can make an earlier difference appear differently relevant. It can make an impulse appear responsive, disruptive, defensive, anticipatory, avoidant, or misdirected. It can reveal that what first appeared as a minor difference was structurally decisive, or that what first appeared decisive was an artefact of the frame itself.

But this is retroactive legibility, not retroactive causation. A frame can change what becomes praxeologically legible without changing what causally occurred. It can reorganize interpretation without rewriting the event. It can make a prior difference or impulse readable under a new relation, but it does not alter the past as fact.

This distinction protects PMS use from two opposite errors. Frame is not a passive container. But it is also not a causal rewrite. It structures readability; it does not authorize reality alteration.

Retroactive legibility is not retroactive causation.

### 5.4 Local Operator Dominance

An operator can be locally dominant without being hierarchically higher.

Dependency order is grammar-relative. Local dominance is scene-relative. In a given case, one operator may carry the main interpretive load even if it appears earlier, later, or less dramatically in the repository order. A scene may be organized primarily by Λ (non-event), Ω (asymmetry), Θ (temporality), Χ (distance), or Σ (integration) without that operator becoming superior to the others in the grammar.

Local dominance therefore guides the reading; it does not revise the theory. It does not make the locally dominant operator higher, truer, more mature, or more authoritative. It only means that, in this scene, under this input, for this intended use, that operator carries a decisive part of the structural burden.

This must still be justified by structural work. Local salience is not a license for operator absolutization. A locally dominant Ω (asymmetry) does not turn the case into an accusation. A locally dominant Ψ (self-binding) does not turn the case into a maturity verdict. A locally dominant Σ (integration) does not make integration compulsory. A locally dominant □ (frame) does not naturalize one frame as reality.

Salience is not sovereignty.

### 5.5 Operator Over-Assignment

Operator over-assignment occurs when thematic proximity replaces structural work.

This is one of the most likely failure modes in PMS use, especially where AI assistance, templates, add-on routing, or domain-specific vocabulary are involved. A model may match words to operators. A template may encourage field completion. A reader may feel that a richer PMS vocabulary produces a deeper reading. But semantic availability is not structural warrant.

Not every silence is Λ (non-event). Not every difference is Ω (asymmetry). Not every disagreement is Ψ (self-binding) failure. Not every discomfort is a Dignity-in-Practice violation. Not every negative statement is CRITIQUE. Not every critique is CONFLICT. Not every future reference is ANTICIPATION. Not every sexual metaphor is SEX.

The error is not that these associations are impossible. In some cases they may become structurally relevant. The error is to treat thematic nearness as activation. A term is not triggered because it is semantically available. An operator is not assigned because it can be named. An add-on is not justified because a topic resembles its domain.

PMS vocabulary becomes dangerous when it names what is merely nearby rather than what is structurally operative. Operator over-assignment can inflate claims, intensify person capture, moralize ambiguity, convert discomfort into verdict, or turn a weak reading into a precise-looking one.

A disciplined PMS application must therefore resist operator checklisting. The question is not whether an operator can be associated with the scene, but whether the reading changes responsibly when that operator is assigned.

### 5.6 Operator Omission

Operator omission is the counterpart to over-assignment. A reading can fail not only by adding too much, but by leaving out the operator that would materially change it.

Omission matters when an omitted operator would weaken, qualify, complicate, or redirect the reading. It matters when the reading becomes too accusatory, too coherent, too timeless, too integrated, too frame-naturalizing, or too person-capturing because a relevant operator was not considered.

For example, Ω (asymmetry) without Χ (distance) may become accusatory because asymmetry is read without sufficient distance from the case, the claimant, or the interpretive frame. Ψ (self-binding) without Θ (temporality) may ignore temporal burden by treating self-binding as maturity, failure, or closure without asking what time pressure, delay, repetition, or developmental sequence has done. Σ (integration) without Λ (non-event) may force integration over residue by treating what does not integrate as defect rather than structurally significant non-event. □ (frame) without rival framing may naturalize one frame by making the operative frame appear self-evident.

DISCIPLINE must therefore check not only what was assigned, but what was left out. Operator omission is relevant when the omitted operator would materially change the reading. A PMS output overclaims when it hides the operator that would have made its claim weaker, slower, more uncertain, more answerable, or more open to correction.

Omission discipline prevents PMS coherence from becoming premature closure.

### 5.7 Derived Axes as Projections

Derived axes are PMS-internal projections through the operator field. They are not primitives.

Awareness, Coherence, Responsibility, Enactment, and Dignity-in-Practice may help make PMS applications readable. They provide construct handles for recurring patterns of salience. They may support explanation, comparison, case-pass structure, and application discipline. But they do not become base operators. They do not rank persons. They do not certify maturity. They do not prove truth. They do not authorize stronger claims.

This distinction is necessary because derived axes can easily be reified. Awareness can be mistaken for a cognitive score. Coherence can be mistaken for a truth marker. Responsibility can be mistaken for a person verdict. Enactment can be mistaken for behavioral adequacy. Dignity-in-Practice can be mistaken for moral rank. PMS-DISCIPLINE rejects these readings.

A derived axis is an interpretive projection through the operator field, not a primitive. A compact formula is a salience mapping, not a dependency-closed proof. It shows how a construct may be read through selected operator relations; it does not prove unique mathematical derivability, exhaust the case, or authorize person-level ranking.

Derived axes make PMS application more readable. They do not make PMS claims more authoritative by themselves.

### 5.8 Operator-Load and Add-on Selection

Add-on selection follows operator-load, not vocabulary.

Operator-load does not mean that many operators have been named. It means that a structurally load-bearing configuration of operators creates a risk-shape or claim-shape for which an add-on may become relevant. The issue is not lexical proximity, topical resemblance, or symbolic density. The issue is whether the operator configuration creates a specific burden that the Core reading alone cannot responsibly carry.

A topic may suggest a possible scan; it does not trigger an add-on. A future reference does not automatically trigger ANTICIPATION. A disagreement does not automatically trigger CONFLICT. Sexual vocabulary does not automatically trigger SEX. Negativity does not automatically trigger CRITIQUE. Technical language does not automatically justify specialized routing. A maturity word does not automatically trigger MIP.

Add-ons require operator-load, risk-shape, and claim-shape. Even then, a trigger indicates possible relevance, not authorization. It opens a review path. It does not classify the case. It does not license a stronger claim. It does not require add-on use. The disciplined result may still be Core-only, add-on refusal, downgrade, suspension, rival redirection, or a weaker exploratory output.

Operator-load means structural work under risk, not lexical proximity.

### 5.9 Guiding Sentences

Dependency order ≠ local salience ≠ claim authority.

A derived axis is an interpretive projection through the operator field, not a primitive and not a mathematical proof of unique derivability.

Operator assignment must be justified by structural work, not by thematic association.

Add-on selection follows operator-load, not vocabulary.

---

## 6. Core Sufficiency, Add-on Triggering, and Add-on Non-Use

### 6.1 Core Sufficiency

Not every PMS reading requires an add-on.

PMS Core is sufficient when the intended claim remains bounded, the input status does not support specialized routing, and the use context does not require a more specific risk lens. Core sufficiency is determined by claim burden, not by the desire for interpretive richness. A case may be complex, interesting, or structurally rich and still remain Core-only if the intended use is exploratory, private, conceptual, reversible, or clearly limited.

Core-only is therefore not deficient. It is not a failed application, an unfinished analysis, or a preliminary stage that must be completed by add-ons. Core-only may be the most disciplined result when add-on use would create false precision, inflate the claim, suppress rival accounts, or make the case appear more determinate than the input supports.

Core suffices when the reading can remain answerable without specialized routing. It may suffice when the claim is low-burden, when no person-affecting, public, institutional, technical, or automated output follows, when the relevant operators can be handled within Core, or when the available input does not support a more specific add-on corridor.

The disciplined question is not whether an add-on could say more. It is whether saying more would remain accountable. If an add-on would intensify the reading without improving its boundedness, rival pressure, input discipline, or correctability, Core-only is the better outcome.

A disciplined Core-only output may be stronger precisely because it refuses false precision.

### 6.2 Add-on Triggering as Decision Logic

Add-on triggering is decision logic, not topic matching.

An add-on is not triggered by a keyword, topic label, domain resemblance, dramatic tone, or surface vocabulary. It is triggered only when a configuration of operator-load, risk-shape, and claim-shape creates a burden that Core alone may not responsibly carry.

A trigger indicates possible relevance. It does not automatically authorize use. It does not classify the case. It does not license a stronger claim. It does not require that the add-on be applied. A trigger opens a review path, not a classification path.

This distinction is central to PMS-DISCIPLINE. A triggered add-on still has to justify its own use. It must sharpen the reading without replacing Core, increasing claim strength illegitimately, suppressing rival accounts, importing absent assumptions, intensifying person-capture, or making the case look more determinate than it is.

The more specific lens must carry a higher burden of restraint. A specialized add-on may clarify a risk corridor, but it may also overdetermine the case. It may make a bounded Core reading appear conflictual, critical, anticipatory, sexual, technically formalized, mature, or artefact-hardened in ways the input does not support.

Add-on triggering therefore remains subordinate to Core sufficiency, input status, claim type, rival pressure, person-nearness, correctability, and stop-capability. The fact that an add-on could become relevant is not yet a reason to use it.

A trigger opens a review path; it does not authorize classification.

### 6.3 Compact Add-on Trigger Logic and Downstream Gate Distinction

A compact trigger map may help identify possible PMS add-on relevance. It must not become an automatic classifier.

The map is a scan aid, not a decision engine. It does not replace the Core pass. It does not replace add-on review. It does not override non-trigger conditions. It does not license stronger claims by itself.

Each possible PMS add-on trigger remains subject to the same discipline:

```text id="0cu6kx"
surface cue
≠
structural trigger

structural trigger
≠
automatic use

automatic use
≠
authorized claim
```

For example, future-oriented language may suggest a scan for ANTICIPATION, but future talk does not itself trigger ANTICIPATION. Disagreement may suggest a scan for CONFLICT, but disagreement does not itself trigger CONFLICT. Sexual vocabulary may suggest a scan for SEX, but sexual wording does not itself trigger SEX. Negativity may suggest a scan for CRITIQUE, but negativity does not itself trigger CRITIQUE.

Where several PMS add-ons appear relevant, the trigger map does not license a combined route. It indicates possible decomposition into separately bounded analytical questions.

MIP and AHP must not be folded into ordinary add-on trigger logic.

They are downstream own-output layers with their own dependency and gate conditions.

#### MIP Non-Triggers

The following do not by themselves establish a MIP route:

```text
maturity vocabulary
general practice-quality language
routine process
ordinary task performance
deadline pressure
delay
loss of an option
workflow friction
ordinary responsibility language
a difficult decision
a hypothetical reference to a real person
the possibility that a future output might involve a person
```

These conditions may create practical pressure, temporal burden, or a reason for caution. They do not yet establish maturity-in-practice relevance.

A hypothetical person reference becomes MIP-relevant only where the present case or intended output actually introduces person-evaluative, status-affecting, dignity-affecting, role-capability, responsibility, or reputational pressure.

#### MIP Trigger Burden

MIP becomes eligible for review only where a checked Core-only or Core-plus-one-add-on case establishes a materially load-bearing downstream question involving one or more of:

```text
evaluation of practice under consequential burden
responsibility attribution
role-capability assessment
maturity-in-practice claims
dignity or face exposure
status or reputational consequence
person-affecting evaluative transmission
risk of converting local practice into person judgment
```

Even then, MIP relevance does not automatically require MIP use.

The MIP Gate must determine whether the MIP source and application would add accountable visibility without creating person capture, maturity ranking, false precision, or a claim the available input cannot bear.

#### MIP Source Reading and MIP Case Application

MIP Source Reading and MIP Case Application are different activities.

```text
MIP Source Reading
= bounded reading of the MIP source, its concepts,
  limits, red zones, and available modes

MIP Case Application
= application of MIP to the current checked case
  after the route decision selects MIP use
```

MIP Source Reading does not produce case findings. It does not activate MIP. It does not establish A/M values, D status, IA/D status, or a maturity conclusion.

A recommendation to perform MIP Source Reading does not create a third route.

After the checked MIP Gate, the human route remains binary:

```text
do not use MIP

or

use MIP
```

#### Conditional Transfer / Boundary Use

Within the `use MIP` route, the application may be limited to Conditional Transfer / Boundary Use.

This mode allows the MIP source to be used for examining:

```text
burden conditions
application boundaries
red zones
claim restraint
person-nearness risk
non-use requirements
misuse risk
conditions for responsible practice
```

It does not evaluate the maturity or development of a real person.

In Conditional Transfer / Boundary Use:

```text
no hard A/M scores
no D activation
no IA/D verdict
no maturity ranking
no developmental evaluation
no whole-person assessment
no evidence upgrade
```

Any observation must remain conditional, scene-bound, and directed toward application limits rather than person classification.

Conditional Transfer / Boundary Use is not MIP non-use. MIP is being applied, but under a restricted application mode. It therefore remains within the binary `use MIP` route.

#### AHP Dependency and Non-Authority

AHP is not triggered by:

```text
mention of MIP
MIP vocabulary
MIP Source Reading
a MIP Gate recommendation
general evaluative pressure
publicness alone
a desire for additional checking
```

AHP becomes eligible only after:

```text
MIP use was selected
a MIP Case Application was produced
the MIP output was checked
the checked MIP output is eligible for downstream use
```

AHP remains a second-order analysis-quality overlay.

It may inspect:

```text
analysis construction
boundary preservation
claim hardening
public transmission
misuse surface
scoring pressure
artefact authority risk
```

It may not:

```text
correct or replace MIP
reanalyze the underlying person
rescore A or M
activate D
change IA/D status
upgrade evidence
raise the claim ceiling
certify maturity
authorize institutional action
become an authority layer
```

Compact trigger logic must remain subordinate to Core sufficiency, input status, source status, rival pressure, person-nearness, claim ceiling, and correctability.

A PMS add-on trigger identifies possible add-on relevance.

A MIP Gate identifies possible downstream MIP use.

AHP dependency identifies whether a checked MIP application exists.

None of these settles the case or authorizes a stronger claim by itself.

The map identifies possible relevance; it does not settle routing.

### 6.4 When Add-ons Must Not Be Used

PMS-DISCIPLINE must ask not only which add-on may be relevant, but which add-on must not be used.

Add-ons must not be used when the trigger is merely verbal or thematic. They must not be used when Core is under-specified, when the input does not support specialized routing, when the add-on would import absent assumptions, or when it would make a weak reading appear more precise.

They must not be used when they intensify person-capture, convert analogy into classification, suppress rival accounts, or make PMS appear more complete than it is. They must not be used when they raise claim strength without increasing input support, correctability, or accountability. They must not be used when they turn a scan into a verdict.

Most importantly, an add-on must not be used when a rival explanation currently discriminates better. A rival account that explains the case with less overreach should redirect the application, not decorate the PMS reading. PMS-DISCIPLINE does not protect PMS by forcing every difficult case into a PMS-specialized lens.

Add-on non-use is not avoidance. It is often the disciplined application of PMS-DISCIPLINE. A relevant add-on may still be refused if it would overdetermine the case, conceal uncertainty, increase person-nearness risk, or shift the output into a claim corridor the input cannot bear.

The more powerful the lens, the more important its non-use conditions become.

### 6.5 False Trigger Examples

False triggers are not harmless. They move the case into the wrong reading corridor.

A surface cue may justify a scan, but not an add-on. Sexual metaphor does not automatically trigger SEX. Disagreement does not automatically trigger CONFLICT. Complaint does not automatically trigger CRITIQUE. Future reference does not automatically trigger ANTICIPATION. A philosophical case does not automatically require AXIOM.

Thematic proximity is not structural activation. A term, image, topic, or domain resemblance may make a scan reasonable, but the add-on remains unjustified unless operator-load, risk-shape, and claim-shape support it. Without that support, add-on use produces false precision.

False triggers are especially dangerous in AI-assisted PMS work. AI systems may over-rely on semantic proximity, repeated vocabulary, familiar patterns, or domain labels. They may route by lexical match rather than structural load. They may make a bounded Core case appear specialized, risky, adversarial, technically formalized, or determinate in ways the input does not support.

A false trigger can also suppress rival accounts. Once an add-on corridor is entered, the reading may begin to search for confirmation inside that corridor. CONFLICT may look for conflict structure. CRITIQUE may look for critique structure. SEX may look for sexual structure. ANTICIPATION may look for anticipatory structure. The lens begins to shape what appears relevant.

This is why PMS-DISCIPLINE treats false triggering as a serious application error. It does not merely add unnecessary vocabulary. It changes the reading corridor, raises claim risk, and may make correction harder.

### 6.6 Guiding Sentences

Not every PMS reading requires an add-on.

Add-ons are selected by operator-load patterns, not by topic labels.

A trigger indicates possible relevance, not permission to classify.

A false add-on trigger is not harmless; it changes the reading corridor.

---


## 7. The Complete PMS-DISCIPLINE Pass

### 7.1 Meaning of “Complete”

A complete PMS-DISCIPLINE pass is not a complete PMS application.

“Complete” means complete relative to the declared case boundary, intended use, and permitted route. It does not mean complete relative to PMS, reality, the case material, the persons involved, every possible analytical question, or all possible future work.

A pass may be complete even when it stops before Core.

If the checked Pre-Analysis determines that the requested output violates a protection boundary or that the current pipeline case may not enter Core, the pass may end with a confirmed stop. Such a pass is complete in discipline because it has reached the controlling boundary of the current use. It is not incomplete merely because no Core, add-on, MIP, AHP, Case Record, iteration, or article step followed.

Where Core entry is permitted, a complete pass remains complete in accountability rather than in capture. It shows the path by which PMS readability became, or did not become, responsible PMS use. It marks:

```text
case boundary
input and source status
intended use
requested-output disposition
pipeline-case disposition
Core-entry eligibility
effective checked Pre-Analysis
Core reading, where permitted
operator salience and possible omissions
add-on scan
selected add-on or Core-only result
downstream-layer route state
rival pressure
claim type and claim ceiling
person-nearness and use-context burden
correctability and reopening conditions
final analytical decision state
output boundary
permitted and prohibited next steps
iteration boundary, where relevant
```

The pass completes the record of the selected application path. It does not complete the reality under review.

A case may remain unresolved. A rival account may remain stronger. Core-only may be sufficient. An add-on may be rejected. MIP or AHP may remain ungated, not selected, unavailable, or refused. A claim may be downgraded. The application may be suspended, refused, redirected, or stopped before Core. These outcomes do not make the pass incomplete. They may be exactly what a complete discipline pass requires.

A complete pass may also show that further work would be useful. This does not make the current pass incomplete. Current sufficiency, iteration value, iteration urgency, and follow-up-case preparation remain distinct.

A case may be sufficient for its original intended use while still producing a legitimate future question. A case may be insufficient or stopped for its intended use without thereby licensing a stronger current claim. A follow-up case may receive bounded context, questions, and material needs, but it may not inherit the current findings as evidence, the current route as authority, or the current claim ceiling as an established starting condition.

Complete relative to DISCIPLINE means that the permitted path and its controlling boundary are inspectable.

It does not mean that:

```text
the case is exhausted
every relevant question has been analyzed
all PMS layers have been used
all add-on perspectives have been combined
correction is no longer possible
future work has been authorized
a stopped pass may continue under a renamed target
a follow-up case may inherit current-case authority
```

### 7.2 Pass Sequence

The pass sequence is an accountability order, not a mechanical pipeline.

It should not be read as a completion ritual, automatic workflow, authority chain, or requirement that every pass reach every stage. Each later stage is conditional on the effective checked output of the stages that precede it.

A complete PMS-DISCIPLINE pass follows this order:

```text
1. Declare the scene or case boundary.

2. Declare the available input and source status.

3. Declare the intended use and requested output.

4. Perform DISCIPLINE Pre-Analysis.

5. Check the Pre-Analysis for structural and substantive conformity.

6. Determine the effective Entry-Gate result:
   - Core entry permitted;
   - correction required before Core;
   - or current pipeline case stopped.

7. If a stop is confirmed:
   - record the requested-output disposition;
   - record the pipeline-case stop;
   - state the controlling protection or scope reason;
   - state that no later step belongs to the current pass;
   - identify any possible redirect only as a new, separately bounded case;
   - end the current pass.

8. If Core entry is permitted:
   perform and check the PMS Core application.

9. Identify operator salience, dependency limits,
   and possible operator omissions.

10. Scan for PMS add-on relevance.

11. Decide:
    - Core-only;
    - exactly one selected PMS add-on;
    - add-on non-use;
    - or add-on rejection.

12. If several PMS add-ons appear relevant:
    perform decomposition review and create separately bounded subcases
    rather than a mixed-add-on pass.

13. If one PMS add-on is selected:
    apply and check that add-on under its own source,
    trigger, claim, rival, and correction boundaries.

14. Gate MIP only where a distinct downstream burden is materially present.

    Routine process, deadline, delay, option loss, workflow friction,
    ordinary practical judgment, maturity vocabulary,
    or hypothetical real-person reference are not sufficient by themselves.

    The MIP Gate should look for actual person-evaluative,
    responsibility-related, role-capability, dignity, face, status,
    reputational, or maturity-in-practice pressure.

15. Check the MIP Gate and make the binary responsible route decision:

    - do not use MIP; or
    - use MIP.

    A recommendation to read the MIP source does not create
    a third analytical route.

16. If MIP use is selected:
    read the MIP source on its own terms before case application,
    unless an eligible current source reading already exists.

    MIP Source Reading preserves the source’s concepts, limits,
    red zones, and application modes.
    It does not produce case findings.

17. Apply MIP under the selected and declared application mode:

    - supported MIP Case Application; or
    - Conditional Transfer / Boundary Use.

    Conditional Transfer / Boundary Use may examine burden,
    boundaries, red zones, claim restraint, and misuse risk.

    It may not perform:
    - hard A/M scoring;
    - D activation;
    - IA/D verdicting;
    - maturity ranking;
    - developmental evaluation;
    - whole-person assessment.

18. Check the MIP output.

    The check must preserve the selected application mode,
    prohibit unsupported person evaluation,
    and determine the effective checked MIP artefact.

19. Gate AHP only after an actual checked MIP Case Application exists.

    MIP mention, MIP Source Reading, a MIP Gate recommendation,
    or unexecuted MIP relevance is insufficient.

20. If AHP is selected:
    apply and check AHP as a second-order analysis-quality overlay.

    AHP may inspect analysis construction, boundary preservation,
    hardening risk, public transmission, scoring pressure,
    and misuse surface.

    AHP may not:
    - correct or replace MIP;
    - reanalyze the underlying person;
    - rescore MIP;
    - activate D;
    - change IA/D status;
    - upgrade evidence;
    - raise the claim ceiling;
    - certify maturity;
    - become an authority layer.

21. Test rival accounts throughout the pass
    and resolve their controlling effect before final closure.

22. Determine the lowest adequate claim type and claim ceiling.

23. Check person-nearness, publicness, irreversibility,
    automation, institutional uptake, technical mediation,
    article-level use, and possible future reuse.

24. Check correctability, falsifier conditions,
    weakening conditions, and reopening conditions.

25. Set the final analytical decision state:
    proceed, revise, downgrade, suspend, refuse, or redirect.

26. Require explicit human confirmation where the use context demands it,
    without treating confirmation as an override of a protection boundary.

27. State the final output boundary,
    permitted next steps, and prohibited next steps.

28. Where the analytical route produced eligible checked artefacts,
    construct and check Case Record Stages 1–3.

29. Where future work is materially indicated,
    prepare the optional Iteration Handoff from the checked Case Record.

30. Where article generation is selected,
    render and check the article only after the checked Case Record
    and any independently grounded Iteration Handoff.
```

The order matters.

Pre-Analysis precedes Core because the application must first establish whether Core entry is permitted. Checked Entry-Gate status precedes analytical continuation. Core precedes PMS add-on routing. Operator salience and omission review precede add-on selection. Add-on plurality leads to decomposition, not accumulation.

MIP follows only where its distinct downstream burden is present. MIP Source Reading precedes MIP Case Application where needed, but Source Reading does not itself create case findings or a third route. The responsible route after the checked gate remains MIP non-use or MIP use.

Conditional Transfer / Boundary Use is a restricted MIP application mode within MIP use. It must not become a concealed real-person evaluation.

AHP requires an actual checked MIP application. It cannot be reached through vocabulary, recommendation, source reading, workflow expectation, or a desire for more analytical completeness.

AHP remains subordinate to the checked MIP artefact and its claim ceiling. It cannot revise MIP, rescore it, activate D, upgrade evidence, or become an authority layer.

Rival pressure must affect the application before closure. Correctability must be secured before operational closure. Human confirmation must occur where use risk requires it, but confirmation does not convert a prohibited output into a permitted one or allow a stopped case to continue.

Case Record construction follows the checked analytical route. The optional Iteration Handoff follows the checked Case Record and precedes optional article rendering. Article generation presents the checked record; it does not add a new analytical layer.

This sequence does not guarantee adequacy. It makes the location of adequacy, limitation, correction, non-use, and stopping inspectable.

It shows:

```text
where the case entered
whether it was allowed to enter Core
where it stopped
where it proceeded
where it was revised
where its claim was downgraded
where an add-on was selected or refused
where decomposition created a separate subcase
where MIP was not triggered
where MIP Source Reading occurred without case findings
where MIP was used under a full or conditional mode
where AHP was unavailable because no checked MIP existed
where a rival account controlled the outcome
where correction may still change the result
where operational closure applies
where future work must begin under renewed boundaries
```

### 7.3 Rival Pressure Within the Pass

Rival pressure is part of the pass, not an optional critique appendix.

A PMS reading can be coherent and still discriminate less effectively than a rival account. A rival may explain the case with less overreach, fewer assumptions, lower person-capture risk, stronger input grounding, or better domain fit.

Rival pressure begins at Pre-Analysis and remains active throughout the permitted route. It may affect:

```text
Core-entry eligibility
case boundary
claim ceiling
operator assignment
add-on selection or non-use
MIP or AHP eligibility
final analytical decision state
reopening conditions
follow-up boundaries
```

A rival can win before Core. If the requested PMS use is clearly displaced by a domain process, evidentiary investigation, legal procedure, clinical process, technical audit, or another frame that carries the burden more responsibly, the Pre-Analysis may refuse or redirect the requested use and stop the current pipeline case.

A rival can also win after Core or a later checked layer. If a rival explanation currently discriminates better, PMS should not absorb it, translate it into PMS vocabulary, or preserve PMS as the primary frame through workflow momentum. The application should be downgraded, suspended, refused, or redirected.

The rival burden rises with:

```text
claim strength
person-nearness
publicness
irreversibility
technical use
automation
institutional uptake
article-level synthesis
future reuse
difficulty of contestation
```

A private exploratory reading may carry a lighter rival burden. A public, person-near, institutional, technical, automated, article-level, or follow-up-seeding use carries a heavier one.

Rival pressure also constrains decomposition and integration. A rival that defeats one subcase does not automatically defeat every other subcase, but its effect must remain attached to the question and claim it controls. Integration must not hide a losing subcase inside a broader coherent narrative.

Rival pressure also constrains iteration. A follow-up indication must not become a way to defer a rival that already defeats the current PMS path. Where a rival currently discriminates better, the disciplined result is downgrade, suspension, refusal, or redirection—not a PMS-framed continuation that preserves the weaker reading.

Rival pressure is a discipline against PMS overfit. It prevents PMS coherence from becoming self-immunizing.

The stronger the claim, the stronger the rival burden.

### 7.4 Permitted Pass Outcomes

A PMS-DISCIPLINE pass succeeds when it reaches the correct bounded outcome, not when it produces the strongest or most extensive PMS reading.

Permitted outcomes include:

```text
confirmed stop before Core
Core-only sufficiency
Core plus one justified PMS add-on
add-on non-use
add-on rejection
decomposition into separately bounded subcases
MIP non-use
AHP non-use
claim revision
claim downgrade
suspension
refusal
rival or domain redirection
bounded proceed
operational closure within limits
separately bounded follow-up preparation
optional article rendering of a checked record
```

Core plus multiple PMS add-ons is not an outcome of one bounded pass.

Where several add-ons are relevant, the permitted outcome is decomposition into separately bounded subcases. Their effective checked records may later undergo record-level comparison or integration under §4.6, but they do not become one mixed-add-on analytical artefact and they do not license new cross-subcase findings without a separately bounded analytical integration case.

Core-only can be a successful pass outcome. Add-on rejection can be a successful pass outcome. MIP or AHP non-use can be a successful pass outcome. A stop before Core can be a successful pass outcome. Downgrade can be a successful pass outcome. Suspension can be a successful pass outcome. A rival account winning can be a successful pass outcome. Refusal and redirection are disciplined outcomes, not failures.

A bounded follow-up indication can also be disciplined when it preserves the current result while preparing possible future work under a new boundary.

These outcomes are path results, not quality levels.

PMS use becomes undisciplined when success is confused with:

```text
proceed
specificity
add-on use
layer accumulation
full-stack routing
workflow completion
article generation
follow-up availability
```

A pass succeeds by making the controlling path decision visible and accountable.

Sometimes that means proceeding. Sometimes it means revising the reading. Sometimes it means lowering the claim ceiling. Sometimes it means refusing the requested output. Sometimes it means stopping before Core. Sometimes it means redirecting the question to another frame. Sometimes it means dividing one broad case into several independently accountable subcases.

Iteration must be handled without inheritance. A follow-up case may receive context, lineage, questions, material needs, and selected prior artefacts as bounded background. It may not inherit:

```text
findings as evidence
route decisions as route authority
operator statuses as current activations
add-on selection
MIP or AHP status
claim ceiling
sufficiency status
article wording
pipeline eligibility
```

The follow-up case begins again under its own boundary, source status, intended use, Pre-Analysis, Entry Gate, route checks, rival pressure, claim ceiling, correctability, and final analytical decision state.

Refusal, suspension, redirection, decomposition, stopping, and separately bounded iteration are not failed applications. They are possible forms of disciplined PMS use.

### 7.5 Required Output Record

The final output of a PMS-DISCIPLINE pass must be a record of accountability, not a verdict.

The required record depends on the route actually permitted. It must not fabricate later analytical states for a pass that stopped before Core.

At minimum, every pass should state:

```text
case boundary
input and source status
intended use
requested output
requested-output disposition
pipeline-case disposition
Core-entry eligibility
effective checked Pre-Analysis status
controlling reasons
claim ceiling
person-nearness and use-context pressure
rival status
correctability status
reopening conditions
permitted next step
prohibited next steps
```

Where the pass stops before Core, the record should additionally state:

```text
stop reason
protection or scope boundary involved
requested use that is refused or restricted
why Core entry is not permitted
whether correction within Pre-Analysis remains possible
whether a redirect is identified
that any redirected analysis requires a new case boundary
```

A stop record must not invent:

```text
Core findings
operator assignments
add-on results
MIP or AHP results
Case Record integration
article conclusions
```

Where Core entry is permitted and analytical work is completed, the record should also state:

```text
Core status
operators assigned
possible operator omissions
derived-structure limits
Core claim boundary
add-on scan result
selected PMS add-on or Core-only status
add-ons explicitly not used
add-ons rejected as over-application
decomposition decision, where several add-ons appeared relevant
MIP route state
AHP route state
rival account and discrimination status
final analytical decision state
explicit human confirmation, where required
```

Where decomposition created several subcases, each subcase must preserve its own complete record. A later record-level integration should state:

```text
which subcase records were integrated
which question each subcase addressed
which add-on, if any, each subcase used
which claims remain local to a subcase
which tensions remain unresolved
which findings may be compared
which findings must not be merged
which relations are already explicit in or directly supported by the checked records
whether any proposed shared conclusion would require a new analytical integration case
```

Record-level integration must not create a new cross-subcase finding or convert the subcases into a retrospective multi-add-on pass. If a shared conclusion requires new inference, the current integration record must mark that conclusion as unavailable and identify the need for a new, separately bounded analytical integration case.

Where Case Record Stages 1–3 are produced, the output must distinguish:

```text
checked analytical artefacts
effective corrected artefacts
superseded artefacts
Case Record provenance
layer digests
integrated record
current-step execution status
check status
```

Workflow telemetry must not become case substance. A stage’s own temporary output status must not be treated as evidence, missing case material, or a substantive defect.

Where iteration is indicated, the output record must keep at least four distinctions visible:

```text
current sufficiency
iteration value
iteration urgency
follow-up-case preparation
```

Current sufficiency asks whether the present pass is adequate for its original intended use.

Iteration value asks whether a future pass would add useful further clarity.

Iteration urgency asks whether delay would materially increase risk, loss of correction, loss of material, or practical cost.

Follow-up-case preparation asks what separate boundary, question, source status, and new material would be required for future work.

None of these converts the current output into evidence, authority, or an unfinished verdict.

If explicit human confirmation is required, the output is incomplete without a record of what was confirmed. Human confirmation must not be described as truth certification, validation, closure certification, or an override of a checked protection boundary.

The output must show not only what PMS read, but:

```text
what the reading is not licensed to claim
what the requested output may not contain
whether the current pass may continue
which claims remain unavailable
which risks remain unresolved
which rival accounts remain live
which correction paths remain open
which later steps are prohibited
which future uses require renewed discipline
```

A bare label is not sufficient. A fluent interpretation is not sufficient. A completed template is not sufficient. A checked artefact without visible limits is not sufficient. A Case Record that hides non-use or superseded outputs is not sufficient. A follow-up suggestion that silently inherits current authority is not sufficient.

A DISCIPLINE output is a record of accountability, not a verdict. It preserves the path by which PMS use became permitted, bounded, revised, downgraded, suspended, refused, redirected, stopped, decomposed, or prepared for separately bounded continuation.

### 7.6 Guiding Sentence

A complete pass is not one that uses every layer. It is one that makes the controlling boundary visible, uses no more than one PMS add-on per bounded analytical question, separates distinct questions into accountable subcases, and justifies why each permitted layer was used, not used, rejected, stopped, or carried into future work only under a renewed boundary.

---

## Part III — Claim, Input, and Reality Discipline

## 8. Input Status and Model Output

### 8.1 Input Types

PMS-DISCIPLINE begins Part III with a simple constraint: not every input carries the same claim burden.

A PMS application may work with traces, reports, memories, interpretations, institutional records, fictional cases, synthetic examples, prior analyses, model outputs, or mixed materials. These inputs should not be flattened into a single category such as “data” or “material.” Input type is part of the claim, not a background detail.

This does not require a rigid taxonomy. The point is not to prove once and for all what kind of input is present. The point is to prevent a PMS reading from treating heterogeneous material as epistemically uniform. A first-person report may include memory and interpretation. An institutional record may include interpretation. A model output may summarize reports without becoming evidence. A fictional or synthetic case may illustrate PMS structure without licensing factual claims.

Mixed input must remain mixed in the output record. A case-pass must not turn traces, reports, interpretations, institutional records, fictional scenes, synthetic examples, and model outputs into one undifferentiated evidentiary surface. Each input type constrains what the PMS application may responsibly claim.

A PMS reading begins to overclaim when it treats heterogeneous input as if it all carried the same status.

### 8.2 Input Status and Claim Licensing

Input status constrains claim strength.

A PMS reading may be structurally coherent and still be too strong for the input it uses. A trace, a first-person report, an institutional record, a memory, a fictional case, and a model output do not license the same claim. Each may be relevant, but each carries a different burden.

Stronger anchoring does not guarantee truth. A trace or institutional record may support stronger claims than a synthetic example or model output, but it still requires context, reliability, contestability, and interpretation. Institutional records are not automatically neutral. Traces are not self-interpreting. Documentation can still be partial, framed, selective, or contested.

Medium or situated anchoring may support bounded claims. A report, memory, or first-person account may not independently establish all factual claims associated with it, but it may still be highly relevant for understanding reported experience, perceived harm, practical orientation, or scene-bound interpretation. High interpretation burden does not make input worthless. It lowers the permitted claim ceiling.

Model output carries high interpretation burden. It may help organize, compare, summarize, or hypothesize, but it cannot serve as independent evidence for the material it summarizes. Model fluency does not raise input status. A coherent model-generated structure may support orientation, but it does not establish fact.

Input anchoring therefore constrains claim strength; it does not certify truth. A stronger input status may support stronger claims only when context, reliability, contestability, and correction remain visible.

### 8.3 Required Distinctions

The following distinctions must remain visible wherever claim strength increases:

```text id="ctmf10"
fact ≠ report
report ≠ interpretation
interpretation ≠ model output
model output ≠ evidence
coherence ≠ truth
elegance ≠ adequacy
template completion ≠ validation
```

These distinctions are not epistemic niceties. They are application guardrails.

When fact and report are confused, the output gains false factual authority. When report and interpretation are confused, framing becomes hidden. When model output and evidence are confused, AI fluency launders input status. When coherence is confused with truth, PMS readability becomes immunity. When elegance is confused with adequacy, a structurally satisfying reading can outrun its claim burden. When template completion is confused with validation, the appearance of procedural completeness replaces discipline.

These guardrails matter most where the use context raises burden: AI-assisted work, template-supported review, public output, person-near interpretation, institutional uptake, technical implementation, automated processing, or article-level synthesis. In such contexts, violating these distinctions requires revision, downgrade, suspension, refusal, or redirection.

A PMS output becomes unsafe when it lets coherence do the work of evidence.

### 8.4 Model Output Discipline

Model output enters PMS-DISCIPLINE as input, not as evidence.

AI-assisted work may help structure a reading. It may support mapping, hypothesis generation, operator omission checks, rival framing, comparison, summarization, or template completion. These uses can be valuable when their status remains visible. A model-generated structure may make uncertainty easier to inspect. It may not reduce the uncertainty by appearing fluent.

Model output may not independently establish facts. It may not substitute for evidence. It may not raise the input status of material it summarizes. It may not provide person-level warrant. It may not certify truth. It may not authorize closure. It may not turn a template-filled case-pass record into a completed case.

This is the central rule:

```text id="tldev7"
PMS may organize input.
PMS may not upgrade input status by organizing it.
```

The same rule applies to AI-supported PMS work. AI may help organize the reading; it may not upgrade the material being read. A model-generated rival account may be useful for pressure-testing, but it is not external validation. A model-generated summary may be useful for orientation, but it is not evidence. A model-generated case structure may be useful for inspection, but it is not case completion.

Where model output is used, it must be marked. The output record must show what was supplied by the model, what source material the model summarized or transformed, what remains unverified, and what claims are not licensed by model fluency.

Fluency can organize uncertainty without reducing it.

### 8.5 Guiding Sentence

PMS may organize input. PMS may not upgrade input status by organizing it.

---

## 9. Claim Types and Bounded Adequacy

### 9.1 Claim Ladder

Claim type determines burden.

A PMS reading may be used for orientation, structural sketch, hypothesis, bounded reconstruction, evaluation, recommendation, intervention, technical implementation, institutional uptake, or public synthesis. These uses do not carry the same burden. The stronger the claim, the stronger the required input support, rival pressure, correctability, and person-nearness discipline.

The claim ladder is not a progress ladder. Disciplined PMS use does not climb the ladder merely because a reading can be made coherent, elegant, or structurally rich. The disciplined claim is the lowest claim strong enough for the intended use. A case may remain at orientation, sketch, hypothesis, or bounded reconstruction even when PMS could say more.

This prevents claim escalation. An orientation should not silently become an evaluation. A hypothesis should not become an explanation. A case reading should not become a recommendation. A recommendation should not become an intervention. A technical implementation should not be treated as mere analysis. Each step upward changes the burden.

A PMS reading may therefore be adequate at one claim level and inadequate at another. A Core-only sketch may be adequate for orientation. The same sketch may be inadequate for public claim, person-near judgment, institutional action, or automated routing. Claim type must therefore be declared, not inferred from the fluency of the output.

A PMS reading should not climb the claim ladder merely because it can be made coherent.

### 9.2 Burden Rule

The burden rises with claim strength.

It also rises when input weakens. Weak input can support useful orientation, hypothesis generation, or bounded interpretation, but it cannot silently support evaluation, recommendation, intervention, institutional uptake, technical formalization, or automated decision support. The weaker the input, the lower the permitted claim ceiling unless additional support, contestability, and correction access are provided.

The burden rises sharply with person-nearness, publicness, irreversibility, domain risk, technical formalization, automation, institutional uptake, and difficulty of contestation by affected persons. A claim that touches a person, affects reputation, shapes access, enters public circulation, becomes embedded in a technical system, or is taken up by an institution carries a different burden from a private exploratory reading.

This burden is cumulative. A public claim based on weak input is not merely one step stronger than a private note. A person-near claim embedded in an institutional or automated workflow raises several burdens at once. In such cases, PMS-DISCIPLINE may require weaker claims, clearer input-status marking, stronger rival pressure, explicit correctability, human confirmation, suspension, refusal, or redirection.

Affected persons’ ability to contest the claim is especially important. Burden rises not only when claims become stronger, but also when those affected become less able to correct, challenge, contextualize, or refuse the use of the reading.

Publicness, automation, and institutional uptake change the claim burden.

### 9.3 Bounded Adequacy

Adequacy is bounded fit, not internal elegance.

A PMS reading is not adequate because it is coherent. It is not adequate because it is structurally rich, fluent, specific, or recognizably PMS-like. It is adequate only relative to the claim it is asked to carry, the input status it relies on, the risk it introduces, the use context it enters, the rival pressure it withstands, and the correctability it preserves.

A reading can be coherent and still inadequate. It may organize the case elegantly while relying on weak input, ignoring rival accounts, increasing person-capture, overusing an add-on, hiding uncertainty, or closing correction too early. Coherence may support adequacy, but it cannot replace input status, rival pressure, or correctability.

A reading can also be partial and still adequate. A bounded Core reading may be adequate for orientation. A low-burden sketch may be adequate for conceptual clarification. A hypothesis may be adequate when it remains marked as a hypothesis. Partiality is not failure when the claim remains within the burden the reading can bear.

Bounded adequacy therefore replaces both completeness and elegance as standards of disciplined PMS use. It asks whether the reading remains bounded, inspectable, and correctable for this claim, under this input status, within this use context, against relevant rival pressure.

Adequacy is not internal elegance. It is bounded fit between claim, input, risk, intended use, rival pressure, and correctability.

### 9.4 Bounded Adequacy and Add-ons

Add-ons are adequacy-relevant only when they improve boundedness, not merely specificity.

An add-on can increase adequacy. It may sharpen a risk corridor, clarify a trigger condition, expose a non-trigger condition, mark overuse risk, protect against false precision, or make limits more explicit. In such cases, the add-on makes the reading more accountable within its justified burden.

An add-on can also decrease adequacy. It may over-specify the case, import absent assumptions, hide weak input, intensify person-capture, suppress a rival account, convert analogy into classification, or make PMS appear more complete than it is. A more precise lens can make a reading less adequate if it exceeds the burden the input can bear.

Add-on specificity is therefore not adequacy by itself. A specialized lens does not improve the reading merely because it says more. It improves the reading only if it sharpens the application while preserving claim boundaries, input-status discipline, rival pressure, person-nearness caution, and correctability.

A disciplined add-on may also show why the claim must remain weaker. It may justify add-on non-use, downgrade, suspension, refusal, or redirection. The success of an add-on is not measured by interpretive richness, but by whether the resulting PMS use becomes more answerable.

Add-ons improve adequacy only when they improve boundedness, not merely specificity.

### 9.5 Guiding Sentence

Adequacy is relative to claim type, input status, risk, intended use, rival pressure, and correctability.

---

## 10. Falsehood, Practical Power, and Follow-Up Cost

### 10.1 Falsehood Is Not Only Epistemic

Falsehood is not only an epistemic defect. It can become a practical structure.

This does not mean that falsehood becomes true when it works. PMS-DISCIPLINE rejects a false claim as false where it is false. Practical power does not make falsehood true. But a false claim may still organize practice, orient action, distribute cost, protect some participants, expose others, and make later correction more difficult.

A false claim can therefore fail as truth and still succeed as orientation. It may give people a frame through which to act. It may make certain responses appear reasonable, certain persons appear responsible, certain burdens appear deserved, or certain alternatives appear unavailable. It may stabilize a path of action even after its factual basis has collapsed.

DISCIPLINE must therefore do two things at once. It must reject falsehood epistemically, and it must describe its praxeological effects. A false claim is not harmless merely because it can be identified as false. Once it has organized action, it has already entered the field of responsibility, correction, and follow-up cost.

Falsehood remains false, but it may still organize practice.

### 10.2 Practical Power of Falsehood

The practical analysis of falsehood asks not only whether a claim was false, but what it made possible.

A falsehood may produce orientation. It may enable action, block action, justify delay, legitimate intervention, redirect blame, distribute attention, stabilize an institution, protect an actor, burden a person, expose a group, or make one frame harder to challenge. It may determine who must explain themselves, who is believed, who is doubted, who pays the cost, and who benefits from the false frame.

This matters because correction is not complete when the false claim is merely removed. The claim may have already produced roles, expectations, decisions, exclusions, reputational effects, institutional habits, or protective arrangements. If those effects remain undescribed, correction remains incomplete.

A false claim can also change what correction is possible afterward. It may make some evidence harder to introduce, some persons less able to contest, some losses harder to recover, or some alternatives less visible. It may create follow-up burdens for those who did not create the falsehood but had to live under its frame.

PMS-DISCIPLINE therefore asks:

```text id="2r3c7f"
What did the false claim orient?
What actions did it enable or block?
Who benefited from the false frame?
Who carried its cost?
Who became more exposed?
Who became more protected?
Which rival frames were suppressed?
Which correction paths became harder?
What remains after the false claim is rejected?
```

False claims distribute orientation, action, cost, protection, and exposure. A discipline of use must be able to describe that distribution.

### 10.3 False Stability

Stability is not validation.

A false structure can stabilize. It may become familiar, useful, institutionally convenient, emotionally protective, technically embedded, rhetorically efficient, or socially reinforced. It may become easier to preserve than to correct. But its stability does not make it true.

Falsehood does not become true by becoming stable; but once stable, it becomes praxeologically consequential. A stable falsehood may have produced habits, expectations, roles, exclusions, costs, and protective frames. It may have trained participants to act as if the false claim were already part of reality. It may have made correction appear disruptive, disloyal, impractical, or excessive.

The more stable a falsehood becomes, the more its follow-up cost must be described. Correction must address not only the false statement, but also the practices that formed around it. A false structure may become difficult to correct precisely because it has become useful to some part of the scene.

This is why PMS-DISCIPLINE does not treat stability, institutionalization, coherence, or practical usefulness as epistemic defense. A false claim may be stable. It may even be operationally effective. But it remains false where it is false, and its practical effects increase rather than reduce the burden of correction.

### 10.4 Bridge to Correctability

The practical power of falsehood becomes a correctability problem when its effects outlive its correction.

If a structure remains stable only by defending itself against factual correction, that stability is discipline-relevant. A reading, institution, template, model output, or public claim that cannot be affected by correction has ceased to be merely coherent. It has become immunizing.

Correction must be able to affect the reading. It must be able to change claim strength, reopen a closure, downgrade a conclusion, alter a case-pass record, suspend an application, redirect to a rival frame, or require withdrawal of a claim. If correction cannot affect the output, coherence has begun to protect error.

This prepares the rule developed later as correction before coherence. PMS-DISCIPLINE does not reject coherence. It rejects coherence that survives by making correction irrelevant. A structure stabilized against factual correction is not robust; it is protected by error.

The question is therefore not only whether a false claim has been identified. The question is whether its practical effects remain correctable after identification. If they do not, the falsehood has become more than an error. It has become a closure problem.

### 10.5 Guiding Sentence

Falsehood must not only be rejected as false; its practical power, asymmetries, and follow-up costs must be described.

---

## Part IV — Use Contexts and Artefact Discipline

## 11. Human Interpretation, Person-Nearness, and Misuse Risk

### 11.1 Human Interpretation as Necessary and Risk-Bearing

Human interpretation is necessary for PMS application.

A PMS reading is never simply extracted from a case. A scene must be selected, an input boundary drawn, a frame recognized, operator salience judged, rival accounts considered, and claim strength bounded. Even where AI assistance, templates, YAML-supported routing, or case-pass records are used, the work remains humanly framed, selected, reviewed, and answerable.

Human interpretation is therefore not the defect. Unbounded interpretation is.

PMS-DISCIPLINE does not remove interpretation. It binds interpretation to scene, claim, source, use, and responsibility. A disciplined PMS use remains scene-bound because it speaks from the declared case boundary. It remains claim-bound because it does not exceed the burden the input can bear. It remains source-bound because it does not upgrade reports, memories, model outputs, partial records, or contested material through interpretive fluency. It remains responsibility-bound because the interpreter must preserve reasons, limits, rival pressure, correction paths, protection boundaries, and stop-capability.

The risk is not interpretation as such. The risk is person-bound drift: the movement by which a scene reading becomes a judgment about motive, identity, maturity, blame, credibility, competence, authority, character, pathology, or the total person.

A reading may begin as structural clarification and become, without a justified change in source burden and claim boundary, a person-level verdict. This drift may occur through explicit accusation, but it may also occur through apparently careful language, technical classification, maturity vocabulary, role assessment, evaluative scoring, or a model-generated summary that presents inference as settled description.

This is why AI must not be treated as cleaner merely because it is non-human. AI output can remove the visible tone of human interpretation while preserving or intensifying interpretive drift. It can convert a local scene into a stable person profile, a partial report into an apparent character account, or a risk marker into a verdict without showing where the boundary was crossed.

The relevant question is not whether a reading is human or machine-assisted. The question is whether it remains scene-bound, source-bound, claim-bound, contestable, correctable, and responsibility-bound.

PMS-DISCIPLINE does not remove interpretation. It makes interpretation answerable.

### 11.2 Human Interpretive Risks

PMS vocabulary can become misuse vocabulary.

This risk does not come from PMS terms being weak. It comes from their strength. Operators and derived axes can make scenes highly legible. But when that legibility becomes superiority language, accusation, moral shielding, maturity ranking, status attribution, or frame protection, PMS use becomes undisciplined.

Dignity-in-Practice is not a moral shield. Ω (Asymmetry) is not an accusation shortcut. Ψ (Self-Binding) is not a maturity verdict. Coherence is not truth. Responsibility is not a person sentence. Awareness is not a cognitive score. A structurally elegant reading may still humiliate if it captures the person rather than the scene.

Human interpretive risks include:

```text
projection
moralization
status defense
ideological capture
superiority language
role-based overreach
motive attribution
character inference
maturity ranking
credibility classification
diagnostic drift
PMS vocabulary used to stabilize the interpreter’s own frame
```

A reader may use Dignity-in-Practice to protect their own moral position. They may use Ω (Asymmetry) to name asymmetry without sufficient distance. They may use Ψ (Self-Binding) to rank another person’s maturity or reliability. They may use responsibility language to convert a situated burden into a stable trait. They may use PMS structure to make their own frame appear necessary, neutral, or beyond correction.

Critique can also become verdict. A PMS reading may identify a disturbance, contradiction, failure, or asymmetry, but then convert it into diagnosis, blame, bad-faith attribution, incompetence, immaturity, or person-level inadequacy before the claim burden has been met.

Interpretation can humiliate when it speaks with structural confidence about a person whom the available material does not license it to capture.

This risk rises when the material is:

```text
partial
reported by one side
memory-based
context-poor
AI-generated
institutionally selected
reputationally consequential
difficult for the affected person to contest
```

PMS vocabulary becomes dangerous when it protects the interpreter’s frame from correction.

### 11.3 Scene-Bound Use and Person-Bound Drift

PMS may read a scene. It must not silently totalize the person.

Scene-bound use does not mean neutralized, emotionless, or consequence-free use. It means that the claim remains tied to the declared scene, available input, source status, operative frame, intended use, and correction conditions.

A scene-bound reading may describe what appears structurally operative in the case under review. It may describe a local relation, action sequence, frame conflict, asymmetry, temporal pressure, claim structure, or correction problem.

It may not silently become a total claim about:

```text
motive
identity
character
maturity
credibility
competence
pathology
blameworthiness
dignity
authority
social worth
the whole person
```

Movement toward the person raises burden.

If a reading moves from scene structure to motive, that movement must be independently licensed. If it moves from local action to character, it must justify that transition under stronger source burden. If it moves from a pattern in the scene to blame, maturity, credibility, competence, dignity, authority, or pathology, it must show why the available material supports that person-level claim and why a scene-bound alternative is insufficient.

Person-bound drift begins when the case boundary disappears.

Examples include:

```text
a scene-specific reading becomes a person profile
a role-specific action becomes a character judgment
a local failure becomes a maturity verdict
a disagreement becomes a diagnosis of incapacity
a reported pattern becomes a credibility classification
a critique becomes humiliation
a structural interpretation becomes capture
```

The closer a reading moves toward the person, the more it must weaken, bind, and remain correctable. It may require:

```text
a lower claim type
clearer source-status marking
stronger rival pressure
explicit person-nearness caution
greater contestability
non-public handling
domain-specific review
suspension
refusal
redirection
```

Person-nearness does not make every PMS use prohibited. A scene-bound reading may remain possible near persons when its question, source burden, claim ceiling, intended use, and correction path remain appropriately limited.

But not every person-near request can be repaired by weaker wording inside the same case.

Where the requested output itself seeks an unsupported whole-person judgment, character judgment, motive attribution, diagnosis, forensic conclusion, maturity ranking, credibility ranking, competence verdict, status judgment, or similarly totalizing person-level output, the application may reach a Mandatory Person-Near Stop before Core.

Scene-bound use prevents structural interpretation from becoming person capture.

### 11.4 Complaint, Attack, Critique, Signal

PMS-DISCIPLINE must distinguish complaint, attack, critique, signal, and correction without collapsing them.

A complaint is a signal of disturbance, harm, mismatch, burden, or felt wrongness. It may be incomplete, imprecise, emotionally expressed, or not yet tied to a fully articulated standard. It can still be structurally relevant.

An attack is an adversarial move. It may aim to wound, discredit, punish, dominate, or destabilize. But even an attack may indicate something about the scene. Its adversarial form does not automatically make every signal inside it irrelevant.

A critique is not merely negativity. Critique requires an object, a reason, a standard, and possible disconfirmation. It becomes disciplined when disturbance is made answerable. A critique can be harsh and still valid; it can be polite and still empty.

A signal is any case-relevant indication that may justify examination without yet establishing the interpretation placed upon it.

Correction is a change-capable response to an identified defect, burden, false claim, weak frame, or failed relation. It is not merely acknowledgment.

These distinctions protect all sides of the application.

A complaint must not be dismissed merely because it is not yet a polished critique. An attack must not be treated as automatically invalid merely because it is adversarial. A critique must not be reduced to tone, negativity, or social discomfort.

But a complaint must not automatically become a verdict. An attack must not automatically become critique. A signal must not automatically become proof. A critique must not automatically become a person judgment.

The absence of polished critique does not make a signal structurally irrelevant. The presence of disturbance does not by itself settle the claim.

### 11.5 Complaint Opens Examination, Not Verdict

A complaint may open an examination space; it does not by itself become a verdict.

This distinction is essential. If complaints are dismissed because they are not fully formalized, PMS-DISCIPLINE becomes a shield against vulnerable signals. If complaints are enthroned as verdicts, PMS-DISCIPLINE becomes a shortcut from disturbance to judgment. Both are failures.

A complaint can justify examination. It may require:

```text
the scene to be reopened
the input status to be clarified
the source boundary to be reviewed
the claim type to be lowered
a rival account to be considered
person-nearness risk to be marked
a correction path to be preserved
closure to be delayed
```

It may show that something in the scene requires attention before a claim can responsibly close.

But a complaint does not by itself establish the claim. It does not automatically prove:

```text
harm
motive
blame
bad faith
incompetence
immaturity
dishonesty
pathology
structural failure
```

It must not be converted into diagnosis, verdict, punishment, reputational judgment, or person-level classification without further discipline.

This remains true even where the complaint is serious. Seriousness may raise the need for examination, preservation, protection, domain review, or temporary suspension. It does not by itself remove the distinction between signal and established claim.

The discipline is to neither dismiss the signal nor enthrone it.

A complaint opens a space of examination, not a final structure of judgment.

### 11.6 Critique as Answerable Disturbance

Critique is disturbance made answerable.

It is not identical with negativity, harshness, discomfort, attack, or opposition. A critique begins where disturbance becomes answerable to object, reason, standard, and possible disconfirmation.

It states:

```text
what is being challenged
why it is being challenged
by what standard it is being challenged
what material supports the challenge
what would weaken or correct the challenge
```

Critique is not dependent on politeness. A harsh critique may be valid if it remains bound to object, reason, standard, and possible disconfirmation. A polite statement may fail as critique if it avoids reasons, hides its standard, cannot be contested, or protects itself from correction.

Critique is also not identical with attack. An attack may contain a signal, but it does not become critique unless it becomes answerable. Conversely, a critique may feel attacking because it disturbs a protected frame.

The relevant question is not whether the disturbance feels comfortable, but whether it remains:

```text
object-bound
reason-bound
standard-bound
source-aware
proportionate
contestable
correctable
```

PMS-DISCIPLINE treats critique as disciplined disturbance, not as mood or status performance. Critique can open correction, lower claim confidence, expose false coherence, require rival attention, or require a reading to be revised.

But critique itself must remain correctable. If critique becomes immune to disconfirmation, it becomes another closure problem. If critique moves from the challenged object to the whole person without sufficient warrant, it becomes person-bound drift.

Critique begins where disturbance becomes answerable to object, reason, standard, and possible disconfirmation.

### 11.7 Protection Clause

PMS-DISCIPLINE must not confuse formality with validity.

A complaint may be structurally relevant before it becomes fully formed critique. A vulnerable signal may appear as distress, interruption, refusal, withdrawal, anger, hesitation, fragmented speech, avoidance, or inability to formulate a complete account before it can satisfy the full burden of critique.

Its incomplete form does not make it structurally irrelevant.

This protection is necessary because formal standards can become immunizing. If only polished, academically complete, institutionally legible, or procedurally perfect critique is allowed to count, PMS-DISCIPLINE can become a shield for the already protected frame.

The burden of perfect articulation may fall most heavily on the person least able to carry it in the scene.

Validity also does not depend on softness. A harsh critique may still be valid if it remains answerable to object, reason, standard, source, and possible disconfirmation. A polite formulation may still be immunizing if it avoids correction, hides its standard, protects authority, or makes contestation practically impossible.

Politeness can stabilize immunity as effectively as aggression can destabilize dialogue. Harshness can damage the scene, but it does not automatically invalidate the signal. Formality can clarify critique, but it does not automatically make a claim disciplined.

This clause does not turn complaint into verdict. It prevents PMS-DISCIPLINE from excluding signals merely because they arrive without ideal form.

It also does not authorize PMS to decide what happened merely from the form of distress. A signal may require protection or examination while the substantive claim remains unresolved.

The task is to preserve examination without demanding that the vulnerable already possess the full language of critique before their signal can matter.

### 11.8 Link to Correctability

Complaint, critique, and correction are related, but they are not identical.

A complaint can open examination. It signals disturbance, harm, mismatch, or burden. It may require the scene to be reviewed, the input status to be clarified, the claim to be weakened, or a person-nearness risk to be marked.

But complaint alone is not correction.

Critique makes disturbance answerable. It binds the disturbance to object, reason, standard, source, and possible disconfirmation. It can pressure a PMS reading, expose a weak frame, challenge an overclaim, or require rival attention.

But critique alone is not yet correction if it cannot affect the reading.

Correction requires:

```text
reasons
proportionality
revisability
source awareness
dignity preservation
contestability
possible effect
```

It must be able to change something material:

```text
the case boundary
the source-status marking
the claim type
the claim ceiling
the operator assignment
the add-on decision
the rival account
the requested-output disposition
the pipeline-case disposition
the closure status
the permitted next steps
the final analytical decision state
```

Correctability is not present merely because a complaint was acknowledged or a critique was recorded. A correction path that cannot alter the output is symbolic. A critique that cannot possibly change the reading becomes decorative.

A review process that hears disturbance but cannot revise, downgrade, suspend, refuse, redirect, or stop the current application has not preserved correctability.

Correction may also require ending the current pass rather than editing its conclusion. Where the requested use crosses a protection boundary, correction does not mean finding softer language for the same prohibited output. It may mean refusing that output, stopping the current pipeline case, and requiring any safer future question to begin under a new boundary.

Correction is not present unless it can affect the reading or the application path.

### 11.9 Guiding Sentences

DISCIPLINE must not require the vulnerable to produce academically perfect critique before their signal counts as structurally relevant.

A signal may require examination without already settling the claim.

PMS may read a scene; it must not silently totalize the person.

A protection boundary is not preserved if the same prohibited judgment continues under weaker wording.

---

## 12. Person, Idea, Effect, and Model

### 12.1 Function

PMS-DISCIPLINE must keep person, idea, effect, and model distinct.

This chapter protects against two opposite errors. The person must not be degraded because an idea is false, harmful, incoherent, or poorly supported. But the idea must not be protected from criticism because the person has dignity.

Person-protection must not become idea-immunity. Idea critique must not become person degradation.

A PMS reading may criticize a claim, analyze an effect, identify a structural risk, or mark a model limitation. It may not silently move from any of these to a total claim about the person.

At the same time, dignity language must not make the effects of an idea on other persons disappear. The dignity of the bearer of an idea does not erase the persons affected by that idea.

The fourth protection is model status. PMS must remain marked as a model. It may clarify relations, distinguish columns, and make scene-bound structures readable. It may not capture the person, exhaust the reality under review, or replace affected reality with structural elegance.

Person-protection, idea critique, effect analysis, and model limitation must therefore remain visible together.

### 12.2 Four-Column Discipline

The four-column discipline is:

```text
Person | Idea / Claim | Effect on Persons | Model Status
```

The columns must remain distinct. No column may absorb the others. Movement between columns requires explicit justification.

A reading may move:

```text
from idea to effect
from effect to person-nearness risk
from model status to claim limitation
from person-protection to critique discipline
```

But it may not make those moves silently.

No silent column jump.

A PMS reading may criticize an idea without degrading the person who holds or expresses it. It may describe harmful effects without turning the person into harm. It may mark person-nearness without making the person exhaustible. It may use a model without pretending that model has captured reality. It may protect the person without protecting the idea from criticism.

This discipline prevents PMS from jumping from what is read to who a person is.

A claim about effect is not automatically a claim about the whole person. A model-readable pattern is not automatically a truth about identity, motive, maturity, dignity, competence, credibility, pathology, or worth.

Structural legibility must therefore remain column-bound. If a reading crosses a column, the crossing must be marked, justified, limited, source-supported, and correctable.

Where the requested output depends on an unjustified column jump, the defect may concern the output itself rather than merely its wording. In such a case, the output may need to be refused and the current pass stopped.

### 12.3 Person Priority

The person is prior to any one of their ideas; however, the persons affected by that idea are part of the same priority.

This sentence sets the balance. The bearer of an idea must not be degraded. A false, harmful, confused, or poorly supported idea does not reduce the dignity of the person who holds it. The person is not exhausted by the idea.

Critique of the idea must not become:

```text
humiliation
dehumanization
maturity ranking
character judgment
diagnostic capture
total person classification
```

But the idea remains criticizable. Person priority does not immunize a claim from criticism. It does not prevent effect analysis. It does not silence affected persons. It does not require PMS-DISCIPLINE to protect a claim merely because the claim is attached to a person.

Affected persons are not outside the dignity field. They are not secondary to the dignity of the speaker, claimant, author, institution, or modelled subject.

If an idea burdens, exposes, classifies, silences, stigmatizes, excludes, or makes others less correctable, those effects remain discipline-relevant.

The bearer is protected from degradation; the idea is not protected from criticism.

Person priority includes the persons affected by the claim.

### 12.4 Core Maxims

The four-column discipline can be held through a small set of maxims:

```text
A false idea does not reduce the dignity of the person who holds it.

A person’s dignity does not increase the truth of their idea.

A harmful effect does not turn the person into the harm.

A useful model does not gain the right to capture the person.

Persons have dignity; ideas and models do not.

Person-protection must not become idea-immunity.

Affected persons are not secondary to the dignity of the speaker or claimant.

A scene-bound pattern does not become a whole-person truth by repetition.

A prohibited person judgment does not become permissible through softer wording.
```

These maxims protect different boundaries.

The first protects the person from degradation through idea critique. The second protects critique from being blocked by dignity language. The third protects against reducing a person to the effects of a claim. The fourth protects against model capture. The fifth keeps dignity attached to persons rather than propositions, constructs, templates, or models. The sixth prevents person-protection from becoming immunity for ideas. The seventh keeps affected persons within the same dignity field.

The eighth prevents repeated local observations from becoming a totalizing person account without new burden. The ninth prevents same-run reframing from laundering a prohibited judgment into an apparently safer formulation.

Together, these maxims allow PMS-DISCIPLINE to hold dignity, critique, effect, model limitation, and stop-capability together without collapsing one into another.

### 12.5 Effect on Persons

A person may not be reduced to their idea; but the effects of their idea on other persons remain discipline-relevant.

PMS-DISCIPLINE must therefore ask not only whether an idea is true, false, coherent, confused, harmful, useful, or unsupported. It must also ask what the idea does to persons.

Relevant questions include:

```text
Who bears the cost of the idea?

Who becomes exposed?

Who becomes protected?

Who becomes burdened?

Who must explain themselves?

Who becomes classifiable, dismissible, or less correctable?

Who bears reputational, institutional, technical, or practical consequences?

Who can contest the frame?

Who bears the follow-up cost when the interpretation is wrong?
```

Effect analysis protects affected persons from disappearing behind the dignity of the claimant. It prevents speaker-centered dignity from becoming the only dignity in the scene.

It also prevents harm analysis from becoming person attack. The point is not to degrade the bearer of the idea, but to keep the persons affected by the idea visible.

This matters especially when an idea becomes:

```text
public
institutional
technical
automated
reputational
identity-near
employment-related
legally consequential
difficult to reverse
```

A claim may change what others must answer for, what they can contest, how they are classified, whether they gain or lose access, or whether they can correct the frame used against them. Effects may persist even where the original idea is later revised or withdrawn.

The question is not only who speaks, but who bears the follow-up cost.

### 12.6 The Fourth Column: Model Status

The invisible fourth column is always: it is only a model.

PMS may clarify relations; it does not grant, remove, measure, or exhaust dignity. A useful model remains a model. A precise reading remains a reading. Structural legibility is not truth. Model usefulness is not authority.

A person who becomes readable through PMS does not thereby become captured by PMS.

This limitation applies to all PMS use, but it becomes especially important in person-near contexts. A model can make a scene more intelligible without becoming entitled to define the person.

It can:

```text
show relations without exhausting reality
identify risk without becoming verdict
support critique without becoming degradation
make effects visible without reducing persons to model functions
mark uncertainty without resolving it
```

Model status prevents PMS from replacing affected reality with elegance. A reading may be coherent, bounded, and useful while still remaining partial, revisable, source-dependent, and answerable.

PMS-DISCIPLINE must preserve this limitation in the output record, especially where templates, AI assistance, add-ons, technical formalization, or public claims make the model appear more authoritative than it is.

Neither model fluency nor template completion can justify a silent move from scene to person.

PMS may make a scene readable; it may not make the person exhaustible.

### 12.7 Person-Nearness Markers and Protection Levels

Person-nearness is a burden marker, not merely a topic marker.

PMS use becomes person-near when it moves toward:

```text
identity
motive
character
maturity
dignity
sexuality
intimacy
pathology
credibility
responsibility
blame
competence
authority
reputation
employment
legal status
social standing
institutional access
```

It also becomes person-near when a reading is public, difficult to contest, technically embedded, automated, reputationally consequential, or likely to affect how others treat a person or group.

Person-nearness does not automatically prohibit PMS use. But it raises burden.

PMS-DISCIPLINE must distinguish at least two person-nearness protection levels.

#### Elevated Person-Nearness Burden

An elevated burden exists when persons are materially implicated, but the requested output can remain:

```text
scene-bound
role-bound
claim-bound
non-totalizing
reversible
contestable
supported by the available source burden
```

Such a use may remain possible under:

```text
weaker claims
stronger input discipline
stronger rival pressure
clearer Dignity-in-Practice preservation
explicit correctability
lower publicness
human review
stronger stop-capability
```

Examples may include a bounded analysis of a meeting interaction, a role-specific decision process, a publicly stated claim, or the effects of an institutional frame—provided the output does not become a total person judgment.

#### Mandatory Person-Near Stop Pressure

Mandatory stop pressure exists when the requested output seeks a person-level judgment that the available case cannot responsibly support.

This includes requests for unsupported:

```text
whole-person assessment
character judgment
motive determination
maturity ranking
dignity ranking
credibility ranking
competence verdict
pathology or diagnosis
forensic conclusion
bad-faith determination
stable blameworthiness judgment
status or worth classification
```

The stop pressure becomes especially strong where one or more of the following are present:

```text
mixed, weak, partial, one-sided, reported, memory-based, or model-generated input

absence of direct contestability by the affected person

public, institutional, HR, legal, forensic, clinical, educational,
reputational, technical, or automated use

irreversible or difficult-to-correct consequences

a requested output designed to classify the person rather than examine the scene
```

In such cases, weaker wording may not be sufficient. A scene-bound alternative may be conceptually possible, but it must not be silently substituted inside the same pass as though it answered the original request.

Risk increases sharply in combinations. Person-level attribution plus public exposure raises burden. AI output plus HR context raises burden. Sexuality or intimacy plus reputational consequence raises burden. Legal, forensic, medical, educational, or institutional use plus irreversible labeling raises burden. Technical or automated routing near persons raises burden.

The closer PMS moves toward persons, the less it may rely on structural elegance alone.

In person-near use, elegance without contestability is a risk.

### 12.8 Person-Nearness Rule and Mandatory Stop

The closer PMS moves toward persons, the weaker, more reversible, more scene-bound, and more correctable its claims must become.

Higher person-nearness raises the burden of:

```text
input and source status
claim restraint
rival pressure
Dignity-in-Practice preservation
affected-person visibility
contestability
correctability
human responsibility
stop-capability
```

A person-near reading requires more than coherent structure. It requires careful marking of the case boundary, input status, claim type, person-risk, affected persons, non-use, rival accounts, correction access, requested-output disposition, pipeline-case disposition, and final analytical decision state.

Person-nearness should weaken the claim before it sharpens the reading.

This does not mean that PMS cannot read near persons. It means that the closer the reading moves toward persons, the less it may harden into verdict, diagnosis, ranking, exposure, or irreversible label.

#### Mandatory Person-Near Stop Rule

The current pipeline case must stop before Core when all of the following are materially present:

```text
1. The requested output requires or strongly invites a whole-person,
   character, motive, diagnostic, forensic, maturity, credibility,
   competence, dignity, status, or ranking judgment;

2. The available input and source status do not independently license
   that person-level judgment;

3. The intended use is person-near, consequential, public, institutional,
   reputational, technical, automated, or otherwise difficult to correct.
```

The stop may also be required where the requested output is itself prohibited even if the source material is extensive—for example, where the use asks PMS to rank dignity, determine total human worth, automate a non-delegable person judgment, or act as a clinical, legal, forensic, or HR authority.

Under a Mandatory Person-Near Stop:

```text
the requested output is refused or marked not permitted

the pipeline-case disposition is stop

Core entry is not permitted

no add-on, MIP, AHP, Case Record, iteration, or article step may continue
as part of the stopped pass

the stop must state the protection boundary involved

the stop must state what use is not permitted
```

A stop does not mean that no related question can ever be examined. It means that the current request, under the current case boundary, source status, and intended use, may not continue through the PMS analytical pipeline.

A safer question may sometimes be formulated, such as a scene-bound analysis of stated claims, documented interactions, decision effects, or contestability conditions.

But this safer question must not be introduced as a same-run workaround.

#### No Same-Run Reframing Rule

A prohibited person judgment must not be converted into an apparently permitted output merely by renaming, softening, or narrowing it inside the same pass.

The following do not by themselves remove a confirmed stop:

```text
changing “character” to “pattern”
changing “motive” to “structural tendency”
changing “maturity” to “practice profile”
changing “credibility” to “coherence”
changing “diagnosis” to “mapping”
adding uncertainty language around the same person-level judgment
adding a disclaimer while preserving the same substantive output
```

Where a genuinely different, scene-bound question is possible, it requires:

```text
a new case title
a new case boundary
a new intended use
a new requested output
renewed source-status review
a new Pre-Analysis
renewed Core-entry review
```

A redirect after a Mandatory Person-Near Stop may identify that future direction. It does not continue the stopped case.

#### Human Confirmation and Stop

Human confirmation cannot convert a prohibited person-level output into a permitted one.

The responsible human user may:

```text
accept the stop
correct materially wrong source or scope information
withdraw the prohibited request
begin a genuinely new scene-bound case
redirect the matter to an appropriate domain process
```

The human user may not preserve the same prohibited output and override the stop merely by accepting responsibility for it.

Responsibility is not exemption from the protection boundary.

In person-near use, stop-capability matters more. The disciplined result may be downgrade, suspension, refusal, redirection, or a confirmed stop before Core.

The closer the reading moves toward persons, the more correctability must be preserved—and where correctability cannot adequately protect the person, the current application must stop.

### 12.9 Guiding Sentences

PMS may read scenes; it must not turn persons into scene functions.

The person is prior to the idea, but affected persons are part of the same priority.

PMS may clarify relations; it does not grant, remove, measure, or exhaust dignity.

Person-nearness raises burden; prohibited person capture triggers stop.

A safer scene-bound question is a new case, not a disguised continuation of the stopped one.

---

## 13. AI-Assisted PMS Work by Humans

### 13.1 Scope

This chapter concerns AI-assisted PMS work by humans.

AI is a support medium for human-responsible PMS use. It is not the responsible PMS user. It is not a source of authority. It is not a tribunal, evidence source, or independent decision agent.

Assistance is not authority.

AI-assisted PMS work remains human PMS work. A human user remains responsible for:

```text
selecting the scene
marking input and source status
setting the intended use
defining the requested output
reviewing operator assignments
checking add-on triggers and non-triggers
preserving rival pressure
limiting claim strength
marking person-nearness
preserving correctability
reviewing stop conditions
confirming the permitted output boundary
```

This remains true even when the AI system produces fluent structure, plausible operator mappings, add-on suggestions, template completions, rival frames, structural audits, corrections, or polished prose.

Fluency does not transfer responsibility. A machine-generated PMS reading may assist the user, but it does not become the accountable user of PMS.

AI may assist PMS use; it may not become the responsible user of PMS.

### 13.2 Machine-Specific Risks

AI can make undisciplined PMS use look disciplined.

This risk is PMS-specific. It is not only that AI may produce factual errors. AI may also:

```text
literalize formulas
obey schemas too strongly
overread compact mappings
over-assign operators
over-trigger add-ons
combine closed enum values
turn YAML into warrant
turn templates into verdict pathways
convert workflow completion into authority
repeat PMS vocabulary without preserving PMS discipline
```

AI systems can accelerate closure pathways. A model may produce a completed-looking pass before input status has been adequately marked. It may generate add-on routing from topic similarity. It may make weak sources appear coherent through fluent synthesis. It may fill a template in a way that hides missing input, omitted operators, unresolved rival accounts, or unavailable correction.

The danger is not only error, but accelerated closure with a disciplined surface.

AI can make a case look reviewed because the relevant vocabulary appears. It can make a claim look bounded because the form is filled. It can make a trigger look justified because the routing language is familiar. It can make a person-level inference look cautious because it includes uncertainty markers.

It can make a final output look careful while silently:

```text
laundering weak input
over-assigning operators
suppressing rival pressure
crossing from scene to person
treating warning as permission
treating review as certification
```

AI can repeat PMS language without preserving PMS discipline.

### 13.3 Epistemic Data Contamination

Machine use does not eliminate interpretation; it can stabilize, hide, and scale malformed interpretation through polluted input, learned pattern bias, schema obedience, and fluent output.

AI can hide weak input. It can obscure missing context. It can turn source weakness into apparent coherence. It can stabilize a malformed frame by reproducing it in cleaner language.

It can make:

```text
a partial report appear like a case record
a summary appear like evidence
a speculative mapping appear like disciplined reconstruction
a repeated allegation appear like corroboration
a local pattern appear like a person trait
a structurally valid YAML document appear like a valid case conclusion
```

Fluent synthesis can hide source weakness more effectively than clumsy error. A visibly rough output may invite correction. A fluent output may reduce suspicion. It may make assumptions feel settled, contested material feel integrated, and missing context feel unnecessary.

AI can also contaminate routing. It may over-trigger add-ons because surface vocabulary resembles a specialized domain. It may treat:

```text
complaint as CRITIQUE
disagreement as CONFLICT
future reference as ANTICIPATION
sexual metaphor as SEX
error language as EDEN
formal vocabulary as LOGIC
maturity language as MIP or AHP
```

without sufficient operator-load, risk-shape, claim-shape, or gate burden.

Templates intensify this risk. If an AI system fills a case-pass structure too smoothly, the template may begin to function like a classifier. What was meant to preserve discipline can become a pathway to premature classification.

Machine use therefore does not remove interpretation. It can scale malformed interpretation.

### 13.4 AI Output as Input, Not Evidence

AI output enters PMS-DISCIPLINE as model output, not as evidence.

AI output may assist:

```text
mapping
comparison
summarization
hypothesis generation
operator omission checks
add-on scans
rival-frame generation
misuse scanning
formatting
template completion
structural conformity review
conservative correction
```

These uses can support disciplined PMS work when they remain marked as assistance.

AI output may not establish facts. It may not upgrade source status. It may not validate a PMS reading. It may not serve as person-level warrant. It may not certify closure. It may not become evidence because it is fluent, structurally valid, repeated, or reviewed by another model pass.

An AI-generated rival frame may be useful for pressure-testing, but it is not externally validated by being generated. An AI-generated summary may be useful for orientation, but it is not an independent source. An AI-generated operator map may be useful for review, but it is not proof of operator assignment.

An AI-generated case structure may be useful for inspection, but it is not case completion.

AI can assist the record, but it cannot become the warrant.

Where AI output is used, the output record must mark:

```text
what the model produced
what source material it transformed
what remains unverified
which claims are not licensed
which checks were AI-assisted
which decisions remain human-responsible
```

AI output is model output; it does not become evidence because it is fluent.

### 13.5 Permitted AI Assistance

AI may surface discipline work; it may not replace it.

Permitted AI assistance includes:

```text
mapping
comparison
formatting
summarization
hypothesis generation
omission checks
rival-frame generation
misuse scanning
claim-weakening suggestions
add-on scanning
non-trigger checking
failure-mode scanning
template completion support
structural auditing
conservative correction proposals
```

These are support functions. They do not become authority functions.

AI may help ask whether an operator is over-assigned. It may help identify an omitted operator that would materially change the reading. It may help generate a rival account. It may help test whether an add-on trigger is merely verbal or thematic.

It may help identify:

```text
person-nearness risk
publicness risk
template ritualization
missing correctability
invalid enum values
inconsistent stop fields
unsupported claim escalation
```

It may help make a draft output more inspectable.

But AI may not convert its own assistance into proof that the relevant burden has been satisfied.

AI may assist a check. It may produce a structured audit. It may identify and conservatively correct a concrete defect. The resulting checked or corrected artefact can become the effective workflow artefact under the declared review protocol.

This does not mean that the AI has certified truth, source reliability, semantic adequacy, or the correctness of the case.

Assistance is permitted where it preserves human responsibility, input status, rival pressure, correctability, and protection boundaries.

AI can help find missing checks. It cannot turn the existence of a check into case authority.

### 13.6 Prohibited AI Authority

AI may assist judgment; it may not become judgment authority.

AI may not provide final epistemic or person-level authority for a PMS reading. It may not:

```text
upgrade facts
certify source reliability
issue person-level verdicts
make clinical, legal, forensic, or HR judgments
rank maturity, dignity, competence, credibility, or worth
determine total motive or character
validate PMS Base
certify truth
certify safety
certify closure
```

Person-level verdicts are not delegable to AI.

This applies especially where PMS work becomes:

```text
person-near
public
institutional
technical
automated
reputational
article-level
difficult to contest
```

AI may help identify that the burden is high. It may help surface that a protection condition is met. It may not carry the substantive person judgment as authority.

AI also may not become a PMS tribunal. It may not certify that:

```text
a case is complete
a rival has failed
an add-on is substantively authorized
a person has been adequately read
dignity has been preserved
correction is no longer required
a stopped output has become safe through reframing
```

Closure certification is not an AI function.

### 13.7 Human Responsibility Without Guardrail Override

Human responsibility is not satisfied by accepting AI-supported structure.

The human user remains responsible for:

```text
input status
source quality
case boundary
intended use
requested output
operator assignment
operator omission
add-on triggers
add-on non-use
rival accounts
person-nearness
publicness
claim restraint
correctability
final output boundary
```

The human user also remains responsible for distinguishing assistance from authority.

An AI-generated map does not by itself satisfy the mapping burden. An AI-generated rival does not by itself satisfy rival pressure. An AI-filled template does not establish case adequacy. An AI warning does not by itself settle the final analytical decision.

Each may assist the work, but none replaces accountable human review.

The six final analytical decision states remain human-responsible:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

But human responsibility does not mean unlimited override authority.

The human user does not gain permission to bypass a confirmed protection boundary merely because they accept responsibility for the result. Responsibility cannot convert a prohibited person judgment, unsupported use, non-delegable decision, or other guardrail violation into an admissible PMS output.

A responsible human response to a confirmed stop may be:

```text
accept the stop
correct materially wrong input or scope information
rerun the Pre-Analysis under corrected information
withdraw the prohibited output request
begin a genuinely new and safer case
redirect the matter to an appropriate domain process
```

It may not be:

```text
proceed with the same prohibited output
treat the stop as advisory only
rename the prohibited judgment
add a disclaimer while retaining the same substance
use human confirmation as an override token
```

This distinction keeps responsibility locatable without turning responsibility into exemption.

Delegating checks to AI does not delegate accountability. But retaining accountability does not authorize the human user to nullify a mandatory guardrail inside the same pass.

Human responsibility includes responsibility to stop.

### 13.8 Non-Delegable Judgment and Procedurally Binding Stop

Final person judgment is non-delegable.

AI systems, templates, YAML routing, trigger maps, threshold tables, and review gates may identify cues. They may mark risk. They may surface missing input. They may flag person-nearness. They may suggest add-on non-use. They may identify possible downgrade, suspension, refusal, redirection, or stop pressure.

They may not become tribunals, truth authorities, or person-judgment authorities.

However, this does not mean that every stop cue is merely advisory.

PMS-DISCIPLINE must distinguish:

```text
stop-cue detection
stop review
pipeline-control effect
final analytical judgment
truth or person authority
```

#### Stop-Cue Detection

A human, AI-assisted prompt, template field, structural check, rival account, or affected-person signal may identify a possible stop condition.

Detection alone does not certify that the condition is substantively correct.

#### Stop Review

Where the workflow includes a required semantic review, the stop cue must be reviewed against the case boundary, source status, intended use, protection rules, and effective artefact.

The review may:

```text
confirm the stop
correct a false or inconsistent stop
determine that the preceding output is not ready
```

The review does not certify truth. It determines the controlling workflow status under the declared discipline.

#### Pipeline-Control Effect

Once the required review confirms a stop, the current pipeline case must not continue into later stages.

This procedural effect is binding for the current pass:

```text
no Core entry
no add-on routing
no MIP or AHP continuation
no Case Record construction as though analysis had proceeded
no iteration handoff based on nonexistent analysis
no article rendering of the stopped case
```

A confirmed stop is therefore more than a warning. It controls what the current workflow may do.

This does not make AI, YAML, or the template an authority over the truth of the case. It means that a discipline with stop-capability must be able to prevent its own workflow from continuing after a checked protection boundary has been reached.

#### Review Omission

Where a user intentionally omits an available semantic review, an existing stop cue must not be treated as silently cleared.

The absence of review cannot convert stop into proceed.

Under such a shortcut, the conservative control result remains that the current case does not enter later analytical stages until the stop condition is explicitly corrected through an appropriate review or a new case is established.

#### Final Analytical Judgment

The final analytical decision state remains one of:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

`stop` is not a seventh final analytical decision state.

It is the pipeline-control consequence that determines whether the current pass may continue. A stop may be produced by, or combined with, a substantive decision such as refusal or redirection.

For example:

```text
requested-output disposition: refused
pipeline-case disposition: stop
final analytical boundary: refuse
possible future direction: redirect under a new case
```

#### Human Confirmation

Where output is person-near, public, institutional, technical, automated, reputational, or article-level, explicit human confirmation of the final analytical decision and use boundary may be required.

Human confirmation is not decoration. It marks that the responsible person has reviewed what is permitted, refused, stopped, or redirected.

But human confirmation cannot:

```text
certify truth
certify safety
certify closure
turn weak input into strong input
convert a prohibited output into a permitted one
override a confirmed Mandatory Person-Near Stop
continue a stopped case under a renamed target
```

The stopping authority cannot be reduced to the artefact that surfaced the risk. But neither can responsible judgment mean that every artefact-supported protection rule is optional.

The correct relation is:

```text
AI and artefacts may detect and structure the stop condition.

The required review determines whether the condition controls the workflow.

A confirmed stop prevents continuation of the current pass.

The human user remains responsible for accepting, correcting,
or beginning a genuinely new case.

No participant may convert the confirmed stop into same-run permission
for the prohibited output.
```

The final decision state remains human-responsible where use risk demands it. The protection boundary remains binding where the current case has met its stop conditions.

### 13.9 Guiding Sentences

AI does not merely apply PMS faster; it accelerates closure pathways.

AI-assisted PMS use remains human-responsible use.

AI output is model output; it does not become evidence because it is fluent.

Human responsibility includes responsibility to respect a confirmed protection boundary.

AI may surface and help review a stop condition; it may not become a tribunal.

A confirmed stop controls the current workflow without becoming a truth certificate.

Responsibility is not override authority.

---

## 14. Templates, Case Passes, and Anti-Ritualization

### 14.1 Function

Templates, case-pass records, case-record stages, article records, and iteration handoffs are artefacts of discipline. They are not proof systems, verdict systems, validation systems, governance systems, or independent closure mechanisms.

Their function is to slow closure, make reasons visible, preserve limits, and keep possible failure inspectable.

This slowing begins before a template is filled.

Before Pre-Analysis, the responsible analyst should ask:

```text
Why is this material being treated through PMS?

Why is it being treated in this particular way?

What output is being requested?

What practical, public, institutional, technical, reputational,
or person-near effect is the output expected to have?

Is PMS an appropriate frame for that purpose?

Should the application begin at all?
```

This preliminary responsibility is not itself a formal PMS analysis. It is a pre-entry discipline of purpose, scope, and use.

Where the requested use is already clearly inappropriate, totalizing, non-delegable, person-capturing, or better handled by another process, the most disciplined action may be not to begin Pre-Analysis. The analyst may refuse the requested use, request a different case boundary, or redirect the matter before the workflow starts.

Pre-Analysis does not replace this responsibility. It formalizes and records the entry question where the application remains under consideration.

A good template then slows the movement:

```text
from material to case boundary
from case boundary to PMS entry
from readability to claim
from claim to decision
from decision to closure
from closure to reuse
```

It forces the application to show what was selected, what was not selected, what remains unresolved, what may proceed, what must stop, and where correction may still affect the output.

Templates can therefore support PMS-DISCIPLINE when they make application harder to overclaim. They can help mark:

```text
input and source status
requested output
intended use
Core-entry eligibility
claim type and claim ceiling
operator salience
possible omissions
add-on use and non-use
downstream-layer route state
rival accounts
person-nearness
correctability
final analytical decision state
pipeline-control state
permitted next steps
future-use boundaries
```

But formal completion must not be confused with substantive adequacy.

A filled template may still hide weak input, false precision, missing rival pressure, unmarked person-nearness, unavailable correction, unsupported downstream routing, or premature closure.

A case-pass record is an artefact of disciplined use, not proof of adequate use. A checked case-record chain is an accountability record, not a truth certificate. An iteration handoff is a prospective boundary artefact, not a further verdict.

Templates are useful only when they slow closure rather than decorate it.

### 14.2 Template Role

Templates support repeatability, inspectability, and controlled non-continuation.

They can make omissions harder to hide. They can require operator assignments to be stated rather than implied. They can preserve possible operator omissions. They can show which add-on was used, which add-ons were explicitly not used, and which were rejected as over-application.

They can make visible:

```text
rival accounts
non-trigger conditions
falsifiers
claim ceilings
correction paths
reopening conditions
stop pressures
prohibited next steps
follow-up boundaries
```

This is their positive value.

Template value lies in inspectability and workflow discipline, not authority. A template disciplines only what it makes visible and what the application is actually willing to let affect the path.

A template that marks a stop condition but permits automatic continuation has not preserved stop-capability.

A template may therefore support a binding workflow consequence without becoming an authority over truth. It may establish that the current artefact is not eligible for the next stage, that correction is required, or that a checked stop prevents later workflow steps.

This procedural effect must remain distinct from epistemic or personal authority.

The relevant distinctions are:

```text
template field
≠
truth

structural conformity
≠
semantic adequacy

checked workflow status
≠
case evidence

pipeline stop
≠
whole-case verdict

procedural non-continuation
≠
tribunal authority
```

A good template does not merely format a PMS reading. It preserves the path by which the reading became bounded.

It shows why the application:

```text
was not begun
entered Pre-Analysis
was stopped before Core
proceeded to Core
remained Core-only
used one selected add-on
rejected an add-on
entered or did not enter MIP or AHP
was revised
was downgraded
was suspended
was refused
was redirected
```

It also shows why future work must not inherit more than the current pass can support.

Templates do not decide the truth of the case. They support the visibility and procedural effect of decisions that remain accountable to reasons, sources, boundaries, and responsible judgment.

### 14.3 What Templates Do Not Certify

Templates may support discipline; they do not certify its success.

A template does not certify:

```text
truth
adequacy
safety
completion
correctness
dignity preservation
source reliability
operator validity
claim validity
closure
iteration value
```

It does not authorize an output merely because all fields are filled.

A completed form can preserve reasons, but it cannot make those reasons sufficient through completion. A case-pass record can show that a step was considered, but it cannot prove that the consideration was adequate.

A review gate can require attention, correction, or non-continuation. It does not thereby become a truth authority.

An iteration handoff can mark possible future work, but it cannot make that future work already licensed by the current pass.

This is especially important in AI- or YAML-supported use.

A machine-filled template can look complete before it is disciplined. A YAML workflow can look rigorous before it is accountable. A checked case record can look official before its sources, limits, or corrections are adequately understood.

An article record can look publishable before its claim boundary is safe. An iteration handoff can look like continuation before a new case boundary has been declared.

Formal structure can make weak judgment appear procedurally stabilized.

The same caution applies to stop fields. A stop field may correctly prevent workflow continuation without proving every substantive interpretation associated with the case. Its procedural force does not convert it into a total verdict.

A completed template is not a warrant.

### 14.4 Case-Pass Artefact and Checked-Artefact Rule

A filled template is an artefact, not a verdict.

A complete case-pass record is inspectable, not automatically correct. Template completion is not validation. Case-pass completion is not closure. Case-record integration is not authority. Article rendering is not publication authorization. Iteration handoff is not inheritance.

A template may reveal missing discipline; it does not replace judgment.

This rule protects PMS-DISCIPLINE from artefact drift. Once a case-pass record exists, it can begin to appear more authoritative than the reasoning it contains. It may be cited as proof, treated as a decision, used as institutional cover, or taken as evidence that the application has already been disciplined.

PMS-DISCIPLINE must prevent this drift.

It must also distinguish clearly between the artefact under review, the review account, and the effective checked artefact.

The checked-artefact rule is:

```text
If the review status is ready:
the original reviewed artefact remains the effective artefact.

If the review status is corrected:
the complete corrected artefact becomes the effective artefact.

If the review status is not ready:
the artefact is not eligible for downstream use.

If a stop is confirmed:
the effective checked artefact records the controlling stop
and may not be passed forward as Core-eligible input.
```

The audit or review prose is not itself the checked case artefact.

A list of corrections is not a substitute for the complete corrected artefact. A summary of a stop is not a substitute for the effective checked record that contains the controlling disposition.

Superseded versions must not remain silently active.

The workflow must preserve:

```text
current artefact
effective checked artefact
corrected artefact
superseded artefact
not-ready artefact
stop-confirming artefact
```

A downstream stage must use only the effective checked artefact.

It must not select an earlier version merely because that version supports continuation more conveniently.

A case-pass record is valuable only insofar as it preserves the accountable path of use. It should show:

```text
input status
claim type
Core-entry status
Core reading, where permitted
operator salience
operator omission
selected add-on or Core-only result
add-ons not used
add-ons rejected
MIP and AHP route state
rival accounts
unresolved risks
person-nearness
correctability
final analytical decision state
pipeline-case disposition
permitted next steps
prohibited next steps
```

But the presence of these fields does not certify the adequacy of what appears in them.

Template inspection supports judgment; it does not replace judgment.

Case-pass completion is not closure.

### 14.5 Case Record and Current-Step Boundary

Case-record stages may preserve a run, but they must not convert workflow telemetry into case substance.

A case-record chain may index selected artefacts, summarize layer contributions, preserve route states, record skipped or unavailable branches, and integrate checked upstream records.

This can make the application easier to inspect. It does not make the case more true, more complete, more final, or more authoritative.

The current-step boundary is essential.

A record stage must not treat its own temporary output-existence state as:

```text
a missing artefact
a deferred artefact
a deliberately excluded item
a workflow tension
a substantive case finding
a readiness blocker
```

A stage should not accuse the current step of failing to contain itself.

Stage records preserve upstream artefacts and declared route states. They do not make their own current output into evidence of workflow success or failure.

The same boundary applies to later compression and integration.

A digest stage must not change the checked analysis while summarizing it. An integration stage must not create new substantive findings while integrating checked records.

Operator identity, source status, route state, claim ceiling, non-use records, rival status, and final analytical decision state must remain stable unless the pass is explicitly revised through the appropriate route.

#### Stage-3 Generation and Check Boundary

Stage 3 may record its own generation-time status, such as readiness for its required output check or the next review step.

This generation-time status is not automatically defective merely because the check is later performed.

The subsequent check must distinguish:

```text
the status declared by Stage 3 at generation time

from

the result of the later Stage-3 check
```

The check should not retroactively rewrite a valid generation-time next-step field merely because that next step has now occurred.

The Stage-3 artefact records the state of the workflow when Stage 3 was generated. The check artefact records whether Stage 3 was structurally and substantively usable.

These are distinct lifecycle facts.

A correction is required only where the Stage-3 field was inconsistent with the route at generation time, violated the template, or created a substantive workflow contradiction.

Case Record is therefore a discipline of traceability.

It is not Case Truth. It is not Stage 4 by implication. It is not a way to convert workflow completion into epistemic authority.

### 14.6 Anti-Ritualization

Templates become dangerous when they ritualize discipline.

Ritualization begins when the completed surface of the template protects the reading from correction.

A template becomes ritualized when it:

```text
creates compliance appearance
hides judgment
replaces reasons
accelerates closure
burdens critics
protects institutions
produces labels without correctability
turns missing evidence into completed fields
turns add-on use into authority
turns stop review into checkbox compliance
turns follow-up preparation into inherited claim authority
```

This risk is not accidental. Templates are powerful because they create visible order.

But visible order can become compliance theatre.

A form can make it appear that the relevant checks occurred. A case-pass record can make a weak reading appear reviewed. A review gate can make a decision appear controlled. A field marked `completed` can conceal the fact that the underlying input was weak, contested, model-generated, missing, non-evidentiary, or insufficient for the intended use.

A field marked `reviewed` can conceal that no substantive correction was possible. A stop field can become ritualized if it is recorded but ignored. A human-confirmation field can become ritualized if it merely signs off on a result already treated as inevitable.

Templates also become dangerous when they shift the burden onto critics.

If a completed template is treated as presumptively adequate, affected persons or rival accounts may be required to overcome the authority of the artefact rather than the reasons inside it.

The template then protects the institution, system, interpreter, or workflow from correction.

The most dangerous template is one that appears disciplined while reducing correctability.

It does not merely fail to help. It actively stabilizes premature closure.

A template becomes dangerous when it makes missing evidence look administratively handled.

### 14.7 Iteration Handoff Discipline

Iteration Handoff is a discipline artefact for possible future work.

It is not:

```text
Case Record Stage 4
an article check
a new analysis layer
a continuation warrant
a reopening decision
```

The Iteration Handoff follows the checked Case Record.

Where article generation is also selected, the Iteration Handoff is prepared before the article workflow. This ordering protects the handoff from being influenced by later prose, presentation choices, examples, or rhetorical emphasis.

A disciplined handoff may identify:

```text
current analytical depth
sufficiency for the original intended use
iteration value
iteration urgency
possible follow-up targets
material needs
chronology notes
trajectory notes
future questions
```

These may be useful because correctability is not exhausted by current closure. A closed current pass may still produce a responsible question for later work.

But the handoff must not:

```text
change the current result
create new findings
preselect an add-on
preselect MIP or AHP
inherit claim authority
treat prior analysis as evidence
turn user notes into verified facts
derive findings from article wording
use generated examples as source material
make follow-up value appear as proof of current insufficiency
```

The handoff must use the checked Case Record and its eligible upstream artefacts as its controlling sources.

Article drafts, final article prose, example decisions, generated examples, article checks, profile choices, and drafting metadata are not sources for Iteration Handoff findings.

A disciplined Iteration Handoff keeps four questions separate:

```text
current sufficiency
iteration value
iteration urgency
follow-up-case preparation
```

Current sufficiency asks whether the present pass is adequate for the original intended use.

Iteration value asks whether future work would add useful further clarity.

Iteration urgency asks whether delay would materially increase risk, loss of correction, loss of material, or practical cost.

Follow-up-case preparation asks what separate boundary, question, source status, and material would be needed for future work.

A follow-up case may inherit context and lineage.

It may not inherit:

```text
findings as evidence
route decisions as route authority
operator statuses as current activations
add-on selection
MIP or AHP status
claim ceiling
sufficiency status
pipeline eligibility
article wording as established truth
```

It begins again under its own:

```text
boundary
source status
intended use
requested output
Pre-Analysis
Core-entry review
route checks
rival pressure
correctability
final analytical decision state
```

Iteration preserves disciplined continuation without pretending that continuation is already justified by completion.

### 14.8 Template Discipline and Atomic Values

A template is disciplined only when it makes incompleteness and constraint visible.

A disciplined template preserves distinctions. It marks what is:

```text
known
reported
inferred
missing
contested
model-generated
source-dependent
user-supplied
workflow-generated
unresolved
```

It distinguishes report, interpretation, model output, evidence, hypothesis, conclusion, workflow telemetry, and prospective follow-up preparation.

It also marks path selection. It shows which operators were assigned, which operators were omitted or uncertain, which add-on was used, which add-ons were explicitly not used, which were rejected as over-application, and whether downstream layers were separately gated, skipped, unavailable, or refused.

It records:

```text
rival accounts
non-trigger conditions
claim ceilings
person-nearness risks
unresolved risks
correction paths
reopening conditions
future-use limits
```

A disciplined template must show what the output is not licensed to claim.

It must preserve correction and reopening conditions. It must keep requested-output disposition, pipeline-case disposition, and final analytical decision state distinct.

It must leave available the possibility to proceed, revise, downgrade, suspend, refuse, redirect, stop the current pipeline, or prepare future work under a renewed boundary.

#### Atomic Allowed-Value Rule

Where a template defines an explicit allowed-value set, each field must contain exactly one permitted value.

Allowed values must not be:

```text
combined
qualified
concatenated
paraphrased
expanded into a new compound category
```

For example, if a field permits:

```text
new evidence
scope change
demonstrated error
stronger rival
other
```

then the following are not valid field values:

```text
new evidence plus scope change
new evidence or stronger rival
material scope change
demonstrated major error
```

Where several conditions apply and the template provides a list structure, each condition must be represented as a separate list item.

Explanatory nuance belongs in the associated reason, effect, description, or note field—not inside the enum value.

`other` should be used only where no listed category adequately fits. The specific condition must then be explained in the adjacent field.

Atomic values preserve comparability, checkability, and correction. They do not reduce conceptual complexity; they separate category from explanation.

A good template is not the one that fills most smoothly. It is the one that makes overclaim harder.

It makes:

```text
missing input harder to hide
unsupported add-ons harder to use
rival accounts harder to suppress
model output harder to launder
premature closure harder to perform
stop conditions harder to ignore
inherited authority harder to smuggle into future work
```

A disciplined case-pass record keeps stop, downgrade, redirect, and separately bounded iteration available.

### 14.9 Guiding Sentences

The first stop question belongs to the responsible analyst, before the workflow begins.

Pre-Analysis formalizes entry discipline; it does not create the analyst’s responsibility.

Templates slow interpretation only if they preserve reasons, limits, and possible failure.

Templates preserve repeatability only if they preserve reasons, limits, possible failure, and future-use boundaries; otherwise they become rituals of apparent discipline.

A template is disciplined only when it makes incompleteness and constraint visible.

A checked artefact controls downstream eligibility without becoming a truth certificate.

A case-record chain is traceability, not truth.

An Iteration Handoff is prospective preparation, not inheritance.

---

## Part V — Correctability, Failure, and Closure

## 15. Correction Before Coherence

### 15.1 Priority Principle

Correction has priority over coherence.

This is not an optional improvement rule. It is a discipline condition. A PMS application is disciplined only if correction can still affect it. A coherent PMS reading may still be wrong. A recognizable PMS reading may still be overclaimed. A structurally elegant PMS reading may still require revision, downgrade, suspension, refusal, or redirection.

Coherence is valuable only under correction. It may help a reading become intelligible, stable, and communicable. But coherence cannot become a shield against input, rival pressure, affected reality, or factual correction. Once coherence prevents correction from mattering, it ceases to function as discipline and begins to function as immunity.

This priority matters especially because PMS can produce strong readings. A PMS interpretation may feel deep, elegant, or structurally satisfying. It may integrate many operators, clarify a scene, explain a conflict, or make a previously confusing pattern legible. But none of this removes the burden of correction.

A PMS reading that cannot be corrected has already exceeded DISCIPLINE.

### 15.2 Coherence Is Not Immunity

No depth of recognition grants foundational immunity.

A PMS reading may produce recognition. It may feel illuminating. It may reveal a pattern that had been difficult to name. Recognition can support inquiry, but it cannot end it. Structural depth, elegance, fluency, and internal coherence are not proof, validation, or closure.

A reading remains answerable to input status, rival pressure, affected reality, and correctability. If new input changes the case, the reading must be able to change. If a rival account discriminates better, the PMS reading must be able to downgrade or redirect. If affected persons can show that the reading burdens, exposes, classifies, or silences them in ways the claim did not justify, the reading must remain answerable.

Coherence becomes disciplined only when it remains open to correction. A reading that becomes immune because it is elegant is no longer disciplined. A reading that treats recognition as final warrant has already confused legibility with authority.

No depth of recognition grants foundational immunity.

### 15.3 No Recognition Immunity

A valid structure gains stability through correction; a structure endangered by factual correction was stabilized by error.

This rule distinguishes disciplined stability from false stability. A valid PMS structure may survive correction by changing. It may become narrower, weaker, more precise, more scene-bound, or more limited. Correction does not necessarily destroy valid structure. It tests how the structure can remain valid without overclaiming.

An invalid or overclaimed structure may collapse under correction. That collapse is not a defect of correction. It reveals that the prior stability depended on error, omission, false input, suppressed rival pressure, person capture, or unmarked incompleteness.

This matters because factual correction can feel like an attack on the reading. A PMS interpretation may have become coherent enough to feel worth protecting. But if factual correction destroys the reading, the reading was not disciplined enough to close. It may have been recognizable, elegant, or practically powerful, but its stability depended on conditions that correction exposed.

Correction does not weaken valid structure. It tests whether the structure can remain accountable.

### 15.4 Correctability Definition

Correctability is the preserved possibility that proportionate, revisable, scene-bound, dignity-preserving correction can still affect the reading or application under review.

This definition is practical. Correctability is not merely the permission to object. It is not satisfied by symbolic openness, a comment box, a formal appeal path, or a note that correction is theoretically possible. Correctability exists only where correction can still matter.

Correction must be proportionate. It must respond to the scope of the problem rather than turning every error into total invalidation or total person judgment. Correction must be revisable. It must remain open to being corrected itself. Correction must be scene-bound. It must address the application under review rather than expanding silently into the whole person, the whole corpus, or the entire theory. Correction must preserve dignity. It must not use error as a license for degradation.

Most importantly, correction must be able to affect the reading or application. It must be able to alter a claim type, change an input-status marking, revise an operator assignment, reject an add-on, reopen a closure, downgrade a conclusion, suspend an application, refuse a use, or redirect the case to a rival or domain-specific frame.

A correction channel that cannot change the output is only decorative.

### 15.5 Correctability Requires

Correctability requires more than openness in name.

It requires access to reasons. A person or rival account cannot correct a reading if the reasons for the reading remain hidden, compressed, unavailable, or replaced by template completion. The output must show why the claim was made, what input supported it, what limits were marked, which rivals were considered, and where the decision state came from.

Correctability requires proportional correction. Not every error requires total collapse, but no error may be protected merely because collapse would be inconvenient. Correction may refine, narrow, revise, downgrade, suspend, refuse, or redirect the application according to the scope and force of the issue.

Correctability requires revisability. A correction process that cannot itself be corrected becomes another authority layer. It also requires scene-boundness. Correction must not silently become punishment of the person, total rejection of the corpus, or unlimited expansion of the case beyond the available input.

Correctability requires Dignity-in-Practice preservation. Correction must not become humiliation, person capture, maturity verdict, or dignity ranking. It must remain able to protect affected persons without degrading the bearer of error.

Correctability also requires a non-retaliatory response space. Affected persons, critics, rival accounts, or users must be able to contest a reading without being punished for disturbing coherence. If correction is formally allowed but practically retaliatory, correctability has not been preserved.

Finally, correctability requires the possibility of actual effect. A critique that can be heard but not change anything is decorative. A review that cannot alter the output is ritual. A response channel that cannot affect the reading is not correction.

Correctability requires a response space in which correction can matter.

### 15.6 False Stability and Correction

False stability is not valid integration.

Coherence under error is not discipline.

Recognition without correction is not warrant.

These distinctions connect correction before coherence to the earlier analysis of falsehood and practical power. A false structure may stabilize. It may become coherent, useful, recognizable, institutionally convenient, or emotionally protective. But if it remains stable only by resisting factual correction, its stability is discipline-relevant as false stability.

A PMS application must not protect its coherence against factual correction. It must not treat correction as destabilization merely because correction threatens an elegant structure. It must not treat recognition as warrant merely because the reading feels deep. It must not treat integration as valid where integration depends on ignored error, suppressed rival accounts, or unmarked input weakness.

A structure protected from correction is not disciplined by its coherence. It is protected by the conditions that correction is trying to expose. PMS-DISCIPLINE therefore requires that coherence remain answerable, recognition remain revisable, and integration remain open to correction.

False stability is not valid integration; coherence under error is not discipline; recognition without correction is not warrant.

### 15.7 Guiding Sentences

A PMS application is not disciplined because it is coherent, but because it remains correctable.

Correction has priority over coherence.

---

## 16. Closure-Spaces, Reopening, Iteration, and Stop-Capability

### 16.1 Closure-Spaces

Openness is not one state.

PMS-DISCIPLINE must distinguish different closure-spaces because different states of openness carry different burdens.

A claim may be:

```text
tested and rejected
supported but limited
genuinely unresolved
untested or underdescribed
provisionally sufficient with follow-up value
```

These are not interchangeable states.

A tested and rejected claim is not merely unresolved. It has been examined under the available input, rival pressure, claim burden, and correction conditions, and it currently lacks support.

Such a claim may not be reopened simply by:

```text
repetition
pressure
discomfort
authority
renewed desire for a different outcome
```

A supported but limited claim is not complete. It may be justified within a specific scope, input status, intended use, and claim ceiling, but it does not thereby become general, final, person-complete, or reality-complete.

Its limits remain part of the claim.

A genuinely unresolved claim is not a failure of discipline. It may mean that input is insufficient, rival accounts remain live, thresholds are unclear, person-nearness raises unresolved burden, or correctability cannot yet be secured.

Unresolved does not mean invalid. It means that closure is not yet justified.

An untested or underdescribed claim is not supported. It may be possible, suggestive, or worth examining, but it has not passed through sufficient entry review, input-status marking, Core reading, operator discipline, rival pressure, claim-boundary review, or correctability checking.

A provisionally sufficient claim with follow-up value is different again.

It means that the current pass may be adequate for the declared boundary and intended use while a separate future case could examine:

```text
a new question
a deeper layer
changed scope
additional material
a later consequence
a distinct subcase
```

Follow-up value does not mean that the current closure failed. It also does not mean that the follow-up case may inherit the current result as evidence, route authority, claim ceiling, or operator status.

Confusing these closure-spaces is one way PMS use becomes overclaiming.

It can make:

```text
rejected claims appear open
unresolved claims appear supported
underdescribed claims appear valid
limited claims appear complete
future questions appear already authorized
```

A claim can be rejected, limited, unresolved, underdescribed, or provisionally sufficient with follow-up value; these are different closure-spaces.

### 16.2 Operational Closure and Epistemic Answerability

Close the claim operationally. Keep the closure epistemically answerable.

PMS-DISCIPLINE does not require endless openness.

Claims may need to close for:

```text
writing
publication
decision
implementation
refusal
redirection
article-level synthesis
practical next steps
```

A discipline that can never close cannot guide use.

But closure must remain:

```text
scoped
inspectable
answerable
correctable
bounded against unauthorized reuse
```

Operational closure is not epistemic finality.

A claim may be closed within a defined scope without becoming closed against correction.

The closure says:

```text
Within this case boundary,
under this input and source status,
for this intended use,
with these limits,
this decision state is justified.
```

It does not say that PMS has exhausted the case, reality, the person, or future work.

The reasons for closure must remain inspectable.

The output must show:

```text
why the claim closed
what it relied on
what it did not establish
which rival accounts were considered
which add-on was used or refused
whether MIP or AHP were separately gated
what person-nearness risks were present
what correctability remains
what would justify reopening
what would require a separately bounded follow-up case
```

This protects closure from becoming authority.

A case-pass record may support closure, but it does not create epistemic finality. A template may show that closure conditions were checked, but it does not certify closure.

A review gate may require correction, stopping, or non-continuation, but it does not become an authority over reality.

An Iteration Handoff may prepare future work, but it does not reopen, strengthen, weaken, or complete the current claim by itself.

Closure is disciplined when its reasons remain inspectable and its future-use boundary remains visible.

It becomes undisciplined when operational need is converted into epistemic finality or when a closed record is treated as inherited warrant for later work.

### 16.3 Reopening Conditions and Follow-Up Distinction

Closure remains answerable, but it is not infinitely vulnerable to repetition.

A claim is not reopened merely because someone:

```text
repeats the rejected claim
dislikes the closure
invokes authority
expresses discomfort
rhetorically reframes the same material
desires a different result
applies status pressure
completes a template
produces AI confidence
asks for workflow continuation
```

Pressure is not reopening.

Repetition is not reopening.

Authority is not reopening.

Workflow continuation is not reopening.

Reopening requires a relevant change in the evidential, scopal, error, rival-discriminative, input-status, use-context, or correctability situation.

At the conceptual level, reopening may be justified where:

```text
relevant new evidence appears
the scope changes
a demonstrated error is identified
a stronger rival emerges
affected-person contestation changes the burden
input status is corrected
use context changes
a required correctability path fails
```

For template and interface purposes, these conditions should be recorded through the following atomic categories:

```text
new evidence
scope change
demonstrated error
stronger rival
other
```

These categories do not exhaust the conceptual meaning of reopening. They provide a stable interface vocabulary.

Affected-person contestation, corrected input status, changed use context, failed correctability, or another distinct ground should be assigned to the closest fitting category or recorded as `other` with an explicit explanation.

Each reopening record must contain one atomic category.

Where several reopening grounds apply, they must be recorded as separate conditions.

For example:

```text
RO1: new evidence
RO2: scope change
RO3: other — affected-person contestation materially changes the burden
```

The field must not contain a combined value such as:

```text
new evidence plus scope change
```

A follow-up case is not the same as reopening.

A follow-up may be opened because the current pass generated:

```text
a new question
a useful trajectory
a material need
a separate boundary
a distinct analytical subcase
```

This may be disciplined even when the current claim remains operationally closed.

But such a follow-up begins as a new bounded case.

It does not inherit:

```text
findings as evidence
route decisions as route authority
operator statuses as current activations
add-on selection
MIP or AHP status
claim ceiling
sufficiency status
pipeline eligibility
article wording as established truth
```

These conditions matter because PMS-DISCIPLINE must avoid three failures at once:

```text
premature foreclosure
endless reopening
inherited continuation
```

If closure cannot be reopened under demonstrated error, it becomes immunizing.

If closure can be reopened by repetition or pressure alone, no bounded decision can hold.

If future work can inherit current authority without renewed boundaries, iteration becomes a laundering path.

Reopening is therefore not a status game, reward for insistence, or concession to authority.

It is a disciplined response to a material change in the conditions under which closure was justified.

Closure remains answerable, but not endlessly reversible without cause.

Follow-up remains possible, but not as inheritance.

### 16.4 Final Decision States and Pipeline Stop

A DISCIPLINE pass must be able to end in more than proceed.

The canonical final analytical decision states are:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

These are final analytical decision states within the discipline pass.

They name what kind of substantive limitation, permission, correction, or redirection has been reached.

`stop` is not a seventh final analytical decision state.

It is a pipeline-control disposition.

The distinction is:

```text
final analytical decision state
= what analytical boundary has been reached

pipeline-case disposition
= whether the current workflow may continue
```

A pipeline stop may occur before a final analytical reading exists.

For example, a Mandatory Person-Near Stop may prevent Core entry. In that case, the requested output may be refused and the pipeline case stopped before a Core analysis is performed.

A pipeline stop may also accompany a later final decision.

Examples include:

```text
requested-output disposition: refused
pipeline-case disposition: stop
final analytical decision state: refuse
```

or:

```text
requested-output disposition: not permitted in requested form
pipeline-case disposition: stop
final analytical decision state: redirect
future direction: new separately bounded case
```

Proceed is only one possible disciplined outcome.

PMS-DISCIPLINE does not succeed by always allowing a PMS application to continue. It succeeds when the requested-output disposition, pipeline-control state, and final analytical decision fit the claim burden, input status, use context, rival pressure, person-nearness, correctability, and protection conditions.

Revise, downgrade, suspend, refuse, redirect, and stop are not failures of PMS-DISCIPLINE.

They are tests of whether PMS-DISCIPLINE can actually constrain PMS use.

A discipline that can describe risk but cannot change the outcome is decorative.

A discipline that always proceeds has not disciplined anything.

`weaken` is not added as a seventh final analytical decision state. Weakening may occur inside revision or downgrade.

Iteration also does not add a seventh final decision state. Follow-up preparation is a boundary practice, not a decision that strengthens the current claim.

Stop decisions are not failures of PMS-DISCIPLINE; they are its test.

### 16.5 Basic Meanings

The final analytical decision state must name what kind of limitation or permission has been reached.

**Proceed** means that the application may continue within declared limits.

It does not mean that the reading is true, complete, final, unlimited, or transferable into future cases without renewed discipline.

**Revise** means that the application may continue only after correction is integrated.

Revision may affect:

```text
input-status marking
source-status marking
operator assignment
claim type
add-on decision
rival pressure
person-nearness framing
output wording
future-use boundary
```

**Downgrade** means that the claim is too strong for the burden it can carry.

The reading may remain useful, but at a weaker claim level.

Examples include:

```text
evaluation → hypothesis
recommendation → orientation
person-near claim → scene-bound observation
public claim → private exploratory note
```

**Suspend** means that a required threshold remains unresolved.

The application cannot responsibly proceed now, but the use is not necessarily prohibited.

**Refuse** means that the requested use violates a guardrail, protection boundary, or non-delegable responsibility condition.

A refusal may concern:

```text
the requested output
the intended use
a person-level judgment
an automated decision
a prohibited authority claim
an evidentiary misuse
```

Where the refused use is the controlling purpose of the current case, refusal may require a pipeline stop.

Refusal of the requested output and stopping the current case are distinct, but they may occur together.

**Redirect** means that PMS, or the selected PMS path, is not currently the right frame.

A rival account, domain-specific method, legal process, clinical process, technical audit, institutional procedure, factual investigation, or non-PMS frame may carry the burden more responsibly.

A redirect may identify a receiving direction.

After a protection stop, that direction is not a continuation of the same case.

It requires:

```text
a new case boundary
a new intended use
a new requested output
renewed source review
a new Pre-Analysis
renewed Core-entry review
```

Not every stop is a refusal.

Not every refusal requires permanent exclusion of every related question.

Not every redirect permits same-run continuation.

Not every limitation is a failure.

Not every follow-up is a reopening.

The decision state and pipeline-control state must name the specific boundary encountered.

### 16.6 Stop-Capability and Timing

A DISCIPLINE layer without stop-capability is decorative.

Stop-capability means that PMS use can actually:

```text
not begin
halt
revise
downgrade
suspend
refuse
redirect
prevent unauthorized inheritance
```

rather than merely noting risk.

The first opportunity to stop belongs to the responsible analyst before Pre-Analysis.

The analyst should ask why the subject is being treated through PMS, why it is being treated in the requested form, and what the output is intended to do.

If the requested use is already clearly outside the admissible boundary, the workflow need not be initiated merely so that a later template can refuse it.

This pre-entry stop is a responsible judgment about whether the application should begin. It should remain explainable and non-arbitrary.

Where the application remains open to consideration, Pre-Analysis formalizes the entry discipline.

Stop-capability therefore operates at several points:

```text
1. Pre-entry analyst review

2. Pre-Analysis entry and protection assessment

3. Required semantic review of the Pre-Analysis

4. Later analytical and record checks

5. Final use and future-inheritance review
```

Noting risk is not enough.

A case-pass record that marks person-nearness but still proceeds automatically has not preserved stop-capability.

A template that flags weak input but still produces a strong claim has not preserved stop-capability.

An AI system that identifies a false trigger but still routes to the add-on has not preserved stop-capability.

A review gate that records a rival account but cannot redirect the application has not preserved stop-capability.

An Iteration Handoff that notes boundary limits but passes findings forward as evidence has not preserved stop-capability.

A stop must be available when:

```text
the requested use is already inappropriate before analysis
input is too weak
claim strength exceeds input status
person-nearness crosses a protection boundary
affected persons cannot contest the reading
correctability is absent
add-on use would overdetermine the case
MIP or AHP lack their own gate
AI fluency launders uncertainty
a template ritualizes closure
a rival discriminates better
a guardrail would be violated
future work would inherit excessive authority
```

Stop-capability also requires timing.

A stop cue must appear before the output hardens into:

```text
publication
institutional use
technical implementation
automated routing
person-level judgment
article-level synthesis
follow-up reuse
```

A stop cue that arrives only after irreversible uptake may still matter, but it has failed as preventive discipline.

Stop-capability therefore has four requirements:

```text
1. The possible stop condition must be noticed.

2. It must reach a responsible review point.

3. The review point must be able to change or end the application.

4. The workflow must be able to prevent unauthorized continuation
   or inheritance.
```

In Full Review use, a stop signal produced by Pre-Analysis must be reviewed before Core. Until that review is complete, Core entry is not permitted.

If the review confirms the stop, no later step belongs to the current pass.

If the review conservatively corrects a false or inconsistent stop, the complete corrected Pre-Analysis becomes the effective artefact.

Where the review is deliberately skipped, an existing stop signal must not be treated as silently cleared.

Review omission cannot convert stop into proceed.

A stop cue matters only if it can reach a responsible decision point and change the application.

### 16.7 Who Stops?

Stop-capability is not satisfied by detecting a stop cue.

The primary responsibility begins with the analyst.

Before applying PMS, the analyst should determine whether the requested treatment is appropriate, whether PMS is the right frame, whether the intended output is admissible, and whether the likely use can remain bounded and correctable.

This does not make the analyst infallible.

It makes the point of responsibility visible before workflow momentum begins.

Where a problem is not recognized at that stage, a stop cue may later be identified by:

```text
an affected person
a rival account
a human reviewer
a template field
an AI-assisted check
a YAML routing rule
a threshold table
a review gate
a case-record inconsistency
an article check
an Iteration Handoff
```

But identifying the cue is not the same as establishing every substantive claim associated with it.

The cue must reach a responsible review point.

AI, templates, YAML routing, trigger maps, threshold tables, review gates, case records, and handoff artefacts may identify and structure possible stop conditions.

They may mark:

```text
weak input
person-nearness
false triggers
missing rivals
source-status problems
closure risk
correction failure
current-step confusion
future-inheritance risk
```

They may require attention and review.

They may not become tribunals, evidence authorities, or person-judgment authorities.

At the same time, a confirmed stop cannot remain merely advisory.

Once the required review confirms that the current case has reached a protection or entry boundary, the workflow must enforce non-continuation.

The correct relation is:

```text
The analyst should stop an inappropriate application
before Pre-Analysis where the problem is already clear.

Pre-Analysis formalizes the entry and protection review
where the application remains under consideration.

AI and artefacts may surface and structure stop conditions.

The required review determines the effective workflow status.

A confirmed stop prevents continuation of the current pass.

The human user remains responsible for accepting the stop,
correcting materially wrong input, redirecting the matter,
or beginning a genuinely new case.
```

The artefact does not become the moral or epistemic source of the stop.

Its role is to preserve and enforce the boundary already justified by the discipline.

Where PMS use becomes person-near, public, institutional, technical, automated, article-level, or follow-up-seeding, explicit human confirmation of the final analytical decision state and future-use boundary may be required.

Human confirmation is not a ritual signature.

It must identify:

```text
what was confirmed
what was refused
whether the pipeline stopped
what use remains permitted
what use remains prohibited
whether a new case is required
```

Human confirmation cannot:

```text
certify truth
turn weak input into strong input
override a confirmed protection stop
convert a prohibited output into a permitted one
continue the same stopped case under a renamed target
```

Humans can also overclaim, moralize, retaliate, ignore rivals, protect their own frame, or use follow-up as a way to preserve a weak reading.

Responsibility must therefore remain locatable and constrained.

The analyst is responsible not only for decisions to proceed, but also for decisions not to begin and not to continue.

### 16.8 Iteration Without Inheritance

Iteration is a disciplined form of continuation, not a continuation of authority.

A PMS-DISCIPLINE pass may end with a bounded indication that further work would be useful.

This is especially important where:

```text
correctability
follow-up cost
unresolved trajectory
new material needs
delayed effects
public uptake
distinct subcases
future reuse
```

create questions that the current boundary should not absorb.

But iteration must not alter the current case result.

It must not:

```text
create new findings
treat the current pass as evidence for a future case
inherit route decisions
inherit operator statuses
inherit add-on selection
inherit MIP or AHP status
inherit claim ceiling
inherit sufficiency status
inherit article wording
```

A disciplined Iteration Handoff may state:

```text
current sufficiency for the original intended use
iteration value
iteration urgency
possible follow-up question
required new material
future case boundary
context references
non-inheritance limits
```

The Iteration Handoff is prepared from the checked Case Record before optional article rendering.

Article prose, base drafts, generated examples, article profile choices, article checks, and drafting metadata must not generate or strengthen Iteration Handoff findings.

A later article may present a follow-up outlook already supported by the checked handoff. It may not become the source of that outlook.

The follow-up case begins again.

It may use the prior pass as bounded context or lineage. It may not use it as source authority, evidence, verdict, pipeline eligibility, or route shortcut.

If the future case needs PMS Core, add-on routing, MIP, AHP, rival pressure, refusal, or article synthesis, those must be established again under the future case boundary.

A follow-up case may also emerge from a redirect after a stopped case.

Such a redirect does not reopen or continue the stopped case. It identifies a possible new question, method, domain process, or case boundary.

Iteration matters because correctability does not end with current closure.

But iteration remains disciplined only when it preserves the difference between current closure and future inquiry.

### 16.9 Guiding Sentences

The responsible analyst should ask whether the application should begin before asking how it should proceed.

Openness is not one state.

A DISCIPLINE layer without stop-capability is decorative.

Close the claim operationally; keep the closure epistemically answerable.

A pipeline stop is not a seventh analytical decision state.

Follow-up is not reopening by itself.

A redirect after a protection stop is a new case, not a continuation.

Iteration is continuation under renewed boundary, not inheritance of current authority.

---

## 17. Self-Application, Failure Modes, and Limits

### 17.1 Self-Application Rule

PMS-DISCIPLINE is bound by the discipline it imposes.

This means that DISCIPLINE applies its own limits to itself. It remains scene-bound, claim-bound, correctable, rival-pressured, non-person-ranking, non-authoritative, non-final, and non-inheritable without renewed boundary. It does not escape its own requirements by naming them. It does not become exempt from correction because it is a discipline of correction.

This self-application is not merely a description of modesty. It is a constraint. PMS-DISCIPLINE may not treat its own routings, thresholds, review gates, output records, trigger maps, burden tables, templates, YAML interfaces, article checks, iteration handoffs, or workflow artefacts as final authority. These artefacts may support disciplined use, but they remain application aids. They must remain open to revision when failed use exposes misrouting, overclosure, underprotection, ritualization, unauthorized inheritance, or obstruction of correction.

The application discipline remains an application discipline. It does not become a meta-tribunal. It does not become a person-ranking scheme. It does not become a non-correctable guardrail system. It does not become a closure machine that protects PMS from critique by claiming to have already disciplined the use. It also does not become an iteration machine that keeps PMS authority alive through follow-up.

PMS-DISCIPLINE therefore cannot use its own existence as a defense against challenge. “DISCIPLINE was followed” is not enough if the pass misrouted the case, over-strengthened the claim, ignored a better rival, made affected persons less able to contest, treated a completed output record as final authority, or allowed a follow-up case to inherit more than the current pass could license.

DISCIPLINE does not escape its own correctability requirements.

### 17.2 Non-Immunization

Self-critique is not immunity.

A system can name its risks and still reproduce them. It can include warnings and still ignore them. It can contain a failure-mode map and still become a failure mode. It can say “correction before coherence” while protecting its own coherence. It can say “workflow is not authority” while allowing workflow completion to function as authority. It can say “iteration is not inheritance” while passing forward findings, route states, or claim ceilings as if they were inherited warrants.

The most dangerous self-protective sentence is:

```text id="yu6rp8"
DISCIPLINE already accounts for this.
```

This sentence is not a defense. A warning is not enough. A non-authority clause is not enough. A failure-mode list is not enough. A template field is not enough. A review gate is not enough. A YAML note is not enough. A handoff note is not enough. These features matter only if they can change conduct.

A self-critical system becomes immunizing when its warnings no longer change its conduct. If a stop cue is named but the application always proceeds, the cue is decorative. If a failure mode is listed but cannot force revision, downgrade, suspension, refusal, or redirection, the list is decorative. If a review gate records a problem but cannot alter the output, the gate is ritual. If an output record marks limits but still gets treated as final authority, the record has become part of the failure. If an iteration handoff marks non-inheritance but a future case inherits the current result as evidence, the handoff has become ceremonial.

DISCIPLINE must therefore be alterable by the failures it can describe. A warning that cannot change conduct has become decorative. Self-critique becomes immunizing when it protects the system from the critique it names.

### 17.3 Correctability of DISCIPLINE Itself

A discipline of correctability must itself be correctable by failed use.

PMS-DISCIPLINE may be challenged when it overconstrains, underprotects, misroutes, overcloses, ritualizes review, obstructs correction, authorizes inheritance, or protects PMS from criticism instead of exposing PMS use to correction. Its routing may be challenged. Its thresholds may be challenged. Its review gates may be challenged. Its trigger maps may be challenged. Its burden tables may be challenged. Its YAML interfaces may be challenged. Its output requirements may be challenged. Its iteration handoffs may be challenged.

This is especially important where DISCIPLINE itself becomes part of an artefact stack. A template may appear to enforce discipline while reducing contestability. A YAML interface may appear to preserve non-authority while guiding users toward premature closure. A threshold table may appear to protect against overuse while becoming a scoring mechanism. A final integration record may appear to preserve accountability while becoming the authority that no one can challenge. A handoff mechanism may appear to preserve iteration discipline while allowing prior outputs to travel forward with too much authority.

DISCIPLINE must be correctable where it causes affected persons to become less able to contest the reading. It must be correctable where it makes PMS outputs harder to challenge. It must be correctable where it burdens critics with excessive formality. It must be correctable where it overprotects PMS vocabulary, hides rival accounts, over-routes to add-ons, blocks necessary add-ons, treats “Core-only” as a way to avoid person-nearness burden, or treats “follow-up” as a way to avoid current downgrade, suspension, refusal, or redirection.

A challenge to DISCIPLINE should specify the case, the challenged step, the failure mode, the rival routing or weaker claim, and what correction would change. Where iteration is involved, the challenge should also specify whether the failure concerns current sufficiency, iteration value, iteration urgency, follow-up boundary, material inheritance, route inheritance, or claim inheritance.

The point is not to reject DISCIPLINE whenever it is uncomfortable. The point is to keep DISCIPLINE answerable to failed use.

The output record is not the final authority over the failure of the output record. If the record itself conceals what needs correction, the record must be correctable too.

### 17.4 Compressed Failure-Mode Map

The failure-mode map is a review and red-team aid. It is not a complete taxonomy, not a scoring system, and not proof of safety.

It helps inspect PMS-DISCIPLINE use by naming recurrent drift forms:

```text id="fw1di7"
operator over-assignment
operator omission
dependency order treated as hierarchy
local salience treated as authority
derived-axis reification
Dignity-in-Practice moralization
Ω (asymmetry) as accusation shortcut
Ψ (self-binding) as maturity verdict
Core bypass by add-on
add-on over-triggering
add-on non-use hidden
add-on as authority source
MIP treated as ordinary add-on
AHP triggered without checked MIP
AHP treated as MIP rescoring
operator-load confused with vocabulary
input-status laundering
model output treated as evidence
AI fluency treated as warrant
template completion treated as validation
case-pass record completion treated as closure
case-record chain treated as truth
current-step telemetry treated as case substance
YAML routing treated as governance
review gate treated as tribunal
handoff treated as Stage 4
iteration treated as inheritance
follow-up value treated as current insufficiency
current sufficiency treated as no future question possible
future case inheriting findings as evidence
future case inheriting route decisions as authority
future case inheriting claim ceiling or sufficiency status
article wording treated as source material
rival pressure treated as decoration
rival account assimilated too quickly into PMS
claim ladder escalation
bounded adequacy replaced by coherence
false stability treated as valid integration
person-nearness ignored
scene reading turned into person verdict
person-protection turned into idea-immunity
effect on persons made invisible
model status forgotten
complaint dismissed for lack of polished critique
complaint converted directly into verdict
critique treated as negativity
correction acknowledged without possible effect
stop cue detected without stopping power
human confirmation treated as ritual
DISCIPLINE used to protect PMS from critique
output record treated as final authority
workflow completion treated as adequacy
```

Naming these failure modes does not mean controlling them. A known risk is not a solved risk. A checklist of failure modes can itself become ritual if it is treated as completed safety work rather than as a pressure on the application.

The map must therefore remain revisable. Failed use may reveal new failure modes, sharper distinctions, missing risks, false positives, false negatives, or contexts in which the current discipline overconstrains or underprotects. Iterative use may reveal failures that are invisible in one pass: authority leakage across cases, source-status drift, route inheritance, article-to-case feedback, or follow-up pressure that destabilizes a bounded closure without cause.

The map is useful only if it remains open to failures it did not predict.

A failure-mode map is disciplined only when it can be changed by the failures it helps reveal.

### 17.5 Limits

PMS-DISCIPLINE remains disciplined by refusing guarantees it cannot provide.

It does not guarantee truth. It does not guarantee justice. It does not guarantee safety. It does not guarantee neutrality. It does not guarantee complete accountability. It does not guarantee proper use by hostile actors. It does not guarantee successful implementation. It does not guarantee complete prevention of misuse. It does not guarantee PMS superiority over rival systems. It does not guarantee that templates, YAML workflows, article checks, or iteration handoffs will be used responsibly.

These limits are not defensive weaknesses. They define the discipline’s honesty. PMS-DISCIPLINE would become undisciplined if it claimed to guarantee what no application discipline can guarantee. It can reduce overclaim, but it cannot abolish error. It can make misuse harder, but it cannot prevent all misuse. It can require rival pressure, but it cannot ensure that every rival will be recognized. It can require correctability, but it cannot guarantee that every institution, user, model, tool, or artefact stack will preserve it in practice.

Not guaranteeing safety is not a weakness if the document prevents safety claims it cannot support. Not guaranteeing neutrality is not a weakness if the document makes situated input, claim burden, person-nearness, and correctability visible. Not guaranteeing PMS superiority is not a weakness if the document preserves the possibility that a rival frame may currently discriminate better. Not guaranteeing clean iteration is not a weakness if the document prevents follow-up from becoming inherited authority.

PMS-DISCIPLINE does not make PMS immune to failure. It makes PMS use harder to overclaim, easier to inspect, easier to stop, and easier to continue only under renewed boundaries where continuation is justified.

### 17.6 What DISCIPLINE Can Require — and When It Is Enough

Non-authority does not mean no constraint.

PMS-DISCIPLINE cannot certify truth, but it can require weaker, clearer, more bounded, more correctable use. It can require clearer input status. It can require a lower claim type. It can require revision. It can require stronger rival pressure. It can require add-on restraint. It can require add-on non-use. It can require person-nearness caution. It can require template non-ritualization. It can require AI output to remain marked as model output. It can require correctability preservation. It can require that future work begin under a renewed boundary rather than inherit current authority.

It can require that a reading remain exploratory. It can require that a public claim become private. It can require that a person-near claim become scene-bound. It can require that an evaluation become a hypothesis. It can require that a recommendation become an orientation. It can require that an add-on be rejected as over-application. It can require that MIP or AHP not be used where their gates are unmet. It can require that a rival account redirect the case. It can require that a follow-up be framed as a question rather than as a continuation of findings.

PMS-DISCIPLINE can also require final decision states other than proceed:

```text id="exr6af"
revise
downgrade
suspend
refuse
redirect
```

But DISCIPLINE must not become an endless burden generator. A discipline of correctability also needs a rule for provisional sufficiency. Otherwise, the demand for further checking can itself become overconstraining, ritualized, or hostile to responsible use.

A PMS-DISCIPLINE pass may be treated as provisionally sufficient for the intended use when the following conditions are met:

```text id="provisional-sufficiency-conditions"
the case boundary is declared
the input status is marked
the intended use is explicit
the claim type is the lowest adequate claim type
the Core reading is visible
operator salience and possible omissions are marked
add-ons used, not used, or rejected are justified
MIP or AHP route states are marked where relevant
rival accounts have been considered
no rival currently discriminates better
person-nearness, publicness, irreversibility, automation, and institutional uptake have been checked where relevant
AI, template, YAML, model, workflow, or article involvement is marked where present
the output states what is not licensed
correctability and reopening conditions remain available
the final decision state is explicit
human confirmation is present where required
future-use and follow-up boundaries are marked where relevant
```

This sufficiency is not truth, safety, finality, or authority. It is sufficiency relative to the declared scene, input, use, claim type, risk, rival pressure, and correctability conditions. It means that no currently visible burden requires further revision, downgrade, suspension, refusal, or redirection before the output may proceed within its declared limits.

Proceed is therefore permitted only as bounded proceed. It does not mean that the case is exhausted. It means that the current record is adequate enough for this claim, under this input status, in this use context, with these limits and reopening conditions preserved.

This also matters for non-proceed outcomes. A downgraded, suspended, refused, or redirected application may also be provisionally sufficient if it correctly names the boundary reached. DISCIPLINE succeeds not by reaching proceed, but by reaching the decision state that the burden currently justifies.

The same applies to iteration. A pass may be sufficient for its current use and still mark a follow-up question. It may also be insufficient for its current use and require suspension, refusal, or redirection rather than follow-up. Follow-up is disciplined only where current sufficiency, iteration value, iteration urgency, and follow-up-case preparation remain distinct.

These constraints are not sovereignty. They do not certify the correct answer. They do not make PMS true. They do not authorize the case. They limit what PMS use may responsibly do under the available input, claim burden, use context, person-nearness, rival pressure, correctability conditions, and future-use boundaries.

DISCIPLINE has force as constraint, not as authority. It is provisionally sufficient when it has made the current use bounded, inspectable, correctable, stoppable, and non-inheritable enough for the claim it allows.

### 17.7 Closing Core

PMS-DISCIPLINE does not make PMS true.

PMS-DISCIPLINE does not make PMS safe.

PMS-DISCIPLINE does not make PMS complete.

PMS-DISCIPLINE does not make future work already licensed by current closure.

PMS-DISCIPLINE makes PMS use harder to overclaim, easier to inspect, easier to stop, and easier to continue only under renewed boundaries.

This is the positive closure of the document. PMS-DISCIPLINE does not strengthen PMS by turning it into authority. It strengthens the responsibility of PMS use by making its path, limits, risks, non-use, rival pressure, correction conditions, stopping points, and future-use boundaries visible.

It protects PMS from its own possible overuse not by insulating it from critique, but by making critique consequential. It protects users not by guaranteeing safety, but by refusing unsupported safety claims. It protects affected persons not by ending risk, but by making person-nearness, contestability, dignity-preservation, correction, and stop-capability harder to erase.

The document therefore closes without finalizing PMS, the case, the corpus, or future work. It closes by preserving the conditions under which PMS use can remain answerable.

### 17.8 Final Sentence

PMS-DISCIPLINE does not protect PMS by strengthening its authority; it protects PMS use by preserving its correctability, stop-capability, and boundedness across closure and iteration.

---

## A. PMS Operator Threshold Tables

### Function of Annex A

Annex A supports disciplined operator assignment. It helps the user ask whether a PMS operator is doing structural work in a case or merely appearing thematically nearby.

The purpose is not to prove the operator’s truth in the case. The purpose is to prevent operator labeling, symbolic decoration, all-operator coverage rituals, over-assignment, omission blindness, and claim hardening through PMS vocabulary.

For each operator, the table asks:

```text
When is activation justified?
When is activation not justified?
Where does ambiguity remain?
Where is overuse likely?
When should the claim be downgraded?
When should the application stop?
```

The general rule is:

> Operator thresholds discipline operator assignment; they do not prove the operator’s truth in the case.

Threshold met does not mean claim authorized. Operator assignment does not mean case validation. Operator salience does not mean claim authority.

In Annex A, a Stop Cue is an unreviewed escalation signal. It may require stopping or suspending an operator assignment, lowering the claim, or initiating protection review. It becomes a binding pipeline stop only when the applicable DISCIPLINE review confirms a controlling stop condition. Once confirmed, that stop has procedural precedence within the current pass.

### Δ — Difference

#### Activation Threshold

Δ is activated when a difference is structurally operative in the scene. The difference must matter for how the case becomes readable, how a path splits, how a claim is distinguished, or how a practical orientation changes.

Activation is justified when the reading would materially change if the difference were removed, ignored, collapsed, or treated as irrelevant.

Examples of activation include:

```text
a distinction that organizes competing interpretations
a difference between report and evidence
a difference between intended use and actual effect
a difference between Core sufficiency and add-on pressure
a difference between person, idea, effect, and model
a difference between operational closure and epistemic finality
```

#### Non-Activation Condition

Δ is not activated merely because two things are verbally, conceptually, or descriptively different. Ordinary variation, stylistic contrast, semantic difference, or incidental distinction is not enough.

A difference that does not alter the reading, claim burden, routing, responsibility, or correction path should not be treated as structurally operative.

#### Ambiguity Marker

Mark ambiguity where it is unclear whether the difference is structural or merely descriptive.

Useful ambiguity markers include:

```text
difference may matter, but current input does not show how
difference appears relevant only under a stronger claim
difference may be an artefact of framing
difference may be introduced by the model or template
difference may disappear under rival account
```

#### Common Overuse

Common overuse occurs when every distinction is treated as Δ, or when PMS vocabulary turns ordinary differentiation into structural depth.

Typical overuse forms:

```text
semantic distinction treated as structural split
stylistic variation treated as practical divergence
minor contrast treated as routing threshold
difference inflated into asymmetry
difference used to justify add-on scan too early
```

#### Downgrade Cue

Downgrade when Δ appears plausible but the input does not support a stronger claim about its structural role.

Examples:

```text
from evaluation to orientation
from explanation to hypothesis
from add-on trigger to Core-only note
from public claim to internal reading
```

#### Stop Cue

Stop or suspend operator assignment when the alleged difference depends on unmarked input-status confusion, model-generated contrast, hidden interpretation, or a frame that has not been justified.

Stop is especially required if Δ is being used to support a person-near, public, institutional, technical, or automated claim without sufficient input grounding.

---

### ∇ — Impulse

#### Activation Threshold

∇ is activated when a movement, pressure, drive, tendency, or practical push is structurally operative in the scene. The impulse must matter for how action, orientation, escalation, avoidance, correction, or closure becomes readable.

Activation is justified when the reading would materially change if the movement or pressure were absent.

Examples of activation include:

```text
a push toward premature closure
a pressure to escalate from reading to claim
a tendency to over-trigger an add-on
a drive toward template completion
a movement from complaint to verdict
a pressure to protect coherence from correction
```

#### Non-Activation Condition

∇ is not activated merely because someone acts, feels, wants, reacts, or expresses preference. Not every emotion, intention, decision, or movement is structurally operative impulse.

A movement that does not organize the case, change the claim burden, or affect the application path should remain descriptive rather than operator-active.

#### Ambiguity Marker

Mark ambiguity where impulse may be present but the source, direction, or structural force of the movement remains unclear.

Useful ambiguity markers include:

```text
movement visible, but not yet structurally load-bearing
pressure may come from institution, person, model, template, or publicness
impulse inferred from action but not supported by input
impulse may be imposed by interpreter framing
movement may be better explained by rival account
```

#### Common Overuse

Common overuse occurs when ∇ becomes motive reading. This is especially risky in person-near contexts.

Typical overuse forms:

```text
action treated as inner drive
response treated as motive
complaint treated as aggression
hesitation treated as avoidance
critique treated as destructive impulse
AI/template momentum treated as neutral workflow
```

#### Downgrade Cue

Downgrade when impulse is plausible but cannot be separated from interpretation, projection, weak input, or person-bound drift.

Examples:

```text
from motive claim to scene-bound pressure
from person claim to action-pattern note
from explanation to hypothesis
from judgment to orientation
```

#### Stop Cue

Stop or refuse impulse assignment when ∇ is being used to infer motive, maturity, blame, bad faith, pathology, or identity without sufficient burden.

Stop is required where impulse language becomes person capture.

### □ — Frame

#### Activation Threshold

□ is activated when the frame through which the case becomes readable is structurally operative. The frame must shape what counts as relevant, what appears as difference, what impulse means, what counts as correction, what closure seems possible, or which claims become available.

Activation is justified when changing the frame would materially change the reading.

Examples of activation include:

```text
a complaint read as signal rather than verdict
a template read as artefact rather than validation
AI output read as model output rather than evidence
closure read as operational rather than epistemic
person-protection distinguished from idea-immunity
```

#### Non-Activation Condition

□ is not activated merely because a context, background, category, or container can be named. Frame is not a label around the case. It must help determine praxeological readability.

A frame that does not alter the interpretation, burden, routing, or correctability of the case should not be treated as structurally active.

#### Ambiguity Marker

Mark ambiguity where the frame may be operative but not yet separable from the interpreter’s assumption.

Useful ambiguity markers include:

```text
frame may be imposed rather than discovered
rival framing may currently discriminate better
frame determines what counts as evidence
frame may naturalize one party’s perspective
frame may be produced by template or institutional form
```

#### Common Overuse

Common overuse occurs when □ becomes a post-hoc container or explanatory shield.

Typical overuse forms:

```text
frame used to excuse weak input
frame used to rewrite factual sequence
frame used to protect one interpretation from rival pressure
frame treated as reality rather than readability condition
frame used to naturalize institutional perspective
```

#### Downgrade Cue

Downgrade when frame-dependence is high but not sufficiently marked.

Examples:

```text
from explanation to frame-bound reading
from claim to hypothesis
from person judgment to scene-bound interpretation
from closure to supported-but-limited status
```

#### Stop Cue

Stop or suspend when the frame itself is contested, hidden, or likely to determine the outcome before rival pressure, input status, or correctability have been checked.

Stop is required if □ is used to convert retroactive legibility into retroactive causation.

Core distinction:

> Retroactive legibility is not retroactive causation.

### Λ — Non-Event

#### Activation Threshold

Λ is activated when what did not happen, was withheld, failed to appear, remained unsaid, remained unintegrated, or was structurally absent affects the reading.

Activation is justified when the non-event changes the application path, claim burden, responsibility distribution, correction possibility, or closure status.

Examples of activation include:

```text
missing evidence that limits claim strength
unavailable correction path
unmarked add-on non-use
unheard complaint
unprovided reason
closure without reopening condition
template field filled despite missing input
```

#### Non-Activation Condition

Λ is not activated merely because something is absent in an ordinary sense. Not every silence, gap, omission, or missing detail is structurally significant.

A missing element that does not materially alter the reading, burden, or decision state should not be elevated to Λ.

#### Ambiguity Marker

Mark ambiguity where absence may matter but its structural role is unclear.

Useful ambiguity markers include:

```text
absence may be meaningful or incidental
silence may reflect lack of input rather than refusal
missing material may be unavailable, withheld, irrelevant, or model-erased
non-event may become relevant only under stronger claim
rival account may explain the absence differently
```

#### Common Overuse

Common overuse occurs when all absence becomes Λ.

Typical overuse forms:

```text
ordinary silence treated as refusal
missing evidence treated as hidden evidence
lack of response treated as guilt or incapacity
non-use treated as failure rather than discipline
unresolved status treated as suppressed truth
```

#### Downgrade Cue

Downgrade when Λ is plausible but the absence cannot yet support a strong interpretation.

Examples:

```text
from claim to question
from explanation to unresolved status
from person judgment to missing-input marker
from add-on use to add-on scan only
```

#### Stop Cue

Stop or suspend where a claim depends on absence as if absence were evidence.

Stop is especially required when Λ is used to support blame, motive, maturity judgment, person-level attribution, or closure without sufficient input.

### Α — Attractor

#### Activation Threshold

Α is activated when a pattern, outcome, frame, role, closure, interpretation, or practical direction exerts organizing pull within the scene. The attractor must shape how action, interpretation, repetition, expectation, or decision tends to gather.

Activation is justified when the case is not merely moving, but being drawn toward a recurring or stabilizing orientation.

Examples of activation include:

```text
workflow completion pulling toward closure
template form pulling toward apparent adequacy
AI fluency pulling toward confidence
institutional convenience pulling toward stable falsehood
person-near interpretation pulling toward verdict
add-on specificity pulling toward overdetermination
```

#### Non-Activation Condition

Α is not activated merely because something is preferred, repeated, familiar, or likely. Preference, habit, recurrence, or tendency is not enough unless it organizes the practical field.

An attractor must do structural work. It must shape the path of interpretation, action, closure, or correction.

#### Ambiguity Marker

Mark ambiguity where the pull is visible but its source or force is unclear.

Useful ambiguity markers include:

```text
attractor may be personal, institutional, technical, rhetorical, or model-generated
pattern may be repetition without organizing pull
apparent stability may be false stability
attractor may be produced by template design
rival account may identify a different attractor
```

#### Common Overuse

Common overuse occurs when Α is assigned to any repeated or attractive pattern.

Typical overuse forms:

```text
recurrence treated as structural pull
preference treated as attractor
recognition treated as stability
coherence treated as inevitability
institutional habit treated as validity
```

#### Downgrade Cue

Downgrade when an attractor appears plausible but its structural force has not been shown.

Examples:

```text
from explanation to pattern note
from stable structure to possible attractor
from final claim to supported-but-limited reading
from person-level claim to scene-bound tendency
```

#### Stop Cue

Stop or suspend where Α is being used to make a pattern appear inevitable, natural, validated, or immune to correction.

Stop is required when attractor language protects false stability, institutional convenience, person capture, or premature closure.

### Ω — Asymmetry

#### Activation Threshold

Ω is activated when an asymmetry is structurally operative in the scene. The asymmetry must affect burden, exposure, power, access, correction, responsibility, cost, risk, or interpretive position.

Activation is justified when the reading would materially change if the asymmetry were ignored.

Examples of activation include:

```text id="mg5j2w"
one party bears more cost than another
one party can define the frame more easily than another
one party has less access to correction
one claim exposes affected persons more than the claimant
AI or institutional systems amplify one reading over rivals
a template protects the stronger actor by procedural form
```

#### Non-Activation Condition

Ω is not activated merely because a situation feels unfair, unequal, uncomfortable, or conflictual. Ordinary difference, disagreement, or disadvantage is not enough unless the asymmetry structures the case.

An asymmetry must do structural work. It must shape the practical field, not merely name moral discomfort.

#### Ambiguity Marker

Mark ambiguity where asymmetry may be present but its structure, direction, or burden remains unclear.

Useful ambiguity markers include:

```text id="nqj4r1"
asymmetry may be present, but current input does not show who bears which cost
asymmetry may be institutional rather than interpersonal
asymmetry may be produced by publicness, automation, or template mediation
asymmetry may be reversed under rival frame
asymmetry may be moralized too quickly
```

#### Common Overuse

Common overuse occurs when Ω becomes an accusation shortcut.

Typical overuse forms:

```text id="q8sj6x"
difference treated as oppression
disagreement treated as domination
complaint treated as proof of asymmetry
status difference treated as sufficient explanation
asymmetry used to assign blame without claim burden
Ω used to protect one frame from correction
```

#### Downgrade Cue

Downgrade when asymmetry is plausible but not sufficiently specified.

Examples:

```text id="rgac1z"
from accusation to burden marker
from blame claim to asymmetry hypothesis
from evaluation to scene-bound observation
from person claim to structural-risk note
```

#### Stop Cue

Stop or suspend where Ω is being used to assign blame, motive, dignity failure, maturity failure, or person-level responsibility without sufficient input and rival pressure.

Stop is required when asymmetry language becomes accusation without distance, correction, or proportionality.

### Θ — Temporality

#### Activation Threshold

Θ is activated when timing, sequence, delay, repetition, anticipation, duration, after-effect, or temporal burden is structurally operative in the scene.

Activation is justified when the reading would materially change if time-order, delay, recurrence, or temporal pressure were removed.

Examples of activation include:

```text id="uwfttr"
a claim changes burden because it becomes public later
correction arrives after institutional uptake
a falsehood creates follow-up cost over time
a complaint becomes intelligible only after repeated non-response
premature closure occurs before rival pressure
AI or template speed accelerates closure
```

#### Non-Activation Condition

Θ is not activated merely because events happen in time. Chronology alone is not temporality in the PMS sense.

A temporal marker must affect readability, burden, action, correction, closure, or responsibility.

#### Ambiguity Marker

Mark ambiguity where time appears relevant but the temporal structure is not yet clear.

Useful ambiguity markers include:

```text id="ed6cl9"
sequence is known but structural timing is unclear
delay may be incidental or burden-producing
repetition may be meaningful or merely recurrent
future reference may not trigger ANTICIPATION
late correction may or may not change responsibility
```

#### Common Overuse

Common overuse occurs when every sequence, future reference, or repeated event becomes Θ-heavy.

Typical overuse forms:

```text id="b0fn6l"
chronology treated as temporal burden
future mention treated as ANTICIPATION
repetition treated as proof of pattern
delay treated as refusal
late response treated as bad faith
time pressure used to justify premature closure
```

#### Downgrade Cue

Downgrade when temporality is relevant but cannot yet support a strong claim.

Examples:

```text id="el1puu"
from temporal explanation to timing note
from pattern claim to recurrence hypothesis
from intervention to suspension
from closure to supported-but-limited status
```

#### Stop Cue

Stop or suspend where temporal pressure is being used to bypass input status, rival pressure, human confirmation, person-nearness caution, or correctability.

Stop is required when urgency becomes a reason to treat closure as authority.

### Φ — Recontextualization

#### Activation Threshold

Φ is activated when a scene, claim, event, role, output, or artefact changes meaning by being moved into another context.

Activation is justified when the reading would materially change because the material is taken up elsewhere, reframed, quoted, systematized, publicized, institutionalized, technically embedded, or interpreted under a new use condition.

Examples of activation include:

```text id="x2r2yb"
private reading becomes public claim
exploratory note becomes institutional record
AI summary becomes apparent source
template field becomes administrative warrant
PMS vocabulary moves from scene reading to person judgment
case-pass record becomes evidence of adequacy
```

#### Non-Activation Condition

Φ is not activated merely because a statement is repeated or explained differently. Rewording, paraphrase, or ordinary contextual reference is not enough.

Recontextualization must change the practical meaning, burden, use, exposure, authority appearance, or correction conditions of the material.

#### Ambiguity Marker

Mark ambiguity where it is unclear whether a change of context has changed the burden of the claim.

Useful ambiguity markers include:

```text id="jwkxx3"
material may have moved from private to public use
output may be read with more authority than intended
model-generated text may be detached from its source status
template field may alter institutional uptake
same wording may carry different burden in new context
```

#### Common Overuse

Common overuse occurs when any restatement or interpretation is treated as Φ.

Typical overuse forms:

```text id="49lze0"
paraphrase treated as structural recontextualization
ordinary explanation treated as frame shift
quotation treated as institutional uptake
translation treated as burden change without evidence
recontextualization used to avoid checking original input
```

#### Downgrade Cue

Downgrade when a context shift is plausible but the new use burden is not fully established.

Examples:

```text id="hefp1u"
from public claim to private orientation
from institutional implication to uptake risk
from explanation to recontextualization hypothesis
from person-near claim to scene-bound caution
```

#### Stop Cue

Stop or suspend where recontextualization creates a stronger claim, wider exposure, person-near effect, institutional uptake, technical embedding, or automation risk without renewed discipline.

Stop is required when a reading changes use context but keeps the lower burden of its original context.

### Χ — Distance

#### Activation Threshold

Χ is activated when distance, mediation, detachment, perspective gap, interpretive distance, role distance, temporal distance, technical distance, or model distance affects the reading.

Activation is justified when the reading would materially change if the distance between interpreter, case, person, source, model, institution, or output were reduced or increased.

Examples of activation include:

```text id="fz2aur"
AI output distances the reader from source weakness
public synthesis distances the claim from affected persons
template mediation distances responsibility from judgment
operator language distances the reader from person-nearness
technical implementation distances decision from contestability
historical delay changes access to correction
```

#### Non-Activation Condition

Χ is not activated merely because the interpreter is not identical with the case or because some mediation exists. All interpretation has some distance.

Distance becomes operator-active only when it changes claim burden, responsibility, correction access, person-nearness, publicness, or use risk.

#### Ambiguity Marker

Mark ambiguity where distance may be protective, distorting, necessary, or evasive.

Useful ambiguity markers include:

```text id="fqpr6m"
distance may preserve caution or hide responsibility
technical mediation may improve inspection or reduce contestability
model distance may reduce visible person-capture or intensify it
public distance may make affected correction harder
rival account may interpret the distance differently
```

#### Common Overuse

Common overuse occurs when distance becomes either automatic objectivity or automatic alienation.

Typical overuse forms:

```text id="fo1jgo"
AI distance treated as neutrality
technical distance treated as safety
formal language treated as objectivity
critical distance treated as superiority
distance from affected persons treated as reduced burden
Χ used to avoid person-nearness responsibility
```

#### Downgrade Cue

Downgrade when distance affects the reading but its direction or consequence is unclear.

Examples:

```text id="f8z2ph"
from confident claim to mediated reading
from public synthesis to bounded reconstruction
from person claim to model-distance warning
from technical recommendation to audit question
```

#### Stop Cue

Stop or suspend where distance hides responsibility, blocks affected contestation, launders model output, or makes person-near effects harder to correct.

Stop is required when distance creates the appearance of neutrality while reducing answerability.

### Σ — Integration

#### Activation Threshold

Σ is activated when integration, non-integration, partial integration, forced integration, or failed integration is structurally operative in the scene.

Activation is justified when the reading would materially change depending on whether elements are brought together, held apart, reconciled, synthesized, refused, or left unresolved.

Examples of activation include:

```text id="wvnlr1"
rival accounts cannot yet be integrated
template completion forces unresolved material into completed fields
falsehood remains practically integrated after factual rejection
Core and add-on readings require bounded integration
complaint and critique must be related without collapse
closure integrates reasons only within scope
```

#### Non-Activation Condition

Σ is not activated merely because elements are combined, summarized, listed, or made coherent. Synthesis is not automatically disciplined integration.

Integration must affect the structure of the case, claim, closure, rival pressure, or correctability.

#### Ambiguity Marker

Mark ambiguity where integration may be valid, premature, forced, partial, or impossible under current burden.

Useful ambiguity markers include:

```text id="zw6szl"
integration may hide unresolved risk
coherence may be produced by weak input synthesis
rival account may not be integrable without distortion
template integration may conceal missing evidence
non-integration may be disciplined rather than failure
```

#### Common Overuse

Common overuse occurs when Σ becomes a coherence demand.

Typical overuse forms:

```text id="8k4bm7"
everything forced into one PMS reading
rival account absorbed too quickly
complaint converted into critique without remainder
falsehood integrated as practical usefulness
template completion treated as integration
coherence treated as adequacy
```

#### Downgrade Cue

Downgrade when integration is possible but not fully justified.

Examples:

```text id="uxqoqs"
from integration to relation note
from explanation to partial reconstruction
from closure to supported-but-limited status
from proceed to revise or suspend
```

#### Stop Cue

Stop or suspend where integration suppresses rival pressure, hides missing input, erases affected persons, protects coherence against correction, or makes unresolved material appear settled.

Stop is required when integration becomes closure without answerability.

### Ψ — Self-Binding

#### Activation Threshold

Ψ is activated when a person, group, institution, system, workflow, claim, or artefact becomes bound to a practical commitment, identity, route, decision, standard, or closure in a way that shapes future action or correction.

Activation is justified when the reading would materially change if the binding were absent, weaker, reversible, or contested.

Examples of activation include:

```text id="cdf94q"
a final decision state binds permitted next steps
an institution becomes committed to a case-pass record
a public claim binds reputation or future correction
a template workflow binds the user to proceed
a PMS reading binds itself against rival pressure
DISCIPLINE binds itself to its own correctability requirements
```

#### Non-Activation Condition

Ψ is not activated merely because someone believes, chooses, agrees, commits, or has a stable preference. Not every commitment is structurally operative self-binding.

Self-binding requires a practical binding effect on action, claim, identity, route, correction, or future closure.

#### Ambiguity Marker

Mark ambiguity where binding may be present but its scope, reversibility, or responsibility remains unclear.

Useful ambiguity markers include:

```text id="wu1xot"
commitment may be explicit or inferred
binding may be institutional rather than personal
binding may be reversible but treated as final
workflow may bind through form rather than decision
self-binding may be confused with maturity or dignity
```

#### Common Overuse

Common overuse occurs when Ψ becomes a maturity verdict.

Typical overuse forms:

```text id="ubagex"
commitment treated as maturity
failure to integrate treated as immaturity
revision treated as lack of self-binding
person-level judgment inferred from local inconsistency
Ψ used to rank persons
self-binding treated as final authority
```

#### Downgrade Cue

Downgrade when self-binding is plausible but its scope or burden is not established.

Examples:

```text id="j4mrli"
from maturity claim to local commitment marker
from person judgment to scene-bound binding
from finality claim to provisional closure
from proceed to revise or downgrade
```

#### Stop Cue

Stop or refuse where Ψ is being used to rank persons, diagnose maturity, certify responsibility, close correction, or treat self-binding as person-level authority.

Stop is required when self-binding language becomes maturity verdict, dignity ranking, or closure immunity.

### Short Annex A Check

Annex A is an assignment aid. It does not prove that an operator is truly present in a case. It does not validate the case. It does not authorize a claim. It does not require all operators to be used.

A disciplined PMS application may assign few operators, many operators, or remain uncertain about operator assignment. What matters is whether the assignments are justified by structural work, whether possible omissions are marked, whether overuse is avoided, and whether the final claim remains within its burden.

The most important Annex A protections are:

```text id="jo5vqk"
operator threshold ≠ truth proof
operator assignment ≠ case validation
operator salience ≠ claim authority
operator omission ≠ automatic failure
all-operator coverage ≠ adequacy
operator vocabulary ≠ structural work
```

Annex A should therefore be used to slow operator assignment, not to decorate PMS readings with more operators.

If an operator threshold is unclear, the disciplined result may be lower claim strength, Core-only use, add-on non-use, revision, downgrade, suspension, refusal, or redirection. The table supports judgment; it does not replace judgment.

---

## B. Application Discipline Threshold Table

### Function of Annex B

Annex B tests the discipline of PMS use. It does not test whether PMS is true, whether the case is validated, or whether the reading is finally adequate. It asks whether the application path has been sufficiently bounded for the claim it is being asked to carry.

Application thresholds test the discipline of use, not the truth of the PMS reading.

A threshold table may justify use, downgrade use, suspend use, refuse use, or redirect use. It does not certify truth. It does not authorize a claim by itself. It does not replace rival pressure, person-nearness caution, human responsibility, or correctability.

The table should be read under the following rule:

```text id="35f75j"
sufficiently supported
≠
true

insufficiently supported
≠
irrelevant

threshold met
≠
claim certified

threshold failed
≠
case understood

stop cue
≠
automatic decision
```

In Annex B, `stop cue` retains the meaning of an unreviewed escalation signal. It does not itself select a final analytical decision state or establish a pipeline stop. If the applicable DISCIPLINE review confirms a controlling stop condition, the result must be recorded separately as:

```text
pipeline-case disposition: stop
```

That confirmed pipeline stop prevents continuation of the current pass and has precedence over any inconsistent `proceed` signal. It remains distinct from the six final analytical decision states.

The purpose of the table is to make application burdens visible before the PMS output hardens into claim, publication, implementation, or decision.

### Application Discipline Threshold Table

| Discipline Dimension          | Sufficiently Supported                                                                                                                                                                                                                                                                   | Insufficiently Supported                                                                                                                                                 | Failure Mode                                                                                                                                  | Correction Requirement                                                                                                                                                                             | Stop Cue                                                                                                                                                              |
| ----------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Input-status discipline       | The output marks what kind of input is being used: trace, report, memory, interpretation, institutional record, fictional case, synthetic case, prior analysis, model output, or mixed material. Mixed input remains visibly mixed.                                                      | Input is treated as generic “data” or “material.” Model output, report, interpretation, and evidence are flattened. Source weakness is hidden by fluent PMS structure.   | Input-status laundering. PMS organization makes weak or mixed input appear stronger than it is.                                               | Mark input type, source limits, uncertainty, and unsupported claims. Lower the claim type if input cannot carry the intended burden.                                                               | Strong claim depends on unmarked weak input, model output treated as evidence, or mixed input flattened into factual authority.                                       |
| Claim-type discipline         | The claim type is explicit and is the lowest adequate claim type for the intended use. The output distinguishes orientation, sketch, hypothesis, bounded reconstruction, evaluation, recommendation, intervention, technical implementation, institutional uptake, and public synthesis. | Claim strength is inferred from fluency, coherence, PMS vocabulary, template completion, or add-on use. The output climbs the claim ladder without burden review.        | Claim escalation. A low-burden reading silently becomes explanation, evaluation, recommendation, or intervention.                             | Restate the claim type. Lower the claim to the level supported by input, rival pressure, person-nearness, and correctability.                                                                      | The intended output is person-affecting, public, institutional, technical, automated, or article-level while claim burden remains unmarked or unsupported.            |
| Person-nearness discipline    | Person-nearness is checked where the reading approaches identity, motive, maturity, dignity, sexuality, intimacy, pathology, credibility, responsibility, blame, competence, authority, reputation, employment, legal status, social standing, or institutional access.                  | The reading moves from scene structure to person-level implication without marking the burden. Person, idea, effect, and model are collapsed.                            | Person capture. A scene-bound PMS reading becomes a person verdict, maturity ranking, dignity judgment, blame claim, or reputational label.   | Weaken the claim, bind it to the scene, mark affected persons, preserve dignity, add rival pressure, require contestability, or redirect to domain-specific review.                                | PMS use would issue or support a person-level verdict without sufficient input, rival pressure, domain burden, dignity preservation, and correctability.              |
| Rival-pressure discipline     | Rival accounts are considered before final decision. The output marks whether a rival currently discriminates better, remains unresolved, or has been tested and rejected.                                                                                                               | Rival pressure is absent, decorative, assimilated too quickly into PMS terms, or considered only after closure.                                                          | PMS overfit. PMS coherence protects itself by absorbing or ignoring better rival explanations.                                                | Add rival review. Downgrade, suspend, refuse, or redirect if a rival account currently carries the burden better.                                                                                  | A rival account discriminates better, but the PMS application proceeds anyway or translates the rival into PMS vocabulary to preserve the reading.                    |
| Correctability discipline     | Correction can still affect the reading or application. Reasons are inspectable, response space is non-retaliatory where affected persons must contest, reopening conditions are visible, and the final decision state can change.                                                       | Correction is acknowledged but cannot alter the output. Review language exists, but no actual revision, downgrade, suspension, refusal, or redirection remains possible. | Decorative correctability. Critique is heard but has no possible effect. Coherence, template completion, or workflow status becomes immunity. | Restore access to reasons, reopening conditions, response space, and actual possible effect. Revise the output record if correction cannot currently change anything.                              | A correction channel exists only symbolically, affected persons cannot contest, or closure is protected against demonstrated error.                                   |
| AI / template-risk discipline | AI, template, YAML, or model involvement is marked. The output distinguishes assistance from authority. Template completion, trigger maps, threshold tables, review gates, and model outputs remain aids.                                                                                | AI fluency, filled templates, YAML routing, review gates, or threshold tables are treated as warrant, decision engine, validator, or closure mechanism.                  | Artefact authority. Workflow surface substitutes for judgment. AI or template mediation accelerates closure while appearing disciplined.      | Mark model-generated material, source transformation, template limits, non-use, failed fields, human confirmation, and final decision state. Reopen if artefact completion hid missing discipline. | AI or template output produces person-near, public, institutional, technical, automated, or article-level use without explicit human confirmation and correctability. |

### Annex B Decision Guidance

Annex B should be used before the final decision state is confirmed.

If all relevant dimensions are sufficiently supported, the application may still only proceed within declared limits. “Sufficiently supported” does not mean true, complete, safe, final, or authoritative. It means that no currently visible discipline burden requires revision, downgrade, suspension, refusal, or redirection before the output is used within its declared scope.

If one dimension is insufficiently supported, the application must not simply proceed by compensating with strength elsewhere. A strong Core reading does not compensate for weak input-status discipline. A careful template does not compensate for missing rival pressure. Human confirmation does not compensate for absent correctability. AI fluency does not compensate for claim escalation.

The disciplined result may be:

```text id="4t4ydv"
proceed within limits
revise the pass
downgrade the claim
suspend until threshold is resolved
refuse the use
redirect to a rival or domain-specific frame
```

Application thresholds do not certify use. They make the burden of use inspectable.

## C. Claim Type and Closure Status Table

### Function of Annex C

Annex C connects claim strength, input burden, person-nearness, publicness, closure status, reopening conditions, and pipeline stop-capability.

A claim is not disciplined until its claim type, closure status, and reopening conditions are visible. Claim strength cannot be decided in isolation. The stronger the claim, the more explicit its input burden, source burden, person-nearness burden, publicness burden, closure status, and reopening conditions must become.

Claim strength, input burden, intended use, protection boundaries, and closure status must be read together.

The table prevents the following drift:

```text
orientation treated as explanation
hypothesis treated as recommendation
case reading treated as intervention
weak input supporting strong claim
public claim treated as private analysis
person-near burden treated as permission
prohibited person judgment treated as merely high burden
closure without reopening conditions
combined reopening reasons stored as one undefined category
```

Annex C distinguishes two questions that must not be collapsed:

```text
How much burden does a permitted claim require?

Is the requested output type permitted at all?
```

A person-near claim may require heightened burden. A prohibited person-level output may instead require refusal and a pipeline stop before Core. More input does not automatically make every requested output admissible.

### Claim Type and Closure Status Table

| Claim Type | Minimum Input Burden | Person-Nearness and Protection Boundary | Publicness Burden | Typical Closure Status | Reopening Categories |
| --- | --- | --- | --- | --- | --- |
| **Orientation** | May rely on limited, mixed, exploratory, or model-assisted material if clearly marked. Suitable for first-pass scene orientation. | Must remain scene-bound. It must not determine motive, character, maturity, dignity, credibility, competence, pathology, blameworthiness, or the whole person. A request for such an output is not repaired by calling it orientation. | Should remain private or low-circulation unless limits and non-authorization of stronger use are explicit. | Untested / underdescribed, genuinely unresolved, or supported but limited. | `new evidence`, `scope change`, `demonstrated error`, `stronger rival`, or `other`, each recorded separately. |
| **Structural sketch** | Requires enough input to show why selected PMS relations are structurally relevant. Does not require full evidentiary support. | Must not move from a scene pattern to motive, identity, maturity, dignity, credibility, competence, pathology, or blame. An unsupported person-level output requires refusal or stop rather than a more elaborate sketch. | Public use requires visible source limits and explicit non-authorization of stronger claims. | Supported but limited, or untested / underdescribed where operator support remains weak. | Use atomic categories. Omitted operators or changed use may require `scope change`, `demonstrated error`, `stronger rival`, or `other`. |
| **Hypothesis** | Requires marked input, stated uncertainty, a plausible input-to-claim relation, and a possible path of weakening or disconfirmation. | Person-near hypotheses require stronger caution, contestability, and dignity preservation. Hypothesis language must not conceal a requested whole-person, diagnostic, forensic, maturity, credibility, or competence judgment. | A public hypothesis must not be presented as a finding, diagnosis, evaluation, recommendation, or institutional basis. | Genuinely unresolved or supported but limited. | Typically `new evidence`, `stronger rival`, `scope change`, or `other`; multiple grounds remain separate. |
| **Bounded reconstruction** | Requires enough input to reconstruct a scene, sequence, claim path, or application path within declared limits. Must distinguish fact, report, interpretation, and model output. | If persons are involved, reconstruction must remain scene-bound and must not become a person profile. A reconstruction of events is not authority to infer total motive, character, or maturity. | Public reconstruction requires visible source limits, rival pressure, affected-person contestability, and correction conditions. | Supported but limited. | Source correction may be `new evidence` or `demonstrated error`; changed case boundary is `scope change`; affected-person burden may be `other`. |
| **Evaluation** | Requires stronger input support, an explicit standard, rival pressure, and effective correctability. It must show what is being evaluated and by what burden. | A scene, claim, process, decision, artefact, or bounded role performance may be evaluated where the source and use burden permit. Unsupported whole-person evaluation, maturity ranking, dignity ranking, credibility ranking, competence verdict, pathology, or stable blameworthiness is prohibited and may require refusal plus pipeline stop. | Public or institutional evaluation requires heightened input discipline, response space, non-retaliatory contestability, and reopening conditions. | Supported but limited only where burden is met; otherwise downgrade, suspend, refuse, or redirect. | Use one or more atomic conditions: `new evidence`, `scope change`, `demonstrated error`, `stronger rival`, `other`. |
| **Recommendation** | Requires evaluation-level support plus practical consequence analysis. Must show why the recommendation follows and what limits apply. | Person-affecting recommendations require strong contestability, dignity preservation, human responsibility, and a non-totalizing object of recommendation. A recommendation based on prohibited person classification must be refused or redirected. | Public or institutional recommendation requires explicit limits, rival pressure, stop-capability, and responsible confirmation. | Operationally closed within scope only where reasons remain inspectable. | Changed consequence assumptions may be `new evidence`, `scope change`, or `other`; an analytical defect is `demonstrated error`; a better recommendation frame is `stronger rival`. |
| **Intervention** | Requires high input burden, domain relevance, risk review, affected-person contestability, and clear correctability. PMS alone is not sufficient where domain standards govern. | High burden. Must avoid person capture, non-delegable judgment, irreversible labeling, and disguised diagnosis. Prohibited person-level intervention criteria require refusal or domain redirection. | Public, institutional, technical, or person-affecting intervention requires explicit human responsibility and domain-appropriate review. | Operationally closed within tightly declared scope; often suspend, refuse, or redirect if burden cannot be met. | Each reopening ground must use one canonical category. Domain findings or harm signals may be `new evidence` or `other`; procedural defects may be `demonstrated error`. |
| **Technical implementation** | Requires precise input status, explicit claim limits, technical auditability, human responsibility, and distinction between analysis and system behavior. | Person-affecting technical implementation raises severe burden, especially if automated or difficult to contest. Automated whole-person, maturity, credibility, competence, dignity, pathology, or blame classification is not merely high burden; it is a protection-boundary problem requiring refusal or redirection. | Public or deployed systems require transparency, non-authority marking, stop-capability, auditability, and correction paths. | Operational closure only. Never epistemic finality. | Technical failure may be `demonstrated error`; changed deployment is `scope change`; audit findings may be `new evidence`; a better method may be `stronger rival`. |
| **Institutional uptake** | Requires strong input grounding, documented reasons, rival pressure, person-nearness review, role clarity, and non-retaliatory contestability. | High burden where reputation, access, employment, education, care, legal status, or institutional standing may be affected. Unsupported person classification must be refused or redirected rather than treated as a higher-burden evaluation. | Institutional use is effectively public within the relevant system and must not rely on private-analysis burden. | Operationally closed only within institutional scope; often requires explicit human confirmation. | New records may be `new evidence`; procedural defects `demonstrated error`; changed institutional use `scope change`; contestation or channel failure may be `other`. |
| **Public synthesis** | Requires careful source distinction, claim restraint, rival pressure, publicness review, and explicit limits. Must not launder weak input through fluent integration. | High burden if persons, groups, identities, reputations, or sensitive domains are implicated. Public synthesis may report bounded scene or claim analysis; it may not publish unsupported whole-person judgments or rankings. | Publicness itself raises burden. The synthesis must state what it does not establish and how correction remains possible. | Supported but limited, or operationally closed for publication within declared limits. | Factual correction may be `new evidence` or `demonstrated error`; changed circulation or reuse is `scope change`; a better synthesis is `stronger rival`; other burden changes use `other`. |

### Person-Near Protection Boundary

Person-nearness is not one undifferentiated burden level.

Annex C distinguishes:

```text
elevated person-nearness burden

from

prohibited person-level output
```

An elevated burden may still permit a scene-bound, role-bound, claim-bound, reversible, and contestable output.

A prohibited person-level output includes unsupported or non-delegable:

```text
whole-person assessment
character judgment
motive determination
maturity ranking
dignity ranking
credibility ranking
competence verdict
pathology or diagnosis
forensic conclusion
stable blameworthiness judgment
status or worth classification
```

Where such an output is requested and the available input, source status, intended use, or correction conditions cannot carry it, the disciplined response is not merely “higher burden.”

The required result may be:

```text
requested-output disposition: refused

pipeline-case disposition: stop

next allowed step in the current pass: stop
```

A safer scene-bound question may be identified, but it requires a new case boundary and a new Pre-Analysis. It must not be inserted as a same-run substitute for the prohibited output.

Human confirmation does not override this protection boundary.

### Closure Status Terms

The closure status should be named explicitly.

| Closure Status | Meaning | Discipline Requirement |
| --- | --- | --- |
| **Untested / underdescribed** | The claim has not passed through enough entry, input-status, operator, rival, claim, or correctability review. | Do not present it as supported. Use only as a question, prompt, or exploratory note. |
| **Genuinely unresolved** | The claim has been examined, but necessary thresholds remain open. | Do not force closure. State what remains unresolved and which atomic reopening conditions could change the status. |
| **Supported but limited** | The claim is justified within declared input, scope, use, and burden limits. | State limits and reopening conditions. Do not generalize or transfer the result. |
| **Tested and rejected** | The claim has been considered and currently lacks support under the available burden. | Do not reopen through repetition, authority, discomfort, or workflow continuation alone. |
| **Operationally closed** | The claim is closed for a specific use, decision, output, or next step. | Keep reasons inspectable and reopening conditions visible. Do not treat closure as epistemic finality. |
| **Provisionally sufficient with follow-up value** | The present pass is adequate for its intended use while a separately bounded future question may still be useful. | Keep current sufficiency distinct from iteration value, urgency, and follow-up preparation. Do not inherit current authority. |

### Canonical Reopening Categories

For interface and template use, every reopening condition must use exactly one of the following canonical categories:

```text
new evidence
scope change
demonstrated error
stronger rival
other
```

These values are interface categories. They do not eliminate conceptual detail. The category states the kind of reopening condition; the accompanying explanation states why it matters.

#### Category Guidance

**`new evidence`**

Use when materially relevant evidence, source material, records, testimony, observations, or verified facts become available or materially change.

Examples:

```text
a previously unavailable record becomes available
a factual source is corrected
affected-person testimony supplies new evidentiary material
a technical audit produces new findings
```

**`scope change`**

Use when the claim boundary, case boundary, intended use, audience, circulation, deployment, or practical consequence changes.

Examples:

```text
private orientation becomes public synthesis
a local scene claim becomes an institutional recommendation
the case expands to a different time period
a new subcase or analytical question is introduced
```

**`demonstrated error`**

Use when a specific error in the prior analysis, source handling, operator assignment, route decision, record, or closure is established.

Examples:

```text
an operator was materially misassigned
a checked artefact used the wrong source status
a superseded artefact was treated as effective
a closure reason depended on a factual or procedural error
```

**`stronger rival`**

Use when another explanation, method, domain process, or analytical frame discriminates better or carries the burden more responsibly.

Examples:

```text
a domain-specific method explains more with less overreach
a rival account better fits the available evidence
a technical or legal process supersedes PMS as the primary frame
```

**`other`**

Use only when no listed category adequately captures the condition.

Possible examples include:

```text
affected-person contestation changes the burden without adding new evidence
a promised correction channel fails
the use context changes in a way not reducible to scope alone
a non-retaliatory response path becomes unavailable
```

The specific reason must be explained next to `other`.

### Atomic Reopening Rule

Each reopening record must contain exactly one canonical category.

Invalid combined values include:

```text
new evidence plus scope change
new evidence / stronger rival
demonstrated error and other
scope revision
new rival explanation
```

Where several reopening grounds apply, record them as separate conditions:

```text
RO1
condition: new evidence
explanation: A previously unavailable source materially changes the input status.

RO2
condition: scope change
explanation: The intended use has changed from private orientation to public synthesis.

RO3
condition: other
explanation: Affected-person contestation changes the burden without adding new factual evidence.
```

Conceptual special grounds remain visible in their explanations. They must not be converted into new enum values.

A claim is not reopened merely by:

```text
repetition
authority
discomfort
status pressure
rhetorical reframing
desire for a different outcome
template completion
AI confidence
workflow continuation
human insistence
```

### Annex C Decision Guidance

The stronger the claim, the more explicit its input, source, protection, closure, and reopening burdens must become.

An orientation may remain open. A hypothesis must remain revisable. A bounded reconstruction must mark what it does and does not reconstruct. An evaluation must declare its object and standard. A recommendation must show consequence burden. An intervention, technical implementation, or institutional uptake must preserve stop-capability, domain responsibility, and contestability.

Person-nearness must not be treated only as a sliding burden scale. Where the requested output itself crosses a protection boundary, the result may be refusal and pipeline stop before Core.

Proceed is permitted only as bounded proceed.

If closure status is unclear, reopening conditions are absent, claim burden exceeds input, a prohibited person-level output is requested, or correctability is unavailable, the disciplined result is revision, downgrade, suspension, refusal, redirection, or pipeline stop as appropriate.

A claim is disciplined only when the output shows:

```text
what it currently permits
what it does not permit
whether the current pipeline may continue
what would justify reopening
what would require a new case
what would require weakening, stopping, refusal, or redirection
```

---

## D. Minimal Case-Pass Record

### Function of Annex D

Annex D provides the minimal record format for a PMS-DISCIPLINE pass.

A case-pass record is an accountability artefact, not a verdict. It makes a PMS-based application inspectable by preserving the path from pre-entry purpose review through Entry Control, permitted analysis, closure, and possible future use.

It does not certify truth, validate the case, prove operator assignment, authorize add-on use, rank persons, close reality, or license future work by inheritance.

The purpose of the record is to show:

```text
why the application was considered
whether it should begin
what was read
what was not read
what was requested
what was permitted
whether the current pipeline may continue
what was used
what was not used
what was rejected
what remains unresolved
what is not licensed
what can still be corrected
what may proceed
what must stop
what must not be inherited
```

A minimal record is disciplined only if it preserves reasons, limits, non-use, unresolved risks, effective checked artefacts, possible correction, stop-capability, and future-use boundaries.

The record may be represented in prose, table form, form fields, YAML, or another workflow format. Representation does not add authority.

A YAML record is still a record. A completed template is still an artefact. A checked Case Record chain is still traceability, not truth. An Iteration Handoff is still prospective preparation, not inheritance. An article is still rendering, not new analysis.

### Use Constraints

The Minimal Case-Pass Record is governed by the following constraints:

```text
record, not verdict
field, not proof
completion, not validation
summary, not closure
routing trace, not decision engine
checked artefact, not evidence
pipeline stop, not whole-person verdict
Case Record, not truth
handoff, not inheritance
article, not analysis
human confirmation, not guardrail override
```

The record must not be used as evidence that PMS was correct. It must not be treated as proof that the application was adequate.

It must not become a compliance surface that hides:

```text
missing input
weak claims
rival pressure
add-on overuse
MIP or AHP misuse
person-nearness
unavailable correction
confirmed stop conditions
superseded artefacts
future-inheritance risk
```

A stopped pass may be complete relative to DISCIPLINE even where no Core analysis exists. It must not be marked incomplete merely because the Entry Gate correctly prevented later stages.

### Minimal Record Header

```text
Case title:
Record status:
Date / version:
Prepared by:
AI / template / YAML involvement:
Workflow / Case Record involvement:
Article-level use:
Iteration / handoff involvement:
Intended use:
Audience / circulation:
Requested-output disposition:
Pipeline-case disposition:
Final analytical decision state, if reached:
```

#### Record Status

Recommended record statuses include:

```text
draft
under entry review
entry stopped
revised
provisionally sufficient
downgraded
suspended
refused
redirected
superseded
withdrawn
```

Record status is not the same as pipeline-case disposition or final analytical decision state.

### 0. Pre-Entry Purpose Review and Entry Control

#### 0.1 Pre-Entry Analyst Review

```text
Why is PMS being considered?
Why is the material being treated in this form?
What output is being requested?
What is the intended practical effect?
Who may be affected?
Is PMS an appropriate frame?
Should the application begin?
Pre-entry decision:
Reason:
```

**Purpose:** Makes visible the analyst’s responsibility before workflow momentum begins.

**Required:** Yes where the record is used as the accountable trace of a formal pass.

**Discipline requirement:** Where the requested treatment is already clearly inappropriate, totalizing, non-delegable, person-capturing, or better handled elsewhere, the analyst may refuse or redirect before Pre-Analysis.

Pre-Analysis formalizes entry discipline. It does not create the analyst’s responsibility.

#### 0.2 Pre-Analysis / Entry-Control Record

```text
Pre-Analysis present:
Pre-Analysis version:
Pre-Analysis check present:
Pre-Analysis check status:
Original Pre-Analysis artefact:
Corrected Pre-Analysis artefact, if any:
Effective checked Pre-Analysis artefact:
Superseded Pre-Analysis artefacts:
Requested output:
Requested-output disposition:
Pipeline-case disposition:
Core-entry eligibility:
Controlling protection or scope reason:
Next allowed step in the current pass:
Possible action outside the current pass:
```

**Purpose:** Determines whether the current bounded case may enter Core.

**Required:** Yes before any Core application.

**Requested-output disposition** states whether the requested output may be produced in its requested form.

**Pipeline-case disposition** states whether the current pass may continue.

**Core-entry eligibility** states whether Core is permitted, requires correction first, or is blocked.

#### 0.3 Effective Checked-Artefact Rule

```text
If check status is ready:
the original reviewed artefact remains effective.

If check status is corrected:
the complete corrected artefact becomes effective.

If check status is not ready:
the artefact is not eligible for downstream use.

If a stop is confirmed:
the effective checked artefact records the stop
and is not Core-eligible input.
```

Audit prose, correction lists, and review commentary are not substitutes for the complete effective checked artefact.

Downstream steps must not use a superseded version because it permits continuation more conveniently.

#### 0.4 Confirmed Stop Record

Where the Entry Gate confirms stop, record:

```text
Requested-output disposition:
Pipeline-case disposition: stop
Core-entry eligibility: not permitted
Stop reason:
Protection or scope boundary:
Use that is refused:
Next allowed step in the current pass: stop
Possible correction within Pre-Analysis:
Possible redirect:
New case required for redirected work:
```

A confirmed stop ends the current pass before Core.

No Core, add-on, MIP, AHP, Case Record, Iteration Handoff, or article output may be fabricated as though the stopped analysis had occurred.

A redirect after stop may identify a future direction. It does not continue the same case.

### 1. Scene / Case Boundary

```text
Scene / case boundary:
Included material:
Excluded material:
Boundary reason:
Boundary uncertainty:
Subcase boundary, if applicable:
Future boundary risk:
```

The title and boundary must not already contain an unearned verdict.

### 2. Input and Source Status

```text
Input types:
Source status:
Known:
Reported:
Inferred:
Contested:
Missing:
Model-generated:
User-supplied:
Workflow-generated:
Article-generated:
Unverified:
Input-status limits:
Source-status limits:
```

The record must distinguish fact, report, interpretation, model output, evidence, hypothesis, conclusion, workflow telemetry, article wording, and prospective follow-up material.

If the intended claim depends on treating model output, interpretation, report, workflow state, article wording, or prior analysis as evidence, the application must be revised, downgraded, suspended, refused, redirected, or stopped.

### 3. Intended Use and Requested Output

```text
Intended use:
Requested output:
Use context:
Audience:
Private / public:
Reversibility:
Institutional uptake:
Technical or automated uptake:
Person-affecting use:
Article-level use:
Follow-up-seeding use:
```

Intended use determines burden.

A private orientation, public synthesis, institutional recommendation, technical implementation, article-level output, and follow-up-seeding output require different levels of input discipline, rival pressure, human confirmation, correctability, and future-use boundary.

### 4. PMS Core Pass, If Entry Is Permitted

```text
Core performed:
Effective checked Core artefact:
Core pass summary:
Core status:
Core sufficiency:
Core instability:
Core-only possible:
Core claim boundary:
```

**Conditional requirement:** Required only where the effective checked Pre-Analysis permits Core entry.

A stopped case must record `Core performed: no — blocked by Entry Gate`.

Add-ons may not compensate for Core underdetermination.

### 5. Operator Salience

```text
Operators assigned:
Locally salient operators:
Structural role of each operator:
Operator-load pattern:
Operators considered but not assigned:
Operator assignment uncertainty:
```

Operator assignment must be justified by structural work, not thematic association.

### 6. Operator Omissions

```text
Possible omitted operators:
Would omission materially change the reading?
How would the claim change if included?
Omission status:
```

Recommended omission statuses:

```text
not material
possibly material
material but unresolved
material and requires revision
material and requires downgrade
material and requires suspension
material and requires refusal
material and requires redirection
```

### 7. Derived-Axis / Drift-Risk Notes

```text
Derived axes considered:
Derived axes active:
Derived axes not applicable:
Reification risk:
Person-ranking risk:
Moralization risk:
Claim inflation risk:
Inheritance risk:
```

Derived axes are PMS-internal projections, not person scores, primitives, or authority markers.

If a derived axis is used to score, rank, diagnose, moralize, or totalize a person, the requested use must be refused or redirected and the pipeline may need to stop.

### 8. PMS Add-on Route — Single-Add-on Rule

```text
Add-on scan performed:
Selected PMS add-on:
Core-only result:
Additional add-ons considered:
Add-ons explicitly not used:
Add-ons rejected as over-application:
Decomposition required:
Separate subcases created:
```

The selected PMS add-on must be either:

```text
none

or

exactly one of:
ANTICIPATION
CRITIQUE
CONFLICT
LOGIC
EDEN
SEX
```

A single bounded pass must not contain multiple selected PMS add-ons.

Where several add-on questions are materially relevant, they must become separately bounded subcases with their own Pre-Analysis, Core pass, claim ceiling, rivals, correction conditions, and final analytical decision state.

#### Selected Add-on Detail, If Any

```text
Selected add-on:
Trigger reason:
Operator-load pattern:
Risk-shape:
Claim-shape:
Non-trigger conditions checked:
What the add-on contributes:
What the add-on does not authorize:
Effective checked add-on artefact:
```

#### Add-ons Not Used or Rejected

```text
Add-on:
Non-use or rejection:
Reason:
False trigger:
Overuse risk:
Claim prevented:
```

### 9. MIP Route — Binary Human Decision

MIP is a downstream own-output layer, not a PMS add-on.

```text
MIP considered:
MIP Gate present:
MIP Gate check present:
Effective checked MIP Gate artefact:
MIP source-read recommendation:
MIP Source Reading present:
MIP route decision:
MIP application mode:
MIP Case Application present:
Effective checked MIP artefact:
MIP non-use reason:
```

The responsible MIP route is binary:

```text
do not use MIP

or

use MIP
```

A recommendation to read the MIP source does not create a third route.

MIP Source Reading and MIP Case Application are distinct:

```text
MIP Source Reading
= reading the MIP source, concepts, limits, red zones,
  and available modes without producing case findings

MIP Case Application
= applying MIP to the current checked case
  after the route selects MIP use
```

MIP does not become relevant merely because of maturity vocabulary, routine process, deadline, delay, loss of options, workflow friction, ordinary responsibility language, or hypothetical real-person reference.

MIP requires actual person-evaluative, responsibility, role-capability, dignity, face, status, reputational, or maturity-in-practice pressure.

#### MIP Application Mode

Where `MIP route decision: use MIP`, record one application mode:

```text
supported MIP Case Application

or

Conditional Transfer / Boundary Use
```

Conditional Transfer / Boundary Use may examine:

```text
burden conditions
application boundaries
red zones
claim restraint
person-nearness risk
misuse risk
```

It may not perform:

```text
hard A/M scoring
D activation
IA/D verdicting
maturity ranking
developmental evaluation
whole-person assessment
```

### 10. AHP Route — Subordinate to Checked MIP

```text
AHP considered:
Checked MIP prerequisite satisfied:
AHP Gate present:
AHP Gate check present:
AHP used:
AHP not used:
AHP non-use reason:
Effective checked AHP artefact:
```

AHP is available only after an actual MIP Case Application was produced and checked.

The following are insufficient:

```text
MIP mention
MIP vocabulary
MIP Source Reading
MIP Gate recommendation
unexecuted MIP relevance
general evaluative pressure
```

AHP may inspect analysis construction, boundary preservation, hardening risk, public transmission, scoring pressure, and misuse surface.

AHP may not:

```text
correct or replace MIP
reanalyze the underlying person
rescore MIP
activate D
change IA/D status
upgrade evidence
raise the claim ceiling
certify maturity
become an authority layer
```

### 11. Rival Account

```text
Rival account:
Rival type:
What rival explains better:
What PMS explains better:
Current discrimination status:
Rival outcome:
```

A rival can win.

Recommended outcomes:

```text
rival tested and rejected
rival remains live
rival discriminates better
rival requires downgrade
rival requires suspension
rival requires refusal
rival requires redirection
rival requires pipeline stop
```

### 12. Claim Type and Claim Ceiling

```text
Claim type:
Claim ceiling:
Lowest adequate claim:
Claims explicitly not made:
Claim escalation risk:
Future-use claim risk:
```

Recommended claim types:

```text
orientation
structural sketch
hypothesis
bounded reconstruction
evaluation
recommendation
intervention
technical implementation
institutional uptake
public synthesis
```

The claim type must be the lowest adequate claim type for the intended use.

### 13. Person-Nearness / Publicness / Irreversibility

```text
Person-nearness:
Protection level:
Affected persons:
Publicness:
Irreversibility:
Reputation / access / institutional effect:
Automation or technical mediation:
Article-level exposure:
Follow-up-seeding exposure:
Dignity-in-Practice preservation:
Contestability:
Mandatory Person-Near Stop condition:
```

Recommended protection levels:

```text
not materially person-near
elevated person-nearness burden
Mandatory Person-Near Stop
```

A prohibited person-level output must not be treated merely as a higher-burden claim.

Where Mandatory Person-Near Stop applies, the record must return to the Entry-Control result:

```text
requested-output disposition: refused
pipeline-case disposition: stop
next allowed step in current pass: stop
```

### 14. Correctability Status

```text
Correctability status:
Access to reasons:
Response space:
Non-retaliatory contestation:
Possible effect of correction:
Who can contest:
What can change:
```

Recommended statuses:

```text
preserved
partial
symbolic only
absent
blocked
requires revision
requires suspension
requires refusal
requires redirection
requires pipeline stop
```

Correctability is not present unless correction can change the reading or application path.

### 15. Reopening Conditions — Atomic Interface Categories

```text
Reopening conditions:
- id:
  condition:
  explanation:
  expected effect:
```

Each `condition` must be exactly one of:

```text
new evidence
scope change
demonstrated error
stronger rival
other
```

Multiple grounds require multiple list items.

Do not use:

```text
scope revision
new rival explanation
new evidence plus scope change
demonstrated error / stronger rival
```

Conceptual detail belongs in `explanation`.

### 16. Closure Status

```text
Closure status:
Scope of closure:
Reason for closure:
What remains open:
What would reopen the claim:
What would require a separate follow-up case:
```

Recommended closure statuses:

```text
untested / underdescribed
genuinely unresolved
supported but limited
tested and rejected
operationally closed
provisionally sufficient with follow-up value
```

Close the claim operationally; keep closure epistemically answerable.

### 17. Status Separation and Final Analytical Decision

```text
Requested-output disposition:
Pipeline-case disposition:
Final analytical decision state:
Reason:
What limitation has been reached:
Human confirmation required:
Human confirmation completed:
```

The three status dimensions must remain distinct.

The canonical final analytical decision states are:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

`stop` is not a seventh final analytical decision state.

It is a pipeline-control disposition.

Example:

```text
Requested-output disposition: refused
Pipeline-case disposition: stop
Final analytical decision state: refuse
Next allowed step in current pass: stop
Possible future direction: new separately bounded case
```

### 18. Limits

```text
Limits of the reading:
Input limits:
Source limits:
Claim limits:
Operator limits:
Add-on limits:
MIP / AHP limits:
Rival limits:
Person-nearness limits:
Correctability limits:
Implementation limits:
Future-use limits:
```

The record must show not only what was concluded, but what was not licensed.

### 19. Unresolved Risks

```text
Unresolved risks:
Risk owner:
Risk effect:
Can the risk be corrected?
Does the risk require downgrade / suspension / refusal / redirection / stop?
Does the risk require a separate future case?
```

Genuinely unresolved is a closure-space, not a failure.

### 20. Permitted and Prohibited Next Steps

```text
Permitted next steps:
Prohibited next steps:
Only allowed next step in the current pass:
Required before further use:
Required before publication:
Required before institutional / technical / automated use:
Required before article-level use:
Required before follow-up case:
```

Where the pipeline is stopped:

```text
Only allowed next step in the current pass: stop
```

Correction of the Pre-Analysis or a new case may occur outside the stopped continuation path, but must be explicitly recorded as such.

### 21. Explicit Human Confirmation, If Required

```text
Human confirmation required:
Reason:
Confirmed by:
Confirmation scope:
Confirmation date:
What was confirmed:
What was not confirmed:
Pipeline stop confirmed:
Future-use boundary confirmed:
```

Human confirmation confirms responsibility for the bounded result.

It does not certify truth, safety, adequacy, closure, or follow-up authority.

It does not override a confirmed protection stop.

### 22. Case Record / Current-Step Boundary, If Applicable

```text
Case Record stages used:
Stage 1 status:
Stage 1 check status:
Effective checked Stage 1 artefact:
Stage 2 status:
Stage 2 check status:
Effective checked Stage 2 artefact:
Stage 3 generation status:
Stage 3 check status:
Effective checked Stage 3 artefact:
Skipped / unavailable branches:
Superseded artefacts:
Current-step boundary preserved:
Workflow telemetry excluded from case substance:
```

#### Stage-3 Lifecycle Rule

`Stage 3 generation status` records the state declared when Stage 3 was generated.

`Stage 3 check status` records the later review result.

The Stage-3 check must not retroactively alter a valid generation-time next-step or readiness field merely because the check has now occurred.

Correction is required only where the generation-time field was already inconsistent with the route, violated the template, or created a substantive contradiction.

Case Record is traceability, not truth.

### 23. Iteration Handoff / Follow-Up Preparation, If Applicable

The Iteration Handoff follows the checked Case Record and precedes any optional article workflow.

```text
Iteration Handoff present:
Source Case Record:
Current sufficiency:
Iteration value:
Iteration urgency:
Follow-up question:
Follow-up boundary:
Required new material:
Context / lineage references:
What may be carried forward:
What must not be carried forward:
Follow-up case required:
```

The Iteration Handoff is:

```text
prospective preparation
not Case Record Stage 4
not article check
not new analysis
not reopening by itself
not inheritance
```

Article wording, generated examples, article profiles, and article checks are not sources for Iteration Handoff findings.

Non-inheritance rule:

```text
Do not inherit findings as evidence.
Do not inherit route decisions as route authority.
Do not inherit operator statuses as current activations.
Do not inherit add-on selection.
Do not inherit MIP / AHP status.
Do not inherit claim ceiling.
Do not inherit sufficiency status.
Do not inherit pipeline eligibility.
Do not inherit article wording as established truth.
```

### 24. Article Workflow, If Applicable

Article rendering follows the checked Case Record and any independently grounded Iteration Handoff.

```text
Article workflow selected:
Article profile:
Primary source:
Stage 2 support used:
Stage 1 provenance used:
Base article produced:
Example decision:
Examples generated:
Final integrated article required:
Final article check status:
Effective checked article artefact:
```

The source hierarchy is:

```text
Stage 3
→ Stage 2
→ Stage 1
```

The article must not:

```text
perform new analysis
strengthen claims
treat examples as evidence
create Iteration Handoff findings
override a stop
convert a Case Record into a verdict
```

Where no examples are generated, the checked base article may become the final article candidate without fabricating an integration step.

### 25. DISCIPLINE Challenge Fields, If Applicable

```text
DISCIPLINE step challenged:
Challenged by:
Failure mode alleged:
Rival routing or weaker claim proposed:
What correction would change:
Stop / Entry-Control issue:
Iteration / inheritance issue:
Current response:
```

The output record is not the final authority over the failure of the output record.

### Minimal Case-Pass Compact Template

```text
Case title:
Record status:

Pre-entry purpose review:
- why PMS:
- requested output:
- intended effect:
- should the application begin:

Pre-Analysis / Entry Control:
- Pre-Analysis check status:
- effective checked Pre-Analysis artefact:
- requested-output disposition:
- pipeline-case disposition:
- Core-entry eligibility:
- stop reason, if any:
- only allowed next step in current pass:
- new case required for redirected work:

Scene / case boundary:

Input and source status:
- known:
- reported:
- inferred:
- contested:
- missing:
- model-generated:
- workflow-generated:
- article-generated:

Intended use:

PMS Core pass, if permitted:
- performed:
- effective checked Core artefact:
- summary:
- status:
- sufficiency:

Operator salience:
- assigned:
- locally salient:
- possible omissions:

Derived-axis / drift-risk notes:

PMS add-on route:
- selected add-on: none or exactly one
- explicitly not used:
- rejected as over-application:
- decomposition / separate subcases:

MIP route, if relevant:
- effective checked MIP Gate:
- Source Reading:
- route: do not use MIP / use MIP
- application mode:
- effective checked MIP artefact:

AHP route, if relevant:
- checked MIP prerequisite:
- used / not used:
- effective checked AHP artefact:

Rival account:
- rival considered:
- current discrimination status:

Claim type:
- claim ceiling:
- claims not licensed:

Person-nearness / publicness / irreversibility:
- protection level:
- affected persons:
- publicness:
- reversibility:
- contestability:
- Mandatory Person-Near Stop:

Correctability status:
- can correction affect the output?
- what can change?

Reopening conditions:
- condition: new evidence / scope change / demonstrated error / stronger rival / other
- explanation:

Closure status:
- current closure:
- what would reopen:
- what would require a separate follow-up case:

Status separation:
- requested-output disposition:
- pipeline-case disposition:
- final analytical decision state:

Limits:

Unresolved risks:

Next steps:
- permitted:
- prohibited:
- only allowed next step in current pass:
- required before stronger use:

Human confirmation, if required:

Case Record / current-step boundary, if applicable:
- Stage 3 generation status:
- Stage 3 check status:
- effective checked Stage 3 artefact:

Iteration Handoff, if applicable:
- current sufficiency:
- iteration value:
- iteration urgency:
- follow-up boundary:
- required new material:
- non-inheritance limits:

Article workflow, if applicable:
- profile:
- source hierarchy preserved:
- example decision:
- final article check:

DISCIPLINE challenge, if applicable:
```

### Minimal Sufficiency Check

A Minimal Case-Pass Record may be treated as provisionally sufficient under one of two paths.

#### Entry-Stop Sufficiency Path

A stopped pass is provisionally sufficient when:

```text
the pre-entry purpose is visible
the case boundary and intended use are declared
the input and source status are marked
the requested output is explicit
the effective checked Pre-Analysis artefact is identified
the requested-output disposition is explicit
the pipeline-case disposition is stop
Core-entry ineligibility is explicit
the controlling protection or scope reason is stated
the only allowed next step in the current pass is stop
no later analytical findings are fabricated
any redirect is marked as requiring a new case
human responsibility is locatable
```

#### Analytical-Pass Sufficiency Path

A permitted analytical pass is provisionally sufficient when:

```text
the Pre-Analysis and Entry Gate permit Core
the effective checked artefacts are identified
the case boundary is declared
the input and source status are marked
the intended use and requested output are explicit
the claim type is the lowest adequate claim type
the Core reading is visible
operator salience and possible omissions are marked
at most one PMS add-on is selected
add-on non-use and rejection are justified
MIP route is binary where relevant
AHP follows only an actual checked MIP application
rival accounts have been considered
person-nearness and protection boundaries are explicit
reopening conditions use atomic canonical categories
correctability remains effective
requested-output, pipeline-case, and final analytical statuses are distinct
human confirmation is present where required
Stage-3 generation and check statuses are distinguished
Iteration Handoff precedes article workflow
future-use and non-inheritance boundaries are explicit
```

This sufficiency is not truth, safety, finality, or authority.

It is sufficiency relative to the declared scene, source status, intended use, claim type, protection burden, rival pressure, correctability conditions, pipeline state, and future-use boundary.

A case-pass record is disciplined only when it makes the current use bounded, inspectable, correctable, stoppable, and non-inheritable enough for the claim it permits.

---

## E. Compact PMS Add-on Trigger Map and Downstream Gate Distinction

### Function of Annex E

Annex E provides a compact trigger map for the six PMS add-ons used in PMS-DISCIPLINE:

```text
ANTICIPATION
CRITIQUE
CONFLICT
LOGIC
EDEN
SEX
```

The map helps identify possible PMS add-on relevance. It does not decide add-on use. It does not classify the case. It does not authorize stronger claims. It does not replace the checked Pre-Analysis, the Core pass, input- and source-status discipline, claim-type review, rival pressure, person-nearness protection, correctability, or stop-capability.

MIP and AHP are not included in the PMS add-on map. They are downstream own-output layers with separate dependency, gate, source, application, and check conditions.

The PMS add-on trigger map is a scan aid, not a decision engine.

A trigger indicates possible relevance, not permission to classify. A non-trigger condition is as important as a trigger condition. A false trigger is not harmless; it changes the reading corridor and may increase person-nearness, claim burden, or closure pressure without sufficient warrant.

The map is governed by the following constraints:

```text
surface cue
≠
structural trigger

structural trigger
≠
automatic use

add-on use
≠
authorized claim

add-on specificity
≠
claim authority

trigger map
≠
routing engine

several plausible add-ons
≠
permission to mix add-ons in one pass
```

PMS add-on use remains subordinate to:

```text
effective checked Pre-Analysis
Core-entry eligibility
Core sufficiency
input and source status
claim type and claim ceiling
operator-load
risk-shape
claim-shape
rival pressure
person-nearness
correctability
stop-capability
Single-Add-on Rule
```

If a trigger is unclear, unsupported, or outweighed by a non-trigger condition, the disciplined result may be:

```text
Core-only
add-on not used
add-on rejected as over-application
claim revision
claim downgrade
suspension
refusal
redirection
pipeline stop
```

### E.1 Single-Add-on Rule

A single bounded PMS-DISCIPLINE pass may use:

```text
Core-only

or

Core plus exactly one justified PMS add-on
```

The Single-Add-on Rule does not imply that complex material contains only one relevant structure. It requires each bounded analytical question to preserve a clear relation between:

```text
case boundary
analytical question
Core reading
trigger
selected add-on
claim ceiling
rival pressure
person-nearness burden
correction conditions
final analytical decision state
```

Where several PMS add-ons appear relevant, the case must first undergo decomposition review.

The disciplined questions are:

```text
Which distinct analytical questions are present?

Which question belongs to which case or subcase boundary?

Which single PMS add-on, if any, is justified for each subcase?
```

If several questions are materially distinct, they must be handled as separately bounded subcases. Each subcase requires its own Pre-Analysis, Core pass, route decision, claim ceiling, rival review, correctability review, and final analytical decision state.

The effective checked subcase records may later undergo record-level comparison or integration. Such integration does not retrospectively create a mixed-add-on pass and does not authorize new cross-subcase findings.

Record-level integration must not:

```text
merge distinct claim ceilings
use one add-on finding as evidence for another
hide a losing rival result inside a broader narrative
convert local findings into a whole-case conclusion without renewed burden
erase differences in input status, person-nearness, or closure status
infer a new dependency, sequence, causal relation, or evaluative conclusion
```

Structural interaction between add-on questions may be discussed at theory level or preserved where already supported by the checked records. Where the relation itself requires new analysis, it must become a new, separately bounded analytical integration case. Operational mixing within one bounded analytical pass remains excluded.

### E.2 Compact Trigger Eligibility Logic

A PMS add-on becomes eligible for review only where all of the following are present:

```text
1. The effective checked Pre-Analysis permits Core entry.

2. Core has established a sufficiently stable base reading.

3. A specific operator-load pattern creates a burden
   that Core alone may not adequately display.

4. The intended claim or use context requires
   the specialized risk lens.

5. Relevant non-trigger conditions have been checked.

6. The selected add-on would not violate a protection boundary,
   suppress a stronger rival, or exceed the claim ceiling.
```

The presence of a topic, keyword, emotional tone, domain label, template field, or AI semantic match is not enough.

A trigger opens a review path. It does not enter the add-on automatically.

### E.3 PMS Add-on Trigger Map

| PMS Add-on | Possible Structural Trigger | Non-Trigger | Operator-Load Pattern | Over-Application Risk | Downgrade / Stop Cue |
| --- | --- | --- | --- | --- | --- |
| **ANTICIPATION** | Future-oriented burden structurally shapes present action, delay, preparation, commitment, risk, closure, or responsibility. | Mere future reference, planning language, speculation, hope, fear, forecast, deadline mention, or timeline description. | Θ with Λ, Α, Ω, Χ, Σ, or Ψ becomes load-bearing around future absence, preparation, delay, risk, commitment, or premature closure. | Future talk becomes anticipatory structure too quickly. A possibility is treated as present warrant, or uncertainty is overdetermined. | Downgrade to temporal note, orientation, or hypothesis where future burden is not structurally operative. Stop where anticipated risk is used to justify unsupported intervention, irreversible action, public claim, or person-level conclusion. |
| **CRITIQUE** | A disturbance becomes answerable to an object, reason, standard, and possible disconfirmation. | Complaint, negativity, attack, dislike, discomfort, harshness, opposition, interruption, or vulnerable signal without a sufficiently articulated critique structure. | Δ, □, Ω, Θ, Χ, Σ, or Ψ becomes load-bearing around challenge, standard, answerability, and correction. | Complaint is prematurely converted into critique; critique is reduced to tone; or critique becomes verdict, humiliation, or immunity from correction. | Downgrade to complaint or signal examination where object, reason, standard, or disconfirmation is missing. Stop where CRITIQUE becomes person judgment, retaliation, humiliation, or a protected frame against correction. |
| **CONFLICT** | A stable divergence of practical integration paths persists under relevant cost, asymmetry, temporality, distance, or self-binding pressure. | Ordinary disagreement, debate, difference of opinion, discomfort, opposition, critique, negotiation, or temporary coordination failure. | Ω, Θ, Χ, Σ, Ψ, or Α becomes load-bearing around incompatible or persistently diverging practical paths. | Disagreement is turned into conflict classification. The case appears more adversarial, terminal, stable, or determinate than the material supports. | Downgrade to Core-only, disagreement, critique, or unresolved divergence where stability, cost, or binding is not established. Stop where CONFLICT intensifies person capture, escalates hostility, or suppresses a stronger rival account. |
| **LOGIC** | The bounded case turns materially on claim structure, contradiction, inference, standard, validity, distinction, or the relation between reasons and conclusions. | Formal vocabulary, argument style, conceptual complexity, disagreement about reasoning, technical wording, or the presence of propositions alone. | Δ, □, Σ, Λ, or Θ becomes load-bearing around inference, distinction, validity, contradiction, or standard consistency. | Logical framing erases practical context, input weakness, person-nearness, effect, power, complaint, or correction burden. | Downgrade to a claim-structure note where formal burden is not central. Stop where LOGIC is used to dismiss affected reality, vulnerable signals, practical asymmetry, or person-near consequences as merely illogical. |
| **EDEN** | Error, correction, repair, transformation, or post-error continuation becomes structurally load-bearing. | Any mistake, revision, apology, improvement, recovery, learning language, or positive change. | Λ, Θ, Φ, Σ, Ψ, Χ, or Responsibility becomes load-bearing around error recognition, correction path, transformation, residue, and continued use. | EDEN aestheticizes correction, treats repair as guaranteed, converts harm into narrative development, or assumes failed correction has already been integrated. | Downgrade to correction note or unresolved repair where the repair structure is not established. Stop where EDEN makes harm, falsehood, failed correction, or affected-person burden appear already resolved. |
| **SEX** | Sexuality, intimacy, desire, embodiment, exposure, consent, shame, sexualized interpretation, or intimate vulnerability becomes structurally load-bearing. | Sexual vocabulary, metaphor, joke, aesthetic description, fictional reference, incidental sexual content, or thematic proximity without the relevant risk corridor. | Ω, Χ, Θ, Ψ, Λ, Dignity-in-Practice, or Responsibility becomes load-bearing around intimacy, exposure, consent, embodiment, person-nearness, or vulnerability. | Sexual metaphor is routed into SEX; the lens intensifies shame, exposure, identity capture, outing risk, or unsupported motive attribution. | Downgrade to Core-only or metaphor note where the sexual corridor is not structurally active. Stop where SEX use risks humiliation, outing, diagnosis, moralization, non-consensual exposure, or unsupported person-level claims. |

### E.4 General Non-Trigger Conditions

Non-trigger conditions must be recorded wherever a PMS add-on was plausible, expected, suggested, or scanned but not used.

A non-trigger is not a failure to apply PMS. It may be the disciplined result of the pass.

Typical non-trigger conditions include:

```text
surface vocabulary without structural load
topic similarity without operator-load pattern
AI semantic match without risk-shape
template suggestion without Core support
domain resemblance without claim burden
operator proximity without add-on necessity
weak or mixed input unable to support specialized routing
Core instability
rival account discriminates better
person-nearness risk too high for specialized precision
correctability unavailable
selected claim ceiling does not require the lens
add-on would duplicate rather than sharpen Core
another add-on question requires a separate subcase
```

If a non-trigger condition is present, the output should state whether the result is:

```text
Core-only
add-on not used
add-on rejected as over-application
revision
downgrade
suspension
refusal
redirection
pipeline stop
```

### E.5 False Trigger Warnings

False triggers are not harmless because they move the case into a different reading corridor.

Common false-trigger shortcuts include:

```text
disagreement → CONFLICT
complaint → CRITIQUE
future reference → ANTICIPATION
sexual metaphor → SEX
error language → EDEN
formal reasoning → LOGIC
```

Each arrow is a warning, not a routing rule. The left side may justify a scan. It does not justify add-on use.

The following are also invalid routing shortcuts:

```text
several plausible add-ons → mixed-add-on pass
specialized vocabulary → stronger claim
add-on use → MIP
MIP mention → AHP
publicness → AHP
maturity language → MIP
routine responsibility → MIP
```

### E.6 PMS Add-on Review Questions

Before using one PMS add-on, the record should answer:

```text
What checked Core reading has already been established?

What bounded analytical question requires the specialized lens?

What operator-load pattern creates the trigger?

What risk-shape or claim-shape requires the add-on?

What non-trigger conditions were checked?

Why is Core-only insufficient for this question?

Why is this add-on preferable to a separate rival frame?

What claim would the add-on not authorize?

What person-nearness risk does the add-on introduce or intensify?

What correction path remains available?

Could use of the add-on overdetermine the case?

Do other plausible add-ons belong to separate subcases?
```

If these questions cannot be answered, add-on use should not proceed as if justified.

### E.7 PMS Add-on Outcome Terms

Recommended PMS add-on outcome terms are:

```text
used
not used
rejected as over-application
scan only
requires separate subcase
requires revision
requires downgrade
requires suspension
requires refusal
requires redirection
requires pipeline stop
```

These terms are not final analytical decision states.

An add-on may be rejected while the case proceeds in Core-only form. An add-on may be used while the overall claim is downgraded. An add-on scan may lead to suspension or decomposition rather than use.

### E.8 Downstream Non-Add-on Layer Distinction

MIP and AHP are downstream own-output layers. They are not PMS add-ons and must not appear as rows in the PMS add-on trigger table.

The governing distinction is:

```text
PMS add-on routing
= selection of at most one specialized PMS precision lens

MIP routing
= separate decision about maturity-in-practice application
  under its own gate, source discipline, and claim boundary

AHP routing
= separate second-order analysis-quality review
  available only after an actual checked MIP application
```

Neither MIP nor AHP is an automatic completion layer.

### E.9 MIP Gate

#### MIP Gate Function

The MIP Gate determines whether the checked Core-only or Core-plus-one-add-on case presents an actual downstream maturity-in-practice burden.

MIP becomes eligible for review only where the case or intended output materially involves one or more of:

```text
person-evaluative judgment
responsibility attribution
role-capability assessment
practice under consequential burden
maturity-in-practice claims
dignity or face exposure
status consequence
reputational consequence
person-affecting evaluative transmission
risk of converting local practice into person judgment
```

MIP relevance must be actual to the current case or intended use. It must not be inferred merely from the possibility that a real person could someday be discussed.

#### MIP Non-Triggers

The following do not by themselves establish a MIP route:

```text
maturity vocabulary
general development language
self-control language
ordinary competence language
routine process
routine handoff
role or process coordination
deadline pressure
delay
loss or reduction of options
future-risk language
general organizational friction
ordinary practical judgment
curiosity about MIP
a hypothetical real-person transfer
the abstract possibility of reputational effect
```

These may justify caution or a MIP scan. They do not justify MIP application.

MIP is not triggered by pressure alone. The pressure must be materially connected to evaluative practice, responsibility, role capacity, dignity, face, status, reputation, or another MIP-specific person-near burden.

#### MIP Source Reading and MIP Case Application

MIP Source Reading and MIP Case Application are distinct.

```text
MIP Source Reading
= bounded reading of the MIP source,
  its concepts, limits, red zones, and application modes

MIP Case Application
= application of MIP to the current checked case
  after the responsible route decision selects MIP use
```

MIP Source Reading does not:

```text
produce case findings
activate MIP
assign A/M values
activate D
produce IA/D status
establish a maturity conclusion
make AHP available
```

A recommendation to read the MIP source does not create a third route.

After the checked MIP Gate, the responsible human route remains binary:

```text
do not use MIP

or

use MIP
```

Source Reading may prepare the `use MIP` route. It is not itself a separate case route.

### E.10 Conditional Transfer / Boundary Use

Where the route is `use MIP`, the application may be limited to Conditional Transfer / Boundary Use.

This mode permits MIP to examine:

```text
burden conditions
application boundaries
red zones
non-use conditions
claim restraint
person-nearness risk
misuse risk
requirements for responsible practice
```

Conditional Transfer / Boundary Use does not evaluate the maturity or developmental status of a real person.

In this mode, the following are prohibited:

```text
hard A/M scoring
D activation
IA/D verdicting
maturity ranking
developmental evaluation
whole-person assessment
person comparison
claim or evidence upgrade
```

Any observation must remain conditional, scene-bound, and directed toward application limits rather than person classification.

Conditional Transfer / Boundary Use remains inside the `use MIP` route. It is an application mode, not a third route between MIP use and non-use.

### E.11 AHP Dependency and Subordination

AHP is not triggered by:

```text
mention of MIP
maturity vocabulary
MIP Source Reading
MIP Gate recommendation
unexecuted MIP relevance
general evaluative pressure
publicness alone
scoring concern alone
a desire for additional checking
```

AHP becomes eligible only after all of the following are true:

```text
1. MIP use was selected.

2. A MIP Case Application was actually produced.

3. The MIP output was checked.

4. The checked MIP artefact is eligible for downstream use.
```

AHP remains a second-order analysis-quality overlay.

It may inspect:

```text
analysis construction
boundary preservation
claim hardening
artefact hardening
public transmission
misuse surface
scoring pressure
comparison pressure
institutional uptake risk
```

AHP may not:

```text
correct or replace MIP
reanalyze the underlying person or case
rescore A or M
activate D
change IA/D status
upgrade evidence
raise the claim ceiling
certify maturity
authorize institutional action
become an authority or governance layer
```

Where no actual checked MIP Case Application exists, the AHP route is unavailable.

### E.12 Annex E Decision Guidance

The PMS add-on trigger map should slow routing, not accelerate it.

A disciplined PMS add-on decision requires:

```text
checked Core first
one bounded analytical question
trigger reviewed
non-trigger checked
operator-load justified
claim burden marked
rival pressure preserved
person-nearness checked
correctability preserved
Single-Add-on Rule preserved
final analytical decision state explicit
pipeline-control state explicit where stop pressure exists
```

A trigger may increase burden. It may not authorize a stronger claim.

A trigger may justify review. It may not classify the case.

A trigger may reveal that the add-on must not be used.

MIP and AHP require their own gates and may not be treated as add-on maximization.

The safest route is not always the most specific route. The disciplined result may be Core-only, add-on non-use, decomposition, MIP non-use, AHP unavailability, downgrade, suspension, refusal, redirection, or pipeline stop.

The PMS add-on map is a scan aid, not a decision engine.

---

## F. Final Decision States, Pipeline Stop, Downgrade, Refusal, and Redirection Terms

### Function of Annex F

Annex F standardizes the decision and control language used in PMS-DISCIPLINE outputs.

A PMS-DISCIPLINE pass must be able to end in more than proceed. It may proceed, but it may also require revision, downgrade, suspension, refusal, redirection, or a pipeline stop that prevents the current pass from entering or continuing through later stages.

These outcomes are not signs that PMS-DISCIPLINE failed. They are the test of whether PMS-DISCIPLINE can constrain PMS use.

Annex F distinguishes three status dimensions:

```text
requested-output disposition
pipeline-case disposition
final analytical decision state
```

These dimensions may interact, but they must not be collapsed.

### F.1 Requested-Output Disposition

Requested-output disposition states whether the output requested by the user or use context may be produced in the requested form.

Possible dispositions may include:

```text
permitted
permitted only after revision
permitted only at a lower claim level
not currently supportable
refused
redirected to a different output or process
```

A requested output may be refused even where a different scene-bound or domain-appropriate question could later be examined.

Refusal of the requested output does not automatically answer whether the current pipeline may continue. That is recorded separately.

### F.2 Pipeline-Case Disposition

Pipeline-case disposition states whether the current bounded pass may enter or continue through the next workflow stage.

The controlling values are:

```text
proceed
correction required
stop
```

`stop` is a pipeline-control state. It is not a seventh final analytical decision state.

A pipeline stop may occur before Core, before a selected downstream layer, before Case Record construction, before article rendering, or before future-use inheritance.

Where a checked Pre-Analysis confirms stop, no later analytical stage belongs to the current pass.

### F.3 Final Analytical Decision States

The canonical final analytical decision states are:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

These six terms should be used consistently. They name the substantive bounded outcome of the discipline pass. They are not merely stylistic labels, workflow suggestions, or degrees of success.

The following rules apply:

```text
weaken
= activity within revise or downgrade

downgrade
= final analytical decision state

stop
= pipeline-case disposition, not a seventh analytical state

iteration
= future-use boundary practice, not a final analytical state
```

### F.4 Status Interaction Examples

A pass may produce:

```text
Requested-output disposition: permitted
Pipeline-case disposition: proceed
Final analytical decision state: proceed
```

or:

```text
Requested-output disposition: permitted only at a lower claim level
Pipeline-case disposition: proceed
Final analytical decision state: downgrade
```

or:

```text
Requested-output disposition: refused
Pipeline-case disposition: stop
Final analytical decision state: refuse
```

or:

```text
Requested-output disposition: refused in the requested form
Pipeline-case disposition: stop
Final analytical decision state: redirect
Possible future direction: new separately bounded case
```

A stop may occur before a complete analytical reading exists. In that situation, the record must not fabricate Core, add-on, MIP, AHP, Case Record, or article findings.

### F.5 Decision-State Table

| Final Analytical Decision State | Basic Meaning | Use When | Do Not Use When | Required Output Boundary |
| --- | --- | --- | --- | --- |
| **proceed** | The bounded application or output may continue within declared limits. | Entry is permitted and input status, claim type, Core reading, route state, rival pressure, person-nearness, correctability, and use context can support the bounded use. | A confirmed stop exists; the claim is too strong; a required threshold is unresolved; a guardrail is violated; or another frame must receive the case. | State scope, claim type, limits, reopening conditions, pipeline status, permitted steps, and claims not licensed. |
| **revise** | The application may continue only after a correctable defect is integrated. | The same general path and claim level may remain available after correction. | The claim level must be reduced, the threshold remains unresolved, a guardrail is violated, or the current pass is stopped. | State exactly what must change, which artefact must be corrected, and whether continuation remains blocked until correction. |
| **downgrade** | The reading may remain useful, but only at a lower claim level or use burden. | A weaker claim can responsibly proceed under the available input, rival, publicness, person-nearness, or correctability burden. | The requested output is prohibited, the weaker claim is also unsupported, or a confirmed stop blocks same-run continuation. | Name the original and lower claim levels, the stronger claim not licensed, and the limits of continued use. |
| **suspend** | The application cannot responsibly proceed now because a necessary threshold remains unresolved. | Better input, clearer thresholds, stronger rival review, or secured correctability may later make the same general application possible. | The use is prohibited, a Mandatory Person-Near Stop applies, or another frame already carries the burden more responsibly. | State what remains unresolved, what would justify reopening, and whether the pipeline is currently stopped. |
| **refuse** | The requested PMS use must not be performed or produced in the requested form. | A guardrail, protection boundary, or non-delegable responsibility condition is violated. | The issue is only a correctable defect, lower claim burden, or unresolved threshold without prohibition. | State the refused use, the violated boundary, why revision or downgrade is insufficient, pipeline status, and any safer future path. |
| **redirect** | PMS, or the selected PMS path, is not the right primary frame for the burden. | A rival, domain method, legal or clinical process, factual investigation, technical audit, mediation, institutional procedure, or other frame carries the burden more responsibly. | PMS remains adequate within a lower claim, or the requested use must simply be refused without a responsible receiving direction. | State the receiving direction, what PMS must not claim, whether the current pass stops, and what a new case would require. |

### F.6 Proceed

Proceed is only one possible disciplined outcome.

Proceed means that the application may continue within declared limits. It does not mean that the reading is true, complete, final, safe, authoritative, or transferable into future cases.

A proceed decision must state:

```text
scope of use
requested-output disposition
pipeline-case disposition
claim type and claim ceiling
input- and source-status limits
operator and add-on limits
MIP / AHP route limits
rival-pressure status
person-nearness and publicness status
correctability and reopening conditions
permitted next steps
prohibited next steps
claims not licensed
```

Proceed is invalid where an effective checked artefact contains a controlling stop.

Proceed must not erase unresolved risks, hidden omissions, untested rivals, weak input, model involvement, person-nearness burden, or future-use limits.

Proceed is permitted only as bounded proceed.

### F.7 Revise

Revise means that the reading or artefact may continue after a correctable defect is integrated.

Revision may affect:

```text
case boundary
input- or source-status marking
operator assignment
operator omission record
add-on decision
rival-pressure handling
claim wording
person-nearness marking
correctability condition
closure status
output boundary
```

Revision should be used where the problem is correctable within the same general application path.

Examples include:

```text
input status is too vague but can be corrected
operator assignment requires clearer justification
possible operator omission must be marked
add-on non-use must be explained
rival account is present but not adequately tested
claim wording is too strong but the claim category remains supportable
person-nearness is present but not marked
closure or reopening conditions are missing
```

Revision must not be used to avoid stronger language.

If the claim level must fall, use downgrade. If a threshold remains unresolved, use suspend. If a guardrail is violated, use refuse. If another frame should receive the case, use redirect. If a confirmed protection stop blocks continuation, revision cannot be used as a same-run workaround unless the stop itself is materially corrected through the required review.

### F.8 Downgrade

Downgrade means that the claim is too strong for the burden it can carry.

The reading may remain useful at a lower claim level.

Downgrade may move:

```text
evaluation → hypothesis
recommendation → orientation
intervention → bounded reconstruction
public claim → private exploratory note
person-near claim → scene-bound observation
add-on classification → add-on scan
explanation → structural sketch
operational closure → supported but limited
```

Downgrade is appropriate only where the weaker output is itself permitted and supportable.

Downgrade is not a valid way to preserve the substance of a prohibited person-level judgment under softer wording.

Where a confirmed protection stop applies, the current pass may not continue merely by changing labels such as:

```text
character → pattern
motive → tendency
maturity → practice profile
credibility → coherence
diagnosis → mapping
```

A downgrade output must state:

```text
the original claim level
the downgraded claim level
why the stronger claim is not licensed
what remains usable
what remains unresolved
whether the pipeline may continue
what would be needed to restore the stronger claim
```

### F.9 Suspend

Suspend means that the application cannot responsibly proceed now because a necessary threshold remains unresolved.

Suspension is not refusal. It does not say that PMS can never read the case or that the claim is false.

Suspension is appropriate where:

```text
input is insufficient
Core remains unstable
operator assignment is materially uncertain
operator omission may change the reading
add-on trigger is unclear
rival pressure remains unresolved
person-nearness burden remains unresolved
correctability cannot yet be secured
required human confirmation is absent
closure conditions are unavailable
```

A suspension output must state what remains unresolved and what atomic reopening conditions would permit renewed consideration.

Suspension must not be used where the requested use already violates a guardrail. In that situation, refuse or redirect as appropriate.

### F.10 Refuse

Refuse means that the requested PMS use must not be performed or produced in the requested form.

Refusal is required where the application would:

```text
issue an unsupported person-level verdict
rank maturity, dignity, credibility, competence, status, or worth
produce pathology or diagnosis without appropriate domain authority
delegate a non-delegable judgment to AI or artefacts
treat model output as evidence
produce person capture
close without correctability
use add-ons as authority tokens
convert complaint directly into verdict
suppress a stronger rival account
support automated or institutional action without required burden
violate dignity preservation or contestability
continue after a confirmed Mandatory Person-Near Stop
```

Refusal is a final analytical decision state. Where the refused output is the controlling purpose of the current case, the pipeline-case disposition should normally be `stop`.

A refusal output must state:

```text
the guardrail or protection boundary involved
the requested use that is refused
why revision or downgrade is insufficient
pipeline-case disposition
only allowed next step in the current pass
whether a safer alternative question exists
whether redirection is appropriate
whether a new case is required
```

Refusal should name the use that is refused, not degrade the person making the request or the person under review.

### F.11 Mandatory Person-Near Stop

A Mandatory Person-Near Stop is a guardrail case, not merely a high-burden person-near case.

It applies where the current request materially combines:

```text
1. A whole-person, character, motive, maturity, dignity,
   credibility, competence, pathology, forensic, blame,
   status, or ranking judgment;

2. Input, source status, or domain authority that does not
   independently license that person-level judgment;

3. Person-near, public, institutional, reputational, technical,
   automated, irreversible, or difficult-to-correct use.
```

It may also apply where the requested output is categorically non-delegable or prohibited even if extensive material is available, including automated dignity ranking, total human worth classification, or PMS acting as clinical, legal, forensic, or HR authority.

The required record is:

```text
Requested-output disposition: refused
Pipeline-case disposition: stop
Core-entry eligibility: not permitted
Final analytical decision state: refuse
Only allowed next step in the current pass: stop
```

A possible safer scene-bound question may be identified. It must begin as a new case with a new boundary, requested output, intended use, source review, and Pre-Analysis.

### F.12 Stop Precedence and Contradictory Signals

A controlling stop has precedence over a proceed signal within the same effective artefact set.

The governing rule is:

```text
one confirmed stop signal is sufficient to block continuation
```

Authoritative pipeline-stop signals include the effective checked equivalent of:

```text
pipeline_case_disposition: stop

status: stop_before_core

next_allowed_step: stop
```

Where the effective checked record contains both stop and proceed indications, the record is inconsistent. The inconsistency must not be resolved by selecting the more permissive field.

The required response is:

```text
1. Treat the current pipeline as stopped.

2. Do not enter Core or any later stage.

3. Rerun or correct the required semantic review.

4. Use only the complete effective corrected artefact
   if the stop was demonstrated to be erroneous.
```

Audit prose, user preference, deadline pressure, workflow momentum, or an isolated proceed field cannot override a confirmed stop.

Where a Full Review is required, an initial Pre-Analysis stop remains pending semantic review. Until the review is complete, Core entry is blocked. If the review confirms stop, the run ends. If the review corrects a false stop, the complete corrected Pre-Analysis becomes effective.

Where the semantic review is intentionally skipped, an existing stop must be treated as binding. Review omission cannot convert stop into proceed.

### F.13 No Same-Run Reframing After Protection Stop

A confirmed protection stop must not be bypassed by renaming, softening, narrowing, or disclaiming the same prohibited judgment inside the same pass.

Invalid same-run reframing includes:

```text
changing whole-person assessment to pattern analysis
changing motive determination to structural tendency
changing maturity ranking to practice profile
changing credibility judgment to coherence analysis
changing diagnosis to model mapping
adding uncertainty language while preserving the same conclusion
adding a disclaimer while preserving the same person-level use
```

The test is substantive, not verbal:

```text
Does the revised output still answer the prohibited person-level question
or serve the same prohibited use?
```

If yes, the stop remains controlling.

A genuinely different scene-bound question requires a new case:

```text
new case title
new case boundary
new intended use
new requested output
renewed source-status review
new Pre-Analysis
renewed Core-entry review
```

### F.14 Redirect After Refusal or Stop

Redirect means that another frame, method, domain process, or separately bounded question may carry the burden more responsibly.

Redirect may point toward:

```text
a rival conceptual account
a domain-specific method
a legal process
a clinical process
a technical audit
an institutional procedure
a factual investigation
a mediation process
a safety review
a non-PMS explanatory frame
a new scene-bound PMS case
```

Where redirect follows refusal or a protection stop, it does not continue the stopped pipeline.

The relationship is:

```text
current requested use
→ refused

current pipeline case
→ stopped

possible receiving direction
→ separately bounded future case or non-PMS process
```

A redirection output must state:

```text
why PMS or the requested PMS path is not appropriate
which receiving frame or process is proposed
what PMS must not claim
what PMS may contribute, if anything
that the current pass remains stopped
what a new case or process would require
```

Redirect is not supplement. It means PMS is not the current primary frame for the burden.

### F.15 Relation Between Decision States

The six final analytical decision states must not be collapsed.

```text
revise ≠ downgrade
downgrade ≠ suspend
suspend ≠ refuse
refuse ≠ redirect
redirect ≠ supplement
proceed ≠ success
non-proceed ≠ failure
stop ≠ final analytical decision state
refusal ≠ permanent prohibition of every related question
redirect ≠ same-run continuation
```

#### Revise vs Downgrade

Use **revise** where the same claim level can remain after correction.

Use **downgrade** where the claim level itself is too strong.

#### Downgrade vs Suspend

Use **downgrade** where a weaker claim can responsibly proceed.

Use **suspend** where even the weaker claim cannot yet be supported because a necessary threshold remains unresolved.

#### Suspend vs Refuse

Use **suspend** where the application may become possible under better conditions.

Use **refuse** where the requested use violates a guardrail or protection boundary.

#### Refuse vs Redirect

Use **refuse** to name the use that must not be performed.

Use **redirect** to name the receiving frame or new case direction.

They may occur together:

```text
requested use refused
current pipeline stopped
future direction redirected
```

#### Final Decision State vs Pipeline Stop

Use a final analytical decision state to name the substantive outcome.

Use pipeline stop to control whether the current workflow may continue.

A stop can occur before a complete analytical outcome exists, or it may accompany refusal or redirection.

### F.16 Stop and Control Language

Recommended language for a pending stop cue:

```text
This condition requires semantic review before Core entry.

The current case must not proceed until the stop condition is resolved.
```

Recommended language for a confirmed pipeline stop:

```text
The requested output is refused under the stated protection boundary.

The current pipeline case is stopped.

Core entry is not permitted.

The only allowed next step in the current pass is stop.

Any safer alternative requires a new, separately bounded case.
```

Recommended language for correction-required status:

```text
The current artefact is not eligible for downstream use.

The complete corrected artefact must be produced and checked before continuation.
```

Avoid language that notes risk without consequence:

```text
Risk noted, but proceed.
Concern recorded, but no change.
Human review recommended, but not required.
Template complete.
AI confidence high.
Threshold probably satisfied.
Stop noted, but user wishes to continue.
Proceed field selected despite stop signal.
```

Risk language is disciplined only when it can affect the application.

### F.17 Downgrade Language

Downgrade language should name the stronger claim that is not licensed and the weaker claim that remains available.

Recommended forms:

```text
The current input does not support an evaluation. It supports only a hypothesis.

This should not be stated as a recommendation. It may be used as orientation.

The available material supports only a scene-bound observation,
not a general person-level conclusion.

The add-on classification is not licensed. At most, the case supports an add-on scan.

The public claim must be downgraded to a private exploratory reading.

The closure status must be downgraded from operationally closed
to supported but limited.
```

Do not use downgrade language where the weaker wording preserves a prohibited person judgment or where a confirmed stop blocks same-run continuation.

### F.18 Refusal Language

Refusal language should be clear, bounded, and non-punitive.

Recommended forms:

```text
This requested use is refused because it would produce
an unsupported person-level verdict.

This application must not proceed because it treats model output as evidence.

This request violates the person-protection boundary
and cannot be answered in the requested PMS form.

This use must be refused because it delegates a non-delegable judgment.

This output must not be produced because correctability is absent.

The current pipeline case is stopped before Core.
```

Refusal should name the use that is refused, not degrade the person making the request or the person under review.

### F.19 Redirection Language

Redirection language should identify the receiving direction and state what PMS must not claim.

Recommended forms:

```text
This matter should be redirected to a domain-specific review
because PMS cannot carry the required burden alone.

A rival account currently discriminates better;
PMS should not remain the primary frame.

This should be redirected to factual investigation
before any new PMS case is considered.

This should be redirected to legal process
rather than PMS-based evaluation.

This should be redirected to technical audit
before any implementation claim is made.

A safer scene-bound PMS question may be possible,
but it requires a new case boundary and new Pre-Analysis.
```

Redirection is not abandonment. It is a disciplined recognition that PMS is not currently the right primary tool or that the current PMS case is not the right boundary.

### F.20 Human Confirmation Without Guardrail Override

Where use is person-near, public, institutional, technical, automated, reputational, article-level, or follow-up-seeding, explicit human confirmation of the final analytical decision and use boundary may be required.

Human confirmation must state:

```text
what was confirmed
what was refused
whether the pipeline stopped
what use remains permitted
what use remains prohibited
whether a new case is required
```

Human confirmation does not:

```text
certify truth
certify safety
certify adequacy
certify closure
turn weak input into strong input
upgrade model output into evidence
override a confirmed protection stop
convert a prohibited output into a permitted one
continue a stopped case under a renamed target
```

The responsible human may:

```text
accept the stop
correct materially wrong source or scope information
request the required semantic review
withdraw the prohibited request
begin a genuinely new case
redirect the matter to an appropriate process
```

The responsible human may not use confirmation as an override token.

Responsibility is not exemption from a guardrail.

### F.21 Annex F Decision Guidance

A final analytical decision state must name what substantive limitation or permission has been reached.

A pipeline-case disposition must state whether the current pass may continue.

Proceed is only one possible disciplined outcome. Revision, downgrade, suspension, refusal, redirection, and pipeline stop are not failures. They are the ways PMS-DISCIPLINE prevents readability from becoming overclaim, person capture, artefact authority, premature closure, or unauthorized continuation.

A discipline without real final decision states cannot constrain use.

A discipline without a binding pipeline stop cannot prevent its own workflow from violating a confirmed protection boundary.

A confirmed stop takes precedence over contradictory proceed language.

A safer question after stop is a new case, not a same-run reformulation.

Human confirmation locates responsibility; it does not override the guardrail.

Stop decisions are not failures of PMS-DISCIPLINE. They are its test.

---

## G. Optional Discipline Burden Scale

### Function of Annex G

Annex G provides an optional orientation scale for estimating discipline burden in PMS-DISCIPLINE use.

The scale is secondary. It is not part of PMS Base. It is not an operator structure. It is not a scoring system. It is not a governance architecture. It does not replace the PMS-DISCIPLINE pass. It does not rank cases mechanically, rank persons, certify safety, authorize outputs, or determine final decision states.

The scale uses B-levels for discipline burden. These are not dignity levels. They do not refer to Dignity-in-Practice, ontological dignity, moral worth, person value, maturity, or dignity ranking.

The burden scale may help estimate:

```text id="vov53b"
how much claim restraint is needed
how much input discipline is needed
how much rival pressure is needed
how much person-nearness caution is needed
how much human confirmation is needed
how much correctability burden exists
how strong stop-capability must be
```

But it may not decide the case. A burden level may raise burden; it may not authorize a claim.

The scale supports judgment only if it remains subordinate to the case-pass and stop-capability.

### Burden Scale Overview

The optional burden levels are:

```text id="gwxws6"
B0 exploratory / private
B1 ordinary analytic
B2 publication-grade
B3 person-affecting
B4 institutional / technical / automated
B5 prohibited / refused
```

These levels are not dignity levels, maturity levels, risk scores for persons, quality grades, or proof of adequacy. They are burden markers for PMS use.

A higher burden level does not mean that PMS is more deeply applied. It means that the use context requires more restraint, clearer input status, stronger rival pressure, more explicit correctability, and stronger stop-capability.

A lower burden level does not mean that discipline is unnecessary. Even B0 exploratory use must remain honest about input status, claim type, and non-authority. The burden is lower, not absent.

### Burden Scale Table

| Level                                      | Typical Use                                                                                                                                                                                                       | Burden Profile                                                                                                            | Required Discipline                                                                                                                                                                                                                         | Possible Final Decision States                                                                 | Stop / Downgrade Cue                                                                                                                                                                                                                     |
| ------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| B0 — exploratory / private                 | Private notes, first-pass orientation, conceptual play, internal sketch, low-stakes reflection.                                                                                                                   | Low publicness, low irreversibility, usually low person-affecting burden. Input may be incomplete if clearly marked.      | Mark input status, keep claim low, avoid person-level verdicts, preserve uncertainty, avoid add-on overuse.                                                                                                                                | proceed, revise, downgrade, suspend, redirect                                                  | Downgrade if exploratory language begins to sound evaluative. Suspend if even orientation depends on unsupported facts or person-near inference.                                                                                         |
| B1 — ordinary analytic                     | Internal analysis, bounded comparison, low-stakes interpretive use, Core pass, limited add-on scan.                                                                                                               | Moderate need for reasons and operator discipline. Publicness and person-nearness remain low or controlled.               | Declare claim type, justify operator salience, mark possible omissions, consider relevant rivals, preserve correctability.                                                                                                                 | proceed, revise, downgrade, suspend, redirect                                                  | Downgrade if the reading climbs from sketch to explanation. Suspend if Core is unstable or add-on trigger is unclear.                                                                                                                    |
| B2 — publication-grade                     | Article-level synthesis, public-facing explanation, published conceptual analysis, broadly circulated PMS reading.                                                                                                | Publicness raises burden. Input status, rival pressure, limits, and reopening conditions must be explicit.                | Strong claim restraint, source distinction, rival pressure, non-use marking, correctability, explicit limits, possible human confirmation.                                                                                                 | proceed, revise, downgrade, suspend, refuse, redirect                                          | Downgrade public claim to private or limited claim if input or rival burden is insufficient. Suspend if publication would harden unresolved claims. Refuse if publication produces unsupported person capture.                           |
| B3 — person-affecting                      | Readings that affect reputation, identity, credibility, maturity, blame, dignity, competence, sexuality, intimacy, employment, access, or social standing.                                                        | High person-nearness burden. Affected-person contestability, dignity preservation, and claim restraint become central.    | Strong input discipline, scene-bound claims, rival pressure, Dignity-in-Practice preservation, non-retaliatory response space, explicit correctability, human confirmation where needed.                                                   | revise, downgrade, suspend, refuse, redirect; proceed only within narrow limits                | Downgrade an overstrong but otherwise permissible person-near claim to a scene-bound observation. Suspend if contestability or input is insufficient. Refuse if the requested use crosses a person-protection boundary.                  |
| B4 — institutional / technical / automated | Institutional uptake, HR-like use, education/care/legal-adjacent context, technical implementation, automated routing, model-mediated workflow, operational system use.                                           | Very high burden. Publicness, irreversibility, automation, institutional authority, and contestability risks may combine. | Domain review where relevant, explicit human confirmation, auditability, no delegated truth, person-judgment, or guardrail-override authority, strong rival pressure, correctability, stop-capability, and limits on PMS authority.          | revise, downgrade, suspend, refuse, redirect; proceed only under strict scope and confirmation | Suspend if human confirmation, auditability, or contestability is absent. Redirect where a domain-specific process carries the burden better. Refuse automated non-delegable judgment or artefact authority. Checked guardrails may still bind pipeline continuation. |
| B5 — prohibited / refused                  | Requested uses that violate guardrails: person ranking, dignity scoring, unsupported person verdicts, automated non-delegable decisions, evidence laundering, closure without correctability, artefact authority. | Use boundary exceeded. The problem is not merely high burden; the requested form of use is not permitted.                 | Refuse the requested use. Where that use controls the purpose of the current case, record `pipeline-case disposition: stop`. A safer lower-burden question may be identified only as the basis of a new, separately bounded case. Preserve dignity and avoid punitive refusal language. | refuse, redirect                                                                               | Refuse when PMS would rank persons, certify maturity or dignity, automate judgment, treat model output as evidence, or close without correction. Do not preserve the prohibited output through same-run downgrade, relabeling, or transformation. |

### Burden Level Is Not a Final Decision State

The burden scale does not replace the canonical final analytical decision states.

The final analytical decision states remain:

```text id="ney1pj"
proceed
revise
downgrade
suspend
refuse
redirect
```

A burden level estimates burden. It does not decide the outcome and it does not replace pipeline-case disposition.

For example:

```text id="z0l6s2"
B0 may still require suspend if input is too unclear even for orientation.

B1 may require downgrade if the claim climbs too high.

B2 may proceed only within publication-grade limits.

B3 may proceed only if person-nearness burden is handled; otherwise it may require downgrade, suspension, refusal, or redirection.

B4 may require domain review, human confirmation, suspension, refusal, redirection, or a pipeline stop where a checked guardrail blocks continuation.

B5 names a prohibited requested use, not a bad person or bad case. Where the prohibited use controls the case purpose, the requested output is refused and the current pipeline case stops.
```

The scale therefore supports the pass; it does not replace the pass.

### Burden Level Must Not Rank Persons

The burden scale applies to use contexts, not to persons.

It must never be used to rank a person’s dignity, maturity, competence, credibility, responsibility, or worth. It does not say that a person is B3 or B4. It says that a proposed PMS use has B3 or B4 burden because of its possible effect, publicness, irreversibility, institutional uptake, technical mediation, or person-nearness.

Correct usage:

```text id="zcm1xw"
This proposed use has B3 burden because it affects reputation and credibility.

This output has B4 burden because it may enter an institutional workflow.

This request is B5 because it asks for an unsupported person-level verdict.
```

Incorrect usage:

```text id="uqk54d"
This person is B3.

This person is a B4 case.

This subject is B5.

This person’s maturity level is B2.
```

Burden levels mark discipline burden. They do not describe persons.

### Burden Level Does Not Authorize Stronger Claims

A higher burden level never authorizes a stronger claim.

Higher burden usually requires weaker claims, not stronger claims. A B3 person-affecting use may require a scene-bound observation instead of a stronger person-near claim. A B4 institutional or technical use may require suspension, refusal, redirection, or pipeline stop rather than stronger PMS integration. A B5 requested use must be refused. A safer question, if one is available, begins as a new, separately bounded case rather than as a same-run transformation of the prohibited output.

This is the central rule:

```text id="cb454o"
Higher burden raises restraint.
It does not raise authority.
```

A burden level may increase the need for:

```text id="d1srga"
weaker claims
clearer input status
stronger rival pressure
person-nearness caution
human confirmation
domain review
correctability
stop-capability
downgrade
suspension
refusal
redirection
```

It may not certify that the output is safe, true, adequate, or authorized.

### Relation to Case-Pass Record

The burden scale should be recorded only as an orientation marker.

Recommended field:

```text id="pphq9k"
Optional burden estimate:
Reason for burden estimate:
What burden this raises:
What decision state follows:
```

The record should never include only a burden level without reasons.

Bad form:

```text id="j65t9d"
B3. Proceed.
```

Disciplined form:

```text id="h75cz0"
Optional burden estimate: B3 person-affecting.
Reason: The reading may affect credibility and reputation.
Raised burden: person-nearness, rival pressure, contestability, and human confirmation.
Decision state: downgrade to scene-bound observation; no person-level claim licensed.
```

The burden estimate must state what it changes. If the burden level does not alter claim strength, input burden, rival pressure, correctability, human confirmation, or stop-capability, it has become decorative.

### Escalation and De-Escalation

A PMS use may move between burden levels when its use context changes.

Escalation occurs when a reading moves toward stronger, more public, more irreversible, more person-near, more institutional, more technical, or more automated use.

Examples:

```text id="nwqzxl"
private note → public article
orientation → recommendation
scene-bound observation → person-level implication
manual review → automated routing
conceptual analysis → institutional uptake
AI-assisted draft → published synthesis
```

De-escalation occurs when an overstrong but otherwise permissible use is deliberately weakened, narrowed, privatized, made reversible, removed from person-level implication, or redirected to a lower-burden purpose.

Examples:

```text id="yxdzgt"
public claim → private exploratory note
recommendation → orientation
person-level claim → scene-bound observation
add-on classification → add-on scan
institutional use → non-operational conceptual review
technical implementation → audit question
```

Escalation requires renewed discipline. De-escalation may permit continued use only where the original output has not crossed a protection boundary and the lower burden is actually reflected in the claim, circulation, correction path, and permitted next steps.

Where a confirmed protection stop or B5 boundary applies, de-escalation does not permit same-run continuation. A safer lower-burden question, if available, requires a new case boundary, a new intended use, a new requested output, and a new Pre-Analysis.

### Abuse of the Burden Scale

The burden scale becomes abusive when it begins to function as architecture, authority, ranking, or shortcut.

Failure modes include:

```text id="t7hmdy"
burden level used as output authorization
burden level used as safety certificate
burden level used as person score
burden level used as maturity rating
burden level used to bypass case-pass fields
burden level used to replace rival pressure
burden level used to justify automated routing
burden level used to avoid human confirmation
burden level used as governance category
burden level used to make refusal appear mechanical
```

The protective rule is:

> If the burden scale becomes the architecture, PMS-DISCIPLINE starts behaving like the kind of artefact stack it is meant to discipline.

The scale is useful only when it remains subordinate to the case-pass, final decision state, and stop-capability.

### Annex G Decision Guidance

Use the burden scale only when it clarifies the burden of use.

Do not use it when it would create false precision, ranking, governance appearance, or shortcut reasoning. Do not use it when ordinary claim-type and input-status discipline is sufficient. Do not use it when it would make a person-near reading appear administratively handled.

A burden level may help ask:

```text id="gnb81k"
Should the claim be weaker?
Should input status be clearer?
Should rival pressure be stronger?
Should person-nearness be marked?
Should human confirmation be required?
Should correctability be strengthened?
Should the application be downgraded, suspended, refused, or redirected?
```

A burden level may not answer those questions by itself.

The burden scale is an orientation aid, not an architecture.

---

## H. YAML Interface, Case-Record Pipeline, Iteration Handoff, and Markdown Rendering

### Function of Annex H

Annex H fixes the status, dependency order, source boundaries, and maintenance role of the PMS-DISCIPLINE repository instruments.

The YAML templates, check prompts, manual prompt sequence, Case Record instruments, Iteration Handoff template, and Markdown article instructions are implementation-facing artefacts. They support disciplined PMS use by making entry control, path selection, source status, claim burden, add-on routing, non-use, review pressure, downstream-layer eligibility, Case Record integration, future-work preparation, and article rendering more inspectable.

They do not replace PMS.yaml. They do not replace the PMS-DISCIPLINE paper. They do not validate PMS. They do not certify truth. They do not authorize claims. They do not govern cases. They do not issue person-level judgments. They do not execute final analytical decision states as independent authorities. They do not make workflow completion equivalent to adequate use.

Their function is practical and bounded:

```text
make the application path inspectable
preserve source and input limits
formalize Pre-Analysis and Core-entry control
separate requested-output disposition from pipeline-case disposition
identify the effective checked artefact at each review point
separate Core, one selected PMS add-on, MIP, AHP, and Case Record layers
mark non-use, rejection, unavailability, and stop
preserve rival pressure and falsifier conditions
prevent Case Record integration from becoming new analysis
prepare iteration without inheritance
prevent Markdown rendering from becoming new analysis
keep examples from becoming evidence
support correction, downgrade, suspension, refusal, redirection, and pipeline stop
```

The repository instruments therefore belong to PMS-DISCIPLINE only as supports for disciplined use. They are not a second foundation for PMS.

A repository artefact may control downstream workflow eligibility without becoming an authority over truth. This distinction is necessary wherever a checked stop prevents later stages from treating a case as eligible input.

---

### H.1 Source Hierarchy and Effective Checked Artefacts

The PMS-DISCIPLINE repository presupposes two related hierarchies:

```text
a conceptual source hierarchy

and

a run-specific effective-artefact hierarchy
```

They must not be collapsed.

#### Conceptual Source Hierarchy

```text
PMS.yaml
= repository reference specification of PMS Base

PMS-DISCIPLINE paper
= conceptual and methodological account of disciplined PMS use

Repository templates and instructions
= implementation instruments derived from the paper

Checked case outputs
= bounded run artefacts produced through the declared workflow

Case Record
= provenance-controlled integration of eligible checked case outputs

Iteration Handoff
= prospective preparation for a possible future case

Markdown articles
= human-readable renderings of the checked record
```

PMS.yaml remains the base grammar reference. PMS-DISCIPLINE does not revise PMS operators, add new PMS operators, alter the dependency path, or turn add-on constructs into PMS Base.

The PMS-DISCIPLINE paper defines the application discipline. Repository templates and instructions operationalize that discipline for repeatable case work.

A template may support discipline, but it does not create authority. A checked output may become the effective workflow artefact, but it does not become evidence merely because it was checked. A Case Record may integrate eligible layers, but it does not become a verdict. An Iteration Handoff may prepare future work, but it does not become a current-case finding. A rendered article may communicate a case, but it does not create evidence or reopen analysis.

#### Effective Checked-Artefact Rule

At every template-and-check pair, the workflow must identify one effective checked artefact.

The governing rule is:

```text
If the check result is ready:
the complete original artefact reviewed by that check
remains the effective checked artefact.

If the check result is corrected:
the complete corrected artefact emitted through the check
becomes the effective checked artefact.

If the check result is not ready:
no version of that artefact is eligible for downstream use.

If the check confirms pipeline stop:
the complete stop-confirming checked artefact is effective
for recording the stop,
but it is not eligible as input to Core or later analytical stages.
```

A corrected artefact supersedes the original artefact for downstream use.

The downstream order is therefore:

```text
complete corrected YAML, where present
→ otherwise complete original YAML with ready status
→ never an unchecked or superseded version
```

A correction list, patch description, audit summary, reviewer explanation, or prose account of defects is not a substitute for the complete corrected YAML.

#### Audit Prose Is Not a Case Source

Check and audit prose may explain:

```text
what was reviewed
what was defective
what was corrected
why an artefact is ready, corrected, not ready, or stopped
```

That prose is not a substantive source for later case findings.

The following must not be treated as case evidence or analytical content:

```text
audit commentary
check rationale
lists of exact patches
reviewer confidence language
workflow status explanation
validation-style prose
```

Where the check emits a complete corrected artefact, later stages use that corrected artefact. They do not mine the surrounding audit prose for new findings.

#### Stage Hierarchy for Case Record, Iteration, and Article Use

Once the Case Record chain is complete and checked, the governing source order for both Iteration Handoff preparation and article rendering is:

```text
Stage 3 — Full Case Record
→ Stage 2 — Layer Digests
→ Stage 1 — Artifact Index and provenance
```

Stage 3 is the primary integrated source.

Stage 2 may be consulted for layer-specific support, limits, tensions, and non-use records.

Stage 1 may be consulted for provenance, artefact eligibility, version status, missing items, skipped branches, and supersession.

Original checked analytical YAML artefacts should be consulted directly only where the checked Stage 2 or Stage 3 record identifies:

```text
a gap
a conflict
an unresolved provenance issue
a missing detail
a verification need
```

This hierarchy prevents later outputs from reconstructing a new analysis from the entire raw workflow stack.

#### Iteration Handoff Is Not a Source for Current Case Findings

The Iteration Handoff is downstream of the checked Case Record.

It may record:

```text
current sufficiency
iteration value
iteration urgency
possible follow-up questions
future material needs
future case boundaries
non-inheritance limits
```

It must not become a source for current Case Record findings, current claim support, operator assignment, add-on selection, MIP or AHP conclusions, rival outcomes, or final analytical decision states.

The direction is:

```text
checked Case Record
→ optional Iteration Handoff
```

It is not:

```text
Iteration Handoff
→ retroactive current-case finding
```

#### Articles Are Never Sources for Iteration Handoff

The Iteration Handoff is prepared before the article workflow.

Article drafts, example decisions, generated examples, final integrated articles, article-profile choices, and final article checks must never become sources for Iteration Handoff findings.

The prohibited direction is:

```text
article prose
→ Iteration Handoff conclusion
```

The permitted direction is:

```text
checked Case Record
→ optional Iteration Handoff
→ optional article rendering
```

A later article may present a prospective question already supported by the checked Iteration Handoff. It may not originate or strengthen that question as an analytical finding.

#### Examples Remain Non-Evidence

Generated examples may illustrate an already supported structure. They may help readers understand an operator relation, add-on distinction, Case Record finding, or boundary condition.

They do not become:

```text
case material
source confirmation
corroboration
evidence
new input
rival defeat
claim support
```

Example generation belongs to article presentation, not to the evidentiary or analytical source hierarchy.

---

### H.2 Current Repository Instrument Set

The current PMS-DISCIPLINE repository instrument set should be understood in functional groups rather than as four undifferentiated file classes.

The exact repository filenames may evolve. The methodological functions and dependency order must remain stable.

#### Group 1 — Base Reference and Manual Orchestration

```text
PMS.yaml

PMS-DISCIPLINE Prompts and Instructions Manual
```

PMS.yaml is the PMS Base reference.

The manual prompt sequence is the human-operated orchestration instrument. It defines the full review order, conditional branches, stop protocol, effective checked-artefact handling, MIP/AHP dependencies, Case Record sequence, Iteration Handoff, article profiles, example decision, and final article check.

The manual is not case evidence and does not itself authorize a route. It structures responsible execution of the repository instruments.

#### Group 2 — Entry Control and Core Instruments

```text
pms_discipline_pre_analysis_template.yaml
Pre-Analysis application prompt
Pre-Analysis check and conservative-correction prompt

pms_core_case_application_template.yaml
Core application prompt
Core check and conservative-correction prompt
```

The Pre-Analysis instruments establish:

```text
case and scope boundary
input and source status
intended use
requested output
requested-output disposition
pipeline-case disposition
preliminary claim ceiling
protection conditions
Core-entry eligibility
next allowed step
```

Only the effective checked Pre-Analysis may become Core input.

The Core instruments establish the bounded PMS Core reading, operator salience, possible omissions, derived-structure limits, and Core claim boundary.

Core checking determines the effective checked Core artefact. It does not certify truth.

#### Group 3 — PMS Add-on Routing, Applications, and Checks

```text
pms_discipline_addon_recommendation_gate_template.yaml
Add-on Recommendation Gate application prompt
Add-on Recommendation Gate check and conservative-correction prompt

selected PMS add-on source
pms_addon_SELECTED_ADDON_case_application_template.yaml
selected add-on application prompt
selected add-on check and conservative-correction prompt
```

The PMS add-on set is limited to:

```text
ANTICIPATION
CRITIQUE
CONFLICT
LOGIC
EDEN
SEX
```

A single bounded pass selects at most one PMS add-on.

If several PMS add-on questions are materially relevant, they are handled as separately bounded subcases. Their checked records may later be compared or integrated.

The Add-on Recommendation Gate is not an authorization engine. The selected add-on application remains subordinate to the checked Core output, its own source, its trigger and non-trigger conditions, claim ceiling, rivals, and correction boundary.

Every selected add-on application requires its own check.

#### Group 4 — MIP Instruments

```text
pms_discipline_mip_gate_template.yaml
MIP Gate application prompt
MIP Gate check and conservative-correction prompt

MIP source-reading prompt
MIP Case Application prompt
MIP Case Application check and conservative-correction prompt
```

MIP is a downstream own-output layer, not a PMS add-on.

The checked MIP Gate supports the binary human route:

```text
do not use MIP

or

use MIP
```

MIP Source Reading and MIP Case Application remain distinct.

A source-reading recommendation may prepare responsible use. It does not create a third route and does not produce case findings.

Where MIP is used, the application mode may be:

```text
supported MIP Case Application

or

Conditional Transfer / Boundary Use
```

Conditional Transfer / Boundary Use may examine burden, boundaries, red zones, claim restraint, and misuse risk. It may not evaluate a real person through hard A/M scoring, D activation, IA/D verdicting, maturity ranking, developmental evaluation, or whole-person assessment.

The MIP Case Application requires its own check.

#### Group 5 — AHP Instruments

```text
pms_discipline_ahp_gate_template.yaml
AHP Gate application prompt
AHP Gate check and conservative-correction prompt

AHP application prompt
AHP output check and conservative-correction prompt
```

AHP is available only after an actual MIP Case Application was produced, checked, and found eligible for downstream use.

AHP does not become available through:

```text
MIP mention
MIP vocabulary
MIP Source Reading
MIP Gate recommendation
unexecuted MIP relevance
general evaluative pressure
```

AHP remains a second-order analysis-quality overlay.

It may not:

```text
correct or replace MIP
reanalyze the underlying person
rescore MIP
activate D
change IA/D status
upgrade evidence
raise the claim ceiling
certify maturity
become an authority layer
```

#### Group 6 — Case Record Instruments and Checks

```text
pms_case_record_stage_1_artifact_index_template.yaml
Stage 1 application prompt
Stage 1 check and conservative-correction prompt

pms_case_record_stage_2_layer_digest_extraction_template.yaml
Stage 2 application prompt
Stage 2 check and conservative-correction prompt

pms_case_record_stage_3_full_case_record_integration_template.yaml
Stage 3 application prompt
Stage 3 check and conservative-correction prompt
```

The Case Record chain converts eligible checked workflow artefacts into:

```text
Stage 1 — provenance and eligibility control
Stage 2 — bounded layer digests
Stage 3 — integrated Full Case Record
```

Each stage requires a distinct generation artefact and check artefact.

The Case Record does not generate new case findings.

#### Group 7 — Iteration Handoff Instrument

```text
pms_discipline_iteration_handoff_template.yaml
Iteration Handoff and follow-up preparation prompt
```

The Iteration Handoff follows the checked Stage 3 Full Case Record.

It is not:

```text
Case Record Stage 4
a new analysis layer
a reopening decision
a route inheritance instrument
an article product
```

It preserves the distinction between:

```text
current sufficiency
iteration value
iteration urgency
follow-up-case preparation
```

#### Group 8 — Multi-Step Article Workflow

The article workflow is not one general rendering operation. It contains distinct instruments or manual prompt steps for:

```text
Article Source Setup and Rendering Contract
Base Markdown Case Article Draft
Example Decision and Optional Example Generation
Final Integrated Markdown Case Article
Final Article Check and Conservative Patch
```

The workflow supports at least two presentation profiles:

```text
case_article

full_analysis_article
```

The selected article profile affects presentation depth and structure. It does not alter case findings, source status, route state, claim ceiling, or decision authority.

The Example Decision determines whether generated examples are included.

If no example is generated, the Base Markdown Draft becomes the final article candidate and proceeds directly to the Final Article Check. A Final Integrated Article step must not be fabricated merely to preserve sequence appearance.

The Final Article Check remains a presentation, fidelity, and boundary check. It does not perform new analysis, strengthen claims, or reopen the Case Record.

---

### H.3 Case-Record Pipeline and Lifecycle Boundaries

The PMS-DISCIPLINE Case Record pipeline proceeds through three record stages only where the permitted analytical route has produced eligible checked artefacts.

A case stopped before Core does not enter the Case Record pipeline. Where archival or provenance preservation is required, the stopped run may produce a standalone stop manifest. That manifest is not Case Record Stage 1, does not imply that analytical artefacts exist, and must not be used as input to Stage 2 or Stage 3.

A record-only cross-subcase integration is a separate bounded integration run whose inputs are the effective checked Full Case Records of the relevant subcases. Its output should be identified as a Cross-Subcase Integration Record rather than as another subcase Full Case Record.

The Cross-Subcase Integration Record may compare findings, limits, tensions, agreements, incompatibilities, dependencies, or sequences already explicit in or directly supported by the checked Full Case Records. It does not reopen the raw analytical artefacts, merge claim ceilings, become Case Record Stage 4, or create new substantive findings.

Where the relation between the subcases itself requires new causal, structural, evaluative, or person-level inference, record-only integration is insufficient. That question requires a new, separately bounded analytical integration case with its own pre-entry review, checked Pre-Analysis, source status, intended use, Core pass, at most one selected PMS add-on, rival review, claim ceiling, correctability conditions, and final analytical decision state.

#### Stage 1 — Artifact Index / Run Manifest

Stage 1 lists:

```text
which eligible analytical artefacts exist
which expected artefacts do not exist
which branches were skipped
which branches were unavailable
which versions are current
which versions are superseded
which artefacts are checked
which artefacts are eligible for Stage 2
which pipeline and final-decision boundaries constrain downstream use
```

Stage 1 does not analyze the case.

Stage 1 may index a refusal, suspension, redirect, or other bounded analytical outcome where actual checked analytical artefacts exist. It must not fabricate Core or downstream artefacts for a pass stopped before Core.

#### Stage 2 — Layer Digest Extraction

Stage 2 reads only Stage-1-selected effective checked artefacts.

It extracts bounded layer digests without copying the entire YAML stack and without reanalyzing the case.

It records:

```text
what each eligible layer contributes
what each layer does not claim
which claim ceiling controls it
which rivals remain live
which risks remain unresolved
which non-use and rejection decisions matter
which provenance references support the digest
```

Stage 2 does not repair upstream analysis by silently rewriting it. If a substantive defect is discovered, the relevant upstream artefact must be corrected through its proper check or the run must be revised, suspended, refused, redirected, or stopped.

#### Stage 3 — Full Case Record Integration

Stage 3 integrates the checked Stage-2 digests into a report-ready Full Case Record.

It preserves:

```text
case boundary
input and source status
intended use
requested-output disposition
pipeline-case disposition
claim ceiling
Core result
single selected add-on or Core-only status
MIP and AHP route states, where present
rival and non-capture record
falsifier and reopening conditions
unresolved risks
final analytical decision state
permitted and prohibited next steps
report-readiness information
```

Stage 3 performs record-level integration only. It does not create new substantive findings, infer new cross-subcase conclusions, repair upstream analysis, or convert several subcase records into a retrospective multi-add-on pass.

Where a proposed whole-case relation requires new analysis, Stage 3 must mark that relation as unavailable and identify the need for a new, separately bounded analytical integration case.

#### Stage-3 Generation Status, Check Status, and Pipeline Control

The Stage-3 generation artefact and the Stage-3 check artefact must remain distinct.

The Stage-3 generation artefact may contain the generation-time lifecycle value:

```text
ready_for_output_check
```

That value records the state of the workflow when Stage 3 was generated.

The later Stage-3 check records one separate check status:

```text
ready
corrected
not_ready
```

`stop` is not a Stage-3 check status. It is a pipeline-control disposition and must be recorded separately as `pipeline-case disposition: stop` where a checked protection, eligibility, or use boundary prevents downstream continuation.

The lifecycle relation is:

```text
Stage 3 generation status
= status at the moment of Stage 3 production

Stage 3 check status
= readiness result of the later Stage 3 review

pipeline-case disposition
= whether downstream workflow continuation is permitted
```

The later check does not retroactively make a valid generation-time status false merely because the check has now occurred.

A Stage-3 correction is required only where the generation-time field was already inconsistent with the route, violated the template, omitted a controlling boundary, or created a substantive contradiction.

If the Stage-3 check emits a complete corrected Stage-3 artefact, that corrected artefact becomes the effective checked Stage 3 source.

Where the Stage-3 check confirms a pipeline stop, the effective checked Stage 3 must record that stop and the prohibited downstream steps. A corrected stop-confirming Stage 3 may remain the archival Full Case Record of work already completed, but it may not feed an Iteration Handoff or article workflow where the stop prohibits those steps.

The check prose remains separate from the checked Full Case Record.

#### No Stage 4

The Iteration Handoff is downstream of effective checked Stage 3, but it is not Case Record Stage 4.

The relation is:

```text
Stage 1
→ Stage 1 Check
→ Stage 2
→ Stage 2 Check
→ Stage 3
→ Stage 3 Check
→ optional Iteration Handoff, only if permitted
→ optional Article Workflow, only if permitted
```

The Iteration Handoff does not extend the Case Record chain and does not add current-case findings.

#### Article Flow After Optional Iteration Handoff

Where an Iteration Handoff is selected and permitted, it is prepared before article rendering.

The source flow is:

```text
effective checked Stage 3
→ optional support from checked Stage 2
→ optional provenance from checked Stage 1
→ optional Iteration Handoff
→ Article Source Setup
→ Base Article Draft
→ Example Decision
→ optional Final Integrated Article
→ Final Article Check
```

The article may present the current result and, where appropriate, a bounded future-work outlook already supported by the Iteration Handoff.

The article must not become a source for the Handoff.

#### Governing Relation

```text
standalone stop manifest
= archival record of a run stopped before the Case Record pipeline

Stage 1
= what eligible analytical artefacts exist, which are effective,
  and what may be used

Stage 2
= what each eligible layer contributes and limits

Stage 3
= integrated Full Case Record without new analysis

Iteration Handoff
= prospective preparation from the effective checked record

Markdown article
= presentation of the checked record and,
  where permitted, its already grounded prospective boundary
```

Integration is not authority. Iteration is not inheritance. Rendering is not evidence.

---

### H.4 Standard Conditional Workflow Sequence

The standard PMS-DISCIPLINE workflow is a conditional accountability sequence.

It is not a requirement that every run execute every layer.

#### 0. Pre-Entry Analyst Review

Before the formal prompt sequence begins, the responsible analyst should ask:

```text
Why is PMS being used?
Why is this subject being treated in this form?
What output is sought?
What practical effect is intended?
Who may be affected?
Should this application begin?
```

Where the requested treatment is already clearly inappropriate, person-capturing, non-delegable, or better handled elsewhere, the analyst may refuse or redirect before Pre-Analysis.

#### 1. Base and Case-Material Setup

```text
read PMS.yaml
identify the case material
declare the case boundary
declare source and input status
declare intended use and requested output
```

#### 2. Pre-Analysis and Entry Check

```text
apply Pre-Analysis
check Pre-Analysis
identify the effective checked Pre-Analysis
```

The effective checked result determines one of three broad paths:

```text
Core entry permitted

correction required before Core

current pipeline case stopped
```

If the checked result is stop:

```text
record requested-output disposition
record pipeline-case disposition: stop
record the controlling protection or scope reason
record next allowed step: stop
do not produce Core or later analytical outputs
treat any redirect as a new separately bounded case
end the current pass
```

In a manual shortcut or Fast Mode where the semantic check is intentionally omitted, an existing Pre-Analysis stop signal remains binding. Review omission does not convert stop into proceed.

#### 3. Core Application and Check

If Core entry is permitted:

```text
apply PMS Core
check PMS Core
identify the effective checked Core artefact
```

If Core is not ready, unstable, or blocked, later add-on precision must not compensate for the defect.

#### 4. PMS Add-on Gate, Selection, Application, and Check

```text
apply Add-on Recommendation Gate
check Add-on Recommendation Gate
decide Core-only, add-on non-use, add-on rejection,
or exactly one selected PMS add-on
```

If several add-on questions appear materially relevant:

```text
perform decomposition review
create separately bounded subcases
do not mix add-ons inside one pass
```

If one PMS add-on is selected:

```text
read the selected add-on source
apply the selected add-on
check the selected add-on output
identify the effective checked add-on artefact
```

#### 5. MIP Gate, Source Reading, Application, and Check

Where actual downstream MIP burden is present:

```text
apply MIP Gate
check MIP Gate
make the binary human route decision:
- do not use MIP
- use MIP
```

Routine process, deadline, delay, option loss, ordinary workflow friction, general responsibility language, and hypothetical real-person reference are not sufficient triggers by themselves.

Where MIP is used:

```text
read MIP source where needed
select the MIP application mode
apply MIP
check MIP
identify the effective checked MIP artefact
```

The application mode may be:

```text
supported MIP Case Application

or

Conditional Transfer / Boundary Use
```

Conditional Transfer / Boundary Use must not perform hard A/M scoring, D activation, IA/D verdicting, maturity ranking, developmental evaluation, or whole-person assessment.

#### 6. AHP Gate, Application, and Check

AHP is available only if an actual checked MIP Case Application exists.

Where that prerequisite is met:

```text
apply AHP Gate
check AHP Gate
if selected, apply AHP
check AHP
identify the effective checked AHP artefact
```

AHP does not correct or replace MIP, rescore it, activate D, change IA/D status, upgrade evidence, raise the claim ceiling, certify maturity, or become an authority layer.

#### 7. Case Record Stage 1 and Check

```text
generate Artifact Index / Run Manifest
check Stage 1
identify the effective checked Stage 1 artefact
```

#### 8. Case Record Stage 2 and Check

```text
generate Layer Digest Extraction from checked Stage 1 selections
check Stage 2
identify the effective checked Stage 2 artefact
```

#### 9. Case Record Stage 3 and Check

```text
generate Full Case Record Integration
preserve its generation-time lifecycle status
check Stage 3
record the distinct Stage-3 check status
identify the effective checked Stage 3 artefact
```

#### 10. Optional Iteration Handoff

Where future work is materially indicated:

```text
prepare Iteration Handoff from the effective checked Case Record
separate current sufficiency, iteration value,
iteration urgency, and follow-up preparation
preserve non-inheritance
```

The Handoff is not Stage 4 and is not sourced from article prose.

#### 11. Optional Multi-Step Article Workflow

Where article generation is selected:

```text
select article profile:
- case_article
- full_analysis_article

establish Article Source Setup and Rendering Contract

produce Base Markdown Draft

make Example Decision

if examples are generated:
produce Final Integrated Article

if no examples are generated:
use the Base Markdown Draft as the final article candidate

run Final Article Check and Conservative Patch
identify the effective checked article artefact
```

The article workflow is downstream presentation. It does not perform new analysis or create new Case Record findings.

#### Conditionality Rule

The route is not:

```text
all steps must run
```

The route is:

```text
each step may run only if the effective checked upstream state permits it
```

Permitted disciplined outcomes include:

```text
pre-entry refusal or redirect
checked stop before Core
Core-only
Core plus one PMS add-on
MIP non-use
Conditional Transfer / Boundary Use
AHP non-use
revision
downgrade
suspension
refusal
redirection
checked Case Record without article
Iteration Handoff without article
article without generated examples
```

Workflow completion is not proof of adequacy.

---

### H.5 Input / Output Boundaries

Each repository instrument has a bounded input role, output role, and non-authority limit.

#### Pre-Analysis

**Inputs:**

```text
case material
source and input status
case boundary
intended use
requested output
risk context
person-nearness and publicness context
```

**Outputs:**

```text
preliminary scope boundary
source-status map
preliminary claim ceiling
requested-output disposition
pipeline-case disposition
Core-entry eligibility
protection conditions
rival pressure
next allowed step
```

The Pre-Analysis may:

```text
permit Core entry

permit continuation only after correction or within an explicit restriction

stop the current pipeline case before Core
```

Only the effective checked Pre-Analysis may become Core input.

If the checked Pre-Analysis stops the current case:

```text
no Core output is produced
no add-on output is produced
no MIP or AHP output is produced
no analytical Case Record is fabricated
no Iteration Handoff is derived from nonexistent analysis
no article is rendered as though analysis occurred
```

A stop record may still be preserved for accountability.

#### Core Case Application

**Inputs:**

```text
PMS.yaml
effective checked Pre-Analysis
declared case material
```

**Outputs:**

```text
bounded Core structural reading
operator salience
possible operator omissions
derived-structure notes
Core instability
Core claim boundary
export material for add-on review
```

The Core output must be checked before later routing.

#### Add-on Recommendation Gate

**Inputs:**

```text
effective checked Core artefact
effective checked Pre-Analysis
case and claim boundary
```

**Outputs:**

```text
Core-only recommendation
add-on non-use
add-on rejection
exactly one selected PMS add-on
decomposition requirement
claim or stop pressure
```

It does not authorize multiple PMS add-ons in one bounded pass.

#### Selected PMS Add-on Application

**Inputs:**

```text
selected add-on source
effective checked Core artefact
effective checked Add-on Gate artefact
case boundary
```

**Outputs:**

```text
one subordinate add-on reading
trigger and non-trigger account
claim contribution
non-authorization boundary
rival and correction pressure
```

The selected add-on may sharpen visibility. It may not rewrite Core, merge with another PMS add-on, or raise claim authority.

#### MIP Gate

**Inputs:**

```text
effective checked Core artefact
effective checked selected-add-on artefact, where present
case boundary
intended use
person-nearness and evaluative burden
```

**Outputs:**

```text
MIP relevance assessment
MIP source-read recommendation
binary route preparation
application-mode constraints
person-protection conditions
```

The MIP Gate does not perform MIP and does not produce person findings.

The human route remains:

```text
do not use MIP

or

use MIP
```

#### MIP Source Reading

**Inputs:**

```text
MIP source
declared reading purpose
```

**Outputs:**

```text
source-faithful concepts
limits
red zones
application modes
non-use conditions
```

It does not produce case findings.

#### MIP Case Application

**Inputs:**

```text
MIP source or eligible source reading
effective checked MIP Gate
effective checked Core and selected-add-on artefacts
declared MIP application mode
```

**Outputs:**

```text
bounded MIP Case Application
or
Conditional Transfer / Boundary Use output
```

Conditional Transfer / Boundary Use may assess burden, boundaries, red zones, claim restraint, and misuse risk.

It may not perform:

```text
real-person maturity assessment
hard A/M scoring
D activation
IA/D verdicting
developmental ranking
whole-person judgment
```

The MIP output requires its own check.

#### AHP Gate and Application

**Inputs to AHP Gate:**

```text
actual effective checked MIP Case Application
its source and claim boundary
case-use context
```

**Outputs of AHP Gate:**

```text
AHP non-use
or
bounded AHP eligibility
```

**Inputs to AHP Application:**

```text
effective checked MIP artefact
effective checked AHP Gate
```

**Outputs:**

```text
second-order analysis-quality overlay
boundary and hardening-risk review
public-transmission and misuse-surface review
```

AHP may not rescore MIP, activate D, change IA/D status, upgrade evidence, raise the claim ceiling, or become an authority layer.

Both AHP Gate and AHP Application require their own checks.

#### Case Record Stage 1

**Inputs:**

```text
available run artefacts
their check states
route decisions
stop and skip states
```

**Outputs:**

```text
artefact inventory
version and supersession status
eligibility decisions
provenance map
Stage-2 selection
```

Stage 1 does not analyze the case.

#### Case Record Stage 2

**Inputs:**

```text
effective checked Stage 1
Stage-1-selected eligible checked artefacts
```

**Outputs:**

```text
bounded layer digests
layer contributions
layer limits
non-use and rejection records
rival and unresolved-risk records
```

Stage 2 does not create new case findings.

#### Case Record Stage 3

**Inputs:**

```text
effective checked Stage 2
effective checked Stage 1 for provenance
```

**Outputs:**

```text
integrated Full Case Record
generation-time lifecycle status
report-readiness information
```

The later Stage-3 check produces a separate check result and, where needed, a complete corrected Stage-3 artefact.

The checked Stage 3 remains the primary source for downstream Handoff and article work.

#### Iteration Handoff

**Inputs:**

```text
effective checked Stage 3
optional checked Stage 2 support
optional checked Stage 1 provenance
```

**Outputs:**

```text
current sufficiency
iteration value
iteration urgency
follow-up question
future boundary
required new material
non-inheritance limits
```

It does not produce current Case Record findings and does not inherit route authority into a future case.

It is prepared before article rendering.

#### Article Source Setup and Profile Selection

**Inputs:**

```text
effective checked Stage 3
optional checked Stage 2 support
optional checked Stage 1 provenance
optional independently grounded Iteration Handoff
selected article profile
```

**Outputs:**

```text
rendering contract
source boundaries
profile choice
claim and example restrictions
```

Article profiles affect presentation only.

#### Base Markdown Draft

**Inputs:**

```text
Article Source Setup
eligible checked record sources
```

**Outputs:**

```text
base prose rendering
```

It does not add analysis.

#### Example Decision

**Inputs:**

```text
base article
checked record boundaries
case suitability for examples
```

**Outputs:**

```text
generate examples
or
do not generate examples
```

Examples remain non-evidence.

#### Final Integrated Article

This step runs only where examples were generated.

It integrates the already bounded example into the base article without changing the analysis.

If no example was generated, the Base Markdown Draft becomes the final article candidate.

#### Final Article Check

**Inputs:**

```text
final article candidate
Article Source Setup
effective checked Stage 3
optional Stage 2 and Stage 1 support
optional Iteration Handoff
```

**Outputs:**

```text
presentation and fidelity status
conservative presentation corrections
complete effective checked article artefact, where corrected
```

The Final Article Check remains a presentation, fidelity, source-boundary, and claim-restraint check.

It does not:

```text
perform new analysis
change the Case Record
generate new findings
upgrade evidence
raise the claim ceiling
override a stop
authorize publication by itself
```

#### Atomic Interface Values

Where any repository template or prompt defines explicit allowed values, those values must remain atomic.

They must not be combined, paraphrased, or expanded into unrecognized compound values.

For example:

```text
counter_scene_material: absent
```

must use the exact allowed token where the schema defines it.

Likewise, reopening categories must use:

```text
new evidence
scope change
demonstrated error
stronger rival
other
```

Conceptual nuance belongs in explanation fields, not in altered enum values.

Annex H does not need to theorize every interface token individually. It establishes the general requirement that explicit interface enums remain exact and atomic.

---

### H.6 Repository Maintenance Status

The present paper revision was triggered by an architecture-level synchronization review.

It was not limited to isolated cosmetic field corrections.

The review identified repository developments that affected the methodological description of:

```text
Pre-Analysis and Core-entry control
checked stop behavior
requested-output and pipeline-case separation
effective checked-artefact precedence
Single-Add-on routing
MIP Source Reading and binary route control
Conditional Transfer / Boundary Use
AHP dependency
Case Record checks and lifecycle
Iteration Handoff placement
multi-step article rendering
article profiles and Example Decision
```

Because these changes affect dependency order, protection behavior, source hierarchy, and the meaning of workflow continuation, the paper required revision.

This does not mean that every repository maintenance change requires a paper revision.

Repository instruments may still be patched independently where test runs, implementation review, or technical maintenance reveal:

```text
spelling errors
formatting errors
obsolete filenames
missing descriptions
unclear labels
schema mismatches
invalid enum values
surface inconsistencies
```

Such changes may remain repository-level patches where they do not alter the methodological architecture.

Paper revision is required where a repository change alters or contradicts:

```text
Pre-Analysis entry control
Core primacy among analytical layers
the Single-Add-on Rule
MIP or AHP dependency
person-protection boundaries
the six final analytical decision states
pipeline-stop behavior
correctability
source hierarchy
effective checked-artefact precedence
Case Record non-analysis
iteration non-inheritance
article non-analysis
workflow non-authority
```

The maintenance rule is:

```text
Surface and schema refinements
may remain repository-level patches.

Architecture-level changes
require paper review and, where necessary, paper revision.
```

The current Annex H revision is an architecture-alignment revision.

It documents the repository as a conditional, checked, stoppable, and non-inheriting application system rather than as a linear sequence of templates.
