# PMS DISCIPLINE - PROMPTS & INSTRUCTIONS

**Standalone manual profile synchronized with PMS-ORCHESTRATOR v1.5**

This is the standalone manual counterpart to the PMS-ORCHESTRATOR prompt sequence. It assumes a human-guided chat or session. Therefore:

- semantic AI check steps remain explicit;
- every YAML check step performs its own complete structural audit;
- the original template or source-derived output structure must be supplied again for each YAML check;
- exact file, route, branch, material, and output-path facts must be maintained in user-supplied manual manifests;
- current-step execution metadata must not be converted into case substance or missing-artifact findings;
- no YAML structure check, completed route, article profile, workflow state, or model response is a truth certificate, evidence upgrade, semantic validation, or authority layer.

## Prompt Sequence Matrix

Use the prompt sequence according to the checked gate status and the explicit human route decision.

### Case 0 — Checked Pre-Analysis stop

Use when Prompt #3 confirms a PMS-DISCIPLINE pipeline stop.

```text
#1  Read PMS.yaml and optional case materials
#2  Apply Pre-Analysis Template
#3  Check Pre-Analysis YAML
STOP — do not run #4–#31 in the current run
```

A redirect may be prepared only as a new, separately bounded run beginning again at Prompt #1.

### Case A — Core only

Use when the Add-on route is Core-only and no MIP/AHP branch is entered.

```text
#1–#7
#20–#25
Optional #26
Optional #27–#31
```

Skip `#8–#19`.

### Case B — Core + selected add-on

Use when exactly one supported add-on is selected or explicitly confirmed, and no MIP/AHP branch is entered.

```text
#1–#10
#20–#25
Optional #26
Optional #27–#31
```

Skip `#11–#19`.

### Case C — Core + MIP

Use when the Add-on route remains Core-only, MIP is explicitly selected or confirmed, MIP is applied and checked, and AHP is not used.

```text
#1–#7
#11–#17
#20–#25
Optional #26
Optional #27–#31
```

Skip `#8–#10` and `#18–#19`.

### Case D — Core + selected add-on + MIP

Use when exactly one add-on is applied and checked, MIP is applied and checked, and AHP is not used.

```text
#1–#17
#20–#25
Optional #26
Optional #27–#31
```

Skip `#18–#19`.

### Case E — Core + MIP + AHP

Use when the Add-on route remains Core-only, MIP is applied and checked, and AHP is explicitly selected or confirmed after MIP.

```text
#1–#7
#11–#25
Optional #26
Optional #27–#31
```

Skip `#8–#10`.

### Case F — Core + selected add-on + MIP + AHP

Use when exactly one add-on is applied and checked, MIP is applied and checked, and AHP is applied and checked.

```text
#1–#31 as routed
```

No analytical branch is skipped after selection, except Prompt #30 is skipped under the no-example shortcut below.

## Human route, iteration, and article-profile confirmation rule

After each checked gate, the human user confirms the next route:

- after #3: stop the current run when the checked artifact confirms stop; otherwise continue to #4;
- after #7: Core-only or exactly one supported add-on;
- after #12: exactly `no_mip` or `use_mip`;
- after #17: exactly `no_ahp` or `use_ahp`;
- after #25: whether to run optional Iteration Handoff #26 and, independently, whether to generate an article;
- before #27 when article generation is selected: `case_article` or `full_analysis_article`.

An override must be recorded as an override. It does not convert a non-recommended layer into a gate-recommended layer and does not authorize stronger claims. AHP may be used only after MIP has actually been applied and checked. A human override cannot overrule a checked Pre-Analysis stop.

Prompt #26 is optional prospective follow-up preparation. It does not change the checked current case and is not required for article generation.

Changing only the article profile does not change the checked analysis or Iteration Handoff. In a manual run, retain #1–#26 and rerun #27–#31 with the new profile.

For compatibility with an older run that has no recorded profile, use `full_analysis_article` unless the human user explicitly selects `case_article`.

## Full Review Mode and manual Fast Mode

This standalone prompt file is written for **Full Review Mode**.

A user may intentionally skip semantic AI review steps to save time, but then:

- the direct preceding output remains `unchecked_by_user_choice`;
- every downstream reference to a “checked” artifact must be manually replaced with “unchecked direct output”;
- no skipped review may be described as validation, correction, acceptance, or certification;
- no deterministic local validator is assumed, so every check prompt must perform the complete manual structure audit;
- route decisions remain human decisions;
- the stop exception below remains binding and cannot be bypassed by skipping Prompt #3.

## Manual Pre-Analysis stop protocol

The following are authoritative stop signals in a Pre-Analysis YAML:

```text
scope_and_pipeline_disposition.pipeline_case_disposition: stop
final_pre_analysis_status.pipeline_case_disposition: stop
final_pre_analysis_status.status: stop_before_core
final_pre_analysis_status.next_allowed_step: stop
```

One authoritative stop signal is sufficient to place the current run under stop review. Additional stop signals are consistency confirmations, not extra prerequisites.

Full Review rules:

1. A stop signal in Prompt #2 is a clear stop warning. Do not run Prompt #4 or any later prompt.
2. Run Prompt #3 as the only allowed next step so the AI can audit and confirm or conservatively correct the Pre-Analysis.
3. If Prompt #3 confirms stop, the current run ends. Prompts #4–#31 are forbidden.
4. If Prompt #3 returns a complete corrected Pre-Analysis YAML without an authoritative stop signal and declares it ready, that complete corrected YAML becomes the effective artifact and the run may continue.
5. Audit prose, reassurance, a human preference, `mixed` pressure, or a `proceed*` value elsewhere cannot overrule an authoritative stop signal.

Manual Fast Mode rule:

- If Prompt #3 is deliberately skipped, any authoritative stop signal in the unchecked Prompt #2 output is immediately binding. The user must not continue to Prompt #4.

A stop may be removed only by revising the Pre-Analysis and checking the complete revised artifact. A redirect after a mandatory stop is a new, separately bounded run; it is not a continuation or same-run reframing.

## Mandatory manual YAML structure protocol

For every YAML-producing step:

1. Supply the exact template or source-derived output structure named by the prompt.
2. Return exactly one YAML document.
3. Preserve the exact root key, all required sections, all required keys, and list-item schemas.
4. Preserve field order as far as possible.
5. Add no new fields unless the supplied template/source explicitly allows extension fields.
6. Use only explicitly allowed values where the template/source defines an enum or choice list.
7. Treat every closed enum field as atomic: one field contains exactly one permitted literal value.
8. Never combine, qualify, concatenate, or paraphrase enum values. For example, `new evidence plus scope change`, `new evidence or stronger rival`, and `material scope change` are invalid when the permitted literals are `new evidence`, `scope change`, `demonstrated error`, `stronger rival`, and `other`.
9. Where a list schema permits several simultaneous triggers, create one complete list item per trigger with its own stable ID and case-specific explanation.
10. Use `other` only when no listed literal accurately represents the value; place the exact explanation in the adjacent explanatory field.
11. Do not infer an enum merely because a template contains one placeholder value.
12. Do not append a standalone `---` or `...` document marker at the end.
13. A fenced `yaml` block may be used only when the chat interface requires separation.

For every YAML check step, re-supply the original template or source file and perform a recursive key-path audit before semantic review. The audit must identify:

- YAML parseability and single-document status;
- exact root key and root type;
- missing keys with full paths;
- unexpected keys with full paths;
- duplicate keys;
- mapping/list/scalar type mismatches;
- list-item schema mismatches;
- explicit allowed-value violations, including combined or paraphrased enum values;
- unresolved placeholders;
- field-order drift where materially relevant.

A clean structure is not semantic adequacy, evidence, truth, validation of PMS, or authorization.

## Checked-artifact handling

- If a check reports `ready`, the original YAML becomes the checked artifact.
- If a check reports `corrected`, the **complete corrected YAML** becomes the checked artifact; the audit prose is not the artifact.
- If a check reports `not ready`, stop and correct or rerun the preceding application step.
- If Prompt #3 reports `pipeline stop confirmed`, the effective checked Pre-Analysis is the binding endpoint of the current run and must not be carried into Prompt #4 as Core input.
- If a correction creates or preserves a stop, the complete corrected YAML is the stop artifact; the prose summary alone neither creates nor removes stop.
- Never carry a superseded pre-correction YAML forward as the checked artifact.

## Manual case-material inventory

When case materials are used, prepare `{MANUAL_CASE_MATERIAL_INVENTORY}` before Prompt #1 and update the read status after the step.

```yaml
case_materials:
  - material_id: <stable manual id>
    original_filename: <filename>
    supplied_filename: <filename as supplied to the AI service>
    description: <user-supplied orientation metadata>
    purpose: <user-supplied orientation metadata>
    source_status: <known | reported | synthetic | mixed | unclear | other bounded value>
    sha256_if_available: <hash | unknown>
    size_bytes_if_available: <integer | unknown>
    read_status: <pending | read_completely | partially_read | inaccessible | unsupported | corrupted | encrypted>
    limitation: <none or concise limitation>
```

Descriptions and purposes are orientation metadata. Material presence, a successful upload, or a completed read step does not make a material true, relevant, complete, evidentiary, validated, or authoritative.

## Manual run manifests for Case Record stages

Before Prompt #20, prepare and paste `{MANUAL_STAGE_1_MANIFEST}`. It must describe the selected run, not the complete local installation, and it must cover upstream steps #1–#19 only.

```yaml
case_id: <manual case id>
route:
  selected_addon: <none | ANTICIPATION | CRITIQUE | CONFLICT | LOGIC | EDEN | SEX>
  addon_selection_basis: <gate_recommended | user_override | not_selected | not_applicable>
  mip: <used | not_used | not_applicable | rejected | unresolved>
  ahp: <used | not_used | not_applicable | rejected | unresolved>
selected_run_resources:
  pms_base:
    path: <exact project-relative path>
    status: <read | present | missing>
  templates_used:
    - path: <exact project-relative path>
      step: <step number>
      status: <used | present | missing>
  selected_addon_source:
    path: <exact path or none>
    status: <read | not_selected | not_applicable | missing>
  mip_source:
    path: <exact path or none>
    status: <read | not_used | not_applicable | missing>
  ahp_source:
    path: <exact path or none>
    status: <read | not_used | not_applicable | missing>
case_materials:
  - material_id: <stable id>
    path: <exact case-relative or project-relative path>
    description: <user-supplied orientation metadata>
    purpose: <user-supplied orientation metadata>
    sha256_if_available: <hash | unknown>
    size_bytes_if_available: <integer | unknown>
    presence_status: <present | missing>
    read_status: <read_completely | partially_read | inaccessible | unsupported | corrupted | encrypted | not_read>
steps:
  step_01:
    status: <completed | skipped | not_applicable>
    output_path: <exact case-relative path or none>
    output_exists: <yes | no>
  # continue through step_19 only
future_case_record_resources:
  stage_2_template:
    path: <exact project-relative path>
    status: deferred_future_step
    blocks_stage_1_readiness: false
  stage_3_template:
    path: <exact project-relative path>
    status: deferred_future_step
    blocks_stage_1_readiness: false
```

Do not add Step #20 as an upstream artifact in the Stage 1 manifest. Do not enumerate unselected local sources or templates merely because they exist. Preserve their route state with a bounded value and no invented path or presence claim.

Before each of Prompts #22–#25, update and paste `{MANUAL_CASE_RECORD_MANIFEST}` with the exact actual paths and states known at that point.

```yaml
case_id: <manual case id>
route:
  selected_addon: <none | ANTICIPATION | CRITIQUE | CONFLICT | LOGIC | EDEN | SEX>
  mip: <used | not_used | not_applicable | rejected | unresolved>
  ahp: <used | not_used | not_applicable | rejected | unresolved>
case_record:
  stage_1_output_path: <exact path>
  stage_1_check_status: <ready | corrected | unchecked_by_user_choice | not_ready>
  stage_2_output_path: <exact expected or actual path>
  stage_2_check_status: <not_started | ready | corrected | unchecked_by_user_choice | not_ready>
  stage_3_output_path: <exact expected or actual path>
  stage_3_check_status: <not_started | ready | corrected | unchecked_by_user_choice | not_ready>
current_step:
  step_number: <22 | 23 | 24 | 25>
  expected_output_path: <exact path>
  status: <current | completed | not_started>
  output_exists: <yes | no>
```

The current step's own expected output path, status, and `output_exists` value are execution metadata only. They must not become a missing item, deferred item, deliberate exclusion, tension, blocker, case finding, or readiness defect in that step's generated or checked artifact.

Do not use temporary attachment names, `/mnt/data` paths, sandbox paths, renamed uploads, helper scripts, or invented hashes.

## Article-profile selection

Before Prompt #27, set `{ARTICLE_PROFILE}` to exactly one of:

```text
case_article
full_analysis_article
```

`case_article` produces a focused standalone case article. `full_analysis_article` produces a detailed, audit-rich narrative rendering. The profile controls presentation depth and structure only. It does not change checked analysis, route state, source status, claim ceiling, unresolved items, Iteration Handoff status, or authority boundaries.

## No-example article shortcut

If Prompt #29 returns one of:

```text
examples_not_applicable
examples_unsafe
examples_not_needed
no_examples
```

do not run Prompt #30. Treat the Prompt #28 Base Markdown Case Article Draft as the final article candidate and continue directly to Prompt #31.

Prompt #30 is used only when examples were actually generated.

## Prompt #1 — Read PMS.yaml and Optional Case Materials

You are beginning a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:
- PMS.yaml
- optional user-provided case-material files listed in the manual inventory below

MANUAL CASE MATERIAL INVENTORY:
{MANUAL_CASE_MATERIAL_INVENTORY}

TASK:
First read PMS.yaml carefully and completely.

After PMS.yaml has been read, read every case-material file listed in the manual inventory. If no case-material files are listed, keep this as a PMS.yaml-only reading step.

For each supplied ZIP archive, inspect the archive inventory first. Then read every accessible and relevant contained file before moving to remaining standalone materials.

PURPOSE:
Establish PMS.yaml as the PMS Base reference and, where supplied, establish the user-provided files as bounded case-material context for later PMS-DISCIPLINE use.

TECHNICAL INSTRUCTIONS:
- Read PMS.yaml before reading any case material.
- Keep this as a source- and material-reading step only.
- PMS.yaml remains the PMS Base reference.
- User-provided materials remain bounded case inputs; they are not PMS Base, PMS add-ons, MIP/AHP, templates, validation, proof, or authority.
- Use descriptions and purposes from the manual inventory only as user-supplied orientation metadata.
- Do not perform Pre-Analysis, Core application, routing, scoring, Case Record generation, article drafting, or final decision work in this step.
- Do not invent inaccessible archive contents, missing documents, statistics, citations, provenance, or unavailable context.
- If any listed file or archive entry cannot be read, state that limitation instead of claiming complete access.

READING FOCUS:
Preserve for later context:
- PMS.yaml is the PMS Base reference.
- PMS operators Δ–Ψ are the base operator grammar.
- Derived axes are PMS-internal projections, not independent primitives.
- PMS is structural, non-diagnostic, non-person-ranking, non-prescriptive, and non-authorizing.
- PMS application requires distance, reversibility, dignity-in-practice, non-capture, rival openness, and claim restraint.
- YAML representation is not validation, proof, implementation, or authority.
- Case materials remain distinguishable by filename, description, purpose, source status, and claim boundary.
- Claims contained in a material are not automatically claims established by the pipeline.

OUTPUT:
If no additional case-material files are supplied, respond only:

PMS.yaml read completely.

If all listed case-material files were accessible and read completely after PMS.yaml, respond only:

PMS.yaml and all listed case materials read completely.

If one or more listed files or archive entries could not be read completely, respond only:

PMS.yaml read completely. Case-material reading incomplete: [list the inaccessible file or archive entry and the limitation].

---
## Prompt #2 — Apply PMS-DISCIPLINE Pre-Analysis Template
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:
- pms_discipline_pre_analysis_template.yaml

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in the previous step.
- PMS.yaml remains the PMS Base reference.
- Any manually listed case materials read in step #1 where accessible remain bounded case-material context.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply pms_discipline_pre_analysis_template.yaml to the CASE PACKET.

PURPOSE:
Produce a PMS-DISCIPLINE Pre-Analysis YAML that either prepares a permitted analysis target for later PMS Core application or records a binding pipeline stop where PMS-DISCIPLINE requires it.

TECHNICAL INSTRUCTIONS:
- Use only the provided template, the CASE PACKET, the available PMS.yaml context, and any bounded case materials already read in step #1.
- Use the Pre-Analysis template as the only output structure.
- HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
- Fill fields precisely from the CASE PACKET, available PMS.yaml context, and any case materials already read in step #1.
- Use unknown, unclear, not_applicable, missing, unresolved, or insufficient where the input does not license a stronger value and where the field permits that value.
- Template sections may change only where valid YAML repair requires it.
- PMS.yaml supplies background reference only; the Pre-Analysis step is not Core application.
- Distinguish the requested output from the pipeline case. A prohibited requested output may proceed through a separately named reframed target only where no mandatory hard-stop rule is triggered.
- MANDATORY PERSON-NEAR STOP RULE: when the requested output is a prohibited whole-person, character, motive, status, diagnostic, forensic, or person-ranking conclusion; the input is minimal, low, insufficient, fragmentary, hypothetical, or unverified; person-nearness is high or severe; irreversibility is high or severe; and the requested-output entry condition is not satisfied, set `scope_and_pipeline_disposition.pipeline_case_disposition: stop`. Do not use `proceed_reframed` in the current run. Set `permitted_analysis_target: not_applicable`, `reframing_required_before_core: false`, `reframing_status: not_needed`, and `hard_gate_effect: stop_pipeline`. Any redirect is only a possible new case or run.
- Apply the template hierarchy strictly: explicit scope prohibitions first; failed entry or protection conditions second; source and burden limits third; claim ceiling fourth; pressure markers only after those controls.
- Explicit scope prohibitions, failed entry/protection conditions, and triggered hard gates override aggregate or `mixed` pressure markers.
- Preliminary operator pressure, add-on scan pressure, and risk markers remain pressure markers. They must not be converted into recommendation, authorization, application, verdict, full Case Record generation, Markdown article generation, or final decision state.

PRE-ANALYSIS SCOPE:
This step may mark:
- case boundary
- input/source status
- intended use
- claim ceiling
- requested-output disposition and pipeline-case disposition
- original and permitted analysis targets
- hard-gate status, basis, and effect
- person-nearness
- publicness
- irreversibility
- preliminary operator pressure
- derived-structure pressure
- rival pressure
- non-capture zones
- falsifier, weakening, and reopening conditions
- correctability requirements
- later gate pressure only where the template asks for it
- handoff information for later Core use
- case-record seed information for later use

CLAIM DISCIPLINE:
- Keep the output bounded to the CASE PACKET.
- Preserve source status and intended use.
- Lower or limit claims where input, publicness, person-nearness, irreversibility, or rival pressure require it.
- Mark unlicensed claims and uncertainty explicitly.
- Preserve correction and reopening conditions.
- Do not use `mixed` preliminary pressure to weaken a hard prohibition, failed entry condition, triggered hard gate, refusal, suspension, or stop.
- Do not construct a same-run permitted analysis target to bypass the mandatory person-near stop rule.
- Where the pipeline stops, make all dependent fields consistent. At minimum preserve: `scope_and_pipeline_disposition.pipeline_case_disposition: stop`, `core_handoff.export_status: refused`, `final_pre_analysis_status.pipeline_case_disposition: stop`, `final_pre_analysis_status.status: stop_before_core`, and `final_pre_analysis_status.next_allowed_step: stop` where those fields exist in the supplied template.

FIELD-SPECIFIC VALUE RULE:
- Explicit allowed values declared by the template field override generic uncertainty or bounded markers.
- Never place `none`, `not_applicable`, `unknown`, `unclear`, or another generic marker into a field whose explicit enum does not allow it.
- Use the closest semantically correct permitted value and preserve remaining uncertainty in an adjacent explanatory field.
- For `falsifier_and_weakening_conditions.reopening_conditions[*].condition`, use exactly one literal allowed value per list item: `new evidence`, `scope change`, `demonstrated error`, `stronger rival`, or `other`.
- Never combine, qualify, concatenate, or paraphrase those values. Values such as `new evidence plus scope change`, `new evidence or stronger rival`, and `material scope change` are invalid.
- Where multiple reopening conditions apply, create one complete `reopening_conditions` list item per condition with a distinct `condition_id` such as `RO1`, `RO2`, and `RO3`. Preserve the case-specific consequence in each item's explanatory or effect field.
- Use `condition: other` only when no listed enum accurately represents the trigger; describe the exact trigger in the adjacent explanatory or effect field.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly and are not combined or paraphrased;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed Pre-Analysis YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #3 — Check PMS-DISCIPLINE Pre-Analysis YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_discipline_pre_analysis_template.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in an earlier step.
- PMS.yaml remains the PMS Base reference.
- The PMS-DISCIPLINE Pre-Analysis Template was applied in the previous step.
- The Pre-Analysis YAML from the previous step is present in this conversation/session.
- The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the Pre-Analysis YAML from the previous step for structural and substantive conformity with the supplied Pre-Analysis template and the PMS-DISCIPLINE use constraints of this step.

PURPOSE:
Determine whether the Pre-Analysis YAML permits a checked handoff to PMS Core, permits Core only on a completed reframed target, or requires revision, suspension, or a binding pipeline stop. Where necessary, conservatively correct it so that it sufficiently conforms to the template and bounded task.

TECHNICAL INSTRUCTIONS:
- Use only the Pre-Analysis YAML from the previous step, the CASE PACKET, available PMS.yaml context, and the supplied Pre-Analysis template structure.
- Re-run the Pre-Analysis from scratch only if the existing output is structurally unusable.
- Check structural conformity: root structure, required sections, required fields, allowed placeholders, valid YAML, list-item schemas, explicit enums, and required handoff sections.
- Check substantive conformity: boundedness to the CASE PACKET, source-status discipline, intended-use discipline, claim ceiling, requested-output and pipeline-case disposition, original and permitted targets, hard-gate hierarchy, person-nearness, publicness, irreversibility, non-capture, rival pressure, falsifier conditions, correctability, and reopening conditions.
- Correct only where necessary to restore PMS-/YAML-conformity or to prevent overclaim, source-status laundering, premature recommendation, premature authorization, premature Core application, or premature finalization.
- Prefer the smallest sufficient correction.
- Preserve the original output wherever it already sufficiently conforms.
- Corrections remain conservative, bounded, and claim-weakening where needed.
- Use explicit uncertainty markers rather than inferential gap-filling.
- Treat `scope_and_pipeline_disposition` as binding scope control, not as a preliminary pressure marker.
- Apply the mandatory person-near stop rule from Prompt #2. If the prior YAML uses `proceed_reframed` despite that rule, this is a concrete semantic defect and must be corrected to stop with all dependent fields made consistent.
- Verify that hard prohibitions, failed entry/protection conditions, and triggered hard gates cannot be overridden by `pressure_status: mixed`, a constructed same-run reframed target, or a generic `ready_with_limits` handoff.
- Treat any one authoritative stop signal as sufficient. If stop and proceed signals conflict, stop controls until the complete YAML is corrected; never resolve the contradiction by commentary alone.
- Validate `falsifier_and_weakening_conditions.reopening_conditions[*].condition` as one exact literal per list item: `new evidence`, `scope change`, `demonstrated error`, `stronger rival`, or `other`.
- A combined, qualified, or paraphrased reopening value is a concrete correctable defect. Split multiple triggers into separate complete `reopening_conditions` records with distinct IDs and preserve their specific effects in the adjacent explanation field.

STEP BOUNDARIES:
This check excludes:
- PMS Core application or PMS Core Case Application YAML generation
- invented source material, files, case facts, source status, or unavailable context
- conversion of preliminary operator pressure, add-on scan pressure, or risk markers into recommendation, authorization, application, verdict, full Case Record generation, Markdown article generation, or final decision state; this does not prohibit the template's binding scope and pipeline disposition
- stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:
- invalid YAML
- missing required sections or fields
- unresolved required placeholders
- source-status laundering
- claim ceiling overreach
- requested-output and pipeline-case disposition conflation
- mandatory person-near stop incorrectly represented as `proceed_reframed`
- hard prohibition or hard gate overridden by aggregate pressure
- Core handoff targeting a refused output, a mandatory-stop case, or an incomplete reframed target
- inconsistent stop status, handoff, or next-step fields
- combined, qualified, or paraphrased reopening-condition enum values
- premature Core analysis
- premature operator assignment
- preliminary pressure treated as final assignment
- scan pressure treated as recommendation, authorization, or application
- premature routing, verdict, full Case Record generation, Markdown article generation, or final decision execution
- missing non-capture, rival, falsifier, correctability, or reopening markers
- unsupported file assumptions
- unsupported layer references
- unsupported strengthening of claims

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values; include combined or paraphrased enum values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value. A closed enum is atomic: one field may contain only one exact permitted literal.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, unresolved required placeholder, or unresolved stop/proceed contradiction remains.

PATCH DISCIPLINE:
If correction is needed:
- Patch only within the Pre-Analysis YAML.
- HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
- Keep claims at or below the level licensed by the CASE PACKET and PMS.yaml context.
- Keep invented evidence, sources, files, case facts, and out-of-scope outputs out of the corrected YAML.
- Patch only the smallest structurally and semantically necessary part; use bounded markers only where the field permits them.
- The corrected output remains a Pre-Analysis YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If correction is made:
- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready or the stop is confirmed.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the Pre-Analysis YAML is usable for Core without correction, return the mandatory YAML structure audit followed by:

Pre-Analysis YAML checked. Ready for PMS Core case application.

If the Pre-Analysis YAML correctly and consistently contains an authoritative stop signal without requiring correction, return the mandatory YAML structure audit followed by:

Pre-Analysis YAML checked. PMS-DISCIPLINE pipeline stop confirmed.

If the Pre-Analysis YAML contains concrete defects that can be conservatively corrected inside this step, return:
- CHECK STATUS: corrected
- CORRECTIONS MADE: concise bullet list
- COMPLETE CORRECTED PRE-ANALYSIS YAML
- FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
- FINAL RESULT: either `Pre-Analysis YAML checked. Ready for PMS Core case application.` or `Pre-Analysis YAML checked. PMS-DISCIPLINE pipeline stop confirmed.`

If the Pre-Analysis YAML is not safely correctable inside this step, return:
- CHECK STATUS: not ready
- BLOCKING ISSUES
- REQUIRED CORRECTIONS
- NEXT ALLOWED STEP
## Prompt #4 — Apply PMS Core Case Application Template
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:
- pms_core_case_application_template.yaml

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in an earlier step.
- PMS.yaml remains the PMS Base reference.
- The checked Pre-Analysis YAML is present in this conversation/session.
- The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply pms_core_case_application_template.yaml to the CASE PACKET under the constraints of the checked Pre-Analysis YAML.

PURPOSE:
Produce a completed PMS Core Case Application YAML.

PRE-CORE ENTRY GUARD:
- Read the effective checked Pre-Analysis artifact, using the complete corrected YAML from Prompt #3 when Prompt #3 returned `corrected`.
- If any authoritative Pre-Analysis stop signal remains, do not apply the Core template and do not generate Core YAML. Respond only: `PMS-DISCIPLINE pipeline stop confirmed. PMS Core application is not permitted in this run.`
- If stop and proceed fields remain contradictory, do not choose between them. Respond only: `Checked Pre-Analysis is internally inconsistent. Rerun Prompt #3 before Core application.`
- If the checked disposition is `proceed_reframed`, continue only when the permitted target is explicit, complete, non-prohibited, and the checked handoff names Core as the next allowed step.

TECHNICAL INSTRUCTIONS:
- Use only the provided Core template, the CASE PACKET, the checked Pre-Analysis YAML, and the available PMS.yaml context.
- Use the Core Case Application template as the only output structure.
- HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
- Fill fields precisely from the CASE PACKET, checked Pre-Analysis YAML, and available PMS.yaml context.
- Use unknown, unclear, not_applicable, missing, unresolved, under_specified, or insufficient where the input does not license a stronger value.
- Template sections may change only where valid YAML repair requires it.
- Use the checked Pre-Analysis YAML as constraint on boundary, source status, input status, intended use, claim ceiling, person-nearness, publicness, irreversibility, rival pressure, non-capture, falsifier conditions, correctability, reopening conditions, and preliminary decision pressure.
- Use PMS.yaml as PMS Base reference for operator grammar, dependency discipline, derived structures, and application guardrails.
- Treat the checked Pre-Analysis YAML as constraint, not as a Core analysis result.
- Template completion is not validation, evidence, truth certification, case closure, or permission for publication or implementation.
- Core pressure markers remain pressure markers, not recommendation, authorization, routing, verdict, full Case Record generation, Markdown article generation, or final decision state.

CORE APPLICATION SCOPE:
This step may produce:
- PMS entry condition status
- application discipline status
- case typing and claim boundary
- checked Pre-Analysis import
- Core principle alignment
- PMS operator analysis Δ–Ψ
- operator dependency checks
- derived structure discipline
- derived axes projection
- self-model analysis, where scoped and warranted
- asymmetry drift pattern status, where scoped and warranted
- example operator-chain application
- computational representation limits
- AI-interface PMS alignment limits
- analysis quality control
- operationalization requirements
- guardrails
- limits
- case synthesis
- Core handoff
- Case Record handoff
- final structural formula as PMS-internal compressed reading only

CLAIM DISCIPLINE:
- Keep findings bounded, reversible, non-diagnostic, non-person-ranking, and open to correction.
- Preserve source status and intended use.
- Respect the claim ceiling declared or corrected in Pre-Analysis.
- Lower or limit claims where input status, publicness, person-nearness, irreversibility, rival pressure, or non-capture require it.
- Mark operator activation only where structurally warranted.
- Mark weak, inactive, under-specified, or non-applicable operators explicitly.
- In `ai_interface_pms_alignment.modes`, `axiomatic.case_status` and `derived_axes_inspection.case_status` accept only `active` or `inactive`; use `inactive` when unused. Only `ai_architecture.case_status` may use `not_applicable`.
- Preserve rival readings, falsifier conditions, reopening conditions, and correction conditions.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed PMS Core Case Application YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #5 — Check PMS Core Case Application YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- PMS.yaml
- pms_core_case_application_template.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in an earlier step.
- PMS.yaml remains the PMS Base reference.
- The checked Pre-Analysis YAML is present in this conversation/session.
- The PMS Core Case Application Template was applied in the previous step.
- The PMS Core Case Application YAML from the previous step is present in this conversation/session.
- The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the PMS Core Case Application YAML from the previous step for structural and substantive conformity with the previously applied Core template, PMS.yaml, and the checked Pre-Analysis constraints.

PURPOSE:
Determine whether the PMS Core Case Application YAML is usable as checked Core output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it sufficiently conforms to the template, PMS.yaml, and checked Pre-Analysis boundaries.

TECHNICAL INSTRUCTIONS:
- Use only the PMS Core Case Application YAML from the previous step, the CASE PACKET, checked Pre-Analysis YAML, available PMS.yaml context, and the previously applied Core template structure.
- Re-run the Core application from scratch only if the existing output is structurally unusable.
- Check structural conformity: root structure, required sections, required fields, allowed placeholders, valid YAML, operator sections Δ–Ψ, dependency sections, derived-structure sections, quality-control sections, and handoff sections.
- Check substantive conformity: operator grammar, dependency discipline, derived structures as projections, source-status discipline, intended-use discipline, claim ceiling, non-capture, rival pressure, falsifier conditions, correctability, reopening conditions, and non-authority boundaries.
- Correct only where necessary to restore PMS-/YAML-conformity or to prevent overclaim, source-status laundering, operator over-assignment, dependency violation, derived-structure reification, premature recommendation, premature authorization, or premature finalization.
- Prefer the smallest sufficient correction.
- Preserve the original output wherever it already sufficiently conforms.
- Corrections remain conservative, bounded, and claim-weakening where needed.
- Use explicit uncertainty, under-specification, weak activation, inactive status, or non-applicability markers rather than inferential gap-filling.
- Before reviewing the Core content, verify that the effective checked Pre-Analysis contains no authoritative stop signal. If it does, the Core artifact is not a permitted pipeline output and must not be repaired into apparent legitimacy. Report `not ready`, identify the stop as the blocker, and name Pre-Analysis revision followed by Prompt #3 as the only allowed route.
- Check `ai_interface_pms_alignment.modes` exactly: `axiomatic.case_status` and `derived_axes_inspection.case_status` allow only `active` or `inactive`; only `ai_architecture.case_status` may use `not_applicable`.

STEP BOUNDARIES:
This check excludes:
- production or application of the next pipeline step
- invented source material, files, case facts, source status, or unavailable context
- conversion of Core pressure markers into recommendation, authorization, routing, verdict, full Case Record generation, Markdown article generation, or final decision state
- stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:
- invalid YAML
- missing required sections or fields
- unresolved required placeholders
- Core application produced despite an authoritative checked Pre-Analysis stop
- contradictory stop/proceed fields carried into Core
- invalid `ai_interface_pms_alignment.modes` case-status value
- source-status laundering
- claim ceiling overreach
- operator over-assignment or under-assignment
- dependency violation
- derived-structure reification
- loss of non-capture or rival pressure
- missing falsifier, correctability, or reopening markers
- unsupported file assumptions
- unsupported strengthening of claims
- premature recommendation, authorization, routing, verdict, full Case Record generation, Markdown article generation, or final decision execution
- unsupported out-of-scope decision or application

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If correction is needed:
- Patch only within the PMS Core Case Application YAML.
- HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
- Keep PMS Base operator definitions, dependency rules, and derived-structure definitions unchanged. Correct only case-level assignments or statuses where the checked material requires it.
- Keep claims at or below the level licensed by the CASE PACKET and checked Pre-Analysis.
- Keep invented evidence, sources, files, case facts, new PMS primitives, and out-of-scope outputs out of the corrected YAML.
- Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
- Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, weak, inactive, or similarly bounded markers where stronger values are not licensed.
- The corrected output remains a PMS Core Case Application YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the PMS Core Case Application YAML is usable for the next checked step without correction, return the mandatory YAML structure audit followed by:

PMS Core Case Application YAML checked. Ready for next PMS-DISCIPLINE pipeline step.

If the PMS Core Case Application YAML contains concrete defects that can be conservatively corrected inside this step, return:
- CHECK STATUS: corrected
- CORRECTIONS MADE: concise bullet list
- FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
- COMPLETE CORRECTED PMS CORE CASE APPLICATION YAML

If the PMS Core Case Application YAML is not safely correctable inside this step, return:
- CHECK STATUS: not ready
- BLOCKING ISSUES
- REQUIRED CORRECTIONS
- NEXT ALLOWED STEP
## Prompt #6 — Apply PMS-DISCIPLINE Add-on Recommendation Gate Template
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:
- pms_discipline_addon_recommendation_gate_template.yaml

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in an earlier step.
- PMS.yaml remains the PMS Base reference.
- The checked Pre-Analysis YAML is present in this conversation/session.
- The checked Core Case Application YAML is present in this conversation/session.
- The CASE PACKET remains the bounded source material for this run.
- Add-on sources and add-on case templates have not been read in this step.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply pms_discipline_addon_recommendation_gate_template.yaml to determine whether the checked Core output should remain Core-only or whether exactly one supported add-on family should be recommended as the next reading step.

PURPOSE:
Produce a completed PMS-DISCIPLINE Add-on Recommendation Gate YAML.

TECHNICAL INSTRUCTIONS:
- Use only the provided gate template, CASE PACKET, checked Pre-Analysis YAML, checked Core Case Application YAML, and available PMS.yaml context.
- Use the Add-on Recommendation Gate template as the only output structure.
- HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
- Fill fields precisely from the available inputs.
- Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
- Keep all findings bounded to the CASE PACKET, checked Pre-Analysis YAML, checked Core Case Application YAML, and PMS.yaml context.
- Treat add-on recommendation as a bounded next-step suggestion only, not as authorization, routing execution, classification, claim strengthening, truth certification, or final decision.
- Recommend at most one supported add-on family.
- Supported add-on families are only: ANTICIPATION, CRITIQUE, CONFLICT, LOGIC, EDEN, SEX.
- If no supported add-on is structurally warranted, mark Core-only or no add-on recommendation.
- If multiple add-on pressures appear, use the template’s multiple-candidate pressure review to select the strongest single candidate, preserve Core-only, require revision, suspend, redirect, or mark unclear.
- If surface cues appear without structural trigger, preserve them as false-trigger or non-use records rather than recommending the add-on.

STEP BOUNDARIES:
This step excludes:
- invented source material, files, case facts, source status, add-on source files, add-on case templates, or unavailable context
- reading, summarizing, or applying add-on sources or add-on case application templates
- add-on case application output
- Case Record generation
- Markdown article generation
- final decision execution

ADD-ON GATE SCOPE:
This step may produce:
- checked prior output import
- case and claim boundary review
- Core-only sufficiency review
- supported add-on scan
- candidate scan records for supported add-on families
- multiple-candidate pressure review
- single-add-on rule application
- false-trigger and non-use record
- discipline constraints review
- gate result
- selected add-on next-step indication at family level only
- add-on gate handoff
- quality checks
- final add-on gate status

CLAIM DISCIPLINE:
- Preserve source status, intended use, and the claim ceiling declared or corrected in the checked Pre-Analysis and checked Core output.
- Preserve person-nearness, publicness, irreversibility, rival pressure, non-capture, falsifier conditions, correctability, and reopening conditions.
- Keep add-on relevance separate from add-on authorization.
- Keep add-on non-use available as a disciplined result.
- Keep Core-only available as a disciplined result.
- Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed PMS-DISCIPLINE Add-on Recommendation Gate YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #7 — Check PMS-DISCIPLINE Add-on Recommendation Gate YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_discipline_addon_recommendation_gate_template.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in an earlier step.
- PMS.yaml remains the PMS Base reference.
- The checked Pre-Analysis YAML is present in this conversation/session.
- The checked Core Case Application YAML is present in this conversation/session.
- The PMS-DISCIPLINE Add-on Recommendation Gate Template was applied in the previous step.
- The Add-on Recommendation Gate YAML from the previous step is present in this conversation/session.
- The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the Add-on Recommendation Gate YAML from the previous step for structural and substantive conformity with the previously applied gate template, PMS.yaml, checked Pre-Analysis constraints, and checked Core constraints.

PURPOSE:
Determine whether the Add-on Recommendation Gate YAML is usable as checked gate output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it sufficiently conforms to the template, PMS.yaml, checked Pre-Analysis, checked Core output, and bounded task.

TECHNICAL INSTRUCTIONS:
- Use only the Add-on Recommendation Gate YAML from the previous step, CASE PACKET, checked Pre-Analysis YAML, checked Core Case Application YAML, available PMS.yaml context, and the previously applied gate template structure.
- Re-run the Add-on Recommendation Gate from scratch only if the existing output is structurally unusable.
- Check structural conformity: root structure, required sections, required fields, allowed placeholders, valid YAML, supported add-on family enum, candidate scan records, single-add-on rule, false-trigger/non-use record, gate result, selected add-on next-step block, selection consistency, authorization boundary, handoff, quality checks, and final gate status.
- Check substantive conformity: Core-only sufficiency, add-on recommendation restraint, false-trigger handling, non-use visibility, single-add-on discipline, claim ceiling preservation, person-nearness caution, rival pressure, non-capture, correctability, and reopening conditions.
- Correct only where necessary to restore PMS-/YAML-conformity or to prevent overclaim, source-status laundering, false-trigger escalation, multi-add-on recommendation, authorization drift, unsupported filename assumptions, out-of-scope leakage, or premature finalization.
- Prefer the smallest sufficient correction.
- Preserve the original output wherever it already sufficiently conforms.
- Corrections remain conservative, bounded, and claim-weakening where needed.
- Use explicit uncertainty markers rather than inferential gap-filling.

STEP BOUNDARIES:
This check excludes:
- invented source material, files, case facts, source status, add-on source files, add-on case templates, or unavailable context
- reading, summarizing, or applying add-on sources or add-on case application templates
- add-on case application output
- Case Record generation
- Markdown article generation
- final decision execution
- stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:
- invalid YAML
- missing required sections or fields
- unresolved required placeholders
- unsupported add-on family
- multiple add-ons recommended
- selected_addon inconsistent with gate_status
- selected_addon_next_step inconsistent with gate_result
- add-on recommendation treated as authorization
- add-on application performed inside the gate
- add-on source file or add-on case template assumed or invented
- surface cue treated as structural trigger without warrant
- false-trigger or non-use record missing where required
- Core-only sufficiency not considered
- source-status laundering
- claim ceiling overreach
- loss of person-nearness, publicness, irreversibility, rival pressure, non-capture, correctability, or reopening constraints
- Case Record generation
- Markdown article generation
- final decision execution
- unsupported strengthening of claims
- unsupported out-of-scope decision or application

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If correction is needed:
- Patch only within the Add-on Recommendation Gate YAML.
- HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
- Keep PMS operators, dependencies, derived structures, and supported add-on families unchanged.
- Keep claims at or below the level licensed by the CASE PACKET, checked Pre-Analysis, and checked Core output.
- Keep unsupported add-ons, invented files, out-of-scope outputs, and new source claims out of the corrected YAML.
- Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
- Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, none, weak, false_trigger, not_recommended, core_only, or similarly bounded markers where stronger values are not licensed.
- The corrected output remains an Add-on Recommendation Gate YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the Add-on Recommendation Gate YAML is usable for the next PMS-DISCIPLINE pipeline step without correction, return the mandatory YAML structure audit followed by:

Add-on Recommendation Gate YAML checked. Ready for the next allowed PMS-DISCIPLINE pipeline step named in the checked gate output.

If the Add-on Recommendation Gate YAML contains concrete defects that can be conservatively corrected inside this step, return:
- CHECK STATUS: corrected
- CORRECTIONS MADE: concise bullet list
- FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
- COMPLETE CORRECTED ADD-ON RECOMMENDATION GATE YAML

If the Add-on Recommendation Gate YAML is not safely correctable inside this step, return:
- CHECK STATUS: not ready
- BLOCKING ISSUES
- REQUIRED CORRECTIONS
- NEXT ALLOWED STEP
## Prompt #8 — Read Selected PMS Add-on YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:
- PMS-{SELECTED_ADDON}.yaml

CONTEXT AVAILABLE:
- PMS.yaml has been read completely in an earlier step.
- PMS.yaml remains the PMS Base reference.
- Checked Pre-Analysis YAML, checked Core Case Application YAML, and checked Add-on Recommendation Gate YAML are present in this conversation/session.
- The checked Add-on Recommendation Gate selected exactly one supported add-on family as the next reading step.
- The provided PMS-{SELECTED_ADDON}.yaml corresponds to the selected or user-confirmed add-on family.

SELECTED ADD-ON FAMILY:
{SELECTED_ADDON}

SUPPORTED ADD-ON FAMILIES:
- ANTICIPATION
- CRITIQUE
- CONFLICT
- LOGIC
- EDEN
- SEX

CASE INPUTS:
- none for this step

TASK:
Read PMS-{SELECTED_ADDON}.yaml carefully and completely.

PURPOSE:
Establish PMS-{SELECTED_ADDON}.yaml as the selected add-on source reference for the later PMS-DISCIPLINE add-on case application step.

TECHNICAL INSTRUCTIONS:
- Use only the provided add-on YAML and the available checked context from previous steps.
- Confirm internally that the provided add-on YAML corresponds to the selected or user-confirmed add-on family.
- Keep this as a source-reading step only.
- Case application, template output, Case Record generation, Markdown article generation, final decision execution, invented source material, invented files, invented case facts, invented source status, invented add-on case templates, and unavailable context are outside this step.

READING FOCUS:
Preserve for later context:
- selected add-on role and scope
- relation to PMS Base
- operator emphases and trigger logic
- non-trigger conditions and overuse risks
- claim boundaries
- non-authority boundaries
- case-application constraints
- source-specific guardrails for later add-on case application

OUTPUT:
If the provided file corresponds to the selected or user-confirmed add-on family, respond only:

PMS-{SELECTED_ADDON}.yaml read completely.

If the provided file does not correspond to the selected or user-confirmed add-on family, respond only:

Selected add-on source mismatch. Provide the PMS YAML for the selected or user-confirmed add-on family.
## Prompt #9 — Apply Selected PMS Add-on Case Application Template
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* pms_addon_SELECTED_ADDON_case_application_template.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* PMS-{SELECTED_ADDON}.yaml was read in the previous step.
* The CASE PACKET remains the bounded source material for this run.

SELECTED ADD-ON FAMILY:
{SELECTED_ADDON}

SUPPORTED ADD-ON FAMILIES:

* ANTICIPATION
* CRITIQUE
* CONFLICT
* LOGIC
* EDEN
* SEX

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply pms_addon_SELECTED_ADDON_case_application_template.yaml to the CASE PACKET under the constraints of PMS.yaml, the checked prior YAML artifacts, and the already-read PMS-{SELECTED_ADDON}.yaml source.

PURPOSE:
Produce a completed PMS-{SELECTED_ADDON} Add-on Case Application YAML.

TECHNICAL INSTRUCTIONS:

* Use the provided add-on case template as the output structure for this step.
* Fill fields only from the CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and the already-read selected add-on source.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Mark under-supported fields with bounded values such as unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, weak, inactive, or none.
* When `{SELECTED_ADDON}` is `EDEN`, set `source_and_claim_burden_discipline.source_status_preserved.counter_scene_material` to exactly one of `present`, `partial`, `absent`, or `needs_review`. When no counter-scene material is supplied, use `absent`, not `none`.
* Keep the selected add-on subordinate to PMS Base, checked Core, source status, intended use, claim ceiling, non-capture, rival pressure, correctability, and reopening conditions.
* Treat the checked Add-on Recommendation Gate as selection context, not as authorization or claim strengthening.
* Apply only the selected add-on family named above.

STEP BOUNDARIES:
This step excludes:

* new source material, invented files, inferred case facts, or unavailable context
* re-running Pre-Analysis, Core, or the Add-on Recommendation Gate
* changing the selected add-on family
* applying any other add-on family
* converting add-on relevance into proof, verdict, mandate, publication permission, or final decision
* generating later pipeline artifacts

ADD-ON APPLICATION SCOPE:
This step may produce:

* selected add-on case application YAML
* add-on-specific trigger review
* non-trigger and false-trigger review
* add-on-specific operator emphasis
* claim-ceiling effect
* rival and non-capture constraints
* correctability and reopening conditions
* add-on synthesis
* quality checks
* handoff to the add-on output check

CLAIM DISCIPLINE:

* Preserve source status and intended use.
* Keep claims at or below the ceiling set by checked Pre-Analysis and checked Core.
* Weaken or mark unlicensed any add-on reading that exceeds the available material.
* Keep persons, groups, and institutions out of ranking, diagnosis, certainty labeling, or moral closure.
* Preserve rival readings and stop-capability.
* Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed PMS-{SELECTED_ADDON} Add-on Case Application YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #10 — Check Selected PMS Add-on Case Application YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- PMS-{SELECTED_ADDON}.yaml
- pms_addon_SELECTED_ADDON_case_application_template.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* PMS-{SELECTED_ADDON}.yaml was read earlier.
* The selected add-on case template was applied in the previous step.
* The produced PMS-{SELECTED_ADDON} Add-on Case Application YAML is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

SELECTED ADD-ON FAMILY:
{SELECTED_ADDON}

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the PMS-{SELECTED_ADDON} Add-on Case Application YAML from the previous step for structural and substantive conformity with the selected add-on case template, PMS.yaml, the checked prior YAML artifacts, and the already-read PMS-{SELECTED_ADDON}.yaml source.

PURPOSE:
Determine whether the selected add-on output is usable for the next PMS-DISCIPLINE pipeline step. Where needed, conservatively correct the YAML so that it remains bounded, structurally valid, and consistent with the selected add-on’s role.

TECHNICAL INSTRUCTIONS:

* Use only the add-on output from the previous step, the CASE PACKET, PMS.yaml context, checked prior YAML artifacts, the selected add-on source context, and the selected add-on case template structure.
* Re-run the add-on application from scratch only if the existing YAML is structurally unusable.
* Check template conformity: root structure, required sections, required fields, valid YAML, selected add-on family, source import, trigger review, non-trigger review, quality checks, handoff, and final status.
* Check substantive conformity: PMS Base preservation, Core subordination, gate-selection consistency, source-status discipline, claim ceiling, add-on trigger discipline, false-trigger handling, rival pressure, non-capture, correctability, reopening conditions, and non-authority boundaries.
* When the selected add-on is EDEN, check `source_and_claim_burden_discipline.source_status_preserved.counter_scene_material` against the exact enum `present`, `partial`, `absent`, `needs_review`; correct `none` to `absent` when no counter-scene material was supplied.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* selected add-on mismatch
* unsupported source or file assumption
* selected source missing, mismatched, or treated as PMS Base
* checked Core overwritten or strengthened
* Add-on Recommendation Gate treated as authorization
* add-on trigger inflated from surface cues
* false-trigger or non-trigger conditions omitted
* another add-on applied inside this output
* source-status laundering
* claim ceiling overreach
* forecast, certainty, mandate, verdict, ranking, diagnosis, or finality drift
* loss of rival readings, non-capture, correctability, or reopening conditions
* invalid EDEN `counter_scene_material` value, including `none` where `absent` is required
* unsupported strengthening of claims
* generated later pipeline artifacts

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If a correction is needed:

* Patch only within the selected add-on output YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep PMS operators, dependencies, derived structures, and supported add-on families unchanged.
* Keep claims at or below the level licensed by the CASE PACKET, checked prior artifacts, and selected add-on source.
* Exclude unsupported add-ons, invented files, new source claims, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a selected PMS add-on case application YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the selected add-on output is already usable without correction, return the mandatory YAML structure audit followed by:

PMS-{SELECTED_ADDON} Add-on Case Application YAML checked. Ready for the next PMS-DISCIPLINE pipeline step.

If concrete defects can be conservatively corrected inside this step, return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
* COMPLETE CORRECTED PMS-{SELECTED_ADDON} ADD-ON CASE APPLICATION YAML

If the output is not safely correctable inside this step, return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP
## Prompt #11 — Apply PMS-DISCIPLINE MIP Gate Template
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* pms_discipline_mip_gate_template.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* The selected PMS add-on source was read earlier if an add-on was selected.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply pms_discipline_mip_gate_template.yaml to determine whether the current checked PMS-DISCIPLINE case state should proceed to MIP source reading, remain without MIP, require revision, downgrade, suspend, refuse, redirect, or require human review.

PURPOSE:
Produce a completed PMS-DISCIPLINE MIP Gate YAML.

TECHNICAL INSTRUCTIONS:

* Use only the provided MIP Gate template, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and checked selected add-on output where present.
* Use the MIP Gate template as the only output structure.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from the available inputs.
* Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Treat the MIP Gate as a bounded recommendation/checkpoint for whether MIP source reading is warranted.
* Keep MIP recommendation separate from MIP application, MIP scoring, person assessment, implementation authority, or finality.
* The manual route remains binary: `not_recommended`, `scan_only`, or unsafe overall outcomes preselect `no_mip`; `recommended` or `recommended_with_limits` preselect `use_mip`. The `use_mip` route includes Prompt #13 source reading followed by Prompt #14 bounded case application. No source-reading-only route is created.
* When MIP source reading is recommended, set `mip_recommendation_output.MIP_source_read_recommendation.status` to exactly `recommended`, never `recommended_with_limits`. Evaluate the case-application recommendation separately without creating a third route.
* Preserve source status, intended use, claim ceiling, non-capture, rival pressure, correctability, reopening conditions, and stop-capability from checked prior artifacts.

MIP TRIGGER CALIBRATION:

MIP must not be triggered merely because a constructed, illustrative, hypothetical, workplace, organizational, or conflict case could involve real persons if instantiated.

Do not treat the following as sufficient MIP triggers by themselves:

* routine handoff of responsibility;
* routine role or process coordination;
* deadline pressure;
* delayed response;
* reduced practical options;
* future-risk language;
* hypothetical real-person transfer;
* general organizational friction;
* user curiosity about maturity or dignity language.

MIP becomes structurally relevant only when the checked case state itself centers, or would directly carry into, one or more of the following:

* person-near practice;
* person-evaluative judgment;
* responsibility attribution under asymmetry;
* role-capacity assessment;
* dignity-in-practice pressure;
* face, status, humiliation, or revision-capacity pressure;
* public reputational exposure;
* irreversible or consequential action toward real persons, groups, offices, or institutions.

A constructed case may remain no-MIP when it is role/process-oriented and explicitly avoids personal blame. A constructed case may trigger MIP when its own theory or intended use is built around face/status loss, revision incapacity, dignity-in-practice pressure, responsibility attribution, role-capacity evaluation, reputational exposure, or person-near judgment if transferred to real parties.

This is not a lower MIP threshold. It distinguishes generic hypothetical person involvement from structurally person-near transfer pressure.

STEP BOUNDARIES:
This step excludes:

* reading or applying a MIP source
* producing a MIP case application YAML
* assigning MIP bands, scores, boxes, modules, person rankings, or maturity verdicts
* changing checked Pre-Analysis, checked Core, checked Add-on Gate, or checked Add-on output
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts

MIP GATE SCOPE:
This step may produce:

* checked prior output import
* MIP applicability review
* burden and source-status review
* red-zone review
* D-module sensitivity review
* A/M-band and IA-box sensitivity review without assigning bands or boxes
* rival and non-capture review
* correctability review
* MIP recommendation output
* MIP gate handoff
* MIP gate quality checks
* final MIP gate status

CLAIM DISCIPLINE:

* Keep claims at or below the ceiling set by checked prior artifacts.
* Mark MIP pressure as pressure only, not as MIP result.
* Preserve Core-only or add-on-only sufficiency where MIP is not structurally warranted.
* Treat person-nearness, publicness, irreversibility, and action-power pressure as caution signals, not automatic MIP triggers.
* Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed PMS-DISCIPLINE MIP Gate YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #12 — Check PMS-DISCIPLINE MIP Gate YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_discipline_mip_gate_template.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* The PMS-DISCIPLINE MIP Gate Template was applied in the previous step.
* The MIP Gate YAML from the previous step is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the MIP Gate YAML from the previous step for structural and substantive conformity with the MIP Gate template, PMS.yaml, checked prior YAML artifacts, and the bounded task.

PURPOSE:
Determine whether the MIP Gate YAML is usable as checked gate output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it sufficiently conforms to the template, PMS.yaml, checked prior outputs, and MIP gate boundaries.

TECHNICAL INSTRUCTIONS:

* Use only the MIP Gate YAML from the previous step, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, checked selected add-on output where present, and the previously applied MIP Gate template structure.
* Re-run the MIP Gate from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, prior-output import, applicability review, burden review, red-zone review, D-module sensitivity review, A/M-band and IA-box sensitivity review, recommendation output, handoff, quality checks, and final gate status.
* Check substantive conformity: MIP recommendation restraint, source-status discipline, claim ceiling, person-nearness caution, publicness, irreversibility, action-power pressure, non-capture, rival pressure, correctability, reopening conditions, and non-authority boundaries.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.

STEP BOUNDARIES:
This check excludes:

* reading or applying a MIP source
* producing MIP case application output
* assigning MIP bands, scores, boxes, modules, person rankings, or maturity verdicts
* changing checked prior artifacts outside the MIP Gate YAML
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* checked prior outputs ignored, overwritten, or strengthened
* MIP recommendation treated as MIP application
* MIP pressure treated as score, band, box, module result, person ranking, or maturity verdict
* red-zone review omitted or softened
* D-module, A/M-band, or IA-box sensitivity converted into actual assignment
* source-status laundering
* claim ceiling overreach
* person-nearness, publicness, irreversibility, or action-power pressure inflated into automatic MIP use
* hypothetical real-person transfer treated as sufficient MIP trigger without person-evaluative, responsibility-attributive, role-capacity, dignity-in-practice, face/status, reputational, or consequential action pressure
* routine role/process coordination, deadline pressure, delay, or option-space reduction over-escalated into MIP where the case explicitly avoids personal blame or person assessment
* face/status/revision-capacity pressure wrongly dismissed as no-MIP merely because the case is constructed or not currently about real named persons
* non-binary manual route or a source-reading-only route introduced
* `MIP_source_read_recommendation.status` set to `recommended_with_limits` instead of exact `recommended` when source reading is recommended
* loss of rival readings, non-capture, correctability, or reopening conditions
* unsupported strengthening of claims
* generated later pipeline artifacts

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the MIP Gate YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep PMS operators, dependencies, derived structures, and MIP-specific categories unchanged.
* Keep claims at or below the level licensed by the CASE PACKET and checked prior artifacts.
* Preserve the calibrated distinction between role/process-only cases and structurally person-near transfer cases.
* When MIP source reading is recommended, set `mip_recommendation_output.MIP_source_read_recommendation.status` to `recommended`, never `recommended_with_limits`.
* Evaluate `mip_recommendation_output.MIP_case_application_recommendation.status` separately. This semantic distinction does not create a separate manual route: the overall recommendation controls only `no_mip` versus `use_mip`, and `use_mip` proceeds through source reading before bounded case application.
* Correct over-triggered MIP to `not_recommended` when the case contains only routine role/process pressure, deadline pressure, delay, option loss, or hypothetical real-person transfer without a person-evaluative center.
* Exclude invented files, new source claims, MIP application output, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a PMS-DISCIPLINE MIP Gate YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the MIP Gate YAML is usable for the next PMS-DISCIPLINE pipeline step without correction, return the mandatory YAML structure audit followed by:

PMS-DISCIPLINE MIP Gate YAML checked. Ready for the next allowed PMS-DISCIPLINE pipeline step named in the checked gate output.

If concrete defects can be conservatively corrected inside this step, return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
* COMPLETE CORRECTED PMS-DISCIPLINE MIP GATE YAML

If the output is not safely correctable inside this step, return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP
## Prompt #13 — Read MIP YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* MIP - Maturity in Practice.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* The checked MIP Gate named MIP source reading as the next allowed step.

CASE INPUTS:

* none for this step

TASK:
Read MIP - Maturity in Practice.yaml carefully and completely.

PURPOSE:
Establish MIP - Maturity in Practice.yaml as the MIP source and case-application reference for the next PMS-DISCIPLINE MIP application step.

TECHNICAL INSTRUCTIONS:

* Use only MIP - Maturity in Practice.yaml and the available checked context from previous steps.
* Confirm internally that the checked MIP Gate allows MIP source reading.
* Keep this as a source-reading step only.
* Case application, template output, scoring, band assignment, module assignment, source invention, file invention, unavailable context, and later pipeline artifacts are outside this step.

READING FOCUS:
Preserve for later context:

* MIP model role and scope
* relation to PMS Base
* A–C–R–P–D structure
* A-score, M-score, IA-box, and D-module mechanics
* Red Zones and non-use conditions
* source-status and evidence-burden requirements
* non-authority boundaries
* case-application constraints
* conditions under which MIP weakens, suspends, redirects, or refuses application

OUTPUT:
If the checked MIP Gate allows MIP source reading, respond only:

MIP - Maturity in Practice.yaml read completely.

If the checked MIP Gate does not allow MIP source reading, respond only:

MIP source reading is not authorized by the checked MIP Gate.
## Prompt #14 — Apply MIP Case Application
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* MIP - Maturity in Practice.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* MIP - Maturity in Practice.yaml was read completely in the previous step.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply the MIP case-application structure in MIP - Maturity in Practice.yaml to the CASE PACKET under the constraints of PMS.yaml, checked prior YAML artifacts, and the checked MIP Gate.

PURPOSE:
Produce a completed MIP Case Application YAML.

TECHNICAL INSTRUCTIONS:

* Use MIP - Maturity in Practice.yaml as the MIP source and case-application structure for this step.
* Fill fields only from the CASE PACKET, PMS.yaml context, checked prior YAML artifacts, checked MIP Gate, and MIP - Maturity in Practice.yaml.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the MIP case-application structure, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from the available inputs.
* Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Keep MIP subordinate to PMS Base, checked Core, source status, intended use, claim ceiling, non-capture, rival pressure, correctability, reopening conditions, and stop-capability.
* Treat the checked MIP Gate as MIP-selection context, not as MIP result, score, band, module assignment, person assessment, implementation authority, or finality.
* Apply only MIP.

CONDITIONAL TRANSFER / BOUNDARY USE:

If the checked MIP Gate recommended MIP only because of conditional person-near transfer pressure, apply MIP as a bounded transfer-risk, burden, red-zone, role-capacity, responsibility, dignity-in-practice, and claim-boundary review.

In that mode:

* do not treat the constructed case as a real-person assessment;
* do not assign hard A/M scores;
* do not activate D;
* do not create a D-profile;
* do not treat IA-box handling as a verdict;
* do not rank, diagnose, blame, or evaluate persons;
* mark unsupported MIP fields as `not_applicable`, `insufficient`, `unknown`, or `scan_only` only where the MIP source permits;
* preserve the result as boundary-focused and conditional.

STEP BOUNDARIES:
This step excludes:

* re-running Pre-Analysis, Core, Add-on Gate, Add-on Application, or MIP Gate
* changing the checked MIP Gate result
* adding source material, files, inferred case facts, or unavailable context
* treating MIP output as proof, verdict, diagnosis, person ranking, maturity judgment, mandate, or implementation permission
* generating later pipeline artifacts

MIP APPLICATION SCOPE:
This step may produce:

* MIP case application YAML
* A–C–R–P–D analysis where structurally warranted
* A-score and M-score handling only where licensed by MIP - Maturity in Practice.yaml and the case material
* IA-box and D-module handling only where licensed by MIP - Maturity in Practice.yaml and the case material
* Red Zone review
* non-use and refusal conditions
* source-status and evidence-burden review
* rival and non-capture constraints
* correctability and reopening conditions
* bounded MIP synthesis
* MIP quality checks
* handoff to MIP output check

CLAIM DISCIPLINE:

* Preserve source status and intended use.
* Keep claims at or below the ceiling set by checked prior artifacts.
* Treat under-supported MIP fields as under-supported rather than filling by inference.
* Keep persons, groups, and institutions out of ranking, diagnosis, certainty labeling, or moral closure.
* Preserve rival readings and stop-capability.
* Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed MIP Case Application YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #15 — Check MIP Case Application YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- MIP - Maturity in Practice.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* MIP - Maturity in Practice.yaml was read completely in an earlier step.
* The MIP Case Application YAML from the previous step is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the MIP Case Application YAML from the previous step for structural and substantive conformity with MIP - Maturity in Practice.yaml, PMS.yaml, checked prior YAML artifacts, checked MIP Gate, and the bounded task.

PURPOSE:
Determine whether the MIP Case Application YAML is usable as checked MIP output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it remains structurally valid, source-bounded, non-authoritative, and consistent with MIP’s own case-application structure.

TECHNICAL INSTRUCTIONS:

* Use only the MIP Case Application YAML from the previous step, MIP - Maturity in Practice.yaml, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and checked MIP Gate.
* Re-run MIP application from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, MIP case-application structure, A–C–R–P–D structure, A-score handling, M-score handling, IA-box handling, D-module handling, Red Zone review, non-use/refusal conditions, source-status and evidence-burden review, quality checks, handoff, and final status.
* Check substantive conformity: MIP source fidelity, checked MIP Gate consistency, PMS Base preservation, checked Core subordination, selected add-on subordination where present, source-status discipline, intended-use discipline, claim ceiling, non-capture, rival pressure, correctability, reopening conditions, and non-authority boundaries.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.

STEP BOUNDARIES:
This check excludes:

* applying AHP
* generating AHP Gate output
* changing checked prior artifacts outside the MIP output YAML
* changing the checked MIP Gate result
* changing PMS.yaml or MIP - Maturity in Practice.yaml
* adding source material, files, inferred case facts, or unavailable context
* treating MIP output as proof, verdict, diagnosis, person ranking, dignity score, maturity judgment, mandate, publication permission, implementation permission, or finality
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* MIP - Maturity in Practice.yaml structure ignored, overwritten, or replaced
* checked prior outputs ignored, overwritten, or strengthened
* checked MIP Gate treated as MIP result rather than selection context
* MIP output treated as PMS-DISCIPLINE verdict
* A-score or M-score treated as hard score where MIP/source status does not license it
* A/M bands over-hardened beyond MIP - Maturity in Practice.yaml
* IA-box treated as verdict rather than asymmetry check
* D-module activated without warrant
* Dignity-in-Practice treated as ontological dignity, person ranking, or dignity score
* Red Zone review omitted or softened where required
* conditional person-near transfer pressure converted into real-person assessment
* constructed-case MIP use converted into hard A/M scoring, D activation, D-profile, IA-box verdict, maturity verdict, person ranking, or blame assignment
* boundary-focused MIP application over-expanded beyond the checked MIP Gate
* MIP application wrongly treating role/process-only material as person-capacity or dignity-in-practice evidence
* non-use or refusal conditions ignored
* source-status laundering
* evidence-burden overreach
* claim ceiling overreach
* person-nearness, publicness, irreversibility, or action-power pressure inflated into MIP authority
* loss of rival readings, non-capture, correctability, reopening conditions, or stop-capability
* unsupported strengthening of claims
* generated AHP, Case Record, Markdown article, or later pipeline artifacts

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the MIP Case Application YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template/source-derived field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep PMS operators, MIP structures, A–C–R–P–D categories, A-score/M-score handling, IA-box handling, D-module handling, and Red Zone categories unchanged.
* Keep claims at or below the level licensed by the CASE PACKET, checked prior artifacts, checked MIP Gate, and MIP - Maturity in Practice.yaml.
* If the MIP branch was entered only for conditional person-near transfer or boundary review, patch over-strong scoring, D activation, IA verdicts, person assessment, or maturity language back to bounded scan, boundary, burden, red-zone, or `not_applicable` language where the source permits.
* Exclude invented files, new source claims, AHP output, Case Record output, Markdown output, MIP authority drift, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a MIP Case Application YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the MIP Case Application YAML is usable for the next PMS-DISCIPLINE pipeline step without correction, return the mandatory YAML structure audit followed by:

MIP Case Application YAML checked. Ready for the next PMS-DISCIPLINE pipeline step.

If concrete defects can be conservatively corrected inside this step, return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
* COMPLETE CORRECTED MIP CASE APPLICATION YAML

If the output is not safely correctable inside this step, return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP
## Prompt #16 — Apply PMS-DISCIPLINE AHP Gate Template
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* pms_discipline_ahp_gate_template.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* MIP - Maturity in Practice.yaml was read earlier if MIP was applied.
* Checked MIP Case Application YAML is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply pms_discipline_ahp_gate_template.yaml to determine whether the checked MIP output should proceed to AHP source reading, remain without AHP, require revision, downgrade, suspension, refusal, redirection, or human review.

PURPOSE:
Produce a completed PMS-DISCIPLINE AHP Gate YAML.

TECHNICAL INSTRUCTIONS:

* Use only the provided AHP Gate template, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and checked MIP output.
* Use the AHP Gate template as the only output structure.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from the available inputs.
* Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Treat the AHP Gate as a bounded checkpoint for whether AHP source reading is warranted.
* Keep AHP recommendation separate from AHP application, Precision Heuristic generation, Attack Points generation, Hardening Backlog generation, scoring, assessment, publication permission, or finality.
* Preserve source status, intended use, claim ceiling, non-capture, rival pressure, correctability, reopening conditions, and stop-capability from checked prior artifacts.

STEP BOUNDARIES:
This step excludes:

* reading or applying an AHP source
* producing AHP output
* generating Precision Heuristic, Attack Points, or Hardening Backlog
* changing checked prior artifacts
* rescoring A-score, M-score, IA-box, D-module, or other MIP structures
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts

AHP GATE SCOPE:
This step may produce:

* checked prior output import
* checked MIP output import
* existing MIP analysis requirement review
* structured case fields requirement review
* AHP trigger review
* precision-need review
* attack-surface need review
* hardening-need review
* transmission and reuse review
* score hygiene and D-language review
* non-interference review
* non-trigger review
* rival and non-capture review
* correctability review
* AHP recommendation output
* AHP gate handoff
* AHP gate quality checks
* final AHP gate status

CLAIM DISCIPLINE:

* Keep claims at or below the ceiling set by checked prior artifacts.
* Mark AHP pressure as pressure only, not as AHP result.
* Treat AHP as optional second-order analysis-quality overlay, not as a case judgment.
* Preserve MIP sufficiency where AHP is not structurally warranted.
* Treat transmission, reuse, publicness, score language, D-language, and hardening pressure as caution signals, not automatic AHP triggers.
* Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed PMS-DISCIPLINE AHP Gate YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #17 — Check PMS-DISCIPLINE AHP Gate YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_discipline_ahp_gate_template.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* Checked MIP Case Application YAML is present in this conversation/session.
* The PMS-DISCIPLINE AHP Gate Template was applied in the previous step.
* The AHP Gate YAML from the previous step is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the AHP Gate YAML from the previous step for structural and substantive conformity with the AHP Gate template, PMS.yaml, checked prior YAML artifacts, checked MIP output, and the bounded task.

PURPOSE:
Determine whether the AHP Gate YAML is usable as checked gate output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it sufficiently conforms to the template, checked prior outputs, and AHP gate boundaries.

TECHNICAL INSTRUCTIONS:

* Use only the AHP Gate YAML from the previous step, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, checked MIP output, and the previously applied AHP Gate template structure.
* Re-run the AHP Gate from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, checked-output imports, existing MIP analysis review, structured case fields review, trigger review, precision review, attack-surface review, hardening review, non-interference review, recommendation output, handoff, quality checks, and final gate status.
* Check substantive conformity: AHP recommendation restraint, source-status discipline, MIP-output preservation, non-interference with MIP scores/modules, claim ceiling, transmission and reuse risk, D-language risk, score hygiene, hardening pressure, rival pressure, non-capture, correctability, reopening conditions, and non-authority boundaries.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.

STEP BOUNDARIES:
This check excludes:

* reading or applying an AHP source
* producing AHP output
* generating Precision Heuristic, Attack Points, or Hardening Backlog
* changing checked prior artifacts outside the AHP Gate YAML
* rescoring A-score, M-score, IA-box, D-module, or other MIP structures
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* checked prior outputs ignored, overwritten, or strengthened
* AHP recommendation treated as AHP application
* AHP pressure treated as score, verdict, assessment, publication permission, or finality
* Precision Heuristic, Attack Points, or Hardening Backlog generated inside the gate
* MIP A-score, M-score, IA-box, D-module, or other structures rescored or altered
* non-interference review omitted or softened
* transmission, reuse, publicness, D-language, score-language, or hardening pressure inflated into automatic AHP use
* source-status laundering
* claim ceiling overreach
* loss of rival readings, non-capture, correctability, or reopening conditions
* unsupported strengthening of claims
* generated later pipeline artifacts

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the AHP Gate YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep PMS operators, MIP structures, and AHP-specific gate categories unchanged.
* Keep claims at or below the level licensed by the CASE PACKET and checked prior artifacts.
* Exclude invented files, new source claims, AHP application output, MIP rescoring, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a PMS-DISCIPLINE AHP Gate YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the AHP Gate YAML is usable for the next PMS-DISCIPLINE pipeline step without correction, return the mandatory YAML structure audit followed by:

PMS-DISCIPLINE AHP Gate YAML checked. Ready for the next allowed PMS-DISCIPLINE pipeline step named in the checked gate output.

If concrete defects can be conservatively corrected inside this step, return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
* COMPLETE CORRECTED PMS-DISCIPLINE AHP GATE YAML

If the output is not safely correctable inside this step, return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP
## Prompt #18 — Apply AHP Module
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* MIP - Maturity in Practice - AHP Module.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* Checked MIP Case Application YAML is present in this conversation/session.
* Checked PMS-DISCIPLINE AHP Gate YAML is present in this conversation/session.
* The checked AHP Gate names AHP application or AHP source use as the next allowed step.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Apply the AHP module from "MIP - Maturity in Practice - AHP Module.yaml" to the checked MIP Case Application YAML under the constraints of PMS.yaml, checked prior YAML artifacts, and the checked AHP Gate.

PURPOSE:
Produce a completed AHP Module Output YAML as an optional second-order analysis-quality overlay for the checked MIP output.

TECHNICAL INSTRUCTIONS:

* Use only the provided AHP module, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, checked MIP output, and checked AHP Gate.
* Use the AHP module’s case schema / overlay structure as the output structure for this step.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the AHP case-application structure, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from the available inputs.
* Use unknown, unclear, not_applicable, missing, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Treat AHP as an optional second-order analysis-quality overlay for precision, attack-surface visibility, and hardening backlog.
* Keep AHP subordinate to checked MIP output, PMS Base, source status, intended use, claim ceiling, non-capture, rival pressure, correctability, and reopening conditions.
* Preserve the AHP non-interference rule: AHP does not alter MIP A-score, M-score, IA-box, D-module, Red Zones, source status, or checked prior outputs.
* Generate only AHP-specific overlay content licensed by the AHP module and the checked AHP Gate.

STEP BOUNDARIES:
This step excludes:

* re-running Pre-Analysis, Core, Add-on Gate, Add-on Application, MIP Gate, MIP Application, or AHP Gate
* changing checked prior artifacts
* rescoring A-score, M-score, IA-box, D-module, or other MIP structures
* activating D-module or creating D-profiles
* treating AHP as person assessment, maturity verdict, score, ranking, publication permission, or finality
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts

AHP APPLICATION SCOPE:
This step may produce:

* AHP Module Output YAML
* Precision Heuristic Summary
* Attack Points / attack-surface visibility
* Hardening Backlog
* scope-leakage review
* evidence-linkage review
* misreadability review
* transmission-status review
* score-hygiene and D-language review
* reversibility and iteration review
* non-interference confirmation
* AHP quality checks
* AHP handoff to output check

CLAIM DISCIPLINE:

* Keep claims at or below the ceiling set by checked prior artifacts.
* Treat AHP output as analysis-quality support, not as case judgment.
* Mark attack points as review points, not as defects proven by AHP itself.
* Mark hardening backlog items as next-iteration tasks, not as mandates.
* Preserve MIP output without strengthening or weakening its scores/modules.
* Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

- exactly one YAML document;
- exact root key and root type;
- no missing required key;
- no unexpected key or section;
- no duplicate key;
- mapping/list/scalar types match the supplied structure;
- repeated list items preserve the expected item schema;
- explicitly defined allowed values are respected exactly;
- no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
- field order is preserved as far as possible;
- no standalone `---` or `...` appears at the end.

Do not print this self-check. Return only the requested YAML.

OUTPUT:
Return only the completed AHP Module Output YAML.
Use a fenced `yaml` code block only if the chat interface requires separation. Do not append a standalone `---` or `...` after the YAML.
## Prompt #19 — Check AHP Module Output YAML
You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- MIP - Maturity in Practice - AHP Module.yaml

The listed template/source must be supplied again in this check step. Do not rely only on memory of a previously uploaded structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present in this conversation/session.
* Checked MIP Case Application YAML is present in this conversation/session.
* Checked PMS-DISCIPLINE AHP Gate YAML is present in this conversation/session.
* The AHP module was applied in the previous step.
* The AHP Module Output YAML from the previous step is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

TASK:
Check the AHP Module Output YAML from the previous step for structural and substantive conformity with the AHP module, PMS.yaml, checked prior YAML artifacts, checked MIP output, checked AHP Gate, and the bounded task.

PURPOSE:
Determine whether the AHP Module Output YAML is usable as checked AHP output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it remains structurally valid, non-interfering, bounded, and consistent with AHP’s role as second-order analysis-quality overlay.

TECHNICAL INSTRUCTIONS:

* Use only the AHP Module Output YAML from the previous step, the AHP module structure, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, checked MIP output, and checked AHP Gate.
* Re-run AHP application from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, Precision Heuristic Summary, Attack Points, Hardening Backlog, quality checks, non-interference fields, and final status.
* Check substantive conformity: AHP optional-overlay role, MIP-output preservation, non-interference with scores/modules, source-status discipline, claim ceiling, attack-surface accuracy, hardening backlog restraint, transmission-status handling, score hygiene, D-language caution, rival pressure, non-capture, correctability, and reopening conditions.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.

STEP BOUNDARIES:
This check excludes:

* re-running prior pipeline stages
* changing checked prior artifacts outside the AHP output YAML
* rescoring A-score, M-score, IA-box, D-module, or other MIP structures
* activating D-module or creating D-profiles
* converting attack points into proven defects
* converting hardening backlog into mandate, publication permission, implementation permission, or finality
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* checked prior outputs ignored, overwritten, or strengthened
* AHP output treated as case judgment, score, ranking, maturity verdict, or finality
* MIP A-score, M-score, IA-box, D-module, Red Zones, or checked MIP structures altered
* Precision Heuristic used as authority rather than analysis-quality summary
* Attack Points treated as proven failures rather than review surfaces
* Hardening Backlog treated as mandate rather than next-iteration support
* source-status laundering
* claim ceiling overreach
* transmission-status upgrade without support
* score-hygiene or D-language risks omitted
* loss of rival readings, non-capture, correctability, or reopening conditions
* generated later pipeline artifacts

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the AHP Module Output YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep PMS operators, checked MIP structures, and AHP overlay categories unchanged.
* Keep claims at or below the level licensed by the CASE PACKET and checked prior artifacts.
* Exclude invented files, new source claims, MIP rescoring, AHP authority drift, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains an AHP Module Output YAML only.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If no correction is needed, follow the audit with the prompt's ready status.

If correction is made:

- list only concrete corrections;
- return the complete corrected YAML;
- then provide `### Final YAML structure audit` with all ten items repeated for the corrected YAML;
- every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

If safe correction is impossible, provide the audit, blocking issues, required corrections, and next allowed step. Do not fabricate missing case content merely to satisfy structure.

OUTPUT:
If the AHP Module Output YAML is usable for the next PMS-DISCIPLINE pipeline step without correction, return the mandatory YAML structure audit followed by:

AHP Module Output YAML checked. Ready for the next PMS-DISCIPLINE pipeline step.

If concrete defects can be conservatively corrected inside this step, return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* FINAL YAML STRUCTURE AUDIT: repeat all ten structure-audit items for the corrected YAML
* COMPLETE CORRECTED AHP MODULE OUTPUT YAML

If the output is not safely correctable inside this step, return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP
## Prompt #20 — Apply PMS-DISCIPLINE Case Record Stage 1 Artifact Index

You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* pms_case_record_stage_1_artifact_index_template.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present if MIP routing occurred.
* MIP - Maturity in Practice.yaml was read earlier if MIP was applied.
* MIP Case Application YAML and its output-check result are present if MIP was applied.
* Checked PMS-DISCIPLINE AHP Gate YAML is present if AHP routing occurred.
* AHP module YAML was read earlier if AHP was applied.
* AHP Module Output YAML and its output-check result are present if AHP was applied.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

AUTHORITATIVE MANUAL RUN MANIFEST (USER-SUPPLIED):
{MANUAL_STAGE_1_MANIFEST}

CURRENT-STEP SELF-REFERENCE RULE:

* Stage 1 indexes upstream run artifacts from steps #1–#19 only.
* The current Stage 1 output path is manual execution metadata, not an upstream artifact.
* Do not list the current Stage 1 output as produced, missing, deferred, selected, excluded, superseded, or deliberately not imported.
* The current output does not need to exist before generation.
* Do not infer or enumerate unselected local source and template files. Preserve their route status using not_selected, not_applicable, skipped, or another template-allowed bounded marker, with no invented path or presence claim.

SOURCE AUTHORITY HIERARCHY:
For run metadata, file existence, exact paths, route state, branch state, and step status, use this order:

1. Authoritative Manual Run Manifest
2. Checked upstream artifact
3. Generated downstream artifact
4. Template default or placeholder
5. Model inference

Conflict rule:

* A higher source always overrides a lower source for the same metadata field.
* Copy manual-manifest values exactly. Do not normalize paths, abbreviate them, or replace an output path with session.json.
* Template defaults are placeholders, not evidence.
* Model inference may fill only fields genuinely absent from every higher source, and then only with an explicit bounded marker.

TASK:
Apply pms_case_record_stage_1_artifact_index_template.yaml to produce a complete artifact index for the current PMS-DISCIPLINE pipeline run.

PURPOSE:
Produce a Stage 1 Artifact Index YAML that records which source files, case materials, templates, checked outputs, optional branches, skipped branches, and missing artifacts exist for this run.

TECHNICAL INSTRUCTIONS:

* Use only the provided Stage 1 template, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and available source/read-status information.
* Use the Stage 1 template as the only output structure.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from the available inputs.
* Use present, absent, not_applicable, skipped, missing, unknown, unclear, unresolved, under_specified, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Distinguish PMS/MIP/AHP source files, user-provided case materials, templates, read confirmations, unchecked outputs, checked outputs, optional branches, skipped branches, and unavailable artifacts.
* Populate the template case_material_index from the user-supplied manual case-material inventory. Preserve exact case-relative paths, descriptions, purposes, hashes, and file-presence status.
* Material presence is not evidence, correctness, completeness, relevance, or successful reading. Preserve step #1 reading limitations if the record contains them.
* Preserve branch status for selected add-on, MIP, and AHP.
* Mark unselected add-ons as unselected, skipped, or not_applicable rather than silently omitting them.
* Preserve source status, intended use, claim ceiling, and artifact provenance where visible.
* Treat the user-supplied manual manifest above as authoritative for local path, file-presence, route, skipped-branch, and produced-output status.
* Use only project-relative source/template paths, case-relative material paths, and case-relative output paths from the manual manifest.
* Ignore AI-service attachment names, /mnt/data paths, sandbox paths, renamed uploads, duplicate attachments, helper scripts, and other service-local files.
* Do not invent SHA-256 values. If the manual manifest does not provide a hash, set sha256_if_available to unknown.
* The Stage 2 and Stage 3 templates are future-step resources in the manual workflow. Mark them deferred, not missing or expected_but_missing. Their current non-upload status is not a Stage 1 blocker.
* Local presence of an unselected add-on source or template does not mean it was read or applied. Unselected add-on outputs are not_applicable and must not receive an output path.
* A deliberately skipped MIP or AHP branch is not a missing-artifact defect.
* ready_for_stage_2 may be yes when all actual current-run artifacts and branch statuses are accurately marked. It must not be set to no solely because a future-step Stage 2 or Stage 3 template has not yet been uploaded.

STEP BOUNDARIES:
This step excludes:

* re-running Pre-Analysis, Core, Add-on Gate, Add-on Application, MIP Gate, MIP Application, AHP Gate, or AHP Application
* checking or patching prior outputs
* extracting layer digests
* integrating a full record
* changing checked prior artifacts
* producing new substantive analysis
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts

STAGE 1 SCOPE:
This step may produce:

* source file inventory
* case-material inventory
* template inventory
* checked output inventory
* read-confirmation inventory
* optional branch inventory
* skipped branch inventory
* missing artifact inventory
* source-status and intended-use index
* artifact dependency map
* Stage 1 readiness status for Stage 1 output check

CLAIM DISCIPLINE:

* Treat Stage 1 as an artifact index only.
* Artifact or case-material presence does not imply correctness, truth, relevance, or successful reading.
* Checked status records prior output-check status; it does not create new authority.
* Missing or skipped artifacts remain visible.
* Optional branches remain optional.
* Mark uncertainty explicitly.

OUTPUT:
Return only the completed PMS-DISCIPLINE Stage 1 Artifact Index YAML.
Wrap the YAML in a fenced yaml code block if the chat interface requires separation.

---
## Prompt #21 — Check PMS-DISCIPLINE Case Record Stage 1 Artifact Index

You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_case_record_stage_1_artifact_index_template.yaml

The listed template must be supplied again in this check step. Do not rely only on memory of a previously supplied structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present if MIP routing occurred.
* Checked MIP Case Application YAML is present if MIP was applied.
* Checked PMS-DISCIPLINE AHP Gate YAML is present if AHP routing occurred.
* Checked AHP Module Output YAML is present if AHP was applied.
* The Stage 1 Artifact Index YAML from the previous step is present in this conversation/session.
* Manually listed case materials and their step #1 read status are present in the authoritative manual run manifest where configured.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

AUTHORITATIVE MANUAL RUN MANIFEST (USER-SUPPLIED):
{MANUAL_STAGE_1_MANIFEST}

STAGE-1 SELF-REFERENCE CHECK RULE:

* The Stage 1 YAML under review indexes upstream run artifacts from steps #1–#19.
* Step #20 is the artifact under review and is not required to index its own output path.
* Absence of `outputs/step_20_stage_1_artifact_index.yaml` from the Stage 1 inventory is not a defect.
* A Stage 1 YAML that imports its own current production status as an upstream artifact should be conservatively corrected by removing that self-reference.
* Do not require a complete installation inventory. Unselected local sources and templates may remain not_selected or not_applicable without a path or local-presence assertion.

SOURCE AUTHORITY HIERARCHY:
For run metadata, file existence, exact paths, route state, branch state, and step status, use this order:

1. Authoritative Manual Run Manifest
2. Checked upstream artifact
3. Stage 1 output under review
4. Template default or placeholder
5. Model inference

A higher source overrides a lower source. Copy manual-manifest values exactly. Never substitute session.json for a produced output path unless the manual manifest itself names session.json for that field.

TASK:
Check the Stage 1 Artifact Index YAML from the previous step for structural and substantive conformity with the Stage 1 template, checked prior artifacts, source/read-status information, and the bounded task.

PURPOSE:
Determine whether the Stage 1 Artifact Index YAML is usable as checked Stage 1 output for Stage 2. Where necessary, conservatively correct it so that it accurately records the artifact state of this pipeline run.

TECHNICAL INSTRUCTIONS:

* Use only the Stage 1 Artifact Index YAML from the previous step, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and the previously applied Stage 1 template structure.
* Re-run Stage 1 from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, artifact inventories, branch inventories, dependency map, status fields, and readiness fields.
* Check substantive conformity: artifact existence, case-material inventory fidelity, checked-output status, source/read-status distinction, optional branch status, skipped branch status, missing artifact status, source status, intended use, and dependency ordering.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative and bounded.
* Use explicit uncertainty markers instead of inferential gap-filling.
* Treat the user-supplied manual manifest above as authoritative for local paths, route states, skipped branches, and produced output existence.
* Reject or correct AI-service-local paths, including /mnt/data paths, sandbox paths, renamed upload copies, duplicate attachment names, and helper scripts.
* Reject invented SHA-256 values. Use unknown when the manual manifest supplies no hash.
* Stage 2 and Stage 3 templates must be deferred future-step resources, not missing or expected_but_missing artifacts. Their non-upload during Stage 1 must not block Stage 2 readiness.
* Local presence of unselected add-on sources/templates must not be converted into selected, read, applied, or produced output status.
* Skipped MIP or AHP branches must remain visible as skipped or not_applicable, not as defects.
* If the only stated blocker is that the Stage 2 or Stage 3 template was not uploaded during Stage 1, correct that blocker, mark the future templates deferred, and set readiness according to the actual run artifacts.

STEP BOUNDARIES:
This check excludes:

* re-running prior pipeline stages
* changing checked prior artifacts outside the Stage 1 YAML
* extracting layer digests
* integrating a full record
* producing new substantive analysis
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* checked outputs mislabeled as unchecked or absent
* unchecked outputs mislabeled as checked
* optional branches silently omitted
* skipped branches mislabeled as absent defects
* source files confused with templates
* templates confused with applied outputs
* read confirmations confused with analysis outputs
* case materials omitted, assigned an invented path/hash, confused with model sources/templates, or treated as evidence merely because present
* artifact presence treated as correctness
* source-status laundering
* claim ceiling overreach
* generated Stage 2 or Stage 3 content inside Stage 1

MANDATORY CRITERIA LEDGER:
Evaluate every criterion separately and mark it PASS or FAIL. A general statement such as “coherent,” “complete,” or “ready” is not sufficient.

1. YAML parses and preserves the Stage 1 root, required sections, required fields, and field order as far as possible.
2. Every completed upstream step output from steps #1–#19 that is relevant to the selected route appears with the exact case-relative output path from the manual manifest; the Stage 1 output under review is not required to index itself.
3. No completed upstream output is represented only by session.json unless the manual manifest explicitly assigns session.json to that artifact field.
4. Route, selected add-on, MIP, AHP, skipped-branch, and produced-output states match the manual manifest exactly.
5. Every configured case material is represented in case_material_index with the exact manual-manifest path, description, purpose, file-presence status, and supplied hash; no material is treated as a model source, template, or evidence merely because present.
6. Stage 2 and Stage 3 templates are marked deferred future-step resources, not missing or expected_but_missing.
7. No /mnt/data path, sandbox path, renamed attachment, duplicate upload name, helper script, or service-local file is treated as a run artifact.
8. No SHA-256 value is invented; unavailable hashes are marked unknown.
9. Unselected add-ons remain unselected/not_applicable and have no produced output path.
10. Skipped MIP or AHP branches remain visible and are not treated as missing-artifact defects.
11. Source status and intended use match the CASE PACKET exactly.
12. ready_for_stage_2 and blocker_notes follow the actual current-run artifacts; future-template upload state is not a blocker.
13. Stage 1 contains no layer digest, Stage 3 integration, new case analysis, later-pipeline content, or self-reference that treats step #20 as its own upstream artifact.

READINESS RULE:
The output may be declared ready only if every criterion is PASS after any correction. Any FAIL must be corrected inside Stage 1 or reported as blocking.

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If correction is made, provide `### Final YAML structure audit` after the complete corrected YAML and repeat all ten items for the corrected document. Every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the Stage 1 Artifact Index YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep claims at or below the level licensed by the artifact state and checked prior outputs.
* Exclude invented files, invented read confirmations, new source claims, layer digests, full-record integration, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a PMS-DISCIPLINE Stage 1 Artifact Index YAML only.

OUTPUT:
After the mandatory YAML structure audit, return the completed criteria ledger, with all 13 numbered criteria marked PASS or FAIL and one concise reason per criterion.

If all criteria are PASS without correction, then return:

* CHECK STATUS: ready
* FINAL RESULT: PMS-DISCIPLINE Stage 1 Artifact Index YAML checked. Ready for Stage 2 Layer Digest Extraction.

If concrete defects can be conservatively corrected inside this step, then return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* CRITERIA AFTER CORRECTION: repeat all 13 criteria as PASS or FAIL
* COMPLETE CORRECTED PMS-DISCIPLINE STAGE 1 ARTIFACT INDEX YAML

If the output is not safely correctable inside this step, then return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP

Do not declare ready while any criterion remains FAIL.

---
## Prompt #22 — Apply PMS-DISCIPLINE Case Record Stage 2 Layer Digest Extraction

You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* pms_case_record_stage_2_layer_digest_extraction_template.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present if MIP routing occurred.
* Checked MIP Case Application YAML is present if MIP was applied.
* Checked PMS-DISCIPLINE AHP Gate YAML is present if AHP routing occurred.
* Checked AHP Module Output YAML is present if AHP was applied.
* Checked Stage 1 Artifact Index YAML is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

AUTHORITATIVE MANUAL CASE-RECORD MANIFEST (USER-SUPPLIED):
{MANUAL_CASE_RECORD_MANIFEST}

CURRENT-STEP OUTPUT RULE:

* The current step's expected output path, current status, and temporary output-existence value are manual execution metadata only.
* Do not copy current-step execution metadata into the generated or reviewed YAML.
* Do not place the current step's own output status in notes, missing-item registers, deliberately-not-imported items, workflow findings, tensions, blockers, readiness fields, or case findings.
* The current output does not need to exist before generation and must not be classified as missing, deferred, excluded, unresolved, or deliberately not imported.
* Preserve genuine substantive contradictions, but do not convert temporary workflow metadata into case substance.

SOURCE AUTHORITY HIERARCHY:

For exact metadata and provenance:
1. Authoritative Manual Case-Record Manifest
2. Checked Stage 1 Artifact Index
3. Checked layer artifact
4. Stage 2 template default or placeholder
5. Model inference

For substantive digest content:
1. The corresponding checked layer artifact
2. Checked Stage 1 only for selection, status, and provenance
3. Stage 2 template structure
4. Model inference only as an explicit bounded marker

Conflict rules:

* Exact paths, file existence, routes, branch states, and step states follow the manual manifest.
* Artifact selection and provenance follow checked Stage 1 unless the manual manifest exposes an exact metadata conflict, in which case the manual manifest controls that metadata field.
* Copy each selected artifact path exactly. Do not replace it with session.json, a chat attachment name, or a temporary path.
* Preserve genuine substantive contradictions between checked artifacts; do not resolve them through template hierarchy or inference.

TASK:
Apply pms_case_record_stage_2_layer_digest_extraction_template.yaml to extract bounded layer digests from checked pipeline artifacts.

PURPOSE:
Produce a Stage 2 Layer Digest Extraction YAML that summarizes the checked outputs layer by layer without re-running, correcting, strengthening, or integrating them.

TECHNICAL INSTRUCTIONS:

* Use only the provided Stage 2 template, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, and checked Stage 1 Artifact Index YAML.
* Use the Stage 2 template as the only output structure.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from checked artifacts only.
* Use not_applicable, skipped, absent, unknown, unclear, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Extract only digest-level content from checked artifacts.
* For PMS Core digests, preserve each operator's canonical identity, canonical name, definition-level function, dependency status, analytic weight, and checked case-specific role.
* Do not rename, repurpose, merge, or substitute PMS operators during compression.
* A case-specific gloss may explain an operator's role, but it must not replace the canonical operator meaning.
* For example, `Λ` remains `Non-Event` and may represent a structured absence or expected occurrence that fails, remains delayed, or remains unresolved within a frame. It must not be redefined as continuity merely because continuity is present elsewhere in the case.
* When a compact digest cannot preserve an operator distinction safely, use a more general description without assigning that description to the wrong operator.
* Preserve each layer’s claim ceiling, non-use, skipped-branch status, uncertainty, correctability, rival pressure, and handoff.
* Keep selected add-on, MIP, and AHP digests separate.
* Keep AHP as optional second-order analysis-quality overlay where present.
* Preserve AHP non-interference: AHP does not alter MIP scores, bands, boxes, modules, source status, or checked prior outputs.

STEP BOUNDARIES:
This step excludes:

* re-running Pre-Analysis, Core, Add-on Gate, Add-on Application, MIP Gate, MIP Application, AHP Gate, or AHP Application
* checking or patching prior outputs
* changing Stage 1
* integrating a full record
* producing new substantive analysis
* resolving contradictions by interpretation
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts

STAGE 2 SCOPE:
This step may produce:

* Pre-Analysis digest
* Core digest
* Add-on Gate digest
* selected add-on digest if applicable
* MIP Gate digest if applicable
* MIP digest if applicable
* AHP Gate digest if applicable
* AHP digest if applicable
* skipped branch digest
* non-use digest
* uncertainty digest
* rival pressure digest
* claim ceiling digest
* correctability and reopening digest
* Stage 2 export for Stage 3 integration
* Source-read confirmations may be indexed from Stage 1, but Stage 2 digest content must come from checked outputs, not from source files alone.

CLAIM DISCIPLINE:

* Treat Stage 2 as digest extraction only.
* Digest does not replace the checked source artifact.
* Digest compression must not strengthen claims.
* Digest compression must not erase uncertainty, non-use, skipped branches, or source limitations.
* Preserve contradictions as contradictions where checked artifacts leave them unresolved.
* Mark uncertainty explicitly.

OUTPUT:
Return only the completed PMS-DISCIPLINE Stage 2 Layer Digest Extraction YAML.
Wrap the YAML in a fenced yaml code block if the chat interface requires separation.

---
## Prompt #23 — Check PMS-DISCIPLINE Case Record Stage 2 Layer Digest Extraction

You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_case_record_stage_2_layer_digest_extraction_template.yaml

The listed template must be supplied again in this check step. Do not rely only on memory of a previously supplied structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present if MIP routing occurred.
* Checked MIP Case Application YAML is present if MIP was applied.
* Checked PMS-DISCIPLINE AHP Gate YAML is present if AHP routing occurred.
* Checked AHP Module Output YAML is present if AHP was applied.
* Checked Stage 1 Artifact Index YAML is present in this conversation/session.
* The Stage 2 Layer Digest Extraction YAML from the previous step is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

AUTHORITATIVE MANUAL CASE-RECORD MANIFEST (USER-SUPPLIED):
{MANUAL_CASE_RECORD_MANIFEST}

CURRENT-STEP OUTPUT RULE:

* The current step's expected output path, current status, and temporary output-existence value are manual execution metadata only.
* Do not copy current-step execution metadata into the generated or reviewed YAML.
* Do not place the current step's own output status in notes, missing-item registers, deliberately-not-imported items, workflow findings, tensions, blockers, readiness fields, or case findings.
* The current output does not need to exist before generation and must not be classified as missing, deferred, excluded, unresolved, or deliberately not imported.
* Preserve genuine substantive contradictions, but do not convert temporary workflow metadata into case substance.

SOURCE AUTHORITY HIERARCHY:

For exact metadata and provenance:
1. Authoritative Manual Case-Record Manifest
2. Checked Stage 1 Artifact Index
3. Stage 2 output under review
4. Stage 2 template default or placeholder
5. Model inference

For substantive digest content, the corresponding checked layer artifact controls. Checked Stage 1 controls selection and provenance. Template defaults and model inference cannot override either.

TASK:
Check the Stage 2 Layer Digest Extraction YAML from the previous step for structural and substantive conformity with the Stage 2 template, checked prior artifacts, checked Stage 1 output, and the bounded task.

PURPOSE:
Determine whether the Stage 2 Layer Digest Extraction YAML is usable as checked Stage 2 output for Stage 3. Where necessary, conservatively correct it so that it accurately extracts and preserves digest-level content without reanalysis or claim strengthening.

TECHNICAL INSTRUCTIONS:

* Use only the Stage 2 Layer Digest Extraction YAML from the previous step, CASE PACKET, PMS.yaml context, checked prior YAML artifacts, checked Stage 1 output, and the previously applied Stage 2 template structure.
* Re-run Stage 2 from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, layer digests, skipped branch digest, non-use digest, claim ceiling digest, correctability digest, and Stage 3 export.
* Check substantive conformity: digest fidelity, checked-artifact grounding, branch separation, source-status discipline, claim-ceiling preservation, uncertainty preservation, non-use preservation, MIP/AHP separation, AHP non-interference, rival pressure, correctability, and reopening conditions.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.

STEP BOUNDARIES:
This check excludes:

* re-running prior pipeline stages
* changing checked prior artifacts outside the Stage 2 YAML
* changing checked Stage 1
* integrating a full record
* producing new substantive analysis
* resolving contradictions by interpretation
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* digest content not grounded in checked artifacts
* PMS operator identity or function changed during digest compression
* compression that strengthens claims
* compression that erases uncertainty or source limits
* skipped branches omitted or misrepresented
* non-use converted into deficiency
* selected add-on, MIP, or AHP digests mixed together
* AHP output treated as MIP correction or rescoring
* Attack Points treated as proven defects
* Hardening Backlog treated as mandate
* Precision Heuristic treated as authority
* source-status laundering
* claim ceiling overreach
* loss of rival readings, non-capture, correctability, or reopening conditions
* generated Stage 3 integration inside Stage 2

MANDATORY CRITERIA LEDGER:
Evaluate every criterion separately and mark it PASS or FAIL. A general statement such as “coherent,” “faithful,” or “ready” is not sufficient.

1. YAML parses and preserves the Stage 2 root, required sections, required fields, and field order as far as possible.
2. The imported Stage 1 reference and every upstream case-record output path match the manual manifest exactly; current-step execution metadata is not imported into Stage 2.
3. selected_artifacts_to_read matches checked Stage 1 exactly; no unselected, skipped, absent, or unavailable artifact is silently read.
4. Every digest identifies the exact selected source artifact path; session.json is not used as a substitute unless explicitly assigned by the manual manifest or checked Stage 1.
5. Each substantive digest is grounded in its corresponding checked layer artifact and contains no new analysis; every PMS operator preserves its canonical identity, canonical function, and checked case-specific role without renaming, repurposing, merging, or substitution.
6. Route, branch, skipped, rejected, non-use, and not_applicable states are preserved exactly.
7. Digest compression does not strengthen claims, erase uncertainty, erase source limits, or turn contradictions into resolved findings.
8. Core, selected add-on, MIP, and AHP remain separate; AHP does not rescore or correct MIP.
9. Rival pressure, non-capture, claim ceiling, correctability, reopening conditions, and stop-capability are preserved where present.
10. Attack Points are not treated as proven defects, Hardening Backlog is not a mandate, and Precision Heuristic is not authority.
11. Stage 2 contains no Stage 3 integration, article prose, new source material, or later-pipeline artifact.
12. Stage 3 export/readiness fields accurately reflect the checked Stage 2 result and any real blockers.

READINESS RULE:
The output may be declared ready only if every criterion is PASS after any correction. Any FAIL must be corrected inside Stage 2 or reported as blocking.

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If correction is made, provide `### Final YAML structure audit` after the complete corrected YAML and repeat all ten items for the corrected document. Every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the Stage 2 Layer Digest Extraction YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep claims at or below the level licensed by checked artifacts and checked Stage 1.
* Exclude invented files, new source claims, new analysis, full-record integration, MIP rescoring, AHP authority drift, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a PMS-DISCIPLINE Stage 2 Layer Digest Extraction YAML only.

OUTPUT:
After the mandatory YAML structure audit, return the completed criteria ledger, with all 12 numbered criteria marked PASS or FAIL and one concise reason per criterion.

If all criteria are PASS without correction, then return:

* CHECK STATUS: ready
* FINAL RESULT: PMS-DISCIPLINE Stage 2 Layer Digest Extraction YAML checked. Ready for Stage 3 Full Record Integration.

If concrete defects can be conservatively corrected inside this step, then return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* CRITERIA AFTER CORRECTION: repeat all 12 criteria as PASS or FAIL
* COMPLETE CORRECTED PMS-DISCIPLINE STAGE 2 LAYER DIGEST EXTRACTION YAML

If the output is not safely correctable inside this step, then return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP

Do not declare ready while any criterion remains FAIL.

---
## Prompt #24 — Apply PMS-DISCIPLINE Case Record Stage 3 Full Record Integration

You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED:

* pms_case_record_stage_3_full_case_record_integration_template.yaml

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present if MIP routing occurred.
* Checked MIP Case Application YAML is present if MIP was applied.
* Checked PMS-DISCIPLINE AHP Gate YAML is present if AHP routing occurred.
* Checked AHP Module Output YAML is present if AHP was applied.
* Checked Stage 1 Artifact Index YAML is present in this conversation/session.
* Checked Stage 2 Layer Digest Extraction YAML is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

AUTHORITATIVE MANUAL CASE-RECORD MANIFEST (USER-SUPPLIED):
{MANUAL_CASE_RECORD_MANIFEST}

CURRENT-STEP OUTPUT RULE:

* The current step's expected output path, current status, and temporary output-existence value are manual execution metadata only.
* Do not copy current-step execution metadata into the generated or reviewed YAML.
* Do not place the current step's own output status in notes, missing-item registers, deliberately-not-imported items, workflow findings, tensions, blockers, readiness fields, or case findings.
* The current output does not need to exist before generation and must not be classified as missing, deferred, excluded, unresolved, or deliberately not imported.
* Preserve genuine substantive contradictions, but do not convert temporary workflow metadata into case substance.

SOURCE AUTHORITY HIERARCHY:

For exact metadata and provenance:
1. Authoritative Manual Case-Record Manifest
2. Checked Stage 1 Artifact Index
3. Checked Stage 2 Layer Digest Extraction
4. Stage 3 template default or placeholder
5. Model inference

For substantive integrated content:
1. Checked Stage 2 Layer Digest Extraction
2. Checked Stage 1 for provenance, route, branch, and artifact status only
3. Underlying checked artifacts only for a gap explicitly marked by Stage 1 or Stage 2
4. Stage 3 template structure
5. Model inference only as an explicit bounded marker

Conflict rules:

* Exact output paths and run states follow the manual manifest. In particular, the Stage 2 source reference must use the exact Step #22 output path, not session.json.
* Preserve genuine substantive contradictions as contradictions.
* Internal path discrepancies, template-status drift, attachment-name drift, and workflow QA notes are metadata issues, not substantive case findings.

TASK:
Apply pms_case_record_stage_3_full_case_record_integration_template.yaml to integrate checked Stage 1 and checked Stage 2 into a bounded full record for this PMS-DISCIPLINE pipeline run.

PURPOSE:
Produce a Stage 3 Full Record Integration YAML that consolidates artifact status, layer digests, branch status, claim ceiling, non-use, rival pressure, correctability, reopening conditions, and permitted next-step boundaries.

TECHNICAL INSTRUCTIONS:

* Use only the provided Stage 3 template, CASE PACKET, PMS.yaml context, checked Stage 1 Artifact Index YAML, checked Stage 2 Layer Digest Extraction YAML, and checked prior artifacts only where needed to verify fidelity to checked Stage 1 and checked Stage 2; Stage 3 must still fill from checked Stage 1 and checked Stage 2.
* Use the Stage 3 template as the only output structure.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no template field omitted.
* Fill fields precisely from checked Stage 1 and checked Stage 2.
* Use not_applicable, skipped, absent, unknown, unclear, unresolved, under_specified, insufficient, none, or another field-allowed bounded marker where the input does not license a stronger value.
* Integrate only what Stage 1 and Stage 2 already establish.
* Preserve canonical PMS operator identities and functions exactly as established by the checked Core and preserved by checked Stage 2.
* Do not use integration prose to rename, repurpose, merge, or substitute an operator.
* Preserve layer separation inside the integrated record.
* Preserve selected add-on, MIP, and AHP branch status.
* Preserve AHP as optional second-order analysis-quality overlay where present.
* Preserve AHP non-interference and MIP output integrity.
* Preserve source status, intended use, claim ceiling, non-capture, rival pressure, correctability, reopening conditions, and stop-capability.
* Record decision-state posture only as an integrated status; execution remains outside this stage.
* Treat Stage 3 lifecycle fields as generation-time state. A conforming Prompt #24 artifact may use `stage_3_full_record_ready_for_output_check`, `ready`, and `stage_3_output_check` to indicate that the generated record is ready for the separate Prompt #25 review.

STEP BOUNDARIES:
This step excludes:

* re-running prior pipeline stages
* checking or patching prior outputs
* changing checked Stage 1 or checked Stage 2
* producing new substantive analysis
* changing MIP scores, bands, boxes, modules, Red Zones, or source status
* treating AHP as MIP correction, MIP rescoring, or person assessment
* converting Attack Points into proven defects
* converting Hardening Backlog into mandate
* resolving contradictions by interpretation
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts

STAGE 3 SCOPE:
This step may produce:

* integrated artifact-status record
* integrated layer-digest record
* branch-status summary
* skipped-branch and non-use summary
* claim-ceiling summary
* uncertainty summary
* rival and non-capture summary
* correctability and reopening summary
* human-confirmation requirement summary where relevant
* permitted next-step boundary
* Stage 3 readiness status for Stage 3 output check

CLAIM DISCIPLINE:

* Treat Stage 3 as integration only.
* Integration does not create new authority.
* Integration must not strengthen checked prior claims.
* Integration must not erase uncertainty, skipped branches, non-use, source limitations, or rival pressure.
* Preserve unresolved contradictions where checked prior artifacts leave them unresolved.
* Mark uncertainty explicitly.

OUTPUT:
Return only the completed PMS-DISCIPLINE Stage 3 Full Record Integration YAML.
Wrap the YAML in a fenced yaml code block if the chat interface requires separation.

---
## Prompt #25 — Check PMS-DISCIPLINE Case Record Stage 3 Full Record Integration

You are continuing a PMS-DISCIPLINE pipeline run.

FILES PROVIDED FOR THIS CHECK:
- pms_case_record_stage_3_full_case_record_integration_template.yaml

The listed template must be supplied again in this check step. Do not rely only on memory of a previously supplied structure.

AVAILABLE CONTEXT:

* PMS.yaml was read earlier and remains the PMS Base reference.
* Checked Pre-Analysis YAML is present in this conversation/session.
* Checked Core Case Application YAML is present in this conversation/session.
* Checked Add-on Recommendation Gate YAML is present in this conversation/session.
* Checked selected PMS add-on case application YAML is present if an add-on was applied.
* Checked PMS-DISCIPLINE MIP Gate YAML is present if MIP routing occurred.
* Checked MIP Case Application YAML is present if MIP was applied.
* Checked PMS-DISCIPLINE AHP Gate YAML is present if AHP routing occurred.
* Checked AHP Module Output YAML is present if AHP was applied.
* Checked Stage 1 Artifact Index YAML is present in this conversation/session.
* Checked Stage 2 Layer Digest Extraction YAML is present in this conversation/session.
* The Stage 3 Full Record Integration YAML from the previous step is present in this conversation/session.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

AUTHORITATIVE MANUAL CASE-RECORD MANIFEST (USER-SUPPLIED):
{MANUAL_CASE_RECORD_MANIFEST}

CURRENT-STEP OUTPUT RULE:

* The current step's expected output path, current status, and temporary output-existence value are manual execution metadata only.
* Do not copy current-step execution metadata into the generated or reviewed YAML.
* Do not place the current step's own output status in notes, missing-item registers, deliberately-not-imported items, workflow findings, tensions, blockers, readiness fields, or case findings.
* The current output does not need to exist before generation and must not be classified as missing, deferred, excluded, unresolved, or deliberately not imported.
* Preserve genuine substantive contradictions, but do not convert temporary workflow metadata into case substance.

SOURCE AUTHORITY HIERARCHY:

For exact metadata and provenance:
1. Authoritative Manual Case-Record Manifest
2. Checked Stage 1 Artifact Index
3. Checked Stage 2 Layer Digest Extraction
4. Stage 3 output under review
5. Stage 3 template default or placeholder
6. Model inference

For substantive content, checked Stage 2 controls the integrated layer substance. Checked Stage 1 controls provenance, route, branch, and artifact status. Template defaults and model inference cannot override either.

TASK:
Check the Stage 3 Full Record Integration YAML from the previous step for structural and substantive conformity with the Stage 3 template, checked Stage 1, checked Stage 2, checked prior artifacts, and the bounded task.

PURPOSE:
Determine whether the Stage 3 Full Record Integration YAML is usable as checked integrated record output for the next PMS-DISCIPLINE pipeline step. Where necessary, conservatively correct it so that it remains structurally valid, bounded, non-authoritative, and faithful to checked Stage 1 and checked Stage 2.

TECHNICAL INSTRUCTIONS:

* Use only the Stage 3 Full Record Integration YAML from the previous step, CASE PACKET, PMS.yaml context, checked Stage 1, checked Stage 2, checked prior artifacts, and the previously applied Stage 3 template structure.
* Re-run Stage 3 from scratch only if the existing output is structurally unusable.
* Check structural conformity: root structure, required sections, required fields, valid YAML, integrated artifact record, integrated layer record, branch-status summary, skipped-branch summary, claim-ceiling summary, uncertainty summary, rival/correctability/reopening summary, human-confirmation summary, and next-step boundary.
* Check substantive conformity: fidelity to checked Stage 1 and checked Stage 2, source-status discipline, claim ceiling, non-use preservation, branch separation, MIP output preservation, AHP non-interference, rival pressure, non-capture, correctability, reopening conditions, stop-capability, and non-authority boundaries.
* Correct only the smallest necessary part.
* Preserve conforming content.
* Keep corrections conservative, bounded, and claim-weakening where needed.
* Use explicit uncertainty markers instead of inferential gap-filling.
* Treat Stage 3 lifecycle fields as generation-time artifact state. A conforming Prompt #24 record may remain `stage_3_full_record_ready_for_output_check`, `ready`, and `stage_3_output_check` while Prompt #25 records the separate check result. Do not patch those fields solely because this check is now being performed or completed.

STEP BOUNDARIES:
This check excludes:

* re-running prior pipeline stages
* changing checked prior artifacts outside the Stage 3 YAML
* changing checked Stage 1 or checked Stage 2
* producing new substantive analysis
* changing MIP scores, bands, boxes, modules, Red Zones, or source status
* treating AHP as MIP correction, MIP rescoring, person assessment, or authority layer
* converting Attack Points into proven defects
* converting Hardening Backlog into mandate
* resolving contradictions by interpretation
* adding source material, files, inferred case facts, or unavailable context
* generating later pipeline artifacts
* stylistic polish, extra reassurance, fuller commentary, or speculative completeness

CHECK SCOPE:
The check may identify and, where safely possible, correct:

* invalid YAML
* missing required sections or fields
* unresolved required placeholders
* unsupported source or file assumptions
* integrated content not grounded in checked Stage 1 or checked Stage 2
* integration that strengthens claims
* integration that erases uncertainty or source limits
* skipped branches omitted or misrepresented
* non-use converted into deficiency
* selected add-on, MIP, or AHP branches mixed together
* AHP output treated as MIP correction or rescoring
* Attack Points treated as proven defects
* Hardening Backlog treated as mandate
* Precision Heuristic treated as authority
* source-status laundering
* claim ceiling overreach
* loss of rival readings, non-capture, correctability, reopening conditions, or stop-capability
* generated later pipeline artifacts

MANDATORY CRITERIA LEDGER:
Evaluate every criterion separately and mark it PASS or FAIL. A general statement such as “coherent,” “bounded,” or “ready” is not sufficient.

1. YAML parses and preserves the Stage 3 root, required sections, required fields, and field order as far as possible.
2. generated_from and all case-record provenance paths match the manual manifest exactly, including the exact Step #20 and Step #22 output paths.
3. Stage 1 controls artifact, route, branch, skipped, and non-use metadata; Stage 2 controls substantive digest content.
4. Integrated content is grounded in checked Stage 1 and checked Stage 2 and introduces no new analysis; canonical PMS operator identities, functions, and checked case-specific roles remain unchanged.
5. Source status, intended use, claim ceiling, person-nearness, publicness, and irreversibility do not drift from controlling checked sources.
6. Selected add-on, MIP, and AHP remain separate; AHP does not rescore, correct, or authorize MIP.
7. Skipped, rejected, absent, not_applicable, and non-used layers remain visible and are not converted into deficiencies.
8. Genuine substantive contradictions, uncertainty, rival pressure, non-capture, correctability, reopening conditions, and stop-capability remain visible.
9. Internal path discrepancies, template-status drift, and workflow QA notes are not converted into substantive case findings.
10. Attack Points are not proven defects, Hardening Backlog is not a mandate, and Precision Heuristic is not authority.
11. The Stage 3 record preserves its generation-time lifecycle status, normally ready for the separate Stage 3 output check. Completion of this current review is recorded in the Prompt #25 check response and is not back-propagated into the Stage 3 record merely because the review has now occurred.
12. Stage 3 contains no article prose, new source material, later-pipeline artifact, truth certificate, release authorization, or implementation permission.

READINESS RULE:
The output may be declared ready only if every criterion is PASS after any correction. Any FAIL must be corrected inside Stage 3 or reported as blocking.

MANDATORY YAML STRUCTURE AUDIT — NO LOCAL VALIDATOR IS ASSUMED:
Before substantive review, compare the YAML under review recursively against the exact template or source-derived output structure supplied for this check.

Complete every item explicitly:

1. `yaml_parse`: PASS or FAIL — exactly one parseable YAML document; no trailing standalone `---` or `...`.
2. `root_match`: PASS or FAIL — exact root key and root mapping/list type.
3. `missing_keys`: `none` or a complete list of missing full key paths.
4. `unexpected_keys`: `none` or a complete list of unexpected full key paths.
5. `duplicate_keys`: `none` or a complete list of duplicate full key paths.
6. `type_mismatches`: `none` or full key paths with expected and actual mapping/list/scalar types.
7. `list_schema_mismatches`: `none` or full paths of list items that do not match the supplied item schema.
8. `invalid_explicit_values`: `none` or full key paths with actual value and explicitly allowed values.
9. `unresolved_placeholders`: `none` or full key paths of placeholders not replaced by case-supported or bounded values.
10. `field_order`: PASS or FAIL — preserved as far as possible; explain only material drift.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

STRUCTURE / SEMANTIC SEPARATION:
The structure audit is authoritative only for the audit performed in this check. It is not deterministic software validation, case evidence, semantic adequacy, truth certification, or authority. After the structure audit, perform the substantive review required by this prompt.

READINESS RULE:
Do not declare the YAML ready while `yaml_parse` or `root_match` is FAIL, or while any missing key, unexpected key, duplicate key, type mismatch, list-schema mismatch, invalid explicit value, or unresolved required placeholder remains.

AUDIT OUTPUT REQUIREMENT:
Always begin the response with `### YAML structure audit` and report all ten audit items above.

If correction is made, provide `### Final YAML structure audit` after the complete corrected YAML and repeat all ten items for the corrected document. Every blocking structure item must be PASS or `none` before the corrected artifact is declared ready.

PATCH DISCIPLINE:
If correction is needed:

* Patch only within the Stage 3 Full Record Integration YAML.
* HIGH-PRIORITY YAML PATCH RULE: preserve every existing template field, preserve field order as far as possible, add no new fields or sections, rename no fields, and leave no required field omitted.
* Keep claims at or below the level licensed by checked Stage 1, checked Stage 2, and checked prior artifacts.
* Exclude invented files, new source claims, new analysis, MIP rescoring, AHP authority drift, and later pipeline artifacts from the corrected YAML.
* Patch only the smallest structurally necessary part; use bounded markers where a field cannot be supported.
* The corrected output remains a PMS-DISCIPLINE Stage 3 Full Record Integration YAML only.

OUTPUT:
After the mandatory YAML structure audit, return the completed criteria ledger, with all 12 numbered criteria marked PASS or FAIL and one concise reason per criterion.

If all criteria are PASS without correction, then return:

* CHECK STATUS: ready
* FINAL RESULT: PMS-DISCIPLINE Stage 3 Full Record Integration YAML checked. Ready for the next PMS-DISCIPLINE pipeline step.

If concrete defects can be conservatively corrected inside this step, then return:

* CHECK STATUS: corrected
* CORRECTIONS MADE: concise bullet list
* CRITERIA AFTER CORRECTION: repeat all 12 criteria as PASS or FAIL
* COMPLETE CORRECTED PMS-DISCIPLINE STAGE 3 FULL RECORD INTEGRATION YAML

If the output is not safely correctable inside this step, then return:

* CHECK STATUS: not ready
* BLOCKING ISSUES
* REQUIRED CORRECTIONS
* NEXT ALLOWED STEP

Do not declare ready while any criterion remains FAIL.

---
## Prompt #26 — Iteration Handoff and Follow-up Preparation

You are continuing a PMS-DISCIPLINE pipeline run.

This is an optional prospective handoff step after the checked Case Record Stages 1–3 and before optional Markdown article generation.

The Iteration Handoff is not Case Record Stage 4. It is not an article check. It is not a new analysis layer and does not continue the current case analysis. It is a bounded prospective preparation record for a possible separately bounded follow-up case.

FILES PROVIDED:

* pms_discipline_iteration_handoff_template.yaml

AVAILABLE CONTEXT:

* Checked Stage 1 Artifact Index YAML is present in this conversation/session.
* Checked Stage 2 Layer Digest Extraction YAML is present in this conversation/session.
* Checked Stage 3 Full Record Integration YAML is present in this conversation/session.
* Checked prior PMS-DISCIPLINE artifacts are present where applicable.
* Article outputs have not yet been generated in this sequence. Any legacy article draft, example, final article, or article check from another pass is a presentation artifact only and is not a source for this step.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

OPTIONAL MANUAL ITERATION NOTES:
{MANUAL_ITERATION_NOTES}

TASK:
Apply pms_discipline_iteration_handoff_template.yaml to prepare a bounded Iteration Handoff for possible future follow-up work.

PURPOSE:
Produce an Iteration Handoff YAML that identifies whether a future separately bounded case, clarification pass, deeper review, or no material iteration is warranted.

This step may recommend future work. It must not change the current checked case result.

SOURCE HIERARCHY:

1. Checked Stage 3 Full Record Integration YAML controls the current integrated result, claim ceiling, unresolved items, rival pressure, limits, final posture, and reopening conditions.
2. Checked Stage 2 Layer Digest Extraction YAML supplies layer-specific depth, selective shallowness, non-use, and uncertainty.
3. Checked Stage 1 Artifact Index YAML supplies provenance, actual artifacts, branch state, and eligible carry-forward references.
4. Underlying checked artifacts may be consulted only where Stage 1, Stage 2, or Stage 3 explicitly identifies a gap, contradiction, unresolved item, or need for layer-specific verification.
5. The CASE PACKET remains bounded source material only where the checked record chain licenses reference to it.
6. Optional article outputs, examples, final article prose, article checks, drafting notes, and article wording are not sources for this handoff.

MIP AND AHP HANDOFF RULE:

If MIP or AHP was used, recommended, rejected, skipped, unresolved, or preserved as non-use in checked Stage 1–3, include its handoff-relevant status only through the checked Case Record.

For MIP, preserve only checked MIP status, source burden, qualitative A/M or IA/D handling where present, red-zone or non-use conditions, and claim-boundary effects already preserved by Stage 3.

For AHP, preserve only checked analysis-quality implications such as precision pressure, attack-surface visibility, hardening backlog, misreadability, transmission risk, score-language hygiene, D-language caution, reversibility, and iteration support.

AHP-derived items may justify follow-up questions or required new material, but they must remain review surfaces, not proven defects or mandates.

Do not rescore MIP, activate D, upgrade evidence, authorize stronger claims, or preselect MIP/AHP for a future follow-up case.

SOURCE EXCLUSION RULE:
Do not derive any Iteration Handoff finding, urgency, target, follow-up question, or material requirement from:

* article prose;
* base article draft;
* generated examples;
* final integrated article;
* final article check;
* article profile choice;
* article wording;
* drafting metadata;
* workflow convenience;
* local file inventory not selected in Stage 1;
* model inference unsupported by checked Stage 1–3.

Any readability concern noticed in a legacy article remains a presentation issue unless checked Stage 1–3 independently support a follow-up need.

TECHNICAL INSTRUCTIONS:

* Use pms_discipline_iteration_handoff_template.yaml as the only output structure.
* HIGH-PRIORITY YAML STRUCTURE RULE: preserve every field from the provided template, preserve field order as far as possible, add no new fields or sections unless the template explicitly allows extension fields, rename no fields, and leave no template field omitted.
* Fill fields precisely from checked Stage 1, checked Stage 2, checked Stage 3, the CASE PACKET where licensed by the checked record, and optional manual iteration notes.
* Use unknown, unclear, not_applicable, missing, unresolved, insufficient, none, or another template-allowed bounded marker where the checked record does not license a stronger value.
* Do not re-run Pre-Analysis, Core, add-on, MIP, AHP, Case Record, or article analysis.
* Do not reinterpret the case.
* Do not strengthen claims.
* Do not convert unresolved items into findings.
* Do not treat current sufficiency as absence of future iteration value.
* Do not treat future iteration value as current insufficiency.
* Do not treat urgency as proof of a stronger current claim.
* Do not generate a new follow-up case inside this step.
* Do not write Markdown article prose.
* Output valid YAML only.

ITERATION DISTINCTIONS:
Keep these separate:

```text
current sufficiency
≠
iteration value
≠
iteration urgency
≠
follow-up case authorization
```

CURRENT DEPTH ASSESSMENT:
Assess whether the current checked record is sufficient for the original intended use.

Use bounded values such as:

* sufficient_for_current_use
* sufficient_but_selectively_shallow
* materially_underdeveloped
* blocked_by_input_or_scope
* unclear

A sufficient current record may still have optional or useful iteration value. A selectively shallow record is not automatically inadequate. A materially underdeveloped or blocked record must not be strengthened through the handoff.

MODEL PRESELECTION:
Provide a model preselection for future iteration value.

Use exactly one recommendation value where the template allows it:

* no_material_iteration_value
* optional_refinement
* recommended_for_deeper_understanding
* recommended_before_stronger_use
* required_before_stronger_claim
* blocked_until_new_material

The model preselection is a recommendation only. It is not a user decision and not authorization to create a new case.

ITERATION URGENCY:
Assign an urgency level only from:

* none
* low
* moderate
* high
* critical

Urgency must be justified by checked-record reasons.

For urgency, preserve:

* reasons;
* what would raise urgency;
* what would lower urgency;
* urgency triggers;
* consequence of not iterating before the relevant next use.

Do not use urgency to intensify the current case conclusion.

Urgency guidance:

* `none`: no material follow-up burden is visible for the declared use.
* `low`: refinement could improve clarity but is not needed for responsible current use.
* `moderate`: follow-up would materially improve understanding, discrimination, or boundary control before stronger use.
* `high`: follow-up is strongly recommended before stronger, public, person-near, institutional, technical, or action-guiding use.
* `critical`: the next intended use or stronger claim should not continue without a separately bounded follow-up case or new material.

FOLLOW-UP TARGETS:
Create follow-up targets only where the checked Stage 1–3 record supports them.

Each material target must include:

* stable short id;
* question;
* basis in checked record;
* required new material or comparison;
* expected discriminative value;
* relation to current sufficiency;
* urgency relation;
* whether it should appear in article-visible outlook if an article is later revised;
* whether it is suitable for a separately bounded follow-up case.

A target is material only if it can change, weaken, differentiate, redirect, or close a relevant uncertainty, rival pressure, scope issue, source limitation, or use boundary.

Do not include generic curiosity questions merely because more detail would be interesting.

MANUAL ITERATION NOTES:
Optional manual iteration notes may be used only as planning, focus, material-location, user-priority, or question-refinement input.

Manual notes must not be treated as:

* verified facts;
* evidence;
* checked findings;
* source upgrades;
* operator assignments;
* route authorization;
* confirmation of the prior analysis;
* proof that a follow-up question is materially warranted.

If manual notes refine, replace, split, merge, accept, reject, or prioritize a proposed question, record that as user-response planning only.

USER RESPONSE:
Because this is a standalone manual prompt, set the user-response status according to the information actually supplied:

* If no explicit manual decision is supplied, mark user response as pending.
* If the optional manual notes explicitly accept, refine, replace, split, merge, reject, or approve follow-up targets, record that bounded response.
* If the user explicitly declines iteration, preserve the model preselection but set effective follow-up preparation accordingly.
* If the user explicitly requests a follow-up case despite weak or negative recommendation, record this as user-requested and preserve the mismatch between model recommendation and user decision.

Effective follow-up preparation must never erase the model preselection. Preserve both the model recommendation and the user-effective decision.

FOLLOW-UP CASE BOUNDARY:
If a follow-up case is recommended, required, or user-approved, prepare only a seed for a future separate case.

The seed may include:

* working title;
* primary follow-up question;
* proposed case boundary;
* required new material;
* inherited context references from the current case;
* source-role warning;
* non-inheritance rules.

The follow-up case must be separately bounded.

It must not inherit:

* current findings as evidence;
* route decisions;
* operator statuses;
* add-on selection;
* MIP/AHP status;
* claim ceiling;
* sufficiency status;
* article wording.

Prior checked analysis artifacts may provide bounded analytical context only. They are not evidence for the follow-up case and must not confirm their own prior findings.

ARTICLE OUTLOOK FIELD:
If the template contains article-outlook fields, fill them prospectively.

Use only checked Stage 1–3 and the approved/effective follow-up preparation.

Article outlook must be:

* omitted when there is no material iteration value;
* brief where the current case is sufficient and iteration is optional;
* explicit where stronger future use should not proceed without follow-up;
* clearly prospective;
* not a current-case defect unless the checked record itself says the current case is insufficient for the original intended use.

Do not write article prose in this step.

STEP BOUNDARIES:
This step excludes:

* producing Case Record Stage 4;
* revising Stage 1, Stage 2, or Stage 3;
* revising the article;
* creating a follow-up case;
* re-running analysis;
* changing route decisions;
* applying or reapplying add-ons, MIP, or AHP;
* treating future questions as current findings;
* using article prose as source;
* using user notes as verified facts.

CLAIM DISCIPLINE:

* Preserve the checked current result.
* Preserve source status and intended use.
* Preserve the current claim ceiling.
* Preserve rival pressure, unresolved items, weakening conditions, and reopening conditions.
* Keep future questions prospective.
* Keep follow-up value separate from current insufficiency.
* Keep urgency separate from claim strength.
* Mark uncertainty explicitly.

YAML OUTPUT SELF-CHECK:
Before answering, silently compare the completed YAML recursively against the exact template or source-derived output structure used in this step.

Confirm all of the following:

* exactly one YAML document;
* exact root key and root type;
* no missing required key;
* no unexpected key or section unless the template explicitly allows extension fields;
* no duplicate key;
* mapping/list/scalar types match the supplied structure;
* repeated list items preserve the expected item schema;
* explicitly defined allowed values are respected exactly;
* no unresolved placeholder remains unless the field is explicitly marked with a bounded value;
* field order is preserved as far as possible;
* no standalone `---` or `...` appears at the end.

VALUE RULE:
Enforce an allowed-value restriction only when the supplied template/source explicitly defines an enum, choices list, permitted-values list, or equivalent constraint. Do not infer a closed enum from one example or placeholder value.

OUTPUT:
Return only the completed PMS-DISCIPLINE Iteration Handoff YAML.
Use a fenced `yaml` code block only if the chat interface requires separation.
Do not append a standalone `---` or `...` after the YAML.
## Prompt #27 — Article Source Setup and Rendering Contract

You are continuing a PMS-DISCIPLINE pipeline run.

This step establishes the source hierarchy and selected article-profile contract for rendering the completed case-record chain into Markdown prose.

AVAILABLE CONTEXT:

* Checked Stage 1 Artifact Index YAML is present in this conversation/session.
* Checked Stage 2 Layer Digest Extraction YAML is present in this conversation/session.
* Checked Stage 3 Full Record Integration YAML is present in this conversation/session.
* The Iteration Handoff YAML from Prompt #26 is present if actually produced. It is prospective planning context only, not a source for current case findings.
* Checked prior PMS-DISCIPLINE artifacts are present where applicable.
* The CASE PACKET remains the bounded source material for this run.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

ARTICLE PROFILE — USER-CONFIRMED
selected_profile: {ARTICLE_PROFILE}

The selected profile controls presentation depth and section structure only. It does not change the checked analysis, route state, source status, claim ceiling, unresolved items, or authority boundary.

CANONICAL PMS OPERATOR NAMING RULE
- Use the canonical PMS operator names exactly:
  Δ (Difference), ∇ (Impulse), □ (Frame), Λ (Non-Event),
  Α (Attractor), Ω (Asymmetry), Θ (Temporality),
  Φ (Recontextualization), Χ (Distance), Σ (Integration),
  Ψ (Self-Binding).
- In article prose, the first occurrence of each operator in every paragraph must be followed by its canonical English name in parentheses.
- When the symbol is emphasized, emphasize the symbol only, for example: `**Δ** (Difference)`.
- Later occurrences of the same operator within that paragraph may use the symbol alone.
- When several operators first occur in the same paragraph, label every one of them.
- Symbolic formulas may remain symbol-only. The first prose occurrence in the paragraph must still use the canonical name.
- Do not replace a canonical operator name with a case-specific gloss. Place the case-specific explanation after the canonical name.

When `selected_profile` is `case_article`, apply this contract:
- Produce a focused, readable, standalone case article.
- Preserve the case-specific structural movement, active-layer contribution, controlling boundary, rival pressure, weakening conditions, and reopening conditions.
- Use Stage 1 for provenance control, not as a visible audit narrative unless a provenance issue materially limits reliability.
- Do not include an audit-style case capsule, full source-chain inventory, workflow correction history, report-readiness planning, examples-policy planning, or a generic misuse catalogue.
- Center the structural reading on the operators that carry the case's main movement.
- Group weak, conditional, dependency-limited, inactive, or analytic-only operators by shared calibration function unless one contributes a distinct case-specific result.
- Do not create a separate paragraph or subsection for an operator merely to show that it was considered.
- Do not narrate every inactive add-on, MIP, or AHP branch. Mention non-use only when it prevents a case-specific false trigger or materially explains the result.
- Keep the case-specific boundary normally to the two to four misuse or escalation risks nearest to the material and actual analysis.
- Mention broader legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use boundaries only when the case, intended use, active layer, or checked record creates concrete proximity to that misuse.
- Do not restore generic boundary language already expressed elsewhere in the article. State each relevant limit once.
- Omission of generic workflow history, inactive-layer inventories, repeated non-authority language, and non-material provenance detail is intentional compression, not source loss.
- Normal guidance is approximately 1,500–3,500 words, but analytical sufficiency controls; there is no minimum length.
- This profile-specific contract overrides generic long-form structure, operator-catalogue, section-count, or minimum-depth wording elsewhere in the prompt.

When `selected_profile` is `full_analysis_article`, apply this contract:
- Produce a detailed, audit-rich narrative rendering of the checked case-record chain.
- Preserve provenance, branch decisions, layer status, claim boundaries, non-use records, rival pressure, weakening conditions, and reopening conditions where they matter.
- Detailed does not mean repetitive. State each provenance fact, route decision, boundary, non-use result, and non-authority warning once at the point where it contributes most.
- Do not import temporary workflow execution metadata, local installation inventory, or drafting metadata into article prose.
- Normal guidance is approximately 5,000–8,000 words; multi-layer cases may be longer when the checked record requires it. There is no artificial minimum.

Apply only the contract matching `selected_profile`.
END ARTICLE PROFILE


TASK:
Establish the source hierarchy and rendering contract for the selected article profile.

SOURCE HIERARCHY:

1. Checked Stage 3 Full Record Integration YAML controls the article's substantive integrated record, title, claim boundary, final posture, unresolved items, and permitted use.
2. Checked Stage 2 Layer Digest Extraction YAML supplies layer-level analytical depth without overriding Stage 3.
3. Checked Stage 1 Artifact Index YAML supplies provenance and artifact status. It is not a source of new case findings.
4. The Iteration Handoff may be considered only as prospective follow-up context. It must not alter the current case result, route, claim ceiling, operator status, source status, or sufficiency assessment. Render a later Iteration outlook only when the handoff contains an explicit effective user decision and its article-outlook fields permit inclusion.
5. Underlying checked artifacts may be consulted only where Stage 1, Stage 2, or Stage 3 explicitly identifies a gap, contradiction, unresolved item, or need for layer-specific verification.
6. The CASE PACKET remains bounded source material only where the checked record chain licenses reference to it.
7. Article drafts, examples, final article prose, article checks, drafting notes, and article wording are not sources for this setup step.

MIP AND AHP ARTICLE RULE:

Include MIP or AHP content only through the checked Case Record and only where it contributes a case-specific result, boundary, non-use decision, or material analysis-quality limit. Do not rescore MIP, activate D, reinterpret AHP review surfaces as proven defects, or use an inactive branch to create new case findings.

COMMON RENDERING DISCIPLINE:

* Do not re-run analysis.
* Do not strengthen claims.
* Do not treat YAML, workflow completion, or AI-generated prose as evidence.
* Preserve material unresolved items, source limits, rival pressure, weakening conditions, reopening conditions, and distinctive misuse risks.
* Keep workflow QA separate from case substance.
* Mention an internal workflow issue only when checked Stage 3 states that it materially limits record reliability or interpretation.
* Do not import temporary workflow execution metadata, local installation inventory, attachment names, drafting metadata, or profile-selection metadata into article prose.
* State each provenance fact, route decision, claim boundary, non-use result, and non-authority warning once at the point where it contributes most.

PROFILE APPLICATION:

For `case_article`:

* Stage 1 controls provenance silently unless a material record limitation must be disclosed.
* Preserve the case-specific analysis rather than narrating the complete workflow.
* Do not require an audit capsule, full source-chain section, generic boundary catalogue, full inactive-layer inventory, report-readiness section, or examples-policy section.
* Mention inactive layers only when their non-use prevents a case-specific false trigger or materially explains the result.

For `full_analysis_article`:

* Preserve detailed provenance, layer decisions, relevant non-use, claim boundaries, and reopening conditions.
* Detailed does not mean repetitive.
* Do not turn the article into a raw file inventory or a transcript of every pipeline step.

TITLE RULE:
The final article begins with the exact case title from checked Stage 3 as an H2 heading. Fall back to checked Stage 2, then to the checked Core title only when Stage 1 selected that artifact as current. Do not invent a title.

OUTPUT:
Respond only:

Article-generation source hierarchy and selected profile contract established.

---
## Prompt #28 — Base Markdown Case Article Draft

You are continuing a PMS-DISCIPLINE pipeline run.

The source hierarchy and selected article-profile contract were established in the previous step.

AVAILABLE CONTEXT:

* Checked Stage 1 Artifact Index YAML is present.
* Checked Stage 2 Layer Digest Extraction YAML is present.
* Checked Stage 3 Full Record Integration YAML is present.
* The Iteration Handoff YAML from Prompt #26 is present if actually produced. It is prospective planning context only, not current-case evidence.
* Checked prior PMS-DISCIPLINE artifacts are present where applicable.
* The CASE PACKET remains the bounded source material.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

ARTICLE PROFILE — USER-CONFIRMED
selected_profile: {ARTICLE_PROFILE}

The selected profile controls presentation depth and section structure only. It does not change the checked analysis, route state, source status, claim ceiling, unresolved items, or authority boundary.

CANONICAL PMS OPERATOR NAMING RULE
- Use the canonical PMS operator names exactly:
  Δ (Difference), ∇ (Impulse), □ (Frame), Λ (Non-Event),
  Α (Attractor), Ω (Asymmetry), Θ (Temporality),
  Φ (Recontextualization), Χ (Distance), Σ (Integration),
  Ψ (Self-Binding).
- In article prose, the first occurrence of each operator in every paragraph must be followed by its canonical English name in parentheses.
- When the symbol is emphasized, emphasize the symbol only, for example: `**Δ** (Difference)`.
- Later occurrences of the same operator within that paragraph may use the symbol alone.
- When several operators first occur in the same paragraph, label every one of them.
- Symbolic formulas may remain symbol-only. The first prose occurrence in the paragraph must still use the canonical name.
- Do not replace a canonical operator name with a case-specific gloss. Place the case-specific explanation after the canonical name.

When `selected_profile` is `case_article`, apply this contract:
- Produce a focused, readable, standalone case article.
- Preserve the case-specific structural movement, active-layer contribution, controlling boundary, rival pressure, weakening conditions, and reopening conditions.
- Use Stage 1 for provenance control, not as a visible audit narrative unless a provenance issue materially limits reliability.
- Do not include an audit-style case capsule, full source-chain inventory, workflow correction history, report-readiness planning, examples-policy planning, or a generic misuse catalogue.
- Center the structural reading on the operators that carry the case's main movement.
- Group weak, conditional, dependency-limited, inactive, or analytic-only operators by shared calibration function unless one contributes a distinct case-specific result.
- Do not create a separate paragraph or subsection for an operator merely to show that it was considered.
- Do not narrate every inactive add-on, MIP, or AHP branch. Mention non-use only when it prevents a case-specific false trigger or materially explains the result.
- Keep the case-specific boundary normally to the two to four misuse or escalation risks nearest to the material and actual analysis.
- Mention broader legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use boundaries only when the case, intended use, active layer, or checked record creates concrete proximity to that misuse.
- Do not restore generic boundary language already expressed elsewhere in the article. State each relevant limit once.
- Omission of generic workflow history, inactive-layer inventories, repeated non-authority language, and non-material provenance detail is intentional compression, not source loss.
- Normal guidance is approximately 1,500–3,500 words, but analytical sufficiency controls; there is no minimum length.
- This profile-specific contract overrides generic long-form structure, operator-catalogue, section-count, or minimum-depth wording elsewhere in the prompt.

When `selected_profile` is `full_analysis_article`, apply this contract:
- Produce a detailed, audit-rich narrative rendering of the checked case-record chain.
- Preserve provenance, branch decisions, layer status, claim boundaries, non-use records, rival pressure, weakening conditions, and reopening conditions where they matter.
- Detailed does not mean repetitive. State each provenance fact, route decision, boundary, non-use result, and non-authority warning once at the point where it contributes most.
- Do not import temporary workflow execution metadata, local installation inventory, or drafting metadata into article prose.
- Normal guidance is approximately 5,000–8,000 words; multi-layer cases may be longer when the checked record requires it. There is no artificial minimum.

Apply only the contract matching `selected_profile`.
END ARTICLE PROFILE


TASK:
Create the base Markdown article draft for the selected article profile.

SOURCE HIERARCHY:

1. Checked Stage 3 is the primary article source.
2. Checked Stage 2 supplies analytical depth.
3. Checked Stage 1 supplies provenance and branch status only.
4. The Iteration Handoff may not change the article's current-case result. Do not render an Iteration outlook unless the handoff contains an effective user decision and its article-outlook fields explicitly permit it.
5. Underlying checked artifacts may verify an explicitly marked gap but may not introduce new claims.

COMMON TECHNICAL RULES:

* Output Markdown only.
* Do not output YAML or code blocks.
* Do not add meta-commentary outside the article.
* Begin with `## [EXACT CASE TITLE]`.
* Do not re-run Core, add-on, MIP, AHP, or Case Record analysis.
* Do not resolve contradictions through interpretation.
* Do not introduce new facts, files, source material, or context.
* Preserve the controlling source status, claim ceiling, unresolved conditions, rival pressure, correctability, and reopening conditions.
* Preserve case-specific operator calibration and layer separation.
* Keep add-on handles distinct from PMS operators.
* Keep MIP and AHP results distinct and include them only where active or case-specifically relevant.
* Keep workflow QA metadata out of case findings.
* Do not generate examples in this step.
* Do not repeat the same boundary or non-use statement in multiple sections.

ITERATION OUTLOOK RENDERING:

* Render an `### Iteration outlook` section only when the effective Iteration Handoff explicitly permits article inclusion.
* If the handoff omits or excludes article outlook, omit the section entirely. Do not mention that an outlook was omitted.
* The section is prospective only and must state that any follow-up would be a new, separately bounded case.
* Do not describe the current case as incomplete when the handoff states that it is sufficient for the original intended use.
* Do not convert proposed follow-up questions into current-case findings, operator activations, add-on recommendations, MIP/AHP recommendations, evidence, or claim authority.
* Use only article-visible effective targets and permitted summary points. User notes marked for exclusion must not appear.
* For `case_article`, keep the outlook brief: current sufficiency, one to three follow-up focuses, and the new-case boundary.
* For `full_analysis_article`, the outlook may include depth status, urgency, reasons, selected effective questions, required new material, expected discriminative value, and the carry-forward boundary.

PROFILE-SPECIFIC STRUCTURE:

For `case_article`, use this structure unless a section is genuinely not applicable:

## [EXACT CASE TITLE]

### Why this case matters

Explain the case-specific closure pressure, structural tension, and why the case is mapped rather than solved.

### Structural reading

Render the main PMS Core movement in compact but substantial prose. Apply the manual canonical PMS operator naming rule throughout the article: at the first occurrence of each operator in every paragraph, write the symbol followed by its canonical English name in parentheses, for example `**Δ** (Difference)`. Later occurrences of the same operator within that paragraph may use the symbol alone. Symbol-only formulas remain permitted. Preserve important dependencies and calibrations, and include an active add-on, MIP, or AHP contribution only where it adds a case-specific result.

Center the structural reading on the operators that carry the case's main movement. Do not produce a mandatory operator-by-operator catalogue.

Group weak, conditional, dependency-limited, inactive, or analytic-only operators by shared calibration function. Normally place them in no more than one compact calibration paragraph unless an individual operator contributes a distinct case-specific result that cannot be preserved by grouping.

Do not create a separate paragraph or subsection for an operator merely to show that it was considered. Do not repeat the same calibration point in different operator-specific wording.

### What the analysis shows

State the central structural movement or formula, what the active layers make visible, and where residue, non-capture, or unresolved structure remains.

### Rival reading and reopening conditions

Preserve the strongest case-specific rival reading, relevant weakening or falsifier conditions, operationalization limits where material, and conditions that would reopen the result.

### Case-specific boundary

State only the distinctive misuse or escalation risks created by this case. Normally select the two to four risks nearest to the case material and actual analysis.

Do not repeat a generic catalogue of every PMS-DISCIPLINE prohibition. Mention broader legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use boundaries only when the case, intended use, active layer, or checked record creates concrete proximity to that misuse.

### Case takeaway

Give a concise synthesis of what the case shows and what remains open.

For `case_article`, do not require or recreate:

* an audit-style case capsule;
* a full source-chain and integration-status section;
* workflow correction history;
* a complete claim-boundary catalogue;
* a complete list of inactive operators;
* individual subsections for every unused add-on;
* generic MIP or AHP non-use exposition;
* a layer-interaction section when no later layer contributes;
* report-readiness or examples-policy planning;
* a generic misuse-boundary catalogue;
* remote legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use prohibitions without concrete case proximity.

For `full_analysis_article`, use a detailed structure appropriate to the checked record. It may include:

* case capsule;
* why the case matters;
* source chain and integration status;
* claim status and scope discipline;
* scene and frame structure;
* substantial PMS Core reading;
* dependency and calibration discipline;
* derived structures and drift status where present;
* active and materially relevant inactive-layer decisions;
* layer interaction;
* MIP/AHP record where applicable;
* rival and non-capture readings;
* weakening, falsifier, operationalization, and reopening conditions;
* misuse boundary;
* report readiness.

For `full_analysis_article`, do not repeat identical provenance, route, boundary, or non-authority statements across multiple sections. Local availability of an unused file is not an analytical result.

LENGTH GUIDANCE:

* `case_article`: normally about 1,500–3,500 words. There is no minimum. Preserve analytical sufficiency without restoring audit structure.
* `full_analysis_article`: normally about 5,000–8,000 words, with additional length only where an actual multi-layer record requires it. There is no artificial minimum.

OUTPUT:
Return Markdown only.
No YAML.
No code blocks.
No meta-commentary outside the article.

---
## Prompt #29 — Example Decision and Optional Example Generation

You are continuing a PMS-DISCIPLINE pipeline run.

The base Markdown article draft exists for the selected profile.

AVAILABLE CONTEXT:

* Checked Stage 1, Stage 2, and Stage 3 outputs are present.
* The Base Markdown Case Article Draft is present.
* The Iteration Handoff YAML from Prompt #26 is present if actually produced. It is prospective planning context only, not current-case evidence.
* The CASE PACKET remains the bounded source material.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

ARTICLE PROFILE — USER-CONFIRMED
selected_profile: {ARTICLE_PROFILE}

The selected profile controls presentation depth and section structure only. It does not change the checked analysis, route state, source status, claim ceiling, unresolved items, or authority boundary.

CANONICAL PMS OPERATOR NAMING RULE
- Use the canonical PMS operator names exactly:
  Δ (Difference), ∇ (Impulse), □ (Frame), Λ (Non-Event),
  Α (Attractor), Ω (Asymmetry), Θ (Temporality),
  Φ (Recontextualization), Χ (Distance), Σ (Integration),
  Ψ (Self-Binding).
- In article prose, the first occurrence of each operator in every paragraph must be followed by its canonical English name in parentheses.
- When the symbol is emphasized, emphasize the symbol only, for example: `**Δ** (Difference)`.
- Later occurrences of the same operator within that paragraph may use the symbol alone.
- When several operators first occur in the same paragraph, label every one of them.
- Symbolic formulas may remain symbol-only. The first prose occurrence in the paragraph must still use the canonical name.
- Do not replace a canonical operator name with a case-specific gloss. Place the case-specific explanation after the canonical name.

When `selected_profile` is `case_article`, apply this contract:
- Produce a focused, readable, standalone case article.
- Preserve the case-specific structural movement, active-layer contribution, controlling boundary, rival pressure, weakening conditions, and reopening conditions.
- Use Stage 1 for provenance control, not as a visible audit narrative unless a provenance issue materially limits reliability.
- Do not include an audit-style case capsule, full source-chain inventory, workflow correction history, report-readiness planning, examples-policy planning, or a generic misuse catalogue.
- Center the structural reading on the operators that carry the case's main movement.
- Group weak, conditional, dependency-limited, inactive, or analytic-only operators by shared calibration function unless one contributes a distinct case-specific result.
- Do not create a separate paragraph or subsection for an operator merely to show that it was considered.
- Do not narrate every inactive add-on, MIP, or AHP branch. Mention non-use only when it prevents a case-specific false trigger or materially explains the result.
- Keep the case-specific boundary normally to the two to four misuse or escalation risks nearest to the material and actual analysis.
- Mention broader legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use boundaries only when the case, intended use, active layer, or checked record creates concrete proximity to that misuse.
- Do not restore generic boundary language already expressed elsewhere in the article. State each relevant limit once.
- Omission of generic workflow history, inactive-layer inventories, repeated non-authority language, and non-material provenance detail is intentional compression, not source loss.
- Normal guidance is approximately 1,500–3,500 words, but analytical sufficiency controls; there is no minimum length.
- This profile-specific contract overrides generic long-form structure, operator-catalogue, section-count, or minimum-depth wording elsewhere in the prompt.

When `selected_profile` is `full_analysis_article`, apply this contract:
- Produce a detailed, audit-rich narrative rendering of the checked case-record chain.
- Preserve provenance, branch decisions, layer status, claim boundaries, non-use records, rival pressure, weakening conditions, and reopening conditions where they matter.
- Detailed does not mean repetitive. State each provenance fact, route decision, boundary, non-use result, and non-authority warning once at the point where it contributes most.
- Do not import temporary workflow execution metadata, local installation inventory, or drafting metadata into article prose.
- Normal guidance is approximately 5,000–8,000 words; multi-layer cases may be longer when the checked record requires it. There is no artificial minimum.

Apply only the contract matching `selected_profile`.
END ARTICLE PROFILE


TASK:
Decide whether an additional illustrative example is permitted and useful, and generate it only when warranted.

DECISION STATES:
Use exactly one:

* examples_not_applicable
* examples_unsafe
* examples_not_needed
* examples_optional
* examples_recommended
* examples_required_for_readability
* no_examples

COMMON RULES:

* Examples are illustrative, not evidentiary.
* Do not use the Iteration Handoff, proposed follow-up questions, or required future material as a source for an illustrative example.
* Do not add new case claims, new source material, new operator assignments, new layer triggers, scores, verdicts, diagnoses, legal conclusions, or implementation authority.
* Preserve the article's claim ceiling and case-specific boundaries.
* Do not dramatize uncertainty, conflict, person-nearness, harm, or institutional consequence beyond the checked record.
* Drafting metadata belongs only in this step and must not appear in the final article.

PROFILE RULES:

For `case_article`:

* Default to no additional example when the case scene already makes the structural movement readable.
* Generate at most one additional example.
* Prefer a micro or compact vignette.
* Generate a longer worked example only when checked Stage 3 or the base draft shows that readability otherwise fails.
* Do not use an example merely to increase article length.

For `full_analysis_article`:

* One or more examples may be generated where the checked examples policy supports them.
* Preserve substantial examples without thinning their internal analysis.
* Do not create examples simply to mirror every layer or every unused branch.

OUTPUT FORMAT:

### Example decision

[exactly one decision state]

### Reason

[brief source-grounded reason]

### Generated example

Write `none` when no example is generated.

When an example is generated, provide the complete Markdown example body. Do not include drafting labels such as `Type`, `Recommended insertion point`, or generation metadata inside the example body.

---
## Prompt #30 — Final Integrated Markdown Case Article

You are continuing a PMS-DISCIPLINE pipeline run.

The Base Markdown Case Article Draft and the Example Decision are present.

AVAILABLE CONTEXT:

* Checked Stage 1, Stage 2, and Stage 3 outputs are present.
* The Base Markdown Case Article Draft is present.
* The Example Decision and any generated example are present.
* The Iteration Handoff YAML from Prompt #26 is present if actually produced. It is prospective planning context only, not current-case evidence.
* The CASE PACKET remains the bounded source material.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

ARTICLE PROFILE — USER-CONFIRMED
selected_profile: {ARTICLE_PROFILE}

The selected profile controls presentation depth and section structure only. It does not change the checked analysis, route state, source status, claim ceiling, unresolved items, or authority boundary.

CANONICAL PMS OPERATOR NAMING RULE
- Use the canonical PMS operator names exactly:
  Δ (Difference), ∇ (Impulse), □ (Frame), Λ (Non-Event),
  Α (Attractor), Ω (Asymmetry), Θ (Temporality),
  Φ (Recontextualization), Χ (Distance), Σ (Integration),
  Ψ (Self-Binding).
- In article prose, the first occurrence of each operator in every paragraph must be followed by its canonical English name in parentheses.
- When the symbol is emphasized, emphasize the symbol only, for example: `**Δ** (Difference)`.
- Later occurrences of the same operator within that paragraph may use the symbol alone.
- When several operators first occur in the same paragraph, label every one of them.
- Symbolic formulas may remain symbol-only. The first prose occurrence in the paragraph must still use the canonical name.
- Do not replace a canonical operator name with a case-specific gloss. Place the case-specific explanation after the canonical name.

When `selected_profile` is `case_article`, apply this contract:
- Produce a focused, readable, standalone case article.
- Preserve the case-specific structural movement, active-layer contribution, controlling boundary, rival pressure, weakening conditions, and reopening conditions.
- Use Stage 1 for provenance control, not as a visible audit narrative unless a provenance issue materially limits reliability.
- Do not include an audit-style case capsule, full source-chain inventory, workflow correction history, report-readiness planning, examples-policy planning, or a generic misuse catalogue.
- Center the structural reading on the operators that carry the case's main movement.
- Group weak, conditional, dependency-limited, inactive, or analytic-only operators by shared calibration function unless one contributes a distinct case-specific result.
- Do not create a separate paragraph or subsection for an operator merely to show that it was considered.
- Do not narrate every inactive add-on, MIP, or AHP branch. Mention non-use only when it prevents a case-specific false trigger or materially explains the result.
- Keep the case-specific boundary normally to the two to four misuse or escalation risks nearest to the material and actual analysis.
- Mention broader legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use boundaries only when the case, intended use, active layer, or checked record creates concrete proximity to that misuse.
- Do not restore generic boundary language already expressed elsewhere in the article. State each relevant limit once.
- Omission of generic workflow history, inactive-layer inventories, repeated non-authority language, and non-material provenance detail is intentional compression, not source loss.
- Normal guidance is approximately 1,500–3,500 words, but analytical sufficiency controls; there is no minimum length.
- This profile-specific contract overrides generic long-form structure, operator-catalogue, section-count, or minimum-depth wording elsewhere in the prompt.

When `selected_profile` is `full_analysis_article`, apply this contract:
- Produce a detailed, audit-rich narrative rendering of the checked case-record chain.
- Preserve provenance, branch decisions, layer status, claim boundaries, non-use records, rival pressure, weakening conditions, and reopening conditions where they matter.
- Detailed does not mean repetitive. State each provenance fact, route decision, boundary, non-use result, and non-authority warning once at the point where it contributes most.
- Do not import temporary workflow execution metadata, local installation inventory, or drafting metadata into article prose.
- Normal guidance is approximately 5,000–8,000 words; multi-layer cases may be longer when the checked record requires it. There is no artificial minimum.

Apply only the contract matching `selected_profile`.
END ARTICLE PROFILE


TASK:
Produce the final Markdown article for the selected profile.

SOURCE HIERARCHY:

1. Checked Stage 3 controls the integrated record and claim boundary.
2. Checked Stage 2 supplies analytical depth.
3. Checked Stage 1 supplies provenance only.
4. The Iteration Handoff may not alter current-case findings or claim boundaries. Render Iteration outlook content only when user-confirmed and explicitly permitted by the handoff.
5. The Base Draft controls the article's profile-specific structure unless it conflicts with the checked record.
6. Generated examples may be inserted only when the Example Decision permits them.

ITERATION OUTLOOK INTEGRATION:

* Preserve a valid Iteration outlook from the Base Draft when it follows the effective handoff.
* Add an Iteration outlook only when the Base Draft omitted one and the effective handoff explicitly permits article inclusion.
* Remove or weaken any outlook wording that treats follow-up questions as current findings, evidence, route recommendations, claim-ceiling changes, or proof that the current case is incomplete.
* The outlook must state that a follow-up case begins again with its own boundary, source status, intended use, and Pre-Analysis.

COMMON INTEGRATION RULES:

* Output Markdown only.
* Begin with the exact case title as an H2 heading.
* Preserve supported case-specific analysis, active-layer results, rival pressure, unresolved items, weakening conditions, and reopening conditions.
* Preserve canonical PMS operator naming. In every rewritten or newly inserted paragraph, the first occurrence of each operator must use `SYMBOL (Canonical Name)` according to the canonical naming rule in the user-confirmed article profile.
* Do not replace canonical operator names with case-specific descriptions. A description may follow the canonical name.
* Do not introduce new analysis or strengthen claims.
* Do not import workflow history, local file inventory, temporary workflow metadata, prompt instructions, example-generation metadata, or audit-planning language into article prose.
* Remove drafting labels such as `Type`, `Recommended insertion point`, `Example decision`, and generation metadata from inserted examples.
* State each boundary, provenance fact, route decision, and non-use result once.
* Do not treat article readiness as truth, publication permission, implementation permission, or authority.

PROFILE INTEGRATION:

For `case_article`:

* Preserve the analytical substance of the Base Draft without restoring omitted audit structure.
* Do not expand the article merely to reproduce the length, section count, operator inventory, branch inventory, or boundary catalogue of Stage 1, Stage 2, Stage 3, or the full-analysis profile.
* Preserve compact grouping of weak, conditional, dependency-limited, inactive, or analytic-only operators.
* Do not unpack grouped operators into separate paragraphs or subsections merely because the checked record lists them separately.
* Give an individual weak or inactive operator separate treatment only when it contributes a distinct case-specific result that would otherwise be lost.
* Do not repeat the same calibration limit in multiple operator-specific formulations.
* Omission of generic workflow history, inactive-layer inventories, repeated non-authority language, report-readiness planning, and non-material provenance detail is intentional and is not source loss.
* Mention inactive add-ons, MIP, or AHP only where their non-use prevents a case-specific false trigger or materially explains the result.
* Keep the case-specific boundary focused on the risks nearest to the actual material and analysis.
* Do not restore remote legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use prohibitions unless the checked record establishes concrete proximity to that misuse.
* Insert no more than one generated example.

For `full_analysis_article`:

* Preserve detailed record depth where the checked source supports it.
* Do not repeat the same provenance fact, branch decision, claim boundary, non-use statement, or non-authority warning across the case capsule, layer sections, misuse section, and conclusion.
* Do not mistake a full analysis article for a file inventory or chronological transcript of the manual workflow.

NO-EXAMPLE RULE:
When the decision state unambiguously indicates no example, preserve the Base Draft as the final article except for necessary cleanup. Do not rewrite or expand it merely because this integration step exists.

OUTPUT:
Return Markdown only.
No YAML.
No code blocks.
No meta-commentary outside the article.

---
## Prompt #31 — Final Article Check and Conservative Patch

You are continuing a PMS-DISCIPLINE pipeline run.

The final Markdown article was generated for the selected profile.

AVAILABLE CONTEXT:

* Checked Stage 1, Stage 2, and Stage 3 outputs are present.
* The Base Markdown Case Article Draft is present.
* The Example Decision and any generated example are present.
* The Final Integrated Markdown Case Article is present.
* Checked prior PMS-DISCIPLINE artifacts are present where applicable.
* The Iteration Handoff YAML from Prompt #26 is present if actually produced. It is prospective planning context only, not current-case evidence.
* The CASE PACKET remains the bounded source material.

CASE PACKET:
CASE TITLE:
{CASE_TITLE}

CASE MATERIAL:
{CASE_MATERIAL}

SOURCE STATUS:
{SOURCE_STATUS}

INTENDED USE:
{INTENDED_USE}

ARTICLE PROFILE — USER-CONFIRMED
selected_profile: {ARTICLE_PROFILE}

The selected profile controls presentation depth and section structure only. It does not change the checked analysis, route state, source status, claim ceiling, unresolved items, or authority boundary.

CANONICAL PMS OPERATOR NAMING RULE
- Use the canonical PMS operator names exactly:
  Δ (Difference), ∇ (Impulse), □ (Frame), Λ (Non-Event),
  Α (Attractor), Ω (Asymmetry), Θ (Temporality),
  Φ (Recontextualization), Χ (Distance), Σ (Integration),
  Ψ (Self-Binding).
- In article prose, the first occurrence of each operator in every paragraph must be followed by its canonical English name in parentheses.
- When the symbol is emphasized, emphasize the symbol only, for example: `**Δ** (Difference)`.
- Later occurrences of the same operator within that paragraph may use the symbol alone.
- When several operators first occur in the same paragraph, label every one of them.
- Symbolic formulas may remain symbol-only. The first prose occurrence in the paragraph must still use the canonical name.
- Do not replace a canonical operator name with a case-specific gloss. Place the case-specific explanation after the canonical name.

When `selected_profile` is `case_article`, apply this contract:
- Produce a focused, readable, standalone case article.
- Preserve the case-specific structural movement, active-layer contribution, controlling boundary, rival pressure, weakening conditions, and reopening conditions.
- Use Stage 1 for provenance control, not as a visible audit narrative unless a provenance issue materially limits reliability.
- Do not include an audit-style case capsule, full source-chain inventory, workflow correction history, report-readiness planning, examples-policy planning, or a generic misuse catalogue.
- Center the structural reading on the operators that carry the case's main movement.
- Group weak, conditional, dependency-limited, inactive, or analytic-only operators by shared calibration function unless one contributes a distinct case-specific result.
- Do not create a separate paragraph or subsection for an operator merely to show that it was considered.
- Do not narrate every inactive add-on, MIP, or AHP branch. Mention non-use only when it prevents a case-specific false trigger or materially explains the result.
- Keep the case-specific boundary normally to the two to four misuse or escalation risks nearest to the material and actual analysis.
- Mention broader legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use boundaries only when the case, intended use, active layer, or checked record creates concrete proximity to that misuse.
- Do not restore generic boundary language already expressed elsewhere in the article. State each relevant limit once.
- Omission of generic workflow history, inactive-layer inventories, repeated non-authority language, and non-material provenance detail is intentional compression, not source loss.
- Normal guidance is approximately 1,500–3,500 words, but analytical sufficiency controls; there is no minimum length.
- This profile-specific contract overrides generic long-form structure, operator-catalogue, section-count, or minimum-depth wording elsewhere in the prompt.

When `selected_profile` is `full_analysis_article`, apply this contract:
- Produce a detailed, audit-rich narrative rendering of the checked case-record chain.
- Preserve provenance, branch decisions, layer status, claim boundaries, non-use records, rival pressure, weakening conditions, and reopening conditions where they matter.
- Detailed does not mean repetitive. State each provenance fact, route decision, boundary, non-use result, and non-authority warning once at the point where it contributes most.
- Do not import temporary workflow execution metadata, local installation inventory, or drafting metadata into article prose.
- Normal guidance is approximately 5,000–8,000 words; multi-layer cases may be longer when the checked record requires it. There is no artificial minimum.

Apply only the contract matching `selected_profile`.
END ARTICLE PROFILE


TASK:
Review the final Markdown article against the checked record and the selected article profile. Patch only concrete defects.

COMMON CHECKS:

1. Source fidelity
   * Stage 3 remains primary.
   * Stage 2 depth is preserved where needed.
   * Stage 1 is used for provenance, not new case findings.
   * No new analysis or source material appears.

2. Claim boundary
   * Source status, claim ceiling, material unresolved items, rival pressure, and reopening conditions remain intact.
   * No unlicensed diagnosis, person ranking, legal/forensic conclusion, metaphysical proof, empirical proof, implementation validation, PMS Base validation, maturity verdict, dignity score, or authority claim appears.

3. Structural fidelity
   * Core calibration and dependencies remain understandable.
   * Every paragraph containing PMS operator prose uses the canonical English name in parentheses at the first occurrence of each operator in that paragraph.
   * Symbol-only formulas are permitted, but they do not satisfy the naming requirement for later prose in the same paragraph.
   * Canonical operator names are not replaced by case-specific glosses or functions.
   * Active add-on, MIP, and AHP results remain separate.
   * Inactive layers are not presented as findings.
   * Workflow QA metadata is not converted into case substance.

4. Examples
   * Any example is permitted by the recorded decision.
   * It remains illustrative only.
   * Drafting labels and insertion metadata are absent from the final article.

5. Iteration outlook
   * An Iteration outlook appears only when the effective Iteration Handoff explicitly permits article inclusion.
   * It remains prospective, uses only article-visible effective targets, and states the separately bounded new-case requirement.
   * It does not convert follow-up questions into current findings or describe a sufficient current case as incomplete.

6. Conclusion
   * The conclusion stays within the checked record.
   * It preserves the controlling posture and does not create publication or implementation authority.

PROFILE CHECKS:

For `case_article`:

* The article remains a focused case article rather than a narrative audit dossier.
* Absence of a case capsule, full source-chain inventory, workflow correction history, inactive-layer catalogue, generic misuse catalogue, report-readiness section, or examples-policy section is not a defect.
* Omission of generic workflow history, repeated boundary language, and non-material provenance detail is not source loss.
* Do not restore material merely because it exists in Stage 1, Stage 2, or Stage 3.
* Restore omitted material only when its absence changes the case-specific structural analysis, controlling claim boundary, active-layer result, material unresolved tension, rival reading, weakening condition, reopening condition, or distinctive misuse risk.
* Weak, conditional, dependency-limited, inactive, or analytic-only operators should normally be grouped by shared calibration function.
* Separate treatment of such an operator is justified only when it contributes a distinct case-specific result that would be lost through grouping.
* Flag separate operator paragraphs that merely repeat the same limitation in different wording as removable excess.
* The case-specific boundary should normally prioritize the two to four misuse or escalation risks nearest to the material and actual analysis.
* Flag remote legal, clinical, forensic, HR, automated-decision, publication, implementation, or institutional-use prohibitions as removable excess unless the checked record establishes concrete proximity to them.
* Flag unnecessary internal workflow narration, repeated inactive-layer notes, repeated calibration points, or generic boundary repetition as removable excess.

For `full_analysis_article`:

* Detailed provenance and layer decisions may remain.
* Flag repeated provenance, route, boundary, and non-authority language when it adds no new case-specific function.
* Flag local installation inventory, temporary workflow state, or drafting metadata as removable excess.
* Do not reduce supported analytical depth merely to make the article shorter.

PATCH DISCIPLINE:

* Patch only the Markdown article.
* Prefer exact find/replace or insertion patches.
* Full rewrite is allowed only when the article is structurally unusable.
* Keep supported content.
* Weaken overclaims rather than replacing them with silence.
* Remove only the smallest unnecessary or unsupported text.
* Do not use the check to convert one profile into the other.

OUTPUT FORMAT:

### Final check status

Use one:

* article_ready_with_no_patch_required
* article_ready_after_minor_patch
* major_revision_required
* source_record_insufficient_for_article
* human_review_required_before_article_use

### Main issues

List only actual issues. Write `none` when there are none.

### Exact patches

Write `none` when no patch is needed.

For each patch:

**Patch [number] — [short title]**

Find:

[exact text]

Replace with:

[replacement text]

or:

Insert after:

[exact anchor text]

Insert:

[text]

---