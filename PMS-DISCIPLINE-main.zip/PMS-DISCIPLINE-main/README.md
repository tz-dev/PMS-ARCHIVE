# PMS-DISCIPLINE

## Purpose

**PMS-DISCIPLINE** is the application-discipline repository for bounded PMS use.

It makes PMS application more explicit, bounded, inspectable, correctable, stoppable, and resistant to over-application.

Its compact rule is:

```text
PMS readability does not imply PMS entry.
PMS entry does not imply Core continuation.
Core continuation does not imply claim permission.
```

PMS-DISCIPLINE is concerned with responsible use, not theory creation.

---

## Ecosystem Position

DISCIPLINE sits between PMS Base and any concrete application attempt.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies the operator grammar. DISCIPLINE controls whether and how a case may enter bounded use. |
| PMS add-ons | May be selected only after Core and only under route discipline. Topical fit is not enough. |
| MIP / AHP | Downstream non-add-on layers with separate gates; not automatic continuations. |
| PMS-ORCHESTRATOR | Tool support for staged DISCIPLINE case workflows. It does not replace human review. |
| PMS — UNDER LOAD | Critiques application discipline when it becomes authority, verdict, or workflow-hardening. |
| PMS-STRATA | Helps control composition, decomposition, and projection in later analysis; it does not override DISCIPLINE stop or claim ceilings. |

---

## Repository Form

This is a **paper-form application-discipline repository with templates**.

| Material | Function |
| --- | --- |
| `PMS-DISCIPLINE.md` | Main methodology paper. |
| `examples/Prompts and Instructions.md` | Manual prompt sequence for disciplined PMS use. |
| `templates/` | Pre-Analysis, gates, add-on, MIP/AHP, Case Record, Handoff, and article workflow templates. |
| Case examples | Bounded demonstrations of route, stop, review, and artifact discipline. |

This README names the workflow and boundaries. The paper and templates carry the operational detail.

---

## Core Workflow

A disciplined pass may proceed as:

```text
Pre-Entry responsibility check
→ Pre-Analysis
→ stop or PMS Core
→ optional single selected PMS add-on
→ optional MIP route
→ optional AHP route
→ Case Record Stages 1–3
→ optional Iteration Handoff
→ optional article workflow or new bounded follow-up case
```

A confirmed Entry-Gate stop ends the current pass before Core. No Core, add-on, MIP, AHP, analytical Case Record, Iteration Handoff, or article output may be produced as though the stopped analysis had occurred.

---

## Supported Add-ons

The PMS-DISCIPLINE add-on path supports exactly six PMS add-on families:

```text
ANTICIPATION
CRITIQUE
CONFLICT
LOGIC
EDEN
SEX
```

The analytical options are:

```text
Core-only
Core plus exactly one selected PMS add-on
```

Several plausible add-ons do not authorize combined add-on use. They normally indicate several distinct analytical questions. Those questions should be decomposed into separately bounded subcases, each with its own Pre-Analysis, Core pass, add-on decision, claim ceiling, rival pressure, protection review, and final analytical decision state.

Checked subcase records may later undergo record-level comparison or integration. Such integration must not create a retrospective multi-add-on pass or new cross-subcase findings.

---

## MIP and AHP Routes

MIP and AHP are downstream own-output layers, not PMS add-ons.

MIP becomes relevant only where the case or intended output places actual load on person-evaluative judgment, responsibility attribution, role-capability assessment, practice under consequential burden, dignity, face, status, reputation, maturity-in-practice, or person-affecting evaluative transmission.

After the checked MIP Gate, the route is binary:

```text
do not use MIP
use MIP
```

MIP Source Reading may guide a later application. It is not a third runner route and does not itself produce findings.

AHP may become available only after an actual checked MIP Case Application. AHP cannot be reached directly from Core, the Add-on Gate, an add-on output, MIP vocabulary, MIP Source Reading, or a MIP Gate recommendation alone.

AHP does not correct, replace, rescore, or evidentially upgrade MIP.

---

## Basic Conditional Route Logic

A compact route logic:

```text
1. Pre-Entry responsibility check
2. Pre-Analysis
   ├─ stop before Core
   └─ allow Core entry
3. PMS Core
4. Core Check
5. Add-on Gate
   ├─ Core-only
   ├─ add-on non-use
   ├─ add-on rejection
   ├─ decompose into subcases
   └─ exactly one selected PMS add-on
6. Selected add-on application and check, if any
7. MIP Gate, if materially relevant
   ├─ do not use MIP
   └─ use MIP
8. MIP Source Reading / MIP Case Application / MIP Check, if selected
9. AHP Gate and AHP Application, only after checked MIP
10. Case Record Stages 1–3
11. Optional Iteration Handoff
12. Optional article route or separately bounded follow-up case
```

---

## Status Distinctions

PMS-DISCIPLINE separates three status dimensions:

```text
requested-output disposition
≠
pipeline-case disposition
≠
final analytical decision state
```

The final analytical decision states are:

```text
proceed
revise
downgrade
suspend
refuse
redirect
```

`stop` is not a seventh final analytical decision state. It is a pipeline-control disposition.

---

## Review Modes

PMS-DISCIPLINE supports **Full Review Mode** and **Fast Mode**.

| Mode | Function | Boundary |
| --- | --- | --- |
| Full Review Mode | Default mode with semantic review checks active. A Pre-Analysis stop signal is reviewed before Core entry. | A confirmed stop ends the current pass before Core. |
| Fast Mode | Skips selected semantic review steps by explicit user choice. | Review omission does not convert stop into proceed. |

Fast Mode reduces friction but increases semantic-drift risk. It should not be used to bypass protection stops, person-near stops, or claim ceilings.

---

## Stop Capability

Stop controls continuation, not truth.

```text
confirmed pipeline stop
→ complete stop-confirming checked artifact is effective for recording the stop
→ not eligible as Core input
→ no same-run reframing as if the stopped analysis had occurred
```

A redirect after a protection stop identifies only a possible future direction. It does not continue the stopped case. The receiving question requires a new boundary, source review, intended use, requested output, and checked Pre-Analysis.

Human confirmation remains responsible for bounded use and final analytical decision where the use context demands it. AI, YAML, templates, gates, and checks may surface workflow conditions; they do not become truth authorities.

---

## Templates and Case Records

Template groups:

| Group | Examples |
| --- | --- |
| Entry Control and Core | `pms_discipline_pre_analysis_template.yaml`, `pms_core_case_application_template.yaml`. |
| Add-on Gate and Applications | Add-on recommendation gate plus ANTICIPATION, CONFLICT, CRITIQUE, EDEN, LOGIC, SEX application templates. |
| MIP and AHP | MIP Gate, MIP Source Reading, MIP Case Application, AHP Gate, AHP Application. |
| Case Record Stages | Stage 1 Artifact Index, Stage 2 Layer Digest Extraction, Stage 3 Full Case Record Integration. |
| Cross-Subcase Integration | Controlled record-level comparison without multi-add-on retro-authorization. |
| Iteration Handoff | Future follow-up preparation and non-inheritance discipline. |
| Multi-Step Article Workflow | Bounded Markdown rendering after checked Case Record and Handoff conditions. |

Templates are structured artifacts for making case handling inspectable. They are not validators, evidence sources, or authorities.

---

## Iteration Handoff

Iteration Handoff follows checked Case Record Stages 1–3. It is not Case Record Stage 4 and not article review.

It may preserve:

```text
follow-up question
context and lineage
material needs
iteration value
iteration urgency
current sufficiency status
non-inheritance limits
```

It may not preserve as evidence or authority:

```text
findings
route decisions
operator statuses
add-on selection
MIP/AHP status
claim ceiling
article wording
```

A follow-up case begins anew under its own boundary, source review, intended use, requested output, Pre-Analysis, and route decisions.

---

## Examples

The repository’s examples demonstrate application discipline rather than substantive verdicts.

| Example | Focus |
| --- | --- |
| The Empty Outrage | Pre-Analysis, unsupported escalation, and refusal of over-application. |
| The Friday Cut-Off | Timing, route pressure, and bounded claim formation. |
| The Locked Conflict | Conflict pressure without collapsing into verdict authority. |
| The Balanced Format That Was Not Balanced | Format neutrality failure and publicness pressure. |
| The Screenshot Verdict Request | Person-near stop, evidence limits, and no same-run reframing. |

Use examples as workflow demonstrations, not as precedent or proof.

---

## Optional Orchestrator Tooling

PMS-ORCHESTRATOR can stage DISCIPLINE case work locally. It prepares prompts, preserves raw outputs, tracks route state, applies local structural YAML validation, supports handoff/article routes, and enforces confirmed stop.

The tool does not connect to an AI service and does not decide meaning. Manual use of prompts remains valid without the tool.

---

## What PMS-DISCIPLINE Is Not

PMS-DISCIPLINE is not:

```text
PMS Base
a validator
governance authority
verdict machinery
person-ranking system
semantic review replacement
truth certification
application permission machine
```

Boundary formula:

```text
application discipline ≠ application authority
checked artifact ≠ correct interpretation
human confirmation ≠ truth certification
stop capability ≠ safety guarantee
```

---

## Reading Path

| Need | Where to go |
| --- | --- |
| Full method | `PMS-DISCIPLINE.md`. |
| Manual use | `examples/Prompts and Instructions.md`. |
| Structured artifacts | `templates/`. |
| Workflow tooling | PMS-ORCHESTRATOR README and `TECHNICAL.md`. |
| Case demonstrations | Examples listed above and case files. |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS-DISCIPLINE DOI | To be added or verified during the Zenodo release/check pass. |

---

## Citation

Cite PMS-DISCIPLINE as an application-discipline and use-boundary repository. Do not cite template completion, route state, or checked artifacts as substantive proof.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
