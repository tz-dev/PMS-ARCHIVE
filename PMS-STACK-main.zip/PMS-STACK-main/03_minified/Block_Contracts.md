---
document_id: PMS-STACK-MIN-BLOCK-CONTRACTS
title: "PMS-STACK Block Contracts"
status: "release-candidate"
version: "v0.1"
claim_type: "minified governance / architecture-area contract summary"
canonical_status: "derivative; compresses README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file compresses architecture-area obligations. It does not replace the canonical blocks, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Block Contracts

## 1. Canonical Status

This file is a minified governance artifact for PMS-STACK.

It summarizes higher-level contracts by architecture area rather than by individual file.

The canonical PMS-STACK v0.1 specification is:

```text
README.md + 01_blocks/00–09
```

This file belongs to:

```text
03_minified/
```

Its role is:

```text
compressive
contractual
release-facing
audit-supporting
non-canonical
```

It does not replace:

```text
README.md
01_blocks/00_overview.md
01_blocks/01_architecture.md
01_blocks/02_pms_um.md
01_blocks/03_pms_cpu.md
01_blocks/04_pms_os.md
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/07_distributed_systems.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

Boundary:

```text
Block contracts compress PMS-STACK.
They do not define PMS-STACK.
They do not redefine PMS Base.
They do not introduce new primitives.
They do not validate PMS Base.
They do not establish implementation completion.
```

---

## 2. Contract Format

Each contract uses the following form:

```text
Contract:
    Name of architecture-area contract.

Primary files:
    Canonical blocks governed or summarized by the contract.

Claim type:
    Type of claim made by the area.

Primary role:
    What this area contributes to PMS-STACK.

Required invariants:
    Conditions that must remain true across future edits.

Boundary:
    What the contract does not claim.

Must not say:
    Unsafe or category-confused wording to avoid.

Acceptance:
    Criteria for future release checks.
```

The contracts are:

```text
Canonical corpus contract
Operator contract
Machine contract
CPU/OS contract
Language/runtime contract
Security contract
Distributed contract
PMS-RUST evidence contract
Claim-boundary contract
Publication/reader contract
```

---

## 3. Global Governance Rules

The following rules apply to every contract in this file.

### 3.1 Canonical Rule

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Source, reference, minified, derivative-publication, and reader layers do not replace the canonical specification.

### 3.2 Strong Claim Rule

PMS-STACK uses strong claims, but every strong claim must be typed.

Canonical pattern:

```text
strong claim → claim type → boundary
```

Correct:

```text
PMS-STACK is the implementation-layer architecture specification of PMS:
an operator-grounded systems architecture deriving abstract machine,
virtual CPU, OS, runtime, language, security, networking, distributed
systems, tooling, simulation, verification, boot, and cluster profiles
from Δ–Ψ.

This is an implementation-layer architecture claim.
It does not validate PMS Base or imply that every layer is already
implemented as an executable artifact.
```

Incorrect:

```text
PMS-STACK validates PMS Base.
PMS-STACK proves PMS as a praxis theory.
PMS-STACK is a completed operating system.
PMS-STACK is fabricated hardware.
PMS-STACK is production-certified security infrastructure.
```

### 3.3 PMS Base Rule

PMS Base remains the source of operator identity.

Correct relation:

```text
PMS Base defines.
PMS-STACK specifies.
PMS-RUST evidences bounded implementation slices.
Tests inspect.
Traces record.
Validators accept or reject under declared profiles.
Formal proofs prove stated properties under models.
External validation validates under external protocols.
```

No lower layer validates PMS Base.

### 3.4 Χ Rule

PMS Base 1.3 uses:

```text
Χ = Distance
```

PMS-STACK implementation layers project Χ as:

```text
isolation
reachability control
boundary management
access separation
sandboxing
containment
quarantine
namespace visibility
device visibility
IPC visibility
trust-domain separation
cross-node boundary management
```

Projection is not redefinition.

Correct:

```text
PMS Base Χ is Distance.
At implementation layers, Χ projects as isolation and boundary management.
```

Incorrect:

```text
PMS Base Χ means isolation.
PMS-STACK redefines Χ.
PMS-RUST chi_exit defines Χ.
```

### 3.5 trace / Trace Rule

PMS-STACK distinguishes concrete runs from execution sets.

Single execution:

```text
trace(artifact, profile, input) ∈ L_PMS
```

Execution set:

```text
Trace(artifact, profile) ⊆ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Distributed single execution:

```text
traceᴳ(D, profile, input) ∈ L_PMS
```

Distributed execution set:

```text
Traceᴳ(D, profile) ⊆ L_PMS
```

Boundary:

```text
A trace records one execution.
A Trace denotes a set of possible executions.
A recorded trace does not prove all behavior.
```

### 3.6 PMS-RUST Rule

PMS-RUST is:

```text
bounded executable PMS-STACK Evidence Spine v0.1
```

It may strengthen bounded implementation-artifact claims through:

```text
deterministic execution
model validation
stateful validation
JSONL traces
golden fixtures
REPL/script tooling
vFS surfaces
AI proposal boundaries
boundary-exit discipline where implemented
```

It does not establish:

```text
PMS Base validation
PMS-STACK completion
full PMS-UM implementation
full PMS-CPU implementation
full PMS-OS implementation
full PMSL compiler
full distributed runtime
external validation
universal proof
```

### 3.7 AI Bridge Rule

The AI Bridge is optional tooling/profile support.

Correct:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

The AI Bridge may propose:

```text
operator-tagged opcode sequences
PMS-IR candidate programs
scenario compilations
trace-analysis comments
diagnostic explanations
```

It may not act as:

```text
PMSL semantics
compiler authority
verifier authority
trusted executable code
runtime policy authority
PMS Base evidence
```

### 3.8 chi_exit / ISO_EXIT Rule

PMS-CPU and PMS-RUST boundary-exit concepts are related but not identical.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under declared profile and active boundary context.
```

Boundary:

```text
chi_exit does not complete ISO_EXIT.
chi_exit does not redefine PMS Base Χ.
chi_exit does not complete PMS-CPU.
chi_exit does not complete PMS-OS isolation.
chi_exit does not validate PMS Base.
```

---

## 4. Canonical Corpus Contract

### Contract

Canonical corpus contract.

### Primary files

```text
README.md
01_blocks/00_overview.md
01_blocks/01_architecture.md
01_blocks/02_pms_um.md
01_blocks/03_pms_cpu.md
01_blocks/04_pms_os.md
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/07_distributed_systems.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
implementation-layer architecture specification claim
```

### Primary role

The canonical corpus specifies PMS-STACK as a complete implementation-layer computational architecture derived from Δ–Ψ.

It establishes:

```text
operator-grounded systems architecture
abstract machine layer
virtual CPU / ISA layer
OS architecture layer
language/runtime/IR layer
runtime security layer
distributed systems profile layer
PMS-RUST evidence relation
claim-boundary discipline
```

### Required invariants

```text
README.md + 01_blocks/00–09 remain canonical.

00_source/ remains provenance.
02_reference/ indexes.
03_minified/ compresses.
04_derivative_publications/ explains.
05_PMS-STACK Reader/ navigates.

No derivative layer overrides canonical blocks.
No source-supporting layer overrides canonical blocks.
```

### Boundary

The canonical corpus specifies architecture.

It does not assert:

```text
completed implementation
fabricated hardware
production OS
complete compiler
complete distributed runtime
universal security certification
PMS Base validation
external validation
```

### Must not say

```text
The minified corpus is canonical.
Reference files redefine PMS-STACK.
Derivative publications replace the blocks.
The Reader validates PMS-STACK.
The source monolith overrides the release blocks.
```

### Acceptance

```text
README names the canonical rule.
All block files exist and are non-empty.
Every derivative layer states its boundary.
No file claims PMS Base validation.
No file claims implementation completion without artifact evidence.
```

---

## 5. Operator Contract

### Contract

Operator contract.

### Primary files

```text
01_blocks/00_overview.md
01_blocks/01_architecture.md
01_blocks/02_pms_um.md
01_blocks/03_pms_cpu.md
01_blocks/04_pms_os.md
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/07_distributed_systems.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
operator-identity / architecture-projection claim
```

### Primary role

The operator contract preserves PMS Base operator identity while allowing PMS-STACK to project operators into implementation-layer systems architecture.

The operator alphabet is:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

At PMS-STACK layers, operators appear as:

```text
machine instructions
CPU opcodes
frames
roles
policies
syscalls
traps
isolation domains
commits
runtime constructs
protocol states
distributed frames
audit events
```

### Required invariants

```text
No new base operators are introduced.

Layer suffixes such as ᴳ mark scope, not new operator identity.

Χ remains PMS Base Distance.

Implementation-layer Χ projection must be explicit when used as isolation,
boundary, reachability control, sandboxing, or containment.

Operator projection must preserve dependency discipline.

Layer-specific terms must remain traceable to Δ–Ψ.
```

### Boundary

Operator projection does not redefine PMS Base.

Operator mapping does not validate PMS Base.

Classical systems may be interpreted as projections or specializations, but this does not make PMS-STACK identical to those systems.

### Must not say

```text
Χ means isolation at PMS Base level.
Distributed operators are new base operators.
Domain-specific additions are primitives.
Classical OS concepts redefine Δ–Ψ.
PMS-RUST runtime labels define PMS Base operator identity.
```

### Acceptance

```text
Operator terminology remains stable.
Χ / Distance boundary is explicit.
Projection is marked as projection.
No add-on is promoted to primitive.
Distributed notation uses scope markers rather than new operator identity.
```

---

## 6. Machine Contract

### Contract

Machine contract.

### Primary files

```text
01_blocks/01_architecture.md
01_blocks/02_pms_um.md
01_blocks/03_pms_cpu.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
abstract-machine / computational expressiveness / formal architecture claim
```

### Primary role

The machine contract governs PMS-UM and its relationship to PMS-CPU.

PMS-UM is the abstract machine layer.

PMS-CPU is the virtual CPU / ISA specialization of PMS-UM.

The machine layer defines:

```text
machine tuple
state and configuration model
program domain
operator-typed instructions
step relation
dependency-constrained execution
determinism and nondeterminism
trace semantics
computational expressiveness
refinement substrate for CPU/OS/runtime layers
```

### Required invariants

The PMS-UM tuple is:

```text
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

The PMS-CPU tuple is:

```text
M_CPU = (
    S_CPU,
    Γ_CPU,
    F_CPU,
    R_CPU,
    PSet_CPU,
    O,
    ISA,
    Π_CPU,
    δ_CPU,
    s₀_CPU,
    S_H_CPU
)
```

Profile-awareness must be preserved through:

```text
Π
Π_CPU
```

Trace notation must preserve:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Computational universality must remain claim-typed:

```text
computational expressiveness / formal architecture claim
```

### Boundary

PMS-UM computational expressiveness does not prove:

```text
OS correctness
CPU implementation correctness
security correctness
distributed correctness
all-program termination
implementation completion
PMS Base validation
```

PMS-CPU as PMS-UM instance does not assert fabricated hardware.

### Must not say

```text
PMS-UM proves PMS Base.
PMS-UM proves every system property.
PMS-CPU is implemented hardware.
The CPU tuple may omit Π_CPU.
The UM tuple may omit Π.
A trace proves all Trace behavior.
```

### Acceptance

```text
M includes Π.
M_CPU includes Π_CPU.
Computational universality is claim-typed.
Machine claims stay at architecture/formal-expressiveness level.
PMS-RUST evidence remains bounded artifact evidence.
```

---

## 7. CPU / OS Contract

### Contract

CPU/OS contract.

### Primary files

```text
01_blocks/03_pms_cpu.md
01_blocks/04_pms_os.md
01_blocks/06_runtime_security.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
virtual CPU / ISA architecture claim
OS architecture claim
```

### Primary role

The CPU/OS contract governs the transition from abstract machine to virtual processor and operating-system architecture.

It covers:

```text
PMS-CPU state
registers
memory
frames
roles
ISA
calling conventions
interrupts
traps
binary encoding
fetch-decode-execute
commit and policy checks
memory consistency
PMS-OS kernel
processes
threads
scheduling
syscalls
resource accounting
virtual memory
filesystem
IPC
events
drivers
OS invariants
```

### Required invariants

CPU invariants:

```text
PMS-CPU remains a virtual CPU / ISA specification.
PMS-CPU does not claim fabricated hardware.
ISO_EXIT is architecture-level.
Boundary exit requires active boundary context.
Sealed isolation forbids expansion but permits valid closure.
```

OS invariants:

```text
PMS-OS remains an OS architecture claim.
PMS-OS does not claim production OS status.
Syscalls are controlled Φ-mediated transitions.
PMS-OS syscall convention is a dedicated trap/syscall ABI.
It does not redefine ordinary PMS-CPU calling convention.
```

Resource/accounting notation:

```text
RF
    register file, where used

RAcc / ResourceAccount
    OS-level resource accounting
```

Syscall operator word:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

OS isolation-domain values:

```text
IDom_user
IDom_global
```

Legacy `X_user`, `X_global`, or comparable notation denotes OS-level isolation-domain values, not PMS Base Χ.

### Boundary

The CPU/OS contract does not establish:

```text
fabricated hardware
silicon implementation
complete emulator
complete assembler
complete compiler backend
complete production OS
POSIX conformance
complete device ecosystem
deployment certification
PMS Base validation
```

### Must not say

```text
PMS-CPU is hardware.
PMS-OS is a completed OS.
PMS-OS is POSIX.
RF means ResourceAccount.
The syscall ABI replaces ordinary PMS-CPU calling convention.
OS isolation-domain variables redefine Χ.
chi_exit completes ISO_EXIT.
```

### Acceptance

```text
PMS-CPU claim remains virtual CPU / ISA.
PMS-OS claim remains OS architecture.
RF/RAcc collision is avoided.
Syscall word includes □ and Χ.
Syscall ABI boundary is explicit.
ISO_EXIT / chi_exit boundary is preserved.
```

---

## 8. Language / Runtime Contract

### Contract

Language/runtime contract.

### Primary files

```text
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
language/runtime specification claim
PMS-IR architecture claim
tooling / analysis / observability claim
```

### Primary role

The language/runtime contract governs PMSL, PMS-IR, runtime architecture, standard library domains, static analysis, model checking, debugging, observability, simulation, and AI proposal boundaries.

It specifies:

```text
PMSL as operator-typed programming surface
PMS-IR as operator-preserving intermediate representation
runtime profiles
standard-library domains
concurrency and IO APIs
static analysis
model checking
debugging and observability
simulation and emulation
example PMSL fragments
AI proposal boundary
PMS-RUST evidence relation
```

### Required invariants

```text
PMSL is a language/runtime specification claim.
PMSL is not a completed language implementation.
PMS-IR is an architecture-level intermediate representation.
PMS-IR is not automatically compiler authority.
Static analysis reports are not proof unless tied to stated verification claims.
Model checking proves only stated properties under stated models.
Debugging and observability record or inspect; they do not validate PMS Base.
Simulation/emulation evidence is artifact evidence, not PMS Base validation.
```

AI Bridge invariant:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI Bridge may appear as:

```text
optional PMS-RUST tooling profile
PMS-IR proposal surface
opcode proposal surface
trace-analysis advisory surface
diagnostic explanation aid
```

AI Bridge may not become:

```text
PMSL semantics
compiler authority
verifier authority
trusted executable code
PMS Base evidence
```

### Boundary

The language/runtime contract does not establish:

```text
complete parser
complete type checker
complete compiler
complete optimizer
complete backend
complete standard library
complete runtime implementation
verified runtime
trusted AI execution
PMS Base validation
```

### Must not say

```text
PMSL is fully implemented.
PMS-IR is executable truth.
AI output is trusted executable code.
AI output is verification evidence.
AI is compiler authority.
Static analysis proves all behavior.
Simulation validates PMS Base.
```

### Acceptance

```text
PMSL/PMS-IR remain specification claims.
AI Bridge remains optional tooling/profile support.
Host validation remains authoritative.
Runtime/kernel execution occurs only after acceptance.
Verification claims stay property-specific.
Artifact evidence stays bounded.
```

---

## 9. Security Contract

### Contract

Security contract.

### Primary files

```text
01_blocks/04_pms_os.md
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/07_distributed_systems.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
runtime-security architecture claim
operator-structured governance claim
```

### Primary role

The security contract governs PMS-STACK security as a structural operator discipline.

Security is not an add-on.

Security-relevant transitions must remain:

```text
Δ-distinguished
Ω-authorized
□-framed
Χ-bounded as implementation-layer Distance projection
Θ-ordered where relevant
Φ-recontextualized on failure where needed
Σ-committed where stable
Ψ-constrained by policy/invariant
```

The contract covers:

```text
trust boundaries
identity
principals
roles
capabilities
isolation
policy definition
policy enforcement
kernel hooks
runtime invariants
audit
compliance hooks
trust anchors
network security
failure handling
attack handling
security scenarios
```

### Required invariants

```text
Security is architecture-level and cross-layer.
Governance is policy discipline, not tribunal authority.
Audit records events; it does not prove all behavior.
Compliance hooks support stated profiles; they do not create universal certification.
Trust anchors support trust interpretation under policy; keys are not authority by themselves.
Attack scenarios are architecture scenarios or fixture candidates, not exhaustive security proof.
```

Χ security rule:

```text
Isolation is an implementation-layer projection of PMS Base Distance.
```

AI/tooling security rule:

```text
AI and tooling principals must remain boundary-constrained.
AI output is not trusted executable code.
```

### Boundary

Runtime security does not assert:

```text
universal security certification
absence of all vulnerabilities
legal authority
moral authority
clinical authority
tribunal status
completed security implementation
completed verification
PMS Base validation
```

### Must not say

```text
PMS-STACK is universally secure.
PMS-STACK governance is a tribunal.
Audit proves all behavior.
Compliance hooks externally validate PMS.
Security scenarios are exhaustive proof.
Keys are authority by themselves.
AI tooling bypasses validation.
```

### Acceptance

```text
Security remains operator-structured.
Governance remains Ψ-bound.
Audit and compliance remain bounded artifacts.
Scenarios remain fixture candidates or architecture examples.
AI/tooling remains constrained.
No tribunal, legal, moral, clinical, or certification drift appears.
```

---

## 10. Distributed Contract

### Contract

Distributed contract.

### Primary files

```text
01_blocks/07_distributed_systems.md
01_blocks/06_runtime_security.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
distributed architecture / runtime-profile claim
```

### Primary role

The distributed contract governs networking, PMS Protocol Suite, resilience, cluster frames, operator lifting, distributed commit, global policy, cross-node isolation, cluster boot, upgrade, distributed verification, and distributed audit.

It specifies distributed PMS-STACK as semantic scaling:

```text
same operator grammar
+ explicit frame/scope expansion
+ profile-specific implementation obligations
```

Distributed operator notation marks scope:

```text
Δᴳ
∇ᴳ
□ᴳ
Λᴳ
Αᴳ
Ωᴳ
Θᴳ
Φᴳ
Χᴳ
Σᴳ
Ψᴳ
```

These are scoped forms, not new PMS Base operators.

### Required invariants

```text
Distributed PMS-STACK is optional by runtime profile.
Distributed scope does not create new base operators.
Cluster frames are higher-order frames.
Σᴳ is distributed integration/commit under profile.
Ψᴳ is distributed policy/invariant discipline.
Χᴳ is cross-node Distance projection.
```

Distributed trace rules:

```text
traceᴳ(D, profile, input) ∈ L_PMS
Traceᴳ(D, profile) ⊆ L_PMS
```

Under active distributed policy:

```text
traceᴳ(D, profile, input) ∈ L_PMS,Ψᴳ
Traceᴳ(D, profile) ⊆ L_PMS,Ψᴳ
```

### Boundary

The distributed contract does not establish:

```text
completed distributed runtime
mandatory distributed implementation
proof of consensus algorithms
proof of Paxos
proof of Raft
proof of PBFT
proof of CRDT correctness
external distributed-systems validation
PMS Base validation
```

### Must not say

```text
Distributed operators are new primitives.
Every PMS-STACK runtime must be distributed.
PMS-STACK proves Raft or Paxos.
Σᴳ is a specific consensus algorithm.
Distributed traces prove all distributed behavior.
```

### Acceptance

```text
Distributed scope is explicit.
ᴳ notation remains scope notation.
Distributed profiles remain optional.
Algorithm proof claims are avoided unless separately proven.
Distributed trace / Trace distinction is preserved.
```

---

## 11. PMS-RUST Evidence Contract

### Contract

PMS-RUST evidence contract.

### Primary files

```text
01_blocks/08_relation_to_pms_rust.md
01_blocks/03_pms_cpu.md
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
bounded implementation-artifact evidence claim
```

### Primary role

The PMS-RUST evidence contract governs the relation between PMS-STACK and PMS-RUST.

Correct relation:

```text
PMS Base = source of operator identity
PMS-STACK = implementation-layer architecture specification
PMS-RUST = bounded executable Evidence Spine v0.1
```

PMS-RUST may evidence bounded slices of:

```text
operator representation
program construction
deterministic execution
model validation
stateful validation
JSONL trace emission
golden fixture discipline
REPL/script tooling
vFS surfaces
AI proposal boundaries
chi_exit boundary-exit behavior where declared
```

### Required invariants

```text
PMS-RUST strengthens bounded implementation-artifact claims.
PMS-RUST does not define PMS Base.
PMS-RUST does not complete PMS-STACK.
PMS-RUST does not complete PMS-UM.
PMS-RUST does not complete PMS-CPU.
PMS-RUST does not complete PMS-OS.
PMS-RUST does not complete PMSL.
PMS-RUST does not complete distributed PMS.
```

Roadmap pattern:

```text
STACK claim
→ executable slice
→ validation rule
→ golden test
→ trace evidence
→ limitation
```

### Boundary

PMS-RUST does not establish:

```text
PMS Base validation
full formal verification
external validation
complete implementation
complete OS
complete CPU
complete compiler
complete distributed runtime
trusted AI execution
```

### Must not say

```text
PMS-RUST validates PMS Base.
PMS-RUST completes PMS-STACK.
PMS-RUST traces prove PMS.
PMS-RUST tests prove PMS.
PMS-RUST chi_exit completes ISO_EXIT.
PMS-RUST AI Bridge is compiler authority.
```

### Acceptance

```text
PMS-RUST is named as bounded Evidence Spine.
Evidence type is explicit.
Artifact boundary is explicit.
Tests/traces/validators are described with correct verbs.
PMS Base validation is denied.
Implementation completion is denied unless artifact-backed and scoped.
```

---

## 12. Claim-Boundary Contract

### Contract

Claim-boundary contract.

### Primary files

```text
01_blocks/00_overview.md
01_blocks/09_non_goals_and_claim_boundary.md
all canonical blocks
```

### Claim type

```text
claim-boundary / non-goal / release-discipline specification
```

### Primary role

The claim-boundary contract governs safe PMS-STACK wording across the entire corpus.

It preserves the strength of PMS-STACK while preventing category errors.

Canonical pattern:

```text
strong claim → claim type → boundary
```

### Required invariants

The corpus must distinguish:

```text
architecture specification
    ≠ completed implementation

computational expressiveness
    ≠ proof of every system property

artifact evidence
    ≠ PMS Base validation

trace evidence
    ≠ proof of all behavior

tests
    ≠ proof

formal proof
    = property-specific proof under assumptions

external validation
    = validation under external protocol

AI proposal
    ≠ authority

governance
    ≠ tribunal

portability
    ≠ equivalence
```

### Boundary

The claim-boundary contract does not weaken PMS-STACK.

It strengthens PMS-STACK by typing claims.

It does not introduce new theory, new operators, new implementation status, or new evidence.

### Must not say

```text
PMS-STACK validates PMS Base.
PMS-RUST validates PMS Base.
Tests prove PMS.
Traces prove all behavior.
Runtime dialect equals PMS 1.3 theory.
Implementation equals truth.
Portability equals equivalence.
Governance is tribunal.
Add-ons are primitives.
Domain papers redefine Δ–Ψ.
AI output is trusted executable code.
```

### Acceptance

```text
Every strong claim has type and boundary.
Unsafe wording is replaced with claim-typed wording.
PMS-STACK remains architecturally strong.
No boundary is written as apology.
No lower layer validates PMS Base.
```

---

## 13. Publication / Reader Contract

### Contract

Publication/reader contract.

### Primary files

```text
README.md
02_reference/
03_minified/
04_derivative_publications/
05_PMS-STACK Reader/
01_blocks/09_non_goals_and_claim_boundary.md
```

### Claim type

```text
derivative publication / navigation / documentation-support claim
```

### Primary role

The publication/reader contract governs all non-canonical support layers.

The corpus formula is:

```text
PMS-STACK is specified in canonical blocks,
indexed in reference files,
compressed in minified contracts,
explained in derivative publications,
and navigated through the Reader.
```

Layer roles:

```text
00_source/
    preserves origin material

02_reference/
    indexes the canonical specification

03_minified/
    compresses the canonical specification

04_derivative_publications/
    explains the canonical specification

05_PMS-STACK Reader/
    navigates the canonical specification
```

### Required invariants

Reference rule:

```text
Reference files index PMS-STACK.
They do not redefine PMS-STACK.
```

Minified rule:

```text
Minified files compress PMS-STACK.
They do not replace the canonical blocks.
```

Derivative-publication rule:

```text
Derivative publications explain PMS-STACK.
They do not become canonical specification.
```

Reader rule:

```text
The Reader navigates PMS-STACK.
It does not validate PMS-STACK.
```

Reader boundary:

```text
The Reader is a convenience tool for local navigation and inspection.
It does not replace canonical Markdown, modify the specification, validate
PMS-STACK, validate PMS Base, prove implementation completion, or establish
PMS-RUST completeness.
```

### Boundary

Publication and reader layers do not establish:

```text
new canonical specification
new PMS Base claims
new implementation evidence
new formal proof
new external validation
new operator identity
new runtime authority
```

### Must not say

```text
The Reader validates PMS-STACK.
Derivative publications are canonical.
Reference files redefine the architecture.
Minified files replace 01_blocks.
README alone exhausts the specification.
```

### Acceptance

```text
Every non-canonical support file states its status.
Derivative files point back to canonical blocks.
Reader remains read-only by default.
Reader searches are navigation aids, not evidence.
Publication layer remains explanatory.
```

---

## 14. Cross-Contract Conformance Matrix

| Rule | Applies to | Required formulation | Boundary |
|---|---|---|---|
| Canonical rule | all files | `README.md + 01_blocks/00–09 = canonical PMS-STACK specification` | support layers do not replace canon |
| Strong claim rule | all claims | strong claim → claim type → boundary | no untyped strength |
| Χ rule | all operator projections | PMS Base Χ = Distance; implementation layers project Χ | no Χ redefinition |
| trace / Trace rule | traces, evidence, audit | `trace(...)` single run; `Trace(...)` execution set | trace does not prove all behavior |
| PMS-RUST rule | evidence mapping | bounded executable Evidence Spine v0.1 | not PMS Base validation |
| AI Bridge rule | PMSL/PMS-IR/tooling/security | AI proposes; host validates; runtime/kernel executes accepted artifacts | AI is not authority |
| chi_exit / ISO_EXIT rule | CPU/runtime/security/evidence | ISO_EXIT architecture-level; chi_exit artifact/runtime evidence | chi_exit does not complete ISO_EXIT |
| Distributed scope rule | distributed systems | ᴳ marks scope-lifted operators | no new base operators |
| Security rule | runtime security | security is operator-structured | not universal certification |
| Publication rule | reference/minified/derivative/reader | index/compress/explain/navigate | not canonical replacement |

---

## 15. Safe Verb Table

| Artifact | Correct verb | Incorrect verb |
|---|---|---|
| PMS Base | defines operator identity | is validated by PMS-STACK |
| PMS-STACK | specifies architecture | proves PMS Base |
| PMS-UM | specifies abstract machine / expressiveness | proves all system properties |
| PMS-CPU | specifies virtual CPU / ISA | fabricates hardware |
| PMS-OS | specifies OS architecture | is a production OS |
| PMSL/PMS-IR | specifies language/runtime architecture | is a complete compiler |
| PMS-RUST | evidences bounded implementation slices | completes PMS-STACK |
| tests | check | prove PMS |
| traces | record | validate PMS Base |
| validators | accept/reject under profile | externally validate |
| fixtures | stabilize cases | exhaust correctness |
| proofs | prove stated properties under assumptions | prove all PMS |
| external validation | validates under external protocol | follows from traces |
| AI Bridge | proposes/analyzes under validation | executes/authorizes/verifies |
| Reader | navigates/inspects | validates/modifies/proves |

---

## 16. Release Acceptance

The block contract layer is accepted when:

```text
It states the canonical rule.
It states its derivative/minified status.
It includes canonical, operator, machine, CPU/OS, language/runtime,
security, distributed, PMS-RUST evidence, claim-boundary, and
publication/reader contracts.
It includes the Χ rule.
It includes the trace / Trace rule.
It includes the PMS-RUST Evidence Spine rule.
It includes the AI Bridge rule.
It includes the chi_exit / ISO_EXIT rule.
It includes support-layer boundaries.
It uses strong but claim-typed wording.
It does not replace the canonical blocks.
```

Negative acceptance conditions:

```text
No PMS Base validation drift.
No proof-by-test drift.
No proof-by-trace drift.
No implementation-completion drift.
No fabricated-hardware drift.
No production-OS drift.
No compiler-completion drift.
No distributed-runtime completion drift.
No AI-authority drift.
No Reader-validation drift.
No derivative-canon drift.
```

---

## 17. Final Formula

```text
PMS-STACK specifies.
PMS Base defines.
PMS-RUST evidences.
Tests inspect.
Traces record.
Validators accept or reject under declared profiles.
Fixtures stabilize bounded cases.
Gates discipline releases.
Proofs prove stated properties under assumptions.
External validation validates under external protocols.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
Reference files index.
Minified files compress.
Derivative publications explain.
The Reader navigates.
None of these lower or derivative layers validate PMS Base.
```

The block-contract formula is:

```text
Canonical blocks define PMS-STACK.
Block contracts compress their obligations.
Compressed obligations do not replace canonical specification.
```