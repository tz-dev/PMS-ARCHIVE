---
document_id: PMS-STACK-REF-READER-PATHWAYS
title: "PMS-STACK Reader Pathways"
status: "release-candidate"
version: "v0.1"
claim_type: "reference guide / corpus navigation / audience-oriented reading map"
canonical_status: "derivative; indexes README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file provides audience-oriented navigation paths through PMS-STACK. It does not replace the canonical blocks, redefine PMS Base, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Reader Pathways

## 1. Canonical Status

This file provides structured reading paths through the PMS-STACK corpus.

It belongs to:

```text
02_reference/
```

Its role is:

```text
reference
navigation guide
reader-orientation layer
audience pathway map
non-canonical
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Boundary:

```text
This file guides readers through PMS-STACK.
It does not redefine PMS-STACK.
It does not replace canonical blocks.
It does not validate PMS Base.
It does not establish implementation completion.
It does not create evidence.
```

---

## 2. Reading Philosophy

PMS-STACK is intentionally layered.

Different readers require different entry sequences.

Recommended reading depends on:

```text
background
goal
review depth
claim sensitivity
implementation focus
audit focus
runtime/security focus
distributed-systems focus
artifact-evidence focus
```

Canonical navigation rule:

```text
overview
→ architecture
→ target layer
→ boundary review
```

Recommended universal close:

```text
09_non_goals_and_claim_boundary.md
```

because it stabilizes claim discipline for the entire corpus.

---

## 3. First-Time Reader Path

Target audience:

```text
new readers
GitHub visitors
systems researchers
runtime/VM readers
architecture reviewers
```

Recommended order:

```text
README.md
→ 01_blocks/00_overview.md
→ 01_blocks/01_architecture.md
→ 01_blocks/09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 02_reference/Glossary.md
→ 02_reference/Cross_Reference_Map.md
```

Purpose:

```text
understand PMS-STACK scope
understand operator grounding
understand claim boundaries
understand what is and is not claimed
```

Do not start with:

```text
03_pms_cpu.md
04_pms_os.md
07_distributed_systems.md
```

unless already familiar with the central architecture layer.

---

## 4. Systems Engineer Path

Target audience:

```text
systems programmers
runtime engineers
VM researchers
kernel/runtime architects
```

Recommended order:

```text
README.md
→ 00_overview.md
→ 01_architecture.md
→ 02_pms_um.md
→ 03_pms_cpu.md
→ 04_pms_os.md
→ 06_runtime_security.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 08_relation_to_pms_rust.md
→ 02_reference/Evidence_Map.md
```

Focus:

```text
machine structure
execution model
ISA architecture
syscall model
runtime governance
boundary architecture
```

Key checkpoints:

```text
PMS-UM tuple
PMS-CPU tuple
syscall ABI boundary
Χ projection discipline
trace / Trace distinction
```

---

## 5. OS / Kernel Path

Target audience:

```text
OS developers
kernel researchers
process/runtime architects
filesystem/runtime-security readers
```

Recommended order:

```text
README.md
→ 01_architecture.md
→ 03_pms_cpu.md
→ 04_pms_os.md
→ 06_runtime_security.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 07_distributed_systems.md
→ 08_relation_to_pms_rust.md
```

Focus:

```text
process model
syscall structure
namespace isolation
kernel governance
resource accounting
trap/fault/recovery model
runtime security
```

Key checkpoints:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
RF vs RAcc distinction
Χ projection discipline
ISO_EXIT semantics
sealed isolation rule
```

Boundary reminders:

```text
PMS-OS is architecture specification.
It is not production OS.
```

---

## 6. CPU / ISA Path

Target audience:

```text
ISA researchers
VM implementers
compiler/backend engineers
microarchitecture readers
```

Recommended order:

```text
README.md
→ 01_architecture.md
→ 02_pms_um.md
→ 03_pms_cpu.md
→ 08_relation_to_pms_rust.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 04_pms_os.md
→ 02_reference/Operator_Index.md
```

Focus:

```text
instruction classes
operator-grounded ISA
machine tuples
execution transitions
trap/recovery structure
boundary-exit semantics
```

Key checkpoints:

```text
M_CPU tuple
ISA operator families
Θ ordering discipline
Φ trap structure
ISO_EXIT
chi_exit relation
```

Boundary reminders:

```text
PMS-CPU is virtual CPU / ISA architecture.
It is not fabricated hardware.
```

---

## 7. Language / Runtime Path

Target audience:

```text
PL researchers
compiler/runtime engineers
IR/toolchain readers
effect-system readers
```

Recommended order:

```text
README.md
→ 01_architecture.md
→ 05_pmsl_pms_ir.md
→ 06_runtime_security.md
→ 08_relation_to_pms_rust.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 02_reference/Glossary.md
→ 02_reference/Operator_Index.md
```

Focus:

```text
PMSL grammar
PMS-IR structure
operator-preserving lowering
policy/effect constraints
runtime governance
AI Bridge boundary
```

Key checkpoints:

```text
operator-preserving IR
validated-under-profile
host validation
AI proposal boundary
policy remains Ψ-governed
```

Boundary reminders:

```text
PMSL/PMS-IR specify language/runtime architecture.
They do not claim a complete compiler.
```

---

## 8. Security Path

Target audience:

```text
security researchers
runtime governance reviewers
identity/capability readers
policy-system architects
```

Recommended order:

```text
README.md
→ 01_architecture.md
→ 04_pms_os.md
→ 06_runtime_security.md
→ 07_distributed_systems.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 08_relation_to_pms_rust.md
→ 02_reference/Evidence_Map.md
```

Focus:

```text
identity
capability structure
boundary management
audit
trust
quarantine
policy
distributed governance
```

Key checkpoints:

```text
Χ projection
Ψ-governed runtime policy
governance ≠ tribunal
audit ≠ proof of intent
quarantine ≠ blame
```

Security formula:

```text
Security-relevant transitions must remain Δ-distinguished,
Ω-authorized, □-framed, Χ-bounded, Θ-ordered where relevant,
Φ-recontextualized where needed, Σ-committed where stable,
and Ψ-constrained.
```

---

## 9. Distributed Systems Path

Target audience:

```text
distributed-systems researchers
consensus/runtime readers
cluster/runtime architects
```

Recommended order:

```text
README.md
→ 01_architecture.md
→ 06_runtime_security.md
→ 07_distributed_systems.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 08_relation_to_pms_rust.md
→ 02_reference/Operator_Index.md
```

Focus:

```text
distributed operator lifting
cluster frames
distributed commit
cross-node boundaries
global policy
distributed traces
```

Key checkpoints:

```text
Δᴳ–Ψᴳ notation
Χᴳ projection
Σᴳ integration
traceᴳ / Traceᴳ distinction
distributed policy binding
```

Boundary reminders:

```text
ᴳ marks distributed scope.
It does not introduce new PMS Base operators.
Distributed PMS-STACK is not completed distributed runtime.
Σᴳ is not a specific consensus algorithm.
```

---

## 10. PMS-RUST Evidence Path

Target audience:

```text
artifact reviewers
runtime implementers
evidence reviewers
GitHub readers
```

Recommended order:

```text
README.md
→ 00_overview.md
→ 08_relation_to_pms_rust.md
→ 02_reference/Evidence_Map.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ 05_pmsl_pms_ir.md
→ 06_runtime_security.md
```

Focus:

```text
bounded executable evidence
validators
fixtures
JSONL traces
REPL/script tooling
AI Bridge boundaries
runtime gates
```

Key checkpoints:

```text
Evidence Spine
tests check
traces record
validators accept/reject
fixtures stabilize
AI proposes; host validates
chi_exit vs ISO_EXIT
```

Boundary reminders:

```text
PMS-RUST evidences bounded implementation slices.
It does not validate PMS Base.
It does not complete PMS-STACK.
```

---

## 11. Claim-Boundary Audit Path

Target audience:

```text
reviewers
editors
release maintainers
claim auditors
publication reviewers
```

Recommended order:

```text
09_non_goals_and_claim_boundary.md
→ 02_reference/Audit_Checklist.md
→ 02_reference/Claim_Type_Table.md
→ 02_reference/Cross_Reference_Map.md
→ 03_minified/PMS_STACK_Claim_Boundary_Minified.md
```

Optional continuation:

```text
→ README.md
→ 08_relation_to_pms_rust.md
```

Focus:

```text
claim discipline
safe wording
evidence boundaries
Χ discipline
trace discipline
AI boundary discipline
```

Key checkpoints:

```text
strong claim → claim type → boundary
Χ = Distance
trace vs Trace
tests vs proofs
chi_exit vs ISO_EXIT
AI proposal boundary
```

Audit questions:

```text
Does the file overclaim?
Does the file collapse architecture into implementation?
Does the file collapse evidence into validation?
Does the file collapse projection into redefinition?
Does the file collapse tooling into authority?
```

---

## 12. Fast Review Path

Target audience:

```text
conference reviewers
GitHub skimmers
technical leads
quick architecture reviewers
```

Recommended order:

```text
README.md
→ 00_overview.md
→ 01_architecture.md
→ 08_relation_to_pms_rust.md
→ 09_non_goals_and_claim_boundary.md
```

Optional continuation:

```text
→ PMS_STACK_Minified_Canonical.md
```

Estimated focus time:

```text
30–90 minutes
```

Primary outcome:

```text
understand PMS-STACK architecture scope
understand implementation-layer claim
understand PMS-RUST relation
understand claim boundaries
```

---

## 13. Reader-Support Files

Recommended support usage:

```text
Glossary.md
    terminology lookup

Cross_Reference_Map.md
    topic-to-file navigation

Evidence_Map.md
    claim/evidence mapping

Audit_Checklist.md
    release auditing

Claim_Type_Table.md
    wording discipline

Operator_Index.md
    Δ–Ψ projection lookup
```

Optional reading order for full reference pass:

```text
Glossary
→ Operator Index
→ Cross Reference Map
→ Evidence Map
→ Claim Type Table
→ Audit Checklist
```

---

## 14. Reader Layer Boundary

The Reader layer includes:

```text
02_reference/
05_PMS-STACK Reader/
```

Its role is:

```text
navigation
inspection
cross-reference
audit assistance
release support
```

Its role is not:

```text
canonical specification
PMS Base validation
implementation completion
proof
runtime authority
compiler authority
AI authority
evidence creation
```

Canonical Reader boundary:

```text
The PMS-STACK Reader is a convenience tool for local navigation and
inspection. It does not replace canonical Markdown, modify the
specification, validate PMS-STACK, validate PMS Base, prove implementation
completion, or establish PMS-RUST completeness.
```

---

## 15. Final Navigation Formula

```text
PMS-STACK is specified in canonical blocks,
indexed in reference files,
compressed in minified contracts,
explained in derivative publications,
and navigated through the Reader.
```

Expanded:

```text
README.md + 01_blocks/00–09 define the canonical PMS-STACK specification.

00_source preserves origin material.
02_reference indexes the canonical specification.
03_minified compresses the canonical specification.
04_derivative_publications explains the canonical specification.
05_PMS-STACK Reader navigates the canonical specification.

None of the derivative, reference, minified, publication, tooling,
artifact, or reader layers replace the canonical blocks or validate
PMS Base.
```
