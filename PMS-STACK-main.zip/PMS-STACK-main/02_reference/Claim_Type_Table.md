---
document_id: PMS-STACK-REF-CLAIM-TYPE-TABLE
title: "PMS-STACK Claim Type Table"
status: "release-candidate"
version: "v0.1"
claim_type: "reference table / claim taxonomy / safe-wording support"
canonical_status: "derivative; indexes README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file indexes PMS-STACK claim types and safe wording. It does not replace the canonical blocks, redefine PMS Base, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Claim Type Table

## 1. Canonical Status

This file defines a reference taxonomy for PMS-STACK claim types.

It belongs to:

```text
02_reference/
```

Its role is:

```text
reference
claim taxonomy
safe-wording support
release audit support
non-canonical
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Boundary:

```text
This table indexes claim types.
It does not redefine PMS-STACK.
It does not replace canonical blocks.
It does not validate PMS Base.
It does not create evidence.
It does not establish implementation completion.
```

---

## 2. Claim Rule

PMS-STACK uses strong claims.

The rule is not to weaken PMS-STACK.

The rule is to type claims.

Canonical pattern:

```text
strong claim → claim type → boundary
```

Correct global claim:

```text
PMS-STACK is the implementation-layer architecture specification of PMS:
an operator-grounded systems architecture deriving abstract machine,
virtual CPU, OS, runtime, language, security, networking, distributed
systems, tooling, simulation, verification, boot, and cluster profiles
from Δ–Ψ.
```

Claim type:

```text
implementation-layer architecture specification claim
```

Boundary:

```text
This does not validate PMS Base, prove PMS as a praxis theory, imply that
all layers are implemented, or claim fabricated hardware.
```

---

## 3. Claim-Type Vocabulary

### Base / Theory Claim

A claim about PMS Base operator identity, dependency structure, theoretical scope, or theory-level non-goals.

Authority source:

```text
PMS Base / PMS.yaml / Praxeological Meta-Structure Theory
```

Boundary:

```text
Base claims are not proven by PMS-STACK.
```

### Architecture Claim

A claim that PMS-STACK specifies a structural system architecture.

Examples:

```text
PMS-UM abstract-machine architecture
PMS-CPU virtual ISA architecture
PMS-OS operating-system architecture
PMSL/PMS-IR language/runtime architecture
runtime-security architecture
distributed-systems architecture
```

Boundary:

```text
Architecture is not implementation completion.
```

### Formal Claim

A claim expressed through formal notation, tuple, relation, language, transition, or mapping.

Boundary:

```text
Formal notation is not automatically a proof of every property.
```

### Computational Expressiveness Claim

A claim that PMS-UM can encode classical computation or simulate relevant abstract-machine behavior.

Boundary:

```text
Computational expressiveness does not prove OS correctness, CPU
implementation correctness, security correctness, distributed correctness,
all-program termination, or PMS Base validation.
```

### Implementation Claim

A claim that a specified architecture can be built or realized in software, runtime, VM, OS, tooling, or artifact form.

Boundary:

```text
Implementation possibility is not implementation completion.
Implementation is not truth.
```

### Artifact Claim

A claim backed by a concrete bounded artifact.

Examples:

```text
PMS-RUST runtime slice
validator
fixture
JSONL trace
REPL/script demo
vFS surface
AI bridge gate
```

Boundary:

```text
Artifact evidence supports only the declared artifact scope.
It does not validate PMS Base.
```

### Evidence Claim

A claim that an artifact, trace, fixture, validator, test, or gate supports a bounded implementation assertion.

Boundary:

```text
Evidence strengthens typed implementation-artifact claims.
It does not change claim type.
```

### Verification Claim

A claim that a property is checked or proven under a declared model, assumptions, and method.

Boundary:

```text
Verification is property-specific.
It does not automatically validate PMS Base.
```

### Security Claim

A claim about operator-structured runtime security, identity, capability, boundary, policy, audit, trust, quarantine, or enforcement architecture.

Boundary:

```text
Security architecture is not universal security certification.
Governance is not tribunal.
```

### Distributed Claim

A claim about distributed profiles, scope-lifted operators, cluster frames, network protocols, distributed commit, global policies, or cross-node boundaries.

Boundary:

```text
Distributed architecture is not completed distributed runtime.
Distributed scope does not introduce new PMS Base operators.
```

### Roadmap Claim

A claim about future work, artifact targets, implementation targets, proof targets, or release direction.

Boundary:

```text
Roadmap is not evidence.
```

### AI / Tooling Claim

A claim about optional AI-assisted proposal, trace analysis, diagnostics, or tooling support.

Boundary:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI is not authority.

### Reader / Navigation Claim

A claim about local navigation, search, inspection, or corpus reading support.

Boundary:

```text
The Reader navigates.
It does not validate PMS-STACK.
```

---

## 4. Claim-Type Matrix

| Claim object            | Correct claim type                              | Boundary                                                    |
| ----------------------- | ----------------------------------------------- | ----------------------------------------------------------- |
| PMS Base                | base/theory operator grammar                    | not proven by PMS-STACK                                     |
| PMS-STACK               | implementation-layer architecture specification | not PMS Base validation                                     |
| Operator identity       | base/theory claim                               | PMS-STACK projects but does not redefine                    |
| Operator projection     | architecture claim                              | projection is not redefinition                              |
| PMS-UM                  | abstract-machine architecture claim             | not full simulator by itself                                |
| PMS-UM universality     | computational expressiveness claim              | not OS/security/distributed correctness                     |
| PMS-CPU                 | virtual CPU / ISA architecture claim            | not fabricated hardware                                     |
| ISO_EXIT                | PMS-CPU architecture-level instruction claim    | not PMS-RUST chi_exit itself                                |
| PMS-OS                  | operating-system architecture claim             | not production OS                                           |
| PMS-OS syscall ABI      | OS-level trap/syscall ABI profile claim         | does not replace ordinary PMS-CPU calling convention        |
| PMSL                    | language architecture claim                     | not complete compiler                                       |
| PMS-IR                  | intermediate-representation architecture claim  | not compiler authority                                      |
| PMSL type system        | language/runtime architecture claim             | soundness target unless separately proven                   |
| Runtime security        | runtime-security architecture claim             | not universal certification                                 |
| Runtime governance      | Ψ-governed policy architecture claim            | not tribunal, moral, legal, clinical, or forensic authority |
| Distributed PMS-STACK   | distributed architecture/profile claim          | not completed distributed runtime                           |
| ᴳ notation              | distributed scope notation claim                | not new PMS Base operators                                  |
| Σᴳ                      | distributed commit/integration claim            | not a specific consensus algorithm                          |
| PMS-RUST                | bounded implementation-artifact evidence claim  | not PMS-STACK completion                                    |
| PMS-RUST chi_exit       | bounded runtime artifact evidence claim         | not ISO_EXIT completion                                     |
| Tests                   | behavioral check claim                          | not proof                                                   |
| Traces                  | execution-record evidence claim                 | not Trace-set proof                                         |
| Validators              | profile-level accept/reject claim               | not PMS Base validation                                     |
| Fixtures                | stable known-case evidence claim                | not exhaustive correctness                                  |
| Formal proof            | property-specific proof claim                   | under stated assumptions only                               |
| External validation     | external-protocol validation claim              | not implied by tests/traces                                 |
| AI Bridge               | proposal/tooling claim                          | not authority                                               |
| Reader                  | navigation/inspection claim                     | not evidence                                                |
| Reference files         | index claim                                     | not canonical specification                                 |
| Minified files          | compression claim                               | not canonical replacement                                   |
| Derivative publications | explanatory claim                               | not canonical specification                                 |

---

## 5. Safe Claim Pattern

Use:

```text
[Strong claim].
Claim type:
    [specific type].
Boundary:
    [what it does not establish].
```

Example:

```text
PMS-CPU specifies a complete virtual CPU / ISA architecture over the Δ–Ψ
operator grammar.

Claim type:
    virtual CPU / ISA architecture claim

Boundary:
    This does not claim fabricated hardware, a completed emulator, a
    completed compiler backend, or PMS Base validation.
```

Example:

```text
PMS-RUST evidences bounded implementation slices of PMS-STACK.

Claim type:
    bounded implementation-artifact evidence claim

Boundary:
    This does not validate PMS Base, complete PMS-STACK, complete PMS-CPU,
    complete PMS-OS, complete PMSL, or complete distributed PMS.
```

---

## 6. Unsafe Claim Patterns

Do not write:

```text
PMS-STACK validates PMS Base.
PMS-RUST validates PMS Base.
PMS-STACK proves PMS.
PMS-RUST proves PMS.
Tests prove PMS.
Traces prove PMS.
Validators validate PMS Base.
Implementation equals truth.
Portability equals equivalence.
Governance is tribunal.
AI output is trusted executable code.
AI output is verification evidence.
PMS-CPU is fabricated hardware.
PMS-OS is production OS.
PMSL is a complete compiler.
Distributed PMS-STACK is a completed runtime.
chi_exit completes ISO_EXIT.
Χ means isolation at PMS Base level.
Reference files redefine PMS-STACK.
Reader validates PMS-STACK.
```

Safe replacements:

| Unsafe wording                | Safe replacement                                                             |
| ----------------------------- | ---------------------------------------------------------------------------- |
| PMS-STACK proves PMS Base     | PMS-STACK specifies PMS implementation-layer architecture                    |
| PMS-STACK validates PMS       | PMS-STACK strengthens the architecture claim; it does not validate PMS Base  |
| PMS-RUST validates PMS        | PMS-RUST evidences bounded implementation slices                             |
| tests prove correctness       | tests check declared behavior                                                |
| traces validate PMS           | traces record executions under declared profiles                             |
| validator validates PMS Base  | validator accepts/rejects under declared profile                             |
| PMS-CPU is hardware           | PMS-CPU is a virtual CPU / ISA architecture                                  |
| PMS-OS is complete            | PMS-OS is an operating-system architecture specification                     |
| PMSL is implemented           | PMSL/PMS-IR are language/runtime architecture specifications                 |
| AI compiles authoritatively   | AI proposes; host validates                                                  |
| AI verifies                   | AI may assist analysis; verification remains formal/profile-bound            |
| Χ means isolation             | PMS Base Χ = Distance; implementation layers project Χ as isolation/boundary |
| chi_exit is ISO_EXIT          | chi_exit is runtime evidence; ISO_EXIT is architecture-level ISA instruction |
| distributed operators are new | ᴳ marks distributed scope, not new operators                                 |
| Reader validates              | Reader navigates and inspects                                                |
| minified is canon             | minified compresses the canonical blocks                                     |

---

## 7. Validation Vocabulary

### validated-under-profile

Meaning:

```text
accepted or rejected by a declared validator, profile, gate, schema, or
conformance rule
```

Not meaning:

```text
PMS Base validation
external validation
proof of all behavior
semantic completeness
implementation correctness
```

### checked

Use for tests:

```text
tests check declared behavior
```

### recorded

Use for traces:

```text
traces record executions
```

### accepted / rejected

Use for validators:

```text
validators accept or reject under declared profiles
```

### stabilized

Use for fixtures:

```text
fixtures stabilize known cases
```

### proven

Use only for formal proofs:

```text
proofs prove stated properties under stated assumptions
```

### externally validated

Use only when an explicit external validation protocol exists:

```text
external validation validates under external protocols
```

---

## 8. Claim-Type Boundaries by Layer

| Layer               | Strong claim                                               | Claim type                       | Boundary                           |
| ------------------- | ---------------------------------------------------------- | -------------------------------- | ---------------------------------- |
| PMS Base            | defines Δ–Ψ                                                | base/theory claim                | not validated by PMS-STACK         |
| PMS-STACK           | derives implementation-layer systems architecture from Δ–Ψ | architecture specification claim | not implementation completion      |
| PMS-UM              | defines abstract-machine execution substrate               | abstract-machine claim           | not proof of all system properties |
| PMS-CPU             | defines virtual CPU / ISA                                  | virtual CPU architecture claim   | not hardware                       |
| PMS-OS              | defines OS architecture                                    | OS architecture claim            | not production OS                  |
| PMSL/PMS-IR         | defines language/runtime/IR architecture                   | language/runtime claim           | not complete compiler              |
| Runtime security    | defines operator-structured security                       | security architecture claim      | not universal certification        |
| Distributed systems | defines distributed profiles                               | distributed architecture claim   | not completed distributed runtime  |
| PMS-RUST            | evidences executable slices                                | artifact evidence claim          | not PMS Base validation            |
| AI Bridge           | proposes artifacts / analyzes traces                       | tooling claim                    | not authority                      |
| Reader              | navigates corpus                                           | navigation claim                 | not evidence                       |

---

## 9. Minimal Safe Formulas

### PMS-STACK

```text
PMS-STACK specifies the implementation-layer architecture of PMS.
It does not validate PMS Base.
```

### PMS-UM

```text
PMS-UM specifies the abstract-machine layer and computational expressiveness
claim of PMS-STACK. It does not prove all system properties.
```

### PMS-CPU

```text
PMS-CPU specifies a virtual CPU / ISA architecture. It does not claim
fabricated hardware.
```

### PMS-OS

```text
PMS-OS specifies an operating-system architecture. It does not claim a
production OS.
```

### PMSL / PMS-IR

```text
PMSL and PMS-IR specify language/runtime architecture. They do not claim a
complete compiler or trusted AI execution path.
```

### Runtime Security

```text
PMS-STACK specifies runtime security as operator-structured architecture.
It does not certify all implementations as secure.
```

### Distributed Systems

```text
Distributed PMS-STACK specifies optional distributed architecture profiles.
It does not complete or prove a distributed runtime.
```

### PMS-RUST

```text
PMS-RUST is a bounded executable PMS-STACK Evidence Spine v0.1.
It evidences selected implementation slices and does not validate PMS Base.
```

### AI Bridge

```text
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
Policy remains Ψ-governed.
```

### Trace

```text
trace(...) records one execution.
Trace(...) denotes a set of possible executions.
A trace does not prove the entire Trace set.
```

### Reader

```text
The Reader navigates PMS-STACK.
It does not validate PMS-STACK.
```

---

## 10. Final Claim Formula

```text
PMS Base defines.
PMS-STACK specifies.
PMS-RUST evidences.
Tests check.
Traces record.
Validators accept or reject under declared profiles.
Fixtures stabilize bounded cases.
Gates discipline releases.
Proofs prove stated properties under assumptions.
External validation validates under external protocols.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
Reference files index.
Minified files compress.
Derivative publications explain.
The Reader navigates.

None of these lower, derivative, artifact, tooling, or support layers validate PMS Base.
```
