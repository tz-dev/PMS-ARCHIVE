---
document_id: PMS-STACK-REF-EVIDENCE-MAP
title: "PMS-STACK Evidence Map"
status: "release-candidate"
version: "v0.1"
claim_type: "reference index / evidence taxonomy / artifact-boundary map"
canonical_status: "derivative; indexes README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file maps PMS-STACK claims to evidence types and artifact boundaries. It does not replace the canonical blocks, redefine PMS Base, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Evidence Map

## 1. Canonical Status

This file maps PMS-STACK claims to evidence types, artifact relations, and claim boundaries.

It belongs to:

```text
02_reference/
```

Its role is:

```text
reference
evidence taxonomy
artifact-boundary map
PMS-RUST relation index
claim-discipline support
non-canonical
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Reference boundary:

```text
Reference files index PMS-STACK.
They do not redefine PMS-STACK.
They do not replace canonical blocks.
They do not introduce new operators.
They do not validate PMS Base.
They do not establish implementation completion.
They do not create evidence.
```

---

## 2. Evidence Rule

Evidence strengthens typed implementation-artifact claims under declared scope.

It does not validate PMS Base.

It does not change claim type.

It does not prove all behavior.

It does not establish implementation completion beyond the declared artifact scope.

Canonical rule:

```text
STACK claim
→ executable slice
→ validation rule
→ golden fixture
→ trace evidence
→ limitation
```

Correct evidence wording:

```text
artifact evidence strengthens a bounded implementation claim
```

Incorrect evidence wording:

```text
artifact evidence validates PMS Base
```

---

## 3. Evidence Vocabulary

| Evidence term       | Correct role                                   | Boundary                     |
| ------------------- | ---------------------------------------------- | ---------------------------- |
| Specification       | defines architecture                           | not implementation by itself |
| Artifact            | executable or inspectable implementation slice | not PMS Base validation      |
| Test                | checks declared behavior                       | not proof                    |
| Trace               | records one execution                          | not full Trace-set proof     |
| Validator           | accepts or rejects under declared profile      | not external validation      |
| Fixture             | stabilizes known case                          | not exhaustive correctness   |
| Gate                | disciplines release acceptance                 | not proof                    |
| Simulation          | executes or inspects under model/profile       | not semantic completeness    |
| Model checking      | checks stated properties under stated model    | not PMS Base validation      |
| Formal proof        | proves stated property under assumptions       | not universal proof          |
| External validation | validates under external protocol              | requires separate protocol   |
| AI analysis         | advisory interpretation or proposal            | not authority                |

Safe verbs:

```text
specifications specify
artifacts evidence
tests check
traces record
validators accept or reject
fixtures stabilize
gates discipline
simulations execute under assumptions
model checkers check stated models
proofs prove stated properties
external validation validates externally
AI proposes or comments
```

Forbidden verbs:

```text
tests prove PMS
traces validate PMS Base
validators validate PMS Base
fixtures exhaust correctness
artifacts prove theory
AI verifies PMS
implementation equals truth
```

---

## 4. PMS-RUST Evidence Spine

PMS-RUST is a bounded executable PMS-STACK Evidence Spine v0.1.

Correct relation:

```text
PMS Base
    defines Δ–Ψ operator identity

PMS-STACK
    specifies implementation-layer architecture

PMS-RUST
    evidences bounded executable implementation slices
```

PMS-RUST may evidence:

```text
operator representation
deterministic kernel execution
model validation
stateful validation
REPL/script tooling
JSONL trace emission
golden fixture discipline
vFS service surfaces
AI proposal boundaries
boundary-exit discipline where declared
```

PMS-RUST does not establish:

```text
PMS Base validation
PMS-STACK completion
complete PMS-UM implementation
complete PMS-CPU implementation
complete PMS-OS implementation
complete PMSL compiler
complete distributed runtime
full formal verification
external validation
trusted AI execution
```

---

## 5. STACK Claim → Artifact Evidence Matrix

| STACK claim                   | Evidence type                        | PMS-RUST slice                                             | Boundary                                 |
| ----------------------------- | ------------------------------------ | ---------------------------------------------------------- | ---------------------------------------- |
| Operator representation       | code / model data                    | opcode representation, key normalization, PMS.yaml loading | not PMS Base definition                  |
| Model validation              | validator                            | PMS.yaml dependency validation                             | not PMS Base validation                  |
| Stateful execution validation | runtime validator                    | stateful pre-execution checks                              | not full PMS-UM proof                    |
| Deterministic execution       | executable runtime                   | pms-kernel deterministic execution                         | not full PMS-CPU / PMS-OS implementation |
| Traceability                  | JSONL trace                          | KernelEvent / audit output                                 | not proof of all behavior                |
| PMS-IR construction           | builder / buffer                     | pms-ir builder, opcode buffer                              | not full PMSL compiler                   |
| REPL/script tooling           | tool surface                         | pms-repl commands and scripts                              | not full language implementation         |
| vFS surface                   | service layer                        | vFS commands and events                                    | not PMS-OS filesystem completion         |
| Golden fixtures               | tests / fixtures                     | demo and fixture expectations                              | not exhaustive correctness               |
| AI proposal boundary          | bridge / gate                        | pms-ai-bridge                                              | not trusted AI execution                 |
| Boundary exit                 | runtime command / validator behavior | chi_exit where implemented                                 | not ISO_EXIT completion                  |
| Release discipline            | gates                                | fmt/test/clippy/acceptance gates                           | not proof or external validation         |

---

## 6. Trace Evidence

A trace records one concrete observed or constructed execution.

Single execution:

```text
trace(artifact, profile, input) ∈ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
```

Distributed single execution:

```text
traceᴳ(D, profile, input) ∈ L_PMS
```

Under active distributed policy:

```text
traceᴳ(D, profile, input) ∈ L_PMS,Ψᴳ
```

Boundary:

```text
A trace records one bounded execution under a declared profile.
It does not enumerate or prove the full Trace(...) set.
It does not validate PMS Base.
```

Trace-set notation:

```text
Trace(artifact, profile) ⊆ L_PMS
Trace(artifact, profile) ⊆ L_PMS,Ψ
Traceᴳ(D, profile) ⊆ L_PMS
Traceᴳ(D, profile) ⊆ L_PMS,Ψᴳ
```

---

## 7. Validator Evidence

A validator accepts or rejects artifacts under a declared schema, model, profile, fixture, gate, or conformance rule.

Correct wording:

```text
validated under profile
```

Meaning:

```text
accepted or rejected by a declared validator, profile, gate, schema, or
conformance rule
```

Boundary:

```text
validated-under-profile is not PMS Base validation.
validated-under-profile is not external validation.
validated-under-profile is not proof of all behavior.
```

Examples:

```text
model validator accepts or rejects operator adjacency under PMS.yaml
stateful validator accepts or rejects runtime preconditions
script validator accepts or rejects unsupported commands
AI bridge gate accepts or rejects proposed opcode programs
```

---

## 8. Fixture Evidence

Fixtures stabilize known cases.

They may show:

```text
known valid trace accepted
known invalid trace rejected
stateful invalidity detected
script/service boundary preserved
AI malformed proposal rejected
boundary-exit invalidity detected
```

Boundary:

```text
Fixtures are bounded artifact evidence.
Fixtures are not exhaustive correctness.
Fixtures do not validate PMS Base.
Fixtures do not prove all variants are blocked.
```

Correct wording:

```text
This fixture stabilizes a known expected behavior under the declared profile.
```

Incorrect wording:

```text
This fixture proves correctness.
```

---

## 9. AI Boundary Evidence

The AI Bridge is evidence only of a proposal boundary when implemented and gated.

Authority chain:

```text
AI proposes.
Host parses, canonicalizes, maps, and validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI may evidence:

```text
proposal envelope handling
task/result-shape enforcement
opcode whitelist enforcement
fail-closed behavior
dry-run proposal behavior
trace-analysis advisory output
buffer replacement only after validation
```

AI may not evidence:

```text
trusted execution
compiler authority
verifier authority
policy authority
PMSL semantics
PMS-IR truth
PMS Base validation
```

Correct wording:

```text
The AI Bridge evidences a bounded proposal and observability surface.
```

Incorrect wording:

```text
AI verifies PMS-IR.
AI compiles PMSL authoritatively.
AI output is trusted executable code.
```

---

## 10. Boundary-Exit Evidence

PMS-CPU and PMS-RUST boundary-exit concepts are related but layer-distinct.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Shared validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under declared profile and active boundary context.
```

Evidence boundary:

```text
PMS-RUST chi_exit may evidence bounded runtime boundary-exit discipline.
It does not complete ISO_EXIT.
It does not redefine PMS Base Χ.
It does not complete PMS-CPU.
It does not complete PMS-OS isolation.
It does not validate PMS Base.
```

---

## 11. Roadmap vs Evidence

A roadmap item is a future artifact target.

An evidence item is an artifact-backed claim under declared scope.

| Item                         | Correct status          | Boundary                                                     |
| ---------------------------- | ----------------------- | ------------------------------------------------------------ |
| full PMS-CPU simulator       | future artifact         | not evidenced by PMS-RUST v0.1 unless separately implemented |
| full PMS-OS kernel           | future artifact         | not claimed by architecture spec                             |
| full PMSL compiler           | future artifact         | PMSL/PMS-IR currently architecture claim                     |
| distributed runtime          | future artifact/profile | distributed architecture is specified, runtime not complete  |
| formal verification suite    | future artifact         | proof requires stated properties and assumptions             |
| external validation protocol | future work             | not replaced by tests or traces                              |
| Reader                       | navigation support      | not evidence                                                 |
| derivative publications      | explanation             | not canonical evidence                                       |

Correct roadmap wording:

```text
future artifact target
```

Incorrect roadmap wording:

```text
already proven
already validated
already complete
```

---

## 12. Evidence Boundary by Layer

| Layer                   | Evidence status                   | Boundary                            |
| ----------------------- | --------------------------------- | ----------------------------------- |
| PMS Base                | theory / operator source          | not evidenced as valid by PMS-STACK |
| PMS-STACK               | architecture specification        | not implementation by itself        |
| PMS-UM                  | specified abstract machine        | not full simulator by itself        |
| PMS-CPU                 | virtual CPU / ISA architecture    | not fabricated hardware             |
| PMS-OS                  | OS architecture                   | not production OS                   |
| PMSL / PMS-IR           | language/runtime architecture     | not complete compiler               |
| Runtime security        | security architecture             | not universal certification         |
| Distributed systems     | distributed profile architecture  | not completed distributed runtime   |
| PMS-RUST                | bounded executable Evidence Spine | not PMS-STACK completion            |
| Reader                  | navigation tool                   | not evidence                        |
| Reference files         | index                             | not evidence                        |
| Minified files          | compress                          | not evidence                        |
| Derivative publications | explain                           | not evidence                        |

---

## 13. Forbidden Evidence Drift

Do not write:

```text
PMS-STACK validates PMS Base.
PMS-RUST validates PMS Base.
Tests prove PMS.
Traces prove PMS.
Runtime traces externally validate PMS.
Validators validate PMS Base.
Fixtures exhaust correctness.
Golden tests prove semantic completeness.
Runtime dialect equals PMS 1.3 theory.
Implementation equals truth.
AI output is trusted executable code.
AI output is verification evidence.
chi_exit completes ISO_EXIT.
Reader output validates PMS-STACK.
Derivative publication proves PMS-STACK.
```

Safe replacements:

```text
PMS-STACK specifies PMS implementation-layer architecture.
PMS-RUST evidences bounded implementation slices.
Tests check declared behavior.
Traces record executions.
Validators accept or reject under declared profiles.
Fixtures stabilize known cases.
AI proposes; host validates.
chi_exit evidences bounded runtime boundary-exit discipline.
The Reader navigates and inspects.
```

---

## 14. Minimal Evidence Formula

```text
PMS Base defines.
PMS-STACK specifies.
PMS-RUST evidences bounded implementation slices.
Tests check.
Traces record.
Validators accept or reject under declared profiles.
Fixtures stabilize bounded cases.
Gates discipline releases.
Proofs prove stated properties under assumptions.
External validation validates under external protocols.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.

None of these lower, derivative, artifact, tooling, or support layers validate PMS Base.
```
