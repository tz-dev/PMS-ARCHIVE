---
document_id: PMS-STACK-REF-CROSS-REFERENCE-MAP
title: "PMS-STACK Cross Reference Map"
status: "release-candidate"
version: "v0.1"
claim_type: "reference index / topic navigation / canonical-block cross-reference"
canonical_status: "derivative; indexes README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file indexes PMS-STACK topics across the canonical block corpus. It does not replace the canonical blocks, redefine PMS Base, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Cross Reference Map

## 1. Canonical Status

This file maps PMS-STACK topics to their primary and secondary canonical locations.

It belongs to:

```text
02_reference/
```

Its role is:

```text
reference
navigation aid
topic index
cross-file orientation
claim-boundary support
non-canonical
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Reference boundary:

```text
Reference files index PMS-STACK.
They do not redefine PMS-STACK.
They do not replace canonical blocks.
They do not introduce new operators.
They do not validate PMS Base.
They do not establish implementation completion.
```

---

## 2. Reading by Layer

| Layer / topic           | Primary file                                   | Secondary files                                                                                                            |
| ----------------------- | ---------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| PMS-STACK overview      | `01_blocks/00_overview.md`                     | `01_blocks/09_non_goals_and_claim_boundary.md`                                                                             |
| Central architecture    | `01_blocks/01_architecture.md`                 | `01_blocks/00_overview.md`, `01_blocks/09_non_goals_and_claim_boundary.md`                                                 |
| Operator grammar        | `01_blocks/01_architecture.md`                 | `01_blocks/00_overview.md`, `02_reference/Operator_Index.md`                                                               |
| Valid sequence language | `01_blocks/01_architecture.md`                 | `01_blocks/02_pms_um.md`, `01_blocks/09_non_goals_and_claim_boundary.md`                                                   |
| PMS-UM                  | `01_blocks/02_pms_um.md`                       | `01_blocks/01_architecture.md`, `01_blocks/09_non_goals_and_claim_boundary.md`                                             |
| PMS-CPU                 | `01_blocks/03_pms_cpu.md`                      | `01_blocks/02_pms_um.md`, `01_blocks/04_pms_os.md`, `01_blocks/08_relation_to_pms_rust.md`                                 |
| PMS-OS                  | `01_blocks/04_pms_os.md`                       | `01_blocks/03_pms_cpu.md`, `01_blocks/06_runtime_security.md`, `01_blocks/09_non_goals_and_claim_boundary.md`              |
| PMSL / PMS-IR           | `01_blocks/05_pmsl_pms_ir.md`                  | `01_blocks/06_runtime_security.md`, `01_blocks/08_relation_to_pms_rust.md`, `01_blocks/09_non_goals_and_claim_boundary.md` |
| Runtime security        | `01_blocks/06_runtime_security.md`             | `01_blocks/04_pms_os.md`, `01_blocks/05_pmsl_pms_ir.md`, `01_blocks/07_distributed_systems.md`                             |
| Distributed systems     | `01_blocks/07_distributed_systems.md`          | `01_blocks/06_runtime_security.md`, `01_blocks/09_non_goals_and_claim_boundary.md`                                         |
| PMS-RUST relation       | `01_blocks/08_relation_to_pms_rust.md`         | `01_blocks/03_pms_cpu.md`, `01_blocks/05_pmsl_pms_ir.md`, `01_blocks/06_runtime_security.md`                               |
| Claim boundaries        | `01_blocks/09_non_goals_and_claim_boundary.md` | all canonical blocks                                                                                                       |
| Repository orientation  | `README.md`                                    | `01_blocks/00_overview.md`, `02_reference/Reader_Pathways.md`                                                              |

---

## 3. Reading by Operator

| Operator | Primary file                   | Secondary files                                                                                                                | Typical lookup topics                                       |
| -------- | ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------- |
| Δ        | `01_blocks/01_architecture.md` | `02_reference/Operator_Index.md`, all layer files                                                                              | distinction, classification, identity, decode, message kind |
| ∇        | `01_blocks/01_architecture.md` | `01_blocks/02_pms_um.md`, `01_blocks/03_pms_cpu.md`, `01_blocks/04_pms_os.md`                                                  | action, mutation, syscall body, execution                   |
| □        | `01_blocks/01_architecture.md` | `01_blocks/04_pms_os.md`, `01_blocks/05_pmsl_pms_ir.md`, `01_blocks/07_distributed_systems.md`                                 | frame, process, module, session, cluster                    |
| Λ        | `01_blocks/01_architecture.md` | `01_blocks/02_pms_um.md`, `01_blocks/06_runtime_security.md`, `01_blocks/07_distributed_systems.md`                            | non-event, timeout, absence, no quorum                      |
| Α        | `01_blocks/01_architecture.md` | `01_blocks/05_pmsl_pms_ir.md`, `01_blocks/07_distributed_systems.md`                                                           | pattern, macro, protocol flow, lifecycle                    |
| Ω        | `01_blocks/01_architecture.md` | `01_blocks/03_pms_cpu.md`, `01_blocks/04_pms_os.md`, `01_blocks/06_runtime_security.md`                                        | role, capability, privilege, authority                      |
| Θ        | `01_blocks/01_architecture.md` | `01_blocks/03_pms_cpu.md`, `01_blocks/04_pms_os.md`, `01_blocks/07_distributed_systems.md`                                     | order, scheduler, sequence, logical clock                   |
| Φ        | `01_blocks/01_architecture.md` | `01_blocks/03_pms_cpu.md`, `01_blocks/04_pms_os.md`, `01_blocks/06_runtime_security.md`                                        | trap, interrupt, exception, migration, recovery             |
| Χ        | `01_blocks/01_architecture.md` | `01_blocks/03_pms_cpu.md`, `01_blocks/04_pms_os.md`, `01_blocks/06_runtime_security.md`, `01_blocks/07_distributed_systems.md` | Distance, isolation projection, boundary, reachability      |
| Σ        | `01_blocks/01_architecture.md` | `01_blocks/04_pms_os.md`, `01_blocks/06_runtime_security.md`, `01_blocks/07_distributed_systems.md`                            | commit, integration, audit record, distributed commit       |
| Ψ        | `01_blocks/01_architecture.md` | `01_blocks/04_pms_os.md`, `01_blocks/06_runtime_security.md`, `01_blocks/09_non_goals_and_claim_boundary.md`                   | policy, invariant, self-binding, governance discipline      |

Boundary:

```text
Operator lookup identifies where operators are specified or projected.
It does not redefine operator identity.
PMS Base remains the source of operator identity.
```

---

## 4. Reading by Claim Type

| Claim type                              | Primary file                                   | Secondary files                                                                        |
| --------------------------------------- | ---------------------------------------------- | -------------------------------------------------------------------------------------- |
| Implementation-layer architecture claim | `01_blocks/00_overview.md`                     | `01_blocks/01_architecture.md`, `01_blocks/09_non_goals_and_claim_boundary.md`         |
| Central architecture claim              | `01_blocks/01_architecture.md`                 | all layer files                                                                        |
| Abstract-machine claim                  | `01_blocks/02_pms_um.md`                       | `01_blocks/01_architecture.md`, `01_blocks/09_non_goals_and_claim_boundary.md`         |
| Computational expressiveness claim      | `01_blocks/02_pms_um.md`                       | `01_blocks/01_architecture.md`, `02_reference/Claim_Type_Table.md`                     |
| Virtual CPU / ISA claim                 | `01_blocks/03_pms_cpu.md`                      | `01_blocks/02_pms_um.md`, `01_blocks/08_relation_to_pms_rust.md`                       |
| OS architecture claim                   | `01_blocks/04_pms_os.md`                       | `01_blocks/03_pms_cpu.md`, `01_blocks/06_runtime_security.md`                          |
| Language/runtime architecture claim     | `01_blocks/05_pmsl_pms_ir.md`                  | `01_blocks/08_relation_to_pms_rust.md`, `01_blocks/09_non_goals_and_claim_boundary.md` |
| Runtime-security architecture claim     | `01_blocks/06_runtime_security.md`             | `01_blocks/04_pms_os.md`, `01_blocks/07_distributed_systems.md`                        |
| Distributed architecture/profile claim  | `01_blocks/07_distributed_systems.md`          | `01_blocks/06_runtime_security.md`, `01_blocks/09_non_goals_and_claim_boundary.md`     |
| Implementation-artifact evidence claim  | `01_blocks/08_relation_to_pms_rust.md`         | `02_reference/Evidence_Map.md`, `01_blocks/09_non_goals_and_claim_boundary.md`         |
| Claim-boundary / non-goal claim         | `01_blocks/09_non_goals_and_claim_boundary.md` | `03_minified/PMS_STACK_Claim_Boundary_Minified.md`                                     |
| Reader/navigation claim                 | `05_PMS-STACK Reader/README.md`                | `02_reference/Reader_Pathways.md`                                                      |

Canonical pattern:

```text
strong claim → claim type → boundary
```

---

## 5. Reading by Evidence Topic

| Evidence topic          | Primary file                                   | Secondary files                                                                              |
| ----------------------- | ---------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Artifact evidence       | `01_blocks/08_relation_to_pms_rust.md`         | `02_reference/Evidence_Map.md`, `01_blocks/09_non_goals_and_claim_boundary.md`               |
| PMS-RUST Evidence Spine | `01_blocks/08_relation_to_pms_rust.md`         | `01_blocks/05_pmsl_pms_ir.md`, `01_blocks/06_runtime_security.md`                            |
| Tests                   | `01_blocks/09_non_goals_and_claim_boundary.md` | `02_reference/Evidence_Map.md`, `02_reference/Audit_Checklist.md`                            |
| Traces                  | `01_blocks/01_architecture.md`                 | `01_blocks/02_pms_um.md`, `01_blocks/06_runtime_security.md`, `02_reference/Evidence_Map.md` |
| JSONL traces            | `01_blocks/08_relation_to_pms_rust.md`         | `02_reference/Evidence_Map.md`                                                               |
| Validators              | `01_blocks/08_relation_to_pms_rust.md`         | `01_blocks/05_pmsl_pms_ir.md`, `02_reference/Evidence_Map.md`                                |
| Golden fixtures         | `01_blocks/08_relation_to_pms_rust.md`         | `02_reference/Evidence_Map.md`                                                               |
| Runtime gates           | `01_blocks/08_relation_to_pms_rust.md`         | `02_reference/Audit_Checklist.md`                                                            |
| Formal proofs           | `01_blocks/09_non_goals_and_claim_boundary.md` | `02_reference/Claim_Type_Table.md`                                                           |
| External validation     | `01_blocks/09_non_goals_and_claim_boundary.md` | `02_reference/Claim_Type_Table.md`                                                           |
| AI proposal boundary    | `01_blocks/05_pmsl_pms_ir.md`                  | `01_blocks/06_runtime_security.md`, `01_blocks/08_relation_to_pms_rust.md`                   |
| Boundary-exit evidence  | `01_blocks/03_pms_cpu.md`                      | `01_blocks/06_runtime_security.md`, `01_blocks/08_relation_to_pms_rust.md`                   |

Evidence rule:

```text
Evidence strengthens typed implementation-artifact claims under declared
scope. It does not validate PMS Base and does not change claim type.
```

---

## 6. Reading by Boundary Topic

| Boundary topic                 | Primary file                                   | Secondary files                                                                                                                |
| ------------------------------ | ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| PMS Base boundary              | `01_blocks/09_non_goals_and_claim_boundary.md` | `01_blocks/00_overview.md`, `01_blocks/01_architecture.md`                                                                     |
| Architecture vs implementation | `01_blocks/09_non_goals_and_claim_boundary.md` | `README.md`, `01_blocks/00_overview.md`                                                                                        |
| Proof vs test vs trace         | `01_blocks/09_non_goals_and_claim_boundary.md` | `02_reference/Evidence_Map.md`, `02_reference/Audit_Checklist.md`                                                              |
| trace / Trace                  | `01_blocks/01_architecture.md`                 | `01_blocks/02_pms_um.md`, `01_blocks/06_runtime_security.md`, `01_blocks/07_distributed_systems.md`                            |
| Χ / Distance projection        | `01_blocks/01_architecture.md`                 | `01_blocks/03_pms_cpu.md`, `01_blocks/04_pms_os.md`, `01_blocks/06_runtime_security.md`, `01_blocks/07_distributed_systems.md` |
| OS isolation-domain values     | `01_blocks/04_pms_os.md`                       | `01_blocks/06_runtime_security.md`                                                                                             |
| RF / RAcc distinction          | `01_blocks/04_pms_os.md`                       | `01_blocks/03_pms_cpu.md`, `02_reference/Audit_Checklist.md`                                                                   |
| Syscall ABI boundary           | `01_blocks/04_pms_os.md`                       | `01_blocks/03_pms_cpu.md`, `01_blocks/06_runtime_security.md`                                                                  |
| ISO_EXIT / chi_exit            | `01_blocks/03_pms_cpu.md`                      | `01_blocks/08_relation_to_pms_rust.md`, `01_blocks/06_runtime_security.md`                                                     |
| Sealed isolation               | `01_blocks/03_pms_cpu.md`                      | `01_blocks/06_runtime_security.md`, `01_blocks/08_relation_to_pms_rust.md`                                                     |
| PMS-RUST evidence boundary     | `01_blocks/08_relation_to_pms_rust.md`         | `01_blocks/09_non_goals_and_claim_boundary.md`, `02_reference/Evidence_Map.md`                                                 |
| AI Bridge boundary             | `01_blocks/05_pmsl_pms_ir.md`                  | `01_blocks/06_runtime_security.md`, `01_blocks/08_relation_to_pms_rust.md`                                                     |
| Distributed ᴳ notation         | `01_blocks/07_distributed_systems.md`          | `01_blocks/01_architecture.md`, `01_blocks/09_non_goals_and_claim_boundary.md`                                                 |
| Σᵢ vs Σᴳ                       | `01_blocks/07_distributed_systems.md`          | `02_reference/Operator_Index.md`                                                                                               |
| Governance is not tribunal     | `01_blocks/06_runtime_security.md`             | `01_blocks/09_non_goals_and_claim_boundary.md`                                                                                 |
| Reader boundary                | `05_PMS-STACK Reader/README.md`                | `02_reference/Reader_Pathways.md`, `README.md`                                                                                 |

---

## 7. File Dependency Map

```text
README.md
    → 01_blocks/00_overview.md
    → 01_blocks/01_architecture.md
    → 01_blocks/09_non_goals_and_claim_boundary.md
```

```text
01_blocks/01_architecture.md
    → 01_blocks/02_pms_um.md
    → 01_blocks/03_pms_cpu.md
    → 01_blocks/04_pms_os.md
    → 01_blocks/05_pmsl_pms_ir.md
    → 01_blocks/06_runtime_security.md
    → 01_blocks/07_distributed_systems.md
    → 01_blocks/08_relation_to_pms_rust.md
```

```text
01_blocks/09_non_goals_and_claim_boundary.md
    → governs claim discipline across all canonical blocks
```

```text
02_reference/
    → indexes README.md + 01_blocks/00–09
```

```text
03_minified/
    → compresses README.md + 01_blocks/00–09
```

```text
04_derivative_publications/
    → explains README.md + 01_blocks/00–09 externally
```

```text
05_PMS-STACK Reader/
    → navigates README.md + 01_blocks/00–09 locally
```

Boundary:

```text
Dependency mapping is navigational.
It does not create new canonical authority.
```

---

## 8. Fast Lookup Table

| User question                            | Start here                           | Then read                                                 |
| ---------------------------------------- | ------------------------------------ | --------------------------------------------------------- |
| What is PMS-STACK?                       | `README.md`                          | `00_overview.md`, `09_non_goals_and_claim_boundary.md`    |
| What is the central architecture?        | `01_architecture.md`                 | `00_overview.md`, `02_pms_um.md`                          |
| Where are operators defined?             | `01_architecture.md`                 | `02_reference/Operator_Index.md`                          |
| What is PMS-UM?                          | `02_pms_um.md`                       | `01_architecture.md`, `03_pms_cpu.md`                     |
| What is PMS-CPU?                         | `03_pms_cpu.md`                      | `02_pms_um.md`, `04_pms_os.md`                            |
| What is PMS-OS?                          | `04_pms_os.md`                       | `03_pms_cpu.md`, `06_runtime_security.md`                 |
| What is PMSL/PMS-IR?                     | `05_pmsl_pms_ir.md`                  | `08_relation_to_pms_rust.md`                              |
| Where is security specified?             | `06_runtime_security.md`             | `04_pms_os.md`, `07_distributed_systems.md`               |
| Where are distributed systems specified? | `07_distributed_systems.md`          | `06_runtime_security.md`                                  |
| What does PMS-RUST evidence?             | `08_relation_to_pms_rust.md`         | `02_reference/Evidence_Map.md`                            |
| What is not claimed?                     | `09_non_goals_and_claim_boundary.md` | `PMS_STACK_Claim_Boundary_Minified.md`                    |
| What is Χ?                               | `01_architecture.md`                 | `03_pms_cpu.md`, `04_pms_os.md`, `06_runtime_security.md` |
| What is chi_exit?                        | `08_relation_to_pms_rust.md`         | `03_pms_cpu.md`, `06_runtime_security.md`                 |
| What is the AI Bridge?                   | `05_pmsl_pms_ir.md`                  | `06_runtime_security.md`, `08_relation_to_pms_rust.md`    |
| What should reviewers check?             | `02_reference/Audit_Checklist.md`    | `09_non_goals_and_claim_boundary.md`                      |

---

## 9. Reference-Layer Links

Recommended reference-layer use:

```text
Glossary.md
    defines terms

Cross_Reference_Map.md
    maps topics to files

Evidence_Map.md
    maps claims to artifact evidence

Audit_Checklist.md
    checks release discipline

Claim_Type_Table.md
    stabilizes claim vocabulary

Operator_Index.md
    indexes Δ–Ψ across layers

Reader_Pathways.md
    gives audience-specific reading paths
```

Reference-layer boundary:

```text
Reference files index.
Canonical blocks specify.
```

---

## 10. Final Navigation Formula

```text
PMS-STACK is specified in canonical blocks,
indexed in reference files,
compressed in minified contracts,
explained in derivative publications,
and navigated through the Reader.
```

Expanded:

```text
README.md + 01_blocks/00–09 define the canonical PMS-STACK specification.

00_source preserves origin material.
02_reference indexes the canonical specification.
03_minified compresses the canonical specification.
04_derivative_publications explains the canonical specification.
05_PMS-STACK Reader navigates the canonical specification.

None of the derivative, reference, source, minified, publication, reader,
tooling, artifact, or evidence layers replace the canonical blocks or
validate PMS Base.
```
