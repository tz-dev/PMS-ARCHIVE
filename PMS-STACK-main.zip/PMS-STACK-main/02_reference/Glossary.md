---
document_id: PMS-STACK-REF-GLOSSARY
title: "PMS-STACK Glossary"
status: "release-candidate"
version: "v0.1"
claim_type: "reference index / terminology navigation / claim-boundary support"
canonical_status: "derivative; indexes README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file indexes PMS-STACK terminology. It does not replace the canonical blocks, redefine PMS Base, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Glossary

## 1. Status

This file indexes central PMS-STACK terms.

It belongs to:

```text
02_reference/
```

Its role is:

```text
reference
index
navigation aid
claim-boundary support
non-canonical
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Boundary:

```text
This glossary indexes PMS-STACK terminology.
It does not redefine PMS Base.
It does not replace the canonical blocks.
It does not introduce new operators.
It does not validate PMS Base.
It does not establish implementation completion.
```

---

## 2. Core Corpus Terms

### PMS Base

The PMS theory layer defining the Δ–Ψ operator grammar.

PMS Base supplies operator identity, operator order, dependency discipline, application guardrails, and non-goals.

Boundary:

```text
PMS Base is not validated by PMS-STACK.
```

### PMS-STACK

The implementation-layer architecture specification of PMS.

Canonical claim:

```text
PMS-STACK is an operator-grounded systems architecture deriving abstract
machine, virtual CPU, OS, runtime, language, security, networking,
distributed systems, tooling, simulation, verification, boot, and cluster
profiles from Δ–Ψ.
```

Claim type:

```text
implementation-layer architecture specification claim
```

Boundary:

```text
PMS-STACK does not validate PMS Base.
PMS-STACK does not claim fabricated hardware.
PMS-STACK does not claim a completed production OS.
```

### PMS-RUST

A bounded executable PMS-STACK Evidence Spine v0.1.

It may evidence bounded implementation slices through deterministic kernel execution, model validation, stateful validation, REPL/script tooling, JSONL traces, golden fixtures, vFS surfaces, and AI proposal boundaries.

Boundary:

```text
PMS-RUST does not validate PMS Base.
PMS-RUST does not complete PMS-STACK.
```

---

## 3. Operator Terms

### Δ — Difference

Minimal distinction, classification, identity split, comparison, or discriminating act.

PMS-STACK projections include:

```text
opcode selection
type distinction
syscall classification
message kind
node identity
route distinction
```

### ∇ — Impulse

Enactment, directed action, mutation, execution, or transition.

PMS-STACK projections include:

```text
instruction execution
write
send
syscall body
state mutation
runtime action
```

### □ — Frame

Context, scope, structured boundary condition, or execution container.

PMS-STACK projections include:

```text
machine state region
CPU frame
process frame
address space
namespace
module
session
cluster frame
```

### Λ — Non-Event

Typed absence under expectation.

PMS-STACK projections include:

```text
timeout
empty queue
missing event
no quorum
absent response
idle state
unavailable resource
```

### Α — Attractor

Pattern, recurrence, stabilized structure, macro, lifecycle, or protocol template.

PMS-STACK projections include:

```text
macro instruction
loop pattern
driver lifecycle
protocol flow
replication pattern
failover pattern
```

### Ω — Asymmetry

Role, authority, capability, privilege, directed relation, or burden structure.

PMS-STACK projections include:

```text
role register
capability
kernel privilege
principal authority
driver role
leader/follower relation
```

### Θ — Temporality

Ordering, sequencing, scheduling, logical progression, or temporal relation.

PMS-STACK projections include:

```text
instruction order
scheduler order
logical clock
event sequence
retry order
audit order
```

### Φ — Recontextualization

Context shift, trap, interrupt, exception, migration, fallback, recovery, or reinterpretation.

PMS-STACK projections include:

```text
syscall entry
trap
interrupt
page fault
exception handler
route change
failover
```

### Χ — Distance

PMS Base operator for Distance.

PMS-STACK projection:

```text
isolation
reachability control
boundary management
access separation
sandboxing
containment
quarantine
namespace visibility
device visibility
IPC visibility
trust-domain separation
cross-node boundary
```

Boundary:

```text
PMS Base Χ = Distance.
Implementation-layer isolation is a projection of Χ, not a redefinition.
```

### Σ — Integration

Commit, merge, stabilization, durable update, delivery, transaction closure, or integrated state.

PMS-STACK projections include:

```text
instruction retirement
syscall commit
filesystem transaction
audit record
delivery commit
distributed commit
```

### Ψ — Self-Binding

Policy, invariant, governance constraint, validity restriction, or future-binding rule.

PMS-STACK projections include:

```text
kernel policy
runtime invariant
type/effect guard
security rule
trust policy
cluster policy
```

---

## 4. Architecture Terms

### Canonical Blocks

The canonical PMS-STACK specification files:

```text
01_blocks/00_overview.md
01_blocks/01_architecture.md
01_blocks/02_pms_um.md
01_blocks/03_pms_cpu.md
01_blocks/04_pms_os.md
01_blocks/05_pmsl_pms_ir.md
01_blocks/06_runtime_security.md
01_blocks/07_distributed_systems.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

### PMS-UM

The PMS Universal Machine.

Claim type:

```text
abstract-machine / computational expressiveness claim
```

Canonical tuple:

```text
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

Boundary:

```text
PMS-UM does not validate PMS Base.
PMS-UM does not complete PMS-CPU, PMS-OS, PMSL, or PMS-RUST.
```

### PMS-CPU

The virtual CPU / ISA architecture layer.

Claim type:

```text
virtual CPU / ISA architecture claim
```

Canonical tuple:

```text
M_CPU =
    (S_CPU, Γ_CPU, F_CPU, R_CPU, PSet_CPU, O,
     ISA, Π_CPU, δ_CPU, s₀_CPU, S_H_CPU)
```

Boundary:

```text
PMS-CPU is not fabricated hardware.
```

### PMS-OS

The operating-system architecture layer.

Claim type:

```text
implementation-layer OS architecture claim
```

Boundary:

```text
PMS-OS is not a completed production OS.
PMS-OS does not validate PMS Base.
```

### PMSL

The PMS-STACK language specification for operator-typed programming.

Boundary:

```text
PMSL is not a completed compiler.
```

### PMS-IR

The operator-preserving intermediate representation for PMSL and PMS-STACK artifacts.

Boundary:

```text
PMS-IR is not compiler authority.
PMS-IR metadata does not override operator semantics.
```

### Runtime Security

The cross-layer PMS-STACK security architecture.

Core rule:

```text
Security-relevant transitions must remain Δ-distinguished, Ω-authorized,
□-framed, Χ-bounded, Θ-ordered where relevant, Φ-recontextualized where
needed, Σ-committed where stable, and Ψ-constrained.
```

Boundary:

```text
Runtime security is not universal security certification.
Governance is not tribunal.
```

### Distributed PMS-STACK

The distributed-systems profile layer of PMS-STACK.

Distributed notation such as:

```text
Δᴳ, □ᴳ, Χᴳ, Σᴳ, Ψᴳ
```

marks distributed scope.

Boundary:

```text
ᴳ does not introduce new PMS Base operators.
Distributed PMS-STACK does not prove any specific consensus algorithm.
```

---

## 5. Evidence and Validation Terms

### Artifact Evidence

Evidence supplied by an implementation artifact under declared scope.

Correct use:

```text
artifacts evidence bounded implementation claims
```

Incorrect use:

```text
artifacts validate PMS Base
```

### Test

A behavioral check under declared fixture, profile, gate, or scenario.

Correct verb:

```text
tests check
```

Incorrect verb:

```text
tests prove PMS
```

### Trace

One concrete observed or constructed execution.

Notation:

```text
trace(...) ∈ L_PMS
```

### Trace Set

A declared set of possible executions under a profile.

Notation:

```text
Trace(...) ⊆ L_PMS
```

Boundary:

```text
A trace does not prove the full Trace(...) set.
```

### Validator

A profile-level accept/reject mechanism.

Correct verb:

```text
validators accept or reject under declared profiles
```

Boundary:

```text
validators do not validate PMS Base.
```

### Formal Proof

A property-specific proof under stated assumptions, model, and method.

Boundary:

```text
A formal proof proves stated properties.
It does not automatically validate PMS Base.
```

### External Validation

Validation under an external protocol.

Boundary:

```text
External validation requires an explicit external validation design.
```

---

## 6. PMS-RUST Terms

### Evidence Spine

The bounded PMS-RUST v0.1 executable artifact relation to PMS-STACK.

Roadmap pattern:

```text
STACK claim
→ executable slice
→ validation rule
→ golden test
→ trace evidence
→ limitation
```

### chi_exit

A PMS-RUST runtime / DSL / validator operation for leaving an active isolation or boundary context.

Boundary:

```text
chi_exit is not PMS-CPU ISO_EXIT.
chi_exit does not redefine PMS Base Χ.
chi_exit does not validate PMS Base.
```

### ISO_EXIT

The PMS-CPU architecture-level virtual ISA instruction for leaving a declared isolation or boundary context.

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

### Sealed Isolation

A bound isolation state that forbids further entry, expansion, or reachability growth.

Boundary:

```text
sealed isolation still permits valid exit, closure, rollback, audit, or
commit under declared profile and active boundary context.
```

---

## 7. AI Bridge Terms

### AI Bridge

Optional PMS-RUST tooling/profile support for proposing PMS-IR or opcode programs and analyzing traces.

Authority chain:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

Boundary:

```text
AI output is not trusted executable code.
AI output is not compiler authority.
AI output is not verifier authority.
AI output is not PMS Base evidence.
```

### AI-Assisted Trace Analysis

Advisory trace-observability support.

May:

```text
summarize operator sequence
identify commit points
flag non-event occurrences
describe policy denials
surface trace anomalies
offer candidate explanations
```

May not replace:

```text
static analysis
model checking
runtime validation
policy evaluation
human review
```

---

## 8. Repository Support Terms

### 00_source

Preserves source and provenance material.

Boundary:

```text
00_source does not override the canonical release blocks.
```

### 02_reference

Indexes PMS-STACK.

Boundary:

```text
Reference files do not redefine PMS-STACK.
```

### 03_minified

Compresses PMS-STACK.

Boundary:

```text
Minified files do not replace README.md + 01_blocks/00–09.
```

### 04_derivative_publications

Explains PMS-STACK externally.

Boundary:

```text
Derivative publications are not canonical specification.
```

### 05_PMS-STACK Reader

Local navigation and inspection tool.

Boundary:

```text
The Reader navigates PMS-STACK.
It does not validate PMS-STACK.
It does not modify the specification.
It does not establish implementation completion.
```

---

## 9. Safe Verb Table

| Subject       | Correct verbs                                   | Avoid                          |
| ------------- | ----------------------------------------------- | ------------------------------ |
| PMS Base      | defines, constrains, supplies operator identity | is validated by PMS-STACK      |
| PMS-STACK     | specifies, derives, projects, structures        | proves PMS Base                |
| PMS-UM        | specifies, models, encodes                      | proves all system properties   |
| PMS-CPU       | specifies, virtualizes, refines                 | fabricates                     |
| PMS-OS        | specifies, mediates, structures                 | deploys as production OS       |
| PMSL / PMS-IR | specifies, lowers, represents, constrains       | compiles authoritatively       |
| PMS-RUST      | evidences, implements bounded slices, records   | validates PMS Base             |
| Tests         | check                                           | prove                          |
| Traces        | record                                          | prove all behavior             |
| Validators    | accept, reject                                  | externally validate PMS Base   |
| Fixtures      | stabilize                                       | exhaust correctness            |
| Proofs        | prove stated properties                         | prove everything               |
| AI            | proposes, comments, assists                     | authorizes, verifies, executes |
| Reader        | navigates, searches, inspects                   | validates, proves, modifies    |

---

## 10. Final Boundary Formula

```text
PMS Base defines.
PMS-STACK specifies.
PMS-RUST evidences.
Tests check.
Traces record.
Validators accept or reject under declared profiles.
Fixtures stabilize bounded cases.
Gates discipline releases.
Proofs prove stated properties under assumptions.
External validation validates under external protocols.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
Reference files index.
Minified files compress.
Derivative publications explain.
The Reader navigates.

None of these lower, derivative, artifact, tooling, or support layers validate PMS Base.
```
