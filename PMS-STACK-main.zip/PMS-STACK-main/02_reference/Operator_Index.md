---
document_id: PMS-STACK-REF-OPERATOR-INDEX
title: "PMS-STACK Operator Index"
status: "release-candidate"
version: "v0.1"
claim_type: "reference index / operator navigation / layer-projection map"
canonical_status: "derivative; indexes README.md + 01_blocks/00–09 without replacing them"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file indexes Δ–Ψ operator projections across PMS-STACK. It does not replace the canonical blocks, redefine PMS Base, introduce new operators, validate PMS Base, establish implementation completion, or create new evidence."
---

# PMS-STACK Operator Index

## 1. Canonical Status

This file indexes the Δ–Ψ operator set across PMS-STACK layers.

It belongs to:

```text
02_reference/
```

Its role is:

```text
reference
operator index
layer-projection map
navigation aid
claim-boundary support
non-canonical
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Boundary:

```text
This file indexes operator projections.
It does not define PMS Base.
It does not redefine operators.
It does not replace canonical blocks.
It does not validate PMS Base.
It does not establish implementation completion.
```

---

## 2. Operator Alphabet

PMS-STACK is grounded in the Δ–Ψ operator grammar.

Operator order:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

Operator alphabet:

```text
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

PMS-valid operator language:

```text
L_PMS ⊆ O*
```

Policy-constrained language:

```text
L_PMS,Ψ ⊆ L_PMS
```

Boundary:

```text
PMS Base defines operator identity.
PMS-STACK projects operator identity into implementation-layer architecture.
Projection is not redefinition.
```

---

## 3. Operator Projection Matrix

| Operator | Base reading           | PMS-STACK projection                                                      | Typical layers                         |
| -------- | ---------------------- | ------------------------------------------------------------------------- | -------------------------------------- |
| Δ        | Difference             | distinction, classification, decode, type/message discrimination          | UM, CPU, OS, PMSL, runtime, network    |
| ∇        | Impulse / enactment    | action, mutation, execution, syscall, write, send                         | all layers                             |
| □        | Frame                  | context, scope, address space, process, module, session, cluster          | all layers                             |
| Λ        | Non-Event / absence    | timeout, idle, no-event, no-result, no quorum, unavailable resource       | UM, OS, runtime, distributed           |
| Α        | Attractor / pattern    | macro, grammar pattern, lifecycle, protocol flow, recurrence              | UM, CPU, PMSL, network, distributed    |
| Ω        | Asymmetry / role       | role, privilege, authority, capability, delegation                        | CPU, OS, runtime security, distributed |
| Θ        | Temporality / ordering | step, schedule, sequence, fence, logical clock, rollout order             | UM, CPU, OS, runtime, distributed      |
| Φ        | Recontextualization    | trap, interrupt, exception, fault, migration, fallback, recovery          | CPU, OS, PMSL, security, distributed   |
| Χ        | Distance               | projected as isolation, boundary, reachability control, access separation | CPU, OS, PMSL, security, distributed   |
| Σ        | Integration            | commit, writeback, merge, transaction close, delivery, audit record       | CPU, OS, runtime, distributed          |
| Ψ        | Self-Binding / policy  | invariant, guard, policy, governance constraint, future-validity binding  | all layers                             |

---

## 4. Operators by Layer

### 4.1 PMS-UM

| Operator | PMS-UM projection                                                            |
| -------- | ---------------------------------------------------------------------------- |
| Δ        | symbol distinction, state distinction, instruction classification            |
| ∇        | abstract state transition, machine action                                    |
| □        | abstract machine frame, execution context                                    |
| Λ        | halted absence, no enabled step, expected missing event                      |
| Α        | instruction pattern, rule block, repeated transition schema                  |
| Ω        | role relation, authority condition, asymmetric state relation                |
| Θ        | step order, run progression, transition sequence                             |
| Φ        | recontextualization, failure transition, context shift                       |
| Χ        | abstract boundary, reachability, visibility, protected subcontext projection |
| Σ        | commit of prior structure, integration of machine effects                    |
| Ψ        | policy, invariant, constrained execution language                            |

Boundary:

```text
PMS-UM projects Δ–Ψ into abstract-machine execution.
It does not validate PMS Base.
```

### 4.2 PMS-CPU

| Operator | PMS-CPU projection                                                              |
| -------- | ------------------------------------------------------------------------------- |
| Δ        | fetch, decode, comparison, branch distinction, opcode classification            |
| ∇        | ALU operation, load, store, register mutation, device action                    |
| □        | CPU frame, execution context, segment, stack frame, frame register              |
| Λ        | wait, idle, absent interrupt, timeout                                           |
| Α        | macro-instruction, instruction pattern, pipeline pattern                        |
| Ω        | privilege, role register, capability register, authority check                  |
| Θ        | instruction order, fence, tick, memory order                                    |
| Φ        | trap, interrupt, exception, fault, syscall control transfer                     |
| Χ        | protected domain, isolation-domain state, memory boundary, ISO_ENTER / ISO_EXIT |
| Σ        | commit, writeback, instruction retirement, trap return integration              |
| Ψ        | guard, invariant, policy check, execution restriction                           |

Special note:

```text
PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
It is not PMS-RUST chi_exit itself.
```

Boundary:

```text
PMS-CPU is virtual CPU / ISA architecture.
It is not fabricated hardware.
```

### 4.3 PMS-OS

| Operator | PMS-OS projection                                                               |
| -------- | ------------------------------------------------------------------------------- |
| Δ        | syscall number, object identity, process ID, event kind                         |
| ∇        | syscall body, process mutation, filesystem write, resource update               |
| □        | process frame, address space, namespace, file handle, kernel context            |
| Λ        | blocked thread, empty queue, timeout, missing event, unavailable resource       |
| Α        | process lifecycle, syscall template, driver lifecycle, scheduling pattern       |
| Ω        | credential, role, capability, privilege, driver authority                       |
| Θ        | scheduling order, timer, dispatch sequence, wakeup order                        |
| Φ        | syscall entry, trap handler, page fault, signal, hotplug event                  |
| Χ        | process isolation, namespace boundary, IPC visibility, sandbox, device boundary |
| Σ        | syscall return, state synchronization, transaction commit, cleanup              |
| Ψ        | kernel invariant, policy engine, quota rule, access policy                      |

Special note:

```text
PMS-OS syscall word:
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

Boundary:

```text
PMS-OS is OS architecture.
It is not a completed production OS.
```

### 4.4 PMSL / PMS-IR

| Operator | PMSL / PMS-IR projection                                              |
| -------- | --------------------------------------------------------------------- |
| Δ        | type distinction, symbol resolution, pattern match, branch            |
| ∇        | statement execution, assignment, effect, runtime call                 |
| □        | lexical scope, function frame, module, task frame                     |
| Λ        | timeout branch, none/null result, missing event, unavailable resource |
| Α        | macro, loop, reusable construct, grammar pattern                      |
| Ω        | role annotation, capability annotation, effect permission             |
| Θ        | sequencing, await, event-loop order, evaluation order                 |
| Φ        | exception, handler frame, FFI boundary, recovery path                 |
| Χ        | module boundary, sandbox, host boundary, runtime boundary             |
| Σ        | return, commit block, transaction construct, result integration       |
| Ψ        | invariant, policy block, type/effect guard                            |

Boundary:

```text
PMSL/PMS-IR specify language/runtime architecture.
They do not claim a complete compiler.
```

### 4.5 Runtime Security

| Operator | Runtime-security projection                                       |
| -------- | ----------------------------------------------------------------- |
| Δ        | actor/action/object/context distinction                           |
| ∇        | protected action, mutation, transfer                              |
| □        | security context, policy scope, trust frame                       |
| Λ        | missing credential, absent permission, timeout                    |
| Α        | recurring security pattern, audit template, attack pattern        |
| Ω        | role, capability, delegation, privilege                           |
| Θ        | audit order, expiry order, policy lifecycle order                 |
| Φ        | denial frame, quarantine trigger, escalation, recovery            |
| Χ        | trust boundary, containment, sandbox, isolation-domain projection |
| Σ        | committed audit record, trust binding, revocation, policy update  |
| Ψ        | access policy, invariant, runtime governance rule                 |

Boundary:

```text
Runtime security is operator-structured architecture.
It is not universal security certification.
Governance is not tribunal.
```

### 4.6 Networking

| Operator | Networking projection                                          |
| -------- | -------------------------------------------------------------- |
| Δ        | packet type, message kind, route distinction, address identity |
| ∇        | send, receive, forward, route update                           |
| □        | connection frame, session frame, protocol frame, route frame   |
| Λ        | dropped packet, timeout, no response, no route                 |
| Α        | protocol flow, handshake, retry pattern                        |
| Ω        | peer authority, client/server role, route authority            |
| Θ        | sequence number, retransmission order, heartbeat               |
| Φ        | fallback, route change, version negotiation, recovery          |
| Χ        | segmentation, reachability boundary, trust-domain boundary     |
| Σ        | delivery commit, route commit, session integration             |
| Ψ        | routing policy, trust rule, network invariant                  |

Boundary:

```text
Network reachability is not authority.
Transport commit is not global commit.
```

### 4.7 Distributed Systems

| Operator | Distributed projection                                               |
| -------- | -------------------------------------------------------------------- |
| Δᴳ       | node, shard, service, partition, quorum, membership distinction      |
| ∇ᴳ       | remote action, replication step, distributed mutation                |
| □ᴳ       | cluster frame, service frame, shard frame, federation frame          |
| Λᴳ       | missing heartbeat, no quorum, partition symptom, absent replica      |
| Αᴳ       | replication pattern, failover pattern, cluster lifecycle             |
| Ωᴳ       | coordinator/worker, leader/follower, participant authority           |
| Θᴳ       | logical clock, event order, rollout sequence                         |
| Φᴳ       | failover, migration, leadership change, partition recovery           |
| Χᴳ       | cross-node Distance projection, tenant boundary, federation boundary |
| Σᴳ       | distributed commit, reintegration, global integration                |
| Ψᴳ       | global invariant, quorum policy, trust rule                          |

Boundary:

```text
ᴳ marks distributed scope.
It does not introduce new PMS Base operators.
Σᴳ is not a specific consensus algorithm.
```

---

## 5. Operators by Evidence Topic

| Evidence topic          | Relevant operators | Notes                                                              |
| ----------------------- | ------------------ | ------------------------------------------------------------------ |
| Test check              | Δ, Ψ, Σ            | distinguish case, apply rule, record outcome                       |
| Trace record            | Θ, Σ, Δ            | ordered execution record with committed evidence                   |
| Validator rejection     | Δ, Ψ, Φ            | classify invalidity, enforce policy, recontextualize failure       |
| Fixture                 | Α, Θ, Σ            | stabilized known pattern across release checks                     |
| JSONL audit             | Θ, Σ, Ψ            | ordered committed record under policy/profile                      |
| Boundary-exit evidence  | Χ, Φ, Σ, Ψ         | active boundary context, exit, closure/audit, policy               |
| AI proposal gate        | Δ, Ω, Ψ, Χ, Σ      | classify proposal, gate authority, enforce boundary, accept/commit |
| PMS-RUST Evidence Spine | Δ–Ψ                | bounded executable slice of operator-typed runtime behavior        |
| Distributed trace       | Δᴳ–Ψᴳ              | distributed-scope operator record under profile                    |

Boundary:

```text
Evidence records or checks bounded artifact behavior.
Evidence does not validate PMS Base.
```

---

## 6. Χ / Distance Special Note

PMS Base 1.3 defines:

```text
Χ = Distance
```

PMS-STACK projects Χ at implementation layers as:

```text
isolation
reachability control
boundary management
access separation
sandboxing
containment
quarantine
namespace visibility
device visibility
IPC visibility
trust-domain separation
cross-node boundary management
```

Correct wording:

```text
PMS Base Χ is Distance.
At implementation layers, Χ projects as isolation and boundary management.
```

Incorrect wording:

```text
PMS Base Χ means isolation.
PMS-STACK redefines Χ.
PMS-RUST chi_exit defines Χ.
OS isolation-domain values are PMS Base Χ itself.
```

Layer-specific notes:

```text
R_iso
    CPU-level isolation-domain state, not PMS Base Χ itself.

X_user / X_global / X_p / IDom_user / IDom_global
    OS-level isolation-domain values, not PMS Base Χ itself.

Bχ / BoundaryType / Effect<Χ>
    PMSL/PMS-IR boundary-projection terms, not PMS Base Χ itself.

Χᴳ
    distributed-scope Distance projection, not a new operator.

chi_exit
    PMS-RUST runtime/artifact boundary-exit behavior, not PMS Base Χ.

ISO_EXIT
    PMS-CPU architecture-level boundary-exit instruction, not PMS Base Χ.
```

---

## 7. Operator Failure Index

| Operator | Failure mode examples                                              | Typical files                                                                  |
| -------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| Δ        | missing distinction, invalid classification, ambiguous target      | `01_architecture.md`, `02_pms_um.md`, `05_pmsl_pms_ir.md`                      |
| ∇        | unauthorized action, invalid mutation, effect without precondition | `02_pms_um.md`, `03_pms_cpu.md`, `04_pms_os.md`                                |
| □        | missing frame, invalid scope, wrong context                        | `01_architecture.md`, `04_pms_os.md`, `05_pmsl_pms_ir.md`                      |
| Λ        | absence without expectation, timeout without expected event        | `02_pms_um.md`, `06_runtime_security.md`, `07_distributed_systems.md`          |
| Α        | invalid pattern expansion, macro expands to invalid word           | `01_architecture.md`, `05_pmsl_pms_ir.md`                                      |
| Ω        | missing role, insufficient capability, invalid delegation          | `03_pms_cpu.md`, `04_pms_os.md`, `06_runtime_security.md`                      |
| Θ        | invalid order, unsatisfied sequencing, replay/order violation      | `03_pms_cpu.md`, `04_pms_os.md`, `07_distributed_systems.md`                   |
| Φ        | invalid trap, missing cause/context, unsafe recovery path          | `03_pms_cpu.md`, `04_pms_os.md`, `06_runtime_security.md`                      |
| Χ        | unbalanced exit, boundary violation, reachability breach           | `03_pms_cpu.md`, `06_runtime_security.md`, `08_relation_to_pms_rust.md`        |
| Σ        | commit without committable prior activity, incomplete integration  | `02_pms_um.md`, `04_pms_os.md`, `07_distributed_systems.md`                    |
| Ψ        | policy denial, invariant violation, invalid future binding         | `04_pms_os.md`, `06_runtime_security.md`, `09_non_goals_and_claim_boundary.md` |

---

## 8. Operator Lookup by File

| File                                 | Operator focus                                                        |
| ------------------------------------ | --------------------------------------------------------------------- |
| `00_overview.md`                     | orientation to Δ–Ψ and layer projections                              |
| `01_architecture.md`                 | full operator grammar, monoid, dependencies, invariants               |
| `02_pms_um.md`                       | abstract-machine execution of Δ–Ψ                                     |
| `03_pms_cpu.md`                      | ISA-level operator families                                           |
| `04_pms_os.md`                       | kernel, syscall, process, memory, filesystem, IPC, driver projections |
| `05_pmsl_pms_ir.md`                  | source/IR/runtime operator obligations                                |
| `06_runtime_security.md`             | identity, capability, boundary, policy, audit, trust projections      |
| `07_distributed_systems.md`          | distributed-scope operator lifting                                    |
| `08_relation_to_pms_rust.md`         | PMS-RUST artifact mapping and bounded evidence                        |
| `09_non_goals_and_claim_boundary.md` | claim boundaries for operator use                                     |

---

## 9. Final Operator Formula

```text
PMS Base defines Δ–Ψ.

PMS-STACK projects Δ–Ψ into implementation-layer systems architecture.

Each layer specializes operators into its own state space, execution
obligations, failure modes, traces, and policies.

Specialization is not redefinition.

Evidence may show bounded artifact behavior under declared profiles.

Evidence does not validate PMS Base.
```
