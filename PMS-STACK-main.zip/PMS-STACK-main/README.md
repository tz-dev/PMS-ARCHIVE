# PMS-STACK

## Purpose

**PMS-STACK** is a corpus-form architecture-specification repository for describing PMS as a stack: operating system, kernel, CPU/ISA, language, runtime, security, networking, distributed systems, and executable implementation boundary.

Its function is to make PMS architecture legible without treating architecture, implementation, tests, traces, or readers as proof of PMS Base.

Compact boundary:

```text
architecture specification ≠ implementation completion
implementation evidence ≠ PMS Base validation
traceability ≠ truth
tests ≠ proof
reader navigation ≠ authority
```

---

## Ecosystem Position

PMS-STACK belongs to the PMS corpus-form repository family and sits closest to PMS-RUST.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies the conceptual operator grammar. |
| PMS-RUST | Implements bounded executable artifacts related to PMS-STACK; it does not complete or prove the specification. |
| PMS-STRATA | Can inspect level shifts between OS, kernel, CPU, language, runtime, trace, and implementation views. |
| PMS-ORCHESTRATOR | Uses workflow tooling logic but is not derived from PMS-STACK. |
| PMS — UNDER LOAD | Critiques stack drift, implementation overclaim, evidence-language drift, and technical publicness. |

PMS-STACK is the architecture specification. PMS-RUST is bounded executable evidence. Neither is a substitute for PMS Base or for external validation.

---

## Repository Form

This is a **corpus-form architecture-specification repository**.

| Material | Function |
| --- | --- |
| `00_source/` | Canonical source specification and long-form architecture material. |
| `01_blocks/` | Modular architecture blocks. |
| `02_reference/` | Reference maps, boundary notes, trace language, and implementation relations. |
| `03_minified/` | Compact specification controls and release-safe summaries. |
| `04_derivative_publications/` | Derivative or publication-facing materials where present. |
| `05_PMS-STACK Reader/` | Optional local navigation and inspection tool. |

No file or directory position by itself grants epistemic priority. The repository form increases inspection pressure.

---

## Reader / Navigation Tooling

![PMS-STACK Reader screenshot](05_PMS-STACK%20Reader/screenshot.png)

The optional PMS-STACK Reader is a local navigation and inspection aid.

It may support:

```text
canonical file navigation
heading navigation
corpus-wide search
operator search
Χ projection search
trace / Trace notation search
PMS-RUST reference search
AI boundary search
chi_exit / ISO_EXIT search
file statistics
audit-oriented inspection
```

Reader boundary:

```text
reader navigation ≠ architecture validation
reader search ≠ implementation completeness
reader visibility ≠ evidence strength
```

See `05_PMS-STACK Reader/` for reader details where present.

---

## Core Derivation Path

PMS-STACK treats PMS through multiple technical analogies without collapsing them into identity.

Core derivation path:

```text
PMS Base
→ OS / kernel / CPU / ISA / language / runtime perspectives
→ security / networking / distributed-system pressures
→ trace language and implementation boundary
→ PMS-RUST as bounded executable evidence spine
```

These perspectives are architectural mappings. They are not claims that PMS is literally an operating system, hardware processor, programming language, or distributed system.

---

## Reading Paths

Use different paths depending on the task.

| Task | Path |
| --- | --- |
| First pass | README → source overview → minified controls. |
| Full architecture | `00_source/` → `01_blocks/` → `02_reference/`. |
| OS / kernel orientation | OS and kernel blocks, then trace/evidence boundary. |
| CPU / ISA orientation | CPU/ISA blocks, then PMSL/PMS-IR relation. |
| PMSL / PMS-IR / runtime | language/runtime blocks, then implementation boundary. |
| PMS-RUST evidence orientation | Relation to PMS-RUST section, reference files, traces, and acceptance gates. |
| Claim-boundary review | Evidence and Claim Boundary, invalid vocabulary, and UNDER LOAD relation. |

The README should route the reader. It should not replace the architecture corpus.

---

## Relation to PMS-RUST

PMS-RUST may supply bounded executable evidence for selected PMS-STACK claims through:

```text
operator representations
model validation
stateful validation
deterministic kernel execution
REPL / script tooling
JSONL traces
golden fixtures
vFS surfaces
AI proposal boundaries
acceptance gates
```

But:

```text
PMS-RUST evidence ≠ PMS-STACK completion
PMS-RUST tests ≠ PMS Base proof
accepted trace ≠ external adequacy
green gate ≠ theory validation
```

### `chi_exit` / `ISO_EXIT`

The distinction between `chi_exit` and `ISO_EXIT` should remain explicit where the architecture discusses isolation, exit, and controlled transition.

The distinction is architectural and operational. It is not a metaphysical claim about final separation, closure, or proof.

---

## Evidence and Claim Boundary

PMS-STACK may use implementation-adjacent evidence language.

Valid claim objects:

```text
tests check
traces record
validators accept or reject under profile
fixtures stabilize known cases
gates discipline release
```

Invalid vocabulary:

```text
tests prove PMS
traces validate PMS Base
validators establish external adequacy
implementation completes the theory
architecture demonstrates truth
```

Evidence language is allowed only when it stays artifact-bounded and claim-typed.

---

## Trace Notation

Trace language should remain explicitly bounded.

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Policy variants may include Ψ where relevant, but trace membership is not the same as truth, adequacy, or completeness.

Valid illustrative trace shape:

```text
input structure
→ operator-bound state transition
→ recorded trace event
→ bounded acceptance or rejection under profile
```

Invalid illustrative trace shape:

```text
recorded trace
→ PMS proven
```

Traceability is inspection pressure, not validation authority.

---

## Buildability Statement

PMS-STACK may be read as buildable architecture only under reduction.

It can describe how PMS-like operator logic could be rendered into languages, kernels, traces, validators, gates, and implementation surfaces.

It cannot claim that such rendering proves PMS, exhausts PMS, or replaces conceptual analysis.

---

## Status

PMS-STACK exists as a corpus-form architecture specification with source material, modular blocks, reference/minified layers, and reader navigation.

Its current status is:

```text
architecture-specification corpus
implementation-adjacent
PMS-RUST-related
trace-aware
evidence-bounded
non-validating
```

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS-STACK DOI | To be added or verified during the Zenodo release/check pass. |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing PMS-STACK, cite the repository release and DOI corresponding to the version used. Do not cite PMS-STACK architecture as if it proves PMS Base or PMS-RUST implementation completeness.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
