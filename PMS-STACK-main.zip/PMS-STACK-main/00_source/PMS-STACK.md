---
document_id: PMS-STACK-SOURCE-MONOLITH
title: "PMS-STACK Monolithic Source Specification"
status: "historical-source"
version: "v1.0"
claim_type: "source specification / monolithic precursor / architecture-origin document"
canonical_status: "non-canonical source document preserved for lineage, auditability, and split-specification traceability"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
derived_into:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
related_documents:
  - "../README.md"
  - "PMS-STACK_Split_Specification_v0.1.md"
boundary: "This file preserves the original monolithic PMS-STACK source specification and architecture lineage. It is retained for auditability, historical continuity, and split-document traceability. It does not replace the canonical block corpus, redefine PMS Base, validate PMS Base, establish implementation completion, or supersede README.md + 01_blocks/00–09 as the canonical PMS-STACK specification."
---

# PMS-STACK

## A Praxeological Operating System Architecture

### Unified Formal Model from Δ–Ψ Operators to OS, CPU, Language & Distributed Systems

Author: T. Zöller
Version: 1.0
Date: 2025-12-09

---

## 1. Introduction & Model Lineage

**PMS-STACK** (“Praxeological Meta-Structure — STACK”) is a complete, unified architecture for computation, operating systems, CPU design, runtime semantics, programming language structure, security, networking, and distributed systems.
Unlike classical OS models, PMS-STACK is not an accumulation of historical abstractions but the direct formalization of a *minimal generative algebra* of distinctions and transformations.

PMS-STACK emerges from the observation that every computational act is structurally isomorphic to the Δ–Ψ operator sequence:
distinguish → act → frame → absence → pattern → asymmetry → temporality → reframe → isolation → integrate → bind policy.

This algebra is abstract enough to describe cognition, organizations, networks, and physical systems — yet concrete enough to express CPU instruction sets and syscalls.

PMS-STACK is the result of a gradual refinement path:

* Maturity in Practice (book) — conceptual foundations on action, asymmetry, framing
* MIPractice YAML model — first formalized operator model (≈1100 lines)
* Praxeological Meta-Structure (PMS.yaml) — distilled structural algebra (≈500 lines)
* PMS-STACK.md — full systems architecture built directly from these operators

This specification is not “inspired by” the PMS model — it is the PMS model, instantiated in computation.

---

### 1.1 Motivation, Scope & Non-Goals

#### Motivation

Current OS and computation architectures are residue: layers of historical constraints, fragmented abstractions, and complex safety mechanisms not grounded in a unifying model.

PMS-STACK provides:

* a minimal algebra generating all computation
* a CPU architecture consistent with that algebra
* a kernel and syscall interface where every operation corresponds to operator semantics
* a programming language (PMSL) typed by operators
* a network stack whose behavior is derivable from Δ–Ψ
* a security/governance model not patched on top, but inherent

#### Scope

This specification defines:

* the formal operator calculus
* PMS-UM (Universal Machine)
* PMS-CPU architecture & ISA
* PMS-OS kernel
* memory, drivers, networking, security
* PMSL language + runtime
* verification & tooling
* boot & cluster semantics

#### Non-Goals

PMS-STACK is not:

* a POSIX re-implementation
* a classical microkernel
* a hardware specification (though mapping is trivial)
* an application framework
* a psychological or sociological metaphor (all operator semantics are *computational*)

---

### 1.2 Lineage: Maturity in Practice → MIPractice model → PMS → PMS-STACK

The lineage of this architecture is bottom-up formalization:

1. Maturity in Practice (book) provided the qualitative theory of action, frames, roles, asymmetry, temporality, recontextualization.
2. MIPractice YAML model captured these elements in a structured data model capable of analysis, inference, and transformation.
3. PMS.yaml distilled the operators into a minimal generative algebra.
4. PMS-STACK demonstrates that this algebra is sufficient to generate an entire OS stack.

Nothing extraneous was added.
Every component is a structural consequence of Δ–Ψ.

---

### 1.3 Relation to Existing OS & Architecture Families

PMS-STACK subsumes classical architectures:

| System Family | PMS-STACK View                                                         |
| ------------- | ---------------------------------------------------------------------- |
| Unix / POSIX  | Emergent pattern of Δ→∇→□→Ω→Θ sequences constrained by ad-hoc policies |
| Microkernel   | Partial alignment with strong Χ (isolation) and Φ (message traps)      |
| Exokernel     | Similar minimality, but no operator-level semantics or policy binding  |
| WASM          | A restricted Δ/∇ fragment without Ω, Φ, Χ, Σ, Ψ                        |
| Capability OS | Matches Ω but lacks the full operator algebra                          |
| Actor models  | Subset of □ + Θ + Δ/Λ + Φ, but missing structural invariants           |

PMS-STACK is not “competing” with these models.
It is the unifying formal generative structure from which all of them can be derived as special cases.

---

### 1.4 Intended Use, Audience & Reading Guide

#### Intended Use

This document is a full architecture specification, suitable for:

* OS designers
* systems programmers
* programming language developers
* formal verification researchers
* distributed systems architects

#### Reading Guide

* Chapter 2: Formal foundations (operators, monoid, dependencies)
* Chapter 3: PMS Universal Machine (abstract semantics)
* Chapter 4: PMS-CPU (concrete architecture)
* Chapter 5: Kernel design
* Chapter 7–10: IPC, devices, networking, security
* Chapter 11–12: Language & runtime
* Chapter 14: Boot & distributed orchestration
* Appendices: Reference tables, proofs, examples, mappings

Readers may treat each chapter independently; the operator algebra is the only prerequisite.

---

## 2. Formal Foundations

This chapter fixes the minimal formal core that everything else in PMS-STACK builds on:

* the Δ–Ψ operator set as an abstract algebra,
* the mapping from PMS to IT structures,
* and the monoid + dependency structure that defines which operator sequences are well-formed.

All later definitions (PMS-UM, PMS-CPU, PMS-OS, PMSL, networking, multi-node systems) assume this chapter as ground truth.

---

### 2.1 PMS Operator Recap (Δ–Ψ)

*Axiomatic mode: operator definitions, roles, semantics sketch.*

The PMS model (schema_version: `PMS_1.1`) defines 11 primitive operators.
They are *not* metaphors — they are formal praxeological transformations applicable to any structured action system, including IT architectures.

Below is the canonical structural interpretation.

#### Δ — Difference / Distinction

Function: Create or detect categorical distinctions.
Structural role:

* branching decision
* classification
* symbol / type identity

In IT: typing, message kind, conditional branches, state discrimination.

---

#### ∇ — Impulse / Enactment

Function: Apply a directed action that changes state.
Structural role:

* write
* update
* execute an instruction

In IT: CPU writes, assignment, syscall invocation, operation execution.

---

#### □ — Frame / Context

Function: Establish or switch the context within which operations have meaning.
Structural role:

* scope
* memory frame
* call frame
* execution context

In IT: address spaces, namespaces, stack frames, protocol contexts.

---

#### Λ — Non-Event / Absence

Function: Encode meaningful absence where an event was expected.
Structural role:

* timeout
* idle
* dropped message
* default path

In IT: timeouts, polling, null results, non-blocking operations.

---

#### Α — Attractor / Pattern

Function: Provide reusable structured sequences and constraints.
Structural role:

* macro-patterns
* grammar rules
* templates
* loops

In IT: design patterns, macros, regular behaviors, common protocol flows.

---

#### Ω — Asymmetry / Role

Function: State or enforce directional or privileged relations.
Structural role:

* roles
* capabilities
* privilege levels
* authority boundaries

In IT: admin/user mode, client/server, access rights, capability systems.

---

#### Θ — Temporal Ordering / Sequence

Function: Impose ordering constraints and progression steps.
Structural role:

* scheduling order
* progression edges
* happens-before relations
* retry / backoff ordering

In IT: scheduler ordering, event loop ordering, sequential program order, logically ordered progressions.

---

#### Φ — Recontextualization / Shift

Function: Change how a situation is interpreted without discarding it.
Structural role:

* version negotiation
* type coercion
* exception reframing
* migration

In IT: exception handling, interpreter switching, feature flags, migrations.

---

#### Χ — Isolation / Reachability

Function: Enforces isolation boundaries and reachability constraints.
Structural role:

* sandbox
* boundary
* protected subsystem
* detached view

In IT: isolation barriers, memory protection, containers, `chroot`, VM boundaries.

---

#### Σ — Integration / Commit

Function: Combine partial trajectories into a coherent result.
Structural role:

* commit
* merge
* fold / reduce
* finalize

In IT: transaction commit, merging buffers, finishing I/O operations.

---

#### Ψ — Self-Binding / Invariant / Policy

Function: Establish commitments that constrain future operation.
Structural role:

* invariants
* contracts
* global constraints
* safety rules

In IT: kernel invariants, system policies, security rules, SLAs, governance.

---

*(Note: detailed dependency and well-formedness constraints between operators are formalized in section 2.3.)*

---

### 2.2 PMS → IT Structural Mapping

*Axiomatic → applied mapping to IT primitives.*

This section fixes the structural “Rosetta mapping” between the abstract PMS operators and concrete IT constructs. The rest of the spec (CPU, OS, protocols, language, distributed coordination) simply instantiates this mapping.

#### 2.2.1 Direct Mapping Table (Δ–Ψ → IT Equivalents)

| PMS Op | IT Equivalent (Structural)                                | Explanation                                          |
| ------ | --------------------------------------------------------- | ---------------------------------------------------- |
| Δ  | type, opcode, syscall number, message kind                | Distinguishes what action or resource is referenced. |
| ∇  | instruction execution, write, mutation                    | State transition or action impulse.                  |
| □  | stack frame, address space, namespace, protocol frame     | The scope in which meaning is evaluated.             |
| Λ  | timeout, dropped packet, idle loop, null                  | Explicit non-event or absence case.                  |
| Α  | loop, grammar, protocol flow, template                    | Structure for reusable trajectory or pattern.        |
| Ω  | privileges, role, user vs kernel, capability              | Structural asymmetry of allowed operations.          |
| Θ  | scheduler ordering step, sequential order, temporal chain | Encodes ordering and progression.                    |
| Φ  | exception, migration, version change, fallback            | Change in interpretation of state or context.        |
| Χ  | memory protection, VM isolation, sandbox                  | Controlled separation between contexts.              |
| Σ  | commit, merge, transaction end                            | Integrative completion or reduction.                 |
| Ψ  | invariants, global policies, kernel rules                 | System-level constraints across time.                |

---

#### 2.2.2 PMS → IT Layers

Minimal structural mapping that justifies later layers.

##### Hardware / CPU

* Δ → opcodes
* ∇ → ALU operations
* Θ → execution ordering / pipeline step index
* Ω → privilege rings
* Χ → MMU + isolation
* Φ → interrupts / traps
* Σ → result commit to registers / memory
* Ψ → hardware invariants (for example: “cannot write read-only segments”)

##### Kernel

* □ → address spaces, process frames
* Ω → capability / role model
* Θ → scheduler ordering and progression
* Λ → timeouts, idle tasks
* Φ → exception handlers
* Σ → system call returns / state sync
* Ψ → kernel-level invariants

##### File Systems

* Α → directory hierarchy
* □ → mounted namespaces
* Σ → `fsync`, transaction commit
* Ω → file permissions
* Θ → ordering of updates and history steps

##### Networking

* Δ → packet type
* Θ → sequence numbers
* Λ → dropped packets
* Ω → client/server asymmetry
* Φ → version negotiation

##### Programming Languages / Runtime

* □ → lexical scopes
* Θ → control flow ordering
* Σ → return value
* Φ → exception
* Ψ → language-level invariants
* Χ → modules as isolated contexts

This is sufficient to proceed to the monoid view (2.3) and then to the PMS-UM formal model (chapter 3).

---

### 2.3 Monoid View & Dependency Constraints

This section establishes:

1. the PMS operator alphabet,
2. a monoid structure over operator compositions,
3. formal constraints that restrict which sequences are structurally valid,
4. the link to the `dependency_table` in `PMS.yaml`.

The result is an operator grammar that all later machines, ISAs, kernels and languages must respect.

---

#### 2.3.1 Alphabet, Composition, Identity

Operator alphabet

Let the operator alphabet be:

`O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }`

Each symbol denotes one primitive transformation class in the PMS axiomatic layer (as introduced in 2.1). For now, we treat them as formal symbols, not yet as concrete machine steps.

---

Free monoid over O

We consider all finite sequences over this alphabet, written as words like:

* `ε` (the empty word)
* `Δ`
* `∇`
* `Δ∇`
* `□ΘΦ`
* …

The set of all such finite sequences is denoted by `O*`.

Define a binary operation `·` on `O*` as sequence concatenation.
For words `x, y` in `O*`, the word `x · y` is simply “run `x` then `y`”.

The neutral element of concatenation is the empty word `ε`:

* `ε · x = x` for all `x` in `O*`
* `x · ε = x` for all `x` in `O*`

Thus, in the purely syntactic sense, PMS operators form the standard free monoid

*`M_free = (O*, ·, ε)`*

---

Semantic role of Δ

Although `ε` is the monoid identity, Δ plays a distinguished semantic role:

* every non-trivial action in PMS-STACK presupposes some distinction (target, type, frame, role),
* Δ is the minimal “distinguish” step that can be semantically neutral in some contexts (no observable state change, but a refined view).

In other words:

* `ε` is the formal identity in the monoid,
* Δ is the minimal semantic precondition for almost all operators (captured as a dependency in 2.3.2).

We keep this distinction clear: identity = `ε`, “neutral distinction” = certain Δ occurrences.

---

#### 2.3.2 Dependency Constraints from PMS.yaml (`dependency_table`)

We begin with the free monoid over the operator alphabet:

* Alphabet: `O` (the PMS operators Δ…Ψ)
* Words: elements of `O*`
* Monoid: `M_free = (O*, ·, ε)`

PMS-STACK does not accept all words in `O*`; it only accepts those that satisfy the dependency structure encoded in the `dependency_table` of `PMS.yaml`.

We define the valid language of PMS operator sequences as a subset

*`L_PMS ⊆ O*`*

Intuition:

> PMS-STACK = the free monoid over Δ–Ψ, restricted by the dependency constraints from `dependency_table`.

In particular:

* all PMS-UM programs,
* all PMS-CPU instruction traces,
* all kernel transition traces,
* all PMSL programs and IR traces

must be words in `L_PMS` (or Ψ-strengthened sublanguages `L_PMS,Ψ ⊆ L_PMS`), never arbitrary words in `O*`.

`PMS.yaml` specifies dependencies as relations of the form

*`op_i ⇒ op_j`*

meaning: `op_j` may only operate if `op_i` appears upstream in the causal ancestry of the operator word (not necessarily adjacent, but within the relevant prefix-context).

We rewrite these semantic dependencies into sequence constraints over the monoid `(O*, ·, ε)`.
The following is the canonical dependency set reconstructed from PMS semantics.

---

##### 1. Δ prerequisites

For every operator `op` different from Δ, we require Δ to appear earlier in the sequence:

*For all `op ≠ Δ`: Δ must occur in the prefix before `op`.*

Intuition:
No frame, role, policy, ordering, or action can occur without a prior distinction.

Examples:

* Valid: `Δ∇`, `Δ□`, `ΔΩ`, `ΔΦ`
* Invalid: `∇` as first operator, `Φ` without any preceding Δ

---

##### 2. ∇ depends on Δ

Impulse requires a distinguished target:

*Δ must appear before ∇.*

Examples:

* Valid: `Δ∇Σ`
* Invalid: `∇Σ` (missing Δ upstream)

---

##### 3. □ (Frame) constrains downstream operators

Frame changes have two constraints:

* Δ must appear before `□` (you frame something already distinguished).
* `□` must be used by the following operator; “floating” frame switches are invalid.

Formally: a `□` must be followed (within the relevant continuation) by at least one of:

* `∇`, `Ω`, `Θ`, `Φ`, `Σ`

Examples:

* Invalid: `Δ□Δ□Θ` (frames introduced and then abandoned)
* Valid: `Δ□∇`, `Δ□Ω`, `Δ□ΘΣ`

---

##### 4. Λ (Non-Event) requires Θ or ∇ context

Λ is meaningful only when something was expected.

Dependencies:

* Either `Θ` or `∇` must appear earlier in the sequence before Λ.

Examples:

* Valid: `ΘΛ`, `∇Λ`
* Invalid: `ΔΛ`

---

##### 5. Α (Attractor) expands to a reusable PMS-valid sequence

Α is a macro-level construct; it expands into a sequence built from Δ, ∇, Θ, □.

Constraint (informal but precise enough here):

* Α must expand to one or more subsequences that themselves are PMS-valid and internally composed only from `{Δ, ∇, □, Θ}` plus any required Δ prefixes.

Α is not semantically atomic.

---

##### 6. Ω (Asymmetry) constrains ∇, □, Θ

Capabilities and asymmetries obey:

* Δ must appear before `Ω`.

And when actions require capability:

* `Ω` must appear before the constrained `∇`.
* `Ω` must appear before privileged `□` transitions.

Examples:

* Valid: `ΔΩ∇`, `ΔΩ□Θ`, `ΔΩΘ∇Σ`
* Invalid: `Δ∇Ω` when that ∇ requires capability

(Policies can bind which ∇ and □ operators are in fact capability-gated.)

---

##### 7. Θ (Temporal Ordering) structures sequences

Θ induces ordering, not time by itself.

Dependencies:

* Δ must appear before `Θ`.
* `Θ` must be followed by one of `∇`, `Λ`, or `Σ` (ordering must order *something*).

Examples:

* Valid: `Θ∇`, `ΘΛ`, `ΘΣ`
* Invalid: a Θ that appears with no “consumer”, such as a terminal Θ that is never used to order a subsequent step.

---

##### 8. Φ (Recontextualization)

Recontextualization requires both distinction and an active frame:

* Δ must appear before Φ.
* `□` must also appear before Φ (there has to be some frame to recontextualize).

Furthermore, Φ must be followed by a meaningful continuation, e.g.:

* `∇`, `Θ`, or `Σ`

This captures exception handling, migrations, and similar constructs: a context shift that leads to further structured action.

---

##### 9. Χ (Isolation / Reachability)

Isolation depends on a prior frame:

* `□` must appear before `Χ`.

After Χ, one of the following must occur:

* `∇`, `Σ`, or `Φ`

Examples:

* Valid: `Δ□Χ∇`, `Δ□ΧΦ`
* Invalid: `Χ` with no preceding `□`

Χ therefore always isolates *some* frame and is used by later actions.

---

##### 10. Σ (Integration / Commit)

Commit requires prior activity:

* At least one of `∇` or `Θ` must appear earlier in the sequence before Σ.

Examples:

* Invalid: `ΔΣ`
* Valid: `Δ∇Σ`, `ΔΘ∇ΘΣ`

---

##### 11. Ψ (Self-Binding / Policy)

Ψ is the strongest constraint operator.

* Δ must appear before Ψ.

Ψ restricts the set of future allowed operators; it may close branches or invalidate otherwise valid operations.

Thus Ψ induces a policy-restricted sublanguage:

*`L_PMS,Ψ ⊆ L_PMS`*

---

##### Summary

The `dependency_table` defines a formal grammar (or equivalently, an automaton) that generates exactly the language `L_PMS` of valid PMS operator sequences.
All PMS-UM, PMS-CPU, kernel, PMSL, and distributed traces are words in this language.

---

#### 2.3.3 Well-Formed Sequences

Let `w = o₁ o₂ … oₙ` be a word over `O`.

A sequence is PMS-valid (“well-formed”) if and only if, for every position `i`:

*for the operator `oᵢ`, all prerequisites required by the dependency rules appear somewhere in the prefix `{o₁, …, oᵢ₋₁}`.*

Equivalently, `w` is accepted by the automaton defined by the dependency relations above.

Define the set of valid words:

*`M_PMS,valid = { w in O* | w respects all dependency constraints }`*

This is the legal instruction algebra for the PMS Universal Machine and all PMS-STACK layers.

---

#### 2.3.4 Computational Expressiveness

Putting the pieces together:

* finite operator alphabet `O`,
* free concatenation over `O*`,
* monoid structure `(O*, ·, ε)`,
* semantic centrality of Δ as minimal distinction,
* dependency constraints shaping `M_PMS,valid`,
* operators for branching (Δ), loops/patterns (Α, Θ), context (□), ordered progression (Θ), isolation (Χ), integration (Σ), and policies (Ψ).

The restricted monoid `M_PMS,valid` is expressive enough to encode:

* state machines (via Δ, ∇, Σ),
* pushdown-like systems (via □ frames),
* systems with ordered progression (via Θ and Λ, with physical time encoded separately in τ where present),
* isolated submachines (via Χ),
* recontextualizable systems (via Φ),
* transactional / policy-bound systems (via Σ and Ψ).

This underlies the computational universality claim for PMS-UM and provides the structural backbone for all following PMS-STACK architectures.

---

### 2.4 Notation & Meta-Model (States, Transitions, Configurations)

This section defines the meta-structures used to reason about:

* PMS-UM
* PMS-CPU
* kernels
* languages (PMSL and IRs)
* protocols

with one canonical set of definitions.

All later layers assume this meta-model as shared substrate.

---

#### 2.4.1 Notation

We fix a compact notation.

Sets and syntax

* `O`
  PMS operator alphabet

  `O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }`

* `O*`
  Set of all finite operator sequences (words).

* `w = o₁ o₂ … oₙ`
  An operator word.

* `ε`
  Empty sequence (formal monoid identity).

* `·`
  Composition (concatenation) of operator words.

* Δ
  Distinguished operator for minimal semantic distinction.
  (The free-monoid identity is `ε`; Δ is the minimal *semantic* precondition for most operators, as encoded in the dependencies in 2.3.)

Wherever there is a clash between informal usage and formal semantics, the dependency-based definition in 2.3 wins.

---

#### 2.4.2 States

A state represents the entire static condition of a system at a given instant.

We write:

*`s ∈ S`*

where `S` is a structured set, domain-dependent.

A generic PMS-STACK state contains:

1. Core state (`s_c`):
   primary contents (memory, registers, tape, filesystem structures, process table, protocol buffers, etc.).

2. Frame context (`f`):
   currently active □ context(s).

3. Role context (`r`):
   current Ω mode / privileges of the locus of action.

4. Policy context (`P`):
   active Ψ constraints binding allowable transitions.

5. Meta-state (`m`):
   temporal reference information (`τ`: clocks, timestamps, deadlines, usage counters), ordering-related metadata for Θ, pending non-events (Λ), exception mode (Φ), isolation/topology information (Χ), etc.

A state can thus be summarized as:

*`s = (s_c, f, r, P, m)`*

Concretely, the temporal reference object `τ` typically has components such as:

* `now` (current time reading),
* `cpu_usage[...]` (per-entity CPU usage accounting),
* `deadlines[...]`,
* `timers[...]`,
* `timestamps[...]`.

These are updated via ∇ and Σ. Θ only induces the ordering of transitions that read or update `τ` or other components of `m`; all physical time and duration values reside in `τ` as data, not in Θ itself.

This schema covers, for example:

* PMS-UM configurations,
* PMS-CPU snapshots,
* kernel process / scheduler state,
* filesystem consistency state,
* network protocol endpoints,
* PMSL runtime / VM states.

---

## 3. PMS Universal Machine (PMS-UM)

### 3.1 Formal Definition of PMS-UM

We now define the PMS Universal Machine (PMS-UM) as a general computational model whose primitive actions are the PMS operators Δ–Ψ, applied to states as defined in 2.4.

We stay purely structural: no EM, no psychology, only operator-typed state transitions.

---

#### 3.1.1 Machine Tuple

A PMS Universal Machine is a tuple

```text
M = (S, Γ, F, R, PSet, O, Inst, δ, s_0, S_H)
```

with:

* S – set of machine states (as in 2.4):

  ```text
  s = (s_c, f, r, P, m)
  ```

  where:

  * `s_c` : core data
  * `f ∈ F` : current frame (□)
  * `r ∈ R` : current role/capability mode (Ω)
  * `P ∈ PSet` : active policies (Ψ)
  * `m` : meta-state

* Γ – symbol alphabet used in core state.

* F – a finite or countable set of frames (□-contexts).

* R – set of roles (Ω modes).

* PSet – sets of policies (Ψ).

* O – PMS operator alphabet:

  ```text
  O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
  ```

* Inst – a finite set of instruction schemata:

  ```text
  I ∈ Inst := (op, pre, post)
  ```

* δ – the transition relation:

  ```text
  (s, I, s') ∈ δ  iff  pre_I(s) holds and s' = post_I(s)
  ```

* s₀ ∈ S – initial machine state.

* S_H ⊆ S – halting states.

---

#### 3.1.2 Configurations and Programs

A program is a finite sequence:

```text
π = ⟨ I₁, I₂, …, Iₙ ⟩
```

We extend state to include an instruction pointer:

```text
s = (s_c, f, r, P, m, ip)
```

A configuration is:

```text
C = (s, π)
```

Execution step:

```text
(s, π) ⇒ (s', π)
```

---

#### 3.1.3 Step Relation

If `ip = k`:

```text
I_k = (op, pre, post)
```

A step is:

```text
(s, π) ⇒ (s', π)
```

iff:

1. `pre(s)` holds
2. `s' = post(s)`
3. `ip'` is updated according to `op` semantics

If no instruction applies or Ψ forbids continuation, the machine is halted or stuck.

---

#### 3.1.4 Incorporating PMS Dependencies

Each operator `op ∈ O` has prerequisites `P(op)`.

To enforce well-formedness:

```text
pre_I(s) ⇒ ( P(op) ⊆ Hist(s) )
```

`Hist(s)` tracks which operators have occurred in the current logical context.

Thus every PMS-UM instance obeys the PMS operator grammar.

---

#### 3.1.5 Deterministic vs. Non-Deterministic PMS-UM

A PMS-UM is deterministic iff:

```text
for all states s:   | { I | pre_I(s) } | ≤ 1
```

Otherwise it is non-deterministic.

---

#### 3.1.6 Turing-Machine-Like Instance (for Later 3.3)

A classical Turing Machine (TM) maps to PMS-UM via:

* Δ — read / compare
* ∇ — write / move
* Θ — step
* Σ — accept / finalize
* Ψ — halting conditions

---

#### 3.1.7 Summary

A PMS-UM consists of:

* structured state `(s_c, f, r, P, m)`
* operator-typed instructions (Δ–Ψ)
* a transition relation constrained by:

  * PMS dependency rules
  * Ψ (policies)
  * Ω (roles)
  * □ (frames)
  * Θ, Λ, Φ, Χ (meta-structure)

Prepared for:

* 3.2 Instruction Semantics
* 3.3 TM Encoding
* 3.4 Determinism vs Non-Determinism

---

### 3.2 Instruction Semantics by Operator (Δ…Ψ)

Recall the state shape from 2.4 (extended with `ip` for program execution):

```text
s = (s_c, f, r, P, m, ip)
```

* `s_c` – core data (tape/memory/registers/filesystem/…)
* `f ∈ F` – current frame (□)
* `r ∈ R` – current role / capabilities (Ω)
* `P ∈ PSet` – active policy set (Ψ)
* `m` – meta-state (ordering metadata, pending non-events, isolation flags, history, etc.)
* `ip` – instruction pointer (index in program)

Each instruction is:

```text
I = (op, pre, post)
```

with `op ∈ O`, `pre: S → { true, false }`, `post: S → S`.

Below we specify, for each operator:

* constraints on `pre`,
* allowed structure of `post`,
* what it must or must not change.

Concrete instances (CPU, kernel, etc.) will refine `post` into explicit algorithms.

---

#### 3.2.1 Δ — Difference / Distinction

Intuition: inspect and branch, but do not mutate core data.

Instruction form:
`I_Δ = (Δ, pre_Δ, post_Δ(params))`

* `pre_Δ(s)`:

  * must satisfy Δ’s dependency constraints (from 2.3) – usually trivial because Δ is the minimal semantic prerequisite,
  * plus any domain-specific condition (for example “the cell is readable”).

* `post_Δ(s) = s'`:

  * `s'_c = s_c` (no core mutation)
  * `f'`, `r'`, `P'` may remain the same or be updated to record classification (but are usually unchanged)
  * `m'` may be updated to include distinction information or history, for example:

    * set flags: `m'.flags.different = (symbol ≠ pattern)`
    * record that Δ has fired in this context
  * `ip'`:

    * either `ip' = ip + 1` (no branch),
    * or `ip'` chosen from a finite set of branch targets based on the distinction result.

Invariant:
Δ is purely observational on `s_c`; it does not change data, only how we see it and where we go next.

---

#### 3.2.2 ∇ — Impulse / Enactment

Intuition: perform a state-changing action.

Instruction form:
`I_∇ = (∇, pre_∇, post_∇(params))`

* `pre_∇(s)`:

  * must ensure Δ prerequisites are satisfied (a target is distinguished),
  * may require appropriate role `r` (Ω) and frame `f` (□) to allow this action.

* `post_∇(s) = s'`:

  ```text
  s'_c = A_∇(s_c, f, r, params)
  ```

  for some domain-specific transformation `A_∇` (write, update, I/O, etc.).

  * `f'`, `r'`, `P'`:

    * typically unchanged,
    * can be altered if the action includes context or role changes, but only in a way consistent with Ω and Ψ.
  * `m'`:

    * may update meta (for example logs, counters, history).
  * `ip' = ip + 1`
    (unless this ∇ is a “jump-like” action; jumps are usually modeled via Δ/Ω/Θ, but we do not forbid ∇ changing `ip` if the instruction design says so).

Invariant:
∇ is the primary operator (besides Σ, Φ, Ψ in special cases) that directly changes core state `s_c` in normal execution.

---

#### 3.2.3 □ — Frame / Context

Intuition: change the interpretation context without itself doing work on core data (except possibly switching which part is considered active).

Instruction form:
`I_□ = (□, pre_□, post_□(params))`

* `pre_□(s)`:

  * ensures Δ prerequisite (we know which frame we are switching to),
  * checks that the requested frame exists and is permitted under role `r` and policies `P`.

* `post_□(s) = s'`:

  * `s'_c`:

    * unchanged as a whole, but the active address region or “view” may shift (for example frame base/limit encoded in meta-state `m`).
  * `f' = f_new` chosen from `F`, based on parameters.
  * `r'`, `P'`:

    * may stay the same or be adjusted if the frame change implies role or policy scope change.
  * `m'`:

    * records the frame switch in meta (for example a stack of frames for nested contexts).
  * `ip' = ip + 1`.

Invariant:
□ is contextual: it does not directly alter the underlying data, only which context is considered active.

---

#### 3.2.4 Λ — Non-Event / Absence

Intuition: handle “expected but missing” events (timeouts, no data, idle).

Instruction form:
`I_Λ = (Λ, pre_Λ, post_Λ(params))`

* `pre_Λ(s)`:

  * requires that a prior Θ or ∇ has established an expectation (for example “waiting for I/O until some ordering bound”),
  * typically checks ordering-related markers in `m` (Θ-related) or pending operations.

* `post_Λ(s) = s'`:

  * `s'_c = s_c` (no core data update by Λ itself),
  * `f'`, `r'`, `P'`:

    * usually unchanged; may be modified to signal degraded mode if Λ triggers a fallback.
  * `m'`:

    * updates meta to reflect timeout or non-event: mark operation as failed, log, increment counters.
  * `ip'`:

    * either `ip + 1` (continue),
    * or branch to an error-handling or fallback section.

Invariant:
Λ never performs the expected main action; it only reacts to its absence.

---

#### 3.2.5 Α — Attractor / Pattern

Intuition: macro or pattern over a reusable operator sequence.

In PMS-UM it is best viewed as a:

* syntactic / macro-level construct, expanded before or at execution into a sequence of Δ, ∇, □, Θ, etc.

Instruction form:
`I_Α = (Α, pre_Α, post_Α(pattern_id, args))`

Two semantics options (we define both; implementations choose):

1. Compile-time / static expansion

   * Α is eliminated by replacing it with a sequence `w_pattern` of primitive ops.
   * At runtime, there is no Α; the machine sees only the expanded operators.

2. Runtime expansion (macro step)

   * `pre_Α(s)`:

     * ensures that the pattern is defined and valid (its sequence respects PMS constraints, as in 2.3).
   * `post_Α(s)`:

     * inserts the corresponding operator subsequence into the program (or into meta `m` as a local instruction buffer),
     * sets `ip` to the first operator of the expanded pattern.

Invariant:
Α does not define new primitive semantics; it reuses valid PMS sequences and must expand to PMS-valid words.

---

#### 3.2.6 Ω — Asymmetry / Role

Intuition: manage roles, privileges, and capability-based branching.

Instruction form:
`I_Ω = (Ω, pre_Ω, post_Ω(params))`

* `pre_Ω(s)`:

  * requires Δ (we know which role or capability set is involved),
  * may require the current role `r` to have authority to switch to the target role or apply that capability.

* `post_Ω(s) = s'`:

  * `r'`:

    * update to a new role (mode switch: user → kernel, client → server, etc.), or confirm the current role.
  * `s'_c`:

    * not usually modified (unless part of the capability mechanism is encoded in core state).
  * `f'`, `P'`:

    * may change if entering a more privileged or less privileged context (policy and frames might shift).
  * `m'`:

    * records mode transitions and audit information.
  * `ip'`:

    * either `ip + 1`,
    * or branch depending on the capability check outcome.

Invariant:
Ω never performs main work itself; it qualifies who may do what and can redirect control based on permissions.

---

#### 3.2.7 Θ — Ordering / Sequence

Intuition: implement ordered progression and structured sequencing. Θ induces an ordering constraint; it never encodes physical time.

Instruction form:
`I_Θ = (Θ, pre_Θ, post_Θ(params))`

* `pre_Θ(s)`:

  * checks that an ordering context exists (for example sequence or phase metadata in `m`),
  * may check scheduling constraints encoded in `P` that refer to ordering positions (for example maximum number of steps in a phase), not to physical timestamps.

* `post_Θ(s) = s'`:

  * `m'`:

    * updates ordering meta: sequence counters, logical steps, scheduler phase, happens-before indices, and so on; Θ does not write physical timestamps (those, if present, live purely as data and are updated via ∇ or Σ).
  * `s'_c`:

    * unchanged; Θ does not perform work on core data. In particular, even TM-like head movement or register updates must be modeled via ∇, not via Θ.
  * `f'`, `r'`, `P'`:

    * typically unchanged; can update scheduling-related contexts (for example which runnable set is current) as part of ordering meta, but without mutating core payload data.
  * `ip' = ip + 1`
    (unless Θ-based control structures are used; for example structured loops that still only manipulate ordering and control flow, not core data).

Invariant:
Θ is the ordering backbone; any recurrent or ordered behavior uses Θ steps to structure the sequence. Physical time, clocks, deadlines, and timers remain represented purely as data or meta-state and are read or updated by ∇ or Σ under Ψ, never encoded in Θ itself.

---

#### 3.2.8 Φ — Recontextualization / Shift

Intuition: change the interpretation of the current situation (exceptions, versioning, migration, fallback).

Instruction form:
`I_Φ = (Φ, pre_Φ, post_Φ(params))`

* `pre_Φ(s)`:

  * requires that Δ and □ exist upstream; there is something to reinterpret within a known frame,
  * may inspect error flags, policy feedback, or type mismatches in `m`.

* `post_Φ(s) = s'`:

  * `f'`:

    * possibly switches to a new frame (for example new version, new context).
  * `s'_c`:

    * may remain unchanged (pure re-interpretation),
    * or be transformed via a migration function if the data layout changes.
  * `r'`, `P'`:

    * may change to reflect the new interpretation or new policy scope.
  * `m'`:

    * clears some error flags, records the new context, sets exception-handling markers.
  * `ip'`:

    * jumps to an exception handler or a new code region, or continues in the new context.

Invariant:
Φ does not discard the underlying content; it repackages it into a new interpretive context.

---

#### 3.2.9 Χ — Isolation / Reachability

Intuition: create and manage isolated subcontexts (sandboxes, sub-machines).

Instruction form:
`I_Χ = (Χ, pre_Χ, post_Χ(params))`

* `pre_Χ(s)`:

  * requires □ (we know which frame is being isolated or split),
  * checks policy and role (Ω and Ψ) to see if isolation is permitted.

* `post_Χ(s) = s'` (two common patterns):

1. Fork-like isolation

   * create a new sub-state or context `s_iso` extracted from `s_c` and `f`,
   * record in `m` that execution may switch between parent and isolated context,
   * optionally set `ip'` to execute inside the isolated context.

2. Enter/exit isolation

   * mark in `m` that the current operations are in an isolated mode,
   * some parts of `s_c` become inaccessible (enforced by later preconditions).

* `s'_c`:

  * unchanged in the parent, or duplicated or partitioned for the isolated region.

* `f'`, `r'`, `P'`:

  * possibly switch to a restricted frame, role, or policy subset.

* `ip'`:

  * next instruction inside or outside the isolated context.

Invariant:
Χ reduces or restructures reachability between contexts; it never extends access beyond what policies and frames allow.

---

#### 3.2.10 Σ — Integration / Commit

Intuition: merge, finalize, or commit accumulated changes into a coherent state.

Instruction form:
`I_Σ = (Σ, pre_Σ, post_Σ(params))`

* `pre_Σ(s)`:

  * ensures that there is something to integrate: prior ∇-operations (possibly structured by Θ steps) have produced partial results,
  * checks transactional or consistency constraints from policies `P` (Ψ).

* `post_Σ(s) = s'`:

  * `s'_c`:

    ```text
    s'_c = C_Σ(s_c, f, m, params)
    ```

    for some commit function `C_Σ` (for example write buffers flushed, partial structures consolidated, transactions closed).

  * `f'`, `r'`, `P'`:

    * may stay the same or change scope (for example leaving a transactional frame).

  * `m'`:

    * clears “pending” markers, logs the commit, advances integration counters.

  * `ip' = ip + 1`
    (or jumps to an “after commit” section, depending on design).

Invariant:
Σ is the integration operator: it marks the finalization and consolidation of a sequence of actions in a given context.

---

#### 3.2.11 Ψ — Self-Binding / Policy

Intuition: establish and/or enforce global or scoped invariants that constrain future transitions.

Instruction form:
`I_Ψ = (Ψ, pre_Ψ, post_Ψ(params))`

Two main usages:

1. policy definition or activation
2. policy enforcement or checking

* `pre_Ψ(s)`:

  * ensures Δ prerequisites (the policy is distinguished),
  * may require an appropriate role `r` (for example only certain roles can set system policies).

* `post_Ψ(s) = s'` (two modes):

(a) Policy definition / update

* `P' = U_Ψ(P, params)` – update the policy set,
* `s'_c`, `f'`, `r'`, `m'` – typically unchanged except for logging or meta updates,
* `ip' = ip + 1`.

(b) Policy enforcement / check

* evaluate policy rules `R(P, s)`:

  * If ok:

    * state passes unmodified, possibly with audit data:

      * `s'_c = s_c`, `f' = f`, `r' = r`, etc.
      * `ip' = ip + 1`

  * If violated:

    * either:

      * transform `s` into a controlled recovery state (for example kill process, rollback),
      * or mark `s` as halting by moving to `S_H` (set `ip'` to a halt code or move to a special halting state `s_H`).

Invariant:
Ψ is the global constraint operator: it is the only operator that may forbid otherwise legal transitions due to invariants.

---

#### 3.2.12 Summary Table

A quick structural view:

| Op | Mutate `s_c`?                    | Typical changes                    | Main purpose                            |
| -- | -------------------------------- | ---------------------------------- | --------------------------------------- |
| Δ  | No                               | `m`, `ip`                          | Distinguish and branch                  |
| ∇  | Yes                              | `s_c`, `m`, `ip`                   | Perform action, write/execute           |
| □  | No (core), context view only     | `f`, `m`, `ip`                     | Switch or define frame                  |
| Λ  | No                               | `m`, `ip`                          | Handle missing events                   |
| Α  | No (directly)                    | `ip`, meta, code                   | Expand patterns or macros               |
| Ω  | No (usually)                     | `r`, `m`, `ip`                     | Roles, privileges, asymmetric branching |
| Θ  | No (core unchanged)              | `m`, `ip`                          | Ordering step                           |
| Φ  | Maybe                            | `f`, `s_c`, `r`, `P`, `m`, `ip`    | Reframe context, recover                |
| Χ  | Maybe (for isolation structures) | `m`, possibly `f` / `r`            | Create and manage isolated contexts     |
| Σ  | Yes (commit)                     | `s_c`, `m`, `ip`                   | Integrate and finalize                  |
| Ψ  | Maybe                            | `P`, `m`, `ip`, `s_c` on violation | Policies and invariants                 |

---

### 3.3 Example Encodings of Classical Turing Machines

This section demonstrates, rigorously and structurally, that a classical deterministic Turing Machine (TM) can be encoded as a particular instance of the PMS Universal Machine (PMS-UM).
We do not introduce anything outside PMS axioms — we embed the TM inside PMS operators Δ, ∇, □, Θ, Σ, Ψ.

This accomplishes two goals:

1. prove PMS-UM is at least TM-powerful (Turing-complete)
2. provide a concrete blueprint for later layers (PMS-CPU, PMSL, kernel execution model)

---

#### 3.3.1 Classical TM Recap (structural)

A TM is a 7-tuple:

```text
T = (Q, Γ, b, Σ, δ, q_0, F)
```

* `Q` : states
* `Γ` : tape alphabet
* `b` : blank symbol
* `Σ ⊆ Γ` : input alphabet
* `δ : Q × Γ → Q × Γ × {L, R}` – transition function
* `q_0` : initial state
* `F` : accepting states

Core dynamics:

* read a symbol,
* write a symbol,
* move the head left or right,
* change control state,
* halt on accept.

---

#### 3.3.2 Encoding the TM State in PMS State

We map TM components into PMS-UM state (from 2.4):

```text
s = (s_c, f, r, P, m, ip)
```

We now specialize each part.

##### Core state `s_c` stores TM data

* tape: an indexed structure over `Γ`
  → part of `s_c`, for example a mapping from integers to `Γ`

* head position:

  ```text
  pos ∈ Z   (Z = set of integers)
  ```

* control state:

  ```text
  q ∈ Q
  ```

Thus:

```text
s_c = ( tape : Z → Γ,  pos ∈ Z,  q ∈ Q )
```

##### Frame `f`

The TM only needs one logical frame; we set:

```text
f = f_TM
```

##### Role `r`

All operations run under a single role:

```text
r = r_TM
```

##### Policy `P`

For pure TM simulation:

```text
P = { allow all operator transitions except those violating TM structure }
```

That is, policies are trivial except for enforcing structural consistency and halting.

##### Meta-state `m`

Used to store:

* operator history (for dependency checks),
* a simple step counter or similar ordering markers.

---

#### 3.3.3 Encoding the TM Transition Function δ Using PMS Operators

A TM transition rule

```text
δ(q, γ) = (q', γ', move)
```

corresponds to the composite PMS operator sequence:

```text
Δ (inspect);  ∇ (write);  Θ (step);  ∇ (move head);  ∇ (change q)
```

Breakdown:

##### (1) Δ — Read the tape symbol at `pos`

```text
Δ_read : inspect tape[pos]
```

This sets a distinction in meta-state `m`, for example:

```text
m.flags.symbol_read = tape[pos]
```

No mutation of `s_c`.

##### (2) ∇ — Write the new symbol `γ'`

```text
∇_write : tape[pos] := γ'
```

Mutates `s_c`.

##### (3) Θ — Advance the computation step

```text
Θ_step : m.step := m.step + 1
```

Encodes step progression as an ordering index.

##### (4) ∇ — Move head left or right

If `move = L`:

```text
∇_move : pos := pos - 1
```

If `move = R`:

```text
∇_move : pos := pos + 1
```

##### (5) ∇ — Update control state `q → q'`

```text
∇_q : q := q'
```

---

#### 3.3.4 Encoding δ as a PMS-UM Instruction Sequence

For each TM transition rule

```text
(q, γ) ↦ (q', γ', move)
```

we construct a sequence of PMS-UM instructions:

1. `I₁ = Δ(read_symbol, expected = γ, branch to "rule block" if match)`
2. `I₂ = ∇(write γ')`
3. `I₃ = Θ(step)`
4. `I₄ = ∇(move head left or right)`
5. `I₅ = ∇(set q := q')`
6. `I₆ = Θ(next_step)` (optional)
7. `I₇ = jump to next rule evaluation`

This sequence respects all PMS dependency constraints (2.3):

* ∇ depends on Δ → Δ appears first,
* Θ can follow ∇ → satisfied,
* no forbidden use of □, Ω, Φ, Χ, Σ, Ψ in this subset.

Pure TM simulation does not require isolation, policies, or commits beyond halting; thus every TM rule becomes a PMS-valid word such as:

```text
Δ; ∇; Θ; ∇; ∇
```

possibly wrapped in Α (pattern) for reuse.

---

#### 3.3.5 Encoded TM Halting Using Σ or Ψ

TM halting state: `q ∈ F`.

Two PMS options:

##### Option A: Σ — Commit to Final Configuration

Use a special integration operator:

```text
Σ_halt
```

to finalize all accumulated ∇/Θ actions.
After this, `ip` moves to a halting indicator or the state enters `S_H`.

##### Option B: Ψ — Policy-Induced Termination

Define a policy:

```text
Ψ_halt :  (q ∈ F) ⇒ disallow all future ∇, Θ
```

Once `q ∈ F`, any further action violates Ψ, so the machine transitions into `S_H`.

Both styles are structurally valid; they differ only in how halting is encoded (integration vs. policy).

---

#### 3.3.6 Tape as Unbounded Memory — No Extra PMS Machinery Needed

A classical TM requires an unbounded tape.

In PMS-UM:

* `s_c.tape` is an unbounded partial function from `Z` to `Γ`,
* PMS does not restrict the domain of `s_c`,
* Θ steps and ∇ writes naturally extend the tape as needed.

No operator besides ∇ touches the tape, respecting TM semantics.
No additional use of Χ, Φ, or Ω is required for the classical TM behavior.

---

#### 3.3.7 TM Simulation Loop in PMS-UM

A single TM step becomes:

```text
Δ; ∇; Θ; ∇; ∇;  (goto next rule)
```

A full TM execution is:

```text
(Δ ∇ Θ ∇ ∇)*          (repeated zero or more times)
```

until:

* the TM halts → Σ or Ψ is triggered, or
* no rule applies → an optional Ψ or Λ signals an undefined transition.

The entire TM execution is a PMS-valid operator sequence.

---

#### 3.3.8 Summary: Why PMS-UM is Turing-Complete

We embedded TM as a subset of PMS-UM where:

* Δ implements read / test,
* ∇ implements write / head-move / state-update,
* Θ yields discrete progression,
* Σ or Ψ handle halting,
* □, Ω, Φ, Χ, Α, Λ are unused but available.

Thus PMS-UM supports:

* branching and discrimination (Δ),
* arbitrary state updates (∇),
* ordered progression (Θ),
* unbounded tape (in s_c),
* halting (Σ or Ψ).

Therefore PMS-UM is at least as expressive as a classical TM; i.e. PMS-UM is Turing-complete.

---

### 3.4 Execution Cycle & Determinism / Non-Determinism

We now specify how a PMS-UM actually runs a program over progression and how determinism vs. non-determinism is represented structurally in terms of:

* enabled instructions,
* operator semantics,
* policies (Ψ),
* and meta-state (Θ, Λ, Χ, Φ).

We stay at the PMS-UM level, not yet CPU/kernel.

---

#### 3.4.1 One-Step Execution Cycle (Small-Step Semantics)

Given a fixed program (π = ⟨I₁,…,Iₙ⟩) and a current machine state:

```

s = (s_c, f, r, P, m, ip)

```

a single execution step of PMS-UM is:

```

(s, π) ⇒ (s', π)

```

defined as follows:

1. Policy pre-check (Ψ-guard)  
   Let `policy_ok(s)` evaluate all active policies in P.

   * If `policy_ok(s) = false`, then either:

     * transition to a recovery / halt state:  
       `(s, π) ⇒ (s_halt, π)` with `s_halt ∈ S_H`
     * or the machine becomes stuck.

   * If `policy_ok(s) = true`, continue.

2. Instruction fetch (via ip)  
   * If `1 ≤ ip ≤ n`, let `I_ip = (op, pre, post)`.  
   * If `ip = halt` or `s ∈ S_H`, the machine is already halted.

3. Instruction applicability check  
   Check:

```

pre(s) ∧ DepsSatisfied(op, s)

```

If false → stuck.

4. Apply operator (state update)  

```

s' = post(s)

```

This updates `(s_c, f, r, P, m, ip)` per the rules in section 3.2.

---

#### 3.4.2 Multi-Step Runs (Big-Step Semantics)

A run of PMS-UM on program π from initial state `s₀` is:

```

(s₀, π) ⇒ (s₁, π) ⇒ (s₂, π) ⇒ …

```

The run:

* halts if some `s_k ∈ S_H` or `ip_k = halt`,
* diverges if infinite without reaching `S_H`,
* gets stuck if no instruction applies and not in `S_H`.

A big-step evaluation:

```

(s₀, π) ⇓ s_f

```

means the machine halts in `s_f ∈ S_H` after zero or more steps.

---

#### 3.4.3 Deterministic PMS-UM

A PMS-UM is deterministic iff:

```

∀ (s, π): | { s' | (s, π) ⇒ (s', π) } | ≤ 1

```

In concrete PMS-UMs (single ip, single instruction per index):

1. exactly one instruction schema per ip,  
2. `pre` is a boolean predicate,  
3. if `pre` holds, `post` yields exactly one successor.

TM encodings (3.3) are deterministic: `(q, γ, ip)` identifies a unique rule.

---

#### 3.4.4 Sources of Non-Determinism in PMS-UM

PMS-UM can be non-deterministic due to:

##### (A) Multiple enabled instructions at a given ip

If multiple instruction schemata share ip and overlapping preconditions:

```

pre_a(s) = pre_b(s) = true

```

then multiple successors exist.

##### (B) Environment-induced transitions (Λ, Φ, Χ, Θ)

Environment-driven stimuli form:

```

δ_total = δ_internal ∪ δ_env

```

introducing nondeterministic interleavings.

##### (C) Policy & role-based branching (Ψ, Ω)

Policies or role rules may yield multiple legal next actions.

---

#### 3.4.5 Execution Modes: Pure, Environment-Driven, Concurrent

##### 1. Pure Deterministic Mode
* one instruction per ip  
* no δ_env  
* Ψ/Ω/Λ/Χ/Φ introduce no branching  

##### 2. Environment-Driven Non-Deterministic Mode
* δ_env allowed  
* reactive systems model

##### 3. Concurrent / Interleaving Mode
* Χ: multiple subcontexts  
* Θ: scheduler decisions  
* interleavings nondeterministic

---

#### 3.4.6 Fairness Assumptions

* Weak fairness: continuously enabled instructions eventually run  
* Strong fairness: enabled infinitely often → run infinitely often

Represented as Ψ-level policies.

---

#### 3.4.7 Observational Semantics

A run yields an observable trace:

```

o₁, o₂, …

```

Deterministic → single trace  
Nondeterministic → set of traces

---

#### 3.4.8 Summary

Execution cycle:

* Ψ policy check  
* fetch  
* pre + dependency check  
* operator step  
* ip update

Determinism depends on:

* uniqueness of enabled instructions  
* presence/absence of δ_env  
* interleaving (Χ + Θ)  
* policies/roles (Ψ, Ω)

---

## 4. PMS Virtual CPU (PMS-CPU)

### 4.1 Architecture Overview

PMS-CPU instantiates PMS-UM with:

* registers + memory + flags = s_c  
* frame = f  
* role = r  
* policies = P  
* meta-state = m (τ, interrupts, isolation, history)

---

#### 4.1.1 Design Goals

CPU must:

* realize PMS-UM  
* map ISA to Δ–Ψ  
* serve PMSL + kernel + simulator

---

#### 4.1.2 Core State

```

s_c = (RF, PC, SP, FR, SR, MEM)

```

* RF – register file  
* PC – program counter  
* SP – stack pointer  
* FR – frame register  
* SR – status register  
* MEM – memory

---

#### 4.1.2.1 Registers

General-purpose: R0..R(n−1)  
Special-purpose: PC, SP, FR, SR

Δ = distinguish registers  
∇ = modify registers

---

#### 4.1.2.2 Memory (MEM)

Mapping:

```

Address → Byte

```

Partitioned into frames: `(base, size, perms)`

□ selects frame  
Χ isolates  
Ω authorizes

---

#### 4.1.3 Frame Model (□)

```

Frame(FR) = (base, size, type, perms)

```

Types: CODE, DATA, STACK, MMIO, KERNEL, USER

Access checks use Δ, Ω, Ψ.

---

#### 4.1.4 Role Model (Ω)

Roles in SR: USER, SYSTEM, SUPERVISOR, HYPERVISOR  
Ω controls privilege transitions.

---

#### 4.1.5 Status & Meta-State

SR: flags, mode bits, exceptions, isolation, transactions  
m: τ, ordering markers, interrupts, history

---

#### 4.1.6 Memory Model

Assume sequential consistency for single core.

---

#### 4.1.7 PMS Operator Mapping at CPU Level

| PMS Op | CPU Interpretation |
|--------|--------------------|
| Δ | decode, compare, branch |
| ∇ | ALU ops, load/store, call/ret |
| □ | frame switching |
| Λ | wait/poll/idle |
| Α | microcode/macro patterns |
| Ω | role/privilege |
| Θ | ordering, fences, scheduling hints |
| Φ | traps, exceptions, reframe |
| Χ | MMU isolation |
| Σ | commit/atomic |
| Ψ | invariants |

---

#### 4.1.8 PMS-CPU as PMS-UM

Direct mapping: S = registers + memory + frame + role + policies + meta.

---

#### 4.1.9 Summary

PMS-CPU is a Δ–Ψ-structured hardware model.

---

### 4.2 Instruction Set Architecture (ISA)

```

Instr = (mnemonic, op ∈ O, operands, constraints)

```

Grouped by operator.

---

#### 4.2.1 General Conventions

Operands: registers, immediates, frame IDs, effective addresses, roles, policies.

---

#### 4.2.2 Δ-Family

```asm
CMP   Rdst, Rsrc
CMPI  Rdst, imm
TST   Rdst, Rsrc
TSTI  Rdst, imm

BEQ   label
BNE   label
BGT   label
BLT   label
BGE   label
BLE   label

JMP   label
NDIF
```

---

#### 4.2.3 ∇-Family

```asm
MOV    Rdst, Rsrc
MOVI   Rdst, imm
LOAD   Rdst, FR+Rn
STORE  FR+Rn, Rsrc

ADD    Rdst, Rsrc
ADDI   Rdst, imm
SUB    Rdst, Rsrc
MUL    Rdst, Rsrc
DIV    Rdst, Rsrc

AND    Rdst, Rsrc
OR     Rdst, Rsrc
XOR    Rdst, Rsrc
NOT    Rdst
SHL    Rdst, imm
SHR    Rdst, imm

PUSH   Rsrc
POP    Rdst
CALL   label
RET

IN     Rdst, port
OUT    port, Rsrc
```

---

#### 4.2.4 □-Family

```asm
FRM_ENTER  fid
FRM_LEAVE
FRM_SET    FR, Rsrc
FRM_CALL   fid, label
FRM_RET
```

---

#### 4.2.5 Λ-Family

```asm
WAIT       cond_reg, timeout_reg
POLL       cond_reg
NOP_SEM    code
```

---

#### 4.2.6 Α-Family

```asm
PATTERN   pid
PATTERN   pid, Rarg0, Rarg1
LOOP_P    pid, count_reg
```

---

#### 4.2.7 Ω-Family

```asm
SET_ROLE   role
CHK_CAP    cap, label_fail
ENTER_PRIV level
EXIT_PRIV
```

---

#### 4.2.8 Θ-Family

```asm
TICK
SLEEP  ticks
FENCE
YIELD
```

---

#### 4.2.9 Φ-Family

```asm
EXC_RAISE   code
EXC_SET     table_ptr
TRAP        code
EXC_RET
REFRAME     ctx
```

---

#### 4.2.10 Χ-Family

```asm
ISO_FORK     ctx
ISO_ENTER    ctx
ISO_EXIT
ISO_RESTRICT mask
```

---

#### 4.2.11 Σ-Family

```asm
TX_BEGIN
TX_COMMIT
TX_ABORT

ATOMIC_ADD  FR+Rn, Rsrc
ATOMIC_CAS  FR+Rn, Rcmp, Rnew

COMMIT_BARRIER
```

---

#### 4.2.12 Ψ-Family

```asm
SET_POL      pol_id, Rcfg
CHK_POL      pol_id, label_fail
CHK_ALL_POL
HALT_IF_POL  pol_id
```

---

#### 4.2.13 ISA Summary

| PMS Op | ISA Families                       |
| ------ | ---------------------------------- |
| Δ      | CMP, TST, BEQ/BNE, JMP, NDIF       |
| ∇      | MOV, LOAD/STORE, ALU, CALL/RET, IO |
| □      | FRM_ENTER/LEAVE/SET                |
| Λ      | WAIT, POLL, NOP_SEM                |
| Α      | PATTERN, LOOP_P                    |
| Ω      | SET_ROLE, CHK_CAP, PRIV ops        |
| Θ      | TICK, SLEEP, FENCE, YIELD          |
| Φ      | EXC_RAISE, TRAP, EXC_RET, REFRAME  |
| Χ      | ISO_FORK/ENTER/EXIT                |
| Σ      | TX_*, ATOMIC_*, COMMIT_BARRIER     |
| Ψ      | SET_POL, CHK_POL, HALT_IF_POL      |

---

### 4.3 Calling Conventions

We define a canonical PMS-CPU calling convention.

---

#### 4.3.1 Design Goals

* frames = □
* privilege = Ω
* policies = Ψ
* integration = Σ
* recursion, reentrancy, tail calls
* user ↔ kernel transitions via Φ + Ω + Χ

---

#### 4.3.2 Register Classification

##### General-purpose

* arguments: R0–R3
* return: R0 (primary), R1 (secondary)
* caller-saved: R0–R3
* callee-saved: R4–R7

##### Special

PC, SP, FR, SR

---

#### 4.3.3 Stack Frame Layout

```
+-------------------------+
| Caller frame            |
+-------------------------+
| Arg spill area          |
+-------------------------+
| Return address (PC)     |
| Saved SR                |
| Saved FR                |
| Saved R4..R7            |
+-------------------------+ <-- SP after prolog
| Locals / temporaries    |
+-------------------------+
```

---

#### 4.3.4 Normal Function Call/Return Protocol

##### Caller

1. prepare arguments

```asm
MOV R0, Ra
MOV R1, Rb
MOV R2, Rc
MOV R3, Rd
```

2. spill extra arguments

```asm
PUSH Re
```

3. capability / policy checks

```asm
CHK_CAP CAP_CALL_FOO, label_fail
```

4. call

```asm
CALL foo_label
```

5. cleanup

```asm
ADDI SP, SP, n_extra * WORD_SIZE
```

Return values are in `R0` and optionally `R1`.

---

##### 4.3.4.1 Caller sequence

1. **Prepare arguments (∇)**

```asm
MOV R0, Ra
MOV R1, Rb
MOV R2, Rc
MOV R3, Rd
```

2. **Spill extra args (∇)**

```asm
PUSH Re
```

3. **Role/policy checks if required (Δ + Ω + Ψ)**

```asm
CHK_CAP CAP_CALL_FOO, label_fail
```

4. **Call (∇)**

```asm
CALL foo_label
```

5. **Cleanup outgoing arg area (∇)**

```asm
ADDI SP, SP, n_extra*WORD_SIZE
```

Return values in `R0` and optionally `R1`.

---

##### 4.3.4.2 Callee prolog

1. Save callee-saved registers (∇)

```asm
PUSH R4
PUSH R5
PUSH R6
PUSH R7
```

2. Allocate locals (∇)

```asm
SUBI SP, SP, frame_size_locals
```

3. Optionally set frame register (□)

```asm
FRM_SET FR, SP
```

##### 4.3.4.3 Callee body

Use:

* `R0..R3` – arguments/temps
* `R4..R7` – preserved locals
* stack locals via `FR+offset` or SP-relative addressing

##### 4.3.4.4 Callee epilog

1. Return value → R0 (∇)

```asm
MOV R0, Rresult
```

2. Deallocate locals & restore saved registers (∇)

```asm
ADDI SP, SP, frame_size_locals
POP  R7
POP  R6
POP  R5
POP  R4
```

3. Return (∇)

```asm
RET
```

RET completes the frame’s lifecycle; structurally this is an ∇ step with Σ-like integration semantics.

---

#### 4.3.5 Tail Calls & Leaf Functions

##### 4.3.5.1 Leaf functions

If no nested calls:

```asm
SUBI SP, SP, frame_size_locals
; body
ADDI SP, SP, frame_size_locals
RET
```

##### 4.3.5.2 Tail calls

A return of the form `return g(args...)` can reuse the current frame:

```asm
MOV R0, Rarg0
MOV R1, Rarg1
MOV R2, Rarg2
MOV R3, Rarg3
JMP g_label
```

Pure Δ + ∇; the □ frame is reused.

---

#### 4.3.6 System Call / Trap Calling Convention

Syscalls cross the Ω boundary via Φ.

##### 4.3.6.1 User-side ABI

1. Place syscall number + args

```asm
MOVI R0, SYS_WRITE
MOV  R1, Rfd
MOV  R2, Rbuf
MOV  R3, Rlen
```

2. Trap (Φ)

```asm
TRAP #0
```

3. Return: result in `R0`.

##### 4.3.6.2 Kernel handler convention

Φ entry sequence:

```asm
PUSH R4
PUSH R5
PUSH R6
PUSH R7
PUSH FR
PUSH SR
PUSH PC
FRM_ENTER FR_KERNEL_STACK     ; □
SET_ROLE ROLE_KERNEL          ; Ω
```

Dispatch via Δ:

```asm
CMPI R0, SYS_WRITE
BEQ  sys_write
```

Return path:

```asm
SET_ROLE ROLE_USER            ; Ω
FRM_LEAVE                     ; □
EXC_RET                       ; Φ
```

---

#### 4.3.7 Reentrancy, Recursion & Ψ Invariants

Ψ invariants ensure:

1. Frame correctness

   * SP and FR define a consistent □-frame
   * saved registers are restored exactly once

2. Register preservation rules

   * Callee restores R4..R7
   * Caller handles R0..R3

3. Cross-role safety (Ω + Ψ)

   * Kernel never returns with user mode holding elevated capabilities
   * User frames never point into kernel segments

4. Isolation correctness (Χ + Ψ)

   * A function’s frame is inaccessible to other contexts unless explicitly shared

These are verifiable statically and dynamically.

---

#### 4.3.8 Summary

We defined a PMS-native calling convention:

* Arguments in `R0..R3`, return in `R0`.
* Frames are stack-based (□), created/destroyed via ∇ operations.
* Syscalls cross user/kernel boundaries via Φ + Ω.
* `EXC_RET` (Φ) restores context with Σ-like integration semantics.
* Ψ invariants maintain correctness, privilege safety, and isolation.

---

### 4.4 Interrupt & Trap Model (external events → Φ/Λ)

We formalize event-handling in PMS-CPU via Δ–Ψ operators:

* Interrupts → Φ
* Traps/syscalls → Φ + Ω
* Faults → Φ
* Timeouts / missing events → Λ
* Recontextualization → Φ
* Frame transitions → □
* Isolation → Χ
* Policies → Ψ

This yields a unified PMS event model.

---

#### 4.4.1 Structural Overview (Φ + Λ + Ω + □)

##### Φ (Recontextualization)

Used for:

* interrupts
* traps
* faults
* exception-level context shifts

Φ always implies:

1. entering a new □ context
2. possible role shift (Ω)
3. reinterpretation (Φ)
4. policy validation (Ψ)

##### Λ (Non-event)

Used when something expected does not occur.

Λ alone does not change □ or Ω.

---

#### 4.4.2 Event Sources

##### Asynchronous → Φ

* hardware interrupts
* inter-processor interrupts
* external signals

##### Synchronous traps → Φ

* TRAP instruction
* privileged operation in user mode
* breakpoints

##### Faults → Φ

* invalid frame access (□ violation)
* privilege errors (Ω)
* arithmetic faults

##### Non-events → Λ

* WAIT timeout
* scheduler idle

---

#### 4.4.3 Interrupt Vector Table (IVT) — Δ-indexed Φ dispatch

```text
IVT0 = reset
IVT1 = timer interrupt
IVT2 = device0 interrupt
...
```

Dispatch via Δ:

```asm
CMPI R_irq, irq
JMP  IVT + irq
```

Entry = Φ.

---

#### 4.4.4 Φ Entry Protocol

##### (1) Save interrupted context (∇)

```asm
PUSH PC
PUSH SR
PUSH FR
PUSH R4
PUSH R5
PUSH R6
PUSH R7
```

##### (2) Switch role (Ω)

```asm
SET_ROLE ROLE_KERNEL
```

##### (3) Switch frame (□)

```asm
FRM_ENTER FR_KERNEL_STACK
```

##### (4) Install meta (Φ)

Cause code, depth, etc.

##### (5) Jump to handler (Δ)

---

#### 4.4.5 Handler Execution

Handlers run in privileged □ + Ω environment, subject to Ψ invariants.

Typical tasks:

* acknowledge device
* update scheduler state (Θ)
* manipulate kernel data structures

---

#### 4.4.6 Φ Exit (EXC_RET)

```asm
SET_ROLE ROLE_USER        ; Ω
FRM_LEAVE                 ; □
POP R7
POP R6
POP R5
POP R4
POP FR
POP SR
POP PC
EXC_RET                   ; Φ
```

Ψ invariants apply on exit.

---

#### 4.4.7 Nested Interrupts

Allowed if:

```
SR.flags.interrupt_enable = 1
```

Each Φ entry:

* pushes a new □ frame
* increments nesting depth
* is limited by Ψ invariants

---

#### 4.4.8 Faults, Traps, Syscalls

| Condition            | PMS Op | Meaning                        |
| -------------------- | ------ | ------------------------------ |
| illegal opcode       | Δ      | misclassification → Φ          |
| invalid frame access | □      | frame violation → Φ            |
| privilege error      | Ω      | role violation → Φ             |
| syscall (TRAP)       | Φ + Ω  | controlled user → kernel entry |

---

#### 4.4.9 Timeouts / Λ

WAIT or SLEEP may produce Λ if expected readiness does not occur.

Λ can escalate to scheduler-level Φ:

```
Λ → Φ_scheduler
```

---

#### 4.4.10 Isolation (Χ) and Interrupts

If Χ is active:

* handler may not access isolated regions unless Ψ permits
* EXC_RET must not violate isolation boundaries

---

#### 4.4.11 Interrupt Priorities & Θ

Θ orders processing:

* higher priority interrupts preempt lower ones
* `m.time` tracks ordering
* Ψ may constrain allowed interleavings

---

#### 4.4.12 Summary

| Phenomenon      | PMS Op | Structural Meaning              |
| --------------- | ------ | ------------------------------- |
| Interrupt       | Φ      | asynchronous context shift      |
| Trap            | Φ + Ω  | controlled privilege transition |
| Fault           | Φ      | reinterpret invalid state       |
| Timeout         | Λ      | absence of expected event       |
| Return          | Φ + Σ  | context restore + commit        |
| Isolation       | Χ + Ψ  | access restrictions             |
| Priority/timing | Θ      | ordering constraints            |

---

### 4.5 Binary Encoding (opcode formats, immediates)

We define a binary encoding for PMS-CPU instructions that preserves Δ–Ψ tagging.

---

#### 4.5.1 Word Size & Endianness

* instruction width: 32 bits
* data memory: little-endian
* PC increments by 4 bytes unless redirected

---

#### 4.5.2 Top-Level Instruction Layout

```text
31           28 27          22 21      16 15       10  9        0
+---------------+--------------+----------+----------+-----------+
| PMS_OP (4)    | OPCODE (6)   | RD (6)   | RS1 (6)  | PAYLOAD   |
+---------------+--------------+----------+----------+-----------+
```

* PMS_OP = operator class (Δ…Ψ)
* OPCODE = subopcode
* RD, RS1 = registers
* PAYLOAD = immediate / offset / meta

---

#### 4.5.3 PMS Operator Tag Encoding

```text
PMS_OP (4 bits)
0000  Δ  
0001  ∇  
0010  □  
0011  Λ  
0100  Α  
0101  Ω  
0110  Θ  
0111  Φ  
1000  Χ  
1001  Σ  
1010  Ψ  
1011–1111 reserved
```

Decoder first distinguishes PMS_OP → structural dispatch.

---

#### 4.5.4 Register Encoding

Registers use 5 bits (0–31).

Logical model:

* R0–R7: GPRs
* R8–R15: reserved future expansion
* R16–R23: special/system registers
* R24–R31: reserved

PC/SP/FR/SR generally implicit in control instructions.

---

#### 4.5.5 Concrete Instruction Formats

We define 4 canonical formats:

* R-type – register–register
* I-type – register–immediate
* B-type – branch/jump
* S-type – system-level (Φ, Χ, Ψ, Ω, □, Σ)

##### 4.5.5.1 R-type

```text
31     28 27   22 21   17 16   12 11   7 6   0
+---------+-------+-------+-------+------+-----+
| PMS_OP  | OPC   |  rd   |  rs1  | rs2  |fun2 |
+---------+-------+-------+-------+------+-----+
```

##### 4.5.5.2 I-type

```text
31     28 27   22 21   17 16   12 11           0
+---------+-------+-------+-------+-------------+
| PMS_OP  | OPC   |  rd   |  rs1  |  imm12      |
+---------+-------+-------+-------+-------------+
```

##### 4.5.5.3 B-type

```text
31     28 27   22 21   17 16                        0
+---------+-------+-------+--------------------------+
| PMS_OP  | OPC   |  rs1  |         off17           |
+---------+-------+-------+--------------------------+
```

##### 4.5.5.4 S-type

```text
31     28 27   22 21   17 16   12 11           0
+---------+-------+-------+-------+-------------+
| PMS_OP  | OPC   |  rs1  |  rs2  |  sys12      |
+---------+-------+-------+-------+-------------+
```

---

#### 4.5.6 Encoding by Operator Family

Full mapping follows structure in 4.2.

---

##### 4.5.6.1 Δ — Distinction

Examples:

* `CMP` / `CMPI`
* `TST` / `TSTI`
* `BEQ` / `BNE` / `BGT` / `BLT` / etc.
* `JMP`
* `NDIF`

---

##### 4.5.6.2 ∇ — ALU / Memory / Control

Examples:

* `ADD`, `SUB`, `MUL`, `DIV`
* `ADDI`, `MOVI`
* `LOAD`, `STORE`
* `PUSH`, `POP`
* `CALL`, `RET`
* `IN`, `OUT`

---

##### 4.5.6.3 □ — Frames

Examples:

* `FRM_ENTER`
* `FRM_LEAVE`
* `FRM_SET`
* `FRM_CALL`

---

##### 4.5.6.4 Λ — Non-events

Examples:

* `WAIT`
* `POLL`
* `NOP_SEM`

---

##### 4.5.6.5 Α — Patterns

Examples:

* `PATTERN pid`
* `PATTERN pid, rs1, rs2`
* `LOOP_P pid, rs1`

---

##### 4.5.6.6 Ω — Roles / Capability

Examples:

* `SET_ROLE`
* `CHK_CAP`
* `ENTER_PRIV`
* `EXIT_PRIV`

---

##### 4.5.6.7 Θ — Ordering

Examples:

* `TICK`
* `SLEEP`
* `FENCE`
* `YIELD`

---

##### 4.5.6.8 Φ — Traps / Exceptions

Examples:

* `TRAP`
* `EXC_RAISE`
* `EXC_SET`
* `EXC_RET`
* `REFRAME`

---

##### 4.5.6.9 Χ — Isolation

Examples:

* `ISO_FORK`
* `ISO_ENTER`
* `ISO_EXIT`
* `ISO_RESTRICT`

---

##### 4.5.6.10 Σ — Integration

Examples:

* `TX_BEGIN`
* `TX_COMMIT`
* `TX_ABORT`
* `ATOMIC_ADD`
* `ATOMIC_CAS`
* `COMMIT_BARRIER`

---

##### 4.5.6.11 Ψ — Policy

Examples:

* `SET_POL`
* `CHK_POL`
* `CHK_ALL_POL`
* `HALT_IF_POL`

---

#### 4.5.7 Encoding of Special Registers

Some instructions treat PC/SP/FR/SR implicitly:

* `CALL`, `RET`, `PUSH`, `POP`, `EXC_RET`

Others use explicit registers:

* `FRM_SET` (FR update)
* `SET_ROLE` (SR.mode update)

This preserves compact encodings while keeping PMS semantics explicit.

---

#### 4.5.8 Invalid Encodings & Ψ/Δ Guards

Not every 32-bit pattern is valid:

* Some combinations of `PMS_OP + OPC` are unused → illegal instruction.
* Even valid opcodes may be disallowed by:
  * current role (Ω),
  * active policies (Ψ),
  * frame constraints (□).

We define:

* Illegal opcode detection as a Δ failure:
  * the bit pattern cannot be classified as a valid instruction.

This yields a Φ fault:

* EXC: illegal instruction,
* trapped into kernel handler.

Policy Ψ can further forbid certain encodings (e.g., TX in user mode) and trigger traps or halting.

---

#### 4.5.9 Example Encodings (Concrete Bitstrings)

Assume:

* `R1 = 00001`, `R2 = 00010`, `R3 = 00011`, `R0 = 00000`.

1. `ADD R1, R2, R3`:

* PMS_OP = ∇ = 0001  
* OPC (ADD) = 000000  
* rd = 00001  
* rs1 = 00010  
* rs2 = 00011  
* fun2 = 0000000  

Binary:

```text
0001 000000 00001 00010 00011 0000000
```

2. `TRAP #2`:

* PMS_OP = Φ = 0111
* OPC = 000000
* rs1, rs2 = 00000
* sys12 = 000000000010

Binary:

```text
0111 000000 00000 00000 000000000010
```

3. `SET_ROLE ROLE_KERNEL (id 1)`:

* PMS_OP = Ω = 0101
* OPC = 000000
* sys12 = 000000000001

Binary:

```text
0101 000000 00000 00000 000000000001
```

---

#### 4.5.10 Summary (Binary Encoding)

Section 4.5 provided:

* a 32-bit fixed encoding for PMS-CPU instructions,
* a 4-bit PMS_OP tag making Δ…Ψ semantics explicit at decode time,
* instruction formats (R/I/B/S) mapped to operator families,
* concrete OPC conventions for ALU, branches, traps, frames, roles, policies, transactions, isolation.

This allows:

* writing PMS-CPU machine code,
* feeding binaries into simulators and verification engines,
* mapping binaries back to operator-typed PMS-UM semantics.

---

### 4.6 PMS-CPU Execution Model (Fetch–Decode–Execute)

The purpose of 4.6 is to show how PMS-CPU executes machine code under Δ–Ψ rules, integrating:

* monoid constraints (2.3),
* operator-typed ISA (4.2),
* binary encoding (4.5),
* and the interrupt/trap model (4.4).

---

#### 4.6.1 High-Level Cycle

Each Θ-step drives a deterministic transition:

```
(s, PC) → (s', PC')
```

The full cycle:

1. Θ-step (ordering progression)
2. Δ-fetch
3. Δ-decode
4. Ω/Ψ validation
5. □ frame binding
6. operator execution (∇, Λ, Φ, Χ, Σ, …)
7. Σ auto-commit (if needed)
8. PC update
9. interrupt/trap check → Φ

---

#### 4.6.2 Step 1 — Θ: Ordering Step

At cycle start:

```
m ← T_Θ(m)
```

Effects in meta-state `m`:

* ordering markers,
* τ-based counters,
* pipeline/event markers,
* Λ pending signals.

---

#### 4.6.3 Step 2 — Δ-Fetch

```
instr = Mem[FR.code_base + PC]
```

Δ distinguishes without mutating state. It updates SR classification flags.

If fetch fails (□, Ω, Χ violation) → Φ trap.

---

#### 4.6.4 Step 3 — Δ-Decode

Δ identifies:

* PMS_OP,
* OPC,
* format (R/I/B/S),
* operand fields.

If PMS_OP invalid → Φ trap.

Decode creates:

```
I = (op, opcode, format, operands, payload)
```

---

#### 4.6.5 Step 4 — Ω / Ψ Pre-Check

##### Ω validation

```
Ω(s, I) = true  iff  role r permits op
```

Examples:

* ∇ STORE forbidden in user mode,
* Φ TRAP allowed in user mode,
* Σ TX_COMMIT privileged only.

##### Ψ validation

```
Ψ(s, I) = true  iff  policies P permit op
```

Policies may forbid syscalls, frames, transactions, etc.

Failure → Φ exception.

---

#### 4.6.6 Step 5 — □ Frame Binding

Compute:

```
f* = BindFrame(f, m, r)
```

Binding resolves:

* code frame,
* data frame,
* stack frame,
* isolation frame,
* transactional overlays.

□ does not mutate memory; it sets interpretation domains.

---

#### 4.6.7 Step 6 — Execute Operator Semantics

##### Δ (Distinction)

Reads, updates SR flags, may update PC for branches.

##### ∇ (Impulse)

Primary state mutation:

```
s_c' = A_∇(s_c, f*, r, operands)
```

Includes ALU, LOAD/STORE, CALL/RET, IO.

##### □ (Frame)

Updates frame state; mutates no memory.

##### Λ (Non-event)

Evaluates missing events/timeout conditions.

##### Α (Attractor)

Expands into Δ/∇/□/Θ micro-ops.

##### Ω (Asymmetry)

Updates role/capabilities; governed by Ψ.

##### Θ (Ordering)

Updates ordering meta; may trigger ∇ updates that read τ.

##### Φ (Recontextualization)

On explicit traps or failed checks:

1. save trap frame,
2. switch frame to handler,
3. update role,
4. set exception code,
5. jump to handler.

##### Χ (Isolation)

Creates isolated contexts; restricts visibility.

##### Σ (Integration)

Commits writes, merges isolation or transaction buffers.

##### Ψ (Policy)

Modifies policy set; enforces invariants; may halt.

---

#### 4.6.8 Step 7 — Σ Commit Phase

Inserted automatically when needed:

* after ∇ STORE in transactions,
* after isolation transitions,
* after Φ returns.

---

#### 4.6.9 Step 8 — PC Update

* normal instructions: `PC = PC + 4`
* branches: `PC = PC + (off << 2)`
* CALL: push return PC, set PC
* RET: pop PC
* Φ: PC = handler
* EXC_RET: pop PC
* HALT: PC = HALT state

---

#### 4.6.10 Step 9 — Interrupt/Trap Check

Checks:

* external interrupts,
* internal faults,
* τ-derived timer interrupts,
* isolation/transaction aborts,
* policy violations.

If pending and enabled → Φ before next cycle.

---

#### 4.6.11 Pipelined View (Optional)

Out-of-order execution:

* Δ-fetch/decode in pipeline,
* Ω/Ψ early checks,
* Χ/Σ reorder restrictions via Θ_FENCE,
* Ψ controls speculation.

Architectural semantics remain equivalent.

---

#### 4.6.12 Formal Execution Relation

```
(s, PC) → (s', PC')
```

One CPU step:

```
Θ
→ Δ_fetch
→ Δ_decode
→ (Ω ∧ Ψ) check
→ □ bind
→ op_execute
→ Σ auto
→ PC update
→ Φ interrupt-check
```

Dependencies obey the PMS monoid:

* Δ precedes ∇,
* Ψ/Ω constrain ∇,
* Φ can wrap any op,
* Σ follows ∇/Θ,
* Χ constrains access.

---

#### 4.6.13 Summary (Execution Model)

PMS-CPU execution is fully Δ…Ψ-typed:

* Ω privilege, Χ isolation, Ψ invariants,
* Θ ordering, Σ commit,
* Φ traps/recontextualization.

It refines PMS-UM semantics at the hardware level.

---

### 4.7 Memory Consistency Model

Defines memory ordering under PMS operator algebra.

---

#### 4.7.1 Memory Operations in PMS

* Δ = reads, classification
* ∇ = writes, LOAD/STORE, register updates
* Σ = commit, finalize writes
* □ = frame changes
* Θ = ordering steps, fences
* Χ = visibility domain changes
* Ψ = policy constraints

---

#### 4.7.2 Fundamental Ordering Dimensions

##### Axis A — Intrinsic Ordering (Δ→∇→Σ)

```
Δ ≺ ∇ ≺ Σ
```

##### Axis B — Θ Ordering

Θ defines happens-before boundaries.

##### Axis C — Χ / □ Visibility Domains

Isolation and frames define what is visible to whom and when.

---

#### 4.7.3 Baseline Consistency (PMS-SC)

Sequential consistency means all operators appear to execute in a total order respecting:

```
Δ ≺ ∇ ≺ Σ ≺ Θ
```

---

#### 4.7.4 Relaxed Consistency — Structural Relaxations

Relaxations arise by relaxing operator dependencies.

##### R1 – Out-of-Order Δ

Speculative reads → weak load semantics.

##### R2 – Delayed Σ

Store buffering.

##### R3 – Frame-based Reordering

Per-object/region reorderings via □.

##### R4 – Isolation-based Reordering

Transactions via Χ + Σ.

---

#### 4.7.5 Θ_FENCE (Barrier)

Θ_FENCE prevents reordering across a boundary.

---

#### 4.7.6 Happens-Before (HB)

HB is closure of:

* program order,
* Θ ordering,
* Σ visibility,
* Χ boundaries,
* Ψ constraints.

τ is data only.

---

#### 4.7.7 Example: TSO

* delayed Σ = write buffers
* speculative Δ = load bypass
* Θ_FENCE = acquire/release
* store→load reorder allowed
* store→store ordered via Σ

---

#### 4.7.8 Example: ARMv8-Style Weak Models

* Δ reordered unless Θ_FENCE
* Σ aggressively delayed
* Ψ enforces dependencies
* Θ fences encode ACQ/REL

---

#### 4.7.9 Example: Strong Transactional Memory

Χ + Σ + Ψ encode:

* transactional isolation,
* atomic commit,
* Φ abort.

---

#### 4.7.10 Example: Language-Level Models

| Language Concept   | PMS Operators                |
| ------------------ | ---------------------------- |
| seq_cst            | Ψ + Θ_FENCE(full)            |
| acquire            | Θ_FENCE(acquire)             |
| release            | Θ_FENCE(release)             |
| relaxed            | Δ/∇ w/out fences (Ψ governs) |
| atomic R/W         | ∇ + Ω capabilities           |
| atomic RMW         | ∇ + Σ                        |
| publication safety | Σ + Ψ                        |

---

#### 4.7.11 Summary (Memory Consistency)

The PMS memory model:

* derives directly from operator algebra,
* Δ/∇/Σ impose minimal ordering,
* Θ sequences,
* Χ and □ define visibility,
* Ψ enforces invariants.

Covers SC, TSO, ARM, POWER, TM, isolation, and language models.

---

## 5. PMS-OS Kernel Core

### 5.1 Kernel Goals & Trust Model (Ψ)

The PMS-OS kernel:

1. mediates Ω, □, Χ, Φ, Ψ transitions,
2. enforces Ψ-level invariants,
3. provides isolated, predictable execution contexts,
4. implements system services with PMS operators.

Everything reduces to Ω, □, Χ, Φ, Ψ.

---

#### 5.1.1 Kernel Trust Boundary (Χ + Ω + □)

Kernel context:

```
Context_kernel = (f = KF, r ∈ {KERNEL, SUPERVISOR}, X = global)
```

Kernel may:

* create/destroy user frames (□ + Χ),
* manage role transitions (Ω),
* install/update policies (Ψ),
* handle traps (Φ),
* perform Σ commits globally.

User processes enter kernel only via Φ and exit via Φ.

---

#### 5.1.2 Kernel Global Invariants (Ψ)

Let P_kernel be the kernel policy set.

##### Ψ₁ — Capability Correctness (Ω-consistency)

```
Ψ₁(s):  for all ∇ instructions I,
        requires_cap(I) ⊆ CapSet(r_s)
```

##### Ψ₂ — Frame Isolation (□ / Χ)

```
Ψ₂(s):  Addr ∈ VisibleFrames(f_s)
```

##### Ψ₃ — No Uncontrolled Privilege Escalation (Ω monotonicity)

```
USER → KERNEL only via Φ_trap
KERNEL → USER only via Φ_return
```

##### Ψ₄ — Policy Integrity

```
Ψ-mutating ops allowed iff r_s = KERNEL
```

##### Ψ₅ — Scheduling Fairness (optional)

```
∀ runnable process p:  p must eventually run
```

##### Ψ₆ — Safe Recontextualization (Φ correctness)

```
Φ(s) ⇒ s' satisfies Ψ₁…Ψ₅
```

Φ cannot violate Ψ invariants.

---

#### 5.1.3 Kernel Rights & Obligations (Operator-Level)

##### Rights: What the kernel may do

* Ω-rights:  
  assign, modify, or revoke roles and capabilities.

* □-rights:  
  create and manage frames (address spaces, kernel segments).

* Χ-rights:  
  create isolated domains (processes, containers, virtual machines).

* Φ-rights:  
  enter and leave any context; handle traps; define trap tables.

* Σ-rights:  
  commit global state (scheduling decisions, resource accounting, process tables).

* Ψ-rights:  
  define global invariants; halt or reframe configurations on violation.

##### Obligations: What the kernel must maintain

All kernel actions must preserve invariants:

```

Ψ(s_before) ⇒ Ψ(s_after)

```

The kernel cannot violate global invariants, except via controlled rollback governed by Φ and Σ.

Additional obligations:

* Monotonic isolation:

```

X_user ≼ X_kernel

```

User isolation cannot exceed kernel visibility.

* Frame/role integrity:

```

(f_user, r_user) never gain access to kernel frames

```

* Θ-scheduling integrity:  
  scheduling must follow Θ/Ψ policy (fairness, quotas, deadlines, etc.)

---

#### 5.1.4 Relation to PMS-CPU

PMS-CPU defines:

* registers, memory, frames, roles  
* trap and interrupt semantics (Φ)  
* isolation primitives (Χ)  
* policy checks (Ψ)  
* commit rules (Σ)

The kernel installs:

* process tables  
* Θ-based scheduling  
* memory allocator (□)  
* privilege architecture (Ω)  
* syscall interface (Φ)  
* isolation semantics (Χ)  
* global policies (Ψ)

Thus the kernel is a privileged PMS program configuring CPU operator algebra into a multiprocess system.

---

#### 5.1.5 Kernel as a Persistent Φ-Handler

Kernel entry occurs via:

* syscalls (user → kernel)  
* interrupts (device → kernel)  
* exceptions (fault → kernel)

These are Φ transitions that:

1. rebind frame, role, isolation:  
```

(f_user, r_user, X_user) → (KF, KERNEL, X_global)

```
2. execute kernel logic (∇ / □ / Ω / Θ / Σ)  
3. return via Φ:

```

(KF, KERNEL, X_global) → (f_user, r_user, X_user)

```

Kernel operation is Φ-centered.

---

#### 5.1.6 Kernel Process Model: Trust Structure (Preview)

Each user process has:

* its own frame set (□)  
* its own isolation domain (Χ)  
* its own restricted role (Ω)  
* its own local policies (P_local), subordinate to P_global (Ψ)

The kernel:

* creates/destroys processes (□ + Χ)  
* schedules via Θ  
* commits context switches and accounting (Σ)  

Processes cannot:

* modify forbidden frames  
* escalate roles (Ω)  
* break isolation (Χ)  
* bypass policy (Ψ)  
* enter kernel except via Φ

---

#### 5.1.7 Summary (Kernel Trust Model)

The kernel trust model is defined by PMS operators:

* Ψ — invariants  
* Ω — privilege roles  
* □ — frames  
* Χ — isolation  
* Φ — trap/entry/exit  
* Σ — integration/commit  
* Θ — scheduling order  
* Δ/∇ — logic/action level

This unifies protection, scheduling, isolation, syscalls, traps, and resource control.

---

### 5.2 Core Data Structures (PProcess, Frame, Policy, Message)

Kernel state uses operator-aligned data structures.

---

#### 5.2.1 PProcess (Praxeological Process Control Block)

```

PProcess = (id, f, r, X, P_local, regs, meta)

```

* `id` — unique PID  
* `f` — current frame (□)  
* `r` — role (Ω)  
* `X` — isolation domain (Χ)  
* `P_local` — local policies, constrained by P_global (Ψ)  
* `regs` — saved registers (PC, SP, FR, SR, GPRs)  
* `meta` — Θ scheduling counters, τ accounting data, Φ flags, Λ waits, Σ cleanup metadata

---

#### 5.2.2 Frame

```

Frame = (id, base, size, type, perms, owner, links)

```

* `id` — frame identifier  
* `base`, `size` — memory bounds  
* `type` — CODE, DATA, STACK, MMIO, DEVICE, USER, KERNEL  
* `perms` — read/write/exec/map/share  
* `owner` — process owning frame  
* `links` — shared frames, clone links, IPC mappings, etc.

Frames are the □ abstraction.

---

#### 5.2.3 Policy

A policy:

```

Policy = (id, scope, predicate, action)

```

* `scope` — global / per_process / per_frame / per_role  
* `predicate` — boolean over kernel state  
* `action` — Φ or Σ or combined response when violated

Policies enforce Ψ invariants.

---

#### 5.2.4 Message (IPC Primitive)

```

Message = (id, sender, receiver, type, payload, meta)

```

* `type` — REQ, RESP, EVT, CTRL, SIG, TIMEOUT  
* `meta` — Θ/Λ semantics, Ω capabilities, Χ visibility, deadlines in τ, Σ guarantees

---

#### 5.2.5 Summary Table

| Structure    | PMS Operators       | Purpose                              |
| ------------ | ------------------- | ------------------------------------ |
| PProcess     | Ω, □, Χ, Θ, Φ, Σ, Ψ | Process identity and execution state |
| Frame        | □, Ω, Χ             | Memory and execution context         |
| Policy       | Ψ, Ω, Φ, Σ          | Invariants and safety rules          |
| Message      | Δ, Ω, Λ, Θ, Φ, Σ    | Kernel IPC                           |

---

### 5.3 Process & Thread Model (states, transitions, roles)

---

#### 5.3.1 Conceptual Overview

A process is a persistent combination of:

* frame environment (□)  
* role constraints (Ω)  
* isolation boundary (Χ)  
* policies (Ψ)

A thread is a Θ-scheduled execution strand performing Δ and ∇, subject to Φ, Χ, Σ, Ψ.

---

#### 5.3.2 Kernel-Level Representation

```

PProcess = (id, f, r, X, P_local, regs, meta)

```
```

Thread = (tid, parentPID, regs, state, Θ_budget, meta)

```

Threads inherit the process’s □, Ω, Χ, Ψ.

---

#### 5.3.3 Thread States (PMS-Aligned)

| State       | Operators      | Meaning                                  |
| ----------- | -------------- | ---------------------------------------- |
| READY       | Δ, Θ           | Ready for Θ dispatch                     |
| RUNNING     | ∇, Θ           | Executing ∇ steps                        |
| BLOCKED     | Λ, Φ           | Waiting for event or trap handling       |
| SUSPENDED   | Χ, Ω           | Blocked by isolation/role restrictions   |
| ZOMBIE      | Σ              | Terminated but not yet integrated        |
| TERMINATED  | Σ + Ψ          | Final state, resources reclaimed         |

Definitions:

READY:

```

ready(t) := Δ(t) ∧ ¬Λ(t) ∧ ¬Φ(t) ∧ Ψ_allow(t)

```

BLOCKED:

```

BLOCKED := Λ_pending(t) ∨ Φ_pending(t)

```

SUSPENDED:

```

SUSPENDED := X_restriction(t) ∨ Ω_deny(t)

```

ZOMBIE:

```

ZOMBIE := Σ_pending(t)

```

TERMINATED:

```

TERMINATED := Σ_done(t) ∧ Ψ_close(t)

```

---

#### 5.3.4 Process States

| Process State | Condition                             |
| ------------- | ------------------------------------- |
| RUNNING       | at least one RUNNING thread           |
| READY         | threads READY, none RUNNING           |
| BLOCKED       | all threads BLOCKED                   |
| SUSPENDED     | all threads suspended by Χ/Ω          |
| ZOMBIE        | finished threads, not integrated      |
| TERMINATED    | all threads TERMINATED, Σ/Ψ complete  |

---

#### 5.3.5 State Transition Rules

READY → RUNNING (Θ):

```

(READY, Θ) → RUNNING

```

RUNNING → READY (quantum expiry):

```

RUNNING ─Θ_expire→ READY

```

RUNNING → BLOCKED:

```

RUNNING ─Λ→ BLOCKED
RUNNING ─Φ→ BLOCKED

```

BLOCKED → READY:

```

BLOCKED ─(¬Λ)→ READY

```

RUNNING → SUSPENDED:

```

RUNNING ─Ω_restrict→ SUSPENDED
RUNNING ─X_enter→ SUSPENDED

```

SUSPENDED → READY:

```

SUSPENDED ─Ω_allow→ READY

```

RUNNING → ZOMBIE:

```

RUNNING ─Σ_pending→ ZOMBIE

```

ZOMBIE → TERMINATED:

```

ZOMBIE ─(Σ_complete ∧ Ψ_close)→ TERMINATED

```

---

#### 5.3.6 Role and Capability Semantics (Ω)

Ω governs:

* privilege levels  
* allowed syscalls  
* allowed frames  
* allowed isolation scopes  
* allowed policy modifications  

Role transitions are only allowed via Φ or kernel Ω ops.

---

#### 5.3.7 Isolation Semantics (Χ)

Χ governs:

* memory visibility  
* namespace visibility  
* device mapping  
* IPC boundaries  

Operations:

```

X_enter(ctx)
X_exit

```

---

#### 5.3.8 Ordering Semantics (Θ)

Θ governs:

* dispatch ordering  
* preemption points  
* quanta boundaries (τ as data)  
* wake-ups based on Λ  
* enforcement of Ψ scheduling rules  

Each execution step:

```

Δ → ∇ → Θ

```

Scheduling is:

```

Θ_schedule: select(t) → context_switch → RUNNING

```

---

#### 5.3.9 Exception & Trap Semantics (Φ)

Φ handles:

* faults  
* illegal ops  
* privilege violations  
* page faults  
* explicit traps  

State transition example:

```

RUNNING ─Φ_pagefault→ BLOCKED
BLOCKED ─Φ_resume→ READY

```

---

#### 5.3.10 Integration Semantics (Σ + Ψ)

Σ disposes resources and integrates final state.

Ψ finalizes accounting and lifecycle policies.

Process ends when:

```

∀ t ∈ Threads(P): TERMINATED(t)

```

---

#### 5.3.11 Summary (Process & Thread Model)

Processes = □, Ω, Χ, Ψ  
Threads   = Θ, Δ, ∇, Φ, Σ, Λ  

This yields a complete operator-typed execution hierarchy.

---

### 5.4 Scheduling (Θ) – algorithms & policies

Scheduling = Θ-mediated selection of ∇-capable execution loci under Ψ, Ω, Χ constraints.

---

#### 5.4.1 Core Idea

Scheduler is Θ-rooted:

```

Θ: ReadySet → SelectedThread

```

Execution:

```

Θ_schedule → Δ → ∇ → Θ → …

```

---

#### 5.4.2 Scheduler State

```

m_sched = (rq, rq_prio, τ_sched, history, fairness_tokens)

```

* `rq` — ready queue  
* `rq_prio` — optional priority queues  
* `τ_sched` — τ slice: quanta, deadlines, wait timeouts  
* `history` — Δ/∇ patterns  
* `fairness_tokens` — Ψ_fair quotas  

---

#### 5.4.3 Scheduler Interface as Operators

##### Θ.enqueue(t)

Add thread t to READY queue.

##### Θ.dequeue(t)

Remove t from scheduling set.

##### Θ.select() → t

Choose the next thread.

##### Θ.dispatch(t)

Context switch:

1. save old thread state (Σ-partial)  
2. switch frame (□)  
3. switch role (Ω) if needed  
4. update instruction pointer  
5. set t to RUNNING

##### Θ.tick()

Advance scheduling position:

* update τ_sched counters  
* check deadlines  
* handle Λ timeouts  
* trigger preemption

---

#### 5.4.4 Context Switch (Θ + Σ + □ + Ω)

A context switch is a Θ-triggered Σ integration of the outgoing thread’s transient ∇ actions, followed by reassignment of □ and Ω to the incoming thread.

Formally:

```

Θ_switch(t_old, t_new) =
Σ_save(t_old)
;◦;
□_set(frame(t_new))
;◦;
Ω_set(role(t_new))
;◦;
Θ_start(t_new)

```

Meaning:

* Θ orchestrates ordering.
* Σ commits and freezes the outgoing thread’s partial execution.
* □ selects the new frame.
* Ω sets the correct role/capability track.
* No ∇ occurs except internal to Σ-save and frame setup.

---

#### 5.4.5 Scheduling as a PMS Automaton

Scheduling transitions form the following structural automaton:

```

(RQ, t, m_sched)
─Θ_select→
(t, RUNNING)
─Θ_quantum_expire→
READY

```
```

RUNNING ─Λ→ BLOCKED
BLOCKED ─(¬Λ)→ READY
RUNNING ─Ω_restrict→ SUSPENDED
SUSPENDED ─Ω_allow→ READY

```

This matches 5.3’s thread state machine, with Θ driving all transitions.

---

#### 5.4.6 Scheduling Algorithms in Θ-Form

##### (A) Round-Robin

```

Θ_select := Θ_rr(rq, ptr)

```

`ptr` is a rotating index in scheduler meta-state `m`.

Preemption:

```

if τ_sched.quantum(t) = 0  ⇒  Θ_switch

```

##### (B) Priority Scheduling (Ω + Θ)

Ω defines priority asymmetry.

```

Θ_select(rq_prio) :=
pick highest-Ω queue with READY threads

```

Preemption:

```

Ω(t') > Ω(t)  ⇒  Θ_switch(t → t')

```

##### (C) Weighted Fairness (Ψ_fair + Θ)

Ψ_fair invariant:

```

For all t:
if ready(t) infinitely often ⇒ scheduled(t) infinitely often

```

Fairness selection:

```

Θ_select(rq) := argmax_t fairness_tokens(t)

```

##### (D) Real-Time Scheduling (deadlines in τ + Θ)

EDF:

```

Θ_select(rq) := argmin_t deadline(t)

```

Rate Monotonic:

```

Ω_RM(t) := 1 / period(t)
Θ_select := argmax_t Ω_RM(t)

```

##### (E) Hierarchical Scheduling (Ω + Ψ + Θ)

```

Θ_select = Θ(Ω-groups → Ψ-constraints → rq)

```

---

#### 5.4.7 Handling Timeouts & Missing Events (Λ)

Blocking:

```

RUNNING ─∇(wait)→ BLOCKED

```

Timeout:

```

BLOCKED ─Λ_timeout→ READY

```

Event arrival:

```

BLOCKED ─(¬Λ)→ READY

```

Timeout condition:

```

Λ_timeout := (τ.now ≥ τ.wait_deadline)

```

---

#### 5.4.8 Hyper-scheduling and Isolation (Χ)

Separate isolation domains:

```

Χ: domain_i ⟂ domain_j

```

Each has its own Θ instance:

```

Θ_i, Θ_j : independent schedulers

```

Used for:

* VM schedulers  
* containers  
* per-core queues  
* real-time vs normal classes

Χ determines whether Θ_i may observe or influence Θ_j.

---

#### 5.4.9 Scheduler Policy Engine (Ψ_s)

Ψ_s enforces:

* no starvation  
* max-latency rules  
* CPU share limits  
* isolation constraints  
* guaranteed minimum service  

Evaluation:

```

Ψ_s(sched_state, t) = true/false

```

Violation effects:

```

Ψ_s violation ⇒
(t stays READY but unselectable)
or (t → SUSPENDED)
or (Φ → recontextualization)
or (t → TERMINATED)

```

---

#### 5.4.10 Preemption Model (Θ + Φ)

Preemption:

```

RUNNING(t) ─Θ_preempt→ READY(t)

```

Causes:

* register save (Σ-save)  
* optional Φ handling  
* Θ_select chooses next thread  

Form:

```

Θ_preempt ∈ {
Θ_quantum_expire,
Ω_priority_intrusion,
Φ_interrupt,
Ψ_policy_trigger
}

```

---

#### 5.4.11 The PMS Scheduling Equation

A full scheduling cycle:

```

Θ_tick
;◦;
Θ_update_queues
;◦;
Θ_select
;◦;
Θ_dispatch
;◦;
(Δ ; ∇)*
;◦;
Θ_yield_or_preempt

```

Must satisfy:

```

Ψ(whole_system) = true

```

---

#### 5.4.12 Summary (Scheduling)

Θ controls:

* which thread runs  
* when and for how long  
* privilege transitions (Ω)  
* frame context (□)  
* isolation (Χ)  
* event/timeout transitions (Λ)  
* trap transitions (Φ)  
* commit integration (Σ)  
* policy enforcement (Ψ)  

Θ is the structural backbone of kernel execution.

---

### 5.5 Isolation & Protection (Χ, Ω)

Isolation (Χ) and privilege (Ω) define:

* who may act  
* where they may act  
* under which constraints (Ψ)  

Isolation is a structural operator transformation, not a heuristic.

---

#### 5.5.1 Core Idea: Isolation = Χ applied to □-contexts

A process is a frame (□) with:

* memory view  
* namespace  
* permitted operations  

Χ establishes the isolation boundary:

```

χ: □_i → (□_i, □_j)_isolated

```

---

#### 5.5.2 Role of Ω

Ω defines access asymmetry:

```

Ω(f_i, r) = allowed action set in frame f_i

```

Ω:

* assigns privilege levels  
* assigns capabilities  
* defines directional access rules  

Combined with Χ → capability-based access architecture.

---

#### 5.5.3 Kernel Isolation Structure

Kernel privilege:

```

Ω(kernel) > Ω(user)

```

Isolation:

```

χ(□_user, □_kernel) = strict separation

```

This yields:

* kernel may read user memory  
* user may not read/write kernel memory  

---

#### 5.5.4 Memory Protection Rules

Memory regions:

```

Mem = {R1, R2, ...}
owner(Rk) = f_i

```

Access rule:

```

AccessAllowed(p, Rk)
⇔ Ω(r_p) ▷ owner(Rk)
∧ no Ψ violation
∧ no Χ barrier

```

Memory operations use ∇:

```

∇_read/write(p, Rk) requires Ω-permission and no χ-barrier

```

---

#### 5.5.5 Isolation Graph (Χ)

```

G_iso = (F, E)

```

Χ enforces absence of edges:

```

χ(f_i, f_j) = true  ⇒  (f_i, f_j) ∉ E

```

Isolation is explicit graph pruning.

---

#### 5.5.6 Address Spaces as Frames

```

VAS(p) = □_p
map_p: VAS(p) → PhysicalMem

```

Validity:

```

∇_read/write(addr) valid iff Ω(r_p) ▷ map_p(addr)

```

Isolation block:

```

χ(□_p, region) ⇒ block ∇ precondition

```

---

#### 5.5.7 Capability System (Ω)

Capability structure:

```

C = (target_frame, allowed_ops, scope)

```

Role with capabilities:

```

r_t = r_base ∪ {C1, ..., Cn}

```

Ω operators:

```

Ω.grant(C)
Ω.revoke(C)
Ω.check(op, f_j)

```

---

#### 5.5.8 Memory Isolation Example

Isolation:

```

□_user ⟂ □_kernel
□_user ⟂ □_driver

```

Valid:

```

kernel : ∇_read(VAS_user)

```

Invalid:

```

user : ∇_write(VAS_kernel)

```

Because χ denies, Ω forbids, Ψ enforces.

---

#### 5.5.9 Syscall Entry (Χ → Ω Reconfiguration)

Syscall sequence:

```

Δ
; Φ
; Ω
; □
; ∇*
; Σ
; □⁻¹
; Ω⁻¹

```

Meaning:

1. Δ classify syscall  
2. Φ enter kernel  
3. Ω switch to kernel role  
4. □ switch to kernel frame  
5. ∇ perform kernel work  
6. Σ integrate  
7. restore □, Ω  

---

#### 5.5.10 Cross-Process Isolation (Χ) + IPC Gates

IPC requires explicit bridges:

```

Bridge(f_i, f_j)

```

No spontaneous cross-frame access:

```

χ(f_i, f_j) ⇒ no Δ/∇/□ access

```

Shared memory creation:

```

Δ → Ω.grant → Σ.commit → update isolation graph

```

---

#### 5.5.11 File System Isolation

Frames as namespaces:

* each mount = □-frame  
* subtree = sub-frame  

Isolation:

```

χ(□_container1, □_container2)

```

---

#### 5.5.12 Device Driver Protection

Drivers isolated via Χ:

* MMIO frames  
* DMA regions  
* device registers  

Ω restricts what drivers may touch.

---

#### 5.5.13 Ψ Tightens Isolation

Ψ enforces:

* mandatory access control  
* namespace rules  
* no-exec regions  
* sandboxing  

Violation:

```

Ψ(s) = violation ⇒ s → S_H

```

Halt/kill transition.

---

#### 5.5.14 Summary (Isolation & Protection)

* Χ = isolation boundaries  
* Ω = capability/privilege  
* Ψ = invariants  
* □ = spatial context  
* ∇ = action subject to constraints  

This yields a strict capability/security architecture.

---

### 5.6 Kernel Policy Engine (Ψ)

Ψ is the kernel’s constraint operator over all Δ, ∇, □, Ω, Θ, Φ, Χ, Σ transitions.

The Kernel Policy Engine (KPE):

```

KPE = (PSet_k, Eval_Ψ, Hooks, Actions)

```

---

#### 5.6.1 Goals & Structural Role

Ψ:

* unifies all security/governance rules  
* expresses rules as constraints over operator transitions  
* remains orthogonal to functional operation  

---

#### 5.6.2 Policy Objects and State

```

struct Policy {
PolicyId        id;
PolicyScope     scope;
PolicyMode      mode;
PolicyPriority  priority;
PolicyExpr      expr;
PolicyActions   actions;
}

```

Scopes:

* GLOBAL  
* FRAME(f)  
* PROCESS(pid)  
* ROLE(r)  
* OBJECT(obj_id)  

Policy expressions are declarative predicates over:

* actor  
* target  
* operator class  
* context  
* simplified history  

---

#### 5.6.3 Policy Hooks

##### Δ-hooks

For branching decisions:

* syscall dispatch  
* IPC routing  
* FS path decisions  
* scheduling choices  

##### ∇-hooks

Before mutations:

* memory writes  
* resource creation  
* capability changes  
* frame mapping  

##### □ / Χ hooks

Frame/isolation transitions:

* context switching  
* mount/sandbox transitions  
* namespace switching  

##### Ω hooks

Role/capability changes:

* privilege escalation  
* impersonation  
* kernel entry  

##### 5.6.3.1 Δ-hooks (distinction / decision)

Places where the system chooses among branches:

* syscall dispatch
* IPC routing decisions
* scheduling decisions (pick next thread)
* FS decisions (follow symlink? mount namespace crossing?)

Δ-hooks allow policies like:

* “deny any syscall from ROLE_GUEST to open() / exec()”
* “for this process, rewrite open(path) to chrooted path”

##### 5.6.3.2 ∇-hooks (state-changing actions)

Before a **mutating operation** executes:

* write to memory / file / socket
* change role / capabilities
* launch a process or clone a thread
* change frame mappings (VM operations)

Ψ can veto or rewrite ∇:

* “deny writes to /etc/* from non-privileged processes”
* “log any ∇ creating network connections with dest outside domain X”

##### 5.6.3.3 □ / Χ hooks (frame/isolation changes)

Important logic when:

* switching address spaces (context switch)
* creating new frames (fork, container, VM)
* entering / exiting isolation (sandbox, chroot, namespace)

Policies:

* “this role cannot join any frame other than these whitelisted frames”
* “containers of type A must never mount B”

##### 5.6.3.4 Ω hooks (role / capability changes)

Any change to **who you are**:

* acquiring or dropping capabilities
* switching from user to kernel mode (trap)
* assuming a new principal identity

Policies:

* “unprivileged processes cannot gain network capability”
* “service X may only impersonate users with label Y”

##### 5.6.3.5 Θ / Λ hooks (ordering and τ-based timeouts)

Scheduling and τ-based timing:

* when Θ advances its ordering step and triggers τ-related updates (sampling timer sources),
* when Λ signals a timeout or idle condition based on τ.

Policies:

* “this process must not exceed N CPU ticks in interval T (T stored in τ)”
* “idle tasks must not starve runnable policy-critical tasks”

##### 5.6.3.6 Φ hooks (exceptions, traps, context shifts)

Triggered when:

* entering kernel via trap,
* faults occur,
* returning to user space.

Policies:

* “on fault F from process with label X, kill process”
* “redirect exceptions to debugging monitor”

##### 5.6.3.7 Σ hooks (commit / integration)

Triggered at commit boundaries:

* filesystem transactions,
* network packet transmission,
* process state commit (after exec).

Policies:

* “commit only if integrity tags match”
* “log every Σ touching high-value resources”

---

#### 5.6.4 Policy Evaluation Pipeline

At every hook:

```

(state s, operation op, context c) ->Eval_Psi-> decision

```

Steps:

##### (1) Collect context (Δ over state)

Collect minimal info:

* actor: pid, tid, role, labels
* target: frame, object id, path, address
* op type: PMS operator class + concrete action (e.g. ∇/WRITE)
* current mode and τ-extracted data
* call-stack tags or subsystem tags

##### (2) Select relevant policies (Δ over PSet_k)

```

P_relevant = { policy_1, ..., policy_n }

```

Ordered by policy priority.

##### (3) Evaluate predicates (Ψ)

For each policy:

```

result_i = Eval(policy_i.expr, s, op, c)

```

Possible results:

* ALLOW
* DENY
* MODIFY
* DEFER
* LOGONLY
* ESCALATE

##### (4) Combine results (resolution)

```

Combine: [result_i] -> final_decision

```

Possible outcomes:

* FINAL_ALLOW(op')
* FINAL_DENY(reason)
* FINAL_ESCALATE(destination)

##### (5) Act on decision (enforcement)

Handled by Ψ.

---

#### 5.6.5 Enforcement Actions (What Ψ Can Do)

1. Allow  
   Proceed unchanged.

2. Modify  
   Rewrite op parameters (path rewrite, permission downgrade, frame remap).

3. Deny / Block  
   Return error or trigger Φ.

4. Kill / Isolate

```

chi' : square_p -> square_p_quarantined

```

5. Log / Audit (Θ + Σ)  
   Commit audit records via Σ.

6. Escalate  
   Notify governance layer.

---

#### 5.6.6 Policy Lifecycle (Load, Update, Revoke)

##### 5.6.6.1 Policy creation

```

Psi_CREATE(policy_spec) -> PolicyId

```

##### 5.6.6.2 Policy update

```

Psi_UPDATE(PolicyId, new_spec)

```

##### 5.6.6.3 Policy disable / remove

```

Psi_SET_MODE(PolicyId, mode)
Psi_DELETE(PolicyId)

```

##### 5.6.6.4 Boot-time Ψ

Loads minimal mandatory safety policies, then site-specific ones.

---

#### 5.6.7 Performance & Caching

##### 5.6.7.1 Policy indexing

Indexed by scope and operator class.

##### 5.6.7.2 Decision caching

```

CacheKey = (actor_id, role, op_type, object_id, coarse_context)
CacheVal = decision_summary

```

##### 5.6.7.3 Fastpaths

```

If FastPathPre(s, op) then allow immediately

```

---

#### 5.6.8 Compositional Policies (Stacking Ψ)

```

P_eff(subject) = Combine(P_global, P_role, P_frame, P_process, P_object)

```

Hierarchy:

```

Psi_total = Psi0 AND Psi1 AND Psi2 AND Psi3

```

---

#### 5.6.9 Interaction with PMSL, Tooling & Verification

Ψ integrates with policy DSL, IR tagging, static analysis, model checking, and observability.

---

### 5.7 Syscall Interface – Taxonomy, Calling, Semantics

Syscalls are structured composites:

1. Φ – kernel entry  
2. Ω – privilege adjustment  
3. Δ – identification  
4. Ψ – policy evaluation  
5. ∇/□/Χ/Θ/Σ – operation  
6. Σ/Φ – commit and exit  

---

#### 5.7.1 Syscall Taxonomy

##### Δ-class
stat, getpid, resolve

##### ∇-class
write, sendmsg, chmod, create/unlink

##### □-class
mmap, mprotect, exec, chroot

##### Ω-class
setuid, capset

##### Θ-class
scheduler and ordering controls

##### Φ-class
syscall entry, execve

##### Χ-class
unshare, clone(new namespace)

##### Σ-class
fsync, sync, checkpoint

##### Ψ-class
policy management

##### τ-related
nanosleep, timers, clock reads

---

#### 5.7.2 Syscall Calling Convention

```

TRAP syscall_id

```

Registers:

* R0 = syscall_id  
* R1–R5 = args  
* return in R0  

---

#### 5.7.3 Syscall Semantics

```

Phi -> Omega -> Delta -> Psi -> (nabla | square | chi | Theta | Sigma) -> Psi -> Phi

```

##### Phase 1: Trap Entry (Φ)

##### Phase 2: Validate identity (Δ)

##### Phase 3: Check arguments (Δ + Ω + Ψ)

##### Phase 4: Execute (∇ / □ / Χ / Θ / Σ)

##### Phase 5: Exit (Φ + Σ)

---

#### 5.7.4 Canonical Syscall Template

```

Pre:
Delta: identify op + args
Omega: capability checks
Psi: policy checks

Body:
square: frame operations
nabla: mutations
chi: isolation
Theta: ordering semantics
Sigma: commit

Post:
Psi: invariants
Phi: return

```

---

#### 5.7.5 Example Syscalls

##### write(fd, buf, len)

Pre: Δ classify, Ω permission, Ψ rules  
Body: ∇ write, ∇ τ accounting, Σ commit/defer  
Post: Ψ post-conditions, Φ return

##### mmap(addr, size, flags)

Pre: Δ classify, Ω permission, Ψ mapping rules  
Body: □ map, Χ isolate, Σ commit  
Post: Φ return

##### execve(path, argv)

Pre: Δ classify, Ψ exec policies  
Body: Σ flush, □ new frame, ∇ load, Φ reframe  
Post: Ψ validate

---

#### 5.7.6 Syscall Table Structure

```

struct SyscallEntry {
SyscallId id;
SyscallHandler handler;
PolicyMask   policy_requirements;
RoleMask     allowed_roles;
FrameMask    allowed_frames;
OperatorClass op_class;
}

```

---

#### 5.7.7 Syscall Interface as PMS Contract

```

Phi ; Omega ; Delta ; Psi ; (nabla | square | chi | Theta | Sigma) ; Psi ; Phi

```

---

### 5.8 Resource Accounting & Quotas

Representation uses Δ, Ω, τ, ∇, Σ, Θ, Ψ, Λ.

---

#### 5.8.1 Goals

1. deterministic accountability  
2. Ψ-governed allocation  
3. Χ-based isolation  
4. Θ + τ temporal fairness  
5. Λ/Φ graceful degradation  
6. Σ/Ψ auditability  

---

#### 5.8.2 Resource Frame (RF)

```

RF = (cpu, mem, ipc, storage, net, policy, limits)

```

Kernel storage:

```

struct ResourceFrame {
CPUUsage      cpu;
MemUsage      mem;
IPCUsage      ipc;
StorageUsage  storage;
NetUsage      net;
RoleMask      owner_roles;
PolicyMask    active_policies;
ResourceLimits limits;
}

```

---

#### 5.8.3 CPU Accounting (τ + Θ + Σ + Ψ)

CPU usage is recorded in τ as accounting data; Θ orders the execution steps along which τ is sampled and updated.

##### Mechanism

On each scheduler tick (a Θ-ordered step that triggers sampling):

1. ∇: read `τ.now` (or an equivalent τ-based CPU clock) and compute the quantum attributed to the current thread.
2. ∇: increment `RF.cpu.used += quantum` in τ’s accounting fields associated with the thread’s RF.
3. Σ: commit usage into the persistent accounting structures (for example, aggregate `τ.cpu_used(p)`).
4. Ψ: verify limits formulated over these τ-based counters.

If a limit is violated:

* Ψ triggers either:

  * downgrade priority (Ω change),
  * throttling via scheduling decisions (Θ no longer selects `t` as often),
  * SIGXCPU-like trap (Φ),
  * suspension or kill (transition to exit state via Φ + Σ).

##### CPU Quota Models

We support both hard and soft limits:

| Type       | Operator Interpretation                                                                         |
| ---------- | ----------------------------------------------------------------------------------------------- |
| Soft limit | Θ continues to order execution; Ψ triggers warnings or lowered priority (Ω shift).              |
| Hard limit | Ψ forbids further Θ selections that would advance ∇ for this RF; Φ transitions to fail context. |

##### Per-Frame + Per-Role Attribution

If a process switches role (Ω), CPU usage in the RF is partitioned by role.

This supports kernel-level billing (“who consumed what in which privilege mode”) via `τ.cpu_used` entries indexed by `(frame, role)`.

---

#### 5.8.4 Memory Accounting (∇ + Σ + Ψ + Χ)

Memory actions use:

* ∇ — for actual allocation/deallocation
* □ — switching address spaces
* Χ — isolation boundaries (protection domains)
* Ψ — limit + policy enforcement

##### Memory Allocation Workflow

When user code calls `mmap`, `brk`, or allocation occurs inside a runtime:

1. Δ: classify the region request.
2. Ω: verify capability to allocate.
3. Ψ: check limits (for example, `RF.mem.used < RF.mem.max`).
4. ∇: perform allocation.
5. Σ: commit accounting update (for example, `RF.mem.used` and corresponding τ-backed summaries if desired).

##### Memory Quota Violations

If `RF.mem.used > RF.mem.max`:

* Φ: throw exception (OOM-like recontextualization),
* Ψ: optional kill/restart policy,
* Λ: represent “allocation failure” (no successful allocation event occurred).

##### Isolation Guarantees (Χ)

Memory of different frames never overlaps unless policy permits.

Isolation is enforced via:

* per-frame page tables,
* Ω-driven capability sets,
* Ψ rules: “user code cannot map kernel pages”, “no execute on writable pages”, and similar constraints.

---

#### 5.8.5 IPC Accounting (Δ + Ω + Σ + Ψ + Λ + τ)

IPC (queues, channels, ports, sockets) is resource-consuming because:

* buffers occupy memory,
* message sends/receives consume kernel operations,
* flows may be rate-limited over τ-measured intervals.

##### IPC Send Operation Accounting

Sending a message triggers:

1. Δ: classify destination port/channel.
2. Ω: verify send capability.
3. Δ: measure message size.
4. Ψ: check message-size and message-rate limits (formulated over τ-based counters, for example “bytes per τ-window”).
5. ∇: enqueue into IPC buffer.
6. Σ: commit size/time counters (for example, update `RF.ipc.used` and a τ-backed rate counter such as `τ.ipc_rate[p]`).

##### IPC Receive Accounting

Receiving a message:

* Δ: inspect availability.

* Λ: if none available (non-blocking receive, Λ = “no-message” event).

* For blocking receive, Λ_timeout is defined via τ:

  ```text
  Λ_timeout := (τ.now >= τ.deadline_recv) AND (NOT event(msg_arrival))
  ```

* Σ: count receive operations and update τ-backed statistics.

##### IPC Quotas

`RF.ipc` contains fields such as:

* `max_message_bytes`,
* `max_queue_bytes`,
* `max_messages_per_second` (interpreted via τ windows),
* `max_outstanding_requests`.

Violation → Ψ triggers:

* temporary blocking (Θ no longer selects the sending thread; Λ outcome at call site),
* forced backoff (Φ-mediated policy such as sleep or throttling),
* capability downgrade (Ω),
* send/recv denial (Λ outcome: attempted event not realized as a successful send/recv).

---

#### 5.8.6 Storage Accounting (∇ + Σ + Δ + Ψ)

Storage usage is accounted structurally like a transactional resource.

##### Allocation / Write Operation

1. Δ: resolve inode / file / block.
2. Ω: verify write permission.
3. Ψ: check quota (`RF.storage.used + delta < RF.storage.max`).
4. ∇: perform write or block allocation.
5. Σ: commit update to storage usage (and, if required, τ-backed storage accounting like `τ.storage_used[p]`).
6. Ψ: enforce consistency rules.

##### Deletion / Freeing

1. Δ: identify object.
2. Ω: verify capability.
3. ∇: free blocks.
4. Σ: decrement `RF.storage.used`.

##### Storage Quota Events

When additional storage cannot be allocated:

* Λ: soft failure (write returns `ENOSPC`; no allocation event materializes),
* Φ: transaction may roll back,
* Ψ: kernel may also suspend or kill the offender via policy-defined responses.

---

#### 5.8.7 Multi-Level Quotas (Process / Role / Group / System)

PMS allows quotas at multiple hierarchical levels, each represented as a frame:

* Process RF
* User RF
* Role RF
* Container / Namespace RF
* System RF

Hierarchy is implemented via frame stacking (□).

During accounting:

* increment at the local RF,
* also increment at all ancestor RFs.

Ψ ensures the strictest limit governs behavior.

Example:

If a container RF is near quota, even if a process RF has headroom, Ψ denies allocations.

---

#### 5.8.8 Auditing & Observability (Δ + Σ + τ + Θ + Ψ)

For every resource-affecting event:

* Δ prepares an audit record, including:

  * who (role `r`),
  * what (resource id),
  * how much (delta),
  * when (`τ.now` or a specific `τ.timestamp(e)`).

* Σ commits the audit log entry.

* Ψ ensures retention and consistency rules.

Audit logs themselves may be isolated via Χ and subject to storage quotas.

---

#### 5.8.9 Policy Integration (Ψ): Resource Governance

Policies express invariants like:

* “No process may allocate more than 2GB total memory.”
* “Containers cannot exceed 10% of system CPU.”
* “IPC send rate must not exceed 10k messages per second.”
* “Write operations cannot exceed storage class guarantees.”

A Ψ-rule activates:

```text
Ψ_resource_limit: RF.x.used > RF.x.max  =>  deny or reframe
```

Possible reactions:

##### Soft reaction:

* Θ: delay,
* Ω: reduce priority,
* Φ: notify process.

##### Hard reaction:

* Λ: return failure,
* Φ: abort syscall,
* Kill: place process in exit state.

We explicitly encode actions as operator transitions, so the model is machine-verifiable.

---

#### 5.8.10 Summary

PMS resource accounting is:

| Resource | Dominant Ops  | Notes                                                   |
| -------- | ------------- | ------------------------------------------------------- |
| CPU      | τ, Θ, Σ, Ψ    | Temporal; fairness and quotas via Θ ordering over τ + Ψ |
| Memory   | ∇, Σ, Ψ, Χ    | Frames (□), isolation (Χ), OOM handling (Φ/Λ)           |
| IPC      | Δ, Ω, τ, Σ, Ψ | Sends/receives, queue length, τ-based rate limits       |
| Storage  | ∇, Σ, Ψ       | Journaling, quota enforcement, Δ resolution             |

All accounting flows reduce to:

```text
Δ -> Ω -> Ψ -> (∇ / □ / Χ) -> Σ -> Ψ
```

This prepares us for Section 6: Memory & Storage Subsystems, since the quota system and accounting model feed directly into:

* VM architecture (6.1),
* allocation and reclamation (6.2),
* filesystem consistency (6.3).

---

## 6 Memory & Storage Subsystems

### 6.1 Virtual Memory & Frames (□, Χ, Φ)

*(address spaces, paging, segmentation)*

This section defines the PMS-native virtual memory model.
It unifies address spaces, memory protection, segmentation/paging, isolation, and context switching under the operator triad:

* □ — Frame → defines addressable context (segments, page tables, stack frames, code/data frames),
* Χ — Isolation boundary → process boundaries, sandboxing, read/write/exec protection,
* Φ — Recontextualization → context switches, page faults, mapping changes, versioned memory views.

This forms the kernel’s full VM abstraction.

---

#### 6.1.1 Conceptual Model: Memory as a Set of Frames (□)

In PMS, memory is not a flat array.
It is a hierarchy of frames, each representing a bounded region of interpretable state.

##### Definition: Memory Frame (□)

A frame is:

```text
Frame = (base, size, type, perms, meta)
```

Where:

* base – physical or virtual base address,
* size – extent,
* type – `CODE`, `DATA`, `STACK`, `HEAP`, `MMIO`, `KERNEL`, `USER`, `SHARED`, etc.,
* perms – `{ r, w, x, u, k, … }` capabilities,
* meta – policy hooks, cacheability, page size, NUMA domain, and so on.

The CPU-level FR register selects the current execution context, but OS-level memory management tracks many frames per process:

```text
PAddr Space -> Physical Frames
VAddr Space -> Virtual Frames / Mappings
Process     -> FrameSet_p = { code, data, heap, stack, shared, ipc, ... }
```

A process address space is simply a set of frames plus a resolution mechanism (page tables / segmentation), all mediated by □.

---

#### 6.1.2 Virtual Address Resolution (□ + Φ)

A virtual address `VA` is interpreted under the current frame context (□):

```text
PhysAddr = Resolve(VA, FrameSet_p)
```

Resolution performs:

1. Δ — classify `VA`: which segment/page does it belong to?
2. □ — select the corresponding frame.
3. Φ — if mapping is missing or invalid → page fault → recontextualize context.
4. Ω — check privilege and capability constraints.
5. Σ — integrate write results into stable memory state when applicable.

##### Two structural strategies are permitted:

---

##### (A) Segmentation-style resolution (pure □)

A set of contiguous frames:

```text
code_frame | data_frame | heap_frame | stack_frame
```

`VA` → pick frame by interval membership.

This is good for:

* small OS designs,
* embedded systems,
* simpler reasoning.

---

##### (B) Paging-style resolution (□ + Δ classification per page)

Virtual space is divided into pages; each page references a frame:

```text
VA -> page_index -> PageTable_p[page_index] = FrameId -> physically mapped frame
```

Δ identifies the page; □ supplies the frame; Φ handles faults.

Paging advantages:

* external fragmentation eliminated,
* dynamic memory allocation simplified,
* copy-on-write (COW) natural,
* isolation and sharing are easier.

---

#### 6.1.3 Process Address Space Construction (□, Χ, Ψ)

A process is assigned a `FrameSet_p` by the kernel:

```text
FrameSet_p = {
    CodeFrame,
    DataFrame,
    HeapFrame,
    StackFrame,
    IPCFrames,
    SharedFrames,
    KernelGatewayFrame
}
```

##### Χ ensures isolation

* A process can only access frames explicitly in its `FrameSet_p`.
* All cross-frame accesses must pass:

  * capability checks (Ω),
  * policy gates (Ψ),
  * optional sandbox filters (Χ-restriction masks).

##### Ψ enforces invariants

Examples:

* read-only code,
* non-executable stack,
* non-executable heap,
* user processes cannot map kernel frames,
* processes cannot escape their sandbox or current namespace.

If any invariant is violated → Φ fault (recontextualization) → kernel handler.

---

#### 6.1.4 Frame Transitions & Context Switching (Φ + □ + Ω)

A context switch is not primarily “switch registers”.
It is: change which frames define the meaning of memory accesses.

##### User → Kernel (syscall/trap)

Sequence:

1. Φ — trap/exception entry,
2. Ω — switch role to kernel,
3. □ — switch FR to kernel frame set,
4. Χ — isolate kernel from user memory,
5. execute handler,
6. Φ — return via `EXC_RET` → restore frames,
7. Ω — role → user,
8. □ — restore user frame set.

##### Kernel → User (return) is symmetric.

This is a frame recontextualization governed by Φ.

---

#### 6.1.5 Paging/PTE Structure (□ + Ω + Ψ)

Each page table entry (PTE) is a frame descriptor:

```text
PTE = (FrameId, perms, flags, meta)
```

perms enforce Ω capabilities:

* `r`: load,
* `w`: store (∇),
* `x`: instruction fetch (Δ decode).

flags can include:

* user / kernel domain,
* copy-on-write,
* dirty / accessed,
* present / not-present,
* shared / private.

meta supports:

* versioned views (Φ),
* isolation scopes (Χ),
* NUMA locality,
* encryption metadata.

##### Page faults = Φ events

Triggered on:

* accessing an unmapped page,
* write to a COW page,
* write to a read-only page,
* execute on a non-exec page,
* user touching a kernel frame.

Flow:

1. Δ — CPU detects violation,
2. Φ — trap,
3. kernel handler resolves frame (for example, map, signal fault, or kill),
4. □ — update page table,
5. return via Φ-exit.

---

#### 6.1.6 Copy-on-Write (Σ + Φ + Χ)

COW frames provide efficient fork and snapshot semantics.

##### Process `fork()`

1. Duplicate address space metadata, not memory.
2. All writable pages → marked COW.
3. Frames shared between parent and child → Χ enforced.
4. On write (∇) to a shared page:

   * Δ — detect COW violation,
   * Φ — COW fault,
   * □ — allocate new frame,
   * Σ — commit new frame and update mapping,
   * continue execution.

This sequence is:

```text
Δ (detect) -> Φ (recontextualize) -> □ (new mapping) -> ∇ (apply write) -> Σ (commit)
```

---

#### 6.1.7 Memory Protection Model (Χ, Ω, Ψ)

Protection is enforced through:

##### Χ — Isolation domains

* process-level,
* thread-level sandbox,
* VM / container boundaries,
* shared memory visibility rules.

##### Ω — Capabilities

* which frames can be mapped,
* which permissions are allowed (r/w/x),
* which syscalls may change mappings.

##### Ψ — Global invariants

Examples:

* kernel frames must not be executable in user mode,
* W^X policy: no frame may be writable and executable simultaneously,
* all shared frames must have stable permissions across processes.

Violations → Φ fault → handler → either resolve or kill the process.

---

#### 6.1.8 Segmentation as a Structured □-Hierarchy

Segmentation becomes natural in PMS.

##### Nested Frames

```text
Process Frame (□)
 ├── CodeFrame
 ├── DataFrame
 ├── HeapFrame
 └── StackFrame
```

Operations such as:

* changing stack frame → □,
* entering a function frame → □,
* switching privilege domain → Ω + □,
* returning to the previous context → Φ + □,

align directly with the frame algebra used earlier for calling conventions.

---

#### 6.1.9 Shared Memory & IPC Frames (□ + Χ + Ω)

Processes may share frames explicitly:

```text
SharedFrame(fid) -> mapped into multiple FrameSet_p instances
```

Χ ensures:

* sharing is opt-in,
* permissions must match,
* Ψ prohibits conflicting usage (for example, both writable unless controlled).

Use cases:

* zero-copy IPC,
* shared ring buffers,
* graphics buffers,
* shared libraries (execute-only).

---

#### 6.1.10 Dynamic Memory Management (Heap) (∇ + Σ + Ψ)

Heap operations:

* `malloc` → allocate slice within `HeapFrame`,
* `free` → mark slice free,
* potential GC integration (see 6.2).

Allocator duties:

* track free lists / trees,
* obey boundaries of `HeapFrame`,
* ensure fragmentation stays within policy limits (Ψ),
* issue Σ commits when blocks become globally visible or shared.

---

#### 6.1.11 Advanced: Versioned Memory Contexts (Φ)

Φ allows the OS to reinterpret memory under new rules.

Examples:

* live process migration,
* hot-patching code pages,
* switching ABI modes,
* rebinding shared libraries,
* transactional memory snapshots.

Memory versioning flow:

1. Φ — reframe memory context,
2. □ — switch to new frame set,
3. update mappings,
4. resume execution in the new version.

All this can happen without changing the logical program state `s_c`, only its interpretation frame.

---

#### 6.1.12 Summary

The PMS-driven virtual memory model rethinks addresses and mappings as structured context operations, not raw integer dereferences.

##### Core conceptual triad

| PMS Operator              | Role in VM                                        | Examples                                           |
| ------------------------- | ------------------------------------------------- | -------------------------------------------------- |
| □ Frame               | defines memory context and address interpretation | segments, pages, stack frames, kernel/user frames  |
| Χ Isolation           | prohibits illegal cross-context access            | process isolation, sandboxing, shared-memory rules |
| Φ Recontextualization | handles faults, traps, frame changes              | page faults, syscalls, migration, ABI switches     |

##### Outcomes

* Unified segmentation and paging,
* clean representation of syscall transitions,
* natural modeling of COW, shared memory, and reentrancy,
* isolation and permissions encoded via Χ and Ω,
* protection via Ψ invariants,
* page faults and context switches treated uniformly as Φ.

---

### 6.2 Allocation & Reclamation – Heaps, Pools, GC/RC

*(∇, Σ, □, Ω, Χ, Ψ, Φ)*

This section formalizes dynamic memory management in PMS-OS using PMS operators as the governing mechanisms.
It covers:

* heap structure,
* allocation and free,
* pools and slab allocators,
* reference counting and garbage collection,
* safety rules (Ω, Χ, Ψ),
* failure semantics (Λ, Φ).

Everything is expressed in the same structural form used for the CPU, kernel, and virtual memory.

---

#### 6.2.1 Heap as a Structured Frame (□)

Each process contains a `HeapFrame` within its `FrameSet_p`:

```text
HeapFrame = (base, size, perms = {r, w}, type = HEAP, meta)
```

The heap is not an undifferentiated region.
It is a hierarchical set of allocation subframes:

```text
HeapFrame (□)
 ├── BlockFrame_0
 ├── BlockFrame_1
 ├── ...
 └── BlockFrame_N
```

Each `BlockFrame` is:

```text
BlockFrame = (addr, size, state ∈ {free, used}, meta)
```

Allocators manipulate these subframes through ∇, Σ, and occasionally Φ.

---

#### 6.2.2 Allocation Semantics (∇ + Σ)

An allocation request of size `n` is:

```text
ptr = alloc(n)
```

Allocation algorithm in PMS operator terms:

1. Δ — classify request
   Determine size class, alignment, pool, and similar parameters.

2. □ — select candidate frame(s)
   Choose an appropriate free `BlockFrame` or pool frame.

3. Ω — privilege check
   Ensure the caller is allowed to expand heap or use shared pools.

4. ∇ — allocate
   Update the `BlockFrame`:

   * mark as used,
   * split if necessary,
   * update free lists / trees.

5. Σ — commit allocation
   The updated allocator metadata becomes globally visible inside the process.

6. Return pointer.

Invalid cases:

* Λ if heap expansion is optional and other strategies may be tried,
* Φ if expansion requires recontextualization (for example, mapping a new page).

---

#### 6.2.3 Free / Reclamation Semantics (∇ + Σ)

Freeing memory:

```text
free(ptr)
```

Steps:

1. Δ — validate `ptr`
   If invalid → Φ fault (use-after-free or foreign pointer).

2. ∇ — mark block as free
   Update `BlockFrame.state = free`.

3. ∇ — coalesce adjacent free blocks
   Optional, depends on allocator.

4. Σ — commit free
   Make the block available for new allocations.

##### Safety Enforcement (Ψ)

Policies ensure:

* double-free detection,
* pointer validity,
* freeing only within `HeapFrame`,
* prevention of freeing kernel/shared frames.

Violation → Φ → kernel terminates process or applies recovery logic.

---

#### 6.2.4 Pool / Slab Allocators (Α + □ + Σ)

Pools and slabs are expressed using Α patterns:

```text
Α_slab(size_class):
    pre-allocated FrameSet:
        SlabFrame
        ObjectFrame_i
```

Allocation from a slab:

* Δ classify object size,
* □ select appropriate slab,
* ∇ toggle object state `free -> used`,
* Σ finalize.

Advantages:

* constant-time allocation and free,
* reduced fragmentation,
* good fit with PMS’s structured frame model.

Shared kernel pools (for example, for IPC messages) require Ω/Ψ enforcement since cross-process allocation is involved.

---

#### 6.2.5 Reference Counting (RC) (∇ + Σ + Ω + Ψ)

Reference counting is a first GC model expressible purely in PMS operators.

For each allocated object `o`:

```text
refcount(o) ∈ s_c
```

##### Increment (retain)

* Ω checks capability to share the object,
* ∇ increments the counter,
* Σ commits the update.

##### Decrement (release)

* ∇ decrements the counter,
* if result = 0 → trigger the free sequence,
* Σ finalizes.

Ψ forbids:

* overflow,
* RC underflow,
* cross-process sharing without appropriate permissions.

Χ constrains which processes may access the object.

---

#### 6.2.6 Mark & Sweep GC (Θ + Δ + ∇ + Σ + Χ)

Garbage collection can be described as a Θ-sequenced traversal of reachable frames.

##### Mark phase

1. Θ — enter GC cycle,
2. Δ — identify roots,
3. Δ — inspect pointers in each reachable object,
4. ∇ — mark reachable objects,
5. Χ — prevent conflicting concurrent mutation (stop-the-world or barriers).

##### Sweep phase

1. Θ — sweep init,
2. Δ — classify blocks: marked vs unmarked,
3. ∇ — free unmarked blocks,
4. Σ — commit the new heap state.

Policies (Ψ) determine:

* GC triggers,
* maximum heap size,
* behavior under memory pressure,
* fairness across processes.

---

#### 6.2.7 Copying / Generational GC (Φ + □ + Σ)

Copying GC uses Φ recontextualization of heap frames.

##### Steps

1. Φ — move to a “new heap frame”,
2. □ — allocate a to-space frame,
3. Δ — scan objects,
4. ∇ — copy live objects into to-space,
5. Σ — integrate the new heap and discard the old frame,
6. update block pointers.

Χ ensures no other thread sees intermediate garbage.

---

#### 6.2.8 Memory Pressure, OOM Handling (Λ + Φ + Ψ)

When memory is low:

* Λ triggers (“non-event”: allocation was expected but cannot be fulfilled yet).

The kernel reacts by:

* reclaiming pages,
* running GC,
* shrinking caches.

If this still fails → Φ OOM recontextualization:

* kill process,
* send signal,
* enter low-memory mode.

Ψ enforces system-wide invariants, such as:

* the kernel must not run out of memory,
* certain system processes cannot be OOM-killed.

---

#### 6.2.9 Concurrency Safety (Χ + Ω + Ψ + Θ)

Concurrent allocation and free across threads:

* Χ defines heap isolation or shared heap subcontexts.
* Ω controls who may allocate on shared heaps.
* Θ defines ordering of allocator structures.
* Ψ ensures:

  * ABA prevention,
  * lock-free correctness rules,
  * memory model constraints (ties into 2.7).

---

#### 6.2.10 Summary

| Concern     | PMS Operator Backbone | Notes                                       |
| ----------- | --------------------- | ------------------------------------------- |
| allocation  | Δ, □, ∇, Σ            | classify → choose frame → allocate → commit |
| free        | Δ, ∇, Σ               | validate → free → integrate                 |
| GC          | Θ, Δ, ∇, Σ            | traversal, marking, sweeping                |
| isolation   | Χ                     | per-process heaps, safe sharing             |
| permissions | Ω                     | who may allocate/free                       |
| invariants  | Ψ                     | memory safety rules                         |
| faults      | Λ, Φ                  | out-of-memory, invalid pointer              |

The heap becomes a consistent PMS-structured subsystem: allocations are ∇ actions inside a □ region governed by Ω/Ψ and finalized via Σ.

---

### 6.3 Filesystem Architecture (Σ, Ψ) — directories, handles, permissions, journaling

*(Operators: Δ, ∇, □, Α, Ω, Χ, Θ, Φ, Λ, Σ, Ψ)*

The PMS filesystem (PMS-FS) is a frame-structured storage system.
Every file, directory, mount, transaction, capability, or journal entry is a Frame (□); every filesystem operation is a PMS operator sequence.
The filesystem is thus a first-class PMS subsystem, fully consistent with the compute and memory models.

---

#### 6.3.1 Core Data Model: The Filesystem as a Frame Tree (□ + Α + Ω + Ψ)

The filesystem is a tree (or DAG with hardlinks) of frames:

```text
FSRoot (□)
 ├── DirFrame("/etc")
 │     ├── FileFrame("config")
 │     └── FileFrame("policy")
 ├── DirFrame("/usr")
 └── DirFrame("/var")
       └── DirFrame("log")
```

Each frame has:

```text
FileFrame = (id, name, type, perms, owner, data, meta)
DirFrame  = (id, name, perms, owner, entries, meta)
```

Where:

* perms / owner use Ω (roles, capabilities),
* entries is a mapping `name -> FrameId`,
* meta includes timestamps (τ), journaling info (Σ), and policy hooks (Ψ).

Σ governs all persistent integration: writes become visible only when a Σ commit occurs.

Ψ enforces filesystem-level invariants such as:

* no crossing isolation boundaries (Χ),
* correct permission enforcement (Ω),
* quota limits,
* structural consistency requirements.

---

#### 6.3.2 Directory Semantics (Δ, ∇, Σ, Ψ)

##### Lookup (Δ)

A directory is a classification frame. Looking up a name is:

`DirFrame --Δ(name)--> entry`

Δ returns:

* exists → branch to file/directory handler,
* missing → Λ (non-event) or Φ (error recontextualization).

##### Create Entry (∇ + Σ)

Creating a new file:

1. Δ: check name not present.
2. Ω: check permission to create in this directory.
3. ∇: create `FileFrame`, add to directory entries.
4. Σ: commit update to directory structure.

##### Remove Entry (∇ + Σ + Ψ)

Deletion:

1. Δ: find entry.
2. Ψ: check constraints (for example, cannot delete non-empty directory).
3. ∇: unlink entry.
4. Σ: commit change.
5. Optionally: perform GC or reclamation for underlying blocks.

---

#### 6.3.3 File Handles and Open File Tables (□, Ω, Χ)

Opening a file creates a `HandleFrame`:

```text
HandleFrame = (file_id, mode, offset, perms, isolation)
```

The process Open File Table is a set of `HandleFrame` objects indexed by file descriptors.

##### Open

1. Δ: locate file.
2. Ω: check read/write/exec permission.
3. □: create a new `HandleFrame` for this process.
4. Χ: apply isolation based on namespace/container.
5. Σ: return handle ID (file descriptor).

Handles allow access without re-checking the directory path each time, although Ψ may still enforce per-operation checks.

---

#### 6.3.4 File I/O Semantics (Δ, ∇, Θ, Σ, Ψ)

##### Read (Δ + Θ)

```text
read(fd, n):
    Δ: check handle validity
    Θ: advance read offset
    return data
```

No persistent write occurs, so Σ is not required for the data path.
Ψ may enforce:

* no reads past EOF,
* isolation constraints (Χ).

##### Write (Δ + Ω + ∇ + Σ)

```text
write(fd, data):
    Δ: classify size and location
    Ω: check write permission
    ∇: modify underlying storage blocks or buffers
    Σ: commit write according to journaling mode
```

Write strategies:

* Σ(write-through): synchronous commit.
* Θ-buffered + Σ-later: delayed commit.
* Transactional (Α-pattern): group multiple writes into a single Σ.

---

#### 6.3.5 Permissions and Role System (Ω + Ψ)

Permissions (Ω) determine what operations are allowed.
Policies (Ψ) define global or directory-level rules.

Examples:

* Ψ: no world-writable directories.
* Ψ: a user may only write within their home subtree.
* Ψ: append-only logs.
* Ψ: immutability windows (“cannot modify for X seconds” → Θ + Ψ).

Ω permissions can be granular:

```text
r   read
w   write
x   execute
c   create
d   delete
p   privilege escalate (CAP-like)
```

Each is checked at Δ or ∇ entry points.

---

#### 6.3.6 Mounts and Namespaces (□ + Χ + Φ + Ψ)

A mount is a frame recontextualization (Φ):

```text
Φ: rebind directory-frame pointer -> new root or subtree
```

Used for:

* process namespaces,
* container isolation,
* per-thread or per-process filesystem views,
* overlay filesystems (union mounts).

Isolation (Χ) enforces view boundaries.

Ψ ensures:

* mount points do not violate system policies,
* read-only mounts remain immutable,
* overlay merges follow consistent Σ rules.

---

#### 6.3.7 Journaling and Transactions (Σ + Α + Θ + Φ)

The filesystem journal is explicitly Σ-centric.
A journal entry is:

```text
JournalEntryFrame = (op_seq, τ_timestamp, state)
```

##### Write-ahead logging (WAL)

1. Α-pattern expands filesystem operations into a canonical ordered sequence.
2. Σ(journal-write) records intended updates.
3. Θ orders log entries according to their τ-based commit ordering.
4. Σ(final) applies updates to filesystem structures.
5. Φ(recovery) recontextualizes state after crash.

This provides:

* crash consistency,
* atomic directory updates,
* transactional file operations.

###### Transaction example

```text
begin_tx:
    Α: open transactional frame

write(file):
    ∇ modify buffers

commit:
    Σ(journal)
    Σ(apply changes)

abort:
    Φ(rollback)
```

Multi-operation transactions become first-class PMS patterns.

---

#### 6.3.8 Crash Recovery (Φ + Σ + Θ)

Upon reboot:

1. Θ: replay the journal as ordered by `τ_timestamp`.
2. Δ: identify completed vs incomplete transactions.
3. Φ: recontextualize filesystem state.
4. Σ: integrate all valid updates.

Any incomplete Α-transaction is rolled back along a Φ recovery path.

---

#### 6.3.9 Quotas and Limits (Ω + Ψ + Σ)

System-wide or per-user quotas are enforced structurally:

* Ω: capability to allocate disk space,
* Ψ: policies restricting max blocks, max inodes,
* Σ: applied after each allocation that changes usage.

Quota violation leads to:

* Λ (write deferred or failed),
* Φ (error recontextualization).

---

#### 6.3.10 Summary Table

| Operation      | Operators     | Structural Meaning                 |
| -------------- | ------------- | ---------------------------------- |
| lookup         | Δ             | distinction in directory frame     |
| open           | Δ, Ω, □, Χ, Σ | permission + handle frame creation |
| read           | Δ, Θ          | classify + move offset             |
| write          | Δ, Ω, ∇, Σ    | update and commit                  |
| mkdir/rmdir    | Δ, ∇, Σ, Ψ    | create/remove frames               |
| mount          | Φ, □, Χ, Ψ    | recontextualize filesystem tree    |
| fsync          | Σ             | integrate pending writes           |
| journaling     | Α, Σ, Θ, Φ    | transactional write discipline     |
| crash recovery | Θ, Δ, Φ, Σ    | ordered reconstruction             |

Filesystem behavior is fully grounded in the PMS axioms.

---

### 6.4 Block Devices and Drivers — device abstraction as frames and roles

*(Operators: □, Ω, Χ, Φ, Σ, Δ, ∇, Θ)*

This section defines the PMS model of block devices, drivers, and I/O pipelines.
The goal is to make device access structurally identical to all other subsystems:
devices are frames (□), access is governed by roles (Ω) and isolation (Χ), driver transitions use Φ, and durable updates use Σ.

This forms a unified basis for both traditional OS block drivers and PMS-native virtual devices (network-backed, memory-backed, or distributed).

---

#### 6.4.1 Block Devices as Frames (□)

Every block device is represented as a `DeviceFrame`:

```text
DeviceFrame = (id, type, blocksize, capacity, perms, owner, ops, state)
```

Where:

* `type` ∈ {DISK, SSD, NVMe, RAMDISK, VDEV, LOOP, NET-BLOCK, …},
* `blocksize` and `capacity` define logical geometry,
* `perms`, `owner` are handled via Ω (capabilities),
* `ops` is a driver-defined map of Δ, ∇, Σ-typed operations,
* `state` includes queues, caches, pending I/O, and so on.

In PMS, a block device is just another frame whose “data” is a sequence of fixed-size blocks:

```text
blocks: N -> Byte[blocksize]
```

Accessing a device requires entering its frame context:

```text
FRM_ENTER dev_id    ; □ — enter device context
```

Device reads and writes are then ∇ operations interpreted relative to this frame.

---

#### 6.4.2 Driver Architecture (Δ, ∇, Θ, Φ, Ω)

A driver in PMS is a structured machine made of operators.

##### DriverFrame (□)

```text
DriverFrame = {
    device_id,
    ops: {
        Δ_identify,
        Δ_check_bounds,
        ∇_read_blocks,
        ∇_write_blocks,
        Σ_commit,
        Φ_recover,
        Θ_dispatch,
        Ω_permission_check
    },
    queues,
    cache,
    state
}
```

Operators in the driver:

| Operator | Driver Meaning                                                           |
| -------- | ------------------------------------------------------------------------ |
| Δ        | identify device, classify I/O request type, check block alignment        |
| Ω        | check role/capability for I/O (for example, user can read but not write) |
| Θ        | dispatch requests over a schedule (queue processing)                     |
| ∇        | perform the actual block read/write on hardware or backing store         |
| Σ        | commit writes (flush buffers or guarantee ordering)                      |
| Φ        | error handling: retries, remapping bad blocks, failover                  |

Drivers are thus PMS submachines attached to device frames.

---

#### 6.4.3 I/O Request Pipeline (Δ → Ω → Θ → ∇ → Σ → Φ)

A block I/O request follows a canonical PMS operator sequence.

##### 1. Δ — Request Classification

```text
Δ(request):
    identify operation (READ/WRITE)
    extract block index and length
    check logical bounds
```

##### 2. Ω — Permission Check

Role/capability enforcement:

* READ requires `cap_read`,
* WRITE requires `cap_write`,
* FLUSH may require `cap_admin` or device-specific capabilities.

If Ω fails → driver emits Φ(access-denied error).

##### 3. Θ — Scheduling and Dispatch

Requests are enqueued into the driver’s scheduling structure:

* FIFO,
* Deadline,
* Elevator / C-LOOK,
* priority-based queues.

The driver’s Θ component serializes and orders operations.

##### 4. ∇ — Execute the I/O

For each scheduled request:

* ∇ read: `blocks[i] -> buffer`,
* ∇ write: `buffer -> blocks[i]`.

Driver-internal caches may be updated here.

##### 5. Σ — Commit and Ordering

Σ ensures:

* write ordering constraints (barriers),
* transaction durability (for journaled filesystems),
* flushing of device cache if necessary.

##### 6. Φ — Recontextualization for Errors or Retries

The driver may:

* retry (after a Θ-based backoff),
* reframe device view (mark block bad, remap),
* escalate error to filesystem or kernel.

This completes the structured I/O lifecycle.

---

#### 6.4.4 Device Isolation Model (Χ)

Block devices are isolation boundaries.

Each `DeviceFrame` has an associated Χ-domain:

```text
Χ(device) = { allowed_frames : caps }
```

When entering a device context (via `FRM_ENTER`):

* Χ enforces that only permitted regions of memory, buffers, descriptors may be accessed.
* Isolation prevents:

  * DMA into unauthorized memory,
  * direct device-to-process memory writes,
  * bypassing filesystem access controls.

##### DMA example (structured)

If DMA is supported:

* a `DMARegionFrame` is created (□),
* Χ restricts DMA to that frame only,
* ∇ DMA operations copy blocks into `DMARegionFrame` buffers.

If DMA violates policy → Φ(exception) or Ψ(system halt).

---

#### 6.4.5 Storage Stack as Composed Frames (□ + Α)

Block device → optional layers → filesystem:

```text
Physical DeviceFrame
        ↓ (□)
PartitionFrame
        ↓ (□)
VolumeFrame / RAIDFrame / EncryptedFrame
        ↓ (□)
Filesystem Root Frame
```

Examples of Α-patterns for layered devices:

* RAID-1 mirror pattern

  ```text
  PATTERN RAID1:
      ∇ write block to devA
      ∇ write block to devB
      Σ commit if (both successful) else Φ(recover)
  ```

* Encryption frame

  ```text
  READ:
      ∇ read encrypted block
      ∇ decrypt block
      return plaintext

  WRITE:
      ∇ encrypt block
      ∇ write encrypted block
      Σ
  ```

Each layer in the stack is itself a PMS operator-based machine.

---

#### 6.4.6 Interrupt Path for Block Devices (Φ + Θ + Λ)

Block devices generate interrupts for:

* I/O completion,
* I/O errors,
* queue-empty conditions,
* device hotplug.

Interrupt handling sequence:

1. Φ(entry) — trap from device.
2. Δ — driver identifies cause.
3. Θ — driver schedules handling (dequeue next request, complete current).
4. Σ — optional commit of completion metadata.
5. Λ — if device becomes idle (no pending events).

This integrates with the CPU interrupt and trap model.

---

#### 6.4.7 Hotplug and Dynamic Reconfiguration (Φ + Ψ + □)

When a device is inserted or removed:

##### Hotplug sequence

1. Φ(hotplug-event) — OS recontextualizes I/O subsystem.
2. Δ — driver identification.
3. □ — create or remove the `DeviceFrame`.
4. Ψ — enforce policies (for example, only privileged roles may mount new devices).
5. Σ — integrate the updated filesystem/device tree state.

Failures produce:

* Φ(retry or fallback driver),
* Λ(timeout waiting for device presence),
* Ψ(reject unauthorized device).

---

#### 6.4.8 Error Handling and Recovery (Φ, Σ, Θ)

Drivers use Φ for:

* block remapping,
* retry logic (Θ-based exponential backoff),
* transitions to degraded modes (for example, half of a mirror failed),
* integrity restoration.

Σ ensures all recovery updates become consistent (for example, marking a block as bad).

---

#### 6.4.9 PMS Device Model vs Classical OS Models

Traditional OSes treat drivers as opaque code running with elevated privilege.
PMS instead treats drivers as operator-constrained machines:

* all operations typed as Δ/∇/□/Ω/Θ/Σ/Φ,
* behavior is verifiable (see section 11: IR and model checking),
* capability-bound (Ω), format-bound (□), isolation-bound (Χ),
* error-handling is structured (Φ),
* transactional semantics are explicit (Σ).

Drivers cannot violate invariants unless Ψ explicitly permits it.

---

#### 6.4.10 Summary Table

| Layer                   | Operators | Structural Meaning                |
| ----------------------- | --------- | --------------------------------- |
| DeviceFrame             | □, Ω, Χ   | identity, capabilities, isolation |
| Driver operations       | Δ, ∇      | classify and execute I/O          |
| Scheduling              | Θ         | dispatch order                    |
| Timeouts                | Λ         | non-event when device is silent   |
| Error handling          | Φ         | recontextualize / retry / recover |
| Write durability        | Σ         | commit to storage                 |
| Stacking (RAID, crypto) | Α, Σ, Φ   | reusable patterns                 |

Block devices fully integrate with the PMS universal model.

---

### 6.5 Caching and Buffer Management — FS/Buffer Cache, Write-Back Semantics

*(Operators: Δ, ∇, Θ, Λ, □, Ω, Χ, Φ, Σ, Α)*

This section defines the unified PMS caching and buffer-management model for block storage and filesystems.
It treats caches and buffers as formal PMS frames, with strict sequencing, isolation, commit, and policy guarantees.

Caching is not an afterthought; it is a first-class operator-structured subsystem.

---

#### 6.5.1 The PMS Cache Model: CacheFrame (□ + Χ)

A cache is a frame with controlled visibility and isolation constraints:

```text
CacheFrame = (id, type, mapping, state, perms, owner)
```

Where:

* `type` ∈ {BLOCK_CACHE, PAGE_CACHE, FS_BUFFER_CACHE},
* `mapping`: block/page → cached data buffer,
* `state`: metadata such as dirty/clean bits, LRU counters, refcounts,
* `perms`: access governed by Ω (filesystem, kernel, device-driver roles),
* `owner` and isolation: Χ ensures user processes cannot see other processes’ cached data directly.

CacheFrames are entered implicitly by the filesystem and explicitly by drivers or kernel routines:

```text
FRM_ENTER cache_id    ; □
```

Within the `CacheFrame`, ∇ operates on cached buffers instead of physical storage.

---

#### 6.5.2 Cache Lifecycle (Δ → Ω → ∇ → Θ → Σ / Λ / Φ)

Every read or write request goes through a canonical operator sequence.

##### 1. Δ — Lookup / Distinction

Determine whether the block/page is in cache:

```text
Δ(cache_lookup):
    if mapping.contains(block):
        hit
    else:
        miss
```

The distinction sets hit/miss flags in the meta-state.

##### 2. Ω — Capability Check

Determine whether the caller has permission to access this cached item:

* Read: `cap_read`,
* Write: `cap_write`,
* Metadata updates: `cap_fs_admin`.

If Ω fails → Φ(access error).

##### 3. ∇ — Load Into Cache (on miss)

On a miss:

* ∇ issues a block read via the driver,
* a buffer is allocated and inserted into the `CacheFrame`.

Dirty bit is initially `false`.

##### 4. Θ — Scheduling and Access Sequencing

Cache management interleaves multiple operations:

* LRU updates,
* multi-threaded reads and writes,
* lock ordering.

Θ ensures sequential consistency at cache level.

##### 5. ∇ — Modify Cached Buffer

On writes:

```text
∇ write bytes to cache buffer
dirty = true
```

This is purely in-cache, not yet committed to the device.

##### 6. Σ / Λ / Φ — Finalization

Depending on policy and state:

* Σ (commit): write-back to device,
* Λ (non-event): delay write if sync criteria are not met yet,
* Φ (recontextualization): remap, retry, fallback, or handle device errors.

This lifecycle is identical across filesystem, drivers, virtual devices, and journal layers.

---

#### 6.5.3 Buffer States and Transitions (Σ-driven)

Each buffer follows a well-defined state machine:

```text
CLEAN -> DIRTY -> FLUSHING -> CLEAN
     ↘ Φ(error) -> RECOVERY -> CLEAN or DEAD
```

Transitions:

| PMS Operator | Transition Meaning                        |
| ------------ | ----------------------------------------- |
| Δ            | check if buffer exists / check dirty flag |
| ∇            | modify buffer (DIRTY), mark metadata      |
| Θ            | schedule flush or eviction                |
| Σ            | commit to storage (DIRTY → CLEAN)         |
| Λ            | delay or non-event (write not yet done)   |
| Φ            | error during flush → recovery path        |

Buffers that fail recovery may be marked DEAD, triggering upper layers to recreate structures.

---

#### 6.5.4 Write Policies (PMS-Structured)

The PMS operator set provides a formal vocabulary for describing classical cache write policies.

##### 1. Write-Through (Σ after every ∇)

Sequence:

```text
∇write -> Σcommit
```

No dirty state persists beyond a single operation.
Easy to reason about; potentially slower on some hardware.

##### 2. Write-Back (Σ deferred)

Sequence:

```text
∇write -> Θ(delay) -> Σcommit
```

Optional Λ if the device is not ready:

```text
Θ -> Λ(timeout) -> retry or Φ(error)
```

##### 3. Write-Around (skip cache on write)

Sequence:

```text
∇write_direct -> Σcommit
```

Cache is unaffected unless a later read demands that block.

##### 4. Log-Structured (Α-pattern)

Expressed via an Α pattern:

```text
PATTERN LOG_APPEND:
    ∇ append to log buffer
    when log buffer is full:
        Σ flush log buffer
```

This composes naturally with the journaling filesystem design in section 6.3.

---

#### 6.5.5 Eviction Policies (Θ + Δ + Ω + Σ)

Eviction is treated as an ordering decision under Θ.

##### Δ — Identify Candidate

Examine:

* LRU history,
* access frequency,
* dirty bit,
* role-specific priorities (Ω).

##### Ω — Permission to Evict?

Some buffers belong to privileged subsystems (for example, superblock).
Eviction may be blocked for such buffers.

##### Θ — Sequence / Choose Eviction Order

The cache scheduler (Θ) picks the next buffer to evict based on its policy.

##### Σ — Commit if Dirty

If the buffer is dirty:

```text
Σ(write_back)
```

##### ∇ — Free Buffer

After any required commit, a final ∇ removes the buffer:

```text
∇ delete cache buffer
```

---

#### 6.5.6 Multi-Layer Caching (Α + □ + Χ)

Filesystems and block devices often maintain multiple caches:

* Block cache
* Page cache
* Directory entry cache
* Metadata cache
* Journaling intent cache

Each is a Frame; they can stack:

```text
FRM_ENTER PageCache
FRM_ENTER BlockCache
FRM_ENTER DeviceFrame
```

The Α-pattern relations define:

* coherency rules
* ordering
* dependency (for example, page cache depends on block cache)

Χ enforces that each layer sees only what it must; filesystem metadata cache is isolated from raw device blocks except via the driver.

---

#### 6.5.7 Journaling and Coherency (Σ + Φ + Θ)

The journaling model integrates tightly with the cache.

##### Write sequence with intent logging

1. ∇ modify data buffer
2. ∇ create journal entry buffer
3. Σ commit journal entry
4. Σ commit data buffer
5. Φ rollback if crash is detected mid-sequence
6. Θ reorder or flush sequences in batches

This prevents torn writes and maintains filesystem integrity.

All journal operations are PMS operator sequences.

---

#### 6.5.8 Concurrency and Synchronization (Θ + Ω + Χ)

Concurrent access to the cache requires:

* lock ordering constraints (Ω)
* ordering constraints (Θ)
* isolation rules (Χ)

##### Example atomic buffer update

```text
LOCK buffer        ; Ω
Δ read state
∇ modify buffer
Σ commit (or deferred)
UNLOCK buffer      ; Ω
```

Optionally:

* Χ enforces that cross-process writes do not interfere
* Θ ensures sequential consistency

Atomicity is expressed with Σ or Σ + Ω combinations.

---

#### 6.5.9 Consistency Models for Caches (Ψ)

Ψ-layer policies define:

* when Σ must fire
* how much reordering Θ may perform
* what isolation levels Χ apply
* how metadata must be updated (Δ constraints)

Examples:

##### Strong consistency

Ψ_strong:

* writes are visible immediately after Σ
* no reorder across Θ barriers
* metadata and data are flushed together

##### Eventual consistency

Ψ_eventual:

* Σ is deferred
* multiple ∇ modifications are batched
* Θ is allowed to reorder non-dependent writes

##### Transactional filesystem consistency (Ψ_fs)

* Σ commit for journal and data
* rollback safety via Φ
* multi-buffer atomicity

The policy system makes consistency configurable and enforceable.

---

#### 6.5.10 Unified Structural Summary

| PMS Operator | Cache Meaning                                               |
| ------------ | ----------------------------------------------------------- |
| Δ        | lookup, metadata inspection, dirty check, eviction tests    |
| ∇        | modify buffer, load/write data                              |
| Θ        | schedule flush, eviction, LRU updates                       |
| Λ        | delay flush, not-ready events                               |
| Φ        | error handling, block remapping, recovery                   |
| □        | frames for caches, device access, journaling layers         |
| Ω        | permission checks, concurrency rules, privileged buffers    |
| Χ        | isolation of cache layers and tenants                       |
| Σ        | commit to stable storage, durability                        |
| Α        | macro-patterns: journaling, log-structured, layered caching |

Caching becomes a first-class, formally-typed system within the PMS kernel, supporting:

* strong invariants
* composability
* formal verification (section 11)
* clear OS/runtime behavior
* deterministic or non-deterministic scheduling

---

## 7 IPC, Synchronization, and Events

### 7.1 Message Passing (Δ, Ω, Λ, Θ, Φ) — queues, mailboxes, request/response

Message passing in PMS-OS is not an “API layer”.
It is a praxeological structure: a rigorously operator-typed flow built from Δ, Ω, Λ, Θ, Φ (and Σ for integration, though we reserve Σ for delivery/commit semantics in 7.2).

The result is a general, verifiable IPC substrate that unifies:

* synchronous and asynchronous messaging
* mailboxes and queues
* request/response protocols
* interrupt-to-process delivery
* fault-tolerant remote message handling
* distributed messaging (when extended in section 7)

Everything follows directly from the PMS operator grammar.

---

#### 7.1.1 Conceptual Model: MessageFrame (□ + Χ)

All messaging occurs inside MessageFrames, which are specialized Frame types:

```text
MessageFrame = (id, type, queue, perms, owner, meta)
```

Where:

* type ∈ {MAILBOX, QUEUE, CHANNEL, PIPE, PORT}
* queue: ordered buffer of messages
* perms: Ω permissions (send, receive, inspect)
* owner: process or kernel subsystem
* meta: Θ counters, Λ flags, Φ error markers

A process enters a `MessageFrame` to perform send/receive:

```text
FRM_ENTER msg_id        ; □
```

Χ isolates each `MessageFrame` unless explicitly shared.

---

#### 7.1.2 Message Structure

A message is a PMS-typed object:

```text
Msg = (kind, payload, sender, caps, meta)
```

* kind: distinguishes message type (REQUEST, RESPONSE, EVENT, SIGNAL, ERROR, …)
* payload: raw data or small structured record
* sender: process ID, role
* caps: optional capabilities sent across Ω boundaries
* meta: includes tau-based timestamp (for example `tau_timestamp(msg)`), retries, hop counters

Messages are FIFO by default; additional structures (priority queues) use Θ + Ω patterns.

---

#### 7.1.3 Send Semantics (Δ → Ω → ∇ → Θ → Σ)

##### 1. Δ — Distinguish the message type

The sender determines what kind of message is being sent:

```text
CMP tag, MSG_TYPE_REQUEST      ; Δ
```

This also selects the correct queue and permissions.

##### 2. Ω — Capability check

Before enqueueing, the OS evaluates whether the sender has:

* SEND permission on this mailbox or queue,
* the right to attach capabilities in `caps`.

If forbidden → Φ (permission trap).

##### 3. ∇ — Enqueue the message

```text
ENQ msgframe, Msg              ; ∇
```

This mutates the queue state.

##### 4. Θ — Ordering and dispatch sequencing

Sender-side Θ handles:

* scheduling dependencies
* message ordering (sequence numbers)
* potential backpressure

```text
TICK                           ; Θ
```

##### 5. Σ — Integration of send (optional)

Some systems require send-commit semantics:

```text
COMMIT_SEND msgframe           ; Σ
```

This means the message is guaranteed visible to receivers.

If Σ is omitted, send is best-effort until buffers are synchronized.

---

#### 7.1.4 Receive Semantics (Δ → Ω → Λ / ∇ → Φ)

Receiving messages is the dual structure.

##### 1. Δ — Check for message availability

```text
CMP queue_length, 0            ; Δ
BEQ no_msg                     ; Δ
```

##### 2. Ω — Capability check

```text
CHK_CAP cap_recv, fail         ; Ω
```

##### 3. Λ — If empty: non-event

If the queue is empty:

```text
no_msg:
WAIT msgframe, timeout         ; Λ
```

Λ produces non-event semantics:

* return with timeout,
* schedule another Θ-based attempt later,
* or Φ if the caller expects a synchronous message and absence implies fault.

##### 4. ∇ — Dequeue

If a message exists:

```text
DEQ msgframe, Rmsg             ; ∇
```

This mutates the queue.

##### 5. Φ — Recontextualization on malformed or policy-blocked message

```text
EXC_RAISE MSG_INVALID          ; Φ
```

Used when:

* the message violates interface contract,
* the sender is not allowed to talk to this receiver,
* there is a protocol version mismatch.

---

#### 7.1.5 Request/Response Pattern (Α over Δ, Ω, Θ, ∇, Σ, Φ)

Request/response is a reusable Α-pattern.

##### Pattern Α_REQRESP(client, server)

1. Client → Server

   ```text
   Δ distinguish REQUEST
   Ω check send rights
   ∇ enqueue into server mailbox
   Θ schedule
   ```

2. Server receipt

   ```text
   Δ check queue
   Ω check recv rights
   ∇ dequeue
   (process request)
   ```

3. Server → Client response

   ```text
   Δ distinguish RESPONSE
   Ω check capability to reply
   ∇ enqueue to client mailbox
   Σ commit
   ```

4. Client receipt

   ```text
   Δ check queue
   Λ wait if needed
   ∇ dequeue
   Φ reframe if response implies new context or state
   ```

In words, the pattern is:

> repeated Δ/Ω/∇/Θ steps to send and process the request,
> followed by Δ/Λ-or-∇/Φ on the client side to receive and apply the response.

This pattern is usable at both kernel and userspace levels (via syscalls).

---

#### 7.1.6 Mailboxes vs Queues (Role and Isolation Semantics)

##### Mailbox (per-process)

* Χ isolates the mailbox to a single process.
* Ω typically grants “owner receives / others send”.

##### Queue (shared)

* Many-to-many communication.
* Ω enforces:

  * producer capabilities,
  * consumer capabilities,
  * ordering constraints (priority, fair queues) via Θ.

Isolation is controlled via:

```text
ISO_RESTRICT mask      ; Χ
```

so that only specific processes can see queue contents.

---

#### 7.1.7 Synchronous Messaging via Λ and Θ

Synchronous IPC (“wait until response arrives”) is implemented structurally:

```text
SEND request
WAIT reply, timeout     ; Λ
IF timeout → Φ error
```

The presence of Λ in the receive path distinguishes:

* event (message arrives),
* non-event (Λ-timeout triggers fallback Φ based on tau-based deadlines).

Θ controls fairness and scheduling:

```text
YIELD                    ; Θ – allow server to run
```

---

#### 7.1.8 Interrupt → Message Unification (Φ → Δ → ∇)

The interrupt subsystem is structurally identical to message passing.

##### Hardware interrupt → Φ trap

Φ captures the external event.

##### Kernel interrupt handler constructs message

* Δ distinguishes interrupt type.
* Ω checks whether delivery is allowed to this process.
* ∇ enqueues a message into the process’s event mailbox.

##### Process later receives it via normal IPC

This unifies:

* hardware events,
* software messages,
* Λ timeouts,
* signals,

all via the same Δ–Ω–Λ–Θ–Φ machinery.

---

#### 7.1.9 Reliability and Delivery Semantics (Ψ + Σ + Λ)

Ψ policies define delivery guarantees.

##### At-most-once delivery

* Σ commits dequeue,
* message is discarded after read,
* Ψ forbids re-delivery.

##### At-least-once delivery

* Sender keeps a copy,
* Σ commit only when receiver acknowledges,
* if Λ timeout → retry (∇ enqueue again),
* Θ controls backoff.

##### Exactly-once delivery

Requires:

* message IDs (Δ),
* a commit protocol (Σ),
* a consistency policy Ψ,
* Φ on duplicate detection.

---

#### 7.1.10 Structural Summary Table

| PMS Operator | IPC Role                                                       |
| ------------ | -------------------------------------------------------------- |
| Δ        | message type distinction, queue state checks, branching        |
| Ω        | send/receive permissions, capability passing                   |
| Λ        | timeouts, non-event on empty queue                             |
| Θ        | ordering, scheduling, fairness, retries                        |
| Φ        | message validation errors, fallback, interrupt arrival         |
| □        | `MessageFrame` objects for queues/mailboxes/channels           |
| Χ        | isolate endpoints, control visibility                          |
| ∇        | enqueue/dequeue, modify queue state                            |
| Σ        | commit delivery, enforce reliability                           |
| Ψ        | delivery policies, interface contracts                         |
| Α        | reusable messaging patterns (request/response, streaming, RPC) |

Message passing in PMS-OS is therefore:

* unified,
* verifiable,
* policy-controllable,
* compatible with concurrency,
* and extensible to distributed systems (later in section 7).

---

### 7.2 Synchronization Primitives (Ω, Θ, Σ, Χ, Δ)

mutexes, semaphores, channels — structural PMS model

In PMS-OS, synchronization is not ad hoc: all primitives are strictly constructed from PMS operators and their dependency grammar.

This yields synchronization mechanisms that are:

* capability-secured (Ω),
* ordering-constrained (Θ),
* isolation-preserving (Χ),
* distinction-driven (Δ),
* commit-consistent (Σ),
* policy-verifiable (Ψ).

---

#### 7.2.1 Core Idea: SyncPrimitive = Frame (□) + Role Gate (Ω) + Temporal Sequencer (Θ)

Every synchronization construct is a specialized `SyncFrame`:

```text
SyncFrame = (id, type, state, waiters, perms, meta)
```

Where:

* type: MUTEX, SEMAPHORE, CHANNEL, RWLOCK, FUTEX-like, EVENT-FD-like
* state: primitive-specific data (for example, locked/unlocked, count, buffer)
* waiters: queue of threads waiting (Θ-ordered)
* perms: Ω roles and capabilities for lock/unlock/wait/signal
* meta: Θ counters, fairness markers, Λ flags, Φ exception markers

Χ isolates each `SyncFrame` unless explicitly shared.

---

#### 7.2.2 Distinction First: Δ Guards Every Sync Operation

Before any lock, unlock, wait, signal, or send/receive:

```text
CMP SyncFrame.type, MUTEX     ; Δ
```

or:

```text
CMP state.locked, 0           ; Δ
```

Δ establishes the precondition for any ∇ mutation.
This enforces PMS dependency constraints (no ∇ without Δ).

---

#### 7.2.3 Mutex Semantics (Ω + ∇ + Θ + Σ)

A mutex is a `SyncFrame` with:

```text
state = (locked in {0,1}, owner)
```

##### Lock (attempt)

1. Δ – check locked/unlocked.

2. Ω – capability check (does caller have LOCK rights?).

3. If unlocked:

   ```text
   state.locked := 1             ; ∇
   state.owner := current_tid    ; ∇
   Σ commit_lock                  ; Σ
   ```

4. If locked:

   * Θ: enqueue thread in waiter queue,
   * thread enters blocked state,
   * scheduler context-switches,
   * Λ may signal timeout if waiting is bounded via tau-based deadlines.

##### Unlock

1. Δ verify ownership.

2. Ω check UNLOCK capability.

3. ∇ unlock mutex:

   ```text
   state.locked := 0
   state.owner := null
   ```

4. Θ pick next waiter (deterministic or via fairness policy).

5. Σ commit unlock and wake.

Σ makes mutex unlocking atomic and visible across contexts.

---

#### 7.2.4 Semaphores (Ω, Θ, ∇, Σ, Λ)

A semaphore has:

```text
state = (count in N, max)
```

##### wait (P / down)

1. Δ compare `count`.

2. If `count > 0`:

   ```text
   count := count - 1          ; ∇
   Σ commit_wait                ; Σ
   ```

3. Else:

   ```text
   ENQUEUE waiters, tid        ; Θ
   BLOCK tid                   ; Θ
   WAIT timeout → Λ            ; Λ
   ```

##### signal (V / up)

1. Δ verify `count < max`.
2. Ω check SIGNAL capability.
3. ∇ increment `count`.
4. Θ wake one or more waiters.
5. Σ commit increment and wake.

Ψ can enforce:

* strong fairness (every waiting thread eventually progresses),
* bounded waiting,
* FIFO order via Θ.

---

#### 7.2.5 Channels (Δ, Ω, Θ, ∇, Λ, Φ, Σ)

Channels unify:

* pipe semantics,
* synchronous and asynchronous send/receive,
* bounded and unbounded queues,
* rendezvous channels (CSP style).

Channel state:

```text
state = (buffer, capacity, closed, wait_send, wait_recv)
```

##### send(channel, msg)

1. Δ check if buffer is full or closed.
2. Ω check SEND permission.

Cases:

###### Case A — buffer not full

```text
ENQ buffer, msg              ; ∇
Σ commit_send                ; Σ
Θ wake receiver if waiting
```

###### Case B — buffer full

* Blocking send:

  ```text
  ENQUEUE wait_send, tid     ; Θ
  BLOCK tid                  ; Θ
  WAIT timeout → Λ           ; Λ
  ```

* Non-blocking send:

  * return Λ (no-space non-event).

##### receive(channel)

1. Δ check if buffer is empty.
2. Ω check RECV permission.

If a message is available:

```text
msg := DEQ buffer            ; ∇
Σ commit_recv                ; Σ
Θ wake sender if waiting
```

If empty:

* blocking: enqueue in `wait_recv`, block, Λ on timeout;
* non-blocking: return Λ.

##### Channel close

1. Δ classify channel as open/closed.
2. Ω check CLOSE capability.
3. ∇ set `state.closed := 1`.
4. Θ wake all waiters.
5. Φ mark subsequent messages as invalid.
6. Σ commit close.

---

#### 7.2.6 RW-Locks (Ω, Θ, Δ, ∇, Σ)

RW-locks combine mutex and semaphore behavior.

State:

```text
state = (readers, writer_active, writer_waiters, reader_waiters)
```

##### read-lock

* Δ check `writer_active == 0`.
* Ω check read permission.
* Θ manage waiters.
* ∇ increment `readers`.
* Σ commit.

##### write-lock

* Δ check `readers == 0` and `writer_active == 0`.
* Ω check write permission.
* Θ enqueue or wake appropriate threads.
* ∇ set `writer_active := 1`.
* Σ commit.

Ψ can encode preferences:

* reader-preference,
* writer-preference,
* fairness policies.

---

#### 7.2.7 Futex-Like Primitives (Fast-Path ∇, Slow-Path Θ/Λ)

A futex (fast userspace lock) maps cleanly to PMS.

##### Fast path (user space only)

* Δ compare memory word.
* Ω ensure access rights.
* ∇ attempt atomic modification (CAS-like).
* Success → Σ commit.
* Failure → slow path.

##### Slow path (kernel)

* Θ enqueue thread.
* Λ wait with timeout.
* Φ wake on error or recontextualization (for example, mutex owner died).

This is the default primitive for PMS userland threading.

---

#### 7.2.8 Condition Variables (Λ, Θ, Ω, Φ)

Condition variable state:

```text
state = (waiters)
```

##### wait(cv, mutex)

1. Δ assert mutex is owned by the caller.
2. Ω check WAIT permission.
3. ∇ release mutex.
4. Θ enqueue thread.
5. WAIT (timeout → Λ).
6. Once signaled → Θ resume.
7. Re-acquire mutex via ∇.

##### signal / broadcast

1. Δ check waiter list.
2. Ω verify SIGNAL rights.
3. Θ select waiter(s).
4. ∇ wake them.
5. Σ commit signal.

Φ handles:

* mutex death,
* policy violations,
* invalid wake-ups.

---

#### 7.2.9 Synchronization as Operator Algebra

Each primitive corresponds to a legal PMS operator word.

##### Mutex lock attempt (success path)

```text
Δ ; Ω ; ∇ ; Σ
```

##### Mutex lock (blocking path)

```text
Δ ; Ω ; Θ ; Λ ; Θ ; ∇ ; Σ
```

##### Semaphore signal (V)

```text
Δ ; Ω ; ∇ ; Θ ; Σ
```

##### Channel synchronous receive

```text
Δ ; Ω ; (Λ or ∇) ; Φ ; Σ
```

These sequences respect the dependency constraints defined earlier.

---

#### 7.2.10 Policy-Level Guarantees (Ψ)

Ψ governs:

* fairness,
* ordering,
* maximum lock hold time,
* priority inheritance,
* deadlock detection,
* capability bounds,
* starvation prevention,
* distributed consistency of lock semantics.

Ψ can enforce scheduling invariants such as:

```text
Ψ: NO_THREAD_WAITING_FOREVER
Ψ: WRITER_PRIORITY
Ψ: FIFO_SEMAPHORE
Ψ: NONBLOCKING_CHANNELS_ONLY
```

Ψ is the regulator and can override or cancel transitions.

---

#### 7.2.11 Summary

Synchronization in PMS-OS is built on:

| Operator | Structural Function                                           |
| -------- | ------------------------------------------------------------- |
| Δ    | inspect resource state (lock free? count?)                    |
| Ω    | ensure correct privilege and capability use                   |
| Θ    | manage wait queues, order, scheduling                         |
| Λ    | timeouts, empty buffer semantics                              |
| ∇    | atomic updates (lock, unlock, count, enqueue)                 |
| Σ    | commit updates, wake operations, finalize consistency         |
| Φ    | handle invalid states, recontextualization, exceptional flows |
| Χ    | isolate sync objects between processes                        |
| □    | synchronization primitives as frames                          |
| Ψ    | global policies for fairness and correctness                  |

This yields a uniform, axiomatic, verifiable synchronization subsystem.

---

### 7.3 Event System and Notifications (Θ, Λ, Φ, Ω, Δ, Σ)

timers, signals, pub-sub — PMS-OS structural definition

Event handling in PMS-OS is not a bolt-on mechanism:
it emerges naturally from the PMS operators for ordering (Θ), absence or non-event (Λ), recontextualization (Φ), asymmetry (Ω), isolation (Χ), distinction (Δ), and commit (Σ), together with the tau-based time reference in the meta-state.

Events are operator-triggerable transitions that may originate:

* internally (Θ-ordered checks over tau for timers, scheduler steps),
* externally (interrupts, device signals),
* cross-process (IPC, signals),
* system-wide (policy notifications, recontextualization events).

All are defined uniformly.

---

#### 7.3.1 Event Model Overview

A PMS event is a typed transition trigger:

```text
Event = (kind, payload, source, target, meta)
```

with:

* kind — operator-level distinction of event type,
* payload — arbitrary data,
* source — process, device, timer, kernel, and so on,
* target — process, sync primitive, channel, or global handler,
* meta — tau-based timestamp, Λ absence flags, Φ error states, Ω required roles.

Events do not mutate anything directly:
they request that some event handler run a PMS operator sequence.

---

#### 7.3.2 Component: EventFrames (□ + Χ)

All events exist inside an EventFrame:

```text
EventFrame = (queue, routing, filters, perms, meta)
```

* queue: Θ-ordered event list,
* routing: mapping from event kind to handler function,
* filters: optional Ψ policies (for example, throttling, priority),
* perms: Ω capability matrix (who may send/receive),
* meta: tau-linked timestamps, error counters, Θ-order tags, last-Φ states.

Χ can isolate `EventFrame` instances per process or security domain.

---

#### 7.3.3 Timers (Θ, Λ, Σ)

Timers are τ-based constructs: they use τ as kernel time reference and Θ to sequence when checks and callbacks are performed.

##### Structures

```text
Timer = (deadline, mode, callback, active)
```

with `deadline` stored in `m.τ.deadlines` inside the meta-state `m.τ`.

##### Timer Operation

(1) Registration

```text
Δ: classify timer parameters
Ω: capability check (create timer)
∇: install or update m.τ.deadlines[timer_id]
Σ: commit registration
```

(2) Θ-ordered activation

At Θ-ordered scheduler steps, the kernel checks the τ-based deadline:

```text
Δ compare τ.now >= m.τ.deadlines[timer_id]
if false: continue
if true: Θ schedule callback event
```

Θ here induces the ordering of when these τ-comparisons and callbacks occur; all actual time values live in τ.

(3) Timer miss / expiry → Λ

If execution cannot occur before the intended deadline due to:

* CPU starvation
* isolation blocking
* policy throttling

then a Λ-event is triggered:

```text
Λ: timer_missed
Φ: optional recontextualization (defer, reschedule)
```

Timers are thus Θ-sequenced Δ/∇/Σ interactions with τ, producing Λ/Φ-class events when deadlines are not met.

---

#### 7.3.4 Signals (Δ, Ω, Θ, Φ, Σ)

Signals are lightweight, asynchronous notifications.

Examples: `SIGIO`, `SIGCHLD`, `SIGTERM` (abstract PMS analogues).

##### SignalFrame

```text
SignalFrame = (pending, handlers, perms, meta)
```

##### Sending a signal

```text
Δ classify signal kind
Ω check SEND_SIGNAL capability
Θ enqueue into target.pending
Σ commit enqueue
```

##### Delivering a signal

On each scheduling boundary (Θ), a process checks:

```text
Δ if pending ≠ ∅
Ω ensure process can receive signals
Θ dequeue one signal
Φ enter signal-handler frame
execute handler
Σ return to main frame
```

##### Failed delivery → Λ

```text
Λ: signal_dropped (blocked, dead task, invalid handler)
Φ: recover (redirect, default handler, escalate)
```

Signal delivery therefore uses:

```text
Δ ; Ω ; Θ ; (optional Φ) ; Σ
```

the minimal operator chain for asynchronous forcing of control flow.

---

#### 7.3.5 Pub-Sub System (Δ, Ω, Θ, Χ, Σ, Λ, Φ)

PMS pub-sub is structurally native: it is built from EventFrames arranged into topic frames.

##### TopicFrame

```text
TopicFrame = (topic_id, subscribers, backlog, perms, meta)
```

##### Publish(message)

1. Δ: classify topic
2. Ω: verify PUBLISH permission
3. Θ: append message to topic backlog
4. Σ: make message visible
5. Θ: enqueue delivery events for each subscriber

##### Subscribe(process)

1. Δ: check that topic exists
2. Ω: SUBSCRIBE permission
3. ∇: add subscriber to list
4. Σ: commit

##### Delivery

Each subscriber receives events through its EventFrame:

```text
Δ classify message
Θ schedule delivery
Ω check RECEIVE permission
∇ deliver into mailbox or channel
Σ commit
```

##### When subscriber is not ready → Λ

```text
Λ: subscriber_unavailable
Φ: drop, retry, buffer, or reroute depending on Ψ policy
```

##### Isolation: Χ

TopicFrames can be isolated per namespace or security class:

* tenants
* containers
* user sessions
* privilege domains

Χ ensures no cross-talk without explicit Ω permission.

---

#### 7.3.6 Timers, Signals, Pub-Sub in Unison (Event Algebra)

All event mechanisms reduce to operator chains of the following forms.

##### Timer event

```text
Θ ; Δ ; Θ ; Σ
```

with τ providing the underlying time reference.

##### Signal

```text
Δ ; Ω ; Θ ; (optional Φ) ; Σ
```

##### Pub-sub publish

```text
Δ ; Ω ; Θ ; Σ
```

##### Delivery failure

```text
Δ ; Λ ; Φ ; (optional Σ)
```

##### Recontextualized event handling

```text
Δ ; Φ ; Θ ; Σ
```

Thus all events are algebraically expressible as PMS-valid sequences.

---

#### 7.3.7 Event Routing Engine (Kernel)

The kernel has an `EventRouter`:

```text
EventRouter = (routing_table, filters, perms, backlog, meta)
```

Processing loop:

1. Θ step advances the routing cycle
2. Δ check incoming event queues
3. Ω verify that event is allowed
4. Θ route to destination EventFrame
5. Φ recontextualize if target is unavailable
6. Σ commit routing

---

#### 7.3.8 Policy (Ψ) Over Events

Ψ governs:

* event rate limits
* masking rules
* signal default actions
* timer reliability constraints (via τ and Θ)
* pub-sub topic visibility
* global ordering guarantees (Θ policies)

Ψ can cancel or redirect events by overriding valid transitions:

```text
Ψ: deny_signal(SIGKILL) in sandboxed process
Ψ: enforce FIFO delivery on topic "orders"
Ψ: prohibit real-time timers in low-privilege domains
```

Ψ is the ultimate arbiter of event behavior.

---

#### 7.3.9 Summary

| Mechanism | Δ | Ω | Θ | Λ | Φ | Σ | Χ | Function                                                  |
| --------- | - | - | - | - | - | - | - | --------------------------------------------------------- |
| Timers    | ✓ | – | ✓ | ✓ | ✓ | ✓ | – | deadline and timeout events (τ-based, Θ-sequenced checks) |
| Signals   | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | asynchronous notifications                                |
| Pub-sub   | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | topic-based messaging                                     |

All event behavior emerges from PMS operators, respecting structural grammar and dependency constraints.

---

## 8 Device and Driver Model

### 8.1 Driver Roles and Capabilities (Ω)

*Axiomatic grounding: Ω = asymmetric access structure, privilege gradients, directional capability relations.*

In PMS-STACK, a driver is not an ad-hoc piece of software.
It is a role-bound execution locus with Ω-typed capability edges that define:

1. what parts of the hardware abstraction it may act on (Δ-bound referents),
2. how it may act (∇ privileges),
3. under which frame its operations are interpreted (□ context),
4. what policies constrain it (Ψ),
5. and which asymmetries it introduces relative to the kernel and device (Ω edges).

Thus, the driver model is entirely derivable from the structure:

```text
Ω: Role and capability operator enforcing directional asymmetries.
```

---

#### 8.1.1 Drivers as Ω-Structured Roles

A driver is defined as a triple:

```text
D = (f_D, r_D, C_D)
```

where:

* `f_D ∈ F` — the driver frame: contextual namespace for device registers, MMIO regions, protocol semantics (grounded in □).
* `r_D ∈ R` — the driver role: a specific Ω-mode that grants exactly the capabilities required to operate the device.
* `C_D ⊆ Capabilities` — the capability set: a finite set of Ω edges describing directed permissions, for example:

  * read capability: `Ω(read → device-register-X)`
  * write capability: `Ω(write → device-register-Y)`
  * interrupt-ack capability: `Ω(ack → IRQ-n)`
  * DMA grant capability: `Ω(dma-map → region)`
  * isolation-entry capability: `Ω(enter → Χ-subcontext)`

These are all Ω-typed relations:

```text
Ω(r_D, action_type, target)
```

The Ω constraints ensure:

* a driver cannot operate outside its declared domain,
* the kernel can formally prove safety properties by checking Ω edges,
* capability elevation and reduction are structurally typed operations.

---

#### 8.1.2 Capability Classes (Ω Families)

All driver capabilities fall into five structural Ω families, each corresponding to PMS operator interplay.

##### (A) Access Capabilities (Δ → ∇ restricted by Ω)

What hardware objects the driver may distinguish or act on.

Examples:

* `Ω(read, register)`
* `Ω(write, register)`
* `Ω(read, config-space)`
* `Ω(write, MMIO-range)`

These restrict ∇ to only the permitted Δ-distinguished objects.

---

##### (B) Ordering and Dispatch Capabilities (Ω → Θ)

Permissions affecting how the driver participates in scheduling and ordered dispatch:

* `Ω(allow-interrupt-handler)`
* `Ω(allow-deferred-work)`
* `Ω(timer-arm)`
* `Ω(timeout-register)`

These define which Θ transitions the driver can initiate.

---

##### (C) Contextual Capabilities (Ω → □)

Permissions to enter or manipulate frames:

* `Ω(enter-driver-frame)`
* `Ω(map-device-frame)`
* `Ω(switch-to-config-frame)`

Without these, the driver cannot perform □ operations affecting device context.

---

##### (D) Isolation Capabilities (Ω → Χ)

Permissions to create, enter, or exit isolation domains for safe operation:

* `Ω(spawn-iosandbox)`
* `Ω(access-ringbuffer-subset)`
* `Ω(allow-DMA-scope)`

These define which Χ transformations are legal for the driver.

---

##### (E) Policy Capabilities (Ω → Ψ)

Permissions to apply or modify policies affecting the device domain:

* `Ω(apply-power-policy)`
* `Ω(change-error-policy)`
* `Ω(register-policy-hooks)`

These control how Ψ changes influence the driver’s future actions.

---

#### 8.1.3 Driver–Kernel Asymmetry Graph (Ω Graph)

Every PMS-OS defines an Ω asymmetry graph.

Nodes:

* kernel role (`r_K`)
* driver roles (`r_D1`, `r_D2`, …)
* optional device-domain roles (`r_dev_low`, `r_dev_high`)

Edges:

* directional Ω edges defining legal capability flows

Graph invariant:

```text
Ω(r_K) ⊇ Ω(r_D) ⊇ Ω(r_dev)
```

Drivers may have strictly less capability than the kernel but more than raw device roles.
This encodes the standard “kernel > driver > device” trust hierarchy without hardcoding it; it is generated structurally.

---

#### 8.1.4 Driver Execution Model Under Ω Constraints

At runtime, the driver executes PMS-CPU instructions, but each instruction prefixed by ∇ or □ must pass an Ω-check:

```text
Allowed(op, target, s) ⇔ Ω(r_D) entails (op, target)
```

Examples:

* `∇(write MMIO_x)` requires `Ω(write, MMIO_x)`
* `□(enter dma-frame)` requires `Ω(enter-dma-frame)`
* `Θ(interrupt-ack)` requires `Ω(ack IRQ)`

If an instruction lacks a supporting Ω edge:

* Ψ may block it,
* the kernel may reframe via Φ (for example, fallback mode),
* or an isolation fallback may occur via Χ.

Thus Ω defines the admissible operator space for the driver.

---

#### 8.1.5 Capability Elevation and Reduction (Ω Transitions)

Ω itself is an operator with dependencies:

```text
Δ ≼ Ω ≺ ∇, □, Θ
```

A capability transition occurs through an instruction:

```text
I_Ω-update = (Ω, pre, post)
```

Two forms:

##### (A) Elevation (controlled)

Allowed only if:

* kernel role `r_K` authorizes elevation via Ψ policy, and
* Δ distinguishes the correct device and operation type.

Effect:

```text
r_D' = r_D ⊕ C
```

where `C` is a capability subset.

##### (B) Reduction (always safe)

```text
r_D' = r_D \ C
```

Used for:

* entering restricted modes,
* fault conditions,
* device reset states.

All changes to capabilities flow through Ω-typed transitions.

---

#### 8.1.6 Driver Modularity via Ω-Framed Capability Sets

Drivers are decomposed into Ω modules, each with its own capability subset:

* init module (`Ω_init`)
* IRQ handler module (`Ω_irq`)
* configuration module (`Ω_cfg`)
* data-path module (`Ω_dp`)
* control-plane module (`Ω_ctl`)

Each module is framed:

```text
M = (□_module, Ω_module, Ψ_module)
```

This provides:

* strict scoping of what each module may do,
* minimal crossing points,
* predictable reasoning for runtime verification.

The kernel loads modules and composes their frames using □ and Σ.

---

#### 8.1.7 Driver–Device Binding (Δ → Ω → □)

Attaching a driver to a device is a structural sequence.

1. Δ(device-id)
   Distinguish the device type.

2. Ω(assign driver role)
   Install the capability profile for that device type.

3. □(enter driver frame)
   Switch to driver context where its MMIO mappings, protocol semantics, and policies apply.

This ensures that no driver can attach itself to a device: the kernel must initiate Δ and Ω.

---

#### 8.1.8 Summary of 8.1

Summary of the full structure of drivers under PMS:

| Structural Element          | PMS Operator | Meaning                                              |
| --------------------------- | ------------ | ---------------------------------------------------- |
| Driver identity             | Δ            | device-type distinctions used to select driver logic |
| Driver action permissions   | Ω            | capability edges restricting ∇, □, Θ                 |
| Driver execution context    | □            | frame for device registers and protocols             |
| Driver scheduling and order | Θ            | placement in IRQ and deferred queues                 |
| Driver isolation            | Χ            | DMA sandboxes, memory protection                     |
| Driver policy domain        | Ψ            | power and error policy, safety constraints           |

Drivers are Ω-structured entities.
Their behaviors are legal only if Ω edges allow the operator sequences they attempt.
This gives a formal, verifiable, capability-secured driver model.

---

### 8.2 Interrupt Handling Path (Φ + Θ)

*Structural mode: interrupts as Φ-driven recontextualization; ordering and dispatch via Θ; privileges by Ω; isolation by Χ.*

We already have:

* CPU-level Φ semantics (how the PMS-CPU enters and exits handlers),
* Ω-based driver roles and capabilities (8.1),
* Θ-based ordering and scheduling in the kernel,
* Χ-based isolation and □-based frames.

Now we assemble these into a full interrupt path from wire → CPU → kernel → driver → scheduler → process, using Φ + Θ as the backbone.

---

#### 8.2.1 Goals and Structural View

The PMS interrupt path is designed to:

1. Treat every interrupt as a Φ event:

   * recontextualization of execution,
   * change of role (Ω) and frame (□),
   * optional isolation changes (Χ).

2. Use Θ for:

   * ordering and priority,
   * sequencing of timer and tick handling and dispatch steps over τ and the scheduler,
   * safe integration with scheduling.

3. Use Ψ to enforce invariants:

   * bounded handler progression,
   * no illegal capability use,
   * safe exit back to the pre-interrupt context or safe fallback on failure.

We split the path into:

* hardware → CPU Φ-entry (low-level),
* CPU → kernel interrupt core (dispatcher),
* kernel core → driver top half (hard IRQ),
* deferred bottom half / softirq / workqueue (Θ-mediated),
* return path (Φ-exit + Σ integration).

---

#### 8.2.2 Interrupt Lifecycle Phases

An interrupt’s life is structurally:

```text
device event
  → (Δ) IRQ line
  → (Φ_CPU) CPU interrupt entry
  → kernel IRQ context
  → (Δ / Ω / Θ) driver handler
  → (Σ / Θ) completion and return
```

Canonical phases:

1. Signal generation (device → IRQ) — device asserts an interrupt line, distinguished by Δ.
2. CPU recognition and Φ-entry — PMS-CPU performs Φ: saves context, switches role and frame.
3. Kernel interrupt dispatch — kernel Δ-selects handler, uses Ω to check driver capabilities.
4. Driver top-half handler — runs in interrupt context with strict Ψ limits.
5. Deferred bottom-half / softirq — Θ-scheduled work in process or soft-interrupt context.
6. Completion and wakeups — Σ integrates results, Θ awakens sleepers, Λ and timeouts handled.
7. Φ-exit and return to pre-interrupt context — EXC_RET-style recontextualization back to user or kernel code.

Each step is a PMS-valid sequence: `Δ → Ω/□ → Φ → Θ → Σ/Ψ`, respecting dependency constraints.

---

#### 8.2.3 CPU-Level Interrupt Entry (Φ Core Recap)

When an IRQ `irq` fires while some context is executing (user or kernel):

1. Asynchronous event arrives (external, modeled via Δ)
   The CPU’s interrupt controller distinguishes an IRQ number:

   ```text
   Δ_irq: classify line → irq_id
   ```

2. Φ-entry microsequence (specialized for drivers):

   Conceptually:

   ```asm
   ; auto-generated by hardware or microcode (Φ)
   PUSH  PC              ; ∇
   PUSH  SR              ; ∇
   PUSH  FR              ; ∇
   ; optionally PUSH R4..R7, etc.

   SET_ROLE  ROLE_KERNEL ; Ω
   FRM_ENTER FR_KSTACK   ; □
   ; record cause in meta m: m.exc.cause = irq_id
   JMP  IVT[irq_id]      ; Δ
   ```

   Structural operators:

   * Φ — we are not executing in the old context anymore,
   * Ω — move to kernel role,
   * □ — move to kernel stack and frame,
   * Θ — induces the next ordering step; ∇ and Σ may update interrupt-related counters in `m.τ`,
   * Χ — implicit: isolation boundaries are reinterpreted under the kernel frame.

The IVT entry (Interrupt Vector Table) for `irq_id` points into the kernel interrupt core, not directly into driver code.

---

#### 8.2.4 Kernel Interrupt Core: Dispatch Layer (Δ + Ω + Θ)

##### 8.2.4.1 IRQ Controller Abstraction Frame

The kernel exposes an IRQ controller frame:

```text
FR_IRQ = (IRQ descriptors, priority, routing, mask state)
```

Each IRQ is represented by:

```text
struct IRQDesc {
    int        irq_id;
    Priority   prio;
    DriverID   owner;        // which driver (if any) handles this
    HandlerFn  top_half;     // hard-IRQ handler entry
    HandlerFn  bottom_half;  // deferred handler (optional)
    PolicyID   pol;          // Ψ constraints for this IRQ
    CapSet     caps;         // Ω capabilities bound to this IRQ
}
```

##### 8.2.4.2 Core dispatch sequence

In the kernel IRQ entry stub (running under Φ, Ω, and □):

1. Lookup descriptor (Δ)

   ```text
   desc = IRQDesc[irq_id]      ; Δ – classification
   ```

2. Policy gate (Ψ)

   * Check whether this IRQ is enabled, not masked, and allowed under current state:

     * power state,
     * CPU affinity,
     * rate-limiting, and so on.

   If policy denies:

   * either ignore (Λ path: non-event for software),
   * or route to a special policy handler.

3. Priority and nesting control (Θ + Ψ)

   * Compare `desc.prio` with `m.current_irq_prio`.
   * If lower priority and nesting not allowed, mark as pending and return (Θ will process later).
   * Otherwise, update `m.current_irq_prio` and `m.irq_nesting++`.

4. Ω capability check

   * Verify that the driver associated with `desc.owner` has capability:

     ```text
     Ω(r_D, handle_irq, irq_id)
     ```

   * If not, Ψ can route to a fallback handler or treat as a security violation.

5. Invoke top-half handler

   * Jump to `desc.top_half` with appropriate calling convention:

     ```asm
     CALL desc.top_half        ; ∇ – driver’s top-half
     ```

   This call runs under:

   * role `r_K` (kernel role) or a driver-specific privileged role `r_D^K`,
   * kernel stack frame (□),
   * with interrupt state (for example, nested interrupts) tracked in `m`.

---

#### 8.2.5 Driver Top Half: Hard IRQ Handler (Φ Domain)

##### 8.2.5.1 Contract and Constraints

The top half is the driver’s time-critical handler executed in interrupt context.

* Must be bounded in execution as measured via τ (Ψ bound).
* Operates under a privileged role (Ω) but with limited capabilities `C_D`.
* Executes in a non-schedulable context:

  * cannot block,
  * cannot perform unbounded allocations,
  * cannot call heavy APIs that might sleep or wait.

PMS view:

* This is a Φ sub-context overlaid on top of the interrupted context.
* Θ transitions are available but constrained: Ψ uses τ-based limits to forbid unbounded sequences within the handler.

##### 8.2.5.2 Typical handler structure

Pseudo-ISA:

```asm
; R_irq, current IRQ descriptor available
driver_irq_top:
    ; Acknowledge interrupt at device level (∇ + Ω + □)
    ; for example, read status register, write ack bit:
    LOAD  Rstatus, FRdev + STATUS_REG        ; ∇
    ; Δ-distinguish cause bits:
    TSTI  Rstatus, MASK_RX                   ; Δ
    BEQ   no_rx                              ; Δ

    ; Clear interrupt flag:
    STORE FRdev + STATUS_REG, Rclear         ; ∇

    ; Enqueue work item for bottom half (Θ + Σ)
    CALL  schedule_bottom_half               ; ∇

no_rx:
    ; Possibly handle TX complete, errors, etc.
    ; Minimal core work here

    RET                                       ; ∇
```

Operators involved:

* □ — device frame `FRdev` maps MMIO registers,
* Ω — permissions enforced on register access and scheduling calls,
* Θ — scheduling API used to queue deferred work,
* Σ — integration of “event occurred” into system state (for example, queued I/O completion).

The top half’s main job:

1. Confirm the interrupt (Δ).
2. Acknowledge and clear hardware state (∇ under Ω and □).
3. Schedule deferred work (Θ).
4. Exit as fast as possible to keep latency low.

---

#### 8.2.6 Bottom Half and Deferred Work (Θ + Σ)

Heavy or blocking work is deferred from Φ context to normal schedulable contexts using Θ.

We provide three structural patterns (the implementation can choose or mix):

1. soft-IRQ context (still “interrupt-like”, but schedulable slices),
2. dedicated kernel threads and work queues,
3. process-level callbacks and completions.

All share the same pattern:

```text
top-half → (Θ_schedule) → deferred context → (Σ) → completion
```

##### 8.2.6.1 Soft IRQ (interrupt bottom half)

* Implemented as a kernel-managed queue of pending work items.
* Each work item is a small function pointer and an argument frame.

Example structure:

```text
struct SoftIRQTask {
    HandlerFn fn;
    void*     arg;
    Priority  prio;
    PolicyID  pol;
}
```

Top half schedules:

```asm
; In top half:
MOV  R0, &softirq_rx_task   ; ∇
CALL softirq_enqueue        ; ∇  (Θ scheduling primitive)
```

Later, in soft-IRQ processing context:

```asm
softirq_loop:
    TASK = dequeue_next_softirq()   ; ∇ + Θ
    IF TASK != NULL:
        CALL TASK.fn(TASK.arg)      ; ∇ – run bottom-half handler
        GOTO softirq_loop
    ELSE:
        RETURN                      ; ∇
```

Here:

* Θ defines when soft-IRQ processing runs (post-IRQ, idle, and so on).
* Ψ ensures no starvation and bounds on execution (combined with τ-based budgets).

##### 8.2.6.2 Work queues and kernel threads

For long-running tasks, the driver can offload to work queues:

* A work queue is a pool of kernel threads.
* Each work item is processed in a normal thread context, with ability to:

  * block,
  * allocate memory,
  * call any safe API.

Pattern:

```asm
; In top half:
MOV  R0, &work_item         ; ∇
CALL workqueue_schedule     ; ∇  (Θ)

; In worker thread (normal kernel context, Ω = ROLE_KERNEL_THREAD):
CALL driver_bottom          ; ∇
```

Θ is responsible for:

* mapping pending work onto worker threads,
* ordering by priority or fairness rules.

##### 8.2.6.3 Process-level completion

For user-visible operations (read/write, asynchronous I/O), bottom halves typically:

1. complete kernel bookkeeping (Σ on in-kernel state),
2. wake tasks waiting on events (Θ scheduling to signal results),
3. deliver signals or completion notifications via IPC (Δ, Ω, Λ, Θ, Φ interplay as defined in section 7).

---

#### 8.2.7 Scheduling, Priorities, and Ordering (Θ + Ψ)

##### 8.2.7.1 IRQ priority model

Each IRQ has an integer priority `prio` and a class (for example, timer, I/O, critical, best-effort).

Θ and Ψ combine to enforce:

* preemption rules:

  * higher-priority IRQ can preempt lower-priority handlers if `SR.interrupt_enable` is set and Ψ allows.

* masking / affinity:

  * masks determined by policy (Ψ) and cores (Θ scheduling across CPUs if multicore).

##### 8.2.7.2 Non-preemptive vs preemptive interrupt handling

Two structural modes:

1. Non-preemptive IRQ handling:

   * Once in an IRQ handler, other interrupts are masked except critical ones.
   * This is just a Ψ rule, for example:

     `Ψ_nonpreempt: for all irq' with priority(irq') ≤ priority(irq), irq' is masked.`

2. Preemptive IRQ handling:

   * Higher-priority IRQs can nest.
   * `m.irq_nesting` and `m.current_irq_prio` track this.
   * Ψ ensures bounded nesting to avoid stack overflow.

##### 8.2.7.3 Interaction with process scheduler

The scheduler (Θ, section 3.4) is integrated via:

* timer interrupts:

  * dedicated IRQs that periodically trigger scheduler tick handlers.
  * these run in kernel IRQ context and can:

    * account CPU usage in τ (3.8),
    * reevaluate run queues,
    * possibly trigger rescheduling.

* wakeups:

  * bottom halves or softirqs call into the scheduler to wake blocked tasks.
  * structurally this is Θ: moving a task from blocked to runnable.

---

#### 8.2.8 Driver-Facing Interrupt Contract

From the point of view of a driver author, PMS-OS offers a structured contract.

##### Registration

Drivers register interest in interrupts via a call like:

```c
int register_irq_handler(int irq, HandlerFn top, HandlerFn bottom, CapSet caps, PolicyID pol);
```

Structural meaning:

1. Δ: distinguish `irq` and driver identity.
2. Ω: ensure driver has needed capabilities in `caps`.
3. Ψ: attach policy `pol` governing rate limits, nesting rules, CPU affinity.
4. □: bind handler into IRQ frame (update `IRQDesc`).

##### Top-half API constraints

Top-half handlers:

* must not:

  * block,
  * allocate unboundedly,
  * call APIs marked “sleepable”.
* should:

  * acknowledge device,
  * queue bottom half,
  * return quickly.

These rules are enforced by:

* Ω (only specific APIs exposed in top-half context),
* Ψ (runtime checks or static analysis),
* tools in section 11 (static proof).

##### Bottom-half API

Bottom halves:

* may block and use full kernel interfaces,
* must still obey policy `pol`:

  * for example, max τ-based latency to complete I/O,
  * fairness to other tasks.

Bottom halves must not violate isolation (Χ) or capability boundaries (Ω); they still run under a role `r_D` but in a thread context.

---

#### 8.2.9 Faults During Interrupt Handling (Φ-of-Φ)

If a fault occurs inside an interrupt handler (for example, illegal access, capability violation, unexpected null), this triggers a nested Φ:

1. Φ_fault entry:

   * save the current (already in Φ) context,
   * optionally switch to a more privileged debug or error-handler role.

2. Error policy `Ψ_fault` decides:

   * terminate the offending driver,
   * mask the IRQ,
   * quarantine the device (Χ: drop from visible frame),
   * panic or halt if fatal.

3. Recovery:

   * attempt to reframe state (Φ) to a safe mode, or
   * rollback partial work (Σ and Ψ cooperation),
   * then `EXC_RET` back to the pre-interrupt context or to a safe stop state.

This explicitly avoids “undefined behavior inside interrupts”: every misbehavior is a structural Φ + Ψ event with defined resolution paths.

---

#### 8.2.10 Summary (Interrupt Path)

The PMS interrupt path is:

* Φ-centric: every interrupt, trap, and exception is a structured recontextualization.
* Θ-backed: ordering and scheduling of top/bottom halves and soft tasks, including how τ-based timer events are integrated.
* Ω-governed: drivers can only act according to their capability sets.
* Χ-isolated: device and kernel states are protected by frames and isolation domains.
* Ψ-guarded: policies ensure bounded, safe, and fair handling, even under nesting and faults.
* Σ-integrated: results of interrupt handling (I/O completions, wakeups, state transitions) are explicitly committed in bottom halves and scheduler hooks.

This yields a precise, compositional model for interrupt handling that we reuse in:

* 8.3 Driver Lifecycle and Policy (Ψ)
* 8.4 Hotplug and Dynamic Reconfiguration (Φ/Ψ + Χ/□)

---

### 8.3 Driver Lifecycle and Policy (Ψ)

*Structural mode: drivers as governed agents; policies Ψ define admissible trajectories across their lifecycles.*

We already have:

* Ω: driver roles and capabilities (8.1),
* Φ + Θ: interrupt and trap model (8.2),
* Χ: isolation domains (3.5, 6.1),
* Σ: integration and commit (FS, memory, IPC),
* Ψ: global invariants and policies (0.x, 3.x, 8.x).

Now we define a driver lifecycle model where:

* a driver is a role-bearing, policy-bound agent attached to devices,
* its lifecycle is a state machine constrained by Ψ,
* all transitions are explicit PMS operator sequences (Δ, Ω, Θ, Φ, Χ, Σ, Ψ).

---

#### 8.3.1 Entities and Policy Layers

We distinguish four main entities:

1. Driver module (D) – code, metadata, and policies.
2. Device (Dev) – hardware or virtual endpoint (PCI device, network interface, block device, and so on).
3. Binding (B) – relation `(D, Dev)` meaning “driver D handles device Dev”.
4. Driver context (C_D) – runtime execution context(s) of D:

   * IRQ handlers, bottom halves, workqueues, threads, control operations.

##### Policy layers (Ψ)

Policies apply at multiple levels:

1. Ψ_K – kernel-global policy:

   * which driver classes are allowed at all,
   * signing, attestation, and trust domain constraints,
   * global resource budgets and safety constraints.

2. Ψ_class – device-class policies:

   * for example, “network drivers must use sandbox X”,
   * “storage drivers require journaling hooks”,
   * “USB drivers must be hotplug-aware”.

3. Ψ_D – per-driver policy:

   * capacities, τ-based bounds, isolation mode, allowed syscalls, logging and audit requirements.

4. Ψ_dev – per-device policy:

   * per-port and per-device config (which drivers may bind, which modes allowed).

The effective policy at runtime is:

`Ψ_eff(D, Dev) = Ψ_K ∧ Ψ_class(Dev) ∧ Ψ_D ∧ Ψ_dev`

All driver lifecycle transitions must satisfy `Ψ_eff`.

---

#### 8.3.2 Driver Lifecycle States

Each driver module `D` has a lifecycle state:

* S₀: Uninstalled – not present in system.
* S₁: Installed – code and metadata present (on disk or in image), registered with kernel.
* S₂: Loaded – code mapped into memory, symbols resolved.
* S₃: Probed – candidate devices have been tested for compatibility.
* S₄: Bound / Active – driver has one or more live `(D, Dev)` bindings.
* S₅: Suspended – driver and devices quiesced (power management, sleep).
* S₆: Error / Degraded – policy violation or runtime failure detected, but not yet fully unloaded.
* S₇: Quarantined – isolated via Χ; only limited recovery and introspection allowed.
* S₈: Unloaded – code detached; no active bindings; resources reclaimed.

Each `(D, Dev)` binding has its own binding-state subgraph, but we mostly talk at the driver-module level and refer to per-device binding when needed.

---

#### 8.3.3 Lifecycle State Machine (Operators on Transitions)

We describe core transitions and the dominant PMS operators involved. Each transition is governed by Ψ and Ω, and often uses Φ, Χ, Σ, Θ, and Δ.

##### T1: Install → Load (S₁ → S₂)

Operators: Δ, Σ, Ψ, □

1. Δ: kernel distinguishes driver artifact (name, version, class, signature).
2. Ψ_K / Ψ_class: check:

   * allowed driver class?
   * signature and attestation valid?
   * not explicitly blacklisted?
3. Σ: integrate driver into the driver registry:

   * add D to `DriverTable`,
   * record class, supported IDs, policy handle `Ψ_D`, capabilities `Ω_D`.
4. □: map driver code into kernel frame:

   * allocate code and data frames,
   * set `FR_D_code`, `FR_D_data`.

Result: `S₂: Loaded`.
If Ψ fails, installation is rejected (stay in S₁ or back to S₀) and may trigger audit logs.

---

##### T2: Load → Probe (S₂ → S₃)

Operators: Δ, Ω, Ψ, Θ, Λ

Probe = testing which devices this driver can handle.

1. Δ: enumerate candidate devices `Dev_i` whose IDs match D’s declared match table.
2. Ψ_class / Ψ_dev: filter by policy:

   * some devices may require only trusted drivers,
   * some may require signed-only.
3. Ω: verify driver capability to access the device’s bus or frame:

   * `Ω(r_D, access_bus, Dev)` must hold.
4. Θ: run hardware and software probes as a finite ordering sequence; Ψ uses τ and Λ to enforce probe timeouts:

   * read device registers,
   * send probe commands,
   * all bounded by policy (no unbounded loops; `Λ_timeout` derived from τ.now and τ.deadline).

If a probe succeeds for a device, we move along a binding transition (T3). If all probes fail, driver remains Loaded (S₂) but unbound; or policy may allow auto-unload.

---

##### T3: Probe → Bound / Active (S₃ → S₄)

Operators: Φ, Χ, Σ, Ω, Ψ

Binding `(D, Dev)`:

1. Φ (recontextualization):

   * interpret Dev as now “owned” or co-owned by D,
   * switch device’s MMIO or command frame into a driver-specific isolation domain:

     * set `FR_dev_D`, or attach Dev to a driver-specific Χ compartment.
2. Ω:

   * assign driver context role `r_D^K` (kernel driver role),
   * assign capabilities `C_D` for:

     * bus access,
     * interrupts registration,
     * DMA (if allowed),
     * control operations.
3. Σ:

   * commit binding into driver bindings:

     * `(D, Dev) → Bound`,
   * set up IRQ handlers (register top and bottom halves using the model from 8.2),
   * allocate internal queues, buffers, and control structures.
4. Ψ:

   * activate `Ψ_eff(D, Dev)` for this binding,
   * may include:

     * interrupt and I/O rate limits (defined over τ),
     * maximum memory for buffers,
     * isolation level (Χ mode),
     * audit level (logging hooks, etc.).

Driver is now Bound / Active (S₄) for that device.

---

##### T4: Active ↔ Suspended (S₄ ⇄ S₅)

Operators: Θ, Ψ, Φ, Σ, Λ

Suspension handles power management / sleep / device quiescing.

###### S₄ → S₅ (Suspend)

From Active to Suspended:

1. Θ: enter an ordered suspend sequence.
2. Ψ: check if driver and device are in a suspendable state:

   * no critical I/O in flight,
   * no unsynced data (Σ not pending),
   * power constraints satisfied.
3. Φ: recontextualization:

   * device moves into low-power or inactive frame,
   * some operations become prohibited by Ψ.
4. Σ:

   * flush buffers,
   * finalize outstanding I/O,
   * update FS, network, and system state to keep invariants intact.
5. Λ:

   * mark outstanding expectations as “suspended” non-events,
   * for example, operations that would have happened but are now postponed using `Λ_timeout` over τ.

###### S₅ → S₄ (Resume)

1. Θ: resume sequence.
2. Ψ:

   * check that environment conditions allow resume (bus still present, security context valid).
3. Φ: recontextualize to active frame:

   * restore `FR_dev_D`,
   * re-enable interrupts (Ω plus SR flags),
   * reopen queues, restart timers.
4. Σ:

   * commit “device is now live” state,
   * wake any waiting users or processes.

If resume fails (lost device, policy change, error), go to Error/Degraded (S₆) or Quarantined (S₇).

---

##### T5: Active/Suspended → Error/Degraded (S₄/S₅ → S₆)

Operators: Ψ, Φ, Χ, Σ, Λ, Θ

This happens when:

* driver violates a policy,
* device misbehaves,
* repeated faults or τ-based timeouts (Λ over τ, sequenced via Θ),
* hardware errors detected.

1. Ψ_detect: observes violation:

   * driver exceeds interrupt budget,
   * tries forbidden frame access,
   * misuses capabilities,
   * too many retries or timeouts.
2. Φ_error:

   * reframe driver context as “degraded mode”,
   * mark `(D, Dev)` binding as “error-state”.
3. Χ strengthening:

   * increase isolation:

     * restrict accessible frames and MMIO ranges,
     * block certain syscalls or kernel APIs,
     * optionally disconnect the device from user-visible namespace.
4. Σ:

   * commit error state to logs and audit,
   * mark operations as failed,
   * propagate error codes to userspace (via IPC, FS, etc.).

The driver is in S₆: still present, but not fully functional.

---

##### T6: Error/Degraded → Quarantined (S₆ → S₇)

Operators: Χ, Ψ, Φ, Σ

Some violations require hard quarantine.

1. Ψ_escalation:

   * repeated faults,
   * critical security violation,
   * driver from untrusted domain.
2. Χ_quarantine:

   * move driver and associated devices into an isolated context:

     * no live user-visible handles,
     * interrupts may be disabled,
     * I/O paths cut.
3. Φ:

   * reframe existing user requests to failure or “device disappeared”.
4. Σ:

   * commit quarantine state in kernel metadata and logs.
5. Ψ_quarantine:

   * restrict allowed operations on D to:

     * introspection,
     * logs,
     * controlled debugging,
     * eventual replacement.

Quarantined drivers cannot be reactivated without explicit administrator or Ψ_K decision (or a defined auto-recovery path).

---

##### T7: Active / Error / Suspended → Unloaded (S₄/S₅/S₆ → S₈)

Operators: Θ, Σ, Φ, Χ, Ψ

When the system decides to remove a driver (manual unload, upgrade, or fatal error):

1. Θ: ensure all contexts have quiesced:

   * no threads executing in D’s code,
   * no IRQ handlers pending,
   * no bottom halves queued,
   * no open handles (or all forcibly closed).
2. Φ_unbind:

   * unbind `(D, Dev)` for all devices:

     * disable IRQs,
     * tear down MMIO mappings,
     * disconnect from FS and network namespaces.
3. Χ_teardown:

   * remove isolation compartments for D and its devices,
   * release frames and resources.
4. Σ:

   * commit removal to kernel state:

     * update driver table,
     * update device-state (mark unhandled or not present).
5. Ψ:

   * verify post-conditions:

     * no reachable references to D’s frames,
     * no capabilities or handles referencing D remain,
     * resource counters (3.8) balanced.

If Ψ fails (for example, leak detected), the system may move to S₇ (quarantine) or take stronger action (such as partial restart).

---

#### 8.3.4 Policy Attachments and Governance (Ψ in Practice)

We now make Ψ more concrete.

##### 8.3.4.1 Policy attachments to drivers

For each driver `D`, the kernel stores:

```text
DriverPolicy {
    TrustLevel   trust;      // core, signed, vendor, third-party, experimental
    CapSet       caps;       // Ω: allowed capabilities
    Isolation    iso_mode;   // Χ: isolation domain type (none, container, VM, enclave)
    TimeBudget   irq_budget; // max IRQ run-time per interval
    TimeBudget   work_budget;// max bottom-half / workqueue time
    MemBudget    mem_limit;  // max memory for driver internal structures
    DeviceClass  class;      // net, block, char, usb, gpu, etc.
    AuditLevel   audit;      // logging intensity
    RecoveryMode recovery;   // restart, quarantine, disable, panic, etc.
}
```

Ψ is a set of constraints referencing these fields.

##### 8.3.4.2 Enforcement points

Key enforcement points for Ψ:

1. Install / Load (T1):

   * trust level, signatures, class allowlist or denylist.

2. Probe / Bind (T2/T3):

   * whether D may touch the bus or device,
   * whether class and trust level match device policy.

3. IRQ / bottom-half / workqueue execution:

   * time budgets represented in τ and enforced via Λ (timeouts) and Θ (scheduling),
   * memory budgets on allocations via Σ and 3.8 resource accounting,
   * API calling patterns (for example, no blocking from top half).

4. Error and fault handling:

   * escalation rules: when to restart, when to quarantine, when to panic.

5. Unload / Upgrade:

   * safe removal conditions,
   * optional auto-migration of device to a new driver (Φ rebind).

---

#### 8.3.5 Driver Upgrade and Replacement (Φ + Σ + Χ)

When upgrading or swapping drivers while devices are live:

##### Scenario: `D_old → D_new` for device `Dev`

We follow a structured Φ sequence:

1. Δ: distinguish `D_old`, `D_new`, and `Dev`.
2. Ψ_compat: check upgrade policy:

   * version compatibility,
   * driver class invariants,
   * trust levels,
   * migration support.
3. Φ_migrate:

   * create a migration frame for Dev:

     * old state (queues, configuration, hardware state),
     * new driver’s view of that state.
   * recontextualize Dev from `(D_old, Dev)` to `(D_new, Dev)`:

     * may require transformation of internal data structures (Φ on the control state).
4. Σ_migrate:

   * commit new binding `(D_new, Dev)`,
   * mark old binding as “replaced”.
5. Χ:

   * isolate old driver `D_old` (S₇) or unload it (S₈) if no other devices use it.
6. Ψ_post:

   * check that no invariants are broken:

     * no lost outstanding I/O,
     * no resource leaks,
     * Dev accessible and consistent.

If migration fails, Ψ may revert:

* roll back to `D_old` (if still functional),
* quarantine Dev and `D_new`,
* escalate to admin or policy.

---

#### 8.3.6 Error Handling, Recovery, and Quarantine (Ψ + Φ + Χ)

We define a small taxonomy of driver fault policies (`RecoveryMode`).

1. Recover / restart in place:

   * try resetting the device,
   * reinitializing driver state,
   * re-establishing bindings.
   * operators: `Φ_reset`, `Σ_reset`, `Θ_backoff`.

2. Restart driver once:

   * unbind, unload, reload D, re-probe and re-bind.
   * operators: T7 (Unload) followed by T1–T3 (Install/Load/Probe/Bind).

3. Quarantine driver and device:

   * isolate both from user-space and most of the kernel.
   * operators: `Χ_quarantine`, `Ψ_quarantine`.

4. Panic / stop system:

   * for critical subsystems (for example, root filesystem, memory controller) with no safe recovery.
   * operators: `Ψ_panic` leading to a global halting state.

Policies can differentiate:

* by trust level (core driver vs third-party),
* by device criticality (boot disk vs optional USB),
* by configured system mode (production vs debug).

---

#### 8.3.7 Interaction with Resource Accounting (5.8 Ψ + Σ)

Drivers are heavy users of resources; their lifecycle hooks tie into 5.8:

1. Memory:

   * driver allocations charged to `ResourceAccount(D, Dev)` buckets,
   * limits enforced by Ψ (`mem_limit` per driver and per device class).

2. CPU:

   * IRQ and bottom-half execution are ordered by Θ,
   * τ records usage and Σ commits accounting updates.

3. IPC and queues:

   * per-driver or public IPC channels accounted for:

     * max queue depths,
     * rate limits.

4. Storage and network:

   * drivers for block and network devices report throughput and utilization to accounting.

If a driver exceeds resource budgets:

* soft warnings (logs),
* throttling (Θ to reduce scheduling slice),
* eventual escalation to S₆ or S₇ (Error or Quarantine).

---

#### 8.3.8 Summary

In PMS terms, a driver is:

* a role-bearing agent (Ω) operating within a frame (□),
* with isolation constraints (Χ),
* subject to global and local policies (Ψ),
* interacting with hardware via Δ, ∇, Φ and ordered execution via Θ (with τ as kernel time reference),
* committing effects via Σ, and handling absences and timeouts via Λ.

The driver lifecycle is a Ψ-governed state machine:

* Install → Load → Probe → Bind/Active → Suspend/Resume → Error → Quarantine → Unload

with clear PMS operators driving each transition and enforcing invariants.

This lifecycle plugs cleanly into:

* 8.2 interrupt path,
* 6.x memory and storage (frames, mapping, filesystem),
* 5.x kernel core (scheduling, isolation, syscalls, accounting),
* and 10.x governance (trust, identity, policy).

---

### 8.4 Hotplug and Dynamic Reconfiguration (Φ/Ψ)

*Structural perspective: hotplug as recontextualization events governed by invariants.*

Hotplug means:

* new devices appear, requiring recognition, classification, policy checks, enumeration, driver binding,
* existing devices disappear, requiring unbinding, teardown, isolation, graceful degradation or quarantine,
* device topology or configuration changes (multi-function devices, network links, PCIe bridges, USB trees),
* driver stacks reconfigure live (driver replacement, fallback, multipath, link renegotiation).

All of this is expressed through Φ, Ψ, Χ, Θ, Δ, Σ.

---

#### 8.4.1 Types of Hotplug Events

We categorize all hotplug events in PMS terms.

##### A. Physical attach/detach events (Φ_ext)

An external source triggers Φ:

* device connected or disconnected,
* bus reports presence change,
* port power change,
* cable insertion or removal,
* function-level resets.

This is structurally:

`Φ_ext: s → s'`

that is, reinterpreting the system topology.

##### B. Logical reconfiguration events (Φ_logic)

No physical event; system context changes:

* virtualization guest attaches a virtual device,
* kernel loads a new bus handler,
* device renames or reassigns functions,
* new capabilities advertised at runtime.

##### C. Discovery and enumeration events (Δ_enum + Θ)

System distinguishes new device identities:

* topology scanning,
* reading device descriptors,
* generating identity distinction records (ID, class, vendor, version).

##### D. Policy events (Ψ_hotplug)

Policies that constrain whether attach/detach are allowed:

* “Only trusted drivers may handle hotplug USB devices.”
* “PCIe hotplug allowed only in zones A/B.”
* “Storage hotplug allowed but must enter write-quiescent state first.”

##### E. Absence and non-event recognition (Λ_hotplug)

Expected attach or detach does not occur:

* delayed device response,
* half-attached states,
* transient enumeration failures.

---

#### 8.4.2 Core Hotplug Pipeline (Attach)

When a device appears, the kernel undergoes the following Φ-driven transformation sequence.

##### Step 1. Signal → Φ_ext

Hardware or bus triggers an interrupt or polled event:

`Φ_ext: bus reports new device D_new present`

Φ_ext updates meta-state:

* new topology snapshot in `m.topology`,
* pending attach job queued for the hotplug subsystem.

##### Step 2. Δ_distinguish: identify device

Kernel performs systematic distinction:

```text
Δ_identify(D_new):
    read IDs
    classify bus type
    read descriptors
```

Result: creation of a device frame:

`□_dev(D_new)`

##### Step 3. Ψ_policy: check attach permissions

Apply effective policy:

`Ψ_eff(D_new) = Ψ_K ∧ Ψ_class ∧ Ψ_bus ∧ Ψ_zone ∧ Ψ_dev`

Examples:

* disallow hotplug in secure mode,
* allow only signed drivers for this bus,
* require virtualization-level mediation,
* require isolation for USB-storage class.

If Ψ denies attach, go directly to the quarantine path (Φ_reject + Χ).

##### Step 4. Φ_enumerate: recontextualize bus

The bus driver performs enumeration:

```text
Φ_enumerate:
    update device tree and topology
    create ephemeral enumeration frame
    reconcile with existing bus state
```

In complex buses (PCIe, USB), enumeration itself is a Δ–Φ–Θ sequence.

##### Step 5. Probe driver candidates (Δ + Ω + Ψ)

For each driver module `D`:

```text
Δ_match(D, D_new)
Ω_cap_check(D, bus_access)
Ψ_D_class(D, D_new)
```

Only drivers satisfying Ψ and Ω remain as candidates.

##### Step 6. Bind (equivalent to T3)

Binding uses Φ + Σ:

```text
Φ_bind(D, D_new):
    assign driver context
    map device MMIO frames (□)
    install IRQ handlers
    register capabilities (Ω)

Σ_commit_binding(D, D_new)
```

The device is now active.

##### Step 7. Notify dependent subsystems (Θ + Σ)

Integration steps:

* filesystem mounts,
* network interface creation,
* block device registration,
* input device nodes.

`Σ_system: commit new device to global namespace`

---

#### 8.4.3 Core Hotplug Pipeline (Detach)

When a device disappears, the system follows analogous but inverse transitions:

##### Step 1. Φ_ext_detach: topology recontextualization

Bus signals removal:

```text
Φ_ext_detach(D_lost)
```

`m.topology` is updated to “device missing”.

##### Step 2. Λ_absence: detect non-event

If the device fails to respond within Ψ-bounded, Θ-ordered intervals measured via τ:

```text
Λ_timeout(D_lost)
```

This distinguishes physical removal from transient error.

##### Step 3. Ψ_detach_policy

Policies decide what kind of teardown is allowed.

Examples:

* “Storage devices must not be detached if writes are pending unless a force-detach flag is set.”
* “Network interfaces may be hot-removed if routing allows failover.”

##### Step 4. Φ_unbind: recontextualize driver → remove binding

Driver transitions:

* Active → Suspended
* Suspended → Unbound

Sequence:

```text
Φ_unbind(D, D_lost)
   disable IRQs
   flush pending DMA
   freeze queues
   mark device frame invalid
```

##### Step 5. Σ: commit unbind

Integration of removal:

* remove from `/dev`,
* update kernel resource tables,
* notify IPC channels.

##### Step 6. Χ_isolate residue

If any part of the driver still refers to the now-missing device, policy can enforce:

```text
Χ: isolate driver context
```

This protects the kernel from invalid memory or hardware access.

##### Step 7. Ψ_post_detach

Final consistency check:

* no outstanding references,
* no leaked capabilities,
* no dangling buffers.

---

#### 8.4.4 Topology Reconfiguration (Bridges, Multi-function, etc.)

Some buses allow dynamic topology, not just simple add/remove.
PMS models this via *composite Φ recontextualizations*.

##### Φ_topology_change

Applied when:

* a PCIe switch appears or disappears,
* a USB hub resets or changes port states,
* a Thunderbolt daisy chain reconfigures,
* network topology changes (link up/down, aggregated bonds).

Φ transforms:

* parent/child device frames (□),
* bus role hierarchy (Ω asymmetry),
* device ID mapping,
* capabilities exposed.

##### Integration

`Σ_topology` commits the new topology.

Policies Ψ then validate:

* no device aliasing,
* no cycles in the topology graph,
* no unauthorized path (for example, Thunderbolt allowed only for certain trust levels).

---

#### 8.4.5 Driver Stack Reconfiguration (Φ_replace, Φ_upgrade)

This includes runtime driver replacement, multipath failover, alternate mode negotiation.

##### Φ_replace: change driver D_old → D_new

Steps mirror 8.3.5:

* Δ: detect incompatible or updated driver.
* Ψ_check: ensure replacement is allowed.
* Φ_migrate: translate state.
* Σ_commit: activate new driver.
* Χ_isolate: retire old driver.

##### Φ_fallback: driver failover

Triggered by Ψ when error budgets are exceeded.

Sequence:

* Φ_migrate device state,
* rebind to fallback driver `D_fallback`,
* update network and storage namespaces via Σ.

---

#### 8.4.6 Policy Model for Hotplug (Ψ_hotplug)

Ψ_hotplug encodes all invariants for attach and detach.

##### Categories

1. Security constraints

   * USB class restrictions
   * Thunderbolt authorization
   * PCI hotplug zones
   * signed-driver requirement

2. Safety constraints

   * storage hotplug only when the filesystem is consistent
   * disallow NVMe detach under load unless forced

3. Resource constraints

   * prevent attach when memory is overcommitted
   * disallow new devices if IRQ budget is exceeded

4. System-governance constraints

   * certain networks allowed only by policy
   * virtualization mediation required (hypervisor policy)

A policy might specify:

```text
Ψ_hotplug(dev_class = X):
    require signed(dev)
    require isolation(Χ_mode = container)
    require driver ∈ approved_driver_list
    forbid attach if loadavg > threshold
    forbid detach if pending_IO(dev) > 0
```

Ψ is evaluated at each step of the attach/detach pipeline.

---

#### 8.4.7 Hotplug Failure Modes (Λ + Φ + Ψ)

Failure in any step triggers one of several structured responses.

##### A. Reject and isolate

If attach fails early:

```text
Φ_reject
Χ_isolate(device)
```

##### B. Retry

If enumeration is nondeterministic (for example, USB flakiness):

```text
Λ_timeout
Θ_backoff
repeat Δ_identify
```

##### C. Partial bind, then rollback

If a driver fails to initialize fully:

```text
Φ_partial
Σ_partial_rollback
return_to_previous_state
```

##### D. Escalation to quarantine

If repeated attach attempts violate policy:

```text
Ψ_escalate → Χ_quarantine(driver)
```

---

#### 8.4.8 Concurrency, Ordering, and Interleavings (Θ)

Hotplug events interleave with other kernel activity.

Typical concurrency patterns:

1. Multiple devices attach simultaneously
   Θ schedules attach jobs; dependencies are expressed by bus ordering.

2. Attach during detach
   Φ resolution ensures consistent topology.

3. Ongoing I/O during detach
   Requires Σ-mediated quiesce and commit before final detach.

4. Driver upgrade concurrent with hotplug
   Policies Ψ restrict reconfiguration windows.

---

#### 8.4.9 Integration with Resource Accounting (5.8)

Attach increases:

* IRQ budget,
* memory allocation per driver,
* bus bandwidth usage,
* possible multipath usage.

Detach decreases these resources.

Metrics pass through Σ + Ψ audit:

```text
Σ_account_update(D, Dev)
Ψ_budget_check()
```

If attach would violate system-level quotas, Ψ blocks it.

---

#### 8.4.10 Summary

Hotplug in PMS is a governed recontextualization pipeline:

* Φ drives context shifts (attach, detach, topology change, driver replacement).
* Ψ enforces system policies: security, safety, resource, governance.
* Χ isolates misbehaving states and maintains integrity during transitions.
* Δ performs identification and classification.
* Θ orders the attach/detach processes and resolves concurrency.
* Σ finalizes new or removed states into the global namespace.
* Λ handles absences, failed attempts, and degraded events.

This yields a unified, formally structured hotplug framework that works for:

* PCIe, USB, Thunderbolt
* network link negotiation
* multipath storage
* virtual devices
* dynamic driver stacks
* clustered or distributed system reconfiguration

---

## 9. Networking Stack

### 9.1 Transport Abstraction – connections as frames, timeouts (Λ over τ)

Operators: □ (frame), Δ (distinction), Θ (ordering over connection steps), Λ (non-event), Ω (asymmetry), Χ (isolation), Φ (recontextualization), Σ (integration), Ψ (policy).

Transport is the lowest-level networking substrate in PMS-OS: the level *beneath* protocols, above device drivers.
Its job is to provide a consistent connection abstraction, which in PMS is framed as:

> A connection is a dynamic □-frame, ordered by Θ, with timeouts modelled as Λ-conditions over τ, and governed by Ω and Ψ.

Everything else — routing, protocol logic, congestion control — is layered on top of these primitives.

---

#### 9.1.1 Transport as a Frame (□_conn)

A connection is represented as a context frame:

```text
□_conn(cid) = (base, state, role, policy, meta)
```

Where:

##### 1. base

The underlying transport device or driver frame (for example, NIC queue pair, virtual port, loopback).

##### 2. state

The local connection state machine:

* sequence numbers
* connection flags
* negotiated parameters
* send/receive windows
* device/driver handles

##### 3. role (Ω)

Asymmetric relation between peers:

* client/server
* initiator/responder
* control/data channel
* privileged/unprivileged send rights

Ω determines what transitions are legal.

##### 4. policy (Ψ)

Connection-level invariants:

* encryption required or not
* authentication required or not
* max RTT, minimum throughput
* congestion fairness constraints
* isolation level

##### 5. meta (Θ, Λ, Φ, Χ, τ)

Ordering counters, τ-based last-seen timestamps, timeout budget, isolation markers, fallback state.

---

#### 9.1.2 Transport Timeline (Θ)

Every connection progresses along a Θ-ordered progression.

##### Θ_connect

Initiation sequence:

```text
Θ: send SYN-equivalent
Θ: receive ACK-equivalent
```

In PMS we do not prescribe specific packets; only the operator structure:

```text
Θ_open = Δ_id ; Ω_role_set ; Σ_commit_open
```

Where:

* Δ distinguishes the connection request,
* Ω sets role (initiator or responder),
* Σ commits the connection into active tables.

##### Θ_active

Main data-transfer ordering loop:

```text
(Δ_window ; ∇*send ; ∇*recv ; Σ_ack)*
```

This is the structural skeleton behind any sliding-window mechanism (TCP, QUIC, RDMA, and similar).

##### Θ_close

Connection teardown sequence:

```text
Θ_close: Δ ; Ω ; Σ ; Φ
```

* Δ distinguishes the closure signal,
* Ω may apply role-specific “who may close” rules,
* Σ commits last bytes and flushes buffers,
* Φ recontextualizes the transport frame back to idle.

---

#### 9.1.3 Non-Events and Timeouts (Λ)

Λ models all network absence conditions:

* delayed ACK → `Λ_acktimeout`
* missing keepalive → `Λ_keepalive`
* peer not responding → `Λ_noreply`
* link-down → `Λ_linkfail`
* partial delivery → `Λ_partial`
* flow-control stall → `Λ_flowcontrol`

Structural form (τ-based):

```text
Λ_timeout(x) := (τ.now ≥ τ.deadline(x)) ∧ not event(x)
```

Λ transitions do not mutate core state directly; they:

1. update `m.timeout_flags` using τ-based checks,
2. schedule a fallback transition via Φ or `Θ_backoff`,
3. trigger policy checks Ψ.

Example:

```text
Λ_acktimeout:
    m.flags.ack_missing = true
    Φ_recover(conn)
```

Λ is essential for liveness: it encodes loss, silence, jitter, and transient failures as structured events rather than raw errors, with τ capturing the concrete timeout conditions.

---

#### 9.1.4 Transport States as PMS Operator Graphs

A transport connection is a PMS-operator state machine, not a single variable.

Let `C` be a connection frame.

Transition structure:

##### OPENING

```text
C0 --Δ_syn--> C1 --Θ--> C2 --Σ_open--> C3
```

##### ACTIVE

Repeated loop:

```text
C
  --Δ_ready-->
  --∇*send-->
  --∇*recv-->
  --(Λ_loss? or Θ_success)-->
  --Σ_update-->
  C'
```

##### CLOSING

```text
C_N --Δ_finish--> --Σ--> --Φ_teardown--> C_free
```

This structuring allows advanced behaviors:

* retransmission (Θ + Λ + Φ over τ-based timeouts),
* congestion control (Θ + Σ),
* backpressure (Ω + Θ),
* out-of-order handling (Δ + Σ),
* half-open states (Λ + Φ).

---

#### 9.1.5 Connection Frames and Namespaces (□ + Χ)

Each connection is isolated via:

##### 1. Its own frame (□_conn)

Contains:

* send buffer
* receive buffer
* state variables
* per-connection policies

##### 2. Isolation boundaries (Χ)

Prevent cross-talk between connections:

* Χ_per_conn: each connection in its own sandbox,
* Χ_per_flow: hardware queues separated,
* Χ_per_security_zone: inter-tenant isolation in virtualized setups,
* Χ_shielding: drop all I/O when a connection is quarantined.

Χ ensures “one connection cannot corrupt another”.

##### 3. Namespaces

Connections belong to:

* process namespace,
* network namespace,
* security namespace,
* bus or interface namespace.

Switching between namespaces uses Φ_recontextualize.

---

#### 9.1.6 Order, Delay, and Scheduling (Θ)

Network transport relies on ordered progression of actions.
Θ is key for this ordering, while τ provides concrete timing information where needed.

##### Θ_seq – sequence maintenance

Assigns ordering to outbound or inbound segments.

##### Θ_retrans – retry ordering after τ-based timeout

If a τ-based condition triggers `Λ_timeout(conn)`:

```text
Λ_timeout(conn)
Θ_backoff
Θ_retransmit
```

`Θ_backoff` and `Θ_retransmit` order retries; τ encodes when a retry becomes eligible.

##### Θ_sched – connection scheduling

The kernel can interleave connections based on Θ policies:

* fair queueing,
* weighted priorities,
* real-time–like ordering constraints,
* latency-sensitive prioritization.

##### Θ_flow – pacing

Transport may enforce pacing: Θ orders sends so that τ-based pacing constraints are respected.

Conceptually:

```text
Θ_pace:
    only schedule next send when pacing_guard(τ) is satisfied
```

Concrete delays live in τ and Λ-guards; Θ determines the sequence in which eligible sends occur.

---

#### 9.1.7 Transport-Level Φ (Recontextualization)

Φ handles major interpretational shifts.

##### A. Φ_migrate

Switch transport to a different underlying device or queue (for example, NIC migration).

##### B. Φ_fallback

Change transport mode:

* fast-path → slow-path,
* offload → software stack,
* encrypted → unencrypted (if allowed by Ψ).

##### C. Φ_resync

Used when sequence numbers or windows diverge.

##### D. Φ_quarantine

Isolate a connection due to security violation or protocol error.

Φ preserves the past but changes the interpretation of state.

---

#### 9.1.8 Transport Policies (Ψ)

Ψ overlays general invariants.

##### 1. Security policies

* encryption mandatory or not,
* authentication required,
* cross-namespace transports allowed or denied,
* allowed peers or subnets,
* anomaly detection (rate limits, malformed sequences).

##### 2. Flow policies

* max bandwidth,
* min throughput,
* RTT constraints (expressed over τ),
* head-of-line blocking limits,
* pacing rules.

##### 3. Resource policies

* per-process connection limits,
* per-user bandwidth quotas,
* kernel-global transport budget.

Ψ determines which transitions are legal in the transport state machine.

---

#### 9.1.9 Transport Integration (Σ)

Σ commits transport-level changes.

##### Σ_send_done

Move sent data to “ack-pending”.

##### Σ_ack_merge

Integrate acked bytes into completion queues.

##### Σ_state_commit

Apply state updates:

* updated windows,
* updated sequence numbers,
* cleared timeout flags,
* merged retransmission status.

##### Σ_teardown

Final teardown state integrated into global namespaces:

* free connection ID,
* free buffers,
* release isolation context,
* update routing tables if needed.

Σ ensures global consistency.

---

#### 9.1.10 Summary (9.1)

Transport abstraction in PMS is expressed as:

* Connection = □ (frame)
* Events and transitions = Δ
* Action and I/O = ∇
* Ordered progression of steps = Θ (with τ holding concrete time values as needed)
* Timeouts and absence = Λ (over τ)
* Recontextualization = Φ
* Isolation = Χ
* Asymmetry = Ω
* Commit/merge = Σ
* Policies = Ψ

This gives a transport layer that is:

* deterministic or non-deterministic depending on Ψ, Θ, and Λ,
* fully isolated per connection,
* fully policy-governed,
* aware of ordering (Θ) and τ-based timing,
* absence-aware (Λ),
* capable of fallback, migration, multi-path, congestion control,
* abstract enough to implement TCP, QUIC, RDMA, Unix sockets, or custom protocols with the same PMS substrate.

---

### 9.2 Addressing and Routing – nodes, services, topics (Δ/□)

Operators: Δ (distinction), □ (frame), Θ (ordering of routing steps), Φ (recontextualization), Ω (asymmetry), Χ (isolation), Λ (non-event), Σ (integration), Ψ (policy).

Addressing and routing in PMS networking follow the same structural pattern as all PMS subsystems:

> Address = Δ (identity) inside □ (namespace) under Ω and Ψ constraints.
> Routing = Δ + Θ + Φ transitions of frames (□_route), producing Σ-committed next-hop decisions.

This provides a unified substrate for:

* local IPC,
* host networking,
* container and VM networking,
* overlay and cluster networking,
* service-mesh addressing,
* topic-based (pub/sub) addressing,
* identity-based networking (actors, principals).

All implemented using the same operator algebra.

---

#### 9.2.1 Structural Address Model (Δ inside □)

In PMS, an address is not a number; it is a distinguished symbol inside a frame:

```text
Addr ::= Δ_id ∈ □_namespace
```

Where:

* Δ_id – the distinguishing element (node ID, service ID, topic ID, path element, queue identifier),
* □_namespace – the scope that gives the identifier meaning.

Examples:

| Address Type           | Δ (distinction) | □ (namespace)   |
| ---------------------- | --------------- | --------------- |
| IP address             | Δ_ip            | □_internet      |
| MAC address            | Δ_mac           | □_link_layer    |
| Unix socket            | Δ_path          | □_filesystem    |
| Actor or service       | Δ_serviceID     | □_service_space |
| Topic (pub-sub)        | Δ_topic         | □_topic_space   |
| VM/container interface | Δ_vnic          | □_tenant_space  |

Key principle:

* Δ without □ has no meaning;
* □ without Δ has no identity.

This two-operator basis replaces ad-hoc address systems.

---

#### 9.2.2 Node Identity Frames (□_node)

Each node in a PMS-based network has a node frame:

```text
□_node = (id, credentials, roles, routing_table, policies)
```

Containing:

##### 1. id (Δ_node)

Node identity inside the cluster or network.

##### 2. credentials (Ω)

Roles and capabilities:

* allowed to send or not,
* allowed to accept or not,
* allowed to administer routing or not.

##### 3. routing_table (Δ → □ mappings)

Maps:

* destination distinctions (`Δ_dest`)
* to routing frames (`□_next`).

##### 4. policies (Ψ)

Enforce allowable routing:

* no routing between certain zones,
* encryption required,
* multi-tenancy boundaries,
* max hop count,
* no hairpin routing, and similar.

Node frames combine all these into a single PMS structure.

---

#### 9.2.3 Address Resolution (Δ → Δ inside new □)

Address resolution transforms an identity Δ in one frame into a Δ in another.

Examples structurally:

##### DNS-like resolution

```text
Δ_hostname  --Φ_resolve-->  Δ_ip  in  □_internet
```

##### Service discovery

```text
Δ_serviceID  --Φ_lookup-->  Δ_instanceID  in  □_service_space
```

##### Topic routing

```text
Δ_topic  --Φ_expand-->  {Δ_subscriber_i}  in  □_subscription_graph
```

The operator is Φ because resolution changes the interpretation context while preserving the original semantic object:
a name becomes an address becomes a next hop.

---

#### 9.2.4 Routing as Frame Transition (□_route)

Routing is treated as a sequence of frame transitions:

```text
□_node_A
  --Δ_dest-->
□_route
  --Θ_select-->
□_node_B
```

`□_route` contains:

* the resolved next hop,
* the path metrics,
* ordering-related state (Θ counters for hops and progression),
* τ-linked lifetimes or deadlines (where needed),
* policy context (`Ψ_route`),
* isolation markers (Χ).

This allows routing to be:

* deterministic,
* probabilistic,
* policy-driven,
* multi-path,
* isolated per tenant,
* context-sensitive,

all using the same PMS operators.

---

#### 9.2.5 Ordered and Temporal Routing Behaviour (Θ)

Routing always has an ordered progression, with any concrete time constraints expressed via τ and Λ.

##### 1. Θ_forward

Orders hop-by-hop progression:

* increment hop count,
* trigger ∇ and Σ updates to TTL or lifetime fields, stored in τ-linked routing state.

##### 2. Θ_select

Choose next hop based on current routing information:

* load,
* congestion metrics,
* deadline-aware metrics (where τ encodes deadlines),
* real-time–like constraints coming from Ψ.

##### 3. Θ_refresh

Order periodic refresh of routing tables or link metrics:

* scheduling of refresh steps is via Θ,
* concrete refresh intervals are encoded in τ and checked via Λ conditions.

##### 4. Θ_reroute

Triggered when:

* Λ (non-event) – missing heartbeat, missing ACK, missing routing update,
* Φ (recontextualization) – link changes,
* Χ (isolation change) – tenant migration or segmentation.

Θ_reroute orders the transition to a new path; τ and Λ determine when rerouting becomes necessary.

---

#### 9.2.6 Λ in Routing (Non-Events)

Non-events handle:

* link failure,
* interface down,
* node disappearance,
* heartbeat loss,
* route expiration,
* missing ARP/NDP response,
* missing DNS response,
* stale metrics.

Structural form (τ-based):

```text
Λ_route_timeout(x) := (τ.now ≥ τ.deadline(x)) ∧ not event(x)
```

Effect:

1. mark route degraded,
2. trigger Φ_reroute (context shift),
3. possibly update policies (Ψ),
4. schedule retry (`Θ_backoff`).

Λ is essential to resilience; no networking stack is complete without absence-handling.

---

#### 9.2.7 Hierarchical Frames for Multi-Level Routing

Because □ denotes context, we can model *any* hierarchy:

##### 1. Global network frame

```text
□_internet
```

##### 2. Region frame

```text
□_region
```

##### 3. Cluster frame

```text
□_cluster
```

##### 4. Node frame

```text
□_node
```

##### 5. Process/service frame

```text
□_service
```

Hierarchical routing becomes:

```text
□_A -> □_B -> □_C -> □_D
```

Each step is a Φ recontextualization plus a Θ-ordered progression.

This works for:

* classic IP routing
* SDN
* service meshes
* overlay networks
* P2P
* RPC
* actor systems
* topic-based routing

All using the same operator structure.

---

#### 9.2.8 Topic-Based (Pub/Sub) Addressing

A topic is simply:

```text
Δ_topic ∈ □_topicspace
```

A publish event:

```text
Δ_topic ; Θ_publish ; ∇_send
```

Routing a publish means:

```text
Φ_expand_subs
```

Which yields:

```text
Δ_sub_i ∈ □_subscribers    (for each subscriber i)
```

Then message delivery proceeds normally (Θ forwarding, Λ timeouts over τ, Σ acknowledgement).

Topics require no special machinery beyond Δ + □ + Θ + Φ + Λ(τ).

---

#### 9.2.9 Capability-Restricted Routing (Ω)

Ω enforces that not all nodes or roles can route to all others.

Examples:

* tenant A cannot route into tenant B (Χ + Ω)
* privileged nodes may use privileged backplane links
* “service-only” nodes cannot perform general routing
* nodes with a low-trust role cannot forward encrypted flows

At routing time, Ω acts as a check on the destination:

```text
Ω_check(Δ_dest) =>
    - allowed
    - blocked
    - rerouted via Φ
```

Ω produces:

* branch decisions
* upgrade or downgrade in routing role
* alternative paths
* quarantine (route suppressed via Χ)

---

#### 9.2.10 Isolation Boundaries (Χ)

Routing respects isolation.

##### Tenant isolation

```text
Χ_tenant
```

Preventing cross-tenant addressing.

##### Namespace isolation

```text
Χ_ns
```

Network namespaces for containers and VMs.

##### Security zones

```text
Χ_sec_zone
```

DMZ, backend, control plane, management plane, and similar patterns.

Routing attempts crossing a Χ boundary force:

* Φ_reinterpret (different address mapping), or
* Ψ_deny (halt routing attempt), or
* encapsulation into an isolated transport (tunnels).

---

#### 9.2.11 Policy-Governed Routing (Ψ)

Ψ establishes invariants such as:

* routing only allowed if encrypted
* routing blocked from low-trust zones
* rate limits
* must avoid certain nodes
* no single point may see all traffic (privacy-preserving routing)
* maximum hop count
* congestion fairness rules

Structurally:

```text
Ψ_route(state) returns one of:
    - allow
    - redirect via Φ
    - require Ω-upgrade
    - deny (halt)
```

Thus policies directly shape the routing graph.

---

#### 9.2.12 Routing Commit (Σ)

When a routing decision is finalized:

```text
Σ_route_commit
```

Actions include:

* update next-hop cache
* update metrics (RTT, congestion, reliability) as τ-linked data
* record successful route in logs
* clear timeout flags
* confirm address-to-path mapping
* update route lifetime counters
* merge cost metrics

Σ ensures routing tables and metrics stay coherent globally.

---

#### 9.2.13 Summary (9.2)

Addressing and routing in PMS are unified under:

* Δ — identity elements (node, service, topic)
* □ — namespaces and routing frames
* Θ — ordered routing steps (hops, scheduling, pacing)
* Λ — absence (timeouts, failures, stale routes) over τ
* Φ — context shifts (resolution, reroute, fallback, reinterpretation)
* Χ — isolation boundaries
* Ω — capability-based routing permissions
* Ψ — routing policies and invariants
* Σ — commit of routing decisions, metrics, state

This gives a routing substrate capable of implementing:

* IP
* UDP
* TCP/QUIC
* SDN
* service discovery
* mesh routing
* actor-based addressing
* topic-based pub/sub routing
* virtual networking
* cluster routing
* multi-tenant segmentation
* privacy-preserving routing

all from the same minimal operator algebra.

---

### 9.3 PMS Protocol Suite Integration (PPS: P-REQ, P-EVT, P-CTRL)

The PMS Protocol Suite (PPS) defines a minimal, operator-typed meta-protocol layer that sits above transport (9.1) and addressing/routing (9.2), but below application semantics and PMSL.

PPS uses the PMS operator algebra directly to define three universal message forms:

1. P-REQ — request–response
   (Δ → Ω → Θ → Σ)

2. P-EVT — event / notification
   (Δ → Θ → (Λ or Σ))

3. P-CTRL — policy, capability, or frame control
   (Δ → Φ → Ω → Ψ → Σ)

These three patterns cover all IT protocol behavior structurally — RPC, REST, gRPC, pub/sub, actor messages, system events, control-plane signals, capability negotiation, versioning, routing changes, isolation mode toggles, and more.

PPS is therefore a meta-protocol grammar, not a concrete wire format.

---

#### 9.3.1 PPS Message Structure (Δ inside □_transport)

A PPS message is:

```text
Msg = (
    Δ_kind,
    Δ_id,
    payload,
    □_transport,
    Ω_src_to_dst,
    Ψ_policy,
    τ_ts,
    m_meta
)
```

Fields:

##### Δ_kind

The protocol distinction:

* P-REQ
* P-EVT
* P-CTRL

##### Δ_id

Message identity (for example, UUID or sequence number).

##### payload

Arbitrary binary or structured data (can contain PMSL values).

##### □_transport

Connection frame:

* stream frame
* datagram frame
* channel frame
* topic frame

##### Ω_src_to_dst

Permissions or capabilities attached to the message flow.

##### Ψ_policy

Active policies constraining handling of the message:

* authenticity required
* replay protection
* routing restrictions
* decryption scope
* isolation boundary

##### τ_ts

Temporal metadata as part of the message’s τ-linked state:

* creation timestamp
* lifetime or TTL
* retry budget
* sequence or ordering counters

##### m_meta

Additional meta:

* version tags
* routing hints
* diagnostics

---

#### 9.3.2 P-REQ (Request/Response Protocol)

Operators: Δ, Ω, Θ, Φ, Λ, Σ

P-REQ is the general form of RPC-like interactions.

Structurally:

```text
P-REQ ≡ Δ_req ; Ω_caps ; Θ_progress ; { ∇, Φ, Λ }* ; Σ_response
```

This models:

* request message (Δ_req)
* permission check at destination (Ω)
* sequential processing (Θ)
* internal actions (∇)
* optional exception or migration (Φ)
* timeouts or missed responses (Λ)
* response commit (Σ)

##### Core semantics

1. Δ_req
   Distinguish request type and call target.

2. Ω_check
   Verify caller capabilities for the function or service.

3. Θ_dispatch
   Enter the service handler in the proper ordered execution frame.

4. Handler body
   Structured sequence of ∇, □, Φ, and Θ (application-layer logic).

5. Σ_reply
   Integrate results and emit a reply message.

##### Non-event path (timeouts)

If no reply is produced before a τ-based deadline:

```text
deadline(τ) -> Λ_no_response -> Φ_error_frame
```

Which may:

* retry
* escalate
* return an error
* reroute
* downgrade capability

P-REQ thus supports synchronous and asynchronous request–response uniformly.

---

#### 9.3.3 P-EVT (Event / Notification Protocol)

Operators: Δ, Θ, Λ, Σ, Φ, Χ

P-EVT is used for pub-sub messages, notifications, asynchronous signals, and state change events.

Structure:

```text
P-EVT ≡ Δ_evt ; Θ_emit ; { Φ, Λ }* ; Σ_deliver
```

##### Core semantics

1. Δ_evt
   Declare the event kind.

2. Θ_emit
   Sequence emission, ordering, and rate-governing for events.

3. Delivery flow

   * Normal: direct delivery to subscribers
     `Σ_deliver`
   * Transform (Φ): reframe event (for example, raw → cooked → filtered)
   * Drop (Λ): backpressure, event queue full, subscriber offline

4. Χ boundaries
   Some events may not be deliverable across security or tenant boundaries.

5. Ω (optional)
   Events often do not require capability checks, unless crossing protected domains.

##### Examples of P-EVT mappings

| Type                | Structural form                              |
| ------------------- | -------------------------------------------- |
| Pub/sub topic event | `Δ_topic ; Θ ; Σ_deliver`                    |
| Timer event         | `Δ_timer ; Θ_tick ; Σ_trigger`               |
| Signal to process   | `Δ_signal ; Θ ; Φ_contextswitch`             |
| Kernel event        | `Δ_kmsg ; Θ ; Λ_drop_on_overflow ; Σ_commit` |

---

#### 9.3.4 P-CTRL (Control Plane Protocol)

Operators: Δ, Φ, Ω, Ψ, Θ, Σ, Χ

P-CTRL manipulates context, roles, policies, routes, capabilities, versions, and isolation boundaries.

Structure:

```text
P-CTRL ≡ Δ_ctrl ; Φ_recontext ; Ω_role_change ;
          Ψ_policy_update ; Θ_apply ; Σ_commit
```

This covers control-plane protocols and operations such as:

* configuration updates
* capability negotiation
* dynamic isolation (hotplug, attach/detach)
* version and feature negotiation
* routing updates
* doorbell or control messages
* service-side admin commands
* container or VM lifecycle commands
* driver reconfiguration
* network stack policy changes

##### Core operator structure

1. Δ_ctrl
   Distinguish what control-plane operation is being attempted.

2. Φ_recontextualize
   Re-interpret local context (switch protocol version, enter new mode, negotiate features, rebind frame mappings).

3. Ω_role_change
   Enforce capability elevation or demotion (for example, admin → user, user → restricted, node → gateway).

4. Ψ_policy_update
   Install, update, or invalidate policies governing routing, security, quotas, protocol behavior, and message validation.

5. Θ_apply
   Apply changes in an ordered rollout (phased application, atomic switch, quiescence window, rollback scheduling).

6. Σ_commit
   Commit the new state atomically and propagate to subsystems.

##### Examples of real protocols mapped to P-CTRL

| System | Example                   | PMS operators     |
| ------ | ------------------------- | ----------------- |
| TCP    | window update, mode shift | Δ ; Φ ; Θ ; Σ     |
| QUIC   | version negotiation       | Δ ; Φ ; Ω ; Ψ ; Σ |
| k8s    | control-plane updates     | Δ ; Φ ; Ψ ; Θ ; Σ |
| SDN    | flow rule install         | Δ ; Φ ; Ψ ; Σ     |
| AMQP   | credit flow control       | Δ ; Φ ; Ω ; Θ ; Σ |
| Actors | capability rebinding      | Δ ; Ω ; Φ ; Σ     |
| iSCSI  | mode transitions          | Δ ; Φ ; Ψ ; Σ     |

---

#### 9.3.5 PPS as Universal Protocol Grammar

The three PPS message classes are minimal and complete:

* P-REQ → transactional, directed, symmetric or asymmetric requests
* P-EVT → asynchronous publish or notify signals
* P-CTRL → recontextualizing, role-changing, policy-carrying control-plane messages

Together, they cover all protocol families:

* RPC
* REST
* streaming RPC
* pub-sub
* signals
* events and webhooks
* distributed locks
* leader election
* control-plane signals
* version negotiation
* capability-based systems
* orchestration (containers, VMs, services)
* SDN control
* cluster coordination
* distributed transactions

All of these decompose cleanly into Δ–Ψ operator sequences.

---

#### 9.3.6 Interactions Between PPS and Networking (9.1, 9.2)

PPS messages use the underlying transport and routing abstractions:

* Δ identifies message type, sender, and destination
* □_transport defines the connection frame
* Θ sequences the flow (send → ack → retry)
* Λ handles missing responses or events (using τ-based guards)
* Ω restricts permitted interactions
* Φ rewrites protocol context (version, mode, fallback)
* Χ enforces isolation
* Ψ enforces packet-level policy
* Σ commits protocol actions (acknowledgement, final state)

Because PPS is built on the operator algebra, all higher-level protocols can be expressed in a unified execution model.

---

#### 9.3.7 Summary (9.3)

The PMS Protocol Suite (PPS) provides a universal, operator-typed grammar for all network protocols:

| PPS class  | Structural meaning              | Operators        |
| ---------- | ------------------------------- | ---------------- |
| P-REQ  | request–response                | Δ, Ω, Θ, ∇, Λ, Σ |
| P-EVT  | asynchronous events and signals | Δ, Θ, Λ, Φ, Σ, Χ |
| P-CTRL | control-plane and policy        | Δ, Φ, Ω, Ψ, Θ, Σ |

Every existing protocol family fits as a specialization of one of these three operator patterns.

---

### 9.4 Network Security (Ω, Χ, Ψ)

Operators: Ω (asymmetry and capabilities), Χ (isolation), Ψ (policy), plus Δ, Θ, Φ, Λ, Σ where required.

PMS treats security not as an add-on but as a first-class structural consequence of the operator algebra.
Network security emerges from the interplay of three dominant operators:

* Ω — Asymmetry / Role / Capability
  Defines who may do what over the network.
* Χ — Isolation Boundary / Reachability
  Defines which contexts are mutually reachable.
* Ψ — Self-binding / Policy / Invariant
  Defines what must always hold across ordered progressions and across all nodes.

Together they create a composable security substrate that governs:

* identity and authentication
* authorization and capabilities
* segmentation and isolation
* trust boundaries
* encryption mandates
* packet filtering
* multi-tenant separation
* control-plane protections
* safety invariants
* policy-driven routing and traffic shaping

This layer is not ad-hoc; it is the consequence of PMS operator dependencies.

---

#### 9.4.1 Structural Identity and Principal Model (Δ + Ω)

Every communicating principal is distinguished by:

```text
Δ_id ∈ □_principal_space
```

Principals include:

* nodes
* services
* processes
* containers and VMs
* users (structural, not psychological)
* actors
* system modules

Identity is structural, not personal.
Capabilities are attached via Ω:

```text
Ω(Δ_id) = { cap_1, cap_2, ... }
```

These capabilities govern:

* which PPS messages a principal may send or receive
* which transport frames (□_transport) they may enter
* which routing domains they may traverse
* which control-plane operations (P-CTRL) they may perform

Identity + Capability = Network Role

Network roles emerge implicitly:

* client, server, admin, router, orchestrator
* producer or consumer
* pub-sub subscriber
* control-plane authority
* observer or debug role
* confined or minimal-capability role

No separate concept of a “role model” is needed; Ω is the role model.

---

#### 9.4.2 Trust Boundaries and Segmentation (Χ)

Χ creates isolation boundaries between network contexts:

```text
□_A  --Χ-->  □_B
```

meaning: the contexts exist, but direct communication is restricted or reinterpreted.

Χ boundaries define:

* network namespaces
* VLANs and VRFs
* tenant segmentation
* DMZs and zones
* private vs public networks
* control-plane vs data-plane separation
* sandboxed subsystems
* microservice trust domains
* confidential compute enclaves
* cross-node capability limits

Χ enforces structural distance:

* a principal in □_1 cannot directly observe or modify state in □_2
* communication must traverse a permitted corridor (P-CTRL message or broker)
* address mapping uses Φ to reinterpret Δ identities across boundaries
* policies (Ψ) apply invariants to crossings (encryption, auditing, allowed protocols)

Thus Χ is the core of zero-trust network architecture in PMS.

---

#### 9.4.3 Policy-Enforced Guarantees (Ψ)

Ψ provides global or scoped invariants:

```text
Ψ = { rule_1, rule_2, ... }
```

Each rule constrains future actions involving:

* sending or receiving packets
* routing decisions
* encryption requirements
* capability transitions
* entry into or exit from isolation frames
* control-plane operations
* traffic shaping and quota boundaries
* cluster-wide safety conditions

##### Examples of Ψ-level network invariants

* “All traffic crossing a given Χ boundary must be encrypted.”
* “Only nodes with Ω_admin may issue P-CTRL updates.”
* “Max hop count = 15 for tenant A.”
* “Topology changes must be serialized (Θ) and committed (Σ).”
* “Rate limit actor messages to N per τ-based accounting window.”
* “No routing through untrusted roles.”
* “Control-plane must never transit the data-plane frame.”

Ψ is enforced at every step: if a transition violates a policy, the machine:

1. rejects (halt or drop), or
2. reframes via Φ (fallback, downgrade), or
3. moves into containment via Χ, or
4. logs and continues under a reduced capability set (Ω downgrade).

---

#### 9.4.4 Message-Level Security (Ω, Ψ on PPS Messages)

Each PPS message carries:

* Ω_src → sender’s capabilities
* Ω_dst → required capabilities for the receiver
* Ψ_message → constraints governing delivery or processing
* Χ_boundary tags → which isolation domain or domains the message belongs to

This allows:

##### Authentication

Using capability claims:

```text
Δ_id + Ω_proof  =>  identity_verified
```

Ω_proof may include:

* cryptographic signatures
* MACs
* token-bound capabilities
* ephemeral session capabilities

##### Authorization

The receiver checks:

```text
Ω_src ⊆ Ω_allowed
```

under Ψ-enforced constraints.

##### Confidentiality

Ψ may enforce encryption:

* per tenant
* per message type
* per Χ-boundary crossing
* per protocol family (P-REQ, P-CTRL)

##### Integrity

Σ_commit rules require:

* checksums or hashes
* signatures
* replay protection
* sequence constraints (Θ-order)

Everything is operator-grounded; nothing is bolted on afterward.

---

#### 9.4.5 Secure Routing (Ω, Χ, Ψ + Δ, Θ, Φ)

Routing in PMS already depends on Δ, □, Θ, Φ, Λ, and Σ.
Security adds Ω, Χ, and Ψ to constrain routing.

##### Ω-based routing constraints

Roles define:

* who may route packets
* which prefixes or domains may be reached
* who may install routing rules (P-CTRL)
* gateway and border router roles
* privileged administrative paths

##### Χ-based segmentation

The routing graph is segmented:

```text
Graph = ⋃_i □^(i)    with crossings guarded by Χ^(i,j)
```

Routing attempts that violate Χ:

* are denied by Ψ
* or require encapsulation and transformation by Φ
* or trigger isolation downgrade or update

##### Ψ-based routing policies

Examples:

* “Tenant A cannot route into tenant B.”
* “Admin-only networks require Ω_admin.”
* “Traffic between zones must satisfy encryption = on.”
* “Must avoid certain intermediate nodes (privacy).”
* “No routing loops: detect via Θ-order and Σ consistency checks.”

---

#### 9.4.6 Secure Transport Frames (□_transport + Ω + Ψ)

Transport frames (from 9.1) include:

* stream (TCP or QUIC-like)
* datagram (UDP-like)
* channel (actor or mailbox-like)
* topic (pub-sub)

Security is applied structurally.

##### Frame entry (□_transport)

```text
enter_frame(□_transport) requires:
    Ω_perm  and  Ψ_rules
```

Violations lead to:

* Φ reinterpretation (fallback, downgrade)
* Λ denial (non-event)
* Χ containment
* Ψ-enforced halt

##### Frame lifetime

Ω and Ψ may impose:

* session expiration (τ and Λ based)
* key rotation constraints
* permissible payload sizes
* fragmentation rules
* backpressure behavior
* allowed P-CTRL operations inside the frame

---

#### 9.4.7 Control Plane Security (P-CTRL with Ω → Ψ → Σ)

P-CTRL messages (9.3) require the strongest security.

Control-plane operations include:

* routing updates
* link-state changes
* capability grants and revocations
* identity provisioning
* cluster membership updates
* driver and device reconfiguration
* version negotiation
* policy distribution

Operator sequence:

```text
Δ_ctrl ; Ω_auth ; Ψ_validate ;
Φ_recontext ; Θ_apply ; Σ_commit
```

Constraints:

* Ω_admin (or domain-specific capabilities) required
* Ψ ensures safety invariants during upgrade or migration
* Χ restricts which nodes may receive or forward control-plane messages
* Θ orders rollout steps
* Σ commits state transitions atomically

This yields a structurally enforced, safe control plane.

---

#### 9.4.8 Failure, Absence, and Attack Handling (Λ + Φ + Ψ)

Network anomalies are modeled explicitly using Λ.

##### Absence conditions

* missing ACK
* missing heartbeat
* missing P-CTRL confirmation
* timeout during routing update
* incomplete handshake
* unreachable node
* link down

Λ triggers Φ recontextualization:

* failover
* reroute
* downgrade
* quarantine frame
* version fallback
* policy reinforcement

Followed by Ψ checks which determine:

* whether to continue
* whether to isolate (Χ)
* whether to escalate
* whether to reject and halt

When a pattern of Λ events matches a Ψ-defined signature:

* an intrusion or anomaly is detected structurally
* no behavioral inferences about “attackers” are needed

---

#### 9.4.9 End-to-End Invariants (Ψ across nodes and frames)

Ψ invariants propagate across entire routing chains:

```text
Ψ_e2e = ⋂_i Ψ_node(i) ∩ Ψ_route
```

Ensuring:

* end-to-end encryption
* hop-limit enforcement
* traffic-class consistency
* QoS guarantees
* multi-tenant separation
* monotonic capability restrictions
* no downgrade attacks
* no frame confusion (□-isolation)

Each hop checks Ψ before forwarding.
Every Σ_commit is subject to Ψ constraints.

---

#### 9.4.10 Summary (9.4)

Network security in PMS is not a subsystem — it is a native structural phenomenon:

| Operator | Security Function                                 |
| -------- | ------------------------------------------------- |
| Ω    | capability, identity, authorization               |
| Χ    | segmentation, isolation, zero-trust boundaries    |
| Ψ    | global and local security policies, invariants    |
| Δ    | identity of principals, domains, message kinds    |
| Θ    | ordering and scheduling of secure transitions     |
| Λ    | failure detection, anomaly patterns (over τ)      |
| Φ    | recontextualization on error, fallback, migration |
| Σ    | commit of secure state transitions                |

This yields:

* zero-trust architecture
* segmented routing
* capability-aware communication
* secure control plane
* safe protocol evolution
* attack-surface minimization
* deterministic security guarantees via operator constraints

All encoded at the operator level, with no external assumptions.

---

### 9.5 Resilience, Failover & Congestion Handling (Λ/Θ/Φ/Σ)

Resilience in PMS networking is not implemented through ad-hoc error handlers or protocol-specific hacks.
Instead, it emerges from the interaction of four operators:

* Λ — Non-event / absence / failure
* Θ — ordering of retries, pacing sequence, scheduling
* Φ — Recontextualization / fallback / migration
* Σ — Integration / commit / stabilization

These four form a canonical pattern:

```text
Λ -> Θ -> Φ -> Σ
```

This is the structural “resilience pipeline.”
Every network anomaly, congestion event, or link failure flows through this sequence (possibly multiple times).

---

#### 9.5.1 Failure & Absence Detection (Λ)

Λ encodes meaningful absence in a context where something was expected.
Network-level Λ events include:

##### Missing or delayed transport events

* missing ACK
* missing heartbeat
* no P-REQ response
* request timed out
* TCP/QUIC-like retransmission timeout
* DNS-style missing answer
* failed handshake

##### Routing and topology absence

* silent node disappearance
* missing link-state update
* neighbor-not-seen condition
* unreachable destination

##### Control-plane absence

* no confirmation for P-CTRL
* no policy-distribution acknowledgment

Λ is always generated structurally, never heuristically:

```text
expected_event && !observed  =>  Λ
```

This makes Λ robust, predictable, and operator-consistent.

---

#### 9.5.2 Temporal Recovery Dynamics (Θ)

Once a Λ occurs, Θ determines how recovery steps are ordered and when retry actions are sequenced (using τ-based guards for actual durations).

Typical Θ-driven behaviors:

##### Backoff patterns (explicit attractors or Θ sequences)

* exponential backoff
* linear retry
* jitter-inserted retry
* scheduled retransmission sequences

These become attractors (Α-patterns) over Θ that can be composed:

```text
Α_retry = (Θ_step ∘ Δ_check)^k
```

where τ encodes the concrete wait parameters (for example, retry deadlines), and Θ orders the checks and retries accordingly.

##### Timeout windows

τ defines timeout and deadline values; Θ defines the ordered logic that consults τ and branches accordingly for:

* connection-timeout handling
* handshake windows
* routing propagation deadlines
* flow-control or congestion-control windows

##### Heartbeats and liveness

Θ sequences Δ-liveness checks along a τ-governed schedule:

* τ contains next-heartbeat deadlines
* Θ orders “check → decide → act” transitions
* Λ is generated when τ-based expectations are not met

Θ does not resolve the failure; it shapes the ordered progression under which τ-based recovery attempts may proceed.

---

#### 9.5.3 Adaptive Fallback & Recontextualization (Φ)

Φ applies when the meaning or context of a connection, route, or session must change.

##### Uses of Φ in resilience

(A) Failover to alternate routes

```text
Φ_route: □_route -> □_alt_route
```

Triggered when repeated Λ events and τ-based timeouts (evaluated by Θ-ordered checks) occur.

(B) Protocol-level fallback

* switch from QUIC-like to TCP-like semantics
* switch to degraded mode (reduced QoS)
* revert to version N-1 after handshake failure

This is Φ: same intention, new interpretation frame.

(C) Multi-path recontextualization

If path A is congested or failing:

```text
Φ_mpath: session -> multipath_mode
```

(D) Service-level migration

When a node becomes unreachable:

```text
Φ_service: endpoint -> new_endpoint
```

This is part of the structural reliability model, not a special RPC mechanism.

(E) Isolation downgrade (Χ + Φ)

If failure is suspicious or matches a Ψ-defined risk pattern:

```text
Φ_risk: □ -> □_sandbox
```

Used for:

* quarantining misbehaving nodes
* isolating a flooding endpoint
* preventing denial-of-service propagation

---

#### 9.5.4 Congestion Handling (Θ, Λ, Σ, Ψ)

Congestion is a τ-measured mismatch between offered load and available capacity over ordered progressions of communication.
PMS expresses congestion via:

* Λ — missing acknowledgments or delayed events (detected via τ)
* Θ — adjusting the order and pattern of rate changes and pacing decisions
* Σ — committing congestion-control state
* Ψ — enforcing global fairness and safety

##### Congestion signals (Λ)

Congestion typically manifests as:

* delayed ACKs
* queue overflows
* flow-control blocks
* missing heartbeats
* timeouts in P-REQ or P-CTRL

All of these are Λ events derived from τ-based expectations.

##### Rate adjustment (Θ)

Θ governs the ordered adaptation of rate parameters stored in τ:

* slow start (Θ sequences doubling of a window within bounds)
* congestion avoidance (Θ sequences linear increments)
* multiplicative decrease schedules
* pacing logic (Θ orders send decisions against τ-pacing parameters)

##### Recontextualization under congestion (Φ)

Φ may shift communication modes:

* high-throughput → low-throughput mode
* switch encodings or compression
* split a stream into multiple substreams
* migrate traffic to alternate paths

##### Committing stable congestion state (Σ)

When rate adjustments stabilize:

```text
Σ_cc: pending_window_updates -> committed_state
```

Σ ensures:

* consistent congestion window
* consistent routing tables
* consistent flow-control parameters
* atomic updates across nodes (if coordinated)

##### Policy constraints (Ψ)

Ψ enforces safety invariants such as:

* “No flow may exceed rate X across a tenant boundary.”
* “Control-plane traffic must never be throttled.”
* “Encrypted traffic must not be dropped unless mandatory.”
* “Congestion control changes must be monotonic under given conditions.”

Thus congestion handling is governed, not accidental.

---

#### 9.5.5 High-Availability Links & Multi-Path Resilience (Φ + Σ + Ψ)

High-availability networking is encoded through:

##### Redundant paths

```text
Φ: □_path1 -> □_path2
```

##### Atomic failover state commit

Σ commits the routing or connection-state change once stable.

##### Policies ensuring monotonic health

Ψ prevents oscillations by:

* forbidding rapid flapping between routes
* requiring a minimum stability window (τ + Θ-sequenced checks) before Φ is applied
* enforcing bounds on retry behavior (Θ) and overall budgets (τ)

---

#### 9.5.6 Session & Stream Resilience (Λ/Θ/Φ/Σ across PPS)

PMS Protocol Suite (9.3) gains resilience automatically.

##### P-REQ (request/response)

* Λ: missing response (τ-based)
* Θ: ordered retry sequences
* Φ: alternate target, fallback version
* Σ: commit final response or fallback result

##### P-EVT (event / notification)

* Λ: subscriber silent
* Θ: ordered retries with τ-parameterized intervals
* Φ: degrade to offline buffer mode
* Σ: finalize event delivery or discard based on Ψ

##### P-CTRL (control plane)

* Ψ disallows loss of essential control-plane messages
* Φ recontextualizes during partition
* Σ ensures consistent routing state across all nodes

---

#### 9.5.7 Partition Tolerance & Cluster Resilience

Partition handling is unified via the Λ → Θ → Φ → Σ chain.

##### Detection (Λ)

No messages from a region within τ-bounded expectations implies a partition is suspected.

##### Temporal heuristics (Θ)

Ordered sequences of:

* wait windows encoded in τ
* confirmation attempts
* stabilizing checks and probes

##### Recontextualization (Φ)

Two sides reinterpret themselves as:

* partitioned-primary
* partitioned-secondary
* read-only mode
* congestion mode
* degraded cluster

##### Commit (Σ)

Once conditions stabilize, the cluster commits:

* new membership view
* new authority node
* new routing graph
* new isolation boundaries

Cluster-level Ψ invariants ensure safety:

* no two primaries
* no uncontested authority split
* no cross-partition write violations

---

#### 9.5.8 Graceful Recovery & Reintegration (Σ + Φ)

When a previously failed or isolated node reappears:

1. Δ identifies the re-joining principal.

2. Ω validates capability (which may have been revoked).

3. Φ recontextualizes:

   * version negotiation
   * resync
   * role reassignment

4. Θ orders step-by-step resync operations over τ-tracked state.

5. Σ commits:

   * routing tables
   * membership view
   * flow-control parameters
   * node state alignment

Ψ ensures recovery does not violate consistency or security invariants.

---

#### 9.5.9 End-to-End Structural Pattern

All resilience mechanisms reduce to the canonical PMS pattern:

```text
Λ   (failure)
-> Θ   (ordered recovery logic)
-> Φ   (fallback / recontextualize)
-> Σ   (commit stable new state)
```

This is universal for:

* congestion control
* routing failover
* session recovery
* partition tolerance
* control-plane stabilization
* service migration
* transport fallback
* multi-path redundancy
* buffering and offline delivery
* handshake retries
* role or capability escalation or downgrade

This structural pattern is what makes PMS networking predictable, analyzable, and composable.

---

## 10 Security & Governance

### 10.1 Identity & Principal Model (structural)

This section defines the foundational identity substrate used across PMS-CPU, PMS-OS, PMSL, the networking stack, drivers, IPC, and governance systems.
Principals exist because the system must decide who may perform which transformations (Ω, Ψ, Χ).

Identity is therefore a first-class operator-level construct that binds:

* Δ – distinction: who or what is acting
* Ω – role or capability: what asymmetries and permissions apply
* Χ – isolation boundaries: which contexts the principal may access
* Ψ – invariants or policies governing identities
* Σ – integration: long-term bindings (keys, attributes, capabilities)
* Φ – recontextualization: delegation, impersonation, sandbox transitions

---

#### 10.1.1 Goals of the Principal Model

The PMS identity framework must satisfy:

1. Global uniqueness within a domain
   Each principal is uniquely distinguishable by Δ.

2. Role-binding and capability constraints
   Principal attributes map into Ω (capabilities, privilege tiers, device permissions, network roles, and so on).

3. Frame-scoped identity
   Identity must follow context (□): per-frame identities, per-process identities, per-connection identities.

4. Isolation mapping (Χ)
   Principals have isolation domains that determine accessible memory, IPC channels, and devices.

5. Policy-controllability (Ψ)
   Policies can restrict principal actions, revoke privileges, impose quotas, or reframe identity (Φ).

6. Composable across nodes
   The same structural definition works for:

   * local OS kernels
   * distributed systems
   * network connections
   * driver ecosystems
   * multi-node orchestration

---

#### 10.1.2 What is a Principal in PMS?

A Principal is the atomic “actor identity” unit in the system.

```text
Principal ::= {
    pid:   PrincipalID,
    attrs: PrincipalAttributes,
    caps:  CapabilitySet,   ; Ω
    frames: FrameScope,     ; □
    iso:   IsolationDomain, ; Χ
    pol:   PolicyLinks      ; Ψ
}
```

##### pid — PrincipalID

A globally unique identifier in the domain.
May be hierarchical, for example:

* NodeID:LocalPID
* Cluster:Node:Service:Thread
* UserID:ProcessID
* DeviceClass:DeviceID

Generated via Δ (distinction).

##### attrs — PrincipalAttributes

Metadata such as:

* type: user, service, kernel, driver, device, VM, container
* cryptographic materials (public keys)
* creation timestamps
* provenance
* resource limits (possibly overridden by Ψ)

##### caps — CapabilitySet (Ω)

The principal’s capabilities determine:

* memory access
* syscall subset
* device access
* IPC rights
* scheduling modes
* network roles
* privilege level transitions

##### frames — FrameScope (□)

Defines:

* active address space
* namespace
* call-stack frame lineage
* mapping of identity into frame-specific roles

Identity can change permissions depending on the enclosing frame.

##### iso — IsolationDomain (Χ)

Defines boundaries:

* which processes this principal can access
* which memory frames
* what IPC channels
* which namespaces
* whether this principal is confined to a sandbox

A principal’s isolation domain is enforced by both Ω and Χ.

##### pol — PolicyLinks (Ψ)

Policies that constrain or extend the principal’s behavior:

* auditing rules
* mandatory access control
* invariants (for example, cannot escalate without justification)
* key rotation rules
* quota policies
* revocation conditions

---

#### 10.1.3 Principal Classes (Static Typology)

PMS defines broad categories of principals:

##### 1. User Principals

Human-facing identity holders (conceptually): UID-like or account-like identifiers.

##### 2. Service Principals

Long-lived internal identities:

* system daemons
* background tasks
* database service
* network broker

##### 3. Process Principals (per execution context)

Every process gets a principal identity:

* `pid = (Node, ProcessID)`
* inherits from a user or service principal
* can be further restricted by isolation domain (Χ)

##### 4. Thread Principals

Optional, but permitted:

* each thread may hold its own derived principal
* used in highly secure systems with per-thread roles

##### 5. Device Principals

Each device or driver is a principal:

* allows fine-grained driver security
* driver cannot exceed its capability domain

##### 6. External Principals (Network)

Remote identities:

* certificates
* public keys
* negotiated identities from networking (transport and PPS)

These interact with local principals via Φ (recontextualization) and Ψ (authorization logic).

---

#### 10.1.4 Identity Binding Mechanisms (Δ, Σ, Ω)

Binding identity happens through integrative operator chains.

##### (A) Creation Binding (Δ → Σ)

When a process, service, device, or connection is created:

1. Δ distinguishes the new entity.
2. Σ binds attributes and capabilities.
3. Ω configures role.
4. Χ establishes isolation.
5. Ψ sets policy constraints.

##### (B) Delegation Binding (Φ → Ω → Σ)

A principal can delegate capabilities:

```text
delegate(P_src, P_dst, cap):
    Φ  – change interpretation of P_dst's context
    Ω  – append cap to P_dst.capabilitySet
    Σ  – commit delegation event to system log
```

Used for:

* privileged subprocess creation
* driver delegation
* network handshake identity passing
* IPC authority transfer

##### (C) Revocation Binding (Ψ → Σ)

Ψ policies revoke:

* capabilities
* access
* identity validity
* isolation permissions

Σ commits the revocation.

---

#### 10.1.5 Identity Across Frames (□)

Principals must map across multiple frames.

##### (1) Execution Frames

Each nested call stack frame may temporarily alter identity interpretation:

```text
call foo():
    □ – new frame
    Ω – restrict/add capabilities
    Ψ – enforce contract
end frame:
    capabilities revert
```

##### (2) Memory Frames

Access rights map directly to frame metadata:

* read/write/exec bits
* shared or mapped frames
* per-frame principal roles

##### (3) Network Frames

Each connection (from networking) is a □ frame:

* has its own security context
* principal identity may be transformed via Φ (for example, TLS handshake)
* mapped into a local principal via Σ

---

#### 10.1.6 Identity Across Isolation Boundaries (Χ)

Isolation domains define:

* principals allowed inside a sandbox
* transitions permitted between parent and child domains
* rules for data exchange
* syscall whitelisting

Χ + Ψ = mandatory isolation invariants.

Example:

```text
Process P1 -> ISO_FORK -> Child C1
Χ:  C1 inherits minimal capabilities only
Ψ:  C1 cannot escalate beyond parent's domain
Ω:  C1 may have additional internal roles
```

Isolation transitions are always mediated by Φ to recontextualize identity.

---

#### 10.1.7 Identity in Distributed Contexts (Δ–Φ–Ψ)

When a principal interacts across nodes:

##### Step 1: Distinguish remote principal (Δ)

* parse credentials
* verify certificate or public key
* classify principal type

##### Step 2: Apply recontextualization (Φ)

* map remote identity to local representation
* adjust role or capability set
* map remote isolation requirements into local ones

##### Step 3: Enforce policies (Ψ)

* apply trust rules
* audit rules
* quota and usage policies
* forwarding constraints

##### Step 4: Commit final identity view (Σ)

Identity becomes stable for the duration of the connection or session.

---

#### 10.1.8 Identity Lifecycle

A principal’s identity moves through:

1. Creation (Δ → Σ)
2. Contextual refinement (□, Ω, Φ)
3. Active operation (∇ governed by Ω and Ψ)
4. Delegation or capability changes (Φ → Ω)
5. Isolation modifications (Χ)
6. Policy updates or revocations (Ψ)
7. Destruction or garbage collection (Σ final)

---

#### 10.1.9 Identity as a First-Class Security Primitive

Identity is not a label; it is an active structural participant in the PMS transition system.

Principals:

* constrain allowable transitions
* carry policies forward through frames
* define the scope of isolation domains
* govern device and driver authority
* enforce network security
* harmonize distributed system semantics

Identity informs:

* which Δ distinctions are legal
* what ∇ impulses are allowed
* which □ frames can be entered
* when Λ timeouts (defined via τ) apply
* who may initiate Φ or Ω transitions
* what Σ integrations are permissible
* how Ψ invariants constrain behavior

Identity is therefore the anchor of security and governance across the entire PMS architecture.

---

#### 10.1.10 Identity Examples / Formal Identity Algebra

To make PMS identities operational in kernels, distributed systems, drivers, and languages, we now define:

1. a formal algebra of principal identities
2. operator-induced transformations over identities
3. worked examples
4. invariants required for system security

This algebra is minimal, closed, and directly aligned with PMS operators (Δ, Ω, Χ, Φ, Σ, Ψ).

---

##### 10.1.10.1 Identity Algebra: Core Objects

We define the algebraic structure:

```text
I = (ID, ∘, ⊑, ⊗, ▷, ⊎)
```

where:

##### 1. ID — Set of identities

Each identity is:

```text
id = (pid, attrs, caps, frames, iso, pol)
```

as established in 10.1.2.

##### 2. Composition (∘)

Identity composition represents derivation:

* new process from user
* thread from process
* device instance from device principal
* connection-context identity from remote principal

Formally:

```text
id_child = id_parent ∘ ctx
```

where ctx is a minimal context descriptor:

```text
ctx = (Δ_create, Ω_adjust, Χ_assign, Ψ_bind)
```

Composition applies the context transformation to the parent principal.

##### 3. Partial Order (⊑)

A structural subprincipal relation:

```text
id_a ⊑ id_b
```

meaning:

* every capability of `id_a` is a subset of `id_b`’s
* every isolation domain of `id_a` is equal or more restrictive
* policies of `id_b` encompass those of `id_a`

Thus:

```text
id_thread  ⊑ id_process ⊑ id_user
id_sandbox ⊑ id_process
```

##### 4. Capability Tensor (⊗)

Binary operation combining capability sets:

```text
caps(id_a ⊗ id_b) = caps(id_a) ∪ caps(id_b)
```

Used for:

* delegation
* merged identities in IPC
* driver-role augmentation

##### 5. Action Authorization (▷)

A relation:

```text
id ▷ op
```

meaning: identity `id` is permitted (by Ω + Ψ) to execute operator `op`.

This is determined by:

* capability set (Ω)
* policy constraints (Ψ)
* frame scope (□)
* isolation domain (Χ)

It defines the admissible transition set in PMS-UM (section 1.x).

##### 6. Policy Union (⊎ or ⊎_Ψ)

Combination of identity policies with global/system policies:

```text
pol(id_1 ⊎ id_2) = Ψ(id_1) ∪ Ψ(id_2)
```

Used for:

* cluster-wide identity propagation
* merging network-derived policies
* applying capability inheritance with constraints

---

##### 10.1.10.2 Operator-Induced Identity Transformations

Each PMS operator affects identities in a formally definable way.

###### Δ — Identity Differentiation

Produces a new unique principal ID:

```text
id' = Δ(id) = (new_pid, attrs, caps, frames, iso, pol)
```

Used for:

* process creation
* device instantiation
* network session establishment
* driver subcontext creation

---

###### Ω — Role/Capability Adjustment

Capability modification:

```text
id' = Ω(id, C_±)
```

where `C_±` adds or removes capabilities.

Must preserve:

```text
id' ⊑ id ⊗ C_+
```

---

###### Χ — Isolation Refinement

Defines a more restrictive isolation domain:

```text
id'  = Χ(id, iso')
iso' ⊆ iso(id)
```

Used for:

* sandbox entry
* per-connection isolation
* driver protection domains
* VM/container operations

---

###### Φ — Recontextualization

Identity reinterpretation across boundaries:

```text
id' = Φ(id, frame_target, role_target)
```

Examples:

* entering kernel mode
* mapping remote identity to local
* applying new version semantics
* driver identity mapping inside bus controllers

---

###### Σ — Commit / Integration

Identity fixation:

```text
id' = Σ(id)
```

which freezes:

* certain attributes
* policies
* isolation domains

Used for:

* post-authentication identity lock
* committed cluster node identities
* stable driver identities once initialized

---

###### Ψ — Policy Enforcement

Identity restriction or invariance:

```text
id' = Ψ(id, rules)
```

Rules can:

* cap capabilities
* forbid specific operators
* limit time or resource consumption
* require audit even if allowed

Ψ can also render identity invalid (revocation).

---

##### 10.1.10.3 Identity Algebra Laws

To ensure global consistency, identities must obey:

###### (1) Composition Associativity

```text
(id ∘ ctx1) ∘ ctx2 = id ∘ (ctx1 ∘ ctx2)
```

Frame and policy scopes must compose in a well-defined way.

---

###### (2) Monotonicity of Capabilities

If:

```text
id_a ⊑ id_b
```

then:

```text
caps(id_a) ⊆ caps(id_b)
```

---

###### (3) Isolation Contraction Law

Isolation can decrease but never increase without a privileged transition:

```text
id' = Χ(id, iso')  ⇒  iso' ⊆ iso
```

and reverse expansion requires Ω or Ψ permission.

---

###### (4) Policy Expansion Monotonicity

```text
pol(id_a ⊎ id_b) ⊇ pol(id_a) ∪ pol(id_b)
```

---

###### (5) Action Authorization Consistency

If:

```text
id ▷ ∇
```

then it must also be true that:

* Δ preconditions can be met
* Ω grants capability
* Ψ does not forbid the action
* Χ does not block relevant access
* □ supports the frame

Thus authorization is multi-factor valid.

---

##### 10.1.10.4 Worked Examples

###### Example 1 — Process Creation from a User

User identity:

```text
id_u = {
  pid  = U123,
  caps = {start_process, access_home},
  iso  = full_user_space,
  pol  = {...}
}
```

Process creation:

```text
id_p = id_u ∘ ctx_proc
```

Where:

```text
ctx_proc = (
   Δ_create,                 ; new PID
   Ω_adjust = {drop:system_caps},
   Χ_assign = {proc_isolation},
   Ψ_bind   = {audit_on_syscalls}
)
```

Yields:

```text
id_p = {
  pid  = P8842,
  caps = {read, write, IPC},    ; reduced
  iso  = proc_isolation,
  pol  = combined-policies
}
```

---

###### Example 2 — Driver Identity Mapping (kernel ↔ driver)

```text
id_kern = {caps = {manage_devices}, iso = kernel_space}
id_drv0 = id_kern ∘ ctx_driver
```

Context:

```text
ctx_driver = (
   Δ_driver_instance,
   Ω_adjust = {drop:kernel_memory_access, add:device_io},
   Χ_assign = {driver_sandbox},
   Ψ_bind   = {device_policy}
)
```

Driver identity is:

* isolated
* capability-limited
* governed by device policies
* unable to escalate unless Ω/Ψ permit

---

###### Example 3 — Network Principal Mapping

Remote identity:

```text
id_remote = {
  pid  = cert:CN=serviceA,
  caps = {net_client},
  pol  = {signed_by_CA}
}
```

Recontextualization via Φ:

```text
id_conn = Φ(id_remote, frame=connection_frame, role=network_service)
```

Then Σ commits it:

```text
id_conn_fixed = Σ(id_conn)
```

This becomes the identity used for:

* IPC
* service calls
* resource quotas
* audit logs

---

###### Example 4 — Impersonation with Delegation

Delegation:

```text
id_child  = Φ(id_parent, frame_child, role_child)
id_child2 = Ω(id_child, add={subset_capabilities})
id_final  = Σ(id_child2)
```

This models:

* sudo-like operations
* service-to-service delegation
* privilege-limited subprocess creation

---

##### 10.1.10.5 Minimal Identity Normal Forms

To support efficient kernel and runtime implementation, define two normal forms:

###### (1) Local Normal Form (LNF)

```text
id = (pid, caps, frame, iso)
```

Policies and attributes baked into `caps + iso`.
Used inside:

* threads
* processes
* scheduling
* syscalls

---

###### (2) Distributed Normal Form (DNF)

```text
id = (pid, caps, frame, iso, pol, provenance)
```

Used for:

* cross-node identities
* network security
* remote services
* multi-node orchestration

---

##### 10.1.10.6 Identity Validity Conditions

An identity is valid iff:

1. `pid` is unique in domain
2. `caps` authorized by Ω
3. `iso` enforced by Χ
4. policies consistent under Ψ
5. identity stands in a valid frame □
6. any recontextualizations (Φ) preserve invariants
7. Σ integrations do not break constraints

These conditions prevent:

* unauthorized elevation
* frame escape
* isolation violations
* policy bypass
* impersonation
* identity confusion attacks

---

##### 10.1.10.7 Summary

Identity algebra provides:

* explicit identity objects
* formal transformations (Δ, Ω, Χ, Φ, Σ, Ψ)
* capability and isolation logic
* compositional derivation of principals
* strict invariants ensuring security
* normal forms for kernel + distributed scenarios

Identity is not a metadata tag — it is a mathematically structured, operator-governed entity that shapes every state transition in the PMS architecture.

---

### 10.2 Role & Capability System (Ω)

*PMS-STACK Architecture — Structural, Operator-Level Specification*

This section defines the formal role and capability system of the PMS architecture entirely in terms of Ω, Ψ, Χ, and □, consistent with all previous identity and kernel specifications.

The Ω-system governs:

* what actions can be performed,
* in which frames,
* under which invariants,
* with which isolation boundaries,
* and how these permissions evolve structurally over ordered execution.

No psychology — only structural roles, capabilities, constraints, and operator-level dynamics.

---

#### 10.2.1 Purpose of Ω in the PMS Stack

Ω is the sole primitive operator responsible for establishing structural asymmetries in any PMS machine.

Functions:

1. Define allowed operator sets
   (Which of Δ, ∇, □, Θ, Φ, Χ, Σ, Ψ an identity/process/driver may invoke)

2. Bind capabilities to identities
   (Ref. §10.1 Identity Model)

3. Establish privileged pathways
   (System calls, kernel transitions, device access, etc.)

4. Restrict transitions
   by excluding specific operator sequences based on identity and frame.

5. Coordinate role changes across frames
   (User → kernel, driver → isolated, node → cluster service, etc.)

In short:

```text
Ω : identity → {allowed operator subsets}
```

and

```text
(id ▷ op) ⇔ op ∈ Ω(id) ∧ Ψ(id, op) ∧ Χ(id)-compatible
```

---

#### 10.2.2 Components of a Role

A role is a structured permission descriptor:

```text
role = (caps, frameScope, isoScope, policyScope)
```

Where:

##### (1) caps (capability set)

The primitive actions enabled for this role.

```text
caps ⊆ O × capabilities
```

Capabilities specify which operators (`O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}`) can be called under which parameters.

##### (2) frameScope (□-range)

Which frames are visible/selectable by this role.

Example:

```text
{ user_frame, process_frame }   ; user role
{ kernel_frame }                ; kernel role
{ driver_sandbox, device_mmio } ; driver role
```

##### (3) isoScope (Χ-domain)

Which isolation boundaries the identity can enter/exit.

Example:

* cannot escape its container
* cannot access sibling driver sandboxes
* can move from user → process → thread, but not reverse

##### (4) policyScope (Ψ-subset)

Which policies apply to the role and which it may modify.

Examples:

* user cannot modify system policies
* kernel can
* driver may only modify device-level policies
* network principal may have externally bound policies imported via Φ

---

#### 10.2.3 Capability Definition

A capability is defined structurally as:

```text
cap = (op, domain, params)
```

Where:

* `op ∈ {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}`
* `domain` is a frame or resource subset
* `params` restrict invocation (resource limits, specific devices, specific pages, etc.)

Capabilities implement fine-grained control of permissible actions.

For example:

```text
cap_write_page   = (∇, domain={page_0..page_3}, params={write})
cap_switch_frame = (□, domain={user_frame → process_frame})
cap_commit_fs    = (Σ, domain={fs_namespace}, params={commit})
cap_recontext    = (Φ, domain={net->service}, params={version=2})
```

---

#### 10.2.4 Capability Hierarchies and Lattices

Capabilities form a partial order:

```text
cap_a ⊑ cap_b  iff
(domain_a ⊆ domain_b) ∧ (params_a ⊆ params_b) ∧ (op_a = op_b)
```

Thus roles are capability sets forming a join-semilattice:

```text
role = ⋁ cap_i
```

Capability union (⊗) is monotonic:

```text
caps(id_a ⊗ id_b) = caps(id_a) ∪ caps(id_b)
```

Used for:

* delegation
* IPC identity merging
* distributed identity mapping

---

#### 10.2.5 Role Transitions (Ω-transformations)

Role transitions are performed by the operator Ω:

```text
id' = Ω(id, Δcaps, ΔframeScope, ΔisoScope, ΔpolicyScope)
```

With constraints:

* Capabilities can be dropped freely, but added only if Ψ permits.
* Isolation can only become more restrictive by default (Χ contraction).
* Frame scope changes must be consistent with privilege transitions.
* Policy scope changes must be validated by Ψ.

Thus transitions follow:

```text
id_new = id ∘ ctx_role
```

where `ctx_role` includes Ω adjustments.

---

#### 10.2.6 Role Types in the PMS-OS Kernel

The system provides canonical roles built directly from Ω:

##### (1) User Role

* Minimal capabilities
* Visible frames: user, home namespace
* Cannot modify policies
* Cannot access hardware frames directly
* Restricted isolation boundaries

---

##### (2) Process Role

* Derived from user via Δ creation
* Gains action capabilities (∇ on memory pages)
* Gets isolated sandbox via Χ
* Frame scope includes process frames

---

##### (3) Kernel Role

* Superset of capabilities
* Access to hardware frames (□)
* Can escalate or de-escalate other roles
* May modify system policies (Ψ)
* Root of isolation tree

---

##### (4) Driver Role

* Specialized capability subset:

  * ∇ only on device-specific MMIO/register pages
  * no access to general kernel memory

* Frame scope includes only `driver_sandbox` and device I/O frame

* Policy-enforced boundaries via `Ψ_driver`

* Runtime transitions allowed under Φ (device reset/reprobe)

---

##### (5) Network Principal Role

* Frame scope: `connection_frame`
* Capabilities limited to IPC, address resolution, protocol operations
* Imported policies via Φ during session establishment
* Restricted isolation to prevent state contamination

These are not “user categories” — they are purely structural permission sets defined by Ω and Ψ.

---

#### 10.2.7 Ω as Enforcement: Authorization Semantics

Authorization predicate for any operator invocation:

```text
id ▷ op(params)
```

is true iff *all* hold:

##### (1) Capability Check

```text
(op, domain, params) ∈ caps(id)
```

##### (2) Frame Check (□)

The operator targets must lie within `frameScope(id)`.

##### (3) Isolation Check (Χ)

The action must not cross forbidden isolation boundaries.

##### (4) Policy Check (Ψ)

No policy forbids this operator for this identity under current conditions.

##### (5) Operator Dependency Check

Structure must be valid:

```text
P(op) ⊆ Hist(s)
```

---

#### 10.2.8 Role Refinement and Decomposition

Roles can be decomposed into micro-roles or subroles:

```text
role = ⋃_i role_i
```

Example: a network service process may have:

* `role_net_recv`
* `role_net_send`
* `role_fs_read`
* `role_tls_handshake`

This decomposition enables:

* least-privilege isolation
* fine-grained auditing
* capability-scoped processes
* multi-frame execution limits

---

#### 10.2.9 Order-Scoped / Lifetime-Bound Roles (Θ + Ω + τ)

Roles can be bound to lifetime conditions represented in τ:

```text
Ω(id, grant:cap, expiry_ref ∈ τ)
```

Here, τ stores expiry and lifetime metadata; Θ orders the checks and transitions that consult τ and revoke or adjust capabilities when the corresponding τ conditions hold.

Used for:

* temporary delegation
* session-scoped permissions
* ephemeral elevated capabilities
* driver update windows
* cluster maintenance modes

---

#### 10.2.10 Summary

Ω provides a unified structural system for:

* role definition
* capability composition
* permission enforcement
* operator-level authorization
* isolation and policy integration
* role transitions across frames and contexts
* distributed identity consistency

It is the foundation of kernel privilege separation, driver safety, network security, filesystem access, and multi-node operations.

---

### 10.3 Policy Definition & Enforcement (Ψ)

*PMS-STACK Architecture — Structural Governance Layer*

Ψ is the highest-order operator in PMS.
It defines, activates, evaluates, and enforces system-wide or scoped invariants that restrict *all other operators* (Δ–Σ) along ordered execution.

Ψ governs:

* safety
* correctness
* consistency
* compliance
* resource constraints
* cross-frame behavior
* role transitions
* isolation boundaries
* scheduling fairness
* network trust
* filesystem integrity
* transactional state models

Ψ is thus the binding contract layer across all subsystems.

No psychology; strict structural semantics.

---

#### 10.3.1 Purpose of Ψ in the System

Ψ enforces global or scoped rules about what transitions are allowed.
It is not itself a transition that changes data — it constrains *all* transitions.

Formally:

```text
Ψ : S → {allow, deny, transform, halt}
```

For any operator invocation:

```text
(id, op, params, s) is valid  ⇔  Ψ(s, id, op, params) = allow
```

Ψ is the final arbiter of:

* operator admissibility
* permitted role transitions (Ω)
* frame scope changes (□)
* isolation crossing (Χ)
* transformation semantics (Φ)
* commit conditions (Σ)

---

#### 10.3.2 Structure of a Policy

A policy is a tuple:

```text
pol = (scope, conditions, actions, priority)
```

Where:

##### (1) scope

Defines the domain in which the policy applies:

* system-wide
* per-frame
* per-process
* per-driver
* per-device
* per-connection
* per-node
* per-distributed-trust-domain

##### (2) conditions

Predicates over:

* identity and roles (Ω)
* frame relations (□)
* isolation boundaries (Χ)
* operator being attempted
* resource usage
* τ-based time windows (evaluated along Θ-ordered checks)
* prior operator history (dependency graph)
* external trust assertions (for network identities)

##### (3) actions

What Ψ does when the conditions match:

* allow
* deny
* transform (redirect via Φ)
* isolate (tighten Χ)
* escalate (Ω restricted → fallback role)
* trigger commit/rollback (Σ)
* trap (Φ)
* halt (to S_H)

##### (4) priority

Policies form a priority-sorted set, defining a deterministic evaluation order.

---

#### 10.3.3 Policy Layers: Hierarchical Composition

Policies are structured into layers:

1. Ψ₀ — Machine Core Policies
   Hardware-level invariants:

   * no execution outside executable frames
   * no writes to read-only pages
   * no privilege escalation without explicit operator
   * commit/atomicity requirements

2. Ψ₁ — Kernel Policies

   * scheduling constraints
   * syscall safety
   * IPC message shape invariants
   * driver access correctness
   * per-process memory bounds

3. Ψ₂ — Filesystem & Network Policies

   * read/write/exec for FS paths
   * per-connection caps
   * encryption/integrity requirements
   * routing constraints

4. Ψ₃ — Application / Domain Policies

   * per-service limits
   * cross-service access constraints
   * data-shape invariants

All Ψ layers form a policy stack:

```text
Ψ = Ψ₀ ≺ Ψ₁ ≺ Ψ₂ ≺ Ψ₃ ≺ ...
```

Each layer can override or restrict the layer above.

---

#### 10.3.4 Policy Enforcement Mechanism

At every operator application:

```text
op(s) --Ψ-->
    s'   (allow)
    s_f  (deny / transform / halt)
```

Enforcement order:

1. Check structural preconditions (dependency constraints)
2. Check Ω capabilities (role/cap permissions)
3. Check Χ isolation rules
4. Run Ψ policy chain
5. Execute actual state transition

Thus Ψ sits at the final gate before any operator actually commits.

---

#### 10.3.5 Policy-Based Transformation (Φ + Ψ)

Ψ may instruct the system to transform the current operation via Φ.

Example transformations:

* convert illegal memory access into trap
* reframe context for compatibility (version mismatch)
* redirect syscall to higher-privileged implementation
* enforce fallback IPC route
* attach or detach isolation layers
* reinterpret role or frame under alternative semantics

Formally:

```text
Ψ(s, op) = transform(Φ(pattern))
op'      = Φ(op)
```

Execution continues under the new interpretation.

---

#### 10.3.6 Policy Domains and Models

##### (A) Memory Policies

* region access rules
* W^X enforcement
* stack guard
* driver MMIO boundaries
* DMA safety

##### (B) Process & Thread Policies

* max memory
* file descriptor limits
* allowed capabilities
* CPU quotas
* isolation barriers

##### (C) IPC & Synchronization Policies

* message shape
* mailbox quotas
* channel directionality
* sender/receiver authorization

##### (D) Filesystem Policies

* path-based permissions
* transactional guarantees
* namespace boundaries

##### (E) Network Policies

* allowed protocols
* cryptographic requirements
* incoming/outgoing address scopes
* routing constraints

##### (F) Distributed Policies

* trust anchors
* certificate/identity constraints
* cross-node capability delegations

All of these are expressed as Ψ rules over operators Δ–Σ.

---

#### 10.3.7 Policy Algebra

Policies form a structured algebra:

##### Union

```text
Ψ_A ∪ Ψ_B = Ψ_{A,B}
```

##### Intersection

```text
Ψ_A ∩ Ψ_B = Ψ_{A∧B}
```

##### Override

```text
Ψ_A ≺ Ψ_B  ⇒  Ψ_B has priority
```

##### Composition

```text
Ψ = Ψ_core ≺ Ψ_kernel ≺ Ψ_runtime ≺ Ψ_app
```

##### Monotonic tightening

Policies may only tighten unless explicit Φ transformation is granted:

```text
Ψ' ⊆ Ψ        is always safe
Ψ' ⊇ Ψ        requires Φ-validated recontextualization
```

---

#### 10.3.8 Policy Evaluation Semantics

A general evaluation step:

```text
function Psi_evaluate(id, op, params, s):
    for pol in sorted(policy_list):
        if pol.scope matches (id, frame(s), isolation(s)):
            if pol.conditions satisfied:
                return pol.actions
    return allow
```

Possible outcomes:

* allow: proceed with operator
* deny: operator forbidden; raise exception
* transform: replace op by Φ(op)
* isolate: apply Χ tightening
* escalate: controlled Ω role shift
* rollback: Σ-based rollback
* halt: transition to S_H

---

#### 10.3.9 Policy Installation & Modification

Ψ is modified only via Ψ-typed instructions:

```text
SET_POL   pol_id, cfg      ; Ψ
DEL_POL   pol_id           ; Ψ
UPDATE_POL pol_id, cfg     ; Ψ
CHK_POL   pol_id           ; Ψ
```

Constraints:

* only identities with capability `cap_modify_policy` may call these
* modifications may require Φ-mediated reframe
* system-core Ψ₀ cannot be relaxed without a privileged reboot path
* policies must remain internally consistent (checked by kernel Ψ validator)

---

#### 10.3.10 Runtime Enforcement Examples

##### 1. Illegal Frame Write

Process attempts:

```text
STORE kernel_frame+0x10, R1
```

Check path:

1. Ω: no capability → fail
2. Ψ: enforce trap → Φ(EXC_RAISE)

Result: exception, not crash.

---

##### 2. Driver Exceeds Allowed IO Ports

Driver tries to write outside allocated MMIO window.

Ψ yields:

```text
action = isolate
```

So Χ applies:

* isolate driver context
* revoke capabilities
* notify kernel

---

##### 3. Network Connection Without Required Crypto

A network principal sends plaintext.

Policy:

```text
if conn.requires_tls and packet.unencrypted:
    action = deny
```

Result: packet drop plus optional event.

---

##### 4. Process Exceeds Memory Quota

Policy triggers:

```text
action = transform(Φ_kill_or_oom)
```

Kernel terminates or reclaims memory.

---

#### 10.3.11 Summary

Ψ is the governance spine of the PMS architecture:

* defines safety and correctness rules
* restricts all operator transitions
* governs Ω role changes
* shapes □ frame functions
* enforces Χ isolation
* invokes Φ for reinterpretation or exceptions
* coordinates Σ commits and transactional consistency
* forms a multi-layer policy lattice

Everything in PMS-STACK — CPU, OS, FS, networking, IPC, concurrency — is ultimately bound by Ψ rules.

---

### 10.4 Audit & Compliance Hooks (Θ + Σ)

*PMS-STACK Architecture — Structural Observation, Logging, and Evidence Layer*

Audit and compliance in PMS are *structural runtime consequences* of the ordering operator Θ (sequencing, progression of execution steps) and the integration operator Σ (commit, finalization, consolidation).

* Θ gives the ordering and position of events within the execution sequence; τ carries any timestamp metadata.
* Σ gives *what actually became durable state*.

Together they form the foundation for a verifiable, replayable, and trustable system history.

No psychology — only system semantics.

---

#### 10.4.1 Rationale: Why Θ + Σ Enable Auditing

Auditing requires three invariants:

1. Execution ordering
   *Where in the ordered execution did something happen?*
   → Provided by Θ steps, sequence indices, scheduling order (correlated with τ-based timestamps if needed).

2. Committed reality
   *What ultimately happened?*
   → Provided by Σ commits, atomicity, transactional reductions.

3. Cross-context coherence
   *Events in one frame/role must be correlated across others.*
   → Provided by PMS frame/role identity, and Σ integration boundaries.

Thus PMS has first-class primitives for trace integrity, without inventing extra mechanisms.

---

#### 10.4.2 Audit Events as Structured Θ Records

Every operator application (Δ–Ψ) may produce a structured Θ event:

```text
E = (ts, op, id, frame, role, result, meta)
```

Where:

* ts — timestamp from τ (logical or physical time value inside m.τ)
* op — the PMS operator invoked
* id — actor identity/principal (from 10.1)
* frame — active □ context
* role — Ω privilege state
* result — success / denied / transformed / isolated / etc.
* meta — optional attributes (size, address, syscall number, message shape)

The Θ event stream is the raw audit log.

Θ defines ordering:

```text
E₁ ≺ E₂  ⇔  the Θ-induced execution step of E₁ precedes that of E₂
```

This ensures that all audits have a consistent, monotonic order, which can be correlated with τ-based timestamps even across isolation domains.

---

#### 10.4.3 Σ as Durable Evidence (Commit-Grade Records)

Not all Θ events matter for compliance.
Only committed effects matter.

Σ marks the boundary:

* before Σ → tentative, undoable actions (partial writes, provisional states)
* at Σ → state becomes binding
* after Σ → audit evidence becomes authoritative

Thus Σ produces an immutable audit checkpoint:

```text
C = Σ(s) = (hash(s_c), frame, role, policies, resource_usage, ...)
```

Each Σ event can include:

* hash of memory frame or affected regions
* hash of FS content after commit
* resource deltas
* isolation boundaries at time of commit
* policy set (Ψ) in effect at commit
* identity/role of committer

This forms a cryptographically chainable audit log (even without requiring cryptography):
each Σ state references its predecessor by Θ ordering and content hash.

---

#### 10.4.4 Audit Scopes

Policies can specify audit scopes to define what is recorded.

##### System-wide (Ψ₁ level)

* privilege transitions
* frame transitions
* traps/exceptions
* isolation entry/exit
* syscalls
* driver events
* network connection lifecycle

##### Resource-level (Ψ₂ level)

* FS writes
* memory allocation
* IPC sends/receives
* device IO

##### Domain-level (Ψ₃ level)

* per-service events
* workflow/state-machine transitions
* protocol compliance (network PPS events)

Scope determines how much Θ metadata is emitted and which Σ commits create durable evidence.

---

#### 10.4.5 Audit Hooks (Θ)

Audit hooks are inserted automatically by:

* the kernel
* drivers
* the network stack
* the filesystem
* the scheduler
* the isolation manager
* the policy engine

Example hook types:

##### Θ.AUDIT_OP(op, id, frame, role)

Emitted each time an operator is attempted.

##### Θ.AUDIT_ALLOW / Θ.AUDIT_DENY

Result of policy evaluation.

##### Θ.AUDIT_FRAME_ENTER / Θ.AUDIT_FRAME_LEAVE

Every □ transition.

##### Θ.AUDIT_ROLE_CHANGE(old, new)

Every Ω transition.

##### Θ.AUDIT_ISO_ENTER / Θ.AUDIT_ISO_EXIT

Every Χ isolation boundary crossing.

##### Θ.AUDIT_NET(packet_meta)

Message sent/received, with identity and routing data.

These events accumulate into the Θ log before any Σ commit makes them final or prunable.

---

#### 10.4.6 Commit Hooks (Σ)

Σ integrates both state and audit slices.

A Σ event creates a commit artifact:

```text
A_k = Σ(Θ_{i…j}, state)
```

Where:

* Θ_{i…j} — ordered set of Θ events since last Σ
* state — the post-commit machine state (or subset as defined by policy)

Each commit artifact `A_k` is:

* durable
* optionally hashed
* linked to `A_{k-1}`
* optionally written to FS or external logger
* optionally transmitted for distributed audit (for clustered systems)

Σ enforces atomicity:
the system cannot partially commit audit data.

---

#### 10.4.7 Audit Storage and Rotation

Audit data may be:

##### (1) In-memory Θ ring buffers

Short-term history for debugging.

##### (2) FS-backed audit journal

Structured, Σ-committed chunks (similar to FS journaling).

##### (3) Network-sent audit streams

Forwarded to trusted remote logger or compliance collector.

##### (4) Distributed audit fabric

For cluster-level invariants, each node’s Σ artifacts include cross-signatures of others.

Rotation policies (Ψ-managed):

* maximum size
* retention time
* tamper-prevention rules
* purge-on-commit
* encrypt-before-write (if the network domain demands it)

---

#### 10.4.8 Policy-Driven Audit Requirements (Ψ + Θ + Σ)

A policy may state:

* what must be audited
* when it must be committed
* how audit must be stored
* what failure response occurs if audit cannot be performed

Examples:

##### Example A: “all network packets must be logged”

Ψ_network:

```text
∀ send, recv: Θ.AUDIT_NET(...) ∧ Σ includes NET events
```

##### Example B: “failed syscall must produce durable evidence”

Ψ_kernel:

```text
fail(syscall)  ⇒  Θ.AUDIT_DENY ; Σ
```

##### Example C: “cross-isolation boundary writes must be committed with hash”

Ψ_iso:

```text
Χ boundary_cross  ⇒  Σ(hash_of_scope)
```

##### Example D: “all actions by role R must be logged”

Ψ_role:

```text
role = R  ⇒  audit everything
```

---

#### 10.4.9 Compliance Verification

Compliance frameworks act on:

* the Θ log (event stream)
* Σ commits (durable, tamper-evident snapshots)
* identity graph (10.1)
* role/capability lattice (10.2)
* active and past policies (10.3)

A compliance verifier checks:

* invariant satisfaction across Θ-ordered progressions
* no forbidden Δ or ∇ operations
* no cross-boundary actions without correct Ω + Ψ authorization
* all required audits present
* Σ commits consistent and unbroken
* no unexpected Φ exception or rollback sequences
* resource quota compliance

Compliance is a policy-based meta-check; it uses the same Ψ mechanism.

---

#### 10.4.10 Distributed Audit & Σ Chaining

For multi-node systems:

* each node commits `A_k`
* transmits `hash(A_k)` to peers
* receives hashes from them
* forms a Merkle chain or DAG of Σ commits

This allows:

* cluster-wide ordering
* detection of tampering
* cross-node compliance
* distributed rollback recovery
* replicated audit logs

This is structurally enabled by Θ ordering and Σ commit semantics — no extra constructs required.

---

#### 10.4.11 Auditable Subsystems Overview

| Subsystem | Θ Events                              | Σ Commits                           |
| --------- | ------------------------------------- | ----------------------------------- |
| CPU       | instruction-level trace, role changes | atomic operations, fences           |
| Kernel    | syscalls, scheduling, traps           | process state commits, IPC delivery |
| Memory    | allocation, faults                    | page-table and frame commits        |
| FS        | path operations                       | writeback, transaction commit       |
| Network   | send/recv events                      | connection/flow boundaries          |
| Drivers   | MMIO operations                       | configuration changes               |
| Isolation | boundary crossings                    | sandbox creation/destruction        |
| Policies  | evaluation                            | policy-set change commits           |

Auditing is unified under Θ and Σ across all layers.

---

#### 10.4.12 Summary

Audit and compliance in PMS-STACK are not add-ons — they are emergent from the execution model:

* Θ provides ordering, causal structure, and fine-grained event capture; τ provides time references for those events.
* Σ produces durable, atomic, tamper-evident commit points.
* Ψ defines what must be audited and what compliance means.
* Ω, □, Χ, Φ add the structural context needed for correct interpretation.
* Identities and principals (10.1) anchor all events to actors.

Together, PMS provides a full structural audit trail, suitable for:

* debugging
* compliance
* forensic reconstruction
* distributed trust
* safety-critical systems

---

### 10.5 Key / Trust Anchor Management (Φ / Ψ)

*PMS-STACK Architecture — Structural Cryptographic Rooting, Context Shifts, and Invariant Enforcement*

This section defines the PMS-native model for trust anchors, keys, credentials, and attestation infrastructure, entirely grounded in Φ (recontextualization / exception / interpretation shift) and Ψ (policy / invariant).

No psychology.
Only structural roles, frames, identities, and operator-level logic.

---

#### 10.5.1 Why Φ + Ψ Form the Trust Infrastructure

In PMS:

* Ψ governs what is accepted, what must be true, and what transitions are allowed → invariant layer
* Φ governs how something is to be interpreted → recontextualization layer

Trust anchors — public keys, certificates, root-of-trust objects — are interpretation mechanisms (Φ) backed by policy-level invariants (Ψ). Thus:

```text
Trust = Φ(credentials)  subject to  Ψ(policies)
```

And:

* key rotation = controlled Φ
* key validation = Ψ check
* compromise handling = Φ + Ψ-triggered reframe
* root-of-trust definition = Ψ-level hard invariant

The PMS model does not treat keys as magical objects; they are simply frames containing distinguishing data whose interpretation depends on established policy invariants.

---

#### 10.5.2 Key Material as PMS Frames (□)

A key is a frame with structured content:

```text
keyFrame = □(material, type, scope, metadata)
```

Where:

* material — raw bytes of key or certificate
* type — public / private / symmetric / ephemeral
* scope — which identities/roles may use it
* metadata — algorithm, key length, expiry reference stored in τ (for example `τ.expiry(key)`), allowed usage (Ω), commit bindings (Σ)

Key material is always kept inside isolated subframes (Χ), ensuring:

* separation of private keys
* distinction between runtime secrets and persistent trust anchors
* restricted copy paths enforced by Ω + Ψ

Thus:
keys = structured, isolated frames with explicit usage roles.

---

#### 10.5.3 Trust Anchors as Policy Constraints (Ψ)

A trust anchor is defined as:

```text
TA = (keyFrame, Ψ_verify, Ψ_use, Ψ_rotate)
```

Meaning:

1. Ψ_verify
   Policies for validating another key or signature using this anchor.

2. Ψ_use
   Policies determining where this anchor’s trust can propagate (for example, signing binaries, validating boot images, verifying network peers).

3. Ψ_rotate
   Policies defining when and how this anchor may be updated, replaced, revoked, or reinterpreted.

Trust anchors are never used directly; their effects always go through Ψ evaluation.

Example:

```text
Ψ_verify_signed_kernel:
    TA_root ⊢ verify(kernel_image.signature)
```

If a kernel image fails verification → a Φ exception reframe is triggered (boot failure, quarantine, fallback).

---

#### 10.5.4 Φ for Key Interpretation, Rotation, and Revocation

Recontextualization (Φ) handles all cases where the meaning of key material changes.

##### (A) Key Rotation

```text
Φ_rotate(keyFrame_old, keyFrame_new)
```

Creates a new interpretation context:

* new signing/verification rules
* rebinds policies using this key
* optionally preserves lineage metadata

##### (B) Key Revocation

```text
Φ_revoke(keyFrame)
```

Triggers:

* removal from trust anchor list
* immediate Ψ rules forbidding signing/verification
* optional fallbacks or quarantine modes

##### (C) Rolling Interpretation Windows

Keys with time-bound validity (τ metadata):

```text
Φ(keyFrame, τ.now) =
    valid    if τ.now < τ.expiry(key)
    expired  otherwise
```

Expiration is a τ-based Φ shift in the meaning of the frame; Θ only orders the checks that consult τ.

##### (D) Cross-Version Trust Conversion

Example: OS upgrade or new protocol version:

```text
Φ_version(keyFrame, newInterpretationRules)
```

Updates how signatures or identities are interpreted under a new code context.

---

#### 10.5.5 Key Usage Bound by Ω (Role Constraints)

The role/capability system (Ω) restricts which identities may perform:

* signing
* decryption
* verification
* key extraction
* key generation

For a given identity `id`:

```text
id ▷ use(keyFrame)
```

iff:

1. `cap(use(keyFrame)) ∈ caps(id)`
2. `keyFrame.scope` permits use
3. Ψ_use rules allow it
4. Χ isolation rules permit access to the key material
5. □ frame switches are allowed (if moving into secure key frame)

Thus Ω determines the structural surface of key usage, while Ψ determines semantic correctness.

---

#### 10.5.6 Σ for Key Commit and Durable Trust State

Key installation, removal, or rotation is always finalized via Σ:

```text
Σ(keyFrame, Ψ_state)
```

This produces:

* a durable record of trust configuration
* an optional hash of the trust anchor set
* binding to logs (Θ)
* persistence across reboots

Use cases:

* log of all key additions/removals
* reproducible trust state after boot
* cluster-wide synchronization of trust state

Σ ensures keys enter durable system state only through transactional integration.

---

#### 10.5.7 Boot-Time Trust Anchor Integration

Boot process is structurally:

1. Load root-of-trust keyFrames
2. Apply Ψ_verify(policy) to check boot image
3. Apply Φ to shift into "trusted" or "untrusted" boot context
4. Use Σ to commit trust state

This process is operator-complete:

* Δ distinguishes signature types
* □ selects boot frame
* Θ orders boot stages
* Ω restricts what can modify trust anchors
* Ψ enforces invariants
* Φ handles fallback or recovery
* Χ isolates boot loaders
* Σ commits validated states

---

#### 10.5.8 Network Trust Anchors (Distributed Ψ + Φ)

Network nodes establish trust using:

##### Ψ_session

Defines acceptable credentials, ciphers, and handshake steps.

##### Φ_negotiate

Recontextualizes connection based on:

* remote key
* protocol version
* identity mapping
* cluster policy

##### Σ_session

Commits established session keys, routing permissions, and identity links.

Thus network trust becomes:

```text
Φ(peerKey) ∧ Ψ(policy)  ⇒  Σ(sessionState)
```

with full PMS grounding.

---

#### 10.5.9 Distributed Trust Anchors & Cross-Node Ψ

Clusters or multi-node systems synchronize trust as follows:

1. Each node maintains a trust anchor set (Σ-committed).
2. Nodes exchange Θ-signed summaries (hashes, timestamps).
3. Φ resolves conflicts or divergent trust states.
4. Ψ policies enforce consistency rules (for example, majority, quorum, external authority).
5. Σ creates unified trust anchor commits across nodes.

This enables:

* distributed CA
* multi-node signing authorities
* consistent certificate revocation
* cluster governance (see section 14)

---

#### 10.5.10 Examples of Trust Anchor Types

##### Static Root-of-Trust Key

* lives in immutable frame (Χ)
* Ψ forbids rotation
* only allowed to verify OS/kernel images

##### Rotatable Root

* versioned keyFrames
* Φ handles rotation path
* Ψ controls conditions under which rotation is allowed

##### Intermediate Authorities

* policies define issuance rules
* Φ handles certificate signing and re-signing

##### Session Keys

* transient frames with τ-based expirations
* not persisted through Σ

##### Driver Keys

* bound to `driver_sandbox` scope
* used for authenticating firmware or device config

##### Cluster Governance Keys

* represent collective identities (10.1.9)
* Ψ ensures quorum-based recontextualization

---

#### 10.5.11 Summary

Key and trust management in PMS follows directly from PMS operator logic:

| Layer                              | Operator | Role                                                  |
| ---------------------------------- | -------- | ----------------------------------------------------- |
| Interpretation of keys         | Φ        | recontextualize key meaning, rotation, version shifts |
| Trust invariants               | Ψ        | define validity, acceptance, propagation rules        |
| Permission to use keys         | Ω        | assign structural capabilities                        |
| Isolation of key materials     | Χ        | secure frames, sandboxed key stores                   |
| Key storage and commit         | Σ        | durable system-wide trust state                       |
| Metadata / lifecycle           | τ        | expiry metadata, validity intervals in (m.τ)          |
| Distinctions between key types | Δ        | key type, algorithm, usage classification             |
| Frame-based key organization   | □        | where keys live in memory/FS/VM                       |

This provides a complete, rigorous, operator-grounded trust system across:

* boot,
* kernel,
* drivers,
* networking,
* distributed systems,
* language runtime,
* and storage.

---

## 11. PMSL – Language Specification

### 11.1 Lexical & Grammar (BNF)

PMSL is a statically typed, PMS-structured language whose syntax is designed so that:

* every construct can be annotated with a PMS operator (Δ…Ψ), and
* the compiler can emit an operator-tagged IR (section 11.1) that respects the dependency monoid from 0.3.

This section is purely syntactic:

* characters → tokens
* tokens → grammar (BNF)
* hooks for PMS operator annotations

Types, effects, operator mapping, and concurrency semantics come in 11.2–11.5.

---

#### 11.1.1 Source Text & Character Set

* Encoding: UTF-8.
* Case sensitivity: PMSL is case-sensitive.
* Line terminators: `\n` (LF) is canonical; `\r\n` is allowed and normalized.

Character classes (abstract):

* `LETTER` – `A–Z`, `a–z`, plus `_` and Unicode letters.
* `DIGIT` – `0–9`.
* `WS` – whitespace: space, tab, carriage return, newline.

---

#### 11.1.2 Tokens & Lexical Rules

Lexing rules (informal) followed by precise token definitions.

1. The source is read left to right and split into tokens.
2. `WS` and comments are ignored, except where they separate tokens.
3. Longest-match rule: when multiple tokens can be recognized, pick the longest.

##### Comments

```text
LineComment  ::= "//" { any-char-except-newline } 
BlockComment ::= "/*"  { any-char } "*/"         // nesting not required by spec
```

Comments are lexically removed.

##### Identifiers

```bnf
Identifier ::= Letter { Letter | Digit }
Letter     ::= "A"…"Z" | "a"…"z" | "_" | UnicodeLetter
Digit      ::= "0"…"9"
```

* Identifiers starting with `_` are reserved for generated / internal symbols (tooling, runtime).

##### Literals

Boolean:

```bnf
BoolLit ::= "true" | "false"
```

Integer:

```bnf
IntLit  ::= DecInt | HexInt | BinInt

DecInt  ::= DigitNonZero { Digit }
         | "0"

DigitNonZero ::= "1"…"9"

HexInt  ::= "0x" HexDigit { HexDigit }
HexDigit ::= Digit | "a"…"f" | "A"…"F"

BinInt  ::= "0b" BinDigit { BinDigit }
BinDigit ::= "0" | "1"
```

Float:

```bnf
FloatLit ::= DecInt "." { Digit } [ExpPart]
           | "." Digit { Digit } [ExpPart]
           | DecInt ExpPart

ExpPart  ::= ("e" | "E") ["+" | "-"] DecInt
```

String:

```bnf
StringLit ::= "\"" { StringChar } "\""

StringChar ::= any char except '"' or '\'
             | EscapeSeq

EscapeSeq  ::= "\\" ( "\"" | "\\" | "n" | "r" | "t" | "0" | "u{" HexDigit {HexDigit} "}" )
```

Char:

```bnf
CharLit ::= "'" CharChar "'"

CharChar ::= any char except "'" or '\'
           | EscapeSeq
```

Bytes (optional but useful):

```bnf
BytesLit ::= "b\"" { ByteChar } "\""
ByteChar ::= StringChar
```

---

#### 11.1.3 Keywords

Keywords are reserved identifiers and cannot be used as user-defined names.

##### Structural / module

```text
module, import, as, from, expose, alias
```

##### Types & declarations

```text
type, struct, enum, union, trait, impl, fn, proc,
let, var, const
```

##### Control flow

```text
if, then, else, match, case, of,
while, for, in, loop, break, continue, return
```

##### Concurrency / IPC / processes

```text
spawn, async, await, send, recv, select,
process, actor, channel
```

##### Roles / policies / security

```text
role, capability, policy, requires, ensures, with,
principal, as_role, assume, assert
```

##### Exceptions / events

```text
try, catch, finally, raise, signal, timeout
```

##### Misc

```text
true, false, null, unit
```

PMS-operator names (`delta`, `nabla`, `phi`, and so on) are not keywords; operator annotations use a different lexical channel (see below).

---

#### 11.1.4 Operators & Punctuation

Arithmetic & bitwise:

```text
+  -  *  /  %  &  |  ^  <<  >>  ~
```

Comparison & logical:

```text
==  !=  <  <=  >  >=
&&  ||  !
```

Assignment & composition:

```text
=  :=  +=  -=  *=  /=  %=  &=  |=  ^=  <<=  >>=
->  =>  ::
```

* `=`   – value binding / simple assignment
* `:=`  – rebind / mutable update (semantics in 11.2)
* `->`  – function/arrow type
* `=>`  – match/guard arrow, or lambda body
* `::`  – path separator for modules/types

Punctuation:

```text
(  )  [  ]  {  }  ,  ;  :  .  @  #
```

---

#### 11.1.5 PMS Operator Annotations (Δ, ∇, □, …)

PMSL allows explicit tagging of syntactic constructs with PMS operators, both in Unicode and in ASCII.

##### Operator tokens

Unicode forms:

```text
Δ  ∇  □  Λ  Α  Ω  Θ  Φ  Χ  Σ  Ψ
```

ASCII aliases (case-sensitive):

```text
DELTA, NABLA, FRAME, LAMBDA0, ATTR, OMEGA, THETA,
PHI, CHI, SIGMA, PSI
```

The lexer recognizes:

* either a single Unicode symbol (for example `Δ`), or
* its ASCII alias (for example `DELTA`)

as an OpTag token when used in annotation position.

##### Annotation syntax

Statement / expression annotation:

```bnf
OpAnnot  ::= "@" OpTag
OpTag    ::= "Δ" | "∇" | "□" | "Λ" | "Α" | "Ω" | "Θ" | "Φ" | "Χ" | "Σ" | "Ψ"
           | "DELTA" | "NABLA" | "FRAME" | "LAMBDA0" | "ATTR"
           | "OMEGA" | "THETA" | "PHI" | "CHI" | "SIGMA" | "PSI"
```

Usage examples (informal):

```pmsl
@Δ if x > 0 { ... }

@∇ let y = x + 1;

@Ω role Admin { ... }

@Σ commit_changes();
```

Block / declaration annotation:

```pmsl
@Φ
fn migrate(old: OldType) -> NewType { ... }

@Ψ
policy NoRawSyscalls { ... }
```

Semantically:

* at most one primary `OpTag` per syntactic node
* additional tags (for example meta-annotations) are possible via attributes (e.g. `#[...]`) but are defined in 11.2

---

#### 11.1.6 High-Level Grammar Overview

We now give a core BNF for PMSL, sufficient to parse full programs and attach OpTags.
Details of types and constructs will be refined in 11.2–11.4.

BNF convention:

```bnf
<nonterm> ::= production
           | alternative
{ X }     ::= zero or more repetitions
[ X ]     ::= optional
```

---

##### 11.1.6.1 Program & Modules

```bnf
Program       ::= { TopLevelDecl }

TopLevelDecl  ::= ModuleDecl
                | ImportDecl
                | TypeDecl
                | RoleDecl
                | PolicyDecl
                | ProcessDecl
                | FnDecl
                | ConstDecl

ModuleDecl    ::= "module" ModulePath "{" { TopLevelDecl } "}"

ModulePath    ::= Identifier { "::" Identifier }

ImportDecl    ::= "import" ModulePath ["as" Identifier]
                | "import" ModulePath "::" "{"
                      ImportItem { "," ImportItem }
                  "}"

ImportItem    ::= Identifier ["as" Identifier]
```

---

##### 11.1.6.2 Declarations (sketch)

```bnf
ConstDecl     ::= "const" Identifier ":" Type "=" Expr ";"

TypeDecl      ::= "type" Identifier TypeParamsOpt "=" TypeBody ";"

TypeParamsOpt ::= [ "<" TypeParam { "," TypeParam } ">" ]
TypeParam     ::= Identifier

TypeBody      ::= StructBody
                | EnumBody
                | AliasBody
                | UnionBody

StructBody    ::= "struct" "{" FieldDecl { ";" FieldDecl } [ ";" ] "}"
FieldDecl     ::= Identifier ":" Type

EnumBody      ::= "enum" "{" EnumVariant { "," EnumVariant } [ "," ] "}"
EnumVariant   ::= Identifier [ "(" Type { "," Type } ")" ]

AliasBody     ::= Type

UnionBody     ::= "union" "{" FieldDecl { ";" FieldDecl } [ ";" ] "}"

RoleDecl      ::= [ OpAnnot ]
                  "role" Identifier
                  "{" RoleItem { ";" RoleItem } [ ";" ] "}"

RoleItem      ::= "capability" Identifier ":" CapabilitySpec

CapabilitySpec ::= Type                          // details in 8.2 / 11.3

PolicyDecl    ::= [ OpAnnot ]
                  "policy" Identifier
                  "{" PolicyClause { ";" PolicyClause } [ ";" ] "}"

PolicyClause  ::= "requires" Expr
                | "ensures" Expr
                | "forbid" Expr

ProcessDecl   ::= [ OpAnnot ]
                  "process" Identifier
                  "(" ParamListOpt ")"
                  ProcessBody

ProcessBody   ::= Block
```

`FnDecl` is the main function construct:

```bnf
FnDecl        ::= [ OpAnnot ]
                  "fn" Identifier
                  "(" ParamListOpt ")"
                  [ "->" Type ]
                  FnBody

ParamListOpt  ::= [ Param { "," Param } ]
Param         ::= Identifier ":" Type

FnBody        ::= Block
                | "=>" Expr   // expression-bodied (lambda-like)
```

---

##### 11.1.6.3 Blocks, Statements, and Operator Annotations

A block introduces a scope (□ at the language level):

```bnf
Block         ::= "{" { Stmt } "}"
```

Every statement can optionally carry an OpAnnot:

```bnf
Stmt          ::= [ OpAnnot ] CoreStmt

CoreStmt      ::= LetStmt
                | VarStmt
                | ExprStmt
                | IfStmt
                | MatchStmt
                | WhileStmt
                | ForStmt
                | ReturnStmt
                | BreakStmt
                | ContinueStmt
                | SpawnStmt
                | SendStmt
                | RecvStmt
                | TryCatchStmt
```

Bindings:

```bnf
LetStmt       ::= "let" Pattern [ ":" Type ] "=" Expr ";"
VarStmt       ::= "var" Pattern [ ":" Type ] "=" Expr ";"

Pattern       ::= Identifier
                | "_"
                | "(" Pattern { "," Pattern } ")"
```

Expression statements:

```bnf
ExprStmt      ::= Expr ";"
```

Control flow:

```bnf
IfStmt        ::= "if" Expr Block [ "else" BlockOrIf ]
BlockOrIf     ::= Block | IfStmt

MatchStmt     ::= "match" Expr "{"
                      MatchArm { MatchArm }
                 "}"

MatchArm      ::= "case" Pattern [ "if" Expr ] "=>" Block

WhileStmt     ::= "while" Expr Block

ForStmt       ::= "for" Pattern "in" Expr Block

ReturnStmt    ::= "return" [ Expr ] ";"
BreakStmt     ::= "break" ";"
ContinueStmt  ::= "continue" ";"
```

Concurrency / IPC (hooks only; semantics in 11.4):

```bnf
SpawnStmt     ::= "spawn" Expr ";"

SendStmt      ::= "send" Expr "to" Expr ";"
RecvStmt      ::= "recv" Expr "into" Pattern
                  [ "timeout" Expr ] ";"
```

Exceptions & events:

```bnf
TryCatchStmt  ::= "try" Block
                  "catch" "(" Pattern ")" Block
                  [ "finally" Block ]

RaiseStmt     ::= "raise" Expr ";"
SignalStmt    ::= "signal" Expr ";"
TimeoutStmt   ::= "timeout" Expr Block
```

(The last three can also be treated as `ExprStmt` with special expression kinds.)

---

##### 11.1.6.4 Expressions

Expressions are PMSL’s core term language. We define them with familiar precedence, plus room for PMS-specific constructs.

```bnf
Expr          ::= LambdaExpr

LambdaExpr    ::= OrExpr
                | "|" ParamListOpt "|" "=>" Expr   // anonymous function

OrExpr        ::= AndExpr { "||" AndExpr }
AndExpr       ::= RelExpr { "&&" RelExpr }

RelExpr       ::= AddExpr
                | RelExpr RelOp AddExpr

RelOp         ::= "==" | "!=" | "<" | "<=" | ">" | ">="

AddExpr       ::= MulExpr { ("+" | "-") MulExpr }
MulExpr       ::= UnaryExpr { ("*" | "/" | "%") UnaryExpr }

UnaryExpr     ::= PrimaryExpr
                | ("+" | "-" | "!" | "~") UnaryExpr

PrimaryExpr   ::= Literal
                | Identifier
                | "(" Expr ")"
                | PrimaryExpr "." Identifier
                | PrimaryExpr "(" ArgListOpt ")"
                | "[" Expr { "," Expr } "]"       // list/array literal
                | BlockExpr

BlockExpr     ::= Block     // expression-valued block

Literal       ::= IntLit | FloatLit | StringLit | CharLit
                | BoolLit | BytesLit | "null" | "unit"

ArgListOpt    ::= [ Expr { "," Expr } ]
```

Operator precedence (highest to lowest):

1. Primary (`()`, `[]`, `.`, function call)
2. Unary (`+`, `-`, `!`, `~`)
3. Multiplicative (`*`, `/`, `%`)
4. Additive (`+`, `-`)
5. Relational (`<`, `>`, `<=`, `>=`)
6. Equality (`==`, `!=`)
7. Logical AND (`&&`)
8. Logical OR (`||`)

All binary infix operators are left-associative, except:

* comparison operators are non-chainable in this base grammar (i.e. `a < b < c` is not allowed syntactically; must write `(a < b) && (b < c)`),
* `=>` and `->` are right-associative where they occur.

---

##### 11.1.6.5 Types (syntactic skeleton)

Detailed type system is in 11.3; here we just define syntax categories.

```bnf
Type          ::= ArrowType

ArrowType     ::= SumType [ "->" Type ]      // right-associative

SumType       ::= ProdType { "|" ProdType }  // union / variant-like

ProdType      ::= AppType { "*" AppType }    // product / tuples

AppType       ::= SimpleType { TypeArgList } // type application

SimpleType    ::= Identifier
                | ModulePath "::" Identifier
                | "(" Type ")"
                | "[" Type "]"              // list/array type
                | "unit"

TypeArgList   ::= "<" Type { "," Type } ">"
```

Examples (informal):

```pmsl
fn f(x: Int, y: Int) -> Int { ... }
type Maybe<T> = enum { None, Some(T) }
type Pair<A,B> = (A * B)
type Proc = process(Unit) -> Unit
```

---

#### 11.1.7 Grammar Hooks for Operator-Typed IR

To support the operator-tagged IR:

1. Every statement and expression admits an optional `OpAnnot`.

2. At the IR level, the compiler will:

   * decorate each node with an effective operator tag:

     * explicit `@Δ` and similar if present,
     * otherwise inferred from construct and context (11.2).

3. For convenience, the grammar can be seen as:

```bnf
AnnotatedNode ::= [ OpAnnot ] Node
```

where `Node` ranges over:

* `TopLevelDecl`
* `Stmt`
* `Expr` (for explicit expression-level ops)
* `TypeDecl`, `RoleDecl`, `PolicyDecl`, `ProcessDecl`, `FnDecl`

This structural hook guarantees that every executable piece of PMSL code can be traced back to a PMS operator in the monoid (0.3).

---

#### 11.1.8 Minimal Example

Illustrative PMSL snippet that type-checks under this grammar (semantics to follow later):

```pmsl
module example::counter {

    type Counter = struct {
        value: Int
    }

    @Ω
    role CounterUser {
        capability inc: Counter;
    }

    @Ψ
    policy NonNegative {
        requires self.value >= 0;
    }

    @∇
    fn inc(c: Counter) -> Counter {
        let next = c.value + 1;
        return Counter { value: next };
    }

    @Δ
    fn main() -> unit {
        let c0 = Counter { value: 0 };
        let c1 = inc(c0);
        if c1.value > 10 {
            // ...
        }
    }
}
```

This is valid PMSL lexically and grammatically per 11.1; the meaning of `@Ω`, `@Ψ`, `@∇` and the type `Counter` will be specified in:

* 11.2 – Core Constructs & Operator Mapping
* 11.3 – Type System
* 11.4 – Concurrency & IPC
* 11.5 – Error & Exception Handling

---

### 11.2 Core Constructs & Operator Mapping

This section defines how every core construct in PMSL maps to the PMS operator algebra
(Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ).

Goal:
For every syntactic construct in PMSL (bindings, functions, control flow, blocks, concurrency, modules), we specify:

1. Primary operator (what the construct fundamentally *is*)
2. Secondary operators (implicit structural effects)
3. Compiler output (operator-tagged IR form)

This is the semantic backbone that ensures PMSL → PMS-CPU → Kernel → Runtime remain operator-consistent.

---

#### 11.2.1 Overview Table (High-Level Mapping)

| PMSL Construct            | Primary PMS Op  | Secondary Ops      | Explanation                                                  |
| ------------------------- | --------------- | ------------------ | ------------------------------------------------------------ |
| `let` binding             | Δ           | Σ                  | distinguish + integrate immutable binding                    |
| `var` binding             | Δ           | ∇, Σ               | distinction + mutable state cell creation                    |
| mutation (`x := e`)       | ∇           | Σ                  | state-changing write, commit local update                    |
| blocks `{ ... }`          | □           | Θ, Σ               | new context frame, structured sequence                       |
| conditionals (`if`)       | Δ           | Θ, Φ               | branch by distinction; Φ used in fallthrough simplifications |
| loops (`while`, `for`)    | Α (pattern) | Θ, Δ, ∇            | loop attractor expands to internal Δ/Θ/∇ cycles              |
| functions                 | □           | Ω (roles), Σ       | call frame = new □; return = Σ                               |
| returns                   | Σ           | Φ (escape context) | integration of result + exit frame                           |
| `match` / `case`          | Δ           | Θ                  | multi-way distinction                                        |
| `try` / `catch` / `raise` | Φ           | Λ, Σ               | recontextualization of error; Λ for absence of normal return |
| `async` / `await`         | Θ           | Χ                  | ordering suspension + isolated future frame                  |
| channels / send / recv    | Δ / ∇       | Λ, Θ, Ω            | send = ∇; recv = Δ + Λ (timeout)                             |
| spawning processes        | Χ           | Θ, Ω               | new isolated execution context                               |
| modules                   | □           | Ψ                  | namespace frame, bound by policy                             |
| imports                   | Δ           | Σ                  | distinguish and integrate symbol sets                        |

Below we go construct by construct.

---

#### 11.2.2 Bindings (`let`, `var`, constants)

##### 1. `let` — Immutable Binding

Semantic operator mapping:

* Primary: Δ — introduces a new distinction (name → value).
* Secondary: Σ — integrates the binding into the current frame.

IR form:

```text
Δ(bind name)
Δ(eval expr)
Σ(install name = value)
```

Characteristics:

* no ∇ allowed on this symbol in this frame (enforced by Ψ-type rules)
* compiled into a □-local namespace entry

---

##### 2. `var` — Mutable Binding

Semantic operators:

* Primary: Δ — introduce variable name
* Secondary: ∇ — allocate mutable cell
* Σ — finalize binding into frame

IR:

```text
Δ(bind name)
Δ(eval initializer)
∇(allocate mutable cell)
Σ(install name → cell)
```

Ψ may restrict mutation privileges based on Ω (role).

---

##### 3. Mutation (`x := e`)

* Primary: ∇
* Secondary: Σ — commit update to the variable’s cell

IR:

```text
Δ(resolve x)
Δ(eval expr)
Ω(check write capability)
∇(write cell(x) ← value)
Σ(complete update)
```

---

#### 11.2.3 Blocks & Scopes

A block:

```pmsl
{
    statements...
}
```

maps to:

* Primary: □ (new lexical frame)
* Secondary:

  * Θ — execution sequencing in the frame
  * Σ — integrate frame results (typically discard scope-locals except return value)

IR shape:

```text
□(enter frame)
Θ(stmt1)
Θ(stmt2)
...
Σ(exit frame)
```

Return statements (below) inject Φ + Σ into block exit.

---

#### 11.2.4 Control Flow

##### 1. `if` expression / statement

An `if` is a Δ-driven branching:

```pmsl
if cond { t } else { f }
```

IR:

```text
Δ(eval cond)
Ω(check branch capability if needed)
Θ(branch)
□ enter true/false frame
...
Σ(merge branch outputs)
```

Notes:

* Δ is the “type of branch path chosen”.
* Θ orders branch entry.
* Σ merges outcomes into a single continuation value.

---

##### 2. `match` / `case`

Pattern matching is multi-way Δ:

```pmsl
match x {
    case A(v) => ...
    case B    => ...
}
```

Mapping:

* Δ (pattern discriminate) for each case arm
* Θ for sequential arm testing
* Σ at merge

---

##### 3. Loops (`while`, `for`, `loop`)

Loops are Α – attractors, expansions of reusable operator sequences.

Example:

```pmsl
while cond { body }
```

Expands to IR macro:

```text
Α(LOOP) expands to:
LABEL start:
  Δ(cond)
  Θ(branch)
  if false → goto end
  □(enter body frame)
    body...
  Σ(exit body)
  Θ(step)
  goto start
LABEL end:
```

Operators involved:

* Α — loop macro/pattern
* Δ — check condition
* Θ — iteration ordering
* □/Σ — body frame

---

#### 11.2.5 Functions and Calls

##### Function Definition

```pmsl
fn f(a: A, b: B) -> C { ... }
```

Maps to:

* Primary: □ — function body = new evaluation frame.
* Secondary:

  * Ω — function may define required roles or capabilities.
  * Σ — on return, integrate return value into caller context.

IR template:

```text
□(enter fn-frame)
Δ(bind parameters)
Θ(seq body statements)
Σ(return value)
```

---

##### Function Call

* evaluate arguments: Δ + Θ
* create call frame: □
* apply role/policy constraints: Ω, Ψ
* execute body
* return: Σ + Φ (exit context)

IR:

```text
Δ(resolve function)
Δ(eval arg1)
...
□(enter call frame)
Θ(exec)
Σ(return integration)
Φ(pop frame context)
```

---

##### Return

```pmsl
return e;
```

* Σ — integrate value as function output
* Φ — shift out of current frame (unwind)

IR:

```text
Δ(eval e)
Σ(set return value)
Φ(exit frame)
```

---

#### 11.2.6 Exceptions, Errors, Recontextualization (Φ, Λ)

##### 1. `try` / `catch` / `finally`

```pmsl
try { ... } catch(e) { ... } finally { ... }
```

Semantic mapping:

* Φ — error → new interpretive context (exception)
* Λ — absence of normal result
* Σ — finalize body or handler

IR skeleton:

```text
□ try-frame
Θ exec
if error:
   Φ(recontextualize → exception-frame)
   □ catch-frame
   Σ(merge)
finally:
   □ fin-frame
   Σ(merge)
```

---

##### 2. `raise e`

* Φ — reframe into error state
* Λ — suppress normal return path

IR:

```text
Δ(eval e)
Φ(create exception context)
Λ(abort normal flow)
```

---

#### 11.2.7 Concurrency & IPC Constructs

##### 1. `spawn expr`

Creates a new isolated execution locus:

* Primary: Χ — new execution boundary
* Secondary:

  * Θ — scheduler enqueues
  * Ω — assign role/capabilities to subprocess

IR:

```text
Δ(eval expr)
Χ(fork new context)
Ω(assign role)
Θ(schedule new task)
```

---

##### 2. Channels: `send`, `recv`, `select`

###### `send x to ch`

* Primary: ∇ — mutate queue state
* Secondary:

  * Ω — capability to send
  * Θ — event sequencing

IR:

```text
Δ(resolve ch)
Δ(eval x)
Ω(check send rights)
∇(enqueue x into ch)
Θ(signal receiver wakeup)
Σ(update channel state)
```

---

###### `recv ch into var timeout t`

* Primary: Δ — check if message available
* Λ — if not and timeout fires
* ∇ — bind received value

IR:

```text
Δ(resolve ch)
Δ(check queue head)
if empty:
   Θ(start timeout)
   Λ(on timeout)         // non-event
else:
   ∇(dequeue)
   Σ(bind var)
```

---

###### `select { recv ch1; recv ch2; … }`

* multi-way Δ
* Λ for timeouts
* Θ schedules readiness

---

#### 11.2.8 Modules, Imports, Namespaces

##### 1. Modules

```pmsl
module X { ... }
```

* Primary: □ — namespace frame
* Secondary: Ψ — module-level invariants / visibility rules

IR:

```text
□(enter module frame)
Ψ(apply module policy)
Σ(export module bindings)
```

---

##### 2. Imports

```pmsl
import m::x as y
```

* Primary: Δ — select symbol from module
* Secondary: Σ — merge into current namespace

IR:

```text
Δ(resolve module path)
Δ(select symbol)
Σ(bind alias in frame)
```

---

#### 11.2.9 Policies, Roles, Capabilities in PMSL Constructs

PMSL exposes Ω/Ψ declarations directly.

##### `role`

```pmsl
role Admin {
    capability shutdown: System;
}
```

Semantic:

* Ω — role definition operator
* Ψ — compiled rule for enforcement

IR:

```text
Ω(declare role Admin)
Σ(register capabilities)
```

---

##### `policy`

```pmsl
policy SafeFS {
    requires path.starts_with("/home");
}
```

* Ψ — invariants
* Δ — distinctions inside conditions
* Σ — finalize policy install

IR:

```text
Ψ(define policy)
Σ(install into PSet)
```

---

#### 11.2.10 Summary: PMSL → Operator-Typed IR Pipeline

Every construct yields a well-typed sequence of operators:

```text
AST node
    ↓ annotated by @OpTag or inferred tag
IR node
    ↓ expanded into primitive PMS ops (Δ…Ψ)
PMS Instruction Sequence
```

This guarantees:

* correct dependency structure (0.3 monoid)
* operator-complete semantics
* direct mapping to PMS-CPU ISA (2.2)
* compatibility with kernel policy engine (3.6)

---

### 11.3 Type System (frames, roles, policies, processes)

The PMSL type system is structural: types are not descriptions of data “shapes” alone, but operator-validity constraints over frames (□), roles (Ω), policies (Ψ), and process loci (Χ).
A PMSL type is therefore a multi-component contract that determines:

* what Δ/∇/Θ/Φ/Σ operations are admissible
* in which frame (□) they are evaluated
* under which role (Ω)
* under which policy set (Ψ)
* inside which execution locus/process (Χ)

In other words:

> A PMSL type is a structural admissibility profile for operator sequences.

This is fundamentally different from classical languages (which type-check values).
PMSL types ensure operator validity, context invariants, and safe transitions.

---

#### 11.3.1 Type System Overview

The PMSL type system consists of four orthogonal but interacting kind-level categories:

1. Frame Types (□-types)
2. Role Types (Ω-types)
3. Policy Types (Ψ-types)
4. Process Types (Χ-types)

Additionally, PMSL still supports:

5. Data Types (primitive + structured) — but even these are expressed with Δ-based distinction operators and Σ-based integration.

All types ultimately reduce to constraints over operator-typed transitions.

---

#### 11.3.2 Frame Types (□)

A Frame Type describes:

* the contextual domain in which a value, computation, or module is valid
* the operator constraints tied to that context (for example, allowed ∇ writes, allowed Φ migrations)

Formally:

```text
FrameType F := {
    allowed_ops: O_subset,
    subframes:   Set<FrameType>,
    visibility:  SymbolMap,
    lifetime:    LifetimeSpec
}
```

##### Structural Semantics

* □ introduces a new frame instance of some `FrameType`.
* The `FrameType` determines which Δ/∇/Θ/Φ/Σ transitions are admissible inside it.

Examples of frame types:

| FrameType          | Structural Meaning                                      |
| ------------------ | ------------------------------------------------------- |
| `LexicalFrame`     | standard scope; ∇ allowed on `var`; Σ flushes bindings  |
| `ModuleFrame`      | named □ frame with export Σ; Ψ attaches module policies |
| `TransactionFrame` | Σ = commit; Φ = rollback; ∇ constrained until commit    |
| `IsolatedFrame`    | used inside Χ (sandbox); restricted ∇/Φ/Ω               |

Frame subtyping:

```text
F1 ≤ F2   iff   allowed_ops(F1) ⊆ allowed_ops(F2)
```

This is a structural inclusion relation.

---

#### 11.3.3 Role Types (Ω)

A Role Type (Ω-type) characterizes capability sets and operator permissions.

```text
RoleType R := {
    capabilities: Set<Capability>,
    allowed_ops:  O_subset,
    escalation:   Set<RoleType>,
    downgrades:   Set<RoleType>
}
```

* Capabilities correspond to structural acts (mutate FS, open socket, spawn process).
* `RoleType` is attached as the `r` component of the machine state.
* Ω transitions (role changes) are type-checked against this structure.

##### Role Subtyping (Capabilities)

```text
R1 ≤ R2   iff   capabilities(R1) ⊆ capabilities(R2)
```

##### Protected Operators

Certain ops require Ω authorization:

* ∇ on privileged memory
* □ frame creation for kernel-level modules
* Χ spawning
* Φ exception-privileged reframing

This yields operator-safety typing:

> A term is well-typed under role R if all operators in its PMSL-expanded sequence are allowed under R.

---

#### 11.3.4 Policy Types (Ψ)

A Policy Type is the type-level encoding of a Ψ invariant, i.e. a rule constraining operator sequences.

```text
PolicyType P := {
    invariants:         Set<Invariant>,
    scope:              FrameType or Module,
    enforcement_points: Set<Op ∈ O>
}
```

Policies do not classify values — they classify trajectories.

##### Policy Subtyping

A policy `P1` is a subtype of `P2` iff:

```text
invariants(P1) ⊇ invariants(P2)
```

(i.e. stronger policies are “subtypes”)

##### Policy Composition

The Σ operator defines policy merge:

```text
P_combined = Σ(P1, P2)
```

Ψ instructions in IR enforce these at compile time and at runtime.

Example policy types:

| PolicyType      | Enforced Invariants             |
| --------------- | ------------------------------- |
| `SafeFS`        | path must start with `/home`    |
| `NoNetwork`     | forbid Δ/∇ on socket ops        |
| `ReadOnlyFrame` | forbid ∇ except on local stack  |
| `SecureModule`  | forbid Φ out of module boundary |

Policies rewrite type-checking constraints on permitted Δ/∇/Φ/Χ transitions.

---

#### 11.3.5 Process Types (Χ)

A Process Type describes the isolation boundary:

```text
ProcessType Proc := {
    isolation_level:  IsoLevel,
    allowed_syscalls: Set<Syscall>,
    namespace:        FrameType,
    scheduler_class:  SchedType
}
```

* Χ creates a new process.
* `ProcessType` determines which kernel ops are admissible.
* Χ-type subtyping relates to containment levels:

```text
Proc_sandbox ≤ Proc_user ≤ Proc_system
```

Operator restrictions follow:

* sandbox → restricted ∇, Φ, no raw FS access
* user → normal privileges
* system → broad but policy-bound privileges

---

#### 11.3.6 Data Types (Δ-derived)

Even simple data types arise structurally from Δ distinctions.

Primitive examples:

```text
Bool   := Δ{true, false}
Int    := Δ ℤ
String := Δ* over character alphabet
```

Composite types are Σ integrations:

```text
Tuple<T1, T2>  := Σ(T1, T2)
List<T>        := Α(pattern using Σ + Θ)
Option<T>      := Δ{none: Λ, some: T}
Result<T, E>   := Δ{ok: T, err: E via Φ}
```

This yields a uniform structural foundation:

* sum types = Δ
* product types = Σ
* sequential types = Θ
* error types = Φ + Λ
* patterned types = Α
* isolated/linear types = Χ

---

#### 11.3.7 Putting It All Together: Typed Judgement Form

We define the typing judgment in PMSL as:

##### Expression Typing

```text
Γ ⊢ e : T   under (F : FrameType, R : RoleType, P : PolicyType, Proc : ProcessType)
```

with Γ = binding environment (Δ/Σ-constructed).

Meaning:

> Expression `e` is valid if all operator sequences produced by `e` are admissible under the quadruple `(F, R, P, Proc)`.

---

#### 11.3.8 Type Soundness (Structural)

Two key theorems:

##### Preservation

If:

```text
Γ ⊢ e : T
(s, e) → (s', e')
```

then:

```text
Γ ⊢ e' : T
```

because transitions respect Ω/Ψ constraints and remain within allowed ops of `FrameType` and `ProcessType`.

##### Progress

If:

```text
Γ ⊢ e : T
```

then `e` is either:

* a value (Σ-complete), or
* a PMSL form where some Δ/∇/Θ/... rule applies, unless blocked by a Ψ policy (in which case the runtime halts legally).

---

#### 11.3.9 Example: Fully Typed Fragment

Consider:

```pmsl
module M {
    policy SafeFS;
    fn write_home(path: String, data: String) {
        let p = path;
        var f = open(p);   // requires Ω(FS.write)
        write(f, data);    // ∇ on FS
    }
}
```

Typing:

1. Module frame:

   ```text
   □ : ModuleFrame
   Ψ(SafeFS)
   ```

2. Function frame:

   ```text
   □ : LexicalFrame
   R : UserRole with capability FS.write
   ```

3. `open`
   Requires Ψ(SafeFS) satisfaction → `path ∈ /home`.

4. `write`
   Requires ∇ permission under `RoleType`.

Thus type-checking ensures:

* no ∇ outside allowed directories
* no write without capability
* frame boundaries respected

All ensured structurally by the type system.

---

#### 11.3.10 Summary

PMSL’s type system is:

* frame-centric (□)
* role-capability-centric (Ω)
* policy-centric (Ψ)
* process/isolation-centric (Χ)
* operator-validity-centric (Δ…Ψ)

It ensures that all programs translate into PMS operator sequences that are:

* structurally valid
* privilege-correct
* policy-compliant
* context-consistent

---

### 11.4 Concurrency & IPC in PMSL

*(Δ–Ψ–structured concurrency, process calculus, message semantics)*

PMSL concurrency is not bolted on — it is the direct programming-level projection of the PMS concurrency substrate defined in:

* PMS-CPU: isolation (Χ), time/order (Θ), non-events (Λ), traps (Φ)
* Kernel: process model, scheduling (Θ), IPC semantics (5.x)
* Type system: process types (Χ), roles (Ω), policies (Ψ) (11.3)

In PMSL, concurrent constructs expand into operator-valid sequences that preserve all these invariants.

This section defines:

1. Concurrency Model
2. Thread / Process Creation (Χ + Θ)
3. Synchronization Constructs (Ω/Θ/Σ)
4. Message Passing Primitives (Δ, Ω, Λ, Θ, Φ)
5. Channel Types & Protocol Enforcement
6. Dispatch & Event Handling

---

#### 11.4.1 Concurrency Model — Actors + Structured Threads

PMSL supports two complementary concurrency layers:

##### A. Structured Threads (χ-local execution loci)

A thread is a fresh execution locus obtained via Χ:

```pmsl
spawn { expr }
```

Expands to:

```text
Χ_fork(ctx)
Θ_start(ctx)
evaluate(expr in ctx)
```

Thread types are governed by ProcessType (11.3), which determines:

* permitted syscalls
* isolation level
* scheduler class
* allowed IPC patterns

##### B. Actor-Like Message Endpoints (Δ-typed channels)

Actors are simply objects with attached message queues (5.1), typed as:

```pmsl
actor A : Channel<T> { ... }
```

Messages follow PMS structural semantics:

* Δ classifies message kind
* Ω checks sender’s role/capability
* Λ covers timeouts / absence
* Θ orders events
* Φ handles error paths / recontextualization
* Σ integrates message into recipient state

The PMS actor model is therefore a strict subset of PMSL concurrency, not a separate paradigm.

---

#### 11.4.2 Thread / Process Creation (Χ + Θ)

##### Syntax

```pmsl
let tid = spawn expr;
```

##### Typing

If:

```text
Γ ⊢ expr : T   under ProcessType P_child
```

and the parent process has permission to spawn `P_child` (Ω + Ψ), then:

```text
Γ ⊢ spawn expr : ThreadId
```

##### Operator Expansion

```text
Χ_fork(P_child)          ; create isolated frame + role + namespace
Θ_init(P_child)          ; establish ordering anchor for scheduler
Δ_thread_id              ; distinguish ID
∇_enqueue_run(expr)      ; schedule work
```

The new thread enters the kernel run queue via Θ.

##### Join / Await

```pmsl
join tid
```

Expands to:

```text
WAIT until (Θ-ordered event marks tid.status == finished)
Λ on timeout (if specified)
Σ integrate tid result
```

---

#### 11.4.3 Synchronization Constructs (Ω/Θ/Σ)

PMSL offers high-level synchronization, all compiled to PMS operators.

##### Mutexes (Ω + Θ)

```pmsl
mutex m;

m.lock();
m.unlock();
```

Expand to:

```text
Ω_acquire(m.cap)         ; capability check
Θ_wait_queue(m)          ; scheduler-ordered wait
Λ (timeout) optional
Σ_grant_lock(m)          ; commit ownership
```

Release:

```text
Ω_release
Σ_unlock
Θ_notify(waiters)
```

##### Semaphores

```pmsl
sem.wait();
sem.post();
```

Expand into:

```text
Δ(count)                 ; test
Θ_block_or_unblock
Σ_update_count
```

##### Condition Variables

```pmsl
cond.wait(m);
cond.notify();
```

Map to kernel event queues:

```text
Θ_sleep
Λ_timeout
Φ_wake(recontextualize into runnable)
```

All synchronization constructs respect:

* process role (Ω)
* isolation boundary (Χ)
* scheduling policy (Θ)
* active policy set (Ψ)

---

#### 11.4.4 Message Passing (Δ, Ω, Λ, Θ, Φ)

Message passing is first-class in PMSL, typed through `Channel<T>` and `Mailbox<T>`.

##### Channel creation

```text
let c = channel<T>();
```

Expands to:

```text
Δ(T)                     ; message type distinction
Χ_create_mailbox         ; isolated queue
Σ_register_object        ; commit channel object
```

---

##### Sending messages

```text
send c msg
```

Operator-level sequence:

1. Δ_msg — classify message (variant/tag/type T)
2. Ω_check — ensure sender has rights to post to `c`
3. ∇_enqueue — insert message into mailbox
4. Θ_signal — notify receiver
5. Σ_post — finalize enqueue

Error paths:

* Λ_timeout if channel is full (bounded channels)
* Φ_reframe if message is incompatible with receiver policy or type

---

##### Receiving

```text
let m = recv c;
```

Operator expansion:

1. Θ_wait — wait for message arrival in scheduler order
2. Λ_no_event — handle timeout or non-blocking failure
3. Δ_unwrap — decode message tag
4. Σ_dequeue — commit removal from mailbox

This is a structural dual of send.

---

#### 11.4.5 Channel Types & Protocol Enforcement

Channels may include protocol specifications (PPS, section 7.3):

```text
channel<P_REQ or P_EVT or P_CTRL>
```

PMSL treats protocol types as Σ-integrated state machines, where each send/recv must conform to allowed transitions:

```text
StateMachineType Protocol :=
    { states, transitions : Δ × Σ × Θ → state }
```

Type-checking ensures:

* illegal message sequences = compilation error
* incomplete handling = warning or error
* missing timeout handling = policy violation under Ψ

Higher-level syntax:

```pmsl
protocol MyProto {
    state Init {
        on Req -> Waiting;
    }
    state Waiting {
        on Resp -> Done;
        on Timeout -> Init;
    }
}
```

PMSL will expand this into Δ/Θ/Λ/Σ operators rigorously.

---

#### 11.4.6 Events & Dispatch (Φ + Θ)

PMSL programs may define event handlers:

```pmsl
on event X from source Y { ... }
```

Compilation:

1. Δ_event — classify incoming event
2. Ω_check_source — ensure handler has authority
3. Φ_enter_handler — switch into handler frame/context
4. Θ_order — record event order in execution sequence (τ may hold timestamps)
5. ∇_exec — perform handler code
6. Σ_exit_handler — commit state changes

Event loops:

```pmsl
loop {
    wait event e;
    handle e;
}
```

Expands to:

```text
Θ_cycle  
Λ no-event  
Δ classify  
Φ dispatch  
Σ integrate  
```

This forms the core of actor-style reactive programs.

---

#### 11.4.7 Structured Concurrency (Α patterns + Θ sequences)

PMSL supports structured concurrency patterns:

```pmsl
async let x = f1();
async let y = f2();
await x + y;
```

Pattern Α expands into:

```text
Χ_spawn f1
Χ_spawn f2
Θ_schedule
WAIT both finished
Σ_join results
```

All expansions remain PMS-valid sequences.

---

#### 11.4.8 Summary

PMSL concurrency is structurally guaranteed by PMS operators:

| PMS Operator | Concurrency Role                               |
| ------------ | ---------------------------------------------- |
| Δ            | message/type distinction, event classification |
| ∇            | enqueue/dequeue, state updates                 |
| □            | per-thread frame contexts                      |
| Λ            | timeouts, non-blocking receive                 |
| Α            | structured concurrency patterns                |
| Ω            | capability checks for send/recv/spawn          |
| Θ            | scheduling, ordering, blocking/wake-up         |
| Φ            | traps, exceptions, event dispatch              |
| Χ            | thread/process creation & isolation            |
| Σ            | integration (message commit, join)             |
| Ψ            | safety policies governing IPC & concurrency    |

PMSL concurrency is thus formally grounded, not ad-hoc.

---

### 11.5 Error & Exception Handling (Φ / Λ)

*(Recontextualization & Non-Event Semantics in PMSL)*

PMSL error handling is not an afterthought layered atop the runtime — it is a direct projection of the PMS Φ/Λ operator semantics:

* Φ — Recontextualization:
  errors trigger context shifts, handler entry, fallback frames, ABI/role changes, or recovery paths.

* Λ — Non-Event:
  missing results, timeouts, absent responses, and cancelled waits are *first-class semantic events*, not special return codes.

This enables a fully structural error model, suitable for OS kernels, distributed protocols, actors, and transactional subsystems.

---

#### 11.5.1 Error Value vs. Error Context (Δ / Φ)

PMSL distinguishes two categories:

##### A. Value-Level Errors (Δ)

Errors that behave like ordinary values, for example:

```pmsl
let result = try f(x);
```

If `f(x)` returns `Err e`, PMSL interprets it via:

* Δ_e — classify error variant
* branch into local handler or propagate

These use Δ only; no context shift occurs yet.

##### B. Context-Level Errors (Φ)

Errors that modify the execution context:

* exceptions
* traps
* ABI reframe
* policy violations
* type mismatch requiring migration
* privilege switch errors

These are true Φ operations: `Φ_raise`, `Φ_enter_handler`, `Φ_restore`.

Thus PMSL supports:

* recoverable value errors (Δ)
* context errors (Φ)

with clean separation.

---

#### 11.5.2 Exception Syntax

##### Raising exceptions

```pmsl
raise err;
```

Expands to:

```text
Δ(err)                 ; classify error
Φ_raise(err)           ; shift context
Θ_branch(handler)      ; schedule handler entry
```

##### Handling exceptions

```pmsl
try {
    expr
} catch (E1 e) {
    handler1
} catch (E2 e) {
    handler2
}
```

Expands to:

1. push handler table into meta-state (`Φ_set_handler_table`)
2. evaluate `expr`
3. if Φ occurs, use Δ to dispatch based on error type
4. jump into handler frame

---

#### 11.5.3 Exception Type System

Errors are typed via PMSL’s sum types:

```pmsl
type IOError =
    | NotFound
    | Permission
    | Timeout
    | DeviceFault(code)

type Result<T> =
    | Ok T
    | Err IOError
```

Type rules:

If `expr : Result<T>`, then:

```pmsl
try expr : T
```

provided all error variants are handled or declared.

This is enforced via Δ completeness checking:

* unhandled variants → compile error
* conditional handler missing fallback → warning or Ψ policy error

---

#### 11.5.4 Recontextualization Semantics (Φ)

Errors that cannot be treated as local values initiate Φ recontextualization:

##### Examples of Φ paths:

1. Privilege escalation errors
   → fallback into kernel handler frame

2. ABI mismatch
   → shift to compatibility frame (`Φ_reframe ABI_v1 → ABI_v2`)

3. Isolation boundary violation
   → `Φ_trap` into sandbox supervisor

4. Process-level faults
   → `Φ_kill` or `Φ_restart` under policy Ψ

###### Formal expansion:

```text
Φ_enter_handler(ctx)
□_switch_frame(handler_frame)
Ω_set_role(handler_role)
Θ_mark_handler_entry
```

Handler execution is just evaluation inside the handler frame until:

* Φ_restore returns to caller context, or
* Σ_commit finalizes a recovery transformation.

---

#### 11.5.5 Non-Event Semantics (Λ)

Λ captures absence rather than malfunction:

```pmsl
let msg = recv c timeout 100ms;
```

Expansion:

1. `Θ_wait(c, deadline_ref)`       ; scheduler-ordered wait, `deadline_ref` stored in τ
2. if message arrives → `Δ_classify` → `Σ_dequeue`
3. if not → Λ_timeout(c)

Λ values can be:

```text
None
Timeout
Cancelled
Empty
```

Λ handlers are allowed:

```pmsl
on timeout { ... }
```

Λ never mutates core state; it updates only:

* meta-state (`m.timeout_count += 1`)
* control flow (`branch label`)

---

#### 11.5.6 Combined Error Model: Δ + Λ + Φ

PMSL integrates all error modes:

##### Δ-value error

*Local branching*
Use for ordinary recoverable failures (parsing, file-not-found, and so on).

##### Λ non-event

*Absence of expected event*
Networking, IPC, scheduling, I/O, timers.

##### Φ context error

*Structural reframe*
Exceptions, traps, policy enforcement, ABI shifts.

A PMSL function can declare which modes it uses:

```pmsl
fn f(x:Int) throws (E_IO, E_Parse) yields ΛTimeout -> Int
```

Meaning:

* may raise Φ exceptions of types `E_IO`, `E_Parse`
* may return ΛTimeout as a valid value
* otherwise returns an `Int`

This integrates directly with the type system (11.3).

---

#### 11.5.7 Try/Else/Finally (Σ integration)

PMSL supports structured cleanup via Σ:

```pmsl
try {
    expr
} else {
    alternative
} finally {
    cleanup
}
```

Operator expansion:

1. try-block
2. on error → `Φ_enter_handler`
3. else-block (only if no Φ/Δ error taken)
4. finally-block is Σ_final:

```text
Σ_enter_cleanup
evaluate cleanup
Σ_exit_cleanup
```

Σ ensures cleanup effects are committed even in the presence of Φ/Λ.

---

#### 11.5.8 Default Runtime Handlers (Ψ policies)

Policies can require:

* catch-all handlers
* mandatory timeout handling
* restricted exception types
* recovery or restart decisions

Example Ψ rule:

```text
Ψ: every process must handle Timeout or be terminated.
```

Runtime check:

```text
CHK_POL TimeoutHandling
Φ_trap_unhandled if violated
```

Another example:

```text
Ψ: forbids raw exception rethrow across isolation boundary.
```

Φ enforcement:

```text
if boundary_violation:
    Φ_redirect to boundary handler
```

---

#### 11.5.9 Exception Handling & IPC

Cross-process exceptions propagate as structured messages:

```pmsl
raise RemoteFault("device failed")
```

is encoded as:

* send P-EVT fault packet
* remote `Φ_enter_handler`
* optional return value (Σ)

Timeouts (Λ) also propagate as structural events.

---

#### 11.5.10 Summary Table

| PMS Operator | Error-Model Role                                  |
| ------------ | ------------------------------------------------- |
| Δ        | classify error value; local branching             |
| Λ        | non-event (timeout, missing input)                |
| Φ        | exception, trap, context shift                    |
| Ω        | check authority for handlers                      |
| Θ        | control wait sequencing (around τ-based timeouts) |
| Χ        | per-thread handler contexts                       |
| Σ        | cleanup, commit recovery                          |
| Ψ        | global error-handling policies                    |

PMSL’s error system is therefore structurally complete, guaranteed to be consistent with the universal PMS semantics.

---

### 11.6 Module System

*(PMSL structural modularity via □, Ω, Ψ, Χ, Σ)*

In PMSL, a module is not merely a namespace—it is a PMS-structured computational region, defined as a triple:

```text
Module = (Frame, RoleSet, PolicySet)
```

This directly reflects PMS operator semantics:

* □ — Frame
  A module is a frame: a context with its own symbol table, memory region, type environment, and import/export scope.

* Ω — Roles / Capabilities
  Each module is executed under a module role, defining what its code may access or do.

* Ψ — Policies / Invariants
  Each module can declare invariants enforced on all code inside the module frame.

* Χ — Isolation
  Modules may run in isolated subcontexts (for example, separate processes, sandboxes, capsules).

* Σ — Integration
  Module linking, finalization, interface commitments.

This gives PMSL modularity a rigorous praxeological foundation—modules are embedded directly into the operator algebra.

---

#### 11.6.1 Module Declaration Syntax

##### Basic form

```pmsl
module M {
    export fn f(x:Int) -> Int { ... }
    let internal_data = ...
    import N { g }
}
```

Semantically expands to:

```text
□_enter(M.frame)
Ω_set_role(M.role)
Ψ_activate(M.policies)
Σ_register_exports
```

##### Extended form with explicit structural constraints

```pmsl
module M : ModuleType {
    requires role UserSpace;
    requires policy SafeFS;

    provides interface I {
        fn f(x:Int) -> Int;
    }
}
```

All of these clauses resolve to Ω and Ψ instructions at compile time and to frame-changing □ instructions at runtime.

---

#### 11.6.2 Modules as Frames (□)

Every module defines a lexical and execution frame:

```text
M.frame = {
    symbols:       {types, functions, values},
    memory_region: {base, size},
    imports:       set of (module, symbols),
    exports:       set of symbols,
}
```

Entering module scope during evaluation is:

```text
□_switch_frame(M.frame)
```

This provides:

* symbol resolution
* address space for module-local data
* scoping of capabilities and policies

Nested modules create a frame stack encoded in meta-state `m`.

---

#### 11.6.3 Role Assignment to Modules (Ω)

Each module has an assigned role:

```text
M.role : Role
```

Common examples:

* `UserSpace`
* `KernelSpace`
* `Driver`
* `TrustedModule`
* `SandboxedModule`
* `NetProtocolModule`

Role semantics:

* determine which PMSL constructs can be used
* control access to system calls
* allow or forbid memory operations
* govern imports/exports
* enforce least-privilege by default

Entering a module applies:

```text
Ω_set_role(M.role)
```

The type checker ensures:

* exported symbols obey role constraints
* imported modules’ roles are compatible
* callers meet required role expectations

---

#### 11.6.4 Module Policies (Ψ)

Modules attach policies that constrain internal operations:

```text
M.policies : PolicySet
```

Policies can specify:

##### Safety constraints

* memory safety rules
* forbidden syscalls
* required handler coverage
* invariants over stored data

##### Security requirements

* encryption required on channels
* all exports must be capability-checked
* only certain roles may call module functions

##### Lifecycle invariants

* module requires Σ-finalization of state
* module must not leak resources
* version compatibility constraints

Entering module:

```text
Ψ_apply(M.policies)
```

Violations cause Φ traps or forced halts (`Ψ_enforce`).

---

#### 11.6.5 Module Isolation (Χ)

Modules may be declared isolated, spawning subcontexts:

```pmsl
module M isolated { ... }
```

This expands to:

```text
Χ_enter_isolation(M.ctx)
□_switch_frame(M.frame)
Ω_set_role(M.role)
Ψ_apply(M.policies)
```

Isolation properties:

* no direct pointer sharing
* IPC-only communication
* controlled resource access
* can run in separate processes or sandboxes
* can enforce deterministic execution

Cross-isolation calls require message passing or capability tokens.

---

#### 11.6.6 Module Linking & Import/Export (Δ + Σ)

##### Import resolution (compile-time)

```pmsl
import N { a, b, c }
```

Compile-time process:

1. Δ_resolve(N) — distinguish module identity
2. verify exported symbols
3. check role and policy compatibility
4. generate integration thunk

##### Export registration (runtime commit)

When a module is loaded:

```text
Σ_register_exports(M.exports)
```

This operation finalizes:

* symbol table consistency
* type signatures
* role/policy annotations
* version bindings

##### Dynamic linking (Φ + Σ)

If module loading occurs at runtime:

```pmsl
load_module("NetStack")
```

Expands to:

```text
Φ_load_frame
Ω_check_privilege
Ψ_apply_policies
Σ_link_exports
```

Errors (bad ABI, incompatible policy, version mismatch) cause Φ_reframe.

---

#### 11.6.7 Module Versioning & Reframing (Φ)

Version changes are performed via Φ:

```pmsl
reframe M to Version2
```

Equivalent to:

```text
Φ_recontextualize(M.old_frame → M.new_frame)
Ψ_reverify_policies
```

Used for:

* live upgrades
* compatibility layers
* ABI migrations
* hot-swapping subsystems

Φ ensures backward-compatibility logic is explicit and typed.

---

#### 11.6.8 Module Capabilities (Ω)

Modules may require or define capabilities:

```pmsl
module FS {
    capability write_file;
}
```

Callers must hold the capability:

```pmsl
require cap write_file;
```

At call time:

```text
Ω_check(cap)
Δ_branch if unauthorized
```

Capabilities may be:

* value-level tokens
* structural module properties
* policy-enforced invariants

---

#### 11.6.9 Module Lifecycle (Θ + Σ)

Each module has a lifecycle aligned with PMS ordering and integration operators.

##### Initialization

```text
Θ_on_load
Σ_commit_init_state
```

##### Active state

Operations run under the module’s frame, role, and policies.

##### Finalization

```text
Θ_before_unload
Σ_finalize_resources
```

##### Optional persistence

Some modules maintain persistent state committed via Σ:

```text
Σ_persist(module_state)
```

This is used in:

* storage subsystems
* network protocols
* configuration modules

---

#### 11.6.10 Types of Modules

We classify modules by structural composition (not by purpose):

| Module Type              | Description                                         |
| ------------------------ | --------------------------------------------------- |
| Pure Module          | only □, Δ, ∇ ops; no I/O, no roles                  |
| Isolated Module      | uses Χ; boundaries enforced                         |
| Privileged Module    | Ω grants extended syscalls; must satisfy Ψ policies |
| Protocol Module      | exports PPS-typed channels (7.3)                    |
| Transactional Module | uses Σ heavily; supports atomic state               |
| Reframe Module       | provides Φ-based version shifts                     |
| Resource Module      | manages memory, storage, IPC objects                |

These are not semantic categories—they express operator-level structure.

---

#### 11.6.11 Module-to-Module Interaction via IPC

A module call across isolation boundaries becomes:

```pmsl
send M_inbox Request(params)
recv response
```

With structural decomposition:

1. Δ classify request
2. Ω check caller capability
3. Χ enforce boundary
4. Φ dispatch into callee frame
5. ∇ execute
6. Σ return

This reproduces safe cross-module interaction automatically.

---

#### 11.6.12 Summary

PMSL modules are not files or namespaces—they are structured PMS entities, combining:

| PMS Operator | Module Semantics                                |
| ------------ | ----------------------------------------------- |
| □        | module frame, lexical & execution context       |
| Ω        | module role, capability requirements            |
| Ψ        | policy constraints & invariants                 |
| Χ        | isolation of module context                     |
| Φ        | dynamic loading, reframing, error handling      |
| Σ        | linking, export commit, init/finalize           |
| Θ        | lifecycle ordering hooks for load/unload        |
| Δ        | symbol resolution, import/export classification |

This yields a modular system that is:

* safe by construction (Ψ + Ω + Χ)
* explicitly structured (□ frames)
* dynamically adaptable (Φ reframing)
* transactionally consistent (Σ)

PMSL modules are therefore the canonical unit of composition in the PMS architecture.

---

### 11.7 FFI / Interoperability (calls into non-PMS code / host OS)

*(Structured external interoperability via Ω, □, Φ, Χ, Ψ)*

The PMS architecture treats interoperability not as an escape hatch but as a first-class operator-typed mechanism.
FFI is modeled as controlled entry into foreign frames with explicit:

* □ — frame switching into foreign environments
* Ω — capability gating for safety
* Φ — recontextualization across ABI, type, and semantic boundaries
* Χ — isolation between PMS memory and foreign memory
* Σ — integration of returned values
* Ψ — policies constraining which foreign calls are allowed

This makes FFI a formal subsystem, not an ad-hoc feature.

---

#### 11.7.1 Foreign Frame Model (□_foreign)

Any external environment is treated as a frame:

```text
ForeignFrame {
    abi_type: C | POSIX | WASI | JVM | custom
    call_gate: entry point
    memory_access: allowed / isolated / shared
    calling_convention: specification
}
```

Switching into a foreign context is done via an explicit operator:

```text
□_enter(ForeignFrame)
```

This corresponds to:

* establishing ABI conventions,
* switching register/stack discipline (PMS-CPU),
* aligning type encodings.

Returning from the FFI call is:

```text
□_exit(ForeignFrame)
```

Foreign frames are therefore typed contexts, not arbitrary jumps into native code.

---

#### 11.7.2 FFI Call Semantics in PMSL

General PMSL syntax:

```pmsl
foreign fn c_sin(x:Float) -> Float;
...
let y = c_sin(1.0);
```

Expands to the operator-level sequence:

1. Δ — resolve foreign symbol
2. Ω_check — verify FFI capability
3. Χ_isolate — isolate PMS memory region if required
4. Φ_reframe — convert PMS types → foreign ABI types
5. □_enter — switch to foreign frame
6. ∇_call — perform actual native call
7. Σ_integrate — convert result back into PMS form
8. □_exit — return to PMS frame

This makes FFI part of the *normal operational algebra* of PMS interpretation.

---

#### 11.7.3 Capability Gating (Ω)

Foreign interaction is *never* allowed by default.
Modules must declare capabilities:

```pmsl
requires capability FFI_Calls;
requires capability HostFS;
```

At call time:

```text
Ω_check(FFI_Calls)
```

If the role lacks the capability:

```text
Δ ⇒ unauthorized
Ψ_enforce ⇒ deny or trap
```

This protects:

* kernel-level transitions
* system resources
* unsafe pointer operations
* filesystem/network access through foreign code

Ω turns FFI into an auditably safe boundary.

---

#### 11.7.4 Memory Interaction & Isolation (Χ)

Because foreign code may expect raw pointers, the PMS runtime mediates memory access through isolation boundaries.

##### Three modes:

###### (a) Fully Isolated

PMS object graph is translated into foreign memory buffers:

```text
Χ_copy_to_foreign
∇_call
Χ_copy_to_pms
```

Used for:

* C library calls
* host OS syscalls
* WASI modules
* safe default mode

###### (b) Shared but Restricted

Only explicitly marked buffers are shared:

```pmsl
buffer shared(pms_buf) with foreign
```

Χ ensures:

* no foreign code can access unshared regions
* linear or borrow-style aliasing rules can be enforced

###### (c) Unsafe Raw Access (needs Ω_superuser)

Available only to privileged modules:

```pmsl
unsafe foreign fn do_raw(ptr: *mut u8);
```

Requires:

```text
Ω_check(SuperFFI)
Ψ_enforce(strict auditing)
```

This prevents accidental system compromise.

---

#### 11.7.5 Foreign ABI Reframing (Φ)

Crossing a language or OS boundary is always a recontextualization event:

```text
Φ(PMS_type → ABI_type)
Φ(exception_model → error_code_model)
Φ(memory_model → foreign_allocation_model)
```

Examples:

* PMS `Int` → C `int64_t`
* PMS exceptions → errno or return codes
* PMS structured errors → POSIX error types
* PMS-owned memory → malloc'ed buffers

Likewise on return:

```text
Φ(ABI_results → PMS_values)
```

If something fails during reframing:

```text
Φ_recover
Ψ_policy_enforce
```

Example: invalid encoding, truncated string, mismatched layout → converted into PMS exception with Φ.

---

#### 11.7.6 Foreign Error Handling (Λ, Φ)

Foreign calls can produce non-events (Λ) or errors requiring reframing (Φ).

##### Λ: Non-Event in FFI

Examples:

* a non-blocking POSIX read returns EAGAIN
* a socket call returns “no data yet”
* optional pointer returns NULL

Runtime treats this as:

```text
Λ_foreign_non_event
Δ classify
branch -> fallback / retry / await
```

##### Φ: Foreign Exception or Error

Errors are reframed into PMS exception structures:

```text
Φ_map_errno
Φ_map_java_exception
Φ_map_wasm_trap
```

Then raised in PMSL’s error model (11.5).

---

#### 11.7.7 Asynchronous Foreign Calls (Θ + Δ + Λ)

Asynchronous host operations (I/O, timers, futures, GPU calls) integrate naturally:

1. Submit request
2. Θ schedules continuation in the PMS ordering of events
3. Λ signals timeout or no-event
4. Φ reframe completion or errors
5. Σ commit result

PMSL syntax:

```pmsl
let r = await foreign async read(fd, buf);
```

Desugars into:

```text
∇ submit_request
Θ schedule
Λ or Φ depending on readiness
Σ integrate result
```

---

#### 11.7.8 Host OS Interoperability Layer

The host OS is modeled as a super-frame:

```text
HostFrame {
    abi: POSIX | NT | WASI | native,
    capabilities: {open, read, write, ioctl, mmap, ...},
    policies: host-defined constraints
}
```

Syscalls in PMSL are just FFI calls to this frame:

```pmsl
foreign sys open(path:String, flags:Int) -> FD;
```

Enforced by:

* Ω_host_role
* Ψ_host_policy
* Χ isolation (esp. for mmap)
* Φ conversion of errno
* Σ commit as PMSL file handle

This makes “syscalls” structurally identical to any FFI call—just more privileged.

---

#### 11.7.9 PMSL → Native Code Calling Convention

The compiler generates a well-defined calling wrapper:

```text
call_wrapper(M.frame, target_symbol, args...) = {
    □_enter(ForeignFrame)
    Ω_check
    Χ_setup_buffers
    Φ_prepare_abi
    ∇ call target_symbol
    Φ_wrap_return
    Σ_commit
    □_exit(ForeignFrame)
}
```

The wrapper ensures:

* no raw escape of PMS pointers
* all cross-boundary semantics are explicit
* policies are verified
* lifetimes and cleanup occur correctly

---

#### 11.7.10 Example: Calling a C Function

##### PMSL code:

```pmsl
foreign fn strlen(s: &Byte) -> Int;

fn demo() {
    let buf = "hello".as_bytes();
    let n = strlen(buf);
}
```

###### Operator-level expansion:

```text
Δ_resolve(strlen)
Ω_check(FFI_Calls)
Χ_share(buf)
Φ_encode_pointer
□_enter(C_ABI)
∇_call(strlen)
Φ_decode_int
Σ_integrate_result
□_exit
```

Everything is explicit and enforced by the operator constraints.

---

#### 11.7.11 Example: Calling Host Filesystem API

```pmsl
foreign sys read(fd:FD, buf:&mut Byte, n:Int) -> Int;
```

Call sequence:

1. Δ resolve `read`
2. Ω check `HostFS_Read` capability
3. Χ share/mmap or isolate buffer
4. Φ convert parameters to host layout
5. □ enter HostFrame
6. ∇ perform syscall
7. Λ_or_Φ handle errno / readiness
8. Σ finalize buffer state
9. □ exit

---

#### 11.7.12 Summary

PMSL FFI is a structured combination of PMS operators:

| PMS Operator | FFI Meaning                                    |
| ------------ | ---------------------------------------------- |
| □        | Switch into foreign ABI frame                  |
| Ω        | Verify capability for external call            |
| Φ        | Reframe values/types/exceptions                |
| Χ        | Enforce isolation & safe memory sharing        |
| Δ        | Symbol and ABI distinction                     |
| ∇        | Perform the actual native call                 |
| Λ        | Handle no-event/partial readiness              |
| Σ        | Commit results back into PMSL                  |
| Ψ        | Apply/enforce policies on external interaction |
| Θ        | Order submission and completion of async calls |

This yields an interoperability system that is:

* safe by construction
* fully typed
* auditable and policy-controlled
* compatible with arbitrary host OS or runtime
* semantically uniform with the rest of PMS

---

## 12. PMSL Runtime & Standard Library

### 12.1 Runtime Architecture (PMSL → PMS-CPU + syscalls)

The PMSL runtime is the bridge from high-level PMSL code to the PMS-CPU + PMS-OS world:

* It compiles and loads PMSL modules into PMS-CPU code (Δ → opcodes).
* It manages process state: heaps, stacks, module frames, tasks.
* It mediates all interaction with the kernel via syscalls (Φ + Ω + Χ).
* It enforces language-level invariants as Ψ on top of the kernel’s Ψ.

We describe:

1. Runtime layering (PMSL → IR → PMS-CPU → syscalls)
2. PMSL process model vs kernel processes
3. Call/return and syscall paths
4. Memory layout and frame usage
5. Concurrency & event integration
6. Policy and safety integration

---

#### 12.1.1 Layering & Components

Conceptual stack for a single PMSL program:

```text
+------------------------------------+
| PMSL Program (modules, types, etc) |
+------------------------------------+
+------------------------------------+
| PMSL Runtime:                      |
|  - Loader & Linker                 |
|  - Scheduler shim                  |
|  - Heap/GC & Handle tables         |
|  - Exception & signal dispatcher   |
|  - Syscall wrapper layer           |
+------------------------------------+
| PMSL IR (Δ–Ψ-tagged)               |
+------------------------------------+
| PMS-CPU ISA (Δ, ∇, □, Ω, Θ, Φ, …)  |
+------------------------------------+
| PMS-OS Kernel (processes, IPC, FS) |
+------------------------------------+
| Hardware / PMS-CPU implementation  |
+------------------------------------+
```

Operator view:

* Δ – IR typing, function/module IDs, syscall numbers, handle kinds
* ∇ – execution of compiled code, heap alloc/free, field updates
* □ – module frames, activation frames, heap regions, address spaces
* Λ – timeouts, failed I/O, empty channels, missing events
* Α – runtime patterns: call sequences, common IPC flows, retry loops
* Ω – language roles: untrusted vs trusted module, capability-scoped APIs
* Θ – task scheduling hooks, ordered wakeups, cooperative yields
* Φ – exception delivery, domain boundary moves (host FFI, kernel boundary)
* Χ – module isolation, sandboxed runtimes, per-tenant heaps
* Σ – transaction-like scopes, commit of buffered I/O, GC phases
* Ψ – language invariants: type safety, ownership, API contracts

---

#### 12.1.2 PMSL Process Model vs Kernel Processes

At the kernel layer (section 3):

* A PProcess is the kernel’s unit of isolation & accounting.
* It may have multiple kernel threads (KThreads), scheduled by Θ.

The PMSL runtime runs *inside* a PProcess and defines its own lighter-weight units:

* Runtime process (RProc) – usually 1:1 with PProcess

  * Has a root module frame and global heap

* Runtime threads / tasks (RThread / Task)

  * Map to:

    * either dedicated kernel threads (1:1 or N:M),
    * or cooperative tasks multiplexed over a smaller kernel thread pool.

Mapping:

* Each RThread has:

  * call stack (□ activation frames)
  * task-local context (roles, policies, handles)
  * scheduler metadata (Θ: run state, priority, deadlines)

* Each RProc corresponds to:

  * one PMS-OS process with a virtual address space (□),
  * one or more KThreads.

This mirrors the PMS operator picture:

* OS-level Χ/□ gives the outer isolation
* Runtime-level □/Χ gives intra-process structure (modules, tasks, actors).

---

#### 12.1.3 Compilation & Execution Path (PMSL → PMS-CPU)

Compile-time pipeline (tooling + runtime loader):

1. PMSL source → PMSL AST (Δ distinctions of syntax/types)

2. AST → PMSL IR (section 11.1):

   * operator-tagged constructs (Δ..Ψ)
   * explicit control flow, frames, roles, policies

3. IR → PMS-CPU ISA:

   * function bodies compiled into ISA functions
   * call sites implemented via CALL/RET conventions (2.3)
   * syscalls inserted for kernel services (3.7)

4. Linker resolves:

   * intra-module and inter-module references
   * runtime entry points (main, init hooks)

5. Loader:

   * allocates code/data frames in the process address space
   * sets up initial module frames (□)
   * builds the Runtime context (RProc, main RThread)

Execution:

* Kernel launches the process (PProcess) via exec-style syscalls.
* PMS-CPU starts at runtime entry stub:

  * sets up initial stack frame
  * initializes runtime (heap, handle tables, sched structures)
  * calls PMSL program’s `main`/entry as a normal function.

From that point:

* PMSL code runs on PMS-CPU,
* runtime intervenes only via:

  * library calls,
  * trap/syscall wrappers,
  * exception handling,
  * GC / housekeeping.

---

#### 12.1.4 Call, Syscall, and FFI Paths

##### PMSL function call

At PMSL level:

```pmsl
fn f(x: Int, y: Int) -> Int { x + y }
```

Compilation:

* Δ – type & function distinction
* ∇ – body compiled to arithmetic ∇ + branches
* □ – new activation frame on stack at call
* Σ – implicit at return (return value commit + frame restoration)

ISA sequence (simplified):

```asm
; caller
MOV   R0, arg_x                 ; ∇
MOV   R1, arg_y                 ; ∇
CALL  f_label                   ; ∇
; result in R0

; callee prolog
PUSH  R4..R7                    ; ∇
SUBI  SP, SP, frame_size        ; ∇
; body ...
ADDI  SP, SP, frame_size        ; ∇
POP   R7..R4                    ; ∇
RET                             ; ∇ (Σ-flavored)
```

##### Syscall path (PMSL → kernel)

PMSL exposes safe APIs like:

```pmsl
fn write(fd: File, buf: &Bytes) -> Result<Int, IoError>
```

Runtime implementation:

1. Type-safe wrapper checks:

   * Ψ invariants: valid `fd`, accessible buffer, capabilities (Ω)

2. Packs raw syscall arguments into registers:

   * `R0 = syscall_number(WRITE)`
   * `R1..R3 = fd, buf_ptr, len`

3. Executes `TRAP #0` (Φ) to enter kernel (3.7).

4. Kernel executes, returns via EXC_RET (Φ).

5. Runtime maps result codes back to:

   * `Ok(n)` or `Err(IoError)`.

Operator view:

* Language call site: Δ + ∇ + □ + Σ
* Boundary crossing: Φ + Ω + Χ + Ψ
* Error mapping: Φ (recontextualization of kernel error to language exception/Result).

##### FFI path (to host libraries)

FFI functions are special frames:

* Declared in PMSL with `foreign`-style syntax.
* Bound at load-time to:

  * host OS functions,
  * or dynamically loaded libraries.

Runtime:

* Enforces Ψ constraints around FFI:

  * type checks,
  * isolation rules (Χ),
  * capability checks (Ω).

* Uses host-specific calling convention, but always through a Φ-like reframe.

---

#### 12.1.5 Memory Layout & Frames in the Runtime

Inside a PMSL process:

* Address space (□, courtesy of kernel):

  * Code frames (modules, runtime)
  * Data frames (globals, literals)
  * Heap frames (allocation arenas)
  * Stack frames (per RThread)
  * MMIO / special kernel-mapped regions

Runtime adds logical frames on top:

1. Module frames (□)

   * Each module M has a frame containing:

     * constants
     * static data
     * imports/exports

   * The PMSL module system (11.6) maps directly onto this structure.

2. Activation frames (□)

   * On each call, runtime creates a stack frame containing:

     * locals
     * saved registers
     * links to module frame

3. Heap regions

   * May be:

     * a single global heap per process
     * or multiple region frames per module or logical subsystem.

   * GC/allocator sees them as Σ domains:

     * allocation ∇
     * collection/compaction Σ

4. Isolation frames (Χ)

   * For stronger guarantees:

     * per-tenant heap/frame
     * per-plugin or untrusted module sandbox

   * The kernel’s Χ (process address spaces, VM) and the runtime’s Χ (heap/handle policies) combine.

Ψ-level invariants:

* “Pointers never cross address-space boundaries except via FFI/special channels.”
* “Handles track which heap/frame they belong to; no cross-region free.”

---

#### 12.1.6 Concurrency, Events, and the Runtime Scheduler

PMSL concurrency (11.4) exposes constructs like:

* tasks / async functions
* channels or mailboxes
* timers and signals

Runtime is responsible for mapping these to:

* kernel scheduler (Θ, section 3.4),
* kernel IPC (5.x),
* PMS-CPU primitives (WAIT, YIELD, TICK, FENCE, etc.).

Typical patterns:

1. Task spawn

   * Runtime allocates a new activation frame + task descriptor.

   * Either:

     * binds it to a kernel thread (1:1),
     * or adds it to a cooperative scheduler queue (N:M).

   * Uses Θ (`YIELD`, `TICK`) to interleave tasks.

2. Channel send/recv

   * Channel is implemented as a kernel mailbox or a shared buffer with Σ/Χ semantics.
   * PMSL send → runtime call → kernel IPC send.
   * PMSL recv:

     * waits on kernel queue or internal queue,
     * uses Λ for timeout semantics.

3. Timers and timeouts

   * Runtime requests kernel timer services (which update τ).

   * PMSL `sleep`, `timeout`, `select`:

     * map to WAIT+Λ+Φ pattern.

   * Θ orders execution relative to the timer events provided by τ.

4. Signals / events

   * Kernel delivers events (signals, I/O ready, etc.) to the PMSL runtime via:

     * signal handlers,
     * event queues,
     * or registered callbacks.

   * Runtime translates these into:

     * PMSL-level events (callbacks, async wakes),
     * Φ-based exception/notification mechanisms in PMSL (11.5).

Overall:

* The kernel provides global scheduling & isolation (Θ, Χ).
* The runtime provides intra-process scheduling & semantics (Θ, Ψ, Α patterns).

---

#### 12.1.7 Policies, Safety & Ψ Integration

There are three Ψ layers:

1. Hardware/CPU Ψ (2.x) – architectural invariants, memory permissions.
2. Kernel Ψ (3.x, 8.x) – process isolation, resource limits, security policy.
3. Runtime Ψᵣ (language level) – type safety, ownership/lifetimes, API contracts.

Runtime duties:

* Enforce Ψᵣ before crossing boundaries:

  * before syscalls,
  * before FFI calls,
  * before sharing references/handles with other RThreads or processes.

* Maintain logs and audits (8.4):

  * annotate Σ points (commits, e.g. file flush)
  * track Θ events (ordering of wakes, waits, timeouts)

* Cooperate with static analysis (11.x):

  * IR retains Δ–Ψ tags,
  * runtime-inserted checks are visible and verifiable.

In effect, the PMSL runtime is a policy-aware conductor:

* It turns PMSL programs into well-formed PMS-CPU traces.
* It ensures that every ∇ touching the outside world goes through the appropriate Δ, Ω, Φ, Χ, Σ, Ψ gates.

---

### 12.2 Core Libraries (FS, Networking, Time, Logging, Policies)

*(Standard Library as Δ–Ψ–structured wrappers over kernel syscalls and runtime services)*

The PMSL standard library (PMSL-Std) is not a random assortment of functions—it is a canonically structured layer that:

1. Wraps all kernel services via structured syscall wrappers (Δ + Ω + Φ + Χ + Σ)
2. Exposes high-level abstractions consistent with PMS operators
3. Enforces Ψ-level invariants that the kernel cannot enforce alone
4. Provides reusable Α-patterns for common tasks
5. Integrates tightly with the runtime’s scheduling, event, and isolation mechanisms

PMSL-Std sits on top of the runtime (12.1) and is the “programmable face” of the OS.

---

#### 12.2.1 Filesystem Library (FS.Std)

*(Α patterns, Δ distinctions, Ω capability gating, Σ commits)*

The FS library mirrors the filesystem architecture (4.3) using PMSL-safe types.

##### Core Types

```pmsl
type Path     = String
type File     = Handle<FileDesc>
type Dir      = Handle<DirDesc>
type OpenMode = { Read, Write, Append, Create, Truncate }
type FsError  = enum { NotFound, Permission, io:IoError, invalid }
```

All handles are opaque and enforce Χ-isolation between PMSL objects and kernel FDs.

##### Core Functions

##### `open(path, mode) → Result<File, FsError>`

Operator sequence:

* Δ resolve path
* Ω_check(FS_Open) — capability
* Φ encode path
* ∇ syscall.open
* Φ map errno → FsError
* Σ return handle

##### `read(file, buf, n) → Result<Int, FsError>`

* Ω_check(FS_Read)
* Χ_isolate or share buf
* ∇ syscall.read
* Λ if non-blocking & no data
* Φ error conversion
* Σ integrate new buffer length

##### `write(file, buf) → Result<Int, FsError>`

Analogous to `read`; Σ ensures commit semantics (fsync/journaling).

##### `flush(file) → Result<(), FsError>`

* ∇ issue kernel flush
* Σ commit

##### `list_dir(path) → Result<DirEntry, FsError>`

Uses repeated Δ→∇→Θ sequences for directory walks.

##### `fsync(file)`

Direct Σ operation at the filesystem level.

---

##### 12.2.1.1 Higher-Level FS-Α Patterns

* `copy_file(src, dst)`
* `write_all(fd, buf)`
* `read_to_end(fd)`
* Directory traversal patterns

All built as Α-constructs that expand into sequences of Δ, ∇, Θ, Λ, Φ, Σ.

---

#### 12.2.2 Networking Library (Net.Std)

*(Structured frames, timeouts via Θ/Λ, connections as □-contexts)*

Networking follows the model from section 7.

##### Core Types

```pmsl
type Socket   = Handle<SocketDesc>
type Address  = { ip:IP, port:Int }
type NetError = enum { Timeout, Reset, Closed, Permission, io:IoError }
type Endpoint = Frame<TransportCtx>
```

Connections are modeled as frames (□) that carry protocol state.

##### Core Functions

##### `socket(domain, type, proto)`

Creates a new □-frame for transport state.

##### `connect(sock, addr, timeout)`

Sequence:

* Δ classify address
* Ω_check(Net_Connect)
* Θ register wait with τ-deadline
* ∇ syscall.connect
* Λ if timeout
* Φ map host-specific connection errors
* Σ finalize connected state

##### `send(sock, buf)`

* Ω_check(Net_Send)
* Χ isolate/validate buf
* ∇ syscall.send
* Σ commit sent bytes

##### `recv(sock, n)`

Uses Λ semantics when no data is available; blocking and non-blocking modes via Θ/Λ.

##### `close(sock)`

Triggers Σ for connection teardown + frame release.

---

##### 12.2.2.1 Higher-Level Networking-Α Patterns

* Request–Response (Δ → send → Θ → recv → Σ)
* Retry with backoff (Α over Θ-sequences)
* Non-blocking event loop (Δ over readiness flags)
* Subscription-based receiving (pub-sub, 5.3)

---

#### 12.2.3 Time Library (Time.Std)

*(Θ scheduling + Λ timeout semantics, backed by τ)*

The Time library encapsulates:

* the system clock (τ.now),
* timer objects (τ.timer),
* sleep operations,
* monotonic clocks.

##### Core Types

```pmsl
type Instant  = u64      // monotonic counter
type Duration = u64      // nanoseconds or runtime-defined unit
type Timer    = Handle<TimerDesc>
```

##### Functions

##### `now() → Instant`

* Δ via syscall.time → τ.now
* Φ map to PMSL Instant

##### `sleep(duration)`

Operator sequence:

* Θ register ordered wait against τ.now + duration
* kernel timer → async wake event (Φ)
* Σ at completion

##### `timeout(duration, future)`

Compiles to:

```pmsl
spawn timer
select { future => Σ, timer => Λ(timeout) }
```

Θ, Λ, Φ work together; τ provides the deadlines.

##### `interval(period)`

Creates recurring Θ-events tied to τ.periodic timers.

---

#### 12.2.4 Logging Library (Log.Std)

*(Structured Θ/Σ events + Ψ consistency rules)*

Logging is a structured commit mechanism:

##### Types

```pmsl
enum Level { Trace, Debug, Info, Warn, Error }
type LogRecord = {
    timestamp: Instant,
    level: Level,
    message: String,
    context: Map
}
```

##### Functions

##### `log(level, msg, context?)`

Sequence:

* Δ distinguish level
* Ω_check(Log_Write)
* Θ insert ordered timestamp (from τ.now)
* ∇ emit record to sink (memory, console, file, syslog)
* Σ flush or batch depending on config

##### `set_log_target(target)`

Switches the □-context for logging.

##### `scoped_context(k,v)`

Creates a temporary □-frame that contributes fields to all nested log entries.

---

#### 12.2.5 Policy Library (Policy.Std)

*(Ψ policy definition + Ω role binding + Σ activation + Φ fallback)*

PMSL-level policies govern:

* invariants for API usage,
* access control,
* safe mode,
* module-local permissions.

Kernel Ψ protects system resources; runtime Ψᵣ protects the program level.

##### Types

```pmsl
type Policy      = Frame<PolicyCtx>
type Rule        = { condition, effect }
type PolicyError = enum { Violated, Invalid, Unauthorized }
```

##### Functions

##### `define(policy_name, rules)`

Creates a Ψ-typed frame.

##### `activate(policy)`

Corresponds to:

```pmsl
Ψ_add(policy)
```

and updates the runtime policy stack.

##### `deactivate(policy)`

Removes it from the Ψ stack.

##### `check(rule, input)`

Δ + Ω_check + Φ mapping of errors.

##### `with_policy(policy) { ... }`

Sets a scoped Ψ-frame (□+Ψ).

---

#### 12.2.6 Integration with Concurrency & Events

The core libraries integrate tightly with the event system (5.3):

* Networking uses async readiness events.
* FS async I/O uses kernel event queues.
* Timers use kernel timer interrupts → runtime Θ-events, driven by τ.
* Logging can run asynchronously or batched via Θ/Σ.
* Policies can be time-/ordering-sensitive, e.g.:

  * “no more than X ops per Θ window (relative to τ)”
  * “forbid write after Σ commit”

The runtime scheduler coordinates all of this according to the task, channel, Λ, Φ, Θ semantics described in 11.4.

---

#### 12.2.7 Summary

The core libraries are structured, operator-oriented facades over kernel services:

| Library    | Dominant Ops  | Meaning                                                            |
| ---------- | ------------- | ------------------------------------------------------------------ |
| FS.Std     | Δ, ∇, Σ, Φ, Ω | path resolution, I/O, commits, error reframing, permissions        |
| Net.Std    | □, Θ, Λ, Φ, Ω | connection frames, ordered waits, transport events                 |
| Time.Std   | Θ, Λ, Φ, τ    | scheduling of waits, timeouts, τ-backed clocks                     |
| Log.Std    | Θ, Σ, Δ, τ    | ordered logging over τ-based timestamps + commit-based integration |
| Policy.Std | Ψ, Ω, □, Φ    | policy definition, enforcement, scoped invariants                  |

Everything is safe, capability-controlled, frame-typed, and policy-aware.

---

### 12.3 Concurrency & IO APIs

*(The PMSL High-Level Concurrency Layer built from Θ, Λ, Φ, Ω, Χ, Σ)*

This is the topmost layer of the runtime stack:
a structured, operator-oriented concurrency model that sits directly on PMS primitives and PMS-CPU + kernel.

* Θ is the ordering/scheduling backbone
* Λ is meaningful absence (timeouts, non-events)
* Φ is exception/migration/interrupt-driven recontextualization
* Ω secures privilege/capability isolation
* Χ enforces per-task, per-channel memory/scope isolation
* Σ provides commit/atomicity boundaries for concurrency

And—crucially—all concurrency primitives compile down to explicit syscalls and runtime operations.

---

#### 12.3.1 Concurrency Model Overview

PMSL supports two modes:

##### (1) Structured Concurrency (default)

All concurrent tasks are spawned within a lexical “task scope” and form a Θ-scoped task tree:

```pmsl
task {
    let a = spawn taskA()
    let b = spawn taskB()
    wait_all(a, b)
}
```

* No orphan tasks.
* No hidden global threads.
* Lifetime is bound to scope → Σ-commit on scope exit.
* Cancellation = Φ recontextualization.
* Timeouts = Λ events, integrated into Θ scheduling.

##### (2) Unstructured Concurrency (explicit, opt-in)

Only via Ω-gated APIs:

```pmsl
spawn_detached worker()
```

Termination is governed by Ψ-kill or administrative policies only.

---

#### 12.3.2 Kernel Execution Units → PMSL Tasks

In the kernel (3.3), processes and threads are isolation frames (Χ) with roles (Ω) and Θ state.

PMSL maps each “task” to a kernel thread/task entity, but:

* each PMSL task has:

  * its own □ lexical frame
  * its own Χ isolation context (memory slice, locals)
  * its own Θ scheduler state / wakeups
  * optionally its own runtime Ψᵣ policy stack

This yields deterministic, safe task boundaries.

---

#### 12.3.3 Task API

##### `spawn(f) → Task<T>`

Creates a child task.

Operator expansion:

1. Δ classify function `f`
2. Χ allocate isolated context for child
3. □ create new lexical frame for task
4. Ω grant task-level capabilities
5. Θ register task in scheduler’s ordering
6. Σ return handle

##### `spawn_detached(f)`

Like `spawn`, except:

* no parent Σ-join required
* Ω-check requires “DETACH” capability
* lifetime is under kernel/runtime policy, not lexical scope

##### `async/await` syntax

PMSL supports:

```pmsl
async fn foo() -> Int {
    let v = await read(socket)
    return v + 1
}
```

`await` compiles to:

* Δ check future state
* Θ suspend current task in the scheduling order
* Λ wait for event (if unresolved)
* Φ resume upon event (recontextualize into runnable frame)
* Σ integrate result into local frame

---

#### 12.3.4 Task Synchronization Primitives

All synchronization abstractions are structured versions of kernel primitives (5.2), but type-safe.

---

##### Mutex<T>

```pmsl
let m = Mutex<T>::new(val)
m.lock().with(|mut t| { ... })
```

Semantics:

1. Ω ensures locking allowed
2. Χ ensures `t` is isolated while locked (view from one task)
3. Θ requeues task on contention (ordering in the scheduler)
4. Σ unlock commits new `t`

---

##### Semaphore(n)

Kernel-backed, with Θ ordering and Λ/τ-based integration for timed waits.

---

##### Channel<T> — the canonical IPC primitive

PMSL includes typed, bounded/unbounded channels:

```pmsl
let (tx, rx) = channel<T>(capacity=16)
tx.send(v)
let v = rx.recv()
```

Operator semantics:

* send:
  Δ classify message → Ω capability check → Χ copy/transfer → ∇ write → Σ commit

* recv:
  Δ classification → Θ wait (ordered blocking) → Λ if τ-based timeout → Φ on channel-close → Σ integration

Channels form the safe user-space equivalent of kernel message queues (5.1).

---

##### Select / Event-Choice

```pmsl
select {
    msg = rx.recv()     => handle(msg),
    tick = timer.next() => handle(tick),
    timeout(50ms)       => handle_default()
}
```

This compiles to a Θ-ordered event loop with Δ-branches and Λ/τ-based timeouts.

---

#### 12.3.5 Task Lifetime & Cancellation (Φ + Ψ)

Cancellation is structured:

##### cancel(task)

* Ψ-runtime verifies hierarchical relationship
* Φ transitions child into cancellation-context
* Child receives cancellation exception
* Child must Σ end state or Φ propagate up
* Parent waits for clean Σ integration

##### scope exit → Σ commit

At the end of any:

```pmsl
task {
    ...
}
```

The runtime performs:

* Σ integration of task results
* Ψ cleanup of policy stack
* Χ release of isolated resources
* Θ update scheduler ordering/accounting state

---

#### 12.3.6 IO API and Asynchronous IO

PMSL unifies all IO (FS, networking, drivers) via the same concurrency primitives.

##### Basic async IO skeleton

```pmsl
let data = await fs.read(fd, n)
let msg  = await socket.recv()
let evt  = await device.wait_irq()
```

Under the hood:

* `read` / `recv` / `irq` → Λ (τ-based wait/timeout) + Θ (event scheduling/order) + Φ (wake/recontextualize)
* Isolation of buffers via Χ
* Privilege checks via Ω
* Proper commits via Σ

Async IO becomes the *default* safe mechanism.

---

#### 12.3.7 High-Level Concurrency Patterns (Α-patterns)

The standard library includes reusable Α-patterns:

---

##### Task Pool

```pmsl
task_pool(size=8).submit(job)
```

Expands to:

* Χ isolate worker contexts
* Θ schedule jobs in an ordered work queue
* Σ returns results in deterministic order

---

##### Pipeline

```pmsl
pipeline {
    stage1 | stage2 | stage3
}
```

Each stage is a □ frame with its own Χ resource boundaries.

---

##### Supervisor Trees (like Erlang), but structured

```pmsl
supervisor {
    child(taskA),
    child(taskB),
    on_fail restart
}
```

Φ → failure detection
Σ → restart commit
Ψ → invariant: supervisor cannot silently drop children

---

##### Async Streams

Native operator-typed stream abstraction:

```pmsl
for await msg in stream {
    ...
}
```

Grounded in Θ-ordered event progression, with τ providing the temporal reference for arrivals and Λ timeouts.

---

#### 12.3.8 Memory Consistency for PMSL (User-Level)

PMSL uses the kernel’s memory model (2.7) but strengthens it:

* All shared-memory synchronization uses Σ barriers
* Data races are structurally impossible unless Ω allows `unsafe` sections
* Channel+task-based concurrency has strong SC semantics

Thus PMSL gives:

* Deterministic messaging
* Safe structured concurrency
* Explicit escape hatches (Ω/Ψ/Σ) for low-level control

---

#### 12.3.9 Summary

PMSL Concurrency & IO APIs provide:

##### Primitive level

| Operator | Role                                                   |
| -------- | ------------------------------------------------------ |
| Θ        | task scheduling, ordered suspension and wake sequences |
| Λ        | timeouts, waits, absence (relative to τ)               |
| Φ        | cancellation, exceptions, trap-based resumes           |
| Ω        | task permissions, async IO gating                      |
| Χ        | isolated task memory and channel boundaries            |
| Σ        | commit points for synchronization                      |

##### APIs

* `spawn`, `spawn_detached`
* `async` / `await`
* channels, `select`, timers
* mutexes, semaphores
* supervisor trees
* pipelines & pools
* unified structured async IO

##### Guarantees

* Structured, safe concurrency
* Deterministic or explicitly nondeterministic
* Task-scoped invariants via Ψ
* Isolation by construction
* Built on the PMS-CPU + kernel IPC model

---

## 13. Tooling & Verification

Tooling in PMS is not an afterthought — it is *intrinsically PMS-structured*.
Every analysis, verification, debug, or transformation tool is defined on top of:

* the operator algebra (Δ–Ψ),
* the meta-model for states/transitions (0.4),
* the PMS-UM reduction semantics, and
* the PMS-CPU ISA (2.2).

The central artifact under which these tools operate is the PMS Intermediate Representation (PMS-IR).

---

### 13.1 Intermediate Representation (IR) – Operator-Tagged

The PMS-IR is a unified, operator-typed, analyzable representation of all executable PMS artifacts:

* PMSL source modules
* compiled PMSL functions
* kernel policies
* syscall interface specs
* driver-state machines
* networking protocol handlers
* verification models
* offline interpretable artifacts (formal proofs, audits)

It is the single canonical IR for analysis, optimization, verification, simulation, and codegen.

---

#### 13.1.1 Guiding Principles

The PMS-IR is designed to:

##### (1) Preserve PMS operator semantics

Every instruction in PMS-IR is explicitly tagged with one operator in {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}.

This tag is invariant under optimization and transformations.

Example:

```text
Δ.compare r1 r2
∇.add     r3 r1 r2
□.enter   frame_id
Θ.tick
Φ.raise   exc_id
Ψ.guard   policy_id
```

##### (2) Preserve all dependency constraints

Unlike machine IRs which treat operators generically, PMS-IR enforces that:

* ∇ cannot appear without Δ in its dominator ancestry
* Λ only appears under Θ or ∇ expectations
* Φ requires Δ and □ ancestry
* Σ requires ∇/Θ antecedents
* Ψ may block or rewrite further control paths

These constraints are syntactically encoded in the IR and checked statically.

##### (3) Be amenable to static analysis & model checking

PMS-IR is:

* SSA-like (single-assignment for core values)
* CFG-representable (basic blocks + edges)
* Explicit about ordering (Θ) and about temporal reference via τ/Λ where relevant
* Explicit about role transitions (Ω)
* Explicit about frame/context boundaries (□)
* Explicit about isolation transitions (Χ)

##### (4) Be the input for PMS-CPU codegen

PMS-IR → PMS-CPU ISA is a clean lowering:

* Δ → CMP/TST/JMP
* ∇ → ALU/LOAD/STORE
* □ → FRM_ENTER/LEAVE
* Ω → SET_ROLE
* … etc.

---

#### 13.1.2 PMS-IR Structure

A PMS-IR program is a tuple:

```text
IR = (Defs, Types, Blocks, Policies)
```

Where:

##### (A) Defs

Function, module, syscall, and driver-state definitions:

```text
def foo(a: Int, b: Int) -> Int
def driver.usb.handle_irq(ctx: IRQContext) -> Status
def sys.read(fd: Int, buf: Ptr, len: Int) -> Int
```

##### (B) Types

Type environment from PMSL’s type system (11.3):

* frame types
* role sets
* policy sets
* process/actor types
* structural types (records, unions, enums, sums)

##### (C) Blocks

Basic blocks of operator-typed instructions:

```text
block B0:
    Δ.test r1 r0
    BEQ B_fail
    ∇.add r2 r1 r0
    Θ.tick
    JMP B1
```

##### (D) Policies

Inline Ψ constraints attached to:

* functions
* modules
* syscalls
* blocks
* edges

Example:

```text
Ψ.require( role == USER or CAP_IO )
Ψ.forbid_write(frame=kernel_code)
Ψ.max_time(block=B0, ticks=5)
```

---

#### 13.1.3 IR Instruction Format

Each PMS-IR instruction is a record:

```text
IRInstr {
    op: PMSOperator,      // Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ
    opcode: Symbol,        // specific operation (cmp, add, enter_frame, etc.)
    operands: List<Value>, // registers, SSA names, frames, roles
    meta: MetaInfo         // loc, debug, source mapping, comments
}
```

Example:

```text
IRInstr(
  op = ∇,
  opcode = "store",
  operands = r2, frame(FR_DATA), offset(0x10),
  meta = {src="foo.pmsl:41"}
)
```

PMSOperator is mandatory — there is no untagged instruction in the IR.

---

#### 13.1.4 Control Flow Graph (CFG) Structure

A PMS-IR CFG edge is labeled with one of the operators:

* Δ-edges — conditional distinctions
* Θ-edges — ordering progression (scheduler / control step)
* Φ-edges — trap/exception/recontextualization flow
* Ψ-edges — policy-induced constraints (may prune edges)
* Σ-edges — commit/transaction boundaries
* Λ-edges — timeout/non-event fallback paths (relative to τ)
* Χ-edges — exit/enter isolation

CFG node example:

```text
block B0:
    Δ.eq r1, r0
    BEQ B1
    JMP B2
```

CFG edges:

* (B0 → B1) labeled Δ
* (B0 → B2) labeled Δ

This enables operator-aware control-flow analysis, for example:

* “Can a Σ commit be reached without a preceding ∇?”
* “Can a Φ raise escape an isolation (Χ) boundary?”
* “Is this Ω privilege elevation reachable by untrusted user input?”

---

#### 13.1.5 SSA Integration

PMS-IR uses partial SSA:

* Register-like values (`v0`, `v1`, …) are single-assignment.
* Frame pointers, roles, and policies are *not* in SSA:

  * they are modeled structurally (□, Ω, Ψ)
  * they evolve through operator-typed transitions

Example:

```text
v0 = ∇.load FR+0
v1 = Δ.compare v0, 10
BEQ B1
v2 = ∇.add v0, 3
Σ.commit
```

---

#### 13.1.6 IR Meta-Operators for Analysis

Some operators have meta variants used only during tooling, not during execution:

##### Δ? — symbolic distinction

Used to ask “what if x = y?” in static analysis.

##### Φ? — symbolic recontextualization

Used for modeling exception propagation.

##### Ψ? — symbolic policy solving

Used to check whether a policy can ever be violated.

Meta-operators do not appear in executable IR but are used by:

* model checker
* static analyzer
* symbolic execution engine

---

#### 13.1.7 IR Validation (Static)

Before an IR program can be accepted:

1. Operator dependency constraints (0.3) must hold globally.

2. Each CFG path must satisfy consistency:

   * ∇ dominated by Δ
   * Λ preceded by Θ/∇
   * Φ preceded by Δ and □
   * Σ dominated by ∇/Θ
   * Ψ must not be bypassed
   * Χ transitions fully bracketed

3. Type checks (11.3) for roles, frames, policies, processes.

4. Policy consistency checks (Ψ):

   * All policy preconditions resolvable
   * No policy cycle creating unsatisfiable invariants

5. Isolation correctness (Χ):

   * No escape from isolated subspace without explicit Χ.exit

6. Temporal/ordering constraints:

   * No infinite Θ-only loops without policy exception
   * No starvation of Δ / ∇ under fairness assumptions

---

#### 13.1.8 IR Transformations

PMS-IR supports several transformations, each operator-aware:

##### (A) Dead code elimination (Δ-aware)

Eliminates blocks whose Δ distinctions can never be satisfied.

##### (B) Φ-normalization

Rewrites nested Φ sequences into canonical form:

```text
Φ.raise → Φ.save_ctx → Φ.dispatch_handler
```

##### (C) Σ-hoisting / sinking

Move commit boundaries to reduce overhead while preserving Σ dominance relations.

##### (D) Ω-constraint narrowing

Simplify role transitions based on static analysis:

```text
if role == USER and CHK_CAP(CAP_IO) always true:
    collapse Ω → identity
```

##### (E) □-frame flattening

Inline frames where isolation and privilege constraints allow it.

##### (F) Δ-specialization

Specialize branches with known distinctions → partial evaluation.

##### (G) Α-expansion

Inline or decompose attractor patterns (loops, macros).

---

#### 13.1.9 IR Serialization Format

A PMS-IR file is stored as a structured, declarative format:

```text
pms-ir-version = 1.0

module mymod:
    import fs
    import net

types:
    Frame DataFrame { base:Addr, size:Size, perms:Perm }
    Role  User | Kernel | Driver

policies:
    Ψ.require( role != Kernel or CAP_K )
    Ψ.forbid_write(frame=kernel_code)

function add(a:Int, b:Int) -> Int:
block entry:
    Δ.cmp v0=a, v1=b
    BEQ block eq_path
    ∇.add v2=a, v3=b
    Σ.commit
    JMP block exit
```

Intended to be:

* machine-readable
* checkable
* stable under optimization
* embeddable into debugging and verification tools

---

#### 13.1.10 Summary

The PMS-IR is:

* operator-tagged, preserving Δ–Ψ semantics
* dependency-checked by construction
* SSA-compatible, CFG-structured, policy-aware
* extensible for static analysis, symbolic execution, and model checking
* the canonical lowering target from PMSL (11.x)
* and the canonical raising source for PMS-CPU codegen (10.x → 2.x)

This IR enables:

* formal verification
* security auditing
* debugging
* optimization
* multi-target compilation

all without losing PMS structural invariants.

---

### 13.2 Static Analysis & Linting – Ω/Ψ, Σ/Λ/Φ Checks

Static analysis in PMS is not merely “compile-time checking.”
It is a semantic verification phase that enforces PMS operator constraints, type rules, isolation guarantees, ordering/temporal properties, and policy consistency before PMS-CPU codegen or kernel integration.

Think of PMS static analysis as:

* structural analysis (operators Δ–Ψ)
* role/capability analysis (Ω)
* policy/invariant analysis (Ψ)
* temporal/ordering analysis (Θ, Λ, τ)
* context/isolation analysis (□, Χ)
* commit semantics analysis (Σ)
* exception/recontext analysis (Φ)

This is much richer than typical compilers.

---

#### 13.2.1 Analysis Pipeline

Given PMS-IR (13.1):

```text
PMSL → IR-gen → PMS-IR → Static Analysis → Optimizer → PMS-CPU codegen
```

Static analysis consists of eight major phases:

1. Operator Dependency Checking (from 0.3)
2. Type & Frame Analysis (frames, roles, policies)
3. Privilege / Role Flow Analysis (Ω)
4. Policy Verification (Ψ)
5. Temporal / Ordering Analysis (Θ, Λ, τ)
6. Isolation Correctness Analysis (Χ)
7. Commit & Integration Analysis (Σ)
8. Exception Propagation Analysis (Φ)

Linters implement the lightweight, user-facing, developer-friendly parts of these phases.

---

#### 13.2.2 Operator Dependency Checking

PMS requires:

* ∇ dominated by Δ
* Λ preceded by Θ or ∇
* Φ preceded by Δ and □
* Σ dominated by ∇/Θ
* Ψ dominated by Δ
* Χ dominated by □ (no isolation without an active frame)

The static analyzer walks the CFG and guarantees that on all paths the dependency table (0.3) is satisfied.

##### Violations (examples):

Error:

```text
∇.store r1, F_DATA
↑ No Δ in dominator chain
```

Error:

```text
Λ.timeout
↑ no Θ expectation upstream
```

Error:

```text
Φ.reinterpret …
↑ must follow Δ and □ in all paths
```

Error:

```text
Σ.commit
↑ no ∇ or Θ upstream → empty commit
```

These are *structural violations* — they are always fatal.

---

#### 13.2.3 Role / Capability Analysis (Ω)

This phase analyzes:

* role transitions (`Ω.enter`, `Ω.elevate`, `Ω.drop`)
* privilege requirements of IR instructions
* capability sets required for syscalls, frame transitions, and isolation exit

We perform flow-sensitive analysis over the CFG:

```text
role_in[B] -> role_out[B]
```

Rules:

* Ω edges update the role context
* Δ/Θ/∇ do not (unless an instruction is explicitly annotated)
* Φ may change role if an exception re-enters kernel mode, and so on

##### Checks Performed

(1) Unreachable Privilege Escalation

```text
Ω.enter(KERNEL)
↑ not reachable from user-space without explicit capability
```

(2) Illegal Cross-Frame Access

```text
∇.store kernel_frame
↑ only permitted in roles = {Kernel, DriverIO}
role = User → violation
```

(3) Excessive Privilege Retention

Fail if:

* role elevated to KERNEL but never dropped back → violates Ψ safety policy.

(4) Missing Role Guards

If a block contains privileged operations but has no Ω-preconditions or Ψ guards:

```text
Δ.test  
∇.write dev_reg
↑ write to device register requires Ω(role=Driver)
```

---

#### 13.2.4 Policy Verification (Ψ)

Policies appear as Ψ instructions and Ψ-annotations in IR.
Static analysis performs:

##### Policy Reachability

Ensure that every path that must pass a policy check does pass it.

##### Policy Coverage

Ensure all policies relevant to:

* filesystem accesses
* network flows
* isolation boundaries
* driver I/O
* syscalls
* resource usage

are reached in all valid scenarios.

##### Policy Satisfiability

Detect contradictions:

```text
Ψ.require role == USER
Ψ.require role == KERNEL
↑ Unsatisfiable combined constraints
```

Or more subtle forms:

```text
Ψ.max_time(block=B0, ticks=10)
Ψ.min_time(block=B0, ticks=12)
↑ Conflicting temporal constraints
```

##### Policy Monotonicity

Ψ may not weaken constraints once established, unless explicitly marked as “rollback/override”.

Static analysis checks:

* no unexpected weakening of invariants
* Ψ overrides only permitted in admin privilege contexts

##### Open Policy Violations

Paths that escape from required policy enforcement:

```text
entry → … → Σ.commit
↑ never hits Ψ.guard → violation
```

---

#### 13.2.5 Temporal Analysis (Θ, Λ)

Temporal/order analysis enforces correct usage of:

* Θ ordering progression (scheduler / execution steps)
* Λ non-event / timeout (defined via τ in the meta-state)
* Φ timed exceptions
* Ψ ordering/timeout bounds

##### Checks:

###### (1) Illegal Timeout

Λ must have an upstream Θ or expected ∇.

###### (2) Deadloops

A loop with only Θ operations and no policy guard:

```text
loop B0:
    Θ
    JMP B0
↑ infinite Θ-only loop unless Ψ allows it (rare)
```

If no Ψ guard exists → static error.

###### (3) Event-Ordering Inconsistency

If a Λ timeout is reachable *without* any event being expected, raise an error.

###### (4) Temporal Bound Violations

Policies can specify:

```text
Ψ.max_time(block=B2, ticks=5)
```

The static analyzer estimates Θ-step ranges and flags potential overruns.

###### (5) Missed Deadline Paths

If a block has a τ-based deadline but the CFG allows bypassing the Θ steps that should lead to the corresponding Λ/Σ handling → violation.

---

#### 13.2.6 Isolation Correctness Analysis (Χ)

Isolation (Χ) establishes boundaries akin to:

* processes
* containers
* security domains
* transactional sandboxes
* protocol/state-machine localities

Static analysis ensures:

##### (1) No Leakage Across Χ Boundaries

If a value or pointer from an isolated region flows outward without explicit Χ.exit, it is an error.

Example:

```text
Χ.enter iso_f
v = ∇.load iso_frame+0
return v        // error — returning isolated pointer/data
```

##### (2) No Implicit Capability Escalation by Isolation

Isolation cannot be used to smuggle privileged frames.

```text
User enters isolation → loads driver_frame → exits
↑ Violation: isolation cannot bypass Ω restrictions
```

##### (3) Balanced Isolation

Each Χ.enter must be matched with a Χ.exit on all terminating paths.

##### (4) No Cross-Context Writes

Writes from one isolation context to another must pass through an authorized integrator / mediator.

---

#### 13.2.7 Commit & Integration Analysis (Σ)

Σ marks integration / commit points:

* filesystem writeback
* transactional commit
* IPC message finalization
* resource accounting boundaries

Static analysis checks:

##### (1) Empty Commit

Σ must not occur without any prior ∇ or Θ that produce state to integrate.

##### (2) Commit Under Isolation

Σ inside Χ isolation is only legal if it commits *inside* the isolated context — not to a parent context unless explicitly authorized.

##### (3) Commit Ordering

Σ must respect frame dominance:

```text
□.enter F1
∇ write
□.enter F2
Σ.commit   // must commit in F2, not bypass into F1
```

##### (4) Atomicity Consistency

If Σ is part of a transaction boundary, static analysis ensures all required operations are included and no forbidden operations appear after Σ in the same context.

---

#### 13.2.8 Exception & Recontextualization Analysis (Φ)

Φ operations restructure execution context:

* raise exceptions
* switch protocol versions
* reframe data
* propagate context changes

Analysis verifies:

##### (1) Dominated by Δ and □

As required by semantics:

```text
Φ.raise without Δ and □ upstream → illegal
```

##### (2) Correct Isolation Escape Semantics

Φ cannot jump out of an isolated context unless:

* explicitly permitted via policy, and
* a matching Χ.exit is provided (or an explicitly allowed escape frame).

##### (3) Completely Handled Exceptions

Every Φ.raise must have:

* a Φ.handler, or
* a return-to-caller policy allowing propagation upward, or
* a transition into a defined halting state.

##### (4) Balanced Reframes

Multiple Φ transitions must not lead to “identity loss,” i.e., forgetting original frames or roles unless allowed by Ψ.

---

#### 13.2.9 Linting Layer

Linting = static analysis made developer-friendly.

Examples of lint rules:

##### Δ-lints

* “Δ distinction result not used”
* “Suspicious Δ: comparison always true/false”

##### ∇-lints

* “∇ write to zero-length frame”
* “∇ compute but result unused before Σ”

##### Ω-lints

* “Role elevation immediately dropped — suspicious”
* “Unreachable Ω branch”

##### Θ-lints

* “Θ inside tight loop without Ψ guard”
* “Unused ordering counter”

##### Λ-lints

* “Timeout unreachable — remove Λ”
* “Multiple Λs without corresponding expected event”

##### Φ-lints

* “Handler returns to invalid frame”
* “Φ chain too deep — consider refactoring”

##### Χ-lints

* “Isolation enters but never commits any Σ inside”
* “Potential isolation leak: value flows out of domain”

##### Σ-lints

* “Σ inside high-frequency loop — performance hazard”
* “Σ commits too large a region — consider splitting”

##### Ψ-lints

* “Policy always true — redundant”
* “Conflicting Ψ constraints”

---

#### 13.2.10 Deliverables of the Static Analyzer

For every PMS-IR input, the analyzer produces:

##### (A) Operator-Flow Graph

Shows how Δ–Ψ propagate across the program.

##### (B) Role-Flow Graph (Ω)

Visualizes privilege transitions.

##### (C) Frame-Path Analysis

Which frames the program can enter and in what order.

##### (D) Policy Verification Report

Satisfied and violated policy constraints.

##### (E) Isolation Audit

All isolation contexts, entry/exit, violations.

##### (F) Temporal / Ordering Model

Ranges of Θ steps, τ-based deadlines, Λ timeouts, reachable loops and deadline paths.

##### (G) Resource Pre-Accounting

Static estimate of commits, memory writes, IPC usage.

##### (H) Human-Friendly Lint Report

Warnings and suggestions.

---

#### 13.2.11 Summary

Static analysis ensures structural correctness, safety, capability discipline, policy compliance, isolation integrity, ordering/timeout soundness, and commit semantics across PMS programs before execution.

It enforces the PMS operator algebra at compile time, not only at runtime.

---

### 13.3 Model Checking & Property Verification

*(Operator-typed verification: Δ–Ψ as the semantic backbone)*

PMS systems have first-class semantics for:
branching (Δ), mutation (∇), frames (□), absence (Λ), patterns (Α), roles (Ω), ordering (Θ), reframing (Φ), isolation (Χ), commit (Σ), and invariants (Ψ).
This makes PMS a *well-typed transition system* — suitable for formal verification.

This section defines how to verify PMS programs, kernels, protocols, and distributed systems.

---

#### 13.3.1 Formal Verification Model

We model a PMS program (IR) as a labeled transition system:

```text
T = (S, S0, ->, P)
```

Where:

* S: PMS states (each state is a tuple of core/frame/role/policy/meta, see 0.4)
* S0: initial states
* ->: transition relation induced by PMS operators
* P: active policy set (Ψ)

Verification means: check properties of this transition system where each step is labeled with an operator in {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}.

---

#### 13.3.2 Operator-Labeled Transition System

Every PMS transition is labeled with exactly one operator (Δ–Ψ).
Thus a path has the form:

```text
s0 -[o1]-> s1 -[o2]-> s2 -[o3]-> ...
```

with each `oi` in {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}.

Model checking uses these labeled paths to verify:

* safety
* liveness
* isolation guarantees
* role/capability constraints
* resource bounds
* ordering/timeout correctness
* policy consistency

Because every label is semantically meaningful (not just a raw opcode), the model checker can reason about system behavior at a high structural level.

---

#### 13.3.3 Classes of Properties

We verify properties corresponding to PMS operators.

---

##### (A) Safety Properties — “Nothing bad ever happens” (Ψ-level invariants)

Examples:

* kernel memory is writable only in roles allowed by Ω (for example Ω = Kernel)
* no cross-domain writes violating Χ
* no Φ exception escapes its allowed frame
* no Σ commit occurs without prior ∇ mutation
* Λ timeout cannot occur in frames marked “strict temporal” unless explicitly allowed

These are global invariants, conceptually “in all reachable states, `safe(s)` holds”.

---

##### (B) Liveness Properties — Θ-driven eventuality

Examples:

* every request (Δ) eventually produces a response (Σ) under fair Θ ordering
* isolation contexts eventually exit via Χ.exit
* every driver interrupt (Φ) eventually triggers driver handler ∇

These are “eventually something good happens” properties under fairness assumptions encoded in Ψ.

---

##### (C) Temporal Boundedness — Θ/Λ constraints

Examples:

* an operation completes within at most `T` Θ-steps
* Λ timeout only occurs if there was a Θ-ordered expectation plus a τ-based deadline

These express deadline-style guarantees over Θ/Λ with τ in the meta-state.

---

##### (D) Isolation Properties — Χ correctness

Examples:

* no isolated value leaks to non-isolated context
* no cross-frame jump without Ω permission

Formally: in all reachable states, some “no leak” predicate over Χ holds.

---

##### (E) Policy Adherence — Ψ constraints

Policies are invariants over:

* roles (Ω)
* frames (□)
* ordering/timeout structure (Θ, Λ, τ)
* allowed transitions

Ψ gives a built-in mechanism for specifying these properties. The model checker ensures that in all reachable states, policy predicates derived from Ψ hold, or transitions that would violate them lead to explicit halting / error states.

---

##### (F) Commit Correctness — Σ

Examples:

* every Σ commit represents a consistent state
* no Σ happens inside forbidden contexts

The property is: whenever a Σ step occurs, the surrounding state satisfies a defined consistency predicate.

---

#### 13.3.4 Model Checking Algorithmic Strategy

PMS verification uses hybrid techniques:

---

##### (1) Symbolic Model Checking

State-space exploration using symbolic encodings of PMS state:

* symbolic frame contexts (□)
* symbolic role sets (Ω)
* symbolic isolation partitions (Χ)
* symbolic policies (Ψ)
* symbolic ordering/time regions (Θ, Λ, τ)

Techniques:

* BDD-like encodings
* SMT solving over operator constraints
* symbolic execution over PMS-IR

---

##### (2) Abstract Interpretation

We abstract:

* value ranges
* frame sets
* capability flows
* Θ-step bounds and τ deadlines
* policy invariants
* Σ commit regions
* Χ isolation partitions

This yields scalable approximations of the reachable state space.

---

##### (3) Operator-Dominance Analysis

Because PMS operators have a partial order (from dependency rules):

* Δ dominates ∇
* □ dominates Χ and Φ
* Θ dominates Λ and Σ
* Ω dominates most privileged operations
* Ψ dominates everything

We use this ordering to prune illegal transitions and compress the search space.

---

##### (4) Path Pruning via Ψ Policies

Ψ invariants eliminate many transitions from the transition system:

* halting states
* forbidden execution paths
* disallowed frame transitions
* illegal role changes
* illegal timeouts

This drastically reduces the model-checking space.

---

##### (5) Commit-Region Partitioning (Σ)

Σ divides the transition system into logical phases.

We exploit Σ boundaries to:

* modularize the state space
* collapse many internal ∇/Θ steps into summarized regions
* enable local reasoning inside transaction-like regions

---

#### 13.3.5 Verification of Multi-Node Systems (Distributed PMS)

PMS networks (Section 9) have:

* role-based endpoints (Ω)
* frame-scoped addressing (□)
* timeouts (Λ defined via τ)
* retries (Θ-ordered patterns)
* recontextualization (Φ)

So distributed properties can be modeled cleanly.

We can check:

---

##### (A) Distributed Safety

* no two nodes commit conflicting Σ states
* cross-node isolation holds (Χ across nodes)
* no unauthorized role escalation across nodes

---

##### (B) Distributed Liveness

* every Δ request eventually yields a Σ response (subject to fairness)
* heartbeats driven by Θ eventually reach all neighbors unless blocked by Ψ

---

##### (C) Network Partition Handling (Φ)

* correctness of recontextualization under partition and healing
* consistency of state after reconnection

---

##### (D) Causal Ordering (Θ + Σ)

* ordering of messages across frames
* consistent transaction replay after isolation or failure

---

#### 13.3.6 Verification of PMS-CPU and Kernel

Key verification tasks:

##### Correct System Call Boundaries (Ω + Ψ)

Ensure:

* user → kernel transitions respect capabilities (Ω, Ψ)
* kernel → user transitions drop privileges correctly
* system-wide invariants always hold across syscalls

##### Memory Protection (Χ)

Prove that illegal memory accesses are unreachable:

* user code cannot write kernel-only frames
* isolation domains (Χ) are respected on all paths

##### Scheduling Liveness (Θ)

Guarantee:

* no runnable task is starved under configured Θ/Ψ fairness rules
* priority inversions are either prevented or handled by explicit mechanisms

##### Policy Enforcement (Ψ)

Show:

* every policy-relevant path hits Ψ guards
* no control-flow path escapes without policy application where required

---

#### 13.3.7 Toolchain Integration

The verification system connects to:

* PMSL compiler
* PMS-IR generator
* static analyzer
* PMS-CPU simulator
* kernel validator
* distributed protocol analyzer

Outputs:

* counterexamples, annotated with Δ–Ψ operator traces
* invariant violation reports
* certified proof artifacts
* temporal / ordering metrics
* role / frame policy diagrams
* isolation graph integrity proofs

---

#### 13.3.8 Summary

PMS verification is possible and tractable because:

* operators encode semantic structure at the machine level
* transitions are typed (Δ–Ψ)
* policies (Ψ) and isolation (Χ) provide strong invariants
* commits (Σ) give natural proof boundaries
* frames (□) segment the state space cleanly
* ordering and absence (Θ, Λ, with τ as the underlying time reference in the meta-state) express temporal properties structurally

The result is a model-checking system that is more expressive and analyzable than conventional instruction sets, while remaining grounded in a single, uniform operator algebra.

---

### 13.4 Debugging & Observability Model (logs, traces, metrics as Θ / Σ)

PMS systems are *inherently observable* because every state transition is typed by one of the 11 PMS operators Δ–Ψ.
This allows debugging, tracing, profiling, and runtime analysis to be expressed directly in terms of:

* Θ — ordering progression, sequencing, scheduler steps
* Σ — commit points, stable snapshots, integration boundaries
* Δ — distinctions that drive control flow
* Φ — context shifts (exceptions, traps)
* Χ — isolation boundaries
* Ω / Ψ — privilege and invariant enforcement events

This section defines the Operator-Structured Observability Architecture (OSOA).

---

#### 13.4.1 Observability Model Overview

Observability in PMS is built around three fundamental ideas:

---

##### (1) Every transition has operator semantics

Instead of arbitrary “instruction tracing,” we log operator-labeled transitions:

` s -(o)-> s'  (with o ∈ {Δ, ∇, □, …, Ψ})`

A debugger or tracing system sees semantic traces, not raw opcodes:

* Δ = branch / distinction
* ∇ = mutation
* □ = frame/context change
* Θ = ordering step in the execution / scheduler
* Φ = exception/trap
* Σ = commit
* Ω = privilege escalation/de-escalation
* Χ = isolation enter/exit

This alone makes introspection dramatically easier.

---

##### (2) Ordering structure is explicit (Θ; τ for timestamps)

Θ is the built-in ordering sequencer; τ in the meta-state provides any actual clock or timestamp values.
So all logs and traces attach to Θ events as an ordered sequence, optionally annotated with τ-based time data:

* instruction_index (Θ-step index)
* τ-based timestamps (if recorded)
* scheduler phase
* transaction window
* isolation epoch

---

##### (3) Commit structure is explicit (Σ)

Σ marks durable, consistent, debuggable points:

* stable snapshots
* transaction commits
* safepoints
* state captures for rollbacks
* log-flush boundaries

This gives observability strong structural anchors.

---

#### 13.4.2 Debugging Model

PMS defines a generic debugger abstraction using Δ–Ψ semantics.

##### Breakpoints (Δ / Ω / Ψ)

Breakpoints can be placed on:

* Δ events
  Whenever a branch-distinction is evaluated (for example, CMP → BEQ), the debugger may stop.

* Ω role transitions
  Break when privilege mode changes (user → kernel, sandbox enter, capability grant).

* Ψ policy triggers
  Stop when an invariant is evaluated or violated.

* Operator-specific breakpoints
  For example, break on any Φ exception, any Σ commit, any Χ isolation entry.

Breakpoint format:

```text
break when op ∈ {Δ, Φ, Σ} and condition(s)
```

Examples:

```text
break Δ where flag.Z = 1
break Φ where exception.code = DIV_ZERO
break Σ where transaction.id = T42
break Ω where role = Kernel
```

---

##### Stepping (Θ-driven)

Because Θ encodes ordered execution steps:

* step-instruction = advance one Θ-step
* step-over = advance to next Σ boundary
* step-through-exception = continue through Φ transitions until a normal frame is reached
* step-frame = continue until next □ switch

This exposes logical execution structure, not just program counter increments.

---

##### Inspection of State

A debugger can inspect:

###### Registers and memory (∇ / Δ)

* internal register values
* frame-scoped memory view via □

###### Frame context (□)

* active address space
* call-frame stack
* privilege frame

###### Role and policy context (Ω / Ψ)

* current role r
* enabled capabilities
* active policy set

###### Isolation context (Χ)

* sandbox / VM / process scope

###### Meta-state (Θ / Λ)

* ordering indices
* pending non-events / waits
* last-operator history

---

##### Reverse Debugging (via Σ snapshots)

Because Σ marks consistent commit points, PMS supports:

* checkpointing on Σ
* replay from Σ boundaries
* reverse stepping until previous Σ

This is similar in spirit to record/replay systems, but structural and guaranteed by the model.

---

#### 13.4.3 Tracing Model

A trace is a sequence of operator-labeled events:

`(o1, t1, info1), (o2, t2, info2), …`

Where:

* `o_i ∈ {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}`
* `t_i` is a Θ-step index (optionally annotated with τ-based time)
* `info_i` is metadata depending on the operator

---

##### Trace Schema (per operator)

###### Δ events

Include: branch target, comparison values, flags.

###### ∇ events

Register/memory diffs (possibly minimized with symbolic deltas).

###### □ events

New frame id, previous frame, reason code.

###### Λ events

Timeout reason, expected event, τ-based elapsed time.

###### Α events

Pattern id, expansion range.

###### Ω events

Role transitions, capability grants/denials.

###### Θ events

Scheduler step, quantum switch, pipeline retirement in the execution order.

###### Φ events

Exception class, trap vector, reframe target.

###### Χ events

Isolation context id, entry/exit, access filters.

###### Σ events

Commit id, write-set summary, transaction boundaries.

###### Ψ events

Policy evaluation result, violated invariant, remediation action.

---

#### 13.4.4 Observability Planes

PMS defines four observability planes, each tied to specific operators:

---

##### (1) Control Plane — Δ / Ω / Ψ

Used for:

* branching logic
* security-related control flow
* policy-driven decisions
* capability enforcement

---

##### (2) Data Plane — ∇ / Σ

Used for:

* data mutations
* commit records
* write sets
* atomic operations

---

##### (3) Context Plane — □ / Φ / Χ

Used for:

* address-space switching
* trap/exception reasoning
* isolation transitions

---

##### (4) Ordering / Timeout Plane — Θ / Λ (plus τ in meta-state)

Used for:

* execution ordering and profiling along Θ
* τ-based measurements (durations, intervals) attached to Θ steps
* timeouts and non-events
* scheduler activity
* event-ordering guarantees

---

#### 13.4.5 Metrics & Profiling Model

Metrics derive directly from Θ/Σ/Δ counts, with τ in the meta-state providing numerical time measurements where needed.

---

##### Ordering / Scheduling Metrics (Θ, τ)

* Θ-step counts per instruction class
* scheduler quanta per task
* τ-based latency histograms between Θ-indexed events

Examples:

```text
metric Θ.count(op = ∇)
metric latency(Φ_exception → Σ_commit)
```

(Here latency is measured via τ between two Θ-indexed events.)

---

##### Stability Metrics (Σ)

* commits per second (from τ) and per Θ-range
* average write-set size
* commit failure rate
* transactional consistency violations (should be 0)

---

##### Control Metrics (Δ)

* branch predictability
* decision tree depth
* misclassification counts

---

##### Policy Metrics (Ψ)

* policy evaluation frequency
* policy violations over time
* mode changes (Ω transitions)

---

##### Isolation Metrics (Χ)

* cross-context calls
* isolation boundary crossings
* restricted-access traps

---

#### 13.4.6 Logging Model (Operator-Tagged Logging)

Logs in PMS are operator-tagged events.

Example log record:

```json
{
  "op": "Φ",
  "timestamp": 88213,
  "frame": "kernel_trap",
  "role": "kernel",
  "exception": "DIV_ZERO",
  "pc": "0x8040123",
  "detail": "division by zero at user frame"
}
```

Here `timestamp` is drawn from τ in the meta-state; the ordering relative to other events is given by Θ.

Logs are structured and machine-parseable by design because:

* PMS-IR is operator-tagged
* PMS-CPU ISA is operator-tagged
* PMSL runtime emits operator-tagged events

---

#### 13.4.7 Operator-Aware Distributed Tracing

Across nodes, traces include:

* frame id (□, node-specific)
* role/capability (Ω)
* Θ-ordered indices (with τ-based clocks or vector clocks if needed)
* isolation boundaries (Χ → process, container, VM, domain)
* recontextualization flows across nodes (Φ)
* commit boundaries (Σ)

This yields strongly structured distributed traces.

---

#### 13.4.8 Debugging & Observability for Kernel and Drivers

Kernel debugging relies heavily on:

* Φ (trap events)
* Ω (role switches)
* Χ (process isolation)
* Δ (scheduler decisions)
* Σ (commit of scheduling or memory operations)

Driver debugging focuses on:

* interrupts (Φ)
* DMA boundaries (□)
* device isolation (Χ)
* policy checks (Ψ)

---

#### 13.4.9 Developer APIs (PMSL Debugging Interface)

PMSL offers built-in debugging primitives:

```text
debug.trace(op?)        -- subscribe to specific operator events
debug.step()            -- Θ-step
debug.break(condition)  -- Δ breakpoint
debug.snapshot()        -- Σ snapshot
debug.revert(id)        -- restore Σ snapshot
debug.inspect(object)   -- inspect frame/role/policy
debug.time()            -- query τ-based time in meta-state
debug.wait()            -- Λ wait
debug.policy()          -- Ψ policy info
```

---

#### 13.4.10 Summary

PMS debugging and observability are not bolted on —
they are inherent in the semantics of Δ–Ψ:

* Θ → ordering backbone, sequencing, stepping; τ in meta-state provides the underlying time reference for profiling and timestamps.
* Σ → commit, checkpoints, reverse debugging.
* Δ → control-flow structure and breakpoints.
* Φ → exception/trap visibility.
* Χ → isolation introspection.
* Ω / Ψ → security-governance instrumentation.

The result is a clean and powerful debugging architecture.

---

### 13.5 Simulation / Emulation Environment (PMS-UM/CPU Simulators)

*A unified, operator-typed simulation stack for correctness, debugging, research, and formal verification.*

A PMS system cannot be properly developed without first-class simulators — and because PMS is an operator-semantic architecture (Δ–Ψ), simulation becomes unusually powerful and structurally clean.

This section defines the architecture, semantics, and tooling for:

* PMS-UM simulators (universal machine, abstract execution)
* PMS-CPU simulators (ISA-level emulation)
* Hybrid simulators (mixed abstract/ISA)
* Deterministic vs. nondeterministic execution modes
* Debug hooks (Θ/Σ), policy hooks (Ψ), and isolation semantics (Χ)
* Replay, execution-order dilation, symbolic execution paths
* Scenario generation for verification and security

---

#### 13.5.1 Simulation Goals

PMS simulation is designed to support:

##### (1) Correctness

* validate PMSL programs
* validate kernel subsystems
* validate device drivers
* ensure correct execution order (Θ)
* check that isolation (Χ) and policy (Ψ) constraints never break

##### (2) Performance Exploration

* test various scheduling algorithms (Θ)
* analyze memory behaviors, caches, frame churn (□)
* study commit frequencies and transactional behaviors (Σ)

##### (3) Security & Governance Analysis

* explore privilege transitions (Ω)
* model policy violations (Ψ)
* simulate attack and failure scenarios using synthetic Φ events

##### (4) Language Runtime Testing

* PMSL → IR → PMS-CPU pipeline testing
* FFI integration behavior
* module loading and recontextualization semantics (Φ)

Because PMS execution is typed at the operator level, simulation has complete semantic fidelity.

---

#### 13.5.2 PMS-UM Simulator (Abstract Machine Simulation)

The PMS-UM simulator is the lowest-level semantic reference, independent of ISA details.

A UM simulation step is exactly:

`(s, π) => (s', π)`

Where `s` is the full PMS-UM state tuple:

` s = (s_c, f, r, P, m, ip)`

* `s_c` — core state
* `f` — frame stack / frame configuration
* `r` — role state
* `P` — active policies
* `m` — meta-state (including τ)
* `ip` — instruction pointer / operator pointer

##### UM Simulator Features

###### A. Operator-Typed Execution

The simulator does not execute “instructions” but operator events:

* Δ — distinction step
* ∇ — mutation step
* □ — frame switch
* Λ — timeout / non-event
* Α — macro expansion
* Ω — role transition
* Θ — ordering progress
* Φ — reframe / trap injection
* Χ — isolate / sandbox
* Σ — commit
* Ψ — policy evaluation

Each step logs structured events (as in the observability model).

###### B. Deterministic vs. Non-Deterministic Mode

The simulator can run in:

* deterministic UM mode — all nondeterminism resolved by a fixed scheduler
* non-deterministic UM mode — branching runs, trace trees

This allows automated exploration of valid paths.

###### C. History Tracking

The meta-state `m` stores operator history for dependency validation (for example, Δ → ∇, Θ → Λ, etc.).

###### D. Instrumented Frames (□)

* reveal address-space views
* reveal isolation boundaries (Χ)
* detect illegal frame transitions based on policies (Ψ)

###### E. Reproducible Runs

All runs can be replayed from Σ commit checkpoints.

---

#### 13.5.3 PMS-CPU Simulator (ISA-Level Execution)

The PMS-CPU simulator emulates full ISA semantics from section 2:

* fetch/decode = Δ
* execution = ∇
* frame operations = □
* privilege = Ω
* traps = Φ
* ordering steps = Θ
* isolation = Χ
* commit = Σ
* policy enforcement = Ψ

##### Instruction Execution Model

For each simulated instruction:

1. Δ: decode and operand distinction
2. Ω: capability check
3. Ψ: policy pre-check
4. ∇ / □ / Φ / Χ: apply instruction semantics
5. Σ: commit point
6. Θ: increment logical ordering index

This pipeline captures all PMS semantics structurally.

---

#### 13.5.4 Hybrid Simulator (UM + CPU)

PMS systems may be evaluated at either:

* abstract operator level (UM)
* ISA level (CPU)

A hybrid simulator integrates both:

* high-level PMSL → IR runs in UM mode
* IR → PMS-CPU mapping executed in CPU mode
* both traces unify because they are operator-tagged

This enables round-trip consistency checking:

`UM-level semantics == CPU-level semantics`

This is essential for language correctness proofs.

---

#### 13.5.5 Configuration & Scenario Testing

Simulation environments can define scenario scripts that inject external events.

##### Event Injection (Φ / Λ)

* timer interrupts
* device interrupts
* exception triggers
* synthetic faults
* timeouts

Example:

```text
inject Φ exception=IO_FAULT at t=120
inject Λ when waiting_on="net.recv"
```

##### Role/Capability Scenarios (Ω / Ψ)

Simulate changes in privilege:

```text
inject Ω role=Elevated for 3 ticks
inject Ψ policy_violation="fs.read.restricted"
```

##### Isolation Scenarios (Χ)

Simulate sandbox enter/exit:

```text
inject Χ enter context=vm1 at t=60
```

This allows systematic stress-testing of kernel, filesystem, network stack, and other subsystems.

---

#### 13.5.6 Symbolic Execution (Optional)

Because every operator has rigid semantic meaning, symbolic execution becomes clean:

* Δ → symbolic branch conditions
* ∇ → symbolic state updates
* □ → symbolic environments
* Ω → symbolic privilege state
* Φ → symbolic context transitions
* Ψ → symbolic invariant constraints

Symbolic execution enables:

* path exploration
* constraint solving
* security ceiling proofs (unreachability)
* formal contract verification.

---

#### 13.5.7 Execution-Order Dilation & Virtual Time (Θ + τ)

The simulator controls Θ-step scheduling and the τ fields representing virtual time, instead of being tied directly to real wall-clock time:

* accelerate execution (more Θ steps per real second, τ advanced synthetically)
* freeze execution order for debugging (pause Θ, hold τ)
* replay with different Θ interleavings (nondeterministic concurrency tests)
* enforce fairness constraints as Ψ-policies over Θ and τ

This allows:

* deterministic replay of originally nondeterministic runs
* time-travel debugging
* scheduling algorithm evaluation

---

#### 13.5.8 Simulation of Multiprocessing & Isolation (Χ + Θ)

A multi-core PMS simulator is built by:

* representing each core as a separate Θ-thread (ordered execution stream)
* using Χ to create isolated cores or partitions
* using Θ interleaving rules to simulate concurrent execution

Isolation semantics ensure:

* no core violates memory/frame isolation
* shared memory accesses follow Σ + Ψ memory model rules
* scheduled interleavings obey deterministic / nondeterministic modes

---

#### 13.5.9 Trace Unification for Multi-Level Observability

All simulators produce unified operator-tagged traces:

`trace = ⟨(o_i, t_i, meta_i)⟩`

UM and CPU traces merge perfectly because:

* both describe Δ–Ψ transitions
* both maintain Θ-step indices
* both record Σ commit boundaries
* both record isolation/context/role/policy state

This gives a single, coherent observability backbone for all layers of the system.

---

#### 13.5.10 Simulator API (Minimal)

A generic API:

```text
sim = Simulator(mode="UM"|"CPU"|"Hybrid")

sim.load(program)
sim.set_initial_state(state)
sim.run(max_steps=?)
sim.step()
sim.step_until(op=Σ)
sim.inject(event)
sim.snapshot()
sim.restore(id)
sim.trace(filter?)        -- Δ, Φ, Θ, Σ, …
sim.export_trace()
sim.verify(properties)    -- uses section 11.3 verifier
```

The same API is available to:

* PMSL compilers
* kernel tests
* driver tests
* network stack tests
* model checkers
* security/governance auditors

---

#### 13.5.11 Summary

The PMS simulation environment:

##### Unifies abstract and ISA execution

via operator-tagged semantics.

##### Supports deterministic and nondeterministic runs

for both correctness and adversarial exploration.

##### Provides powerful introspection

via Θ, Σ, Ψ, Χ instrumentation with τ-based time where needed.

##### Is deeply tied to verification

via symbolic execution, path exploration, and invariant checking.

This completes the Tooling & Verification chapter.

---

## 14 Boot & Deployment

### 14.1 Boot Sequence (Δ → … → Ψ)

#### *From bare hardware/VM image to a fully running PMS-OS kernel*

The PMS boot process is not described in terms of firmware quirks or silicon details; instead, it is a structured ascent through the PMS operator hierarchy.
Every stage corresponds to a well-defined operator class, building an increasingly constrained action space until the kernel invariant (Ψ) takes over.

Boot becomes a formal Δ→…→Ψ chain:

`Δ ⇒ □ ⇒ Ω ⇒ Θ ⇒ ∇ ⇒ Χ ⇒ Φ ⇒ Σ ⇒ Ψ`

We walk this in exact structural order.

---

#### 14.1.1 Stage 0 — Δ: Distinguish Hardware / VM Identity

*(Platform bring-up)*

The bare machine, physical or virtual, exposes only raw state.
The earliest boot code performs Δ-distinctions.

Hardware identity:

* CPU type, ISA level
* frame layout capability (paging, segmentation)
* device presence
* memory ranges
* boot medium (disk, network, firmware, ROM)

PMS-CPU identity:

* operator availability (does CPU support Χ isolation, Σ atomics, etc.?)
* privilege modes recognized (Ω mapping)

Boot distinctions map into a hardware capability structure:

`H = Δ(cpu, mem, frames, devices, features)`

These distinctions are not operational yet; they merely classify the substrate so later stages can reason about it.

---

#### 14.1.2 Stage 1 — □: Establish Initial Frame (Boot Frame)

*(The root execution context)*

Boot firmware sets up a boot frame:

`f0 = □(boot memory segment)`

This is the first true PMS context:

* code frame (where bootloader lives)
* data frame (heap/scratch)
* device frame (memory-mapped I/O)

The OS is not yet running; we have simply bounded the region in which early code executes.

---

#### 14.1.3 Stage 2 — Ω: Enter Privileged Role (Early Kernel Mode)

*(Assign asymmetry: privileged boot context)*

Once inside the boot frame, the machine authorizes the initial role:

`r0 = Ω(BootSupervisor)`

Meaning:

* full access to memory
* access to frame table
* permission to install policies later
* ability to execute privileged opcodes

Boot is impossible without Ω: the system must clearly mark who has authority.

---

#### 14.1.4 Stage 3 — Θ: Activate Ordered Execution & τ Reference

*(Initialize execution ordering and attach a time reference in meta-state)*

Before performing any non-trivial ∇-operations, we must establish ordered progression and the corresponding τ component in the meta-state:

`m.τ := τ0;  Θ_boot_step`

The bootloader initializes:

* CPU cycle counter and other hardware clocks, feeding τ
* timer interrupts (if hardware supports), updating τ in `m.τ`
* boot scheduling model (single-thread sequential ordering via Θ)

From now on, memory and I/O operations are observed along a well-defined Θ-ordered execution trace; τ in `m.τ` holds the actual hardware or virtual time values that may be sampled by later stages.

---

#### 14.1.5 Stage 4 — ∇: Load Kernel Image into Memory

*(State-changing impulse: constructing the live system image)*

This is the first substantial mutation stage:

`∇(load kernel binary into kernel frame)`

Operations include:

* copy kernel sections from boot medium into memory
* initialize kernel data structures
* allocate kernel stack
* prepare early device tree

All ∇ actions are fully privileged (Ω) and occur within the boot frame (□).

---

#### 14.1.6 Stage 5 — Χ: Establish Isolation Domains

*(Create the separation between kernel and user, devices, and virtual subsystems)*

Once the kernel is in memory, the system must formalize isolation:

```text
Χ:
  kernel domain
  user domain
  device subcontexts
  optional VM partitions
```

This includes:

* setting up MMU page tables or segmentation
* marking kernel pages executable and user pages restricted
* creating protected address-space frames
* installing unreachable regions for security

Isolation is a PMS primitive — not a late addition.

---

#### 14.1.7 Stage 6 — Φ: Context Switch From Boot Context → Kernel Context

*(Reframe the world: enter the kernel proper)*

The kernel is now loaded but not yet running as itself.
Φ performs the recontextualization:

`Φ(switch from boot frame f0 → f_kernel)`

This includes:

* dropping BootSupervisor role
* entering KernelSupervisor role
* switching to kernel stack
* switching instruction pointer to kernel entry symbol
* installing kernel exception/trap tables

Φ is the formal transition from “bootloader environment” to “kernel environment”.

---

#### 14.1.8 Stage 7 — Σ: System-Wide Integration / Commit

*(Stabilize early state into a coherent operational baseline)*

Before services start, the system must commit its early configuration:

`Σ_kernel_init`

Meaning:

* lock kernel memory map
* finalize device enumeration
* seal early kernel structures
* transition from provisional allocation to stable runtime allocation
* flush relocation tables

After Σ, the kernel is in its first consistent state.

This is the formal moment where “the kernel exists.”

---

#### 14.1.9 Stage 8 — Ψ: Install Global Policies (Kernel Invariants)

*(The final and defining step of PMS boot)*

The kernel now installs the system’s invariants:

`Ψ_install(SecurityPolicy, SchedulingPolicy, IsolationPolicy, FSPolicy, …)`

Typical invariants:

* user mode cannot access kernel frames
* interrupt handlers must run in privileged role
* no execution from writable pages
* scheduling fairness is enforced
* isolation between processes is mandatory
* kernel data structures cannot be mutated except by kernel code

Ψ binds the system:
after activation, not all legal PMS operator sequences remain allowed.
The OS becomes a governed structure.

Many systems “boot” before Φ or Σ; PMS-OS only exists after Ψ binds.

---

#### 14.1.10 Summary of Boot as Δ→Ψ Ascent

| Stage | PMS Operator | Meaning                                                         |
| ----- | ------------ | --------------------------------------------------------------- |
| 0     | Δ            | classify hardware and boot capabilities                         |
| 1     | □            | establish boot frame                                            |
| 2     | Ω            | authorize privileged boot role                                  |
| 3     | Θ            | activate ordered execution and attach τ reference in meta-state |
| 4     | ∇            | load kernel and mutate memory                                   |
| 5     | Χ            | isolate memory and create domains                               |
| 6     | Φ            | enter kernel context                                            |
| 7     | Σ            | commit initial system state                                     |
| 8     | Ψ            | install global policies → kernel becomes authoritative          |

This is the formal PMS boot sequence.

---

### 14.2 Configuration & Policy Bootstrap

#### *How the running PMS-OS kernel absorbs configuration, establishes system-wide Ψ policies, activates Ω role structures, and initializes persistent □ frames.*

Key principle:
boot (14.1) produces a *minimal, policy-capable kernel state*.
Section 14.2 is where the system becomes governed — configured by external inputs, persistent system state, and admin-level policies.

We describe the bootstrap in strict PMS operator order.

---

#### 14.2.1 Overview: Post-Boot Initialization as a Ψ-Centered Pipeline

After Σ (kernel commit), the system is coherent but empty of configuration.
To become a usable OS, the kernel must integrate configuration → generate roles → build policy graphs → bind invariants.

This phase uses the core trio:

* Δ — load and parse configuration distinctions
* □ — assemble configuration frames
* Ω — instantiate role and capability model
* Ψ — activate full policy model
* Σ — commit final system configuration

This becomes a reproducible chain:

`Δ → □ → Ω → Ψ → Σ`

---

#### 14.2.2 Step Δ — Load and Distinguish Configuration Sources

Configuration enters the system via distinctions in operator space.
Typical sources:

1. boot configuration (kernel parameters, sysctl seeds, command line)
2. system configuration files (for example, `/etc/pms/system.conf`)
3. policy bundles (security, memory, scheduling, IPC)
4. user account manifests
5. module or service descriptors

Each is parsed as Δ operations:

`Δ_cfg: read raw config → extract key distinctions`

Examples:

* `scheduler = "priority"`
* `default_user_role = "Standard"`
* `filesystem.root.label = "pms-os"`
* `networking.enable = true`

Key property:
Δ loads configuration, but does not yet act on it.

---

#### 14.2.3 Step □ — Construct Configuration Frames

Configuration distinctions are grouped into frames (contexts) so later operations reason about them consistently.

The kernel produces a structured set:

`F_cfg = { f_system, f_network, f_security, f_fs, f_process, f_users, … }`

Each frame is a □-context representing:

* system-wide settings (time, locale, tick rate)
* kernel behavior (memory layout, MMU mode, scheduling mode)
* subsystem config (network, storage, IPC, security)
* identity and authentication config

Frames give semantic locality.
When a module or service is initialized, it enters the relevant frame.

Example:

`□.enter(f_security)`

means all subsequent Ω, Ψ, Σ operations interpret configuration within the “security” context.

---

#### 14.2.4 Step Ω — Instantiate Role & Capability Graph

Once configuration frames exist, the system synthesizes the Ω-role graph:

`R = Ω(roles from config)`

Examples:

* `root`, `system`, `daemon`, `user`, `nobody`
* subsystem roles: `netd`, `fsd`, `authd`, `sched`
* hardware roles: `driver.usb`, `driver.pci`, etc.

Ω builds:

##### (1) Capability sets

Mapping roles to capabilities:

* filesystem: read/write/exec on namespaces
* network: bind/listen/send
* process: fork/kill/signal
* kernel: privileged operations allowed only to system roles

##### (2) Hierarchy / inheritance

Ω generates directed asymmetries such as:

`root > system > daemon > user > nobody`

##### (3) Boundary rules

For example:

* user cannot write kernel frames
* daemon cannot alter policy frames
* nobody has only read access to public resources

Ω is thus the graph-building operator for system authority.

---

#### 14.2.5 Step Ψ — Activate Policies (Invariants)

This is the decisive phase:
once Ψ activates system policies, the kernel becomes governed.

Policies come from:

* static kernel policy templates
* configuration files
* admin policy bundles
* module and service supplied policies

Ψ merges them:

`Ψ_activate(P_kernel, P_config, P_services)`

Ψ enforces:

##### (1) Access control policies

* role → capability checks
* cross-frame access restrictions
* user isolation
* process ↔ kernel boundary invariants

##### (2) Memory and isolation policies

* allowed frame transitions
* forbidden direct writes
* sandbox behavior for processes

##### (3) Scheduling policies

* fairness invariants
* maximum CPU consumption per role
* priority ceilings and floors

##### (4) Filesystem policies

* write restrictions
* mount options
* namespace visibility

##### (5) Network policies

* allowed outbound and inbound channels
* firewall-like structural constraints
* routing rules

Ψ sets hard global invariants that change what operator sequences are legal.

Before Ψ, the kernel can do nearly anything (Ω determines who may).
After Ψ, the kernel must obey the policy lattice; illegal transitions become blocked.

---

#### 14.2.6 Step Σ — Commit Configuration into Live System State

Once Ψ completes, the configuration becomes live and persistent:

`Σ_cfg_commit`

Σ merges:

* configuration distinctions
* configuration frames
* role and capability graphs
* policy sets
* subsystem initial states
* kernel structures

into a coherent operational baseline.

Σ also:

* finalizes subsystem initialization
* notifies services that configuration is ready
* starts user-mode or service-mode runtime

Σ is the moment the OS enters operational normal form.

---

#### 14.2.7 Post-Bootstrap: Policy Reactivity (Φ + Ψ)

After boot, configuration is not static.
The system supports Φ-recontextualization of policy dynamically:

* updating network configuration
* remounting filesystems
* rotating keys
* upgrading scheduler policies
* enabling or disabling modules

Sequence:

`Φ(updated frame) → Ψ(new invariants) → Σ(commit)`

Φ reinterprets context, Ψ imposes new constraints, Σ stabilizes.

This is how PMS-OS supports hot reconfiguration without reboot.

---

#### 14.2.8 Final Result of Configuration Bootstrap

After `Δ → □ → Ω → Ψ → Σ`:

The system now has:

* a bound role hierarchy
* active global policies
* stable configuration frames
* an isolation and capability model
* kernel and system services initialized
* an authoritative Ψ baseline

---

### 14.3 Upgrade & Migration Patterns (Φ / Σ / Ψ)

#### *Dynamic system evolution through controlled recontextualization, integration, and policy rebinding.*

Upgrades and migrations are not ad-hoc in the PMS architecture.
They follow a strict operator-level discipline:

`Φ (recontextualize) → Ψ (bind policies) → Σ (commit)`

This triplet forms the universal system evolution pipeline.

Upgrades are not interruptions.
They are structured context shifts expressed directly through the core PMS operators.

---

#### 14.3.1 Upgrade / Migration as a Φ-First Process

The essence of Φ:

> Φ changes the interpretation of existing state without discarding it.

This is precisely what upgrades and migrations require.

Examples of Φ-relevant operations:

* switching filesystem version or metadata layout
* upgrading a kernel subsystem (scheduler, MMU mode, driver model)
* changing network protocol version
* reinterpretation of configuration formats
* migrating a persistent representation (filesystem, database, policy store)
* live OS patching (hotfix, microkernel module reload)

Formally:

`Φ_upgrade: (s_c, f, r, P, m) → (s_c', f', r', P', m')`

where the underlying data is preserved, but its meaning, structure, or constraints change.

Φ always prepares the system for a new semantic frame before enforcing invariants.

---

#### 14.3.2 Φ – Types of Recontextualization in Upgrades

##### (1) Frame Migration (□ → □′)

Switch from one frame structure to another:

* filesystem metadata format v1 → v2
* memory frame model change (for example, from segmentation to full paging)
* VM isolation-mode switch (interaction with Χ)

`Φ_frame: □_old → □_new`

No mutation is required yet; only interpretation changes.

---

##### (2) Schema / Layout Reinterpretation

For persistent structures:

* inode layout v3 → v4
* network packet header reinterpretation
* process control block upgrade

Φ establishes a bridge:

`Φ_schema(s_c) = reinterpret(s_c)`

Sometimes followed by actual data migration during Σ.

---

##### (3) Version Activation

Switching active version of:

* scheduler
* network interface driver
* authentication subsystem
* PMSL runtime

Φ loads the new version, flips a context pointer, and marks the old version for retirement.

---

##### (4) Fallback / Rollback Reframes

Failures during migration trigger:

`Φ_fallback: □_new → □_old`

Rollback semantics are integrated with Ψ (policy check) and Σ (commit rollback).

---

#### 14.3.3 Ψ – Policy Rebinding After Recontextualization

Φ alters meaning. Ψ enforces invariants under the new meaning.

After Φ, the system must check:

1. Compatibility of role/capability assignments
2. Forward-compatibility of policies (older policies may be incompatible)
3. Security posture of the new frame
4. Resource limits/quotas remain valid
5. Privilege boundaries remain correct
6. Migration-specific invariants (for example, “must not downgrade isolation mode”)

Thus the system executes something structurally equivalent to:

```text
Ψ_upgrade-check(P, f', s'_c) →
    allow upgrade
    block upgrade
    Φ_fallback + Σ_rollback
```

Ψ acts as the governor of upgrades.

---

#### 14.3.4 Σ – Upgrade Commit (New System Baseline)

Once Φ shifts context and Ψ approves the change:

```text
Σ_commit-upgrade: s' → s_new
```

Σ responsibilities:

##### (1) Finalize Data Migration

If Φ only reinterpreted the layout, Σ actually mutates the persistent structures:

* rewrite filesystem metadata
* update persistent configuration
* convert policy stores
* update thread/process tables
* flush changes to disk

##### (2) Activate New Components

Switch to new:

* kernel modules
* device drivers
* scheduler or MMU mode
* protocol implementation
* runtime libraries

##### (3) Retire Old Structures

Clean up pre-upgrade frames or versions; ensure no stale references remain.

##### (4) Notify Subsystems and Services

Transitions along Θ are emitted to:

* services
* daemons
* userland
* kernel subsystems
* driver frameworks

regarding the new baseline.

After Σ, the upgrade becomes the new system truth.

---

#### 14.3.5 Bootstrapping & Fallback Guarantees

Upgrades must always be:

1. Atomic (Σ ensures indivisibility)
2. Recoverable (Φ rollback paths)
3. Policy-consistent (Ψ approval required)

Sequence:

```text
Φ_prepare → Ψ_validate → Σ_commit
```

Failure-safe via:

```text
Ψ_fail → Φ_fallback → Σ_rollback
```

This makes upgrades and migrations inherently safe, auditable, and policy-bound.

---

#### 14.3.6 Hot vs Cold Upgrades (Both Are Natural)

##### Cold Upgrade (reboot between versions)

* Φ reconstructs state from persistent frames
* Ψ ensures new kernel is compatible
* Σ commits new baseline
* most components restart

##### Hot Upgrade (in-place, live migration)

* Φ swaps live module contexts
* Ψ verifies invariants on live processes
* Σ commits incremental changes
* no reboot required
* PMS structure is particularly strong here because Φ cleanly separates meaning from data

---

#### 14.3.7 Distributed / Multi-Node Migration (Optional)

When PMS-OS runs on multiple nodes:

* Φ coordinates frame reinterpretation across nodes
* Ψ verifies cluster-wide invariants (for example, no partitioning of capability graph)
* Σ commits consistent global state

Later, in “Optional: multi-node boot/orchestration”, this becomes a full model.

---

#### 14.3.8 Summary of PMS Upgrade/Migration Logic

##### Upgrades are Φ–Ψ–Σ sequences:

1. Φ — Recontextualize state

   * new frame
   * new interpretation
   * new version
   * rollback path established

2. Ψ — Validate and bind policies

   * ensure safety
   * ensure compatibility
   * allow or deny transition

3. Σ — Integrate and commit

   * finalize migration
   * activate new system baseline
   * retire old context
   * issue subsystem notifications

---

### 14.4 Multi-Node / Cluster Boot & Orchestration (Optional)

#### *Distributed PMS-OS initialization through Δ → □ → Ω → Ψ → Σ across multiple nodes and shared policy domains.*

A multi-node PMS system is not a special case added on top of the OS.
It is simply PMS operators applied to *multiple machine roots* whose frames, roles, and policies are synchronized.

The same operator grammar — Δ, □, Ω, Θ, Φ, Χ, Σ, Ψ — scales without modification.

---

#### 14.4.1 Conceptual Model: A Cluster as a Higher-Order Frame (□ᴳ)

A cluster is represented as a global frame:

```text
□ᴳ = Frame(nodes, topology, shared policy domain, capabilities)
```

Each node Nᵢ has its own:

* core state (s_cᵢ)
* role set (rᵢ)
* policy set (Pᵢ)
* meta (mᵢ)
* isolation boundaries (Χᵢ)
* local frames (□ᵢ)

Cluster orchestration adds:

* inter-node Δ (distinctions: node identity, readiness, capabilities)
* global □ᴳ (cluster config, placement, topology)
* global Ωᴳ (cluster-level roles and capabilities)
* distributed Ψᴳ (global invariants)
* distributed Σᴳ (cluster-wide commit and logical consistency)

This mirrors single-node boot, but lifted to the cluster level.

---

#### 14.4.2 Δ — Distinguish Nodes, Identity, and Capabilities

Cluster boot begins with a discovery wave:

```text
Δ_discover(N1, N2, …, Nk)
```

Performed via:

* network beacons
* registry queries
* fixed topology lists
* out-of-band control channels

Each node self-advertises:

* node ID
* hardware capabilities
* available storage
* roles it can serve (Ω)
* version information for drivers, kernel modules, PMSL runtime

All this is represented as Δ distinctions.

Δ does not connect nodes — it only maps them.

---

#### 14.4.3 □ — Build Cluster Frames (Topology, Shards, Services)

Next, Δ outputs are arranged into structured frames.

Cluster frames:

* □ᴳ.topology — cluster graph (edges, latency classes, partitions)
* □ᴳ.services — service placement frame
* □ᴳ.storage — global namespace for volumes
* □ᴳ.security — identity domains and trust anchors
* □ᴳ.runtime — task distribution, scheduling domains
* □ᴳ.failure-zones — fault-containment groups

Each node contributes a local □ᵢ, integrated into □ᴳ through:

```text
□_integrate: □ᵢ → □ᴳ
```

This creates the structural context for distributed operation.

---

#### 14.4.4 Ω — Establish Cluster Roles & Capabilities

The cluster defines node-level and global roles.

##### Node-level roles include:

* storage node
* compute node
* network node
* controller node
* auth node
* gateway node

Each has asymmetries:

```text
Ω_node(Nᵢ)
```

assigning capabilities such as:

* allowed to host volumes
* allowed to route traffic
* allowed to execute distributed scheduling decisions
* allowed to issue distributed Ψ policies
* allowed to participate in consensus

##### Cluster-level roles (Ωᴳ):

* orchestrator (global controller)
* consensus node (voter, log replicator)
* coordination node (barrier, lock service)
* observer

Ωᴳ ensures:

* each role is uniquely placed or sharded
* access to shared frames is asymmetrically regulated
* no node performs actions outside its capability envelope

---

#### 14.4.5 Ψ — Global Policies, Invariants, and Consensus

Ψ is the heart of cluster orchestration.

Cluster-wide Ψ includes:

##### (1) Membership policy

Defines conditions for:

* joining
* leaving
* eviction
* quarantine
* recovery

```text
Ψ_membership(Nᵢ) → { allowed, blocked }
```

##### (2) Resource policy

Invariant constraints across the cluster:

* maximum volume replicas
* CPU and memory limits
* load distribution shape
* global quotas

##### (3) Security policy

Cluster trust anchors and identity domains:

* certificate binding
* allowed key-exchange modes
* isolation boundaries across nodes (Χᴳ)
* cluster-wide privilege invariants

##### (4) Consensus policy (Ψᴳ.consensus)

Defines:

* quorum requirements
* election rules
* log consistency guarantees
* commit semantics (Σᴳ)

Ψ enforces that any transition that would violate global invariants is illegal, even if locally valid.

---

#### 14.4.6 Σ — Distributed Commit (Σᴳ)

Cluster-wide Σ is a multi-node integration step:

```text
Σᴳ: (s1, …, s_k) → (s1', …, s_k')
```

using:

* consensus for logically shared state
* barriers for synchronization
* two-phase (or PMS-native) commit for distributed transactions
* global sequence numbers (Θᴳ) for ordered integration

Σᴳ ensures:

* consistent filesystem namespace
* synchronized service topology
* policy invariants persist across the cluster
* upgrades and migrations finish atomically across nodes
* no split-brain states persist

A global commit is performed only when:

```text
Ψ_global(all nodes) = true
```

Σᴳ is thus the distributed version of Σ: cluster-level finalization.

---

#### 14.4.7 Φ — Distributed Recontextualization (Upgrades, Failover, Rebalancing)

Φ handles:

##### (1) Versioned failover

Node failure triggers:

```text
Φ_failover: □ᴳ → □ᴳ_degraded
```

This reinterprets cluster topology without modifying data.

##### (2) Rolling upgrades

Version transitions:

```text
Φ_upgrade(Nᵢ): fᵢ → fᵢ_new
```

Θ sequences orchestrate rollout order.

##### (3) Sharding / resharding

Move responsibilities:

```text
Φ_reshard: □ᴳ.services → □ᴳ.services'
```

Then Σᴳ finalizes the reassignment.

##### (4) Network reinterpretation / route migration

Topology changes and route re-evaluation.

---

#### 14.4.8 Θ — Distributed Temporal Coordination

Cluster-wide execution ordering is modeled by Θᴳ, while the associated cluster temporal reference τᴳ (in the cluster meta-state) holds logical clocks, timer metadata, and heartbeat timestamps.

Together Θᴳ and τᴳ support:

* propagation of ordering ticks (Θᴳ) that drive updates in τᴳ
* drift estimation and compensation in τᴳ, based on ordered observations
* event ordering across nodes via Θᴳ edges
* distributed timers, heartbeat schedules, and timeout budgets stored in τᴳ and evaluated along Θᴳ
* timeout conditions for Λ events computed from τᴳ within the Θᴳ-ordered execution

Θᴳ ensures globally consistent ordering for:

* consensus logs
* replicated state machines
* cluster-wide Σ commits
* distributed scheduling
* multi-node upgrades (Φ)

---

#### 14.4.9 Χ — Cross-Node Isolation Domains

Distributed isolation types:

##### (1) Fault domains

Χ separates power zones, racks, availability zones.

##### (2) Security domains

Cluster RBAC boundaries enforced across nodes.

##### (3) Workload isolation

Tenant separation at cluster level.

Χᴳ ensures:

* failure propagation is controlled
* security roles remain local unless explicitly exported
* workloads can be contained

---

#### 14.4.10 Full Multi-Node Boot Sequence Summary

The cluster boot pipeline:

```text
Δᴳ → □ᴳ → Ωᴳ → Ψᴳ → Σᴳ
```

Step summary:

1. Δᴳ — discover nodes, distinguish capabilities
2. □ᴳ — build global cluster context
3. Ωᴳ — assign global roles, capabilities, responsibilities
4. Ψᴳ — enforce cluster-wide invariants
5. Σᴳ — commit cluster baseline
6. (optional) Φ for upgrades, failure reframes, topology changes
7. Θᴳ — coordinate ordered progression across nodes, in conjunction with τᴳ
8. Χᴳ — enforce distributed isolation

After Σᴳ:
the cluster reaches operational normal form.

---

## 15. Finalization & Spec Epilogue

### *Unifying Statement, Guarantees, and Canonical Closure of the PMS-STACK Architecture*

The preceding sections define a complete, axiomatic, layered IT architecture whose foundation is the 11 PMS operators (Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ).
This final section closes the specification by:

1. unifying the layers into a single coherent architecture,
2. stating formal guarantees achieved by the PMS model,
3. defining completeness conditions,
4. defining extensibility conditions,
5. stating equivalence to classical computational, OS, and distributed models,
6. marking the specification as internally consistent and closed.

This section is intentionally short and definitive.

---

### 15.1 Unified Stack Overview (Top-to-Bottom)

Across sections 0–14, PMS-STACK establishes a full architecture:

```text
PMS Operators (Δ–Ψ)
    ↓
Monoid + Dependency System (0.3)
    ↓
PMS-UM (Universal Machine, 1.x)
    ↓
PMS-CPU (Virtual Hardware, 2.x)
    ↓
PMS-OS Kernel (3.x)
    ↓
Memory, Storage (4.x)
    ↓
IPC, Events, Devices (5–6)
    ↓
Networking Stack (7.x)
    ↓
Security & Governance (8.x)
    ↓
PMSL Language & Runtime (9–10)
    ↓
Tooling, Verification, Simulation (11.x)
    ↓
Boot & Deployment (12–14)
```

These layers are not independent modules but structured projections of the same operator algebra.

Every IT layer behaves as a *restricted PMS-UM instance*.

---

### 15.2 What Has Been Proven / Established

The spec establishes:

#### (1) A Universal Operational Semantics

Every IT mechanism – CPU instruction, syscall, trap, message, filesystem operation, network exchange – is representable as a PMS operator sequence respecting the dependency grammar.

This gives the system:

* semantic uniformity
* formal analyzability
* provable invariants
* safe extensibility

#### (2) Turing-Completeness

Section 1.3 gives a constructive embedding of deterministic Turing machines into PMS-UM.
Therefore, PMS-UM is Turing-complete.

#### (3) A Unified Model for Hardware, OS, Language, Network, Security

Instead of separate conceptual frameworks (ISA, kernel design, protocol stack, RBAC, etc.), PMS-STACK shows that:

> all IT constructs reduce to controlled compositions of
> `Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ`.

Each IT-level construct is simply a structural special case.

#### (4) Deterministic and Non-Deterministic Execution as Structural Modes

PMS explicitly encodes:

* deterministic machines
* non-deterministic machines
* environment-driven systems
* concurrent interleavings
* distributed consensus systems

All follow the same reduction semantics.

#### (5) A Unified Security Model

Identity → roles → capabilities → policies → commit
is structurally:

```text
Δ → Ω → Ψ → Σ
```

Security emerges as operator ordering, not bolted-on rules.

#### (6) A Complete Systems Architecture

Sections 2–14 collectively define a full operating system:

* PMS-CPU (machine)
* PMS-OS kernel (supervisor)
* memory, storage, IPC, drivers
* networking stack
* security and governance
* language and runtime
* verification tools
* boot and cluster orchestration

All grounded in PMS-UM.

---

### 15.3 Completeness Conditions

The specification is complete when:

1. All PMS operators have explicit ISA-level representatives
   (done: 2.2).

2. All OS-level mechanisms map to operator sequences
   (done: sections 3–6).

3. Language constructs map cleanly to CPU operations via PMSL → IR → ISA
   (done: 9.x and 13.1).

4. Global invariants Ψ are definable at all layers
   (done: 3.1, 9.4, 10.x, 14.x).

5. Σ commits define clear integration semantics for:

   * memory operations
   * IPC
   * filesystem
   * transactions
   * distributed consensus

   (done across 2.2.11, 3.8, 4.5, 7.x, 13.x, 14.4).

6. Boot produces a normal-form operational cluster state
   (done: 14.1–14.4).

These six conditions ensure the framework is self-contained.

---

### 15.4 Extensibility Conditions

New features can be added only if:

1. They reduce to sequences of the 11 operators,
2. They obey dependency constraints (section 0.3),
3. They do not require new primitive operators,
4. Any new instruction or system behavior fits cleanly into:

   * Δ for distinctions,
   * ∇ for mutations,
   * □ for contexts,
   * Λ for absence-handling,
   * Α for patterns,
   * Ω for role asymmetry,
   * Θ for ordering of execution steps,
   * Φ for recontextualization,
   * Χ for isolation,
   * Σ for integration,
   * Ψ for invariants.

If a proposed mechanism cannot be expressed using this operator algebra, the mechanism is *not part of PMS-STACK*.

This guarantees long-term stability and prevents architectural drift.

---

### 15.5 Equivalences to Classical Frameworks

PMS-STACK is sufficient to express:

#### Classical Computation

* deterministic Turing machines
* nondeterministic Turing machines
* λ-calculus
* register machines
* pushdown automata
* actor models

#### Classical OS Theory

* POSIX-like process model
* capabilities systems
* microkernels
* monolithic kernels
* virtualization

#### Distributed Systems

* Paxos / Raft
* CRDTs
* state-machine replication
* eventual consistency
* strong consistency
* leader election

#### Language Theory

* imperative
* functional
* capability-secured
* transactional languages

PMS operators are *orthogonal primitives*: these classical models appear as specializations, not additions.

---

### 15.6 Canonical Closure: The PMS Normal Form of Computation

We can now define the PMS Normal Form:

```text
w = Δ* ; Ω* ; □* ; (Θ* ∇* Λ* Φ* Χ*)* ; Σ* ; Ψ*
```

with the dependency constraints from 0.3.

Every legitimate PMS-STACK execution — from hardware fetch/decode to cluster-wide distributed commit — reduces to such sequences.

This is the canonical form of all computation in the PMS-STACK system.

---

### 15.7 Epilogue Statement

PMS-STACK is now a complete, unified, formally grounded, implementation-ready systems architecture.

It provides:

* a universal operational semantics (PMS-UM),
* a full CPU model (PMS-CPU),
* a complete OS (PMS-OS),
* networking, IPC, FS, memory, scheduling subsystems,
* a programming language (PMSL),
* runtime and libraries,
* debugging, verification, modeling tools,
* boot and distributed orchestration models,
* a unified security and governance system,
* and a strict algebraic foundation based on PMS operators.

The specification is closed, consistent, and internally complete.

From here, the next steps are:

* reference implementation,
* compiler pipeline,
* kernel prototype,
* distributed runtime,
* formal verification suite,
* standard library definition expansion,
* release and documentation generation.

But architecturally and semantically, the PMS-STACK specification is finished.

---

## Appendix A — PMS Operator & Dependency Reference (Δ–Ψ)

Purpose.
This section is the central cheatsheet for all PMS operators Δ–Ψ.
It is meant to serve both as

* a compact human-readable reference, and
* a machine-readable single source of truth for tools
  (together with the `dependency_table` and the YAML/JSON spec in the repo).

---

### A.1 Operator Overview

The following table summarizes, for each operator, its name, intuitive role, coarse type, and typical layers.
(The “Layer” column is intentionally rough – details are given in A.3 and in the respective chapters.)

| Op | Name (EN/DE)               | Intuitive role                                                        | Type | Layer (typical)          | Category                         |
| -- | -------------------------- | --------------------------------------------------------------------- | ---- | ------------------------ | -------------------------------- |
| Δ  | Difference / Distinction   | Distinguish, classify, branch on things                               | Δ    | UM, CPU, OS, PMSL, Dist  | structural / control             |
| ∇  | Impulse / Enactment        | Perform actions, writes, I/O, compute and update steps                | ∇    | UM, CPU, OS, PMSL, Dist  | dynamic / action                 |
| □  | Frame / Context            | Enter, leave, and select frames/contexts                              | □    | CPU, OS, PMSL, VM, Dist  | structural / context             |
| Λ  | Non-Event / Absence        | Timeouts, “nothing happened”, missing events                          | Λ    | CPU, OS, PMSL, Net, Dist | temporal / absence               |
| Α  | Attractor / Pattern        | Recurring patterns, loops, macros, higher-level constructs            | Α    | Compiler, PMSL, OS, Dist | pattern / macro                  |
| Ω  | Asymmetry / Role           | Roles, privileges, capabilities, asymmetric access                    | Ω    | CPU, OS, PMSL, Sec, Dist | security / role / capability     |
| Θ  | Ordering / Progress        | Scheduling, ordering, progress, ticks                                 | Θ    | UM, CPU, OS, PMSL, Dist  | temporal / ordering              |
| Φ  | Recontextualization / Trap | Exceptions, traps, entering handlers, migration, reframing            | Φ    | CPU, OS, PMSL, Dist      | recontext / error / transition   |
| Χ  | Isolation                  | Processes, containers, sandboxes, isolation and visibility boundaries | Χ    | OS, VM, PMSL, Dist       | structural / isolation           |
| Σ  | Integration / Commit       | Commits, transactional end, integrating changes                       | Σ    | OS, FS, DB, PMSL, Dist   | commit / integration             |
| Ψ  | Self-Binding / Policy      | Policies, invariants, governance, global/scoped rules                 | Ψ    | all layers incl. Dist    | policy / invariants / governance |

How to read this appendix:

* A.1 + A.3 together form the operator/layer spread:

  * A.1: “What does this operator mean in general?”
  * A.3: “How does the same operator show up on UM/CPU/OS/PMSL/Dist?”

---

### A.2 Formal Semantics — Operator Fact Sheet

For tools and formal work, each operator comes with a standardized fact sheet.
The schema is the same for all operators; only the content differs:

* Signature (coarse form):
  `op : S → S` or `op : S × Params → S'`
  (Δ/Λ/Θ are mostly “observational”, ∇/Σ are “state-changing”, Ω/□/Χ/Φ/Ψ are “context/policy-changing”.)
* Short description: one plain-text sentence.
* Allowed changes: which components of
  `s = (s_c, f, r, P, m, ip)`
  *may* change and which *must not*.
* Typical preconditions (pre): which other operators/contexts must be “in scope”.
* Typical postconditions (post): which structural effects the operator leaves behind (e.g. “enables commit points”, “sets a timeout marker”, …).

The following table summarizes this compactly
(a more detailed version can be mirrored 1:1 as YAML/JSON):

| Op | Signature (schematic)      | Short semantics (plain text)                                                                | Mutates `s_c`?                                  | May typically change                                       | Typical preconditions (pre)                                                                  |
| -- | -------------------------- | ------------------------------------------------------------------------------------------- | ----------------------------------------------- | ---------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Δ  | `Δ : S × Query → S`        | Observes/classifies state and chooses branches without changing core data.                  | No                                          | `m, ip`                                                    | essentially none; often the minimal semantic prerequisite for other ops                      |
| ∇  | `∇ : S × Act → S'`         | Performs an action (ALU, write, I/O) and changes core data.                                 | Yes (primarily)                             | `s_c, m, ip`                                               | requires: at least one Δ (target/operand distinguished), suitable `Ω`-role, valid `□` frame  |
| □  | `□ : S × FrameInstr → S'`  | Switches or defines the active frame/context without changing core data itself.             | No (core), only view                        | `f, m, ip`                                                 | often requires: appropriate Ω rights, existing frame context                                 |
| Λ  | `Λ : S × Expectation → S'` | Marks the absence of an expected event (timeout, idle, empty queue).                        | No                                          | `m, ip`                                                    | requires: a prior expectation via Θ or Δ/∇ (there must have been *something* to wait for)    |
| Α  | `Α : S × Pattern → S'`     | Expands a structured pattern into a PMS-valid Δ/∇/… word.                                   | Not directly                                | `ip, m` (possibly code/IR)                                 | requires: defined pattern body; inherits the dependencies of its expansion                   |
| Ω  | `Ω : S × RoleΔ → S'`       | Changes roles/capabilities and determines which actions/frames are allowed.                 | No (core), yes for `r`                      | `r, m, ip`                                                 | requires: Δ over capability/role; Ψ must allow the change; Χ boundaries must not be violated |
| Θ  | `Θ : S × Step → S'`        | Performs an ordering/progress step (scheduling, tick, sequence advance).                    | No (core)                                   | `m, ip`                                                    | requires: valid running context; may be guarded by Ω/Ψ                                       |
| Φ  | `Φ : S × Cause → S'`       | Re-contextualizes (trap, exception, migration), saves context and switches frames.          | Maybe (mainly `f, r, P, m`)                 | `f, r, P, m, ip` (and possibly `s_c` on recovery)          | requires: active frame/role/policy to be reframed; often triggered by Δ/Ω/Ψ/Χ/∇              |
| Χ  | `Χ : S × IsoInstr → S'`    | Creates/manages isolation, separates frames/domains and bounds reachability.                | Maybe (isolation structures)                | `f` (graph), `m, r`                                        | requires: active frame; Ω rights for isolation; Ψ must allow the isolation operation         |
| Σ  | `Σ : S × CommitSpec → S'`  | Integrates/commits previously produced changes into persistent state.                       | Yes (commit)                                | `s_c, m, ip` (possibly `f, r` for scope changes)           | requires: non-empty history of Δ/∇/Θ, no forbidden sequences, Ψ-commit conditions satisfied  |
| Ψ  | `Ψ : S × PolicyInstr → S'` | Defines/updates policies or enforces invariants and may forbid otherwise legal transitions. | Maybe (mainly `P`; on violation also `s_c`) | `P, m, ip` (with possible recovery effects on `s_c, f, r`) | requires: Δ over policy, suitable Ω-role; can itself become a precondition for other ops     |

Conventions for the rest of the document:

* Whenever an instruction `I = (op, pre, post)` appears, then:

  * `op` is one of `{Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}`,
  * `pre` is at least as strong as the typical preconditions of `op`,
  * `post` respects the “may change / must not change” constraints for `op`.
* The concrete variants per layer (CPU ISA, kernel, PMSL, distributed) are refined in the respective chapters and in A.3/A.4.
  Appendix A remains the canonical overview of the meaning and allowed effects of each operator.

---

### A.3 Layer Mapping

This table shows how the *same* operator manifests across different PMS layers.
It acts as the layer-wise projection of the operator semantics defined in A.1–A.2.

| Op | UM (Unified Model) | CPU                         | OS                                 | PMSL                   | Distributed (G)             |
| -- | ------------------ | --------------------------- | ---------------------------------- | ---------------------- | --------------------------- |
| Δ  | State partitioning | Decode, type classification | Object/frame types, ACL entries    | Types, pattern matches | Node/Shard ID, partitioning |
| Σ  | Commit point       | Writeback, memory barrier   | Transaction end, filesystem commit | `commit { … }`         | Consensus commit            |
| …  | …                  | …                           | …                                  | …                      | …                           |

Layout idea.
A.1 and A.3 together form the two-page operator spread:

* Page 1: Operator Overview (A.1) + quick legend
* Page 2: Layer Mapping (A.3) + a pointer to the homomorphisms described in B.5

This helps readers see both the *abstract meaning* of each operator and its *concrete manifestations* across the stack.

---

### A.4 Dependency Table

Dependencies are presented in two complementary forms:

---

#### 1. Human-readable matrix

This table summarizes, for each pair of operators, whether one requires, affects, or forbids another.

| From \ To | Δ | ∇ | □ | Λ | Α | Ω | Θ | Φ | Χ | Σ | Ψ |
| --------- | - | - | - | - | - | - | - | - | - | - | - |
| ∇         | R | – | R | A | … | R | … | A | R | R | R |
| …         |   |   |   |   |   |   |   |   |   |   |   |

Legend

* R — requires
  May only occur if at least one such operator is already in scope.
  (Example: ∇ typically requires Δ, Ω, □, Ψ.)

* A — affects
  Modifies the scope, status, or validity of the target operator.
  (Example: ∇ affects Σ by producing committable state.)

* F — forbidden
  Indicates a semantically invalid sequence.

* blank — neutral
  No structural relation.

This matrix is the *readable* view; the canonical truth lives in the machine-readable file.

---

#### 2. Machine-readable specification (authoritative)

A single YAML/JSON file in the repository—the canonical specification that tools should consume.
Appendix A simply presents a formatted view of this file.

Example excerpt:

```yaml
dependencies:
  "∇":
    requires: $$
"Ω", "Ψ"
$$
    affects: $$
"Σ"
$$
    forbidden_after: $$
"Λ"
$$

  "Φ":
    requires: $$
"□"
$$
    affects: $$
"□", "Ω"
$$
```

Notes:

* The YAML/JSON version is exhaustive; the table in the book can be partial or summarized.
* Tools (linters, compilers, verifiers, simulators) should treat the YAML as the primary authority.
* A.4 unifies syntactic constraints (ordering), semantic constraints (scopes), and policy constraints (Ψ) in a single declarative structure.

---

### A.5 Operator Lattice & Partial Order

This subsection introduces a lightweight structural order over the operator alphabet Δ–Ψ.
Its purpose is not to prove anything heavy here (the real formal work is in Appendix B), but to give readers an intuitive, visual sense of how operators relate to one another.

#### A.5.1 Preorder on Operators

We define a preorder `≼` on the operator set O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}.

A simple and useful intuition is:

> “Structure precedes action, which precedes commit, which is governed by policy.”

Formally, we introduce a coarse ordering:

```
structural   ≼   dynamic   ≼   commit   ≼   policy
```

where:

* Structural operators:
  `{Δ, □, Ω, Χ, Ψ}`
* Dynamic/procedural operators:
  `{∇, Θ, Λ, Φ, Σ, Α}`

Ψ appears in both lists depending on perspective, but in the preorder it occupies the *highest governance position.*

#### A.5.2 Visual Lattice (informal)

A conceptual diagram (included in the book as a simple Hasse-like diagram) might look like:

```
        Ψ (policies / invariants)
                 ↑
        Σ (commit / integration)
                 ↑
   ∇, Θ, Λ, Φ, Α (dynamic actions / progress / traps / patterns)
                 ↑
   Δ, □, Ω, Χ    (structure / frames / roles / isolation)
```

This visualization communicates two things:

1. Structural operators define the semantic space within which all dynamic behavior must operate.
2. Dynamic operators produce effects that are eventually consolidated via Σ (commit).
3. Ψ (policy) constrains and regulates *all* lower layers.

#### A.5.3 Informal Normal Form Claim

We state — *without proving it here* — an important structural fact:

> Every valid PMS sequence can be transformed into a normal form in which structural blocks `Δ, □, Ω, Χ, Ψ` precede dynamic blocks `∇, Θ, Λ, Φ, Σ, Α`.

This does not mean every real program is written that way;
it means that the semantics admit such a rearrangement under the dependency rules of A.4 and the monoid laws discussed in Appendix B.

#### A.5.4 Relation to Appendix B

Appendix B will:

* formalize the preorder using a constrained monoid `(L, ∘, ε)`,
* define equivalence classes of operator words up to permissible reordering,
* and sketch a proof that every valid word in `L` has an associated normal form consistent with the lattice above.

Here, in Appendix A, the goal is simply to give the intuition needed for reading later proofs, tools, and examples.

---

## Appendix B — Monoid & Formal Foundations

Purpose.
This appendix makes the formal foundations—already used implicitly throughout PMS—explicit.
PMS is framed as a constrained monoid `(O*, ∘, ε)` enriched with semantic and typing rules.
We present only the essentials needed for later reasoning (normal forms, homomorphisms, completeness).
This is *not* intended to become a separate theoretical paper.

Audience.
Readers interested in formal methods, denotational models, or tool construction.
Other readers can simply note that *a clean algebraic foundation exists* and skip to later chapters.

---

### B.1 Basic Definition

We begin with the underlying syntactic structure.

* Let
  `O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}`
  be the full PMS operator alphabet.

* Let `O*` be the set of all finite words over `O`:

  ```
  w = o1 o2 … ok   with each oi ∈ O
  ```

* The monoid operation is concatenation `∘`, which is associative.

* The neutral element is the empty word `ε`.

Thus:

```
(O*, ∘, ε)
```

forms the free monoid over the operator alphabet.

#### Optional submonoids

It is often useful to distinguish two large classes:

* `O_struct = {Δ, □, Ω, Χ, Ψ}`
  (operators shaping structure, context, capabilities, isolation, policy)

* `O_dyn    = {∇, Θ, Λ, Φ, Σ, Α}`
  (operators producing effects, recontextualizing, advancing time/order)

These two sets play a key role in the partial order and normal-form intuition of A.5.

---

### B.2 Constraints: from free monoid to PMS monoid

In PMS, not every word over O is valid.
Instead, we define a subset `L ⊆ O*` of well-formed operator sequences.

This turns the free monoid into a constrained monoid:

```
(L, ∘, ε)     with   L ⊆ O*
```

#### B.2.1 Well-formedness rules

These rules ensure that operator sequences adhere to the semantics of PMS.
Examples include:

* No Σ without a preceding dynamic block.
  A commit (`Σ`) must follow some meaningful sequence of `∇` and/or structural setup (Δ, □).

* No Ψ (policy change) outside allowed frames/roles.
  A policy update must occur within a context authorized by `Ω` and scoped by `□`.

* Φ (trap/recontextualization) may appear only when a valid frame exists.

* Isolation (Χ) may not be created or collapsed arbitrarily.
  It must respect role and policy constraints.

These constraints enforce the semantic discipline expressed in A.2 and A.4.

#### B.2.2 Typing rules

Beyond mere well-formedness, PMS sequences must respect typing rules related to the execution layer (A.3):

* Some operators have UM-only meaning (e.g., Δ as abstract classification).
* Some require a CPU context (e.g., ∇ for ALU/I/O actions, Φ for traps).
* Some require an OS or PMSL context (e.g., Σ as FS/transaction commit, Ψ as policy update).
* Some have distributed variants (`opᵍ`) that require a global frame and quorum conditions.

If the layer context does not support an operator, then the word is invalid in that context.

##### Result

Together, well-formedness rules + typing rules produce a constrained language:

```
L = { w ∈ O*  |  w satisfies all well-formedness and typing constraints }
```

with monoid structure inherited from `O*`.

Interpretation.
`L` is the set of admissible PMS programs, instructions, kernel transitions, and distributed steps.
Everything evaluated in PMS—from CPU micro-steps to distributed commits—is representable as an element of `L`.

---

### B.3 Normal Form

We state an informal but essential structural property of PMS programs.

#### B.3.1 Normal-form theorem (informal)

> For every valid PMS word `w ∈ L`, there exists an equivalent word `nf(w)` in normal form:
>
> ```text
> nf(w) ≡ (struct-block)* (dyn-block)* (commit/policy-block)*
> ```
>
> where:
>
> * struct-block contains only `{Δ, □, Ω, Χ, Ψ}`
> * dyn-block contains only `{∇, Θ, Λ, Φ, Σ, Α}`
> * commit/policy-block contains a tail consisting of `{Σ, Ψ}` in an order compatible with dependency constraints.

The normal form preserves the semantics of the original word (up to the equivalence relation defined by the monoid and the dependency rules of A.4).

#### B.3.2 Example rewrite rules

The following rewrite schemata illustrate how normal form can be reached whenever the constraints of A.4 are satisfied:

1. Structural operators commute upward
   (unless forbidden by policy or scope constraints):

   ```
   ∇ Δ  →  Δ ∇
   Θ Ω  →  Ω Θ
   Φ □  →  □ Φ     (if Φ does not depend on the new frame introduced by □)
   ```

2. Dynamic operators commute among themselves
   (subject to ordering or dependency requirements):

   ```
   Θ ∇  →  ∇ Θ     (if Θ does not require the step produced by ∇)
   Α ∇  →  ∇ Α     (pattern expansion can move after action)
   ```

3. Commit/policy operators migrate to the tail

   ```
   Σ ∇  →  ∇ Σ
   Ψ Δ  →  Δ Ψ
   ```

   *provided that the movement does not violate the role/policy/isolation guards.*

These rewrite relations are not exhaustive; they indicate how most reorderings follow the intuition from A.5:
“structure before action before integration/policy.”

#### B.3.3 Relation to A.5

Appendix A.5 introduced a partial order/lattice suggesting that structural operators sit below dynamic ones, which in turn sit below commit/policy operators.
The normal-form theorem is the syntactic reflection of that hierarchy:
operators can be rearranged so long as the dependency rules (A.4) and typing constraints (B.2) allow.

#### B.3.4 Notes on formal proof

A full proof is omitted here.
Appendix B.5 and B.6 provide the elements (homomorphisms, constrained monoid structure) needed for a complete treatment; a full formal proof would belong in a dedicated theoretical paper.

---

### B.4 Turing Completeness (Sketch)

PMS is computationally universal. This subsection provides a high-level justification without going into full formal detail.

#### B.4.1 Constructive route

To demonstrate Turing completeness directly, one can show that the operator set Δ–Ψ suffices to encode:

1. Boolean logic

   * Δ enables branching based on distinctions (tests).
   * ∇ performs value updates.
   * Φ can model conditional jumps via recontextualization.

2. A writable memory cell

   * ∇ writes; Δ distinguishes states; Σ commits persistent transitions.

3. Conditional and looping behavior

   * Δ + Θ provide branching and progression.
   * Α enables macro/loop-like pattern expansion.
   * Φ allows control transfer and exception-like jumps.

With these components, the classical construction of a register machine or a Minsky machine can be encoded using PMS operators alone.

#### B.4.2 Reduction route

Alternatively, show that a known Turing-complete machine can be homomorphically embedded into PMS:

* Let `Instr*` be the instruction language of a register machine (or RAM machine).
* Construct a homomorphism

  ```
  h : Instr* → O*
  ```

  such that:

  * `h` preserves concatenation (h is a monoid homomorphism),
  * `h` preserves operational semantics: executing `I` and executing `h(I)` result in equivalent state transitions.

This requires mapping:

* register increments/decrements → suitable ∇ actions
* conditional jumps → Δ + Φ (branch via distinction + trap/recontextualization)
* memory updates → ∇ + Σ
* program counters → contexts/frames via □

A sketch of such a mapping is sufficient to establish universality.

#### B.4.3 Interpretation

These two paths—constructive encoding and semantic reduction—show that PMS is capable of expressing arbitrary computable functions, regardless of how high-level or constrained the form of PMSL is.

A full formal proof of Turing completeness would require a separate publication; the results summarized here are enough for the design goals of the PMS-STACK system.

---

### B.5 Homomorphisms

To relate PMS semantics across layers, we define a family of structure-preserving mappings (monoid homomorphisms).
Each maps operator words from one abstraction level to an equivalent representation on a lower level while preserving key invariants.

We present them informally but precisely enough for formal-methods use.

---

#### B.5.1 `h_UM→CPU : O* → ISA*`

This homomorphism translates Unified Model operator words into instruction sequences of a PMS-CPU.

Intuition:

```
h_UM→CPU(w1 ∘ w2) = h_UM→CPU(w1) ∘ h_UM→CPU(w2)
h_UM→CPU(ε) = ε
```

Preserved structure:

* Distinctions (Δ) become *decode, classify, branch* instructions.
* Actions (∇) become ALU steps, register updates, memory writes.
* Frames (□) become frame-pointer or segment-switch instructions.
* Roles/Capabilities (Ω) become privilege bits, capability registers, access flags.
* Isolation (Χ) becomes MMU/TLB/ASID manipulations.
* Commit (Σ) becomes writeback, fences, memory-barriers.
* Policies (Ψ) become privilege checks, guard instructions, traps.

The mapping ensures that operator dependencies (A.4) correspond to CPU-enforced constraints:
e.g., `Σ` is only emitted where Σ is semantically valid; `Ω` and `Ψ` become guards that precede ∇ instructions.

---

#### B.5.2 `h_CPU→OS : ISA* → KernelSeq*`

This homomorphism lifts CPU-level traces into OS-level primitives.

Think of it as abstracting away instruction-level detail into system-call-like units:

```
h_CPU→OS(instr1 … instrk) = syscall/exception/scheduler events
```

Preserved structure:

* Φ (trap/recontextualization) becomes exception dispatch, signal/trap handlers.
* Θ (ordering/progress) becomes scheduling ticks or process-switch events.
* Χ (isolation) maps to address-space boundaries, container boundaries, object capabilities.
* Σ (commit) maps to filesystem transaction commit, page-dirtying completion, or IPC message enqueue/dequeue.
* Ω (roles) persists as credential, capability, or access-control state in the OS.

Dynamic events (∇) are aggregated into higher-level OS transitions like “write to file”, “send on channel”, “map/unmap page”.

---

#### B.5.3 `h_OS→PMSL : KernelPrim* → PMSL*`

Finally, kernel-level primitives are projected into PMSL language constructs.

This is the basis for the PMSL execution model and for developer-facing semantics:

```
h_OS→PMSL(kernel-primitive) = PMSL statement or operator block
```

Preserved structure:

* Frames (□) → `frame enter …`, `frame leave`, `with frame F { … }`.
* Policies (Ψ) → `policy with P { … }`, invariant blocks, effect-guards.
* Capabilities/Roles (Ω) → role declarations, capability annotations, access scopes.
* Isolation (Χ) → module boundaries, sandbox declarations, visibility constraints.
* Commits (Σ) → `commit Σ { … }` blocks or transactional constructs.
* Channels + IPC map to PMSL channel primitives with Δ/Ω preconditions embedded in the type system.

The composition

```
h = h_OS→PMSL ∘ h_CPU→OS ∘ h_UM→CPU
```

acts as a semantic pipeline ensuring that high-level PMSL constructs correspond to properly typed low-level traces.

---

### B.6 Optional: Categorical Perspective

For readers with a background in category theory, PMS can be formulated categorically in a straightforward way.

#### B.6.1 Objects and morphisms

* Objects: abstract machine states `S`.
* Morphisms: valid PMS operator words `w ∈ L`.
* Composition: concatenation of words,

  ```
  w₂ ∘ w₁
  ```

  defined whenever the end state of `w₁` is a valid start state for `w₂`.

Thus, `(L, ∘, ε)` forms a category whose identities are empty words and whose morphisms encode transitions.

#### B.6.2 Endomorphisms and commit operators

Commit operators Σ form a distinguished class of endomorphisms:

```
Σ : S → S
```

satisfying:

* idempotence up to equivalence
  (`Σ ∘ Σ ≈ Σ` under semantic equivalence),
* fixpoint property: the committed state no longer changes under further Σ,
* monotonicity with respect to policy Ψ.

These properties allow Σ to be interpreted as a monadic join or closure operator in some categorical formulations.

### B.6.3 Policies as subobject classifiers (informal)

Ψ can be viewed (very loosely) as providing a subobject classifier or a modal structure that marks allowed vs. forbidden transitions.
This connects PMS with modal logics and categorical semantics of effect systems.

#### Purpose of this section

This categorical view is not required for understanding PMS, PMSL, or the operator monoid.
It simply indicates that the formal structure is robust enough to support categorical refinement for readers who wish to work in that direction.

---

## Appendix C — Notation, Symbols & Abbreviations

Purpose.
Provide the authoritative reference for all notation used in PMS-STACK: glyphs, ASCII fallbacks, symbols, abbreviations, and PMSL syntax.
This appendix defines *one canonical truth* for every symbol appearing in the text.

Role.
A required appendix.
This is the notation cheatsheet readers will consult constantly.

---

### C.1 Operators

Every PMS operator has:

* a glyph,
* an ASCII fallback,
* a name,
* and a short semantic role description.

| Glyph | ASCII  | Name             | Short role (semantic intuition)                      |
| ----- | ------ | ---------------- | ---------------------------------------------------- |
| Δ     | DELTA  | Distinction      | Classification, branching, type/context detection    |
| ∇     | NABLA  | Enactment        | Actions, ALU steps, writes, I/O                      |
| □     | FRAME  | Frame / Context  | Enter, leave, or select frames/contexts              |
| Λ     | LAMBDA | Non-Event        | Absence, timeout, missing event                      |
| Α     | ALPHA  | Attractor        | Patterns, macros, loop expansion                     |
| Ω     | OMEGA  | Asymmetry / Role | Roles, capabilities, privileges                      |
| Θ     | THETA  | Ordering         | Scheduling, sequencing, progress                     |
| Φ     | PHI    | Recontextualize  | Traps, exceptions, migrations, reframing             |
| Χ     | CHI    | Isolation        | Visibility, sandboxing, process/container boundaries |
| Σ     | SIGMA  | Commit           | Integration, transactional commit                    |
| Ψ     | PSI    | Policy           | Rules, invariants, governance                        |

Notes

* ASCII fallbacks are mandatory in all machine-facing formats (e.g., YAML/JSON of dependencies).
* When tools cannot render Unicode glyphs, they *must* fall back to the ASCII names above.

---

### C.2 Core Structural Entities

These symbols denote the primary semantic structures appearing throughout PMS-STACK and PMSL.
Definitions are intentionally short—full explanations appear in the main chapters.

| Symbol    | Name                        | Meaning (short definition)                                                         |
| --------- | --------------------------- | ---------------------------------------------------------------------------------- |
| `Frame`   | Frame / Context             | A delimited region of state and execution; governs visibility, policy, role scope. |
| `Role`    | Role / Capability class     | Determines what actions are allowed; governs access to frames, objects, channels.  |
| `Policy`  | Policy / Invariant set      | A set of rules or constraints controlling transitions, visibility, and commits.    |
| `Process` | Process                     | An OS-level unit of execution parameterized by frames, roles, and policies.        |
| `Thread`  | Thread                      | A schedulable subcontext of a process, carrying its own Δ/Θ/Φ timeline.            |
| `Channel` | Channel                     | A typed message-passing medium with Δ/Ω/Σ constraints.                             |
| `CapSet`  | Capability Set              | A set of Ω-granted authorities; governs resource reachability.                     |
| `State`   | `s = (s_c, f, r, P, m, ip)` | The abstract machine state: core state, frame, role, policy, memory/env, pointer.  |

Only structures actually used in the main text should appear here.

---

### C.3 Type Classes

PMSL and the formal model use type families parameterized by operator semantics.

#### Common families

| Family                  | Meaning / Usage Example                                                            |
| ----------------------- | ---------------------------------------------------------------------------------- |
| Δ-type   (`Δ_type`) | Types arising from classification/distinction; often used for guards or branching. |
| Σ-type   (`Σ_tx`)   | Transactional/commit-related types; e.g., `Σ_tx<FileWrite>` for FS operations.     |
| Φ-type   (`Φ_trap`) | Trap/exception types; attaches cause information (faults, migration events, etc.). |

#### Notes

* Type families reflect operator classes; e.g., a Δ-type signals a *structural* constraint, while a Σ-type signals a *transactional* one.
* Tools may rely on naming conventions (`Δ_*`, `Φ_*`, `Σ_*`) to infer invariants or generate formal proof obligations.

---

### C.4 Registers & ISA Notation

This section defines the standard naming conventions used for PMS-aware CPU architectures and their instruction sets.
These names appear in examples, proofs, and homomorphisms (B.5).

#### C.4.1 General-purpose and special registers

| Symbol   | Meaning                                                 |
| -------- | ------------------------------------------------------- |
| `R_pc`   | Program counter / instruction pointer                   |
| `R_sp`   | Stack pointer                                           |
| `R_fp`   | Frame pointer (if distinct from stack pointer)          |
| `R_cap`  | Capability register (Ω-related authority state)         |
| `R_fr`   | Active frame register (□-select / context ID)           |
| `R_role` | Current role or privilege state (Ω)                     |
| `R_flag` | Condition/status flags (Zero, Carry, TrapPending, etc.) |
| `R_tmpN` | Temporary registers, architecture-dependent             |
| `R_iso`  | Isolation-domain selector (Χ)                           |

#### C.4.2 Status/flag registers

Flags relevant to PMS operator semantics include:

* `Z` – result-zero flag (Δ-based branching)
* `T` – trap-pending (Φ)
* `C` – carry / overflow
* `P` – policy-violation indicator (Ψ)
* `I` – isolation boundary flag (Χ)

Architectures may represent these as a single status word (`R_flag`) or multiple smaller flags.

#### C.4.3 Segment, frame, and isolation registers

PMS-aware architectures often expose:

* Frame register (`R_fr`) — selects the active execution/frame context (□).
* Capability/role register (`R_cap`, `R_role`) — the hardware reflection of Ω.
* Isolation domain register (`R_iso`) — boundary identifier for Χ.
* Policy domain register (`R_pol`) — optional, for fast Ψ checks.

These registers anchor the hardware interpretation of the Δ–Ψ operator layer described in Appendix A.

---

### C.5 PMSL Syntax

This section provides a practical syntax reference for PMSL.
It is *not* a full language specification; it is a compact cheat sheet.

#### C.5.1 Reserved keywords

```
frame
enter
leave
with
policy
commit
role
channel
send
recv
spawn
cancel
trap
on
match
```

(Only keywords appearing in the book are listed; the full PMSL specification may define additional ones.)

#### C.5.2 Operator macro notation

Operators may appear:

* explicitly in PMSL (e.g., `commit Σ { … }`)
* implicitly via constructs that expand to operator words (Α-patterns)

Examples:

* `frame enter F` expands to a sequence involving `□` (context change), possible Δ checks, and Ω verification.
* `policy with P { … }` introduces a Ψ-scope enclosing the block.
* `channel<T>` implies Δ-type classification for messages and Σ/Φ behavior for send/receive.

#### C.5.3 Syntax snippets

Minimal examples illustrating the syntax-to-operator mapping:

```pmsl
frame enter F_user {
    // Δ: classify user frame
    // Ω: activate user role
    // □: switch active context
}
```

```pmsl
policy with P_write {
    // Ψ: allow write operations in this block
    write(file, data)   // expands to ∇-steps + Σ-guard
}
```

```pmsl
commit Σ {
    // Σ: integrate state changes produced in the block
}
```

These snippets illustrate how PMSL code maps directly to operator classes defined in Appendix A.

---

### C.6 Graph Notation

PMS uses diagrams to illustrate execution, frame hierarchies, IPC channels, and policy scopes.
This section defines a consistent notation for these diagrams.

#### C.6.1 Node types

| Node Shape / Style      | Meaning                         |
| ----------------------- | ------------------------------- |
| Rounded rectangle   | Frame (`□`), context boundary   |
| Hexagon             | Policy domain (`Ψ`)             |
| Double-bordered box | Commit boundary (`Σ`-scope)     |
| Circle / ellipse    | Process or thread               |
| Diamond             | Distinction/decision node (`Δ`) |
| Shield icon / lock  | Role or capability (`Ω`)        |

#### C.6.2 Edge types

| Edge Style              | Meaning                                         |
| ----------------------- | ----------------------------------------------- |
| Solid arrow         | Action or state transition (`∇`, `Θ`, `Λ`)      |
| Dashed arrow        | Policy influence or constraint (`Ψ` → op)       |
| Double arrow        | Commit propagation (`Σ`) across frames or nodes |
| Thick boundary edge | Isolation boundary (`Χ`)                        |
| Dotted arrow        | Pattern expansion or macro correspondence (`Α`) |

#### C.6.3 Legend conventions

* Isolation boundaries (`Χ`) are shown as thick or shaded region outlines.
* Policy scopes (`Ψ`) are shown as dashed enclosures.
* Commit regions (`Σ`) use double borders.
* Channels show bidirectional or directed message edges annotated with Δ/Ω/Σ constraints.

These conventions ensure all diagrams in the book and in PMS documentation remain consistent and unambiguous.

---

## Appendix D — Example PMSL Programs

Purpose.
Provide 5–7 small, fully commented PMSL examples in the style of *literate specifications*.
They show how Δ–Ψ operators manifest in everyday PMSL code and serve as high-quality copy-and-paste templates.

Role.
This is likely the most important appendix for adoption.
Quality over quantity: it is better to present 4–5 exceptionally well-commented examples than a larger number of shallow ones.

The examples below focus on the recommended v1 set:

* D.1 Hello Frame
* D.2 Policy Scope
* D.3 IPC Channel (send/recv)
* D.4 Filesystem Operation
* D.5 Upgrade / Migration

Each example is written in PMSL, with inline comments mapping PMSL constructs to Δ–Ψ operators.
Some examples use pseudo-identifiers like `Δ_msg` or `Σ_post` to name internal operator steps; these are *descriptive labels*, not PMSL keywords.

---

### D.1 “Hello Frame”

Minimal example: create a frame, enter it, perform a small action, leave it.

```pmsl
// Create a new frame for a user session.
frame enter F_user {
    // Δ: classify the frame (user-level context)
    // Ω: activate user role
    // □: switch the active context to F_user
    // Χ: enforce isolation from kernel/system frames

    let x = 1 + 2;
    // ∇: evaluation (ALU step)
    // Θ: sequencing/progress

} // frame leave happens implicitly here
// Φ: exit context; □: restore previous frame
```

This program shows the minimal pattern: structure (Δ, Ω, □, Χ) → dynamic steps (∇) → context exit (Φ + □).

---

### D.2 Policy Scope & Violation

A policy is introduced, applied to a block, and a deliberate violation triggers Φ + Ψ machinery.

```pmsl
policy with P_write {
    // Ψ: activate policy P_write
    //   (e.g., "writes allowed only to /tmp/")

    frame enter F_log {
        // Δ: classify log frame
        // Ω: switch into log-writer role
        // □: enter log-writing context

        write("/secure/secret.txt", data);
        // ∇: attempt to write
        // Δ: path distinction → "secure" vs "tmp"
        // Ψ: policy violation detected
        // Φ: trap → recontextualize into violation handler
    }
} // Ψ: policy scope ends
```

This illustrates how policies (Ψ) can dynamically reject transitions, triggering Φ to shift execution into a handler context.

---

### D.3 IPC Channel (send / recv)

A simplified message-passing example showing Δ, Ω, Θ, Λ, Φ, Σ interplay.

#### Sender

```pmsl
channel<Message> C;

send C {
    Δ_msg: classify(msg);            // Δ: ensure message type matches channel<T>
    Ω_check: require(sender_role);   // Ω: sender must have capability for C
    ∇_enqueue(msg);                  // ∇: enqueue message in C
    Θ_signal(C);                     // Θ: progress/signal to waiting receivers
    Σ_post;                          // Σ: commit enqueue to channel buffer
}
```

#### Receiver

```pmsl
recv C {
    Θ_wait(C);                       // Θ: wait for incoming message
    Λ_timeout(100ms);                // Λ: if nothing arrives → timeout branch

    msg = ∇_dequeue(C);              // ∇: dequeue message
    // Δ: validate type
    // If mismatch:
    //    Φ_reframe: move into error-handler frame
}
```

This example demonstrates temporal progression (Θ), absence handling (Λ), role checks (Ω), and reframing on type failure (Φ).

---

### D.4 Filesystem Operation (open → read → write → close)

A toy filesystem transaction with explicit operator expansion.

```pmsl
frame enter F_fs {
    // Δ: classify filesystem frame
    // Ω: activate appropriate FS role

    let fd = open("/tmp/x");
    // ∇: issue open syscall
    // Θ: scheduling/progress
    // Σ: commit open-result into process state

    let buf = read(fd, 128);
    // ∇: perform read
    // Σ: commit buffer contents

    write(fd, "hello");
    // ∇: perform write
    // Δ: validate write size/type
    // Σ: commit written bytes

    close(fd);
    // ∇: perform close
    // Σ: finalize and integrate resource release
}
```

This example maps the familiar POSIX sequence to Δ–Ψ semantics, showing how Σ commits mark integration points and how Δ frames checks for each step.

---

### D.5 Upgrade / Migration

A structural upgrade scenario involving recontextualization, new policy activation, and commit.

```pmsl
// Node upgrade triggered
Φ_upgrade {
    // Φ: enter upgrade frame due to external trigger
    // □: switch context

    Δ_new_policy: classify new policy version;
    // Δ: structural distinction → "old policy" vs "new policy"

    Ψ_update {
        // Ψ: update policy set, enforce invariants
        // Ω: ensure caller has upgrade capability
    }

    Σ_commit;
    // Σ: integrate policy changes into persistent configuration
}
```

This pattern is representative for cluster upgrades, configuration changes, and governance transitions.

---

#### Notes for Readers

* Each snippet can be expanded into its underlying Δ–Ψ operator sequence using Appendix A.
* Examples use a lightweight PMSL syntax shown in Appendix C.5.
* Every key construct corresponds to a mechanized semantics in the monoid-based model (Appendix B).

---

## Appendix E — PMS-STACK vs. Classical OS Design

Purpose.
Demonstrate that PMS-STACK is *not* an alien system, but a structurally stricter and more explicit version of ideas already present in classical OS and VM design.
This appendix is especially helpful for skeptics, practitioners, and readers coming from Unix, microkernel, or VM backgrounds.

---

### E.1 High-Level OS Model

A top-level comparison of classical designs and PMS-STACK:

| Aspect        | Unix/POSIX                  | Microkernel (L4, seL4)         | PMS-STACK                                        |
| ------------- | --------------------------- | ------------------------------ | --------------------------------------------- |
| Protection    | User/Kernel mode, UIDs      | Capabilities + IPC             | Ω-roles + Χ-isolation + Ψ-policies            |
| IPC           | Pipes, sockets, signals     | Synchronous / asynchronous IPC | Channels with Δ/Ω/Σ/Ψ semantics               |
| Scheduling    | CFS, priority scheduling    | Round-robin / priority         | Θ-ordering semantics + Ψᵀ fairness invariants |
| Formal models | Local/partial formalisation | Fully verifiable kernel (seL4) | Global Δ–Ψ operator monoid for all layers     |

#### Interpretation

In Unix/POSIX, notions of *protection*, *context*, and *control* appear in ad-hoc or subsystem-specific form (UIDs, modes, privilege escalation rules, ACLs). Microkernels refine some of these ideas by making capabilities explicit and minimizing the trusted computing base.

PMS-STACK takes these same concepts and lifts them into a *single, unified formal structure* based on operators Δ–Ψ.

* What Unix treats as “user vs kernel mode,” PMS-STACK expresses through Ω roles and Χ isolation, both first-class and compositional.
* What microkernels treat as “IPC + capabilities,” PMS-STACK treats as channels governed by Δ (typing), Ω (capability), Σ (commit), and Ψ (policy).
* Where classical scheduling relies on heuristics or priority queues, PMS-STACK exposes scheduling as explicit Θ-ordering operators bound by policy constraints (Ψᵀ).
* And instead of scattered or local formal models, PMS-STACK provides a global operator-monoid semantics that spans UM → CPU → OS → PMSL → distributed layers.

The point is not that classical systems are “wrong,” but that PMS-STACK generalises their underlying ideas into a single, coherent semantic foundation.

---

### E.2 Virtual Machines / Runtimes

A comparison of how mainstream VMs structure execution compared to PMS-STACK/PMSL.

| Aspect           | JVM / CLR                     | WASM                          | PMS-STACK / PMSL                                   |
| ---------------- | ----------------------------- | ----------------------------- | ----------------------------------------------- |
| Code format      | Bytecode for a stack-based VM | Stack VM + linear memory      | Operator-words over O* (Δ–Ψ alphabet)       |
| Isolation        | Sandbox enforced by the VM    | Linear memory + module bounds | Χ isolation + Ψ policies as first-class ops |
| Host integration | FFI / native calls            | Host functions                | Homomorphisms OS ↔ PMSL ↔ UM                |

#### Interpretation

JVM, CLR, and WASM all offer:

* a bytecode representation,
* a virtualised execution environment, and
* some sandboxing guarantees.

PMSL is *not* “another VM.” It provides a structural semantics into which VMs can be embedded:

* A JVM method invocation becomes a sequence of Δ (type distinction) and ∇ (evaluation) operators.
* WASM module boundaries map naturally to Χ isolation frames.
* Host calls correspond to the h_CPU→OS and h_OS→PMSL homomorphisms introduced in Appendix B.5.

PMSL is therefore *below* the abstraction level of a VM: it describes the semantic structure that hosts, VMs, kernels, and hardware can all map onto.

#### Optional Migration Scenario: Projecting a POSIX Process into PMS-STACK

A simple illustration:

| POSIX Concept         | PMS-STACK Projection                                     |
| --------------------- | ----------------------------------------------------- |
| Process               | Frame F_proc (□)                                  |
| Effective UID/GID     | Role Ω_user                                       |
| File descriptor table | Distinguished object set Δ_fd + policy Ψ_fd_rules |
| Signals               | Φ traps with contextual re-entry                  |
| Access controls (rwx) | Ψ policies governing permitted ∇ operations       |
| Namespace isolation   | Χ isolation boundaries                            |

The result is a structurally richer representation of the same familiar semantics — but with *explicit* policies, roles, and isolation guarantees, rather than implicit OS conventions.

---

### E.3 IPC & Scheduling Detail

Below are concrete comparisons of PMS-STACK mechanisms with classical OS mechanisms.

#### E.3.1 IPC

| Mechanism              | POSIX Message Queue / Pipe                     | PMS-STACK Channel                                        |
| ---------------------- | ---------------------------------------------- | ----------------------------------------------------- |
| Typing                 | No intrinsic type system                       | Δ: typed messages (compile- & policy-checked)     |
| Permissions            | File-permissions / ACLs                        | Ω: sender/receiver roles & capabilities           |
| Delivery guarantees    | Kernel-defined (best-effort except for errors) | Σ: commit semantics; explicit integration steps   |
| Blocking / waiting     | `read`, `write`, `select`, `epoll`             | Θ: progress & wakeup operators; Λ timeouts    |
| Error handling         | Errno, signal handlers                         | Φ: recontextualization into explicit error frames |
| Isolation / boundaries | File-descriptor namespace                      | Χ: per-frame or per-domain channel boundaries     |

PMS-channels don’t replace pipes or sockets — they make their semantics explicit in terms of Δ–Ψ operators.

---

#### E.3.2 Event Selection / Scheduling

| Mechanism          | `epoll` / `kqueue` / POSIX scheduler | PMS-STACK Equivalent                                        |
| ------------------ | ------------------------------------ | -------------------------------------------------------- |
| Wait for readiness | Kernel monitors FD sets              | Θ_wait, Θ_probe (ordering & readiness operators) |
| Timeout handling   | `epoll_wait` timeout parameter       | Λ_timeout as first-class operator                    |
| Dispatch policy    | Priority / fairness heuristics       | Ψᵀ fairness and policy-governed Θ steps              |
| Context switching  | Kernel-level scheduling              | □ context + Θ progression semantics              |
| Handling errors    | Errno, signals                       | Φ traps with structured re-entry                     |

#### Interpretation

Classical OS subsystems implement these mechanics implicitly in kernel code.
PMS-STACK exposes them as explicit operators with defined semantics:

* Readiness → Θ
* Timeouts → Λ
* Commit points → Σ
* Role and permission checks → Ω
* Isolation boundaries → Χ
* Policy constraints → Ψ

This unified operator model makes IPC, scheduling, and error handling *composable*, *analyzable*, and *formally verifiable* across layers.

---

## Appendix F — Security & Governance Scenarios

Purpose.
Provide *storyboard-style* examples that show how PMS-STACK’s security and governance guarantees follow directly from its structural semantics.
These scenarios are especially valuable for readers with backgrounds in security, compliance, verification, and governance.

Rather than relying on heuristics, permissions scattered across subsystems, or ad-hoc policy engines, PMS-STACK expresses security through Δ–Ψ operators, frames, roles, and policies that are part of the core semantics.

---

### F.1 Scenario Template

All scenarios follow the same consistent structure so that security analysts can quickly map components to PMS semantics.

#### 1. Setup

Define the initial conditions:

* Frames (□): Which execution domains exist?
  (e.g., `F_user`, `F_kernel`, `F_db`, `F_containerA`)
* Roles (Ω): Which capabilities or privilege states apply?
  (e.g., `Ω_user`, `Ω_admin`, `Ω_node`)
* Policies (Ψ): Which invariants constrain behavior?
  (e.g., `Ψ₁ = “no cross-frame read without capability X”`,
  `Ψ₂ = “role escalation must be monotonic”`)
* Isolation (Χ): Which visibility boundaries are active?
* Initial structural distinctions (Δ): Any relevant type or object partitions.

#### 2. Attack / Misbehavior

Describe the attempted violation as a word in `O*`, using Δ–Ψ operators to express what the attacker or faulty subsystem tries to do.
For example:

```
w_attack = Δ_target  ∇_read  Χ_bypass  Ω_escalate
```

or a more explicit sequence:

```
w_attack = (Δ_obj  ∇_open  ∇_read  Φ_suppress  Ω_gain_root)
```

These sequences illustrate intent, not *success*.
The point is to show exactly where the semantics reject or reframe the operation.

#### 3. Expected Behavior

Explain what the PMS runtime *must* do according to the semantics:

* Block (operation forbidden by Ψ or Ω)
* Reframe (Φ) into an error or audit frame
* Rollback (Σ⁻) partial updates
* Isolate (Χ) the offending context
* Escalate to governance (Ψ-based escalation paths)
* Commit-with-audit (Σᴬ) if partial integration is allowed

This section demonstrates that PMS guarantees emerge *structurally*, not from ad-hoc checks.

#### 4. Linked Ψ-Invariants

List the specific Ψ rules or policies that govern the scenario:

* Which invariant is violated?
* Which Ψ-rule blocks or redirects execution?
* Which roles (Ω) or isolation boundaries (Χ) are involved?
* Which commit guarantees (Σ) apply?

For example:

* `Ψ₂ (Role monotonicity)` prevents illegal privilege escalation.
* `Ψ₄ (Isolation boundaries)` requires a valid capability before any Χ-crossing.
* `Ψ_commit` ensures Σ does not apply if earlier operators violate invariants.

These references point readers back to the formal policy definitions and show how PMS’s semantics create *provable* security behaviors.

---

### F.2 Typical Scenarios

Each of the following subsections provides one fully worked scenario.
They are intentionally concise but structurally revealing, illustrating how PMS security and governance guarantees emerge directly from Δ–Ψ semantics.

---

#### F.2.1 Unauthorized Privilege Escalation

Setup.

* Active frame: `F_user`
* Current role: `Ω_user`
* Policy: `Ψ₃ = role-monotonicity` (“no escalation to a higher role without an approved transition path”)
* Isolation: `Χ_user-kernel` prevents crossing into privileged frames without capability.

Attack attempt (`O*`).

Attacker attempts to escalate privileges:

```
w = Δ_targetRole  ∇_requestRole(Ω_root)  Ω_elevate
```

Expected behavior.

* `Ω_elevate` checks Ψ₃ and finds no monotonic path from `Ω_user → Ω_root`.
* Sequence becomes invalid at that point.
* Runtime emits:

  * `Φ_trap` → recontextualize into a violation frame
  * optional `Σ_rollback` → revert partial side effects

Linked Ψ-invariants.

* `Ψ₃` (monotone role evolution): forbids direct jumps to stronger roles.
* `Ψ_policyScope`: ensures privilege changes only occur within explicitly authorized frames.

---

#### F.2.2 Isolation Leak

Setup.

* Frames: `F_app` (unprivileged) and `F_secret` (restricted).
* Isolation boundary: `Χ(F_app → F_secret)` disallows direct reads.
* Policies: `Ψ₄ = “all cross-frame reads require capability C_readSecret”`.

Attack attempt (`O*`).

```
w = Δ_secretObj  ∇_read(secretObj)  Χ_bypass
```

Expected behavior.

* At `∇_read`, PMS checks the active frame and the Χ-boundary.
* No valid Ω-capability exists.
* System triggers:

  * `Φ_trap` → enter security-violation frame
  * optional `Σ_rollback` if read had partial effects (e.g., prefetch)

Linked Ψ-invariants.

* `Ψ₄` (cross-frame isolation): forbids any Χ-crossing without capability.
* `Ψ_trapPolicy`: determines whether reads fail open/closed or escalate.

---

#### F.2.3 Transaction Failure

Setup.

* Filesystem frame: `F_fs`
* Transactional policy: `Ψ_tx` enforcing atomicity of multi-step FS commits.
* Commit operator: `Σ` stands for atomic integration.

Attack / failure sequence (`O*`).

A multi-step commit fails midway:

```
w = ∇_open  Δ_path   ∇_write   Δ_validate   ∇_stage   Φ_error   Σ?
```

Expected behavior.

* Upon encountering `Φ_error`, PMS transitions to recovery frame.
* `Σ` cannot complete because `Ψ_tx` requires all steps to be valid.
* PMS performs:

  * `Σ_rollback` → revert all staged writes
  * `Α_log` or `Δ_log` → record failure for audit

Linked Ψ-invariants.

* `Ψ_tx` (transaction atomicity): disallows partial commits.
* `Ψ_consistency`: ensures rollback leaves the FS in a valid state.

---

#### F.2.4 Praxeological Malware Pattern

Setup.

* Attacker tries to gradually weaken the system’s structural invariants.
* Policies include `Ψ₄`: “Δ/Ω/Ψ modifications must occur only in kernel-governed frames.”
* Attacker operates within a user frame.

Attack sequence (`O*`).

A slow, creeping attempt:

```
w = Δ_shadowPolicy  Ω_escalate?  Ψ_redefine  (repeat)
```

The intent is to alter policies from user space without triggering classical alarms.

Expected behavior.

* Any `Ψ_redefine` requires a kernel-level governance frame.
* Since the attacker is in a user frame, the attempt violates `Ψ₄`.
* PMS enforces:

  * `Φ_trap` → move attacker into a governance-violation frame
  * `Χ_restrict` → tighten isolation
  * optional `Σ_audit` → commit event to audit logs

Linked Ψ-invariants.

* `Ψ₄` (governance locality): forbids structural changes outside kernel context.
* `Ψ_integrity`: ensures Δ/Ω/Ψ changes cannot be smuggled in gradually.

---

#### F.2.5 Multi-Node Attack

Setup.

* Distributed PMS cluster with global frame `□ᴳ`.
* Node roles: `Ω_node`, `Ω_orchestrator`.
* Global policy: `Ψᴳ_commitQuorum` (“Σᵍ only valid if quorum Q approves state”).
* Global commit operator: `Σᵍ`.

Attack attempt (`O*`).

A compromised node tries to advance commit state unilaterally:

```
w = Δ_state   ∇_reportProgress(fake)   Σᵍ
```

Expected behavior.

* At `Σᵍ`, the orchestrator checks `Ψᴳ_commitQuorum`.
* Fake progress lacks quorum → global commit is blocked.
* PMS performs:

  * `Φᵍ_trap(node)` → isolate offending node into a restricted global frame
  * `Χᵍ_restrict(node)` → limit network/cluster visibility
  * optional `Σᵍ_audit` → record anomaly in distributed log

Linked Ψ-invariants.

* `Ψᴳ_commitQuorum`: enforces correctness of global state transitions.
* `Ψᴳ_clusterIntegrity`: prevents one node from pushing global state forward.

---

## Appendix G — Cluster & Multi-Node Extensions

Purpose.
Show how PMS operators generalize to cluster-level semantics.
The goal is not to build a full distributed-systems textbook, but to demonstrate that the Δ–Ψ operator model scales naturally to multi-node settings by introducing global operators (`Oᵍ`) and global policies (`Ψᵍ`).

Scope.
This appendix stays intentionally focused:

* how global structures correspond to local ones,
* how operators are *lifted*,
* how consensus fits into the Σᵍ semantics.

---

### G.1 Global Structures

In a distributed PMS deployment, several structures acquire global counterparts that live above individual nodes:

#### Global Frame `□ᵍ`

Represents a cluster-level execution or configuration domain.
Examples:

* a cluster (“one global frame per cluster”)
* a region or availability zone
* a logical shard in a distributed service

Just like local frames (`□`), the global frame defines:

* scope for global policies,
* visibility between nodes,
* permissible transitions under Ψᵍ.

---

#### Global Roles (`Ωᵍ`)

Distributed systems typically distinguish multiple node-level or orchestration roles.
Examples:

* `Ωᵍ_orchestrator` — entity coordinating updates or cluster-wide actions
* `Ωᵍ_node` — a regular participating node
* `Ωᵍ_operator` — administrative role for configuration or governance

Role checks work identically to the local Ω semantics, but apply to *cross-node* capabilities.

---

#### Global Policies (`Ψᵍ`)

Cluster-level invariants governing:

* commit quorums
* membership changes
* failover conditions
* cross-node isolation rules (`Χᵍ`)
* upgrade safety (e.g., “never run two incompatible versions simultaneously”)

These policies bind global execution in the same way Ψ binds local execution.

---

### G.2 Operator Lifting

Every operator `o ∈ O` can be lifted to a global variant `oᵍ` where semantics apply across node boundaries.
This follows a simple principle:

> Local operator = effect on a single state `S`.
> Global operator = coordinated effect on a set of states `{S₁ … Sₙ}` under Ψᵍ.

Below are the key lifted operators.

---

#### Σᵍ — Global Commit (Consensus Commit)

The global counterpart to Σ is the commit of a change that must be accepted cluster-wide.

Semantics (informal):

```
Σᵍ : (S₁ × S₂ × … × Sₙ × CommitSpec) → (S₁' × S₂' × … × Sₙ')
```

A Σᵍ transition only succeeds when all required nodes satisfy the global preconditions defined in Ψᵍ (e.g., quorum, majority, uniformity constraints).

Examples:

* committing a cluster-wide configuration
* finalizing a distributed transaction
* publishing a new policy set across nodes

---

#### Θᵍ — Global Ordering / Progress

Represents distributed coordination of:

* logical clocks
* heartbeats
* scheduling steps across nodes
* causal or topological ordering constraints

Typical use cases:

* global “tick” driving coordination protocols
* detecting node timeouts or partition conditions (in combination with Λᵍ)

---

#### Φᵍ — Global Trap / Recontextualization

Triggered when:

* a node misbehaves (invalid Σᵍ vote, inconsistent state)
* global invariants are violated
* a failover or migration event occurs

Typical effects:

* isolate the offending node (`Χᵍ_restrict(node)`)
* move the cluster into a recovery frame (`□ᵍ_recovery`)
* enforce rollback or partial recomputation

---

#### Three concise examples of lifting

1. Local commit → Global commit

   ```
   Σ        : integrate change locally
   Σᵍ       : integrate change only after quorum of nodes agrees
   ```

2. Local trap → Global trap

   ```
   Φ        : process jumped to handler frame
   Φᵍ       : entire cluster enters coordinated recovery mode
   ```

3. Local ordering → Distributed ordering

   ```
   Θ        : advance local scheduler
   Θᵍ       : advance shared cluster epoch / heartbeat / logical clock
   ```

These examples emphasize that lifting is conceptually uniform, not special-cased.

---

### G.3 Consensus

Consensus is not an add-on to PMS—it falls out naturally from the semantics of Σᵍ.

#### Consensus as a Σᵍ Rule

A global commit `Σᵍ` is valid iff:

```
Ψᵍ_commitQuorum( votes(nodes), proposal ) = true
```

`Ψᵍ_commitQuorum` is the policy defining what “agreement” means:

* majority quorum
* multi-zone quorum
* uniform agreement (all nodes must agree)
* weighted or role-based voting (e.g., orchestrator’s vote required)

Thus Σᵍ is simply the commit operator under global policy constraints.

---

#### Mapping Paxos/Raft to Σᵍ sequences (very short sketch)

Rather than re-explaining distributed algorithms, PMS gives a clean abstraction:

* Prepare phase
  corresponds to a sequence of Θᵍ (ordering), Δ (proposal comparisons), and Ωᵍ checks.

* Accept phase
  corresponds to nodes locally staging state under Σ (not Σᵍ yet).

* Commit phase
  is literally Σᵍ, triggered when Ψᵍ_commitQuorum is satisfied.

This demonstrates that Paxos/Raft are special cases of the general PMS model:

* their mechanics are implementation-level details of how nodes collectively satisfy Ψᵍ.

---

#### Why this matters

* PMS does not impose a specific consensus algorithm.
* PMS embeds algorithm choice into policy semantics (Ψᵍ).
* Global commits become first-class citizens in the Δ–Ψ operator system.

---

### G.4 Cross-Node Isolation (Χᵍ)

Cross-node isolation generalizes the local Χ-operator to distributed frames.
While Χ enforces intra-machine isolation (between processes, frames, sandboxes), Χᵍ enforces inter-node isolation across a cluster.

#### What Isolation Means in a Distributed Setting

A global frame `□ᵍ` may consist of nodes participating in different roles or hosting different logical partitions. Χᵍ specifies:

* which nodes may see or modify which subsets of global state,
* which communication paths are allowed between nodes,
* how failure or compromise of one node affects its visibility to others,
* which nodes are permitted to join or leave a global frame.

In effect:

> Χᵍ is the global reachability and containment relation
> between nodes, partitions, roles, and global frames.

#### Cross-Node Isolation Violations

A violation occurs when a node attempts to read/write/participate in a global context without satisfying Ωᵍ + Ψᵍ guards.
Typical problematic sequence:

```
w = Δ_targetPartitionᵍ  ∇_readRemote(partition)  Χᵍ_bypass
```

Expected reaction:

* detect violation under Ψᵍ isolation policies
* emit global trap `Φᵍ_isolation`
* restrict node via `Χᵍ_restrict` (removal from certain communication paths or quorum sets)
* possibly trigger a global recovery or membership update

#### Small Diagram (ASCII-friendly)

You can replace this later with a real graphic, but here is the structural idea:

```
        □ᵍ (Global Frame)
   ┌──────────────────────────┐
   │    Cluster Namespace     │
   │                          │
   │   $$
Node A
$$───allowed────$$
Node B
$$
   │      │                   │
   │   forbidden             allowed
   │      │                   │
   │   $$
Node C
$$──────────────$$
Node D
$$
   │         (Χᵍ boundary)    │
   └──────────────────────────┘
```

Nodes separated by a Χᵍ boundary may not exchange frames, messages, or shared state without explicit capability + policy authorization.

This keeps partition breaches, rogue cross-node reads, and inconsistent global updates structurally impossible.

---

### G.5 Cluster Boot / Upgrade

Cluster-level lifecycle management fits naturally into the Oᵍ-operator model.
Unlike traditional ad-hoc bootstraps, PMS exposes cluster boot and upgrade as explicit operator words in `Oᵍ*`.

#### G.5.1 Cluster Boot (as a word in `Oᵍ*`)

A simplified boot sequence:

```
w_boot =
    Δᵍ_clusterID
    Δᵍ_membership
    Ωᵍ_assignRoles
    Θᵍ_initEpoch
    Ψᵍ_loadPolicies
    Σᵍ_commitInit
```

Semantics:

* `Δᵍ_clusterID` and `Δᵍ_membership` classify the initial cluster structure.
* `Ωᵍ_assignRoles` binds roles (nodes vs. orchestrators).
* `Θᵍ_initEpoch` sets the initial global time/ordering baseline.
* `Ψᵍ_loadPolicies` installs global invariants.
* `Σᵍ_commitInit` finalizes the cluster's initial consistent state.

This forms the cluster analogue of process initialization under `□`.

---

#### G.5.2 Rolling Upgrade / Policy Migration

Rolling upgrades are expressed as structured global transitions:

```
Φᵍ_trigger
Δᵍ_new_policy
Ψᵍ_update
Σᵍ_commit
```

Explanation:

* `Φᵍ_trigger` — cluster enters upgrade-frame due to operator action or scheduled event.
* `Δᵍ_new_policy` — classify new configuration or governance rule.
* `Ψᵍ_update` — apply updated global policy set; enforce invariants (no incompatible nodes, no version skew beyond tolerance).
* `Σᵍ_commit` — once quorum agrees and Ψᵍ is satisfied, integrate new policy cluster-wide.

This covers:

* rolling version upgrades,
* membership updates,
* staged migrations (e.g., new storage formats),
* policy/gov updates that must remain globally consistent.

---

#### Scope Guidance for v1

For the first edition, G.1–G.3 + G.5 provide more than enough conceptual foundation.
A future “PMS Cluster Architecture” document can extend:

* detailed membership change semantics,
* failure domains,
* cross-region replication,
* distributed recovery and recontextualization sequences.

This appendix keeps the essentials tight and conceptually aligned with the Δ–Ψ model.

---

## Appendix H — Glossary & Cross-Model Mapping

### H.1 Glossary (Alphabetical)

Action (∇)
A dynamic PMS operator performing computation, mutation, or I/O.
See: Appendix A (Operator Reference), Appendix B (Monoid Semantics).

Attractor (Α)
Pattern or macro expansion operator that unfolds structured patterns into Δ–Ψ sequences.
See: Appendix A.2; B.2 (constraints on expansions).

Capability (Ω)
A role- or privilege-bearing token granting permission for certain transitions (e.g., access to frames, channels, files).
See: Chapters 3–4; Appendix A.1.

Channel
Bidirectional or unidirectional communication primitive between frames or processes.
Implements message passing via Δ (typing), Ω (capability checks), ∇ (enqueue/dequeue), Θ/Λ (temporal operations), and Σ (commit).
See: Chapter 6; Appendix D.3.

Commit (Σ)
Operator that integrates staged changes into durable, visible state.
In distributed settings: Σᵍ = consensus commit.
See: Chapter 5; Appendices A.2, G.3.

Context / Frame (□)
A structural unit representing a namespace, isolation boundary, or logical execution domain.
Entering/leaving a frame changes visibility, policies, and roles.
See: Chapter 2; Appendices A.1–A.3.

Distinction (Δ)
Operator for classification, branching, pattern matching, and structural decisions.
Forms the “structural spine” of PMS semantics.
See: Chapter 2; Appendix A.1.

Dynamic Block
Any subsequence dominated by dynamic operators (∇, Θ, Λ, Φ, Σ, Α).
See: Appendix A.5 (operator partial order).

Error / Trap (Φ)
Recontextualization operator: triggered by violations, exceptions, or recovery events.
Switches into a handler frame; may adjust policies or isolation.
See: Chapter 4; Appendix A.2; Appendix F.

Frame Graph
The graph structure of frames and their reachability relations (Χ), optionally extended to a global frame graph (Χᵍ).
See: Chapters 2 & 7; Appendices A, G.4.

Governance (Ψ)
Policy semantics: invariants constraining allowed transitions, role evolution, isolation behavior, commit conditions, etc.
See: Chapters 3 & 8; Appendices A.2, F.

Homomorphism (h)
Structure-preserving mapping between execution layers (UM → CPU → OS → PMSL).
Ensures Δ–Ψ semantics remain intact across translations.
See: Appendix B.5.

Isolation (Χ)
Structural boundary preventing unauthorized visibility or access between frames/domains.
Global version Χᵍ applies across nodes.
See: Chapters 2–4; Appendices A.2, F.2, G.4.

Monoid (O*, ∘, ε)
Formal foundation of PMS operator semantics:

* `O` = operator alphabet
* `O*` = words over O
* `∘` = concatenation
* `ε` = neutral element (empty word)
  Valid PMS executions form a constrained subset `L ⊆ O*`.
  See: Appendix B.1–B.3.

Normal Form
Canonical arrangement of operator words:

```
(struct-block)* (dyn-block)* (commit/policy-block)*
```

Ensures readability, analyzability, and predictable translation to other layers.
See: Appendix A.5; Appendix B.3.

Policy (Ψ)
Set of invariants controlling roles, frames, isolation, commits, timeouts, and cross-node behavior.
Policies exist locally and globally (Ψᵍ).
See: Chapter 3; Appendices A, F, G.

Praxeology / Praxeological Pattern
Behavioral pattern describing adversarial or manipulative sequences attempting to weaken structural invariants (e.g., covert policy tampering).
Used in security analyses (Appendix F).
See: Appendix F.2.4.

Process / Thread
Execution units represented via frames and scheduled via Θ semantics.
Their resource boundaries correspond to Χ boundaries.
See: Chapters 2 & 6.

Reframe (Φ)
A Φ-triggered transition into an alternative frame, usually due to error, migration, upgrade, or policy violation.
See: Chapter 4; Appendices D.2, D.3, F.

Role (Ω)
Marker of capability, privilege, or operational stance within a frame.
Transitions between roles must satisfy Ψ invariants (e.g., monotonicity).
See: Chapters 3 & 4; Appendix A.1.

Scheduling (Θ)
Progress, ordering, or temporal advancement operator.
In distributed contexts (Θᵍ): logical clocks, heartbeats, event synchronization.
See: Chapters 2 & 6; Appendices A.2, G.2.

Sequence (word in O*)
A PMS program or trace represented as a word over the operator alphabet `O`.
Validity governed by typing rules and Ψ invariants.
See: Appendix B.2.

Self-Binding (Ψ)
Property of policies: they constrain not only program transitions but their own evolution (e.g., Ψ disallows weakening Ψ).
See: Chapter 8; Appendix F.

Structural Block
Any contiguous sequence of structural operators (Δ, □, Ω, Χ, Ψ).
See: Appendix A.5.

Timeout / Absence (Λ)
Operator representing the non-occurrence of an expected event (e.g., missing message, delayed action).
Often paired with Θ.
See: Appendix A.2; Appendix D.3.

Trap (Φ)
See Error / Trap.

Upgrade / Migration
Sequence of operators for changing configuration or policies.
Typical form:

```
Φ_upgrade  →  Δ_new_policy  →  Ψ_update  →  Σ_commit
```

Global version appears in Appendix G as `Φᵍ → Δᵍ → Ψᵍ → Σᵍ`.

Word (O*)
An execution trace expressed as concatenated operators.
See: Appendix B.

---

### H.2 Cross-Model Tables

The purpose of these tables is twofold:

1. Bridging layers inside PMS (UM → CPU → OS → PMSL) by showing how core concepts manifest at each level.
2. Bridging PMS to other conceptual frameworks (MIP, Emergence theory, classical CS) to help readers familiar with those domains orient themselves.

To avoid overload, the tables focus on *a small set of carefully chosen, representative concepts*.

---

#### H.2.1 PMS-UM ↔ PMS-CPU ↔ PMS-OS ↔ PMSL

| Concept                | PMS-UM (Universal Machine)                                      | PMS-CPU                                                     | PMS-OS                                                 | PMSL                                                        |
| ---------------------- | --------------------------------------------------------------- | ----------------------------------------------------------- | ------------------------------------------------------ | ----------------------------------------------------------- |
| Frame (□)          | Subset/region of the abstract state space; structural partition | Page / segment / execution domain; hardware-isolated region | Process / address space / container boundary           | `frame { … }` block; explicit context boundary in code      |
| Role (Ω)           | Abstract capability relation over state partitions              | Privilege bits, capability registers                        | User/group IDs, ACL roles, seccomp profiles            | `role use R` or implicit via `policy with P`                |
| Policy (Ψ)         | Constraint set restricting allowed transitions in O*            | Enforcement logic in privilege checks, guard conditions     | Security modules, mandatory access control, invariants | `policy with P { … }`, policy blocks; invariant enforcement |
| Isolation (Χ)      | Non-reachability relation between state partitions              | MMU/segment protections, hardware domains                   | Namespaces, containers, sandbox boundaries             | Explicit `isolate { … }` constructs; scoped visibility      |
| Action (∇)         | State transition primitive                                      | ALU op, memory write, I/O instruction                       | System calls, FS operations, IPC ops                   | Expressions, statements, SSR (side-effect rules)            |
| Commit (Σ)         | Integration of staged state into global state                   | Writeback, barrier, fence, TLB sync                         | Transaction end, FS commit, scheduler state update     | `commit Σ { … }` or implicit commit points                  |
| Trap / Reframe (Φ) | Recontextualization in state model                              | Exception, interrupt, trap handler entry                    | Signal, fault handler, migration / restart             | `on Φ { … }`, handler frames                                |
| Ordering (Θ)       | Abstract temporal / sequencing step                             | CPU tick, instruction step, branch resolution               | Scheduler tick, wakeups, timers                        | `await`, `step`, ordering constructs in PMSL                |
| Absence (Λ)        | Non-event placeholder (“no transition occurred”)                | Timeout, wait loop not satisfied                            | Empty queue, no event, poll timeout                    | `timeout Λ`, absence branches                               |

Interpretation.
This table highlights the *uniformity* of Δ–Ψ semantics across layers: what is a “page” or “address space” at the CPU/OS level becomes a frame, and what is a trap or system-call error becomes Φ recontextualization. PMSL does not invent new semantics—rather, it exposes the common structure that already spans UM → CPU → OS.

---

#### H.2.2 PMS ↔ MIP ↔ Classical Computer Science

To connect PMS with external conceptual frameworks (Model–Interpreter–Praxeology, and standard CS), the following table identifies approximate correspondences.
These are *not strict equivalences*, but structural analogies.

| PMS Concept            | MIP (Model–Interpreter–Praxeology)                       | Classical CS / OS                           | Interpretation                                                       |
| ---------------------- | -------------------------------------------------------- | ------------------------------------------- | -------------------------------------------------------------------- |
| Frame (□)          | Model / context / stance from which the interpreter acts | Process context, address space, environment | Frames define the interpretive “lens,” similar to contextual models. |
| Role (Ω)           | Interpreter capacity / stance                            | Privilege / capability / user role          | Roles formalize asymmetry of action possibilities.                   |
| Policy (Ψ)         | Praxeological norms; constraints on valid actions        | Security policy, MAC, invariants            | Ψ encodes the rules that shape global patterns.                      |
| Distinction (Δ)    | Differentiation step (model boundary)                    | If/else, type checks, namespace boundaries  | Δ creates “differences that matter” in execution.                    |
| Action (∇)         | Interpreter act / intervention                           | Instruction, syscall, operation             | The concrete step that updates state.                                |
| Isolation (Χ)      | Segmentation of praxeological spaces                     | Process isolation, sandboxing               | Χ prevents undesired coupling across domains.                        |
| Commit (Σ)         | Stabilization of model state                             | Transaction commit, durable write           | A state becomes “real” or binding.                                   |
| Trap / Reframe (Φ) | Shift in interpretive stance                             | Exception, signal handler                   | Φ replaces the active model or pivot point.                          |
| Ordering (Θ)       | Temporal step of interpretive process                    | Scheduler tick, event loop                  | Θ provides controlled temporal structure.                            |
| Absence (Λ)        | Nil-action in praxeology                                 | Poll timeout, empty queue                   | Λ is the formal representation of “nothing happened.”                |

Interpretation.
These mappings help position PMS in a broader intellectual landscape:

* In MIP terms, PMS operators encode how an interpreter distinguishes, acts, reframes, and commits.
* In classical CS, PMS systematically unifies control flow, type checking, scheduling, security, and exception handling under one operator algebra.
