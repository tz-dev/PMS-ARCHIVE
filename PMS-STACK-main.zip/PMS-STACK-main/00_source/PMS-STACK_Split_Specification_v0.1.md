---
document_id: PMS-STACK-SPLIT-SPEC-v0.1
title: "PMS-STACK Split Specification v0.1"
status: "documentation"
version: "v0.1"
claim_type: "source-to-block provenance / modularization record"
canonical_status: "non-canonical; documents the split from PMS-STACK.md into 01_blocks/00–09"
canonical_rule: "README.md + 01_blocks/00–09 = canonical PMS-STACK specification"
source_file:
  - "00_source/PMS-STACK.md"
canonical_blocks:
  - "01_blocks/00_overview.md"
  - "01_blocks/01_architecture.md"
  - "01_blocks/02_pms_um.md"
  - "01_blocks/03_pms_cpu.md"
  - "01_blocks/04_pms_os.md"
  - "01_blocks/05_pmsl_pms_ir.md"
  - "01_blocks/06_runtime_security.md"
  - "01_blocks/07_distributed_systems.md"
  - "01_blocks/08_relation_to_pms_rust.md"
  - "01_blocks/09_non_goals_and_claim_boundary.md"
boundary: "This file records modularization and source lineage. It does not replace the canonical blocks, introduce new claims, validate PMS Base, or establish implementation completion."
---

# PMS-STACK Split Specification v0.1

## 1. Purpose

This document records how the original monolithic `PMS-STACK.md` was split into the modular PMS-STACK v0.1 block corpus.

It exists for documentation, provenance, and release traceability.

The canonical PMS-STACK v0.1 specification is:

```text
README.md + 01_blocks/00–09
```

This file is not canonical specification.

It documents:

```text
source lineage
block allocation
original source-section mapping
intended block functions
claim-boundary decisions
later release refinements
current corpus organization
```

The original `PMS-STACK.md` was less fully elaborated than the current modular block corpus. The current `01_blocks/00–09` files are therefore not merely mechanical extracts. They are expanded, claim-typed, PMS-conformant release blocks derived from the monolith and refined through the PMS-STACK release iteration.

The split rule is:

```text
PMS-STACK.md
    → source / origin material

01_blocks/00–09
    → expanded canonical modular specification
```

Boundary:

```text
This split specification records how the corpus was derived.
It does not override the canonical blocks.
It does not validate PMS Base.
It does not claim that all implementation targets are completed artifacts.
```

---

## 2. Current Repository Organization

The PMS-STACK v0.1 corpus is organized as:

```text
PMS-STACK/
├─ README.md
├─ 00_source/
│  ├─ PMS-STACK.md
│  └─ PMS-STACK_Split_Specification_v0.1.md
├─ 01_blocks/
│  ├─ 00_overview.md
│  ├─ 01_architecture.md
│  ├─ 02_pms_um.md
│  ├─ 03_pms_cpu.md
│  ├─ 04_pms_os.md
│  ├─ 05_pmsl_pms_ir.md
│  ├─ 06_runtime_security.md
│  ├─ 07_distributed_systems.md
│  ├─ 08_relation_to_pms_rust.md
│  └─ 09_non_goals_and_claim_boundary.md
├─ 02_reference/
├─ 03_minified/
├─ 04_derivative_publications/
└─ 05_PMS-STACK Reader/
```

The historical split plan referred to a `docs/00–09` directory. The v0.1 corpus uses `01_blocks/00–09` instead.

This is a path adaptation, not a specification change.

Historical target:

```text
docs/00–09
```

Current canonical target:

```text
01_blocks/00–09
```

Canonical rule:

```text
README.md + 01_blocks/00–09 = canonical PMS-STACK specification.
```

Derivative-layer rule:

```text
00_source preserves origin material.
02_reference indexes the canonical specification.
03_minified compresses the canonical specification.
04_derivative_publications explains the canonical specification.
05_PMS-STACK Reader navigates the canonical specification.

None of these layers replace the canonical blocks.
```

---

## 3. Split Principles

The split was governed by the following principles.

### 3.1 Architecture First

The monolithic `PMS-STACK.md` contained multiple interwoven layers:

```text
operator foundations
universal machine
virtual CPU
operating system
language/runtime
security
networking
distributed systems
tooling
claim boundaries
classical-system relations
```

The modular split separates these into stable files.

The central architecture file is:

```text
01_blocks/01_architecture.md
```

All other technical files depend on it.

### 3.2 Claim Boundary as a First-Class Block

The original monolith included claims about architecture, expressiveness, completeness, extensibility, classical-system mappings, security, and distributed systems.

The modular release makes claim discipline explicit through:

```text
01_blocks/09_non_goals_and_claim_boundary.md
```

This file governs:

```text
architecture vs implementation
specification vs proof
trace evidence vs proof
tests vs proof
PMS-RUST evidence vs PMS Base validation
virtual CPU vs fabricated hardware
PMS-OS vs production OS
PMSL spec vs complete compiler
distributed architecture vs completed runtime
AI proposal vs authority
chi_exit evidence vs ISO_EXIT completion
```

The global rule is:

```text
strong claim → claim type → boundary
```

### 3.3 PMS Base Boundary

PMS-STACK derives implementation-layer systems architecture from the PMS operator grammar.

It does not validate PMS Base.

The correct relation is:

```text
PMS Base defines operator identity.
PMS-STACK projects operator identity into systems architecture.
PMS-RUST may evidence bounded implementation slices.
Tests inspect.
Traces record.
Validators accept or reject under declared profiles.
Formal proofs prove stated properties under models.
External validation validates under external protocols.
```

No lower layer validates PMS Base.

### 3.4 Χ / Distance Discipline

The original monolith often used Χ in implementation-facing ways such as isolation, boundary, reachability, and containment.

The modular release preserves PMS 1.3 operator identity:

```text
PMS Base 1.3:
    Χ = Distance
```

At PMS-STACK implementation layers:

```text
Χ projects as:
    isolation
    reachability control
    boundary management
    access separation
    sandboxing
    containment
    quarantine
    namespace visibility
    trust-domain separation
```

This is projection, not redefinition.

### 3.5 Trace Discipline

The modular release distinguishes concrete traces from trace sets:

```text
trace(artifact, profile, input) ∈ L_PMS
```

denotes one concrete observed or constructed execution.

```text
Trace(artifact, profile) ⊆ L_PMS
```

denotes a declared set of possible executions under a profile.

A recorded trace does not enumerate or prove the whole `Trace(...)` set.

### 3.6 Artifact Evidence Discipline

PMS-RUST may strengthen bounded implementation-artifact claims.

It does not complete PMS-STACK.

It does not validate PMS Base.

Correct role:

```text
PMS-RUST = bounded executable PMS-STACK Evidence Spine v0.1
```

Evidence may include:

```text
deterministic execution
model validation
stateful validation
JSONL traces
golden fixtures
REPL/script tooling
vFS surface
AI proposal boundaries
chi_exit boundary-exit discipline where declared
```

Boundary:

```text
artifact evidence strengthens bounded implementation claims.
It does not prove PMS Base, complete PMS-STACK, or complete every STACK layer.
```

---

## 4. Modular Block Map

The canonical modular block set is:

```text
01_blocks/
├─ 00_overview.md
├─ 01_architecture.md
├─ 02_pms_um.md
├─ 03_pms_cpu.md
├─ 04_pms_os.md
├─ 05_pmsl_pms_ir.md
├─ 06_runtime_security.md
├─ 07_distributed_systems.md
├─ 08_relation_to_pms_rust.md
└─ 09_non_goals_and_claim_boundary.md
```

Each block has a specific role.

| Block | Role | Claim type | Boundary |
|---|---|---|---|
| `00_overview.md` | entry, scope, reading path, lineage, claim orientation | overview / orientation claim | not formal core, not proof, not implementation report |
| `01_architecture.md` | operator foundation, monoid, dependency language, state/configuration, mappings | central architecture claim | does not replace PMS Base |
| `02_pms_um.md` | PMS Universal Machine and abstract execution | abstract-machine / computational expressiveness claim | not full simulator by itself |
| `03_pms_cpu.md` | virtual CPU, ISA, execution cycle, memory consistency | virtual CPU / ISA architecture claim | not fabricated hardware |
| `04_pms_os.md` | kernel, process, syscall, memory, filesystem, IPC, drivers | OS architecture claim | not production OS |
| `05_pmsl_pms_ir.md` | PMSL, PMS-IR, runtime, tooling, analysis | language/runtime architecture claim | not complete compiler |
| `06_runtime_security.md` | identity, roles, capabilities, policy, audit, trust, attack handling | runtime-security architecture claim | not universal security certification |
| `07_distributed_systems.md` | networking, protocols, cluster frames, distributed commit | distributed architecture/profile claim | optional by runtime profile; not algorithm proof |
| `08_relation_to_pms_rust.md` | relation between STACK and PMS-RUST | implementation/artifact relation claim | PMS-RUST evidences bounded slices, not PMS Base |
| `09_non_goals_and_claim_boundary.md` | non-goals, proof boundary, implementation boundary, safe wording | claim-boundary specification | governs wording; does not weaken architecture claims |

---

## 5. Block-Level Split Record

### 5.1 `00_overview.md`

#### Function

`00_overview.md` serves as the entry point into the PMS-STACK block corpus.

It explains:

```text
purpose
scope
model lineage
claim orientation
relation to classical architectures
reading path
document map
overview boundary
```

#### Source sections from `PMS-STACK.md`

The initial split plan assigned the following monolith sections to this block:

```text
1. Introduction & Model Lineage
1.1 Motivation, Scope & Non-Goals
1.2 Lineage
1.3 Relation to Existing OS & Architecture Families
1.4 Intended Use, Audience & Reading Guide
15.1 Unified Stack Overview
15.7 Epilogue Statement, shortened
Appendix H, only as pointer to later glossary/mapping files
```

#### Release refinement

The final block adds:

```text
claim orientation
canonical document map
modular claim map
Χ = Distance / implementation projection discipline
PMS-UM computational universality as claim-typed expressiveness
release-candidate frontmatter
```

#### Claim boundary

`00_overview.md` is not the formal core.

It orients the reader and points to the technical blocks.

It does not validate PMS Base.

It does not claim every layer is implemented.

---

### 5.2 `01_architecture.md`

#### Function

`01_architecture.md` is the central reference file for PMS-STACK.

It defines:

```text
operator foundation
PMS-to-IT structural mapping
operator monoid
dependency constraints
valid sequence language
state/configuration relation
cross-layer homomorphisms
architecture invariants
reference mappings
```

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
2. Formal Foundations
2.1 PMS Operator Recap
2.2 PMS → IT Structural Mapping
2.3 Monoid View & Dependency Constraints
2.4 Notation & Meta-Model
Appendix A
Appendix B
Appendix C, selectively
Appendix H.2 Cross-Model Tables, selectively
```

#### Release refinement

The final block becomes more than a rearranged formal-foundations section.

It functions as the central architectural grammar for all later blocks.

It stabilizes:

```text
Δ–Ψ operator identity
well-formedness
operator dependencies
state/configuration conventions
implementation-layer projections
cross-layer mappings
claim discipline hooks
```

#### Claim boundary

`01_architecture.md` specifies the implementation-layer architecture grammar.

It does not redefine PMS Base.

It does not validate PMS Base.

It does not by itself implement any runtime.

---

### 5.3 `02_pms_um.md`

#### Function

`02_pms_um.md` specifies PMS-UM, the PMS Universal Machine.

It defines the abstract machine layer of PMS-STACK.

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
3. PMS Universal Machine
3.1 Formal Definition
3.2 Instruction Semantics by Operator
3.3 Example Encodings of Classical Turing Machines
3.4 Execution Cycle & Determinism / Non-Determinism
Appendix B.4 Turing Completeness
Appendix B.1–B.3, where needed for UM
```

#### Release refinement

The final block stabilizes the canonical PMS-UM tuple:

```text
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

The addition of `Π` ensures profile-awareness in the abstract machine definition.

PMS-UM computational universality is formulated as:

```text
computational expressiveness / formal architecture claim
```

not as proof of all PMS-STACK subsystems and not as PMS Base validation.

#### Claim boundary

PMS-UM is the abstract-machine core.

It may be claimed as computationally universal at the abstract-machine architecture layer through constructive or reduction-based routes.

It does not prove OS correctness, security correctness, distributed correctness, all-program termination, implementation completion, or PMS Base validation.

---

### 5.4 `03_pms_cpu.md`

#### Function

`03_pms_cpu.md` specifies PMS-CPU as a virtual CPU / ISA architecture.

It refines PMS-UM into processor-shaped execution.

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
4. PMS Virtual CPU
4.1 Architecture Overview
4.2 ISA
4.3 Calling Conventions
4.4 Interrupt & Trap Model
4.5 Binary Encoding
4.6 Fetch–Decode–Execute
4.7 Memory Consistency Model
Appendix C.4 Registers & ISA Notation
Appendix E, where CPU/VM-relevant
```

#### Release refinement

The final block stabilizes the canonical PMS-CPU tuple:

```text
M_CPU = (
    S_CPU,
    Γ_CPU,
    F_CPU,
    R_CPU,
    PSet_CPU,
    O,
    ISA,
    Π_CPU,
    δ_CPU,
    s₀_CPU,
    S_H_CPU
)
```

The release block also adds the PMS-RUST/PMS-CPU boundary for boundary exit:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

#### Claim boundary

PMS-CPU is a virtual CPU / ISA specification.

It does not claim:

```text
fabricated hardware
silicon implementation
complete emulator
complete assembler
complete compiler backend
complete hardware verification
```

`chi_exit` may evidence bounded runtime isolation-exit discipline where implemented.

It does not complete `ISO_EXIT`.

It does not redefine PMS Base Χ.

It does not validate PMS Base.

---

### 5.5 `04_pms_os.md`

#### Function

`04_pms_os.md` specifies PMS-OS as an operator-typed operating-system architecture.

It covers:

```text
kernel
processes
threads
scheduling
syscalls
resource accounting
virtual memory
filesystem
IPC
events
devices
drivers
OS-level invariants
```

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
5. PMS-OS Kernel Core
6. Memory & Storage Subsystems
7. IPC, Synchronization, and Events
8. Device & Driver Model
Appendix E.1–E.3
Appendix F, selectively as scenario references
```

#### Release refinement

The final block resolves several release-critical naming and notation issues:

```text
ResourceAccount / RAcc is used for resource accounting.
RF remains available for register-file meaning where needed.
```

The syscall convention is clarified:

```text
PMS-OS syscall convention is a dedicated trap/syscall ABI.
It does not redefine ordinary PMS-CPU calling convention.
```

The syscall operator word includes `□` and `Χ`:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

OS isolation-domain variables are clarified:

```text
IDom_user
IDom_global
```

Legacy `X_user`, `X_global`, or comparable notation denotes OS-level isolation-domain values, not the PMS Base operator Χ.

#### Claim boundary

PMS-OS is an OS architecture claim.

It does not assert a complete production OS, POSIX reimplementation, completed kernel, complete device ecosystem, complete syscall ABI implementation, deployment certification, or PMS Base validation.

---

### 5.6 `05_pmsl_pms_ir.md`

#### Function

`05_pmsl_pms_ir.md` specifies PMSL, PMS-IR, the runtime architecture, analysis path, tooling, and observability surfaces.

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
11. PMSL – Language Specification
12. PMSL Runtime & Standard Library
13. Tooling & Verification
Appendix C.5 PMSL Syntax
Appendix D Example PMSL Programs
Appendix B.5 Homomorphisms
```

#### Release refinement

The final block makes PMSL/PMS-IR claim-typed:

```text
PMSL = language-level expression of Δ–Ψ
PMS-IR = operator-preserving intermediate representation
runtime = profile-specific execution/validation/tracing architecture
```

The block incorporates the AI Bridge as an optional tooling/profile boundary.

Correct AI Bridge status:

```text
AI Bridge = optional PMS-RUST tooling/profile for proposing PMS-IR/opcode
programs or analyzing traces under host-side validation.
```

Not:

```text
AI Bridge = PMSL semantics
AI Bridge = compiler authority
AI Bridge = verifier authority
AI Bridge = trusted executable code
AI Bridge = PMS Base evidence
```

Required boundary:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

#### Claim boundary

PMSL/PMS-IR specify language/runtime architecture.

They do not assert a complete parser, type checker, compiler, optimizer, backend, standard library, verified runtime, trusted AI execution, verifier authority, compiler authority, verification evidence, or PMS Base validation.

---

### 5.7 `06_runtime_security.md`

#### Function

`06_runtime_security.md` specifies runtime security and governance as operator-constrained system structure.

It covers:

```text
identity
principals
roles
capabilities
isolation
policy enforcement
kernel hooks
runtime invariants
audit
trust anchors
network security integration
failure handling
attack handling
quarantine
AI/tooling boundary
boundary-exit discipline
```

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
10. Security & Governance
5.1 Kernel Trust Model
5.5 Isolation & Protection
5.6 Kernel Policy Engine
5.8 Resource Accounting
7.3 Event System
9.4 Network Security
10.1–10.5 fully
13.4 Debugging & Observability, where audit/trace-relevant
Appendix F Security & Governance Scenarios
```

#### Release refinement

The final block emphasizes that security is not an add-on.

Security-relevant transitions must be:

```text
Δ-distinguished
Ω-authorized
□-framed
Χ-bounded as implementation-layer Distance projection
Θ-ordered where relevant
Φ-recontextualized on failure where needed
Σ-committed where stable
Ψ-constrained by policy/invariant
```

It also incorporates PMS-RUST `chi_exit` as bounded runtime evidence where declared.

#### Claim boundary

Runtime security is an architecture claim.

It does not certify all implementations as secure, prove absence of vulnerabilities, provide legal or moral authority, establish a tribunal, complete runtime-security implementation, complete ISO_EXIT, or validate PMS Base.

---

### 5.8 `07_distributed_systems.md`

#### Function

`07_distributed_systems.md` specifies networking and distributed PMS-STACK profiles.

It covers:

```text
transport frames
timeouts
addressing
routing
PMS Protocol Suite
network security
resilience
cluster frames
operator lifting
distributed commit
global policy
cross-node isolation
cluster boot
upgrade
distributed audit
distributed verification
```

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
9. Networking Stack
14.4 Multi-Node / Cluster Boot & Orchestration
Appendix G Cluster & Multi-Node Extensions
10.4 Distributed Audit & Σ-Chaining
10.5 Distributed Trust Anchors
13.3.5 Verification of Multi-Node Systems
14.3 Distributed / Multi-Node Migration
```

#### Release refinement

The final block clarifies that distributed PMS-STACK is semantic scaling.

Global operator notation marks scope:

```text
Δᴳ
∇ᴳ
□ᴳ
Λᴳ
Αᴳ
Ωᴳ
Θᴳ
Φᴳ
Χᴳ
Σᴳ
Ψᴳ
```

It does not introduce new PMS Base operators.

Distributed trace notation is stabilized:

```text
traceᴳ(D, profile, input) ∈ L_PMS
Traceᴳ(D, profile) ⊆ L_PMS
```

Under active distributed policy:

```text
traceᴳ(D, profile, input) ∈ L_PMS,Ψᴳ
Traceᴳ(D, profile) ⊆ L_PMS,Ψᴳ
```

#### Claim boundary

Distributed PMS-STACK is an optional architecture/profile claim.

It does not require every runtime to be distributed.

It does not mandate one consensus algorithm.

It does not prove Paxos, Raft, PBFT, CRDTs, or any specific algorithm correct.

It does not complete a distributed runtime or validate PMS Base.

---

### 5.9 `08_relation_to_pms_rust.md`

#### Function

`08_relation_to_pms_rust.md` explains the relationship between PMS-STACK and PMS-RUST.

It positions PMS-RUST as bounded executable evidence spine, not as the source of PMS operator identity.

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
13.5 Simulation / Emulation
15.2 What Has Been Proven / Established
15.3 Completeness Conditions
15.4 Extensibility Conditions
Appendix H.2 Cross-Model Tables
Appendix E, where classical OS/VM boundary-relevant
```

The plan also identified later PMS-RUST sources:

```text
PMS-RUST README.md
pms-docs/ARCHITECTURE.md
pms-docs/ROADMAP.md
pms-docs/KEY_WORLDS.md
pms-docs/ACCEPTANCE_GATES.md
pms-docs/EVENT_FORMAT.md
golden fixtures
scripts
```

#### Release refinement

The final block is not a placeholder. It is a full claim-typed relation document.

It defines:

```text
PMS Base = source of operator identity
PMS-STACK = implementation-layer architecture specification
PMS-RUST = bounded executable Evidence Spine v0.1
```

It maps PMS-RUST evidence types to STACK claims:

```text
operator representation
deterministic execution
validation
JSONL traces
fixtures
REPL/script tooling
vFS surface
AI proposal boundary
chi_exit boundary-exit evidence where declared
```

It also includes the ChiExit / ISO_EXIT / Boundary-Exit mapping.

#### Claim boundary

PMS-RUST may strengthen bounded implementation-artifact claims.

It does not:

```text
validate PMS Base
complete PMS-STACK
complete PMS-CPU
complete PMS-OS
complete PMSL
complete distributed runtime
complete ISO_EXIT
redefine PMS Base Χ
turn AI output into trusted executable code
```

---

### 5.10 `09_non_goals_and_claim_boundary.md`

#### Function

`09_non_goals_and_claim_boundary.md` defines the claim discipline of the entire PMS-STACK corpus.

It is the main boundary document.

#### Source sections from `PMS-STACK.md`

The initial split plan assigned:

```text
1.1 Non-Goals
15.2 What Has Been Proven / Established
15.3 Completeness Conditions
15.4 Extensibility Conditions
15.5 Equivalences to Classical Frameworks
15.6 Canonical Closure
Appendix B.4 Turing Completeness
Appendix E PMS-STACK vs Classical OS Design
Appendix F Security Scenarios
Appendix G Optional Cluster Extensions
```

#### Release refinement

The final block expands the boundary layer substantially.

It includes:

```text
architectural claims
formal claims
computational expressiveness claims
OS and CPU specification claims
PMSL and runtime claims
security and governance claims
distributed systems claims
non-goals
not-yet-implemented status
not-proven status
classical framework relation
safe wording rules
trace / Trace distinction
AI boundary
chi_exit / ISO_EXIT boundary
Χ / Distance discipline
validated-under-profile definition
```

#### Claim boundary

This file keeps PMS-STACK strong and precise.

It does not weaken the architecture claim.

It prevents category errors.

The governing formula is:

```text
PMS-STACK specifies.
Artifacts evidence.
Tests inspect.
Traces record.
Validators accept or reject under declared profiles.
Formal proofs prove stated properties under models.
External validation validates under external protocols.
PMS Base remains the source of operator identity.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
```

---

## 6. Important Release Updates Integrated After Initial Split

The initial split plan was expanded during release work.

The following updates are now part of the canonical block corpus.

---

### 6.1 AI Bridge Integration

The AI Bridge is included only as optional tooling/profile support.

Correct role:

```text
AI Bridge = optional PMS-RUST tooling/profile for proposing PMS-IR/opcode
programs or analyzing traces under host-side validation.
```

It appears primarily in:

```text
01_blocks/05_pmsl_pms_ir.md
01_blocks/08_relation_to_pms_rust.md
01_blocks/09_non_goals_and_claim_boundary.md
```

It may also be referenced in security, evidence, and reader layers.

Required boundary:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI output is not:

```text
trusted executable code
compiler authority
verifier authority
verification evidence
runtime policy authority
PMSL semantics
PMS Base evidence
```

---

### 6.2 PMS-RUST Evidence Spine

PMS-RUST is treated as bounded executable evidence spine.

Correct role:

```text
PMS-RUST = bounded executable PMS-STACK Evidence Spine v0.1.
```

PMS-RUST may strengthen:

```text
operator representation
bounded deterministic execution
validation
trace emission
fixture discipline
REPL/script workflows
vFS boundary tests
AI proposal boundaries
chi_exit boundary-exit discipline where declared
```

It does not establish:

```text
PMS Base validation
PMS-STACK completion
full PMS-UM simulator
full PMS-CPU / ISA
full PMS-OS
full PMSL compiler
full distributed runtime
full formal verification
trusted AI execution
```

---

### 6.3 ChiExit / ISO_EXIT / Boundary-Exit Mapping

The modular corpus distinguishes architecture instruction from runtime evidence.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Boundary:

```text
PMS-RUST chi_exit does not redefine PMS Base Χ.
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.
PMS-RUST chi_exit does not complete PMS-OS isolation.
PMS-RUST chi_exit does not validate PMS Base.
```

---

### 6.4 Χ = Distance Discipline

The corpus preserves the PMS 1.3 operator identity:

```text
PMS Base 1.3:
    Χ = Distance
```

At PMS-STACK implementation layers, Χ may project as:

```text
isolation
reachability control
boundary management
access separation
sandboxing
containment
quarantine
namespace/device/IPC visibility
trust-domain separation
cross-node boundary
```

Boundary:

```text
implementation projection does not redefine PMS Base Χ.
```

---

### 6.5 trace / Trace Notation

The corpus uses:

```text
trace(...)
```

for a single execution.

It uses:

```text
Trace(...)
```

for a declared set of possible executions under profile.

Canonical examples:

```text
trace(artifact, profile, input) ∈ L_PMS
Trace(artifact, profile) ⊆ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Distributed forms:

```text
traceᴳ(D, profile, input) ∈ L_PMS
Traceᴳ(D, profile) ⊆ L_PMS
```

Under active distributed policy:

```text
traceᴳ(D, profile, input) ∈ L_PMS,Ψᴳ
Traceᴳ(D, profile) ⊆ L_PMS,Ψᴳ
```

Boundary:

```text
A recorded trace evidences one concrete trace(...).
It does not enumerate or prove the whole Trace(...) set.
```

---

### 6.6 Tuple Synchronization

The PMS-UM tuple is:

```text
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

The PMS-CPU tuple is:

```text
M_CPU = (
    S_CPU,
    Γ_CPU,
    F_CPU,
    R_CPU,
    PSet_CPU,
    O,
    ISA,
    Π_CPU,
    δ_CPU,
    s₀_CPU,
    S_H_CPU
)
```

Release checks confirmed that `00_overview.md`, `08_relation_to_pms_rust.md`, and `09_non_goals_and_claim_boundary.md` do not contain obsolete tuple forms.

---

### 6.7 PMS-OS Resource and Syscall Discipline

The release corpus distinguishes:

```text
RF
    register file, where used

RAcc / ResourceAccount
    OS-level resource accounting
```

This prevents collision between register-file notation and resource accounting.

The PMS-OS syscall path is a dedicated trap/syscall ABI.

It does not redefine ordinary PMS-CPU calling convention.

Canonical syscall operator word includes `□` and `Χ`:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

OS isolation-domain values are not PMS Base Χ itself.

Preferred notation:

```text
IDom_user
IDom_global
```

Legacy examples using `X_user`, `X_global`, or comparable forms denote OS-level isolation-domain values.

---

## 7. Recommended Historical Development Order

The initial split plan recommended this development order:

```text
01_architecture.md
09_non_goals_and_claim_boundary.md
00_overview.md
02_pms_um.md
03_pms_cpu.md
04_pms_os.md
05_pmsl_pms_ir.md
06_runtime_security.md
07_distributed_systems.md
08_relation_to_pms_rust.md
```

The rationale was:

```text
stabilize architecture first
stabilize claim boundary second
write overview after architecture/boundary are known
then elaborate technical layers
close with PMS-RUST relation
```

The final release process broadly followed this dependency logic, with later patches applied for:

```text
Χ discipline
trace / Trace discipline
Π / Π_CPU tuple discipline
AI Bridge boundary
PMS-RUST evidence spine
chi_exit / ISO_EXIT mapping
PMS-OS syscall/resource-accounting discipline
```

---

## 8. Current Status of the Split

Current status:

```text
01_blocks/00_overview.md
    release-candidate

01_blocks/01_architecture.md
    release-candidate

01_blocks/02_pms_um.md
    release-candidate

01_blocks/03_pms_cpu.md
    release-candidate

01_blocks/04_pms_os.md
    release-candidate

01_blocks/05_pmsl_pms_ir.md
    release-candidate

01_blocks/06_runtime_security.md
    release-candidate

01_blocks/07_distributed_systems.md
    release-candidate

01_blocks/08_relation_to_pms_rust.md
    release-candidate

01_blocks/09_non_goals_and_claim_boundary.md
    release-candidate
```

The block corpus is complete at the architecture specification layer.

Remaining corpus work belongs to reference, minified, derivative publication, README, and Reader layers:

```text
02_reference/
03_minified/
04_derivative_publications/
README.md
05_PMS-STACK Reader/
```

These layers do not change the canonical specification.

They index, compress, explain, or navigate it.

---

## 9. Non-Canonical Status of This File

This file is part of:

```text
00_source/
```

Its role is documentary.

It records the source-to-block transformation.

It should not be cited as the canonical source for PMS-STACK semantics when `01_blocks/00–09` are available.

Correct use:

```text
Use this file to understand how PMS-STACK.md became the modular corpus.
```

Incorrect use:

```text
Use this file instead of 01_blocks/00–09 as the specification.
```

Boundary:

```text
This file documents the split.
It does not define PMS-STACK.
It does not redefine PMS Base.
It does not add operators.
It does not validate PMS Base.
It does not complete implementation.
It does not prove PMS-STACK.
```

---

## 10. Final Split Formula

The final split formula is:

```text
PMS-STACK.md
    source monolith / origin material

PMS-STACK_Split_Specification_v0.1.md
    source-to-block documentation

README.md + 01_blocks/00–09
    canonical PMS-STACK specification

02_reference/
    index and audit layer

03_minified/
    compression and contract layer

04_derivative_publications/
    explanatory publication layer

05_PMS-STACK Reader/
    local navigation and inspection layer
```

The final corpus formula is:

```text
PMS-STACK is specified in canonical blocks,
indexed in reference files,
compressed in minified contracts,
explained in derivative publications,
and navigated through the Reader.
```

Expanded:

```text
README.md + 01_blocks/00–09 define PMS-STACK.

00_source preserves provenance.
02_reference indexes PMS-STACK.
03_minified compresses PMS-STACK.
04_derivative_publications explains PMS-STACK.
05_PMS-STACK Reader navigates PMS-STACK.

None of the derivative or source-supporting layers replace the canonical
blocks or validate PMS Base.
```