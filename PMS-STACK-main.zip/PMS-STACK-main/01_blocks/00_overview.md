---
document_id: PMS-STACK-DOC-00
title: "PMS-STACK Overview"
source: "PMS-STACK.md"
source_role: "modularized overview extraction and claim-typed refinement"
status: "release-candidate"
version: "v0.3"
owner_sections:
  - "1. Introduction & Model Lineage"
  - "1.1 Motivation, Scope & Non-Goals"
  - "1.2 Lineage"
  - "1.3 Relation to Existing OS & Architecture Families"
  - "1.4 Intended Use, Audience & Reading Guide"
  - "15.1 Unified Stack Overview"
  - "15.7 Epilogue Statement"
secondary_references:
  - "2. Formal Foundations"
  - "2.1 PMS Operator Recap"
  - "2.2 PMS → IT Structural Mapping"
  - "Appendix E — PMS-STACK vs. Classical OS Design"
  - "Appendix H.2 Cross-Model Tables"
external_reference_files:
  - "PMS.yaml"
  - "Praxeological Meta-Structure Theory.md"
  - "PMS - UNDER LOAD.md"
  - "PMS-RUST README.md"
claim_type: "implementation-layer architecture claim"
claim_mode: "complete systems-architecture orientation; claim-typed; non-validating"
pms_base_status: "source of truth for Δ–Ψ operator identity and application boundaries"
stack_status: "implementation-layer architecture specification; not PMS Base validation"
pms_rust_status: "bounded executable artifact evidence; relevant to later relation document; not required for this overview"
chi_status: "PMS Base 1.3 Χ = Distance; PMS-STACK projects Χ as isolation, reachability control, boundary management, and access separation"
scope: "orientation layer for the modular PMS-STACK specification"
non_goal: "not the formal core, not an implementation report, not a proof document, not PMS Base validation"
claim_boundary_reference: "09_non_goals_and_claim_boundary.md"
overview_expansion_status: "claim-map aligned with modular docs 01–09"
depends_on:
  - "01_architecture.md"
links_forward_to:
  - "01_architecture.md"
  - "02_pms_um.md"
  - "03_pms_cpu.md"
  - "04_pms_os.md"
  - "05_pmsl_pms_ir.md"
  - "06_runtime_security.md"
  - "07_distributed_systems.md"
  - "08_relation_to_pms_rust.md"
  - "09_non_goals_and_claim_boundary.md"
---

# PMS-STACK Overview

## 1. Purpose of PMS-STACK

PMS-STACK (“Praxeological Meta-Structure — STACK”) is a unified architecture for computation, operating systems, CPU design, runtime semantics, programming language structure, security, networking, and distributed systems.

Its central purpose is to instantiate the PMS operator grammar — the Δ–Ψ sequence — as a complete implementation-layer computational architecture. PMS-STACK does not begin from historically accumulated operating-system abstractions and then attempt to organize them after the fact. Instead, it starts from a formal operator sequence and derives computational structures from it.

The guiding operator sequence is:

```text
distinguish → act → frame → absence → pattern → asymmetry
→ temporality → reframe → distance, projected as boundary → integrate → bind policy
```

In PMS notation:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

PMS-STACK treats this sequence not as a metaphor for computation, but as the structural basis from which computational layers can be specified. CPU opcodes, execution steps, frames, processes, privileges, traps, isolation domains, commits, policies, protocols, and runtime constructs are interpreted as concrete projections of the same operator grammar.

PMS-STACK is the implementation-layer architecture specification of PMS: a complete systems architecture in which machine, CPU, OS, runtime, language, security, networking, tooling, boot, and distributed-system structures are derived from Δ–Ψ.

This is an implementation-layer architecture claim. It strengthens the architectural and realization claim of PMS-STACK; it does not function as PMS Base validation and does not imply that every layer is already implemented as an executable artifact.

The purpose of the architecture is therefore twofold:

1. to define a formal computational stack grounded in the PMS operator model;
2. to show, at the architecture level, how classical systems concepts can be reconstructed as restricted or partial projections of Δ–Ψ operator semantics.

PMS-STACK is thus an architecture specification, not merely a terminology mapping. Its claim is that the same operator structure can organize the universal machine layer, virtual CPU layer, kernel layer, runtime layer, language layer, networking layer, security layer, tooling layer, and distributed-systems layer.

At the highest level, PMS-STACK provides:

* a universal operational semantics through PMS-UM, specified as a computational expressiveness claim at the abstract-machine architecture layer;
* a virtual CPU and ISA model through PMS-CPU;
* an operating-system kernel model through PMS-OS;
* memory, filesystem, IPC, event, driver, and networking subsystems;
* a security and governance model based on role, isolation, policy, audit, and commit semantics;
* a programming-language and runtime model through PMSL and PMS-IR;
* tooling, verification, simulation, and boot/deployment structures;
* optional distributed and cluster profiles through lifted operator semantics.

The architectural ambition is not to reproduce an existing OS family under new names, but to define a coherent formal stack in which every major computational layer is read as an operator-constrained projection of PMS.

---

## 2. Scope of the Architecture

PMS-STACK defines a full systems architecture. Its scope includes the formal operator calculus, abstract machine semantics, virtual CPU design, operating-system kernel structure, memory and storage subsystems, IPC and event handling, device and driver models, networking, security, language/runtime design, verification, tooling, boot, and distributed orchestration.

The architecture covers the following major layers:

```text
PMS Operators (Δ–Ψ)
    ↓
Monoid + Dependency System
    ↓
PMS-UM
    ↓
PMS-CPU
    ↓
PMS-OS Kernel
    ↓
Memory, Storage
    ↓
IPC, Events, Devices
    ↓
Networking Stack
    ↓
Security & Governance
    ↓
PMSL Language & Runtime
    ↓
Tooling, Verification, Simulation
    ↓
Boot & Deployment
    ↓
Optional Cluster / Distributed Profiles
```

These layers are not treated as independent subsystems that merely communicate through interfaces. They are treated as layer-specific projections of the same operator algebra. A frame at one layer may appear as an abstract state partition, a CPU execution domain, an OS address space, a language scope, a network session, a node scope, or a distributed cluster context. A policy may appear as an abstract constraint, a privilege check, a kernel invariant, a PMSL policy block, a runtime security rule, or a distributed governance condition.

The scope of PMS-STACK therefore includes both abstract formalization and concrete systems mapping. It defines:

* the Δ–Ψ operator alphabet;
* a constrained language of valid operator sequences;
* the PMS Universal Machine as an abstract computation model;
* the PMS Virtual CPU as a concrete execution architecture;
* the PMS-OS kernel as a policy-, frame-, role-, and isolation-aware kernel structure;
* memory, storage, filesystem, and driver models;
* IPC, synchronization, event, and networking semantics;
* PMSL as an operator-typed programming language;
* PMS-IR as an operator-preserving intermediate representation;
* runtime and standard-library structures;
* security and governance structures;
* verification, debugging, tracing, and simulation models;
* boot, deployment, upgrade, and cluster orchestration semantics.

The scope is architectural and semantic. PMS-STACK specifies how these layers are structured and how they relate to PMS operators. It does not, in this overview document, provide the complete details of every subsystem. Those details are distributed across the remaining documents in the modular specification.

PMS-STACK is the implementation-layer architecture specification of this computational stack. Implementations may realize subsets, prototypes, simulators, evidence spines, kernels, runtimes, compilers, or distributed systems based on this architecture. No single implementation exhausts the architecture.

---

## 3. Claim Orientation

PMS-STACK uses strong claims, but they are typed claims.

The primary claim of PMS-STACK is an implementation-layer architecture claim:

```text
PMS-STACK specifies a complete implementation-layer operator-grounded
systems architecture derived from Δ–Ψ.
```

This means that PMS-STACK defines the intended architectural structure of the stack:

```text
abstract machine
virtual CPU
operating system
memory
storage
IPC
devices
runtime
language
IR
security
networking
distributed systems
simulation
verification
boot
implementation evidence relations
```

It does not mean that every specified layer is already implemented.

The core claim distinction is:

```text
architecture specification
    ≠ completed implementation

computational expressiveness
    ≠ proof of every system property

artifact evidence
    ≠ PMS Base validation

classical-system expressibility
    ≠ full equivalence to every classical implementation

distributed architecture
    ≠ completed distributed runtime

security architecture
    ≠ universal security certification
```

The documentation therefore uses the following claim discipline:

```text
strong claim → claim type → boundary
```

Examples:

```text
PMS-CPU is a virtual CPU / ISA architecture claim.

PMS-OS is an operating-system architecture claim.

PMSL and PMS-IR are language/runtime specification claims.

Runtime security is an operator-structured runtime-discipline claim.

Distributed PMS-STACK is a distributed architecture/profile claim.

PMS-RUST is a bounded executable implementation/artifact evidence claim.
```

This claim discipline preserves PMS-STACK’s ambition while preventing category errors. PMS-STACK is not made weaker by saying what kind of claim it makes. It becomes more precise.

### 3.1 Claim Layers

PMS-STACK documentation distinguishes the following claim layers:

```text
PMS Base
    source of operator identity and PMS 1.3 grammar

PMS-STACK
    implementation-layer architecture specification

PMS-RUST
    bounded executable evidence spine / implementation artifact

tests, traces, fixtures
    bounded artifact evidence

formal verification
    property-specific proof or model-check claim under stated model

external validation
    independent validation under external protocol
```

The relation is:

```text
PMS Base defines operator identity.
PMS-STACK projects operators into systems architecture.
PMS-RUST implements bounded slices.
Tests and traces inspect bounded executions.
Formal proofs prove stated properties under models.
External validation validates under external protocols.
```

No lower layer automatically validates the base layer.

### 3.2 Claim-Type Examples

| Statement | Claim type | Boundary |
| --------- | ---------- | -------- |
| PMS-STACK derives CPU, OS, runtime, language, security, networking, and distributed systems from Δ–Ψ | architecture claim | not completed implementation by itself |
| PMS-UM is specified as computationally universal at the abstract-machine architecture layer | computational expressiveness claim | not OS/security correctness, proof of all system properties, or PMS Base validation |
| PMS-CPU specifies an ISA | virtual CPU architecture claim | not fabricated hardware |
| PMS-OS specifies a kernel architecture | OS architecture claim | not production OS by itself |
| PMSL specifies operator-typed programming | language specification claim | not complete compiler by itself |
| Runtime security is operator-structured | security architecture claim | not universal security certification |
| Distributed commit is represented as Σᴳ under Ψᴳ | distributed architecture claim | not consensus-algorithm proof |
| PMS-RUST executes bounded operator programs | implementation/artifact claim | not PMS-STACK completion |
| JSONL traces record executions | trace evidence claim | not proof of all behavior |
| Golden fixtures stabilize cases | regression evidence claim | not exhaustive correctness |

PMS-UM computational universality is therefore claim-typed:

```text
Claim:
    PMS-UM is specified as computationally universal at the abstract-machine
    architecture layer.

Claim type:
    computational expressiveness / formal architecture claim.

Boundary:
    This does not prove OS correctness, CPU implementation correctness,
    security correctness, distributed correctness, all-program termination,
    or PMS Base validation.
```

### 3.3 Claim Orientation Boundary

This overview introduces claim discipline, but it does not replace the full claim-boundary document.

The governing reference for detailed non-goals, proof boundaries, implementation boundaries, safe wording, and PMS-RUST evidence boundaries is:

```text
09_non_goals_and_claim_boundary.md
```

This overview orients the reader.

`09_non_goals_and_claim_boundary.md` governs claim discipline in detail.

---

## 4. Model Lineage

PMS-STACK belongs to a broader development path that moves from conceptual praxeology toward formal operator modeling and then toward computational architecture.

The lineage is:

```text
Maturity in Practice
    ↓
MIPractice YAML model
    ↓
Praxeological Meta-Structure (PMS.yaml)
    ↓
PMS-STACK
```

In this lineage, each stage increases formal explicitness.

**Maturity in Practice** provides the qualitative and conceptual foundations: action, asymmetry, framing, roles, temporality, recontextualization, maturity, and self-binding.

The **MIPractice YAML model** translates these conceptual structures into a structured model suitable for analysis, inference, and transformation.

**PMS.yaml** distills the model further into the PMS operator grammar. The eleven operators Δ–Ψ become the minimal formal vocabulary for describing structural transformations of praxis.

**PMS-STACK** then instantiates this grammar in computation. It asks what follows if the Δ–Ψ operators are not only used to analyze praxis in general, but are used as the generative basis for a computational stack.

The central lineage claim is that PMS-STACK is not merely inspired by PMS. At the implementation-architecture layer, it is PMS instantiated as a systems architecture. The operating-system concepts are not imported first and then decorated with PMS terminology. Rather, the stack is organized so that each computational concept corresponds to a structural consequence of the operator grammar.

This lineage matters because it constrains the architecture. PMS-STACK should not introduce arbitrary subsystems that have no operator role. Conversely, when classical systems concepts appear — processes, frames, interrupts, syscalls, files, schedulers, policies, capabilities, protocols — they should be explained through their operator semantics.

The lineage also establishes the basic discipline of the specification:

* do not treat PMS-STACK as a POSIX clone;
* do not treat it as a conventional microkernel with new names;
* do not treat PMSL as an unrelated programming language;
* do not treat security as an afterthought;
* do not treat distributed systems as an external extension detached from the operator model;
* do not treat PMS-RUST or any artifact as the source of PMS Base identity.

Each layer should remain traceable to Δ–Ψ.

---

## 5. PMS-STACK as Computational Instantiation of Δ–Ψ

PMS-STACK interprets computation as structured operator execution. Every computational act presupposes distinction, action, framing, ordering, role, boundary management, integration, and policy in some form. Classical architectures often distribute these concerns across unrelated mechanisms: opcodes, memory maps, syscalls, process tables, schedulers, exception handlers, access-control systems, transaction systems, and configuration policies.

PMS-STACK makes those structures explicit as operator semantics.

At the operator level:

| Operator | Computational role |
| -------- | ------------------ |
| Δ | distinction, classification, opcode selection, type or message discrimination |
| ∇ | action, mutation, execution, write, syscall invocation |
| □ | frame, scope, address space, namespace, execution context |
| Λ | timeout, non-event, absence, idle state, missing message |
| Α | recurrent pattern, macro, grammar, protocol flow |
| Ω | role, privilege, capability, asymmetry |
| Θ | ordering, scheduling, sequence, temporal progression |
| Φ | recontextualization, exception, trap, migration, fallback |
| Χ | Distance projected as isolation, reachability boundary, sandbox, protection |
| Σ | integration, commit, merge, transaction finalization |
| Ψ | policy, invariant, self-binding, governance constraint |

The Χ row uses PMS-STACK’s implementation-layer projection. In PMS Base 1.3, Χ denotes Distance. Within PMS-STACK, Χ is projected as isolation, reachability control, boundary management, and access separation in computational systems. This overview uses the implementation-layer projection when discussing CPU, OS, runtime, network, and distributed-system structures.

This mapping is not limited to one layer. The same operator may appear differently across the stack:

* Δ is a branch condition in an abstract machine, an opcode distinction in a CPU, a syscall number in a kernel, a message kind in IPC, or a type distinction in PMSL.
* □ is a state partition in PMS-UM, a page or execution domain in PMS-CPU, a process address space in PMS-OS, a module or scope in PMSL, a network session frame, or a cluster frame in distributed PMS.
* Ω is an abstract capability relation, a privilege bit, a kernel role, a security label, a runtime authority relation, or a protocol-side node authority.
* Φ is a recontextualization in the abstract semantics, an interrupt or trap in CPU terms, a signal or fault in OS terms, an exception handler in PMSL, or a migration/recovery step in distributed systems.
* Χ is Distance at PMS Base level and becomes computationally concrete as isolation, protected reachability, sandboxing, boundary management, and access separation.
* Ψ is a constraint on valid transitions, a hardware or kernel invariant, a language-level policy, a runtime security rule, or a distributed governance condition.

The architecture therefore treats each layer as a restricted PMS-UM instance. A CPU is not outside the operator model; it is a concrete execution projection. A kernel is not outside the operator model; it is a persistent frame-, role-, isolation-, and policy-governed transition system. A language is not outside the operator model; it is a surface syntax and type system for operator-typed computation. A distributed system is not outside the operator model; it is a scoped lifting of the same operators into node, route, session, shard, cluster, or federation frames.

This is the core meaning of PMS-STACK as computational instantiation: the Δ–Ψ grammar is not merely documented at the top of the stack, but propagated through each layer as the invariant semantic spine.

### 5.1 Semantic Scaling

PMS-STACK treats later layers as semantic scaling of the same operator grammar.

The local operator semantics remain stable while their scope changes:

```text
local frame
→ process frame
→ runtime frame
→ network session frame
→ node frame
→ cluster frame
→ federation frame
```

Thus a local commit `Σ` may become a distributed commit `Σᴳ` under a global policy `Ψᴳ`; a local frame `□` may become a cluster frame `□ᴳ`; a local role `Ω` may become a node, controller, orchestrator, participant, or quorum role `Ωᴳ`.

This does not introduce a new base operator alphabet. It marks scope.

```text
semantic scaling =
    same operator grammar
    + explicit frame/scope expansion
    + profile-specific implementation obligations
```

This principle becomes especially important in `07_distributed_systems.md`, where networking, cluster frames, distributed commit, consensus-related policy, cross-node isolation, cluster boot, upgrade, and distributed audit are treated as scope-lifted PMS-STACK structures.

### 5.2 Operator Identity and Projection

PMS-STACK preserves PMS Base operator identity while projecting operators into computational layers.

The most important projection boundary in this overview is Χ:

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK implementation layer:
    Χ projects as isolation, reachability control, boundary management,
    access separation, sandboxing, quarantine, and cross-frame separation.
```

This is not a redefinition of PMS Base.

It is an implementation-layer projection.

The same discipline applies throughout the stack:

```text
base operator identity
→ architecture-level projection
→ layer-specific implementation semantics
→ artifact-specific evidence where implemented
```

---

## 6. Relation to Classical OS and Architecture Families

PMS-STACK relates to classical operating-system and architecture families by reinterpretation rather than direct replacement. It does not begin by choosing Unix, POSIX, microkernel, exokernel, WASM, capability OS, or actor models as its base. Instead, it treats these as partial projections of operator structures.

A simplified comparison:

| System family | PMS-STACK interpretation |
| ------------- | ------------------------ |
| Unix / POSIX | Emergent Δ→∇→□→Ω→Θ patterns constrained by historically accumulated policies |
| Microkernel | Partial alignment with strong Χ isolation and Φ message/trap semantics |
| Exokernel | Similar minimality, but without full operator-level semantics and policy binding |
| WASM | Restricted Δ/∇ fragment with limited expression of Ω, Φ, Χ, Σ, Ψ |
| Capability OS | Strong Ω alignment, but without the full Δ–Ψ operator grammar |
| Actor models | Subset of □ + Θ + Δ/Λ + Φ structures, typically without full invariants |

This comparison is structural rather than polemical: PMS-STACK situates existing architectures as historically evolved or restricted projections of operator structures.

For example, a microkernel emphasizes isolation and message-mediated interaction. In PMS-STACK terms, this gives strong importance to Χ as implementation-layer isolation and Φ as message/trap recontextualization, supported by □, Ω, and Θ. A capability OS gives strong importance to Ω, because authority is represented through capabilities. Actor systems emphasize framed entities, message handling, ordering, and event absence; they therefore correspond naturally to combinations of □, Θ, Δ, Λ, and Φ. WASM provides a constrained execution environment with strong control over action and memory, but it does not expose the full operator space as a governing architecture.

PMS-STACK differs from these systems because it makes the operator basis explicit and complete across the stack. It does not isolate security, scheduling, traps, roles, frames, commits, and policies as separate engineering concerns. Instead, it treats them as structurally related operators.

The result is a formal re-reading: existing architectures can be situated as restricted fragments, partial projections, or historically evolved subsets of the Δ–Ψ grammar.

### 6.1 Classical Relation Boundary

Classical-system mapping is an expressibility and architecture-orientation claim.

Correct:

```text
PMS-STACK can express POSIX-like, microkernel-like, VM-like, WASM-like,
actor-model, capability-system, and distributed-system structures as
operator projections or specializations.
```

Incorrect:

```text
PMS-STACK is POSIX.
PMS-STACK is merely a VM.
PMS-STACK is a classical microkernel.
PMS-STACK proves Raft, Paxos, or CRDT correctness.
```

PMS-STACK is structurally continuous with classical systems, but it is not reduced to any one classical framework.

Classical comparisons orient the reader.

They do not validate PMS Base.

---

## 7. Intended Audience and Reading Path

PMS-STACK is intended for readers concerned with formal systems architecture, operating-system design, programming-language semantics, runtime design, verification, security, and distributed systems.

The main intended audiences are:

* OS designers;
* systems programmers;
* CPU and virtual-machine designers;
* programming-language developers;
* runtime and compiler engineers;
* formal verification researchers;
* distributed-systems architects;
* security and governance modelers.

The prerequisite for reading PMS-STACK is not prior familiarity with every classical systems layer. The main prerequisite is understanding the operator grammar. Once the operator model is understood, each layer can be read as a projection of that grammar.

A recommended reading path is:

1. **Overview**  
   Read this file first to understand the purpose, scope, lineage, claim orientation, and document structure.

2. **Architecture**  
   Read `01_architecture.md` for the operator set, monoid structure, dependency constraints, state model, and cross-layer mappings.

3. **Universal Machine**  
   Read `02_pms_um.md` for the abstract machine model and operator-typed execution semantics.

4. **Virtual CPU**  
   Read `03_pms_cpu.md` for registers, memory model, ISA, calling conventions, traps, binary encoding, execution cycle, and memory consistency.

5. **Operating System**  
   Read `04_pms_os.md` for kernel goals, process and thread model, scheduling, syscalls, resource accounting, memory, filesystem, IPC, events, and drivers.

6. **Language and IR**  
   Read `05_pmsl_pms_ir.md` for PMSL, runtime architecture, standard libraries, PMS-IR, analysis, verification, debugging, and simulation.

7. **Runtime Security**  
   Read `06_runtime_security.md` for identity, roles, capabilities, isolation, policy enforcement, audit, trust anchors, and governance.

8. **Distributed Systems**  
   Read `07_distributed_systems.md` for networking, PMS protocols, resilience, cluster frames, distributed commit, cross-node isolation, and multi-node boot.

9. **Relation to PMS-RUST**  
   Read `08_relation_to_pms_rust.md` for the relation between the PMS-STACK architecture and the PMS-RUST evidence spine or implementation subset.

10. **Non-Goals and Claim Boundary**  
    Read `09_non_goals_and_claim_boundary.md` to understand what PMS-STACK claims, what it does not claim, what is specified, what is implemented elsewhere, what is proven, what is not proven, and what remains future work.

The modular structure is designed so that readers can enter through their domain of expertise while still preserving the operator grammar as common ground.

---

## 8. Modular Claim Map

The modular documents divide PMS-STACK by architecture layer and claim type.

| Document | Primary function | Claim type | Boundary |
| -------- | ---------------- | ---------- | -------- |
| `00_overview.md` | orientation, scope, lineage, reading path | overview / orientation claim | not formal core, not implementation report |
| `01_architecture.md` | operator foundation, monoid, dependencies, state/configuration, cross-layer mappings | central architecture claim | does not replace PMS Base |
| `02_pms_um.md` | abstract machine and operator-typed execution | abstract-machine / expressiveness claim | not full simulator by itself |
| `03_pms_cpu.md` | virtual CPU / ISA | virtual CPU architecture claim | not fabricated hardware |
| `04_pms_os.md` | kernel, process, syscall, memory, storage, IPC, devices | OS architecture claim | not completed production OS |
| `05_pmsl_pms_ir.md` | PMSL, PMS-IR, runtime, compiler-analysis path | language/runtime specification claim | not complete compiler unless artifact-backed |
| `06_runtime_security.md` | identity, roles, capabilities, policy, audit, trust, attack/failure handling | runtime-security architecture claim | not universal security certification, not tribunal |
| `07_distributed_systems.md` | networking, cluster frames, operator lifting, distributed commit, cross-node isolation | distributed architecture/profile claim | optional by runtime profile; not algorithm proof |
| `08_relation_to_pms_rust.md` | STACK/RUST relation and evidence spine | implementation/artifact relation claim | PMS-RUST strengthens artifacts, not PMS Base |
| `09_non_goals_and_claim_boundary.md` | claim discipline, non-goals, proof and implementation boundaries | boundary/governance-of-claims document | governs wording; does not weaken claims |

This table is part of the overview’s claim orientation. It gives the reader the status of each document before entering technical details.

### 8.1 Modular Dependency

The modular stack has one central dependency:

```text
01_architecture.md
```

All other documents depend on it.

The relation is:

```text
01_architecture.md
    → defines the operator and architecture grammar

02_pms_um.md
    → instantiates the grammar as an abstract machine

03_pms_cpu.md
    → specializes the abstract machine as virtual CPU / ISA

04_pms_os.md
    → builds the operating-system layer over the virtual execution model

05_pmsl_pms_ir.md
    → defines the language, IR, runtime, and analysis path

06_runtime_security.md
    → defines security/governance as runtime operator discipline

07_distributed_systems.md
    → scales the same semantics into networked and clustered profiles

08_relation_to_pms_rust.md
    → maps architecture claims to bounded executable evidence

09_non_goals_and_claim_boundary.md
    → governs non-goals, boundaries, proof status, and safe wording
```

### 8.2 Boundary of the Modular Claim Map

The modular claim map is not a proof table.

It is a documentation-orientation table.

It tells the reader how to interpret the role of each file.

Detailed claims, invariants, non-goals, proof boundaries, and implementation boundaries are stated inside the corresponding documents.

---

## 9. Document Map

The PMS-STACK specification is organized into ten primary documents under `docs/`.

```text
docs/
├─ 00_overview.md
├─ 01_architecture.md
├─ 02_pms_um.md
├─ 03_pms_cpu.md
├─ 04_pms_os.md
├─ 05_pmsl_pms_ir.md
├─ 06_runtime_security.md
├─ 07_distributed_systems.md
├─ 08_relation_to_pms_rust.md
└─ 09_non_goals_and_claim_boundary.md
```

### `00_overview.md`

Introduces PMS-STACK, its purpose, scope, claim orientation, lineage, relation to classical architectures, intended audience, reading path, document map, and overview-level boundaries.

This file is the orientation layer. It introduces the architecture without replacing the formal core.

### `01_architecture.md`

Defines the operator foundation of PMS-STACK.

It covers the Δ–Ψ operator set, PMS-to-IT mapping, monoid and dependency structure, well-formed operator sequences, state/configuration models, architectural invariants, and cross-layer homomorphisms.

All other documents depend on this one.

### `02_pms_um.md`

Defines the PMS Universal Machine.

It specifies the abstract machine tuple, state and configuration model, programs, operator-typed instructions, step relation, dependency-constrained execution, determinism/non-determinism, and the relationship to classical computation models.

### `03_pms_cpu.md`

Defines the PMS Virtual CPU.

It covers registers, memory, frames, privilege and role models, instruction families, ISA conventions, calling conventions, interrupt/trap semantics, binary encoding, fetch–decode–execute, commit behavior, and memory consistency.

The primary claim is a virtual CPU / ISA architecture claim. It does not assert fabricated hardware.

### `04_pms_os.md`

Defines the PMS Operating System layer.

It covers kernel goals, trust model, process and thread model, scheduling, isolation, policy engine, syscalls, resource accounting, virtual memory, allocation, filesystem architecture, block devices, caching, IPC, synchronization, events, and driver lifecycle.

The primary claim is an operating-system architecture claim. It does not assert a completed production OS.

### `05_pmsl_pms_ir.md`

Defines PMSL and PMS-IR.

It covers language grammar, operator mapping, type system, concurrency, errors, modules, FFI, runtime architecture, standard library domains, PMS-IR, static analysis, model checking, observability, and simulation.

The primary claim is a language/runtime specification claim. It does not assert a complete compiler unless artifact evidence supports that claim.

### `06_runtime_security.md`

Defines runtime security and governance.

It covers identity, principals, roles, capabilities, isolation, policy enforcement, kernel hooks, audit/compliance hooks, trust anchors, network security integration, and attack/failure handling.

The primary claim is a runtime-security architecture claim. It does not assert universal security certification, legal authority, moral authority, clinical authority, or tribunal status.

### `07_distributed_systems.md`

Defines distributed PMS-STACK systems.

It covers networking, transport frames, addressing, routing, PMS protocol suite integration, resilience, cluster frames, operator lifting, distributed commit, consensus-related structures, cross-node isolation, cluster boot, upgrade, audit, and verification.

The primary claim is a distributed architecture/profile claim. Distributed profiles are optional by runtime profile; they are not algorithm proofs and not mandatory for every implementation.

### `08_relation_to_pms_rust.md`

Explains the relationship between the PMS-STACK architecture specification and PMS-RUST as a bounded executable PMS-STACK Evidence Spine.

This document distinguishes full architecture from executable subset, runtime validation from complete formal verification, trace/audit evidence from full kernel observability, AI proposal gating from a PMSL compiler, and implementation-artifact evidence from PMS Base validation.

### `09_non_goals_and_claim_boundary.md`

States non-goals and claim boundaries.

It distinguishes architecture from implementation, specification from proof, virtual CPU from hardware implementation, PMSL specification from implemented compiler, distributed architecture from deployed distributed runtime, formal expressiveness from universal explanatory closure, traces/tests from proof, PMS-RUST evidence from PMS-STACK completion, and PMS-STACK from PMS Base validation.

This document is part of the specification discipline. It keeps PMS-STACK’s strong architecture claims typed, bounded, and reusable.

---

## 10. Boundary of This Overview

This overview is an orientation document. It introduces PMS-STACK as the implementation-layer architecture specification of PMS, but it does not replace the formal architecture documents.

Specifically, this overview does not fully define:

* the PMS operator calculus;
* the monoid and dependency language;
* formal state and transition semantics;
* the PMS-UM machine tuple;
* the PMS-CPU ISA;
* binary instruction encoding;
* OS kernel data structures;
* scheduling algorithms;
* syscall semantics;
* memory consistency rules;
* PMSL grammar and type system;
* PMS-IR lowering rules;
* runtime implementation profiles;
* verification algorithms;
* distributed commit mechanisms;
* security policy algebra;
* implementation details;
* proof artifacts;
* external validation protocols.

Those topics belong to the corresponding technical documents.

This overview also does not independently extend PMS-STACK beyond the source architecture. It does not introduce new operators, new subsystems, new implementation claims, or new theoretical commitments. Its role is to reorganize and explain the PMS-STACK entry layer in a modular documentation structure.

The overview should therefore be read as the guide to the architecture, not as the full architecture itself.

The phrase “complete architecture” is an implementation-layer architecture claim. It means that PMS-STACK defines the intended stack structure and operator semantics across machine, CPU, OS, runtime, language, security, networking, tooling, boot, and distributed systems.

This strengthens the PMS-STACK architecture claim. It does not function as PMS Base validation, does not prove PMS as a praxis theory, and does not imply that every layer is already implemented, empirically validated, hardware-realized, deployed, or formally proven in all details.

Some parts of PMS-STACK may be directly implementable. Some may be executable through prototypes, simulators, or evidence-spine systems. Some may remain formal or future-facing. The modular documentation should preserve this distinction throughout.

For that reason, the final claim boundaries are collected separately in `09_non_goals_and_claim_boundary.md`.

This overview introduces the stack.

The boundary document governs how far the claims may be taken.

### 10.1 Final Overview Boundary

The final overview boundary is:

```text
00_overview.md orients.
01_architecture.md defines the central architecture.
02–07 specify architecture layers.
08 relates PMS-STACK to bounded executable evidence.
09 governs claim discipline.
```

This overview is therefore intentionally strong and intentionally bounded:

```text
strong architecture
typed claim
clear boundary
forward links to technical documents
no PMS Base validation drift
```
