---
document_id: PMS-STACK-DOC-08
title: "Relation to PMS-RUST"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "implementation-artifact relation and evidence-boundary claim"
pms_base_status: "source of Δ–Ψ operator identity"
stack_status: "implementation-layer architecture specification"
pms_rust_status: "bounded executable PMS-STACK Evidence Spine v0.1"
chi_status: "PMS Base 1.3 Χ = Distance; PMS-RUST v0.1 projects Χ/Chi as runtime isolation/boundary scope; chi_exit is bounded runtime boundary-exit evidence and does not redefine Base Χ"
depends_on:
  - "01_architecture.md"
  - "02_pms_um.md"
  - "03_pms_cpu.md"
  - "04_pms_os.md"
  - "05_pmsl_pms_ir.md"
  - "06_runtime_security.md"
  - "07_distributed_systems.md"
links_forward_to:
  - "09_non_goals_and_claim_boundary.md"
---

# Relation to PMS-RUST

## 1. PMS-STACK as Architecture Specification

PMS-STACK is the implementation-layer architecture specification of PMS.

It specifies how the Δ–Ψ operator grammar can be projected into a complete systems architecture:

```text
PMS-UM
PMS-CPU
PMS-OS
PMSL / PMS-IR
runtime security
networking
distributed systems
tooling
simulation
verification
boot
cluster extensions
```

The central claim is:

```text
PMS-STACK is the implementation-layer architecture specification of PMS:
a complete systems architecture deriving abstract machine, virtual CPU,
OS kernel, runtime, language, security, networking, distributed systems,
tooling, boot, and verification structures from Δ–Ψ.
```

Claim type:

```text
IMPLEMENTATION-LAYER ARCHITECTURE SPECIFICATION CLAIM
```

Boundary:

```text
This is an architecture claim.

It is not a PMS Base validation claim.
It is not a completed-implementation claim.
It is not a hardware-fabrication claim.
It is not a proof of PMS Base.
```

### 1.1 Specification Layer

PMS-STACK defines the architecture of an operator-grounded computing stack.

It answers:

```text
What is the abstract machine?
What is the virtual CPU?
What is the OS layer?
What is the runtime?
What is the language/IR path?
What is security?
What is networking?
What is distributed execution?
What is simulation?
What is verification?
What is a valid extension?
```

It does not answer:

```text
Has every layer been fully implemented?
Has PMS Base been validated?
Has the praxis theory been externally proven?
Has every runtime profile been built?
Has every artifact passed every future acceptance gate?
```

PMS-STACK therefore functions as:

```text
architecture specification
implementation target
realization horizon
layer map
operator-to-system projection
acceptance-gate source
```

It does not function as:

```text
PMS Base proof
empirical validation
completed implementation
external adequacy demonstration
```

### 1.2 Architecture Claim Form

The correct claim form is:

```text
PMS-STACK specifies how PMS operators can be instantiated as a complete
implementation-layer systems architecture.
```

This includes:

```text
operator-level execution
state and frame structure
role/capability structure
policy and invariant structure
ordering and timeout structure
trap/recontextualization structure
isolation/boundary structure
commit structure
audit and trace structure
distributed extension structure
```

The architecture claim is strong because it is systematic.

It is bounded because it remains a specification-layer claim.

### 1.3 What PMS-STACK Establishes

PMS-STACK establishes the following architecture-level results.

#### Universal Operational Semantics

Every relevant IT mechanism can be represented as an operator sequence:

```text
CPU instruction
syscall
trap
message
filesystem operation
network exchange
policy decision
commit
rollback
distributed proposal
```

Each becomes a structured word over:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

#### Turing-Completeness of PMS-UM

PMS-STACK treats PMS-UM as a computationally expressive abstract machine.

The claim is:

```text
PMS-UM is capable of expressing general computation through valid operator
programs and state transitions.
```

This supports the architectural adequacy of PMS-UM as the abstract machine layer.

It does not validate PMS Base as a praxis theory.

#### Unified IT Architecture

PMS-STACK presents hardware, OS, language runtime, security, networking, and distributed systems as projections of one operator grammar.

```text
PMS-CPU      = virtual ISA projection
PMS-OS       = kernel/runtime projection
PMSL/PMS-IR  = programming-language and compiler-path projection
Security     = Ω/Χ/Ψ/Σ/Θ/Φ runtime discipline
Networking   = □/Θ/Λ/Φ/Ω/Χ/Σ/Ψ communication discipline
Distributed  = scoped lifting into node, route, session, cluster frames
```

This is the architectural center of PMS-STACK.

#### Deterministic and Non-Deterministic Execution

PMS-STACK supports both:

```text
deterministic execution
non-deterministic exploration
concurrent interleavings
environment-driven execution
distributed progress
```

through explicit ordering, policy, absence, and commit structure.

#### Unified Security Model

Security is specified as runtime structure:

```text
identity
→ role/capability
→ boundary
→ policy
→ commit
→ audit
```

Operator form:

```text
Δ → Ω → Χ → Ψ → Σ
```

with Θ ordering, Φ trap/recontextualization, and Λ absence handling where required.

At PMS Base level:

```text
Χ = Distance
```

At PMS-STACK implementation level, Χ projects as:

```text
isolation
reachability control
boundary management
access separation
sandboxing
containment
namespace visibility
quarantine
```

This projection does not redefine PMS Base Χ.

#### Complete Systems Architecture

PMS-STACK specifies the full systems architecture:

```text
machine
processor
kernel
process/thread model
memory
storage
IPC
drivers
networking
runtime
language/IR
security/governance
audit
simulation
verification
boot
distributed systems
```

Completeness here means architectural completeness under the PMS-STACK specification.

It does not mean every subsystem already exists as finished code.

### 1.4 Completeness Conditions

PMS-STACK gives conditions under which the specification counts as complete.

The architecture is complete when:

```text
all operators have implementation-layer representatives

OS mechanisms map to operator sequences

PMSL / PMS-IR can map to machine/runtime operations

Ψ invariants are definable at each layer

Σ commit semantics are defined for memory, IPC, filesystem,
transactions, audit, and distributed commit

boot or runtime initialization reaches a declared normal form

extensions reduce to the existing operator grammar

no feature requires a new primitive outside Δ–Ψ
```

These conditions become acceptance-gate sources for implementation artifacts.

They do not become proof that any one implementation has completed PMS-STACK.

### 1.5 Extensibility Conditions

PMS-STACK is extensible only under operator reduction.

A new feature is admissible when:

```text
it reduces to sequences of Δ–Ψ

it obeys dependency constraints

it does not introduce new primitive operators

it preserves operator identity

it declares its frame, role, policy, boundary, ordering, absence,
recontextualization, and commit semantics where relevant
```

Feature admissibility form:

```text
Feature F ∈ PMS-STACK
iff
    F can be represented as valid operator-typed structure
    ∧ F respects PMS-STACK dependency and layer constraints
    ∧ F does not require a new base primitive.
```

If a proposed mechanism cannot be expressed through the operator grammar, it is not part of PMS-STACK.

This prevents architectural drift.

### 1.6 Simulation and Emulation as Architecture Bridge

Simulation and emulation are the natural bridge from PMS-STACK specification to executable artifacts.

PMS-STACK defines:

```text
PMS-UM simulator
PMS-CPU simulator
hybrid UM/CPU simulator
deterministic modes
non-deterministic modes
debug hooks
policy hooks
isolation hooks
replay
symbolic paths
scenario testing
operator-tagged traces
```

Simulation matters because every step can be operator-typed.

A simulator may emit:

```text
Δ distinction events
∇ mutation events
□ frame events
Λ timeout / non-event events
Ω role/capability events
Θ ordering events
Φ trap/reframe events
Χ boundary/isolation events as implementation-layer Distance projections
Σ commit events
Ψ policy events
```

This produces a direct architectural path:

```text
PMS-STACK specification
→ simulator profile
→ operator-tagged execution
→ trace
→ fixture
→ validation rule
→ acceptance gate
```

This path is where PMS-RUST becomes relevant.

### 1.7 Cross-Layer Mapping

PMS-STACK gives cross-layer mappings:

```text
PMS-UM  ↔ PMS-CPU ↔ PMS-OS ↔ PMSL
```

Representative concepts map across layers:

```text
Frame
Role
Policy
Isolation / Distance projection
Action
Commit
Trap / Reframe
Ordering
Absence
```

Example:

```text
Frame (□)
    PMS-UM: abstract state partition
    PMS-CPU: page / segment / execution domain
    PMS-OS: process / address space / container
    PMSL: frame block / explicit context

Commit (Σ)
    PMS-UM: integration into global state
    PMS-CPU: writeback / fence / barrier
    PMS-OS: transaction end / scheduler state update
    PMSL: commit block or implicit commit point
```

This cross-layer mapping is essential for relating PMS-RUST artifacts to the architecture.

A Rust artifact may implement one slice of this table without implementing the whole stack.

### 1.8 Classical OS and VM Boundary

PMS-STACK is not presented as an alien architecture unrelated to existing systems.

It structurally generalizes familiar systems concepts:

```text
Unix/POSIX processes
microkernel capabilities
VM bytecode
WASM sandboxing
IPC
scheduling
signals
traps
file descriptors
namespaces
host calls
```

PMS-STACK does not merely imitate them.

It makes their underlying structure explicit through:

```text
Δ distinction
Ω capability / role
□ frame
Χ boundary / Distance projection
Θ ordering
Λ absence
Φ trap / reframe
Σ commit
Ψ policy
```

Therefore PMS-RUST should not be read as:

```text
another VM
a finished OS
a complete CPU
a replacement for PMS-STACK
```

It should be read as a bounded artifact showing that pieces of the operator architecture can be executed, accepted or rejected under profile, traced, and tested.

### 1.9 PMS-STACK vs. PMS Base

PMS Base remains the source of truth for operator identity.

PMS-STACK uses the operators in an implementation-layer architecture.

Important boundary:

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK implementation layer:
    Χ projects as isolation, reachability control, boundary management,
    access separation, sandboxing, containment, namespace/device/IPC
    visibility control, and quarantine.
```

This projection is valid as an implementation-layer reading.

It does not redefine PMS Base Χ.

### 1.10 Architecture Specification Boundary

PMS-STACK claims:

```text
a complete operator-grounded systems architecture can be specified
from Δ–Ψ.
```

It does not claim:

```text
all layers are implemented
all simulators exist
all compilers exist
all distributed profiles exist
all policies are externally validated
tests are proof
traces are proof
implementation validates PMS Base
```

The correct boundary is:

```text
PMS-STACK is the architecture specification.
Artifacts may strengthen implementation-layer claims.
Artifacts do not convert the specification into PMS Base validation.
```

---

## 2. PMS-RUST as Evidence Spine, Not Source of PMS Base

PMS-RUST is the bounded executable artifact relation to PMS-STACK.

It is best described as:

```text
PMS-RUST = bounded executable PMS-STACK Evidence Spine v0.1
```

The central claim is:

```text
PMS-RUST strengthens PMS-STACK implementation-artifact claims by showing
that bounded Δ–Ψ operator programs can be represented, built, validated
under declared artifact profiles, executed, traced, tested, surfaced
through tooling, and protected by explicit trust boundaries.
```

Claim type:

```text
IMPLEMENTATION-ARTIFACT RELATION / EVIDENCE-SPINE CLAIM
```

Boundary:

```text
PMS-RUST is not the source of PMS Base.

It is not a replacement for PMS-STACK.

It is not a completed PMS-OS, PMS-CPU, PMSL compiler, or distributed PMS
runtime.

It does not validate PMS Base.
```

Validation in this document means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean:

```text
PMS Base validation
proof
external validation
semantic finality
```

### 2.1 Evidence Spine Meaning

An evidence spine is not a complete implementation of the whole architecture.

It is a bounded executable path through the architecture that creates inspectable artifacts.

For PMS-RUST, the documented path is:

```text
.pms script / REPL / AI proposal
→ PmsBuilder / OpCode buffer
→ PMS.yaml model validation
→ stateful kernel validation
→ deterministic kernel execution
→ JSONL trace / audit
→ vFS service surface
→ optional AI analysis
→ golden tests + demos + docs
```

This is a powerful implementation-layer relation.

It shows:

```text
operator programs can be authored
operator programs can be buffered
operator adjacency can be checked
runtime state can be guarded
deterministic stepping can execute bounded programs
events can be emitted
traces can be serialized
fixtures can be replayed
AI output can be gated
developer tooling can expose the spine
```

### 2.2 What PMS-RUST v0.1 Provides

PMS-RUST v0.1 provides a bounded runtime/toolchain.

Its components include:

```text
pms-kernel
pms-model
pms-ir
pms-repl
pms-ai-bridge
pms-model-data / PMS.yaml
pms-docs
pms-demos
tests
golden fixtures
JSONL trace/audit output
vFS service surface
```

These support implementation evidence for:

```text
deterministic Δ–Ψ kernel execution
model validation
stateful validation
operator-buffer construction
REPL/script execution
trace emission
golden-test discipline
bounded vFS service behavior
controlled AI proposal handling
```

The correct claim is:

```text
PMS-RUST demonstrates a bounded executable spine of PMS-STACK-style
operator execution and evidence generation.
```

### 2.3 What PMS-RUST Does Not Provide

PMS-RUST v0.1 does not claim:

```text
full PMS-OS
full PMS-CPU / ISA
full PMSL compiler
full distributed PMS runtime
complete PMS 1.3 semantic migration
trusted AI execution
complete runtime security implementation
complete PMS-STACK implementation
PMS Base validation
```

This is not a weakness.

It is the correct evidence boundary.

### 2.4 Evidence Spine vs. Full Stack

The relationship is:

```text
PMS-STACK
    full implementation-layer architecture specification

PMS-RUST
    bounded executable artifact-backed evidence spine

PMS-OS
    specified OS architecture layer

PMS-CPU
    specified virtual CPU / ISA layer

PMSL / PMS-IR
    specified language and IR layer

future artifacts
    direct implementations of additional STACK layers
```

PMS-RUST may support several architecture paths, but it does not equal all of them.

Example:

```text
PMS-RUST supports the PMS-CPU implementation path by already providing:
    operator representation
    deterministic stepping
    validation
    trace emission
    golden tests
    policy/boundary/commit discipline surfaces

But a complete PMS-CPU still requires:
    CPU state
    register model
    memory model
    ISA instruction enum
    binary decoder
    fetch-decode-execute loop
    CPU-level trap frames
    memory-consistency profiles
    ISA golden tests
```

Thus:

```text
PMS-RUST strengthens the path.
It does not complete the target.
```

### 2.5 Evidence Types

PMS-RUST may provide several evidence types.

```text
code structure
crate separation
operator enum representation
opcode buffer construction
model validation
stateful validation
deterministic execution
event emission
JSONL trace/audit output
golden fixtures
script fixtures
REPL interaction
vFS service behavior
AI bridge gating
acceptance-gate reports
```

Each evidence type supports a bounded claim.

| Evidence type | Supports | Does not support |
| ------------- | -------- | ---------------- |
| deterministic kernel execution | executable operator-kernel slice | full OS / CPU / PMSL |
| model validation | runtime-adjacent dependency checking | PMS Base truth |
| stateful validation | bounded invariant enforcement | full formal verification |
| JSONL trace | inspectable execution evidence | proof of all behavior |
| golden fixtures | regression discipline | universal correctness |
| REPL/script tooling | developer-facing execution surface | complete compiler |
| vFS surface | bounded host/service interface | full PMS filesystem |
| AI bridge | proposal-gating architecture | trusted AI execution |

### 2.6 Claim Pattern

The preferred PMS-RUST claim pattern is:

```text
STACK claim
→ executable slice
→ validation rule
→ golden test
→ trace evidence
→ limitation
```

Example:

```text
STACK claim:
    operator programs can be represented and checked.

Executable slice:
    OpCode buffer + PmsBuilder + pms-kernel.

Validation rule:
    PMS.yaml adjacency validation + stateful pre-execution validation.

Golden test:
    valid and invalid script fixtures.

Trace evidence:
    JSONL KernelEvent output.

Limitation:
    bounded runtime subset; not complete PMS-OS, PMS-CPU, PMSL,
    distributed runtime, or PMS Base validation.
```

This pattern keeps evidence strong and bounded.

### 2.7 PMS-RUST and Simulation

PMS-RUST relates directly to PMS-STACK simulation/emulation logic.

PMS-STACK specifies:

```text
operator-typed execution
deterministic and non-deterministic modes
trace unification
debug hooks
policy hooks
isolation hooks
scenario testing
replay
symbolic paths
```

PMS-RUST realizes a bounded executable subset:

```text
deterministic runtime execution
operator-tagged events
model validation
stateful validation
script/REPL scenarios
JSONL trace output
golden fixtures
```

Correct relation:

```text
PMS-STACK simulation architecture
    defines the artifact bridge.

PMS-RUST v0.1
    implements a bounded deterministic evidence-spine slice of that bridge.
```

Future work may extend this toward:

```text
PMS-UM simulator
PMS-CPU simulator
hybrid UM/CPU simulator
PMSL compiler pipeline
distributed runtime simulation
symbolic exploration
model-checking integration
```

### 2.8 PMS-RUST and PMS.yaml

PMS-RUST may use PMS.yaml as machine-readable model data.

This supports:

```text
operator name normalization
dependency table loading
adjacency validation
model-reference checks
diagnostics
```

Correct claim:

```text
PMS.yaml can be used as a model-reference artifact for runtime-adjacent
validation.
```

Incorrect claim:

```text
PMS.yaml execution proves PMS Base.
```

Machine-readable model reference is implementation support.

It does not replace the base theory.

### 2.9 PMS-RUST and AI Boundary

PMS-RUST includes a controlled AI proposal bridge.

The correct trust rule is:

```text
AI proposes.
Host parses, canonicalizes, maps, and validates.
Kernel executes only accepted PMS opcode programs.
```

AI output is not trusted executable code.

AI may support:

```text
trace analysis
scenario proposal
opcode-program suggestion
developer assistance
diagnostic explanation
fixture drafting
```

AI may not supply:

```text
runtime authority
policy authority
verification authority
verifier authority
compiler authority
trusted code authority
PMSL semantics
PMS Base evidence
verification evidence
```

This is a strong boundary because it makes AI useful without making it authoritative.

### 2.10 Runtime Dialect Boundary

PMS-RUST v0.1 has a known Χ boundary.

```text
Rust v0.1 Chi / Χ = isolation / boundary scope
PMS Base 1.3 Chi / Χ = Distance axis
```

This must be stated explicitly.

Correct relation:

```text
PMS-RUST v0.1 implements an implementation-layer Χ projection as
isolation/boundary handling.

PMS Base 1.3 defines Χ as Distance.
```

This is a version/scope boundary.

It is not a contradiction when named.

It becomes a problem only if the runtime dialect is silently treated as PMS Base.

PMS-RUST runtime dialect alignment is a tracked migration boundary.

A runtime command, alias, or opcode name may evidence implementation alignment work, but it does not by itself complete PMS 1.3 semantic migration.

### 2.10a ChiExit / ISO_EXIT / Boundary-Exit Mapping

PMS-RUST `chi_exit` and PMS-CPU `ISO_EXIT` refer to the same boundary-exit concern at different layers.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

They correspond at the boundary-exit concept level.

They are not the same claim layer.

```text
ISO_EXIT
    belongs to the PMS-CPU / ISA architecture specification

chi_exit
    belongs to PMS-RUST v0.1 runtime/artifact behavior
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

A PMS-RUST `chi_exit` may evidence that a bounded runtime profile rejects unbalanced isolation exit or permits valid isolation closure.

It does not complete PMS-CPU.

It does not redefine PMS Base Χ.

It does not validate PMS Base.

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Thus:

```text
PMS-RUST chi_exit strengthens bounded implementation-artifact claims about
runtime isolation-exit discipline.

PMS-CPU ISO_EXIT remains the architecture-level instruction target.

PMS Base Χ remains Distance.
```

### 2.11 PMS-RUST as Implementation Pressure

PMS-RUST strengthens PMS-STACK because it creates implementation pressure.

It shows that parts of the architecture can become:

```text
code
tests
traces
fixtures
diagnostics
developer commands
validation gates
runtime events
```

This pressure is productive.

It sharpens the architecture.

It also sharpens the boundary problem.

Because executable artifacts are persuasive, they can be mistaken for proof.

Therefore `08_relation_to_pms_rust.md` must state:

```text
implementation pressure is not proof

realizability is not truth

passing tests are not PMS Base validation

traceability is not external validation

artifact stability is not semantic finality
```

### 2.12 PMS-RUST as Evidence, Not Authority

PMS-RUST may show that:

```text
some PMS-STACK structures can be represented
some PMS-STACK structures can be executed
some PMS-STACK structures can be validated under artifact profiles
some PMS-STACK structures can be traced
some PMS-STACK structures can be tested
some PMS-STACK structures can be surfaced through tooling
```

PMS-RUST may not show that:

```text
PMS Base is true
PMS Base is complete
PMS Base is empirically validated
PMS 1.3 migration is complete
PMS-STACK is fully implemented
all runtime profiles are secure
all traces prove all behavior
all tests imply correctness
AI output is trustworthy
```

The correct statement is:

```text
PMS-RUST is implementation-layer evidence for bounded executable PMS-STACK
feasibility.
```

### 2.13 Evidence Spine Invariants

```text
ER1: PMS-RUST evidence is implementation-layer evidence

ER2: PMS-RUST does not define PMS Base

ER3: PMS-RUST does not validate PMS Base

ER4: PMS-RUST does not complete PMS-STACK

ER5: PMS-RUST v0.1 is bounded to its declared runtime/toolchain scope

ER6: deterministic kernel execution strengthens executable artifact claims

ER7: model validation strengthens runtime-adjacent checking claims

ER8: JSONL traces strengthen traceability and audit-surface claims

ER9: golden fixtures strengthen regression and acceptance-gate claims

ER10: REPL/script tooling strengthens developer-surface claims

ER11: vFS service behavior strengthens bounded host-service claims

ER12: AI bridge gating strengthens advisory-tooling boundary claims

ER13: Rust v0.1 Χ-as-isolation is an implementation projection, while
      PMS Base 1.3 Χ remains Distance

ER14: every PMS-RUST claim must state artifact, evidence type, supported
      STACK claim, and limitation

ER15: evidence-spine claims strengthen PMS-STACK implementation-artifact
      claims and do not function as PMS Base validation

ER16: PMS-RUST chi_exit requires an active runtime boundary context;
      unbalanced exit is invalid under the declared profile
```

### 2.14 Section Boundary

The relationship is:

```text
PMS Base
    source of operator identity

PMS-STACK
    implementation-layer architecture specification

PMS-RUST
    bounded executable artifact-backed evidence spine

future artifacts
    additional implementations of specified architecture slices
```

Thus PMS-RUST is neither peripheral nor sovereign.

It is architecturally important because it makes PMS-STACK executable in bounded form.

It remains claim-bounded because executable artifact-backed partial realization is not PMS Base validation.

### 2.15 Architectural Consequence

The consequence is:

```text
PMS-RUST is the current bounded executable Evidence Spine for PMS-STACK
v0.1: it demonstrates that selected operator-grounded structures can be
represented, validated under artifact profiles, executed, traced, tested,
and exposed through tooling.
```

The boundary is equally central:

```text
PMS-RUST strengthens PMS-STACK implementation-artifact claims.
It does not define PMS Base.
It does not validate PMS Base.
It does not complete PMS-STACK.
```

This gives `08_relation_to_pms_rust.md` its governing function:

```text
map architecture claims to executable artifact status
without allowing artifact status to become base-theory authority.
```

---

## 3. Simulation and Emulation as the Artifact Bridge

Simulation and emulation form the central artifact bridge between PMS-STACK as architecture specification and PMS-RUST as executable evidence spine.

The central claim is:

```text
Simulation and emulation are the bridge by which PMS-STACK architecture
claims become executable artifact claims: operator-typed programs are
run under declared machine profiles, emit structured traces, expose
policy and commit behavior, support replay and scenario testing, and
produce bounded evidence for implementation-layer conformance.
```

Claim type:

```text
IMPLEMENTATION-LAYER SIMULATION / ARTIFACT-BRIDGE ARCHITECTURE CLAIM
```

Boundary:

```text
This bridge is architectural.

It does not convert simulation into PMS Base validation.

It does not make traces proofs.
It does not make fixtures universal correctness evidence.
It does not complete PMS-UM, PMS-CPU, PMS-OS, PMSL, or distributed runtime
implementation.
```

### 3.1 Why Simulation Matters in PMS-STACK

PMS-STACK is operator-semantic.

That makes simulation unusually direct.

A simulator does not need to infer the semantics of a generic instruction stream from an external architecture manual. It can execute and observe operator-level events:

```text
Δ   distinction
∇   action / mutation
□   frame transition
Λ   absence / timeout / non-event
Α   pattern / macro-structure
Ω   role / capability / asymmetry
Θ   ordering / step progression
Φ   recontextualization / trap / fallback
Χ   Distance projection as boundary / isolation in implementation layer
Σ   commit / integration
Ψ   policy / invariant
```

Thus the simulator can produce traces that are already semantically aligned with PMS-STACK.

The result is an explicit path from specification to artifact:

```text
PMS-STACK operator architecture
→ simulator profile
→ executable operator program
→ validation rule
→ trace
→ replay
→ fixture
→ acceptance gate
→ implementation-artifact evidence
```

### 3.2 Simulation as Architecture-to-Artifact Translation

PMS-STACK defines what the simulator should preserve.

A simulator must preserve:

```text
operator identity
operator dependency structure
frame state
role/capability state
policy state
ordering state
absence/timeout state
recontextualization paths
boundary/isolation state as Χ projection
commit points
trace evidence
```

This makes simulation more than debugging.

It becomes the first executable conformance surface.

Correct statement:

```text
A PMS simulator realizes a declared executable profile of PMS-STACK
operator semantics.
```

Boundary:

```text
A PMS simulator does not validate PMS Base.
It executes a bounded profile of PMS-STACK semantics.
```

### 3.3 PMS-UM Simulator

The PMS-UM simulator is the abstract-machine simulation layer.

A UM simulation step has the form:

```text
(s, π) → (s', π')
```

where:

```text
s = (s_c, f, r, P, m, ip)
```

Meaning:

```text
s_c   core state
f     frame stack / frame configuration
r     role state
P     active policies
m     meta-state, including τ and history
ip    instruction pointer / operator pointer
```

The simulator executes operator events rather than opaque instructions.

Example UM event stream:

```text
Δ_entity
□_enter_frame
Ω_assign_role
Θ_step
∇_mutate
Ψ_check
Σ_commit
```

A PMS-UM simulator supports architecture claims about:

```text
abstract operator execution
state transition discipline
frame validity
policy enforcement
commit visibility
operator dependency checking
trace emission
replay from commit checkpoints
```

It does not imply that a complete PMS-CPU, PMS-OS, PMSL compiler, or distributed runtime has already been built.

### 3.4 PMS-CPU Simulator

The PMS-CPU simulator emulates ISA-level execution.

PMS-STACK specifies the CPU-level execution pipeline as operator-typed:

```text
1. Δ    decode and operand distinction
2. Ω    capability / privilege check
3. Ψ    policy pre-check
4. ∇    execute mutation or effect
5. □    frame operation where needed
6. Φ    trap or exception path where needed
7. Χ    boundary / isolation enforcement where needed
8. Σ    commit point
9. Θ    increment logical ordering index
```

A PMS-CPU simulator therefore provides evidence for:

```text
fetch/decode semantics
instruction-level operator mapping
privilege and capability checks
trap/reframe behavior
frame and memory-domain behavior
commit semantics
ordering semantics
traceability
```

Boundary:

```text
A CPU simulator profile strengthens PMS-CPU implementation claims.
It does not by itself complete the PMS-CPU hardware/ISA artifact.
```

PMS-CPU `ISO_EXIT` remains an architecture-level ISA instruction target for boundary exit.

PMS-RUST `chi_exit` may evidence bounded runtime boundary-exit discipline.

They map at the boundary-exit concern level but remain different claim layers.

### 3.5 Hybrid UM/CPU Simulation

A hybrid simulator connects abstract and ISA-level execution.

It enables:

```text
PMSL / PMS-IR semantic run at UM level
IR or opcode lowering into PMS-CPU-like execution
trace comparison across abstraction levels
round-trip consistency checking
```

The key claim is:

```text
UM-level and CPU-level traces can be compared because both are
operator-tagged.
```

Trace alignment form:

```text
trace_UM ≈ trace_CPU
```

where equivalence is evaluated under a declared profile:

```text
same operator obligations
same frame transitions
same role/policy decisions
same commit boundaries
compatible ordering
compatible absence behavior
compatible trap/reframe behavior
compatible boundary-exit behavior where ISO_EXIT / chi_exit mapping is relevant
```

This is the route toward language/runtime correctness evidence.

Boundary:

```text
trace alignment under profile P demonstrates conformance of that profile.
It does not prove all possible implementations equivalent.
```

### 3.6 Deterministic and Non-Deterministic Modes

PMS-STACK simulation supports both deterministic and non-deterministic execution.

Deterministic mode:

```text
all scheduling, input, timeout, and nondeterministic choices are resolved
by declared scheduler/profile/state.
```

Use cases:

```text
golden tests
replay
regression testing
trace comparison
artifact acceptance gates
CI execution
```

Non-deterministic mode:

```text
execution branches over possible schedules, interleavings, injected faults,
timeouts, or environment events.
```

Use cases:

```text
concurrency exploration
failure exploration
symbolic scenarios
security testing
liveness/safety analysis
distributed interleaving checks
```

PMS-RUST v0.1 primarily supports the deterministic evidence-spine direction.

Future artifacts may add nondeterministic exploration.

### 3.7 Θ / Σ Debug Hooks

Simulation exposes execution order and commit boundaries.

Debug hooks may include:

```text
Θ_step
Θ_before_op
Θ_after_op
Θ_before_commit
Σ_commit
Σ_snapshot
Σ_rollback
Σ_trace_flush
```

These support:

```text
single-step execution
step-until-commit
commit checkpointing
replay
trace slicing
audit correlation
regression fixture generation
```

Debugging is operator-typed:

```text
what happened
where it happened
under which frame
under which role
under which policy
before or after which commit
```

This is the foundation for PMS-RUST-style JSONL traces and golden fixtures.

### 3.8 Ψ Policy Hooks

A simulator must expose policy evaluation.

Policy hooks include:

```text
Ψ_before_transition
Ψ_before_frame_enter
Ψ_before_role_change
Ψ_before_boundary_cross
Ψ_before_commit
Ψ_on_failure
Ψ_on_timeout
Ψ_on_recovery
```

Policy-hook evidence supports claims such as:

```text
invalid operator adjacency rejected
forbidden state transition denied
commit blocked after policy failure
post-Ψ sealed state protected
runtime invariant preserved
```

Boundary:

```text
policy-hook evidence demonstrates enforcement under declared model/profile.
It does not establish external adequacy of the policy itself.
```

### 3.9 Χ Boundary and Isolation Hooks

PMS-STACK simulation may instrument Χ.

Important boundary:

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK simulation / implementation profile:
    Χ projects as boundary, reachability, isolation, containment,
    sandboxing, and access separation.
```

Simulation hooks may include:

```text
Χ_enter
Χ_exit
Χ_boundary_check
Χ_quarantine
Χ_violation
Χ_visibility
```

These support testing of:

```text
frame separation
sandbox entry/exit
cross-frame access denial
quarantine behavior
capability-bound visibility
network/session/tenant boundary checks
```

For PMS-RUST, this is especially important because its v0.1 runtime dialect uses Chi as an implementation-layer boundary/isolation construct.

That must be named as projection, not silently treated as PMS Base operator identity.

Boundary-exit rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

### 3.10 Φ and Λ Scenario Injection

Simulation supports scenario testing through injected events.

Φ injections:

```text
trap
exception
fault
fallback
migration
rollback
recontextualization
quarantine
version shift
```

Λ injections:

```text
timeout
missing event
no response
empty queue
no resource
no route
missing heartbeat
no quorum
```

Example scenario forms:

```text
inject Φ exception=IO_FAULT at Θ=120

inject Λ when waiting_on="net.recv"

inject Χ enter context=vm1 at Θ=60

inject Ψ policy_violation="fs.read.restricted"
```

Scenario injection supports:

```text
kernel testing
filesystem testing
network testing
runtime security testing
distributed failure testing
cluster boot testing
upgrade rollback testing
AI proposal boundary testing
```

Scenario evidence checks declared behavior under profile.

It does not prove all scenario variants.

### 3.11 Replay and Commit Checkpoints

Because Σ marks integration, simulation can replay from commit checkpoints.

Replay model:

```text
initial state
+ operator program
+ deterministic scheduler/profile
+ injected events
+ checkpoints
→ reproducible trace
```

Checkpoint:

```text
Checkpoint = (
    checkpoint_id,
    commit_ref,
    state_snapshot,
    frame_state,
    role_state,
    policy_state,
    boundary_state,
    ordering_state,
    meta
)
```

Replay supports:

```text
debugging
regression tests
golden traces
trace comparison
audit reconstruction
failure reproduction
deterministic CI validation
```

Replay boundary:

```text
replay proves reproducibility of a captured execution profile.
It does not prove all possible executions.
```

### 3.12 Trace Unification

All simulator levels produce operator-tagged traces.

Generic single-run trace:

```text
trace(...) ∈ L_PMS
```

Generic trace set:

```text
Trace(...) ⊆ L_PMS
```

A concrete PMS-RUST execution produces:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Under active runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible PMS-RUST executions under a declared profile is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

and under policy:

```text
Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

JSONL output records observed `trace_rust(...)` values.

It does not by itself enumerate `Trace_rust(...)`.

More explicit event shape:

```text
TraceEvent = (
    event_id,
    order,
    operator,
    frame,
    role?,
    policy?,
    boundary?,
    commit_ref?,
    result,
    meta
)
```

UM, CPU, OS, PMSL, network, security, and distributed traces can be compared because they expose the same operator grammar.

Trace unification supports:

```text
cross-layer debugging
UM↔CPU consistency checking
runtime audit
policy conformance
scenario validation
golden fixture generation
artifact acceptance gates
```

This is the direct conceptual ancestor of PMS-RUST event formats.

Trace boundary:

```text
traces record observed behavior.
Trace sets describe possible behavior under profile.
A recorded trace is not proof of all behavior.
```

### 3.13 Symbolic Execution and Path Exploration

PMS-STACK supports symbolic execution as an optional simulation extension.

Operator reading:

```text
Δ   symbolic branch distinction
∇   symbolic state update
□   symbolic environment/frame
Ω   symbolic capability condition
Φ   symbolic recontextualization
Ψ   symbolic invariant constraint
Σ   symbolic commit boundary
```

Symbolic execution may support:

```text
path exploration
unreachability checks
security ceiling tests
contract verification
operator dependency exploration
failure-space exploration
```

Boundary:

```text
symbolic proof under model M proves property P under model M.
It does not validate PMS Base or all implementations.
```

### 3.14 PMS-RUST as Bounded Simulator-Like Evidence

PMS-RUST v0.1 is not a complete PMS-UM or PMS-CPU simulator.

It is a bounded executable evidence spine aligned with the simulation bridge.

It already fits the bridge by providing:

```text
operator representation
program buffer
model validation
stateful validation
deterministic kernel execution
event emission
JSONL traces
REPL/script execution
golden fixtures
bounded vFS surface
AI proposal gating
```

Correct relation:

```text
PMS-STACK simulation architecture defines the bridge.
PMS-RUST v0.1 implements a bounded executable slice on that bridge.
```

This supports implementation-artifact claims for selected paths.

It does not complete all simulator profiles.

### 3.15 Artifact Bridge Claim Pattern

The correct bridge pattern is:

```text
specification claim
→ executable profile
→ implementation slice
→ validation rule
→ fixture
→ trace
→ acceptance gate
→ limitation
```

Example:

```text
Specification claim:
    PMS operator programs can be executed under deterministic profile.

Executable profile:
    bounded deterministic kernel.

Implementation slice:
    pms-kernel OpCode stepping.

Validation rule:
    adjacency and stateful validators.

Fixture:
    valid and invalid demo scripts.

Trace:
    JSONL KernelEvent stream.

Acceptance gate:
    expected trace and expected rejection behavior.

Limitation:
    bounded evidence-spine slice; not full PMS-OS, PMS-CPU,
    PMSL compiler, distributed runtime, or PMS Base validation.
```

### 3.16 Simulation Bridge Invariants

```text
SB1: every simulator profile declares its execution scope

SB2: every simulator event is operator-typed

SB3: every deterministic run declares scheduler/input/profile assumptions

SB4: every nondeterministic run declares branching dimensions

SB5: every policy hook is Ψ-scoped

SB6: every boundary/isolation hook treats Χ as implementation-layer
     projection of PMS Base Distance

SB7: every replay claim states checkpoint, input, profile, and trace range

SB8: every trace comparison states equivalence relation and abstraction level

SB9: every fixture supports a bounded acceptance claim

SB10: every simulator/artifact result strengthens implementation-layer
      evidence claims and does not function as PMS Base validation

SB11: JSONL trace output records observed trace_rust(...) values and does not
      enumerate Trace_rust(...)

SB12: PMS-RUST chi_exit / PMS-CPU ISO_EXIT mapping is boundary-exit mapping
      across artifact/runtime and architecture/ISA layers, not Base Χ
      redefinition
```

### 3.17 Architectural Consequence

The consequence is:

```text
Simulation and emulation are the artifact bridge of PMS-STACK. They turn
operator architecture into executable profiles, traces, scenarios,
fixtures, replay artifacts, and acceptance gates.
```

PMS-RUST enters precisely here:

```text
not as PMS Base authority,
not as complete PMS-STACK,
but as bounded executable evidence that selected PMS-STACK structures
can be represented, validated under artifact profiles, executed, traced,
tested, and inspected.
```

---

## 4. What PMS-STACK Establishes

PMS-STACK establishes a full implementation-layer architecture.

This section restates the strongest claims of PMS-STACK in claim-typed form.

The central establishment claim is:

```text
PMS-STACK establishes that the Δ–Ψ operator grammar can specify a
complete systems architecture spanning abstract machine, virtual CPU,
kernel, memory, storage, IPC, drivers, runtime, language/IR, security,
networking, distributed systems, simulation, verification, and boot.
```

Claim type:

```text
IMPLEMENTATION-LAYER ARCHITECTURE ESTABLISHMENT CLAIM
```

Boundary:

```text
This is an architecture/specification claim.

It is not a PMS Base validation claim.
It is not a completed PMS-RUST implementation claim.
It is not a proof that all specified layers already exist as artifacts.
It is not external validation of PMS Base.
```

### 4.1 Universal Operational Semantics

PMS-STACK establishes a universal operational semantics for IT systems at the architecture layer.

Every major systems mechanism can be expressed as an operator sequence:

```text
instruction fetch/decode
memory access
syscall
trap
process switch
IPC send/receive
filesystem operation
driver interaction
network transport
route selection
PPS message
security policy decision
audit event
commit
rollback
distributed proposal
cluster membership update
```

Each can be represented as a word over:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

This yields:

```text
semantic uniformity
cross-layer mapping
operator-typed traceability
policy visibility
commit visibility
implementation extensibility
```

Boundary:

```text
universal operational semantics is a PMS-STACK architecture claim.
It does not prove PMS Base as a theory of praxis.
```

### 4.2 PMS-UM as Computational Core

PMS-STACK establishes PMS-UM as the abstract computational core of the stack.

PMS-UM provides:

```text
state tuple
operator pointer
frame stack
role state
policy state
meta-state
ordering
absence handling
commit semantics
```

PMS-UM supports general computation through operator programs.

The architecture claim is:

```text
PMS-UM is sufficient as the abstract-machine basis for PMS-STACK
implementation layers.
```

This claim grounds:

```text
PMS-CPU
PMS-OS
PMSL/PMS-IR
simulation
verification
runtime execution
```

Boundary:

```text
PMS-UM computational sufficiency strengthens PMS-STACK architecture.
It does not validate PMS Base.
```

### 4.3 Unified Model for Hardware, OS, Language, Network, and Security

PMS-STACK establishes a single systems model across layers.

Instead of separate semantic worlds for:

```text
hardware
kernel
runtime
language
security
networking
distributed systems
```

PMS-STACK uses one operator grammar.

Layer projections:

```text
PMS-CPU:
    operator representatives as ISA / virtual CPU semantics

PMS-OS:
    kernel, processes, syscalls, memory, storage, IPC, drivers

PMSL / PMS-IR:
    programming-language constructs and compiler/runtime path

Security:
    identity, role, capability, boundary, policy, commit, audit

Networking:
    transport frames, routing, PPS messages, timeout, resilience

Distributed systems:
    node frames, cluster frames, Σᴳ commit, Ψᴳ policy, Χᴳ boundary

Simulation / Verification:
    operator-tagged execution, traces, fixtures, replay, property checks
```

This is PMS-STACK’s central architectural move.

PMS Base remains the source of operator identity.

At PMS Base level:

```text
Χ = Distance
```

At PMS-STACK implementation layers, Χ projects as:

```text
isolation
boundary
reachability control
access separation
namespace visibility
sandboxing
containment
quarantine
cross-node boundary
trust-domain separation
```

This projection does not redefine PMS Base Χ.

### 4.4 Deterministic and Non-Deterministic Execution Modes

PMS-STACK establishes deterministic and non-deterministic execution as structural modes.

Deterministic execution:

```text
fixed ordering
fixed inputs
fixed policy
fixed scheduler/profile
reproducible trace
```

Non-deterministic execution:

```text
branching paths
environment-driven events
concurrent interleavings
fault injection
timeout variation
distributed choices
```

Both are expressed through:

```text
Θ ordering
Λ absence
Ψ policy
Φ recontextualization
Σ commit
```

This matters for PMS-RUST because deterministic execution and golden traces are a bounded artifact path, while nondeterministic exploration remains a future extension path.

A concrete PMS-RUST execution produces:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

The set of possible PMS-RUST executions under a declared profile is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

JSONL output records observed `trace_rust(...)` values.

It does not by itself enumerate `Trace_rust(...)`.

### 4.5 Unified Security Model

PMS-STACK establishes security as runtime structure.

Security is not an add-on subsystem.

Its basic form is:

```text
Δ identity / object / message / event distinction
Ω role / capability / authority
Χ boundary / Distance projection / reachability / isolation
Ψ policy / invariant
Θ order / audit sequence
Φ trap / fallback / recontextualization
Λ absence / timeout / failure
Σ commit / integration / durable evidence
```

Compactly:

```text
identity → authority → boundary → policy → commit → audit
```

Security claim:

```text
PMS-STACK specifies a unified operator-grounded security architecture
across runtime, OS, language, networking, trust, audit, and distributed
systems.
```

Boundary:

```text
this establishes a security architecture.
It does not certify any implementation as universally secure.
```

For boundary-exit discipline:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA boundary-exit instruction

PMS-RUST chi_exit
    bounded runtime/artifact behavior evidencing isolation-exit discipline
```

Shared validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

This strengthens runtime-security and PMS-CPU mapping clarity.

It does not redefine PMS Base Χ and does not validate PMS Base.

### 4.6 Complete Systems Architecture

PMS-STACK establishes a complete systems architecture at specification level.

It covers:

```text
abstract machine
virtual CPU / ISA
kernel / OS
processes and threads
memory
storage
filesystem
IPC
drivers
runtime
PMSL / PMS-IR
security and governance
networking
distributed systems
simulation and verification
boot
cluster extensions
```

Completeness means:

```text
the architecture supplies operator-grounded places for the major systems
mechanisms required to specify a computing stack.
```

It does not mean:

```text
every implementation exists
every feature is complete in PMS-RUST
every distributed profile is built
every proof obligation has been discharged
```

### 4.7 Completeness Conditions

PMS-STACK establishes completeness conditions.

The specification is architecturally complete when:

```text
C1: all operators have implementation-layer representatives

C2: all OS-level mechanisms map to operator sequences

C3: language constructs map through PMSL / PMS-IR into runtime or machine
    operations

C4: Ψ invariants are definable at all layers

C5: Σ commit semantics are defined for memory, IPC, filesystem,
    transactions, audit, and distributed commit

C6: boot or runtime initialization reaches a declared normal form

C7: extensions reduce to the existing operator grammar

C8: no new primitive outside Δ–Ψ is required
```

For PMS-RUST, these become artifact questions:

```text
Which conditions are implemented?
Which are partially implemented?
Which are represented by fixtures?
Which are traced?
Which remain future work?
```

PMS-RUST answers these questions as an evidence spine.

It does not transform architecture completeness into artifact completion.

### 4.8 Extensibility Conditions

PMS-STACK establishes a disciplined extension model.

A new feature is admissible only when it can be expressed through:

```text
Δ   distinction
∇   mutation / action
□   frame / context
Λ   absence
Α   pattern
Ω   role / asymmetry / capability
Θ   ordering
Φ   recontextualization
Χ   Distance projection / boundary at implementation layer
Σ   integration / commit
Ψ   policy / invariant
```

Extension rule:

```text
Feature F is PMS-STACK-conformant iff
    F reduces to valid Δ–Ψ operator structure
    ∧ F respects dependency constraints
    ∧ F declares its layer/profile
    ∧ F introduces no new primitive operator.
```

This prevents uncontrolled growth.

PMS-RUST extensions should be evaluated through this rule.

### 4.9 Classical Model Embedding

PMS-STACK establishes that classical computation and systems concepts can be represented as PMS-STACK projections.

Examples include:

```text
Turing machines
register machines
actor models
lambda-calculus-like evaluation
POSIX-like process model
capability systems
microkernels
monolithic kernels
virtual machines
WASM-style sandboxing
IPC
scheduling
event loops
timeouts
distributed protocols
leader election
state-machine replication
CRDT-like merge profiles
```

These are not added as new primitives.

They are represented as specialized operator structures.

Boundary:

```text
embedding a classical model as PMS-STACK structure does not mean that
every classical implementation automatically satisfies every PMS-STACK
policy or evidence requirement.
```

### 4.10 PMS Normal Form of Computation

PMS-STACK establishes a canonical execution shape.

A broad normal form is:

```text
w = Δ* ; Ω* ; □* ; (Θ* ∇* Λ* Φ* Χ*)* ; Σ* ; Ψ*
```

with dependency and layer constraints.

This form should not be read as a rigid concrete runtime sequence for every implementation.

It is a canonical structural representation of legitimate PMS-STACK execution.

It expresses:

```text
distinguish
authorize / role-bind
frame
order and act
handle absence
recontextualize
respect boundary
commit
remain policy-bound
```

### 4.11 What This Establishes for PMS-RUST

For PMS-RUST, these PMS-STACK establishments become mapping targets.

PMS-RUST can be evaluated by asking:

```text
Which PMS-STACK operator structures are represented?

Which are executable?

Which are validated under declared artifact profiles?

Which are traced?

Which have fixtures?

Which have acceptance gates?

Which are bounded?

Which remain architecture-only?
```

Example mapping:

```text
PMS-STACK:
    operator programs should be executable and traceable.

PMS-RUST:
    bounded OpCode programs execute deterministically and emit JSONL traces.

Boundary:
    this strengthens executable evidence-spine claims, not full PMS-STACK
    completion and not PMS Base validation.
```

Validation in this document means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean:

```text
PMS Base validation
proof
external validation
semantic finality
```

### 4.12 PMS-RUST Runtime Dialect and Migration Boundary

PMS-RUST may contain runtime commands, aliases, or opcode names that evidence implementation alignment work.

Such alignment is valuable.

It remains bounded.

Correct boundary:

```text
PMS-RUST runtime dialect alignment is a tracked migration boundary.

A runtime command, alias, or opcode name may evidence implementation
alignment work, but it does not by itself complete PMS 1.3 semantic
migration.
```

`chi_exit` belongs to this boundary.

```text
PMS-RUST chi_exit
    evidences runtime boundary-exit discipline.

PMS-CPU ISO_EXIT
    remains the architecture-level boundary-exit instruction.
```

Neither redefines PMS Base Χ.

Neither validates PMS Base.

### 4.13 What PMS-STACK Does Not Establish

PMS-STACK does not establish:

```text
PMS Base validation

complete implementation of every specified layer

complete PMS-RUST implementation of PMS-STACK

universal security of all implementations

external correctness of all policies

proof of all distributed algorithms

proof that every trace captures all relevant behavior

proof that all tests imply full correctness

AI proposal trustworthiness

identity, personhood, moral, clinical, or legal claims
```

The boundary is not a weakening of PMS-STACK.

It is the condition under which its architecture claims remain strong and precise.

### 4.14 Establishment Invariants

```text
ES1: PMS-STACK establishes an implementation-layer architecture

ES2: PMS-STACK does not validate PMS Base

ES3: universal operational semantics is a specification claim

ES4: PMS-UM computational sufficiency supports the architecture layer

ES5: unified hardware/OS/language/network/security modeling is a
     STACK architecture claim

ES6: deterministic and non-deterministic execution are structural modes

ES7: security is runtime structure, not an add-on subsystem

ES8: completeness conditions define architecture sufficiency, not artifact
     completion

ES9: extensibility conditions prevent new primitive drift

ES10: classical models embed as projections, not additional primitives

ES11: PMS-RUST maps to PMS-STACK through executable evidence, not authority

ES12: tests, fixtures, traces, and simulators strengthen implementation-artifact
      claims and do not function as PMS Base validation

ES13: trace_rust(...) denotes a concrete observed PMS-RUST execution;
      Trace_rust(...) denotes a profile-bounded execution set

ES14: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline;
      PMS-CPU ISO_EXIT is the architecture-level boundary-exit instruction;
      neither redefines PMS Base Χ nor validates PMS Base
```

### 4.15 Architectural Consequence

The consequence is:

```text
PMS-STACK establishes the complete specification-level architecture into
which PMS-RUST can be mapped.
```

PMS-STACK supplies:

```text
the operator grammar
the layer map
the simulation bridge
the completeness conditions
the extensibility conditions
the cross-model mappings
the claim boundaries
```

PMS-RUST supplies:

```text
bounded executable evidence for selected slices of that architecture.
```

The relationship is therefore precise:

```text
PMS-STACK establishes the architecture.
PMS-RUST strengthens selected implementation-artifact claims.
PMS Base remains the source of operator identity.
No artifact becomes PMS Base validation.
```

---

## 5. Completeness Conditions and Artifact Gates

PMS-STACK defines architecture-level completeness conditions.

PMS-RUST relates to these conditions through bounded artifact gates.

The central claim is:

```text
PMS-STACK completeness conditions become PMS-RUST artifact gates when
each architecture condition is translated into an executable slice,
validation rule, fixture, trace expectation, acceptance criterion, and
declared limitation.
```

Claim type:

```text
IMPLEMENTATION-ARTIFACT GATE / COMPLETENESS-MAPPING CLAIM
```

Boundary:

```text
Completeness in PMS-STACK means the specification has supplied a complete
operator-grounded place for the relevant system mechanism.

Completeness in PMS-RUST means only that a bounded artifact slice
satisfies a declared acceptance gate.

These are different claim layers.

Passing an artifact gate does not complete PMS-STACK.
Passing an artifact gate does not validate PMS Base.
Passing an artifact gate does not prove all behavior.
```

### 5.1 Completeness Condition vs Artifact Gate

PMS-STACK condition:

```text
Architecture mechanism X is specified as Δ–Ψ structure.
```

PMS-RUST artifact gate:

```text
Artifact slice Y represents, validates, executes, traces, or tests a
bounded instance of X.
```

Relation:

```text
PMS-STACK completeness condition
    → defines what an implementation must eventually account for

PMS-RUST artifact gate
    → checks whether a bounded artifact slice accounts for a declared part
```

This distinction prevents a common error:

```text
passing artifact gate
≠ completing PMS-STACK
≠ validating PMS Base
```

### 5.2 Gate Pattern

Every artifact gate should follow the same pattern:

```text
STACK claim
→ artifact slice
→ validation rule
→ fixture / scenario
→ trace or evidence
→ acceptance criterion
→ limitation
```

Canonical form:

```text
ArtifactGate = (
    id,
    stack_claim,
    artifact_slice,
    validation_rule,
    fixture,
    expected_trace,
    acceptance_criterion,
    limitation
)
```

This creates traceable evidence without overclaiming.

Validation means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean PMS Base validation, proof, external validation, or semantic finality.

### 5.3 Completeness Condition C1 — Operator Representatives

PMS-STACK condition:

```text
all PMS operators have implementation-layer representatives.
```

Artifact gate:

```text
G-C1: Operator Representation Gate
```

Gate requirements:

```text
all required operators are represented in code

operator names have stable model keys

operator variants map to PMS.yaml or declared model data

operator serialization is stable where traces require it

unknown operators fail closed
```

Evidence types:

```text
operator enum
model-key mapping
parser / builder mapping
validation tests
trace output
golden fixtures
```

Acceptance:

```text
ACCEPT iff every declared runtime operator has:
    code representation
    stable external key
    model reference
    trace representation
    invalid/unknown rejection behavior
```

Limitation:

```text
operator representation in PMS-RUST supports bounded execution.
It does not prove PMS Base operator adequacy.
```

### 5.4 Completeness Condition C2 — OS Mechanisms as Operator Sequences

PMS-STACK condition:

```text
all OS-level mechanisms map to operator sequences.
```

Artifact gate:

```text
G-C2: OS Mechanism Mapping Gate
```

Gate requirements:

```text
each implemented OS-like mechanism declares its operator word

host-service effects are separated from kernel timeline effects

syscall-like or service-like behavior declares authority, policy, boundary,
commit, and audit semantics

unsupported OS mechanisms are explicitly outside artifact scope
```

Evidence types:

```text
vFS service surface
script commands
host-service boundary docs
trace records
policy/validation tests
```

Acceptance:

```text
ACCEPT iff implemented OS-like operations are represented as declared
operator-governed slices and do not masquerade as full PMS-OS.
```

Limitation:

```text
bounded vFS or host-service behavior strengthens artifact claims.
It does not implement full PMS-OS.
```

### 5.5 Completeness Condition C3 — PMSL / PMS-IR Mapping

PMS-STACK condition:

```text
language constructs map cleanly through PMSL → PMS-IR → runtime or machine
operations.
```

Artifact gate:

```text
G-C3: PMSL / PMS-IR Mapping Gate
```

Gate requirements:

```text
builder or IR layer emits canonical operator programs

source-level or script-level constructs map to opcodes

invalid construction paths are rejected

runtime execution consumes validated operator programs

source spans or diagnostic anchors exist where profile requires them
```

Evidence types:

```text
PmsBuilder
OpCode buffer
script parser
REPL commands
diagnostics
valid/invalid fixtures
```

Acceptance:

```text
ACCEPT iff a declared language/script/IR construct maps to canonical
operator representation and invalid mappings fail closed.
```

Limitation:

```text
PMS-IR construction does not equal full PMSL compiler.
```

### 5.6 Completeness Condition C4 — Ψ Invariants at All Layers

PMS-STACK condition:

```text
Ψ invariants are definable at all layers.
```

Artifact gate:

```text
G-C4: Policy / Invariant Gate
```

Gate requirements:

```text
implemented runtime layer declares invariants

validator checks pre-execution admissibility

stateful validator checks runtime-relevant frame, boundary, commit, or
ordering constraints

policy failure prevents execution or commit

diagnostics identify violated invariant
```

Evidence types:

```text
model validator
stateful validator
runtime checks
negative fixtures
error diagnostics
trace denial events
```

Acceptance:

```text
ACCEPT iff invalid programs are rejected before protected execution or
before forbidden commit, and rejection is observable.
```

Limitation:

```text
bounded validator behavior strengthens implementation-artifact claims.
It does not prove all Ψ invariants for all STACK layers.
```

### 5.7 Completeness Condition C5 — Σ Commit Semantics

PMS-STACK condition:

```text
Σ commits define clear integration semantics for memory, IPC, filesystem,
transactions, audit, and distributed commit.
```

Artifact gate:

```text
G-C5: Commit Semantics Gate
```

Gate requirements:

```text
implemented commit points are explicit

commit changes runtime state in declared way

post-commit state is traceable

sealed or finalized state obeys declared constraints

rollback / failure behavior is declared where relevant

unsupported commit domains are marked out of scope
```

Evidence types:

```text
kernel commit operation
snapshot events
trace commit records
golden traces
post-commit invariant checks
failure fixtures
```

Acceptance:

```text
ACCEPT iff every implemented Σ has:
    pre-state
    commit action
    post-state
    trace event
    invariant effect
    failure behavior or explicit unsupported boundary
```

Limitation:

```text
local Σ evidence does not establish distributed Σᴳ.
```

### 5.8 Completeness Condition C6 — Boot or Normal Form

PMS-STACK condition:

```text
boot or runtime initialization reaches a declared normal form.
```

Artifact gate:

```text
G-C6: Runtime Normal Form Gate
```

Gate requirements:

```text
runtime initialization is deterministic under declared profile

model data loads or is embedded

initial frame / state / policy / meta-state is declared

validation mode is known

execution starts from known baseline

trace begins with identifiable runtime context where required
```

Evidence types:

```text
runtime initialization tests
model loading tests
script startup behavior
REPL model command
initial trace event
fixture harness
```

Acceptance:

```text
ACCEPT iff runtime startup produces a reproducible baseline under the
declared profile.
```

Limitation:

```text
runtime normal form in PMS-RUST is not full PMS boot or cluster boot.
```

### 5.9 Completeness Condition C7 — Extensible Without New Primitives

PMS-STACK condition:

```text
new features reduce to the existing operator grammar.
```

Artifact gate:

```text
G-C7: Extension Reduction Gate
```

Gate requirements:

```text
new feature maps to existing operators

new feature declares frame, role, policy, boundary, ordering, absence,
recontextualization, and commit behavior where relevant

new feature introduces no hidden primitive

new feature has tests for valid and invalid behavior

new feature trace preserves operator vocabulary
```

Evidence types:

```text
feature design note
operator mapping table
validation rules
fixtures
trace output
negative tests
```

Acceptance:

```text
ACCEPT iff feature behavior is expressible as Δ–Ψ structure and passes
declared conformance tests.
```

Limitation:

```text
feature-level reduction does not prove full architectural completeness.
```

### 5.10 Completeness Condition C8 — No Primitive Drift

PMS-STACK condition:

```text
no feature requires a primitive outside Δ–Ψ.
```

Artifact gate:

```text
G-C8: Primitive Discipline Gate
```

Gate requirements:

```text
no new runtime action is treated as semantically primitive unless mapped
to Δ–Ψ

host-service shortcuts are marked as host services, not PMS operators

AI/tooling outputs are proposals, not new semantics

external APIs are boundary surfaces, not base operators
```

Evidence types:

```text
operator enum review
host-service boundary tests
AI bridge tests
trace vocabulary inspection
documentation
```

Acceptance:

```text
ACCEPT iff every new executable behavior either maps to existing operator
structure or is explicitly classified as outside PMS operator execution.
```

Limitation:

```text
primitive discipline in one artifact does not guarantee all future
artifacts preserve it.
```

### 5.11 Boundary-Exit Artifact Gate

PMS-STACK condition:

```text
boundary entry, boundary exit, sealed isolation, closure, rollback, audit,
and commit behavior must preserve Χ as an implementation-layer projection
of PMS Base Distance.
```

Artifact gate:

```text
G-BX: Boundary-Exit Gate
```

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Gate requirements:

```text
boundary entry creates an active boundary context

valid exit requires an active boundary context

unbalanced exit is rejected

sealed isolation forbids further entry, expansion, or reachability growth

sealed isolation permits valid exit, closure, rollback, audit, or commit
under the declared runtime profile and active boundary context

boundary-exit behavior emits trace evidence where profile requires it
```

Evidence types:

```text
chi_enter / chi_exit fixtures
unbalanced-exit rejection fixture
sealed-isolation fixture
trace event for valid exit
trace event for rejected exit
stateful validation gate
golden tests
```

Acceptance:

```text
ACCEPT iff valid boundary exit succeeds under an active boundary context
and unbalanced exit is rejected under the declared profile.
```

Limitation:

```text
PMS-RUST chi_exit evidence strengthens bounded runtime isolation-exit
claims.

It does not complete PMS-CPU ISO_EXIT.
It does not redefine PMS Base Χ.
It does not validate PMS Base.
```

### 5.12 PMS-RUST Gate Matrix

A useful relation matrix:

| PMS-STACK completeness condition | PMS-RUST artifact gate | Evidence form |
| -------------------------------- | ---------------------- | ------------- |
| Operator representatives | Operator Representation Gate | enum, model keys, traces |
| OS mechanisms as operator sequences | OS Mechanism Mapping Gate | vFS/service fixtures |
| PMSL → IR → runtime mapping | PMSL/PMS-IR Mapping Gate | builder, scripts, opcodes |
| Ψ invariants at layers | Policy / Invariant Gate | validators, negative tests |
| Σ commit semantics | Commit Semantics Gate | commit events, snapshots |
| Boot / normal form | Runtime Normal Form Gate | init tests, startup trace |
| Extensible without new primitives | Extension Reduction Gate | mapping table, fixtures |
| No primitive drift | Primitive Discipline Gate | enum/API/trace review |
| Boundary exit | Boundary-Exit Gate | chi_exit / ISO_EXIT mapping fixtures |

### 5.13 Evidence Levels

Artifact gates can be graded.

```text
E0: architecture-only
E1: data model exists
E2: code representation exists
E3: validation exists
E4: execution exists
E5: trace exists
E6: golden fixture exists
E7: acceptance gate enforced in CI or equivalent harness
```

Example:

```text
operator enum with stable key:
    E2

operator enum + validator:
    E3

operator enum + validator + deterministic execution + JSONL trace:
    E5

plus golden fixtures:
    E6
```

Evidence-level rule:

```text
higher evidence level strengthens implementation-artifact claim.
It does not change claim type into PMS Base validation.
```

Roadmap boundary:

```text
roadmap ≠ implemented evidence

documented_slice ≠ executable evidence

implemented_slice requires code, test, trace, fixture, or validation
evidence for bounded scope
```

### 5.14 Acceptance-Gate Language

Recommended gate language:

```text
This gate accepts when ...
This gate rejects when ...
This gate emits evidence ...
This gate supports ...
This gate does not establish ...
```

Example:

```text
This gate accepts when an invalid Σ-after-seal program is rejected before
execution and emits a diagnostic plus trace evidence.

This gate supports bounded runtime invariant enforcement.

This gate does not establish full formal verification of PMS-STACK.
```

Artifact gate vocabulary:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

Incorrect gate vocabulary:

```text
tests validate PMS
traces prove PMS
gates externally validate PMS
runtime validates PMS Base
```

### 5.15 Trace Evidence in Artifact Gates

Artifact gates may require trace evidence.

A concrete PMS-RUST execution produces:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Under active runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible PMS-RUST executions under a declared profile is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

and under policy:

```text
Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

JSONL output records observed `trace_rust(...)` values.

It does not by itself enumerate `Trace_rust(...)`.

Gate trace boundary:

```text
trace evidence supports the declared gate outcome for the observed run.
It does not prove all possible executions.
```

### 5.16 Artifact Gate Invariants

```text
AG1: every artifact gate maps to a PMS-STACK architecture condition

AG2: every artifact gate states executable scope

AG3: every artifact gate states validation rule

AG4: every artifact gate states expected evidence

AG5: every artifact gate states acceptance and rejection behavior

AG6: every artifact gate states limitation

AG7: passing one gate does not imply passing all gates

AG8: passing gates strengthens implementation-artifact claims

AG9: passing gates does not validate PMS Base

AG10: artifact gates prevent implementation claims from exceeding evidence

AG11: validation means profile/gate acceptance or rejection, not PMS Base
      validation, proof, external validation, or semantic finality

AG12: trace_rust(...) is observed execution evidence; Trace_rust(...) is a
      declared possible-execution set

AG13: PMS-RUST chi_exit requires active boundary context; unbalanced exit is
      invalid under the declared profile

AG14: PMS-RUST chi_exit and PMS-CPU ISO_EXIT map at boundary-exit concern
      level but remain different claim layers
```

### 5.17 Architectural Consequence

The consequence is:

```text
PMS-STACK completeness conditions become usable for PMS-RUST only when
translated into artifact gates.
```

This gives PMS-RUST a rigorous roadmap:

```text
architecture condition
→ bounded implementation slice
→ validation rule
→ fixture
→ trace
→ acceptance gate
→ limitation
```

The result is strong:

```text
PMS-RUST can accumulate executable evidence for PMS-STACK conformance.
```

The boundary is equally strong:

```text
accumulated artifact evidence strengthens implementation-layer claims.
It does not validate PMS Base and does not by itself complete PMS-STACK.
```

---

## 6. Extensibility Conditions

PMS-STACK is extensible because its architecture is operator-stable.

A new feature, subsystem, tool, runtime profile, protocol, validator, or artifact slice may be added only when it reduces to the existing operator grammar and preserves claim boundaries.

The central extensibility claim is:

```text
A PMS-STACK extension is valid when it can be represented as a valid
composition of Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, and Ψ, respects dependency
and layer constraints, declares its runtime profile, and introduces no
new primitive operator.
```

Claim type:

```text
IMPLEMENTATION-LAYER EXTENSIBILITY / ARTIFACT-GROWTH CLAIM
```

Boundary:

```text
For PMS-RUST, this becomes an implementation discipline.

New code must not merely work.

It must preserve operator structure, layer boundaries, validation
discipline, trace clarity, and claim limits.

Extension evidence strengthens bounded implementation-artifact claims.
It does not validate PMS Base and does not complete PMS-STACK by itself.
```

### 6.1 Extension Rule

A proposed extension `E` is admissible when:

```text
E ∈ PMS-STACK
iff
    reduce(E) ∈ O*
    ∧ valid_dependencies(reduce(E))
    ∧ declares_profile(E)
    ∧ preserves_layer_boundary(E)
    ∧ introduces_no_new_primitive(E)
```

where:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

This rule applies to:

```text
new kernel behavior
new IR construct
new runtime command
new validator
new file/service operation
new PPS message profile
new trace event
new AI bridge task
new simulator feature
new distributed fixture
new policy gate
new boundary-exit behavior
```

### 6.2 Operator Reduction Table

Every extension should supply an operator reduction table.

| Question | Required answer |
| -------- | --------------- |
| What does the feature distinguish? | `Δ` |
| What state does it mutate or act on? | `∇` |
| What frame gives it context? | `□` |
| What absence/failure can occur? | `Λ` |
| What reusable pattern does it instantiate? | `Α` |
| What authority or asymmetry governs it? | `Ω` |
| What ordering does it require? | `Θ` |
| What recontextualization can occur? | `Φ` |
| What Distance/boundary projection applies? | `Χ` |
| What state becomes stable? | `Σ` |
| What policy or invariant constrains it? | `Ψ` |

An extension does not need to use every operator.

It must account for every operator-relevant obligation.

### 6.3 PMS-RUST Extension Template

A PMS-RUST extension should include:

```text
name
purpose
STACK layer
runtime profile
operator reduction
validation rule
trace events
fixtures
acceptance gate
claim boundary
```

Template:

```text
ExtensionSpec = (
    name,
    stack_layer,
    profile,
    operator_word,
    state_effects,
    authority_requirements,
    boundary_requirements,
    policy_requirements,
    commit_semantics,
    absence_semantics,
    trace_schema,
    tests,
    limitations
)
```

This keeps the artifact aligned with PMS-STACK rather than drifting into ordinary ad-hoc tooling.

### 6.4 No New Primitive Rule

The strongest extensibility condition is:

```text
no new primitive operators.
```

Allowed:

```text
new opcode variant that maps to existing operator semantics
new parameterization
new profile
new validator pass
new trace event
new host service
new artifact gate
new fixture
new API wrapper
```

Not allowed as PMS-STACK primitive:

```text
new semantic operator outside Δ–Ψ
unmapped host behavior treated as PMS execution
AI output treated as authority
external API treated as base semantics
policy bypass treated as optimization
trace event treated as proof
runtime dialect alias treated as PMS Base migration completion
```

If a behavior is external, it may exist as:

```text
host service
tooling
adapter
bridge
test harness
simulation input
```

but it must not be misclassified as PMS operator semantics.

### 6.5 Dependency Constraints

Extensions must preserve operator dependency discipline.

Examples:

```text
Ω authority cannot be assumed before Δ subject classification

Σ commit cannot stabilize state before Ψ policy has permitted it where protected

Φ recontextualization cannot erase prior policy or audit obligations

Χ boundary crossing cannot happen invisibly

Λ timeout requires an expected event and τ/window context

Θ ordering must be declared where execution order affects correctness

Ψ policy update must itself be governed by authority and commit semantics

chi_exit requires an active boundary context

unbalanced boundary exit is invalid
```

Dependency failure should produce:

```text
validation error
runtime denial
trace event
fixture failure
acceptance-gate rejection
```

### 6.6 Layer Boundary Discipline

Extensions must declare their layer.

Possible layers:

```text
PMS Base reference
PMS-STACK architecture
PMS-UM profile
PMS-CPU profile
PMS-OS profile
PMSL / PMS-IR
runtime security
networking
distributed systems
simulation
verification
PMS-RUST artifact
host tooling
AI bridge
test harness
```

Layer rule:

```text
artifact extension
≠ PMS Base change

runtime dialect
≠ base theory

host tooling
≠ operator semantics

test harness
≠ proof system

PMS-RUST chi_exit
≠ PMS Base Χ redefinition

PMS-RUST chi_exit
≠ PMS-CPU ISO_EXIT completion
```

This matters especially for PMS-RUST, where executable usefulness can make boundaries feel less visible.

### 6.7 Runtime Profile Discipline

Every extension must declare its runtime profile.

Profiles may include:

```text
deterministic_kernel
script_runner
REPL
vFS_service
AI_bridge
simulation
trace_only
validator_only
distributed_fixture
cluster_simulation
host_adapter
boundary_exit_fixture
```

Profile declaration must state:

```text
supported operators
unsupported operators
state model
validation rules
commit behavior
trace behavior
failure behavior
security boundary
```

Profile rule:

```text
behavior under profile P
≠ behavior under all PMS-STACK profiles.
```

### 6.8 Trace Discipline

Extensions must preserve trace clarity.

Trace events should state:

```text
operator
event kind
frame
role/capability if relevant
policy if relevant
boundary if relevant
commit ref if relevant
result
source profile
```

Trace invariant:

```text
new trace events must not obscure whether behavior is PMS execution,
host service, tooling event, validation event, or AI proposal event.
```

For PMS-RUST, this prevents host-service commands or AI outputs from being confused with kernel operator execution.

Single-run convention:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Set convention:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

### 6.9 Validation Discipline

Extensions should define validation before execution where possible.

Validation types:

```text
syntax validation
model validation
operator dependency validation
stateful validation
policy validation
profile validation
boundary validation
commit validation
trace-schema validation
fixture validation
```

Validation rule:

```text
invalid extension behavior fails closed.
```

Recommended rejection evidence:

```text
diagnostic code
operator or feature name
expected condition
found condition
span or source if available
trace event where appropriate
```

Validation boundary:

```text
validation means acceptance or rejection under declared artifact profile.

It does not mean PMS Base validation, proof, external validation, or
semantic finality.
```

### 6.10 Host-Service Extension Boundary

Some PMS-RUST features may be host services rather than PMS operator execution.

Examples:

```text
file read/write helper
script runner command
trace export
REPL meta-command
AI analysis request
debug command
test harness action
```

Host-service rule:

```text
host service may support PMS execution,
but it is not itself automatically an operator transition.
```

If a host service affects PMS state, it must declare:

```text
where the boundary lies
which operator event represents the PMS-visible part
what authority is required
what policy applies
what trace is emitted
what commit occurs
```

### 6.11 AI Bridge Extension Boundary

AI bridge extensions require strict boundary discipline.

Allowed:

```text
analyze trace
propose scenario
propose operator program
summarize diagnostics
suggest fixture
```

Not allowed:

```text
AI directly executes code
AI grants authority
AI bypasses validator
AI changes policy
AI commits runtime state
AI validates PMS Base
AI supplies compiler authority
AI supplies verifier authority
AI supplies verification evidence
AI defines PMSL semantics
```

Correct pattern:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to known schema.
Validator checks.
Kernel executes only accepted opcode program.
Trace records accepted execution.
```

AI output is not trusted executable code, compiler authority, verifier authority, verification evidence, runtime policy authority, or PMS Base validation.

### 6.12 Extending Toward PMS-CPU

A PMS-RUST extension toward PMS-CPU must declare:

```text
CPU state
register model
instruction enum
decode Δ
privilege Ω
policy Ψ
frame/memory □/Χ
trap Φ
ordering Θ
commit Σ
trace events
fixtures
unsupported ISA features
```

Acceptance examples:

```text
valid instruction decodes to operator event

privileged instruction without authority is denied

trap enters Φ frame

commit emits Σ event

trace matches golden fixture

ISO_EXIT-style boundary exit requires active boundary context
```

Boundary:

```text
partial CPU slice strengthens PMS-CPU artifact claim.
It does not complete PMS-CPU.
```

### 6.13 Extending Toward PMS-OS

A PMS-RUST extension toward PMS-OS must declare:

```text
process/thread frame
syscall surface
memory/resource model
capability model
policy model
isolation model
scheduler/order model
commit semantics
audit events
host boundary
```

Acceptance examples:

```text
process frame created under policy

syscall-like operation requires capability

cross-frame access denied

resource exhaustion produces Λ/no-resource

state change commits through Σ

audit-required operation emits trace
```

Boundary:

```text
OS-like service slice strengthens PMS-OS artifact claim.
It does not equal full PMS-OS.
```

### 6.14 Extending Toward PMSL / PMS-IR

A PMS-RUST extension toward PMSL/PMS-IR must declare:

```text
source construct
IR form
operator lowering
type/profile constraints
diagnostics
runtime behavior
trace semantics
fixtures
```

Acceptance examples:

```text
source construct lowers to canonical opcode sequence

invalid construct produces diagnostic

lowered program passes model/stateful validation

execution trace matches expected operator sequence
```

Boundary:

```text
IR lowering slice strengthens PMSL/PMS-IR artifact claim.
It does not complete full PMSL compiler.
```

AI may propose PMS-IR or opcode programs under host-side validation.

AI output is not PMSL semantics, compiler authority, verifier authority, verification evidence, or trusted executable code.

### 6.15 Extending Toward Runtime Security

A PMS-RUST extension toward runtime security must declare:

```text
identity model
role/capability model
boundary model
policy model
sealed-state behavior
entry/exit discipline
commit semantics
audit evidence
failure behavior
```

Acceptance examples:

```text
boundary entry creates active context

chi_exit succeeds only under active boundary context

unbalanced chi_exit is rejected

sealed isolation forbids further entry, expansion, or reachability growth

sealed isolation permits valid exit, closure, rollback, audit, or commit
under declared profile

policy denial prevents protected execution or commit
```

Boundary:

```text
runtime-security slice strengthens bounded runtime-security artifact claims.
It does not complete runtime security and does not redefine PMS Base Χ.
```

### 6.16 Extending Toward Distributed Systems

A distributed extension must declare:

```text
node frame
session/message model
routing profile
PPS class
authority model
boundary model
policy model
absence/failure model
commit profile
audit profile
```

Acceptance examples:

```text
P-REQ timeout produces Λ_no_response

quorum failure produces Λ_no_quorum

distributed commit requires declared Ψᴳ condition

cross-node isolation violation is denied

audit chain records distributed commit summary
```

Boundary:

```text
distributed fixture strengthens distributed artifact claim.
It does not prove distributed correctness for all profiles.
```

### 6.17 PMS 1.3 Migration Boundary for Extensions

Extensions may advance PMS 1.3 alignment.

They do not complete it by naming.

Correct migration boundary:

```text
PMS-RUST runtime dialect alignment is a tracked migration boundary.

A runtime command, alias, opcode name, validator rule, or trace event may
evidence implementation alignment work.

It does not by itself complete PMS 1.3 semantic migration.
```

`chi_exit` is part of this boundary:

```text
PMS-RUST chi_exit evidences runtime boundary-exit discipline.

It does not redefine PMS Base Χ.

It does not complete PMS-CPU ISO_EXIT.

It does not validate PMS Base.
```

### 6.18 Extension Acceptance Checklist

Before accepting a PMS-RUST extension:

```text
1. Does it declare STACK layer?

2. Does it declare runtime profile?

3. Does it reduce to Δ–Ψ or mark itself as host/tooling?

4. Does it preserve PMS Base operator identity?

5. Does it declare validation?

6. Does it declare commit semantics?

7. Does it declare failure/absence behavior?

8. Does it declare trace evidence?

9. Does it include positive and negative fixtures?

10. Does it state limitations?

11. Does it avoid PMS Base validation language?

12. Does it avoid claiming full STACK completion unless evidence supports it?

13. Does it preserve the chi_exit / ISO_EXIT / PMS Base Χ boundary where
    boundary-exit behavior is involved?

14. Does it keep AI/tooling output non-authoritative?
```

### 6.19 Extensibility Invariants

```text
EX1: every extension reduces to Δ–Ψ or is explicitly outside PMS operator
     execution

EX2: every extension declares layer and profile

EX3: every extension preserves PMS Base operator identity

EX4: every extension preserves the PMS Base / PMS-STACK / PMS-RUST boundary

EX5: every extension declares validation and failure behavior

EX6: every extension declares commit semantics where state becomes stable

EX7: every boundary-crossing extension accounts for Χ as implementation-layer
     projection of PMS Base Distance

EX8: every extension with authority effects accounts for Ω

EX9: every extension with ordering effects accounts for Θ

EX10: every extension with absence/failure behavior accounts for Λ

EX11: every extension with recontextualization accounts for Φ

EX12: every extension with policy effects accounts for Ψ

EX13: every extension includes artifact evidence proportional to its claim

EX14: extension tests and traces strengthen implementation-artifact claims

EX15: extension tests and traces do not function as PMS Base validation

EX16: PMS-RUST chi_exit requires active runtime boundary context; unbalanced
      exit is invalid under the declared profile

EX17: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline;
      PMS-CPU ISO_EXIT is the architecture-level boundary-exit instruction;
      neither redefines PMS Base Χ nor validates PMS Base

EX18: AI/tooling may propose, summarize, and assist; it may not provide
      compiler authority, verifier authority, verification evidence,
      runtime policy authority, or PMS Base evidence
```

### 6.20 Architectural Consequence

The consequence is:

```text
PMS-STACK extensibility is disciplined semantic growth.
```

New PMS-RUST features may grow the evidence spine toward PMS-CPU, PMS-OS, PMSL/PMS-IR, security, networking, distributed systems, simulation, and verification.

But every extension must answer:

```text
Which operator structure does this realize?
Which profile does it belong to?
Which validation gate protects it?
Which trace shows it?
Which fixture tests it?
Which claim does it strengthen?
Which claim does it not make?
```

This keeps PMS-RUST extensible without turning artifact convenience into theory drift.

The extension boundary is therefore:

```text
PMS-STACK specifies.
PMS-RUST evidences.
PMS Base defines.
Tests inspect.
Traces record.
Gates discipline.
AI proposes.
Host validates.
Kernel executes accepted artifacts.
```

---

## 7. Cross-Layer Mapping: UM, CPU, OS, PMSL, Runtime

PMS-STACK is cross-layer by design.

It does not define PMS-UM, PMS-CPU, PMS-OS, PMSL, runtime security, networking, and distributed systems as unrelated layers. It defines them as projections of the same operator grammar into different implementation frames.

The central cross-layer claim is:

```text
PMS-STACK cross-layer mapping is valid when the same Δ–Ψ operator
structure can be read across PMS-UM, PMS-CPU, PMS-OS, PMSL/PMS-IR,
runtime security, networking, and distributed systems without changing
the base operator alphabet.
```

Claim type:

```text
IMPLEMENTATION-LAYER CROSS-LAYER MAPPING CLAIM
```

Boundary:

```text
This is an architecture claim.

PMS-RUST relates to this mapping as a bounded executable artifact: it may
implement and evidence selected cross-layer correspondences, but it does
not by itself instantiate all layers.

Cross-layer mapping does not validate PMS Base.
Cross-layer mapping does not complete PMS-STACK.
Cross-layer mapping does not make one implemented slice equivalent to the
whole architecture.
```

PMS Base remains the source of operator identity.

At PMS Base level:

```text
Χ = Distance
```

At PMS-STACK implementation layers, Χ projects as:

```text
isolation
boundary
reachability control
access separation
namespace visibility
sandboxing
containment
quarantine
cross-node boundary
trust-domain separation
```

This projection does not redefine PMS Base Χ.

### 7.1 Purpose of Cross-Layer Mapping

Cross-layer mapping serves four functions.

```text
1. semantic continuity
    the same operator grammar remains visible across abstraction levels

2. implementation guidance
    each layer knows what kind of artifact must represent which operator role

3. conformance checking
    artifacts can be checked against layer-specific mappings

4. claim discipline
    a Rust crate, runtime slice, trace, or fixture can be mapped to the
    correct STACK layer without becoming PMS Base authority
```

The mapping prevents two opposite errors:

```text
treating each layer as unrelated engineering

treating one implemented layer as the whole architecture
```

PMS-RUST is important in this section because it gives executable pressure to cross-layer mapping.

It remains bounded because executable pressure is not PMS Base validation.

### 7.2 Mapping Principle

The mapping principle is:

```text
same operator
different layer projection
same claim boundary
```

Example:

```text
□ at PMS-UM level:
    abstract state partition

□ at PMS-CPU level:
    page, segment, execution domain, hardware-isolated region

□ at PMS-OS level:
    process, address space, container, kernel/user frame

□ at PMSL level:
    explicit frame block or context boundary

□ at PMS-RUST evidence-spine level:
    bounded runtime frame/state representation, where implemented
```

The operator remains `□`.

The implementation projection changes.

A runtime convenience, host command, or trace event does not become a new operator merely because it is useful.

### 7.3 Mapping Table

The following table gives the core cross-layer structure.

| Concept | PMS-UM | PMS-CPU | PMS-OS | PMSL / PMS-IR | PMS-RUST evidence-spine reading |
| ------- | ------ | ------- | ------ | ------------- | ------------------------------- |
| Frame `□` | abstract state partition | page, segment, execution domain | process, address space, container | `frame { … }`, context boundary | runtime frame/state slice where implemented |
| Role `Ω` | abstract capability relation | privilege bits, capability registers | UID/GID, ACL, seccomp, capability state | `role use R`, policy-bound role | role/capability validation where implemented |
| Policy `Ψ` | transition constraint over `O*` | guard / privilege / policy check | security module, MAC, invariant | `policy with P { … }` | model/stateful validation and rejection |
| Distance / Boundary `Χ` | PMS Base: Distance; STACK projection: non-reachability | MMU/domain protection | namespace, sandbox, container boundary | scoped visibility / isolation block | v0.1 boundary/isolation projection |
| Action `∇` | state transition | ALU op, memory write, I/O instruction | syscall, FS op, IPC op | expression, statement, side-effect rule | opcode execution / host-service boundary where declared |
| Commit `Σ` | staged state integrated into global state | writeback, fence, barrier, TLB sync | transaction end, FS commit, scheduler update | `commit Σ { … }` or implicit commit point | kernel commit event / trace commit / seal where implemented |
| Trap / Reframe `Φ` | recontextualization in state model | exception, interrupt, trap entry | signal, fault handler, migration/restart | `on Φ { … }`, handler frame | runtime error/reframe/failure path where implemented |
| Ordering `Θ` | abstract step / sequence | CPU tick, instruction step, branch resolution | scheduler tick, wakeup, timer | `await`, `step`, ordering construct | deterministic step/tick/event order |
| Absence `Λ` | non-event placeholder | timeout, wait-loop not satisfied | empty queue, poll timeout, no event | `timeout Λ`, absence branch | timeout/no-event fixture where implemented |
| Boundary exit | valid frame/boundary closure | `ISO_EXIT` ISA-level boundary-exit instruction | isolation/context exit under OS policy | scoped block exit | `chi_exit` bounded runtime/artifact evidence where implemented |

### 7.4 PMS-UM Mapping

PMS-UM is the abstract machine layer.

It defines execution in terms of:

```text
state
operator pointer
frame configuration
role state
policy state
meta-state
ordering
absence
commit
```

A PMS-UM-level execution is read as an operator transition system.

```text
(s, π) → (s', π')
```

where `π` is an operator program or operator pointer.

PMS-RUST relation:

```text
PMS-RUST may implement bounded operator programs and deterministic
stepping behavior that resemble a UM execution slice.
```

Boundary:

```text
PMS-RUST v0.1 does not equal a complete PMS-UM simulator unless the
artifact explicitly implements the full UM profile.
```

A bounded UM-like execution trace strengthens implementation-artifact evidence.

It does not complete PMS-UM and does not validate PMS Base.

### 7.5 PMS-CPU Mapping

PMS-CPU is the virtual CPU / ISA architecture layer.

CPU-level mapping turns operators into instruction semantics:

```text
Δ   fetch/decode / operand distinction
∇   instruction effect
□   frame / memory-domain operation
Ω   privilege / capability check
Θ   instruction order / tick / pipeline order
Φ   trap / exception / interrupt
Χ   memory/domain boundary projection
Σ   writeback / barrier / commit
Ψ   guard / invariant / policy check
Λ   timeout / wait / no-event condition where relevant
```

PMS-RUST relation:

```text
PMS-RUST can support future PMS-CPU work by already representing
operators, executing bounded opcode programs, validating model constraints,
and emitting traces.
```

Boundary:

```text
operator execution support is not the same as a complete PMS-CPU.

A complete PMS-CPU still requires declared CPU state, registers, memory
model, ISA instruction set, decode loop, trap frames, and CPU-level tests.
```

Boundary-exit mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

They correspond at the boundary-exit concept level.

They are not the same claim layer.

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

A PMS-RUST `chi_exit` may evidence that a bounded runtime profile rejects unbalanced isolation exit or permits valid isolation closure.

It does not complete PMS-CPU.

It does not redefine PMS Base Χ.

It does not validate PMS Base.

### 7.6 PMS-OS Mapping

PMS-OS is the kernel/runtime architecture layer.

OS mechanisms map to operator structures:

```text
process
    □ process frame

thread
    Θ-ordered execution stream inside runtime frame

syscall
    Δ classify call
    Ω check authority
    Ψ check policy
    ∇ perform operation
    Σ commit result
    Φ trap/error path if needed

memory isolation
    Χ implementation projection of Distance

filesystem operation
    Δ path/object distinction
    Ω authority
    Ψ access/invariant policy
    ∇ read/write/update
    Σ commit

IPC
    Δ message type
    Ω sender/receiver capability
    Θ delivery order
    Λ timeout/no receiver
    Σ delivery commit
    Ψ channel policy
```

PMS-RUST relation:

```text
PMS-RUST may provide bounded OS-like evidence through host-service surfaces,
vFS behavior, script commands, validation gates, and traces.
```

Boundary:

```text
bounded vFS or host-service behavior does not equal full PMS-OS.
```

Host-service effects must remain separated from PMS operator execution unless explicitly mapped, validated, traced, and committed under a declared profile.

### 7.7 PMSL / PMS-IR Mapping

PMSL and PMS-IR are the language/runtime representation layers.

Language constructs map into operator words.

Examples:

```text
frame block
    → □

role use / capability context
    → Ω

policy block
    → Ψ

timeout branch
    → Λ

exception / handler
    → Φ

commit block
    → Σ

await / step
    → Θ

isolate / scoped visibility
    → Χ implementation projection

boundary exit
    → valid closure of an active boundary context
```

PMS-RUST relation:

```text
PMS-RUST may implement bounded PMS-IR construction through builder APIs,
opcode buffers, scripts, REPL commands, validators, and traces.
```

Boundary:

```text
IR construction and script lowering are not a complete PMSL compiler.
```

AI may propose PMS-IR or opcode programs.

AI output is not PMSL semantics, compiler authority, verifier authority, verification evidence, trusted executable code, or PMS Base evidence.

### 7.8 Runtime Mapping

The runtime layer sits between PMSL/PMS-IR, kernel execution, host services, validators, traces, and tooling.

Runtime responsibilities include:

```text
program loading
operator buffering
validation
execution
state tracking
event emission
trace serialization
diagnostics
host-service mediation
AI proposal gating
fixture execution
```

PMS-RUST relation:

```text
PMS-RUST is primarily a bounded runtime/evidence-spine artifact at this
stage.
```

It strengthens runtime claims such as:

```text
bounded operator programs can be built

bounded operator programs can be validated under declared artifact profiles

bounded operator programs can be executed deterministically

runtime events can be emitted

JSONL traces can be produced

invalid programs can fail closed

AI proposals can be kept outside trusted execution until validated

runtime boundary-exit discipline can be evidenced through chi_exit-style
fixtures where implemented
```

Boundary:

```text
runtime evidence does not imply complete CPU, OS, PMSL compiler, or
distributed runtime implementation.
```

Validation in this document means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean PMS Base validation, proof, external validation, or semantic finality.

### 7.9 Security Mapping

Security maps across every layer.

```text
PMS-UM:
    Ψ constraints over valid transitions

PMS-CPU:
    privilege checks, guard conditions, capability registers, ISO_EXIT
    boundary-exit instruction semantics where declared

PMS-OS:
    user/kernel roles, process boundaries, access control, policies

PMSL:
    policy blocks, role usage, scoped visibility

Runtime:
    validator checks, rejection paths, boundary entry/exit discipline,
    trace/audit events

PMS-RUST:
    bounded validation, fail-closed behavior, chi_exit boundary-exit
    discipline where implemented, trace evidence, AI boundary
```

Security is not a separate layer pasted on top.

It is a cross-layer reading of:

```text
Δ + Ω + Χ + Ψ + Θ + Φ + Λ + Σ
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

This rule is a runtime-security and boundary-exit discipline.

It does not redefine PMS Base Χ.

### 7.10 Trace Mapping

Traces are the practical bridge between cross-layer specification and artifact evidence.

Trace mapping requires:

```text
operator label
layer/profile
frame
role/capability if relevant
policy if relevant
boundary if relevant
ordering
commit reference if relevant
result
```

A PMS-RUST trace should therefore be readable as:

```text
this runtime event corresponds to this operator role
inside this declared profile
with this claim boundary
```

Trace mapping supports:

```text
debugging
golden tests
acceptance gates
artifact review
cross-layer conformance
future simulator comparison
```

Trace convention:

```text
trace_rust(artifact, profile, input) ∈ L_PMS

Trace_rust(artifact, profile) ⊆ L_PMS
```

Under active runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ

Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

JSONL output records observed `trace_rust(...)` values.

It does not by itself enumerate `Trace_rust(...)`.

Trace boundary:

```text
trace readability strengthens evidence.
It does not prove full correctness.
```

### 7.11 Cross-Layer Mapping to Artifact Gates

The mapping table becomes a gate table for PMS-RUST.

| STACK concept | Artifact question |
| ------------ | ----------------- |
| `□` Frame | Does the artifact declare state/context boundary? |
| `Ω` Role | Does it declare authority/capability requirements? |
| `Ψ` Policy | Does validation enforce declared constraints? |
| `Χ` Boundary | Does it name boundary/isolation as implementation projection? |
| `∇` Action | Does execution mutate only declared state? |
| `Σ` Commit | Does stable state change emit commit evidence? |
| `Φ` Reframe | Are errors/traps/fallbacks structured? |
| `Θ` Ordering | Is event order deterministic or profiled? |
| `Λ` Absence | Are missing events/timeouts explicit? |
| `Δ` Distinction | Are entities/operators/messages classified before use? |
| `ISO_EXIT` / `chi_exit` | Does boundary exit require active boundary context and reject unbalanced exit? |

Artifact gate boundary:

```text
passing a cross-layer gate strengthens the mapped artifact claim.

It does not complete the mapped STACK layer.
It does not validate PMS Base.
```

### 7.12 Mapping Levels

PMS-RUST evidence can be graded by mapping level.

```text
M0: concept named only
M1: data structure exists
M2: parser/builder/API representation exists
M3: validator checks it
M4: runtime executes it
M5: trace emits it
M6: fixture covers it
M7: acceptance gate enforces it
```

Example:

```text
Frame support at M2
    a frame-like data structure or builder construct exists

Frame support at M5
    frame entry/exit or frame state appears in trace

Frame support at M7
    invalid frame usage is rejected by acceptance gate
```

Mapping level discipline prevents overclaiming.

Roadmap discipline:

```text
roadmap ≠ implemented evidence

documented_slice ≠ executable evidence

implemented_slice requires code, test, trace, fixture, or validation
evidence for bounded scope
```

### 7.13 Cross-Layer Drift Risk

The risk is layer drift.

Examples:

```text
runtime dialect treated as PMS Base

host service treated as kernel semantics

builder convenience treated as PMSL compiler

trace output treated as proof

vFS demo treated as full PMS filesystem

AI bridge treated as trusted compiler

operator enum treated as full architecture completion

chi_exit treated as PMS Base Χ redefinition

chi_exit treated as completed PMS-CPU ISO_EXIT
```

The corrective rule is:

```text
artifact evidence may strengthen the layer it actually implements.
It may not silently borrow authority from another layer.
```

Runtime dialect alignment is a tracked migration boundary.

A runtime command, alias, opcode name, validator rule, or trace event may evidence implementation alignment work.

It does not by itself complete PMS 1.3 semantic migration.

### 7.14 Cross-Layer Mapping Invariants

```text
CLM1: every artifact claim states its STACK layer

CLM2: every artifact claim states its runtime profile

CLM3: every operator representation preserves PMS Base operator identity

CLM4: every Χ implementation claim names the Distance-to-boundary projection

CLM5: every runtime convenience is separated from PMS operator semantics

CLM6: every trace event declares enough context to be layer-readable

CLM7: every implemented slice maps to explicit architecture concepts

CLM8: every unimplemented layer remains architecture target, not artifact claim

CLM9: cross-layer mapping strengthens implementation-artifact claims

CLM10: cross-layer mapping does not validate PMS Base

CLM11: validation means profile/gate acceptance or rejection, not PMS Base
       validation, proof, external validation, or semantic finality

CLM12: trace_rust(...) denotes an observed PMS-RUST execution; Trace_rust(...)
       denotes a profile-bounded execution set

CLM13: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline;
       PMS-CPU ISO_EXIT is the architecture-level boundary-exit instruction;
       neither redefines PMS Base Χ nor validates PMS Base

CLM14: AI/tooling output is not compiler authority, verifier authority,
       verification evidence, PMSL semantics, trusted executable code, or
       PMS Base evidence
```

### 7.15 Architectural Consequence

The consequence is:

```text
Cross-layer mapping is the table by which PMS-RUST can be related to
PMS-STACK without inflation.
```

PMS-STACK supplies:

```text
UM → CPU → OS → PMSL → runtime structure
```

PMS-RUST supplies:

```text
bounded executable evidence for selected runtime and operator slices.
```

The relationship is therefore precise:

```text
same operator grammar,
different layer projection,
bounded artifact evidence,
no PMS Base validation.
```

---

## 8. Classical OS / VM Boundary

PMS-STACK is not an alien alternative to operating systems, virtual machines, runtimes, or IPC mechanisms.

It is a structurally stricter architecture that makes their underlying semantics explicit.

The central boundary claim is:

```text
PMS-STACK generalizes classical OS, VM, runtime, IPC, scheduling, and
security concepts by representing them as Δ–Ψ operator structures; PMS-RUST
may evidence bounded executable slices of that structure, but it should
not be misread as merely another VM, a finished OS, a finished CPU, a
finished compiler, or a replacement for PMS-STACK.
```

Claim type:

```text
IMPLEMENTATION-LAYER CLASSICAL OS / VM BOUNDARY CLAIM
```

Boundary:

```text
This section defines the boundary between classical OS concepts,
classical VM/runtime concepts, PMS-STACK architecture, and PMS-RUST
evidence-spine artifacts.

Classical comparison aids reader orientation.

It does not validate PMS Base.
It does not prove PMS-STACK.
It does not complete PMS-RUST.
It does not make PMS-RUST a finished OS, CPU, compiler, or VM platform.
```

### 8.1 Why the Boundary Matters

Without this boundary, PMS-RUST can be misclassified in several ways.

Incorrect readings:

```text
PMS-RUST is just another VM.

PMS-RUST is already PMS-OS.

PMS-RUST is the PMS-CPU.

PMS-RUST is the PMSL compiler.

PMS-RUST proves PMS-STACK.

PMS-RUST validates PMS Base.

PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.

PMS-RUST runtime dialect completes PMS 1.3 migration.
```

Correct reading:

```text
PMS-RUST is a bounded executable evidence spine for selected PMS-STACK
operator structures.
```

Classical OS and VM comparisons help place PMS-STACK for practitioners while preserving claim boundaries.

### 8.2 PMS-STACK and Unix/POSIX

Unix/POSIX expresses protection, process context, IPC, scheduling, signals, and filesystem behavior through historically evolved mechanisms:

```text
UID/GID
processes
file descriptors
pipes
sockets
signals
permissions
scheduler policies
errno
namespaces
```

PMS-STACK maps these to explicit operator structures:

```text
process
    □ process frame

effective UID/GID / privilege
    Ω role / capability

file descriptor table
    Δ_fd set inside process/file frame

access controls
    Ψ policy over permitted ∇ operations

namespace isolation
    Χ implementation projection of Distance

signals
    Φ trap / reframe

readiness / event wait
    Θ wait / probe

timeout
    Λ

resource finalization
    Σ commit / release
```

PMS-RUST boundary:

```text
A PMS-RUST vFS or script service may model bounded POSIX-like operations.
It does not thereby implement full POSIX or full PMS-OS.
```

### 8.3 PMS-STACK and Microkernels

Microkernels make capabilities and IPC explicit.

PMS-STACK absorbs that strength and generalizes it.

Microkernel concepts:

```text
minimal kernel
capabilities
IPC
user-space services
fault isolation
message passing
```

PMS-STACK projection:

```text
capability
    Ω

IPC message
    Δ typed message + Θ delivery + Σ commit

service frame
    □

fault or exception
    Φ

service isolation
    Χ projection

IPC policy
    Ψ

timeout / no receiver
    Λ
```

PMS-STACK is not anti-microkernel.

It is a higher-order semantic architecture into which microkernel structures can be embedded.

PMS-RUST boundary:

```text
bounded message/opcode execution or service-like behavior strengthens
evidence for operator-governed runtime design.
It does not equal a verified microkernel.
```

### 8.4 PMS-STACK and Monolithic Kernels

Monolithic kernels centralize many services inside one kernel address space.

PMS-STACK can represent monolithic behavior as a profile:

```text
large kernel frame
internal subsystem frames
privileged Ω roles
Ψ internal policies
Χ internal boundaries where declared
Σ subsystem commits
Φ trap/error paths
Θ scheduling/order
```

The key PMS-STACK improvement is not that monolithic kernels vanish.

It is that their implicit internal boundaries become explicit where the profile declares them.

PMS-RUST boundary:

```text
a bounded kernel-like interpreter is not a monolithic kernel.
It may evidence selected kernel semantics such as validation, stepping,
commit, and trace.
```

### 8.5 PMS-STACK and Virtual Machines

Classical VMs such as JVM, CLR, and WASM provide:

```text
bytecode
execution environment
sandbox
host integration
module boundary
runtime checks
```

PMS-STACK/PMSL maps these as:

```text
bytecode / code format
    operator words over O*

sandbox / module boundary
    Χ implementation projection + Ψ policy

host call / FFI
    Φ recontextualization across host boundary
    Ω authority
    Ψ policy
    Σ result commit where applicable

runtime checks
    Ψ validation

method invocation / function call
    Δ distinction + ∇ evaluation + Θ ordering + Σ result
```

Critical statement:

```text
PMSL is not merely another VM language.
It provides the semantic structure into which VM-like systems can be mapped.
```

PMS-RUST boundary:

```text
PMS-RUST may look VM-like because it executes bounded programs.
Its claim is narrower and stronger: it executes operator-typed artifacts
under declared validation and trace profiles.
```

Validation here means artifact-profile acceptance or rejection.

It does not mean PMS Base validation.

### 8.6 PMS-STACK and WASM

WASM is especially useful as comparison because it has a clear sandbox and host-function boundary.

WASM concepts:

```text
module
linear memory
host function
stack VM
import/export boundary
runtime validation
```

PMS-STACK projection:

```text
module
    □ frame

linear memory boundary
    Χ projection

host function
    Φ host recontextualization + Ω authority + Ψ policy

runtime validation
    Ψ

instruction/evaluation
    Δ/∇/Θ

result stabilization
    Σ
```

PMS-RUST boundary:

```text
PMS-RUST host-service commands or AI bridge calls must be treated as
boundary-mediated tooling/host actions, not silently as PMS operator
semantics.
```

AI output is not trusted executable code, compiler authority, verifier authority, verification evidence, runtime policy authority, or PMS Base validation.

### 8.7 IPC Boundary

Classical IPC includes:

```text
pipes
message queues
sockets
signals
shared memory
eventfds
channels
RPC
```

PMS-STACK reads IPC as:

```text
Δ   message / channel / endpoint distinction
Ω   sender/receiver authority
□   channel or session frame
Θ   send/receive ordering
Λ   no message / timeout / closed channel
Φ   error handler / reframe / signal
Χ   namespace / process / tenant boundary
Σ   delivery / enqueue / dequeue commit
Ψ   channel policy
```

PMS-RUST boundary:

```text
a runtime command, trace event, or host service may support IPC-like
scenarios only within its declared artifact profile.
```

A local delivery or script-level event is not distributed commit unless the declared profile explicitly connects it to Σᴳ.

### 8.8 Scheduling Boundary

Classical scheduling uses:

```text
priority
fairness heuristics
run queues
timers
wakeups
blocking
preemption
```

PMS-STACK maps scheduling to:

```text
Θ ordering
Ψ fairness / policy constraints
Λ no-ready-task / timeout
Φ preemption / trap / context switch
Σ scheduler-state commit
Ω privileged scheduling authority
□ execution frame
```

PMS-RUST boundary:

```text
deterministic step execution is an ordering profile.
It is not a full OS scheduler unless scheduler state, run queues,
preemption, timers, fairness policy, and fixtures are implemented.
```

A deterministic trace:

```text
trace_rust(artifact, deterministic_profile, input) ∈ L_PMS
```

records one observed execution.

It does not enumerate:

```text
Trace_rust(artifact, deterministic_profile)
```

and does not prove scheduler correctness.

### 8.9 Filesystem Boundary

Classical filesystem operations include:

```text
open
read
write
close
fsync
rename
unlink
transaction
journal
permissions
```

PMS-STACK projection:

```text
Δ path/object distinction
Ω file/resource authority
□ filesystem frame
Ψ access and consistency policy
∇ read/write/update
Θ ordering
Λ missing file / timeout / no resource
Φ error / rollback / reframe
Σ commit / writeback / release
Χ namespace / mount / container boundary
```

PMS-RUST boundary:

```text
bounded vFS behavior may evidence filesystem-like operator structure.
It does not equal complete PMS filesystem architecture.
```

Filesystem-like host services must not be silently treated as PMS-OS completion.

### 8.10 Host Integration Boundary

Host integration is one of the most important PMS-RUST boundaries.

Host actions include:

```text
filesystem access
process environment
terminal IO
AI backend call
trace export
script loading
debug command
test harness operation
```

Boundary rule:

```text
host action
≠ PMS operator execution
unless explicitly mapped, validated, traced, and committed as part of
a declared PMS profile.
```

A correct host boundary representation uses:

```text
Φ host recontextualization
Ω host permission
Χ host/runtime boundary
Ψ host policy
Σ result commit if PMS state changes
Θ audit/order
```

This keeps PMS-RUST useful without making the host environment invisible.

### 8.11 Boundary Exit in Classical Terms

Classical systems often have implicit boundary exit operations:

```text
return from sandboxed call
leave user/kernel transition
exit protected context
close scoped capability
leave transaction frame
return from exception handler
release namespace/session frame
```

PMS-STACK requires this behavior to be explicit where it affects isolation or authority.

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Boundary:

```text
PMS-RUST chi_exit strengthens bounded implementation-artifact claims about
runtime isolation-exit discipline.

It does not complete PMS-CPU ISO_EXIT.
It does not redefine PMS Base Χ.
It does not validate PMS Base.
```

### 8.12 PMS-RUST Is Not Merely Another VM

PMS-RUST may appear VM-like because it can:

```text
load scripted programs
construct opcodes
validate programs
execute a bounded runtime
emit traces
provide REPL interaction
```

But its architectural role is different.

A normal VM primarily claims:

```text
execute bytecode under a runtime.
```

PMS-RUST claims:

```text
execute bounded operator-typed programs under PMS-STACK-derived
validation, trace, and evidence discipline.
```

The distinction matters.

PMS-RUST is not valuable because it is “a small VM”.

It is valuable because it is an artifact spine:

```text
operator representation
validation
execution
trace
fixture
acceptance gate
boundary discipline
```

### 8.13 PMS-RUST Is Not PMS-OS

PMS-OS is the specified operating-system architecture layer.

It includes:

```text
kernel model
process model
thread model
memory model
syscalls
scheduling
IPC
filesystem
drivers
resource accounting
security
audit
boot
```

PMS-RUST v0.1 may implement or simulate bounded slices.

It does not equal PMS-OS unless those OS components are implemented under declared PMS-OS profiles.

Correct statement:

```text
PMS-RUST may strengthen PMS-OS implementation-path claims.
It does not complete PMS-OS.
```

### 8.14 PMS-RUST Is Not PMS-CPU

PMS-CPU is the virtual CPU/ISA architecture.

It requires:

```text
CPU state
register model
instruction set
decode semantics
execution semantics
trap semantics
memory model
privilege model
ordering model
commit semantics
ISA tests
```

PMS-RUST operator execution can support this path.

But:

```text
operator enum + deterministic stepping
≠ full PMS-CPU
```

Correct statement:

```text
PMS-RUST provides operator-kernel evidence that can support future
PMS-CPU implementation.
```

Specific boundary:

```text
PMS-RUST chi_exit
    bounded runtime boundary-exit evidence

PMS-CPU ISO_EXIT
    architecture-level ISA boundary-exit instruction
```

The first may support the path to the second.

It does not complete it.

### 8.15 PMS-RUST Is Not Full PMSL Compiler

PMSL/PMS-IR architecture includes:

```text
source language
syntax
type/effect system
IR
lowering
diagnostics
runtime profiles
stdlib/API profile
compiler analysis
trace mapping
```

PMS-RUST may implement:

```text
builder APIs
script syntax
opcode buffers
REPL commands
basic diagnostics
validation
execution
```

Boundary:

```text
PMS-IR builder or script runner
≠ complete PMSL compiler.
```

Correct statement:

```text
PMS-RUST strengthens PMSL/PMS-IR implementation-path claims where it
builds, validates, executes, and traces bounded operator programs.
```

AI proposal boundary:

```text
AI may propose PMS-IR or opcode programs.

Host validates.

Kernel executes only accepted artifacts.

AI output is not PMSL semantics, compiler authority, verifier authority,
verification evidence, or trusted executable code.
```

### 8.16 Classical Embedding Does Not Equal Classical Equivalence

PMS-STACK can express many classical frameworks.

Examples:

```text
POSIX-like process models
capability systems
microkernels
monolithic kernels
virtual machines
actor models
event loops
distributed protocols
leader election
state-machine replication
CRDT-like merge profiles
```

But expressibility is not equivalence.

Correct boundary:

```text
PMS-STACK can embed or project classical structures.
It does not claim every classical system automatically satisfies PMS-STACK
policy, trace, commit, or evidence discipline.
```

For PMS-RUST:

```text
a demo resembling classical behavior strengthens only the declared
operator-mapping claim.
```

Portability is not equivalence.

### 8.17 Classical Boundary Invariants

```text
CB1: PMS-STACK is structurally continuous with classical OS and VM ideas

CB2: PMS-STACK generalizes classical mechanisms through Δ–Ψ operator structure

CB3: classical embedding does not equal implementation equivalence

CB4: PMS-RUST is not merely another VM

CB5: PMS-RUST is not full PMS-OS

CB6: PMS-RUST is not full PMS-CPU

CB7: PMS-RUST is not full PMSL compiler

CB8: host-service behavior is not automatically PMS operator execution

CB9: VM-like execution behavior must be claim-typed as bounded artifact evidence

CB10: POSIX-like or filesystem-like demos do not equal complete OS support

CB11: classical comparison strengthens reader orientation, not PMS Base validation

CB12: artifact evidence strengthens implementation-layer claims and does not
      function as PMS Base validation

CB13: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline;
      PMS-CPU ISO_EXIT remains the architecture-level instruction target

CB14: runtime dialect alignment is tracked migration evidence, not completed
      PMS 1.3 migration

CB15: tests check, traces record, validators accept/reject, and gates discipline;
      none of these validate PMS Base
```

### 8.18 Architectural Consequence

The consequence is:

```text
PMS-STACK is not outside the history of OS and VM design. It is a
structurally stricter specification of the semantic obligations those
systems already partially express: context, authority, boundary, policy,
ordering, absence, trap, commit, and audit.
```

PMS-RUST belongs inside this boundary as:

```text
bounded executable evidence spine
```

not as:

```text
finished OS
finished CPU
finished compiler
generic VM
PMS Base authority
```

This section therefore protects the strongest possible reading of PMS-RUST:

```text
PMS-RUST is important precisely because it is not inflated.
It is an executable artifact that can be mapped layer-by-layer to
PMS-STACK architecture, with traceable evidence and explicit limits.
```

---

## 9. Evidence Types: Trace, Fixture, Validator, Simulator, REPL

PMS-RUST relates to PMS-STACK through evidence types.

An evidence type is a bounded artifact form that can support a typed implementation claim.

The central claim is:

```text
PMS-RUST evidence is valid when each artifact type states what STACK
claim it supports, what executable or inspectable behavior it exposes,
what validation or trace relation it provides, and what it does not
establish.
```

Claim type:

```text
IMPLEMENTATION-ARTIFACT EVIDENCE-TYPE CLAIM
```

Boundary:

```text
Evidence types do not all carry the same force.

A trace is not a proof.

A fixture is not a theory.

A validator is not PMS Base.

A REPL is not PMSL.

A simulator is not automatically a full CPU, OS, or distributed runtime.

Each evidence type strengthens a specific implementation-artifact claim
under a declared profile.
```

Validation in this document means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean:

```text
PMS Base validation
proof
external validation
semantic finality
```

### 9.1 Evidence-Type Discipline

PMS-RUST evidence must be read through the pattern:

```text
artifact
→ evidence type
→ supported STACK claim
→ profile
→ limitation
```

Canonical form:

```text
Evidence = (
    artifact,
    evidence_type,
    supported_claim,
    runtime_profile,
    validation_scope,
    trace_scope?,
    fixture_scope?,
    limitation
)
```

This prevents evidence inflation.

Correct:

```text
This JSONL trace supports the claim that this bounded operator program
executed under this deterministic runtime profile.
```

Incorrect:

```text
This trace proves PMS.
```

Evidence-type discipline also prevents roadmap inflation:

```text
roadmap ≠ implemented evidence

documented_slice ≠ executable evidence

implemented_slice requires code, test, trace, fixture, validator, or gate
evidence for bounded scope
```

### 9.2 Trace Evidence

Trace evidence is serialized execution evidence.

A trace records what the artifact did under declared conditions.

A concrete PMS-RUST execution produces:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Under active runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible PMS-RUST executions under a declared profile is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

and under policy:

```text
Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

JSONL output records observed `trace_rust(...)` values.

It does not by itself enumerate `Trace_rust(...)`.

Trace evidence may include:

```text
operator event
runtime order
frame state
role/capability state
policy decision
boundary/isolation event
commit event
diagnostic
host-service event
AI proposal boundary event
```

Generic trace event:

```text
TraceEvent = (
    event_id,
    order,
    operator?,
    event_kind,
    frame?,
    role?,
    policy?,
    boundary?,
    commit_ref?,
    result,
    runtime_profile,
    meta
)
```

PMS-RUST trace evidence supports claims such as:

```text
bounded operator execution occurred

events were emitted in deterministic order

commit points were externally inspectable

validation or runtime denial became visible

host-service behavior remained distinguishable from kernel execution

AI proposals did not execute without host-side acceptance
```

Trace evidence does not support:

```text
PMS Base validation

complete PMS-STACK implementation

proof of all runtime behavior

proof that all relevant behavior was captured

universal security

full audit sufficiency
```

Trace rule:

```text
traceability strengthens inspectability.
It does not create truth.
```

### 9.3 JSONL Trace / Audit Output

JSONL is a useful trace format because it is:

```text
line-oriented
diffable
machine-readable
fixture-friendly
CI-friendly
audit-friendly
```

JSONL trace evidence is valuable for:

```text
golden trace comparison
regression testing
event-format stability
artifact review
debugging
acceptance gates
audit-surface inspection
```

Recommended evidence statement:

```text
JSONL trace output supports bounded traceability and regression claims
for declared runtime executions.
```

Boundary:

```text
JSONL output does not prove full semantic adequacy.
It serializes observed artifact behavior under a profile.
```

JSONL trace discipline:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

### 9.4 Fixture Evidence

A fixture is a reproducible input/output expectation.

Fixtures may include:

```text
.pms scripts
expected validation failures
expected runtime traces
expected JSONL lines
expected diagnostic text
expected AI bridge rejection
expected vFS event stream
expected golden output
expected chi_exit rejection
expected sealed-isolation behavior
```

Fixture evidence supports:

```text
reproducibility
regression control
acceptance-gate stability
negative-case discipline
documented behavior under examples
```

Fixture evidence does not support:

```text
universal correctness

coverage of all possible inputs

PMS Base validation

complete semantic implementation
```

Fixture rule:

```text
fixtures stabilize known cases.
They do not exhaust the space of cases.
```

### 9.5 Golden Fixture Evidence

Golden fixtures are stronger than informal demos because they define expected behavior.

A golden fixture should declare:

```text
input
profile
expected validation result
expected execution result
expected trace
expected rejection path if invalid
claim supported
limitation
```

Golden fixture object:

```text
GoldenFixture = (
    fixture_id,
    input_artifact,
    runtime_profile,
    expected_result,
    expected_trace?,
    expected_diagnostic?,
    acceptance_rule,
    limitation
)
```

Golden fixtures support:

```text
format stability
trace stability
validation stability
runtime regression checks
documented executable examples
```

Boundary:

```text
golden fixture success is bounded reproducibility evidence.
It is not proof of PMS truth or full implementation adequacy.
```

### 9.6 Validator Evidence

Validator evidence shows that an artifact checks declared rules.

Validator types:

```text
model validator
operator adjacency validator
stateful validator
profile validator
trace-schema validator
fixture validator
AI proposal validator
host-boundary validator
boundary-exit validator
```

PMS-RUST validator evidence may support:

```text
runtime-adjacent model checking

operator dependency checking

stateful pre-execution rejection

fail-closed behavior

diagnostic clarity

invalid-script rejection

AI proposal containment

unbalanced chi_exit rejection
```

Validator object:

```text
ValidatorEvidence = (
    validator_id,
    rule_set,
    input_scope,
    accepted_cases,
    rejected_cases,
    diagnostics,
    limitation
)
```

Validator evidence does not support:

```text
external adequacy of the rules

truth of PMS Base

full formal verification

complete coverage of all runtime states
```

Validator rule:

```text
a validator enforces declared constraints.
It does not justify those constraints as base truth.
```

### 9.7 Model-Validation Evidence

Model-validation evidence is especially important because PMS-RUST may load and use PMS.yaml or related model data.

It supports:

```text
operator name normalization

dependency-table lookup

adjacency validation

diagnostic reporting

runtime/model alignment checks
```

Correct claim:

```text
PMS-RUST can use model-reference data to constrain bounded runtime programs.
```

Incorrect claim:

```text
PMS-RUST proves PMS.yaml or PMS Base.
```

Model-reference rule:

```text
machine-readable model data supports implementation alignment.
It does not replace the theory source of truth.
```

PMS Base remains the source of operator identity.

PMS.yaml and related model data may support implementation alignment, validation, diagnostics, and release discipline.

They do not become the base theory.

### 9.8 Stateful Validation Evidence

Stateful validation is stronger than adjacency validation because it checks runtime-sensitive constraints.

It may check:

```text
active frame required

sealed frame behavior

commit after seal forbidden where declared

isolation enter/exit discipline

stateful preconditions for Σ

runtime boundary constraints

execution-after-finalization constraints

unbalanced boundary exit
```

Stateful validator evidence supports:

```text
bounded invariant enforcement

runtime-state-aware rejection

pre-execution safety discipline

negative fixture strength
```

Boundary:

```text
stateful validation strengthens bounded runtime claims.
It does not equal full formal verification.
```

Boundary-exit validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

### 9.9 Boundary-Exit Evidence

Boundary-exit evidence concerns the relationship between PMS-RUST `chi_exit` and PMS-CPU `ISO_EXIT`.

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

They correspond at the boundary-exit concept level.

They are not the same claim layer.

Evidence may include:

```text
valid boundary-entry fixture
valid chi_exit fixture
unbalanced chi_exit rejection fixture
sealed-isolation fixture
boundary-exit trace event
stateful validator rejection
golden test for boundary closure
```

Supported claim:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile.
```

Boundary:

```text
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.

PMS-RUST chi_exit does not redefine PMS Base Χ.

PMS-RUST chi_exit does not validate PMS Base.
```

At PMS Base level:

```text
Χ = Distance
```

At PMS-RUST artifact level:

```text
Chi / Χ is an implementation-layer boundary or isolation projection.
```

### 9.10 Simulator Evidence

Simulator evidence comes from executing architecture profiles under controlled conditions.

Simulator evidence types:

```text
PMS-UM simulator trace
PMS-CPU simulator trace
hybrid UM/CPU trace comparison
deterministic simulator run
nondeterministic branch exploration
scenario injection run
symbolic path report
replay from checkpoint
```

PMS-RUST v0.1 should not be inflated into a complete simulator unless it explicitly implements the corresponding simulator profile.

Current relation:

```text
PMS-RUST v0.1 provides bounded deterministic execution evidence.
```

Future relation:

```text
PMS-RUST or later artifacts may implement PMS-UM, PMS-CPU, hybrid,
distributed, or symbolic simulator profiles.
```

Simulator evidence supports:

```text
execution under declared machine profile

trace emission

scenario replay

profile-specific conformance

future cross-layer comparison
```

Simulator evidence does not support:

```text
all possible machine behavior

complete CPU/OS/language correctness

Base validation

external deployment safety
```

### 9.11 REPL Evidence

REPL evidence is interactive tooling evidence.

It shows that users or tests can:

```text
construct programs
inspect buffers
run programs
trigger validation
observe traces
dump JSONL
exercise script behavior
interact with bounded service surfaces
```

REPL evidence supports:

```text
developer-surface claims

tooling usability claims

interactive execution claims

diagnostic visibility claims

script/REPL parity claims

manual exploration of bounded runtime behavior
```

REPL evidence does not support:

```text
complete PMSL compiler

complete PMS-OS shell

complete runtime correctness

proof of usability across all users

PMS Base validation
```

REPL rule:

```text
interactive executability strengthens tooling evidence.
It does not enlarge the architecture claim beyond the implemented profile.
```

### 9.12 Script Evidence

Script evidence is REPL-adjacent but more reproducible.

A script fixture can be used for:

```text
CI execution
golden testing
negative cases
documentation examples
trace comparison
demo replay
```

Script evidence object:

```text
ScriptEvidence = (
    script_file,
    expected_validation,
    expected_execution,
    expected_trace,
    profile,
    limitation
)
```

Script evidence supports:

```text
repeatable artifact behavior

operator-program authoring

bounded runtime execution

trace generation

validation failure documentation
```

Boundary:

```text
script support is not full language support unless the language/compiler
profile is implemented and declared.
```

### 9.13 vFS / Host-Service Evidence

PMS-RUST may include bounded vFS or host-service behavior.

This evidence supports:

```text
host-service surface

runtime/service boundary

file-like operations under declared profile

traceable host interaction

separation of kernel timeline and host command surface
```

It does not support:

```text
full PMS filesystem

full PMS-OS

complete POSIX compatibility

kernel-level storage architecture completion
```

Host-service rule:

```text
host service supports PMS execution.
It is not automatically PMS operator execution.
```

If a host service changes PMS-visible state, the mapping must declare:

```text
operator relation
authority
policy
boundary
commit
trace
limitation
```

### 9.14 AI Bridge Evidence

AI bridge evidence concerns the trust boundary around AI-assisted proposals.

It supports claims such as:

```text
AI output is parsed as proposal

host canonicalizes and maps

unknown or malformed output fails closed

kernel executes only accepted opcode programs

AI does not receive runtime authority

AI does not validate PMS Base
```

AI bridge evidence does not support:

```text
trusted AI execution

autonomous PMS reasoning

AI as validator authority

AI as verifier authority

AI as compiler authority

AI as policy authority

AI-generated proof

AI as verification evidence

PMSL semantics

PMS Base validation
```

AI bridge rule:

```text
AI proposes.
Host validates.
Kernel executes only accepted programs.
```

More precise artifact boundary:

```text
AI output is not trusted executable code.
AI output is not compiler authority.
AI output is not verifier authority.
AI output is not verification evidence.
AI output is not PMS Base evidence.
```

### 9.15 Acceptance-Gate Evidence

Acceptance-gate evidence reports whether defined artifact gates pass.

Gate evidence may include:

```text
format check
lint check
test suite
golden fixture check
trace comparison
validation rejection check
script-run check
AI bridge boundary check
boundary-exit check
event format check
```

Acceptance gates support:

```text
release discipline

artifact quality

regression control

bounded reproducibility

evidence-spine stability
```

Acceptance gates do not support:

```text
external validation of PMS

complete correctness

proof of semantic adequacy

finality of PMS Base
```

Gate rule:

```text
passing gates raises artifact confidence.
It does not change the claim layer.
```

### 9.16 Documentation Evidence

Documentation is an evidence type when it records:

```text
scope
architecture
non-goals
boundary conditions
usage
gate definitions
event formats
roadmap
fixtures
trust boundaries
```

Documentation supports:

```text
inspectability

source accounting

claim discipline

artifact review

future implementation planning
```

Documentation does not support:

```text
implementation by assertion

proof by README

evidence without code, fixture, trace, or test where those are required
```

Documentation rule:

```text
documentation makes claims inspectable.
It does not replace artifact evidence.
```

### 9.17 Evidence-Type Matrix

| Evidence type | Supports | Does not support |
| ------------- | -------- | ---------------- |
| Trace | observed execution under profile | proof of all behavior |
| JSONL output | serialized audit/trace surface | semantic finality |
| Fixture | reproducible case | exhaustive coverage |
| Golden fixture | regression stability | universal correctness |
| Validator | enforcement of declared rules | truth of rules as PMS Base |
| Stateful validator | bounded runtime invariant checks | full formal verification |
| Boundary-exit fixture | active-context exit discipline | PMS-CPU completion |
| Simulator | profile execution / replay | complete architecture implementation |
| REPL | interactive tooling surface | full language or OS |
| Script | reproducible tool execution | full PMSL compiler |
| vFS / host service | bounded service surface | full PMS filesystem/OS |
| AI bridge | proposal boundary discipline | trusted AI execution |
| Acceptance gate | release/artifact discipline | external validation |
| Documentation | inspectable source relation | implementation by itself |

### 9.18 Evidence Strength Levels

Evidence may be graded:

```text
E0: named in architecture
E1: documented as planned
E2: represented in code/data
E3: validator exists
E4: executable behavior exists
E5: trace output exists
E6: fixture/golden test exists
E7: acceptance gate enforces it
E8: independently reproduced or externally reviewed under declared protocol
```

PMS-RUST v0.1 primarily supports E2–E7 for its bounded runtime/toolchain scope.

External validation would require additional protocol and independent evaluation.

Evidence strength rule:

```text
higher evidence level strengthens an implementation-artifact claim.

It does not change the claim into PMS Base validation.
```

### 9.19 Evidence-Type Invariants

```text
ET1: every evidence type states supported claim and limitation

ET2: trace evidence records observed behavior under profile

ET3: fixture evidence stabilizes known cases without claiming exhaustion

ET4: validator evidence enforces declared rules without validating PMS Base

ET5: simulator evidence is profile-bound

ET6: REPL evidence is tooling evidence

ET7: script evidence is reproducibility evidence

ET8: host-service evidence is boundary evidence unless mapped into operator
     execution

ET9: AI bridge evidence is trust-boundary evidence, not AI authority

ET10: acceptance-gate evidence strengthens artifact quality claims

ET11: documentation evidence makes claims inspectable but does not implement them

ET12: no evidence type functions as PMS Base validation

ET13: validation means profile/gate acceptance or rejection, not PMS Base
      validation, proof, external validation, or semantic finality

ET14: trace_rust(...) denotes one observed PMS-RUST execution; Trace_rust(...)
      denotes a declared possible-execution set

ET15: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline;
      PMS-CPU ISO_EXIT remains the architecture-level instruction target

ET16: AI output is not compiler authority, verifier authority, verification
      evidence, PMSL semantics, trusted executable code, or PMS Base evidence
```

### 9.20 Architectural Consequence

The consequence is:

```text
PMS-RUST becomes architecturally legible through evidence types.
```

It is not just a code repository.

It is a structured evidence surface:

```text
traces
fixtures
validators
deterministic runs
REPL/script tooling
host-service boundaries
AI proposal gates
boundary-exit fixtures
acceptance gates
documentation
```

Each evidence type strengthens a precise implementation-artifact claim.

None becomes PMS Base authority.

---

## 10. What PMS-RUST May Strengthen

PMS-RUST may strengthen implementation-layer and artifact-layer claims.

The central claim is:

```text
PMS-RUST may strengthen PMS-STACK implementation-artifact claims where it
provides bounded executable, validated, traceable, fixture-backed, and
documented evidence for selected operator-grounded structures.
```

Claim type:

```text
BOUNDED IMPLEMENTATION-ARTIFACT STRENGTHENING CLAIM
```

Boundary:

```text
The word “strengthen” is important.

PMS-RUST does not replace PMS-STACK.

It does not define PMS Base.

It does not validate PMS Base.

It does not complete PMS-STACK.

It strengthens the path from architecture to executable artifact.
```

### 10.1 Implementation Feasibility

PMS-RUST may strengthen the claim that selected PMS-STACK structures are implementable.

It shows that bounded forms of the architecture can become:

```text
Rust crates
operator enums
opcode buffers
validators
runtime state
execution steps
events
traces
fixtures
REPL commands
scripts
docs
acceptance gates
```

Supported claim:

```text
Selected PMS-STACK structures can be represented and executed as bounded
software artifacts.
```

Boundary:

```text
this is implementation feasibility evidence, not PMS Base validation.
```

### 10.2 Operator Representation

PMS-RUST may strengthen operator-representation claims.

Evidence may include:

```text
operator enum
runtime opcode names
model keys
runtime aliases
event labels
script syntax
trace serialization
```

Supported claim:

```text
The Δ–Ψ operator vocabulary can be represented in a bounded runtime
dialect and surfaced through execution artifacts.
```

Boundary:

```text
operator representation does not define or validate the base operators.
```

Runtime dialect alignment is a tracked migration boundary.

A runtime command, alias, or opcode name may evidence implementation alignment work.

It does not by itself complete PMS 1.3 semantic migration.

### 10.3 Runtime Execution

PMS-RUST may strengthen executable-runtime claims.

Evidence may include:

```text
deterministic kernel stepping

opcode program execution

runtime guards

frame/boundary state

commit/seal behavior

event emission
```

Supported claim:

```text
Bounded operator programs can execute deterministically under a declared
runtime profile.
```

Boundary:

```text
deterministic runtime execution does not equal complete PMS-UM, PMS-CPU,
PMS-OS, PMSL compiler, or distributed runtime.
```

Trace form:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

The corresponding execution set is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

A recorded JSONL trace supports observed execution evidence.

It does not enumerate the whole set.

### 10.4 Model Validation

PMS-RUST may strengthen model-validation claims.

Evidence may include:

```text
PMS.yaml loading

operator-name normalization

dependency-table lookup

adjacency validation

diagnostics for invalid transitions
```

Supported claim:

```text
Machine-readable model data can constrain runtime-adjacent operator
programs.
```

Boundary:

```text
model validation is implementation alignment, not PMS Base proof.
```

Validation means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean PMS Base validation, proof, external validation, or semantic finality.

### 10.5 Stateful Invariant Enforcement

PMS-RUST may strengthen bounded invariant-enforcement claims.

Evidence may include:

```text
frame precondition checks

post-commit/seal checks

isolation enter/exit discipline

stateful rejection of invalid programs

fail-closed behavior

unbalanced chi_exit rejection
```

Supported claim:

```text
Selected runtime invariants can be enforced before or during bounded
execution.
```

Boundary:

```text
stateful validation is not full formal verification.
```

Boundary-exit validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

### 10.6 Boundary-Exit Discipline

PMS-RUST may strengthen boundary-exit claims.

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Supported claim:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
where active boundary contexts, valid exit, unbalanced-exit rejection,
sealed-isolation behavior, trace evidence, and negative fixtures are
declared.
```

Boundary:

```text
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.

PMS-RUST chi_exit does not redefine PMS Base Χ.

PMS-RUST chi_exit does not validate PMS Base.
```

At PMS Base level:

```text
Χ = Distance
```

At PMS-RUST artifact level:

```text
Chi / Χ is an implementation-layer boundary or isolation projection.
```

### 10.7 Traceability and Audit Surface

PMS-RUST may strengthen traceability claims.

Evidence may include:

```text
KernelEvent records

JSONL trace/audit output

stable event formats

event metadata

commit records

fixture-comparable traces

boundary-exit trace records
```

Supported claim:

```text
Bounded runtime behavior can be serialized into inspectable trace artifacts.
```

Boundary:

```text
traceability is not proof and not complete audit sufficiency.
```

Trace discipline:

```text
trace_rust(...) records observed behavior.
Trace_rust(...) describes the declared possible-execution set under profile.
```

### 10.8 Golden-Test and Regression Discipline

PMS-RUST may strengthen regression-discipline claims.

Evidence may include:

```text
valid demo fixtures

invalid demo fixtures

golden trace comparison

script tests

event-format tests

validation tests

AI bridge tests

chi_exit / sealed-isolation negative tests
```

Supported claim:

```text
Selected PMS-STACK artifact behavior can be stabilized through fixtures
and acceptance gates.
```

Boundary:

```text
test success does not establish universal correctness.
```

Correct vocabulary:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

### 10.9 Developer Surface

PMS-RUST may strengthen developer-tooling claims.

Evidence may include:

```text
REPL

script runner

show buffer

dump JSONL

validation UX

model inspection commands

demo scripts
```

Supported claim:

```text
PMS-STACK-style operator programs can be authored, inspected, validated,
executed, and traced through developer-facing tooling.
```

Boundary:

```text
developer tooling does not equal full PMSL, PMS-OS shell, or complete
runtime environment.
```

### 10.10 PMS-IR / Builder Path

PMS-RUST may strengthen PMS-IR path claims.

Evidence may include:

```text
PmsBuilder

opcode buffer

read-only program inspection

transactional buffer drain on run

idempotent entity construction

script-to-opcode mapping where implemented
```

Supported claim:

```text
A bounded IR/builder layer can construct canonical operator programs for
runtime execution.
```

Boundary:

```text
builder or script support is not a complete PMSL compiler.
```

AI may propose PMS-IR or opcode programs.

AI output is not PMSL semantics, compiler authority, verifier authority, verification evidence, trusted executable code, or PMS Base evidence.

### 10.11 Host-Service Boundary

PMS-RUST may strengthen host-boundary claims.

Evidence may include:

```text
vFS service primitives

hostcall tests

script-mode rejection of unsupported host commands

trace separation between runtime and host service

explicit service surface
```

Supported claim:

```text
Host-facing services can be bounded, documented, tested, and separated
from kernel operator execution.
```

Boundary:

```text
host services do not equal full PMS filesystem, OS, or kernel semantics.
```

Host service supports PMS execution.

It is not automatically PMS operator execution.

### 10.12 AI Proposal Boundary

PMS-RUST may strengthen AI-boundary claims.

Evidence may include:

```text
strict AI envelopes

task-specific parsing

compile proposal mapping

analysis proposal handling

malformed output rejection

host-side validation before execution
```

Supported claim:

```text
AI can be used as a proposal layer without becoming trusted executable
authority.
```

Boundary:

```text
AI proposal support does not establish trusted AI execution, PMS Base
validation, autonomous PMS reasoning, compiler authority, verifier
authority, verification evidence, or PMSL semantics.
```

Correct rule:

```text
AI proposes.
Host validates.
Kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 10.13 Claim Discipline

PMS-RUST may strengthen claim discipline itself.

It forces questions such as:

```text
what is implemented?

what is validated under declared artifact profile?

what is traced?

what is fixture-backed?

what is host tooling?

what is operator execution?

what remains architecture-only?

what is future work?

what does the artifact not establish?
```

Supported claim:

```text
Executable artifacts can sharpen PMS-STACK claim boundaries by making
implementation status inspectable.
```

Boundary:

```text
better claim discipline is not external validation.
```

### 10.14 PMS-STACK Roadmap Precision

PMS-RUST may strengthen roadmap precision.

It can show the next direct implementation targets:

```text
PMSL parser/compiler prototype
PMS-CPU/ISA simulator prototype
OS/process/capability layer
distributed PMS profile
file-service expansion
stronger event formats
stronger acceptance gates
PMS 1.3 migration work
boundary-exit fixtures
```

Supported claim:

```text
PMS-STACK implementation can proceed through artifact-backed slices.
```

Boundary:

```text
roadmap clarity does not mean roadmap completion.
```

Roadmap discipline:

```text
roadmap ≠ implemented evidence

documented_slice ≠ executable evidence

implemented_slice requires code, test, trace, fixture, validator, or gate
evidence for bounded scope
```

### 10.15 Architecture Feedback

PMS-RUST may strengthen PMS-STACK architecture by exerting implementation pressure.

It can reveal:

```text
ambiguous operator mappings

missing diagnostics

underspecified event formats

boundary confusion

validation-order issues

runtime dialect deviations

host/tooling ambiguity

trace-schema needs

fixture gaps

chi_exit / ISO_EXIT mapping needs
```

Supported claim:

```text
Executable implementation pressure can refine PMS-STACK specification
quality.
```

Boundary:

```text
implementation pressure refines architecture.
It does not decide PMS Base truth.
```

### 10.16 Strengthening Matrix

| PMS-RUST evidence | May strengthen |
| ----------------- | -------------- |
| deterministic kernel | bounded executable runtime claim |
| operator enum / opcodes | operator representation claim |
| model validation | model-reference alignment claim |
| stateful validation | bounded invariant enforcement claim |
| chi_exit / sealed-isolation fixture | runtime boundary-exit discipline claim |
| JSONL traces | traceability / audit-surface claim |
| golden fixtures | regression / acceptance-gate claim |
| REPL/script tooling | developer-surface claim |
| PmsBuilder / buffer | PMS-IR construction-path claim |
| vFS service | bounded host-service claim |
| AI bridge | proposal-boundary claim |
| docs / roadmap | source-accounting and future-work clarity |
| acceptance gates | artifact quality and release discipline |

### 10.17 What “Strengthen” Means

“Strengthen” means:

```text
increase executable support for a typed implementation claim.
```

It does not mean:

```text
prove
validate base
complete stack
settle theory
replace architecture
create external warrant
```

Formal pattern:

```text
Evidence E strengthens claim C
iff
    E is relevant to C
    ∧ E is inspectable
    ∧ E has declared scope
    ∧ E has declared limitation
    ∧ C remains at the correct claim layer.
```

### 10.18 PMS-RUST Strengthening Invariants

```text
S1: PMS-RUST may strengthen implementation claims

S2: PMS-RUST may strengthen artifact claims

S3: PMS-RUST may strengthen roadmap precision

S4: PMS-RUST may strengthen traceability claims

S5: PMS-RUST may strengthen validator and fixture claims

S6: PMS-RUST may strengthen bounded runtime feasibility claims

S7: PMS-RUST may strengthen PMS-STACK specification through implementation
    pressure

S8: PMS-RUST may strengthen AI-boundary claims where AI remains proposal-only

S9: PMS-RUST may strengthen PMS-IR path claims where builder/script/opcode
    evidence exists

S10: PMS-RUST may strengthen host-service boundary claims where service
     behavior is separated and traced

S11: every strengthened claim remains scope-bound

S12: strengthened implementation claims do not become PMS Base claims

S13: validation means artifact-profile acceptance or rejection, not PMS Base
     validation, proof, external validation, or semantic finality

S14: trace_rust(...) denotes observed execution; Trace_rust(...) denotes the
     declared possible-execution set under profile

S15: PMS-RUST chi_exit may strengthen bounded runtime isolation-exit discipline;
     it does not complete PMS-CPU ISO_EXIT, redefine PMS Base Χ, or validate
     PMS Base

S16: AI output is not compiler authority, verifier authority, verification
     evidence, PMSL semantics, trusted executable code, runtime policy
     authority, or PMS Base evidence
```

### 10.19 Architectural Consequence

The consequence is:

```text
PMS-RUST materially strengthens PMS-STACK as an implementation-layer
architecture because it gives selected architecture claims executable,
validated, traceable, fixture-backed, and tool-visible form.
```

Its significance is real.

Its boundary is equally real.

```text
PMS-RUST changes the status of selected implementation-artifact claims.
It does not change the status of PMS Base.
```

---

## 11. What PMS-RUST Does Not Establish

PMS-RUST has a strong role precisely because its non-claims are explicit.

The central boundary claim is:

```text
PMS-RUST does not establish PMS Base validation, complete PMS-STACK
implementation, full PMS-OS, full PMS-CPU/ISA, full PMSL compiler,
distributed PMS runtime, universal security, full formal verification,
trusted AI execution, external adequacy of PMS, or completed PMS 1.3
semantic migration.
```

Claim type:

```text
IMPLEMENTATION-ARTIFACT NON-ESTABLISHMENT / CLAIM-BOUNDARY CLAIM
```

Boundary:

```text
This boundary does not weaken PMS-RUST.

It protects the exact claim it can strongly make:

bounded executable PMS-STACK Evidence Spine v0.1.
```

Validation in this document means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean:

```text
PMS Base validation
proof
external validation
semantic finality
```

### 11.1 PMS-RUST Does Not Validate PMS Base

PMS Base is the source of operator identity and theoretical grammar.

PMS-RUST is an implementation artifact.

Correct:

```text
PMS-RUST can support implementation-layer evidence.
```

Incorrect:

```text
PMS-RUST validates PMS Base.
```

Reason:

```text
implementation shows bounded executable realization under technical
constraints.

It does not establish PMS as final, complete, empirically adequate,
uniquely ordered, or epistemically privileged.
```

PMS-RUST may strengthen implementation-artifact claims.

It does not validate PMS Base.

### 11.2 PMS-RUST Does Not Define PMS Base

PMS-RUST may contain:

```text
operator enums
runtime aliases
model keys
PMS.yaml loading
diagnostics
runtime names
trace labels
script commands
REPL commands
```

These do not define PMS Base.

Correct:

```text
runtime naming should align with PMS Base and PMS-STACK mappings.
```

Incorrect:

```text
the Rust enum is the operator theory.
```

Boundary:

```text
code represents selected theory structures.
It does not become the theory source of truth.
```

PMS Base remains the source of operator identity.

PMS.yaml and repository model data may support implementation alignment, validation, diagnostics, and release discipline.

They do not replace the base theory.

### 11.3 PMS-RUST Does Not Complete PMS-STACK

PMS-STACK is a complete architecture specification across many layers.

PMS-RUST v0.1 is a bounded evidence spine.

It does not complete:

```text
PMS-UM simulator
PMS-CPU / ISA
PMS-OS
PMSL compiler
full runtime security
full networking
distributed PMS
cluster boot
distributed commit
formal verification system
```

Correct:

```text
PMS-RUST implements selected slices that support PMS-STACK realization.
```

Incorrect:

```text
PMS-RUST is the whole PMS-STACK.
```

PMS-RUST strengthens the implementation path.

It does not replace the architecture specification.

### 11.4 PMS-RUST Does Not Implement Full PMS-OS

Full PMS-OS requires:

```text
kernel model
process model
thread model
scheduler
syscall layer
memory model
filesystem
IPC
driver model
resource accounting
security model
audit
boot
```

PMS-RUST may include bounded runtime, vFS, validation, trace, and tooling slices.

Boundary:

```text
bounded service or vFS behavior
≠ full PMS-OS.
```

Correct:

```text
PMS-RUST may strengthen PMS-OS implementation-path claims.
```

But bounded host-service evidence does not become PMS-OS completion.

### 11.5 PMS-RUST Does Not Implement Full PMS-CPU / ISA

Full PMS-CPU requires:

```text
CPU state
register model
memory model
instruction set
binary encoding
decoder
fetch-decode-execute loop
trap/interrupt model
privilege model
memory consistency profiles
ISA fixture suite
```

PMS-RUST may support operator execution and future CPU work.

Boundary:

```text
opcode runtime execution
≠ full PMS-CPU / ISA.
```

Correct:

```text
PMS-RUST may support the PMS-CPU path by providing operator execution,
validation, traces, and fixtures.
```

Specific boundary-exit mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

They correspond at the boundary-exit concern level.

They are not the same claim layer.

### 11.6 PMS-RUST Does Not Implement Full PMSL Compiler

Full PMSL compiler requires:

```text
source language
parser
type/effect system
IR
lowering
diagnostics
compiler analyses
runtime profile mapping
standard library / API profile
trace mapping
```

PMS-RUST may include:

```text
builder APIs
scripts
REPL commands
opcode buffers
validation
execution
```

Boundary:

```text
PmsBuilder or script runner
≠ full PMSL compiler.
```

AI may propose PMS-IR or opcode programs.

AI output is not:

```text
PMSL semantics
compiler authority
verifier authority
verification evidence
trusted executable code
PMS Base evidence
```

### 11.7 PMS-RUST Does Not Implement Distributed PMS Runtime

Distributed PMS runtime would require:

```text
node frames
network transport
routing
PPS messages
cross-node isolation
distributed commit
quorum/global policy
cluster boot
distributed audit
partition handling
upgrade/reintegration
```

PMS-RUST v0.1 may provide future roadmap direction, fixtures, or bounded mock slices where implemented.

Boundary:

```text
distributed PMS in roadmap
≠ distributed PMS implemented.
```

Correct:

```text
PMS-RUST-style artifacts may strengthen future distributed
implementation-artifact claims when mock node frames, PPS fixtures,
quorum/no-quorum fixtures, distributed audit chains, cross-node
isolation fixtures, JSONL traces, and golden tests exist under declared
profiles.
```

They do not complete distributed PMS-STACK.

### 11.8 PMS-RUST Does Not Prove Tests as Truth

Passing tests support artifact quality.

They do not prove PMS.

Tests may show:

```text
this case passes

this invalid case rejects

this trace matches expected output

this gate currently passes under declared harness
```

Tests do not show:

```text
all cases pass

all semantics are complete

PMS Base is true

architecture is externally validated

runtime is universally safe
```

Test rule:

```text
tests are bounded evidence.
They are not proof of theoretical adequacy.
```

Correct vocabulary:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

### 11.9 PMS-RUST Does Not Convert Traces into Proof

Traces are valuable.

They show recorded behavior.

They do not prove total behavior.

A concrete PMS-RUST execution produces:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Under active runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible PMS-RUST executions under a declared profile is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

and under policy:

```text
Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

Trace boundary:

```text
trace_rust(...) records one observed execution under profile and input.

Trace_rust(...) denotes the declared possible-execution set under profile.
```

Not:

```text
trace T proves all PMS executions.
```

A trace may support:

```text
debugging
audit surface
fixture comparison
regression evidence
execution inspection
```

It does not support:

```text
complete correctness
external validation
base finality
universal audit sufficiency
```

### 11.10 PMS-RUST Does Not Make AI Trusted

AI may propose.

AI may analyze.

AI may assist.

AI may not become trusted runtime authority.

Not established:

```text
AI output is executable code

AI output is valid PMS

AI output is a proof

AI output is policy authority

AI output is compiler authority

AI output is verifier authority

AI output is verification evidence

AI output validates PMS Base

AI output is autonomous PMS reasoning
```

Correct boundary:

```text
AI proposal is host-mediated, parsed, canonicalized, mapped, validated,
and accepted or rejected before execution.
```

Standard rule:

```text
AI proposes.
Host validates.
Kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 11.11 PMS-RUST Does Not Complete PMS 1.3 Migration

PMS-RUST v0.1 may use a runtime dialect with known version boundaries.

Important:

```text
PMS Base 1.3:
    Χ = Distance

Rust v0.1:
    Χ / Chi = isolation / boundary scope
```

This is acceptable only when named.

Boundary:

```text
runtime dialect alignment
≠ complete PMS 1.3 semantic migration.
```

Correct:

```text
PMS-RUST v0.1 uses an implementation-layer Χ projection.
PMS 1.3 alignment remains a tracked migration boundary.
```

A runtime command, alias, opcode name, validator rule, or trace event may evidence implementation alignment work.

It does not by itself complete PMS 1.3 semantic migration.

### 11.12 PMS-RUST Does Not Redefine Χ

PMS Base defines:

```text
Χ = Distance
```

PMS-RUST v0.1 may project Χ/Chi as:

```text
isolation
boundary scope
runtime containment
visibility control
entry/exit discipline
sealed context behavior
```

This is an implementation-layer projection.

It is not a PMS Base redefinition.

Boundary-exit rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline.

It does not redefine PMS Base Χ.

### 11.13 PMS-RUST Does Not Complete ISO_EXIT

PMS-CPU `ISO_EXIT` is an architecture-level virtual ISA instruction target.

PMS-RUST `chi_exit` is artifact/runtime behavior.

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level boundary-exit instruction

PMS-RUST chi_exit
    bounded runtime boundary-exit evidence
```

Correct:

```text
PMS-RUST chi_exit may support the implementation path toward ISO_EXIT by
evidencing active-context exit discipline, unbalanced-exit rejection,
sealed-isolation behavior, and traceable boundary closure.
```

Incorrect:

```text
PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

Boundary:

```text
chi_exit evidence strengthens a bounded artifact claim.
It does not complete the PMS-CPU ISA.
```

### 11.14 PMS-RUST Does Not Replace PMS-STACK

PMS-STACK is the architecture specification.

PMS-RUST is an artifact within the realization path.

Boundary:

```text
artifact
≠ architecture
```

PMS-RUST may reveal:

```text
what is executable now

what is validated now

what is traced now

what is fixture-backed now

what is still missing

what the next artifact gates should be
```

But PMS-STACK remains the layer map and specification authority for implementation architecture.

### 11.15 PMS-RUST Does Not Replace External Validation

External validation would require:

```text
independent application
rival-sensitive comparison
empirical protocol where relevant
formal verification where claimed
deployment evidence where claimed
review by external parties
clear success/failure criteria
```

PMS-RUST supplies internal artifact evidence.

Boundary:

```text
internal executable evidence
≠ external validation.
```

This distinction is essential for trustworthiness.

### 11.16 PMS-RUST Does Not Establish Universal Security

PMS-RUST may include:

```text
validation
fail-closed paths
boundary checks
AI containment
trace output
negative fixtures
unbalanced-exit rejection
sealed-isolation checks
```

These strengthen bounded security-architecture claims.

They do not establish:

```text
universal runtime security

absence of vulnerabilities

complete policy adequacy

complete sandboxing

complete audit sufficiency

secure deployment in all environments
```

Security claim must remain profile-specific:

```text
security property S holds for artifact/profile/evidence E under stated
conditions.
```

### 11.17 PMS-RUST Does Not Establish Full Formal Verification

Validators and tests are not full formal verification.

Formal verification would require:

```text
formal model
property statement
proof method
checked proof or verified model result
assumptions
scope
limitations
```

PMS-RUST may prepare the ground for formal verification by producing:

```text
operator traces
stateful constraints
fixtures
model data
deterministic runs
boundary-exit negative cases
```

Boundary:

```text
verification-adjacent artifacts are not full verification.
```

Correct claim form:

```text
Property P holds over artifact A under model/profile M and assumptions B.
```

Not:

```text
PMS-RUST proves PMS.
```

### 11.18 Non-Establishment Matrix

| PMS-RUST artifact | Does not establish |
| ----------------- | ------------------ |
| deterministic kernel | full PMS-UM / PMS-CPU / PMS-OS |
| operator enum | PMS Base definition |
| model validator | PMS Base truth |
| stateful validator | full formal verification |
| JSONL trace | proof of all behavior |
| golden fixtures | universal correctness |
| REPL/script runner | full PMSL compiler |
| vFS service | full filesystem / OS |
| AI bridge | trusted AI execution |
| `chi_exit` fixture | PMS-CPU ISO_EXIT completion |
| boundary/isolation runtime dialect | PMS Base Χ redefinition |
| acceptance gates | external validation |
| roadmap | implemented future work |
| documentation | implementation by assertion |

### 11.19 Boundary Invariants

```text
NE1: PMS-RUST does not validate PMS Base

NE2: PMS-RUST does not define PMS Base

NE3: PMS-RUST does not complete PMS-STACK

NE4: PMS-RUST does not implement full PMS-OS

NE5: PMS-RUST does not implement full PMS-CPU / ISA

NE6: PMS-RUST does not implement full PMSL compiler

NE7: PMS-RUST does not implement full distributed PMS runtime

NE8: tests do not prove PMS truth

NE9: traces do not prove all behavior

NE10: validators do not establish external adequacy of the rules

NE11: AI output is not trusted executable code

NE12: PMS-RUST v0.1 does not complete PMS 1.3 migration

NE13: artifact evidence does not replace PMS-STACK architecture

NE14: artifact evidence does not replace external validation

NE15: every PMS-RUST claim remains implementation/artifact-layer unless a
      different claim type is independently justified

NE16: validation means profile/gate acceptance or rejection, not PMS Base
      validation, proof, external validation, or semantic finality

NE17: trace_rust(...) denotes observed execution; Trace_rust(...) denotes
      declared possible execution under profile

NE18: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline;
      PMS-CPU ISO_EXIT remains the architecture-level boundary-exit
      instruction target

NE19: PMS-RUST chi_exit does not redefine PMS Base Χ and does not validate
      PMS Base

NE20: AI output is not compiler authority, verifier authority, verification
      evidence, PMSL semantics, runtime policy authority, or PMS Base evidence
```

### 11.20 Architectural Consequence

The consequence is:

```text
PMS-RUST is strongest when it is not inflated.
```

Its correct status is:

```text
bounded executable PMS-STACK Evidence Spine v0.1
```

This means:

```text
strong implementation evidence
clear artifact gates
inspectable traces
reproducible fixtures
runtime validation
developer tooling
AI proposal containment
boundary-exit discipline where implemented
explicit roadmap pressure
```

and also:

```text
no PMS Base validation
no full PMS-STACK completion
no full PMS-OS
no full PMS-CPU
no full PMSL compiler
no full distributed runtime
no proof by tests
no proof by traces
no trusted AI execution
no completed PMS 1.3 migration
no Base Χ redefinition
```

This boundary preserves the architecture:

```text
PMS-STACK specifies the implementation-layer system.
PMS-RUST evidences selected executable slices.
PMS Base remains the source of operator identity.
```

---

## 12. Phase-2 Mapping to PMS-RUST Repository

Phase 2 maps PMS-STACK architecture claims to the concrete PMS-RUST repository.

The central claim is:

```text
Phase-2 PMS-RUST mapping is valid when repository artifacts are related
to specific PMS-STACK architecture claims through executable slices,
validation rules, traces, fixtures, acceptance gates, roadmap status,
and explicit limitations.
```

Claim type:

```text
IMPLEMENTATION-ARTIFACT REPOSITORY MAPPING CLAIM
```

Boundary:

```text
Phase 2 does not ask:

Does PMS-RUST prove PMS?

It asks:

Which PMS-STACK claim does this repository artifact support?
What evidence does it provide?
What runtime profile does it belong to?
What acceptance gate checks it?
What limitation prevents overclaim?
```

Phase-2 mapping turns repository structure into typed evidence.

It does not turn repository structure into PMS Base authority.

### 12.1 Phase-2 Source Set

Phase 2 uses the PMS-RUST repository source set.

Primary sources:

```text
README.md
pms-docs/ARCHITECTURE.md
pms-docs/ROADMAP.md
pms-docs/KEY_WORLDS.md
pms-docs/ACCEPTANCE_GATES.md
pms-docs/EVENT_FORMAT.md
pms-docs/AI_BRIDGE.md
pms-docs/DEMO.md
pms-docs/golden/
pms-demos/
tests/
crate source files
```

Crate-level artifacts:

```text
pms-kernel
pms-model
pms-model-data
pms-ir
pms-repl
pms-ai-bridge
pms-examples
```

The source set is implementation evidence.

It is not a PMS Base source.

### 12.2 Mapping Rule

Each repository artifact must be mapped through this rule:

```text
RepoArtifact
→ STACK layer
→ supported claim
→ evidence type
→ acceptance gate
→ limitation
```

Canonical form:

```text
RepoMapping = (
    repo_artifact,
    stack_layer,
    supported_claim,
    evidence_type,
    runtime_profile,
    gate_or_fixture,
    limitation
)
```

This prevents repository structure from being treated as theory structure.

Validation means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean PMS Base validation, proof, external validation, or semantic finality.

### 12.3 Repository-to-STACK Matrix

| PMS-RUST artifact | STACK layer | Supported claim | Evidence type | Boundary |
| ----------------- | ----------- | --------------- | ------------- | -------- |
| `pms-kernel` | runtime / operator execution | bounded deterministic operator execution | code, tests, traces | not full PMS-UM/CPU/OS |
| `pms-model` | model-reference alignment | model data can constrain runtime programs | validator | not PMS Base proof |
| `pms-model-data/PMS.yaml` | model data | machine-readable reference data | schema/data | not source-of-truth replacement |
| `pms-ir` | PMS-IR path | builder can construct opcode programs | IR convenience layer | not full PMSL compiler |
| `pms-repl` | tooling/runtime surface | scripts and REPL can author/run/trace programs | REPL/script evidence | not PMSL or OS shell |
| `pms-ai-bridge` | AI trust boundary | AI can propose without becoming trusted executor | bridge tests/docs | not AI validation |
| `pms-docs/ARCHITECTURE.md` | implementation architecture | repository design is inspectable | documentation | not ontology/proof |
| `pms-docs/ROADMAP.md` | future work | Release+ work is scoped | roadmap | not implemented evidence |
| `pms-docs/KEY_WORLDS.md` | terminology boundary | dialect/world-language distinctions are explicit | glossary/boundary doc | not theory authority |
| `pms-docs/ACCEPTANCE_GATES.md` | gate discipline | release checks are declared | gate doc | not external validation |
| `pms-docs/EVENT_FORMAT.md` | trace/audit | event format is documented | event schema | not proof by trace |
| `pms-docs/golden/` | regression evidence | known scripts/traces/specs are reproducible | golden fixtures | not exhaustive coverage |
| `pms-demos/` | demo execution | documented runnable cases exist | scripts/demos | not general adequacy |
| `tests/` | quality gate | selected cases are checked | tests | not universal correctness |

### 12.4 Boundary-Exit Mapping in Phase 2

Phase 2 must explicitly track the boundary-exit relation.

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction target

PMS-RUST chi_exit
    bounded runtime/artifact evidence target
```

Repository artifacts may support this mapping through:

```text
opcode or command representation
stateful validator checks
active-boundary context tracking
unbalanced-exit rejection
sealed-isolation fixtures
boundary-exit trace events
golden tests
documentation
```

Mapping rule:

```text
PMS-RUST chi_exit supports PMS-CPU ISO_EXIT only as bounded
implementation-path evidence.

It does not complete PMS-CPU.
It does not redefine PMS Base Χ.
It does not validate PMS Base.
```

Phase-2 table entry:

| STACK claim | PMS-RUST slice | Validation | Fixture / trace | Status label | Limitation |
| ----------- | -------------- | ---------- | --------------- | ------------ | ---------- |
| boundary exit requires active context | `chi_exit` runtime slice where implemented | stateful boundary validation | valid-exit / unbalanced-exit fixtures | fixture_backed / validator_backed where present | not PMS-CPU ISO_EXIT completion |

### 12.5 `README.md` Mapping

`README.md` functions as the repository’s top-level status and boundary document.

It supports:

```text
release identity
artifact purpose
execution path
crate overview
non-goals
quick-start path
gate summary
roadmap pointer
resource positioning
```

Supported STACK claim:

```text
PMS-RUST is a bounded executable PMS-STACK Evidence Spine v0.1.
```

Evidence type:

```text
documentation
source accounting
scope declaration
non-goal declaration
release status
```

Boundary:

```text
README documentation makes artifact status inspectable.
It does not implement the artifact by itself and does not validate PMS Base.
```

### 12.6 `pms-kernel` Mapping

`pms-kernel` is the core executable slice.

It maps to:

```text
PMS-STACK runtime
operator execution
bounded kernel semantics
trace emission
stateful validation
commit/boundary behavior
```

Supported claims:

```text
bounded operator programs can execute deterministically

runtime events can be emitted

frame/isolation state can be tracked

runtime guards can reject invalid state

commit/seal behavior can be represented

model adjacency and stateful validation can be integrated

boundary-exit discipline can be evidenced where chi_exit-style behavior exists
```

Evidence types:

```text
Rust code
unit tests
runtime state
KernelEvent records
JSONL traces
negative tests
boundary-exit fixtures where present
```

Boundary:

```text
pms-kernel is not full PMS-OS, PMS-CPU, PMS-UM simulator, PMSL compiler,
or distributed runtime.
```

### 12.7 `pms-model` Mapping

`pms-model` maps to machine-readable model-reference alignment.

Supported claims:

```text
operator names can be normalized

dependency tables can be loaded

adjacency validation can be checked

invalid transitions can produce diagnostics
```

Evidence types:

```text
model loader
validation queries
diagnostic output
tests
```

Boundary:

```text
model validation supports runtime alignment.
It does not validate PMS Base and does not replace PMS Base as source of
operator identity.
```

### 12.8 `pms-model-data/PMS.yaml` Mapping

`pms-model-data/PMS.yaml` maps to model data used by the artifact.

Supported claims:

```text
runtime validation can be grounded in machine-readable model data

operator identifiers and dependencies can be referenced by tooling

validation diagnostics can report model-derived expectations
```

Evidence type:

```text
machine-readable model reference
```

Boundary:

```text
PMS.yaml as repository data is not PMS Base proof.
Machine-readability supports inspection and validation; it does not
create theoretical warrant.
```

### 12.9 `pms-ir` Mapping

`pms-ir` maps to the PMS-IR construction path.

Supported claims:

```text
operator programs can be built programmatically

PmsBuilder can construct bounded opcode buffers

programs can be inspected before execution

runtime execution can consume constructed programs
```

Evidence types:

```text
builder API
opcode buffer
tests
script/REPL integration
```

Boundary:

```text
PmsBuilder is an IR convenience layer.
It is not the PMS grammar and not a complete PMSL compiler.
```

AI may propose PMS-IR or opcode programs.

Host validation remains authoritative.

### 12.10 `pms-repl` Mapping

`pms-repl` maps to developer-facing runtime tooling.

Supported claims:

```text
operator programs can be authored interactively

.pms scripts can be run

buffers can be inspected

validation can be toggled or invoked

JSONL traces can be dumped

vFS and AI bridge surfaces can be reached under declared commands
```

Evidence types:

```text
REPL
script runner
tests
demos
JSONL outputs
developer commands
```

Boundary:

```text
REPL/script execution shows toolchain behavior under constraints.
It is not PMSL completeness, OS shell completeness, or PMS Base validation.
```

### 12.11 `pms-ai-bridge` Mapping

`pms-ai-bridge` maps to AI proposal-boundary architecture.

Supported claims:

```text
AI requests and responses can be typed

AI tasks can be whitelisted

AI output can be parsed as proposal

malformed or unknown output can fail closed

host-side mapping and validation retain execution authority

kernel executes only accepted opcode programs
```

Evidence types:

```text
typed envelopes
bridge code
tests
AI docs
rejection fixtures
```

Boundary:

```text
AI proposes.
Host validates.
Kernel executes accepted programs.

AI output is not trusted executable code, not policy authority, not
compiler authority, not verifier authority, not verification evidence,
not proof, and not PMS Base evidence.
```

### 12.12 `pms-docs/ARCHITECTURE.md` Mapping

`ARCHITECTURE.md` maps to repository implementation architecture.

Supported claims:

```text
the repository design is inspectable

crate roles are documented

runtime/toolchain boundaries are documented

v0.1 dialect boundaries can be stated

chi_exit / ISO_EXIT mapping can be documented where relevant
```

Evidence type:

```text
architecture documentation
```

Boundary:

```text
architecture documentation describes artifact design.
It does not establish ontology, PMS Base truth, or implementation by itself.
```

### 12.13 `pms-docs/ROADMAP.md` Mapping

`ROADMAP.md` maps to future implementation pressure.

Supported claims:

```text
Release+ work is identified

future PMS-STACK slices are scoped

known gaps can be tracked

PMS 1.3 migration work can be named

future CPU/ISA, PMSL, OS, and distributed slices can be planned

future ISO_EXIT-level work can be distinguished from chi_exit artifact evidence
```

Evidence type:

```text
roadmap documentation
```

Boundary:

```text
roadmap status is not implementation status.
Planned work is not executable evidence.
```

### 12.14 `pms-docs/KEY_WORLDS.md` Mapping

`KEY_WORLDS.md` maps to terminology and dialect boundary discipline.

Supported claims:

```text
runtime vocabulary can be distinguished from PMS Base vocabulary

world/layer language can reduce confusion

implementation dialect boundaries can be named

repository readers can be oriented across stack layers

Chi-as-runtime-boundary can be distinguished from PMS Base Χ-as-Distance
```

Evidence type:

```text
glossary
terminology boundary documentation
```

Boundary:

```text
terminology prevents drift.
It does not decide theory.
```

### 12.15 `pms-docs/ACCEPTANCE_GATES.md` Mapping

`ACCEPTANCE_GATES.md` maps to artifact gate discipline.

Supported claims:

```text
release-quality checks are declared

format/test/lint/demo/golden gates are documented

artifact status can be checked against repeatable gates

boundary-exit and AI-boundary gates can be named where implemented
```

Evidence type:

```text
gate documentation
acceptance discipline
```

Boundary:

```text
gates support artifact quality claims.
They do not create external warrant for PMS Base.
```

### 12.16 `pms-docs/EVENT_FORMAT.md` Mapping

`EVENT_FORMAT.md` maps to trace/audit inspectability.

Supported claims:

```text
runtime events have a documented structure

JSONL trace/audit output can be parsed

golden traces can be compared

event metadata can be inspected

boundary-exit events can be represented where implemented
```

Evidence type:

```text
event schema
trace format documentation
```

Boundary:

```text
event format makes runtime behavior inspectable.
Inspection is not self-validation.
```

Trace convention:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
Trace_rust(artifact, profile) ⊆ L_PMS
```

Recorded JSONL events support observed-run evidence.

They do not enumerate all possible executions.

### 12.17 `pms-docs/AI_BRIDGE.md` Mapping

`AI_BRIDGE.md` maps to the AI trust boundary.

Supported claims:

```text
AI interaction is documented as proposal-only

host enforcement is part of the bridge

fail-closed behavior is expected

task/result-shape boundaries are explicit
```

Evidence type:

```text
trust-boundary documentation
```

Boundary:

```text
AI bridge documentation supports boundary discipline.
It does not make AI output valid, trusted, proof-bearing, compiler
authoritative, verifier authoritative, or PMS Base evidence.
```

### 12.18 `pms-docs/golden/` Mapping

The golden directory maps to reproducibility and regression evidence.

It may include:

```text
golden scripts
golden JSONL event fixtures
golden AI specs
golden tests
boundary-exit fixtures where implemented
```

Supported claims:

```text
known executions can be reproduced

known event formats can be compared

known validation/rejection behavior can be stabilized

AI proposal boundaries can be fixture-tested

chi_exit / sealed-isolation behavior can be fixture-tested where present
```

Evidence types:

```text
golden fixtures
golden scripts
expected event outputs
expected AI specs
test runner
```

Boundary:

```text
golden fixtures cover known cases.
They do not exhaust semantic space.
```

### 12.19 `pms-demos/` Mapping

`pms-demos/` maps to demonstration scripts.

Supported claims:

```text
a valid trace demo can run

model-invalid transition can be rejected

stateful invalid behavior can be rejected

script-mode host boundary can be demonstrated

boundary-exit behavior can be demonstrated where implemented
```

Evidence types:

```text
demo scripts
expected outcomes
manual or CI execution
```

Boundary:

```text
demos show bounded reproducibility paths.
They do not establish general adequacy.
```

### 12.20 `tests/` Mapping

`tests/` maps to regression and artifact-quality evidence.

Supported claims:

```text
selected behavior is checked

invalid behavior is rejected

event formatting is stable where tested

model validation is covered where tested

REPL/script features are covered where tested

AI bridge failure modes are covered where tested

boundary-exit failure modes are covered where tested
```

Evidence types:

```text
unit tests
integration tests
script fixtures
golden tests
```

Boundary:

```text
passing tests strengthen artifact claims.
They do not prove PMS, validate PMS Base, or establish universal correctness.
```

### 12.21 Phase-2 Claim Table

Phase-2 mapping should use a table like this:

| STACK claim | PMS-RUST slice | Validation | Fixture / trace | Status label | Limitation |
| ----------- | -------------- | ---------- | --------------- | ------------ | ---------- |
| operator programs executable | `pms-kernel` | stateful/model validation | JSONL trace | implemented_slice | bounded runtime |
| operator model checkable | `pms-model` + `PMS.yaml` | adjacency validation | invalid demos | implemented_slice | not PMS Base proof |
| IR can build programs | `pms-ir` | builder tests | script/REPL programs | implemented_slice | not full PMSL |
| tooling can expose runtime | `pms-repl` | REPL/script tests | dumps/golden | implemented_slice | not OS shell |
| trace/audit inspectable | `EVENT_FORMAT.md` + kernel events | schema tests | JSONL | implemented_slice | not proof |
| AI proposal bounded | `pms-ai-bridge` | envelope/task checks | AI golden specs | implemented_slice | not trusted AI |
| vFS service surfaced | `pms-kernel`/`pms-repl` service tests | host-service tests | FS event JSONL | bounded slice | not full FS/OS |
| boundary exit requires active context | `chi_exit` runtime slice where implemented | stateful boundary validation | valid-exit / unbalanced-exit fixtures | fixture_backed / validator_backed where present | not PMS-CPU ISO_EXIT completion |
| CPU/ISA path | roadmap | none yet / future | future fixtures | roadmap | not implemented |
| PMSL compiler path | roadmap | none yet / future | future fixtures | roadmap | not implemented |
| distributed PMS path | roadmap | none yet / future | future fixtures | roadmap | not implemented |
| PMS 1.3 migration | roadmap / boundary docs | future work | future gates | tracked boundary | not complete |

### 12.22 Status Labels

Use stable status labels.

```text
implemented_slice
    code + tests + trace/fixture evidence exist for bounded scope

documented_slice
    documented design exists, but executable evidence is limited or absent

fixture_backed
    reproducible fixture or golden output exists

validator_backed
    validation rule exists and rejects invalid cases

trace_backed
    event output exists and can be inspected

roadmap
    planned Release+ work, not implemented evidence

out_of_scope
    explicitly non-goal for current release

boundary
    named version/scope/claim distinction

tracked_boundary
    known migration or layer-alignment issue that is named and governed
```

Avoid ambiguous labels such as:

```text
done
proven
validated
complete
final
```

unless the exact object and claim type are specified.

Preferred vocabulary:

```text
implemented_slice
validator_backed
trace_backed
fixture_backed
documented_slice
roadmap
boundary
```

### 12.23 Phase-2 Mapping Workflow

The mapping workflow:

```text
1. Identify STACK claim.
2. Identify repo artifact.
3. Identify runtime profile.
4. Identify evidence type.
5. Identify validation rule.
6. Identify fixture or trace.
7. Identify acceptance gate.
8. Identify limitation.
9. Assign status label.
10. State what the artifact does not establish.
```

Example:

```text
STACK claim:
    operator execution is traceable.

Repo artifact:
    pms-kernel + EVENT_FORMAT.md + JSONL output.

Evidence type:
    deterministic runtime trace.

Gate:
    golden JSONL comparison.

Status:
    trace_backed implemented_slice.

Limitation:
    traceability does not prove all runtime behavior and does not validate
    PMS Base.
```

Boundary-exit example:

```text
STACK claim:
    boundary exit requires active boundary context.

Repo artifact:
    chi_exit runtime slice where implemented.

Evidence type:
    stateful validation + negative fixture.

Gate:
    unbalanced chi_exit rejects.

Status:
    validator_backed / fixture_backed where present.

Limitation:
    supports bounded runtime isolation-exit discipline; does not complete
    PMS-CPU ISO_EXIT, redefine PMS Base Χ, or validate PMS Base.
```

### 12.24 Phase-2 Output Format

Recommended Phase-2 output format:

```text
### Mapping: <STACK claim>

STACK claim:
    ...

Repository slice:
    ...

Evidence:
    ...

Gate:
    ...

Status:
    ...

Limitation:
    ...
```

Example:

```text
### Mapping: Model Validation

STACK claim:
    PMS operator programs can be checked against dependency structure.

Repository slice:
    pms-model + pms-model-data/PMS.yaml + pms-kernel validation path.

Evidence:
    adjacency validation, diagnostic failures, invalid demo scripts.

Gate:
    model-invalid fixtures reject expected transitions.

Status:
    validator_backed implemented_slice.

Limitation:
    model validation supports implementation alignment; it does not validate
    PMS Base.
```

### 12.25 Phase-2 Trace Convention

Phase-2 mappings that cite trace evidence should use the same notation.

Single observed run:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Single observed run under runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ
```

Declared possible execution set:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

Declared possible execution set under runtime policy:

```text
Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

Boundary:

```text
JSONL trace output records observed trace_rust(...) values.

It does not enumerate Trace_rust(...).
```

### 12.26 Phase-2 AI Boundary

Phase-2 mappings involving AI must use the standard boundary.

```text
AI proposes.
Host validates.
Kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI output is not:

```text
trusted executable code
compiler authority
verifier authority
verification evidence
runtime policy authority
PMSL semantics
PMS Base validation
```

AI evidence supports proposal-boundary discipline.

It does not support AI-as-authority claims.

### 12.27 Phase-2 Migration Boundary

Phase-2 must keep PMS 1.3 migration visible.

Important boundary:

```text
PMS Base 1.3:
    Χ = Distance

PMS-RUST v0.1:
    Chi / Χ may appear as isolation or boundary scope
```

Correct mapping:

```text
PMS-RUST v0.1 Chi behavior is an implementation-layer projection.

PMS Base Χ remains Distance.

PMS 1.3 migration remains a tracked boundary until completed by explicit
artifact, documentation, validator, fixture, and trace updates under
declared gates.
```

Runtime alias, opcode name, or command alignment is evidence of migration work.

It is not migration completion.

### 12.28 Phase-2 Mapping Invariants

```text
P2M1: every Phase-2 mapping starts from a PMS-STACK claim

P2M2: every mapping identifies a concrete PMS-RUST artifact

P2M3: every mapping states evidence type

P2M4: every mapping states runtime profile or repository layer

P2M5: every mapping states validation, trace, fixture, or gate where present

P2M6: every mapping distinguishes implemented_slice from roadmap

P2M7: every mapping distinguishes documentation from executable evidence

P2M8: every mapping states limitation

P2M9: every mapping avoids repo-as-validation drift

P2M10: every mapping preserves PMS Base / PMS-STACK / PMS-RUST layer discipline

P2M11: validation means artifact-profile acceptance or rejection, not PMS Base
       validation, proof, external validation, or semantic finality

P2M12: trace_rust(...) denotes observed execution; Trace_rust(...) denotes
       possible execution under declared profile

P2M13: PMS-RUST chi_exit evidence supports bounded runtime isolation-exit
       discipline; PMS-CPU ISO_EXIT remains the architecture-level target

P2M14: roadmap status is not implemented evidence

P2M15: AI output is not compiler authority, verifier authority, verification
       evidence, PMSL semantics, trusted executable code, or PMS Base evidence
```

### 12.29 Architectural Consequence

The consequence is:

```text
Phase-2 mapping turns PMS-RUST from a repository into a typed evidence map.
```

The repository becomes legible as:

```text
kernel evidence
model-validation evidence
IR construction evidence
REPL/script evidence
trace/event-format evidence
golden-fixture evidence
AI-boundary evidence
host-service evidence
boundary-exit evidence where implemented
roadmap pressure
claim-boundary documentation
```

This strengthens PMS-STACK implementation-artifact claims while preventing the repository from becoming PMS Base authority.

The final Phase-2 discipline is:

```text
repo artifact
→ STACK claim
→ evidence type
→ profile
→ gate
→ limitation
```

No repository artifact escapes this chain.

---

## 13. Claim Boundary

This document closes by fixing the claim boundary between PMS Base, PMS-STACK, PMS-RUST, artifacts, tests, traces, gates, documentation, AI/tooling, repository structure, and future work.

The central boundary claim is:

```text
PMS-RUST strengthens PMS-STACK implementation-artifact claims where it
provides bounded executable, validated, traceable, fixture-backed, and
documented evidence; it does not define PMS Base, validate PMS Base,
complete PMS-STACK, complete PMS 1.3 migration, or convert tests,
traces, gates, docs, roadmap, repository structure, or AI output into
proof.
```

Claim type:

```text
IMPLEMENTATION-ARTIFACT RELATION / FINAL CLAIM-BOUNDARY CLAIM
```

Boundary:

```text
This boundary is not defensive.

It is the condition that lets the implementation claim remain strong.
```

Validation in this document means:

```text
acceptance or rejection under a declared artifact profile, schema,
runtime model, validator, gate, fixture, or conformance rule.
```

It does not mean:

```text
PMS Base validation
proof
external validation
semantic finality
```

### 13.1 Layer Boundary

The layer relation is:

```text
PMS Base
    source of operator identity and PMS 1.3 grammar

PMS-STACK
    implementation-layer architecture specification

PMS-RUST
    bounded executable PMS-STACK Evidence Spine v0.1

pms-docs
    repository documentation, gates, event format, roadmap, boundaries

tests / fixtures / traces
    bounded artifact evidence

future roadmap
    planned implementation pressure

AI/tooling
    proposal, analysis, drafting, and inspection support under host-side
    validation
```

The authority relation is:

```text
PMS Base defines operators.

PMS-STACK projects operators into system architecture.

PMS-RUST implements bounded artifact slices.

Tests, traces, fixtures, and gates inspect artifact behavior.

Docs state scope and boundary.

Roadmap states future work.

AI proposes or assists under host-side validation.
```

No lower layer validates the base layer.

### 13.2 Correct Strong Claim

Correct:

```text
PMS-RUST is a bounded executable PMS-STACK Evidence Spine v0.1.
```

It demonstrates that selected PMS-STACK structures can be:

```text
represented
validated under declared artifact profiles
executed
traced
tested
documented
exposed through developer tooling
bounded by host/service/AI trust constraints
```

This is a strong claim.

It is also bounded.

### 13.3 Incorrect Inflated Claims

Incorrect:

```text
PMS-RUST validates PMS Base.

PMS-RUST proves PMS.

PMS-RUST completes PMS-STACK.

PMS-RUST is full PMS-OS.

PMS-RUST is PMS-CPU/ISA.

PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.

PMS-RUST is full PMSL compiler.

PMS-RUST implements distributed PMS.

PMS-RUST completes PMS 1.3 migration.

PMS-RUST redefines PMS Base Χ.

JSONL traces prove PMS.

Golden fixtures prove semantic completeness.

Acceptance gates create external warrant.

AI output is trusted executable PMS.

AI output is compiler authority.

AI output is verifier authority.

AI output is verification evidence.

Repository structure defines operator theory.

Documentation is implementation.

Roadmap is evidence.
```

These are layer errors.

### 13.4 Claim Type Table

| Claim object | Correct claim type | Boundary |
| ------------ | ------------------ | -------- |
| PMS Base | base/theory grammar | not proven by implementation |
| PMS-STACK | implementation-layer architecture claim | not PMS Base validation |
| PMS-RUST | implementation/artifact claim | bounded Evidence Spine |
| `pms-kernel` | executable runtime slice | not full OS/CPU/UM |
| `pms-model` | model-reference validation slice | not theory proof |
| `pms-ir` | IR construction convenience | not PMSL compiler |
| `pms-repl` | tooling/script execution slice | not OS shell/language completeness |
| `pms-ai-bridge` | AI proposal-boundary artifact | not trusted AI execution |
| `chi_exit` behavior | bounded runtime boundary-exit evidence | not PMS-CPU ISO_EXIT completion |
| JSONL trace | trace/audit surface | not proof |
| golden fixture | reproducibility/regression evidence | not exhaustive coverage |
| acceptance gate | artifact quality gate | not external validation |
| docs | scope and design documentation | not implementation by itself |
| roadmap | future work boundary | not implemented evidence |

### 13.5 Χ / Chi Boundary

This document must preserve the Χ boundary.

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK implementation layer:
    Χ projects as isolation, reachability control, boundary management,
    access separation, sandboxing, quarantine, and cross-frame separation

PMS-RUST v0.1:
    Chi / Χ appears as isolation / boundary scope in the runtime dialect
```

Correct statement:

```text
PMS-RUST v0.1 implements an implementation-layer Χ projection.
```

Incorrect statement:

```text
PMS-RUST v0.1 redefines PMS Base Χ.
```

This is a version/scope boundary.

It is not a contradiction when named.

It becomes a problem only if the runtime dialect is silently treated as PMS Base.

### 13.6 ChiExit / ISO_EXIT Boundary

PMS-RUST `chi_exit` and PMS-CPU `ISO_EXIT` must remain claim-layer distinct.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Shared validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Correct statement:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline.
```

Incorrect statements:

```text
PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.

PMS-RUST chi_exit redefines PMS Base Χ.

PMS-RUST chi_exit validates PMS Base.
```

Boundary:

```text
chi_exit strengthens bounded implementation-artifact claims.

ISO_EXIT remains the architecture-level PMS-CPU instruction target.

PMS Base Χ remains Distance.
```

### 13.7 Evidence Boundary

Evidence supports typed claims.

```text
code
tests
fixtures
traces
validators
REPL sessions
scripts
event formats
docs
gates
boundary-exit fixtures
AI proposal-boundary fixtures
```

may support:

```text
bounded executable feasibility
artifact quality
traceability
validation discipline
regression stability
developer-surface claims
host-boundary claims
AI-boundary claims
boundary-exit discipline
roadmap precision
```

They do not establish:

```text
PMS Base validation
universal correctness
complete implementation
external validation
final theory status
```

Evidence rule:

```text
evidence strengthens a typed implementation-artifact claim under declared
scope.

It does not change claim type.
```

### 13.8 Test and Gate Boundary

Tests and gates are important.

They can show:

```text
the workspace passes declared checks

selected valid cases run

selected invalid cases reject

event format is stable under fixtures

AI boundary tests pass

golden outputs match expected artifacts

unbalanced chi_exit rejects where the profile implements that gate

sealed-isolation behavior is checked where implemented
```

They cannot show:

```text
all possible cases are covered

the theory is true

the architecture is complete in code

the runtime is universally safe

the implementation is externally validated
```

Correct sentence:

```text
Passing gates strengthen artifact-quality and bounded-execution claims.
They do not function as PMS Base validation.
```

Preferred vocabulary:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

### 13.9 Trace Boundary

Traces are important.

They can show:

```text
what happened in a recorded run

which events were emitted

which commit points appeared

which validation path was taken

which runtime profile produced the output

which boundary or host-service event was recorded where implemented
```

A concrete PMS-RUST execution produces:

```text
trace_rust(artifact, profile, input) ∈ L_PMS
```

Under active runtime policy:

```text
trace_rust(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible PMS-RUST executions under a declared profile is:

```text
Trace_rust(artifact, profile) ⊆ L_PMS
```

and under policy:

```text
Trace_rust(artifact, profile) ⊆ L_PMS,Ψ
```

Trace boundary:

```text
JSONL trace output records observed trace_rust(...) values.

It does not enumerate Trace_rust(...).
```

Traces cannot show:

```text
all behavior
all missing behavior
all correctness
all audit sufficiency
theoretical adequacy
```

Correct sentence:

```text
Trace evidence makes execution inspectable.
It does not make inspection self-validating.
```

### 13.10 Documentation Boundary

Documentation is necessary.

It can show:

```text
scope
intent
architecture
usage
non-goals
gate definitions
event formats
roadmap
trust boundaries
PMS 1.3 migration boundaries
chi_exit / ISO_EXIT mapping
AI proposal boundaries
```

It cannot show:

```text
implementation without code

correctness without evidence

validation without protocol

future work as current status
```

Correct sentence:

```text
Documentation makes claims inspectable.
It does not implement them by assertion.
```

### 13.11 Roadmap Boundary

Roadmap material is valuable because it prevents hidden claim inflation.

It can state:

```text
planned PMSL parser/compiler prototype

planned PMS-CPU/ISA simulator prototype

planned OS/process/capability layer

planned distributed PMS

planned PMS 1.3 migration work

planned ISO_EXIT-level implementation work

planned stronger fixtures or gates
```

It cannot state:

```text
these are already implemented

these are already evidence-backed

these already complete PMS-STACK

these complete PMS 1.3 migration

these complete PMS-CPU ISO_EXIT
```

Correct sentence:

```text
Roadmap pressure identifies future implementation paths.
It is not executable artifact evidence until implemented, tested, traced,
and gated.
```

### 13.12 AI Boundary

AI may support PMS-RUST.

AI may:

```text
propose opcode programs

propose PMS-IR candidates

analyze traces

suggest scenarios

assist developer workflow

generate candidate scripts

summarize diagnostics

draft fixtures
```

AI may not:

```text
execute directly

grant authority

bypass validation

define PMS

define PMSL semantics

validate PMS Base

act as proof system

act as compiler authority

act as verifier authority

act as verification evidence

commit runtime state without host/kernel mediation
```

Correct sentence:

```text
AI proposes; host and kernel constraints decide what can execute.
```

Standard rule:

```text
AI proposes.
Host validates.
Kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 13.13 Implementation Boundary

Implementation is serious.

Implementation can show:

```text
the architecture has executable pressure

operator structures can be represented

selected runtime paths can execute

validation can reject invalid cases

traces can be emitted

fixtures can stabilize behavior

boundary-exit behavior can be checked where implemented

AI proposal containment can be tested where implemented
```

Implementation cannot show by itself:

```text
base truth

finality

external adequacy

complete coverage

rival superiority

universal correctness
```

Correct sentence:

```text
Implementation pressure strengthens the implementation layer.
It does not upgrade PMS Base.
```

### 13.14 External Validation Boundary

External validation would require additional work.

It may involve:

```text
independent reproduction

formal proof under declared model

external audit

rival-sensitive comparison

deployment study

empirical protocol

security review

third-party verification
```

PMS-RUST may prepare artifacts for such work.

It does not replace it.

Correct sentence:

```text
PMS-RUST can make external validation easier to design.
It is not itself external validation of PMS Base.
```

### 13.15 Phase-2 Repository Boundary

The PMS-RUST repository can be mapped into a typed evidence map.

Correct mapping form:

```text
repo artifact
→ STACK claim
→ evidence type
→ runtime profile
→ gate
→ limitation
```

Examples:

```text
pms-kernel
    → bounded runtime execution
    → code / tests / trace
    → deterministic profile
    → golden fixture or runtime test
    → not full OS/CPU/UM

pms-ai-bridge
    → AI proposal boundary
    → bridge tests / docs
    → AI_bridge profile
    → malformed-output rejection
    → not trusted AI execution

chi_exit runtime slice where implemented
    → boundary-exit discipline
    → stateful validation / negative fixture / trace
    → boundary_exit profile
    → unbalanced-exit rejection
    → not PMS-CPU ISO_EXIT completion
```

Repository structure is evidence only when mapped through claim, profile, gate, and limitation.

It is not theory authority.

### 13.16 Final Claim Form

The final claim form for `08_relation_to_pms_rust.md` is:

```text
PMS-STACK is the implementation-layer architecture specification.

PMS-RUST is a bounded executable artifact-backed Evidence Spine v0.1.

PMS-RUST strengthens selected PMS-STACK implementation-artifact claims
by providing code, validation, deterministic execution, JSONL traces,
fixtures, REPL/script tooling, vFS surface, docs, gates, boundary-exit
discipline where implemented, and AI proposal boundaries.

PMS-RUST does not define PMS Base, validate PMS Base, complete PMS-STACK,
complete PMS 1.3 migration, or establish full PMS-OS, PMS-CPU/ISA,
PMSL compiler, distributed runtime, universal security, formal proof,
external validation, trusted AI execution, or PMS-CPU ISO_EXIT completion.
```

### 13.17 Claim-Boundary Invariants

```text
CB1: PMS Base remains the source of operator identity

CB2: PMS-STACK remains the implementation-layer architecture specification

CB3: PMS-RUST remains a bounded executable implementation/artifact claim

CB4: PMS-RUST strengthens selected PMS-STACK implementation-artifact claims

CB5: PMS-RUST does not validate PMS Base

CB6: PMS-RUST does not define PMS Base

CB7: PMS-RUST does not complete PMS-STACK

CB8: PMS-RUST does not complete PMS 1.3 migration

CB9: PMS-RUST does not implement full PMS-OS

CB10: PMS-RUST does not implement full PMS-CPU/ISA

CB11: PMS-RUST does not implement full PMSL compiler

CB12: PMS-RUST does not implement full distributed PMS runtime

CB13: tests and gates strengthen artifact quality claims, not PMS Base claims

CB14: traces strengthen inspectability claims, not proof claims

CB15: docs make claims inspectable, not implemented by assertion

CB16: roadmap identifies future pressure, not current evidence

CB17: AI bridge supports proposal-boundary claims, not trusted AI execution

CB18: implementation pressure is not proof

CB19: executable artifact-backed partial realization is not PMS Base validation

CB20: every PMS-RUST claim must state artifact, supported claim, evidence type,
      profile, status, and limitation

CB21: validation means profile/gate acceptance or rejection, not PMS Base
      validation, proof, external validation, or semantic finality

CB22: trace_rust(...) denotes observed execution; Trace_rust(...) denotes a
      declared possible-execution set under profile

CB23: PMS Base 1.3 defines Χ as Distance

CB24: PMS-RUST v0.1 Chi / Χ behavior is an implementation-layer boundary or
      isolation projection, not a PMS Base redefinition

CB25: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline

CB26: PMS-CPU ISO_EXIT remains the architecture-level boundary-exit
      instruction target

CB27: PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT

CB28: AI output is not compiler authority, verifier authority, verification
      evidence, PMSL semantics, trusted executable code, runtime policy
      authority, or PMS Base evidence
```

### 13.18 Architectural Consequence

The consequence is:

```text
The PMS-STACK / PMS-RUST relation is strong because it is bounded.
```

PMS-STACK gives:

```text
architecture
layer map
operator projections
completeness conditions
extensibility conditions
classical-system boundary
simulation bridge
artifact gate logic
claim-type discipline
```

PMS-RUST gives:

```text
bounded executable evidence
deterministic runtime slice
model validation
stateful validation
REPL/script tooling
JSONL trace/audit
vFS service surface
golden fixtures
tests
documentation
acceptance gates
AI proposal boundary
boundary-exit evidence where implemented
roadmap pressure
```

The final relation is:

```text
PMS-STACK specifies.
PMS-RUST evidences.
PMS Base defines.
Tests inspect.
Traces record.
Gates discipline.
Docs boundary.
Roadmap pressures.
AI proposes.
Host validates.
Kernel executes accepted artifacts.
None of these lower layers validate PMS Base.
```

This completes `08_relation_to_pms_rust.md` as a precise relation document:

```text
strong architecture
strong artifact evidence
strict layer discipline
explicit non-claims
clear chi_exit / ISO_EXIT mapping
visible PMS 1.3 migration boundary
no repo-as-validation drift
```
