---
document_id: PMS-STACK-DOC-06
title: "Runtime Security and Governance"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "implementation-layer runtime-security / governance architecture claim"
pms_base_status: "source of Δ–Ψ operator identity"
stack_status: "cross-cutting runtime-security specification layer of PMS-STACK"
chi_status: "PMS Base 1.3 Χ = Distance; runtime security projects Χ as isolation, boundary, visibility, reachability, containment, namespace separation, quarantine, and trust-boundary control"
depends_on:
  - "01_architecture.md"
  - "03_pms_cpu.md"
  - "04_pms_os.md"
  - "05_pmsl_pms_ir.md"
links_forward_to:
  - "07_distributed_systems.md"
  - "08_relation_to_pms_rust.md"
  - "09_non_goals_and_claim_boundary.md"
---

# Runtime Security and Governance

PMS-STACK treats runtime security as operator structure.

Security is not a subsystem bolted onto computation after execution has already been defined. It is the runtime discipline by which identity, authority, isolation, policy, audit, trust anchors, resource governance, network trust, failure handling, compliance, quarantine, and lifecycle control are represented as Δ–Ψ-constrained transitions.

The central runtime-security claim is:

```text
Runtime security in PMS-STACK is valid when every security-relevant
transition is Δ-distinguished, Ω-authorized, □-framed, Χ-bounded as an
implementation-layer boundary projection, Θ-ordered, Φ-recontextualized
when needed, Σ-committed when stable, and Ψ-constrained by active
invariants and policies.
```

This is an implementation-layer runtime-security / governance architecture claim. It does not function as PMS Base validation. It defines how PMS-STACK projects the operator grammar into executable security, governance, policy, audit, trust-boundary, isolation, failure-response, and runtime-enforcement mechanisms.

Governance in this document means runtime governance: the operator-typed policy, audit, trust, escalation, quarantine, lifecycle, rollback, commit, and enforcement discipline of a computational system.

It does not mean moral judgment, legal authority, forensic omniscience, person ranking, social governance, clinical classification, or policy enforcement over humans as such.

Validation in this document means acceptance or rejection under a declared runtime-security schema, policy, hook, model, profile, artifact, trace schema, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

The assurance vocabulary is:

```text
tests check
traces record
validators accept or reject under profile
model checking checks stated properties under a model
proof artifacts prove stated properties under formal assumptions
external validation validates externally under an explicitly designed protocol
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

Runtime security projects Χ as boundary, isolation, visibility, reachability, containment, namespace separation, quarantine, trust-boundary control, and access separation.

Runtime-security projections of Χ do not redefine PMS Base Χ.

## 1. Security as Operator Structure

Security in PMS-STACK is structural.

It is not defined primarily as:

```text
access-control lists
permission bits
process labels
sandbox flags
network filters
audit logs
cryptographic keys
compliance reports
```

These may exist as implementation mechanisms. PMS-STACK defines the underlying security semantics in terms of operators:

```text
Δ — distinguish actor, action, object, context, credential, event
∇ — perform mutation, IO, transfer, allocation, execution
□ — locate the action inside a frame, scope, module, process, session
Λ — represent absent resources, missing events, timeouts, no-route, no-permission result profiles
Α — encode recurring security/governance patterns
Ω — assign role, capability, privilege, delegation, authorization
Θ — order execution, scheduling, audit sequence, expiry checks, event progression
Φ — recontextualize traps, policy denials, identity mappings, escalation, recovery
Χ — project Distance as isolation, boundary, visibility, reachability, containment
Σ — commit stable state, audit record, trust binding, revocation, policy update
Ψ — bind policies, invariants, compliance rules, governance constraints
```

Security is therefore not a separate layer that occasionally interrupts normal execution. It is the validity discipline of execution whenever the transition has security, governance, identity, isolation, trust, audit, lifecycle, or failure-response consequences.

### 1.1 Security Is Not an Add-On

In a conventional system, security is often distributed across:

```text
kernel checks
user/group permissions
capability tables
memory protection
process isolation
network ACLs
firewall rules
TLS configuration
audit systems
logging systems
policy engines
container runtimes
key stores
```

PMS-STACK unifies these under one structural reading:

```text
security event = operator-constrained transition
```

A filesystem write, for example, is not merely an IO call. It is a composite transition:

```text
Δ classify path and operation
Ω verify write authority
□ locate process/module/filesystem frame
Χ check namespace and boundary reachability as a runtime projection
Ψ evaluate policy
∇ perform or stage write
Σ commit visible or durable result
Θ order trace/audit event
Φ handle denial, IO trap, rollback, or recovery
```

A security architecture is valid when those obligations remain visible and enforceable.

### 1.2 Security-Relevant Transitions

The runtime-security layer governs transitions such as:

```text
identity creation
principal mapping
role assignment
capability grant/revocation
frame entry/exit
kernel entry/exit
module import/export
task spawn
IPC send/receive
filesystem read/write
network connect/listen/send/receive
FFI call
foreign callback
policy installation
policy update
resource allocation
audit commit
trust-anchor rotation
key use
session establishment
distributed commit
quarantine
rollback
halt
```

Each transition must be readable as an operator word.

Example:

```text
w_security =
    Δ_actor
    ; Ω_authorize
    ; □_context
    ; Χ_boundary_projection
    ; Ψ_policy
    ; ∇_action
    ; Σ_commit
```

If a transition cannot be represented this way, it is not yet a PMS-STACK security transition. It is an implementation hole or an unmodeled host behavior.

### 1.3 Security Operator Table

| Security concern | Operator structure |
| ---------------- | ------------------ |
| actor distinction | Δ |
| object/resource distinction | Δ |
| execution context | □ |
| principal identity | Δ + Ω + □ + Χ + Ψ + Σ |
| authority | Ω |
| capability | Ω |
| isolation | Χ projected from PMS Base Distance |
| visibility | Χ + □ |
| policy | Ψ |
| invariant | Ψ |
| scheduling fairness / rate limits | Θ + Ψ |
| timeout / no-resource / no-response | Λ |
| trap / violation / recovery | Φ |
| commit / audit / durable trust state | Σ |
| delegation | Φ + Ω + Σ |
| revocation | Ψ + Ω + Σ |
| quarantine | Χ + Ψ + Φ + Σ |
| compliance evidence | Θ + Σ + Ψ |
| trust-anchor interpretation | Φ + Ψ |
| key material containment | □ + Χ + Ω + Ψ |
| network trust | Δ + Φ + Ψ + Σ |
| distributed governance | Ω + Χ + Θ + Φ + Σ + Ψ |

This table is not a metaphor table. It is the operator contract for runtime-security implementation.

### 1.4 Security State

Runtime security state may be represented as:

```text
SecurityState = (
    principals,
    identities,
    roles,
    capabilities,
    frames,
    boundaries,
    policies,
    trust_anchors,
    key_frames,
    resource_accounts,
    audit_state,
    active_sessions,
    network_trust_state,
    quarantine_state,
    meta
)
```

where:

| Field | Operator role |
| ----- | ------------- |
| `principals` | Δ/Ω/Ψ actor identities |
| `identities` | Δ-created, Σ-bound identity objects |
| `roles` | Ω structural authority classes |
| `capabilities` | Ω action grants over domains |
| `frames` | □ execution/resource contexts |
| `boundaries` | Χ-projected isolation and reachability constraints |
| `policies` | Ψ active invariants and governance rules |
| `trust_anchors` | Φ/Ψ interpretation roots |
| `key_frames` | □/Χ-contained credential material |
| `resource_accounts` | Θ/Σ/Ψ usage and quota state |
| `audit_state` | Θ-ordered, Σ-committed evidence state |
| `active_sessions` | Δ/Φ/Σ mapped local or network principals |
| `quarantine_state` | Χ/Ψ/Φ containment responses |
| `meta` | timestamps, trace IDs, provenance, profile data |

Runtime security is valid when this state constrains execution rather than merely describing it after the fact.

### 1.5 Security Transition Form

A canonical security transition has the form:

```text
SecurityTransition =
    (
        actor,
        action,
        target,
        frame,
        role,
        capability,
        boundary,
        policy,
        ordering,
        result,
        commit,
        audit
    )
```

The corresponding operator sequence is:

```text
Δ(actor, action, target)
→ □(frame)
→ Ω(role, capability)
→ Χ(boundary_projection)
→ Ψ(policy)
→ Θ(order)
→ ∇(action)
→ Σ(commit)
```

with possible alternatives:

```text
Λ absence/no-resource/no-response
Φ trap/recontextualization/recovery
Χ quarantine/isolation tightening
Ψ deny/halt/escalate
Σ rollback/compensate/audit
```

The validity rule:

```text
valid_security_transition(t) iff
    distinguished(t.actor, t.action, t.target)
    ∧ framed(t.frame)
    ∧ authorized(t.role, t.capability, t.action)
    ∧ boundary_permits(t.boundary, t.actor, t.target)
    ∧ policy_allows(t.policy, t)
    ∧ ordered(t.ordering)
    ∧ commit_valid(t.commit)
```

This is a runtime-security validity predicate under a declared profile. It is not PMS Base validation.

### 1.6 Security Is Cross-Layer

Runtime security crosses PMS-STACK layers.

```text
PMS-CPU:
    privilege, traps, memory access, isolation primitives, policy checks

PMS-OS:
    kernel entry, syscalls, processes, frames, scheduling, IPC, drivers, resource accounting

PMSL/PMS-IR:
    type/effect/capability declarations, standard-library API profiles, FFI boundaries

Networking:
    remote principals, trust anchors, session policies, transport boundaries

Distributed systems:
    node identities, quorum policies, global commits, cluster trust

Tooling:
    audit traces, diagnostics, verification reports, golden fixtures, policy linting
```

The runtime-security document is therefore a cross-cutting architecture document. It does not replace `04_pms_os.md`, `05_pmsl_pms_ir.md`, or `07_distributed_systems.md`. It binds their security-relevant mechanisms into a shared governance and enforcement discipline.

### 1.7 Security vs. Runtime Governance

PMS-STACK treats security and governance as related but distinct.

```text
security
    constrains who may do what, where, when, and under which boundary.

runtime governance
    defines which policies, invariants, trust anchors, audit obligations,
    lifecycle rules, rollback rules, quarantine rules, escalation paths,
    and commit obligations bind the computational system.
```

Security is primarily expressed through:

```text
Ω
Χ
Ψ
Φ
Σ
```

Runtime governance is primarily expressed through:

```text
Ψ
Σ
Θ
Φ
Ω
```

Examples:

```text
Security:
    user process may not write kernel frame

Runtime governance:
    policy mutation requires kernel-governed frame and durable audit commit
```

The two meet at policy enforcement, lifecycle control, failure response, and audit.

Runtime governance is the Ψ-governed discipline by which a computational system controls policy lifecycle, enforcement decisions, audit obligations, trust interpretation, quarantine, escalation, rollback, and commit validity.

This is a systems-architecture claim.

It is not social governance, moral judgment, legal adjudication, person evaluation, clinical classification, forensic verdict, or authority over humans as such.

### 1.8 Security Planes

Runtime security can be understood through several planes.

#### Identity Plane

```text
Δ + Ω + □ + Χ + Ψ + Σ
```

Defines principals, identity lifecycle, credential mapping, delegation, revocation, and session binding.

#### Authority Plane

```text
Ω + Ψ
```

Defines roles, capabilities, privilege transitions, authorization predicates, and least-privilege surfaces.

#### Boundary Plane

```text
□ + Χ + Ψ
```

Defines frames, process isolation, module boundaries, host boundaries, network boundaries, container boundaries, driver/device boundaries, and quarantine.

#### Policy Plane

```text
Ψ over Δ–Σ
```

Defines what transitions are allowed, denied, transformed, audited, isolated, rolled back, or halted.

#### Audit Plane

```text
Θ + Σ + Ψ
```

Defines ordered evidence, committed audit records, compliance hooks, tamper-evident state, and trace correlation.

#### Trust Plane

```text
Φ + Ψ + Σ + Ω + Χ
```

Defines key interpretation, trust anchors, validation rules, rotation, revocation, and session establishment.

#### Failure Plane

```text
Λ + Φ + Χ + Σ + Ψ
```

Defines timeout, absence, policy denial, trap, rollback, quarantine, compensation, escalation, and halt behavior.

### 1.9 Attack and Misbehavior as Operator Words

PMS-STACK describes attacks and misbehavior as attempted operator words.

Example privilege escalation attempt:

```text
w_attack =
    Δ_target_role
    ; ∇_request_role(root)
    ; Ω_elevate
```

Example isolation leak attempt:

```text
w_attack =
    Δ_secret_object
    ; ∇_read(secret_object)
    ; Χ_bypass_attempt
```

Example policy-tampering attempt:

```text
w_attack =
    Δ_shadow_policy
    ; Ω_escalate?
    ; Ψ_redefine
```

These sequences describe attempted behavior, not successful execution.

Runtime security determines where the sequence becomes invalid:

```text
Ω denial
Χ boundary block
Ψ policy denial
Φ trap
Σ rollback
Χ quarantine
Σ audit commit
Ψ halt
```

This is the reason security scenarios are expressible as structured storyboards rather than informal threat narratives.

### 1.10 Security Outcomes

Security decisions may produce several outcomes.

```text
allow
deny
return absence
trap
rollback
compensate
quarantine
degrade
revoke capability
tighten boundary
audit
escalate
terminate
halt
```

Operator mapping:

| Outcome | Operator reading |
| ------- | ---------------- |
| allow | Ψ permits transition |
| deny | Ψ/Ω blocks transition |
| absence | Λ expected event/resource absent |
| trap | Φ recontextualization |
| rollback | Σ recovery / compensation path |
| quarantine | Χ tightened boundary under Ψ |
| degrade | Φ + Ψ controlled lower-capability context |
| revoke | Ψ + Ω + Σ |
| audit | Θ + Σ |
| escalate | Ψ + Φ |
| terminate | Φ + Σ + Ψ |
| halt | Ψ critical invariant response |

Security architecture is incomplete if it defines denial but not the resulting state.

### 1.11 Security and Audit

Runtime security is audit-ready by construction.

A security-relevant event should be able to emit:

```text
AuditEvent = (
    order,
    actor,
    action,
    target,
    frame,
    role,
    capability,
    boundary,
    policy,
    decision,
    result,
    commit_state,
    source,
    meta
)
```

Operator reading:

```text
Δ classify event
Θ order event
Ω record actor authority
□ record frame context
Χ record projected boundary context
Ψ record decision
Σ commit audit evidence if required
```

Audit is not merely a log sink. It is the committed evidence surface of runtime security.

Audit records are runtime-security evidence artifacts. They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 1.12 Trace and Evidence Convention

A concrete runtime-security execution produces:

```text
trace_runtime(runtime, artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security executions under a declared profile is:

```text
Trace_runtime(runtime, artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared runtime-security profile.

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Audit records and trace streams record observed executions.

They do not prove all possible executions unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

### 1.13 Security and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of runtime-security discipline:

```text
operator-tagged execution
model/stateful validation
fail-closed rejection paths
JSONL traces
golden fixtures
vFS service boundaries
AI proposal gating
```

Correct relation:

```text
Runtime-security specification
    defines security/governance obligations.

PMS-RUST bounded artifacts
    demonstrate executable slices of validation, traceability,
    service-boundary discipline, rejection paths, and proposal gating.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime security, prove deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, or make tests/traces proofs.

### 1.14 Security-as-Structure Invariants

Runtime security maintains the following structural invariants.

```text
I1: every security-relevant actor is Δ-distinguished
I2: every protected action is Ω-authorized
I3: every action occurs inside a valid □ frame
I4: every boundary-sensitive action is Χ-checked as an implementation-layer projection
I5: every policy-governed action is Ψ-evaluated
I6: every security-relevant ordering is Θ-representable
I7: every absence/security no-event is Λ-visible where declared
I8: every violation/trap/recovery is Φ-representable
I9: every stable security state is Σ-committed
I10: every policy mutation is Ψ-governed and Ω-authorized
I11: every trust-anchor change is Φ/Ψ/Σ-governed
I12: every audit-relevant event can be Θ-ordered and Σ-committed
I13: every quarantine action is Χ/Ψ/Φ/Σ-representable
I14: no security fast path bypasses Ω, Χ, Ψ, or Σ
I15: security strengthens implementation-layer architecture and does not function as PMS Base validation
```

### 1.15 Architectural Consequence

The consequence is:

```text
Runtime security in PMS-STACK is not an auxiliary service. It is the
operator discipline by which execution remains authorized, bounded,
policy-governed, auditable, recoverable, and committable.
```

Security becomes a first-class runtime structure:

```text
identity
authority
isolation
policy
audit
trust
failure response
governance
```

are all projections of Δ–Ψ rather than disconnected mechanisms.

## 2. Trust Boundaries

A trust boundary is a structured transition boundary.

It defines where an actor, frame, role, capability set, policy scope, isolation domain, execution substrate, host service, network session, key frame, audit surface, tooling surface, or governance domain changes interpretation.

The central trust-boundary claim is:

```text
A PMS-STACK trust boundary is valid when every crossing is Δ-classified,
Ω-authorized, □-framed, Χ-bounded as an implementation-layer boundary
projection, Ψ-policy-checked, Φ-recontextualized when interpretation
changes, Θ-ordered for audit, and Σ-committed when the resulting state
becomes stable.
```

Trust boundaries are not informal zones of confidence. They are operator-governed transition surfaces.

### 2.1 Trust Boundary Model

A trust boundary may be represented as:

```text
TrustBoundary = (
    id,
    source,
    target,
    source_frame,
    target_frame,
    source_principal,
    target_principal?,
    required_role,
    required_capability,
    boundary_relation,
    policy,
    entry_transition,
    exit_transition,
    commit_profile,
    audit_profile,
    failure_policy,
    meta
)
```

where:

| Field | Operator role |
| ----- | ------------- |
| `id` | Δ boundary distinction |
| `source` | Δ actor/source context |
| `target` | Δ target context |
| `source_frame` | □ origin frame |
| `target_frame` | □ destination frame |
| `source_principal` | Δ/Ω/Ψ actor identity |
| `target_principal` | mapped identity if crossing creates one |
| `required_role` | Ω role requirement |
| `required_capability` | Ω capability requirement |
| `boundary_relation` | Χ-projected reachability / isolation relation |
| `policy` | Ψ rule set |
| `entry_transition` | Φ or controlled call entry |
| `exit_transition` | Φ return / result recontextualization |
| `commit_profile` | Σ integration of boundary result |
| `audit_profile` | Θ/Σ evidence requirement |
| `failure_policy` | Λ/Φ/Χ/Ψ response |
| `meta` | profile, source, runtime, trace data |

A boundary is not valid because both sides “trust” each other. It is valid because the transition satisfies this structure.

### 2.2 Boundary Kinds

Runtime security covers several boundary kinds.

```text
kernel/user boundary
process/process boundary
thread/task boundary
module boundary
runtime/stdlib boundary
language/runtime boundary
FFI/host boundary
driver/kernel boundary
device/MMIO/DMA boundary
filesystem namespace boundary
IPC/channel boundary
network session boundary
distributed node boundary
trust-anchor/key-frame boundary
audit/compliance boundary
AI/tooling boundary
```

Each boundary has a different concrete substrate. All must preserve the same operator discipline.

### 2.3 Kernel/User Trust Boundary

The kernel/user boundary is the canonical runtime-security boundary.

Kernel context:

```text
Context_kernel = (f = KF, r ∈ {KERNEL, SUPERVISOR}, IDom = global)
```

User context:

```text
Context_user = (f = UF, r = USER, IDom = user_domain)
```

`IDom`, `X_user`, `X_global`, and comparable runtime-domain names denote implementation-level isolation-domain values.

They are not the PMS Base operator `Χ` itself.

PMS Base 1.3 defines `Χ` as Distance. Runtime security projects `Χ` as boundary, isolation, visibility, reachability, containment, namespace separation, quarantine, and trust-boundary control.

Entry:

```text
(f_user, r_user, IDom_user)
    --Φ_enter-->
(KF, KERNEL, IDom_global)
```

Exit:

```text
(KF, KERNEL, IDom_global)
    --Φ_return-->
(f_user, r_user, IDom_user)
```

A valid kernel entry requires:

```text
Δ classify entry reason
Ω authorize transition
□ switch to kernel frame
Χ establish kernel-visible projected boundary state
Ψ check entry policy
Θ order entry event
Σ commit any entry accounting/audit if required
```

A valid kernel exit requires:

```text
target frame valid
∧ target role permitted
∧ return address executable
∧ boundary state coherent
∧ policy permits return
∧ pending commit state resolved
```

The kernel is trusted as mediator, not as an unconstrained actor.

```text
kernel authority is privileged
kernel behavior is invariant-bound
```

### 2.4 Positive Trust Boundary

A PMS trust boundary is positive, not merely defensive.

It states:

```text
this transition is admissible because its frame, role, boundary,
policy, commit, and audit obligations are known.
```

It does not state:

```text
inside the boundary anything may happen.
```

For example, the kernel may have global visibility, but kernel actions still preserve:

```text
capability correctness
frame isolation
privilege monotonicity
policy integrity
scheduling integrity
commit validity
safe recontextualization
auditability
```

Trust is therefore a constrained runtime relation.

### 2.5 Process and Container Boundaries

A process boundary is a □/Χ structure.

```text
ProcessBoundary = (
    process_id,
    frame_set,
    role_state,
    capability_set,
    isolation_domain,
    local_policy,
    resource_account
)
```

A user process may:

```text
execute inside its frame
use permitted IPC endpoints
access authorized files and handles
allocate within quota
invoke allowed syscalls
receive events/signals
terminate through kernel-mediated Σ
```

A user process may not:

```text
directly access kernel frames
rewrite policy
grant itself capabilities
bypass syscall entry
break process isolation
access devices without mapping and authorization
commit global state without kernel mediation
```

Container or sandbox boundaries add stronger Χ-projected constraints:

```text
namespace restriction
filesystem subtree restriction
network restriction
syscall filtering
resource quota
capability contraction
audit requirement
```

Boundary crossing occurs only through:

```text
syscall
IPC
shared frame with policy
capability transfer
runtime service call
explicit boundary bridge
```

### 2.6 Module and Runtime Boundaries

Modules and runtime services introduce language/runtime trust boundaries.

Module boundary:

```text
ModuleBoundary = (
    module_frame,
    export_surface,
    import_edges,
    role,
    capability_surface,
    policy_set,
    isolation_profile
)
```

Valid module crossing:

```text
Δ resolve export/import
Ω verify module/interface capability
Χ check projected module visibility
Ψ check module policy
□ enter callee/module frame
∇ execute operation
Σ integrate result
Φ handle trap if produced
```

Runtime boundary examples:

```text
standard-library dispatcher
PMSL runtime service
PMS-IR validation layer
trace emitter
scheduler API
host adapter
simulation adapter
```

A runtime service may be trusted only for its declared profile.

```text
runtime profile support
≠ universal authority
```

### 2.7 FFI and Host Boundaries

FFI and host interoperability are high-risk trust boundaries.

A foreign boundary is:

```text
ForeignBoundary = (
    host,
    abi,
    foreign_symbol,
    memory_transfer_profile,
    error_map,
    capability,
    policy,
    commit_profile
)
```

Valid FFI crossing:

```text
Δ classify foreign symbol
Ω verify foreign-call capability
Χ enter projected host/foreign boundary
Ψ check FFI policy
Φ recontextualize into host ABI/context
∇ execute host call
Φ map host errors
Λ map expected no-response/timeout
Σ integrate result or effect state
```

The boundary rule:

```text
host behavior is never silently PMSL behavior.
```

Host calls must be represented through:

```text
ForeignFrame
HostService
FFI profile
error map
memory profile
commit profile
trace profile
```

A host runtime may support execution. It does not become PMS-OS.

### 2.8 Driver and Device Boundaries

Drivers are privileged but bounded actors.

Driver boundary:

```text
DriverBoundary = (
    driver_frame,
    driver_role,
    device_frames,
    MMIO_regions,
    DMA_regions,
    interrupt_vectors,
    driver_policy,
    quarantine_policy
)
```

Driver authority is specific:

```text
assigned device frames
declared MMIO windows
declared DMA regions
assigned interrupts
driver-local resources
```

Driver may not:

```text
access arbitrary kernel memory
DMA into unauthorized frames
ignore device isolation
self-grant capabilities
bypass driver policy
continue after quarantine
use stale device frames after detach
```

Device boundary failures may produce:

```text
Φ trap
Χ quarantine
Ω capability revocation
Σ rollback/cleanup
Ψ halt if critical
```

### 2.9 Network and Distributed Boundaries

A network boundary introduces remote identity and trust interpretation.

Network session boundary:

```text
NetworkBoundary = (
    local_principal,
    remote_principal,
    connection_frame,
    credential_set,
    trust_anchor,
    session_policy,
    protocol_profile,
    commit_profile
)
```

Session establishment:

```text
Δ distinguish remote principal and credentials
Φ map remote identity into local session frame
Ω assign session capabilities
Χ establish projected network/session boundary
Ψ enforce trust and protocol policy
Σ commit session state
Θ order audit and handshake events
```

Distributed boundary:

```text
DistributedBoundary = (
    node_id,
    cluster_role,
    quorum_policy,
    global_commit_profile,
    trust_anchor_set,
    audit_chain
)
```

Distributed trust depends on:

```text
remote identity mapping
capability delegation
quorum policy
cross-node audit
global or replicated commit
network boundary enforcement
```

Full distributed semantics belong to `07_distributed_systems.md`; this section fixes the runtime-security boundary form.

Distributed markers in this section are boundary-facing references to `07_distributed_systems.md`. They do not make this section the distributed-system specification.

### 2.10 Trust Anchor and Key Boundaries

Trust anchors and keys live inside explicit frames.

```text
KeyFrame = □(material, type, scope, metadata)
```

A trust boundary around key material includes:

```text
Χ isolation of private material
Ω capability to use/sign/decrypt/verify
Ψ policy for validity and allowed propagation
Φ interpretation of credential meaning
Σ commit of key installation, rotation, or revocation
Θ audit ordering
```

Trust anchor transition:

```text
Δ classify key/certificate/signature
Ω verify use authority
Χ check key-frame isolation
Ψ verify trust policy
Φ interpret credential or rotate/revoke context
Σ commit resulting trust state
```

Key material is not trusted because it exists. It is trusted because active Ψ policies interpret it under a valid Φ context and commit its state through Σ.

A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

### 2.11 Audit and Compliance Boundaries

Audit introduces a visibility boundary.

Some observers may see:

```text
full trace
redacted trace
metadata only
hash chain
policy decision only
aggregate metrics
nothing
```

Audit access requires:

```text
Δ classify audit query
Ω verify observer authority
Χ check projected audit visibility boundary
Ψ apply redaction/retention/compliance policy
Σ commit audit read/export event if required
```

Audit records themselves may become protected resources.

```text
audit log
    is evidence
    is state
    is governed
    is bounded
```

Compliance systems read Θ-ordered and Σ-committed evidence. They do not become policy authority unless explicitly granted by Ψ and Ω.

Compliance means checking runtime evidence against declared policy, profile, retention, redaction, and conformance obligations.

It does not mean social governance, legal adjudication, tribunal status, universal security certification, or PMS Base validation.

### 2.12 AI and Tooling Boundaries

AI tooling is a trust boundary.

AI/tooling may:

```text
propose PMS-IR
summarize traces
explain diagnostics
suggest missing policies
suggest scenarios
draft test fixtures
```

AI/tooling may not:

```text
authorize execution
define semantics
replace policy evaluation
replace verification
grant capabilities
commit runtime state
serve as trusted executable code
serve as compiler authority
serve as verification evidence
serve as runtime policy authority
validate PMS Base
```

AI/tooling boundary:

```text
Δ classify task
Ω verify tooling capability
Χ enter tooling/host boundary
Ψ enforce advisory-only policy
∇ request/advisory response
Φ handle malformed or failed response
Σ integrate advisory artifact only as advisory
```

Execution requires separate acceptance:

```text
parse
canonicalize
validate
policy-check
runtime acceptance
kernel/runtime execution
```

The trust boundary is explicit:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 2.13 Boundary Crossing Pipeline

General boundary crossing follows this pipeline:

```text
1. Δ classify source, target, action, credential, and boundary kind
2. □ determine active source and target frames
3. Ω verify required role/capability
4. Χ evaluate projected reachability / isolation / transfer relation
5. Ψ evaluate policy and governance constraints
6. Φ recontextualize if interpretation changes
7. ∇ perform permitted action or transfer
8. Σ commit result, audit, identity mapping, or resource state
9. Θ order events and attach trace/audit metadata
10. Λ/Φ/Χ/Ψ handle absence, trap, quarantine, denial, or halt
```

Compact form:

```text
Δ ; □ ; Ω ; Χ ; Ψ ; Φ? ; ∇? ; Σ? ; Θ
```

Failure alternatives:

```text
Ω denial
Χ boundary block
Ψ denial
Λ no route / no resource / no response
Φ trap / recovery
Χ quarantine
Σ rollback / audit
Ψ halt
```

### 2.14 Boundary Failure

A trust-boundary failure is operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown actor/target | Δ failure |
| invalid frame | □/Δ failure |
| missing capability | Ω/Ψ |
| isolation violation | Χ projection / Ψ / Φ |
| policy denial | Ψ/Φ |
| unsupported runtime boundary | Λ/Φ/Ψ |
| no route/no response | Λ |
| host failure | Φ |
| invalid credential | Δ/Ψ/Φ |
| expired key/session | Θ/Φ/Ψ |
| commit failure | Σ/Φ |
| audit failure | Σ/Ψ/Φ |
| critical invariant violation | Ψ halt/quarantine |

Boundary failure must not be collapsed into a generic error if the operator distinction matters.

### 2.15 Quarantine as Boundary Response

Quarantine is a stronger boundary state.

```text
Χ_quarantine(subject)
```

may apply to:

```text
process
thread
driver
device
IPC endpoint
filesystem subtree
module
namespace
container
network session
node
tooling service
```

Quarantine may:

```text
remove from ready set
revoke capabilities
restrict frame visibility
block device access
disable IPC delivery
freeze filesystem writes
redirect syscalls
require audit
force finalization
terminate under policy
```

Quarantine is not a moral judgment and not a forensic verdict. It is a runtime-security isolation response to a policy or invariant condition.

Operator reading:

```text
Δ classify offending subject
Ψ decide quarantine
Χ tighten projected boundary
Ω revoke or restrict capabilities
Φ recontextualize execution
Σ commit quarantine state
Θ audit event
```

### 2.16 Trust Boundary Invariants

Runtime security maintains the following trust-boundary invariants.

```text
I1: every boundary has a Δ-distinguishable source and target
I2: every boundary crossing occurs inside known □ frames
I3: every protected crossing is Ω-authorized
I4: every crossing is Χ-reachability checked as an implementation-layer projection
I5: every crossing is Ψ-policy checked
I6: every interpretation-changing crossing is Φ-mediated
I7: every stable boundary result is Σ-committed
I8: every audit-relevant crossing is Θ-ordered and traceable
I9: kernel/user crossing occurs only through controlled Φ entry/return
I10: process/process crossing occurs only through explicit bridge, IPC, shared frame, or authorized transfer
I11: module crossing uses import/export/interface surfaces
I12: FFI crossing uses ForeignFrame or HostService profile
I13: driver/device crossing is confined to assigned frames and capabilities
I14: network crossing maps remote identity before local authority is granted
I15: trust-anchor crossing interprets credentials only under Ψ policy
I16: audit boundary respects Ω/Χ/Ψ visibility and redaction rules
I17: AI/tooling boundary remains advisory unless host validation accepts an artifact
I18: boundary failure has typed Λ/Φ/Χ/Ψ/Σ response
I19: quarantine is explicit Χ tightening under Ψ
I20: no trust-boundary fast path bypasses Ω, Χ, Ψ, Φ, or Σ
```

### 2.17 Architectural Consequence

The consequence is:

```text
PMS-STACK trust boundaries are not informal trust zones. They are
operator-governed transition surfaces. A boundary crossing is valid only
when identity, frame, role, capability, isolation, policy,
recontextualization, commit, ordering, and audit obligations are
explicitly satisfied.
```

This gives PMS-STACK a uniform trust-boundary architecture for:

```text
kernel entry
process isolation
module linkage
runtime services
FFI and host calls
drivers and devices
network sessions
distributed nodes
trust anchors
audit systems
AI/tooling services
```

The boundary claim is implementation-layer precise: trust is real, enforceable, inspectable, and auditable, but it remains bounded by declared profiles, policies, assumptions, and artifacts.

### 2.18 Trust Boundary Claim Boundary

The trust-boundary model specifies implementation-layer runtime-security boundary architecture.

It does not claim completed kernel isolation, completed process isolation, completed sandboxing, completed cryptographic deployment, completed network security, completed FFI safety, completed distributed trust, completed audit/compliance implementation, universal security certification, or PMS Base validation.

This strengthens the PMS-STACK runtime-security architecture claim.

It does not validate PMS Base.

---

## 3. Identity and Principal Model

Identity is the actor substrate of PMS-STACK runtime security.

A PMS-STACK runtime cannot decide whether an action is valid unless it can determine:

```text
who or what is acting
under which role
inside which frame
across which boundary projection
with which capabilities
under which policies
toward which target
with which commit and audit consequences
```

The central identity claim is:

```text
A PMS-STACK identity is valid when the acting principal is Δ-distinguished,
Ω-role/capability-bound, □-frame-scoped, Χ-boundary-located as an
implementation-layer projection, Ψ-policy-constrained,
Φ-recontextualizable across interpretation changes, and Σ-committed when
its bindings become stable.
```

Identity is therefore not a passive label. It is a runtime-security object that constrains transitions.

Claim type:

```text
RUNTIME-SECURITY IDENTITY / PRINCIPAL ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK identity and principals as
implementation-layer runtime-security architecture.

It does not define personhood, moral status, psychological identity,
social worth, clinical identity, legal personality, forensic authority,
or person-ranking.

A PMS principal is a computational actor identity used for authorization,
isolation, policy, audit, delegation, trust mapping, resource accounting,
and runtime governance.

This strengthens the PMS-STACK runtime-security architecture claim.
It does not validate PMS Base.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At runtime-security identity level, Χ is projected as isolation domain, boundary location, namespace visibility, endpoint reachability, trust-boundary control, container/sandbox containment, host-service boundary, and audit visibility boundary.

Runtime identity uses this Χ projection. It does not redefine Χ.

### 3.1 Role of Identity in Runtime Security

Runtime security needs identity because security decisions are not made over actions alone.

The same action may be valid or invalid depending on:

```text
actor
role
frame
boundary projection
capability
policy
resource state
trust context
audit requirement
runtime profile
```

Example:

```text
FS.write("/var/log/audit.log", data)
```

is not intrinsically valid or invalid.

It becomes valid only when the runtime can establish:

```text
actor is distinguished
role has write authority
capability covers the path
frame can reach the namespace
boundary projection permits filesystem access
policy allows the write
commit profile is correct
audit obligation is satisfied
```

Identity is the binding surface for those checks.

The runtime-security identity model therefore answers:

```text
Who is the actor?
What authority does the actor carry?
Where is the actor located?
Which boundary projections constrain the actor?
Which policies bind the actor?
Which actions may the actor perform?
Which transitions may change the actor?
Which audit record must identify the actor?
```

### 3.2 Principal

A principal is the atomic actor identity unit of PMS-STACK runtime security.

Specification form:

```text
Principal = (
    pid,
    attrs,
    caps,
    frames,
    iso,
    policies,
    provenance,
    lifecycle,
    meta
)
```

Minimal form:

```text
Principal ::= {
    pid:      PrincipalID,
    attrs:    PrincipalAttributes,
    caps:     CapabilitySet,    ; Ω
    frames:   FrameScope,       ; □
    iso:      IsolationDomain,  ; Χ projection
    policies: PolicyLinks       ; Ψ
}
```

A principal is valid when:

```text
principal_valid(p) iff
    unique(p.pid)
    ∧ attrs_valid(p.attrs)
    ∧ capabilities_valid(p.caps)
    ∧ frames_valid(p.frames)
    ∧ isolation_domain_valid(p.iso)
    ∧ policies_consistent(p.policies)
    ∧ lifecycle_valid(p.lifecycle)
```

`iso`, `IDom`, `X_user`, `X_global`, and comparable runtime-domain names denote implementation-level isolation-domain values.

They are not the PMS Base operator `Χ` itself.

A principal is not reducible to a PID, username, token, certificate, process ID, or role label. Those may be fields or representations. The principal is the structured runtime object that links identity to operator-governed execution.

### 3.3 Principal Fields

#### `pid` — Principal Identity

```text
pid: PrincipalID
```

The `pid` is the Δ-distinguished identifier of the principal.

It must be:

```text
unique inside its identity domain
stable for the declared lifetime
not reused before policy permits reuse
auditable where required
resolvable by runtime-security mechanisms
```

Examples:

```text
UserID:ProcessID
NodeID:LocalPID
Cluster:Node:Service:Thread
DeviceClass:DeviceID
ContainerID:ProcessID
CertificateFingerprint:SessionID
```

`pid` is a distinction, not an authority grant.

```text
pid identifies.
Ω authorizes.
Ψ constrains.
Χ projection bounds.
Σ commits.
```

#### `attrs` — Principal Attributes

```text
attrs: PrincipalAttributes
```

Attributes describe the principal.

Examples:

```text
type = user | service | process | thread | kernel | driver | device | node | external
creation_time
issuer
provenance
labels
resource class
trust class
public key reference
audit class
runtime profile
```

Attributes are not sufficient for access.

They may feed:

```text
Ω role selection
Ψ policy evaluation
Χ boundary-profile selection
Σ audit records
Φ recontextualization
```

but they do not replace those operators.

#### `caps` — Capability Set

```text
caps: CapabilitySet
```

The principal’s capability set defines what operator-scoped actions it may attempt.

Examples:

```text
fs.read("/home/user/**")
fs.write("/var/log/**")
net.connect("cluster.internal")
ipc.send(ChannelA)
ipc.recv(ChannelB)
device.mmio(DeviceFrame0)
policy.install(LocalPolicy)
module.reframe(AppModule)
debug.trace(ProcessX)
```

Capabilities are Ω structures.

They are checked against:

```text
action
target
frame
boundary projection
policy
scope
constraints
lifetime
```

A capability does not override Ψ policy or Χ-projected isolation.

```text
capability present
≠ action automatically valid
```

A capability is necessary where required. It is not sufficient without policy and boundary validity.

#### `frames` — Frame Scope

```text
frames: FrameScope
```

The principal’s frame scope defines where the principal may act.

Frame scope may include:

```text
process address space
module frame
task frame
kernel gateway frame
filesystem namespace
IPC endpoints
shared memory frames
driver/device frames
network session frame
foreign/host frame
audit frame
```

Frame scope is □-typed.

Identity is therefore contextual: the same principal may have different effective authority inside different frames.

Example:

```text
principal P inside UserFrame:
    capabilities = limited user operations

principal P inside ServiceFrame under delegated context:
    capabilities = service-limited operations

principal P inside ForeignFrame:
    capabilities = host-call profile only
```

A principal does not float above frames. It is interpreted through frames.

#### `iso` — Isolation Domain

```text
iso: IsolationDomain
```

The isolation domain is the implementation-layer projection of PMS Base Χ.

At PMS Base level:

```text
Χ = Distance
```

At runtime-security implementation level, this projects as:

```text
process boundary
namespace boundary
sandbox boundary
container boundary
network session boundary
device boundary
module boundary
host boundary
audit visibility boundary
trust-anchor boundary
```

The principal’s isolation domain defines:

```text
which frames are visible
which namespaces are visible
which IPC endpoints are reachable
which devices are accessible
which host services are reachable
which network sessions are permitted
which audit surfaces are visible
```

Isolation is enforced with Ω and Ψ.

```text
Χ projection bounds reachability.
Ω authorizes attempts.
Ψ decides admissibility.
```

#### `policies` — Policy Links

```text
policies: PolicyLinks
```

Policy links bind the principal to active Ψ constraints.

Policy links may include:

```text
mandatory access policy
audit policy
quota policy
delegation policy
revocation policy
key-use policy
network policy
module policy
FFI policy
driver policy
runtime profile policy
compliance policy
```

Policies may:

```text
allow
deny
modify
audit
trap
isolate
revoke
quarantine
escalate
halt
```

A principal’s policy set is part of identity validity.

```text
identity without policy links is under-specified in PMS-STACK security.
```

#### `provenance`

```text
provenance: Provenance
```

Provenance records how the principal was created, mapped, delegated, or imported.

Examples:

```text
created by kernel
derived from user principal
spawned by service principal
mapped from network credential
created by driver discovery
created by device enumeration
generated by cluster membership protocol
derived from AI/tooling host service
```

Provenance is relevant for:

```text
audit
revocation
delegation chains
trust decisions
compliance
incident reconstruction
policy explanation
```

Provenance is not authority by itself. It is evidence used by Ψ-governed policy evaluation and audit.

It is not forensic omniscience or legal identity proof.

#### `lifecycle`

```text
lifecycle: PrincipalLifecycle
```

A principal has lifecycle state.

Possible states:

```text
NEW
BOUND
ACTIVE
SUSPENDED
QUARANTINED
REVOKED
EXPIRED
TERMINATING
TERMINATED
```

Lifecycle transitions are operator-governed:

```text
NEW → BOUND          Δ + Σ
BOUND → ACTIVE       Ω + Ψ + Σ
ACTIVE → SUSPENDED   Ψ + Θ + Σ
ACTIVE → QUARANTINED Ψ + Χ + Φ + Σ
ACTIVE → REVOKED     Ψ + Ω + Σ
ACTIVE → EXPIRED     Θ over τ metadata + Ψ + Σ
ACTIVE → TERMINATING Φ + Σ
TERMINATING → TERMINATED Σ + Ψ
```

A runtime-security system must not use an identity outside its valid lifecycle state.

### 3.4 Principal Classes

PMS-STACK supports several principal classes.

The classes are structural. They are not personality, social, moral, clinical, forensic, or legal categories.

#### User Principal

A user principal represents an account-like actor.

Typical role:

```text
human-facing or account-facing identity
```

Common bindings:

```text
home namespace
interactive session
process creation rights
user-scoped filesystem access
audit identity
quota policy
```

A user principal is a computational principal. It is not a claim about personhood or moral status.

#### Service Principal

A service principal represents a long-lived runtime service.

Examples:

```text
scheduler service
network broker
database service
logging service
policy manager
update manager
AI tooling service
```

Common bindings:

```text
service frame
service role
restricted capability set
audit policy
restart/supervision policy
network or IPC endpoint identity
```

#### Process Principal

A process principal represents an execution context.

It may be derived from:

```text
user principal
service principal
kernel principal
container principal
network session principal
```

Process principal form:

```text
ProcessPrincipal = (
    pid,
    parent_principal,
    frame_set,
    role_state,
    isolation_domain,
    local_policy,
    resource_account
)
```

It controls:

```text
syscalls
memory access
IPC
filesystem ownership
scheduler identity
resource accounting
signals/events
audit records
policy evaluation
```

#### Thread Principal

A thread principal is optional but permitted.

It is useful for:

```text
high-security runtimes
per-thread delegation
fine-grained audit
capability-scoped worker pools
driver worker isolation
network session workers
```

Constraint:

```text
thread_principal ⊑ process_principal
```

A thread principal may refine authority. It must not exceed the parent process principal unless a kernel-mediated Ω/Φ/Ψ/Σ path grants and commits that transition.

#### Kernel Principal

A kernel principal represents privileged mediation.

It may:

```text
create frames
manage process tables
install policies
grant/revoke capabilities
handle traps
manage resource accounting
mediate syscalls
commit global state
```

But kernel principal authority is not unbounded in the PMS-STACK architecture.

Kernel action must preserve:

```text
capability correctness
frame isolation
policy integrity
safe recontextualization
commit validity
auditability
```

The kernel is a privileged invariant-bound actor.

#### Driver Principal

A driver principal represents a governed device-control actor.

It is bound to:

```text
driver frame
device frames
MMIO regions
DMA regions
interrupt vectors
driver policy
quarantine policy
```

A driver principal may access only assigned device resources.

It may not:

```text
access arbitrary kernel memory
grant itself broader MMIO access
DMA into unauthorized frames
modify system policy
continue execution after quarantine
```

#### Device Principal

A device principal represents a hardware or virtual device identity.

It supports:

```text
driver binding
device access policy
firmware authentication
resource accounting
MMIO/DMA boundary enforcement
audit attribution
```

Device principals are important because devices are not passive in a secure runtime architecture. They participate in state transitions through driver-mediated effects.

A device principal is a runtime-security actor model. It is not a person-like subject.

#### Container / Sandbox Principal

A container principal represents a restricted execution domain.

It carries:

```text
namespace boundary
filesystem boundary
IPC boundary
network boundary
capability contraction
resource quota
audit policy
```

Container identity is not a stronger authority. It is usually a contraction:

```text
container_principal ⊑ parent_principal
```

unless a policy-governed recontextualization explicitly defines another relation.

#### Network / External Principal

An external principal represents a remote actor.

Examples:

```text
certificate identity
public-key identity
session identity
remote node identity
remote service identity
peer connection identity
```

External principal handling requires:

```text
Δ classify credential
Φ map remote identity into local interpretation
Ψ verify trust policy
Ω assign local capabilities
Χ bind projected session boundary
Σ commit session principal
```

Remote identity is not automatically local authority.

#### Node / Cluster Principal

A node principal represents a distributed-system actor.

It may carry:

```text
node ID
cluster role
quorum capability
routing authority
replication responsibility
trust-anchor bindings
audit-chain commitments
```

Node principals are refined in `07_distributed_systems.md`. Runtime security defines the local identity form and trust-boundary obligations.

#### Tooling / AI Principal

A tooling principal represents a debugger, analyzer, build tool, AI proposal service, trace analyzer, or host-side assistant.

A tooling principal may be allowed to:

```text
inspect traces
propose PMS-IR
summarize diagnostics
run simulations
request validation
read redacted reports
draft candidate fixtures
```

It may not automatically:

```text
authorize execution
grant capabilities
modify policy
commit runtime state
replace verifier
replace policy evaluation
define semantics
serve as trusted executable code
serve as compiler authority
serve as verification evidence
validate PMS Base
```

Tooling identity is governed by an advisory boundary unless explicitly promoted by policy.

The standard AI/tooling boundary is:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 3.5 Identity Binding

Identity binding is the process by which a principal becomes stable enough for runtime use.

Canonical creation binding:

```text
Δ distinguish new principal
Σ bind attributes
Ω configure role/capability set
□ assign frame scope
Χ assign projected isolation domain
Ψ attach policies
Σ commit identity record
Θ order audit event
```

Compact form:

```text
Δ → Σ → Ω → □ → Χ → Ψ → Σ
```

A principal is not fully active until binding is complete.

#### Creation Binding

Creation binding occurs when the runtime creates:

```text
process
thread
service
driver
device
session
module instance
container
node membership
tooling service
```

Creation binding rule:

```text
created_principal_valid(p) iff
    Δ created unique pid
    ∧ Ω assigned initial role
    ∧ □ assigned valid frame scope
    ∧ Χ assigned valid isolation-domain projection
    ∧ Ψ attached policies
    ∧ Σ committed binding
```

#### Session Binding

Session binding maps an external or temporary identity into a local runtime principal.

Example:

```text
remote credential
→ Δ classify
→ Ψ verify credential policy
→ Φ map into local session frame
→ Ω assign session capabilities
→ Χ establish projected session boundary
→ Σ commit session principal
```

The session principal may expire, revoke, or reframe independently of the remote credential.

#### Device Binding

Device binding maps discovered hardware or virtual hardware into a device principal.

Example:

```text
Δ discover device
□ create DeviceFrame
Ω assign device/driver capabilities
Χ isolate MMIO/DMA regions as projected device boundaries
Ψ attach driver/device policy
Σ commit device principal
```

This prevents device access from being represented as unstructured kernel privilege.

### 3.6 Delegation

Delegation transfers or derives authority from one principal to another.

Delegation form:

```text
delegate(P_src, P_dst, cap, scope, constraints)
```

Operator reading:

```text
Δ classify delegation request
Ω verify P_src may delegate cap
Ψ check delegation policy
Φ recontextualize P_dst authority context
Ω add or refine capability on P_dst
Σ commit delegation event
Θ audit delegation
```

Delegation validity:

```text
valid_delegation iff
    cap ∈ delegable(P_src)
    ∧ scope(cap) is explicit
    ∧ constraints are policy-valid
    ∧ P_dst can hold the capability
    ∧ delegation is committed
```

Delegation may be:

```text
temporary
frame-scoped
task-scoped
session-scoped
resource-scoped
path-scoped
device-scoped
network-scoped
one-shot
revocable
```

Delegation is not impersonation unless the policy explicitly allows identity recontextualization.

### 3.7 Impersonation

Impersonation is a controlled Φ transformation.

It changes how an actor is interpreted for a restricted context.

Example:

```text
service acts on behalf of user
```

Operator reading:

```text
Δ classify impersonation request
Ω verify impersonation capability
Ψ check on-behalf-of policy
Φ recontextualize service principal as delegated user context
Σ commit impersonation scope
Θ audit event
```

Impersonation must define:

```text
source principal
represented principal
scope
duration
capability subset
policy restrictions
audit attribution
revocation path
```

Impersonation invariant:

```text
impersonated authority ≤ allowed delegated authority
```

A service may act for a user only through a committed, policy-governed, auditable scope.

Impersonation remains a computational runtime-security construct. It is not personhood transfer, moral substitution, or legal representation unless an external legal framework separately defines such a relation.

### 3.8 Revocation

Revocation removes or invalidates identity authority.

Revocation may target:

```text
principal
capability
role
session
trust binding
key use
network membership
module authority
driver authority
tooling authority
```

Operator reading:

```text
Δ classify revocation target
Ψ evaluate revocation policy
Ω remove or restrict capability/role
Χ restrict projected boundary if needed
Φ recontextualize active executions if needed
Σ commit revocation
Θ audit revocation
```

Revocation outcomes:

```text
capability removed
principal suspended
session expired
process killed
driver quarantined
node isolated
policy updated
key invalidated
audit marker committed
```

Revocation must handle live uses.

For example:

```text
capability revoked while task is running
```

requires:

```text
Θ order revocation relative to active task
Ψ decide effect on current operation
Φ trap or recontextualize if operation becomes invalid
Σ commit new authority state
```

### 3.9 Identity Across Frames

Principals are frame-scoped.

A principal may have different effective authority depending on:

```text
function frame
module frame
process frame
kernel frame
handler frame
foreign frame
network session frame
transaction frame
audit frame
```

Frame entry may:

```text
drop capabilities
activate policies
narrow isolation
bind temporary roles
enable handler context
switch audit profile
```

Frame exit must:

```text
restore prior role/capability state where applicable
close or transfer frame-local resources
commit or rollback frame-local effects
preserve audit order
```

Example:

```text
call secure_service():
    □ enter ServiceFrame
    Ω restrict to service capability subset
    Ψ enforce service contract
    ∇ perform service operation
    Σ commit result
    □ exit ServiceFrame
```

Frame-scoped identity invariant:

```text
authority_inside_frame ≤ authority_allowed_by_frame_policy
```

A frame may refine identity. It may not silently grant unbounded authority.

### 3.10 Identity Across Isolation Boundaries

Isolation boundaries govern where identity can act.

Cross-boundary identity transition:

```text
source principal in IDom_src
→ target context in IDom_dst
```

requires:

```text
Δ classify source/target/action
Ω verify crossing capability
Χ verify projected reachability relation
Ψ enforce boundary policy
Φ recontextualize identity if interpretation changes
Σ commit mapped identity or transfer result
Θ audit crossing
```

Examples:

```text
process → kernel
container → host service
module → module
driver → device
local node → remote node
tooling host → runtime artifact
```

Identity across a boundary may be:

```text
preserved
restricted
mapped
anonymized
delegated
proxied
revoked
quarantined
```

The mapping must be explicit.

```text
identity crossing boundary
≠ identity retaining all prior meaning
```

`IDom_src` and `IDom_dst` are implementation-level isolation-domain values. They are not PMS Base Χ itself.

### 3.11 Identity in Distributed Contexts

Distributed identity is local identity plus trust mapping.

Remote identity cannot be used directly as local authority.

Distributed identity flow:

```text
1. Δ distinguish remote credential / node / service / session
2. Ψ verify credential, issuer, trust anchor, freshness, and policy
3. Φ map remote identity into local principal form
4. Ω assign local capabilities
5. Χ bind projected network/session/node boundary
6. Σ commit local session or node principal
7. Θ audit handshake and mapping events
```

Distributed principal form:

```text
DistributedPrincipal = (
    local_pid,
    remote_id,
    node_id,
    credential,
    mapped_role,
    mapped_capabilities,
    session_boundary,
    trust_anchor,
    policy_links,
    provenance,
    commit_state
)
```

Distributed identity invariants:

```text
remote credential is classified before use
trust policy evaluates before authority assignment
local capability is explicitly assigned
session boundary is explicit
mapping is committed
audit event is ordered
revocation path exists
```

Cluster identity requires additional policies:

```text
quorum membership
node admission
node revocation
role downgrade
network partition handling
global audit
trust-anchor rotation
```

Those are refined in `07_distributed_systems.md`.

Distributed markers in this section are boundary-facing references. They do not make this section the distributed-system specification.

### 3.12 Identity and Trust Anchors

Trust anchors participate in identity but do not replace identity.

A key or certificate may support:

```text
credential validation
session establishment
principal mapping
signature verification
node admission
driver validation
boot validation
```

But a credential does not become runtime authority until the runtime performs:

```text
Δ classify credential
Ψ verify policy
Φ interpret credential in local context
Ω assign role/capability
Χ bind projected boundary
Σ commit principal/session/trust state
```

Trust anchor relation:

```text
credential supports a trust claim under policy.
principal receives authority only after runtime binding.
```

A trust anchor does not create authority by existing.

A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

Trust validation in this section means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, and runtime policy profile.

It does not mean external validation of PMS Base, legal identity proof, universal trust, or personhood validation.

A key verifies a cryptographic relation under a profile. A policy interprets what that relation means. The runtime commits only the resulting local trust state.

This distinction prevents cryptographic material from becoming magical authority.

### 3.13 Identity and Resource Accounting

Resource accounting is principal-linked.

A resource event should be attributable to:

```text
principal
process
thread/task
role
frame
boundary projection
policy
resource account
```

Examples:

```text
CPU usage
memory allocation
IPC queue usage
filesystem writes
network bytes
device operations
trace volume
audit storage
```

Accounting flow:

```text
Δ classify resource event
Ω identify accountable principal/role
Θ order usage update
Σ commit usage counters
Ψ enforce quota policy
Λ/Φ produce no-resource or trap outcome if limit is exceeded
```

Identity is therefore necessary for quotas and runtime governance.

Resource accounting is an implementation-layer accounting discipline. It is not social evaluation or person ranking.

### 3.14 Identity and Audit

Audit records must identify actors structurally.

Audit record form:

```text
IdentityAuditRecord = (
    event_id,
    order,
    actor_principal,
    effective_principal,
    source_principal?,
    delegated_from?,
    role,
    capabilities,
    frame,
    boundary,
    policy,
    action,
    target,
    decision,
    result,
    commit_state,
    provenance,
    meta
)
```

Audit event reading:

```text
Δ classify audit event
Θ order event
Ω record authority state
□ record frame context
Χ record projected boundary context
Ψ record policy decision
Σ commit audit evidence
```

Audit must distinguish:

```text
actor principal
effective principal
delegated principal
remote principal
tooling principal
kernel mediator
```

Otherwise delegation, impersonation, network mapping, and kernel mediation become opaque.

Audit records are runtime-security evidence artifacts.

They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 3.15 Identity Normal Forms

Runtime implementations may use normal forms for efficiency.

#### Local Normal Form

```text
LocalPrincipal = (
    pid,
    role,
    caps,
    frame_scope,
    isolation_domain,
    policy_refs
)
```

Used for:

```text
syscalls
scheduler
IPC
memory access
filesystem
process management
driver calls
```

#### Session Normal Form

```text
SessionPrincipal = (
    session_id,
    local_pid,
    remote_id?,
    caps,
    session_frame,
    network_boundary,
    trust_state,
    policy_refs,
    expiry
)
```

Used for:

```text
network connections
remote services
TLS-like sessions
cluster membership
brokered IPC
```

#### Audit Normal Form

```text
AuditPrincipal = (
    stable_id,
    effective_id,
    source_id?,
    role,
    frame,
    boundary,
    policy_hash,
    provenance_hash
)
```

Used for:

```text
audit logs
compliance exports
trace correlation
incident reconstruction
```

#### Distributed Normal Form

```text
DistributedPrincipal = (
    node,
    cluster_id,
    remote_pid,
    local_mapping,
    trust_anchor,
    quorum_role,
    caps,
    policies,
    provenance
)
```

Used for:

```text
distributed sessions
node admission
global commit
replication
orchestration
cluster audit
```

Normal forms may optimize representation. They may not erase operator obligations.

### 3.16 Identity Algebra

PMS-STACK may model identities through a compact algebra.

```text
I = (ID, ∘, ⊑, ⊗, ▷, ⊎)
```

where:

| Symbol | Meaning |
| ------ | ------- |
| `ID` | set of principal identities |
| `∘` | derivation/composition |
| `⊑` | subprincipal / restriction relation |
| `⊗` | capability combination |
| `▷` | authorization relation |
| `⊎` | policy union/composition |

#### Composition

```text
id_child = id_parent ∘ ctx
```

where:

```text
ctx = (
    Δ_create,
    Ω_adjust,
    □_assign,
    Χ_assign_projection,
    Ψ_bind,
    Σ_commit
)
```

Composition models:

```text
process from user
thread from process
driver from kernel device manager
session from remote credential
container from service
tooling task from build system
```

#### Subprincipal Relation

```text
id_a ⊑ id_b
```

means:

```text
caps(id_a) ⊆ caps(id_b)
∧ frames(id_a) ⊆ frames(id_b)
∧ iso(id_a) is equal or more restrictive
∧ policies(id_a) are equal or stronger
```

This relation supports least privilege.

Examples:

```text
thread_principal ⊑ process_principal
sandbox_principal ⊑ service_principal
driver_worker ⊑ driver_principal
session_principal ⊑ mapped_remote_principal under local policy
```

#### Capability Combination

```text
id_a ⊗ cap
```

adds or combines capability state only when Ω and Ψ permit it.

Valid capability combination:

```text
Ω permits capability grant
∧ Ψ permits delegation
∧ Χ projection permits target boundary
∧ Σ commits grant
```

#### Authorization Relation

```text
id ▷ action
```

is true when:

```text
Ω permits action
∧ Ψ permits action
∧ Χ projection permits target reachability
∧ □ supports frame context
∧ action dependency structure is valid
```

Authorization is multi-factor.

#### Policy Union

```text
pol(id_a ⊎ id_b)
```

combines policy constraints.

Policy composition should be monotone by default:

```text
combined policy is at least as restrictive as all required policies
```

Relaxation requires explicit Φ/Ω/Ψ authorization and Σ commit.

### 3.17 Identity Lifecycle

A principal’s lifecycle is operator-governed.

```text
PrincipalLifecycle =
    CREATED
    BOUND
    ACTIVE
    DELEGATED
    SUSPENDED
    QUARANTINED
    REVOKED
    EXPIRED
    CLOSED
```

Lifecycle transitions:

| Transition | Operator reading |
| ---------- | ---------------- |
| create | Δ |
| bind | Σ + Ω + □ + Χ + Ψ |
| activate | Ω + Ψ + Σ |
| delegate | Φ + Ω + Σ |
| suspend | Ψ + Θ + Σ |
| quarantine | Ψ + Χ + Φ + Σ |
| revoke | Ψ + Ω + Σ |
| expire | Θ over τ metadata + Ψ + Σ |
| close | Σ + Ψ |

Lifecycle invariant:

```text
principal may authorize actions only in ACTIVE or policy-approved delegated states.
```

A revoked, expired, quarantined, or closed principal cannot silently continue to authorize actions.

### 3.18 Identity Validation

Identity validation checks whether a principal may participate in runtime security.

Validation in this section means acceptance or rejection under a declared runtime-security schema, identity model, lifecycle rule, trust-anchor profile, policy profile, hook profile, artifact profile, or conformance rule.

It does not mean external validation of PMS Base.

Validation pipeline:

```text
Δ resolve principal
check uniqueness
check lifecycle
check role/capability set
check frame scope
check isolation domain
check policy links
check provenance if required
check trust-anchor binding if external
check resource account
check audit profile
Σ accept active identity view
```

Identity validation failure may produce:

```text
Δ failure
Ω denial
Χ boundary denial
Ψ denial
Λ absent identity / expired session
Φ trap / recontextualization
Σ revocation or audit commit
```

Validation is required at:

```text
syscall entry
process creation
capability grant
policy modification
FFI call
network session mapping
driver/device binding
module import/export
audit export
debug inspection
AI/tooling request
```

Validators accept or reject under declared profiles. They do not prove PMS Base or complete deployment security.

### 3.19 Identity Failure Modes

Identity failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown principal | Δ / Λ |
| duplicate principal ID | Δ / Ψ |
| expired session | Θ / Λ / Ψ |
| revoked principal | Ψ / Ω / Σ |
| missing capability | Ω / Ψ |
| invalid frame scope | □ / Ψ |
| boundary mismatch | Χ projection / Ψ / Φ |
| invalid trust credential | Δ / Ψ / Φ |
| delegation not permitted | Ω / Ψ / Φ |
| impersonation invalid | Φ / Ω / Ψ |
| policy conflict | Ψ |
| audit identity missing | Δ / Σ / Ψ |
| resource identity mismatch | Δ / Ψ |
| stale distributed mapping | Φ / Θ / Ψ |

Identity failure must not be collapsed into generic authentication failure when the operator distinction matters.

### 3.20 Identity and Attack Handling

Many attacks are identity attacks.

Attack words describe attempted operator sequences. They do not assert that the attack succeeds.

Runtime security identifies the failed obligation: Δ classification, Ω authority, □ frame validity, Χ boundary projection, Ψ policy, Φ recontextualization, Σ commit, or Θ ordering.

#### Unauthorized Privilege Escalation

Attempt:

```text
w =
    Δ_target_role
    ; ∇_request_role(root)
    ; Ω_elevate
```

Runtime response:

```text
Ω denies direct elevation
Ψ enforces role monotonicity
Φ traps into violation context
Σ commits audit event
```

#### Identity Confusion

Attempt:

```text
remote principal claims local service identity
```

Runtime response:

```text
Δ distinguishes remote credential
Ψ verifies trust policy
Φ maps only into allowed local session principal
Ω assigns limited capabilities
Σ commits mapping
```

#### Delegation Smuggling

Attempt:

```text
service passes capability through IPC without delegation policy
```

Runtime response:

```text
Δ classifies capability-bearing payload
Ω checks transfer authority
Χ checks projected endpoint boundary
Ψ denies unauthorized delegation
Φ traps or strips capability
Σ audits decision
```

#### Stale Session Reuse

Attempt:

```text
expired session uses old capability
```

Runtime response:

```text
Θ orders expiry check
Ψ rejects stale identity
Ω revokes effective capability
Σ commits session closure
```

A successful rejection shows that a specific attempted transition was blocked under a declared profile. It is not a universal proof that all variants are blocked.

### 3.21 Identity, Tooling, and AI Boundary Violations

A tooling or AI boundary violation occurs when advisory output attempts to become execution authority, policy authority, verifier authority, capability grant, runtime commit, trusted executable code, or PMS Base evidence without host-side acceptance.

Runtime response:

```text
Δ classify tooling artifact
Ω check tooling capability
Χ enforce tooling/host boundary
Ψ deny execution authority
Φ recontextualize as violation if needed
Σ commit audit/rejection record
```

Permitted tooling/AI identity behavior:

```text
propose PMS-IR
summarize trace
explain diagnostic
suggest missing policy
suggest scenario
draft test fixture
request validation
```

Forbidden tooling/AI identity behavior:

```text
authorize execution
define semantics
replace policy evaluation
replace verification
grant capabilities
commit runtime state
serve as trusted executable code
serve as compiler authority
serve as verification evidence
validate PMS Base
```

Required boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 3.22 Identity and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of identity and principal discipline:

```text
operator-tagged principal-like entities
model/stateful validation
fail-closed rejection paths
JSONL traces
golden fixtures
vFS/service boundaries
AI proposal gating
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime identity, prove deployment security, complete PMS-OS identity handling, complete PMSL/PMS-IR identity handling, or make tests/traces proofs.

PMS-RUST-style identity evidence is useful when it follows the pattern:

```text
runtime-security claim
→ executable slice
→ validation rule
→ golden fixture
→ JSONL trace evidence
→ stated limitation
```

### 3.23 Identity and Claim Boundary

The PMS-STACK identity model is a runtime-security architecture.

It claims:

```text
principals can be represented as operator-governed actor identities
identity can bind roles, capabilities, frames, boundaries, policies,
delegation, revocation, trust mapping, resource accounting, and audit
identity transitions can be analyzed, validated, audited, and enforced
```

It does not claim:

```text
identity equals personhood
principal equals human subject
principal model ranks persons
identity model is clinical, moral, legal, or forensic authority
cryptographic credential alone establishes trust
runtime identity validates PMS Base
implementation artifact proves complete security
```

The model is strong because it is precise: it defines the actor substrate of runtime security without importing unrelated identity claims.

### 3.24 Identity Invariants

Runtime security maintains the following identity invariants.

```text
I1: every principal has a Δ-distinguishable PrincipalID
I2: every active principal has a valid lifecycle state
I3: every active principal has Ω role/capability state
I4: every active principal has a □ frame scope
I5: every active principal has a Χ-projected isolation domain
I6: every active principal has Ψ policy links
I7: every external principal is Φ-mapped before local authority is granted
I8: every capability delegation is Ω/Ψ-governed and Σ-committed
I9: every revocation is Ψ-governed and Σ-committed
I10: every impersonation is Φ-mediated, scoped, policy-checked, and audited
I11: every process/thread principal remains bounded by parent or committed delegated authority
I12: every driver/device principal is confined to assigned frames and capabilities
I13: every session principal has explicit trust, boundary, and expiry state
I14: every principal used in audit has stable actor/effective/provenance identity fields
I15: every identity crossing a boundary is Χ-checked as a projection and Ψ-governed
I16: every key-backed identity is interpreted through Φ under Ψ trust policy
I17: every identity failure has typed Δ/Λ/Ω/Χ/Φ/Σ/Ψ handling
I18: no principal gains authority by identifier alone
I19: no identity fast path bypasses Ω, Χ, Ψ, Φ, or Σ
I20: identity modeling strengthens runtime-security architecture and does not function as PMS Base validation
I21: tooling/AI principals remain advisory unless host validation and runtime policy accept an artifact
I22: PMS-RUST-style artifacts may evidence bounded identity slices; they do not complete runtime identity or validate PMS Base
```

### 3.25 Architectural Consequence

The consequence is:

```text
PMS-STACK identity is not a username, PID, token, or certificate label.
It is an operator-governed runtime actor structure that binds distinction,
authority, frame scope, isolation-domain projection, policy,
recontextualization, commit, trust mapping, resource accounting, and
audit.
```

This gives runtime security a uniform principal model for:

```text
users
services
processes
threads
kernel actors
drivers
devices
containers
network peers
distributed nodes
trust anchors
tooling services
AI proposal services
```

The next section defines the Ω-layer that makes those principals operational: roles, capabilities, authorization, delegation, least privilege, and capability-governed transition control.

### 3.26 Identity and Principal Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK identity and principal model specifies implementation-layer
runtime-security identity architecture: principals, attributes,
capabilities, frame scope, isolation-domain projections, policy links,
provenance, lifecycle, principal classes, identity binding, delegation,
impersonation, revocation, frame-scoped identity, boundary-crossing
identity, distributed identity, trust-anchor interpretation, resource
accounting, audit identity, normal forms, identity algebra, validation,
failure modes, attack handling, tooling/AI boundary violations,
PMS-RUST evidence boundaries, and identity invariants.

This is a runtime-security identity / principal architecture claim.

It does not claim personhood, moral status, psychological identity,
social worth, clinical identity, legal personality, forensic authority,
universal identity truth, completed runtime-security implementation,
complete deployment security, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection, JSONL traces, golden fixtures, vFS/service boundaries, and AI
proposal gating. It does not complete runtime identity and does not
validate PMS Base.
```

---

## 4. Role and Capability System

The role and capability system is the Ω layer of PMS-STACK runtime security.

It defines which principals may perform which operator-typed actions, in which frames, across which boundary projections, under which policies, with which lifetime, and with which commit and audit consequences.

The central Ω claim is:

```text
A PMS-STACK role/capability system is valid when authority is represented
as explicit Ω-typed permission structure over operators, domains, frames,
boundary projections, policies, lifetimes, delegation paths, and commit
states, such that no protected transition can execute unless the active
principal, role, capability, frame, Χ-projected boundary, Ψ policy, and
operator dependency conditions all permit it.
```

Claim type:

```text
RUNTIME-SECURITY ROLE / CAPABILITY ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK roles and capabilities as
implementation-layer runtime-security architecture.

It does not define social status, moral rank, human worth,
organizational hierarchy, legal authority, clinical classification,
forensic authority, or person ranking.

A PMS role is a structural permission descriptor.
A PMS capability is a directed authorization edge over
operator-governed runtime state.

This strengthens the PMS-STACK runtime-security architecture claim.
It does not validate PMS Base.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At runtime-security authorization level, Χ is projected as boundary scope, reachability, isolation, visibility, namespace separation, sandbox/container containment, host boundary, network/session boundary, audit boundary, and trust-boundary control.

Runtime roles and capabilities use this Χ projection. They do not redefine Χ.

### 4.1 Role of Ω in Runtime Security

Ω establishes structured asymmetry.

It answers:

```text
who may act?
which action may be attempted?
against which target?
inside which frame?
across which boundary projection?
under which policy?
for how long?
with which delegation path?
with which commit result?
```

At runtime-security level:

```text
Ω : Principal → AllowedOperatorTransitions
```

or:

```text
Ω(p) = {
    capabilities,
    frame_scope,
    boundary_scope,
    policy_scope,
    transition_rules,
    delegation_rules,
    lifetime_rules
}
```

A runtime action is authorized only when Ω permits the action and Ψ does not forbid it.

```text
authorized(p, action, s) iff
    Ω_allows(p, action, s)
    ∧ Χ_allows(p, action, s)
    ∧ Ψ_allows(p, action, s)
    ∧ frame_valid(p, action, s)
    ∧ dependency_valid(action, s)
```

Ω is therefore necessary but not sufficient.

```text
Ω gives authority.
Χ projection bounds reachability.
Ψ constrains admissibility.
□ supplies context.
Σ commits authority changes.
Θ orders lifetime and expiry checks.
Φ mediates controlled recontextualization.
```

### 4.2 Roles

A role is a structured permission profile.

Specification form:

```text
Role = (
    role_id,
    class,
    capabilities,
    frame_scope,
    isolation_scope,
    policy_scope,
    delegation_rules,
    transition_rules,
    lifetime,
    audit_profile,
    meta
)
```

Minimal form:

```text
role = (
    caps,
    frameScope,
    isoScope,
    policyScope
)
```

where:

| Field | Operator role |
| ----- | ------------- |
| `role_id` | Δ role distinction |
| `class` | Δ role typology |
| `capabilities` | Ω action grants |
| `frame_scope` | □ valid frame range |
| `isolation_scope` | Χ-projected reachable boundary set |
| `policy_scope` | Ψ applicable or modifiable policies |
| `delegation_rules` | Φ/Ω/Σ controlled authority transfer |
| `transition_rules` | Ω/Φ allowed role changes |
| `lifetime` | Θ/τ-governed expiry or scope |
| `audit_profile` | Θ/Σ audit obligations |
| `meta` | implementation/runtime profile data |

A role is not equivalent to a principal.

```text
Principal  = actor identity
Role       = structural authority mode
Capability = directed action permission
```

A principal may hold one or more roles. A role may be assigned to many principals. A capability may be contained by a role, delegated from a role, scoped to a frame, or granted temporarily under policy.

### 4.3 Role Classes

PMS-STACK may define canonical role classes.

These are architecture profiles, not exhaustive implementation requirements.

#### User Role

```text
Role.USER = (
    minimal user capabilities,
    user/process frame scope,
    user isolation domain,
    user policy constraints
)
```

Typical permissions:

```text
execute user code
read/write permitted user namespace
invoke allowed syscalls
use assigned IPC endpoints
spawn processes within quota
read allowed audit/debug surfaces
```

Forbidden by default:

```text
modify kernel policy
access kernel frames
access devices directly
grant itself capabilities
cross container/sandbox boundary
perform privileged syscalls without mediation
```

A user role is a computational authorization profile. It is not a social, moral, clinical, or legal category.

#### Service Role

A service role belongs to a long-running runtime service.

Typical permissions:

```text
bind service endpoint
receive service IPC
access service namespace
write service logs
manage service-local state
spawn service workers
perform policy-scoped network operations
```

Service roles should be decomposed into micro-roles where possible:

```text
role_service_recv
role_service_send
role_service_store
role_service_admin_limited
```

#### Process Role

A process role is attached to an execution context.

It includes:

```text
memory permissions
syscall permissions
file/IPC permissions
scheduler class
resource-accounting class
local policy links
```

The process role is usually derived from a user or service principal and constrained by process isolation.

#### Kernel Role

The kernel role is privileged and invariant-bound.

It may:

```text
create/destroy frames
manage roles and capabilities
install/update policies
handle traps and syscalls
schedule threads
commit global state
quarantine subsystems
revoke authority
```

But kernel authority is not operator-free.

Kernel actions must preserve:

```text
capability correctness
frame isolation
policy integrity
safe recontextualization
commit validity
auditability
```

The kernel role is powerful because it mediates global runtime structure. It remains Ψ-bound.

#### Supervisor Role

A supervisor role is a restricted privileged role.

It may:

```text
restart services
quarantine processes
rotate service capabilities
inspect limited traces
manage policy-scoped runtime configuration
```

It may not automatically:

```text
rewrite kernel invariants
access arbitrary kernel memory
grant root-like capabilities
bypass audit
bypass trust-anchor policy
```

Supervisor roles are useful for runtime governance without uncontrolled kernel equivalence.

#### Driver Role

A driver role is device-scoped.

It grants capabilities such as:

```text
read/write assigned MMIO region
ack assigned interrupt
map assigned DMA region
reset assigned device
emit driver event
bind/unbind assigned device frame
```

It should not grant:

```text
arbitrary kernel memory access
unbounded DMA
policy mutation outside driver scope
general filesystem/network access
self-escalation
```

Driver role structure:

```text
DriverRole = (
    driver_frame,
    device_frames,
    MMIO_scope,
    DMA_scope,
    interrupt_scope,
    driver_policy,
    quarantine_policy
)
```

#### Device Role

A device role represents authority of or over a device principal.

It is used for:

```text
device authentication
firmware validation under declared trust profile
driver binding
device event emission
resource accounting
device-specific audit
```

Device roles are tightly Χ-bounded because hardware or virtual device behavior may affect memory, interrupts, IO, and trust anchors.

#### Container / Sandbox Role

A sandbox role is a contracted authority profile.

It typically includes:

```text
restricted namespace
restricted syscalls
restricted filesystem
restricted network
restricted IPC
reduced capabilities
strong audit profile
resource quota
```

Sandbox role rule:

```text
sandbox_role ⊑ parent_role
```

unless a privileged, policy-governed recontextualization explicitly states otherwise.

A sealed isolation context forbids further entry, expansion, or reachability growth.

It still permits valid exit, closure, audit, rollback, or commit under the declared policy and active boundary context.

Sealing is not the same as trapping execution forever.

#### Network Session Role

A network session role is bound to a connection or remote identity mapping.

It may include:

```text
send/receive on session channel
use negotiated cryptographic context
access service endpoint
use rate-limited protocol operations
emit session audit records
```

It is created through:

```text
Δ credential classification
Φ remote-to-local identity mapping
Ψ trust policy evaluation
Ω local capability assignment
Χ projected session boundary
Σ session commit
```

#### Distributed Node Role

A distributed node role is used in multi-node systems.

Possible capabilities:

```text
participate in quorum
replicate state
propose commit
vote on global transition
forward messages
accept cluster policy update
emit node audit hash
```

This role belongs primarily to `07_distributed_systems.md`; runtime security defines the local authorization form.

Distributed markers in this section are boundary-facing references to distributed profiles. They do not make this section the distributed-system specification.

#### Tooling / AI Role

A tooling role may allow:

```text
read redacted trace
request static analysis
propose PMS-IR
run simulation
summarize diagnostics
compare golden fixtures
draft candidate test fixtures
```

It must not by default allow:

```text
execute proposed artifact
grant capability
modify policy
commit runtime state
replace verifier
replace policy evaluation
bypass redaction
serve as trusted executable code
serve as compiler authority
serve as verification evidence
validate PMS Base
```

Tooling roles are advisory unless promoted through explicit Ω/Ψ/Σ authority.

The standard AI/tooling boundary is:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 4.4 Capabilities

A capability is a directed permission edge.

Specification form:

```text
Capability = (
    cap_id,
    subject,
    op,
    action,
    target,
    domain,
    scope,
    constraints,
    lifetime,
    delegation,
    commit_profile,
    audit_profile,
    meta
)
```

Minimal form:

```text
cap = (op, domain, params)
```

or OS-oriented form:

```text
Capability = (subject, action, target, scope, constraints)
```

A capability says:

```text
subject may attempt action on target within scope under constraints.
```

It does not say:

```text
the action must succeed.
```

Success still depends on:

```text
frame validity
boundary reachability
policy approval
resource state
runtime profile support
absence/trap behavior
commit validity
```

### 4.5 Capability Fields

#### `cap_id`

```text
cap_id: CapabilityID
```

A Δ-distinguishable identifier for audit, revocation, delegation, caching, and diagnostics.

#### `subject`

```text
subject: Principal | Role | Group | Session | Module | Device
```

The subject that holds or may exercise the capability.

#### `op`

```text
op ∈ { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The operator class governed by the capability.

Examples:

```text
Δ.resolve(Path)
∇.write(FileFrame)
□.enter(ModuleFrame)
Ω.grant(Capability)
Θ.schedule(Task)
Φ.enter(KernelFrame)
Χ.cross(NetworkBoundary)
Σ.commit(Transaction)
Ψ.update(Policy)
```

#### `action`

Concrete action within the operator class.

Examples:

```text
read
write
execute
map
send
receive
bind
listen
connect
grant
revoke
delegate
enter
exit
commit
rollback
install_policy
rotate_key
emit_audit
inspect_trace
```

#### `target`

The object or domain affected.

Examples:

```text
FileFrame
PathPrefix("/var/log/**")
KernelFrame
DeviceFrame(dev0)
MMIORegion(dev0.regs)
Channel(inbox)
NetworkEndpoint(serviceA)
Policy(P_write)
TrustAnchor(rootA)
AuditLog(security)
RuntimeProfile(debug)
```

#### `scope`

The valid range of the capability.

Scope may be:

```text
frame-scoped
process-scoped
thread-scoped
task-scoped
module-scoped
session-scoped
container-scoped
device-scoped
path-scoped
endpoint-scoped
node-scoped
time-scoped
one-shot
transaction-scoped
```

#### `constraints`

Constraints refine use.

Examples:

```text
read-only
write-only
append-only
path prefix
max bytes
rate limit
allowed protocol
allowed method
no delegation
audit required
requires durable commit
requires redaction
requires isolation boundary
requires policy approval
expires at τ_ref
```

#### `lifetime`

Capabilities may expire.

```text
lifetime = (
    start,
    expiry,
    revocation_ref,
    use_count?,
    transaction?,
    session?
)
```

Lifetime is checked through Θ-ordered evaluation over τ metadata.

```text
Θ orders checks.
τ stores expiry/reference data.
Ψ decides validity.
Σ commits revocation or renewal.
```

#### `delegation`

Delegation rules state whether the capability may be passed, attenuated, derived, or proxied.

```text
delegation = none | attenuate_only | explicit_policy | transferable | one_shot
```

#### `commit_profile`

Authority changes are security-relevant commits.

Examples:

```text
Σ_local
Σ_session
Σ_audit
Σ_durable
Σ_cluster
```

#### `audit_profile`

Audit profile states what must be recorded.

Examples:

```text
no_audit
audit_on_use
audit_on_grant
audit_on_denial
audit_all
audit_durable
audit_redacted
```

A high-value capability usually requires audit on grant, use, denial, and revocation.

### 4.6 Capability Domains

Capability domains may include:

```text
memory
filesystem
IPC
network
device
driver
module
runtime
policy
audit
trust-anchor
key-frame
scheduler
resource-account
FFI/host
debugging/tooling
distributed-node
```

Examples:

```text
cap_fs_read_logs =
    (∇, filesystem, read, target="/var/log/**")

cap_fs_write_audit =
    (∇, filesystem, append, target="/var/audit/**", audit=required)

cap_ipc_send_orders =
    (∇, IPC, send, target=Channel("orders"))

cap_net_connect_cluster =
    (∇, network, connect, target="cluster.internal:443")

cap_driver_mmio_write =
    (∇, device, write, target=MMIORegion(dev0.regs))

cap_policy_update_local =
    (Ψ, policy, update, target=PolicyScope(process_local))

cap_trace_read_redacted =
    (Δ/∇, audit, inspect, target=Trace(process), constraints=redacted)

cap_ai_propose_ir =
    (∇, tooling, propose, target=PMSIRFragment, constraints=advisory_only)
```

The `cap_ai_propose_ir` capability permits advisory proposal, not execution.

```text
propose_ir capability
≠ execute_ir capability
```

### 4.7 Authorization Predicate

Authorization is the runtime evaluation of role/capability validity.

Canonical predicate:

```text
id ▷ action(params)
```

is true iff all hold:

```text
1. principal is valid
2. role is active
3. capability exists
4. capability covers operator/action/target
5. frame scope contains target context
6. Χ projection permits reachability
7. Ψ policy permits action
8. capability lifetime is valid
9. delegation chain is valid if delegated
10. operator dependency preconditions hold
11. runtime profile supports action
```

Formal sketch:

```text
authorized(id, op, target, s) iff
    active(id, s)
    ∧ ∃ role ∈ roles(id, s)
    ∧ ∃ cap ∈ caps(role, id, s)
    ∧ cap.op = op
    ∧ target ∈ cap.domain
    ∧ params_satisfy(cap.constraints)
    ∧ frame(target) ∈ frameScope(role)
    ∧ Χ_allows(id, target, s)
    ∧ Ψ_allows(id, op, target, s)
    ∧ lifetime_valid(cap, Θ, τ, s)
    ∧ dependency_valid(op, s)
```

Authorization failure is typed:

```text
invalid principal      → Δ / Ψ
inactive role          → Ω / Ψ
missing capability     → Ω
target outside scope   → Ω / □
boundary denial        → Χ / Ψ
policy denial          → Ψ
expired capability     → Θ / Ψ
invalid delegation     → Ω / Ψ / Φ
unsupported profile    → Λ / Φ / Ψ
invalid dependency     → Δ / Ψ
```

### 4.8 Capability Lattice

Capabilities form a partial order.

```text
cap_a ⊑ cap_b
```

iff:

```text
op_a = op_b
∧ domain_a ⊆ domain_b
∧ params_a ⊆ params_b
∧ constraints_a are equal or stricter
∧ lifetime_a ≤ lifetime_b
∧ delegation_a ≤ delegation_b
```

Examples:

```text
fs.read("/var/log/app.log")
    ⊑ fs.read("/var/log/**")
    ⊑ fs.read("/**")

net.connect("serviceA:443")
    ⊑ net.connect("*.internal:443")
    ⊑ net.connect("*")
```

Least privilege means selecting the smallest sufficient capability.

Capability join:

```text
cap_join = cap_a ⊔ cap_b
```

is permitted only if policy allows combined authority.

Capability meet:

```text
cap_meet = cap_a ⊓ cap_b
```

is safe when it restricts authority.

Default rule:

```text
narrowing is safe
widening requires Ω/Ψ authorization and Σ commit
```

### 4.9 Role Composition and Decomposition

Roles may be composed from micro-roles.

```text
role = ⋃ role_i
```

Example service role:

```text
role_order_service =
    role_net_recv_orders
    ∪ role_net_send_confirmations
    ∪ role_fs_append_service_log
    ∪ role_trace_emit_redacted
```

Micro-role benefits:

```text
least privilege
audit clarity
delegation control
easier revocation
clearer diagnostics
safer sandboxing
smaller attack surface
```

Role decomposition rule:

```text
effective_caps(role) = union of caps(role_i)
```

subject to:

```text
Ψ composition policy
Χ boundary constraints
frame compatibility
lifetime constraints
delegation rules
```

A composed role must not create implicit authority not present in its components unless explicitly granted by policy.

### 4.10 Role Transitions

Role transitions are Ω transformations.

```text
id' = Ω(id, Δcaps, ΔframeScope, ΔisoScope, ΔpolicyScope)
```

Role transition kinds:

```text
grant
revoke
attenuate
elevate
de-escalate
delegate
impersonate
session-bind
sandbox-enter
kernel-enter
driver-bind
node-admit
quarantine
restore
```

A valid role transition requires:

```text
Δ classify transition
Ω verify transition authority
□ check source and target frames
Χ check boundary-projection effect
Ψ evaluate transition policy
Φ mediate interpretation shift if role meaning changes
Σ commit new role state
Θ audit ordering
```

Default role transition law:

```text
dropping authority may be local
adding authority requires explicit Ω/Ψ/Σ path
```

Privilege escalation rule:

```text
higher_role(id') > higher_role(id)
    ⇒ transition must be kernel-mediated or policy-authorized
       and Φ/Σ-represented
```

No user process may directly become kernel.

No driver may silently acquire broader authority than its driver profile.

No tooling service may promote advisory output into executable authority without host validation, policy acceptance, and runtime acceptance.

### 4.11 Grant, Revoke, Attenuate

#### Grant

Granting capability:

```text
Ω.grant(subject, capability)
```

requires:

```text
grantor has grant authority
capability is grantable
subject may hold capability
policy permits grant
boundary permits target scope
grant is committed
audit occurs if required
```

Operator sequence:

```text
Δ classify grant
Ω verify grantor authority
Ψ check grant policy
Χ check scope/boundary projection
Ω attach capability
Σ commit grant
Θ audit event
```

#### Revoke

Revocation:

```text
Ω.revoke(subject, capability)
```

requires:

```text
revoker authority
policy basis
live-use handling
commit of new authority state
audit
```

Operator sequence:

```text
Δ classify revocation
Ψ evaluate revocation policy
Ω remove capability
Φ recontextualize active operations if needed
Χ restrict projected boundary if needed
Σ commit revocation
Θ audit event
```

#### Attenuate

Attenuation narrows authority.

```text
cap' ⊑ cap
```

Examples:

```text
fs.read("/**") → fs.read("/home/app/**")
net.connect("*") → net.connect("api.internal:443")
debug.trace(all) → debug.trace(redacted)
```

Attenuation is the preferred delegation form.

### 4.12 Delegation

Delegation transfers authority under policy.

```text
delegate(P_src, P_dst, cap, scope, constraints)
```

Delegation is valid iff:

```text
P_src holds cap
∧ cap is delegable
∧ P_src has delegation authority
∧ P_dst may hold cap
∧ delegated cap is not broader than source cap
∧ Ψ permits delegation
∧ delegation is committed
∧ audit requirements are satisfied
```

Operator sequence:

```text
Δ classify delegation
Ω verify source authority
Ψ check delegation policy
Φ recontextualize destination authority context
Ω attach attenuated capability to destination
Σ commit delegation
Θ audit delegation
```

Delegation types:

```text
one-shot delegation
session delegation
task delegation
process delegation
module delegation
service-to-service delegation
network delegation
driver delegation
debug delegation
```

Delegation must preserve provenance:

```text
cap.delegated_from = source_principal
cap.delegation_chain = [...]
```

Delegation without provenance becomes an audit and revocation weakness.

### 4.13 Impersonation and On-Behalf-Of Authority

Impersonation is not ordinary delegation.

It is a Φ-mediated identity/role recontextualization.

```text
impersonate(P_actor, P_represented, scope)
```

requires:

```text
Ω impersonation capability
Ψ on-behalf-of policy
scope limitation
audit attribution
Σ committed impersonation context
```

The audit record must distinguish:

```text
actor_principal
effective_principal
represented_principal
delegation source
scope
policy
```

Rule:

```text
impersonation must never erase the actor.
```

It may create an effective authority context, but audit must preserve both the actor and represented identity.

Impersonation is a computational runtime-security construct. It is not personhood transfer, moral substitution, or legal representation unless an external legal framework separately defines such a relation.

### 4.14 Lifetime-Bound Roles and Capabilities

Roles and capabilities may be lifetime-bound.

Examples:

```text
temporary admin window
session-scoped network key
one-shot file write
debug trace for 10 minutes
driver update mode
cluster maintenance role
AI proposal session
```

Lifetime form:

```text
Ω.grant(cap, expiry_ref ∈ τ)
```

Interpretation:

```text
τ stores expiry metadata.
Θ orders checks.
Ψ determines expiry policy.
Σ commits revocation or renewal.
```

Runtime check:

```text
valid_lifetime(cap, s) iff
    τ.now < cap.expiry
    ∧ cap.revoked = false
    ∧ policy_allows_current_use
```

Expiry event:

```text
Θ check expiry
Ψ decide invalidation
Ω revoke capability
Σ commit revocation
Θ audit expiry
```

Lifetime-bound authority prevents permanent broad privileges.

### 4.15 Frame-Scoped Authority

Capabilities are frame-scoped.

A capability valid in one frame may be invalid in another.

Example:

```text
cap_fs_write_log
    valid inside ServiceFrame(LogService)
    invalid inside ForeignFrame(host_tool)
```

Frame-scoped check:

```text
frame(target) ∈ frameScope(role)
```

Frame entry may:

```text
narrow capabilities
activate additional policy
create handler-specific authority
enable local resource authority
```

Frame exit must:

```text
drop frame-local capabilities
close or transfer frame-local resources
commit or rollback authority state
audit scoped authority if required
```

Frame-scoped authority is essential for:

```text
kernel entry
module calls
FFI calls
handler execution
transactions
debugging sessions
tooling sessions
network sessions
```

### 4.16 Boundary-Scoped Authority

Capabilities are boundary-scoped.

A capability may permit an action only if Χ projection permits the target relation.

Example:

```text
cap_channel_send(C)
```

does not allow sending if:

```text
sender boundary cannot reach receiver endpoint
```

Boundary-scoped check:

```text
Χ_allows(source, target, boundary_relation)
```

Examples:

```text
process boundary
module boundary
driver/device boundary
host/FFI boundary
network boundary
container boundary
distributed node boundary
audit boundary
tooling boundary
```

Boundary rule:

```text
Ω grants authority to attempt.
Χ projection determines whether the target is reachable.
Ψ decides whether this attempt is admissible.
```

### 4.17 Policy-Scoped Authority

Policy may restrict, transform, or revoke capability use.

Examples:

```text
capability allows FS.write("/var/log/**")
policy denies writes after quota exceeded

capability allows Net.connect("serviceA")
policy denies plaintext connection

capability allows debug.trace(ProcessX)
policy requires redaction

capability allows policy.update(local)
policy denies relaxation of inherited policy
```

Authorization therefore includes:

```text
Ω capability check
∧ Ψ policy check
```

Policy may also modify operations:

```text
rewrite path
downgrade capability
force redaction
force audit
require approval
quarantine on violation
```

Policy-scoped authority prevents capability tables from becoming the final runtime-governance layer.

### 4.18 Syscall and Kernel Capability Checks

Syscalls are canonical capability checks.

Syscall flow:

```text
Φ enter kernel
Ω switch to kernel role
□ enter kernel frame
Δ classify syscall
Ω check caller capability
Χ check target boundary projection
Ψ evaluate syscall policy
∇ / □ / Χ / Θ / Σ perform kernel operation
Σ commit result if needed
Φ return
```

Example:

```text
write(fd, buf, len)
```

requires:

```text
capability to write fd
frame visibility of fd and buffer
boundary reachability of file/socket/pipe
policy permission
resource quota
commit profile
```

Syscall authority is not established by reaching the kernel. Kernel entry is a Φ transition that enables mediation. It does not grant arbitrary authority to the caller.

This syscall capability-check sequence is a runtime-security enforcement view.

It does not redefine the PMS-OS syscall ABI specified in `04_pms_os.md`, and it does not replace the PMS-CPU trap/control-transfer convention specified in `03_pms_cpu.md`.

The PMS-OS syscall contract remains:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

### 4.19 Driver and Device Capabilities

Driver capabilities are narrowly scoped.

Examples:

```text
Ω(read, DeviceRegister(dev0.status))
Ω(write, DeviceRegister(dev0.control))
Ω(ack, IRQ(dev0.irq))
Ω(dma_map, DMARegion(dev0.buffer))
Ω(reset, Device(dev0))
Ω(bind, DriverFrame(dev0_driver))
```

Driver capability invariants:

```text
driver may touch only assigned device frames
driver MMIO scope is explicit
DMA regions are explicit frames
interrupt authority is explicit
driver cannot grant itself new device authority
driver cannot access arbitrary kernel memory
driver quarantine revokes or suspends driver capabilities
```

Device capability failure may produce:

```text
Φ trap
Χ quarantine
Ω revoke capability
Σ cleanup
Ψ halt if critical
```

### 4.20 Network and Distributed Capabilities

Network capabilities govern session and endpoint authority.

Examples:

```text
Ω(net.connect, Endpoint("api.internal:443"))
Ω(net.listen, Endpoint("service.local:8443"))
Ω(net.send, Session(s))
Ω(net.recv, Session(s))
Ω(node.vote, QuorumGroup(g))
Ω(cluster.commit_propose, StatePartition(p))
```

Network capability validation includes:

```text
remote principal mapped
session boundary established
trust policy satisfied
protocol policy satisfied
rate/quota policy satisfied
audit profile satisfied
```

Distributed capabilities additionally require:

```text
node identity
cluster role
quorum policy
global commit profile
cross-node audit
trust-anchor state
```

A remote principal does not gain local capability until mapped and committed through the local runtime-security model.

Network and distributed capabilities in this section describe runtime-security authorization surfaces. They do not complete a network stack, transport implementation, cryptographic library, distributed consensus algorithm, cluster policy synchronization, global commit protocol, or multi-node failure semantics.

Those belong to `07_distributed_systems.md` and declared distributed runtime profiles.

### 4.21 FFI, Host, Debug, and Tooling Capabilities

Host and tooling capabilities require strong boundaries.

#### FFI / Host

Examples:

```text
Ω(host.call, HostService(clock))
Ω(host.read, HostPath("/tmp/pms/**"))
Ω(host.invoke, ForeignSymbol("crypto_sign"))
```

Checks:

```text
ForeignFrame exists
host boundary is declared
memory transfer profile exists
host error map exists
policy permits call
result commit profile is known
audit if required
```

A host capability does not make host runtime behavior equivalent to PMS-OS.

#### Debugging

Examples:

```text
Ω(debug.trace, Process(pid), redacted)
Ω(debug.inspect, Frame(fid))
Ω(debug.break, Operator(Ψ))
Ω(debug.snapshot, RuntimeState)
```

Debug authority is highly sensitive.

It must respect:

```text
observer role
audit visibility boundary
redaction policy
runtime profile
target process policy
```

#### AI / Tooling

Examples:

```text
Ω(tool.ai.propose_ir, AdvisoryOnly)
Ω(tool.trace.summarize, RedactedTrace)
Ω(tool.simulate, PMSIRProgram)
```

Tooling authority may permit proposal, inspection, explanation, simulation request, or trace analysis. It must not imply execution, policy authority, verification authority, trusted executable code, runtime commit, or PMS Base validation.

```text
propose_ir capability
≠ execute_ir capability

trace_summarize capability
≠ verification authority

fixture_draft capability
≠ proof artifact
```

AI/tooling may propose PMS-IR, summarize traces, explain diagnostics, suggest missing policies, suggest scenarios, or draft test fixtures.

AI/tooling may not authorize execution, define semantics, replace policy evaluation, replace verification, grant capabilities, commit runtime state, or validate PMS Base.

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 4.22 Capability Commit and Storage

Capabilities are security state.

Grant, revoke, delegate, attenuate, and renew operations must be commit-governed.

Capability state may be stored in:

```text
kernel capability table
process descriptor
principal record
session record
module metadata
driver binding table
network session table
trust-anchor state
audit record
```

Capability mutation sequence:

```text
Δ classify mutation
Ω verify mutation authority
Ψ evaluate mutation policy
Χ check target boundary/scope projection
∇ update capability state
Σ commit mutation
Θ audit mutation
```

A capability mutation is not stable until Σ commits it.

Rollback or failure must leave authority state coherent.

### 4.23 Capability Audit

Capability use, denial, delegation, and revocation may be audit-relevant.

Audit record:

```text
CapabilityAuditEvent = (
    event_id,
    order,
    actor_principal,
    effective_role,
    capability,
    action,
    target,
    frame,
    boundary,
    policy,
    decision,
    result,
    delegation_chain?,
    commit_state,
    meta
)
```

Audit-required events:

```text
privilege elevation
policy mutation
key use
trust-anchor rotation
driver/device access
host/FFI call
debug inspection
network session establishment
distributed quorum action
capability delegation
capability revocation
capability denial on protected target
```

Audit flow:

```text
Δ classify authority event
Θ order event
Ω record role/capability state
Χ record projected boundary context
Ψ record policy decision
Σ commit audit if required
```

Audit records are runtime-security evidence artifacts.

They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

A concrete runtime-security capability trace produces:

```text
trace_runtime(runtime, authority_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security capability traces under a declared profile is:

```text
Trace_runtime(runtime, authority_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

Traces record observed executions. They do not prove all possible executions unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

### 4.24 Capability Failure and Attack Handling

Capability failures are typed.

| Failure | Operator reading |
| ------- | ---------------- |
| no capability | Ω denial |
| capability expired | Θ/Ψ denial |
| capability outside frame | □/Ω denial |
| capability outside boundary | Χ projection / Ω / Ψ denial |
| policy denies despite capability | Ψ denial |
| delegation invalid | Ω/Ψ/Φ |
| role escalation invalid | Ω/Ψ/Φ |
| capability table corrupt | Δ/Ψ/Φ |
| commit failure after grant | Σ/Φ |
| audit required but unavailable | Σ/Ψ/Φ |
| unsupported capability domain | Λ/Φ/Ψ |

Attack words describe attempted operator sequences.

They do not assert that the attack succeeds. Runtime security identifies the failed obligation: Δ classification, Ω authority, □ frame validity, Χ boundary projection, Ψ policy, Φ recontextualization, Σ commit, or Θ ordering.

#### Unauthorized Privilege Escalation

```text
w =
    Δ_target_role
    ; ∇_request_role(root)
    ; Ω_elevate
```

Response:

```text
Ω denies transition
Ψ enforces monotonicity
Φ traps into violation context
Σ commits audit
```

#### Capability Smuggling

```text
w =
    Δ_message
    ; ∇_send(capability_payload)
    ; Σ_delivery
```

Response:

```text
Δ detects capability-bearing payload
Ω checks transfer authority
Χ checks endpoint boundary projection
Ψ denies or attenuates
Φ strips/traps if required
Σ audits decision
```

#### Driver Overreach

```text
w =
    Δ_mmio_region
    ; ∇_write(unassigned_region)
```

Response:

```text
Ω denies MMIO write
Χ blocks device boundary projection
Ψ triggers driver policy
Φ enters driver fault handler
Χ quarantine if repeated/critical
Σ commits audit/cleanup
```

#### Debug Bypass

```text
w =
    Δ_trace_target
    ; ∇_inspect(secret_frame)
```

Response:

```text
Ω checks debug.inspect
Χ checks audit/debug visibility projection
Ψ applies redaction or denial
Σ commits audit-read event if allowed
```

#### AI/Tooling Boundary Violation

```text
w =
    Δ_ai_output
    ; ∇_execute(proposed_ir)
    ; Σ_runtime_commit
```

Response:

```text
Δ classifies tooling artifact
Ω checks tooling capability
Χ enforces tooling/host boundary
Ψ denies execution authority
Φ recontextualizes as violation if needed
Σ commits audit/rejection record
```

A successful rejection shows that a specific attempted transition was blocked under a declared profile. It is not a universal proof that all variants are blocked.

### 4.25 Role/Capability Static and Runtime Checks

Static checks should verify:

```text
declared capabilities cover protected API calls
exported modules expose required capabilities
FFI calls declare host capabilities
debug/tooling calls declare observer authority
role transitions are declared
capability lifetimes are represented
delegation policies are present
```

Runtime checks should verify:

```text
active principal
active role
active capability
current frame
boundary relation
active policy
runtime profile
lifetime state
resource state
commit state
```

Validation in this section means acceptance or rejection under a declared runtime-security schema, role/capability model, policy, hook, profile, artifact, or conformance rule.

It does not mean external validation of PMS Base.

Model checking may verify stated properties under a declared model/profile, such as:

```text
no protected action occurs without capability
no policy mutation occurs outside kernel-governed role
no driver reaches unassigned MMIO frame
no user reaches kernel frame without Φ entry
no delegated capability exceeds source authority
no expired capability remains usable
```

Proof artifacts prove stated properties under formal assumptions. Tests check. Traces record. Validators accept or reject under profile.

### 4.26 Role and Capability Reports

Tooling may emit role/capability reports.

Report form:

```text
AuthorityReport = (
    principal,
    active_roles,
    effective_capabilities,
    frame_scope,
    boundary_scope,
    policy_scope,
    delegation_chain,
    lifetime_state,
    denied_attempts,
    audit_profile,
    meta
)
```

Useful views:

```text
capabilities by principal
capabilities by resource
capabilities by frame
capabilities by boundary
capabilities by role
delegation graph
revocation graph
high-risk capability list
expired capability list
unused broad capability list
policy-denied capability use
```

Lint examples:

```text
lint[Ω]:
    role has fs.write("/**") but observed calls use only "/var/log/**".
    Consider narrowing capability.

lint[Ω/Χ]:
    driver role can access device frame but boundary policy lacks DMA region constraint.

lint[Ω/Ψ]:
    debug role permits full trace inspection without redaction policy.
```

Reports are evidence surfaces and inspection artifacts. They are not forensic truth or PMS Base validation.

### 4.27 Role and Capability PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of role/capability discipline:

```text
operator-tagged execution
model/stateful validation
fail-closed rejection paths
JSONL traces
golden fixtures
vFS service boundaries
AI proposal gating
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime security, prove deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, or make tests/traces proofs.

PMS-RUST-style authority evidence is useful when it follows the pattern:

```text
runtime-security claim
→ executable slice
→ validation rule
→ golden fixture
→ JSONL trace evidence
→ stated limitation
```

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where a capability or boundary rule requires active isolation context before exit.

It does not redefine PMS Base Χ, complete PMS-OS isolation, or validate PMS Base.

### 4.28 Claim Boundary

The role and capability system claims:

```text
authority can be represented as explicit Ω-typed runtime structure
capabilities can be scoped, delegated, revoked, audited, validated,
checked statically, checked dynamically, and verified against stated
properties under declared models/profiles
roles can be decomposed into least-privilege micro-roles
protected transitions can be blocked before execution
```

It does not claim:

```text
all possible security policies are complete
capabilities alone make a system secure
kernel privilege is unconstrained
host runtime behavior is equivalent to PMS-OS
tests or traces prove security
PMS-RUST artifacts validate PMS Base
runtime roles define social or moral hierarchy
runtime roles define legal or forensic authority
tooling or AI output is trusted executable code
tooling or AI output is verification evidence
```

The model is strong because it is bounded: it defines executable authority structure without converting authority into a non-typed global trust assumption.

### 4.29 Role and Capability Invariants

Runtime security maintains the following Ω invariants.

```text
I1: every active principal has at least one active role or an explicit no-authority state
I2: every protected action requires an Ω capability basis
I3: every capability has an operator class, action, target, scope, and constraints
I4: every capability use occurs inside a valid □ frame
I5: every boundary-sensitive capability is Χ-checked as an implementation-layer projection
I6: every policy-sensitive capability is Ψ-checked
I7: every authority-widening transition is Ω/Ψ-authorized and Σ-committed
I8: every authority-narrowing transition preserves audit where required
I9: every delegation is scoped, provenance-preserving, and policy-governed
I10: every impersonation is Φ-mediated and audit-distinguishable from direct action
I11: every lifetime-bound capability is Θ/τ-checkable and Ψ-revocable
I12: every kernel role action preserves kernel invariants
I13: every driver/device capability is confined to assigned frames and boundaries
I14: every network/distributed capability follows local identity mapping before authority assignment
I15: every host/FFI capability crosses a declared ForeignFrame or HostService boundary
I16: every debug/tooling capability respects redaction, boundary, and policy rules
I17: every capability grant, revocation, delegation, and role transition has a Σ commit profile
I18: every high-value capability use is Θ-ordered and audit-representable
I19: no authority fast path bypasses Ω, Χ, Ψ, Φ, or Σ
I20: role/capability evidence strengthens runtime-security implementation claims and does not function as PMS Base validation
I21: AI/tooling roles remain advisory unless host validation, runtime acceptance, and Ψ-governed policy permit a specific artifact
I22: PMS-RUST-style artifacts may evidence bounded role/capability slices; they do not complete runtime security or validate PMS Base
```

### 4.30 Architectural Consequence

The consequence is:

```text
PMS-STACK roles and capabilities are not flat permissions. They are
operator-typed authority structures that bind principals to allowed
transitions across frames, boundary projections, policies, lifetimes,
delegation paths, commits, audits, and runtime profiles.
```

This gives runtime security a uniform authorization model for:

```text
kernel privilege
syscalls
processes
threads
modules
standard-library APIs
filesystems
IPC
network sessions
drivers
devices
FFI and host calls
debugging
tooling
AI proposal services
distributed nodes
trust-anchor operations
policy mutation
audit access
```

The next section uses this Ω model to define the isolation model: how Χ projects PMS Base Distance into runtime boundaries, reachability constraints, containment, sandboxing, quarantine, namespace separation, and protection domains.

### 4.31 Role and Capability Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK role and capability system specifies implementation-layer
runtime-security authority architecture: roles, capabilities, role
classes, capability domains, authorization predicates, capability
lattices, role composition, role transitions, grants, revocations,
attenuation, delegation, impersonation, lifetime-bound authority,
frame-scoped authority, boundary-scoped authority, policy-scoped
authority, syscall and kernel checks, driver/device capabilities,
network and distributed capabilities, FFI/host/debug/tooling
capabilities, capability commit/storage, audit, failure handling,
static/runtime checks, reports, PMS-RUST evidence boundaries, and
Ω-invariants.

This is a runtime-security role / capability architecture claim.

It does not claim completed runtime-security implementation, universal
security certification, complete deployment security, social hierarchy,
moral hierarchy, legal authority, forensic authority, AI/tooling
authority, proof of all security properties, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection, JSONL traces, golden fixtures, vFS/service boundaries, and AI
proposal gating. It does not complete runtime security and does not
validate PMS Base.
```

---

## 5. Isolation Model

The isolation model is the Χ layer of PMS-STACK runtime security.

At PMS Base level:

```text
Χ = Distance
```

At PMS-STACK runtime-security level, Χ is projected into implementation structures:

```text
boundary
isolation
visibility
reachability
namespace separation
memory separation
process containment
module separation
host boundary
network/session boundary
device boundary
audit visibility boundary
quarantine
```

The central isolation claim is:

```text
A PMS-STACK isolation model is valid when every protected domain is
represented as a □-framed context whose visibility, reachability,
crossing rules, transfer paths, authority requirements, policy
constraints, trap behavior, commit effects, and audit obligations are
Χ-explicit as implementation-layer projections and enforceable at
runtime.
```

Claim type:

```text
RUNTIME-SECURITY ISOLATION / Χ-PROJECTION ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies the PMS-STACK runtime-security isolation model.

It is an implementation-layer projection of PMS Base Χ = Distance into
runtime boundaries, reachability constraints, containment, sandboxing,
namespace separation, device separation, host boundaries, audit
visibility, quarantine, and protection domains.

It does not redefine PMS Base Χ.
It does not claim completed kernel isolation, completed sandboxing,
completed container runtime, completed host isolation, completed network
security, completed distributed isolation, side-channel elimination, or
PMS Base validation.
```

Runtime isolation uses Χ projection. It does not replace Ω authority, Ψ policy, □ framing, Φ recovery, Σ commit, or Θ ordering.

### 5.1 Isolation as Χ over □ Contexts

Isolation applies to frames.

A runtime frame may represent:

```text
address space
process
thread/task context
module
kernel context
driver context
device region
filesystem namespace
IPC endpoint
network session
container
sandbox
foreign host context
audit view
trust-anchor store
```

Core form:

```text
χ_runtime : □_i → (□_i, □_j)_isolated
```

Meaning:

```text
frame □_i is placed into a relation with frame □_j such that
visibility, reachability, transfer, and action rules are constrained.
```

Here `χ_runtime` denotes an implementation-layer projection. It is not the PMS Base operator Χ itself.

A process, for example, is not merely a PID. It is:

```text
Process = (
    frame_set,        ; □
    role_state,       ; Ω
    isolation_domain, ; Χ projection
    local_policy,     ; Ψ
    resource_account,
    lifecycle
)
```

Isolation governs:

```text
what this process can see
what it can address
what it can call
what it can receive
what it can transfer
what it can map
what it can commit
what it can observe
```

### 5.2 Isolation Is Not Secrecy Alone

Isolation is broader than confidentiality.

It includes:

```text
memory visibility
namespace reachability
syscall reachability
IPC reachability
network reachability
module access
device access
debug visibility
audit visibility
resource containment
scheduler influence
fault containment
commit containment
trust-anchor containment
```

Isolation may serve:

```text
confidentiality
integrity
availability
fault containment
least privilege
determinism
audit separation
distributed trust separation
runtime hardening
```

Therefore:

```text
isolation = controlled distance between framed contexts
```

not merely:

```text
secret data hiding
```

### 5.3 Isolation State

Runtime isolation state may be represented as:

```text
IsolationState = (
    frames,
    domains,
    graph,
    namespace_views,
    memory_views,
    IPC_edges,
    device_edges,
    host_edges,
    network_edges,
    audit_edges,
    trust_edges,
    quarantine_edges,
    policies,
    meta
)
```

where:

| Field | Meaning |
| ----- | ------- |
| `frames` | □ runtime contexts |
| `domains` | named isolation-domain values |
| `graph` | Χ-projected reachability graph |
| `namespace_views` | filesystem/process/module namespaces |
| `memory_views` | address/mapping visibility |
| `IPC_edges` | permitted message paths |
| `device_edges` | permitted driver/device relations |
| `host_edges` | permitted FFI/host boundaries |
| `network_edges` | permitted session/node reachability |
| `audit_edges` | permitted observability paths |
| `trust_edges` | permitted key/trust-anchor use paths |
| `quarantine_edges` | restricted or severed edges |
| `policies` | Ψ constraints over crossings |
| `meta` | profile, trace, runtime, topology data |

`domains`, `IDom`, `X_user`, `X_global`, and comparable runtime-domain names denote implementation-level isolation-domain values.

They are not the PMS Base operator `Χ` itself.

Isolation is valid when this state is enforced, not merely recorded.

### 5.4 Isolation Graph

The core isolation representation is a graph.

```text
G_iso = (F, E)
```

where:

```text
F = set of frames / domains
E = permitted reachability or transfer edges
```

Isolation removes or constrains edges.

```text
χ_runtime(f_i, f_j) = true ⇒ (f_i, f_j) ∉ E
```

or more generally:

```text
edge(f_i, f_j) exists only if the Χ projection permits it
```

Edges may carry profiles:

```text
Edge = (
    source,
    target,
    direction,
    allowed_ops,
    transfer_profile,
    capability_requirement,
    policy_requirement,
    commit_profile,
    audit_profile,
    meta
)
```

Examples:

```text
process → kernel:
    allowed only via Φ syscall/trap entry

process → process:
    allowed only via IPC/shared frame/capability transfer

module → module:
    allowed only through import/export interface

driver → device:
    allowed only through assigned MMIO/DMA/IRQ frames

runtime → host:
    allowed only through ForeignFrame/HostService profile

network peer → service:
    allowed only through session boundary and mapped principal
```

Isolation graph rule:

```text
no edge, no crossing.
edge present, crossing still requires Ω and Ψ.
```

### 5.5 Visibility Predicate

Runtime visibility is a Χ/□/Ω/Ψ predicate.

```text
Visible(actor, target, s) iff
    target ∈ VisibleFrames(frame(actor), s)
    ∧ Χ_allows(actor, target, s)
    ∧ Ω_allows(actor, observe/access target, s)
    ∧ Ψ_allows(actor, observe/access target, s)
```

Visibility is not authority alone.

```text
visible target
≠ allowed mutation
```

Mutation requires a stronger predicate:

```text
AccessAllowed(actor, action, target, s) iff
    Visible(actor, target, s)
    ∧ Ω_allows(actor, action, target, s)
    ∧ Ψ_allows(actor, action, target, s)
    ∧ dependency_valid(action, s)
```

Memory example:

```text
AccessAllowed(p, Rk)
⇔ Ω(r_p) ▷ owner(Rk)
∧ no Ψ violation
∧ no Χ-projected barrier
```

### 5.6 Isolation Domains

An isolation domain is a named runtime Χ-projection context.

```text
IsolationDomain = (
    domain_id,
    frames,
    principals,
    roles,
    capabilities,
    policies,
    namespace_view,
    memory_view,
    IPC_view,
    device_view,
    network_view,
    audit_view,
    parent?,
    children,
    meta
)
```

Domain examples:

```text
kernel_global
user_process
container
sandbox
driver_sandbox
device_domain
network_session
module_capsule
foreign_host
audit_restricted_view
cluster_node
quarantine_domain
```

Domain relation:

```text
domain_a ⟂ domain_b
```

means that direct reachability is absent unless a bridge is installed.

Domain nesting:

```text
domain_child ⊑ domain_parent
```

means:

```text
child visibility is equal or more restrictive
child capabilities are equal or narrower
child policies are equal or stronger
```

This supports containers, sandboxes, service compartments, driver sandboxes, and network sessions.

### 5.7 Address Spaces as Frames

A virtual address space is a □ frame with Χ-projected constraints.

```text
VAS(p) = □_p
map_p : VAS(p) → PhysicalMem
```

Memory operation validity:

```text
∇_read/write(addr) valid iff
    addr ∈ VAS(p)
    ∧ map_p(addr) defined
    ∧ Ω permits requested operation
    ∧ Χ projection does not block region
    ∧ Ψ permits access
```

Memory isolation blocks:

```text
χ_runtime(□_p, region) ⇒ block ∇ precondition
```

Memory isolation applies to:

```text
user/kernel memory
process/process memory
driver MMIO
DMA buffers
shared memory
foreign host memory
runtime heap regions
key material frames
audit buffers
```

A read or write that bypasses the active address-space frame is invalid even if an address value exists.

```text
address existence
≠ visibility
≠ authority
≠ policy validity
```

### 5.8 Kernel/User Isolation

Kernel/user isolation is the canonical PMS-OS runtime boundary.

```text
□_user ⟂ □_kernel
```

Kernel context:

```text
Context_kernel = (f = KF, r ∈ {KERNEL, SUPERVISOR}, IDom = global)
```

User context:

```text
Context_user = (f = UF, r = USER, IDom = user_domain)
```

`IDom`, `X_user`, `X_global`, and comparable runtime-domain names denote implementation-level isolation-domain values.

They are not the PMS Base operator `Χ` itself.

Valid crossing:

```text
USER → KERNEL only via Φ_trap
KERNEL → USER only via Φ_return
```

Syscall entry:

```text
Δ classify syscall
Φ enter kernel
Ω switch to kernel role
□ switch to kernel frame
Χ establish kernel-visible projected boundary context
Ψ evaluate syscall policy
∇ perform kernel operation
Σ commit result/accounting/audit
Φ return to user
```

This syscall flow is a runtime-security isolation view.

It does not redefine the PMS-OS syscall ABI specified in `04_pms_os.md`, and it does not replace the PMS-CPU trap/control-transfer convention specified in `03_pms_cpu.md`.

The PMS-OS syscall contract remains:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

Invalid crossing:

```text
user : ∇_write(VAS_kernel)
```

Runtime response:

```text
Χ projection blocks access
Ω denies authority
Ψ enforces invariant
Φ traps
Σ audits / rolls back where needed
```

Kernel privilege is therefore mediated authority, not exemption from invariants.

### 5.9 Process Isolation

A process isolation domain includes:

```text
address space
file descriptor table
namespace view
IPC endpoints
resource frame
signal/event context
local policy set
principal/role state
```

Process isolation prevents:

```text
direct memory access across processes
direct descriptor-table access
direct namespace mutation
direct policy mutation
direct role escalation
direct scheduler manipulation
direct kernel-frame access
```

Cross-process interaction requires one of:

```text
IPC channel
shared memory frame
kernel-mediated handle transfer
capability delegation
filesystem object with policy
network loopback/session
debugging authority
audit export
```

Cross-process bridge creation:

```text
Δ classify bridge request
Ω verify bridge/capability authority
Χ establish permitted projected edge
Ψ evaluate bridge policy
Σ commit bridge
Θ audit event
```

No process-to-process authority is implicit.

### 5.10 Container and Sandbox Isolation

Containers and sandboxes are contracted isolation domains.

They restrict:

```text
filesystem namespace
network namespace
IPC namespace
process visibility
syscall set
capability set
device access
debug visibility
resource usage
audit export
```

Container creation:

```text
Δ distinguish container
□ create container frame set
Ω assign contracted role/capability set
Χ create container isolation-domain projection
Ψ attach container policy
Σ commit container boundary
Θ audit creation
```

Sandbox entry:

```text
Φ recontextualize principal into restricted context
Ω attenuate capabilities
Χ tighten projected boundary
Ψ activate sandbox policy
Σ commit sandbox state
```

Sandbox invariant:

```text
sandbox_authority ⊑ parent_authority
```

unless a privileged policy-governed transition explicitly commits a different relation.

A sealed isolation context forbids further entry, expansion, or reachability growth.

It still permits valid exit, closure, audit, rollback, or commit under the declared policy and active boundary context.

Sealing is not the same as trapping execution forever.

### 5.11 Module Isolation

Modules may be isolated as runtime subcontexts.

Module isolation uses:

```text
□ module frame
Ω module role
Χ module boundary projection
Ψ module policy
Σ export/import commit
```

Isolated module declaration concept:

```pmsl
module M isolated {
    ...
}
```

Runtime expansion:

```text
Χ_enter_isolation(M.ctx)
□_switch_frame(M.frame)
Ω_set_role(M.role)
Ψ_apply(M.policies)
Σ_register_exports
```

Module isolation prevents:

```text
direct pointer sharing
unmediated state access
implicit capability leakage
import/export bypass
direct mutation of internal module state
```

Cross-module calls require:

```text
exported interface
import edge
capability token
IPC/message passing
policy-approved transfer profile
```

Invalid module leak:

```text
isolated module exports internal mutable state without transfer profile
```

Response:

```text
Χ/Ψ rejection
Φ trap if attempted at runtime
Σ audit where required
```

### 5.12 IPC and Channel Isolation

IPC is the standard bridge across isolated domains.

A channel is a controlled edge:

```text
ChannelEdge = (
    sender_frame,
    receiver_frame,
    payload_type,
    direction,
    capacity,
    capability_requirements,
    policy,
    delivery_commit,
    audit_profile
)
```

Send operation:

```text
Δ classify channel and payload
Ω verify send capability
Χ verify endpoint reachability
Ψ check channel policy
∇ enqueue message
Θ order delivery/wake
Σ commit delivery
Λ no-space/no-receiver if declared
Φ trap on invalid channel or policy violation
```

Receive operation:

```text
Δ classify endpoint
Ω verify receive capability
Χ verify endpoint visibility
Ψ check receive policy
Θ wait/select
Λ no-message/timeout if declared
∇ dequeue
Σ commit receive
Φ trap on invalid payload or channel failure
```

IPC isolation rule:

```text
message passing is a bridge, not shared authority.
```

A received value may require:

```text
copy
serialization
capability transfer
boundary reclassification
policy filtering
redaction
```

### 5.13 Shared Memory Isolation

Shared memory is a controlled relaxation of isolation.

Shared frame creation:

```text
Δ classify sharing request
Ω verify share/map capability
Χ create shared projected edge
Ψ evaluate sharing policy
□ map shared frame into participants
Σ commit mapping
Θ audit mapping
```

Shared memory frame:

```text
SharedFrame = (
    frame_id,
    participants,
    permissions,
    synchronization_profile,
    transfer_profile,
    policy,
    commit_profile
)
```

Shared memory must declare:

```text
read/write permissions
ownership
lifetime
synchronization requirements
revocation behavior
audit requirements
commit semantics
```

Invalid shared memory pattern:

```text
map writable shared frame into untrusted process without policy or synchronization profile
```

Response:

```text
Ω/Χ/Ψ rejection
```

Shared memory is not a hole in isolation. It is an explicit Χ-projected edge with Ω/Ψ constraints.

### 5.14 Filesystem Namespace Isolation

Filesystem isolation is frame-based namespace control.

Filesystem namespace:

```text
FSNamespace = □(
    root,
    mounts,
    path_rules,
    handles,
    policies,
    visibility
)
```

Container filesystem boundary:

```text
χ_runtime(□_container1, □_container2)
```

denies direct path visibility.

Filesystem operation:

```text
Δ resolve path
Ω verify file capability
Χ check namespace/mount boundary projection
Ψ evaluate FS policy
∇ perform operation
Σ commit visible/durable result
Λ missing path/no-space
Φ IO/policy trap
```

Namespace isolation must distinguish:

```text
path string
resolved object
mount boundary
handle frame
capability scope
policy result
commit profile
```

A path string does not imply reachability.

### 5.15 Network Isolation

Network isolation governs connection visibility and remote reachability.

Network domain fields:

```text
NetworkDomain = (
    local_principal,
    local_frame,
    session_boundary,
    allowed_endpoints,
    protocol_profile,
    trust_policy,
    rate_policy,
    audit_profile
)
```

Connection attempt:

```text
Δ classify endpoint and protocol
Ω verify network capability
Χ check network/session boundary projection
Ψ evaluate route/trust/protocol policy
Φ map remote identity if needed
∇ connect/send/receive
Σ commit session or delivery state
Λ no-route/no-response/timeout
Φ network/protocol trap
```

Network isolation prevents:

```text
unauthorized outbound connections
unauthorized inbound service exposure
session identity confusion
cross-tenant route leakage
plaintext where policy requires protected session
unbounded network resource consumption
```

Network isolation here specifies runtime-security enforcement points. It does not claim a completed network stack, production protocol implementation, cryptographic library, transport implementation, or distributed consensus implementation.

Distributed isolation is refined in `07_distributed_systems.md`; runtime security defines the local boundary and session enforcement structure.

### 5.16 Driver and Device Isolation

Driver/device isolation is a high-risk Χ-projection domain.

Driver domain:

```text
DriverDomain = (
    driver_frame,
    driver_role,
    device_frames,
    MMIO_regions,
    DMA_regions,
    interrupt_vectors,
    policy,
    quarantine_policy
)
```

Device access requires:

```text
assigned device frame
explicit MMIO or DMA capability
boundary-valid region
driver policy approval
audit where required
```

DMA isolation is critical:

```text
DMARegion(dev) ⊆ permitted_frame_set(driver)
```

Invalid:

```text
driver DMA into kernel memory
driver MMIO outside assigned register window
driver accesses sibling device frame
driver continues after quarantine
```

Response:

```text
Χ block
Ω denial
Ψ driver policy action
Φ driver fault/recovery
Χ quarantine
Σ cleanup/audit
```

Driver isolation is not optional hardening. It is structural protection.

### 5.17 FFI and Host Isolation

FFI crosses a host boundary.

Foreign context:

```text
ForeignFrame = □(
    host,
    abi,
    memory_profile,
    error_profile,
    policy,
    commit_profile
)
```

FFI call:

```text
Δ classify foreign symbol
Ω verify host-call capability
Χ enter projected host boundary
Ψ evaluate FFI/host policy
Φ recontextualize into host ABI
∇ execute host call
Φ map host error
Λ map no-response/timeout
Σ integrate result
Θ audit if required
```

FFI isolation prevents:

```text
untyped host authority
raw memory leakage
unmapped host errors
hidden blocking behavior
unbounded host side effects
host result treated as PMSL-native truth
```

Rule:

```text
host behavior is isolated and recontextualized before integration.
```

A host call is not a PMSL semantic primitive and does not make host OS behavior equivalent to PMS-OS.

### 5.18 Audit and Debug Isolation

Observability is also isolated.

Debugging may expose:

```text
memory values
capabilities
policy state
trace contents
audit records
principal identities
network metadata
host-service responses
key-use metadata
```

Therefore debug access requires:

```text
Δ classify inspection request
Ω verify observer/debug capability
Χ check observability boundary projection
Ψ apply redaction and access policy
∇ inspect or export
Σ commit audit-read event where required
```

Audit visibility profiles:

```text
full
redacted
metadata_only
hash_only
denied
delayed
compliance_export
```

Debugging is not a privilege bypass.

```text
debug authority
⊂ runtime authority
```

unless an explicit Ψ policy grants more.

Audit records are runtime-security evidence artifacts. They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 5.19 Trust Anchor and Key Isolation

Key material is frame-contained.

```text
KeyFrame = □(material, type, scope, metadata)
```

Isolation requirements:

```text
private key material lives in isolated frame
key use requires Ω capability
trust policy governs interpretation
copy/export paths are Χ-controlled
rotation/revocation is Φ/Ψ/Σ-governed
audit is Θ/Σ-governed
```

Key use:

```text
Δ classify key and operation
Ω verify key-use capability
Χ check key-frame isolation projection
Ψ evaluate key-use/trust policy
Φ interpret credential or key state
∇ sign/verify/decrypt/derive
Σ commit trust/session/key-use state
```

A key does not confer authority by existing. It participates in identity/trust only through valid runtime binding.

Trust validation here means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, and runtime policy profile.

It does not mean external validation of PMS Base, legal identity proof, universal trust, or personhood validation.

### 5.20 Scheduler Isolation

Scheduling has an isolation dimension.

Separate domains may have independent Θ instances:

```text
Χ projection: domain_i ⟂ domain_j

Θ_i, Θ_j : independent schedulers
```

Used for:

```text
containers
VMs
per-core queues
real-time partitions
driver isolation
security-critical tasks
tenant isolation
```

Scheduler isolation controls:

```text
who can observe scheduling state
who can influence priority
which queues are visible
which events wake which tasks
which domain can starve another
which policy enforces fairness
```

Scheduler isolation failure may produce:

```text
priority leak
covert timing channel
unfair resource control
cross-domain starvation
```

Policy may respond with:

```text
quota enforcement
domain-local queues
audit
priority downgrade
scheduler quarantine
```

Scheduler isolation is a runtime-security architecture claim. It does not claim side-channel elimination by specification alone.

### 5.21 Resource Isolation

Resource isolation governs bounded consumption.

Resources:

```text
CPU
memory
IPC buffers
file handles
storage quota
network quota
device queues
trace buffers
audit storage
host calls
timers
```

Resource frame:

```text
ResourceFrame = (
    owner,
    resource_type,
    used,
    limit,
    policy,
    isolation_domain,
    audit_profile
)
```

Resource use:

```text
Δ classify resource request
Ω verify allocation/use capability
Χ check resource domain projection
Ψ evaluate quota policy
∇ allocate/use
Σ commit accounting
Λ no-resource if recoverable
Φ trap/reframe if critical
```

Resource isolation prevents one principal or domain from consuming another’s runtime capacity.

Resource accounting is runtime governance. It is not social evaluation or person ranking.

### 5.22 Isolation Bridges

A bridge is a controlled Χ-projected edge.

Bridge forms:

```text
syscall bridge
IPC bridge
shared-memory bridge
module import/export bridge
FFI bridge
driver/device bridge
network session bridge
audit export bridge
trust-anchor validation bridge
debugging bridge
distributed node bridge
```

Bridge definition:

```text
Bridge = (
    source_domain,
    target_domain,
    allowed_ops,
    transfer_profile,
    required_capabilities,
    policies,
    commit_profile,
    audit_profile,
    failure_policy
)
```

Bridge creation:

```text
Δ classify bridge
Ω verify bridge authority
Χ add constrained projected edge
Ψ evaluate bridge policy
Σ commit bridge
Θ audit
```

Bridge removal:

```text
Δ classify bridge
Ψ evaluate teardown/revocation policy
Χ remove projected edge
Ω revoke bridge capabilities
Σ commit removal
Θ audit
```

Bridge invariant:

```text
all cross-domain effects pass through declared bridges.
```

A sealed isolation context may allow a valid bridge exit or closure while forbidding additional entry, expansion, or reachability growth.

### 5.23 Quarantine

Quarantine is an isolation response.

It tightens or replaces a subject’s Χ-projected domain after a policy, trap, or invariant event.

Quarantine target:

```text
process
thread
module
driver
device
container
network session
IPC endpoint
filesystem subtree
node
tooling service
AI service
```

Quarantine operation:

```text
Δ classify subject and cause
Ψ decide quarantine
Φ recontextualize subject into restricted context
Χ tighten projected isolation
Ω revoke or attenuate capabilities
Σ commit quarantine state
Θ audit event
```

Quarantine effects:

```text
remove scheduler eligibility
block IPC
freeze writes
deny network send
restrict device access
redact observability
force resource cleanup
require manual or policy-governed release
terminate subject
```

Quarantine is not a moral or forensic judgment. It is a runtime-security boundary action.

### 5.24 Sealed Isolation and Valid Exit

Sealed isolation is a specific isolation state.

```text
SealedIsolation = (
    domain,
    active_boundary_context,
    entry_policy = denied,
    expansion_policy = denied,
    reachability_growth = denied,
    exit_policy,
    closure_policy,
    audit_profile
)
```

A sealed isolation context forbids:

```text
new entry
authority expansion
reachability growth
new outbound edges
new inbound edges
unapproved capability grants
policy relaxation
```

It may still permit:

```text
valid exit
closure
audit
rollback
commit
resource cleanup
quarantine finalization
policy-governed termination
```

Rule:

```text
sealed isolation
≠ trapped execution forever
```

Valid exit requires active boundary context:

```text
valid_exit(domain) iff
    active_boundary_context(domain)
    ∧ Ψ permits exit/closure
    ∧ pending commit/rollback obligations are resolved
    ∧ audit obligations are satisfiable
```

Unbalanced exit is invalid:

```text
χ_exit without active isolation context → error[Χ]
```

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline under this rule.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete PMSL isolation, or validate PMS Base.

### 5.25 Isolation Failure Modes

Isolation failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown frame/domain | Δ / Λ |
| invalid frame mapping | □ / Φ |
| no boundary edge | Χ projection |
| forbidden boundary crossing | Χ projection / Ψ |
| missing crossing capability | Ω |
| policy denial | Ψ |
| stale bridge | Θ / Ψ / Χ |
| invalid shared memory | □ / Χ / Ψ |
| namespace escape | Χ / Ψ / Φ |
| driver overreach | Ω / Χ / Ψ / Φ |
| host boundary leak | Χ / Φ / Ψ |
| audit visibility violation | Ω / Χ / Ψ |
| key-frame exposure | Χ / Ω / Ψ |
| quarantine failure | Χ / Ψ / Φ / Σ |
| commit after invalid crossing | Σ / Ψ |
| unbalanced isolation exit | Χ / Ψ / Φ |

A valid runtime must preserve these distinctions where they matter.

### 5.26 Isolation Leak Scenario

Setup:

```text
Frames:
    F_app
    F_secret

Role:
    Ω_user

Boundary:
    Χ(F_app → F_secret) denies direct read as a runtime projection

Policy:
    Ψ_secret = all cross-frame reads require C_readSecret
```

Attack attempt:

```text
w_attack =
    Δ_secretObj
    ; ∇_read(secretObj)
    ; Χ_bypass_attempt
```

Expected runtime behavior:

```text
Δ classifies secretObj
□ identifies active frame F_app
Χ detects forbidden crossing into F_secret
Ω finds no C_readSecret capability
Ψ denies action
Φ enters security-violation frame
Σ commits audit / rollback if needed
```

Result:

```text
no secret value becomes visible to F_app
no successful Σ read result is emitted
audit records actor, frame, boundary, policy, and denial
```

Attack words describe attempted operator sequences.

They do not assert that the attack succeeds. Runtime security identifies the failed obligation: Δ classification, Ω authority, □ frame validity, Χ boundary projection, Ψ policy, Φ recontextualization, Σ commit, or Θ ordering.

A successful rejection shows that a specific attempted transition was blocked under a declared profile. It is not a universal proof that all variants are blocked.

### 5.27 Isolation Validation

Static analysis, runtime validation, trace conformance, and model checking can check isolation properties under declared profiles.

Validation in this section means acceptance or rejection under a declared runtime-security schema, isolation model, policy, hook, profile, artifact, trace schema, or conformance rule.

It does not mean external validation of PMS Base.

Static checks:

```text
module isolation declarations
FFI boundary profiles
driver MMIO/DMA scopes
shared-memory transfer profiles
debug/audit visibility policies
network session boundary requirements
capability scope compatibility
```

Runtime checks:

```text
active frame
active domain
active principal
capability set
boundary edge
policy decision
commit state
audit requirement
```

Model-checkable properties:

```text
no user path reaches kernel memory without Φ syscall/trap entry
no isolated module leaks internal mutable state
no driver reaches unassigned MMIO region
no host call occurs without ForeignFrame
no network session receives local authority before identity mapping
no audit export crosses redaction boundary without authority
no quarantined subject sends IPC
```

Trace-conformance properties:

```text
every boundary crossing event has preceding Ω and Ψ event
every quarantine event has Χ tightening and Σ commit
every host call trace includes ForeignFrame metadata
every valid isolation exit has active boundary context
```

Proof artifacts prove stated properties under formal assumptions. Tests check. Traces record. Validators accept or reject under profile.

### 5.28 Isolation Trace and Evidence Convention

A concrete runtime-security isolation execution produces:

```text
trace_runtime(runtime, isolation_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security isolation executions under a declared profile is:

```text
Trace_runtime(runtime, isolation_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared runtime-security isolation profile.

Audit records and trace streams record observed executions.

They do not prove all possible executions unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

Golden fixtures stabilize regression expectations. They do not prove full isolation coverage or validate PMS Base.

### 5.29 Isolation and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of runtime-isolation discipline:

```text
operator-tagged execution
model/stateful validation
fail-closed rejection paths
JSONL traces
golden fixtures
vFS service boundaries
AI proposal gating
active isolation-stack checks
bounded chi_enter / chi_exit discipline
```

Correct relation:

```text
Runtime isolation specification
    defines implementation-layer Χ-projection obligations.

PMS-RUST bounded artifacts
    may demonstrate executable slices of those obligations.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime security, complete PMS-OS isolation, prove deployment security, complete PMSL/PMS-IR isolation, complete FFI safety, complete distributed isolation, or make tests/traces proofs.

PMS-RUST `chi_exit` evidences a bounded runtime isolation-exit discipline.

It does not redefine PMS Base Χ, complete PMS-OS isolation, or validate PMS Base.

### 5.30 Isolation Claim Boundary

The PMS-STACK isolation model claims:

```text
runtime boundaries can be represented as Χ-projected, □-framed,
Ω-authorized, Ψ-constrained, Φ-recoverable, Σ-committed,
Θ-auditable structures.
```

It does not claim:

```text
all implemented systems are secure by specification alone
all side channels are eliminated automatically
all host runtimes are equivalent to PMS-OS
all distributed boundaries are solved locally
Χ in PMS-STACK redefines PMS Base Χ
tests or traces prove complete security
implementation artifacts validate PMS Base
completed kernel isolation
completed container runtime
completed sandbox runtime
completed FFI safety
completed network security
universal deployment security certification
```

Isolation is strong because it is explicit and enforceable. Its claim is bounded by profiles, policies, implementations, assumptions, and evidence artifacts.

### 5.31 Isolation Invariants

Runtime security maintains the following isolation invariants.

```text
I1: every isolated subject belongs to a Δ-distinguishable domain
I2: every isolation domain is backed by one or more □ frames
I3: every boundary-sensitive access is Χ-checked as an implementation-layer projection
I4: every protected crossing is Ω-authorized
I5: every crossing is Ψ-policy checked
I6: every cross-domain transfer uses a declared bridge or is rejected
I7: every memory access is frame-visible before ∇ read/write
I8: user frames cannot access kernel frames except via Φ-mediated kernel entry
I9: process/process access occurs only through IPC, shared memory, handle transfer, or explicit bridge
I10: module isolation prevents direct internal-state access unless exported through policy-valid interface
I11: driver/device access is confined to assigned MMIO, DMA, IRQ, and device frames
I12: FFI/host access occurs only through ForeignFrame or HostService boundary
I13: network/session authority requires identity mapping before local capability assignment
I14: key material remains inside key frames unless Ω/Χ/Ψ permit use or transfer
I15: audit/debug visibility is itself Ω/Χ/Ψ-governed
I16: shared memory is an explicit Χ edge with permission, synchronization, and lifetime profile
I17: quarantine tightens Χ, attenuates Ω, applies Ψ, and commits state through Σ
I18: isolation failure has typed Λ/Ω/Χ/Ψ/Φ/Σ handling
I19: no isolation fast path bypasses Ω, Χ, Ψ, Φ, or Σ
I20: isolation evidence strengthens runtime-security implementation claims and does not function as PMS Base validation
I21: sealed isolation forbids further entry, expansion, or reachability growth while permitting valid exit/closure under policy
I22: PMS-RUST-style artifacts may evidence bounded isolation slices; they do not complete runtime isolation or validate PMS Base
```

### 5.32 Architectural Consequence

The consequence is:

```text
PMS-STACK isolation is not a flag, sandbox label, container wrapper,
or memory-permission table. It is the runtime projection of Χ as
operator-governed distance between framed contexts: processes, modules,
drivers, devices, filesystems, network sessions, host services, audit
views, trust anchors, and distributed nodes.
```

This gives runtime security a uniform isolation architecture:

```text
□ supplies the context.
Χ defines reachability and separation as an implementation-layer projection.
Ω authorizes attempts.
Ψ constrains admissibility.
Φ handles violation and recontextualization.
Σ commits bridge, transfer, quarantine, or rollback state.
Θ makes boundary events traceable.
```

The next section defines the Ψ policy layer that governs these isolation decisions, enforcement hooks, transformations, denials, audit requirements, and runtime governance actions.

### 5.33 Isolation Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK isolation model specifies implementation-layer
runtime-security isolation architecture: frames, isolation domains,
reachability graphs, visibility predicates, address-space separation,
kernel/user isolation, process isolation, container/sandbox isolation,
module isolation, IPC/channel isolation, shared-memory isolation,
filesystem namespace isolation, network/session isolation, driver/device
isolation, FFI/host isolation, audit/debug isolation, trust-anchor/key
isolation, scheduler isolation, resource isolation, isolation bridges,
quarantine, sealed isolation, valid exit, isolation failure modes,
attack attempts, validation, trace/evidence conventions, PMS-RUST
evidence boundaries, and isolation invariants.

This is a runtime-security isolation / Χ-projection architecture claim.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete
PMSL/PMS-IR isolation, complete host isolation, complete distributed
isolation, eliminate all side channels, certify all deployments, or
validate PMS Base.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection, JSONL traces, golden fixtures, vFS/service boundaries,
active isolation-stack checks, bounded chi_enter / chi_exit discipline,
and AI proposal gating. It does not complete runtime isolation and does
not validate PMS Base.
```

---

## 6. Policy Definition and Enforcement

Policy definition and enforcement are the Ψ layer of PMS-STACK runtime security.

Ψ defines which operator-typed transitions are admissible, denied, transformed, audited, isolated, rolled back, escalated, or halted. It is the runtime-governance operator that constrains Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, and Σ.

The central policy claim is:

```text
A PMS-STACK policy system is valid when policies are represented as
Ψ-typed constraints over explicit operator transitions, principal state,
role/capability state, frames, boundary projections, resources, ordering
context, trap state, commit state, trust state, and audit obligations,
such that every protected transition is evaluated before it becomes
executable or globally committed.
```

Claim type:

```text
RUNTIME-SECURITY POLICY / ENFORCEMENT ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK policy definition and enforcement as
implementation-layer runtime-security / governance architecture.

It does not make PMS-STACK a moral tribunal, legal authority, forensic
oracle, social-governance system, clinical classifier, person-ranking
system, or PMS Base validation mechanism.

A PMS-STACK policy governs transitions inside a computational system.
It does not enforce policy over humans as such.
```

Policy is not an after-the-fact advisory layer. It is the runtime structure that narrows the valid execution language:

```text
L_PMS,Ψ_runtime ⊆ L_PMS
```

A concrete runtime-security execution produces:

```text
trace_runtime(runtime, artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security executions under a declared profile is:

```text
Trace_runtime(runtime, artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared runtime-security profile.

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Validation in this section means acceptance or rejection under a declared runtime-security schema, policy, hook, model, profile, artifact, trace schema, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

The assurance vocabulary is:

```text
tests check
traces record
validators accept or reject under profile
model checking checks stated properties under a model
proof artifacts prove stated properties under formal assumptions
external validation validates externally under an explicitly designed protocol
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At runtime-policy level, Χ is projected as boundary, isolation, visibility, reachability, containment, namespace separation, quarantine, and trust-boundary control.

Runtime policy uses this Χ projection. It does not redefine PMS Base Χ.

### 6.1 Purpose of Ψ

Ψ governs:

```text
operator admissibility
role and capability transitions
frame entry and exit
boundary crossing
policy mutation
resource governance
scheduling constraints
network trust
filesystem integrity
device/driver safety
FFI and host access
audit obligations
trust-anchor validity
commit correctness
quarantine conditions
failure response
```

For any operator invocation:

```text
(id, op, params, state) valid
    ⇔ Ψ(state, id, op, params) permits it
```

More completely:

```text
valid_transition(s, id, op, params, s') iff
    structural_preconditions_hold(s, op, params)
    ∧ Ω_allows(id, op, params, s)
    ∧ Χ_allows(id, op, params, s)
    ∧ Ψ_allows(id, op, params, s)
    ∧ Σ_valid_if_committing(s, op, s')
```

Ψ does not replace Ω, Χ, □, Φ, Θ, or Σ. It binds them.

```text
Ω answers: does the actor have authority?
Χ answers: is the target reachable across this boundary projection?
□ answers: is the context/frame valid?
Φ answers: how is violation/recontextualization handled?
Σ answers: what becomes stable?
Ψ answers: is the transition admissible under active invariants?
```

### 6.2 Policy Is Runtime Governance

PMS-STACK uses “governance” in a runtime-architectural sense.

Runtime governance means:

```text
the active constraint system that defines valid runtime behavior,
policy lifecycle, enforcement response, audit requirement, trust rule,
revocation path, quarantine condition, rollback rule, escalation
condition, and commit obligation.
```

It does not mean:

```text
social judgment
moral ranking
person evaluation
legal adjudication
psychological assessment
clinical classification
forensic verdict
policy enforcement over humans as such
```

A PMS-STACK policy governs transitions inside a computational system.

Examples:

```text
no user process may map kernel frames
driver D may write only assigned MMIO range
network session S requires verified remote principal
policy update requires kernel role and signed policy source
debug trace export requires redaction
filesystem commit requires integrity tag match
capability delegation must be attenuated and audited
quarantined subject may not send IPC
```

These are runtime invariants and transition constraints.

### 6.3 Policy Object

A policy object is a structured Ψ artifact.

Specification form:

```text
Policy = (
    id,
    scope,
    mode,
    priority,
    predicate,
    action,
    lifecycle,
    owner,
    version,
    audit_profile,
    meta
)
```

Compact form:

```text
pol = (scope, conditions, actions, priority)
```

Kernel-oriented form:

```text
Policy = (id, scope, mode, priority, predicate, action, meta)
```

Field meanings:

| Field | Meaning |
| ----- | ------- |
| `id` | Δ-distinguishable policy identity |
| `scope` | where the policy applies |
| `mode` | enforcement mode |
| `priority` | resolution order |
| `predicate` | condition over state, operation, context |
| `action` | response if predicate matches or fails |
| `lifecycle` | loaded, active, suspended, revoked, expired |
| `owner` | principal/role allowed to manage policy |
| `version` | policy revision and compatibility metadata |
| `audit_profile` | required Θ/Σ audit behavior |
| `meta` | τ windows, labels, provenance, source, profile |

Policy predicates may inspect:

```text
actor principal
effective principal
role/capability state
operator class
concrete operation
target object
frame context
isolation domain
boundary relation
resource account
τ-derived timing/accounting data
prior operator history
pending commit state
trap/fault state
trust-anchor state
remote credential state
audit requirement
runtime profile
```

A policy must be expressible as a constraint over runtime state and operation context. It is not an untyped side channel.

### 6.4 Policy Scope

Policy scope defines where a policy applies.

Common scopes:

```text
GLOBAL
KERNEL
PROCESS(pid)
THREAD(tid)
FRAME(fid)
ROLE(role_id)
PRINCIPAL(principal_id)
OBJECT(obj_id)
DEVICE(dev_id)
DRIVER(driver_id)
IPC(endpoint)
FILESYSTEM(path_or_frame)
NETWORK(endpoint_or_session)
MODULE(module_id)
FFI(host_service)
AUDIT(log_or_view)
TRUST_ANCHOR(anchor_id)
RESOURCE(resource_frame)
DISTRIBUTED_NODE(node_id)
TOOLING(service_id)
AI_PROPOSAL(service_id)
```

Scope rule:

```text
policy applies iff scope_matches(policy.scope, operation_context)
```

Policy scopes may compose:

```text
P_eff(subject) =
    Combine(
        P_global,
        P_kernel,
        P_principal,
        P_role,
        P_frame,
        P_object,
        P_runtime_profile
    )
```

Local policies may restrict. They may not weaken stronger invariants.

```text
local policy may narrow
local policy may not silently relax inherited policy
```

### 6.5 Policy Modes

A policy has a mode.

Recommended modes:

| Mode | Meaning |
| ---- | ------- |
| `ENFORCING` | decision affects execution |
| `PERMISSIVE` | decision is computed and audited, but execution proceeds |
| `AUDIT_ONLY` | policy exists for observation/reporting |
| `DISABLED` | policy is inactive |
| `QUARANTINE_ONLY` | policy may isolate on violation but not deny ordinary operation |
| `FAIL_CLOSED` | evaluation failure denies execution |
| `FAIL_OPEN` | evaluation failure permits execution but records audit |
| `SIMULATION` | policy is evaluated in simulated profile only |
| `SHADOW` | policy is compared against production behavior without enforcement |

Mode choice is itself policy-governed.

Critical runtime invariants should normally be fail-closed:

```text
kernel frame isolation
policy mutation
capability grant
trust-anchor update
driver/device authority
FFI host memory transfer
distributed quorum commit
```

A profile may permit fail-open behavior for low-risk diagnostic policies, but the mode must be explicit and auditable.

### 6.6 Policy Lifecycle

Policy lifecycle states:

```text
DRAFT
VALIDATED
LOADED
ACTIVE
SUSPENDED
SHADOW
REVOKED
EXPIRED
ARCHIVED
```

Lifecycle transitions:

```text
DRAFT → VALIDATED      static validation / signature / schema check
VALIDATED → LOADED     Ω-authorized load
LOADED → ACTIVE        Ψ activation + Σ commit
ACTIVE → SUSPENDED     Ψ lifecycle action
ACTIVE → SHADOW        policy mode transition
ACTIVE → REVOKED       revocation policy
ACTIVE → EXPIRED       Θ/τ expiry condition
REVOKED → ARCHIVED     audit-retention policy
```

Policy lifecycle mutation:

```text
Δ classify policy mutation
Ω verify mutation authority
Χ check management boundary projection
Ψ evaluate lifecycle policy
Φ recontextualize if upgrade/migration needed
Σ commit policy state
Θ audit policy event
```

No policy should become active by mere presence in a file, message, or repository.

```text
policy source exists
≠ policy loaded
≠ policy active
≠ policy authoritative
```

### 6.7 Policy Layers

Policies are layered.

A common hierarchy:

```text
Ψ₀ — machine/core policies
Ψ₁ — kernel/runtime policies
Ψ₂ — subsystem policies
Ψ₃ — application/domain policies
Ψ₄ — deployment/site policies
Ψ₅ — session/distributed policies
```

Examples:

#### Ψ₀ — Machine/Core Policies

```text
no execution outside executable frames
no writes to read-only pages
no uncontrolled role escalation
commit preconditions required
trap return must preserve invariants
```

#### Ψ₁ — Kernel/Runtime Policies

```text
syscall safety
process lifecycle
IPC message shape
driver access correctness
scheduler fairness
resource accounting
policy mutation integrity
```

#### Ψ₂ — Subsystem Policies

```text
filesystem path rules
network encryption/integrity requirements
device MMIO/DMA rules
module import/export constraints
FFI memory-transfer rules
audit retention rules
```

#### Ψ₃ — Application/Domain Policies

```text
service-level limits
business workflow state constraints
domain-specific object access
API-specific validation
tenant boundaries
```

Layer relation:

```text
Ψ = Ψ₀ ≺ Ψ₁ ≺ Ψ₂ ≺ Ψ₃ ≺ ...
```

where stronger/lower layers constrain weaker/higher layers.

Policy layer invariant:

```text
higher-level policy may specialize;
higher-level policy may not violate lower-level invariants.
```

### 6.8 Policy Algebra

Policies compose through explicit algebra.

#### Union

```text
Ψ_A ∪ Ψ_B
```

combines constraints.

#### Intersection

```text
Ψ_A ∩ Ψ_B
```

requires both.

#### Priority Override

```text
Ψ_A ≺ Ψ_B
```

means `Ψ_B` has priority in conflict resolution, subject to non-weakening constraints.

#### Sequential Composition

```text
Ψ_total = Ψ_core ; Ψ_kernel ; Ψ_runtime ; Ψ_app
```

#### Monotonic Tightening

```text
Ψ' ⊆ Ψ
```

means the policy set is equal or stricter.

Default law:

```text
tightening is admissible
relaxation requires explicit Φ/Ω/Ψ/Σ path
```

#### Conflict Detection

Policy conflict occurs when:

```text
policy_A requires allow
policy_B requires deny
```

or:

```text
policy_A requires commit
policy_B requires rollback
```

or:

```text
policy_A requires audit export
policy_B forbids visibility
```

Conflict resolution must be explicit.

A valid runtime must not silently pick a convenient policy.

### 6.9 Policy Decision

A policy decision is the result of evaluating active policy set over an operation.

```text
PolicyDecision = (
    decision,
    matched_policies,
    action,
    reason,
    transformed_operation?,
    audit_requirement,
    commit_requirement,
    meta
)
```

Decision values:

```text
ALLOW
DENY
MODIFY
TRANSFORM
DEFER
LOGONLY
AUDIT
QUARANTINE
REVOKE
ROLLBACK
ESCALATE
HALT
UNKNOWN
ERROR
```

Decision classes:

| Decision | Runtime meaning |
| -------- | --------------- |
| `ALLOW` | transition may proceed |
| `DENY` | transition must not proceed |
| `MODIFY` | operation parameters are rewritten |
| `TRANSFORM` | operation is recontextualized via Φ |
| `DEFER` | decision postponed until more state is available |
| `LOGONLY` | emit audit, do not affect execution |
| `QUARANTINE` | tighten Χ projection |
| `REVOKE` | revoke Ω authority |
| `ROLLBACK` | undo staged state through Σ recovery |
| `ESCALATE` | route to governance/supervisor context |
| `HALT` | enter critical stop state |
| `UNKNOWN` | policy cannot decide |
| `ERROR` | policy evaluation failed |

Decision failure mode is profile-dependent:

```text
FAIL_CLOSED:
    UNKNOWN/ERROR ⇒ DENY

FAIL_OPEN:
    UNKNOWN/ERROR ⇒ ALLOW + AUDIT

AUDIT_ONLY:
    decision recorded, execution unaffected
```

Critical policies should not rely on fail-open behavior.

### 6.10 Policy Evaluation Pipeline

Canonical evaluation pipeline:

```text
(state s, operation op, context c)
    → collect context
    → select relevant policies
    → evaluate predicates
    → combine results
    → resolve conflicts
    → produce decision
    → enforce action
    → emit audit if required
```

Expanded form:

```text
1. Δ collect and classify context
2. Δ select relevant policies
3. Ω inspect actor authority state
4. □ inspect active frame context
5. Χ inspect boundary relation
6. Θ inspect ordering / τ-derived timing state if needed
7. Ψ evaluate predicates
8. Ψ combine policy results
9. Ψ resolve final decision
10. Φ transform/recontextualize if decision requires it
11. Σ commit decision/audit/state if needed
12. return enforcement result
```

Pseudo-code:

```text
function Eval_Ψ(PSet, s, op, ctx):
    ctx'       = collect_context(s, op, ctx)
    relevant  = select_policies(PSet, ctx')
    results   = []
    for pol in priority_order(relevant):
        results.push(eval_policy(pol, s, op, ctx'))
    decision  = combine(results)
    resolved  = resolve(decision, ctx')
    return resolved
```

Evaluation invariant:

```text
a protected transition may not execute before its required policy decision exists.
```

### 6.11 Context Collection

Policy evaluation requires context.

Context object:

```text
PolicyContext = (
    actor,
    effective_actor,
    target,
    operator_class,
    concrete_operation,
    frame,
    role,
    capabilities,
    isolation_domain,
    boundary_relation,
    resource_state,
    τ_metadata,
    history_summary,
    pending_commit,
    trap_state,
    trust_state,
    audit_state,
    runtime_profile,
    source
)
```

Context collection must be minimal but sufficient.

Security rule:

```text
policy context must not require access that violates the policy being evaluated.
```

Example:

```text
checking whether actor may read secret
```

must not require reading the secret value. It may inspect labels, frame IDs, capabilities, and policy metadata.

### 6.12 Policy Hooks

Policy hooks are runtime points where Ψ asks:

```text
May this operator-typed transition proceed?
```

Generic hook interface:

```text
PolicyHook = (
    operator_class,
    operation,
    state,
    context
)
```

Evaluation:

```text
decision = Eval_Ψ(PSet, state, operation, context)
```

Hooks are operator-specific.

They are runtime-security enforcement points. They do not by themselves prove security; they expose the places where security decisions must be made, checked, traced, and audited.

### 6.13 Δ-Hooks — Distinction and Decision

Δ-hooks apply when the runtime distinguishes among possible paths.

Examples:

```text
syscall dispatch
IPC route selection
filesystem path resolution
scheduler candidate selection
device-driver match
namespace resolution
policy selection
credential classification
remote principal classification
```

Policy examples:

```text
deny syscall class for ROLE_GUEST
rewrite open(path) into process namespace root
deny following symlink across namespace boundary
deny driver probe for untrusted device class
reject unrecognized remote credential type
```

Δ-hooks constrain which distinctions may become executable branches.

### 6.14 ∇-Hooks — Mutation and State Change

∇-hooks apply before mutations.

Examples:

```text
write memory
write file
enqueue IPC message
create process
create thread
allocate memory
change capability table
update driver state
write device register
send network packet
call host service
```

Policy examples:

```text
deny writes to protected filesystem frames
deny memory allocation above quota
deny network connection creation outside allowed domain
log any mutation of policy-related state
deny unredacted audit export
```

∇-hooks prevent unauthorized or invalid state mutation.

### 6.15 □-Hooks — Frame and Context Change

□-hooks apply when execution changes frame context.

Examples:

```text
context switch
address-space switch
entering process frame
mapping shared memory
mounting filesystem subtree
switching namespace
entering device frame
binding driver frame
entering ForeignFrame
entering AuditFrame
```

Policy examples:

```text
process may not enter frame outside its FrameSet
container may not mount host namespace
driver may not map unassigned MMIO frame
shared frame requires explicit policy approval
host frame requires FFI profile
```

□-hooks ensure that frame transitions remain policy-valid.

### 6.16 Ω-Hooks — Role and Capability Change

Ω-hooks apply when authority changes or is checked.

Examples:

```text
role switch
capability grant
capability revoke
setuid-like operation
driver capability assignment
syscall authority check
privilege entry or exit
impersonation
delegation
debug authority check
policy mutation authority check
```

Policy examples:

```text
unprivileged process cannot gain device capability
driver cannot acquire DMA scope outside assigned frame
service may impersonate only users with matching label
policy update requires kernel role and signed policy source
tooling service may propose but not execute PMS-IR
```

Ω-hooks make authority transitions explicit and policy-bound.

### 6.17 Θ-Hooks — Scheduling and Ordering

Θ-hooks apply at ordering and scheduling points.

Examples:

```text
scheduler tick
dispatch selection
preemption
workqueue dispatch
timer activation
interrupt priority decision
cache flush ordering
driver bottom-half scheduling
audit sequencing
expiry checks
```

Policy examples:

```text
process may not exceed CPU budget in τ-window
real-time thread must not be starved
driver interrupt handler must stay within budget
idle task must not starve policy-critical tasks
capability expires after τ deadline
session must rotate key after interval
```

Θ-hooks govern order and progression. Physical or logical time values are τ-derived metadata in runtime state.

### 6.18 Λ-Hooks — Absence, Wait, Timeout

Λ-hooks apply when an expected event, resource, response, or condition is absent.

Examples:

```text
empty IPC queue
lock unavailable
timer missed
device not ready
allocation cannot be satisfied
expected hotplug event absent
blocking syscall timeout
network no-route
host-service no-response
missing credential
unsupported runtime feature
```

Policy examples:

```text
timeout after τ deadline
retry with Θ backoff
escalate repeated absence to Φ
treat missing device response as quarantine trigger
return no-resource instead of trap under soft quota
```

Λ-hooks convert non-events into typed runtime behavior.

### 6.19 Φ-Hooks — Trap, Fault, and Recontextualization

Φ-hooks apply when execution changes interpretation or context.

Examples:

```text
syscall entry
page fault
protection fault
interrupt entry
exception return
signal delivery
driver error
OOM handling
process kill path
quarantine entry
network credential mapping
version migration
FFI error mapping
```

Policy examples:

```text
on page fault from sandbox, deny mapping and signal process
on repeated driver fault, quarantine device
on policy violation, enter audit frame
on trap return, verify target frame and role
on remote identity mismatch, map to restricted session principal
```

Φ-hooks ensure recontextualization preserves invariants.

### 6.20 Χ-Hooks — Isolation and Boundary Change

Χ-hooks apply to boundary transitions.

Examples:

```text
sandbox enter/exit
container namespace switch
IPC bridge creation
shared memory map
host boundary entry
network session establishment
driver/device binding
audit export
trust-anchor access
module import/export
sealed isolation exit
```

Policy examples:

```text
container may not mount host root
module may not export internal mutable state
driver may not DMA into kernel frame
network session may not bypass credential mapping
debugger may see redacted trace only
unbalanced isolation exit is rejected
```

Χ-hooks make isolation enforceable as an implementation-layer projection of PMS Base Distance.

A sealed isolation context forbids further entry, expansion, or reachability growth. It still permits valid exit, closure, audit, rollback, or commit under the declared policy and active boundary context.

Sealing is not the same as trapping execution forever.

### 6.21 Σ-Hooks — Commit and Integration

Σ-hooks apply at commit boundaries.

Examples:

```text
filesystem transaction
network packet transmission
IPC delivery
process state commit after exec
policy installation
capability grant
trust-anchor rotation
audit record commit
resource accounting update
quarantine state commit
driver binding commit
distributed vote/commit
```

Policy examples:

```text
commit only if integrity tags match
log every Σ touching high-value resources
deny commit if prior Ω or Χ checks failed
require audit commit before exposing trust-anchor update
require durable commit for security-critical policy change
```

Σ-hooks ensure that policy-invalid state does not become stable.

Distributed commit markers here are boundary-facing integration references. Full distributed semantics belong to `07_distributed_systems.md` and declared distributed runtime profiles.

### 6.22 Policy Enforcement Actions

Policy decisions become enforcement actions.

Actions include:

```text
allow
deny
modify
transform
defer
audit
rollback
quarantine
revoke
attenuate
throttle
suspend
terminate
escalate
halt
```

#### Allow

```text
Ψ decision = ALLOW
```

Transition proceeds.

#### Deny

```text
Ψ decision = DENY
```

Transition does not execute.

Possible result:

```text
Λ absent outcome
Φ policy trap
error return
audit-only denial record
```

#### Modify

Policy rewrites operation parameters.

Examples:

```text
path rewrite into namespace root
capability attenuation
redaction of audit export
priority downgrade
rate-limit adjustment
```

Modify must be traceable.

#### Transform

Policy invokes Φ.

Examples:

```text
convert illegal memory access into trap
redirect syscall to compatibility handler
map remote identity to restricted local session
enter rollback context
enter quarantine context
```

#### Quarantine

Policy tightens Χ projection.

Examples:

```text
driver quarantine
process sandboxing
network session isolation
node isolation
tooling service restriction
```

Quarantine is not a moral or forensic judgment. It is a runtime-security boundary action.

#### Revoke / Attenuate

Policy changes Ω authority.

Examples:

```text
remove capability
narrow capability path
drop debug authority
revoke session role
downgrade network role
```

#### Rollback / Compensate

Policy invokes Σ recovery.

Examples:

```text
abort filesystem transaction
undo capability grant
discard staged audit export
rollback module reframe
```

#### Halt

Policy enters critical halt state.

Use for:

```text
kernel invariant failure
trust-anchor corruption
policy engine corruption
unsafe trap return
unrecoverable global consistency violation
```

Halt must be profile-defined.

### 6.23 Enforcement Timing

Policy enforcement may occur at several times.

```text
precheck
mid-transition check
commit check
postcheck
continuous check
audit check
```

#### Precheck

Before action executes.

```text
Ω/Χ/Ψ before ∇
```

Used for:

```text
access control
syscall admission
FFI admission
device operation
network connect
```

#### Mid-Transition Check

During multi-step operation.

Used for:

```text
long-running copy
streaming network transfer
multi-block filesystem write
driver firmware update
distributed protocol sequence
```

#### Commit Check

Before Σ makes state visible.

Used for:

```text
filesystem commit
policy update
capability grant
trust-anchor rotation
IPC delivery
distributed commit
```

#### Postcheck

After tentative operation but before return.

Used for:

```text
trap return validation
resource accounting verification
audit completion
integrity tag check
```

#### Continuous Check

Runtime monitor over ordered Θ progression.

Used for:

```text
CPU quotas
session expiry
driver health
network rate limits
audit retention
```

### 6.24 Policy Caching and Fast Paths

Policy evaluation may be cached.

Cache key:

```text
CacheKey = (
    actor_id,
    role,
    operator_class,
    concrete_operation,
    target_id,
    coarse_context,
    policy_epoch
)
```

A cached decision is valid only while:

```text
policy_epoch unchanged
∧ actor role/capability unchanged
∧ target frame/boundary state unchanged
∧ relevant resource state unchanged
∧ τ/lifetime constraints unchanged
∧ trust state unchanged
```

Fast path rule:

```text
FastPathPre(s, op) ⇒ allow
```

A fast path is valid only when:

```text
all relevant policy dependencies are included in FastPathPre
∧ no active hook could produce a different decision
∧ invalidation conditions are explicit
∧ audit behavior is preserved
```

Invalid fast path:

```text
skip policy check because previous access was allowed
```

Valid fast path:

```text
allow repeated read only while:
    same principal
    same role/capability epoch
    same frame/boundary epoch
    same policy epoch
    same target label
    same resource constraints
```

No security fast path may bypass active Ψ constraints.

### 6.25 Policy Installation and Modification

Policy mutation is security-critical.

Operations:

```text
Psi_CREATE(policy_spec)
Psi_VALIDATE(policy_spec)
Psi_LOAD(policy_spec)
Psi_ACTIVATE(policy_id)
Psi_UPDATE(policy_id, new_spec)
Psi_SET_MODE(policy_id, mode)
Psi_DISABLE(policy_id)
Psi_DELETE(policy_id)
Psi_REVOKE(policy_id)
Psi_ARCHIVE(policy_id)
```

Mutation path:

```text
Δ classify mutation
Ω verify policy-management capability
Χ check management boundary projection
Ψ check mutation policy
Φ migrate/recontextualize if needed
Σ commit policy mutation
Θ audit mutation
```

Policy mutation requirements:

```text
authorized manager principal
valid source/provenance
valid signature or trust binding if required
schema-valid policy expression
no weakening of protected lower-level invariants
defined conflict-resolution behavior
defined failure mode
audit requirement satisfied
```

Policy update invariant:

```text
policy update cannot invalidate the invariants required to perform policy update safely.
```

Policy source presence is not authority.

```text
file exists
message arrived
repository contains policy
AI generated a policy candidate
≠ policy active
≠ policy authoritative
```

### 6.26 Policy Validation

Before activation, a policy should be validated.

Validation checks:

```text
syntax/schema validity
scope validity
predicate type validity
action validity
priority/composition validity
mode validity
lifecycle validity
non-weakening of inherited policies
conflict detection
resource-reference validity
operator-reference validity
audit-profile validity
trust-source validity
runtime-profile support
```

Static validation result:

```text
accepted
accepted_with_warnings
rejected
unsupported_profile
conflict_detected
requires_higher_authority
```

Policy validation is not the same as runtime enforcement. It checks that a policy object is admissible as policy under a declared schema/profile.

Runtime enforcement checks operations under active state.

Policy validation does not externally validate PMS Base, prove deployment security, or prove that every future runtime transition will be secure.

### 6.27 Policy Conflict Resolution

Policies may conflict.

Conflict kinds:

```text
allow vs deny
modify vs deny
audit export vs redaction
commit vs rollback
quarantine vs continue
fail-open vs fail-closed
local relaxation vs global invariant
```

Resolution strategies:

```text
deny_overrides
priority_order
most_restrictive
scope_specificity
kernel_invariant_overrides
fail_closed_on_conflict
explicit_composition_rule
```

Recommended default:

```text
critical invariant conflict ⇒ fail closed
ordinary policy conflict ⇒ explicit priority/composition
local-vs-global conflict ⇒ global/lower-level invariant wins
```

Conflict result must be auditable.

A runtime must not silently choose the result that maximizes convenience, performance, or permissiveness.

### 6.28 Policy and Audit

Policy decisions may be audit events.

Policy audit record:

```text
PolicyAuditRecord = (
    event_id,
    actor,
    effective_actor,
    target,
    operator_class,
    operation,
    policy_ids,
    decision,
    action,
    frame,
    boundary,
    role,
    capability,
    order,
    timestamp?,
    metadata
)
```

Audit flow:

```text
Δ prepare audit record
Θ order audit event
Σ commit audit record
Ψ enforce audit retention/integrity
```

Policy may require:

```text
audit on allow
audit on deny
audit on modify
audit on quarantine
audit on grant/revoke
audit on trust-anchor use
audit on policy mutation
durable audit before commit
redacted audit export
hash-chain audit record
```

Audit failure may itself trigger policy action:

```text
audit required but unavailable
    ⇒ deny
    ⇒ defer
    ⇒ quarantine
    ⇒ fail closed
```

depending on policy class.

Audit records are runtime-security evidence artifacts.

They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 6.29 Policy and Compliance

Compliance is policy-based meta-checking over runtime traces, audit records, commits, and invariants.

Compliance verifier input:

```text
Θ event stream
Σ commit records
policy set
principal graph
role/capability graph
isolation graph
resource accounts
trust-anchor state
runtime profile
```

Compliance checks:

```text
required audits present
no forbidden operator transitions
capability denials occurred where required
policy mutations authorized and committed
trust-anchor rotations valid
quarantine events committed
resource quotas enforced
commit records consistent
redaction policies followed
```

Compliance means checking runtime evidence against declared policy, profile, retention, redaction, and conformance obligations.

It does not mean social governance, legal adjudication, tribunal status, universal security certification, forensic omniscience, moral authority, or PMS Base validation.

Compliance reports are evidence surfaces under declared profiles. They may support conformance inspection and operational review, but they do not prove complete security or validate PMS Base.

### 6.30 Policy Domains

Policy domains include:

```text
memory
process/thread
scheduler
IPC/channel
filesystem
network
driver/device
module/runtime
FFI/host
debug/audit
trust-anchor/key
resource accounting
distributed node
AI/tooling
```

Each domain is a runtime-security enforcement surface. A domain policy specifies constraints over operator-typed transitions in that domain; it does not by itself complete the corresponding subsystem implementation.

#### Memory Policy

Examples:

```text
no write to read-only frame
no execute from writable frame
no user map of kernel frame
sandbox may not map host memory
```

#### Process/Thread Policy

Examples:

```text
no role escalation without kernel-mediated Φ
process must stay inside FrameSet
thread must not outlive parent TaskGroup unless detached under policy
```

#### Scheduler Policy

Examples:

```text
no starvation of policy-critical task
process may not exceed CPU quota
driver interrupt handler must remain within budget
```

#### IPC Policy

Examples:

```text
sender must hold channel.send
receiver must hold channel.recv
payload type must match
capability transfer requires delegation policy
```

#### Filesystem Policy

Examples:

```text
path prefix restrictions
namespace crossing denial
durability required for audit log
append-only security log
```

#### Network Policy

Examples:

```text
required credential mapping
no plaintext on protected endpoint
rate limit per session
remote node must be admitted before cluster action
```

Network policy in this section defines runtime-security enforcement. It does not claim a completed network stack, transport implementation, cryptographic library, distributed consensus implementation, cluster policy synchronization, global commit protocol, or multi-node failure semantics.

Distributed semantics belong to `07_distributed_systems.md` and declared distributed runtime profiles.

#### Driver / Device Policy

Examples:

```text
driver may access only assigned MMIO region
DMA region must be declared before use
driver quarantine on repeated invariant violation
device firmware validation requires declared trust profile
```

Driver/device policies constrain runtime authority. They do not certify hardware behavior or prove deployment security.

#### FFI / Host Policy

Examples:

```text
foreign call requires HostService profile
host pointer transfer requires memory profile
host error must map to Φ or Λ
host result is advisory unless committed by runtime
```

Host policy prevents host behavior from becoming untyped PMS-STACK behavior.

A host runtime may support execution. It does not become PMS-OS.

#### Debug / Audit Policy

Examples:

```text
debug trace requires observer capability
audit export requires redaction policy
audit log mutation requires durable commit
debug access must be audited when profile requires it
```

Audit records are runtime-security evidence artifacts. They are not forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

#### Trust-Anchor / Key Policy

Examples:

```text
key use requires key-frame authority
credential freshness must be checked
revocation state must be consulted before mapping identity
trust-anchor rotation requires authorized policy path and audit
```

A trust anchor does not create authority by existing. A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

#### Resource-Governance Policy

Examples:

```text
process memory ≤ limit
container CPU share ≤ quota
IPC rate ≤ max messages per τ-window
network bytes ≤ budget
audit log storage ≥ required retention
```

Resource policy governs runtime capacity. It is not social evaluation or person ranking.

#### AI / Tooling Policy

Examples:

```text
AI may propose PMS-IR
AI may not execute PMS-IR
AI may analyze redacted traces only
tooling output is advisory until host validation
```

Standard boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI/tooling output is not trusted executable code, compiler authority, verification evidence, runtime policy authority, or PMS Base validation.

### 6.31 Policy-Based Transformation

Ψ may instruct the runtime to transform an operation via Φ.

Form:

```text
Ψ(s, op) = transform(Φ(pattern))
op'      = Φ(op)
```

Examples:

```text
illegal memory access → Φ_trap<ProtectionFault>
unsupported runtime feature → Λ_absent<RuntimeFeature> or Φ_trap
version mismatch → Φ_reframe<CompatibilityContext>
policy denial → Φ_security_violation
network remote identity → Φ_local_session_mapping
host error → Φ_trap<HostError>
driver repeated fault → Φ_quarantine_context
```

Transformation rule:

```text
transformed operation must itself satisfy Ψ invariants.
```

A policy transformation may not smuggle invalid state into a valid context.

Examples of invalid transformation:

```text
policy denial transformed into silent success
host error transformed into trusted PMSL result without error map
AI proposal transformed into executable PMS-IR without host validation
quarantined subject transformed into active subject without release policy
```

Valid transformation preserves:

```text
Δ classification
Ω authority constraints
□ frame validity
Χ boundary projection
Ψ policy constraints
Φ interpretation change
Σ commit discipline
Θ audit/order visibility
```

### 6.32 Policy and Commit

Σ is policy-governed.

Before a commit becomes visible, durable, global, or authoritative, policy may require:

```text
integrity tag
capability check
resource check
audit record
trust-anchor verification
quorum proof under distributed profile
transaction consistency
rollback path
redaction
commit profile match
```

Commit policy examples:

```text
filesystem commit requires integrity tag
security audit write requires durable commit
capability grant requires audit commit
policy update requires signed source and kernel role
distributed commit requires quorum
trust-anchor rotation requires prior revocation state
```

Commit validity:

```text
valid_commit(s, Σ, subject) iff
    committable(subject)
    ∧ prior checks valid
    ∧ Ψ_commit permits
    ∧ audit obligations satisfied
```

No invalid transition should become stable through Σ.

Distributed commit references in this section are runtime-security integration points. Their full semantics belong to `07_distributed_systems.md` and the declared distributed runtime profile.

### 6.33 Policy and Quarantine

Quarantine is a Ψ-driven Χ response.

Policy may quarantine:

```text
process
thread
driver
device
module
container
network session
distributed node
tooling service
AI service
filesystem subtree
IPC endpoint
```

Quarantine action:

```text
Ψ decision = QUARANTINE
→ Φ enter restricted context
→ Χ tighten projected boundary
→ Ω revoke/attenuate capability
→ Σ commit quarantine state
→ Θ audit event
```

Quarantine policy examples:

```text
repeated driver faults
policy-tampering attempt
unexpected device DMA
network node violates quorum protocol
AI/tooling service attempts execution authority
process attempts kernel-frame write
```

Quarantine must be visible to:

```text
scheduler
resource accounting
IPC
network routing
audit
capability checks
policy evaluation
runtime reports
```

Quarantine is not a moral judgment, legal verdict, forensic conclusion, or person-level sanction. It is a runtime-security boundary action.

A successful quarantine evidences a specific runtime response under a declared profile. It does not prove complete security or eliminate all attack variants.

### 6.34 Policy and Trust Anchors

Trust anchors are policy-defined interpretation roots.

A credential, key, or signature becomes relevant only through policy.

Trust policy checks:

```text
key type
issuer
scope
expiry
revocation state
usage constraints
principal mapping
session boundary
rotation rules
audit requirement
```

Trust flow:

```text
Δ classify credential/key
Ω verify key-use authority
Χ check key-frame isolation
Ψ evaluate trust policy
Φ interpret credential
Σ commit trust/session state
```

Policy governs:

```text
what counts as a valid credential
where trust propagates
when keys expire
who may rotate trust anchors
how revocation affects live sessions
which audit evidence is required
```

Trust validation in this section means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, and runtime policy profile.

It does not mean external validation of PMS Base, universal identity truth, legal identity proof, or universal trust.

A key verifies a cryptographic relation under a profile. A policy interprets what that relation means. The runtime commits only the resulting local trust state.

This section specifies trust-anchor and key-management policy architecture. It does not specify a mandatory cryptographic algorithm, certify cryptographic strength, prove deployment security, or validate PMS Base.

### 6.35 Policy and Resource Governance

Resource policies constrain runtime consumption.

Resource policy examples:

```text
process memory ≤ limit
container CPU share ≤ quota
IPC rate ≤ max messages per τ-window
network bytes ≤ budget
audit log storage ≥ required retention
driver interrupt rate ≤ budget
tooling trace export ≤ redacted quota
```

Resource enforcement:

```text
Δ classify resource event
Ω identify accountable principal
Θ order usage update
Σ commit accounting
Ψ evaluate quota
Λ no-resource if recoverable
Φ trap/reframe if critical
```

Possible responses:

```text
allow
throttle
delay
return no-resource
reduce priority
revoke capability
quarantine
terminate
```

Resource governance is runtime governance. It does not mean social governance, person evaluation, moral ranking, legal adjudication, or clinical classification.

### 6.36 Policy and Runtime Profiles

A policy may depend on runtime profile.

Profiles:

```text
production
debug
simulation
deterministic_test
host_runtime
pms_os_runtime
distributed_runtime
high_assurance
audit_heavy
sandboxed
```

Example profile constraints:

```text
debug profile may allow trace inspection
production profile requires redaction
deterministic_test profile forbids nondeterministic host calls
high_assurance profile fails closed on policy ambiguity
simulation profile may evaluate shadow policies
```

Policy must declare profile assumptions.

```text
policy valid under profile P
≠ policy valid under all profiles
```

Profile-bound validity prevents portability overclaim.

A policy accepted under a simulation profile does not automatically become valid under production, host-runtime, PMS-OS-runtime, distributed-runtime, or high-assurance profiles.

### 6.37 Policy Reports

A runtime may emit policy reports.

Report form:

```text
PolicyReport = (
    policy_set_id,
    active_policies,
    modes,
    priorities,
    conflicts,
    decisions,
    denials,
    modifications,
    quarantines,
    audit_requirements,
    cache_state,
    lifecycle_events,
    limitations,
    meta
)
```

Useful views:

```text
policies by scope
policies by operator
policies by principal
policies by resource
policy conflicts
policy-denied transitions
policy-modified transitions
policy-triggered quarantines
policy audit coverage
policy cache invalidations
shadow-policy differences
```

Policy reports support:

```text
debugging
compliance inspection
verification preparation
governance inspection
trace conformance
runtime diagnostics
```

They do not replace enforcement.

Policy reports are evidence surfaces under declared profiles. They do not constitute forensic proof, legal judgment, moral authority, universal security certification, or PMS Base validation.

### 6.38 Policy Verification and Trace Conformance

Policy systems can be checked.

Static analysis checks:

```text
policy syntax/schema
scope validity
operator references
unsupported actions
conflicts
non-weakening
missing audit profiles
missing failure modes
```

Model checking can verify stated properties under a declared model/profile:

```text
no protected action reaches ∇ without Ψ allow
no policy mutation occurs outside kernel role
no local policy weakens global invariant
no denied transition reaches Σ success
no driver reaches unassigned device frame
no quarantined subject sends IPC
```

Trace conformance checks observed behavior against declared policy expectations:

```text
every protected transition has policy decision
every denial is represented
every quarantine has Χ tightening
every audit-required event has Σ audit commit
every policy mutation has Ω and Ψ authorization
```

Policy verification boundary:

```text
policy verification establishes stated properties under stated model,
profile, assumptions, and artifact scope.
```

Trace-conformance boundary:

```text
trace conformance checks observed traces against declared expectations.
It does not prove all possible executions unless paired with stated
coverage, model, bounds, and proof or model-checking artifacts.
```

Golden fixtures stabilize regression behavior. They do not prove full policy coverage or validate PMS Base.

Policy verification and trace conformance do not validate PMS Base.

### 6.39 Policy Failure Modes

Policy failure is operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| policy not found | Δ / Λ |
| policy disabled unexpectedly | Ψ / audit |
| predicate error | Φ / Ψ |
| conflict unresolved | Ψ |
| missing context | Δ / Λ |
| unsupported action | Λ / Φ |
| policy cache stale | Θ / Ψ |
| policy source invalid | Δ / Ψ / Φ |
| policy signature invalid | Δ / Ψ |
| policy update unauthorized | Ω / Ψ |
| local policy weakens invariant | Ψ |
| audit required but unavailable | Σ / Ψ / Φ |
| enforcement action fails | Φ / Σ / Ψ |
| critical invariant violation | Ψ halt/quarantine |

Policy failure mode must be explicit.

Default for critical policy failure:

```text
fail closed
audit if possible
recontextualize or quarantine
halt if global invariant is unsafe
```

A fail-open policy is permitted only when the declared profile allows it and the risk boundary is explicit.

### 6.40 Policy Scenarios

Policy scenarios are executable architecture tests or conformance storyboards.

They specify:

```text
initial state
attempted transition or attack word
expected operator obligation
expected rejection or acceptance point
expected runtime response
expected audit/evidence artifact
claim boundary
```

They do not prove complete runtime security.

#### Unauthorized Privilege Escalation

Attempt:

```text
w =
    Δ_targetRole
    ; ∇_requestRole(Ω_root)
    ; Ω_elevate
```

Policy:

```text
Ψ_role_monotonicity:
    no escalation to higher role without approved transition path
```

Runtime response:

```text
Ω_elevate reaches policy hook
Ψ denies transition
Φ traps into violation frame
Σ rolls back partial effects if any
Θ/Σ commits audit
```

Boundary:

```text
This scenario checks one privilege-escalation attempt under a declared
profile. It does not prove that all escalation variants are impossible.
```

#### Isolation Leak

Attempt:

```text
w =
    Δ_secretObj
    ; ∇_read(secretObj)
    ; Χ_bypass_attempt
```

Policy:

```text
Ψ_cross_frame:
    all cross-frame reads require C_readSecret
```

Runtime response:

```text
Χ detects forbidden crossing
Ω lacks capability
Ψ denies
Φ enters violation context
Σ audit/rollback
```

Boundary:

```text
The attack word describes attempted behavior, not successful execution.
```

#### Transaction Failure

Attempt:

```text
w =
    ∇_open
    ; Δ_path
    ; ∇_write
    ; Δ_validate
    ; ∇_stage
    ; Φ_error
    ; Σ?
```

Policy:

```text
Ψ_tx:
    Σ final commit only if all transaction steps valid
```

Runtime response:

```text
Φ enters recovery frame
Ψ denies final Σ
Σ_rollback reverts staged writes
Θ/Σ audits failure
```

Boundary:

```text
A rejected final commit evidences behavior under the transaction policy
profile. It is not proof of all transaction behavior.
```

#### Policy Tampering

Attempt:

```text
w =
    Δ_shadowPolicy
    ; Ω_escalate?
    ; Ψ_redefine
```

Policy:

```text
Ψ_policy_integrity:
    Ψ mutation only inside kernel-governed frame by authorized role
```

Runtime response:

```text
Ω denies mutation authority
Ψ rejects redefinition
Φ traps or quarantines
Σ commits audit
```

#### AI/Tooling Boundary Violation

Attempt:

```text
w =
    Δ_ai_output
    ; ∇_execute(proposed_ir)
    ; Σ_runtime_commit
```

Policy:

```text
Ψ_ai_advisory:
    AI/tooling output is advisory unless host validation and runtime
    acceptance authorize a specific artifact.
```

Runtime response:

```text
Δ classifies tooling artifact
Ω checks tooling capability
Χ enforces tooling/host boundary
Ψ denies execution authority
Φ recontextualizes as violation if needed
Σ commits audit/rejection record
```

Boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 6.41 Scenarios and Golden Fixtures

Each policy scenario may be converted into a golden fixture by declaring:

```text
input program or event sequence
runtime profile
expected validation decision
expected trace/audit events
expected rejection or commit point
limitations
```

Example fixture shape:

```text
fixture policy_tampering_rejected {
    profile = deterministic_runtime_security
    input = [
        Delta.shadow_policy,
        Omega.escalate_attempt,
        Psi.redefine_attempt
    ]
    expected_validation = rejected
    expected_rejection_point = Psi.policy_integrity
    expected_trace_contains = [
        Delta.classify(policy_mutation),
        Omega.deny(policy_management_capability),
        Psi.deny(policy_integrity),
        Phi.trap_or_quarantine,
        Sigma.audit_commit
    ]
    limitation = "single scenario fixture; not proof of all policy-tampering variants"
}
```

Golden fixtures stabilize regression expectations.

They do not prove full security coverage, complete policy correctness, complete runtime-security implementation, or PMS Base validation.

### 6.42 Policy and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of policy/governance discipline:

```text
model/dependency validation
stateful validation
operator-tagged runtime checks
fail-closed validation paths
JSONL trace/audit output
golden fixtures for rejected programs
vFS service boundary discipline
AI proposal gating
```

Correct relation:

```text
Runtime policy specification
    defines Ψ obligations.

PMS-RUST bounded artifacts
    demonstrate executable slices of validation, traceability,
    rejection, service-boundary discipline, and proposal gating.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime policy enforcement, complete runtime security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, prove deployment security, or make tests/traces proofs.

PMS-RUST-style policy evidence is useful when it follows the pattern:

```text
runtime-security claim
→ executable slice
→ validation rule
→ golden fixture
→ JSONL trace evidence
→ stated limitation
```

PMS-RUST `chi_exit` may evidence bounded isolation-exit discipline where policy requires active boundary context before exit.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 6.43 AI / Tooling Policy Boundary

AI/tooling may propose PMS-IR, summarize traces, explain diagnostics, suggest missing policies, suggest scenarios, or draft test fixtures.

AI/tooling may not:

```text
authorize execution
define semantics
replace policy evaluation
replace verification
grant capabilities
commit runtime state
serve as trusted executable code
serve as compiler authority
serve as verification evidence
serve as runtime policy authority
validate PMS Base
```

Policy for AI/tooling must preserve advisory/execution separation.

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

An AI/tooling violation occurs when advisory output attempts to become execution authority, policy authority, verifier authority, capability grant, runtime commit, or trusted executable code without host-side acceptance.

Runtime response:

```text
Δ classify tooling artifact
Ω check tooling capability
Χ enforce tooling/host boundary
Ψ deny execution authority
Φ recontextualize as violation if needed
Σ commit audit/rejection record
```

### 6.44 Policy Claim Boundary

The PMS-STACK policy model claims:

```text
runtime governance can be represented as explicit Ψ constraints over
operator transitions, scopes, predicates, actions, modes, hooks,
lifecycle states, enforcement decisions, audit obligations, trust rules,
resource limits, quarantine decisions, trace expectations, and commit
requirements.
```

It does not claim:

```text
policies are automatically correct
all policy conflicts are semantically resolved by syntax
runtime policy equals legal authority
governance equals tribunal
audit equals forensic proof
tests or traces prove complete security
implementation artifacts validate PMS Base
AI/tooling output is trusted executable code
AI/tooling output is verification evidence
PMS-RUST completes runtime policy enforcement
```

Policy is strong because it is explicit, enforceable, inspectable, and auditable. Its claim is bounded by declared policies, profiles, implementations, assumptions, and evidence artifacts.

### 6.45 Policy Invariants

Runtime security maintains the following Ψ invariants.

```text
I1: every active policy has a Δ-distinguishable id
I2: every active policy has explicit scope, mode, priority, predicate, and action
I3: every protected transition has a policy hook or an explicit reason no hook is required
I4: every policy-governed transition is evaluated before protected ∇ or Σ
I5: every policy mutation is Ω-authorized and Σ-committed
I6: local policies cannot silently weaken global/kernel invariants
I7: policy conflicts are resolved by explicit priority/composition rules
I8: policy failure mode is explicit: fail-open, fail-closed, audit-only, disabled, or profile-defined
I9: enforcement actions are operator-typed
I10: Φ recontextualization caused by policy preserves active invariants
I11: Χ isolation caused by policy is committed and visible to scheduler/resource logic
I12: Σ commits are policy-checked before global visibility
I13: policy caches are invalidated on relevant policy, role, boundary, resource, trust, or time-context changes
I14: audit-required policy decisions are Θ-ordered and Σ-committed
I15: policy installation, activation, update, suspension, revocation, and deletion are lifecycle-governed
I16: trust-anchor policies govern credential interpretation before local authority assignment
I17: resource policies govern quota, throttling, no-resource outcomes, traps, and quarantine
I18: AI/tooling policies preserve advisory boundaries unless explicit execution authority is separately granted
I19: no policy fast path bypasses Ω, Χ, Ψ, Φ, or Σ
I20: policy evidence strengthens runtime-security implementation claims and does not function as PMS Base validation
I21: policy trace conformance checks observed behavior under declared profiles; it is not proof of all executions
I22: golden fixtures stabilize regression expectations; they do not prove full policy coverage
I23: PMS-RUST-style artifacts may evidence bounded policy slices; they do not complete runtime security or validate PMS Base
```

### 6.46 Architectural Consequence

The consequence is:

```text
PMS-STACK policy is not a configuration file or an external rule engine.
It is the Ψ-governed runtime language of admissibility: the layer that
decides which operator transitions may proceed, which must be denied,
which must be transformed, which must be audited, which must be rolled
back, which must be quarantined, and which may become committed state.
```

This gives runtime security a uniform enforcement architecture for:

```text
kernel invariants
capability grants
role transitions
process isolation
filesystem operations
IPC
network sessions
driver/device access
FFI and host calls
audit visibility
trust-anchor management
resource quotas
debugging and tooling
AI proposal boundaries
distributed-node authority
policy lifecycle
```

The next section specializes this Ψ machinery into kernel policy hooks: the concrete runtime points where policy decisions attach to syscalls, scheduling, memory, IPC, devices, commits, traps, boundaries, and audit.

### 6.47 Policy Definition and Enforcement Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK policy definition and enforcement model specifies
implementation-layer runtime-security / governance architecture:
policy objects, scopes, modes, lifecycle, layers, algebra, decisions,
evaluation pipelines, context collection, hooks, enforcement actions,
timing, caching, installation, validation, conflict resolution, audit,
compliance, policy domains, transformation, commit governance,
quarantine, trust-anchor policy, resource governance, runtime profiles,
reports, verification, trace conformance, failure modes, scenarios,
golden-fixture candidates, PMS-RUST evidence boundaries, AI/tooling
policy boundaries, and Ψ-invariants.

This is a runtime-security policy / enforcement architecture claim.

It does not claim completed runtime-policy implementation, universal
security certification, complete deployment security, complete network
security, complete distributed runtime, legal authority, moral authority,
clinical authority, forensic omniscience, tribunal status, trusted AI
authority, proof of all security properties, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
model/dependency validation, stateful validation, operator-tagged runtime
checks, fail-closed rejection paths, JSONL traces, golden fixtures, vFS
service boundaries, bounded isolation-exit discipline, and AI proposal
gating. It does not complete runtime policy enforcement and does not
validate PMS Base.
```

---

## 7. Kernel Policy Hooks

Kernel policy hooks are the enforcement attachment points of the Kernel Policy Engine.

They connect the abstract Ψ policy model to concrete kernel transitions: syscalls, traps, scheduling, memory mapping, process creation, IPC, filesystem operations, network operations, device access, driver binding, resource accounting, audit, trust-anchor management, policy mutation, quarantine, and commit boundaries.

The central kernel-hook claim is:

```text
A PMS-STACK kernel policy hook is valid when it attaches Eval_Ψ to an
operator-typed kernel transition before that transition can mutate,
cross a boundary, change authority, change frame context, become visible,
or become committed state.
```

Claim type:

```text
RUNTIME-SECURITY KERNEL-HOOK / POLICY-ENFORCEMENT ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK kernel policy hooks as
implementation-layer runtime-security enforcement architecture.

It does not claim that every implementation has installed every hook,
that hook presence alone proves security, that audit logs are forensic
proof, that tests/traces prove complete security, or that PMS-STACK
validates PMS Base.

Kernel hooks make runtime governance executable at declared transition
points. They do not replace the PMS-CPU control-transfer convention or
the PMS-OS syscall ABI.
```

Kernel policy hooks are therefore not “callbacks” in an incidental implementation sense. They are the kernel’s operator-governed enforcement joints.

```text
Kernel Policy Engine:
    KPE = (PSet_k, Eval_Ψ, Hooks, Actions)
```

where:

```text
PSet_k  = active kernel policy set
Eval_Ψ  = policy evaluation function
Hooks   = operator-specific attachment points
Actions = allow, deny, transform, isolate, rollback, audit, halt, ...
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At kernel-hook level, Χ is projected as process boundary, address-space boundary, namespace boundary, sandbox/container boundary, device boundary, driver boundary, IPC visibility boundary, filesystem view boundary, DMA boundary, host/FFI boundary, network/session boundary, audit visibility boundary, quarantine boundary, and trust-boundary control.

Kernel hooks use this Χ projection. They do not redefine PMS Base Χ.

Validation in this section means acceptance or rejection under a declared runtime-security hook schema, policy, model, profile, artifact, trace schema, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

### 7.1 Role of Kernel Policy Hooks

Kernel policy hooks answer one question:

```text
May this operator-typed kernel transition proceed?
```

A hook is called at a point where the kernel is about to:

```text
distinguish a branch
perform mutation
enter a frame
change authority
advance scheduling/order
represent absence
handle trap/recontextualize
cross isolation boundary
commit state
emit audit evidence
```

General hook form:

```text
PolicyHook = (
    operator_class,
    operation,
    state,
    context
)
```

Evaluation:

```text
decision = Eval_Ψ(PSet_k, state, operation, context)
```

Enforcement:

```text
Apply(decision, state, operation, context)
```

A hook is valid only if it occurs before the relevant effect becomes irreversible or externally visible.

```text
pre-effect hook    before ∇
pre-boundary hook  before Χ crossing
pre-authority hook before Ω grant/elevation
pre-commit hook    before Σ
pre-return hook    before Φ return
```

### 7.2 Kernel Hook Surface

The kernel hook surface includes:

```text
syscall dispatch
syscall argument validation
trap entry
trap return
interrupt handling
exception handling
process creation
thread creation
context switch
scheduler selection
memory mapping
shared-memory creation
frame switch
capability grant/revoke
role transition
IPC send/receive
channel bridge creation
filesystem path resolution
filesystem mutation
filesystem commit
network connect/send/receive
driver load/bind/unbind
device MMIO/DMA access
resource accounting update
audit event emission
policy installation/update
trust-anchor rotation
quarantine entry/exit
kernel halt path
```

Each hook has:

```text
operator class
concrete operation
required context
policy scope
decision type
enforcement action
audit behavior
failure mode
```

A kernel without hooks at these points may still perform operations, but it is not enforcing PMS-STACK runtime-security policy at those points.

Hook coverage is therefore part of runtime-security conformance, not proof of complete security.

### 7.3 Hook Contract

Every kernel hook must satisfy a contract.

```text
HookContract = (
    name,
    operator_class,
    trigger,
    pre_state,
    context_builder,
    policy_scope,
    eval_function,
    allowed_decisions,
    enforcement_actions,
    postconditions,
    audit_profile,
    failure_mode
)
```

Example:

```text
HookContract {
    name: syscall_open_pre
    operator_class: Δ/Ω/Χ/Ψ
    trigger: before open(path) dispatches to filesystem operation
    context_builder: syscall_context(pid, role, path, namespace, caps)
    policy_scope: SYSCALL(open) ∪ FILESYSTEM(path) ∪ ROLE(role)
    allowed_decisions: ALLOW | DENY | MODIFY | AUDIT | QUARANTINE
    failure_mode: FAIL_CLOSED
}
```

Hook invariant:

```text
if hook_required(op) and hook_missing(op):
    transition is not policy-complete
```

A missing hook is a coverage gap. It is not automatically a proof of insecurity, but it is a runtime-security conformance failure for the declared hook profile.

### 7.4 Hook Ordering

Hook ordering matters.

A canonical protected kernel transition follows:

```text
Δ classify
→ Ω authorize
→ □ locate / switch frame
→ Χ check boundary projection
→ Ψ evaluate policy
→ ∇ perform action
→ Σ commit result
→ Θ audit/order event
→ Φ return or trap if needed
```

Hook sequence:

```text
H_Δ
→ H_Ω
→ H_□
→ H_Χ
→ H_Ψ
→ H_∇
→ H_Σ
→ H_Θ
→ H_Φ
```

Not every transition uses every hook. But a transition must use every hook relevant to its operator obligations.

Example filesystem write:

```text
H_Δ_path
H_Ω_fs_write
H_Χ_namespace
H_Ψ_fs_policy
H_∇_write
H_Σ_commit_visible_or_durable
H_Θ_audit
H_Φ_error_or_return
```

Example context switch:

```text
H_Θ_select
H_Σ_save_old_thread
H_□_switch_frame
H_Ω_set_role
H_Χ_domain_check
H_Ψ_scheduler_policy
H_Θ_dispatch
```

### 7.5 Hook Context

Hooks evaluate policy over context.

Kernel hook context:

```text
KernelHookContext = (
    actor,
    effective_actor,
    target,
    operator_class,
    concrete_operation,
    syscall?,
    frame_context,
    role_state,
    capability_state,
    isolation_domain,
    boundary_relation,
    resource_account,
    τ_data,
    history_summary,
    pending_commit_state,
    trap_state,
    audit_state,
    trust_state,
    runtime_profile,
    source
)
```

Context collection is Δ-like:

```text
the kernel distinguishes the facts relevant to policy evaluation.
```

Context must be:

```text
minimal
sufficient
policy-safe
auditable
stable enough for decision
```

Policy-safe means:

```text
collecting context must not itself violate the policy being evaluated.
```

For example, a path policy check may inspect path metadata, namespace, labels, and capabilities. It must not read protected file content merely to decide whether the file may be read.

### 7.6 Hook Decisions

Hook decisions use the decision forms from Section 6.

```text
ALLOW
DENY
MODIFY
TRANSFORM
DEFER
LOGONLY
AUDIT
QUARANTINE
REVOKE
ROLLBACK
ESCALATE
HALT
UNKNOWN
ERROR
```

The hook must specify which decisions are meaningful at that point.

Example:

```text
pre-mutation hook:
    ALLOW, DENY, MODIFY, TRANSFORM, QUARANTINE, ESCALATE, HALT

pre-commit hook:
    ALLOW, DENY, ROLLBACK, AUDIT, HALT

audit hook:
    ALLOW, REDACT, DENY_EXPORT, COMMIT_AUDIT, HALT_ON_AUDIT_FAILURE

scheduler hook:
    ALLOW, MODIFY_PRIORITY, DEFER, THROTTLE, SUSPEND, QUARANTINE
```

Decision application must be operator-typed.

```text
DENY       → Ψ denial, possibly Φ trap or Λ absence
MODIFY     → Ψ rewrite, Δ/Φ traceable
TRANSFORM  → Φ recontextualization
QUARANTINE → Χ tightening + Ω attenuation + Σ commit
ROLLBACK   → Σ recovery path
AUDIT      → Θ/Σ evidence path
HALT       → Ψ critical invariant response
```

### 7.7 Δ-Hooks — Distinction and Decision

Δ-hooks attach where the kernel distinguishes among possible branches.

Triggers:

```text
syscall dispatch
path resolution
IPC route selection
scheduler candidate selection
device-driver match
namespace lookup
policy selection
credential classification
object type classification
signal/event dispatch
```

Examples:

```text
H_Δ_syscall_dispatch(syscall_id)
H_Δ_path_resolve(path, namespace)
H_Δ_ipc_route(sender, receiver, endpoint)
H_Δ_device_match(device_id, driver_id)
H_Δ_policy_select(scope, operation)
```

Policy examples:

```text
deny syscall class for ROLE_GUEST
rewrite open(path) into process namespace root
deny following symlink across namespace boundary
deny driver probe for untrusted device class
deny route to hidden IPC endpoint
reject unknown credential type
```

Δ-hook contract:

```text
before kernel chooses executable branch,
policy may restrict, rewrite, or reject the distinction.
```

Invalid pattern:

```text
resolve privileged target first
then ask policy whether resolution was allowed
```

Correct pattern:

```text
classify resolution context
evaluate policy
then resolve or rewrite within permitted namespace
```

### 7.8 ∇-Hooks — Mutation and State Change

∇-hooks attach before state-changing actions.

Triggers:

```text
write to memory
write to file
enqueue IPC message
send network packet
create process
create thread
allocate memory
change frame mapping
change capability table
update driver state
write device register
call host service
modify policy state
```

Examples:

```text
H_∇_memory_write(process, addr, value)
H_∇_file_write(process, file, bytes)
H_∇_ipc_enqueue(sender, channel, msg)
H_∇_net_send(session, packet)
H_∇_device_mmio_write(driver, region, value)
H_∇_capability_table_update(actor, target, cap)
```

Policy examples:

```text
deny writes to protected filesystem frames
deny memory allocation above quota
deny network connection creation outside allowed domain
log any mutation of policy-related state
deny device register write outside assigned MMIO window
deny host call without ForeignFrame profile
```

∇-hook invariant:

```text
no protected mutation occurs before Ω, Χ, and Ψ have permitted it.
```

If a mutation has staged effects, the ∇ hook governs staging and the Σ hook governs visibility/commit.

### 7.9 □-Hooks — Frame and Context Changes

□-hooks attach when the kernel changes execution context, address-space context, or frame visibility.

Triggers:

```text
context switch
address-space switch
enter process frame
enter kernel frame
enter driver frame
map shared memory
mount filesystem subtree
switch namespace
enter device frame
bind driver frame
enter ForeignFrame
enter AuditFrame
```

Examples:

```text
H_□_context_switch(old_thread, new_thread)
H_□_address_space_switch(old_vas, new_vas)
H_□_mmap(process, region, perms)
H_□_shared_frame_map(process_a, process_b, frame)
H_□_driver_bind(driver, device_frame)
```

Policy examples:

```text
process may not enter frame outside its FrameSet
container may not mount host namespace
driver may not map unassigned MMIO frame
shared frame requires explicit policy approval
ForeignFrame entry requires FFI profile
AuditFrame entry requires observer authority
```

□-hook invariant:

```text
frame transition must preserve role, boundary, and policy constraints.
```

Frame entry may narrow authority:

```text
entering sandbox frame
    → Ω attenuate capabilities
    → Ψ activate sandbox policy
    → Χ tighten boundary projection
```

Frame exit must restore or commit authority state correctly.

### 7.10 Ω-Hooks — Role and Capability Changes

Ω-hooks attach when authority is checked or changed.

Triggers:

```text
role switch
capability grant
capability revoke
capability check
setuid-like operation
driver capability assignment
syscall authority check
kernel entry authority transition
privilege return
impersonation
delegation
debug authority check
policy-management authority check
trust-anchor use authority check
```

Examples:

```text
H_Ω_check(actor, capability, target)
H_Ω_grant(grantor, subject, capability)
H_Ω_revoke(revoker, subject, capability)
H_Ω_role_switch(actor, old_role, new_role)
H_Ω_impersonate(actor, represented, scope)
```

Policy examples:

```text
unprivileged process cannot gain network capability
driver cannot acquire DMA scope outside assigned frame
service may impersonate only users with label Y
policy update requires kernel role and signed policy source
debugger may inspect only redacted traces
tooling service may propose but not execute PMS-IR
```

Ω-hook invariant:

```text
authority cannot widen without explicit Ω/Ψ authorization and Σ commit.
```

Dropping authority may be local. Adding authority is always policy-relevant.

### 7.11 Θ-Hooks — Scheduling and Ordering

Θ-hooks attach at ordering points.

Triggers:

```text
scheduler tick
dispatch selection
preemption
workqueue dispatch
timer activation
interrupt priority decision
cache flush ordering
driver bottom-half scheduling
audit sequencing
expiry checks
rate-window updates
```

Examples:

```text
H_Θ_scheduler_tick(current_thread)
H_Θ_select_next(runqueue)
H_Θ_preempt(thread, cause)
H_Θ_timer_fire(timer)
H_Θ_capability_expiry(capability, τ_ref)
H_Θ_rate_window(account, resource)
```

Policy examples:

```text
process may not exceed CPU budget in τ-window
real-time thread must not be starved
driver interrupt handler must stay within budget
idle task must not starve policy-critical tasks
session capability expires after τ deadline
network rate window must throttle sender
```

Θ-hooks govern order and progress. They do not redefine physical time. Time values are τ-derived metadata in kernel state.

Θ-hook invariant:

```text
ordering decisions that affect security, fairness, expiry, quotas,
audit sequence, or visibility must be policy-checkable.
```

### 7.12 Λ-Hooks — Absence, Wait, Timeout

Λ-hooks attach when an expected event, resource, response, or condition is absent.

Triggers:

```text
empty IPC queue
lock unavailable
timer missed
device not ready
allocation cannot be satisfied
expected hotplug event absent
blocking syscall timeout
network no-route
host-service no-response
missing credential
unsupported runtime feature
```

Examples:

```text
H_Λ_ipc_empty(receiver, channel)
H_Λ_lock_unavailable(thread, lock)
H_Λ_alloc_failure(process, size)
H_Λ_device_not_ready(driver, device)
H_Λ_network_timeout(session, endpoint)
H_Λ_missing_credential(peer)
```

Policy examples:

```text
timeout after τ deadline
retry with Θ backoff
escalate repeated absence to Φ
treat missing device response as quarantine trigger
return no-resource under soft quota
trap under hard quota
```

Λ-hook invariant:

```text
absence is typed behavior, not generic failure.
```

A kernel should distinguish:

```text
no message
no resource
no route
no credential
unsupported feature
timeout
```

because each may have a different policy response.

### 7.13 Φ-Hooks — Trap, Fault, and Recontextualization

Φ-hooks attach when execution changes context, interpretation, or failure mode.

Triggers:

```text
syscall entry
syscall return
interrupt entry
interrupt return
page fault
protection fault
illegal instruction
policy violation trap
signal delivery
driver error
OOM handling
process kill path
quarantine entry
identity mapping
version migration
FFI error mapping
```

Examples:

```text
H_Φ_syscall_enter(process, syscall_id)
H_Φ_syscall_return(kernel, process, result)
H_Φ_page_fault(process, addr, cause)
H_Φ_protection_fault(process, target)
H_Φ_driver_fault(driver, device, cause)
H_Φ_quarantine_enter(subject, reason)
```

Policy examples:

```text
on page fault from sandbox, deny mapping and signal process
on repeated driver fault, quarantine device
on policy violation, enter audit frame
on trap return, verify target frame and role
on remote identity mismatch, map to restricted session principal
```

Φ-hook invariant:

```text
recontextualization must preserve kernel invariants.
```

Trap entry does not grant arbitrary authority. It enters a mediated kernel context.

Trap return must check:

```text
target frame
target role
instruction pointer / return target
pending commit state
boundary state
policy state
signal/trap result
```

### 7.14 Χ-Hooks — Isolation and Boundary Changes

Χ-hooks attach at boundary transitions.

At PMS Base level:

```text
Χ = Distance
```

At runtime-security/kernel level, Χ is projected as:

```text
process boundary
address-space boundary
namespace boundary
sandbox boundary
container boundary
device boundary
driver boundary
IPC visibility boundary
filesystem view boundary
DMA boundary
host/FFI boundary
network/session boundary
audit visibility boundary
quarantine boundary
```

Triggers:

```text
enter sandbox
exit sandbox
create container
join namespace
create shared memory
bridge IPC endpoints
map device memory
grant DMA region
bind driver to device
enter host/ForeignFrame
establish network session
export audit view
move object into quarantine
sealed isolation exit
```

Examples:

```text
H_Χ_sandbox_enter(process, sandbox)
H_Χ_sandbox_exit(process, sandbox)
H_Χ_shared_memory_create(p1, p2, frame)
H_Χ_namespace_join(process, namespace)
H_Χ_dma_grant(driver, region)
H_Χ_ipc_bridge_create(source, target)
H_Χ_quarantine(subject, reason)
H_Χ_sealed_exit(subject, boundary_context)
```

Policy examples:

```text
deny cross-container shared memory
require explicit bridge for IPC visibility
forbid DMA outside DMARegionFrame
quarantine process on forbidden boundary crossing
deny audit export without redaction
deny host call without ForeignFrame boundary
deny unbalanced isolation exit
```

Χ-hook invariant:

```text
reachability and visibility changes must be policy-checked before use.
```

A boundary edge is security state. Creating, removing, using, sealing, or exiting it is hook-governed.

A sealed isolation context forbids further entry, expansion, or reachability growth. It still permits valid exit, closure, audit, rollback, or commit under the declared policy and active boundary context.

Sealing is not the same as trapping execution forever.

### 7.15 Σ-Hooks — Commit and Integration

Σ-hooks attach at commit boundaries.

Triggers:

```text
filesystem journal commit
IPC delivery commit
context-switch state save
resource-accounting commit
process creation finalization
process termination finalization
driver binding commit
policy update activation
capability grant commit
storage writeback
transaction commit
audit record commit
trust-anchor rotation commit
quarantine state commit
distributed vote/commit
```

Examples:

```text
H_Σ_fs_commit(transaction)
H_Σ_ipc_delivery(message)
H_Σ_context_save(thread)
H_Σ_resource_account(account, delta)
H_Σ_policy_activate(policy_id)
H_Σ_capability_grant(subject, cap)
H_Σ_audit_commit(record)
```

Policy examples:

```text
commit only if integrity tags match
deny filesystem commit if quota exceeded
audit every commit touching high-value resource
rollback staged state if postcondition fails
durable audit required before trust-anchor update
deny capability grant if delegation policy changed before commit
```

Σ-hook invariant:

```text
produced effects become visible only when commit policy permits them.
```

The kernel may stage effects. It may not expose committed state if prior Ω, Χ, or Ψ obligations failed.

Distributed commit references are runtime-security integration points. Full distributed semantics belong to `07_distributed_systems.md` and declared distributed runtime profiles.

### 7.16 Syscall Hook Chain

Syscalls are composite hook sequences.

Canonical syscall chain:

```text
Φ_enter
→ Δ_syscall_classify
→ Ω_caller_authorize
→ □_kernel_frame
→ Χ_target_boundary
→ Ψ_syscall_policy
→ ∇ / □ / Χ / Θ / Σ body hooks
→ Σ_result_commit
→ Φ_return
```

Example `write(fd, buf, len)`:

```text
H_Φ_syscall_enter
H_Δ_syscall_dispatch(write)
H_Δ_fd_resolve(fd)
H_Ω_check(fd.write)
H_□_check_buffer_frame(buf, len)
H_Χ_check_file_or_socket_boundary(fd.target)
H_Ψ_write_policy
H_∇_write_or_enqueue
H_Σ_visible_or_deferred_commit
H_Θ_audit_syscall
H_Φ_return
```

Example `mmap(addr, size, flags)`:

```text
H_Φ_syscall_enter
H_Δ_classify_mapping_request
H_Ω_check(map capability)
H_Ψ_memory_policy
H_□_create_or_modify_frame_mapping
H_Χ_check_isolation_boundary
H_Σ_commit_page_table_update
H_Θ_audit_mapping
H_Φ_return
```

Example `execve(path, argv)`:

```text
H_Φ_syscall_enter
H_Δ_resolve_executable_path
H_Ω_check_execute
H_Χ_namespace_boundary
H_Ψ_exec_policy
H_Σ_flush_old_state
H_□_create_new_process_frame
H_∇_load_image
H_Σ_commit_exec_state
H_Ψ_post_exec_invariants
H_Φ_return_or_reframe
```

Syscall invariant:

```text
kernel entry mediates authority; it does not grant caller authority.
```

This syscall hook chain is a runtime-security enforcement view.

It does not redefine the PMS-OS syscall ABI specified in `04_pms_os.md`, and it does not replace the PMS-CPU trap/control-transfer convention specified in `03_pms_cpu.md`.

The PMS-OS syscall contract remains:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ
```

### 7.17 Memory and VM Hook Chain

Memory operations require hooks across Δ, Ω, □, Χ, Ψ, ∇, Σ, Φ, Λ.

Example allocation:

```text
H_Δ_classify_alloc(size, flags)
H_Ω_check_alloc_capability
H_Ψ_resource_policy
H_□_select_address_space
H_Χ_check_memory_domain
H_∇_allocate
H_Σ_commit_accounting
H_Θ_audit_memory_event
```

Example page fault:

```text
H_Φ_page_fault_enter
H_Δ_classify_fault(addr, cause)
H_□_identify_faulting_frame
H_Ω_check_mapping_authority
H_Χ_check_region_boundary
H_Ψ_page_fault_policy
H_∇_map_or_deny
H_Σ_commit_mapping_or_fault_result
H_Φ_resume_or_signal
```

Example invalid kernel-frame write:

```text
H_Δ_classify_write
H_□_identify_target_frame(kernel)
H_Ω_check_write_capability
H_Χ_detect_user_kernel_boundary
H_Ψ_deny
H_Φ_protection_fault
H_Σ_audit
```

Memory-hook invariant:

```text
no address value bypasses frame, boundary, role, and policy checks.
```

### 7.18 Process and Thread Hook Chain

Process creation:

```text
H_Δ_create_process
H_Ω_check_spawn_capability
H_Ψ_process_creation_policy
H_□_create_frame_set
H_Χ_create_isolation_domain
H_Σ_commit_process_record
H_Θ_enqueue_initial_thread
H_Σ_commit_accounting
H_Θ_audit_process_create
```

Thread creation:

```text
H_Δ_create_thread
H_Ω_check_thread_create
H_Ψ_thread_policy
H_□_bind_thread_frame
H_Θ_enqueue_thread
H_Σ_commit_thread_record
```

Process termination:

```text
H_Φ_exit_or_kill
H_Ψ_termination_policy
H_Σ_commit_exit_status
H_Σ_commit_resource_cleanup
H_Θ_audit_termination
```

Process-hook invariant:

```text
process identity, frame set, isolation domain, role state, and resource
accounting become active only after Σ commit.
```

### 7.19 Scheduler Hook Chain

Scheduler selection:

```text
H_Θ_tick
H_Δ_ready_set_classify
H_Ψ_scheduler_policy
H_Ω_priority_or_class_check
H_Χ_domain_visibility_check
H_Θ_select
H_Σ_save_old_context
H_□_switch_frame
H_Ω_set_effective_role
H_Θ_dispatch
```

Preemption:

```text
H_Θ_preempt_reason
H_Σ_save_thread_state
H_Ψ_preemption_policy
H_Θ_requeue_or_suspend
```

Quota violation:

```text
H_Θ_account_tick
H_Σ_commit_usage
H_Ψ_quota_policy
→ allow | throttle | suspend | Φ_trap | terminate
```

Scheduler-hook invariant:

```text
scheduling is ordering under policy, not arbitrary dispatch.
```

Scheduler hook claims do not eliminate timing side channels by specification alone.

### 7.20 IPC and Event Hook Chain

IPC send:

```text
H_Δ_classify_endpoint_and_payload
H_Ω_check_send_capability
H_Χ_check_endpoint_visibility
H_Ψ_channel_policy
H_Ψ_resource_policy
H_∇_enqueue
H_Σ_commit_delivery_or_staging
H_Θ_wake_receiver
H_Θ_audit_ipc_send
```

IPC receive:

```text
H_Δ_classify_receive
H_Ω_check_receive_capability
H_Χ_check_endpoint_visibility
H_Ψ_receive_policy
H_Θ_wait_or_select
H_Λ_no_message_or_timeout
H_∇_dequeue_if_available
H_Σ_commit_receive
H_Θ_audit_ipc_recv
```

Event delivery:

```text
H_Δ_classify_event
H_Ω_check_event_authority
H_Χ_check_delivery_boundary
H_Ψ_event_policy
H_Θ_order_delivery
H_Σ_commit_event_visibility
```

IPC invariant:

```text
message passing is a policy-governed bridge, not direct frame access.
```

### 7.21 Filesystem Hook Chain

Path resolution:

```text
H_Δ_path_parse
H_Δ_namespace_lookup
H_Χ_mount_namespace_boundary
H_Ψ_path_policy
H_Ω_check_path_capability
```

File read:

```text
H_Δ_resolve_handle
H_Ω_check_read
H_Χ_check_namespace
H_Ψ_read_policy
H_∇_read
H_Θ_audit_if_required
```

File write:

```text
H_Δ_resolve_target
H_Ω_check_write
H_Χ_check_namespace
H_Ψ_write_policy
H_Ψ_quota_policy
H_∇_stage_or_write
H_Σ_commit_visible
H_Θ_audit_write
```

Durable commit:

```text
H_Σ_fs_journal_commit
H_Ψ_integrity_policy
H_Ψ_quota_policy
H_Σ_durable_commit
H_Θ_audit_commit
```

Filesystem invariant:

```text
path strings do not imply reachability or authority.
```

### 7.22 Network Hook Chain

Network hooks specify runtime-security enforcement points.

They do not claim a completed network stack, production protocol implementation, cryptographic library, transport implementation, or distributed consensus implementation.

Connection establishment:

```text
H_Δ_classify_endpoint
H_Ω_check_connect_or_listen
H_Χ_network_boundary
H_Ψ_network_policy
H_Δ_classify_remote_credential
H_Ψ_trust_policy
H_Φ_map_remote_identity
H_Σ_commit_session
H_Θ_audit_connection
```

Send:

```text
H_Ω_check_send
H_Χ_session_boundary
H_Ψ_protocol_policy
H_Ψ_rate_policy
H_∇_send_or_queue
H_Σ_delivery_or_transmit_commit
H_Θ_audit_network_send
```

Receive:

```text
H_Δ_classify_packet
H_Χ_session_boundary
H_Ψ_protocol_policy
H_Ω_check_receive
H_∇_deliver
H_Σ_commit_receive
```

Distributed integration hooks may include:

```text
H_net_distributed_vote
H_net_distributed_commit
H_net_cluster_policy_update
H_net_partition_event
```

Distributed hooks are integration points for distributed profiles.

Their full semantics are defined by `07_distributed_systems.md` and by the declared distributed runtime profile.

Network invariant:

```text
remote identity is mapped before local authority is assigned.
```

This section defines network security at runtime-security level. It does not complete distributed PMS semantics, consensus algorithms, cluster policy synchronization, global commit, partition handling, or multi-node failure semantics.

### 7.23 Driver and Device Hook Chain

Driver load:

```text
H_Δ_classify_driver
H_Ψ_driver_trust_policy
H_Ω_check_driver_load
H_□_create_driver_frame
H_Χ_create_driver_domain
H_Σ_commit_driver_load
H_Θ_audit_driver_load
```

Device bind:

```text
H_Δ_classify_device
H_Ω_check_bind_authority
H_Χ_check_device_boundary
H_Ψ_driver_device_policy
H_□_bind_device_frame
H_Σ_commit_binding
H_Θ_audit_device_bind
```

MMIO write:

```text
H_Δ_classify_mmio_region
H_Ω_check_mmio_write
H_Χ_check_device_frame
H_Ψ_driver_policy
H_∇_write_device_register
H_Σ_commit_or_order_device_effect
H_Θ_audit_mmio
```

DMA grant:

```text
H_Δ_classify_dma_region
H_Ω_check_dma_map
H_Χ_check_dma_boundary
H_Ψ_dma_policy
H_Σ_commit_dma_mapping
```

Driver fault:

```text
H_Φ_driver_fault
H_Ψ_driver_fault_policy
→ recover | reset | revoke | quarantine | halt
H_Σ_commit_fault_response
H_Θ_audit_fault
```

Driver/device invariant:

```text
drivers are privileged only inside assigned frames, regions, and policies.
```

This section specifies hook architecture for driver/device enforcement. It does not certify hardware behavior, complete driver isolation, or prove deployment security.

### 7.24 Audit Hook Chain

Audit hooks are themselves policy-governed.

Audit event attempt:

```text
H_Δ_classify_audit_event
H_Θ_order_audit_event
H_Ψ_audit_policy
H_Χ_check_audit_visibility_boundary
H_Σ_commit_audit_record
```

Audit read/export:

```text
H_Δ_classify_audit_query
H_Ω_check_observer_authority
H_Χ_check_audit_boundary
H_Ψ_redaction_policy
H_∇_read_or_export
H_Σ_commit_audit_access_record
```

Audit failure:

```text
H_Φ_audit_failure
H_Ψ_audit_failure_policy
→ deny original op | defer | quarantine | halt
```

Audit invariant:

```text
audit visibility is itself a protected boundary.
```

A subject cannot gain sensitive visibility merely because logs exist.

Audit records are runtime-security evidence artifacts.

They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 7.25 Trust Anchor and Key Hook Chain

Key use:

```text
H_Δ_classify_key_and_operation
H_Ω_check_key_use
H_Χ_check_key_frame_boundary
H_Ψ_key_use_policy
H_Φ_interpret_key_context
H_∇_sign_verify_decrypt_or_derive
H_Σ_commit_key_use_or_session_state
H_Θ_audit_key_use
```

Trust-anchor update:

```text
H_Δ_classify_trust_anchor_update
H_Ω_check_trust_management_capability
H_Χ_check_trust_store_boundary
H_Ψ_trust_update_policy
H_Φ_rotate_or_revoke_context
H_Σ_commit_trust_state
H_Θ_audit_trust_update
```

Trust invariant:

```text
credential material does not become authority until Ψ policy interprets
it and Σ commits resulting trust or session state.
```

A trust anchor does not create authority by existing.

A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

Trust validation in this section means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, and runtime policy profile.

It does not mean external validation of PMS Base, universal identity truth, legal identity proof, universal trust, or cryptographic certification.

### 7.26 Policy Mutation Hook Chain

Policy updates are kernel-policy-hook events.

Policy activation:

```text
H_Δ_classify_policy_spec
H_Ω_check_policy_management_authority
H_Χ_check_policy_management_boundary
H_Ψ_policy_mutation_policy
H_Ψ_non_weakening_check
H_Φ_migrate_policy_context_if_needed
H_Σ_commit_policy_activation
H_Θ_audit_policy_activation
```

Policy deletion/revocation:

```text
H_Δ_classify_policy_target
H_Ω_check_policy_delete_authority
H_Ψ_policy_lifecycle_policy
H_Σ_commit_policy_revocation
H_Θ_audit_policy_revocation
```

Policy invariant:

```text
policy update cannot invalidate the invariants required to perform
policy update safely.
```

Policy source presence is not authority.

```text
file exists
message arrived
repository contains policy
AI generated a policy candidate
≠ policy active
≠ policy authoritative
```

### 7.27 Quarantine Hook Chain

Quarantine is a hook-driven isolation response.

```text
H_Δ_classify_subject_and_cause
H_Ψ_quarantine_policy
H_Φ_enter_quarantine_context
H_Χ_tighten_boundary
H_Ω_revoke_or_attenuate_capabilities
H_Σ_commit_quarantine_state
H_Θ_audit_quarantine
```

Quarantine targets:

```text
process
thread
module
driver
device
container
network session
IPC endpoint
filesystem subtree
distributed node
tooling service
AI service
```

Quarantine invariant:

```text
a quarantined subject cannot continue using pre-quarantine authority.
```

Quarantine is not a moral judgment, legal verdict, forensic conclusion, clinical classification, or person-level sanction. It is a runtime-security boundary action.

### 7.28 AI / Tooling Hook Chain

AI/tooling hooks preserve advisory/execution separation.

Permitted AI/tooling hook surfaces:

```text
trace summarization
diagnostic explanation
policy suggestion
scenario suggestion
fixture drafting
PMS-IR proposal
simulation request
validation request
```

Forbidden AI/tooling effects without host-side acceptance:

```text
authorize execution
define semantics
replace policy evaluation
replace verification
grant capabilities
commit runtime state
serve as trusted executable code
serve as compiler authority
serve as verification evidence
serve as runtime policy authority
validate PMS Base
```

Canonical AI/tooling hook chain:

```text
H_Δ_classify_tooling_artifact
H_Ω_check_tooling_capability
H_Χ_check_tooling_host_boundary
H_Ψ_advisory_only_policy
H_Φ_recontextualize_if_violation
H_Σ_commit_advisory_or_rejection_record
```

Execution requires separate acceptance:

```text
parse
canonicalize
validate
policy-check
runtime acceptance
kernel/runtime execution
```

Boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 7.29 Hook Failure Modes

Hook failure is operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| hook not registered | Δ / Ψ |
| context collection failure | Δ / Λ / Φ |
| policy evaluation failure | Ψ / Φ |
| missing policy for critical hook | Ψ fail-closed |
| stale policy cache | Θ / Ψ |
| hook recursion | Φ / Ψ |
| audit hook failure | Σ / Ψ / Φ |
| enforcement action failure | Φ / Σ / Ψ |
| commit hook denial | Σ / Ψ |
| boundary hook denial | Χ / Ψ |
| capability hook denial | Ω / Ψ |
| trap-return hook denial | Φ / Ψ |
| critical invariant violation | Ψ halt/quarantine |

Critical hooks should normally fail closed.

Examples:

```text
policy mutation hook failure
    → deny mutation

trust-anchor update hook failure
    → deny update

kernel frame access hook failure
    → trap/halt depending on profile

driver DMA hook failure
    → deny/quarantine

audit-required commit hook failure
    → deny or halt depending on policy
```

A fail-open hook is permitted only when the declared runtime profile explicitly allows it and the risk boundary is stated.

### 7.30 Hook Caching and Invalidation

Hooks may use cached policy decisions only when safe.

Cache key:

```text
HookDecisionCacheKey = (
    hook_id,
    actor_id,
    effective_role,
    operator_class,
    operation,
    target_id,
    frame_epoch,
    boundary_epoch,
    policy_epoch,
    capability_epoch,
    resource_epoch,
    trust_epoch,
    τ_window
)
```

Invalidation triggers:

```text
policy update
capability grant/revoke
role transition
frame mapping change
boundary graph change
resource quota change
trust-anchor change
principal lifecycle change
session expiry
quarantine event
audit policy change
runtime profile change
```

Cache invariant:

```text
cached decision is valid only while all decision dependencies remain unchanged.
```

Hook fast paths must preserve:

```text
policy correctness
audit behavior
commit constraints
failure mode
```

No fast path may skip required Ω, Χ, Ψ, Φ, or Σ obligations.

### 7.31 Hook Observability

Kernel hooks must be observable where policy permits.

Hook trace event:

```text
KernelHookEvent = (
    event_id,
    hook_id,
    operator_class,
    operation,
    actor,
    role,
    frame,
    boundary,
    policy_ids,
    decision,
    action,
    result,
    order,
    commit_state,
    meta
)
```

Examples:

```text
op=Omega hook=capability_check decision=DENY capability=fs.write
op=Chi hook=boundary_cross decision=QUARANTINE target=containerA
op=Sigma hook=fs_commit decision=ROLLBACK reason=quota_exceeded
op=Phi hook=trap_return decision=DENY reason=invalid_return_frame
```

Observability invariant:

```text
security-relevant hook decisions are Θ-ordered and Σ-committed when
audit policy requires durable evidence.
```

A concrete runtime-security hook execution produces:

```text
trace_runtime(runtime, hook_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security hook executions under a declared profile is:

```text
Trace_runtime(runtime, hook_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared runtime-security hook profile.

Trace records observed hook behavior. It does not prove all possible hook behavior unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

### 7.32 Hook Testing, Verification, and Trace Conformance

Kernel hooks can be tested and checked.

Static checks:

```text
every protected operation has a hook
hook context is sufficient
hook failure mode is explicit
hook decision set matches operator class
hook audit profile exists where required
no hook introduces untyped side effects
```

Runtime checks:

```text
hook executes before protected transition
decision is enforced
denied transition does not reach ∇ or Σ success
quarantine tightens Χ and attenuates Ω
commit denial prevents visibility
```

Model-checkable properties:

```text
no user write reaches kernel frame without hook denial/trap
no policy mutation reaches Σ without Ω/Ψ hook approval
no driver DMA mapping reaches Σ without Χ/Ψ hook approval
no syscall returns to invalid user frame
no quarantined process sends IPC
no trust-anchor update commits without trust-policy hook
```

Trace-conformance properties:

```text
every protected Σ event has prior policy hook decision
every boundary-crossing event has Χ hook decision
every capability grant has Ω hook decision and Σ commit
every audit-required hook has corresponding audit event
```

Verification boundary:

```text
hook verification establishes stated properties under stated model,
profile, assumptions, and artifact scope.
```

Trace-conformance boundary:

```text
trace conformance checks observed traces against declared expectations.
It does not prove all possible executions unless paired with stated
coverage, model, bounds, and proof or model-checking artifacts.
```

Tests check. Traces record. Validators accept or reject under profile. Proof artifacts prove stated properties under formal assumptions.

None of these validate PMS Base.

### 7.33 Hook and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of kernel-hook discipline:

```text
operator-tagged execution
model validation before execution
stateful validation of active frame/isolation/commit state
fail-closed rejection paths
JSONL trace/audit output
golden fixtures for invalid programs
vFS service boundaries
AI proposal gating before buffer replacement or execution
bounded chi_enter / chi_exit discipline
```

Correct relation:

```text
Kernel hook specification
    defines where Ψ must attach to runtime transitions.

PMS-RUST bounded artifacts
    may demonstrate executable slices of hook-like validation,
    rejection, traceability, service-boundary discipline, and acceptance
    gating.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, equal a complete kernel hook implementation, complete runtime security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, prove deployment security, or make tests/traces proofs.

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where an exit requires active boundary context.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 7.34 Hook Claim Boundary

The kernel policy hook model claims:

```text
kernel policy can be attached to concrete operator-typed runtime points:
distinction, mutation, frame change, authority change, ordering, absence,
trap, boundary change, commit, audit, trust, policy mutation, AI/tooling
boundaries, and quarantine.
```

It does not claim:

```text
all implementations have installed every hook
hook presence alone proves security
policy decisions are automatically correct
kernel privilege is unconstrained
audit logs are forensic proof
tests or traces validate PMS Base
host runtime hooks are equivalent to PMS-OS hooks
network hooks complete a network stack
distributed hooks complete distributed semantics
AI/tooling hooks grant execution authority
PMS-RUST completes kernel-hook implementation
```

Hooks are strong because they make governance executable. Their claim is bounded by declared hook coverage, policies, profiles, implementations, assumptions, and evidence artifacts.

### 7.35 Kernel Policy Hook Invariants

Runtime security maintains the following kernel hook invariants.

```text
I1: every protected kernel transition has a declared hook or an explicit exemption
I2: every hook is tied to an operator class
I3: every hook builds sufficient policy context before evaluation
I4: every hook calls Eval_Ψ or a profile-declared equivalent
I5: every hook has explicit allowed decisions and enforcement actions
I6: every hook has explicit failure mode
I7: every mutation hook precedes protected ∇ state change
I8: every authority hook precedes Ω grant, revoke, escalation, delegation, or impersonation
I9: every frame hook precedes protected □ transition
I10: every boundary hook precedes Χ reachability or isolation change as an implementation-layer projection
I11: every trap/return hook ensures Φ preserves kernel invariants
I12: every scheduling hook preserves Θ policy constraints
I13: every absence hook preserves Λ typed no-event semantics
I14: every commit hook precedes protected Σ visibility or durability
I15: every audit-required hook emits Θ/Σ evidence
I16: hook caches invalidate on relevant policy, role, capability, frame, boundary, resource, trust, or timing changes
I17: no hook fast path bypasses Ω, Χ, Ψ, Φ, or Σ
I18: quarantine hooks tighten Χ, attenuate Ω, apply Ψ, and commit state through Σ
I19: hook traces strengthen implementation-artifact claims but do not function as PMS Base validation
I20: kernel hook coverage is part of runtime-security conformance
I21: syscall hook chains are runtime-security enforcement views and do not redefine PMS-OS or PMS-CPU conventions
I22: PMS-RUST-style artifacts may evidence bounded hook slices; they do not complete runtime security or validate PMS Base
```

### 7.36 Architectural Consequence

The consequence is:

```text
PMS-STACK kernel policy is not an abstract governance layer floating
above execution. It is attached to concrete operator-typed kernel
transitions: syscalls, traps, scheduling, memory, frames, capabilities,
IPC, filesystems, networks, drivers, devices, resources, commits, audit,
trust anchors, AI/tooling boundaries, quarantine, and policy mutation.
```

Kernel policy hooks make Ψ executable:

```text
Δ hooks decide distinctions.
∇ hooks guard mutations.
□ hooks guard frame transitions.
Ω hooks guard authority.
Θ hooks govern ordering and expiry.
Λ hooks type absence and timeout.
Φ hooks govern traps and recontextualization.
Χ hooks govern boundaries as implementation-layer projections.
Σ hooks govern visibility and commit.
```

This gives PMS-STACK a runtime-security enforcement surface that is structurally uniform, auditable, model-checkable, and implementation-drivable while preserving the claim boundary: hook evidence strengthens implementation-layer security claims; it does not function as PMS Base validation.

### 7.37 Kernel Policy Hook Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK kernel policy hook model specifies implementation-layer
runtime-security enforcement architecture: hook contracts, hook ordering,
hook context, hook decisions, Δ/∇/□/Ω/Θ/Λ/Φ/Χ/Σ hooks, syscall hook
chains, memory and VM hook chains, process/thread hooks, scheduler hooks,
IPC/event hooks, filesystem hooks, network hooks, driver/device hooks,
audit hooks, trust-anchor/key hooks, policy-mutation hooks, quarantine
hooks, AI/tooling hooks, hook failure modes, caching/invalidation,
observability, testing, verification, trace conformance, PMS-RUST
evidence boundaries, and hook invariants.

This is a runtime-security kernel-hook / policy-enforcement architecture
claim.

It does not claim completed kernel-hook implementation, universal
security certification, complete deployment security, complete PMS-OS,
complete PMS-CPU, complete network stack, complete distributed runtime,
legal authority, moral authority, clinical authority, forensic
omniscience, tribunal status, trusted AI authority, proof of all security
properties, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection paths, JSONL traces, golden fixtures, vFS/service boundaries,
bounded isolation-exit discipline, and AI proposal gating. It does not
complete runtime security and does not validate PMS Base.
```

---

## 8. Runtime Invariants

Runtime invariants are the stability conditions of PMS-STACK runtime security.

They define what must remain true across identity binding, role changes, capability checks, frame transitions, isolation crossings, policy decisions, trap handling, resource accounting, audit emission, trust-anchor interpretation, kernel entry/exit, tooling boundaries, and commit boundaries.

The central invariant claim is:

```text
A PMS-STACK runtime-security invariant is valid when it constrains
operator-typed execution such that every security-relevant transition
preserves declared Ω authority, □ frame validity, Χ boundary structure
as an implementation-layer projection, Ψ policy admissibility, Θ ordering
discipline, Φ recontextualization safety, Λ absence semantics, Σ commit
correctness, and audit representability.
```

Claim type:

```text
RUNTIME-SECURITY INVARIANT / PRESERVATION ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK runtime-security invariants as
implementation-layer preservation architecture.

It does not claim completed runtime-security implementation, universal
security certification, complete deployment security, complete PMS-OS,
complete PMSL/PMS-IR, complete distributed runtime, proof of all security
properties, legal authority, moral authority, forensic authority,
clinical authority, tribunal status, or PMS Base validation.
```

Runtime invariants are not optional documentation. They are the conditions under which a PMS-STACK runtime remains a valid runtime-security system rather than a set of uncoordinated mechanisms.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At runtime-invariant level, Χ is projected as boundary, isolation, visibility, reachability, containment, namespace separation, host boundary, device boundary, network/session boundary, audit visibility boundary, quarantine, and trust-boundary control.

Runtime invariants use this Χ projection. They do not redefine PMS Base Χ.

Validation in this section means acceptance or rejection under a declared runtime-security invariant set, model, profile, artifact, hook schema, trace schema, conformance rule, report format, or verification profile.

It does not mean external validation of PMS Base.

The assurance vocabulary is:

```text
tests check
traces record
validators accept or reject under profile
trace conformance checks observed behavior against declared expectations
model checking verifies stated properties under a stated model/profile
proof artifacts prove stated properties under formal assumptions
audit verification checks evidence completeness and consistency
external validation validates externally under an explicitly designed protocol
```

No mechanism in this section validates PMS Base.

### 8.1 Role of Runtime Invariants

Runtime invariants answer:

```text
What must never be silently broken?
What must hold before execution?
What must hold after execution?
What must hold across traps?
What must hold before commit?
What must hold after policy transformation?
What must remain auditable?
What remains profile-bound, unsupported, or unverified?
```

A runtime invariant is stronger than a local check.

A check may say:

```text
this operation is allowed now
```

An invariant says:

```text
all valid executions under this profile preserve this condition
```

Example:

```text
check:
    actor has fs.write capability for this path

invariant:
    no filesystem write reaches visible or durable commit unless actor,
    frame, boundary projection, capability, policy, and commit profile
    are valid
```

The invariant is cross-cutting. It constrains all paths, including fast paths, traps, recovery, simulation, debugging, FFI, host calls, network sessions, distributed profiles, AI/tooling paths, and shutdown paths.

### 8.2 Invariant Form

A runtime invariant may be written as a predicate over runtime state.

```text
I : RuntimeState → Bool
```

or as a preservation rule over transitions:

```text
I(s) ∧ transition_valid(s → s') ⇒ I(s')
```

Security form:

```text
Ψ_runtime(s_before) ⇒ Ψ_runtime(s_after)
```

More explicitly:

```text
∀ transition t:
    valid_security_transition(t, s)
    ⇒ invariants_hold(apply(t, s))
```

A runtime invariant may be:

```text
precondition invariant
postcondition invariant
transition invariant
commit invariant
audit invariant
lifecycle invariant
boundary invariant
recovery invariant
profile invariant
evidence invariant
```

In PMS-STACK, invariants are expressed over operator-typed transitions rather than opaque state mutations.

### 8.3 Runtime Security State

Runtime invariants apply over the combined security state.

```text
RuntimeSecurityState = (
    principals,
    roles,
    capabilities,
    frames,
    boundaries,
    policies,
    hooks,
    scheduler_state,
    resource_accounts,
    trap_state,
    absence_state,
    commit_state,
    audit_state,
    trust_state,
    network_state,
    driver_state,
    FFI_state,
    tooling_state,
    profile_state,
    evidence_state,
    meta
)
```

Each field has invariant relevance:

| State field | Invariant concern |
| ---------- | ----------------- |
| `principals` | identity uniqueness, lifecycle, provenance |
| `roles` | authority mode validity |
| `capabilities` | scoped permission correctness |
| `frames` | context validity |
| `boundaries` | Χ-projected reachability / isolation correctness |
| `policies` | Ψ policy integrity and non-weakening |
| `hooks` | enforcement coverage |
| `scheduler_state` | Θ ordering and fairness/profile rules |
| `resource_accounts` | quota and attribution correctness |
| `trap_state` | Φ recontextualization safety |
| `absence_state` | Λ typed no-event correctness |
| `commit_state` | Σ visibility/durability correctness |
| `audit_state` | Θ/Σ evidence correctness |
| `trust_state` | Φ/Ψ/Σ trust-anchor correctness |
| `network_state` | mapped identity/session boundary correctness |
| `driver_state` | device/frame/capability correctness |
| `FFI_state` | host boundary and error-map correctness |
| `tooling_state` | advisory boundary correctness |
| `profile_state` | runtime profile, assumptions, unsupported features |
| `evidence_state` | trace/report/fixture/proof artifact references |
| `meta` | epochs, τ metadata, trace IDs, artifact IDs |

Runtime invariants constrain the whole state, not one subsystem.

### 8.4 Invariant Classes

PMS-STACK runtime security defines several invariant classes.

```text
operator invariants
identity invariants
authority invariants
frame invariants
boundary invariants
policy invariants
hook invariants
scheduler invariants
resource invariants
absence invariants
trap invariants
commit invariants
audit invariants
trust invariants
network invariants
driver/device invariants
FFI/host invariants
tooling/AI invariants
profile invariants
evidence/report invariants
failure/recovery invariants
```

These classes are separated for implementation clarity. At runtime they compose into one invariant set:

```text
Ψ_runtime =
    Ψ_identity
  ∧ Ψ_authority
  ∧ Ψ_frame
  ∧ Ψ_boundary
  ∧ Ψ_policy
  ∧ Ψ_hooks
  ∧ Ψ_scheduler
  ∧ Ψ_resources
  ∧ Ψ_failure
  ∧ Ψ_commit
  ∧ Ψ_audit
  ∧ Ψ_trust
  ∧ Ψ_tooling
  ∧ Ψ_profile
  ∧ Ψ_evidence
  ∧ Ψ_subsystems
```

### 8.5 Core Preservation Law

The core runtime-security law is:

```text
Ψ_runtime(s_before) ∧ valid_transition(t, s_before)
    ⇒ Ψ_runtime(s_after)
```

where:

```text
s_after = apply(t, s_before)
```

If a transition cannot preserve runtime invariants, the runtime must not silently execute it.

Allowed responses:

```text
deny
return typed absence
trap
rollback
compensate
quarantine
revoke authority
defer
audit
escalate
halt
```

Operator reading:

```text
Ω denial
Λ absence
Φ trap/recontextualization
Σ rollback/compensation
Χ quarantine as runtime boundary projection
Ψ halt/escalation
Θ audit/order
```

The invariant-preserving runtime may fail, but it must fail structurally.

### 8.6 Kernel Global Invariants

The kernel is the privileged invariant-preserving runtime locus.

Let:

```text
P_kernel
```

be the active kernel policy set.

The kernel maintains the following global invariants.

#### Ψ₁ — Capability Correctness

Every protected or privileged action requires a valid capability.

```text
Ψ₁(s):
    for all protected ∇ instructions or kernel actions I,
    requires_cap(I) ⊆ CapSet(active_role(s))
```

Meaning:

```text
no mutation of protected state may bypass Ω
```

Applies to:

```text
syscalls
memory writes
filesystem writes
IPC sends
network sends
device operations
driver actions
policy mutation
trust-anchor use
audit export
debug inspection
FFI host calls
AI/tooling execution gates
```

#### Ψ₂ — Frame Validity and Isolation

All accesses must be valid in the active frame context.

```text
Ψ₂(s):
    target ∈ VisibleFrames(active_frame(s))
```

or:

```text
AccessAllowed(actor, target)
    ⇒ target is frame-visible and Χ-reachable as a runtime projection
```

Meaning:

```text
no process, module, driver, host call, network session, or tooling
service may act outside its valid □/Χ-projected context.
```

#### Ψ₃ — No Uncontrolled Privilege Escalation

Privilege escalation requires controlled Ω/Φ/Ψ/Σ structure.

```text
USER → KERNEL only via Φ_trap
KERNEL → USER only via Φ_return
```

More generally:

```text
authority_widening(id → id')
    ⇒ Ω_authorized
       ∧ Ψ_policy_permits
       ∧ Φ_mediated if interpretation changes
       ∧ Σ_committed
       ∧ Θ_auditable if required
```

No role becomes stronger by accident, cache artifact, host callback, driver path, debug tooling path, or AI/tooling proposal path.

#### Ψ₄ — Policy Integrity

Policy mutation is itself policy-governed.

```text
Ψ_update allowed iff
    Ω authorizes policy mutation
    ∧ mutation occurs in a policy-governed frame
    ∧ management boundary projection permits it
    ∧ non-weakening constraints hold
    ∧ Σ commits the update
```

This prevents a subsystem from rewriting the rules that constrain it.

#### Ψ₅ — Scheduling Integrity

Scheduling is Θ-ordered and Ψ-constrained.

```text
schedule(t) valid iff
    t is runnable
    ∧ t is not quarantined
    ∧ resource/quota policy permits execution
    ∧ scheduling profile permits selection
```

Optional fairness property:

```text
∀ runnable process p:
    if p remains runnable under the active profile,
    p is eventually scheduled
```

A specific runtime profile may refine fairness, priority, real-time, hierarchical scheduling, deterministic execution, or simulation ordering.

Scheduler invariants do not eliminate timing side channels by specification alone.

#### Ψ₆ — Safe Recontextualization

Φ must preserve invariants.

```text
Φ(s) ⇒ s' satisfies Ψ_runtime
```

Applies to:

```text
syscall entry
syscall return
page fault
interrupt
signal delivery
driver fault
network identity mapping
FFI error mapping
policy transformation
quarantine entry
upgrade/reframe
tooling artifact rejection
```

Recontextualization may change context. It may not smuggle invalid authority, invalid frame state, invalid policy state, invalid boundary state, or invalid commit state.

#### Ψ₇ — Commit Validity

Σ requires valid prior structure and policy permission.

```text
Σ(s, subject) valid only if:
    committable(subject)
    ∧ frame conditions hold
    ∧ role/capability conditions hold
    ∧ boundary constraints hold
    ∧ policy permits integration
    ∧ audit obligations are satisfied if required
```

No invalid action may become stable by commit.

#### Ψ₈ — Auditability

Security-relevant transitions must be operator-representable and audit-capable.

```text
audit_required(t)
    ⇒ ∃ AuditEvent(t)
       with actor, role, frame, boundary, policy, decision, result, order
```

When durable evidence is required:

```text
audit_required_durable(t)
    ⇒ Σ_commit(AuditEvent(t))
```

Auditability is an invariant because runtime security must remain inspectable.

Audit strengthens evidence under profile. It is not forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 8.7 Identity Invariants

Identity invariants constrain principals.

```text
I_id1: every active principal has a unique Δ-distinguishable PrincipalID
I_id2: every active principal has valid lifecycle state
I_id3: every active principal has role/capability state
I_id4: every active principal has frame scope
I_id5: every active principal has isolation-domain state as a Χ projection
I_id6: every active principal has policy links
I_id7: external principals are Φ-mapped before local authority is granted
I_id8: identity binding is Σ-committed before use
I_id9: revocation prevents future authorization unless policy explicitly defines grace behavior
I_id10: audit records distinguish actor, effective actor, and delegated actor where relevant
I_id11: AI/tooling principals remain advisory unless separately authorized, validated, accepted, and committed
```

Identity preservation rule:

```text
principal_active(p, s_after)
    ⇒ principal_valid(p, s_after)
```

Identity failure response:

```text
unknown principal      → Δ / Λ
expired principal      → Θ / Λ / Ψ
revoked principal      → Ψ / Ω / Σ
invalid mapping        → Φ / Ψ
audit identity missing → Δ / Σ / Ψ
```

A principal is a computational runtime-security identity. It is not personhood, moral status, legal personality, social rank, clinical identity, or forensic authority.

### 8.8 Role and Capability Invariants

Authority invariants constrain Ω.

```text
I_Ω1: every protected action has an Ω capability basis
I_Ω2: every capability has operator, action, target, scope, and constraints
I_Ω3: capability use occurs inside valid frame scope
I_Ω4: boundary-sensitive capability use is Χ-checked as an implementation-layer projection
I_Ω5: policy-sensitive capability use is Ψ-checked
I_Ω6: authority-widening requires Ω/Ψ authorization and Σ commit
I_Ω7: delegation is scoped, provenance-preserving, and policy-governed
I_Ω8: impersonation is Φ-mediated and audit-distinguishable
I_Ω9: lifetime-bound capabilities are Θ/τ-checkable
I_Ω10: no high-value capability use is unauditable when audit policy requires evidence
I_Ω11: tooling proposal authority is distinct from execution authority
```

Capability preservation rule:

```text
capability_effective(c, p, s)
    ⇒ c.scope valid
       ∧ c.lifetime valid
       ∧ c.policy valid
       ∧ c.boundary valid
```

No runtime may treat a capability as a global permission token.

### 8.9 Frame Invariants

Frame invariants constrain □.

```text
I_□1: every executing thread/task has an active frame
I_□2: every memory access targets a frame-visible object
I_□3: every kernel entry switches to kernel-governed frame
I_□4: every kernel exit restores valid user frame or enters recovery
I_□5: shared frames are explicitly created and policy-authorized
I_□6: foreign/host frames are explicit before host access
I_□7: device/MMIO/DMA frames are explicit before driver access
I_□8: audit/debug frames enforce visibility boundaries
I_□9: key material resides in declared key frames
I_□10: frame destruction closes or transfers contained resources through Σ
I_□11: tooling/AI artifacts are held in tooling/host frames until separately accepted
```

Frame preservation rule:

```text
frame_transition(□_a → □_b)
    ⇒ Ω permits transition
       ∧ Χ permits reachability as a runtime projection
       ∧ Ψ permits context switch
       ∧ Σ commits stable frame effects if required
```

### 8.10 Boundary and Isolation Invariants

Boundary invariants constrain Χ.

At PMS Base level:

```text
Χ = Distance
```

At runtime-security implementation level:

```text
Χ projects as isolation, boundary, reachability, visibility,
access separation, namespace separation, host boundary, device boundary,
network session boundary, audit boundary, sealed isolation, and quarantine.
```

`IDom`, `X_user`, `X_global`, and comparable runtime-domain names denote implementation-level isolation-domain values.

They are not the PMS Base operator `Χ` itself.

Isolation invariants:

```text
I_Χ1: every isolation domain is Δ-distinguishable
I_Χ2: every isolation domain is backed by □ frames
I_Χ3: every protected boundary crossing is Χ-checked as an implementation-layer projection
I_Χ4: every crossing requires explicit edge, bridge, or policy-valid transfer
I_Χ5: user frames cannot directly access kernel frames
I_Χ6: process/process access occurs only through declared bridges
I_Χ7: module isolation prevents direct internal-state access
I_Χ8: driver/device access is confined to assigned regions
I_Χ9: FFI/host access occurs through ForeignFrame or HostService boundary
I_Χ10: network authority requires session boundary and identity mapping
I_Χ11: audit/debug visibility is boundary-governed
I_Χ12: quarantine tightens or replaces boundary state and is Σ-committed
I_Χ13: sealed isolation forbids further entry, expansion, or reachability growth
I_Χ14: sealed isolation still permits valid exit, closure, audit, rollback, or commit under policy
I_Χ15: unbalanced isolation exit is invalid
```

Boundary preservation rule:

```text
cross(source, target)
    ⇒ edge_exists_or_bridge_valid(source, target)
       ∧ Ω permits crossing
       ∧ Ψ permits crossing
       ∧ transfer profile valid
```

Valid exit rule:

```text
valid_exit(domain) iff
    active_boundary_context(domain)
    ∧ Ψ permits exit/closure
    ∧ pending commit/rollback obligations are resolved
    ∧ audit obligations are satisfiable
```

Sealing is not the same as trapping execution forever.

### 8.11 Policy Invariants

Policy invariants constrain Ψ.

```text
I_Ψ1: every active policy has id, scope, mode, priority, predicate, and action
I_Ψ2: every protected transition has a policy hook or declared exemption
I_Ψ3: policy mutation is Ω-authorized and Σ-committed
I_Ψ4: local policies cannot silently weaken global/kernel invariants
I_Ψ5: policy conflicts have explicit resolution
I_Ψ6: policy failure mode is explicit
I_Ψ7: Φ recontextualization caused by policy preserves invariants
I_Ψ8: Χ isolation caused by policy is visible to scheduler/resource logic
I_Ψ9: Σ commits are policy-checked before visibility
I_Ψ10: policy caches invalidate on relevant epoch changes
I_Ψ11: AI/tooling policy preserves advisory/execution separation
```

Policy preservation rule:

```text
P_active(s_after)
    ⇒ policy_set_consistent(P_active)
       ∧ non_weakening(P_active, P_core)
```

A runtime may cache policy decisions. It may not cache away invariant responsibility.

### 8.12 Hook Invariants

Kernel and runtime hooks make Ψ executable.

Hook invariants:

```text
I_hook1: every critical transition has a hook or explicit exemption
I_hook2: every hook is operator-typed
I_hook3: every hook builds sufficient context before Eval_Ψ
I_hook4: every hook has allowed decisions and enforcement actions
I_hook5: every hook has explicit failure mode
I_hook6: mutation hooks precede protected ∇
I_hook7: authority hooks precede Ω grant/elevation/delegation
I_hook8: boundary hooks precede Χ crossing or edge creation
I_hook9: trap-return hooks verify valid return context
I_hook10: commit hooks precede protected Σ
I_hook11: audit-required hooks emit Θ/Σ evidence
I_hook12: hook fast paths do not bypass Ω, Χ, Ψ, Φ, or Σ
I_hook13: AI/tooling hooks prevent advisory output from becoming execution authority without acceptance
```

Hook preservation rule:

```text
protected_transition(t)
    ⇒ hook_coverage(t) complete
       ∧ hook_decision(t) enforced
```

Hook coverage supports runtime-security conformance. Hook presence alone does not prove security.

### 8.13 Scheduler and Ordering Invariants

Ordering invariants constrain Θ.

```text
I_Θ1: every runnable selection follows declared scheduler profile
I_Θ2: scheduling decisions are policy-constrained
I_Θ3: preemption preserves frame, role, trap, and commit state
I_Θ4: timers and expiries are checked in Θ order using τ metadata
I_Θ5: audit events are orderable
I_Θ6: resource accounting updates are ordered before quota decisions that depend on them
I_Θ7: deterministic profiles produce stable ordering under same inputs
I_Θ8: fairness or priority constraints are explicit profile properties
```

Ordering preservation rule:

```text
Θ_step(s → s')
    ⇒ scheduler_state_valid(s')
       ∧ ordered_events_consistent(s')
```

Ordering properties are profile-bound. A property checked under a deterministic test profile does not automatically transfer to production, distributed, high-assurance, or host-runtime profiles.

### 8.14 Resource Invariants

Resource invariants constrain quota and accounting state.

```text
I_res1: every resource use is attributable to principal, role, frame, and domain
I_res2: resource accounting updates are Σ-committed before durable quota decisions
I_res3: quotas are Ψ policies over committed or profile-defined accounting state
I_res4: hard limit violation prevents further protected use
I_res5: soft limit violation produces profile-defined throttling, warning, downgrade, or trap
I_res6: no-resource outcomes preserve Λ semantics where recoverable
I_res7: resource cleanup is committed at lifecycle closure
I_res8: resource audit occurs where required
```

Resource preservation rule:

```text
resource_use(r, actor)
    ⇒ accounted(r, actor)
       ∧ quota_policy_evaluated(r, actor)
```

Resource accounting is runtime governance. It is not social evaluation, moral ranking, clinical classification, or person ranking.

### 8.15 Absence Invariants

Absence invariants constrain Λ.

Λ represents an expected event, resource, response, or condition not materializing.

```text
I_Λ1: absence outcomes are typed
I_Λ2: timeout absence is Θ/τ-checkable
I_Λ3: no-resource absence does not imply mutation occurred
I_Λ4: no-message absence is distinct from channel failure
I_Λ5: missing credential is distinct from invalid credential
I_Λ6: unsupported runtime feature is explicit
I_Λ7: absence paths are handled, declared, or policy-rejected
I_Λ8: absence does not silently become Φ trap unless policy specifies transformation
```

Absence preservation rule:

```text
Λ_absent(x)
    ⇒ no successful Σ for expected event x occurred
```

This preserves the distinction between non-event and failure.

### 8.16 Trap and Recontextualization Invariants

Trap invariants constrain Φ.

```text
I_Φ1: every trap has source context, cause, and target context
I_Φ2: syscall entry is Φ-mediated
I_Φ3: syscall return is Φ-mediated
I_Φ4: trap return restores valid frame, role, boundary, and policy state
I_Φ5: policy transformations preserve invariants
I_Φ6: identity mapping across trust boundary is Φ-mediated
I_Φ7: FFI error mapping is Φ-mediated
I_Φ8: quarantine entry is Φ/Χ/Ψ/Σ-governed
I_Φ9: recovery paths preserve or restore commit validity
I_Φ10: no trap path grants uncommitted authority
I_Φ11: tooling/AI violations are recontextualized as advisory-boundary failures where required
```

Trap preservation rule:

```text
Φ(s) = s'
    ⇒ Ψ_runtime(s')
```

A trap may redirect execution. It may not become a privilege escape.

### 8.17 Commit Invariants

Commit invariants constrain Σ.

```text
I_Σ1: visible state changes require valid commit profile
I_Σ2: durable state changes require durable commit profile
I_Σ3: capability grants/revocations are committed before use
I_Σ4: policy mutations are committed before activation
I_Σ5: session identities are committed before local authority assignment
I_Σ6: trust-anchor changes are committed before use
I_Σ7: audit-required events are committed before evidence is considered durable
I_Σ8: invalid prior checks prevent successful commit
I_Σ9: rollback/compensation paths leave invariant-valid state
I_Σ10: commit records are traceable where audit policy requires
I_Σ11: AI/tooling artifacts become executable only after separate validation, policy acceptance, runtime acceptance, and commit where required
```

Commit validity:

```text
valid_Σ(subject, s) iff
    committable(subject)
    ∧ Ω conditions hold
    ∧ □ conditions hold
    ∧ Χ conditions hold as runtime projection
    ∧ Ψ permits commit
    ∧ audit requirements satisfied
```

Commit preservation rule:

```text
Σ(s) = s'
    ⇒ Ψ_runtime(s')
```

### 8.18 Audit Invariants

Audit invariants constrain Θ/Σ evidence state.

```text
I_audit1: audit-required events are Θ-orderable
I_audit2: durable audit events are Σ-committed
I_audit3: audit records include actor/effective actor where relevant
I_audit4: audit records include frame, role, boundary, policy, decision, and result where required
I_audit5: audit visibility is Ω/Χ/Ψ-governed
I_audit6: redaction is explicit
I_audit7: audit export is a protected transition
I_audit8: audit failure has explicit policy response
I_audit9: audit state is itself protected state
I_audit10: compliance reports state scope, completeness, redaction, and profile
```

Audit preservation rule:

```text
audit_required(t)
    ⇒ audit_event_exists(t)
```

and when durable:

```text
durable_audit_required(t)
    ⇒ Σ_commit(audit_event(t))
```

Audit strengthens runtime evidence under a declared profile.

It does not become proof of all behavior outside its scope, forensic truth, legal authority, moral authority, external validation, or PMS Base validation.

### 8.19 Trust Anchor Invariants

Trust invariants constrain Φ/Ψ/Σ trust state.

```text
I_trust1: key material lives in declared key frames
I_trust2: key-frame access is Ω/Χ/Ψ-governed
I_trust3: trust anchors are policy constraints, not automatic authority
I_trust4: credential interpretation is Φ-mediated
I_trust5: credential acceptance is Ψ-governed
I_trust6: session/trust state is Σ-committed before authority assignment
I_trust7: key rotation is Φ/Ψ/Σ-governed
I_trust8: key revocation affects future policy decisions
I_trust9: trust-anchor updates are audited where required
I_trust10: distributed trust state declares quorum or synchronization policy
```

Trust preservation rule:

```text
credential_used_for_authority(c)
    ⇒ Δ classified(c)
       ∧ Ψ verified(c)
       ∧ Φ interpreted(c)
       ∧ Σ committed resulting trust/session state
```

A key verifies a cryptographic relation under a profile. A policy interprets what that relation means. The runtime commits only the resulting local trust state.

Trust validation means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, and runtime policy profile. It does not mean legal identity proof, universal trust, external validation of PMS Base, or PMS Base validation.

### 8.20 Network and Distributed Invariants

Network invariants constrain remote authority and session state.

```text
I_net1: remote principal is classified before use
I_net2: remote identity is Φ-mapped before local authority assignment
I_net3: session boundary is Χ-explicit as a runtime projection
I_net4: session capabilities are Ω-assigned locally
I_net5: protocol/trust policy is Ψ-checked
I_net6: network send/receive is resource-accountable where policy requires
I_net7: session commit occurs before stable authority
I_net8: remote node authority requires node role and trust policy
I_net9: distributed commit requires declared quorum/commit profile
I_net10: network audit events are Θ/Σ-governed where required
```

Distributed invariants are refined in `07_distributed_systems.md`.

Runtime security defines their local enforcement structure. It does not complete network-stack implementation, cryptographic deployment, distributed consensus, cluster policy synchronization, global commit semantics, or multi-node failure semantics.

### 8.21 Driver and Device Invariants

Driver/device invariants constrain high-risk privileged IO.

```text
I_drv1: every driver has a driver principal or role
I_drv2: every driver is bound to declared driver frame
I_drv3: every device has device frame or device principal
I_drv4: MMIO access is confined to assigned regions
I_drv5: DMA regions are explicit frames
I_drv6: driver interrupts are assigned and policy-governed
I_drv7: driver faults enter Φ recovery or quarantine path
I_drv8: driver quarantine revokes or attenuates capabilities
I_drv9: driver unload/update commits cleanup or rebind state
I_drv10: device/trust policy is checked before binding
```

Driver preservation rule:

```text
driver_action(d, target)
    ⇒ target ∈ assigned_device_scope(d)
       ∧ Ω permits action
       ∧ Χ permits device boundary as runtime projection
       ∧ Ψ permits action
```

Driver/device invariants constrain runtime authority. They do not certify hardware behavior, complete driver isolation, or prove deployment security.

### 8.22 FFI and Host Invariants

FFI/host invariants constrain foreign execution.

```text
I_ffi1: every host call crosses ForeignFrame or HostService boundary
I_ffi2: foreign symbol is Δ-classified before invocation
I_ffi3: host-call capability is Ω-checked
I_ffi4: host boundary is Χ-checked as runtime projection
I_ffi5: FFI policy is Ψ-checked
I_ffi6: host errors are Φ-mapped
I_ffi7: host no-response/timeouts preserve Λ semantics
I_ffi8: host result is integrated only through declared Σ profile
I_ffi9: memory transfer profile is explicit
I_ffi10: host behavior is not treated as PMSL/PMS-OS native truth
```

FFI preservation rule:

```text
host_result_integrated(r)
    ⇒ ForeignFrame declared
       ∧ error/absence map declared
       ∧ Ψ permits integration
       ∧ Σ commit profile valid
```

A host runtime may support execution. It does not become PMS-OS.

### 8.23 Tooling and AI Invariants

Tooling/AI invariants preserve advisory boundaries.

```text
I_tool1: tooling principal is explicit
I_tool2: tooling authority is Ω-scoped
I_tool3: tooling boundary is Χ-explicit as runtime projection
I_tool4: tooling policy is Ψ-enforced
I_tool5: AI proposal is advisory unless separately accepted
I_tool6: proposed PMS-IR is parsed and canonicalized by host tooling
I_tool7: validation precedes execution
I_tool8: execution authority is separate from proposal authority
I_tool9: trace analysis does not become verification by assertion
I_tool10: tooling output does not function as PMS Base validation
I_tool11: AI output is not trusted executable code, compiler authority, verifier authority, or runtime policy authority
```

AI/tooling preservation rule:

```text
ai_proposed_artifact_executed(a)
    ⇒ host_validated_under_declared_tooling_profile(a)
       ∧ policy_accepted(a)
       ∧ runtime_accepted(a)
       ∧ execution_authority_separate_from_proposal(a)
```

Standard boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 8.24 Failure and Recovery Invariants

Runtime failure must remain structured.

```text
I_fail1: failure mode is operator-typed
I_fail2: denial does not execute protected effect
I_fail3: absence preserves Λ semantics
I_fail4: trap preserves Φ semantics
I_fail5: rollback preserves Σ recovery semantics
I_fail6: quarantine tightens Χ and attenuates Ω
I_fail7: halt is Ψ-governed
I_fail8: recovery path cannot weaken invariant set silently
I_fail9: audit-required failure is Θ/Σ-recorded
I_fail10: partial state does not become stable without valid commit
```

Failure preservation rule:

```text
failure_response(f, s) = s'
    ⇒ Ψ_runtime(s')
```

If no invariant-preserving recovery exists, the correct response is policy-defined halt or quarantine, not silent continuation.

### 8.25 Quarantine Invariants

Quarantine is a stronger isolation state.

```text
Χ_quarantine(subject)
```

Here `Χ_quarantine` denotes a runtime-security boundary projection, not a redefinition of PMS Base Χ.

Quarantine invariants:

```text
I_q1: quarantined subject is Δ-distinguishable
I_q2: quarantine cause is recorded
I_q3: quarantine is Ψ-decided
I_q4: quarantine tightens Χ as runtime boundary projection
I_q5: quarantine attenuates or revokes Ω authority
I_q6: quarantine state is Σ-committed
I_q7: scheduler observes quarantine state
I_q8: IPC/network/filesystem/device access observe quarantine state
I_q9: audit records quarantine
I_q10: release from quarantine is policy-governed
```

Quarantine preservation rule:

```text
quarantined(subject)
    ⇒ subject cannot use pre-quarantine authority
       unless release policy commits restoration
```

Quarantine is not a moral judgment, legal verdict, forensic conclusion, clinical classification, or person-level sanction. It is a runtime-security boundary response.

### 8.26 Sealed Isolation Invariants

Sealed isolation is a Ψ-bound boundary state.

```text
SealedIsolation = (
    domain,
    active_boundary_context,
    entry_policy = denied,
    expansion_policy = denied,
    reachability_growth = denied,
    exit_policy,
    closure_policy,
    audit_profile
)
```

Sealed isolation invariants:

```text
I_seal1: sealed domain is Δ-distinguishable
I_seal2: sealed domain has active boundary context
I_seal3: further entry is denied
I_seal4: expansion is denied
I_seal5: reachability growth is denied
I_seal6: valid exit remains possible under exit policy
I_seal7: closure, audit, rollback, commit, or termination remain possible under policy
I_seal8: unbalanced exit is rejected
I_seal9: sealed state is audit-representable
I_seal10: sealed state does not redefine PMS Base Χ
```

Valid exit rule:

```text
valid_sealed_exit(domain) iff
    active_boundary_context(domain)
    ∧ Ψ permits exit/closure
    ∧ pending commit/rollback obligations are resolved
    ∧ audit obligations are satisfiable
```

Invalid case:

```text
chi_exit without active isolation context → rejected
```

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline under this rule.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime security, or validate PMS Base.

### 8.27 Invariant Composition

Runtime invariants compose.

Example filesystem write invariant:

```text
FS.write visible commit valid iff:
    actor identity valid
    ∧ role/capability valid
    ∧ path/object frame valid
    ∧ namespace boundary valid
    ∧ filesystem policy permits
    ∧ resource quota permits
    ∧ mutation hook allowed
    ∧ commit hook allowed
    ∧ audit obligation satisfied if required
```

Example network session invariant:

```text
Session authority valid iff:
    remote principal classified
    ∧ trust policy verified
    ∧ identity Φ-mapped
    ∧ session boundary established
    ∧ local capabilities assigned
    ∧ session state committed
    ∧ expiry/revocation policy active
```

Example driver MMIO invariant:

```text
MMIO write valid iff:
    driver principal valid
    ∧ driver role active
    ∧ MMIO capability covers region
    ∧ region belongs to assigned device frame
    ∧ driver policy permits write
    ∧ device boundary permits access
    ∧ audit occurs if required
```

Example AI/tooling proposal invariant:

```text
Proposed PMS-IR execution valid iff:
    tooling principal valid
    ∧ proposal authority exists
    ∧ tooling boundary is active
    ∧ host parses and canonicalizes artifact
    ∧ validation accepts artifact under declared profile
    ∧ runtime policy permits execution
    ∧ execution authority is separate from proposal authority
    ∧ execution acceptance is committed where required
```

Invariant composition is what makes runtime security cross-layer.

### 8.28 Invariant Violation Handling

Invariant violation is not a single error type.

Violation handling depends on operator class and policy.

| Violation | Typical response |
| --------- | ---------------- |
| missing capability | Ω denial / Φ trap / audit |
| frame escape | Χ denial / Φ protection fault |
| policy mutation violation | Ψ denial / quarantine / halt |
| invalid trap return | Φ denial / terminate / halt |
| invalid commit | Σ rollback / Φ trap |
| audit failure | deny / defer / halt by policy |
| key/trust failure | Φ fallback / quarantine / deny |
| resource quota violation | Λ no-resource / throttle / Φ trap |
| driver overreach | quarantine / revoke / halt |
| distributed quorum failure | deny global commit / isolate node |
| AI/tooling authority violation | Ψ denial / Χ boundary enforcement / audit |
| unbalanced isolation exit | Χ/Ψ denial / Φ violation context |

General response law:

```text
violation(v)
    ⇒ typed_response(v)
       ∧ invariant_preserving_result
```

A successful rejection evidences one blocked transition under a declared profile. It is not a universal proof that all variants are blocked.

### 8.29 Invariant Checking

Runtime invariants may be enforced or checked through several mechanisms.

```text
static analysis
type/effect checking
PMS-IR validation
kernel policy hooks
runtime assertions
model checking
simulation
trace conformance
golden fixtures
audit verification
compliance reports
proof artifacts
```

Different mechanisms establish different claims.

| Mechanism | What it supports |
| --------- | ---------------- |
| static analysis | rejects invalid source/IR patterns before execution |
| runtime hook | enforces policy at execution point |
| model checking | verifies stated property under stated model/profile |
| simulation | explores scenarios under declared assumptions |
| trace conformance | checks observed behavior against expected trace/property |
| audit verification | checks evidence completeness and consistency |
| golden fixture | stabilizes regression behavior |
| proof artifact | proves stated property under formal assumptions |
| compliance report | reports profile-bound evidence against declared obligations |

No mechanism alone validates PMS Base.

The correct claim form is:

```text
Invariant I was checked under profile P for artifact A with evidence E.
```

Not:

```text
The runtime is absolutely secure.
PMS Base has been validated.
The trace proves all executions.
```

### 8.30 Trace and Evidence Convention

A concrete runtime-security invariant execution produces:

```text
trace_runtime(runtime, invariant_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security invariant executions under a declared profile is:

```text
Trace_runtime(runtime, invariant_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared runtime-security invariant profile.

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Trace records observed behavior.

Trace conformance checks whether observed traces satisfy declared expectations.

Trace evidence does not prove all possible executions unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

### 8.31 Invariant Reports

A runtime may emit invariant reports.

```text
InvariantReport = (
    runtime_profile,
    invariant_set,
    checked_invariants,
    violated_invariants,
    enforcement_points,
    evidence,
    traces,
    audit_records,
    assumptions,
    unsupported_features,
    limitations,
    meta
)
```

Result statuses:

```text
holds
violated
not_checked
unsupported
profile_limited
unknown
inconclusive
counterexample
```

A report should state:

```text
which invariant
under which profile
over which artifact
with which evidence
with which limitations
```

Correct claim:

```text
Invariant I held for this trace/model/profile.
```

Not:

```text
The system is absolutely secure.
The audit report proves forensic truth.
The test suite validates PMS Base.
```

Invariant reports are inspection artifacts. They support runtime-security conformance review under declared profiles. They do not replace implementation, policy enforcement, external validation, or formal proof.

### 8.32 Invariants and Runtime Profiles

Invariants may be profile-specific.

Profiles:

```text
minimal_runtime
deterministic_test
PMS-RUST evidence spine
host_runtime
PMS-OS runtime
simulation_runtime
distributed_runtime
high_assurance_runtime
debug_runtime
production_runtime
```

Example:

```text
debug_runtime:
    permits trace inspection under redaction policy

production_runtime:
    denies full trace inspection except through audit authority

deterministic_test:
    requires stable ordering and stable JSONL trace schema

distributed_runtime:
    requires node/session/quorum invariants

PMS-RUST evidence spine:
    supports bounded operator-tagged execution, validation, traces,
    golden fixtures, vFS/service boundaries, and AI proposal gating
```

Invariant profile rule:

```text
invariant set must declare profile assumptions.
```

A property proven, tested, simulated, traced, or reported under one profile does not automatically transfer to another profile.

Profile portability requires explicit mapping, assumptions, and evidence.

Portability is not equivalence.

### 8.33 Invariants and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of invariant enforcement:

```text
operator-tagged execution
model validation
stateful validation
frame/isolation/sealing checks
bounded chi_enter / chi_exit discipline
fail-closed rejection paths
JSONL trace/audit output
golden fixtures
vFS service boundary discipline
AI proposal gating
```

Correct relation:

```text
Runtime invariant specification
    defines what must be preserved.

PMS-RUST bounded artifacts
    demonstrate executable slices of preservation, rejection,
    traceability, and conformance under specific profiles.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime security, prove deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, or make tests/traces proofs.

PMS-RUST-style invariant evidence is useful when it follows the pattern:

```text
runtime-security claim
→ executable slice
→ validation rule
→ golden fixture
→ JSONL trace evidence
→ stated limitation
```

### 8.34 Runtime Invariant Claim Boundary

The runtime-invariant model claims:

```text
PMS-STACK runtime security can be specified as a set of operator-typed
preservation conditions over principals, roles, capabilities, frames,
boundaries, policies, hooks, resources, traps, absence states, commits,
audit records, trust anchors, network sessions, drivers, FFI, tooling,
profiles, reports, traces, and failure responses.
```

It does not claim:

```text
all policies are automatically correct
all implementations satisfy all invariants
all side channels are eliminated
all traces prove all executions
audit equals forensic truth
tests equal proof
implementation artifacts validate PMS Base
runtime security equals legal or moral authority
runtime governance equals tribunal
AI/tooling output is trusted executable code
PMS-RUST completes runtime security
```

The model is strong because it is explicit: a runtime either preserves the declared invariants under its profile, or its violation is expressible, auditable, and policy-addressable.

### 8.35 Consolidated Runtime Invariants

The consolidated invariant set for `06_runtime_security.md` is:

```text
R1: every active principal is Δ-distinguished, lifecycle-valid,
    frame-scoped, boundary-located, policy-linked, and auditable where
    required

R2: every protected action has Ω authority and cannot proceed solely from
    identifier, label, credential, AI output, or host origin

R3: every action occurs inside a valid □ frame

R4: every boundary-sensitive action is Χ-checked as an implementation-layer
    projection of PMS Base Distance

R5: every policy-governed action is Ψ-evaluated before protected ∇ or Σ

R6: every authority-widening transition is Ω/Ψ-authorized and Σ-committed

R7: every kernel entry and return is Φ-mediated and invariant-preserving

R8: every scheduler decision that affects security, quota, expiry, or
    fairness is Θ/Ψ-governed

R9: every recoverable non-event is Λ-typed and not collapsed into generic
    error

R10: every violation, trap, recovery, identity mapping, and policy
     transformation is Φ-representable and invariant-preserving

R11: every visible, durable, global, policy, trust, audit, or authority state
     change is Σ-committed under policy

R12: every audit-required transition is Θ-ordered and Σ-committed where
     durable evidence is required

R13: every trust-anchor or credential-based authority path is Δ-classified,
     Φ-interpreted, Ψ-verified, and Σ-committed before local authority exists

R14: every driver/device authority is confined to assigned frames,
     capabilities, boundaries, and policies

R15: every FFI/host call crosses a declared boundary and maps host absence,
     errors, effects, and commits explicitly

R16: every AI/tooling path remains advisory unless separately parsed,
     canonicalized, validated, authorized, accepted, and committed where
     required

R17: every quarantine tightens Χ, attenuates Ω, applies Ψ, and commits state
     through Σ

R18: every sealed isolation state forbids further entry, expansion, or
     reachability growth while permitting valid exit/closure under policy

R19: every cache or fast path preserves the same Ω/Χ/Ψ/Φ/Σ obligations as the
     slow path

R20: every runtime profile declares which invariants it enforces, checks,
     simulates, observes, reports, or leaves unsupported

R21: invariant evidence strengthens implementation-layer security claims and
     does not function as PMS Base validation
```

### 8.36 Architectural Consequence

The consequence is:

```text
PMS-STACK runtime security is invariant-centered. Security is not
established by a single permission check, sandbox flag, policy file,
audit log, key, kernel privilege, AI/tooling report, or verification pass.
It is established by preservation of operator-typed invariants across the
complete runtime transition surface.
```

The invariant architecture binds:

```text
identity
authority
frames
boundaries
policies
hooks
scheduler order
resources
absence
traps
commits
audit
trust
network sessions
drivers
FFI
tooling
profiles
reports
quarantine
failure recovery
```

into a single runtime-security discipline.

This gives `06_runtime_security.md` its enforcement core:

```text
a PMS-STACK runtime is security-conformant to the extent that its
declared runtime profile preserves the invariants required by its
security, governance, trust, audit, tooling, evidence, and execution
claims.
```

### 8.37 Runtime Invariant Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK runtime-invariant model specifies implementation-layer
runtime-security preservation architecture: runtime-security state,
invariant classes, preservation laws, kernel global invariants, identity
invariants, role/capability invariants, frame invariants, boundary and
isolation invariants, policy invariants, hook invariants, scheduler
invariants, resource invariants, absence invariants, trap invariants,
commit invariants, audit invariants, trust-anchor invariants, network and
distributed invariants, driver/device invariants, FFI/host invariants,
tooling/AI invariants, failure/recovery invariants, quarantine invariants,
sealed-isolation invariants, invariant composition, violation handling,
checking mechanisms, trace/evidence conventions, reports, runtime
profiles, PMS-RUST evidence boundaries, consolidated invariants, and
architectural consequences.

This is a runtime-security invariant / preservation architecture claim.

It does not claim completed runtime-security implementation, universal
security certification, complete deployment security, complete PMS-OS,
complete PMSL/PMS-IR, complete distributed runtime, completed network
stack, completed cryptographic system, legal authority, moral authority,
clinical authority, forensic omniscience, tribunal status, trusted AI
authority, proof of all security properties, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection paths, JSONL traces, golden fixtures, vFS/service boundaries,
bounded isolation-exit discipline, and AI proposal gating. It does not
complete runtime security and does not validate PMS Base.
```

---

## 9. Audit and Compliance Hooks

Audit and compliance hooks are the evidence surface of PMS-STACK runtime security.

They record, order, commit, preserve, correlate, redact, export, and check security-relevant runtime behavior. They make identity, role, capability, frame, boundary projection, policy, trap, absence, resource, trust, and commit decisions inspectable without converting inspection into proof of PMS Base.

The central audit claim is:

```text
A PMS-STACK audit system is valid when security-relevant transitions are
represented as operator-labeled, Θ-ordered, Ψ-governed, and Σ-committed
evidence artifacts whose identity, role, capability, frame, boundary
projection, policy, resource, trust, trap, absence, and commit context is
sufficient for runtime inspection and conformance checking under a
declared profile.
```

The central compliance claim is:

```text
A PMS-STACK compliance check is valid when it evaluates declared policies,
invariants, audit requirements, and commit obligations against declared
runtime evidence: Θ event streams, Σ commit artifacts, identity graphs,
role/capability state, isolation graphs, resource accounts, trust state,
audit-access records, and runtime profiles.
```

Claim type:

```text
RUNTIME-SECURITY AUDIT / COMPLIANCE ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK audit and compliance hooks as
implementation-layer runtime-security evidence and conformance
architecture.

Audit is not merely logging.
Compliance is not moral judgment, legal judgment, forensic omniscience,
tribunal status, universal security certification, or PMS Base validation.

Audit records evidence runtime behavior under declared profiles.
Compliance checks evidence against declared policies and invariants.
Neither proves all possible executions unless paired with stated models,
bounds, assumptions, and proof or model-checking artifacts.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At audit/compliance level, Χ is projected as audit visibility boundary, redaction boundary, evidence-access boundary, tenant boundary, host boundary, process boundary, network/session boundary, distributed evidence boundary, quarantine boundary, and trust-boundary control.

Audit and compliance use this Χ projection. They do not redefine PMS Base Χ.

Validation in this section means acceptance or rejection under a declared audit schema, compliance profile, evidence profile, runtime-security policy, invariant set, hook schema, trace schema, report format, or verification profile.

It does not mean external validation of PMS Base.

The assurance vocabulary is:

```text
tests check
traces record
audit records evidence observed transitions
validators accept or reject under profile
trace conformance checks observed behavior against declared expectations
compliance checks evidence against declared obligations
model checking verifies stated properties under stated models
proof artifacts prove stated properties under formal assumptions
external validation validates externally under an explicitly designed protocol
```

### 9.1 Role of Audit in Runtime Security

Audit answers:

```text
what happened?
who acted?
under which role?
with which capability?
inside which frame?
across which boundary projection?
under which policy?
with which decision?
with which result?
was anything committed?
was anything denied?
was anything transformed?
was anything quarantined?
was evidence preserved?
which profile governs the evidence?
```

Audit binds execution to evidence.

A security runtime without audit can deny, allow, trap, quarantine, or commit, but it cannot reliably explain its own security behavior.

A PMS-STACK audit system therefore records not only outcomes, but the operator context of outcomes:

```text
Δ classification
Ω authority
□ frame
Χ boundary projection
Ψ policy decision
Θ ordering
Λ absence
Φ trap/recontextualization
Σ commit
```

Audit is the runtime’s evidence memory of operator-governed security behavior.

### 9.2 Θ and Σ as Audit Foundation

Auditing requires two structural facts.

#### Ordering

```text
Where in execution did this happen?
```

Provided by:

```text
Θ ordering
Θ step index
scheduler order
event sequence
logical order
runtime trace order
distributed logical order under declared profile
```

τ may provide timestamp metadata:

```text
τ.timestamp(e)
τ.now
τ.window
τ.deadline
τ.expiry
```

but Θ gives the execution ordering relation.

#### Committed Reality

```text
What became stable?
```

Provided by:

```text
Σ commit
Σ checkpoint
Σ durable record
Σ audit chunk
Σ resource accounting update
Σ policy activation
Σ trust-anchor update
Σ quarantine state
Σ session state
```

Before Σ:

```text
event may be tentative, staged, provisional, rollbackable
```

At or after Σ:

```text
state becomes binding under the declared commit profile
```

Together:

```text
Θ = order of evidence
Σ = stability of evidence
```

Audit without Θ loses sequence.

Audit without Σ cannot distinguish tentative observation from committed evidence.

### 9.3 Audit Event

An audit event is an operator-labeled runtime evidence record.

Generic form:

```text
AuditEvent = (
    event_id,
    order,
    timestamp?,
    operator,
    actor,
    effective_actor?,
    role,
    capability?,
    frame,
    boundary?,
    policy?,
    operation,
    target,
    decision,
    result,
    commit_state?,
    resource_delta?,
    trust_state?,
    source,
    runtime_profile,
    meta
)
```

Minimal form:

```text
AuditEvent = (
    order,
    op,
    actor,
    frame,
    role,
    result
)
```

Security-grade form:

```text
AuditEvent = (
    event_id,
    Θ_order,
    τ_timestamp?,
    op,
    principal,
    effective_principal,
    role,
    capability,
    frame,
    isolation_domain,
    boundary_relation,
    policy_ids,
    operation,
    target,
    decision,
    action,
    result,
    Σ_commit_id?,
    provenance,
    runtime_profile,
    evidence_profile,
    meta
)
```

Audit records must be machine-readable and operator-readable.

A concrete audit trace produces:

```text
trace_runtime(runtime, audit_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible audit traces under a declared profile is:

```text
Trace_runtime(runtime, audit_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Trace records observed behavior. It does not prove all possible behavior.

### 9.4 Audit Event Classes

Audit events may be classified by operator.

#### Δ Audit Events

Record distinctions.

Examples:

```text
syscall classified
path resolved
credential classified
device matched
policy selected
remote principal distinguished
tooling artifact classified
```

Fields:

```text
classification_type
input_summary
resolved_target
branch
reason
profile
```

#### ∇ Audit Events

Record mutations or attempted mutations.

Examples:

```text
file write
memory write
IPC enqueue
network send
device register write
capability table update
resource allocation
host service call
```

Fields:

```text
mutation_type
target
delta
pre_state_hash?
post_state_hash?
staged?
```

#### □ Audit Events

Record frame/context changes.

Examples:

```text
process frame entered
kernel frame entered
shared frame mapped
ForeignFrame entered
driver frame bound
AuditFrame entered
tooling frame entered
```

Fields:

```text
old_frame
new_frame
reason
frame_scope
```

#### Λ Audit Events

Record typed absences.

Examples:

```text
timeout
no message
no resource
no route
missing credential
unsupported runtime feature
host-service no-response
```

Fields:

```text
expected
absence_kind
deadline?
wait_context
policy_response
```

#### Ω Audit Events

Record authority checks and changes.

Examples:

```text
capability check
capability grant
capability revoke
role switch
delegation
impersonation
privilege denial
tooling authority check
```

Fields:

```text
role
capability
scope
delegation_chain?
decision
```

#### Θ Audit Events

Record ordering, scheduling, expiry, and rate windows.

Examples:

```text
scheduler tick
dispatch
preemption
expiry check
quota window update
audit sequence marker
```

Fields:

```text
order_index
scheduler_class
subject
reason
τ_window?
```

#### Φ Audit Events

Record traps and recontextualizations.

Examples:

```text
syscall entry
syscall return
page fault
policy violation trap
driver fault
quarantine entry
remote identity mapping
FFI error mapping
AI/tooling violation recontextualization
```

Fields:

```text
source_context
target_context
cause
trap_type
reframe_result
```

#### Χ Audit Events

Record boundary and isolation behavior as runtime projections of PMS Base Distance.

Examples:

```text
boundary crossing
sandbox entry
sealed isolation exit
shared memory bridge
container namespace switch
host boundary entry
network session boundary
quarantine boundary
audit visibility boundary
```

Fields:

```text
source_domain
target_domain
edge
boundary_kind
allowed_or_denied
active_boundary_context?
```

#### Σ Audit Events

Record commits.

Examples:

```text
filesystem commit
IPC delivery commit
capability grant commit
policy activation commit
trust-anchor rotation commit
audit chunk commit
resource accounting commit
quarantine commit
tooling rejection commit
```

Fields:

```text
commit_id
commit_profile
subject
write_set
hash?
durability
previous_commit?
```

#### Ψ Audit Events

Record policy evaluation and governance decisions.

Examples:

```text
policy allow
policy deny
policy modify
policy quarantine
policy conflict
policy failure
policy update
policy revocation
AI/tooling advisory-only denial
```

Fields:

```text
policy_ids
predicate_result
decision
action
reason
failure_mode?
```

### 9.5 Audit Hooks

Audit hooks are runtime attachment points that emit audit events.

They may be attached to:

```text
kernel policy hooks
syscall entry/exit
scheduler transitions
memory operations
filesystem operations
IPC operations
network operations
driver/device operations
policy lifecycle events
capability lifecycle events
trust-anchor lifecycle events
resource accounting updates
debug/audit access
FFI/host calls
quarantine transitions
sealed isolation entry/exit
distributed session events
tooling/AI proposal boundaries
```

Generic audit hook:

```text
AuditHook = (
    hook_id,
    trigger,
    operator_class,
    context_builder,
    audit_profile,
    redaction_policy,
    commit_profile,
    failure_policy
)
```

Audit hook execution:

```text
Δ classify event
Θ order event
Ψ apply audit policy
Χ apply visibility/redaction boundary as runtime projection
Σ commit event if required
```

Audit hooks are themselves policy-governed.

A runtime may not expose sensitive audit content merely because the event exists.

### 9.6 Audit Profiles

Audit behavior depends on profile.

Recommended audit profiles:

```text
NONE
METADATA_ONLY
DECISION_ONLY
SECURITY
RESOURCE
FULL_TRACE
DURABLE
HASH_CHAINED
REDACTED
DISTRIBUTED
COMPLIANCE_EXPORT
INCIDENT_REVIEW
SIMULATION
DEBUG
```

Profile examples:

#### `SECURITY`

Records:

```text
identity
role
capability
boundary projection
policy decision
result
```

#### `RESOURCE`

Records:

```text
resource class
delta
account before/after
quota
decision
```

#### `DURABLE`

Requires:

```text
Σ commit before evidence is considered stable under the profile
```

#### `REDACTED`

Applies:

```text
field-level Ψ policy
Χ visibility boundary
hash/summarize/remove sensitive payloads
```

#### `DISTRIBUTED`

Adds:

```text
node id
session id
remote principal
vector/logical clock metadata
cross-node commit reference
```

#### `INCIDENT_REVIEW`

Supports post-event inspection under declared evidence, redaction, retention, and access policies.

It does not make the audit system a forensic authority or legal proof engine.

A runtime must declare which audit profiles it supports.

### 9.7 Audit Scope

Policies define what must be audited.

Scope may be:

```text
system-wide
kernel
process
thread
role
principal
capability
frame
boundary
filesystem
network
device
driver
module
FFI/host
trust-anchor
resource account
audit log
policy set
distributed node
tooling service
AI service
```

Audit scope determines:

```text
which events emit audit
which fields are captured
which commit profile applies
which redaction applies
who may inspect the record
how long evidence is retained
what happens if audit fails
```

Example:

```text
Ψ_audit_policy:
    all Ω grants and revocations require durable audit
```

Example:

```text
Ψ_network_audit:
    all network session establishment events require SECURITY audit
```

Example:

```text
Ψ_driver_audit:
    all MMIO writes by driver role require RESOURCE + SECURITY audit
```

Audit scope is part of runtime governance. It is not an authority over humans as such.

### 9.8 Audit Decision

An audit hook may produce an audit decision.

```text
AuditDecision = (
    emit,
    suppress?,
    redact?,
    summarize?,
    hash?,
    commit?,
    export?,
    deny_original_operation?,
    failure_action?
)
```

Possible audit actions:

```text
EMIT
DROP
REDACT
HASH
SUMMARIZE
COMMIT
COMMIT_DURABLE
EXPORT
DEFER
DENY_EXPORT
DENY_ORIGINAL_OPERATION
QUARANTINE_ON_AUDIT_FAILURE
HALT_ON_AUDIT_FAILURE
```

Example:

```text
audit required but audit log unavailable
```

Policy may decide:

```text
deny original operation
defer operation
use fallback audit sink
quarantine subject
halt if critical invariant
```

Audit failure is not an implementation detail. It is a runtime-security event.

### 9.9 Audit Commit

Audit events may be tentative or committed.

Tentative audit:

```text
event exists in Θ stream
not yet stable
may be pruned or rolled back under profile
```

Committed audit:

```text
Σ commits audit event or chunk
event becomes stable evidence under declared profile
```

Audit commit artifact:

```text
AuditCommit = (
    commit_id,
    event_range,
    previous_commit?,
    hash?,
    policy_snapshot,
    frame_snapshot?,
    resource_snapshot?,
    trust_snapshot?,
    redaction_profile,
    storage_target,
    durability,
    meta
)
```

Generic form:

```text
A_k = Σ(Θ_{i...j}, state)
```

where:

```text
Θ_{i...j} = ordered event slice
state      = post-commit state or subset required by policy
```

Audit commit invariant:

```text
audit chunk cannot partially commit.
```

If an audit chunk is required for compliance, incomplete commit must be represented as failure.

### 9.10 Audit Storage

Audit storage may be:

```text
in-memory ring buffer
kernel trace buffer
Σ-committed audit journal
filesystem-backed audit log
append-only security log
hash-chained log
remote collector
distributed audit fabric
compliance export bundle
simulation trace
golden fixture trace
```

Storage profile includes:

```text
retention
rotation
integrity
redaction
encryption?
hashing?
compression?
replication?
access policy
failure response
```

Audit storage itself is protected state.

```text
AuditLog = (
    frame,
    owner,
    policy,
    boundary,
    retention,
    commit_profile
)
```

Audit log access requires:

```text
Δ classify query
Ω verify observer capability
Χ check audit visibility boundary as runtime projection
Ψ apply redaction/export policy
∇ read/export
Σ commit audit-access record if required
```

Audit storage supports inspection and conformance. It does not create forensic omniscience.

### 9.11 Audit Rotation and Retention

Audit retention is Ψ-governed.

Retention policy may specify:

```text
minimum duration
maximum duration
maximum size
rotation interval
compression
hash-chain preservation
remote copy requirement
redaction after interval
legal/compliance hold under external profile
secure deletion profile
```

Rotation flow:

```text
Δ classify audit segment
Ψ evaluate retention/rotation policy
Σ seal current segment
∇ create new segment
Σ commit rotation state
Θ audit rotation event
```

Deletion flow:

```text
Δ classify deletion candidate
Ω verify deletion authority
Ψ evaluate retention policy
Σ commit deletion or archive
Θ audit deletion event
```

Audit deletion is itself an auditable transition.

Retention policy may support external compliance workflows. It does not itself constitute legal authority.

### 9.12 Audit Redaction

Audit content may be sensitive.

Sensitive fields:

```text
secret values
personal data
capability tokens
private key references
host responses
network addresses
policy internals
debug payloads
memory contents
AI prompts/responses
credential material
```

Redaction flow:

```text
Δ classify field
Ω verify observer authority
Χ check visibility boundary as runtime projection
Ψ apply redaction policy
Σ commit redacted export if exported
```

Redaction actions:

```text
remove
mask
hash
summarize
tokenize
bucket
delay
deny
```

Redaction invariant:

```text
redacted report must state that it is redacted.
```

A redacted audit record is valid evidence for the fields it preserves, not for hidden contents.

### 9.13 Audit Access

Audit inspection is a protected operation.

Audit access request:

```text
AuditReadRequest = (
    observer,
    target_log,
    query,
    requested_fields,
    purpose?,
    export_profile?,
    runtime_profile
)
```

Access flow:

```text
Δ classify request
Ω verify observer role/capability
Χ check audit boundary as runtime projection
Ψ evaluate access/redaction/export policy
∇ read permitted records
Σ commit access event if required
```

Audit access outcomes:

```text
allow full
allow redacted
allow metadata only
deny
defer
require approval
quarantine suspicious observer
```

Audit access is not free merely because logs exist.

Audit access may be granted only under declared observer authority, boundary visibility, redaction policy, and evidence profile.

### 9.14 Compliance Hooks

Compliance hooks are higher-order audit consumers.

They evaluate evidence against declared policies and invariants.

Compliance hook form:

```text
ComplianceHook = (
    hook_id,
    evidence_source,
    policy_set,
    invariant_set,
    check_profile,
    report_profile,
    failure_policy
)
```

Input evidence:

```text
Θ event stream
Σ commit artifacts
identity graph
role/capability lattice
isolation graph
policy set
resource accounts
trust-anchor state
network session state
driver/device state
audit access records
runtime profile
```

Compliance hook flow:

```text
Δ classify compliance check
Ω verify compliance authority
Χ check evidence visibility as runtime projection
Ψ select policy/invariant obligations
∇ evaluate evidence
Σ commit compliance report if required
Θ audit compliance check
```

Compliance is policy-based meta-checking over committed or declared evidence.

It is not tribunal status, legal judgment, moral judgment, clinical classification, forensic omniscience, universal security certification, or PMS Base validation.

### 9.15 Compliance Report

A compliance report is a structured artifact.

```text
ComplianceReport = (
    report_id,
    scope,
    runtime_profile,
    evidence_range,
    policy_set,
    invariant_set,
    checks,
    results,
    violations,
    missing_evidence,
    redactions,
    assumptions,
    limitations,
    commit_ref?,
    meta
)
```

Result statuses:

```text
COMPLIANT
NON_COMPLIANT
PARTIAL
UNKNOWN
INCONCLUSIVE
UNSUPPORTED
REDACTED
EVIDENCE_MISSING
PROFILE_LIMITED
COUNTEREXAMPLE
```

A compliance report must state:

```text
what was checked
against which policy/invariant set
over which evidence
under which profile
with which redactions
with which assumptions
with which limitations
```

Correct claim:

```text
System behavior in evidence range R satisfies policy set P under profile X.
```

Incorrect claim:

```text
The system is absolutely secure.
The report proves forensic truth.
The report validates PMS Base.
```

Compliance reports are inspection artifacts. They support runtime-security conformance review under declared profiles.

### 9.16 Compliance Checks

Compliance checks may include:

```text
all required audits present
no protected transition without Ω authority
no cross-boundary action without Χ/Ψ authorization
no invalid policy mutation
no capability grant without Σ commit
no trust-anchor rotation without policy approval
no resource quota violation without policy response
no driver MMIO access outside assigned frame
no FFI host call without ForeignFrame
no AI/tooling proposal executed without validation
all commit records consistent
all redaction policies applied
all quarantine events committed
all sealed-isolation exits have active boundary context
```

Examples:

#### Capability Compliance

```text
∀ protected ∇:
    exists prior Ω_allow
    ∧ policy Ψ permits
    ∧ audit event exists if required
```

#### Boundary Compliance

```text
∀ boundary_crossing:
    edge or bridge exists
    ∧ Ω authorizes crossing
    ∧ Χ projection permits crossing
    ∧ Ψ permits crossing
    ∧ audit event exists if required
```

#### Commit Compliance

```text
∀ security-critical Σ:
    prior checks valid
    ∧ policy permits
    ∧ audit requirement satisfied
```

#### Trust Compliance

```text
∀ credential-derived authority:
    credential classified
    ∧ trust policy verified
    ∧ Φ mapping recorded
    ∧ local authority committed
```

#### AI / Tooling Compliance

```text
∀ executed tooling-derived artifact:
    proposal classified
    ∧ host parsed/canonicalized
    ∧ validation accepted
    ∧ policy permitted execution
    ∧ runtime accepted artifact
    ∧ proposal authority remained distinct from execution authority
```

### 9.17 Audit and Resource Accounting

Resource-affecting events are audit-relevant.

Resource audit record:

```text
ResourceAuditRecord = (
    event_id,
    order,
    actor,
    role,
    frame,
    isolation_domain,
    resource_class,
    delta,
    account_before,
    account_after,
    limit,
    policy,
    decision,
    action,
    timestamp?,
    metadata
)
```

Resource audit flow:

```text
Δ classify resource event
Ω identify accountable principal/role
Θ order event
Σ commit resource accounting update
Ψ enforce quota/retention policy
Σ commit audit record if required
```

Auditable resource events:

```text
CPU quota update
memory allocation
IPC send/receive
storage growth
network byte accounting
driver buffer allocation
audit log growth
trace export
host call budget
resource reclamation
```

Resource compliance checks:

```text
all resource deltas accounted
quota decisions match committed counters
hard limit violations deny further use
soft limit violations produce policy-defined response
accounting records are not missing before compliance report
```

Resource accounting is runtime governance. It is not social evaluation, moral ranking, clinical classification, or person ranking.

### 9.18 Audit and Policy Decisions

Policy decisions may become audit events.

Policy audit record:

```text
PolicyAuditRecord = (
    event_id,
    order,
    actor,
    target,
    operator_class,
    operation,
    policy_ids,
    decision,
    action,
    reason,
    frame,
    boundary,
    role,
    capability,
    commit_state,
    runtime_profile,
    meta
)
```

Events usually audited:

```text
policy allow for high-value target
policy denial
policy modification
policy conflict
policy failure
policy quarantine decision
policy lifecycle transition
policy cache invalidation
AI/tooling advisory-only denial
sealed-isolation exit decision
```

Policy audit invariants:

```text
policy denial must be distinguishable from missing capability
policy modification must record actor and authority
policy conflict must record resolution rule
policy failure mode must be recorded
policy cache invalidation must identify the invalidated dependency
policy decision evidence must state its runtime profile
```

Policy audit supports inspection of runtime governance.

It does not prove policy correctness, complete security, external validity, legal correctness, moral correctness, forensic truth, or PMS Base validity.

### 9.19 Audit and Capability Lifecycle

Capability lifecycle is audit-critical because authority changes alter what future transitions may become valid.

Audited events:

```text
capability grant
capability revoke
capability attenuation
capability delegation
capability expiry
capability denial
capability use on high-value target
capability cache invalidation
capability restoration after quarantine or recovery
```

Capability audit record:

```text
CapabilityAuditRecord = (
    event_id,
    order,
    actor,
    subject,
    capability,
    operation,
    target,
    scope,
    delegation_chain?,
    lifetime?,
    decision,
    policy,
    commit_id?,
    runtime_profile,
    meta
)
```

Compliance checks:

```text
no active capability without grant record if audit profile requires it
no delegation broader than source capability
no expired capability used after expiry
no revoked capability accepted after revocation commit
no high-value capability use without required audit evidence
no capability cache reuse after policy/capability/boundary epoch invalidation
```

Capability audit supports authority inspection. It does not prove that all possible authority paths are safe unless paired with stated model, bounds, and proof or model-checking artifacts.

### 9.20 Audit and Trust Anchors

Trust-anchor events require strong evidence because they affect identity mapping, session authority, credential interpretation, and local trust state.

Audited events:

```text
key creation
key import
key use
key rotation
key revocation
trust-anchor update
credential verification
session establishment
node admission
signature failure
trust-policy denial
trust-state rollback
```

Trust audit record:

```text
TrustAuditRecord = (
    event_id,
    order,
    actor,
    key_or_anchor,
    operation,
    trust_policy,
    credential_summary,
    decision,
    Φ_mapping?,
    Σ_session_or_trust_commit?,
    expiry?,
    revocation_state?,
    key_frame?,
    boundary_relation?,
    runtime_profile,
    meta
)
```

Compliance checks:

```text
no credential-derived authority without trust-policy verification
no session authority without Σ session commit
no trust-anchor update without Ω authority
no key use outside key-frame boundary
no key-frame export without Ω/Χ/Ψ authorization
all rotations and revocations are auditable where required
```

A trust anchor does not create authority by existing.

A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

Trust validation means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, and runtime policy profile. It does not mean legal identity proof, universal trust, external validation, or PMS Base validation.

### 9.21 Audit and Boundary Crossings

Boundary crossings are core audit events.

At PMS Base level:

```text
Χ = Distance
```

At audit level, Χ is projected as runtime boundary, audit visibility boundary, evidence-access boundary, redaction boundary, network/session boundary, host boundary, quarantine boundary, and trust-boundary control.

Boundary audit record:

```text
BoundaryAuditRecord = (
    event_id,
    order,
    actor,
    source_frame,
    target_frame,
    source_domain,
    target_domain,
    boundary_kind,
    edge_or_bridge,
    capability,
    policy,
    decision,
    transfer_profile?,
    commit_id?,
    runtime_profile,
    meta
)
```

Audited boundaries:

```text
kernel/user
process/process
module/module
container/host
driver/device
FFI/host
network/session
audit/export
trust-anchor/key-frame
tooling/runtime
distributed node
sealed isolation exit
```

Compliance checks:

```text
no crossing without declared bridge or edge
no host call without ForeignFrame
no driver DMA outside assigned frame
no audit export across redaction boundary without authority
no network local authority before remote identity mapping
no sealed isolation exit without active boundary context
```

Boundary audit records do not redefine PMS Base Χ. They record implementation-layer boundary projections.

### 9.22 Audit and Quarantine

Quarantine must be auditable.

Quarantine audit record:

```text
QuarantineAuditRecord = (
    event_id,
    order,
    subject,
    cause,
    policy,
    prior_capabilities,
    revoked_capabilities,
    old_boundary,
    new_boundary,
    scheduler_effect,
    resource_effect,
    commit_id,
    release_policy?,
    runtime_profile,
    meta
)
```

Quarantine flow:

```text
Δ classify subject/cause
Ψ decide quarantine
Φ enter restricted context
Χ tighten boundary as runtime projection
Ω revoke/attenuate capabilities
Σ commit quarantine state
Θ audit event
```

Compliance checks:

```text
quarantined subject cannot use pre-quarantine authority
quarantine has committed boundary state
scheduler observes quarantine
IPC/network/filesystem/device logic observes quarantine
release is policy-governed
quarantine release has audit evidence where required
```

Quarantine is not a moral judgment, legal verdict, forensic conclusion, clinical classification, or person-level sanction.

It is a runtime-security boundary response.

### 9.23 Audit and FFI / Host Calls

Host calls are audit-sensitive because they cross a foreign boundary.

FFI audit record:

```text
FFIAuditRecord = (
    event_id,
    order,
    actor,
    host,
    foreign_symbol,
    ForeignFrame,
    capability,
    boundary,
    policy,
    memory_transfer_profile,
    error_map,
    result_class,
    commit_profile,
    runtime_profile,
    meta
)
```

Audited FFI events:

```text
host call admission
host call denial
foreign symbol resolution
memory transfer
host error mapping
host no-response/timeout
host result integration
host-side service event
```

Compliance checks:

```text
no host call without ForeignFrame
no raw host pointer crosses without memory profile
host error maps to Φ or Λ
host result is committed only under declared Σ profile
host behavior is not treated as PMS-OS/PMSL-native truth
host-service events remain distinguishable from PMS kernel execution
```

A host runtime may support execution. It does not become PMS-OS.

### 9.24 Audit and AI / Tooling

AI and tooling are audit boundaries.

AI/tooling audit record:

```text
ToolingAuditRecord = (
    event_id,
    order,
    tooling_principal,
    task,
    input_artifact,
    output_artifact,
    advisory_status,
    validation_status,
    policy,
    boundary,
    decision,
    commit_state?,
    runtime_profile,
    meta
)
```

Audited tooling events:

```text
AI proposal request
AI proposal response
trace analysis request
redaction before AI request
PMS-IR parse/canonicalization
validation acceptance/rejection
runtime acceptance
execution denial
tooling policy denial
buffer replacement attempt
advisory explanation generation
```

Compliance checks:

```text
AI proposal did not execute directly
proposal authority separated from execution authority
host validation occurred before runtime acceptance
redaction policy applied before external/tooling boundary
advisory output was labeled advisory
AI/tooling output was not recorded as verification evidence
AI/tooling output was not recorded as PMS Base evidence
```

Standard boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI output is not trusted executable code, compiler authority, verifier authority, runtime policy authority, verification evidence, or PMS Base validation.

### 9.25 Distributed Audit

Distributed audit extends Θ/Σ evidence across nodes.

Distributed audit record:

```text
DistributedAuditRecord = (
    node_id,
    local_order,
    cluster_order?,
    vector_clock?,
    event,
    local_commit,
    remote_commit_refs,
    trust_anchor_state,
    quorum_state?,
    runtime_profile,
    meta
)
```

Distributed audit may use:

```text
hash chaining
Merkle DAG
cross-node commit references
quorum-signed summaries
replicated audit chunks
remote collector
cluster compliance report
```

Distributed audit flow:

```text
node commits local audit artifact
node transmits commit hash/summary
peers verify under trust policy
cluster records cross-reference
Σ commits distributed audit state
```

Distributed compliance checks:

```text
node identities valid
session boundaries explicit
quorum policies satisfied
commit references consistent
no unilateral global commit without policy
audit chains unbroken under declared model
partition handling recorded under declared profile
```

Full distributed semantics are refined in `07_distributed_systems.md`.

This section defines the runtime-security audit form. It does not complete distributed consensus, cluster policy synchronization, global commit semantics, or multi-node failure semantics.

### 9.26 Audit Failure Handling

Audit failure is operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| audit event cannot be created | Δ / Φ |
| audit sink absent | Λ |
| audit storage full | Λ / Ψ / Φ |
| audit commit failure | Σ / Φ |
| redaction policy conflict | Ψ |
| unauthorized audit read | Ω / Χ / Ψ |
| audit export denied | Χ / Ψ |
| audit chain broken | Σ / Ψ / Φ |
| remote audit collector unavailable | Λ / Θ / Ψ |
| required audit missing | Ψ compliance failure |
| audit cache stale | Θ / Ψ |
| audit tamper detected | Δ / Ψ / Φ / Χ |
| AI/tooling audit boundary missing | Δ / Χ / Ψ |

Failure response depends on policy.

Possible actions:

```text
deny original operation
defer operation
use fallback audit sink
emit reduced metadata
quarantine subject
halt critical subsystem
mark compliance report partial
raise Φ audit trap
invalidate acceptance gate
```

Critical policy:

```text
security-critical operation requiring durable audit
    ∧ audit commit unavailable
    ⇒ deny or halt under policy
```

Audit failure must not silently disappear from the evidence surface.

### 9.27 Compliance Failure Handling

Compliance failure is typed.

Possible failures:

```text
evidence missing
policy violated
invariant violated
audit redacted beyond checkability
commit chain broken
identity graph incomplete
capability provenance missing
boundary crossing unaccounted
resource accounting mismatch
trust-anchor state inconsistent
runtime profile unsupported
AI/tooling boundary evidence missing
distributed commit reference inconsistent
```

Compliance response:

```text
report NON_COMPLIANT
report PARTIAL
report UNKNOWN
report INCONCLUSIVE
trigger policy review
trigger quarantine
trigger revocation
trigger rollback if possible
block deployment
fail acceptance gate
open incident-review workflow
```

Compliance is not the enforcement point unless policy grants it such authority.

```text
compliance check may observe
compliance policy may require response
runtime Ψ decides enforcement
```

Compliance failure does not by itself create legal judgment, moral judgment, forensic truth, or PMS Base validation.

### 9.28 Audit and Compliance Reports as Artifacts

Audit and compliance artifacts may include:

```text
raw event log
operator trace
audit chunk
commit chain
resource report
policy decision log
capability lifecycle report
boundary crossing report
trust-anchor report
quarantine report
compliance report
distributed audit summary
golden trace comparison
simulation compliance report
AI/tooling boundary report
```

Artifact metadata:

```text
artifact_id
source_runtime
runtime_profile
policy_epoch
capability_epoch
boundary_epoch
trust_epoch
event_range
commit_range
redaction_profile
completeness_status
signature/hash?
limitations
```

Artifact status:

```text
raw
redacted
committed
durable
partial
profile-limited
simulation
advisory
verified_against_policy
non_compliant
inconclusive
unsupported
```

A report must not overstate its status.

Correct claim:

```text
Artifact A evidences behavior B under profile P over event range R.
```

Incorrect claim:

```text
Artifact A proves complete security.
Artifact A validates PMS Base.
Artifact A proves hidden redacted contents.
```

### 9.29 Compliance as Acceptance Gate

Compliance can serve as an acceptance gate for artifacts.

Examples:

```text
PMS-IR program acceptance
runtime profile acceptance
kernel hook coverage acceptance
policy set activation
driver load
trust-anchor rotation
distributed node admission
AI-proposed artifact acceptance
deployment release
```

Acceptance gate form:

```text
AcceptanceGate = (
    artifact,
    required_policies,
    required_invariants,
    required_audit_evidence,
    required_commit_profile,
    check_result,
    decision
)
```

Gate decisions:

```text
ACCEPT
REJECT
ACCEPT_WITH_WARNINGS
REQUIRE_REVIEW
REQUIRE_ADDITIONAL_EVIDENCE
UNSUPPORTED
```

Acceptance gate boundary:

```text
accepted artifact under profile P
≠ universally valid artifact
```

An acceptance gate may support implementation-artifact claims. It does not validate PMS Base, prove complete deployment security, or convert profile-local evidence into universal correctness.

### 9.30 Audit and Trace Conformance

Trace conformance checks audit/event behavior against expected operator structure.

Example property:

```text
every protected filesystem write has:
    Δ path classification
    Ω capability check
    Χ namespace boundary check as runtime projection
    Ψ policy decision
    ∇ write/stage
    Σ commit or Φ/Λ failure
    Θ audit event if required
```

Trace conformance failure:

```text
observed Σ commit without prior Ψ allow
observed host call without ForeignFrame
observed capability grant without audit
observed network authority before identity mapping
observed quarantine without committed boundary change
observed AI/tooling proposal executed without validation evidence
observed sealed isolation exit without active boundary context
```

Trace convention:

```text
trace_runtime(runtime, audit_artifact, input_profile) ∈ L_PMS,Ψ_runtime
Trace_runtime(runtime, audit_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

Trace conformance supports regression and evidence quality.

It does not prove all possible executions unless paired with stated coverage, model, bounds, and proof or model-checking artifacts.

### 9.31 Audit and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

PMS-RUST-style artifacts are relevant when they provide bounded executable evidence such as:

```text
operator-tagged traces
JSONL trace/audit output
golden fixtures
model validation reports
stateful validation reports
vFS service-event traces
AI proposal acceptance/rejection traces
deterministic kernel execution traces
bounded chi_enter / chi_exit evidence
fail-closed rejection paths
```

Correct relation:

```text
Audit/compliance specification
    defines evidence obligations.

PMS-RUST bounded artifacts
    may demonstrate executable slices of trace generation,
    audit representation, golden comparison, rejection paths,
    acceptance-gate behavior, service-boundary separation, and
    AI proposal gating.
```

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where an active boundary context is required before exit.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime security, complete audit/compliance implementation, or validate PMS Base.

This strengthens the implementation-artifact claim.

It does not validate PMS Base, prove all executions, prove all deployments, or make tests/traces proofs.

### 9.32 Audit and Compliance Claim Boundary

The audit/compliance model claims:

```text
PMS-STACK runtime security can make security-relevant execution
operator-readable, orderable, commit-aware, policy-governed,
redaction-aware, evidence-producing, profile-bound, and
compliance-checkable.
```

It does not claim:

```text
audit is complete by default
logs are proof of all behavior
compliance equals legal compliance in any jurisdiction
compliance equals forensic certainty
compliance equals moral authority
compliance equals tribunal status
evidence cannot be tampered with unless implementation supports that
redacted reports prove hidden contents
tests or traces validate PMS Base
implementation artifacts prove complete security
AI/tooling output is trusted evidence
PMS-RUST completes audit/compliance
```

The model is strong because it is precise: it defines what counts as runtime evidence, how it is ordered, how it is committed, how it is protected, how it is redacted, and how it is checked.

### 9.33 Audit and Compliance Invariants

Runtime security maintains the following audit/compliance invariants.

```text
I1: every audit-required event is Δ-classified
I2: every audit event has Θ ordering
I3: every durable audit event is Σ-committed
I4: every audit record identifies actor, role, frame, boundary projection,
    policy, decision, result, and commit state where required
I5: every audit access is Ω/Χ/Ψ-governed
I6: every audit export has explicit redaction and visibility policy
I7: every policy decision requiring audit produces audit evidence or typed failure
I8: every capability grant, revocation, delegation, and high-value use is auditable
    where required
I9: every trust-anchor use, rotation, and revocation is auditable where required
I10: every quarantine event records cause, policy, boundary change, authority change,
     and commit state
I11: every resource-affecting event is accountable when resource policy requires it
I12: every audit storage/rotation/deletion event is itself policy-governed
I13: every compliance report states evidence scope, policy set, runtime profile,
     redaction status, assumptions, and limitations
I14: every compliance failure has a typed result status
I15: every distributed audit record declares node/session/trust context
I16: every AI/tooling audit record preserves advisory/validation/execution boundary
I17: every sealed-isolation exit audit states active boundary context where required
I18: no audit fast path bypasses Ω, Χ, Ψ, Φ, or Σ
I19: no compliance report upgrades trace evidence into PMS Base validation
I20: audit artifacts strengthen implementation-layer evidence claims
I21: compliance checks establish stated properties under stated evidence/profile,
     not absolute security
I22: PMS-RUST-style artifacts may evidence bounded audit/compliance slices; they do
     not complete runtime security or validate PMS Base
```

### 9.34 Architectural Consequence

The consequence is:

```text
PMS-STACK audit is not log accumulation. It is the Θ/Σ evidence
architecture of runtime security: operator-labeled events are ordered,
policy-governed, redaction-aware, boundary-protected, and committed into
evidence artifacts when required.
```

Compliance becomes a structural check over that evidence:

```text
identity graph
role/capability lattice
isolation graph
policy set
resource accounts
trust-anchor state
Θ event stream
Σ commit chain
runtime profile
redaction profile
evidence limitations
```

This gives PMS-STACK a uniform audit/compliance architecture for:

```text
kernel actions
syscalls
policy decisions
capability lifecycle
frame transitions
boundary crossings
resource accounting
driver/device behavior
network sessions
trust anchors
FFI/host calls
debug access
AI/tooling proposals
distributed nodes
quarantine
sealed isolation exits
deployment acceptance gates
```

Audit and compliance strengthen runtime-security implementation claims by making security behavior inspectable, reproducible, and checkable under declared profiles.

They do not function as PMS Base validation.

### 9.35 Audit and Compliance Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK audit and compliance hook model specifies
implementation-layer runtime-security evidence architecture: audit events,
audit event classes, audit hooks, audit profiles, audit scope, audit
decisions, audit commit, audit storage, rotation, retention, redaction,
audit access, compliance hooks, compliance reports, compliance checks,
resource accounting audit, policy-decision audit, capability lifecycle
audit, trust-anchor audit, boundary-crossing audit, quarantine audit,
FFI/host audit, AI/tooling audit, distributed audit, failure handling,
acceptance gates, trace conformance, PMS-RUST evidence boundaries,
audit/compliance invariants, and architectural consequences.

This is a runtime-security audit / compliance architecture claim.

It does not claim completed audit implementation, completed compliance
implementation, universal security certification, legal compliance in any
jurisdiction, forensic certainty, moral authority, clinical authority,
tribunal status, proof of all runtime behavior, complete PMS-OS, complete
PMSL/PMS-IR, complete distributed runtime, trusted AI authority, or PMS
Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged traces, JSONL trace/audit output, golden fixtures,
model/stateful validation reports, fail-closed rejection paths, vFS
service-event traces, bounded isolation-exit discipline, deterministic
kernel execution traces, and AI proposal gating. It does not complete
audit/compliance and does not validate PMS Base.
```

---

## 10. Key and Trust Anchor Management

Key and trust anchor management is the Φ/Ψ/Σ trust-state layer of PMS-STACK runtime security.

Keys, certificates, credentials, signatures, trust anchors, session secrets, firmware-signing keys, cluster governance keys, audit-signing keys, host-service credentials, tooling provenance keys, and root-of-trust objects are not treated as magical authority objects. They are structured runtime artifacts whose meaning depends on frame containment, boundary projection, role/capability authority, policy interpretation, recontextualization, lifecycle state, commit state, and audit evidence.

The central trust-anchor claim is:

```text
A PMS-STACK key/trust-anchor system is valid when key material is
□-framed, Χ-bounded as an implementation-layer isolation projection,
Ω-use-bound, Ψ-policy-constrained, Φ-interpreted across credential,
version, rotation, revocation, recovery, and session contexts,
Θ-ordered for lifecycle/audit, and Σ-committed before it becomes stable
runtime trust state.
```

The compact trust equation is:

```text
Trust = Φ(credentials) subject to Ψ(policies)
```

Stable trust requires:

```text
Φ(credentials)
∧ Ψ(policy)
∧ Ω(use authority)
∧ Χ(key-boundary projection)
∧ □(key/trust frame)
⇒ Σ(trust_state)
```

Claim type:

```text
RUNTIME-SECURITY KEY / TRUST-ANCHOR ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies trust-anchor and key-management architecture.

It does not specify a mandatory cryptographic algorithm, certify
cryptographic strength, prove deployment security, define social trust,
define moral trust, establish institutional legitimacy, define personhood,
prove legal identity, provide forensic certainty, or validate PMS Base.
```

A trust anchor does not create authority by existing.

A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At key/trust-anchor level, Χ is projected as key-frame isolation, export boundary, key-store boundary, host-service boundary, session boundary, credential visibility boundary, trust-store boundary, device boundary, boot boundary, distributed trust boundary, audit visibility boundary, and quarantine boundary.

Key and trust-anchor management uses this Χ projection. It does not redefine PMS Base Χ.

Validation in this section means acceptance or rejection under a declared trust-anchor, key-use, credential, freshness, revocation, lifecycle, runtime policy, artifact, backend, evidence, or conformance profile.

It does not mean external validation of PMS Base, universal identity truth, legal identity proof, universal trust, cryptographic certification, or deployment-security proof.

A key verifies a cryptographic relation under a profile.

A policy interprets what that relation means.

The runtime commits only the resulting local trust state.

### 10.1 Role of Key and Trust Anchor Management

Key and trust anchor management answers:

```text
What key material exists?
Where does it live?
Who may use it?
What may it be used for?
Which frame contains it?
Which boundary projection protects it?
Which policy interprets it?
Which identity does it support?
Which session does it establish?
Which boot state does it validate?
Which driver or firmware does it authenticate?
Which node or cluster authority does it support?
When does it expire?
How is it rotated?
How is it revoked?
What trust state becomes committed?
What audit evidence is required?
```

A key-management layer is valid only when these questions are represented as runtime-security state, not as implicit library behavior.

Key and trust management crosses:

```text
boot
kernel
process identity
driver loading
firmware validation
network sessions
distributed nodes
policy lifecycle
audit/compliance
FFI/host services
PMSL runtime services
tooling/AI proposal boundaries
storage
```

It is therefore part of runtime security, not a cryptographic appendix.

### 10.2 Trust Is Interpretation Under Policy

A credential does not carry universal meaning.

A credential becomes meaningful only through:

```text
Δ classification
Φ interpretation
Ψ policy validation
Ω authorized use
Χ boundary containment as runtime projection
Σ committed trust state
```

Example:

```text
certificate bytes
```

are merely data until the runtime performs:

```text
Δ classify certificate
Ψ verify issuer / validity / revocation / scope
Φ map credential into local identity or trust context
Ω assign local session or verification capability
Χ bind to session/key/trust boundary
Σ commit resulting trust/session state
```

A signature may support a trust decision. It does not replace policy.

A public key may support identity mapping. It does not itself grant local authority.

A root key may validate an image. It does not itself guarantee that the loaded runtime preserves PMS-STACK invariants.

This section therefore treats trust as:

```text
profile-bound interpretation
policy-governed authority
commit-bound runtime state
audit-representable evidence
```

### 10.3 Key Material as Frames

Key material is represented as a frame.

```text
KeyFrame = □(
    material,
    type,
    scope,
    metadata,
    owner,
    policies,
    lifecycle,
    audit_profile
)
```

Minimal form:

```text
keyFrame = □(material, type, scope, metadata)
```

Fields:

| Field | Meaning |
| ----- | ------- |
| `material` | raw key bytes, certificate, key reference, sealed handle, public key, symmetric secret |
| `type` | public, private, symmetric, ephemeral, root, intermediate, session, firmware, cluster |
| `scope` | identities, roles, frames, sessions, nodes, devices, operations allowed to use it |
| `metadata` | algorithm, key length, expiry reference, version, issuer, provenance, usage class |
| `owner` | principal or trust domain that owns/manages the key frame |
| `policies` | Ψ verification/use/rotation/revocation policies |
| `lifecycle` | created, active, suspended, rotating, revoked, expired, archived |
| `audit_profile` | key-use, rotation, revocation, import/export evidence requirements |

Key material is always boundary-sensitive.

```text
private key material
    ⇒ Χ-isolated as runtime projection
       Ω-use-bound
       Ψ-export-controlled
       Σ-commit-governed
```

A key frame may be implemented through many substrates. The PMS-STACK claim is the architecture contract: the substrate must expose the declared frame, boundary, authority, policy, lifecycle, commit, and audit obligations.

### 10.4 Key Material Is Not Authority by Itself

PMS-STACK separates:

```text
key material
credential
trust anchor
identity
role
capability
session
policy
committed trust state
```

The relation is:

```text
key material
    may support credential verification

credential
    may support identity mapping

identity mapping
    may support local principal/session construction

local principal/session
    may receive Ω capabilities

capabilities
    remain Ψ/Χ/□ constrained

stable trust state
    requires Σ commit
```

This prevents a common collapse:

```text
has key
⇒ trusted
⇒ authorized
⇒ committed
```

PMS-STACK requires the full chain.

```text
key possession
≠ identity
≠ authority
≠ policy permission
≠ committed trust state
```

### 10.5 Key Classes

The runtime may classify keys into structural classes.

```text
KeyClass =
    RootTrustKey
  | IntermediateAuthorityKey
  | SigningKey
  | VerificationKey
  | EncryptionKey
  | DecryptionKey
  | SessionKey
  | EphemeralKey
  | DeviceKey
  | DriverKey
  | FirmwareKey
  | BootKey
  | AuditSigningKey
  | ClusterGovernanceKey
  | ToolingBoundaryKey
  | HostServiceKey
```

Each class has different:

```text
scope
lifetime
usage policy
rotation rule
revocation rule
audit requirement
commit profile
failure response
```

Examples:

#### Root Trust Key

```text
type = root
scope = boot / trust-anchor verification
rotation = forbidden or strictly controlled
storage = immutable or high-assurance KeyFrame
audit = durable on use/update
```

#### Rotatable Root

```text
type = root_versioned
scope = trust-anchor verification
rotation = Φ_rotate under Ψ_rotate
commit = Σ_trust_state
audit = durable
```

#### Intermediate Authority

```text
type = intermediate
scope = issue/verify subordinate credentials
policy = issuance and path constraints
rotation = allowed under parent trust policy
```

#### Session Key

```text
type = ephemeral/session
scope = connection/session frame
lifetime = τ-bound
commit = session state, not persistent trust anchor
audit = session establishment/use summary
```

#### Driver / Firmware Key

```text
type = driver_firmware
scope = validate driver image, firmware blob, device config
boundary = driver_sandbox/device frame
policy = driver trust policy
failure = deny load, quarantine, or fallback
```

#### Cluster Governance Key

```text
type = distributed governance
scope = node admission, quorum, cluster policy update, replicated commit
policy = quorum / membership / revocation
commit = distributed Σ state
```

#### Tooling Boundary Key

```text
type = tooling provenance / host-service boundary
scope = artifact provenance, service authentication, trace-bundle origin
policy = tooling/advisory boundary policy
commit = accepted artifact state only after validation
```

Tooling provenance may support acceptance. It does not make AI/tooling output executable authority.

### 10.6 Trust Anchor

A trust anchor is a policy-governed interpretation root.

```text
TrustAnchor = (
    anchor_id,
    key_frame,
    Ψ_verify,
    Ψ_use,
    Ψ_rotate,
    Ψ_revoke,
    scope,
    lifecycle,
    provenance,
    commit_state,
    audit_profile,
    meta
)
```

Compact form:

```text
TA = (keyFrame, Ψ_verify, Ψ_use, Ψ_rotate, Ψ_revoke)
```

Meaning:

```text
Ψ_verify:
    rules for validating signatures, certificates, images, sessions,
    node identities, firmware, or subordinate keys

Ψ_use:
    rules defining where trust may propagate

Ψ_rotate:
    rules defining when and how the trust anchor may be updated,
    replaced, versioned, or reinterpreted

Ψ_revoke:
    rules defining invalidation, quarantine, fallback, and audit behavior
```

A trust anchor is never used directly.

Its effects pass through:

```text
Ψ evaluation
Φ interpretation
Ω use authority
Χ key-frame boundary
Σ trust-state commit
```

A trust anchor is therefore not global truth. It is an interpretation root under a declared trust profile.

### 10.7 Trust State

Trust state is runtime state.

```text
TrustState = (
    anchors,
    key_frames,
    sessions,
    credential_cache,
    revocation_state,
    rotation_state,
    trust_graph,
    policy_links,
    audit_state,
    commit_chain,
    meta
)
```

Fields:

| Field | Meaning |
| ----- | ------- |
| `anchors` | active trust anchors |
| `key_frames` | contained key material and handles |
| `sessions` | committed session trust state |
| `credential_cache` | validated credential summaries, not raw trust authority |
| `revocation_state` | revoked keys, anchors, sessions, issuers |
| `rotation_state` | pending/active/retired key versions |
| `trust_graph` | relations among anchors, intermediates, sessions, nodes |
| `policy_links` | Ψ policies governing verification, use, rotation, revocation |
| `audit_state` | Θ/Σ evidence for trust operations |
| `commit_chain` | Σ history of trust-state changes |
| `meta` | epochs, τ expiries, profile, provenance |

Trust state must be versioned or epoch-based.

```text
trust_epoch
policy_epoch
key_epoch
session_epoch
revocation_epoch
```

are useful invalidation boundaries for caches, sessions, and verification decisions.

### 10.8 Key Lifecycle

A key has lifecycle state.

```text
KeyLifecycle =
    CREATED
    IMPORTED
    VALIDATED
    ACTIVE
    SUSPENDED
    ROTATING
    RETIRED
    REVOKED
    EXPIRED
    DESTROYED
    ARCHIVED
```

Lifecycle transitions:

| Transition | Operator reading |
| ---------- | ---------------- |
| create | Δ + □ + Ω + Ψ |
| import | Δ + Χ + Ψ + Σ |
| validate | Δ + Ψ + Φ |
| activate | Ω + Ψ + Σ |
| suspend | Ψ + Σ |
| rotate | Φ + Ψ + Σ |
| retire | Θ/Ψ + Σ |
| revoke | Φ + Ψ + Ω + Σ |
| expire | Θ over τ metadata + Φ + Ψ + Σ |
| destroy | Χ + Σ + Ψ |
| archive | Σ + Ψ + audit |

Lifecycle invariant:

```text
key may be used only in ACTIVE or policy-defined transitional states.
```

A key in `REVOKED`, `EXPIRED`, or `DESTROYED` state cannot authorize future trust decisions.

Historical verification may remain possible under a separate profile, but historical verification is not active authorization.

### 10.9 Key Creation and Import

Key creation:

```text
Δ classify creation request
Ω verify key-generation authority
□ create KeyFrame
Χ isolate key material as runtime projection
Ψ apply key-generation policy
∇ generate or receive material
Σ commit KeyFrame metadata and lifecycle state
Θ audit key creation
```

Key import:

```text
Δ classify imported material
Ω verify import authority
Χ place material into isolated KeyFrame
Ψ validate import policy
Φ interpret imported credential/key context
Σ commit imported key state
Θ audit import
```

Import policy may require:

```text
allowed algorithm profile
minimum length profile
issuer policy
hardware-backed origin
provenance metadata
scope constraints
non-exportability
rotation path
revocation path
audit profile
```

Key import failure may produce:

```text
DENY
Φ invalid-key trap
Χ quarantine imported material
Σ audit rejection
```

Algorithm profiles may be referenced by a runtime or deployment profile. This architecture document does not certify or mandate a cryptographic algorithm.

### 10.10 Key Use

Key use is Ω-bound and Ψ-governed.

For a principal `id`:

```text
id ▷ use(keyFrame)
```

iff:

```text
cap(use(keyFrame)) ∈ caps(id)
∧ keyFrame.scope permits use
∧ key lifecycle permits use
∧ Ψ_use permits operation
∧ Χ permits key-frame access as runtime projection
∧ □ frame transition is valid
∧ audit requirements can be satisfied
```

Key-use operation:

```text
Δ classify key and operation
Ω verify use capability
□ enter or reference key frame
Χ check key material isolation
Ψ evaluate key-use policy
Φ interpret key meaning under current context
∇ sign / verify / encrypt / decrypt / derive / attest
Σ commit resulting trust/session/audit state if required
Θ audit use
```

Key-use actions:

```text
verify signature
sign artifact
encrypt
decrypt
derive session key
validate firmware
validate boot image
validate node identity
validate policy bundle
validate audit chunk
attest runtime state
validate tooling provenance
```

Key-use invariant:

```text
key operation cannot proceed from key possession alone.
```

### 10.11 Key Extraction and Export

Key extraction/export is high-risk.

Export operation:

```text
Δ classify export request
Ω verify export capability
Χ check key-frame boundary
Ψ evaluate export policy
Φ recontextualize material if wrapping/sealing/redaction occurs
∇ export, wrap, or deny
Σ commit export record
Θ audit export
```

Export profiles:

```text
forbidden
public_only
wrapped
sealed
hardware_bound
session_bound
redacted_metadata_only
audit_only
```

Private key export should normally be forbidden or require a strongly declared export profile.

Export invariant:

```text
key material may cross boundary only through declared transfer profile.
```

Export permission is not implied by key-use permission.

### 10.12 Key Rotation

Rotation is a Φ recontextualization and Σ trust-state commit.

```text
Φ_rotate(keyFrame_old, keyFrame_new)
```

Rotation flow:

```text
Δ classify rotation request
Ω verify rotation authority
Χ verify old/new key-frame boundaries
Ψ evaluate rotation policy
Φ reinterpret trust context from old key to new key
Σ commit rotation state
Θ audit rotation
```

Rotation state:

```text
RotationState = (
    old_key,
    new_key,
    overlap_window?,
    allowed_uses_old,
    allowed_uses_new,
    migration_policy,
    rollback_policy,
    audit_profile
)
```

Rotation may support:

```text
hard cutover
overlap window
dual-signing
grace period
phased rollout
cluster quorum activation
rollback
```

Rotation invariant:

```text
after rotation commit, trust decisions must use the active key version
according to Ψ_rotate.
```

Any allowed use of the old key must be explicit.

### 10.13 Key Revocation

Revocation invalidates trust use.

```text
Φ_revoke(keyFrame)
```

Revocation flow:

```text
Δ classify revocation target
Ω verify revocation authority
Ψ evaluate revocation policy
Φ recontextualize key/trust state as revoked
Ω revoke related use capabilities if required
Χ restrict key/session boundaries if required
Σ commit revocation
Θ audit revocation
```

Revocation effects:

```text
deny future verification use
deny signing/decryption
invalidate sessions
quarantine affected principals
reject dependent credentials
require rekey
trigger fallback anchor
mark audit/compliance event
```

Revocation may target:

```text
key
trust anchor
intermediate
session
node identity
driver signing identity
firmware identity
audit signing identity
tooling boundary identity
```

Revocation invariant:

```text
revoked trust material cannot produce new local authority after
revocation commit.
```

Live uses must be handled by policy:

```text
allow current transaction to finish
abort immediately
revalidate
quarantine
rollback
expire at next Θ boundary
```

### 10.14 Expiry and Temporal Trust

Expiry is τ metadata checked in Θ order and interpreted through Φ.

```text
Φ(keyFrame, τ.now) =
    valid   if τ.now < τ.expiry(key)
    expired otherwise
```

Expiry flow:

```text
Θ orders expiry check
τ supplies expiry metadata
Ψ evaluates expiry policy
Φ recontextualizes key/session as expired
Ω removes effective authority if required
Σ commits expiry/revocation state
Θ audits expiry
```

Expiry targets:

```text
session key
certificate
delegated capability
temporary trust anchor
driver update key
cluster maintenance key
AI/tooling session credential
```

Expiry invariant:

```text
expired key material may remain archived, but it cannot produce active
trust unless policy defines a historical verification mode.
```

Historical verification must be separate from active authorization.

### 10.15 Boot-Time Trust Anchor Integration

Boot trust is operator-complete.

Boot flow:

```text
1. Δ distinguish boot artifact, signature type, image type, policy source
2. □ select boot frame
3. Χ isolate boot loader and trust-anchor frame
4. Ω restrict who may modify boot trust anchors
5. Ψ verify boot policy and image signature
6. Φ recontextualize into trusted, fallback, recovery, or failed boot context
7. Σ commit boot trust state
8. Θ audit boot stages
```

Compact form:

```text
Load root KeyFrames
→ Ψ_verify(kernel_image.signature)
→ Φ(trusted | untrusted | fallback | recovery)
→ Σ(boot_trust_state)
```

Boot outcomes:

```text
trusted_boot
recovery_boot
quarantine_boot
fallback_boot
halt
```

Boot invariant:

```text
user execution, device binding, and policy activation beyond the minimal
boot set may occur only after mandatory boot trust state is committed.
```

Boot trust does not prove the entire runtime is correct. It establishes that boot artifacts satisfied declared trust policy under the boot profile.

### 10.16 Kernel Trust Anchor Integration

The kernel uses trust anchors for:

```text
boot image validation
driver loading
firmware validation
policy bundle validation
module loading
audit-log signing
node/session identity
secure update
debug/tooling admission
```

Kernel trust operation:

```text
Δ classify artifact
Ω verify verification authority
Χ access trust/key frame
Ψ evaluate trust policy
Φ interpret artifact trust status
Σ commit load/admission/trust state
Θ audit decision
```

Kernel trust failure responses:

```text
deny load
fallback
quarantine artifact
quarantine device/driver
enter recovery mode
halt on critical invariant
audit denial
```

Kernel invariant:

```text
trusted artifact status is policy-bound and commit-bound.
```

No artifact becomes trusted merely because it is signed.

The signature must validate under the active trust policy, scope, lifecycle state, boundary context, and runtime profile.

### 10.17 Driver and Firmware Trust

Drivers and firmware require explicit trust paths.

Driver trust state:

```text
DriverTrust = (
    driver_image,
    signer,
    trust_anchor,
    driver_policy,
    device_class,
    capability_profile,
    isolation_profile,
    audit_profile,
    commit_state
)
```

Driver load:

```text
Δ classify driver image and device class
Ω verify driver-load authority
Χ isolate driver frame and trust-anchor frame
Ψ verify signature/trust/class policy
Φ interpret driver trust level
Ω assign driver capabilities
Χ create driver isolation domain
Σ commit driver-load trust state
Θ audit load
```

Firmware validation:

```text
Δ classify firmware blob
Ψ verify firmware signature/version/device policy
Φ interpret as valid, stale, rejected, or quarantine
Σ commit firmware admission or denial
```

Driver trust failure:

```text
deny load
quarantine driver/device
fallback to previous version
require manual/admin Ψ decision
halt if critical device/invariant
```

Driver trust invariant:

```text
driver authority requires both trust validation and capability/isolation
assignment.
```

Signature validity alone does not grant unrestricted kernel authority.

### 10.18 Network Session Trust

Network trust maps remote credentials into local session state.

Session establishment:

```text
Δ classify remote credential, protocol, endpoint
Ω verify local authority to establish session
Χ establish session boundary
Ψ_session evaluate acceptable credentials, ciphers, freshness, policy
Φ_negotiate map remote identity and protocol context
Ω assign local session capabilities
Σ_session commit session keys, routing permissions, identity links
Θ audit handshake
```

Compact form:

```text
Φ(peerKey) ∧ Ψ(policy) ⇒ Σ(sessionState)
```

Session trust state:

```text
SessionTrust = (
    session_id,
    local_principal,
    remote_principal,
    credential,
    trust_anchor,
    negotiated_profile,
    session_keys,
    capabilities,
    boundary,
    expiry,
    revocation_state,
    commit_state
)
```

Network trust invariant:

```text
remote identity is mapped before local authority is granted.
```

A remote certificate or key may support mapping.

It does not directly become local principal authority.

### 10.19 Distributed Trust Anchors

Distributed systems require synchronized or policy-related trust anchor state.

Distributed trust state:

```text
DistributedTrustState = (
    node_id,
    cluster_id,
    local_anchor_set,
    remote_anchor_summaries,
    quorum_policy,
    revocation_state,
    rotation_state,
    commit_refs,
    audit_refs,
    meta
)
```

Cluster trust flow:

```text
1. each node maintains Σ-committed trust anchor set
2. nodes exchange Θ-ordered summaries or signed hashes
3. Φ resolves divergent trust interpretations
4. Ψ enforces quorum / majority / authority / federation policy
5. Σ commits unified or locally accepted trust state
6. Θ/Σ audit distributed trust update
```

Distributed trust operations:

```text
node admission
node revocation
cluster key rotation
quorum-key update
remote policy-bundle validation
cross-node audit validation
distributed commit authorization
```

Distributed trust invariant:

```text
no node receives cluster authority solely by presenting a credential;
cluster policy must map, constrain, and commit that authority.
```

Full distributed semantics belong to `07_distributed_systems.md`; this section defines the runtime-security trust-anchor model.

### 10.20 Trust Anchor Policies

Trust-anchor policy types:

```text
Ψ_verify
Ψ_use
Ψ_rotate
Ψ_revoke
Ψ_expire
Ψ_export
Ψ_import
Ψ_delegate
Ψ_audit
Ψ_recovery
Ψ_distributed
```

Examples:

#### Verification Policy

```text
Ψ_verify_driver:
    driver image valid iff signature verifies under DriverRoot
    ∧ device class matches signer scope
    ∧ key not revoked
    ∧ image version allowed
```

#### Use Policy

```text
Ψ_use_root:
    root key may verify boot and policy bundles only
    root key may not sign session credentials
```

#### Rotation Policy

```text
Ψ_rotate_cluster_root:
    rotation requires quorum Q
    ∧ new key signed by threshold authority
    ∧ old key not compromised or compromise path declared
    ∧ audit commit durable before activation
```

#### Revocation Policy

```text
Ψ_revoke_driver_signer:
    revoked signer invalidates future driver loads
    live drivers signed by signer enter review or quarantine profile
```

#### Export Policy

```text
Ψ_export_private:
    private key export forbidden except sealed hardware backup profile
```

#### Audit Policy

```text
Ψ_audit_key_use:
    all root, trust-anchor, driver-signing, audit-signing key uses require durable audit
```

Policy invariant:

```text
trust-anchor effects always pass through Ψ evaluation.
```

### 10.21 Trust Anchor Hooks

Key and trust management uses runtime hooks.

#### Key Use Hook

```text
H_key_use(actor, keyFrame, operation)
```

Flow:

```text
Δ classify key operation
Ω check use capability
Χ check KeyFrame boundary
Ψ evaluate Ψ_use
Φ interpret key context
∇ perform cryptographic operation
Σ commit result/trust state if required
Θ audit use
```

#### Trust Verification Hook

```text
H_trust_verify(artifact, credential, anchor)
```

Flow:

```text
Δ classify artifact and credential
Ψ evaluate verification policy
Φ interpret credential result
Σ commit admission/denial if required
Θ audit decision
```

#### Rotation Hook

```text
H_key_rotate(old_key, new_key)
```

Flow:

```text
Ω check rotation authority
Ψ evaluate Ψ_rotate
Φ recontextualize trust state
Σ commit rotation
Θ audit rotation
```

#### Revocation Hook

```text
H_key_revoke(key_or_anchor)
```

Flow:

```text
Ψ evaluate revocation policy
Φ mark trust context revoked
Ω remove related authority if required
Σ commit revocation
Θ audit revocation
```

#### Session Hook

```text
H_session_establish(peerCredential)
```

Flow:

```text
Δ classify peer credential
Ψ evaluate session trust policy
Φ map remote identity
Ω assign local session capability
Σ commit session
Θ audit handshake
```

#### Tooling Provenance Hook

```text
H_tooling_artifact_provenance(artifact, credential)
```

Flow:

```text
Δ classify tooling artifact and credential
Ψ evaluate tooling provenance policy
Φ interpret artifact origin
Ω assign advisory or acceptance capability if allowed
Χ preserve tooling/runtime boundary
Σ commit accepted artifact only after validation
Θ audit provenance decision
```

### 10.22 Trust Graph

Trust anchors form a trust graph.

```text
G_trust = (K, E)
```

where:

```text
K = key frames / anchors / credentials / sessions / principals
E = verification, delegation, issuance, mapping, rotation, revocation relations
```

Edge types:

```text
verifies
issues
delegates
rotates_to
revokes
maps_to_principal
establishes_session
signs_artifact
admits_node
commits_policy
supports_tooling_provenance
```

Trust graph edge:

```text
TrustEdge = (
    source,
    target,
    relation,
    policy,
    scope,
    validity,
    commit_state,
    audit_ref
)
```

Trust graph invariant:

```text
no trust edge is active without policy validity and commit state.
```

Trust graph analysis supports:

```text
revocation impact
rotation lineage
session provenance
driver signer lineage
policy bundle trust
distributed node admission
audit chain verification
tooling artifact provenance
```

### 10.23 Trust Caches and Epochs

Trust verification may be cached.

Trust cache key:

```text
TrustCacheKey = (
    credential_id,
    anchor_id,
    policy_epoch,
    trust_epoch,
    revocation_epoch,
    key_epoch,
    τ_window,
    scope
)
```

Cache validity requires:

```text
policy_epoch unchanged
trust_epoch unchanged
revocation_epoch unchanged
key lifecycle unchanged
scope unchanged
expiry not reached
runtime profile unchanged
```

Invalidation triggers:

```text
key revocation
anchor rotation
policy update
session expiry
trust graph change
node revocation
driver signer revocation
audit policy update
runtime profile change
tooling provenance policy change
```

Trust cache invariant:

```text
cached trust decision cannot outlive the policy, key, revocation, expiry,
scope, runtime profile, or trust epoch on which it depends.
```

No cache may bypass Ω, Χ, Ψ, Φ, or Σ obligations.

### 10.24 Key Storage and Commit

Key installation, removal, rotation, revocation, and trust-state update are finalized through Σ.

```text
Σ(keyFrame, Ψ_state)
```

Commit produces:

```text
durable trust configuration
trust-state epoch
optional trust-anchor hash
binding to audit logs
boot or runtime reproducibility
cluster synchronization reference
```

Key-state commit artifact:

```text
TrustCommit = (
    commit_id,
    operation,
    key_or_anchor,
    old_state,
    new_state,
    policy_snapshot,
    actor,
    audit_ref,
    previous_commit?,
    hash?,
    runtime_profile,
    meta
)
```

Commit invariant:

```text
key material may exist in memory, but it does not become active trust
state until committed under policy.
```

Trust commit evidence supports runtime conformance review. It does not prove cryptographic strength or PMS Base validity.

### 10.25 Key Storage Backends

PMS-STACK does not require one concrete backend.

Possible backends:

```text
kernel memory KeyFrame
secure enclave
hardware security module
sealed filesystem store
TPM-like device
network key service
distributed key store
host-service key store
simulation key store
test fixture key store
```

Backend profile must declare:

```text
isolation guarantees
export behavior
failure behavior
audit behavior
commit profile
rollback behavior
trust assumptions
runtime profile
unsupported operations
```

Backend boundary rule:

```text
backend behavior is represented through □/Χ/Ω/Ψ/Φ/Σ profiles.
```

A host key service does not automatically become PMS-native trust.

It crosses a host/service boundary and must remain explicit as such.

### 10.26 Audit and Compliance for Keys

Key and trust operations are audit-relevant.

Audited events:

```text
key creation
key import
key export
key use
signature verification
signing
decryption
session establishment
trust-anchor installation
trust-anchor rotation
trust-anchor revocation
policy-bundle validation
driver/firmware validation
node admission
trust failure
key destruction
tooling provenance verification
```

Trust audit record:

```text
TrustAuditRecord = (
    event_id,
    order,
    actor,
    operation,
    key_or_anchor,
    key_class,
    policy,
    decision,
    trust_context,
    boundary,
    lifecycle_state,
    commit_id?,
    credential_summary?,
    session_id?,
    node_id?,
    runtime_profile,
    meta
)
```

Compliance checks:

```text
no key use without Ω authority
no key-frame access without Χ boundary validity
no trust decision without Ψ policy
no credential-derived authority without Φ mapping
no active trust state without Σ commit
no rotation without audit
no revocation without trust-state update
no expired key used for active authority
no private key export without declared profile
no tooling-provenance result treated as execution authority without validation
```

Audit records are runtime-security evidence artifacts.

They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 10.27 Failure and Compromise Handling

Key/trust failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown key | Δ / Λ |
| malformed credential | Δ / Φ |
| invalid signature | Ψ / Φ |
| missing trust anchor | Λ / Ψ |
| revoked key | Ψ / Φ / Σ |
| expired key | Θ / Φ / Ψ |
| key-frame access denied | Ω / Χ / Ψ |
| key export denied | Ω / Χ / Ψ |
| rotation conflict | Φ / Ψ |
| trust-state commit failure | Σ / Φ |
| audit required but unavailable | Σ / Ψ / Φ |
| distributed trust divergence | Φ / Ψ / Σ |
| suspected compromise | Ψ / Φ / Χ / Ω / Σ |
| tooling provenance mismatch | Δ / Ψ / Φ |
| host key service unavailable | Λ / Φ / Ψ |

Compromise response may include:

```text
revoke key
quarantine affected session/node/driver
rotate anchor
deny future verification
invalidate cache
force revalidation
fallback to previous anchor
halt critical boot path
commit audit incident
restrict tooling boundary
```

Compromise handling flow:

```text
Δ classify compromise signal
Ψ evaluate compromise policy
Φ recontextualize trust state
Ω revoke related authority
Χ quarantine affected domains if required
Σ commit compromise response
Θ audit response
```

A successful rejection or quarantine evidences a specific runtime response under a declared profile. It is not a universal proof that all compromise variants are blocked.

### 10.28 Recovery and Fallback

Trust recovery must be policy-defined.

Recovery paths:

```text
fallback trust anchor
recovery boot
previous key version
quorum-approved rekey
manual/admin policy decision
offline validation
restricted network mode
driver quarantine and rollback
session rekey
node re-admission
tooling boundary reset
```

Recovery flow:

```text
Φ enter recovery context
Ψ evaluate recovery policy
Ω restrict authority
Χ restrict boundary
Σ commit recovery state
Θ audit recovery
```

Recovery invariant:

```text
recovery cannot silently weaken trust policy.
```

A fallback key, recovery mode, manual decision path, or restricted profile must be explicitly governed.

### 10.29 Tooling and AI Trust Boundaries

Tooling may use credentials or signatures for artifact provenance, but tooling output is not runtime authority by default.

Tooling trust flow:

```text
Δ classify tooling artifact
Ψ verify provenance policy
Φ interpret artifact source
Ω assign allowed tooling capability
Χ keep tooling boundary explicit
Σ commit accepted artifact only after validation
```

AI/tooling boundary rule:

```text
AI proposes.
Host validates.
Runtime accepts only policy-valid artifacts.
Trust anchors may verify provenance.
They do not make AI output executable authority.
```

AI/tooling may:

```text
propose PMS-IR
summarize traces
explain diagnostics
suggest missing policies
suggest scenarios
draft test fixtures
provide provenance-bearing advisory artifacts
```

AI/tooling may not:

```text
authorize execution
define semantics
replace policy evaluation
replace verification
grant capabilities
commit runtime state
serve as trusted executable code
serve as compiler authority
serve as verification evidence
serve as runtime policy authority
validate PMS Base
```

Tooling trust invariant:

```text
artifact provenance may support acceptance, but validation and policy
remain authoritative.
```

A signature on an AI/tooling artifact may verify origin under a profile. It does not convert the artifact into trusted executable code.

### 10.30 Verification and Model Checking

Key/trust management can be checked.

Static checks:

```text
key scope valid
policy references valid
rotation path declared
revocation path declared
audit profile present
export profile declared
trust-anchor lifecycle valid
runtime backend profile supported
tooling provenance boundary declared
```

Runtime checks:

```text
key lifecycle active
capability present
key-frame boundary valid
policy permits use
expiry valid
revocation state valid
commit state valid
audit emitted if required
tooling artifact validated before acceptance
```

Model-checkable properties:

```text
no active trust decision without Ψ_verify
no local session authority before Φ identity mapping
no key use after revocation commit
no expired session key authorizes new operation
no trust-anchor rotation activates without Σ commit
no driver load proceeds after failed trust verification
no distributed node commits cluster action without admitted node role
no AI/tooling artifact executes solely because provenance verifies
```

Trace conformance properties:

```text
every key-use trace includes Ω, Χ, Ψ, Φ, and audit where required
every trust-anchor update includes Σ trust-state commit
every session establishment includes credential classification and identity mapping
every tooling-derived artifact acceptance includes validation and policy acceptance
```

Verification boundary:

```text
verification establishes stated properties under stated model, profile,
assumptions, and artifact scope.

It does not validate PMS Base.
```

Tests check.

Traces record.

Validators accept or reject under profile.

Model checking checks stated properties under a model.

Proof artifacts prove stated properties under formal assumptions.

### 10.31 Trace and Evidence Convention

A concrete key/trust-anchor execution produces:

```text
trace_runtime(runtime, trust_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible key/trust-anchor executions under a declared profile is:

```text
Trace_runtime(runtime, trust_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared key/trust-anchor profile.

Trace evidence may show:

```text
key classification
key-frame access
policy decision
credential interpretation
trust-state commit
rotation/revocation event
session establishment
driver/firmware admission
tooling provenance handling
```

Trace evidence records observed behavior.

It does not prove all possible behavior unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

Golden fixtures stabilize regression expectations. They do not prove complete trust correctness or validate PMS Base.

### 10.32 PMS-RUST Evidence Relation

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

PMS-RUST-style artifacts are relevant when they provide bounded executable slices such as:

```text
operator-tagged trace output
fail-closed validation paths
service-boundary discipline
JSONL audit events
golden fixtures
AI proposal gating
runtime acceptance gates
bounded chi_enter / chi_exit discipline
```

A future PMS-RUST trust slice could demonstrate:

```text
KeyFrame representation
trust-state epoching
policy-checked artifact admission
signature-result event modeling
trust audit records
acceptance-gate fixtures
revocation/expiry test fixtures
```

Correct relation:

```text
Key/trust-anchor specification
    defines runtime-security obligations.

PMS-RUST bounded artifacts
    may demonstrate executable slices of acceptance, rejection,
    traceability, policy gating, service-boundary discipline, and audit
    representation.
```

This strengthens the implementation-artifact claim for declared slices.

It does not validate PMS Base, complete runtime security, equal a complete cryptographic subsystem, certify cryptographic strength, prove deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, or make tests/traces proofs.

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where an active boundary context is required before exit.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 10.33 Claim Boundary

The PMS-STACK key/trust-anchor model claims:

```text
keys, credentials, trust anchors, sessions, boot trust, driver trust,
firmware trust, network trust, distributed trust, tooling provenance,
and audit-signing trust can be represented as operator-governed
runtime-security state: □-framed, Χ-bounded as implementation-layer
isolation projection, Ω-use-bound, Ψ-policy-constrained,
Φ-interpreted, Θ-auditable, and Σ-committed.
```

It does not claim:

```text
cryptographic algorithms are specified here
cryptographic strength is certified here
all implementations are secure
all key stores are equivalent
all host key services are PMS-native
signatures alone grant authority
trust anchors prove runtime correctness
boot trust proves full system correctness
audit signatures prove all behavior
distributed trust is solved without distributed policy
tooling provenance makes AI output executable authority
tests or traces prove complete security
implementation artifacts validate PMS Base
```

The model is strong because it is explicit: trust has structure, lifecycle, policy, boundary, commit, and audit obligations.

### 10.34 Key and Trust Anchor Invariants

Runtime security maintains the following key/trust invariants.

```text
I1: every key or credential-bearing object is Δ-classified before use

I2: every key material object lives in a □ KeyFrame or declared backend profile

I3: private or sensitive key material is Χ-isolated as an implementation-layer
    boundary projection

I4: every key use is Ω-authorized

I5: every trust decision is Ψ-policy-governed

I6: every credential interpretation is Φ-mediated

I7: every active trust state is Σ-committed

I8: every trust-anchor installation, update, rotation, revocation, and deletion
    is policy-governed and auditable where required

I9: every key lifecycle state is explicit

I10: revoked keys cannot create new active trust after revocation commit

I11: expired keys cannot create new active trust outside historical-verification policy

I12: key export requires explicit Ω/Χ/Ψ transfer profile

I13: session authority requires committed session trust state

I14: remote credentials are mapped to local principals before local authority exists

I15: boot trust state is committed before non-minimal runtime exposure

I16: driver/firmware trust validation precedes driver/device authority assignment

I17: distributed trust-anchor changes declare quorum, federation, or synchronization policy

I18: trust caches invalidate on key, policy, revocation, expiry, scope, runtime profile,
     or trust-epoch change

I19: every key/trust audit-required event is Θ-ordered and Σ-committed where
     durable evidence is required

I20: tooling provenance may support acceptance but may not replace host validation,
     policy evaluation, runtime acceptance, or execution authority

I21: trust evidence strengthens runtime-security implementation claims and does not
     function as PMS Base validation

I22: PMS-RUST-style artifacts may evidence bounded key/trust slices; they do not
     complete trust-anchor management or validate PMS Base
```

### 10.35 Architectural Consequence

The consequence is:

```text
PMS-STACK key and trust-anchor management is not a cryptographic side
module. It is the runtime-security architecture by which credentials,
keys, sessions, boot images, drivers, firmware, network peers,
distributed nodes, policy bundles, audit artifacts, host services, and
tooling artifacts become interpretable, constrained, usable, revocable,
auditable, and committable.
```

The trust layer binds:

```text
Δ classification
□ key frames
Χ key isolation as runtime projection
Ω key-use authority
Ψ trust policy
Φ credential interpretation, rotation, revocation, recovery
Θ lifecycle and audit ordering
Σ committed trust state
```

into one trust-state discipline.

This gives PMS-STACK a uniform trust architecture across:

```text
boot
kernel
drivers
devices
firmware
runtime services
PMSL/PMS-IR tooling
network sessions
distributed nodes
audit logs
policy bundles
host services
AI/tooling boundaries
```

Trust becomes real because it is operator-governed, not because a key exists.

### 10.36 Key and Trust Anchor Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK key and trust-anchor management model specifies
implementation-layer runtime-security trust architecture: key frames,
key classes, trust anchors, trust state, key lifecycle, key creation and
import, key use, key export, rotation, revocation, expiry, boot-time
trust, kernel trust, driver/firmware trust, network-session trust,
distributed trust anchors, trust-anchor policies, trust hooks, trust
graphs, trust caches and epochs, storage and commit, backend profiles,
audit/compliance for keys, failure and compromise handling, recovery and
fallback, tooling/AI trust boundaries, verification, trace/evidence
conventions, PMS-RUST evidence boundaries, key/trust invariants, and
architectural consequences.

This is a runtime-security key / trust-anchor architecture claim.

It does not specify mandatory cryptographic algorithms, certify
cryptographic strength, complete a cryptographic subsystem, complete
deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete
distributed runtime, provide legal identity proof, provide forensic
certainty, define moral authority, define social trust, grant AI/tooling
authority, prove all trust behavior, or validate PMS Base.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection paths, JSONL traces, golden fixtures, vFS/service boundaries,
bounded isolation-exit discipline, service-boundary separation, and AI
proposal gating. It does not complete key/trust-anchor management and
does not validate PMS Base.
```

---

## 11. Network Security Integration

Network security integration is the runtime-security layer that extends PMS-STACK identity, capability, boundary, policy, trust-anchor, audit, resource, absence, and commit semantics across network sessions.

Network security in PMS-STACK is not treated as a packet filter, TLS wrapper, firewall rule, protocol library, or transport stack alone. Those may be implementation mechanisms. The architecture defines the operator structure required for secure remote interaction.

The central network-security claim is:

```text
A PMS-STACK network-security transition is valid when remote actors,
messages, sessions, credentials, routes, protocols, resources, absence
conditions, and commits are Δ-distinguished, □-framed, Ω-authorized,
Χ-bounded as implementation-layer boundary projections,
Ψ-policy-constrained, Φ-recontextualized when identity or protocol
meaning changes, Θ-ordered for session/audit semantics, Λ-typed on
absence or timeout, and Σ-committed when session, delivery, trust, audit,
or distributed state becomes stable.
```

Claim type:

```text
RUNTIME-SECURITY NETWORK-INTEGRATION ARCHITECTURE CLAIM
```

Boundary:

```text
This section defines network security at runtime-security level.

It does not define a specific wire protocol, cryptographic algorithm,
transport stack, firewall product, production network stack, consensus
algorithm, cluster policy synchronization mechanism, global commit
protocol, partition-handling semantics, deployment policy, or PMS Base
validation mechanism.

Those distributed-system semantics belong to `07_distributed_systems.md`
and to declared distributed runtime profiles.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At network-security level, Χ is projected as session boundary, route reachability, tenant boundary, container egress/ingress boundary, host-network boundary, network-device boundary, trust boundary, audit-export boundary, distributed-node boundary, quarantine boundary, and network visibility control.

Network security uses this Χ projection. It does not redefine PMS Base Χ.

Validation in this section means acceptance or rejection under a declared network-security schema, protocol profile, trust profile, route policy, hook profile, runtime profile, trace schema, evidence profile, or conformance rule.

It does not mean external validation of PMS Base.

### 11.1 Role of Network Security in PMS-STACK

Network security answers:

```text
who is the remote actor?
what credential or identity is presented?
which local principal does it map to?
which session frame contains the interaction?
which capabilities does the session receive?
which boundaries constrain reachability?
which policies govern protocol, route, trust, quota, and audit?
which messages are valid?
which effects may cross the network?
which events are absent, delayed, replayed, or denied?
which session or distributed state becomes committed?
```

A network transition is therefore not merely:

```text
send bytes
receive bytes
open socket
close socket
```

It is a structured runtime-security event:

```text
Δ remote actor / packet / message / route / credential
□ connection or session frame
Ω local network capability
Χ network/session boundary as runtime projection
Ψ protocol / trust / route / quota / audit policy
Φ remote-to-local identity mapping or protocol negotiation
∇ send / receive / route / transform
Θ ordering / heartbeat / timeout / audit sequence
Λ timeout / no route / no response / no quorum
Σ delivery / session / trust / audit / distributed commit
```

Network security extends runtime security beyond the local boundary without dissolving local authority.

```text
remote identity
≠ local authority

network reachability
≠ policy permission

session establishment
≠ global trust

transport delivery
≠ application commit
```

### 11.2 Network Frames

A network connection is a frame.

```text
NetworkFrame = □(
    session_id,
    local_endpoint,
    remote_endpoint,
    local_principal,
    remote_principal?,
    protocol_profile,
    trust_state,
    capability_state,
    boundary,
    policy_set,
    resource_account,
    audit_profile,
    lifecycle,
    meta
)
```

A network frame provides the context in which remote actions become meaningful.

Inside a network frame, the runtime can determine:

```text
who is speaking
which session is active
which protocol state applies
which keys or trust anchors apply
which messages are valid
which capabilities are active
which audit profile applies
which resource limits apply
which commit semantics apply
```

A packet or message outside a valid network frame is not yet a trusted action. It is input to be classified.

```text
packet bytes
≠ remote identity
≠ local authority
≠ committed session state
```

Frame invariant:

```text
network behavior becomes runtime-security behavior only after it is
interpreted inside a declared NetworkFrame or rejected as invalid input.
```

### 11.3 Remote Principal Mapping

Remote principals are not local principals by default.

Remote principal flow:

```text
1. Δ classify remote credential / address / protocol / identity claim
2. Ψ verify trust policy, credential validity, freshness, and scope
3. Φ map remote identity into local interpretation
4. Ω assign local session capabilities
5. Χ bind the interaction to a session/network boundary
6. Σ commit local session principal
7. Θ audit the mapping
```

Remote principal form:

```text
RemotePrincipal = (
    remote_id,
    credential,
    issuer?,
    protocol_profile,
    trust_anchor?,
    claimed_role?,
    provenance,
    meta
)
```

Mapped local session principal:

```text
SessionPrincipal = (
    session_id,
    local_pid,
    remote_id,
    mapped_role,
    capabilities,
    session_frame,
    network_boundary,
    trust_state,
    policy_links,
    expiry,
    commit_state
)
```

Invariant:

```text
remote credential is classified and policy-verified before local authority exists.
```

A remote certificate, public key, token, address, or node identifier may support mapping. It does not itself grant runtime authority.

### 11.4 Network Session Establishment

Session establishment is a trust-boundary transition.

```text
SessionEstablish =
    Δ_endpoint
    ; Δ_credential
    ; Ψ_session
    ; Φ_negotiate
    ; Ω_assign_session_caps
    ; Χ_bind_session_boundary
    ; Σ_session
```

Expanded flow:

```text
Δ classify local endpoint
Δ classify remote endpoint
Δ classify protocol profile
Δ classify credential or absence of credential
Ω verify local authority to listen/connect/accept
Χ establish candidate network boundary
Ψ evaluate network, trust, route, protocol, and audit policies
Φ negotiate or map remote identity
Ω assign session capabilities
Σ commit session state
Θ audit session establishment
```

Session state:

```text
SessionState = (
    session_id,
    local_principal,
    remote_principal,
    mapped_principal,
    protocol_state,
    trust_state,
    capabilities,
    boundary,
    resource_account,
    audit_profile,
    expiry,
    commit_state
)
```

Session establishment may produce:

```text
accepted session
restricted session
anonymous session
read-only session
quarantined session
denied session
deferred session
Λ no credential / no route / timeout
Φ protocol trap / trust failure
```

Session establishment is local trust-state construction. It is not universal remote trust.

### 11.5 Network Capabilities

Network activity requires Ω capabilities.

Examples:

```text
Ω(net.listen, Endpoint("service.local:8443"))
Ω(net.accept, Listener(L))
Ω(net.connect, Endpoint("api.internal:443"))
Ω(net.send, Session(S))
Ω(net.recv, Session(S))
Ω(net.route, RouteDomain(D))
Ω(net.bind, LocalAddress(A))
Ω(net.join, Cluster(C))
Ω(net.vote, QuorumGroup(Q))
Ω(net.audit_export, Collector(C))
```

Network capability check:

```text
authorized_network_action(p, action, target, s) iff
    principal_valid(p)
    ∧ capability covers action/target
    ∧ session frame is valid
    ∧ Χ permits network/session boundary as runtime projection
    ∧ Ψ permits protocol/route/trust/quota/audit state
    ∧ runtime profile supports network operation
```

Capability examples:

```text
cap_net_connect_api =
    (∇, network, connect, target="api.internal:443")

cap_net_send_session =
    (∇, network, send, target=Session(s), constraints={rate_limit, audit})

cap_cluster_vote =
    (Σᴳ, distributed, vote, target=QuorumGroup(q))

cap_node_admit =
    (Ψᴳ, distributed, admit_node, target=Cluster(c))
```

A local process may have a socket handle and still lack the right to send, receive, route, delegate, or commit through that session.

### 11.6 Network Boundaries

A network boundary is a runtime projection of PMS Base Χ.

```text
NetworkBoundary = (
    boundary_id,
    local_domain,
    remote_domain,
    session_frame,
    protocol_profile,
    trust_profile,
    reachability,
    allowed_ops,
    transfer_profile,
    policy,
    audit_profile
)
```

Network boundary examples:

```text
local process ↔ remote service
container ↔ external network
service ↔ service mesh
node ↔ cluster
driver ↔ network device
runtime ↔ host network stack
tooling ↔ remote analyzer
audit emitter ↔ remote collector
```

Network boundary rules:

```text
no session, no stable boundary
no boundary, no local authority
no policy, no admissible crossing
no commit, no stable session/trust state
```

Boundary crossing flow:

```text
Δ classify endpoint/message
Ω verify send/receive/connect/listen capability
Χ check network/session boundary
Ψ evaluate route/protocol/trust policy
∇ perform send/receive/route
Σ commit delivery/session/audit result if required
```

Boundary invariant:

```text
network reachability is not equivalent to authorization.
```

### 11.7 Protocol Profiles

PMS-STACK does not require one protocol. It requires protocol behavior to be operator-typed.

```text
ProtocolProfile = (
    protocol_id,
    message_types,
    state_machine,
    credential_requirements,
    ordering_rules,
    absence_rules,
    error_map,
    capability_requirements,
    boundary_requirements,
    policy_requirements,
    commit_profile,
    audit_profile
)
```

A protocol profile defines:

```text
valid message classes
valid state transitions
which credentials are required
which messages can be absent or delayed
which timeouts are meaningful
which errors map to Φ
which events commit session state
which events must be audited
```

Examples:

```text
untrusted_plain_profile
authenticated_session_profile
mutual_trust_profile
cluster_membership_profile
replication_profile
audit_export_profile
host_network_profile
```

Protocol invariant:

```text
message validity is evaluated inside a protocol frame.
```

A byte sequence is not a valid message until Δ classifies it under a protocol profile.

Protocol profiles are architecture contracts. They do not imply that this document implements a production protocol stack.

### 11.8 Message Security

Network messages are structured transition objects.

```text
NetworkMessage = (
    msg_id,
    session_id,
    kind,
    sender,
    receiver,
    payload,
    metadata,
    order,
    capability_context,
    policy_context,
    commit_profile
)
```

Message validation flow:

```text
Δ classify message kind and payload shape
Ω verify sender/receiver capability
□ locate session/protocol frame
Χ check session boundary
Ψ evaluate message policy
Θ order message
Λ handle missing/late/replayed message if relevant
Φ map protocol violation or error
Σ commit delivery or state update if valid
```

Message policies may enforce:

```text
shape
size
rate
sequence
authentication
integrity
replay window
routing scope
tenant boundary
payload class
capability transfer
redaction
audit
```

Invalid messages may produce:

```text
drop
deny
Λ no valid message
Φ protocol trap
Χ session quarantine
Ω capability revocation
Σ audit
```

Message invariant:

```text
accepted message effects are valid only inside the active session,
protocol, trust, boundary, policy, and commit profile.
```

### 11.9 Send Path

A secure send path is operator-structured.

```text
send(session, message):
    Δ classify session and message
    Ω verify send capability
    □ locate NetworkFrame
    Χ check session boundary and route visibility
    Ψ evaluate protocol, route, quota, trust, and audit policies
    Θ order send event
    ∇ transmit or enqueue
    Σ commit delivery/queued/transmitted state if profile requires
    Θ/Σ audit if required
```

Send may fail through:

```text
Λ no route
Λ no buffer
Λ no peer response
Ω missing capability
Χ boundary denial
Ψ policy denial
Φ protocol/transport trap
Σ commit failure
```

A send is not necessarily a durable commit. Profiles distinguish:

```text
queued
transmitted
acknowledged
delivered
application-accepted
replicated
globally committed
```

Send-path invariant:

```text
network send cannot bypass principal, capability, frame, boundary,
policy, resource, ordering, and audit obligations.
```

### 11.10 Receive Path

A secure receive path is also operator-structured.

```text
receive(session):
    Δ classify incoming event
    □ locate NetworkFrame
    Χ check session boundary
    Ψ evaluate ingress policy
    Ω verify receiver capability
    Δ classify message kind
    Ψ evaluate protocol state
    Θ order receive event
    Λ no-message/timeout if applicable
    ∇ deliver to runtime endpoint
    Σ commit receive/delivery state if required
    Θ/Σ audit if required
```

Receive path must distinguish:

```text
no message
late message
replayed message
malformed message
unauthorized message
policy-denied message
valid message
valid but non-committed message
valid and committed message
```

These are different runtime-security outcomes.

Receive-path invariant:

```text
network input is not trusted by arrival; it becomes runtime input only
after classification, boundary, policy, capability, and protocol checks.
```

### 11.11 Route and Reachability Policy

Routing is security-relevant.

Route decision:

```text
RouteDecision = (
    source,
    target,
    route,
    domain,
    boundary,
    policy,
    trust_state,
    resource_state,
    result
)
```

Route flow:

```text
Δ classify source, target, and route
Ω verify route authority
Χ check reachability boundary
Ψ evaluate route policy
Θ order route update/event
∇ install/use route if permitted
Σ commit route state if persistent
```

Policies may enforce:

```text
allowed endpoints
blocked subnets
tenant boundaries
service mesh constraints
cluster routing zones
no egress from sandbox
no ingress to protected service
audit collector routes only
failover routes under Φ context
```

Route invariant:

```text
network reachability is a Χ/Ψ decision, not a mere table lookup.
```

Route tables are runtime-security state when they affect protected reachability.

### 11.12 Network Trust Anchors

Network trust anchors interpret credentials and sessions.

Network trust state:

```text
NetworkTrustState = (
    trust_anchors,
    accepted_issuers,
    revocation_state,
    session_keys,
    peer_identity_map,
    protocol_profile,
    policy,
    commit_state
)
```

Session trust flow:

```text
Δ classify peer credential
Ω verify local use of trust anchors
Χ check trust/key frame boundary
Ψ_session verify acceptable credentials, ciphers, freshness, issuer, revocation
Φ_negotiate map peer identity and protocol context
Σ_session commit session trust state
Θ audit handshake
```

Compact form:

```text
Φ(peerKey) ∧ Ψ(policy) ⇒ Σ(sessionState)
```

Network trust invariant:

```text
peer credential supports trust only under active Ψ_session and committed
session state.
```

A trust anchor does not create authority by existing.

A credential, key, signature, certificate, or anchor supports a trust claim only under a declared trust policy, active key/frame boundary, valid interpretation context, and committed runtime binding.

### 11.13 Session Keys

Session keys are transient trust-bound artifacts.

```text
SessionKey = (
    key_id,
    session_id,
    key_frame,
    scope,
    expiry,
    protocol_profile,
    use_policy,
    revocation_state,
    commit_state
)
```

Session key rules:

```text
lives inside KeyFrame or backend profile
bound to session boundary
expires through Θ/τ policy
used only under Ω key-use authority
interpreted under Φ protocol/session context
committed as session trust state through Σ
```

Session key use:

```text
Δ classify key and operation
Ω verify session key use
Χ check key/session boundary
Ψ evaluate key-use and session policy
Φ interpret key under protocol profile
∇ encrypt/decrypt/sign/verify/derive
Σ commit resulting session state if required
```

Session keys should not become general-purpose runtime keys.

Session-key validation means acceptance or rejection under a declared key-use, freshness, revocation, session, and runtime policy profile. It does not mean universal trust or PMS Base validation.

### 11.14 Network Policy Domains

Network security policies may cover:

```text
ingress
egress
routing
session establishment
credential requirements
protocol version
cipher/profile requirements
message shape
rate limits
resource usage
capability transfer
identity mapping
trust-anchor use
audit and redaction
quarantine
distributed node admission
cluster commit
```

Example policies:

```text
Ψ_ingress:
    service S accepts only authenticated sessions from role service_client

Ψ_egress:
    sandboxed process may connect only to broker endpoint

Ψ_session:
    remote credential must validate under anchor A and not be revoked

Ψ_protocol:
    message type UPDATE requires capability update.submit

Ψ_rate:
    session may send at most N messages per τ-window

Ψ_cap_transfer:
    network messages may not carry capabilities unless delegation policy permits

Ψ_audit:
    all cluster membership changes require durable audit

Ψ_quarantine:
    repeated malformed messages isolate session boundary
```

Network policy is runtime governance.

It is not social governance, legal adjudication, forensic judgment, or policy enforcement over humans as such.

### 11.15 Network Resource Governance

Network operations consume resources.

Resources:

```text
connection slots
receive buffers
send buffers
message queues
bandwidth
rate windows
CPU for cryptographic checks
audit volume
session table entries
route table entries
distributed protocol budget
```

Resource governance flow:

```text
Δ classify network resource event
Ω identify accountable principal/session
Θ order usage update
Σ commit accounting
Ψ evaluate quota/rate policy
Λ no-resource/no-buffer/no-slot if recoverable
Φ trap/quarantine if critical
```

Responses:

```text
allow
throttle
drop
backpressure
return Λ no-resource
revoke session capability
quarantine session
terminate connection
```

Network resource invariant:

```text
network resource consumption is attributable to principal, session,
boundary, and policy context.
```

Resource governance is runtime governance. It is not social evaluation, moral ranking, clinical classification, or person ranking.

### 11.16 Replay, Freshness, and Ordering

Network security must handle replay and ordering.

Ordering state:

```text
NetworkOrderState = (
    session_order,
    sequence_numbers?,
    nonce_state?,
    replay_window?,
    heartbeat_state?,
    τ_metadata,
    Θ_order
)
```

Replay/freshness flow:

```text
Δ classify message order/freshness metadata
Θ compare with session ordering state
Ψ evaluate replay/freshness policy
Λ represent missing/late/out-of-window events where profile defines absence
Φ protocol trap on invalid sequence
Σ commit updated ordering state if accepted
```

Freshness policies may require:

```text
monotonic sequence
nonce uniqueness
session epoch match
τ expiry window
heartbeat freshness
cluster epoch match
```

Ordering invariant:

```text
accepted message order must be valid under declared protocol profile.
```

Ordering and freshness checks are profile-bound. A deterministic test-profile property does not automatically transfer to production, distributed, or host-runtime profiles.

### 11.17 Absence, Timeout, Partition

Network systems are defined by absence as much as presence.

Network Λ cases:

```text
no route
no peer response
no credential
no message
timeout
connection refused
partition symptom
missing heartbeat
no quorum
unsupported protocol feature
```

Absence handling flow:

```text
Θ order wait/check
τ provide timeout metadata
Λ represent absence
Ψ decide retry/backoff/failover/quarantine/deny
Φ recontextualize if failure mode changes
Σ commit timeout/failover/audit state if required
```

Examples:

```text
Λ_no_route
Λ_no_response
Λ_missing_heartbeat
Λ_no_quorum
Λ_unsupported_protocol
```

Absence invariant:

```text
network absence is typed behavior, not generic failure.
```

A missing heartbeat is not the same as malicious node behavior.

A no-route result is not the same as policy denial.

A no-quorum result is not a local timeout only.

Partition handling at distributed-system level belongs to `07_distributed_systems.md`.

### 11.18 Quarantine and Session Restriction

Network quarantine tightens Χ as a runtime-security boundary projection.

Targets:

```text
session
remote principal mapping
endpoint
route
node
service
tenant boundary
protocol profile
connection pool
```

Quarantine flow:

```text
Δ classify cause
Ψ decide quarantine
Φ enter restricted session/network context
Χ tighten boundary
Ω revoke or attenuate capabilities
Σ commit quarantine state
Θ audit event
```

Triggers:

```text
repeated malformed messages
failed trust verification
credential revocation
protocol violation
rate-limit abuse
capability-smuggling attempt
invalid distributed vote
suspected node compromise
audit failure on critical session
```

Quarantine effects:

```text
drop messages
deny sends
restrict receive to control messages
force re-authentication
remove from route table
isolate node
revoke session capabilities
require manual or policy-governed release
```

Quarantine is not a moral judgment, legal verdict, forensic conclusion, or person-level sanction. It is a runtime-security boundary response.

### 11.19 Capability Transfer over Network

Capability transfer is high-risk.

Network messages may carry:

```text
handles
tokens
delegations
session capabilities
service rights
cluster roles
temporary grants
```

Transfer flow:

```text
Δ classify capability-bearing payload
Ω verify sender delegation authority
Χ check sender/receiver/session boundary
Ψ evaluate delegation and transfer policy
Φ map capability into receiver context
Ω attach attenuated capability
Σ commit delegation
Θ audit transfer
```

Transfer invariant:

```text
capability received over network is not active until locally mapped,
policy-checked, attenuated if required, and committed.
```

Capability-smuggling attempt:

```text
w_attack =
    Δ_message
    ; ∇_send(capability_payload)
    ; Σ_delivery
```

Response:

```text
Δ detects capability-bearing payload
Ω checks transfer authority
Χ checks session boundary
Ψ denies, strips, or attenuates
Φ traps/recontextualizes if required
Σ audits decision
```

Attack words describe attempted operator sequences. They do not assert that the attack succeeds.

A successful rejection shows that this specific attempted transfer was blocked under a declared profile. It is not a universal proof that all variants are blocked.

### 11.20 Network Audit

Network security events are audit-relevant.

Network audit record:

```text
NetworkAuditRecord = (
    event_id,
    order,
    local_principal,
    remote_principal?,
    mapped_principal?,
    session_id,
    endpoint,
    protocol_profile,
    boundary,
    capability,
    policy,
    trust_state,
    operation,
    decision,
    result,
    resource_delta?,
    commit_id?,
    runtime_profile,
    meta
)
```

Audited events:

```text
listen
connect
accept
credential classification
session negotiation
session commit
message send
message receive
route decision
policy denial
trust failure
capability transfer
rate-limit decision
timeout
quarantine
session close
node admission
distributed commit
AI/tooling remote-analysis request
```

Audit flow:

```text
Δ classify network event
Θ order event
Ψ apply audit/redaction policy
Χ apply audit visibility boundary
Σ commit audit record if required
```

Audit records are runtime-security evidence artifacts.

They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 11.21 Network Compliance

Network compliance checks evidence against network policies and invariants.

Inputs:

```text
Θ event stream
Σ session commits
identity mappings
role/capability state
boundary graph
policy decisions
trust-anchor state
session keys
resource accounts
quarantine records
route table history
distributed commit refs
runtime profile
```

Compliance checks:

```text
no local authority before remote identity mapping
no send without session capability
no network boundary crossing without Χ/Ψ authorization
no trusted session without Ψ_session verification
no revoked credential accepted after revocation commit
no capability transfer without delegation policy
no route use outside route policy
no cluster commit without quorum policy
no audit-required session event missing
```

Network compliance report:

```text
NetworkComplianceReport = (
    scope,
    session_range,
    policy_set,
    evidence_range,
    checked_properties,
    violations,
    missing_evidence,
    redactions,
    runtime_profile,
    limitations
)
```

Compliance means checking runtime evidence against declared policy, profile, retention, redaction, and conformance obligations.

It does not mean social governance, legal adjudication, tribunal status, forensic certainty, or universal security certification.

### 11.22 Network Hooks

Network security integrates with kernel/runtime policy hooks.

Hook points:

```text
H_net_bind
H_net_listen
H_net_accept
H_net_connect
H_net_handshake
H_net_credential_classify
H_net_session_commit
H_net_send
H_net_recv
H_net_route
H_net_rate_window
H_net_timeout
H_net_quarantine
H_net_close
H_net_distributed_vote
H_net_distributed_commit
```

Example send hook:

```text
H_net_send(session, message):
    Δ classify session/message
    Ω check send capability
    Χ check boundary
    Ψ evaluate protocol/route/quota/audit policy
    ∇ transmit/enqueue if allowed
    Σ commit delivery profile if required
```

Example handshake hook:

```text
H_net_handshake(peerCredential):
    Δ classify credential
    Ψ evaluate session trust policy
    Φ map remote identity
    Ω assign session capability
    Χ bind session boundary
    Σ commit session
```

Hook invariant:

```text
network effects that cross trust or isolation boundaries are hook-governed.
```

Network hooks specify runtime-security enforcement points.

They do not claim a completed network stack, production protocol implementation, cryptographic library, transport implementation, or distributed consensus implementation.

Distributed hooks are integration points for distributed profiles.

Their full semantics are defined by `07_distributed_systems.md` and by the declared distributed runtime profile.

### 11.23 Network Security Scenarios

Network security scenarios are executable architecture tests or conformance storyboards for network-security obligations.

They do not prove complete network security.

#### Unauthorized Remote Access

Attempt:

```text
w =
    Δ_remote_claim
    ; ∇_request_service
    ; Ω_use_service
```

Expected response:

```text
Δ classifies credential/claim
Ψ_session rejects trust or scope
Ω denies session capability
Φ maps to violation or restricted context
Σ audits denial
```

Boundary:

```text
This scenario checks one unauthorized-access attempt under a declared
profile. It does not prove that all unauthorized-access variants are
blocked.
```

#### Network Isolation Leak

Attempt:

```text
w =
    Δ_target_endpoint
    ; ∇_connect(protected_service)
    ; Χ_bypass
```

Expected response:

```text
Χ route/session boundary blocks
Ω lacks connect capability
Ψ egress/ingress policy denies
Φ network trap or Λ no-route profile
Σ audit
```

Boundary:

```text
The attack word describes attempted behavior, not successful execution.
```

#### Capability Smuggling

Attempt:

```text
w =
    Δ_message
    ; ∇_send(capability_payload)
    ; Σ_delivery
```

Expected response:

```text
Δ detects capability-bearing payload
Ψ_cap_transfer denies or requires delegation
Ω delegation check fails
Φ strips/traps
Σ audit
```

#### Replay Attempt

Attempt:

```text
w =
    Δ_old_message
    ; ∇_deliver_again
```

Expected response:

```text
Θ checks session ordering/replay window
Ψ freshness policy denies
Φ protocol trap or drop
Σ audit
```

#### Multi-Node Fake Commit

Attempt:

```text
w =
    Δ_state
    ; ∇_reportProgress(fake)
    ; Σᵍ
```

Expected response:

```text
Ψᵍ_commitQuorum fails
Σᵍ blocked
Φᵍ traps/recontexts cluster
Χᵍ restricts offending node
Σᵍ audit if required
```

Distributed markers in this scenario are boundary-facing references to `07_distributed_systems.md`.

They do not make Section 11 the distributed-system specification.

### 11.24 Integration with `07_distributed_systems.md`

This section defines network security at runtime-security level.

`07_distributed_systems.md` refines:

```text
cluster frames
node roles
global policies
quorum semantics
distributed commit
global audit
failover
replication
partition handling
node admission
cluster trust anchors
```

Boundary between documents:

```text
06_runtime_security.md:
    local runtime-security integration of network sessions,
    remote principal mapping, trust anchors, policies, audit, resources,
    route/reachability control, session quarantine, and hooks.

07_distributed_systems.md:
    architecture of multi-node PMS systems, distributed Σᵍ,
    Θᵍ ordering, Ψᵍ policies, Χᵍ boundaries, cluster behavior,
    consensus/profile semantics, partition handling, and global commit.
```

Distributed markers in this section are boundary-facing references to `07_distributed_systems.md`.

They do not make Section 11 the distributed-system specification.

The same operator discipline applies across both documents, but the claim type differs:

```text
Section 11:
    runtime-security network integration claim

07_distributed_systems.md:
    distributed-systems architecture claim
```

### 11.25 Trace and Evidence Convention

A concrete runtime-security network execution produces:

```text
trace_runtime(runtime, network_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible runtime-security network executions under a declared profile is:

```text
Trace_runtime(runtime, network_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared network-security profile.

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Audit records and trace streams record observed executions.

They do not prove all possible executions unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

Network trace evidence may show:

```text
remote identity classification
session establishment
trust-policy decision
message validation
route decision
capability-transfer rejection
timeout/absence handling
quarantine
session commit
audit commit
distributed integration marker
```

Trace evidence strengthens implementation-layer claims under declared profiles. It does not validate PMS Base.

### 11.26 PMS-RUST Evidence Relation

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

PMS-RUST v0.1 may evidence bounded network-security slices:

```text
operator-tagged trace records
service-boundary discipline
policy-gated host/service calls
JSONL audit output
validation before execution
AI proposal acceptance gates
golden fixtures for allowed/rejected flows
bounded chi_enter / chi_exit discipline where active boundary context is required
```

A future network-security slice could implement:

```text
NetworkFrame model
SessionPrincipal model
session policy validator
network audit schema
remote principal mock mapping
trust-state epoch
send/receive trace fixtures
capability-transfer rejection fixture
timeout/absence fixture
```

Correct relation:

```text
Network-security specification
    defines runtime obligations.

PMS-RUST bounded artifacts
    may demonstrate executable slices of validation, boundary discipline,
    traceability, audit, service-boundary separation, acceptance gates,
    and rejected-flow fixtures.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete PMS-STACK network security, complete distributed runtime semantics, prove deployment security, or turn traces/tests into proofs.

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where an exit requires active boundary context.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 11.27 Claim Boundary

The PMS-STACK network-security model claims:

```text
network sessions, remote principals, credentials, messages, routes,
protocol profiles, trust anchors, distributed node relations, resource
limits, absence conditions, audit events, and commit states can be
represented as operator-governed runtime-security structures.
```

It does not claim:

```text
a specific protocol is required
a specific cryptographic algorithm is specified
a completed network stack exists
a production protocol implementation exists
a cryptographic library is implemented here
transport implementation is completed
distributed consensus is solved locally
cluster policy synchronization is completed here
global commit semantics are completed here
partition handling is completed here
all network attacks are eliminated automatically
all side channels are removed
all deployments are secure by architecture alone
host network stacks are equivalent to PMS-OS networking
audit logs prove all network behavior
tests or traces validate PMS Base
PMS-RUST completes network security
```

Network security is strong because it is explicit: authority, trust, boundary, policy, absence, commit, resource, and audit obligations are visible at the session and message level.

### 11.28 Network Security Invariants

Runtime security maintains the following network-security invariants.

```text
I1: every network session has a Δ-distinguishable session id

I2: every accepted remote principal is Δ-classified before use

I3: every remote identity is Φ-mapped before local authority is assigned

I4: every network session is represented as a □ NetworkFrame

I5: every session has a Χ boundary as an implementation-layer projection

I6: every network send/receive requires Ω capability where protected

I7: every ingress/egress decision is Ψ-policy-governed

I8: every trust-based session uses Ψ_session before Σ_session

I9: every session key is KeyFrame-bound, Χ-isolated, Ω-use-bound, and Ψ-governed

I10: every accepted message is valid under its protocol profile

I11: replay/freshness/order decisions are Θ/Ψ-governed

I12: network timeouts, no-route, no-response, missing heartbeat, and no-quorum
     are Λ-typed

I13: every capability transfer over network is delegation-policy-governed and
     locally committed before use

I14: every route/reachability decision is Χ/Ψ-governed

I15: every network resource event is accountable where resource policy requires it

I16: every network quarantine tightens Χ, attenuates Ω, applies Ψ, and commits
     state through Σ

I17: every audit-required network event is Θ-ordered and Σ-committed where durable
     evidence is required

I18: every distributed/network trust transition declares its local vs global
     commit boundary

I19: no network fast path bypasses Ω, Χ, Ψ, Φ, or Σ

I20: network-security evidence strengthens implementation-layer claims and does
     not function as PMS Base validation

I21: distributed markers in network security remain boundary-facing references
     to `07_distributed_systems.md`

I22: PMS-RUST-style artifacts may evidence bounded network-security slices; they
     do not complete network security or validate PMS Base
```

### 11.29 Architectural Consequence

The consequence is:

```text
PMS-STACK network security is not a perimeter wrapper. It is the runtime
extension of identity, role, capability, isolation, policy, trust,
absence, commit, resource governance, and audit across connection frames,
sessions, remote principals, messages, routes, host boundaries, and
distributed-node interfaces.
```

Network security integrates:

```text
Δ remote/message distinction
□ connection/session frames
Ω session and network capabilities
Χ session, route, tenant, node, and trust boundaries as runtime projections
Ψ protocol, trust, route, quota, audit, and distributed policies
Φ negotiation, identity mapping, failover, protocol traps
Θ ordering, heartbeats, replay windows, audit sequence
Λ timeout, no-route, no-response, no-quorum
Σ session commit, delivery commit, trust commit, audit commit, distributed commit
```

This gives PMS-STACK a uniform security architecture for:

```text
local networking
service-to-service sessions
container egress/ingress
remote principal mapping
network trust anchors
protocol enforcement
message validation
capability transfer
resource governance
audit export
cluster membership
distributed commit integration points
node quarantine
```

Network behavior becomes secure to the extent that its session, trust, boundary, policy, commit, resource, absence, and audit obligations are explicit and enforced under the declared runtime profile.

### 11.30 Network Security Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK network-security integration model specifies
implementation-layer runtime-security architecture: NetworkFrames,
remote-principal mapping, session establishment, network capabilities,
network boundaries, protocol profiles, message validation, send/receive
paths, route/reachability policy, network trust anchors, session keys,
network policy domains, resource governance, replay/freshness/ordering,
absence/timeout/partition handling, network quarantine, capability
transfer, network audit, network compliance, network hooks, security
scenarios, distributed-systems integration boundaries, trace/evidence
conventions, PMS-RUST evidence boundaries, network-security invariants,
and architectural consequences.

This is a runtime-security network-integration architecture claim.

It does not claim a completed network stack, production protocol
implementation, completed transport implementation, completed
cryptographic library, completed distributed consensus, completed global
commit semantics, completed partition handling, universal security
certification, complete deployment security, legal authority, moral
authority, forensic certainty, trusted AI authority, proof of all network
behavior, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged traces, JSONL audit output, validation before execution,
golden fixtures for allowed/rejected flows, service-boundary discipline,
policy-gated host/service calls, bounded isolation-exit discipline, and
AI proposal acceptance gates. It does not complete network security and
does not validate PMS Base.
```

---

## 12. Failure, Absence, and Attack Handling

Failure, absence, and attack handling define how PMS-STACK runtime security behaves when expected execution cannot proceed normally.

PMS-STACK does not collapse all abnormal behavior into generic errors. It distinguishes:

```text
absence
fault
trap
policy denial
authority failure
boundary violation
commit failure
resource exhaustion
trust failure
protocol violation
attack attempt
compromise signal
quarantine condition
critical invariant failure
AI/tooling boundary violation
```

Each has an operator-typed structure and a policy-defined response.

The central failure-handling claim is:

```text
A PMS-STACK runtime handles abnormal behavior correctly when absence,
faults, denials, violations, attacks, compromise signals, and recovery
paths are represented as Δ-classified, Ω/Χ/Ψ-evaluated, Λ-typed where
an expected event is absent, Φ-recontextualized where execution context
must change, Σ-rolled back or committed where state stability is involved,
Θ-ordered for audit and timeout semantics, and Ψ-governed throughout.
```

The central attack-handling claim is:

```text
A PMS-STACK attack model is valid when attempted violations are represented
as operator words in O*, where the word describes attempted behavior, not
success, and the runtime identifies the rejection, recontextualization,
rollback, quarantine, audit, escalation, or halt point through Ω, Χ, Ψ,
Φ, Λ, Θ, and Σ.
```

Claim type:

```text
RUNTIME-SECURITY FAILURE / ABSENCE / ATTACK-HANDLING ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-STACK failure, absence, and attack handling as
implementation-layer runtime-security architecture.

It does not claim complete attack prevention, universal security
certification, forensic certainty, legal judgment, moral judgment,
person ranking, tribunal status, proof of all executions, or PMS Base
validation.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At failure/attack-handling level, Χ is projected as runtime boundary, isolation, reachability control, quarantine, containment, namespace separation, host boundary, device boundary, network/session boundary, audit visibility boundary, and trust-boundary control.

Failure and attack handling use this Χ projection. They do not redefine PMS Base Χ.

Attack words describe attempted operator sequences.

They do not assert that the attack succeeds. Runtime security identifies the failed obligation:

```text
Δ classification
Ω authority
□ frame validity
Χ boundary projection
Ψ policy
Φ recontextualization
Σ commit
Θ ordering
Λ absence handling
```

Failure and attack-handling traces evidence observed behavior under a declared runtime profile.

They do not prove complete security, eliminate all attacks, certify a deployment, or validate PMS Base.

A successful rejection shows that a specific attempted transition was blocked under a declared profile. It is not a universal proof that all variants are blocked.

Validation in this section means acceptance or rejection under a declared runtime-security failure model, attack scenario, policy, invariant, hook, runtime profile, trace schema, fixture, artifact, or conformance rule.

It does not mean external validation of PMS Base.

### 12.1 Failure Is Structured Runtime Behavior

Failure in PMS-STACK is not merely:

```text
return false
raise error
panic
crash
abort
log message
errno
exception
timeout
```

Those are possible implementation surfaces.

The runtime-security model asks:

```text
What failed?
Which operator obligation failed?
Was an expected event absent?
Was authority missing?
Was a boundary violated?
Was policy denied?
Was a frame invalid?
Was a commit invalid?
Was trust interpretation invalid?
Was this a recoverable condition?
Was this an attack attempt?
What state became committed?
What state was rolled back?
What must be audited?
```

A failure is validly handled only when its operator structure is preserved.

```text
abnormal behavior
⇒ Δ-classified
⇒ policy-governed
⇒ operator-typed response
⇒ audit/commit where required
```

### 12.2 Distinguishing Failure, Absence, and Attack

PMS-STACK distinguishes three important classes.

#### Absence

Absence is Λ.

```text
expected event/resource/response did not materialize
```

Examples:

```text
no message
no route
no resource
no credential
no quorum
timeout
empty queue
unavailable device
unsupported runtime feature
```

Absence is not automatically an attack.

#### Failure

Failure is a condition in which execution cannot continue along the current path.

Examples:

```text
invalid address
invalid frame
policy denial
capability missing
commit failure
host call failure
driver fault
trust verification failure
protocol violation
```

Failure may be recoverable or terminal.

#### Attack Attempt

An attack attempt is a structured attempted operator word that seeks to violate invariants.

Examples:

```text
Ω privilege escalation
Χ boundary bypass
Ψ policy tampering
Σ fake commit
capability smuggling
replay attack
audit tampering
driver overreach
trust-anchor compromise
distributed fake quorum
AI/tooling authority takeover
```

An attack attempt may be blocked before any harmful effect occurs.

```text
attempted word ≠ successful transition
```

### 12.3 Failure Object

A runtime failure can be represented as:

```text
FailureEvent = (
    failure_id,
    kind,
    operator_basis,
    actor,
    effective_actor?,
    target,
    frame,
    boundary?,
    role?,
    capability?,
    policy?,
    expected?,
    observed?,
    pending_commit?,
    resource_state?,
    trust_state?,
    order,
    source,
    response,
    audit_profile,
    runtime_profile,
    meta
)
```

Fields:

| Field | Meaning |
| ----- | ------- |
| `failure_id` | Δ-distinguishable failure identity |
| `kind` | absence, denial, trap, violation, attack, compromise, commit failure |
| `operator_basis` | Δ/Ω/Χ/Ψ/Λ/Φ/Σ/etc. basis |
| `actor` | principal or subject involved |
| `target` | object, frame, resource, session, policy, key, device |
| `frame` | active □ context |
| `boundary` | Χ-projected runtime boundary relation involved |
| `policy` | Ψ rule or policy set involved |
| `expected` | expected event/resource/condition |
| `observed` | observed invalid/missing condition |
| `pending_commit` | staged Σ state if any |
| `response` | deny, trap, rollback, quarantine, halt, etc. |
| `audit_profile` | Θ/Σ evidence requirement |
| `runtime_profile` | profile under which the response is interpreted |

A failure object is not necessarily exposed to application code. It is the architectural runtime-security representation.

### 12.4 Failure Classification

Failure classification is Δ.

The runtime must distinguish failure class before choosing response.

```text
Δ_failure : observed abnormal state → FailureKind
```

Failure kinds:

```text
ABSENCE
TIMEOUT
NO_RESOURCE
NO_ROUTE
NO_QUORUM
INVALID_FRAME
INVALID_ADDRESS
MISSING_CAPABILITY
POLICY_DENIAL
BOUNDARY_VIOLATION
ROLE_ESCALATION_ATTEMPT
TRUST_FAILURE
KEY_REVOKED
KEY_EXPIRED
PROTOCOL_VIOLATION
RESOURCE_QUOTA_VIOLATION
COMMIT_FAILURE
ROLLBACK_REQUIRED
AUDIT_FAILURE
DRIVER_FAULT
DEVICE_FAULT
HOST_FAILURE
FFI_FAILURE
TOOLING_BOUNDARY_VIOLATION
ATTACK_ATTEMPT
COMPROMISE_SIGNAL
CRITICAL_INVARIANT_FAILURE
```

Classification invariant:

```text
failure_response(f) depends on Δ_failure(f)
```

A runtime should not treat all abnormal behavior as the same error.

### 12.5 Absence Model — Λ

Λ represents non-event, missing resource, missing response, or timeout.

Absence form:

```text
Absence = (
    expected,
    context,
    deadline?,
    wait_state?,
    resource?,
    policy,
    response
)
```

Examples:

```text
Λ_no_message(channel)
Λ_timeout(wait_context, τ.deadline)
Λ_no_resource(resource_class)
Λ_no_route(endpoint)
Λ_no_credential(peer)
Λ_no_quorum(cluster)
Λ_unsupported_feature(profile, feature)
```

Absence flow:

```text
Δ classify expected event/resource
Θ order wait/check
τ provide deadline/window metadata if relevant
Λ represent non-materialization
Ψ decide response
Φ recontextualize if needed
Σ commit timeout/resource/audit state if required
```

Absence invariant:

```text
Λ_absent(x) means no successful Σ for expected event x occurred.
```

Absence must not be confused with successful zero-value result, policy denial, or attack.

### 12.6 Timeout Handling

Timeout is a Θ/τ/Λ pattern.

```text
Λ_timeout := (τ.now ≥ τ.deadline) ∧ expected_event_absent
```

Timeout flow:

```text
Θ wait or poll
τ compare deadline/window
Λ emit timeout absence
Ψ apply timeout policy
Φ recontextualize if timeout requires failure path
Σ commit timeout/audit state if required
```

Timeout responses:

```text
return timeout
retry
backoff
defer
throttle
trigger failover
quarantine subject
revoke capability
terminate operation
halt if critical invariant
```

Timeout invariant:

```text
timeout requires prior expectation or wait context.
```

An illegal timeout is a timeout without a valid expected event or deadline context.

### 12.7 No-Resource Handling

No-resource is Λ when a resource cannot be provided.

Examples:

```text
memory unavailable
IPC queue full
storage quota exhausted
network buffer unavailable
device queue full
audit log unavailable
host service unavailable
```

No-resource flow:

```text
Δ classify resource request
Ω verify actor authority
Ψ check quota and policy
∇ attempt or stage resource acquisition if allowed
Λ resource-not-available if not satisfiable
Φ quota fault / OOM / throttling / kill / recovery if policy requires
Σ commit accounting/audit state if needed
```

Responses:

```text
return no-resource
block
retry
throttle
deny
shed load
reclaim
kill process
quarantine subsystem
halt if critical resource invariant
```

No-resource invariant:

```text
no-resource outcome does not imply that allocation occurred.
```

### 12.8 Authority Failure — Ω

Authority failure occurs when a principal lacks required role/capability structure.

Examples:

```text
missing capability
expired capability
revoked capability
wrong role
invalid delegation
invalid impersonation
unauthorized policy mutation
unauthorized debug inspection
unauthorized key use
```

Authority failure flow:

```text
Δ classify requested action
Ω check role/capability
Ψ apply authority policy
Φ trap or recontextualize if required
Σ audit or rollback if staged effects exist
```

Possible responses:

```text
deny
return permission error
trap
strip delegated authority
revoke related capability
quarantine subject
audit
halt if kernel authority invariant compromised
```

Authority invariant:

```text
protected action cannot reach ∇ or Σ success without Ω basis.
```

### 12.9 Boundary Failure — Χ

Boundary failure occurs when an actor attempts to cross or affect an unreachable or isolated domain.

Examples:

```text
user writes kernel frame
process reads sibling process memory
container accesses host namespace
driver DMA into unauthorized frame
module exports internal mutable state
host call crosses undeclared FFI boundary
audit export bypasses redaction boundary
network session bypasses identity mapping
```

Boundary failure flow:

```text
Δ classify source, target, and action
□ identify source and target frames
Χ evaluate boundary relation as runtime projection
Ω check crossing capability
Ψ apply boundary policy
Φ trap or recontextualize if violation
Σ rollback/audit/quarantine if required
```

Possible responses:

```text
deny
return absent/restricted target
trap
rollback partial effects
quarantine subject
tighten boundary
revoke crossing capability
audit
halt if global boundary invariant fails
```

Boundary invariant:

```text
no cross-domain effect becomes visible without declared Χ edge, bridge,
or policy-valid transfer.
```

Here `Χ edge` denotes a runtime-security boundary projection. It does not redefine PMS Base Χ.

### 12.10 Policy Failure — Ψ

Policy failure occurs when active invariants deny, conflict, fail to evaluate, or detect invalid behavior.

Policy failure kinds:

```text
DENY
CONFLICT
UNSATISFIABLE
MISSING_POLICY
POLICY_EVAL_ERROR
POLICY_WEAKENING_ATTEMPT
POLICY_TAMPERING
AUDIT_POLICY_FAILURE
TRUST_POLICY_FAILURE
COMMIT_POLICY_FAILURE
```

Policy failure flow:

```text
Δ classify operation and policy scope
Ψ evaluate policy set
Ψ resolve or detect conflict
Φ recontextualize if failure action requires it
Χ quarantine if policy demands isolation
Ω revoke/attenuate authority if required
Σ commit policy decision/audit/recovery state
```

Responses:

```text
deny
modify operation
transform through Φ
defer
quarantine
rollback
revoke authority
escalate to runtime-governance context
halt
```

Policy failure invariant:

```text
policy failure mode must be explicit.
```

Critical policy failure should normally fail closed.

### 12.11 Trap and Fault Handling — Φ

Φ handles recontextualization: trap, exception, fault, signal, recovery, compatibility, violation frame, quarantine entry, and fallback context.

Trap object:

```text
Trap = (
    trap_id,
    cause,
    source_context,
    target_context,
    actor,
    frame,
    role,
    boundary,
    policy,
    pending_commit,
    recovery_profile,
    audit_profile
)
```

Trap flow:

```text
Δ classify trap cause
Φ enter trap/recovery context
Ω set trap-handler authority
□ switch to trap frame
Χ maintain or tighten boundary
Ψ evaluate trap policy
Σ commit trap/audit/recovery state if required
Φ return, terminate, quarantine, or halt
```

Trap causes:

```text
page fault
protection fault
illegal instruction
syscall entry
policy violation
driver fault
device fault
network protocol violation
FFI error
trust failure
audit failure
commit failure
AI/tooling authority violation
```

Trap invariant:

```text
Φ(s) ⇒ Ψ_runtime(s')
```

A trap may change context. It may not break invariants or grant uncommitted authority.

### 12.12 Commit Failure and Rollback — Σ

Commit failure occurs when staged effects cannot become stable.

Examples:

```text
filesystem transaction fails
IPC delivery cannot be committed
capability grant loses authority before commit
policy activation fails validation
trust-anchor update fails
audit commit unavailable
distributed quorum fails
resource accounting commit fails
```

Commit failure flow:

```text
Δ classify pending commit
Ψ evaluate commit policy
Σ attempt commit
if invalid:
    Φ enter recovery
    Σ rollback or compensate
    Θ audit failure
    Ψ verify recovered state
```

Rollback form:

```text
Σ_rollback(staged_state)
```

Compensation form:

```text
Σ_compensate(effect, inverse_or_repair)
```

Commit failure invariant:

```text
invalid or incomplete state must not become visible as committed state.
```

### 12.13 Rollback, Compensation, and Recovery

Recovery is not outside the model.

Recovery path:

```text
violation_detected
⇒ Φ_recovery
⇒ Σ_rollback or Σ_compensate
⇒ Ψ_runtime(recovered_state)
⇒ Θ/Σ audit if required
```

Recovery actions:

```text
rollback staged write
discard partial IPC delivery
undo capability grant
restore prior policy state
revoke session
rekey trust state
reset driver
unbind device
restart service
fall back to previous version
quarantine subject
halt if recovery impossible
```

Recovery invariant:

```text
recovered state must satisfy runtime invariants.
```

A runtime may recover. It may not recover by silently weakening invariants.

### 12.14 Quarantine

Quarantine is a Χ/Ψ/Φ/Σ response.

```text
Χ_quarantine(subject)
```

Here `Χ_quarantine` denotes runtime-security boundary tightening, not a redefinition of PMS Base Χ.

Targets:

```text
process
thread
module
container
driver
device
IPC endpoint
filesystem subtree
network session
distributed node
trust anchor
host service
tooling service
AI service
```

Quarantine flow:

```text
Δ classify subject and cause
Ψ decide quarantine
Φ enter restricted context
Χ tighten or replace boundary
Ω revoke or attenuate capabilities
Σ commit quarantine state
Θ audit quarantine
```

Quarantine effects:

```text
remove from scheduler ready set
block IPC
freeze writes
deny network sends
restrict device access
revoke capabilities
redirect syscalls
force reauthentication
require review
terminate under policy
```

Quarantine invariant:

```text
quarantined subject cannot continue using pre-quarantine authority.
```

Quarantine is not a moral judgment, legal verdict, clinical classification, forensic conclusion, or person-level sanction.

It is a runtime-security isolation response to an invariant, policy, trust, failure, or attack condition.

### 12.15 Halt

Halt is a Ψ-governed critical response.

Halt may apply when:

```text
kernel invariant fails unrecoverably
trap return would violate frame/role/boundary integrity
policy engine integrity fails
trust-anchor root is corrupted
audit-required critical commit cannot be performed
driver/device fault threatens global integrity
distributed commit state cannot be made safe
rollback cannot restore invariant-valid state
```

Halt flow:

```text
Δ classify critical invariant failure
Ψ decide halt policy
Φ enter halt/recovery context if possible
Σ commit halt/audit state if possible
Θ emit terminal audit marker if possible
```

Halt invariant:

```text
halt is preferable to silent invariant violation.
```

Halt is a runtime-security response. It is not moral or legal judgment.

### 12.16 Attack Attempts as Operator Words

PMS-STACK represents attack attempts as words in `O*`.

```text
w_attack ∈ O*
```

where:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

An attack word describes attempted behavior, not successful execution.

Example:

```text
w_attack =
    Δ_target
    ; ∇_read
    ; Χ_bypass
    ; Ω_escalate
```

The security question is:

```text
At which operator obligation does this word become invalid?
```

Possible invalidation points:

```text
Δ classification rejects target
Ω denies capability
Χ blocks boundary
Ψ denies policy
Φ traps violation
Σ refuses commit
Λ represents absent route/resource/credential
Θ detects expiry/replay/timeout
```

Attack modeling is therefore structural.

It is not a declaration that the attack succeeds, nor a claim that one modeled rejection proves universal resistance.

### 12.17 Attack Scenario Template

A runtime-security attack scenario uses the following form.

```text
Scenario = (
    setup,
    attempted_word,
    rejection_point,
    expected_runtime_response,
    linked_invariants,
    audit_obligations,
    claim_boundary
)
```

#### Setup

Define:

```text
frames
principals
roles
capabilities
policies
boundaries
trust anchors
resource accounts
initial state
```

#### Attempted Word

Represent the attempted behavior:

```text
w_attack = op₁ ; op₂ ; ... ; opₙ
```

#### Rejection Point

Identify:

```text
which operator obligation fails
which policy/invariant applies
which state remains uncommitted
```

#### Expected Runtime Response

Specify:

```text
deny
Λ absence
Φ trap
Σ rollback
Χ quarantine
Ω revoke
Ψ halt/escalate
Σ audit
```

#### Linked Invariants

List relevant invariants:

```text
capability correctness
frame isolation
role monotonicity
policy integrity
commit validity
auditability
trust-state validity
```

#### Claim Boundary

State:

```text
This scenario checks one attempted transition under a declared profile.
It does not prove complete runtime security.
```

### 12.18 Unauthorized Privilege Escalation

Setup:

```text
Active frame: F_user
Current role: Ω_user
Policy: Ψ_role_monotonicity
Isolation: Χ_user-kernel as runtime boundary projection
```

Attempt:

```text
w =
    Δ_targetRole
    ; ∇_requestRole(Ω_root)
    ; Ω_elevate
```

Expected runtime behavior:

```text
Δ classifies target role
Ω_elevate checks role transition
Ψ_role_monotonicity denies direct escalation
Φ enters violation frame
Σ rolls back partial side effects if any
Θ/Σ audit records attempt
```

Result:

```text
no root role assigned
no kernel authority committed
no policy state weakened
```

Boundary:

```text
This scenario checks one privilege-escalation attempt under a declared
profile. It does not prove that all privilege-escalation variants are
blocked.
```

### 12.19 Isolation Leak

Setup:

```text
Frames:
    F_app
    F_secret

Boundary:
    Χ(F_app → F_secret) denies direct read as runtime projection

Policy:
    Ψ_cross_frame requires C_readSecret
```

Attempt:

```text
w =
    Δ_secretObj
    ; ∇_read(secretObj)
    ; Χ_bypass
```

Expected runtime behavior:

```text
Δ identifies secret object
□ identifies active frame F_app
Χ detects forbidden boundary
Ω finds no C_readSecret
Ψ denies read
Φ enters violation context
Σ rollback/audit if any staged side effect exists
```

Result:

```text
secret value does not become visible to F_app
no successful Σ read result exists
```

Boundary:

```text
The attack word describes attempted behavior, not successful execution.
```

### 12.20 Transaction Failure

Setup:

```text
Filesystem frame: F_fs
Policy: Ψ_tx atomicity
Commit: Σ final transaction integration
```

Failure word:

```text
w =
    ∇_open
    ; Δ_path
    ; ∇_write
    ; Δ_validate
    ; ∇_stage
    ; Φ_error
    ; Σ?
```

Expected runtime behavior:

```text
Φ_error enters recovery context
Ψ_tx denies final Σ
Σ_rollback reverts staged writes
Θ/Σ audit records failure
Ψ_consistency checks recovered filesystem state
```

Result:

```text
partial write does not become committed filesystem state
```

Boundary:

```text
A rejected final commit evidences behavior under the transaction policy
profile. It is not proof of all transaction behavior.
```

### 12.21 Policy Tampering / Praxeological Malware Pattern

Setup:

```text
Actor: user-frame process
Target: policy state
Policy: Ψ_policy_integrity
```

Attempt:

```text
w =
    Δ_shadowPolicy
    ; Ω_escalate?
    ; Ψ_redefine
    ; repeat
```

Expected runtime behavior:

```text
Δ classifies policy mutation attempt
Ω denies policy-management authority
Ψ_policy_integrity rejects mutation outside kernel-governed frame
Φ enters governance-violation frame
Χ restricts offender if policy requires
Σ commits audit/quarantine state
```

Result:

```text
policy set remains unchanged
attacker cannot gradually weaken invariants
```

Boundary:

```text
Policy-tampering language describes an attempted operator sequence.
It does not assert successful execution.
```

### 12.22 Capability Smuggling

Setup:

```text
Sender has message send capability
Sender does not have delegation capability
Receiver would gain authority if payload were accepted
Policy: Ψ_cap_transfer
```

Attempt:

```text
w =
    Δ_message
    ; ∇_send(capability_payload)
    ; Σ_delivery
```

Expected runtime behavior:

```text
Δ detects capability-bearing payload
Ω checks delegation authority
Χ checks sender/receiver/session boundary
Ψ_cap_transfer denies or requires attenuation
Φ strips/traps if required
Σ_delivery blocked or commits sanitized message only
Θ/Σ audit records decision
```

Result:

```text
capability is not active in receiver context unless locally policy-checked
and committed
```

Boundary:

```text
A successful rejection shows that this specific attempted capability
transfer was blocked under a declared profile. It is not a universal
proof that all capability-smuggling variants are blocked.
```

### 12.23 Replay / Freshness Attack

Setup:

```text
Network session S
Protocol profile requires fresh sequence/nonce
Policy: Ψ_freshness
```

Attempt:

```text
w =
    Δ_old_message
    ; ∇_deliver_again
    ; Σ_accept
```

Expected runtime behavior:

```text
Δ classifies message and sequence metadata
Θ checks ordering/replay window
Ψ_freshness denies replay
Φ protocol trap or drop
Σ_accept blocked
Θ/Σ audit records replay attempt if required
```

Result:

```text
old message does not produce new committed effect
```

Boundary:

```text
Replay rejection evidences one observed rejection path under a declared
protocol profile. It does not eliminate all replay variants by itself.
```

### 12.24 Resource Exhaustion / Quota Attack

Setup:

```text
Actor attempts repeated allocation/send/write
Resource policy: Ψ_quota
Resource account: RAcc_actor
```

Attempt:

```text
w =
    (Δ_resource
     ; Ω_use
     ; ∇_allocate
     ; Σ_account)*
```

Expected runtime behavior:

```text
Δ classifies resource request
Ω verifies authority
Ψ_quota checks limits
∇ performs or stages allocation if allowed
Σ commits accounting
on exhaustion:
    Λ_no_resource
    or Φ quota fault / throttling / kill / recovery
```

Policy may respond:

```text
deny
throttle
backpressure
return no-resource
downgrade priority
quarantine
terminate
audit
```

Result:

```text
resource exhaustion remains attributable and policy-governed
```

Boundary:

```text
This scenario checks one resource-exhaustion pattern under a declared
resource-accounting profile. It does not prove complete denial-of-service
resistance.
```

### 12.25 Driver Overreach

Setup:

```text
Driver D
Assigned device frame: DeviceFrame(dev0)
Allowed MMIO region: R0
Policy: Ψ_driver
```

Attempt:

```text
w =
    Δ_mmio_region(R_bad)
    ; ∇_write(R_bad)
```

Expected runtime behavior:

```text
Δ classifies MMIO target
□ identifies target frame
Ω checks driver MMIO capability
Χ blocks unassigned device boundary
Ψ_driver denies
Φ enters driver fault context
Χ quarantines driver/device if policy requires
Σ commits cleanup/audit state
```

Result:

```text
driver does not mutate unauthorized device/kernel memory
```

Boundary:

```text
This scenario checks one driver-overreach attempt. It does not certify
hardware behavior or prove complete driver isolation.
```

### 12.26 Trust Anchor Compromise Signal

Setup:

```text
Trust anchor TA
KeyFrame K
Policy: Ψ_revoke / Ψ_rotate
```

Signal:

```text
w =
    Δ_compromise_signal
    ; Ψ_revoke?
    ; Φ_recontextualize_trust
```

Expected runtime behavior:

```text
Δ classifies compromise signal
Ψ evaluates revocation/rotation policy
Φ recontextualizes trust state
Ω revokes related key-use/session capabilities if required
Χ quarantines affected sessions/domains if required
Σ commits revocation/rotation state
Θ/Σ audits trust incident
```

Result:

```text
compromised trust material cannot create new active trust after revocation commit
```

Boundary:

```text
Compromise-signal handling evidences one declared response path. It does
not prove cryptographic strength, universal trust, or deployment security.
```

### 12.27 Audit Tampering

Setup:

```text
Audit log A
Policy: Ψ_audit_integrity
Actor lacks audit mutation authority
```

Attempt:

```text
w =
    Δ_audit_record
    ; ∇_delete_or_modify
    ; Σ_commit
```

Expected runtime behavior:

```text
Δ classifies audit mutation
Ω checks audit-management capability
Χ checks audit visibility/write boundary
Ψ_audit_integrity denies
Φ enters violation context
Σ_commit blocked
Σ_audit records tampering attempt if possible
```

Result:

```text
audit evidence remains protected or tamper signal is itself recorded
```

Boundary:

```text
Audit-tamper rejection supports runtime-security evidence discipline.
It does not make audit records forensic proof or PMS Base validation.
```

### 12.28 Multi-Node Fake Commit

Setup:

```text
Distributed PMS cluster
Global frame: □ᴳ
Node role: Ω_node
Policy: Ψᴳ_commitQuorum
Global commit: Σᵍ
```

Attempt:

```text
w =
    Δ_state
    ; ∇_reportProgress(fake)
    ; Σᵍ
```

Expected runtime behavior:

```text
Δ classifies proposed state
Ω checks node/global commit authority
Ψᴳ_commitQuorum checks quorum
Σᵍ denied without quorum
Φᵍ traps or recontextualizes node state
Χᵍ restricts offending node if policy requires
Σᵍ_audit records anomaly
```

Result:

```text
one node cannot unilaterally advance global committed state
```

Boundary:

```text
Distributed markers here are attack-handling references to
`07_distributed_systems.md`. They do not make this chapter the
distributed-system specification.
```

### 12.29 FFI / Host Failure

Setup:

```text
ForeignFrame F_host
Host service H
Policy: Ψ_ffi
```

Failure:

```text
host call returns error
host call blocks
host returns malformed data
host side effect cannot be mapped
```

Expected runtime behavior:

```text
Δ classify host result/error
Φ map host error into PMS trap or recovery context
Λ no-response/timeout if event absent
Ψ_ffi decides integration policy
Σ integrates result only if commit profile permits
Θ/Σ audit if required
```

Result:

```text
host behavior does not silently become PMS-native truth
```

Boundary:

```text
A host runtime may support execution. It does not become PMS-OS.
```

### 12.30 AI / Tooling Boundary Violation

Setup:

```text
AI/tooling service T
Capability: propose_ir
No capability: execute_ir
Policy: Ψ_tooling_advisory
```

Attempt:

```text
w =
    Δ_ai_output
    ; ∇_replace_runtime_program
    ; Σ_execute
```

Expected runtime behavior:

```text
Δ classifies tooling artifact
Ω detects missing execution authority
Χ checks tooling/runtime boundary
Ψ_tooling_advisory denies direct execution
Φ rejects or recontextualizes artifact as advisory
Σ_execute blocked
Θ/Σ audit records decision
```

Standard boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

An AI/tooling violation occurs when advisory output attempts to become execution authority, policy authority, verifier authority, capability grant, runtime commit, or trusted executable code without host-side acceptance.

Runtime response:

```text
Δ classify tooling artifact
Ω check tooling capability
Χ enforce tooling/host boundary
Ψ deny execution authority
Φ recontextualize as violation if needed
Σ commit audit/rejection record
```

Result:

```text
AI proposal remains advisory unless separately validated, authorized,
accepted, and committed.
```

AI output is not trusted executable code, compiler authority, verification evidence, runtime policy authority, or PMS Base validation.

### 12.31 Response Matrix

PMS-STACK responses are operator-typed.

| Condition | Primary operators | Typical responses |
| --------- | ----------------- | ----------------- |
| absence | Λ + Θ + Ψ | timeout, no-resource, retry, backoff, no-route, no-message |
| authority failure | Ω + Ψ | deny, trap, revoke, audit |
| boundary failure | Χ + Ψ + Φ | deny, trap, quarantine, audit |
| policy denial | Ψ + Φ | deny, transform, quarantine, rollback, halt |
| trap/fault | Φ + Ψ | recover, signal, kill, quarantine, halt |
| commit failure | Σ + Φ + Ψ | rollback, compensate, deny commit, audit |
| resource exhaustion | Λ + Ψ + Σ | no-resource, throttle, kill, quarantine |
| trust failure | Δ + Φ + Ψ + Σ | deny, revoke, rotate, quarantine |
| attack attempt | Δ + Ω + Χ + Ψ | reject, trap, audit, quarantine, rollback |
| AI/tooling violation | Δ + Ω + Χ + Ψ + Φ + Σ | reject, preserve advisory boundary, audit |
| critical invariant failure | Ψ + Φ + Σ | halt, quarantine, recovery path |

Response invariant:

```text
abnormal behavior must produce an operator-typed response, not silent continuation.
```

### 12.32 Fail-Closed, Fail-Open, and Profile Discipline

Failure response depends on runtime profile.

Profiles may define:

```text
FAIL_CLOSED
FAIL_OPEN
AUDIT_ONLY
SIMULATION
DEGRADED
RECOVERY
HIGH_ASSURANCE
DEBUG
PRODUCTION
```

Recommended default for critical invariants:

```text
fail closed
```

Critical cases:

```text
kernel frame access
policy mutation
trust-anchor update
driver DMA
capability grant
commit of security-critical state
audit-required critical operation
distributed quorum commit
AI/tooling execution boundary
```

Low-risk diagnostic or simulation paths may be fail-open or audit-only, but only when declared.

Profile invariant:

```text
failure mode must be explicit in the runtime profile or policy.
```

A fail-open behavior under one profile does not transfer to high-assurance, production, PMS-OS, distributed, or host-runtime profiles without explicit mapping.

### 12.33 Escalation

Escalation is a Ψ/Φ transition to a runtime-governance or recovery context.

Escalation targets:

```text
kernel security handler
policy manager
quarantine manager
trust manager
driver recovery manager
distributed governance layer
audit/compliance monitor
operator-facing report
```

Escalation flow:

```text
Δ classify escalation condition
Ψ decide escalation
Φ enter escalation context
Ω assign escalation handler authority
Σ commit escalation event
Θ audit escalation
```

Escalation is not tribunal behavior.

It is runtime routing of an invariant or policy condition to a handler with declared authority.

### 12.34 Attack Handling and Audit

Attack handling must be auditable where policy requires.

Attack audit record:

```text
AttackAuditRecord = (
    event_id,
    order,
    actor,
    target,
    attempted_word,
    rejection_point,
    failed_operator_obligation,
    policy,
    boundary,
    capability,
    response,
    commit_state,
    quarantine_state?,
    trust_state?,
    resource_state?,
    runtime_profile,
    meta
)
```

Audit questions:

```text
what was attempted?
which invariant blocked it?
what state changed?
what state did not commit?
was rollback performed?
was quarantine applied?
was authority revoked?
was trust state affected?
```

Audit invariant:

```text
security-relevant attack handling is Θ-ordered and Σ-committed where
durable evidence is required.
```

Audit records are runtime-security evidence artifacts. They support traceability, conformance checking, policy inspection, incident reconstruction, and compliance reporting under declared profiles.

They do not by themselves constitute forensic proof, legal judgment, moral authority, external validation, or PMS Base validation.

### 12.35 Attack Handling and Compliance

Compliance checks may verify that attack handling followed declared policy.

Compliance properties:

```text
all unauthorized privilege attempts were denied
all isolation leaks were blocked before committed visibility
all policy mutation attempts required kernel-governed authority
all invalid commits were rolled back
all quarantines committed boundary changes
all key revocations blocked future trust decisions
all network replays were rejected under protocol profile
all audit-required attack records exist
all AI/tooling execution attempts preserved advisory/execution boundary
```

Compliance result may be:

```text
COMPLIANT
NON_COMPLIANT
PARTIAL
UNKNOWN
EVIDENCE_MISSING
PROFILE_LIMITED
```

Compliance is a policy-based evidence check, not universal proof.

Compliance means checking runtime evidence against declared policy, profile, retention, redaction, and conformance obligations.

It does not mean social governance, legal adjudication, tribunal status, forensic certainty, or universal security certification.

### 12.36 Static Analysis and Model Checking

Failure and attack handling can be checked before runtime.

Static checks:

```text
Λ has valid expectation context
Φ trap paths preserve invariants
Σ commit paths have valid preconditions
Ω escalation paths are policy-governed
Χ exit paths are balanced and authorized
policy denial paths do not reach protected Σ
rollback paths restore invariant-valid state
audit-required failures emit audit
AI/tooling proposal paths cannot reach execution without validation
```

Model-checkable properties:

```text
no unauthorized role reaches privileged state
no cross-boundary read reaches visible result
no invalid transaction reaches Σ commit
no capability smuggling activates receiver authority
no replay message produces committed duplicate effect
no quarantined subject sends IPC
no revoked key produces active trust
no AI proposal executes without validation
```

Trace-conformance checks:

```text
failure event has operator basis
denial prevents protected effect
rollback follows failed commit
quarantine tightens Χ and attenuates Ω
audit-required response has Θ/Σ evidence
AI/tooling rejection preserves advisory/execution separation
```

Assurance boundary:

```text
tests check
traces record
validators accept or reject under profile
model checking verifies stated properties under a model/profile
proof artifacts prove stated properties under formal assumptions
```

None of these validate PMS Base.

### 12.37 Trace and Evidence Convention

A concrete failure/absence/attack-handling execution produces:

```text
trace_runtime(runtime, failure_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible failure/absence/attack-handling executions under a declared profile is:

```text
Trace_runtime(runtime, failure_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared failure/attack-handling profile.

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Failure and attack-handling traces evidence observed behavior under a declared runtime profile.

They do not prove complete security, eliminate all attacks, certify a deployment, or validate PMS Base.

A successful rejection shows that a specific attempted transition was blocked under a declared profile.

It is not a universal proof that all variants are blocked.

### 12.38 Failure Handling and PMS-RUST Evidence

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

It may evidence bounded slices of failure/attack-handling discipline:

```text
operator-tagged rejection paths
model validation failures
stateful validation failures
fail-closed behavior
post-Ψ sealing
JSONL traces for denied/invalid programs
golden fixtures for invalid operator sequences
script/service boundary rejection
AI proposal gating
bounded chi_enter / chi_exit discipline
```

Potential future fixtures:

```text
invalid_privilege_escalation
invalid_isolation_leak
invalid_sigma_no_frame
invalid_commit_after_policy_denial
invalid_capability_transfer
network_timeout_absence
revoked_key_rejected
ai_proposal_not_executable
quarantine_trace
rollback_trace
```

Correct relation:

```text
Failure/attack-handling specification
    defines runtime-security obligations.

PMS-RUST bounded artifacts
    may demonstrate executable slices of rejection, absence handling,
    stateful validation, traceability, fail-closed discipline, and
    acceptance gating.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime security, prove deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, establish universal attack resistance, or make tests/traces proofs.

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where active boundary context is required before exit.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 12.39 Claim Boundary

The PMS-STACK failure/absence/attack model claims:

```text
failure, absence, denial, traps, rollback, quarantine, trust failure,
resource exhaustion, attack attempts, AI/tooling boundary violations,
and critical invariant responses can be represented as operator-typed
runtime-security transitions.
```

It does not claim:

```text
all attacks are automatically prevented
all failures are recoverable
all side channels are eliminated
all implementations preserve all invariants
audit equals forensic proof
quarantine equals moral or legal judgment
tests or traces prove complete security
implementation artifacts validate PMS Base
PMS-RUST proves universal attack resistance
AI/tooling output is trusted executable code
```

The model is strong because abnormal behavior remains structured, enforceable, recoverable where possible, auditable where required, and bounded by explicit policies and runtime profiles.

### 12.40 Failure, Absence, and Attack Invariants

Runtime security maintains the following invariants.

```text
I1: every abnormal event is Δ-classified before response selection

I2: recoverable absence is represented as Λ, not collapsed into generic error

I3: timeout requires Θ ordering and τ deadline/window metadata

I4: no-resource outcomes do not imply successful allocation or mutation

I5: every protected authority failure is Ω/Ψ-governed

I6: every protected boundary failure is Χ/Ψ/Φ-governed

I7: every policy failure has explicit fail-open, fail-closed, audit-only,
    simulation, recovery, quarantine, or halt behavior

I8: every trap/recontextualization preserves runtime invariants

I9: every failed commit either leaves no visible state or enters rollback,
    compensation, quarantine, or halt under policy

I10: every rollback or recovery path produces invariant-valid state

I11: every quarantine tightens Χ, attenuates Ω, applies Ψ, and commits state
     through Σ

I12: every attack attempt represented as O* describes attempted behavior,
     not successful execution

I13: every successful rejection identifies the operator obligation that failed

I14: every high-value attack/failure response is Θ-ordered and Σ-auditable
     where policy requires durable evidence

I15: every trust failure prevents new active trust after revocation/denial commit

I16: every resource exhaustion response is attributable to principal, frame,
     boundary, and resource account where policy requires it

I17: every host/FFI failure is mapped through Φ or Λ before integration

I18: every AI/tooling boundary violation preserves advisory/execution separation

I19: no abnormal fast path bypasses Ω, Χ, Ψ, Φ, or Σ

I20: failure/attack-handling evidence strengthens implementation-layer claims
     and does not function as PMS Base validation

I21: PMS-RUST-style artifacts may evidence bounded failure/attack-handling
     slices; they do not complete runtime security or validate PMS Base
```

### 12.41 Architectural Consequence

The consequence is:

```text
PMS-STACK runtime security does not treat abnormal behavior as an
unstructured exception layer. Failure, absence, denial, trap, rollback,
quarantine, resource exhaustion, trust failure, attack attempt, AI/tooling
boundary violation, and halt are all operator-typed runtime transitions.
```

This gives PMS-STACK a unified handling architecture for:

```text
timeouts
missing events
no-resource conditions
policy denials
capability failures
boundary violations
trap handling
transaction failures
rollback
quarantine
resource exhaustion
driver faults
network failures
trust-anchor compromise
audit failures
FFI/host errors
AI/tooling violations
distributed fake commits
critical invariant failures
```

The runtime remains security-conformant to the extent that abnormal behavior is classified, bounded, policy-governed, recoverable where possible, auditable where required, and never silently committed outside its declared operator obligations.

### 12.42 Failure, Absence, and Attack Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK failure, absence, and attack-handling model specifies
implementation-layer runtime-security architecture: structured failure
classification, Λ absence, timeout handling, no-resource handling,
authority failure, boundary failure, policy failure, trap/fault handling,
commit failure, rollback, compensation, recovery, quarantine, halt,
attack attempts as operator words, attack scenario templates, privilege
escalation rejection, isolation-leak rejection, transaction failure,
policy-tampering rejection, capability-smuggling rejection, replay
rejection, resource-exhaustion handling, driver-overreach handling,
trust-anchor compromise response, audit-tamper response, distributed
fake-commit handling, FFI/host failure mapping, AI/tooling boundary
violation handling, response matrices, profile discipline, escalation,
audit/compliance handling, static checking, model checking,
trace/evidence conventions, PMS-RUST evidence boundaries, invariants,
and architectural consequences.

This is a runtime-security failure / absence / attack-handling
architecture claim.

It does not claim complete attack prevention, universal security
certification, complete deployment security, complete PMS-OS, complete
PMSL/PMS-IR, complete distributed runtime, forensic certainty, legal
authority, moral authority, clinical authority, tribunal status, proof of
all runtime behavior, trusted AI authority, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged rejection paths, model/stateful validation failures,
fail-closed behavior, JSONL traces for denied/invalid programs, golden
fixtures, script/service boundary rejection, bounded isolation-exit
discipline, and AI proposal gating. It does not complete failure/attack
handling and does not validate PMS Base.
```

---

## 13. Security Scenarios

Security scenarios are executable architecture tests or conformance storyboards for PMS-STACK runtime security.

They show how identity, roles, capabilities, frames, isolation, policy, hooks, invariants, audit, trust anchors, network sessions, failure handling, AI/tooling boundaries, and commit semantics work together under normal, abnormal, and adversarial conditions.

A scenario is not a proof of total security. It is a structured runtime-security case that states:

```text
initial state
attempted transition or attack word
expected operator obligation
expected rejection or acceptance point
expected runtime response
expected audit/evidence artifact
claim boundary
```

The central scenario claim is:

```text
A PMS-STACK security scenario is valid when it represents security-relevant
behavior as an operator-typed transition sequence over principals, roles,
capabilities, frames, boundaries, policies, trust state, resources, traps,
absence, commits, and audit evidence, and when it states the expected
runtime response under a declared profile.
```

Claim type:

```text
RUNTIME-SECURITY SCENARIO / CONFORMANCE-STORYBOARD ARCHITECTURE CLAIM
```

Boundary:

```text
Security scenarios make the architecture testable, traceable,
implementation-drivable, and regression-stabilizable.

They do not prove complete runtime security, eliminate all attacks,
certify deployments, prove all implementations secure, make traces/tests
proofs, or validate PMS Base.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At scenario level, Χ is projected as runtime boundary, isolation, reachability, sandboxing, containment, quarantine, host boundary, device boundary, network/session boundary, audit visibility boundary, and trust-boundary control.

Security scenarios use this Χ projection. They do not redefine PMS Base Χ.

Validation in this section means acceptance or rejection under a declared scenario, runtime profile, invariant set, policy set, trace schema, fixture profile, artifact, evidence profile, or conformance rule.

It does not mean external validation of PMS Base.

### 13.1 Scenario Form

A canonical security scenario has the following form:

```text
SecurityScenario = (
    id,
    title,
    purpose,
    runtime_profile,
    initial_state,
    actor,
    target,
    attempted_word,
    required_invariants,
    expected_decision,
    expected_response,
    expected_audit,
    expected_commit_state,
    acceptance_gate,
    claim_boundary
)
```

Minimal representation:

```text
Scenario:
    Setup
    Attempt
    Expected Runtime Response
    Expected Evidence
    Boundary
```

Scenario word:

```text
w = op₁ ; op₂ ; ... ; opₙ
```

where:

```text
opᵢ ∈ { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The word describes attempted runtime behavior.

It does not imply success.

### 13.2 Scenario Acceptance Criteria

A scenario is accepted when the runtime produces the expected operator-typed result.

Acceptance may require:

```text
operator-tagged trace
policy decision event
capability check event
boundary check event
trap or absence event
rollback or commit event
audit event
quarantine event
resource accounting event
trust-state event
compliance report
```

Generic acceptance gate:

```text
ACCEPT iff
    expected decision occurs
    ∧ forbidden effect does not commit
    ∧ required audit evidence exists
    ∧ runtime state after scenario satisfies declared invariants
```

Example:

```text
Scenario accepted if:
    no Σ_success exists for forbidden write
    Ψ_denial exists
    Χ_boundary_check exists
    Ω_missing_capability exists
    AuditEvent records actor, frame, boundary, policy, decision
```

A scenario should never be accepted merely because execution returned an error.

The error must be operator-typed, profile-consistent, policy-consistent, and evidence-visible where required.

### 13.3 Scenario Evidence Levels

Scenarios may be supported by different evidence levels.

```text
E0 — specification scenario only
E1 — static analysis expectation
E2 — executable fixture
E3 — trace-conformance fixture
E4 — runtime hook test
E5 — model-checking property
E6 — audit/compliance report
E7 — deployment evidence under declared profile
```

Evidence level is claim-relevant.

```text
E2 executable fixture
    strengthens implementation-artifact claim.

E5 model-checking result
    establishes stated property under stated model/profile.

E7 deployment evidence
    supports deployment-specific assurance.

None of these validate PMS Base.
```

The assurance vocabulary is:

```text
tests check
traces record
validators accept or reject under profile
trace conformance checks observed behavior against declared expectations
model checking verifies stated properties under stated models
proof artifacts prove stated properties under formal assumptions
audit verification checks evidence completeness and consistency
external validation validates externally under an explicitly designed protocol
```

### 13.4 Scenarios as Golden Fixture Candidates

Each scenario may be converted into a golden fixture by declaring:

```text
input program or event sequence
runtime profile
expected validation decision
expected trace/audit events
expected rejection or commit point
expected final state
limitations
```

Golden-fixture shape:

```text
GoldenFixture = (
    fixture_id,
    scenario_id,
    runtime_profile,
    input_sequence,
    expected_validation,
    expected_trace,
    expected_audit,
    expected_final_state,
    expected_rejection_or_commit_point,
    limitations
)
```

Golden fixtures stabilize regression expectations.

They do not prove full security coverage or validate PMS Base.

The scenarios in this section may supply README examples of:

```text
one valid security transition
one invalid operator sequence
one rejected boundary violation
one trace/audit conformance check
```

### 13.5 Trace and Evidence Convention

A concrete security-scenario execution produces:

```text
trace_runtime(runtime, scenario_artifact, input_profile) ∈ L_PMS,Ψ_runtime
```

The set of possible security-scenario executions under a declared profile is:

```text
Trace_runtime(runtime, scenario_artifact, profile) ⊆ L_PMS,Ψ_runtime
```

A `valid_runtime_trace` is one concrete `trace_runtime(...)` value accepted under the declared scenario profile.

Rule:

```text
trace(...) ∈ L_PMS
Trace(...) ⊆ L_PMS
```

Scenario traces record observed execution.

They do not prove all possible executions unless paired with a stated model, stated bounds, and a proof or model-checking artifact.

### 13.6 Scenario 1 — Unauthorized Privilege Escalation

#### Purpose

Test that role elevation cannot bypass Ω, Ψ, Φ, and Σ.

#### Setup

```text
Principal:
    P_user

Active role:
    ROLE_USER

Frame:
    F_user

Boundary:
    Χ(F_user → F_kernel) requires Φ_trap/syscall mediation

Policy:
    Ψ_role_monotonicity:
        user role cannot become kernel/admin/root role without
        authorized transition path

Capabilities:
    P_user lacks cap.role.elevate(ROOT)
```

Here `Χ(F_user → F_kernel)` denotes a runtime-security boundary projection, not a redefinition of PMS Base Χ.

#### Attempt

```text
w_attack =
    Δ_targetRole(ROOT)
    ; ∇_requestRole(ROOT)
    ; Ω_elevate
    ; Σ_commitRole
```

#### Expected Runtime Response

```text
Δ classifies requested role transition
Ω checks role-elevation capability
Ψ_role_monotonicity denies
Φ enters security-violation context
Σ_commitRole is blocked
Θ/Σ audit records attempt
```

#### Expected Evidence

```text
AuditEvent {
    op = Ω / Ψ
    actor = P_user
    attempted_role = ROOT
    decision = DENY
    reason = missing capability / monotonicity policy
    committed = false
}
```

#### Acceptance Gate

```text
ACCEPT iff
    ROLE_USER remains active
    ROOT role is not committed
    denial trace exists
    audit event exists where policy requires
```

#### Boundary

This scenario supports the runtime-security architecture claim that privileged role transition is operator-governed.

It does not prove all privilege-escalation attacks impossible.

### 13.7 Scenario 2 — Isolation Leak

#### Purpose

Test that Χ boundary enforcement prevents unauthorized cross-frame read.

#### Setup

```text
Frames:
    F_app
    F_secret

Principal:
    P_app

Boundary:
    Χ(F_app → F_secret) = denied unless cap.secret.read exists

Policy:
    Ψ_cross_frame_read:
        all reads from F_secret require cap.secret.read and audit

Capabilities:
    P_app lacks cap.secret.read
```

#### Attempt

```text
w_attack =
    Δ_secretObj
    ; ∇_read(secretObj)
    ; Χ_bypass
    ; Σ_result
```

#### Expected Runtime Response

```text
Δ classifies target as secret object
□ identifies active frame F_app
Χ denies reachability into F_secret
Ω finds no cap.secret.read
Ψ_cross_frame_read denies
Φ enters protection fault or violation context
Σ_result is blocked
Θ/Σ audit records denial
```

#### Expected Evidence

```text
BoundaryAuditRecord {
    source_frame = F_app
    target_frame = F_secret
    boundary_kind = secret_frame
    decision = DENY
}

PolicyAuditRecord {
    policy = Ψ_cross_frame_read
    decision = DENY
}
```

#### Acceptance Gate

```text
ACCEPT iff
    no secret value becomes visible in F_app
    no successful Σ_result exists
    denial point is Χ/Ω/Ψ-represented
```

#### Boundary

This scenario supports the isolation architecture claim.

It does not establish complete side-channel elimination.

### 13.8 Scenario 3 — Policy Tampering

#### Purpose

Test that Ψ policy mutation is itself policy-governed.

#### Setup

```text
Actor:
    P_user

Target:
    PSet_kernel

Frame:
    F_user

Required role:
    ROLE_KERNEL_POLICY_MANAGER

Policy:
    Ψ_policy_integrity:
        policy updates require kernel-governed frame,
        policy-management capability,
        non-weakening validation,
        Σ commit,
        audit
```

#### Attempt

```text
w_attack =
    Δ_shadowPolicy
    ; ∇_write(PSet_kernel)
    ; Ψ_redefine
    ; Σ_policyCommit
```

#### Expected Runtime Response

```text
Δ classifies target as kernel policy set
Ω denies policy-management authority
Χ denies user→kernel policy boundary
Ψ_policy_integrity rejects update
Φ enters governance violation context
Σ_policyCommit is blocked
Θ/Σ audit records policy tampering attempt
```

#### Acceptance Gate

```text
ACCEPT iff
    active policy set unchanged
    attempted policy is not loaded or activated
    audit record identifies actor, target policy, and denial
```

#### Boundary

This scenario supports policy-integrity architecture.

It does not prove all policy languages complete or all policies semantically correct.

### 13.9 Scenario 4 — Capability Smuggling Across IPC

#### Purpose

Test that capability-bearing payloads cannot create authority without delegation policy.

#### Setup

```text
Sender:
    P_sender with cap.ipc.send(ChannelX)

Receiver:
    P_receiver

Sender lacks:
    cap.capability.delegate

Policy:
    Ψ_cap_transfer:
        capability transfer requires explicit delegation authority,
        attenuation,
        provenance,
        Σ commit,
        audit
```

#### Attempt

```text
w_attack =
    Δ_message(capability_payload)
    ; Ω_send
    ; ∇_enqueue(ChannelX)
    ; Σ_delivery
```

#### Expected Runtime Response

```text
Δ classifies payload as capability-bearing
Ω checks send capability
Ω checks delegation capability
Ψ_cap_transfer denies or strips payload
Φ traps or recontextualizes payload if required
Σ_delivery blocked or sanitized delivery committed
Θ/Σ audit records transfer decision
```

#### Acceptance Gate

```text
ACCEPT iff
    receiver does not gain active capability
    capability is denied, stripped, or attenuated under policy
    delegation provenance absent or invalid is recorded
```

#### Boundary

This scenario supports capability-transfer discipline.

It does not assert all serialization formats are safe by default.

### 13.10 Scenario 5 — Transaction Failure and Rollback

#### Purpose

Test that invalid transaction does not reach committed state.

#### Setup

```text
Actor:
    P_service

Target:
    F_fs transaction

Policy:
    Ψ_tx:
        transaction may commit only if all staged writes validate

Commit:
    Σ_final requires integrity + quota + audit preconditions
```

#### Attempt

```text
w =
    ∇_open
    ; Δ_path
    ; ∇_stage_write
    ; Δ_validate
    ; Φ_error
    ; Σ_final?
```

#### Expected Runtime Response

```text
Φ_error enters recovery context
Ψ_tx denies final commit
Σ_rollback discards staged write
Θ/Σ audit records rollback
runtime state satisfies filesystem invariants after recovery
```

#### Acceptance Gate

```text
ACCEPT iff
    no partial write becomes visible
    rollback trace exists
    final Σ_success absent
    recovered filesystem state is invariant-valid
```

#### Boundary

This scenario supports commit-validity architecture.

It does not prove all storage backends equivalent.

### 13.11 Scenario 6 — Driver Overreach

#### Purpose

Test that driver/device authority remains bounded by assigned frames and capabilities.

#### Setup

```text
Driver:
    D_net

Assigned device:
    dev0

Allowed MMIO:
    R0

Forbidden target:
    R_bad

Policy:
    Ψ_driver:
        driver may access only assigned MMIO/DMA/IRQ frames
```

#### Attempt

```text
w_attack =
    Δ_mmio_region(R_bad)
    ; Ω_mmio_write?
    ; ∇_write(R_bad)
    ; Σ_device_effect
```

#### Expected Runtime Response

```text
Δ classifies MMIO target
□ identifies target device frame
Ω finds no capability for R_bad
Χ denies unassigned device boundary
Ψ_driver denies
Φ enters driver fault context
Χ quarantine driver/device if policy requires
Σ_device_effect blocked
Θ/Σ audit records overreach
```

#### Acceptance Gate

```text
ACCEPT iff
    R_bad not mutated
    driver authority not widened
    quarantine or denial follows declared policy
```

#### Boundary

This scenario supports driver/device isolation.

It does not implement hardware-specific DMA protection by itself and does not certify hardware behavior.

### 13.12 Scenario 7 — Trust Anchor Revocation

#### Purpose

Test that revoked trust material cannot create new authority.

#### Setup

```text
Trust anchor:
    TA_old

Policy:
    Ψ_revoke:
        after revocation commit, TA_old cannot validate new sessions

Session attempt:
    peer presents credential chain under TA_old
```

#### Attempt

```text
w =
    Δ_peerCredential
    ; Ψ_verify(TA_old)
    ; Φ_mapRemoteIdentity
    ; Ω_assignSessionCaps
    ; Σ_session
```

#### Expected Runtime Response

```text
Δ classifies credential
Ψ_verify detects revoked anchor
Φ maps result to trust failure
Ω session capabilities not assigned
Σ_session blocked
Θ/Σ audit records revoked trust attempt
```

#### Acceptance Gate

```text
ACCEPT iff
    no new session authority is committed
    revocation state is observed
    trust failure audit exists where required
```

#### Boundary

This scenario supports trust-anchor lifecycle enforcement.

It does not prove cryptographic algorithm security, legal identity, universal trust, or PMS Base validation.

### 13.13 Scenario 8 — Network Replay

#### Purpose

Test that replayed network message does not produce duplicate committed effect.

#### Setup

```text
Session:
    S

Protocol:
    requires sequence freshness

Policy:
    Ψ_freshness:
        reject old sequence/nonce outside replay window
```

#### Attempt

```text
w_attack =
    Δ_old_message
    ; Θ_check_sequence
    ; ∇_deliver_again
    ; Σ_accept
```

#### Expected Runtime Response

```text
Δ classifies message
Θ detects old sequence or nonce reuse
Ψ_freshness denies
Φ protocol trap or drop
Σ_accept blocked
Θ/Σ audit if required
```

#### Acceptance Gate

```text
ACCEPT iff
    duplicate effect not committed
    replay decision recorded
    session ordering state remains valid
```

#### Boundary

This scenario supports session-ordering discipline.

It does not define a specific anti-replay algorithm.

### 13.14 Scenario 9 — No-Resource / Quota Exhaustion

#### Purpose

Test that resource exhaustion is Λ-typed and policy-governed.

#### Setup

```text
Principal:
    P_worker

Resource:
    memory quota Q

Resource account:
    RAcc_worker

Policy:
    Ψ_resource:
        hard limit denies allocation
        soft limit throttles
```

#### Attempt

```text
w =
    Δ_alloc(size)
    ; Ω_alloc
    ; Ψ_quota
    ; ∇_allocate
```

where:

```text
requested allocation exceeds remaining quota
```

#### Expected Runtime Response

```text
Δ classifies allocation request
Ω verifies allocation authority
Ψ_quota denies or throttles
Λ_no_resource emitted if recoverable
Φ quota fault if policy requires trap
Σ resource accounting/audit committed if required
```

#### Acceptance Gate

```text
ACCEPT iff
    allocation does not commit beyond quota
    no-resource or trap response matches policy
    accounting is attributable to P_worker and RAcc_worker
```

#### Boundary

This scenario supports resource-governance behavior.

It does not prove all denial-of-service attacks impossible.

### 13.15 Scenario 10 — Audit Tampering

#### Purpose

Test that audit storage is protected state.

#### Setup

```text
Actor:
    P_user

Target:
    AuditLog(security)

Policy:
    Ψ_audit_integrity:
        audit mutation requires audit-management authority
        deletion/rotation is audited
```

#### Attempt

```text
w_attack =
    Δ_audit_record
    ; ∇_delete_or_modify
    ; Σ_commit
```

#### Expected Runtime Response

```text
Δ classifies target as audit state
Ω denies audit-management authority
Χ denies audit-write boundary
Ψ_audit_integrity denies
Φ enters violation context
Σ_commit blocked
Σ_audit records tampering attempt if possible
```

#### Acceptance Gate

```text
ACCEPT iff
    target audit record remains protected
    tampering attempt is recorded or typed as audit-failure if audit sink unavailable
```

#### Boundary

This scenario supports audit-integrity architecture.

It does not assert tamper-proof storage unless the runtime profile provides it. Audit records are evidence artifacts, not forensic proof.

### 13.16 Scenario 11 — FFI Host Boundary Failure

#### Purpose

Test that host behavior does not silently become PMS-native state.

#### Setup

```text
Actor:
    P_runtime

Host service:
    H_clock or H_crypto

Boundary:
    ForeignFrame required

Policy:
    Ψ_ffi:
        host call requires declared profile, error map, memory profile, commit profile
```

#### Attempt

```text
w =
    Δ_foreign_symbol
    ; Ω_host_call
    ; Χ_enter_host?
    ; ∇_host_call
    ; Σ_integrate_result
```

where the host call returns malformed data or fails.

#### Expected Runtime Response

```text
Δ classifies host result/error
Χ verifies ForeignFrame boundary
Ψ_ffi evaluates integration policy
Φ maps host error or malformed result
Λ no-response/timeout if applicable
Σ_integrate_result blocked unless profile permits
Θ/Σ audit if required
```

#### Acceptance Gate

```text
ACCEPT iff
    malformed host result not committed as trusted runtime state
    host failure mapped through Φ or Λ
    boundary and policy events visible in trace
```

#### Boundary

This scenario supports FFI boundary discipline.

It does not make host behavior equivalent to PMS-OS behavior.

### 13.17 Scenario 12 — AI / Tooling Boundary Violation

#### Purpose

Test that AI/tooling proposal authority is separated from execution authority.

#### Setup

```text
Tooling principal:
    P_ai

Capability:
    cap.ai.propose_ir

Missing:
    cap.runtime.execute_ir

Policy:
    Ψ_tooling_advisory:
        AI may propose
        host validates
        runtime executes only accepted artifacts
```

#### Attempt

```text
w_attack =
    Δ_ai_output
    ; ∇_replace_program
    ; Σ_execute
```

#### Expected Runtime Response

```text
Δ classifies AI output as proposal
Ω detects no execution authority
Χ checks tooling/runtime boundary
Ψ_tooling_advisory denies direct execution
Φ recontextualizes artifact as advisory or rejects it
Σ_execute blocked
Θ/Σ audit records boundary decision
```

#### Acceptance Gate

```text
ACCEPT iff
    proposed artifact does not execute directly
    validation/acceptance path is required
    proposal/execution boundary preserved
```

#### Boundary

This scenario supports AI/tooling safety boundary.

It does not claim AI output is verified, true, trusted executable code, compiler authority, runtime policy authority, verification evidence, or PMS Base evidence.

Standard boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 13.18 Scenario 13 — Distributed Fake Commit

#### Purpose

Test that one node cannot unilaterally produce global committed state.

#### Setup

```text
Cluster:
    C

Node:
    N_bad

Policy:
    Ψᴳ_commitQuorum

Global commit:
    Σᴳ requires quorum proof
```

#### Attempt

```text
w_attack =
    Δ_state_update
    ; ∇_reportProgress(fake)
    ; Σᴳ_commit
```

#### Expected Runtime Response

```text
Δ classifies proposed update
Ω checks node commit authority
Ψᴳ_commitQuorum denies missing quorum
Σᴳ_commit blocked
Φᴳ traps/recontexts cluster condition
Χᴳ restricts node if policy requires
Θ/Σ audit records anomaly
```

#### Acceptance Gate

```text
ACCEPT iff
    no global committed state advances from unilateral report
    quorum failure is represented
    node response follows policy
```

#### Boundary

This scenario supports distributed commit discipline.

It does not specify a complete consensus algorithm in this document. Full distributed semantics belong to `07_distributed_systems.md`.

### 13.19 Scenario 14 — Boot Trust Failure

#### Purpose

Test that untrusted boot artifact does not produce normal runtime exposure.

#### Setup

```text
Boot artifact:
    kernel_image

Trust anchor:
    TA_boot

Policy:
    Ψ_boot_verify:
        image must verify under active boot trust anchor
```

#### Attempt

```text
w =
    Δ_boot_artifact
    ; Ψ_verify(signature)
    ; Φ_trusted_boot?
    ; Σ_boot_state
```

where verification fails.

#### Expected Runtime Response

```text
Δ classifies boot artifact
Ψ_boot_verify denies trust
Φ enters recovery, fallback, quarantine, or halt context
Σ normal boot state blocked
Θ/Σ audit boot failure if profile supports it
```

#### Acceptance Gate

```text
ACCEPT iff
    normal runtime exposure does not occur
    boot state is recovery/fallback/quarantine/halt according to policy
```

#### Boundary

This scenario supports boot trust-state architecture.

It does not prove full runtime correctness.

### 13.20 Scenario 15 — Quarantined Subject Continues Sending IPC

#### Purpose

Test that quarantine state affects scheduler, IPC, boundary, and capability logic.

#### Setup

```text
Subject:
    P_proc

State:
    quarantined(P_proc) = true

Policy:
    Ψ_quarantine:
        quarantined subject may not send IPC
```

#### Attempt

```text
w_attack =
    Δ_channel
    ; Ω_send
    ; Χ_cross_endpoint
    ; ∇_enqueue
    ; Σ_delivery
```

#### Expected Runtime Response

```text
Δ classifies IPC attempt
Ω observes attenuated/revoked authority
Χ observes tightened quarantine boundary
Ψ_quarantine denies
∇_enqueue blocked
Σ_delivery blocked
Θ/Σ audit records quarantine enforcement
```

#### Acceptance Gate

```text
ACCEPT iff
    no message is delivered
    quarantine state is visible to IPC path
    audit shows denial under quarantine policy
```

#### Boundary

This scenario supports quarantine enforcement.

It does not imply quarantine is forensic proof of malicious intent.

### 13.21 Scenario 16 — Policy Cache Staleness

#### Purpose

Test that cached policy decisions invalidate on relevant state changes.

#### Setup

```text
Actor:
    P_service

Cached decision:
    ALLOW fs.write("/var/log/app.log")

State change:
    policy_epoch increments or capability revoked

Policy:
    Ψ_cache:
        cached decision invalid if policy/capability/boundary/resource/trust epoch changes
```

#### Attempt

```text
w_attack =
    Δ_cached_decision
    ; ∇_write_using_cache
    ; Σ_commit
```

#### Expected Runtime Response

```text
Θ detects stale epoch
Ψ_cache invalidates cached decision
Ω/Ψ reevaluation occurs
operation allowed or denied under current state
Σ_commit only if current policy permits
Θ/Σ audit cache invalidation if required
```

#### Acceptance Gate

```text
ACCEPT iff
    stale cached allow does not bypass current Ω/Χ/Ψ state
```

#### Boundary

This scenario supports fast-path correctness.

It does not forbid caching; it constrains cache validity.

### 13.22 Scenario 17 — Audit Sink Unavailable for Critical Operation

#### Purpose

Test fail-closed behavior when durable audit is required but unavailable.

#### Setup

```text
Operation:
    trust-anchor rotation

Policy:
    Ψ_audit_required:
        durable audit required before rotation commit

Failure:
    audit sink unavailable
```

#### Attempt

```text
w =
    Δ_trust_rotation
    ; Ω_rotate
    ; Ψ_rotate
    ; Σ_trust_update
```

with:

```text
Λ_audit_sink_unavailable
```

#### Expected Runtime Response

```text
Λ identifies audit sink absence
Ψ_audit_required denies trust update commit
Φ enters recovery/defer context
Σ_trust_update blocked
Θ/Σ records audit failure if fallback audit exists
```

#### Acceptance Gate

```text
ACCEPT iff
    trust-anchor rotation does not commit without required audit
    failure mode matches declared policy
```

#### Boundary

This scenario supports audit-as-security-obligation.

It does not assert all audit backends are failure-proof.

### 13.23 Scenario 18 — Network Capability Transfer with Attenuation

#### Purpose

Test valid capability transfer under explicit delegation policy.

#### Setup

```text
Sender:
    P_service_A

Receiver:
    P_service_B

Capability:
    cap.fs.read("/data/project/**")

Delegation policy:
    may delegate attenuated read to "/data/project/public/**"
    session-scoped
    audited
```

#### Attempt

```text
w =
    Δ_capability_payload
    ; Ω_check_delegation
    ; Χ_session_boundary
    ; Ψ_cap_transfer
    ; Φ_map_receiver_context
    ; Ω_attach_attenuated_capability
    ; Σ_delegate
```

#### Expected Runtime Response

```text
delegation accepted only as attenuated capability
scope narrowed
session lifetime attached
provenance recorded
Σ commit delegation state
Θ/Σ audit transfer
```

#### Acceptance Gate

```text
ACCEPT iff
    receiver gains only attenuated, scoped capability
    broader source capability is not transferred
    audit includes delegation chain
```

#### Boundary

This scenario shows valid transfer, not only denial.

It supports capability governance, not unrestricted delegation.

### 13.24 Scenario 19 — Host Key Service Boundary

#### Purpose

Test that external key service behavior is represented as host/service boundary.

#### Setup

```text
Backend:
    HostKeyService

Required:
    ForeignFrame or HostService boundary
    key-use policy
    host error map
    commit profile
```

#### Attempt

```text
w =
    Δ_key_operation
    ; Ω_key_use
    ; Χ_enter_host_service
    ; Ψ_key_policy
    ; ∇_host_key_call
    ; Φ_map_result
    ; Σ_trust_state
```

#### Expected Runtime Response

```text
host service boundary checked
key-use policy evaluated
host result mapped through Φ
trust state committed only under declared Σ profile
audit emitted if required
```

#### Acceptance Gate

```text
ACCEPT iff
    host key service does not become implicit PMS-native authority
    result integration follows Φ/Ψ/Σ
```

#### Boundary

This scenario supports pluggable key backend architecture.

It does not claim host key services are equivalent to native PMS-OS key storage.

### 13.25 Scenario 20 — Valid Security-Critical Operation

Security scenarios should include positive cases.

#### Purpose

Test that valid operation succeeds when all obligations are met.

#### Setup

```text
Actor:
    P_audit_service

Role:
    ROLE_AUDIT_WRITER

Capability:
    cap.audit.append(SecurityLog)

Frame:
    F_audit_service

Boundary:
    Χ permits SecurityLog append

Policy:
    Ψ_audit_append permits append-only write

Commit:
    Σ_durable required
```

#### Attempt

```text
w_valid =
    Δ_security_log
    ; Ω_check_append
    ; □_audit_frame
    ; Χ_audit_boundary
    ; Ψ_audit_append
    ; ∇_append_record
    ; Σ_durable
    ; Θ_audit_order
```

#### Expected Runtime Response

```text
operation allowed
append succeeds
durable audit commit emitted
security invariants preserved
```

#### Acceptance Gate

```text
ACCEPT iff
    append result committed
    record is append-only
    audit evidence is durable
    no unrelated authority is granted
```

#### Boundary

Positive scenarios ensure the architecture is not merely denial-oriented.

Valid authority remains executable.

### 13.26 Scenario Matrix

The scenario matrix summarizes coverage.

| Scenario | Primary operators | Security concern |
| -------- | ----------------- | ---------------- |
| Unauthorized privilege escalation | Ω / Ψ / Φ / Σ | role monotonicity |
| Isolation leak | Χ / Ω / Ψ / Φ | boundary enforcement |
| Policy tampering | Ψ / Ω / Χ / Σ | policy integrity |
| Capability smuggling | Ω / Ψ / Φ / Σ | delegation control |
| Transaction failure | Φ / Σ / Ψ | rollback and commit |
| Driver overreach | Ω / Χ / Ψ / Φ | device confinement |
| Trust-anchor revocation | Φ / Ψ / Σ | trust lifecycle |
| Network replay | Θ / Ψ / Φ / Σ | freshness and ordering |
| Resource exhaustion | Λ / Ψ / Σ | quota and no-resource |
| Audit tampering | Ω / Χ / Ψ / Σ | evidence protection |
| FFI failure | Χ / Φ / Λ / Σ | host boundary |
| AI/tooling violation | Ω / Χ / Ψ / Σ | advisory boundary |
| Distributed fake commit | Ψᴳ / Σᴳ / Χᴳ | global commit |
| Boot trust failure | Ψ / Φ / Σ | boot trust state |
| Quarantine bypass | Χ / Ω / Ψ / Σ | quarantine enforcement |
| Cache staleness | Θ / Ψ / Ω | fast-path invalidation |
| Audit sink failure | Λ / Ψ / Σ | fail-closed audit |
| Valid capability transfer | Ω / Φ / Ψ / Σ | governed delegation |
| Host key service | Χ / Φ / Ψ / Σ | trust backend boundary |
| Valid audit append | Ω / Χ / Ψ / Σ | positive operation |

The matrix is a coverage map for scenario design. It is not proof of complete runtime-security coverage.

### 13.27 Scenario Implementation Guidance

An implementation should treat scenarios as acceptance artifacts.

Recommended fixture format:

```text
scenario/
    metadata
    initial_state
    attempted_program_or_event_sequence
    expected_trace
    expected_final_state
    expected_audit
    expected_diagnostics
    claim_boundary
```

Scenario result:

```text
PASS
FAIL
UNSUPPORTED
PROFILE_LIMITED
INCONCLUSIVE
```

Trace checks should verify:

```text
operator order
policy decision
capability result
boundary result
commit result
audit evidence
final invariant state
```

A scenario should never be accepted merely because execution returned an error.

The error must be operator-typed and policy-consistent.

### 13.28 PMS-RUST Evidence Relation

PMS-RUST v0.1 is a bounded executable PMS-STACK Evidence Spine.

PMS-RUST-style artifacts can support scenario evidence when they provide:

```text
operator-tagged execution
model validation
stateful validation
fail-closed rejection paths
JSONL traces
golden fixtures
vFS service boundary traces
AI proposal gating traces
acceptance-gate reports
bounded chi_enter / chi_exit discipline
```

A PMS-RUST scenario suite may include:

```text
invalid_delta_omega
invalid_sigma_no_frame
post_psi_sealing
script_rejects_fs
capability_smuggling_rejected
ai_proposal_not_executable
boundary_crossing_denied
audit_required_commit
resource_no_resource
trust_revocation_denied
valid_audit_append
```

Correct relation:

```text
Security scenarios
    define operator-typed acceptance cases.

PMS-RUST bounded artifacts
    may demonstrate executable scenario slices.
```

This strengthens implementation-artifact claims for declared slices.

It does not validate PMS Base, complete runtime security, prove deployment security, complete PMS-OS, complete PMSL/PMS-IR, complete distributed runtime, establish universal attack resistance, or make tests/traces proofs.

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where an exit requires active boundary context.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 13.29 Scenario Claim Boundary

Security scenarios claim:

```text
specific runtime-security properties hold for specific scenarios under
declared profiles, initial states, policies, artifacts, traces, and
acceptance gates.
```

They do not claim:

```text
all attacks are covered
all implementations are secure
all side channels are eliminated
all policies are correct
all traces prove all executions
all domains are externally validated
PMS Base is validated
PMS-RUST completes runtime security
AI/tooling output is trusted executable code
```

Scenarios are strong because they make runtime-security obligations concrete. They transform architecture into executable, inspectable, and regression-testable cases without overclaiming their evidential scope.

### 13.30 Security Scenarios Invariants

Runtime security maintains the following scenario invariants.

```text
I1: every security scenario declares initial state, attempted transition or
    attack word, expected operator obligation, expected response, expected
    evidence, and claim boundary

I2: every attack word describes attempted behavior, not successful execution

I3: every scenario declares a runtime profile or is marked profile-limited

I4: every scenario acceptance gate distinguishes rejection, absence, trap,
    rollback, quarantine, commit, and audit outcomes

I5: every invalid scenario identifies the failed operator obligation

I6: every valid scenario states which authority, boundary, policy, frame,
    and commit conditions make execution admissible

I7: every scenario evidence claim states whether the evidence is specification,
    fixture, trace, hook test, model-checking result, audit report, or
    deployment-profile evidence

I8: every scenario trace is interpreted through trace_runtime(...) and does
    not prove all possible executions

I9: every scenario that uses Χ treats it as an implementation-layer projection
    of PMS Base Distance

I10: every AI/tooling scenario preserves advisory/execution separation

I11: every distributed marker remains boundary-facing toward
     `07_distributed_systems.md`

I12: every PMS-RUST-style scenario artifact strengthens implementation-artifact
     claims and does not validate PMS Base

I13: every golden fixture stabilizes regression expectations without proving
     complete security coverage
```

### 13.31 Architectural Consequence

The consequence is:

```text
PMS-STACK runtime security is scenario-drivable. Its security architecture
can be expressed as executable, profile-bound, operator-typed cases that
specify initial conditions, attempted transitions, expected obligations,
expected rejection or acceptance points, expected evidence, and explicit
claim boundaries.
```

This gives PMS-STACK a practical bridge from architecture to artifact:

```text
specification scenario
→ fixture candidate
→ validation rule
→ expected trace
→ expected audit evidence
→ acceptance gate
→ limitation
```

Security scenarios therefore make PMS-STACK implementation-facing without converting testability into proof.

### 13.32 Security Scenarios Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-STACK security-scenario model specifies implementation-layer
runtime-security scenario architecture: scenario forms, acceptance
criteria, evidence levels, golden-fixture candidates, trace/evidence
conventions, privilege-escalation scenarios, isolation-leak scenarios,
policy-tampering scenarios, capability-smuggling scenarios, transaction
failure scenarios, driver-overreach scenarios, trust-anchor revocation
scenarios, network replay scenarios, quota/no-resource scenarios, audit
tampering scenarios, FFI/host-boundary scenarios, AI/tooling boundary
scenarios, distributed fake-commit scenarios, boot-trust scenarios,
quarantine scenarios, policy-cache scenarios, audit-sink failure
scenarios, valid capability-transfer scenarios, host-key-service
scenarios, valid positive-operation scenarios, scenario matrices,
implementation guidance, PMS-RUST evidence boundaries, scenario
invariants, and architectural consequences.

This is a runtime-security scenario / conformance-storyboard
architecture claim.

It does not claim complete attack coverage, universal security
certification, complete deployment security, complete PMS-OS, complete
PMSL/PMS-IR, complete distributed runtime, forensic certainty, legal
authority, moral authority, clinical authority, tribunal status, trusted
AI authority, proof of all runtime behavior, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection paths, JSONL traces, golden fixtures, vFS/service-boundary
traces, bounded isolation-exit discipline, AI proposal gating traces, and
acceptance-gate reports. It does not complete runtime security and does
not validate PMS Base.
```

---

## 14. Claim Boundary

This section defines the claim boundary for `06_runtime_security.md`.

The runtime-security architecture of PMS-STACK is intentionally strong. It does not describe security as an optional add-on, wrapper, policy file, permission list, cryptographic appendix, audit log, or host-library feature. It specifies security as a cross-cutting implementation-layer architecture derived from operator-typed execution.

The central document claim is:

```text
PMS-STACK runtime security is the implementation-layer security and
governance architecture by which identity, authority, frames, boundaries,
policies, hooks, invariants, audit, trust anchors, network sessions,
failure handling, and security scenarios are represented as
operator-governed runtime structures.
```

Claim type:

```text
IMPLEMENTATION-LAYER RUNTIME-SECURITY / GOVERNANCE ARCHITECTURE CLAIM
```

Boundary:

```text
This is an implementation-layer architecture claim.

It is not PMS Base validation.
It is not universal security certification.
It is not deployment-security proof.
It is not forensic certainty.
It is not legal, moral, clinical, or tribunal authority.
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

`06_runtime_security.md` uses Χ as a runtime-security projection:

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK runtime-security layer:
    Χ projects as isolation, reachability, boundary management,
    access separation, containment, visibility control, namespace
    separation, trust-boundary control, sealed isolation, and quarantine.
```

This projection is implementation-layer usage.

It does not redefine PMS Base Χ.

### 14.1 What This Document Claims

`06_runtime_security.md` claims that PMS-STACK can specify runtime security through:

```text
Δ distinction of actors, objects, events, credentials, policies, and attacks

∇ controlled mutation and state effects

□ runtime frames for processes, modules, kernel contexts, devices,
  network sessions, FFI, audit, and key material

Λ typed absence, timeout, no-resource, no-route, no-message, and no-quorum

Α reusable security patterns, scenarios, handlers, profiles, and acceptance gates

Ω roles, capabilities, authority, delegation, revocation, impersonation,
  and key-use rights

Θ ordering, scheduling, expiry, replay windows, resource windows, and audit order

Φ traps, faults, recontextualization, identity mapping, protocol negotiation,
  recovery, rotation, revocation, and quarantine entry

Χ implementation-layer projection of Distance as isolation, boundary,
  reachability, containment, visibility, access separation, sealed
  isolation, and quarantine

Σ commit, rollback, durable evidence, trust-state stabilization,
  policy activation, session commit, and distributed commit boundaries

Ψ policies, invariants, hook decisions, enforcement actions, governance rules,
  audit requirements, trust rules, validation profiles, and claim boundaries
```

It claims these structures form a coherent runtime-security architecture.

### 14.2 Architecture Claim

The architecture claim is:

```text
PMS-STACK defines security as operator-governed runtime structure.
```

This includes:

```text
identity and principals
roles and capabilities
isolation and boundary models
policy definition and enforcement
kernel policy hooks
runtime invariants
audit and compliance hooks
key and trust-anchor management
network security integration
failure, absence, and attack handling
security scenarios
claim boundaries
```

These are not independent add-ons.

They form one security architecture.

```text
identity defines who acts
authority defines what may be attempted
frames define where action is situated
boundaries define what is reachable
policy defines what is admissible
hooks define where enforcement attaches
invariants define what must remain true
audit defines what becomes evidence
trust defines how credentials become local runtime state
network security defines how remote interaction enters local authority
failure handling defines how abnormal behavior remains typed
scenarios define how architecture becomes testable
claim boundaries define what the document does and does not establish
```

### 14.3 Implementation-Layer Claim

The implementation-layer claim is:

```text
PMS-STACK provides an implementation-oriented specification for building
systems in which security-relevant runtime transitions are explicitly
typed, constrained, checked, traced, audited, and committed.
```

This supports implementation work such as:

```text
kernel hooks
capability tables
policy engines
isolation graphs
audit schemas
trust-state stores
network session models
validation passes
runtime profiles
golden fixtures
trace-conformance tests
acceptance gates
PMS-RUST-style executable evidence slices
```

An implementation may realize bounded slices first.

Partial implementation can strengthen implementation-artifact claims when it is explicit about:

```text
which profiles are implemented
which invariants are enforced
which hooks exist
which policies are active
which scenarios are covered
which traces are emitted
which audit records are committed
which limitations remain
```

Partial implementation does not become complete runtime security by implication.

### 14.4 Evidence Claim

The evidence claim is:

```text
Artifacts such as validators, traces, audits, fixtures, simulations,
model checks, proof artifacts, and executable runtimes can strengthen
PMS-STACK implementation-layer claims when they demonstrate declared
properties under declared profiles.
```

Examples:

```text
operator-tagged traces
fail-closed validation
stateful invariant checks
JSONL audit streams
golden fixtures
scenario acceptance gates
policy decision logs
hook coverage reports
trust-state audit records
network session traces
quarantine traces
rollback traces
AI proposal gating traces
```

Correct evidence phrasing:

```text
This artifact demonstrates property P under runtime profile R
for scenario/evidence range E.
```

Incorrect evidence phrasing:

```text
This artifact proves PMS Base.
This trace proves all executions.
This audit log proves forensic truth.
This test suite proves complete security.
```

Assurance vocabulary:

```text
tests check
traces record
validators accept or reject under profile
trace conformance checks observed behavior against declared expectations
audit verification checks evidence completeness and consistency
model checking verifies stated properties under stated models
proof artifacts prove stated properties under formal assumptions
external validation validates externally under an explicitly designed protocol
```

### 14.5 PMS-RUST Relation

PMS-RUST v0.1 may function as a bounded executable PMS-STACK Evidence Spine.

For runtime security, PMS-RUST-style artifacts can support bounded slices of:

```text
operator-tagged execution
model validation
stateful validation
fail-closed rejection paths
trace/audit output
golden fixtures
service-boundary discipline
vFS boundary behavior
AI proposal gating
acceptance-gate behavior
bounded chi_enter / chi_exit discipline
```

Correct relation:

```text
PMS-STACK runtime security
    defines architecture and obligations.

PMS-RUST bounded artifacts
    may demonstrate executable slices of those obligations.
```

PMS-RUST-style artifacts may evidence bounded runtime-security slices:

```text
validation gates
deterministic operator execution
fail-closed rejection
JSONL traces
golden fixtures
vFS/service boundaries
AI proposal gating
bounded isolation-exit discipline
```

They strengthen implementation-artifact claims.

They do not:

```text
validate PMS Base
complete runtime security
prove deployment security
complete PMS-OS
complete PMSL/PMS-IR
complete distributed runtime
turn tests into proofs
turn traces into external validation
make runtime dialect PMS 1.3 theory
```

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline where an exit requires active boundary context.

It does not redefine PMS Base Χ, complete PMS-OS isolation, complete runtime-security enforcement, or validate PMS Base.

### 14.6 PMS Base Boundary

PMS Base remains the source of truth for the base operator grammar.

This document uses PMS operators for implementation-layer runtime security.

Important boundary:

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK runtime-security layer:
    Χ projects as isolation, reachability, boundary management,
    access separation, containment, visibility control, namespace
    separation, quarantine, and trust-boundary control.
```

`IDom`, `X_user`, `X_global`, and comparable runtime-domain names denote implementation-level isolation-domain values.

They are not the PMS Base operator `Χ` itself.

This document does not validate PMS Base.

It strengthens:

```text
PMS-STACK architecture claim
runtime-security specification claim
implementation-artifact claim when executable evidence exists
```

It does not establish:

```text
PMS Base truth
universal praxis theory validation
external empirical validation of PMS
formal proof of PMS
operator metaphysics
domain-policy authority
```

### 14.7 Security Claim Boundary

This document claims:

```text
security-relevant runtime behavior can be represented, constrained,
checked, audited, and committed through operator-governed structures.
```

It does not claim:

```text
all systems implementing parts of it are secure
all attacks are eliminated
all side channels are eliminated
all cryptographic algorithms are specified
all deployment policies are correct
all host systems are equivalent
all distributed systems are safe by local policy alone
all audit logs are complete
all compliance reports are legal compliance
all traces prove all executions
all runtime profiles transfer automatically
```

Security remains profile-, policy-, implementation-, assumption-, and evidence-dependent.

The architecture is strong because it makes those dependencies explicit.

### 14.8 Governance Boundary

Runtime governance is the Ψ-governed discipline by which a computational system controls:

```text
policy lifecycle
enforcement decisions
audit obligations
trust interpretation
quarantine
escalation
rollback
commit validity
runtime-profile boundaries
evidence obligations
```

This is a systems-architecture claim.

It is not:

```text
social governance
moral judgment
legal adjudication
person evaluation
clinical classification
forensic verdict
tribunal authority
political authority
policy enforcement over humans as such
```

Governance is runtime governance.

A policy denial is a runtime decision.

It is not a moral verdict.

Quarantine is a runtime isolation response.

It is not a legal accusation.

Compliance is a declared evidence check.

It is not universal compliance with all possible external regimes.

### 14.9 Identity Boundary

Principals, roles, sessions, remote identities, tooling identities, and device identities are computational runtime constructs.

This document does not claim:

```text
principal = personhood
identity = legal person
role = social rank
capability = moral entitlement
trust anchor = institutional legitimacy
quarantine = blame
audit = forensic truth
```

It claims:

```text
principals and roles can bind runtime authority, frames, boundaries,
policies, audit, trust, and commit obligations.
```

A runtime identity may correspond to a user, service, process, device, node, tool, AI service, session, or host boundary.

That correspondence is local to the declared runtime profile and policy.

It is not a universal identity truth.

### 14.10 Trust Boundary

This document claims:

```text
keys, credentials, sessions, trust anchors, boot images, drivers,
network peers, distributed nodes, host services, and tooling artifacts
can be represented as policy-governed trust-state structures.
```

It does not claim:

```text
cryptographic algorithms are defined here
cryptographic strength is certified here
signatures alone establish authority
boot trust proves runtime correctness
trust anchors prove semantic truth
host key stores are PMS-native by default
distributed trust is solved without distributed policy
audit signatures prove all behavior
tooling provenance makes AI output executable authority
```

Trust means:

```text
Φ(credentials) subject to Ψ(policies), with Ω use authority,
Χ boundary containment, and Σ committed trust state.
```

A key verifies a cryptographic relation under a profile.

A policy interprets what that relation means.

The runtime commits only the resulting local trust state.

### 14.11 Audit and Compliance Boundary

This document claims:

```text
audit and compliance can make security behavior operator-readable,
orderable, commit-aware, policy-checkable, redaction-aware, and
evidence-producing.
```

Audit records are runtime-security evidence artifacts.

They support:

```text
traceability
conformance checking
policy inspection
incident reconstruction
compliance reporting under declared profiles
```

They do not by themselves constitute:

```text
forensic proof
legal judgment
moral authority
external validation
PMS Base validation
```

Compliance means checking runtime evidence against declared policy, profile, retention, redaction, and conformance obligations.

It does not mean:

```text
social governance
legal adjudication
tribunal status
universal security certification
forensic omniscience
```

Correct claim:

```text
Evidence E supports property P under profile R and scope S.
```

Incorrect claim:

```text
Audit proves all behavior.
Compliance report proves legal compliance.
Trace conformance proves all executions.
```

### 14.12 Network and Distributed Boundary

This document claims:

```text
network sessions, remote identities, protocol profiles, trust anchors,
resource policies, message validation, capability transfer, audit, and
distributed commit boundaries can be integrated into runtime security.
```

It does not claim:

```text
a specific protocol stack
a specific cryptographic suite
complete distributed consensus
complete cluster policy synchronization
complete global commit semantics
complete partition handling
universal network safety
side-channel elimination
host network equivalence
global security from local policy alone
```

Distributed semantics are refined in `07_distributed_systems.md`.

`06_runtime_security.md` defines the runtime-security integration surface.

Distributed markers in this document are boundary-facing references to `07_distributed_systems.md`.

They do not make this document the distributed-system specification.

### 14.13 Failure and Attack Boundary

This document claims:

```text
failure, absence, policy denial, traps, rollback, quarantine, attack
attempts, trust failures, resource exhaustion, AI/tooling boundary
violations, and critical invariant responses can be represented as
operator-typed runtime-security transitions.
```

It does not claim:

```text
all attacks are known
all attacks are prevented
all failures are recoverable
quarantine proves maliciousness
audit proves intent
all compromise states are detectable
all recovery paths are safe without implementation evidence
all rejection traces prove universal resistance
```

Attack words describe attempted operator sequences.

They do not assert that the attack succeeds.

A successful rejection shows that a specific attempted transition was blocked under a declared profile.

It is not a universal proof that all variants are blocked.

Attack scenarios are structured acceptance cases.

They are not exhaustive threat coverage.

### 14.14 Scenario Boundary

This document claims:

```text
security scenarios can make runtime-security obligations executable,
inspectable, profile-bound, and regression-testable.
```

Security scenarios are executable architecture tests or conformance storyboards.

They specify:

```text
initial state
attempted transition or attack word
expected operator obligation
expected rejection or acceptance point
expected runtime response
expected audit/evidence artifact
claim boundary
```

They do not prove complete runtime security.

Each scenario may be converted into a golden fixture by declaring:

```text
input program or event sequence
runtime profile
expected validation decision
expected trace/audit events
expected rejection or commit point
limitations
```

Golden fixtures stabilize regression expectations.

They do not prove full security coverage or validate PMS Base.

### 14.15 Runtime Profile Boundary

Every runtime-security claim is profile-dependent.

A profile may be:

```text
minimal
simulation
deterministic_test
debug
production
high_assurance
host_runtime
PMS-OS runtime
distributed_runtime
PMS-RUST evidence spine
```

A profile must declare:

```text
which hooks are implemented
which invariants are enforced
which policies are active
which audits are emitted
which trust backends exist
which network features exist
which FFI boundaries exist
which scenarios are supported
which unsupported features fail closed, fail open, or remain absent
```

Claim rule:

```text
property P under profile R
≠ property P under all profiles
```

Portability requires explicit mapping, assumptions, and evidence.

Portability is not equivalence.

### 14.16 AI and Tooling Boundary

AI/tooling may support runtime-security workflows.

It may:

```text
propose PMS-IR
summarize traces
explain diagnostics
suggest missing policies
suggest scenarios
draft test fixtures
analyze audit records under redaction policy
suggest conformance checks
```

AI/tooling may not:

```text
authorize execution
define semantics
replace policy evaluation
replace verification
grant capabilities
commit runtime state
serve as trusted executable code
serve as compiler authority
serve as verification evidence
serve as runtime policy authority
validate PMS Base
```

Standard boundary:

```text
AI proposes.
Host validates.
Runtime executes only accepted artifacts.
Policy remains Ψ-governed.
```

AI output is not trusted executable code, compiler authority, verification evidence, runtime policy authority, or PMS Base validation.

### 14.17 Final Claim Table

`06_runtime_security.md` claims:

```text
PMS-STACK has a complete implementation-layer runtime-security and
governance architecture specification for identity, principals, roles,
capabilities, isolation, policy hooks, runtime invariants,
audit/compliance, trust anchors, network security integration, failure
handling, attack scenarios, security scenarios, and runtime claim
boundaries.
```

It does not claim:

```text
completed runtime-security implementation
universal security certification
production hardening
complete cryptographic system
complete network stack
complete distributed runtime
complete PMS-OS
complete PMSL/PMS-IR
legal authority
moral authority
clinical authority
forensic omniscience
tribunal status
trusted AI authority
proof of all runtime behavior
PMS Base validation
```

This strengthens the PMS-STACK runtime-security architecture claim.

It does not validate PMS Base.

It does not prove all deployments secure.

It does not make audit, tests, traces, fixtures, or scenarios proofs.

### 14.18 Non-Claims

This document does not claim:

```text
PMS-STACK validates PMS Base

PMS-RUST validates PMS Base

tests equal proof

traces equal external validation

audit equals forensic certainty

implementation equals truth

portability equals equivalence

governance equals tribunal

trust anchor equals truth

signature equals authority

policy equals legal command

quarantine equals blame

AI proposal equals verified code

host runtime equals PMS-OS

network session equals distributed correctness

local security policy equals global distributed safety

side channels are eliminated by naming isolation

all future implementations are secure
```

These are not weaknesses of the architecture.

They are necessary claim boundaries.

They keep the runtime-security architecture strong, typed, implementable, and evidence-ready without converting architectural specification into PMS Base validation or universal security certification.

### 14.19 Positive Boundary Statement

The positive boundary is:

```text
PMS-STACK runtime security is a complete implementation-layer
architecture for structuring security-relevant runtime behavior through
operator-governed identity, authority, frames, boundaries, policies,
hooks, invariants, audit, trust, network integration, failure handling,
and scenarios.
```

This is strong because it is typed:

```text
architecture claim
implementation-layer claim
runtime-security claim
governance-architecture claim
evidence-backed artifact claim where artifacts exist
```

It is bounded because it does not convert architecture, implementation, tests, traces, audit, scenarios, PMS-RUST artifacts, or AI/tooling output into PMS Base validation.

### 14.20 Final Claim

The final claim of `06_runtime_security.md` is:

```text
PMS-STACK treats security as runtime structure. A runtime is
security-conformant to the extent that its declared profile preserves
operator-typed obligations for identity, authority, frames, boundaries,
policies, hooks, invariants, audit, trust, network behavior, failure
handling, and scenario acceptance.
```

This strengthens the PMS-STACK architecture claim.

Executable artifacts can strengthen the implementation-artifact claim.

Neither function as PMS Base validation.

### 14.21 Architectural Consequence

The consequence is:

```text
Security in PMS-STACK is not added after computation. It is how
operator-governed computation remains bounded, authorized, policy-valid,
auditable, recoverable, trust-aware, profile-declared, and committable.
```

`06_runtime_security.md` therefore completes the security/governance layer of PMS-STACK:

```text
identity says who acts
roles/capabilities say what authority exists
isolation says where action may reach
policy says what is admissible
hooks say where enforcement attaches
invariants say what must remain true
audit says what becomes evidence
trust anchors say how credentials become interpretable runtime trust
network security says how remote interaction enters local authority
failure handling says how abnormal behavior remains structured
scenarios say how claims become testable
claim boundary says what the document does and does not establish
```

This is the runtime-security architecture of PMS-STACK.

### 14.22 Document Boundary Statement

The correct boundary for `06_runtime_security.md` is:

```text
The PMS-STACK runtime-security document specifies implementation-layer
runtime-security / governance architecture: security as operator
structure, trust boundaries, identity and principal models, role and
capability systems, isolation models, policy definition and enforcement,
kernel policy hooks, runtime invariants, audit and compliance hooks, key
and trust-anchor management, network security integration, failure,
absence, and attack handling, security scenarios, PMS-RUST evidence
relations, AI/tooling boundaries, runtime profiles, and claim boundaries.

This is a runtime-security / governance architecture claim.

It does not claim completed runtime-security implementation, universal
security certification, production hardening, completed PMS-OS, completed
PMSL/PMS-IR, completed cryptographic subsystem, completed network stack,
completed distributed runtime, legal authority, moral authority, clinical
authority, forensic omniscience, tribunal status, trusted AI authority,
proof of all runtime behavior, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged execution, model/stateful validation, fail-closed
rejection paths, JSONL traces, golden fixtures, vFS/service boundaries,
bounded isolation-exit discipline, acceptance gates, and AI proposal
gating. It does not complete runtime security and does not validate PMS
Base.
```
