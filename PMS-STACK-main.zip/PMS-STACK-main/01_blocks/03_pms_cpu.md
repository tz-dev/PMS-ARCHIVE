---
document_id: PMS-STACK-DOC-03
title: "PMS Virtual CPU"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "virtual CPU / ISA architecture claim"
pms_base_status: "source of Δ–Ψ operator identity"
stack_status: "PMS-UM specialization into virtual CPU / ISA architecture"
chi_status: "PMS Base 1.3 Χ = Distance; PMS-CPU projects Χ as virtual CPU boundary, reachability, protection-domain, isolation-domain, and access-separation discipline"
depends_on:
  - "01_architecture.md"
  - "02_pms_um.md"
links_forward_to:
  - "04_pms_os.md"
  - "05_pmsl_pms_ir.md"
  - "08_relation_to_pms_rust.md"
  - "09_non_goals_and_claim_boundary.md"
---

# PMS Virtual CPU

## 1. Role of PMS-CPU in the Stack

PMS-CPU is the virtual CPU and ISA layer of PMS-STACK.

It refines PMS-UM into a register-, memory-, frame-, role-, capability-, policy-, boundary-, trap-, interrupt-, commit-, and memory-order-aware virtual processor architecture.

PMS-CPU does not claim fabricated hardware.

It specifies a virtual processor model whose instruction families are typed by the Δ–Ψ operator grammar and whose execution cycle preserves the PMS-STACK validity discipline defined in `01_architecture.md` and specialized by `02_pms_um.md`.

The central PMS-CPU claim is:

```text id="brh0dr"
PMS-CPU is a complete virtual CPU / ISA architecture specification whose
instructions are operator-typed projections of Δ–Ψ and whose execution
cycle is a PMS-UM instance over register and memory state.
```

Claim type:

```text id="uqg9sd"
virtual CPU / ISA architecture claim
```

Boundary:

```text id="0d4mpp"
This strengthens the PMS-STACK implementation-layer architecture claim.

It does not claim fabricated hardware.

It does not imply that a complete PMS-CPU simulator already exists.

It does not function as PMS Base validation.
```

PMS-CPU occupies the following position in the stack:

```text id="t0y9sk"
PMS Base Δ–Ψ operator grammar
    ↓
01_architecture.md
    ↓
02_pms_um.md
    ↓
03_pms_cpu.md
    ↓
04_pms_os.md / 05_pmsl_pms_ir.md / runtime / tooling layers
```

Its role is to make PMS-UM executable at the level of a virtual instruction set.

PMS-UM defines:

```text id="5lcaab"
operator-typed abstract machine execution
```

PMS-CPU specializes this into:

```text id="ph2so8"
registers
memory
program counter
stack pointer
frame pointer
status flags
frame register
role register
capability register
policy state
boundary / isolation-domain state
traps
interrupts
commit and fence behavior
memory-order constraints
binary instruction encoding
fetch–decode–execute semantics
```

### 1.1 PMS-CPU as PMS-UM Specialization

PMS-CPU is a specialized PMS-UM instance.

PMS-UM defines the abstract machine tuple:

```text id="s3dqel"
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

PMS-CPU instantiates this tuple as:

```text id="9kizw0"
M_CPU =
    (S_CPU, Γ_CPU, F_CPU, R_CPU, PSet_CPU, O,
     ISA, Π_CPU, δ_CPU, s₀_CPU, S_H_CPU)
```

where the shared operator alphabet remains:

```text id="b4edzp"
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The PMS-CPU program domain is:

```text id="l5a9k0"
Π_CPU
```

A concrete PMS-CPU program, instruction stream, or binary image is:

```text id="dqvwll"
π_CPU ∈ Π_CPU
```

The PMS-UM execution state is:

```text id="bq1qjp"
s⁺ = (s_c, f, r, P, m, ip)
```

PMS-CPU specializes this as:

```text id="j7zlx5"
s_cpu =
    (RF, MEM, R_pc, R_sp, R_fp, R_fr,
     R_role, R_cap, R_flag, R_iso, P, m)
```

or, grouped structurally:

```text id="niwbmz"
s_cpu = (s_core, f_cpu, r_cpu, P, m_cpu)
```

where:

```text id="fsw0ps"
s_core = (RF, MEM, R_pc, R_sp, R_fp, R_flag)

f_cpu  = (R_fr, FrameTable)

r_cpu  = (R_role, R_cap)

m_cpu  = (
    R_iso,
    interrupts,
    traps,
    ordering,
    history,
    transaction_state,
    boundary_metadata,
    pending_non_events,
    audit_metadata
)
```

Mapping from PMS-UM to PMS-CPU:

| PMS-UM component | PMS-CPU specialization                                 |
| ---------------- | ------------------------------------------------------ |
| `S`              | coherent virtual CPU states                            |
| `Γ`              | byte/word alphabet for register and memory values      |
| `F`              | frame identifiers and frame table                      |
| `R`              | CPU role, privilege, and capability modes              |
| `PSet`           | CPU policy sets                                        |
| `O`              | Δ–Ψ operator alphabet                                  |
| `Inst`           | PMS-CPU ISA instruction families                       |
| `Π`              | PMS-CPU programs / instruction streams / binary images |
| `δ`              | fetch–decode–execute transition relation               |
| `s₀`             | initial virtual CPU state                              |
| `S_H`            | halt, trap-halt, policy-halt, or terminal CPU states   |

This makes PMS-CPU a PMS-UM instance at the virtual ISA level.

It is concrete as architecture.

It is virtual as processor.

### 1.2 Virtual CPU Claim

PMS-CPU defines a virtual processor architecture.

It may support:

```text id="iwiqcr"
interpreter
emulator
simulator
JIT backend
compiler target
formal transition model
trace validator
binary decoder
runtime instrumentation layer
future hardware design input
```

but it does not itself assert:

```text id="n26vxz"
fabricated silicon
physical pipeline
cache-coherence circuitry
branch predictor
hardware timing model
manufactured MMU
physical interrupt controller
device bus protocol
```

The correct claim form is:

```text id="6mxjgr"
PMS-CPU specifies a virtual CPU / ISA architecture.
```

not:

```text id="iq20ta"
PMS-CPU is existing hardware.
```

and not:

```text id="g4m71m"
PMS-CPU validates PMS Base.
```

### 1.3 Design Goals

PMS-CPU has six design goals.

First, it realizes PMS-UM as a virtual processor architecture:

```text id="dc5thk"
PMS-UM abstract transition
    ↓
PMS-CPU fetch–decode–execute transition
```

Second, it maps each ISA family to one primary PMS operator class:

```text id="py9p99"
Instr = (mnemonic, op ∈ O, operands, constraints)
```

where:

```text id="pc9ldo"
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

Third, it makes virtual CPU execution operator-visible.

PMS-CPU instructions are not opaque opcodes. Decode exposes:

```text id="g8h6gx"
instruction bits
    → PMS_OP
    → ISA opcode
    → operands
    → operator-typed execution rule
```

Fourth, it provides a target for later PMS-STACK layers:

```text id="b36ccv"
PMS-OS kernel transitions
PMSL / PMS-IR lowering
runtime policy checks
trap and syscall handling
simulator execution
trace checking
artifact evidence paths
```

Fifth, it preserves PMS-STACK validity in the CPU layer:

```text id="sa1k4q"
dependency validity
frame validity
role / capability validity
boundary validity
commit validity
policy validity
trace validity
```

Sixth, it prepares a direct implementation path:

```text id="tfv6gp"
ISA model
binary encoding
fetch–decode–execute loop
CPU state
trap model
memory model
trace format
validation fixtures
simulator / emulator artifact
```

These are architecture goals.

They do not imply that all implementation targets already exist.

### 1.4 Operator-Typed Virtual CPU Execution

At PMS-CPU level, the Δ–Ψ operators appear as virtual processor mechanisms.

| Operator | PMS-CPU role                                                                 |
| -------- | ---------------------------------------------------------------------------- |
| Δ        | instruction decode, compare, classify, branch, address distinction           |
| ∇        | ALU operation, register update, memory write, load/store, call/return        |
| □        | frame selection, segment/frame binding, execution-context selection          |
| Λ        | wait, poll, idle, timeout, absent interrupt/event                            |
| Α        | micro-pattern, macro-instruction, loop or instruction template               |
| Ω        | privilege state, role register, capability register, authority check         |
| Θ        | instruction order, fence, sequencing, scheduler hint, progression marker     |
| Φ        | trap, interrupt, exception, handler entry, recontextualization               |
| Χ        | Distance projected as MMU boundary, isolation domain, ASID, protected region |
| Σ        | writeback, commit, transaction completion, memory barrier                    |
| Ψ        | policy check, invariant enforcement, trap-on-violation, halt-on-policy       |

This table is a virtual CPU projection of the operator grammar.

It does not redefine the operators.

The critical version boundary is:

```text id="l1s7ah"
PMS Base 1.3:
    Χ = Distance

PMS-CPU layer:
    Χ projects as MMU boundary, protected domain, isolation selector,
    address-space separation, sandbox state, access separation,
    reachability control, boundary metadata, and boundary-exit discipline.
```

### 1.5 PMS-CPU Trace Discipline

A PMS-CPU execution produces operator-readable traces.

For a decoded instruction:

```text id="i6c9f4"
Instr = (mnemonic, op, operands, constraints)
```

the primary trace contribution is:

```text id="rtcf62"
op
```

A full CPU cycle may also expose support operators:

```text id="alil3k"
Θ Δ Δ Ω Ψ □ Χ? op Σ? Φ?
```

where:

```text id="n31zaa"
Θ
    orders the cycle

Δ Δ
    fetches and decodes

Ω / Ψ
    check role and policy under the declared CPU profile

□
    binds frame context

Χ?
    checks boundary conditions where relevant

op
    executes the decoded instruction family

Σ?
    commits effects where required

Φ?
    handles trap, interrupt, exception, or fault
```

A concrete PMS-CPU execution produces:

```text id="sfx9b3"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="cnc4bp"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

For a declared machine, program, initial state, environment, and execution profile, the set of possible PMS-CPU runs is:

```text id="kmad0d"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="e99aiu"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

Thus:

```text id="z2tqag"
trace_cpu(...)
    denotes one concrete observed or selected CPU execution

Trace(...)
    denotes the set of possible CPU executions under a declared profile
```

The trace discipline is not merely logging.

It is the CPU-layer observability of PMS-STACK validity.

Trace evidence records observed execution.

It does not prove all possible CPU behavior.

It does not validate PMS Base.

### 1.6 PMS-CPU and the `h_UM→CPU` Homomorphism

PMS-CPU is related to PMS-UM through the domain-restricted mapping:

```text id="zh71rj"
h_UM→CPU : L_UM ⊆ L_PMS → ISA*
```

This mapping is valid only on its declared domain.

Not every PMS-valid word must have a direct CPU instruction sequence.

The domain consists of PMS-UM operator words meaningful as virtual CPU execution.

Validity preservation:

```text id="gzkb33"
w ∈ dom(h_UM→CPU) ∩ L_PMS
    ⇒ h_UM→CPU(w) is PMS-CPU ISA-valid
```

Policy preservation:

```text id="ob8fd5"
w ∈ dom(h_UM→CPU) ∩ L_PMS,Ψ
    ⇒ h_UM→CPU(w) satisfies PMS-CPU policy constraints
```

This prevents overclaim.

Correct:

```text id="kx70hq"
PMS-CPU refines the PMS-UM-executable subset into virtual ISA structure.
```

Incorrect:

```text id="xy937d"
Every PMS operator word automatically has a PMS-CPU binary encoding.
```

### 1.7 Relation to PMS-OS

PMS-CPU is the execution substrate from which PMS-OS receives typed machine events.

PMS-OS reads PMS-CPU traces as kernel-relevant structures:

```text id="pq23xr"
trap
syscall
interrupt
page/frame access
privilege transition
frame fault
boundary fault
commit/fence
policy violation
timer/non-event
```

At the CPU layer:

```text id="se19bh"
TRAP
    is Φ-readable

role transition
    is Ω-readable

handler frame entry
    is □-readable

boundary crossing
    is Χ-readable

boundary exit
    is ISO_EXIT-readable at the PMS-CPU layer

policy check
    is Ψ-readable

commit / writeback / barrier
    is Σ-readable
```

PMS-OS does not receive opaque hardware anomalies.

It receives operator-typed events suitable for kernel transition semantics.

The PMS-CPU syscall/trap convention defines the virtual CPU control-transfer mechanism for entering handler or kernel contexts.

It does not define the PMS-OS syscall ABI.

`04_pms_os.md` defines the dedicated OS-level syscall ABI on top of this CPU trap mechanism.

The required separation is:

```text id="a7z1c7"
ordinary PMS-CPU function calling convention
    ≠ PMS-CPU trap/syscall control-transfer convention
    ≠ PMS-OS syscall ABI
```

### 1.8 Relation to PMSL and PMS-IR

PMSL and PMS-IR may lower into PMS-CPU instruction families.

Representative mapping:

```text id="bqwz3w"
type distinction
    → Δ

effect / assignment
    → ∇

scope / module
    → □

absence / timeout case
    → Λ

macro / loop pattern
    → Α

role annotation
    → Ω

sequencing / fence
    → Θ

exception
    → Φ

sandbox / module boundary
    → Χ

commit block
    → Σ

policy block / invariant
    → Ψ
```

This is a compiler / runtime architecture relation.

It does not claim that a complete PMSL compiler already exists.

A PMSL-to-PMS-CPU lowering path must preserve:

```text id="abw9p1"
operator identity
dependency validity
frame discipline
role/capability discipline
boundary discipline
commit discipline
policy constraints
typed failure
traceability
```

### 1.9 Relation to Classical CPUs

PMS-CPU can be compared to classical virtual CPUs, register machines, bytecode VMs, WASM-like runtimes, and hardware ISAs.

The relation is architectural projection, not identity.

PMS-CPU includes familiar structures:

```text id="zzsntx"
registers
memory
program counter
stack pointer
flags
instructions
traps
interrupts
calling conventions
binary encoding
memory ordering
```

but it retypes those structures through Δ–Ψ.

Classical CPU component:

```text id="qsi8wh"
status flag
```

PMS-CPU reading:

```text id="z2t43z"
Δ / Φ / Ψ / Χ-visible execution metadata
```

Classical CPU component:

```text id="intz2g"
privilege mode
```

PMS-CPU reading:

```text id="yt2ydj"
Ω role / authority structure
```

Classical CPU component:

```text id="f1zj8p"
memory protection
```

PMS-CPU reading:

```text id="gb3zt8"
Χ as Distance projected into boundary and reachability discipline
```

Classical CPU component:

```text id="xpapqy"
trap
```

PMS-CPU reading:

```text id="yk7rw5"
Φ recontextualization
```

Thus:

```text id="q1uc6q"
PMS-CPU can express classical virtual CPU mechanisms as Δ–Ψ projections.
```

Boundary:

```text id="x1g0qo"
PMS-CPU is not identical to any existing ISA or hardware family.
```

### 1.10 Architectural Claim Boundary

The PMS-CPU architecture claim is strong and typed.

It states:

```text id="v8mv9l"
PMS-CPU defines a complete virtual CPU / ISA architecture specification
derived as a PMS-UM specialization over the Δ–Ψ operator grammar.
```

This includes:

```text id="sy660v"
CPU state
register model
memory model
frame model
role/capability model
boundary projection
policy model
operator-typed ISA
binary encoding
fetch–decode–execute cycle
trap and interrupt semantics
commit phase
memory consistency model
PMS-UM instance mapping
```

Boundary:

```text id="i9ibcw"
This is an implementation-layer architecture claim.

It does not claim fabricated hardware.

It does not imply that a complete PMS-CPU simulator already exists.

It does not validate PMS Base.

It does not prove PMS-OS, PMSL, runtime security, networking, or
distributed PMS-STACK correctness.
```

### 1.11 Role Invariants

```text id="bfrlwm"
CPU-R1: PMS-CPU is the virtual CPU / ISA layer of PMS-STACK

CPU-R2: PMS-CPU specializes PMS-UM into register and memory execution

CPU-R3: PMS-CPU instructions are operator-typed

CPU-R4: PMS-CPU state preserves core, frame, role, policy, boundary, and
        meta-state structure

CPU-R5: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-R6: Trace(...) denotes the set of possible PMS-CPU executions under a
        declared machine/program/profile

CPU-R7: concrete PMS-CPU traces belong to L_PMS or L_PMS,Ψ

CPU-R8: h_UM→CPU is domain-restricted

CPU-R9: PMS-CPU may serve as simulator, emulator, compiler target,
        JIT backend, trace validator, or formal transition model

CPU-R10: PMS-CPU does not claim fabricated hardware

CPU-R11: PMS Base Χ = Distance

CPU-R12: PMS-CPU projects Χ as virtual CPU boundary, reachability,
         protection, isolation-domain, and access-separation structure

CPU-R13: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
         instruction form

CPU-R14: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
         not a PMS-CPU architecture instruction

CPU-R15: PMS-CPU architecture claims strengthen PMS-STACK
         implementation-layer architecture, not PMS Base validation
```

### 1.12 Boundary Statement

The correct boundary for this chapter is:

```text id="ll6l32"
PMS-CPU is the virtual CPU / ISA layer of PMS-STACK. It specializes PMS-UM
into a register-, memory-, frame-, role-, capability-, boundary-, policy-,
trap-, commit-, and memory-order-aware virtual processor architecture.

This is a virtual CPU / ISA architecture claim.

It strengthens the PMS-STACK implementation-layer architecture claim.

It does not claim fabricated hardware, does not imply a completed PMS-CPU
simulator, and does not function as PMS Base validation.
```

---

## 2. CPU State Model

PMS-CPU state is the virtual processor specialization of the PMS-UM state and configuration model.

The PMS-UM execution state is:

```text id="wgadgb"
s⁺ = (s_c, f, r, P, m, ip)
```

PMS-CPU specializes this into:

```text id="b842bm"
s_cpu =
    (RF, MEM, R_pc, R_sp, R_fp, R_fr,
     R_role, R_cap, R_flag, R_iso, P, m)
```

or, grouped structurally:

```text id="j43ijp"
s_cpu = (s_core, f_cpu, r_cpu, P, m_cpu)
```

where:

```text id="4cdzqk"
s_core = (RF, MEM, R_pc, R_sp, R_fp, R_flag)

f_cpu  = (R_fr, FrameTable)

r_cpu  = (R_role, R_cap)

m_cpu  = (
    R_iso,
    interrupts,
    traps,
    ordering,
    history,
    transaction_state,
    boundary_metadata,
    boundary_stack,
    isolation_stack,
    sealed_boundary_state,
    pending_non_events,
    audit_metadata
)
```

The PMS-CPU program domain is:

```text id="zjhj8r"
Π_CPU
```

A concrete PMS-CPU program, instruction stream, or binary image is:

```text id="t94p1q"
π_CPU ∈ Π_CPU
```

The central state claim is:

```text id="qgbm08"
PMS-CPU state is virtual processor state typed by the PMS-STACK
state/configuration model: core register and memory state, frame state,
role/capability state, policy state, boundary state, and execution
meta-state.
```

Claim type:

```text id="wvmatg"
virtual CPU state-model architecture claim
```

Boundary:

```text id="mugbf8"
This is a virtual CPU state model.

It is not a physical microarchitecture.

It does not define transistor layout, cache circuitry, pipeline hardware,
or fabricated processor state.

It does not validate PMS Base.
```

### 2.1 Core Processor State

The core processor state is:

```text id="qt5wjw"
s_core = (RF, MEM, R_pc, R_sp, R_fp, R_flag)
```

| Component | Meaning                                       |
| --------- | --------------------------------------------- |
| `RF`      | general-purpose register file                 |
| `MEM`     | virtual memory map                            |
| `R_pc`    | program counter / instruction pointer         |
| `R_sp`    | stack pointer                                 |
| `R_fp`    | frame pointer, if distinct from stack pointer |
| `R_flag`  | condition/status flags                        |

The register file may be modeled as:

```text id="11g0o7"
RF : RegisterName → Word
```

or as a finite register vector:

```text id="2k1o6o"
RF = { R0, R1, …, R(n−1) }
```

The memory map may be modeled as:

```text id="z44khh"
MEM : Address → Byte
```

or, at a word-level abstraction:

```text id="jywzop"
MEM : Address → Word
```

The core processor state is where ordinary computation occurs.

But PMS-CPU does not treat this state as unstructured.

Every read, write, branch, call, trap, commit, and policy effect is interpreted through the relevant operator discipline.

### 2.2 Frame State

The CPU frame state is:

```text id="ct79a7"
f_cpu = (R_fr, FrameTable)
```

where:

```text id="xwjtik"
R_fr
```

is the active frame register, and:

```text id="7z3d45"
FrameTable : FrameId → FrameDescriptor
```

maps frame identifiers to frame descriptors.

A frame descriptor may be written:

```text id="w5w4wy"
FrameDescriptor = (base, size, type, perms, policy_domain, boundary_domain)
```

Minimal descriptor:

```text id="846nyw"
Frame(fid) = (base, size, type, perms)
```

Common frame types:

```text id="ryxsjx"
CODE
DATA
STACK
MMIO
KERNEL
USER
HANDLER
TRANSACTION
SANDBOX
```

The □ operator appears at PMS-CPU level as:

```text id="njcyex"
frame selection
execution-context binding
segment or region binding
stack-frame binding
handler-frame entry
frame-relative memory interpretation
```

A frame-sensitive instruction is valid only when:

```text id="zgjjso"
R_fr selects a valid frame
∧ the frame type supports the instruction
∧ frame permissions allow the requested access
∧ active role and policy permit the frame relation
```

Frame state gives meaning to addresses, control-flow targets, stack entries, local variables, handler contexts, and memory permissions.

### 2.3 Role and Capability State

The CPU role/capability state is:

```text id="gk6bxu"
r_cpu = (R_role, R_cap)
```

where:

```text id="gwkz0k"
R_role
```

records the current role or privilege mode, and:

```text id="v16c0q"
R_cap
```

records active capability state.

Typical roles include:

```text id="0jhdy3"
USER
SYSTEM
SUPERVISOR
HYPERVISOR
KERNEL
HANDLER
VERIFIER
```

Capability state may include:

```text id="ot4ik2"
read capability
write capability
execute capability
frame-entry capability
policy-update capability
trap capability
boundary-transition capability
boundary-exit capability
commit capability
device/MMIO capability
```

The Ω operator appears at PMS-CPU level as:

```text id="ak5xv8"
role selection
privilege state
capability check
authority relation
protected instruction gate
user/kernel asymmetry
handler authority
boundary-exit authority
```

A protected CPU instruction requires:

```text id="uqjx3m"
role_ok(R_role, I)
∧ capability_ok(R_cap, I)
∧ policy_ok(P, s_cpu, I)
```

Ω does not perform the protected action.

It establishes whether the action is authorized.

### 2.4 Policy State

The active policy state is:

```text id="abn0lf"
P
```

PMS-CPU may also expose an optional policy-domain register:

```text id="q19xws"
R_pol
```

Policy state supports Ψ-family behavior:

```text id="c7vt36"
policy installation
policy activation
policy check
policy denial
trap-on-policy
halt-on-policy
commit restriction
boundary restriction
boundary-exit restriction
memory-order restriction
```

A PMS-CPU instruction is valid only if:

```text id="mn1e4l"
policy_ok(P, s_cpu, I) = true
```

Policy may constrain:

```text id="7k5bbw"
instruction classes
memory regions
role transitions
frame entry
trap entry
trap return
interrupt delivery
boundary crossing
boundary exit
transaction commit
speculation
reordering
memory visibility
user/kernel crossing
```

Ψ changes the future valid execution language:

```text id="mfm8jh"
L_PMS,Ψ ⊆ L_PMS
```

At PMS-CPU level this means:

```text id="n7oqwm"
active policy restricts future valid instruction traces.
```

### 2.5 Boundary and Distance Projection State

PMS Base 1.3 defines:

```text id="0tuhbm"
Χ = Distance
```

PMS-CPU does not redefine Χ.

PMS-CPU projects Χ into virtual processor boundary state.

The isolation-domain selector is:

```text id="j1l3b8"
R_iso
```

Boundary metadata may also live in:

```text id="7bcxfh"
m_cpu.boundary_metadata
m_cpu.boundary_graph
m_cpu.reachability
m_cpu.boundary_stack
m_cpu.isolation_stack
m_cpu.sealed_boundary_state
m_cpu.domain_permissions
```

At PMS-CPU level, Χ may appear as:

```text id="expu2o"
MMU-like boundary
address-space identity
ASID-like selector
protected execution domain
sandbox context
access-separation region
reachability restriction
transaction boundary
kernel/user boundary
handler boundary
MMIO boundary
boundary-entry state
boundary-exit state
```

The rule is:

```text id="ghmz51"
PMS Base Χ:
    Distance

PMS-CPU Χ:
    Distance projected as virtual CPU boundary, reachability,
    protection-domain, isolation-domain, and access-separation state.
```

A boundary-sensitive transition is valid only when:

```text id="lfe04k"
boundary_ok(R_iso, boundary_metadata, f_cpu, r_cpu, P, I) = true
```

This check must remain frame-grounded, role-constrained, and policy-constrained.

Boundary exit is represented at the PMS-CPU ISA level by:

```text id="on3oso"
ISO_EXIT
```

`ISO_EXIT` is valid only when an active boundary or isolation context exists.

The active context may be recorded in:

```text id="8isj4i"
R_iso
m_cpu.boundary_metadata
m_cpu.boundary_stack
m_cpu.isolation_stack
```

Unbalanced exit is invalid:

```text id="k6fxwj"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

An unbalanced exit must produce a typed outcome under the declared PMS-CPU profile:

```text id="efkhcu"
Χ violation
Φ trap
Ψ denial
Σ audit / rejection commit
halt
stuck
```

A sealed isolation context has a stricter rule:

```text id="sf1r8d"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared policy and active boundary context:

```text id="tubgid"
valid exit
closure
audit
rollback
commit
```

Sealing a context is not the same as trapping execution forever.

### 2.6 Meta-State

The PMS-CPU meta-state is:

```text id="qqdmiv"
m_cpu = (
    R_iso,
    interrupts,
    traps,
    ordering,
    history,
    transaction_state,
    boundary_metadata,
    boundary_stack,
    isolation_stack,
    sealed_boundary_state,
    pending_non_events,
    audit_metadata
)
```

It may contain:

| Meta-state component    | Meaning                                                            |
| ----------------------- | ------------------------------------------------------------------ |
| `ordering`              | Θ-related progression, fence, sequence, or pipeline-order metadata |
| `interrupts`            | pending interrupt state                                            |
| `traps`                 | current trap cause, handler state, nesting depth                   |
| `history`               | operator trace history                                             |
| `transaction_state`     | staged writes, commit state, abort state                           |
| `boundary_metadata`     | Χ-projected domain and reachability metadata                       |
| `boundary_stack`        | active boundary contexts                                           |
| `isolation_stack`       | active isolation contexts relevant to `ISO_EXIT`                   |
| `sealed_boundary_state` | contexts sealed against further expansion                          |
| `pending_non_events`    | Λ wait, timeout, poll, or idle state                               |
| `audit_metadata`        | trace, diagnostic, or evidence metadata                            |
| `speculation_state`     | optional speculative execution metadata                            |
| `store_buffer`          | optional delayed-write state                                       |
| `commit_log`            | optional Σ commit history                                          |

The meta-state records execution structure that is not ordinary register or memory data.

It is where PMS-CPU keeps the information needed for:

```text id="x0o8m8"
dependency validity
ordering
trap handling
interrupt dispatch
boundary checks
boundary exit
sealed isolation checks
policy checks
transaction commit
memory visibility
typed failure
trace emission
```

The meta-state may contain clocks, timestamps, counters, deadlines, or timer values as data.

Θ is not physical time.

Θ orders transitions that may read or update such data.

### 2.7 Program Counter and Instruction Position

The program counter is:

```text id="w7utq0"
R_pc
```

It is the PMS-CPU specialization of the PMS-UM instruction pointer `ip`.

Ordinary sequential update:

```text id="4iy06f"
R_pc' = R_pc + instruction_width
```

For a fixed 32-bit instruction encoding:

```text id="0bjm12"
R_pc' = R_pc + 4
```

Control-flow instructions may set:

```text id="mb6uzr"
R_pc' = branch_target
R_pc' = call_target
R_pc' = trap_handler
R_pc' = interrupt_vector_entry
R_pc' = return_address
R_pc' = halt
```

The program counter is not merely a numeric address.

It is ordered execution state governed by:

```text id="s3jfpx"
Θ ordering
Δ branch distinction
□ frame validity
Ω authority
Χ boundary validity
Ψ policy constraints
Φ recontextualization
Σ return/commit discipline where relevant
```

An `R_pc` value is valid only if it points into an executable frame and remains permitted by active role, boundary, and policy state.

### 2.8 Register File

The register file is:

```text id="5kufma"
RF : RegisterName → Word
```

General-purpose registers hold:

```text id="j3w2jl"
operands
results
temporary values
function arguments
return values
intermediate computation
```

Typical convention:

```text id="t8w173"
R0–R3
    argument / caller-saved registers

R4–R7
    callee-saved registers

R_tmpN
    temporary registers, profile-dependent
```

The operator reading of register operations is:

| Register operation               | PMS operator reading           |
| -------------------------------- | ------------------------------ |
| select register                  | Δ                              |
| compare register                 | Δ                              |
| write register                   | ∇                              |
| save/restore register            | ∇ under □ frame discipline     |
| branch on register/flag          | Δ                              |
| role/capability register update  | Ω                              |
| flag update                      | Δ / ∇ depending on instruction |
| trap flag update                 | Φ                              |
| boundary flag update             | Χ projection                   |
| boundary-exit flag update        | Χ / Φ / Ψ depending on profile |
| policy flag update               | Ψ                              |
| commit of staged register effect | Σ                              |

A PMS-CPU instruction that modifies a general-purpose register is usually an ∇-family instruction.

If the target register carries frame, role, boundary, or policy structure, the instruction belongs to the corresponding operator family or must preserve that family’s constraints.

### 2.9 Memory State

The memory component is:

```text id="b9zd17"
MEM : Address → Byte
```

or:

```text id="7skcbq"
MEM : Address → Word
```

depending on the chosen abstraction.

PMS-CPU memory is frame-aware and boundary-aware.

Memory access is not valid merely because an address can be computed.

A memory operation requires:

```text id="mz1n5e"
addr ∈ Frame(R_fr)
∧ permissions allow requested access
∧ Ω authorizes access
∧ Χ boundary permits reachability
∧ Ψ permits access
```

A load is operator-readable as:

```text id="pgojg8"
Δ distinguish address / frame / permission
Ω check authority if required
Χ check reachability if boundary-sensitive
Ψ check policy
∇ transfer value into register
```

A store is operator-readable as:

```text id="xh55fo"
Δ distinguish address / target
□ bind active frame
Ω authorize write
Χ check boundary
Ψ permit mutation
∇ produce write
Σ commit if required by transaction or memory model
```

This state model makes memory safety, frame access, and boundary validity architectural rather than external add-ons.

### 2.10 Status and Flag State

The status register may be modeled as:

```text id="4mtnid"
R_flag = (Z, T, C, P, I, H, ...)
```

Relevant flags include:

| Flag | Meaning                                | Operator relation          |
| ---- | -------------------------------------- | -------------------------- |
| `Z`  | zero / equality distinction            | Δ                          |
| `C`  | carry / overflow / arithmetic metadata | Δ / ∇                      |
| `T`  | trap-pending status                    | Φ                          |
| `P`  | policy-violation indicator             | Ψ                          |
| `I`  | isolation/boundary indicator           | Χ                          |
| `H`  | halt or terminal marker                | Ψ / Σ depending on profile |

A flag is not an untyped side effect.

It is execution metadata that participates in branching, trap handling, policy handling, and boundary-sensitive execution.

Examples:

```text id="vtzney"
CMP
    may update Z through Δ

ADD
    may update C through ∇ result metadata

CHK_POL
    may update P through Ψ

TRAP
    may update T through Φ

ISO_ENTER
    may update I through Χ

ISO_EXIT
    may update I through Χ when an active boundary context exists
```

### 2.11 Interrupt and Trap State

Interrupt and trap state belongs to `m_cpu`.

It may include:

```text id="i7km1r"
pending_interrupts
interrupt_enable
trap_pending
trap_cause
trap_depth
trap_frame
handler_table
return_frame
return_role
return_pc
syscall_trap_state
```

At CPU level:

```text id="ou6xd6"
interrupt
    is Φ-readable

trap
    is Φ-readable

syscall
    is Φ + Ω + □ + Χ + Ψ readable as CPU control transfer

fault
    is Φ-readable, often triggered by Δ / □ / Ω / Χ / Ψ failure

exception return
    is Φ with restoration and Σ-readable integration discipline
```

Trap state is not outside ordinary PMS-CPU execution.

It is part of the operator-typed state model.

The PMS-CPU syscall/trap state models virtual CPU control transfer into a handler or kernel context.

It does not define the PMS-OS syscall ABI.

The OS-level syscall ABI is specified by `04_pms_os.md` as a dedicated kernel-service ABI on top of the PMS-CPU trap mechanism.

### 2.12 Transaction and Commit State

Transaction and commit state belongs to `m_cpu`.

It may include:

```text id="did7ko"
transaction_active
transaction_log
store_buffer
pending_writeback
committable_state
commit_log
abort_state
```

Σ-family instructions operate on this state.

Examples:

```text id="gkxch4"
TX_BEGIN
    creates staged transaction context

TX_COMMIT
    integrates staged changes

TX_ABORT
    closes or discards staged state

COMMIT_BARRIER
    forces ordered visibility
```

A commit is valid only when:

```text id="j55nzq"
committable prior structure exists
∧ frame conditions are coherent
∧ role/capability permits integration
∧ boundary conditions permit visibility
∧ active policy permits commit
∧ ordering constraints are satisfied
```

A boundary-sensitive commit must also respect sealed-isolation constraints:

```text id="v5j5k4"
sealed isolation
    forbids further reachability growth

sealed isolation
    may still permit valid closure, audit, rollback, or commit
    under declared policy
```

This commit discipline prevents PMS-CPU from treating writeback, return, trap exit, transaction close, or memory visibility as untyped completion.

### 2.13 CPU Configuration

A PMS-CPU configuration may be written:

```text id="ieeqkv"
κ_cpu = (s_cpu, π_CPU, R_pc, h_cpu, e_cpu)
```

where:

```text id="c61tbx"
π_CPU ∈ Π_CPU
```

| Component | Meaning                                                                 |
| --------- | ----------------------------------------------------------------------- |
| `s_cpu`   | current virtual CPU state                                               |
| `π_CPU`   | concrete instruction memory, program image, binary image, or ISA stream |
| `R_pc`    | current program counter                                                 |
| `h_cpu`   | operator history / concrete trace prefix                                |
| `e_cpu`   | optional environment: interrupts, device events, host input             |

The program domain remains:

```text id="gd1lbm"
Π_CPU
```

The concrete program is:

```text id="vxkb6x"
π_CPU ∈ Π_CPU
```

A concrete PMS-CPU execution produces:

```text id="d2tc4f"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="u2w9ou"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

For a declared machine, program, initial state, environment, and profile:

```text id="cnlng0"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="u1o1wj"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

A PMS-CPU configuration is well-formed when:

```text id="xngm5z"
s_cpu is coherent
∧ π_CPU ∈ Π_CPU
∧ R_pc points to a valid instruction position or terminal state in π_CPU
∧ h_cpu ∈ L_PMS or h_cpu ∈ L_PMS,Ψ
∧ active frame/role/policy/boundary state is coherent
∧ pending traps, interrupts, commits, and non-events are typed
∧ environment events enter through operator-typed mechanisms
```

This configuration form aligns PMS-CPU with PMS-UM while retaining virtual processor structure.

### 2.14 CPU State Coherence

A PMS-CPU state is coherent when:

```text id="mlq8yg"
R_pc points into an executable frame

R_sp points into a stack frame

R_fp is coherent with the active stack frame when used

R_fr selects a valid frame

R_role is a valid role

R_cap is valid for R_role

R_iso is valid for the active boundary domain

P is a valid active policy set

R_flag is internally consistent

MEM access respects frame, role, boundary, and policy constraints

m_cpu is consistent with frame, role, policy, boundary, trap,
interrupt, transaction, and ordering state

boundary_stack / isolation_stack state is balanced where profile requires it

sealed_boundary_state forbids further entry, expansion, or reachability
growth while preserving valid exit, closure, audit, rollback, or commit
where declared
```

A PMS-CPU transition may proceed only from a coherent state, or from a state that can be recontextualized through Φ into a valid handler or recovery path.

If coherence fails, the CPU must produce a typed outcome:

```text id="w9g53q"
Φ trap
Ψ denial
Χ violation
Λ non-event
Σ audit / rejection commit
halt
stuck
```

The architecture does not allow silent validity.

### 2.15 State Validity Predicate

A compact predicate is:

```text id="bjjh1c"
valid_cpu_state(s_cpu) iff
    core_valid(s_core)
    ∧ frame_valid(f_cpu)
    ∧ role_valid(r_cpu)
    ∧ policy_valid(P)
    ∧ boundary_valid(R_iso, m_cpu)
    ∧ boundary_stack_valid(m_cpu)
    ∧ sealed_boundary_valid(m_cpu)
    ∧ trap_state_valid(m_cpu)
    ∧ transaction_state_valid(m_cpu)
    ∧ ordering_state_valid(m_cpu)
    ∧ history_valid(m_cpu.history)
```

A transition step additionally requires instruction validity:

```text id="d3dzxs"
valid_cpu_step(s_cpu, I, s_cpu') iff
    valid_cpu_state(s_cpu)
    ∧ op(I) ∈ O
    ∧ operands_valid(I, s_cpu)
    ∧ frame_valid(I, s_cpu)
    ∧ role_ok(I, s_cpu)
    ∧ boundary_ok(I, s_cpu)
    ∧ commit_ok(I, s_cpu)
    ∧ policy_ok(P, s_cpu, I)
    ∧ postcondition_valid(I, s_cpu, s_cpu')
    ∧ valid_cpu_state(s_cpu')
```

For boundary exit:

```text id="a2fo6d"
valid_cpu_step(s_cpu, ISO_EXIT, s_cpu') iff
    valid_cpu_state(s_cpu)
    ∧ active_boundary_context(s_cpu) = true
    ∧ role_ok(ISO_EXIT, s_cpu)
    ∧ policy_ok(P, s_cpu, ISO_EXIT)
    ∧ profile_allows(profile, ISO_EXIT)
    ∧ postcondition_valid(ISO_EXIT, s_cpu, s_cpu')
    ∧ valid_cpu_state(s_cpu')
```

Unbalanced `ISO_EXIT` is invalid:

```text id="gbt9tm"
active_boundary_context(s_cpu) = false
    ⇒ ISO_EXIT invalid
```

This notation is architectural helper notation.

Concrete simulators may implement it as explicit checks, fused checks, traps, typed rejections, or proof obligations.

Validation here means acceptance or rejection under a declared schema, model, profile, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 2.16 State Model Invariants

```text id="lmphdn"
CPU-S1: PMS-CPU state specializes PMS-UM execution state

CPU-S2: PMS-CPU state is virtual processor state, not physical
        microarchitecture

CPU-S3: Π_CPU denotes the PMS-CPU program domain

CPU-S4: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
        program image, or binary image

CPU-S5: core state contains registers, memory, program counter, stack/frame
        pointers, and flags

CPU-S6: frame state records active □ context through R_fr and FrameTable

CPU-S7: role/capability state records Ω authority through R_role and R_cap

CPU-S8: policy state records active Ψ constraints through P and optional R_pol

CPU-S9: PMS Base Χ = Distance

CPU-S10: PMS-CPU projects Χ as virtual CPU boundary, reachability,
         isolation-domain, protection-domain, and access-separation state

CPU-S11: R_iso is PMS-CPU isolation-domain state produced by the PMS-CPU
         projection of Χ; it is not PMS Base Χ itself

CPU-S12: ISO_EXIT is valid only when an active boundary / isolation context
         exists

CPU-S13: unbalanced ISO_EXIT is invalid

CPU-S14: sealed isolation forbids entry, expansion, and reachability growth
         while permitting valid exit, closure, audit, rollback, or commit
         under declared profile

CPU-S15: meta-state records ordering, interrupts, traps, history,
         transactions, boundary metadata, boundary stack, isolation stack,
         sealed boundary state, non-events, audit, and optional speculation
         state

CPU-S16: valid CPU state requires coherence across core, frame, role,
         boundary, policy, trap, transaction, and ordering state

CPU-S17: CPU configurations preserve operator history in L_PMS or L_PMS,Ψ

CPU-S18: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-S19: Trace(...) denotes the set of possible PMS-CPU executions under a
         declared machine/program/profile

CPU-S20: invalid state must become typed failure, trap, denial, halt, or
         recovery path, not silent validity

CPU-S21: the CPU state model strengthens PMS-CPU architecture claims and
         does not validate PMS Base
```

### 2.17 Architectural Consequence

The PMS-CPU state model makes virtual processor execution operator-visible.

The state is not merely:

```text id="b7bvaz"
registers + memory
```

It is:

```text id="em3chu"
registers
+ memory
+ program counter
+ stack/frame pointers
+ condition/status flags
+ frame context
+ role/capability context
+ policy context
+ boundary / Distance-projection context
+ boundary-exit context
+ sealed-isolation state
+ ordering/trap/interrupt/commit/non-event/audit meta-state
```

This is the state substrate on which the PMS-CPU ISA, calling convention, trap model, binary encoding, fetch–decode–execute cycle, commit phase, and memory consistency model are defined.

### 2.18 Boundary Statement

The correct boundary for this chapter is:

```text id="d1x77g"
The PMS-CPU state model defines virtual processor state as a PMS-UM
specialization over registers, memory, frames, roles, capabilities,
policies, boundary state, traps, interrupts, commits, ordering metadata,
operator history, and concrete PMS-CPU program state π_CPU ∈ Π_CPU.

This is a virtual CPU state-model architecture claim.

It does not specify physical microarchitecture, fabricated hardware, or
completed simulator implementation, and it does not validate PMS Base.
```

---

## 3. Registers, Memory, Frames, Roles

PMS-CPU exposes register, memory, frame, role, capability, boundary, and policy state as part of one virtual processor model.

The design principle is:

```text id="gnszff"
CPU state is not only data storage.

CPU state is operator-addressable execution structure.
```

Registers, memory, frames, roles, capabilities, policy state, and boundary state are therefore not separate ad hoc subsystems.

They are PMS-CPU projections of the PMS-UM state model into a virtual ISA architecture.

The active PMS-CPU program is:

```text id="jx1d7f"
π_CPU ∈ Π_CPU
```

where:

```text id="ep5vft"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images
π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The core grouping is:

```text id="mm3tuw"
s_cpu =
    (RF, MEM, R_pc, R_sp, R_fp, R_fr,
     R_role, R_cap, R_flag, R_iso, P, m)
```

where:

| Component | PMS-CPU role                                                                                                      |
| --------- | ----------------------------------------------------------------------------------------------------------------- |
| `RF`      | general-purpose register file                                                                                     |
| `MEM`     | virtual memory                                                                                                    |
| `R_pc`    | program counter                                                                                                   |
| `R_sp`    | stack pointer                                                                                                     |
| `R_fp`    | frame pointer                                                                                                     |
| `R_fr`    | active frame register                                                                                             |
| `R_role`  | active role or privilege mode                                                                                     |
| `R_cap`   | active capability state                                                                                           |
| `R_flag`  | condition/status flags                                                                                            |
| `R_iso`   | isolation/domain selector, PMS-CPU state produced by the Χ projection                                             |
| `P`       | active policy state                                                                                               |
| `m`       | meta-state for ordering, traps, interrupts, commits, non-events, history, boundary metadata, and sealed isolation |

The central claim is:

```text id="rqmzxp"
PMS-CPU register, memory, frame, role, capability, boundary, and policy
structures are virtual processor mechanisms that preserve Δ–Ψ operator
semantics at CPU level.
```

Claim type:

```text id="mdvd77"
virtual CPU structural-state architecture claim
```

Boundary:

```text id="s0ka1k"
This specifies logical CPU state roles.

It does not require a particular physical register file, cache hierarchy,
MMU circuit, interrupt controller, or hardware privilege implementation.

It does not validate PMS Base.
```

### 3.1 Register Classes

PMS-CPU distinguishes general-purpose registers from special-purpose registers.

General-purpose registers hold ordinary computation values:

```text id="45xvev"
R0, R1, …, R(n−1)
```

They are used for:

```text id="bk7nmv"
arithmetic and logic
load/store operands
function arguments
return values
temporaries
intermediate computation
```

Special-purpose registers hold execution structure:

| Symbol   | Meaning                                                               |
| -------- | --------------------------------------------------------------------- |
| `R_pc`   | program counter / instruction pointer                                 |
| `R_sp`   | stack pointer                                                         |
| `R_fp`   | frame pointer, if distinct from stack pointer                         |
| `R_fr`   | active frame register, □ context selector                             |
| `R_role` | current role or privilege state, Ω                                    |
| `R_cap`  | capability register, Ω-related authority state                        |
| `R_flag` | condition and status flags                                            |
| `R_iso`  | isolation-domain selector, PMS-CPU state produced by the Χ projection |
| `R_pol`  | optional policy-domain register for fast Ψ checks                     |
| `R_tmpN` | temporary registers, architecture-dependent                           |

The special registers make PMS-CPU operator-aware.

A classical CPU exposes program counters, stack pointers, flags, privilege modes, and memory protection.

PMS-CPU retypes these structures through Δ–Ψ.

| CPU structure       | PMS operator role                               |
| ------------------- | ----------------------------------------------- |
| program counter     | Θ / Δ / ∇ control progression                   |
| stack pointer       | □ / ∇ frame-relative state                      |
| frame pointer       | □ frame-local reference                         |
| frame register      | □ active context                                |
| role register       | Ω active authority                              |
| capability register | Ω permitted operations                          |
| flag register       | Δ result distinction, Φ / Ψ / Χ status          |
| isolation register  | Χ projection state; PMS Base Χ remains Distance |
| policy register     | Ψ fast policy context                           |

### 3.2 General-Purpose Register Semantics

The general-purpose register file is:

```text id="kpbxns"
RF : RegisterName → Word
```

A register may be:

```text id="0mvc2o"
selected by Δ
compared by Δ
written by ∇
saved/restored under □ frame discipline
constrained by Ω if it carries authority-sensitive data
constrained by Χ if it exposes boundary-sensitive data
constrained by Ψ if policy restricts use
committed by Σ if part of a transaction, call boundary, or staged update
```

Examples:

```asm id="bqfhpv"
CMP   R1, R2      ; Δ
MOV   R1, R2      ; ∇
ADD   R1, R2      ; ∇
PUSH  R4          ; ∇ under stack/frame discipline
POP   R4          ; ∇ under stack/frame discipline
```

A general-purpose register update is normally an ∇ transition:

```text id="ysgtxf"
RF'[Rdst] = value
```

The update is valid only if:

```text id="wz5n2z"
target register is distinguished
∧ active frame permits the operation
∧ active role permits the operation where protected
∧ active boundary state permits visibility where relevant
∧ active policy permits the operation
```

A concrete PMS-CPU run over a concrete program updates registers as part of:

```text id="wc1tmh"
trace_cpu(M_CPU, π_CPU, s₀_CPU)
```

The set of possible runs under a declared profile is:

```text id="usl09u"
Trace(M_CPU, π_CPU, s₀_CPU)
```

These notations must not be collapsed.

### 3.3 Status and Flag Registers

PMS-CPU uses status flags for distinction, branching, traps, policy violations, and boundary-sensitive execution.

A status register may be modeled as:

```text id="sgbb0i"
R_flag = (Z, T, C, P, I, H, ...)
```

Relevant flags include:

| Flag | Meaning                          | Operator relation          |
| ---- | -------------------------------- | -------------------------- |
| `Z`  | result-zero / equality flag      | Δ                          |
| `T`  | trap-pending flag                | Φ                          |
| `C`  | carry / overflow flag            | Δ / ∇ result metadata      |
| `P`  | policy-violation indicator       | Ψ                          |
| `I`  | isolation-boundary flag          | Χ projection               |
| `H`  | halt / terminal condition marker | Ψ / Σ depending on profile |

Architectures may represent these flags as a single status word or as separate logical flags.

Flag updates are part of operator execution.

Examples:

```text id="c9e65f"
CMP
    may set Z through Δ

ADD
    may set C through ∇ result metadata

CHK_POL
    may set P through Ψ

TRAP
    may set T through Φ

ISO_ENTER
    may set I through Χ

ISO_EXIT
    may update I through Χ only when an active boundary / isolation context
    exists under the declared profile
```

A branch instruction reads flag state through Δ.

A trap dispatcher reads trap flags through Φ.

A policy handler reads policy flags through Ψ.

A boundary handler reads isolation/boundary flags through Χ.

An unbalanced `ISO_EXIT` must not silently clear isolation flags.

It is an invalid boundary-exit transition and must be represented through typed CPU behavior.

### 3.4 Program Counter and Control Registers

The program counter is:

```text id="f4iv9s"
R_pc
```

It realizes the PMS-UM instruction pointer at CPU level.

Ordinary update:

```text id="ar4tjv"
R_pc' = R_pc + instruction_width
```

For the reference fixed-width encoding:

```text id="l2s8vq"
R_pc' = R_pc + 4
```

Control-flow instructions may alter `R_pc`.

| Control event              | Operator reading                                             |
| -------------------------- | ------------------------------------------------------------ |
| branch after comparison    | Δ                                                            |
| jump                       | Δ / ∇ depending on encoding                                  |
| call                       | ∇ with frame/calling-convention discipline                   |
| return                     | ∇ with frame lifecycle and Σ-readable integration discipline |
| trap entry                 | Φ                                                            |
| interrupt dispatch         | Φ                                                            |
| exception return           | Φ with restoration and integration semantics                 |
| policy halt                | Ψ                                                            |
| commit-controlled transfer | Σ where return/commit boundary applies                       |
| boundary exit              | Χ through `ISO_EXIT`, with Φ / Ψ outcome if invalid          |

The program counter is not a raw pointer.

It is executable control state governed by:

```text id="yc841h"
Θ ordering
Δ distinction
□ frame validity
Ω role/capability validity
Χ boundary validity
Ψ policy constraints
Φ recontextualization
Σ commit/return discipline where relevant
```

### 3.5 Stack Pointer and Frame Pointer

The stack pointer is:

```text id="df21ug"
R_sp
```

The optional frame pointer is:

```text id="zqgaos"
R_fp
```

They are frame-relative control registers.

Stack and frame pointer validity requires:

```text id="c1v3ev"
R_sp points into an active stack frame
R_fp is coherent with the active call frame when used
R_fr selects a frame compatible with stack operations
role/capability state permits the stack operation
boundary state permits stack reachability
policy permits call/return behavior
```

Stack operations are usually ∇-family effects under □ discipline:

```asm id="v0zc2k"
PUSH Rsrc
POP  Rdst
```

A function prolog / epilog is not just register movement.

It preserves:

```text id="l4brpl"
frame structure
saved register discipline
return address validity
role state
boundary state
policy invariants
commit / integration points
```

This prepares the calling convention in Section 6.

### 3.6 Memory Model at Register/Frame Level

PMS-CPU memory is modeled as:

```text id="eu06gh"
MEM : Address → Byte
```

or:

```text id="657l3u"
MEM : Address → Word
```

Memory is partitioned into frames.

A frame descriptor has the form:

```text id="x05f5u"
Frame(fid) = (base, size, type, perms)
```

where `type` may include:

```text id="1v411n"
CODE
DATA
STACK
MMIO
KERNEL
USER
HANDLER
SANDBOX
TRANSACTION
```

A memory access is valid only when:

```text id="e2umze"
addr ∈ Frame(R_fr)
∧ perms allow requested access
∧ Ω authorizes access
∧ Χ boundary permits reachability
∧ Ψ permits access
```

A load may be read as:

```text id="u26noh"
LOAD Rdst, FR+Rn
```

with operator structure:

```text id="lf55im"
Δ distinguish address / frame / permission
Ω check authority if required
Χ check reachability if boundary-sensitive
Ψ check policy if required
∇ read value into register
```

A store may be read as:

```text id="njer9z"
STORE FR+Rn, Rsrc
```

with operator structure:

```text id="c2na5d"
Δ distinguish address / target
□ bind active frame
Ω authorize write
Χ check boundary
Ψ permit mutation
∇ produce write
Σ commit if required by transaction or memory model
```

Thus load/store are not pure memory effects.

They are operator-constrained transitions.

### 3.7 Frame Register and Frame Table

The active frame register is:

```text id="5mzrds"
R_fr
```

It selects the current □ context.

The frame table is:

```text id="oqao6z"
FrameTable : FrameId → FrameDescriptor
```

PMS-CPU frame operations include:

```asm id="pj0m1d"
FRM_ENTER  fid
FRM_LEAVE
FRM_SET    FR, Rsrc
FRM_CALL   fid, label
FRM_RET
```

Frame operations are □-family instructions.

They update the context in which addresses, instruction fetch, stack access, policy scope, and boundary state are interpreted.

The active frame influences:

```text id="t7pni5"
instruction fetch
load/store addressing
stack access
trap entry
trap return
function calls
isolation domains
privilege transitions
policy scope
transaction scope
```

Frame failure is not an untyped CPU error.

It is represented through typed failure:

```text id="65ao93"
□ failure
→ Φ frame fault
→ Ψ denial where policy forbids continuation
→ Σ audit where audit commit is required
```

### 3.8 Role and Capability Registers

PMS-CPU role state is represented by:

```text id="b6y0k6"
R_role
```

Capability state is represented by:

```text id="0ilax2"
R_cap
```

Typical role modes:

```text id="2j4oac"
USER
SYSTEM
SUPERVISOR
HYPERVISOR
KERNEL
HANDLER
```

Ω-family instructions include:

```asm id="pmqb3w"
SET_ROLE   role
CHK_CAP    cap, label_fail
ENTER_PRIV level
EXIT_PRIV
```

Role and capability state govern:

```text id="paux2r"
privileged instructions
frame transitions
kernel entry and return
memory permissions
policy update authority
boundary entry
boundary exit
transaction or commit authority
device or MMIO access
trap handling
interrupt delivery
```

A privileged operation requires:

```text id="zinadu"
Ω permits operation
∧ Ψ permits operation
```

If the check fails, PMS-CPU produces a typed failure path:

```text id="p9b40r"
Ω denial
→ Φ privilege trap

Ψ denial
→ Φ policy trap / halt / denial handler

Χ-sensitive denial
→ Χ violation + Ψ denial / Φ trap
```

Ω qualifies authority.

It does not perform the protected action itself.

### 3.9 Boundary and Isolation State

The isolation-domain register is:

```text id="sdnngx"
R_iso
```

`R_iso` is PMS-CPU state produced by the implementation-layer projection of Χ.

It is not the PMS Base operator Χ itself.

In PMS Base 1.3:

```text id="kb0uql"
Χ = Distance
```

At PMS-CPU level, this Distance becomes computationally concrete as:

```text id="mt5lsg"
MMU boundary
address-space identity
protected execution domain
ASID-like selector
sandbox identifier
access-separation region
reachability restriction
transaction or submachine boundary
kernel/user boundary
handler boundary
boundary-entry context
boundary-exit context
```

Boundary-sensitive instructions must satisfy:

```text id="sx3g6g"
valid Χ projection available
∧ active frame supports the boundary relation
∧ role permits access
∧ policy permits access
```

Examples:

```asm id="u7nt3x"
ISO_FORK     ctx
ISO_ENTER    ctx
ISO_EXIT
ISO_RESTRICT mask
```

These instructions do not redefine Χ as isolation.

They implement a virtual CPU projection of Distance as boundary and reachability control.

`ISO_EXIT` has a strict validity rule:

```text id="ad7rbu"
ISO_EXIT is valid only when an active boundary / isolation context exists.
```

The active context may be recorded in:

```text id="fbxq3v"
R_iso
m.boundary_metadata
m.boundary_stack
m.isolation_stack
```

Unbalanced exit is invalid:

```text id="xixbt1"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

The invalid case must become typed CPU behavior under the declared profile:

```text id="74jklk"
Χ violation
Φ trap
Ψ denial
Σ audit / rejection commit
halt
stuck
```

A sealed isolation context has a distinct rule:

```text id="wnktr0"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, if the context is active and policy allows:

```text id="1nmbt6"
valid exit
closure
audit
rollback
commit
```

Sealing a context is not trapping execution forever.

It binds the scope against expansion while preserving valid closure paths.

PMS-RUST note:

```text id="m73yt0"
PMS-CPU ISO_EXIT is an architecture-level virtual ISA instruction for
leaving a declared isolation or boundary context.

PMS-RUST chi_exit is an artifact/runtime command that evidences a bounded
runtime isolation-exit discipline.

The two correspond at the boundary-exit concept level, but they are not the
same layer.
```

Boundary:

```text id="gwy2yt"
ISO_EXIT does not redefine PMS Base Χ.

chi_exit does not complete PMS-CPU.

chi_exit does not validate PMS Base.
```

### 3.10 Policy Registers and Policy State

PMS-CPU policy state is represented by:

```text id="ig286u"
P
```

and optionally:

```text id="syxpjb"
R_pol
```

Ψ-family instructions include:

```asm id="r9bwpm"
SET_POL      pol_id, Rcfg
CHK_POL      pol_id, label_fail
CHK_ALL_POL
HALT_IF_POL  pol_id
```

Policy state may constrain:

```text id="0xcxbp"
instruction classes
memory regions
role transitions
frame entry
frame return
trap return
boundary crossing
boundary exit
transaction commit
speculation
reordering
interrupt handling
user/kernel crossing
MMIO behavior
```

The policy check can be written:

```text id="e2o78j"
policy_ok(P, s_cpu, instr) = true
```

A failed policy check may:

```text id="nkn3id"
set a policy flag
raise a Φ trap
redirect control to a handler
deny a commit
halt
mark the instruction invalid
record an audit event
```

Policy state is not passive.

It restricts future valid CPU traces:

```text id="lwg1w7"
L_PMS,Ψ ⊆ L_PMS
```

At PMS-CPU level this means:

```text id="07e4n9"
active policy restricts future valid instruction traces.
```

### 3.11 Register/Memory/Frame/Role Coherence

PMS-CPU execution requires coherence across registers, memory, frames, roles, boundaries, and policies.

A coherent state satisfies:

```text id="f4j6ll"
R_pc points into executable frame

R_sp points into stack frame

R_fp is coherent with the active stack frame when used

R_fr selects a valid frame

R_role is a valid role

R_cap is valid for R_role

R_iso is valid for the active boundary domain

P is a valid active policy set

R_flag is internally consistent

MEM access respects frame, role, boundary, and policy constraints

trap, interrupt, transaction, ordering, and commit metadata are coherent

boundary / isolation stack state is coherent

sealed isolation state forbids expansion while preserving valid closure
paths under declared policy
```

If coherence fails, PMS-CPU must either:

```text id="5ghrra"
reject the transition
become stuck
raise a Φ trap
enter a recovery frame
halt under Ψ
record a Σ audit / rejection commit where required
```

The architecture does not allow silent validity.

### 3.12 Example: Frame-Aware Load

A frame-aware load:

```asm id="l64xfw"
LOAD R1, FR+R2
```

is not merely:

```text id="kneyqw"
R1 := MEM[R2]
```

It is operator-typed:

```text id="usgpg6"
Δ distinguish address and frame-relative target
□ bind active frame
Ω check read authority where required
Χ check boundary / reachability where relevant
Ψ check active policy
∇ transfer value into R1
```

Validity requires:

```text id="zq9df0"
R_fr selects a valid frame
R2 resolves to an address inside that frame
the frame permits read
R_role / R_cap authorize read where protected
R_iso permits reachability
P permits the operation
```

Failure is typed:

```text id="hp1zqf"
invalid frame
    → Φ frame fault

missing authority
    → Ω / Ψ denial

boundary violation
    → Χ violation + Φ trap

policy denial
    → Ψ denial
```

A concrete accepted execution contributes to:

```text id="vqb0gk"
trace_cpu(...)
```

It does not by itself enumerate:

```text id="t1l2yl"
Trace(...)
```

### 3.13 Example: Privileged Boundary Operation

A boundary entry:

```asm id="wmonbv"
ISO_ENTER ctx
```

is Χ-family.

It is valid only if:

```text id="kw8prd"
ctx is distinguished
∧ active frame permits domain transition
∧ R_role / R_cap authorize boundary entry
∧ P permits entry
∧ boundary metadata is coherent
```

Operator reading:

```text id="lgovkw"
Δ distinguish target context
□ bind frame/domain context
Ω authorize entry
Ψ permit transition
Χ enter boundary domain
Σ commit boundary state if profile requires integration
```

A boundary exit:

```asm id="p3n2mg"
ISO_EXIT
```

is also Χ-family.

It is valid only if:

```text id="9fwr6k"
active boundary / isolation context exists
∧ R_role / R_cap authorize exit
∧ P permits exit
∧ declared profile permits boundary closure
∧ post-exit state remains coherent
```

Operator reading:

```text id="xjnc0u"
Δ distinguish active boundary context
Ω authorize exit
Ψ permit closure
Χ exit boundary domain
Σ commit boundary closure if profile requires integration
```

Invalid:

```text id="bqvu3o"
ISO_EXIT with no active boundary / isolation context
```

Typed result:

```text id="lpc9bs"
Χ violation
→ Φ trap or Ψ denial
→ optional Σ audit / rejection commit
```

A sealed isolation context may still permit `ISO_EXIT` when the context is active and policy allows closure.

The operation is a virtual CPU projection of Distance.

It does not redefine PMS Base Χ.

### 3.14 Example: Policy-Gated Store Commit

A policy-gated store:

```asm id="ywq9of"
STORE FR+R1, R2
COMMIT_BARRIER
```

is read as:

```text id="lq9ggu"
Δ distinguish address / target
□ bind frame
Ω authorize write
Χ check boundary
Ψ permit mutation
∇ stage or perform write
Θ order visibility where required
Σ commit visibility through COMMIT_BARRIER
```

A structurally valid store may still be invalid under policy:

```text id="ej24mp"
STORE is ISA-valid
∧ frame is valid
∧ authority exists
∧ boundary is coherent
∧ Ψ forbids write
⇒ no valid store transition
```

This illustrates the CPU-layer distinction between:

```text id="z370ib"
syntactic instruction validity
structural CPU validity
policy-constrained execution validity
commit visibility
```

### 3.15 Structural Invariants

```text id="exm0w5"
CPU-RMF1: PMS-CPU exposes registers, memory, frames, roles, capabilities,
          policies, and boundaries as one virtual processor state model

CPU-RMF2: general-purpose registers carry ordinary computation values

CPU-RMF3: special-purpose registers carry execution structure

CPU-RMF4: R_pc specializes PMS-UM ip

CPU-RMF5: Π_CPU denotes the PMS-CPU program domain

CPU-RMF6: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
          program image, or binary image

CPU-RMF7: R_fr records active □ frame context

CPU-RMF8: R_role and R_cap record Ω authority structure

CPU-RMF9: P and optional R_pol record Ψ policy structure

CPU-RMF10: PMS Base Χ = Distance

CPU-RMF11: R_iso records PMS-CPU's implementation-layer projection of Χ as
           boundary, reachability, protection, isolation-domain, and
           access-separation state

CPU-RMF12: R_iso is not PMS Base Χ itself

CPU-RMF13: memory access is frame-, role-, boundary-, and policy-constrained

CPU-RMF14: flag state is operator-visible metadata, not untyped side effect

CPU-RMF15: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
           instruction form

CPU-RMF16: ISO_EXIT is valid only when an active boundary / isolation context
           exists

CPU-RMF17: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-RMF18: sealed isolation forbids entry, expansion, and reachability growth
           while permitting valid exit, closure, audit, rollback, or commit
           under declared profile

CPU-RMF19: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
           not the PMS-CPU ISO_EXIT instruction

CPU-RMF20: frame failure, role denial, policy denial, and boundary violation
           are typed failure paths

CPU-RMF21: register/memory/frame/role coherence is required before normal
           execution

CPU-RMF22: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-RMF23: Trace(...) denotes the set of possible PMS-CPU executions under a
           declared machine/program/profile

CPU-RMF24: concrete PMS-CPU traces belong to L_PMS or L_PMS,Ψ

CPU-RMF25: the register/memory/frame/role model is a virtual CPU
           architecture claim, not fabricated hardware and not PMS Base
           validation
```

### 3.16 Architectural Consequence

The architectural consequence is:

```text id="y961i2"
PMS-CPU treats processor state as operator-addressable execution structure.
Registers, memory, frames, roles, capabilities, boundaries, policies, flags,
traps, commits, boundary exits, sealed isolation state, and ordering metadata
are not disconnected CPU mechanisms; they are virtual processor projections
of Δ–Ψ.
```

This gives later sections their substrate:

```text id="2n7j7p"
Section 4:
    operator families at CPU level

Section 5:
    instruction set architecture

Section 6:
    calling conventions

Section 7:
    interrupts, traps, and recontextualization

Section 8:
    binary encoding

Section 9:
    fetch–decode–execute cycle

Section 10:
    commit and policy checks

Section 11:
    memory consistency model
```

The same substrate also supports later artifact mapping:

```text id="u0kr6u"
PMS-CPU ISO_EXIT
    = architecture-level virtual ISA boundary-exit instruction

PMS-RUST chi_exit
    = bounded artifact/runtime boundary-exit command

PMS Base Χ
    = Distance
```

The mapping is concept-level alignment across layers, not layer identity.

### 3.17 Boundary Statement

The correct boundary for this chapter is:

```text id="d7zl62"
Registers, memory, frames, roles, capabilities, boundary state, policy state,
and CPU meta-state define the operator-visible structural substrate of
PMS-CPU.

This is a virtual CPU structural-state architecture claim.

It does not specify fabricated hardware, physical register layouts,
physical MMU circuitry, physical cache behavior, or completed simulator
implementation.

PMS-CPU ISO_EXIT specifies an architecture-level boundary-exit instruction.
PMS-RUST chi_exit may evidence bounded runtime boundary-exit discipline, but
it does not complete PMS-CPU and does not validate PMS Base.

This chapter does not redefine PMS Base Χ and does not validate PMS Base.
```

---

## 4. PMS Operator Families at CPU Level

PMS-CPU groups its virtual ISA by PMS operator family.

This is the central architectural difference between PMS-CPU and an ordinary untyped instruction set. A PMS-CPU instruction carries both an ISA opcode and an operator class:

```text id="tjwtj4"
Instr = (mnemonic, op ∈ O, operands, constraints)
```

where:

```text id="9ax09h"
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The active PMS-CPU program is:

```text id="ufnk9c"
π_CPU ∈ Π_CPU
```

where:

```text id="bhc6ud"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The operator family specifies the structural role of the instruction.

The opcode specifies the concrete virtual CPU operation inside that family.

The central claim is:

```text id="gm42nc"
PMS-CPU instruction families are ISA-level projections of Δ–Ψ. Each family
defines a valid class of virtual CPU behavior with operator-specific
preconditions, state effects, failure modes, and trace meaning.
```

Claim type:

```text id="w7dk78"
virtual CPU / ISA operator-family architecture claim
```

Boundary:

```text id="n4eynv"
This section specifies virtual CPU instruction families.

It does not define physical hardware.

It does not claim fabricated processor implementation.

It does not redefine PMS Base.

It does not validate PMS Base.
```

Every operator family is described by:

```text id="xz1iy6"
operator role
instruction examples
validity conditions
state effects
failure modes
trace contribution
```

A decoded PMS-CPU instruction must remain operator-visible:

```text id="k3gwmf"
instruction bits
    → PMS_OP
    → opcode
    → operands
    → operator family
    → validity checks
    → state transition
    → trace event
```

A concrete PMS-CPU execution records:

```text id="km2qo4"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="ky2e6j"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="ui6hzo"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="r84s98"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 4.1 Family Form

Every PMS-CPU instruction has the form:

```text id="o6878n"
Instr = (mnemonic, op, operands, constraints)
```

where:

| Field         | Meaning                                                           |
| ------------- | ----------------------------------------------------------------- |
| `mnemonic`    | instruction name                                                  |
| `op`          | primary Δ–Ψ operator family                                       |
| `operands`    | registers, immediates, labels, frames, roles, policies, contexts  |
| `constraints` | dependency, frame, role, boundary, commit, and policy constraints |

A valid instruction family must define:

```text id="a2klpm"
preconditions
postconditions
allowed state effects
failure modes
trace contribution
```

A valid CPU instruction is therefore not merely an opcode.

It is an operator-typed state-transition rule.

### 4.2 Family Validity Pattern

The common validity pattern is:

```text id="hne5n4"
valid_cpu_family_instr(I, s_cpu) iff
    op(I) ∈ O
    ∧ π_CPU ∈ Π_CPU
    ∧ operands_valid(I, s_cpu)
    ∧ dependencies_available(op(I), s_cpu)
    ∧ frame_ok(I, s_cpu)
    ∧ role_ok(I, s_cpu)
    ∧ boundary_ok(I, s_cpu)
    ∧ commit_ok(I, s_cpu)
    ∧ policy_ok(P, s_cpu, I)
    ∧ postcondition_preserves_operator_role(I)
```

Not every instruction uses every check dynamically.

But every instruction family declares which checks are structurally relevant.

Examples:

```text id="kpjbb1"
CMP
    requires operand availability and frame readability

STORE
    requires target distinction, frame validity, role/capability validity,
    boundary validity, policy permission, and possible commit discipline

TRAP
    requires trap cause, handler frame, role transition, policy permission,
    and recontextualization semantics

ISO_EXIT
    requires active boundary / isolation context, exit authority, policy
    permission, and declared profile support

TX_COMMIT
    requires committable state, boundary validity, ordering validity, and
    policy permission
```

### 4.3 Δ-Family — Distinction, Decode, Comparison, Branching

The Δ-family distinguishes instruction classes, data values, conditions, addresses, and branch cases.

Typical Δ-family instructions:

```asm id="q3gqvk"
CMP   Rdst, Rsrc
CMPI  Rdst, imm
TST   Rdst, Rsrc
TSTI  Rdst, imm

BEQ   label
BNE   label
BGT   label
BLT   label
BGE   label
BLE   label

JMP   label
NDIF
```

Δ-family instructions may:

```text id="rvketf"
compare register values
test register or immediate values
classify instruction bit patterns
select branch paths
distinguish valid from invalid opcode forms
distinguish current state for dispatch
distinguish an address, target, role, frame, or condition
```

Typical preconditions:

```text id="0wa4pq"
operands are available
∧ active frame permits reading them
∧ role/capability state permits observation if protected
∧ policy permits the distinction
```

Typical state effects:

```text id="rhlk77"
R_flag' = update_flags(result)
R_pc'   = branch_target or R_pc + instruction_width
m'      = update_distinction_metadata(m, result)
```

Δ does not primarily mutate memory.

It reads, distinguishes, classifies, records condition metadata, and may redirect control.

Failure modes:

| Failure                      | Typed handling    |
| ---------------------------- | ----------------- |
| operand unavailable          | Φ fault or stuck  |
| invalid branch target        | Φ control fault   |
| policy forbids observation   | Ψ denial          |
| frame does not permit read   | □ / Φ frame fault |
| boundary forbids observation | Χ / Ψ denial      |

Trace contribution:

```text id="eeovnl"
Δ
```

Architectural invariant:

```text id="oz7mao"
Δ distinguishes before action.
```

### 4.4 ∇-Family — Action, Mutation, Execution

The ∇-family performs primary state-changing action.

Typical ∇ instructions:

```asm id="lm1h1t"
MOV    Rdst, Rsrc
MOVI   Rdst, imm
LOAD   Rdst, FR+Rn
STORE  FR+Rn, Rsrc

ADD    Rdst, Rsrc
ADDI   Rdst, imm
SUB    Rdst, Rsrc
MUL    Rdst, Rsrc
DIV    Rdst, Rsrc

AND    Rdst, Rsrc
OR     Rdst, Rsrc
XOR    Rdst, Rsrc
NOT    Rdst
SHL    Rdst, imm
SHR    Rdst, imm

PUSH   Rsrc
POP    Rdst
CALL   label
RET

IN     Rdst, port
OUT    port, Rsrc
```

∇-family instructions may:

```text id="mbtfdg"
update registers
perform ALU operations
load from memory
store to memory
manipulate stack state
perform calls and returns
perform virtual I/O
produce staged writes
produce committable state
```

Typical preconditions:

```text id="e9lyrf"
target distinguished
∧ operands valid
∧ active frame permits action
∧ active role/capability permits action where protected
∧ boundary permits reachability where relevant
∧ active policy permits mutation
```

Typical state effects:

```text id="zc0qwo"
RF'   = update_registers(RF, operands)
MEM'  = update_memory_or_stage_write(MEM, operands, m)
R_sp' = update_stack_pointer_if_needed(R_sp, operands)
R_pc' = next_or_control_target
m'    = update_action_or_staging_metadata(m)
```

An ∇ instruction is invalid if it mutates an undistinguished target or bypasses frame, role, boundary, or policy constraints.

Failure modes:

| Failure                           | Typed handling      |
| --------------------------------- | ------------------- |
| no distinguished target           | Φ fault / stuck     |
| write without authority           | Ω / Ψ denial        |
| invalid frame access              | □ / Φ fault         |
| boundary violation                | Χ violation + Φ / Ψ |
| policy denial                     | Ψ denial            |
| invalid arithmetic condition      | Φ arithmetic fault  |
| commit-required effect not staged | Σ / Φ failure       |

Trace contribution:

```text id="iyof55"
∇
```

Architectural invariant:

```text id="5w8vox"
∇ performs primary state-changing action.
```

### 4.5 □-Family — Frame and Context

The □-family establishes, switches, restores, or exits execution context.

Typical □ instructions:

```asm id="yj4b69"
FRM_ENTER  fid
FRM_LEAVE
FRM_SET    FR, Rsrc
FRM_CALL   fid, label
FRM_RET
```

□-family instructions may:

```text id="1i7gsl"
enter a frame
leave a frame
select a frame register
bind an execution context
establish code/data/stack interpretation
support frame-sensitive calls and returns
enter handler or kernel frame
restore caller frame
```

Typical preconditions:

```text id="3dx335"
target frame distinguished
∧ frame exists or can be validly created
∧ frame type supports the transition
∧ role/capability permits frame transition
∧ boundary permits frame reachability
∧ policy permits frame transition
```

Typical state effects:

```text id="e85gk5"
R_fr' = fid
m.frame_stack' = update_frame_stack(m.frame_stack, fid)
m.frame_meta'  = update_frame_metadata(...)
R_pc' = next_or_frame_entry
```

□ does not primarily mutate ordinary memory.

It changes the context in which addresses, roles, policies, code, data, stack entries, and operations have meaning.

Failure modes:

| Failure                  | Typed handling                |
| ------------------------ | ----------------------------- |
| frame not found          | Φ frame fault                 |
| frame type mismatch      | Φ frame fault                 |
| unauthorized frame entry | Ω / Ψ denial                  |
| frame boundary violation | Χ / Ψ denial                  |
| invalid frame return     | Φ / Σ-readable return failure |

Trace contribution:

```text id="g0te36"
□
```

Architectural invariant:

```text id="crv6aa"
□ grounds contextual meaning.
```

### 4.6 Λ-Family — Non-Event, Waiting, Timeout, Idle

The Λ-family represents meaningful absence at the virtual CPU level.

Typical Λ instructions:

```asm id="idvjnq"
WAIT       cond_reg, timeout_reg
POLL       cond_reg
NOP_SEM    code
```

Λ-family instructions may:

```text id="0j3c8z"
wait for readiness
poll a condition
record timeout
represent idle execution
handle absence of an expected interrupt or event
record missing device readiness
represent empty scheduler condition
```

Typical preconditions:

```text id="fywdgq"
expectation exists
∧ wait/poll condition is distinguished
∧ timeout or absence condition is meaningful
∧ policy permits wait or absence handling
```

Typical state effects:

```text id="vvcjf8"
m.pending_non_event' = update_wait_or_timeout(...)
R_flag'              = update_absence_status(...)
R_pc'                = next_or_absence_handler
```

Λ does not perform the expected action.

It records or handles that the expected event did not occur.

Failure modes:

| Failure                        | Typed handling  |
| ------------------------------ | --------------- |
| no expectation exists          | stuck / Φ fault |
| invalid wait condition         | Φ fault         |
| timeout handler missing        | Φ handler fault |
| policy forbids waiting         | Ψ denial        |
| absence path violates ordering | Θ / Ψ failure   |

Trace contribution:

```text id="mdxcia"
Λ
```

Architectural invariant:

```text id="8gymnf"
Λ requires expectation.
```

### 4.7 Α-Family — Pattern and Macro Structure

The Α-family packages reusable instruction patterns.

Typical Α instructions:

```asm id="sv0op6"
PATTERN   pid
PATTERN   pid, Rarg0, Rarg1
LOOP_P    pid, count_reg
```

Α-family instructions may:

```text id="rxs9q5"
expand a macro-pattern
activate a microcode-like sequence
encode repeated operator structure
instantiate a loop pattern
reuse a checked instruction template
package syscall templates
package trap/handler templates
package memory-order templates
```

Typical preconditions:

```text id="jfum38"
pattern is defined
∧ pattern arguments are valid
∧ expansion is PMS-valid
∧ expansion is ISA-valid on the declared target profile
∧ active policy permits expansion
```

Typical state effects:

```text id="ovaywo"
m.active_pattern' = pid
m.expansion_state' = update_expansion_state(...)
R_pc' = pattern_entry or next
```

Α does not introduce new primitive semantics.

It expands to or activates a PMS-valid operator sequence.

Validity condition:

```text id="s3d95e"
valid(Α(pattern)) iff valid(expand(pattern))
```

Failure modes:

| Failure                              | Typed handling  |
| ------------------------------------ | --------------- |
| pattern undefined                    | Φ pattern fault |
| invalid expansion                    | Φ / Ψ denial    |
| expansion violates boundary          | Χ / Ψ denial    |
| expansion bypasses commit discipline | Σ / Ψ failure   |
| loop count invalid                   | Δ / Φ fault     |

Trace contribution:

```text id="s2mlhs"
Α
```

Architectural invariant:

```text id="4uhh2c"
Α expands to valid operator structure.
```

A sealed isolation context forbids Α-driven expansion when that expansion would enlarge reachability, enter a new boundary, or extend the sealed scope.

It may still permit valid exit, closure, rollback, audit, or commit under the declared policy profile.

### 4.8 Ω-Family — Role, Capability, Privilege

The Ω-family manages authority and privilege structure.

Typical Ω instructions:

```asm id="d5bt6l"
SET_ROLE   role
CHK_CAP    cap, label_fail
ENTER_PRIV level
EXIT_PRIV
```

Ω-family instructions may:

```text id="1kmytv"
set role
check capability
enter privileged mode
exit privileged mode
branch on authorization failure
prepare syscall/trap role transition
authorize frame transition
authorize boundary transition
authorize boundary exit
authorize policy update
authorize commit
```

Typical preconditions:

```text id="t91q2a"
role/capability relation distinguished
∧ requested role exists
∧ current role may perform transition
∧ active policy permits role/capability operation
```

Typical state effects:

```text id="nakqwr"
R_role' = new_role or R_role
R_cap'  = updated_capability_state
R_pc'   = next_or_failure_label
m.auth' = update_authority_metadata(...)
```

Ω qualifies authority.

It does not perform the protected action itself.

Failure modes:

| Failure                      | Typed handling     |
| ---------------------------- | ------------------ |
| role missing                 | Ψ denial / Φ fault |
| capability missing           | Ω denial           |
| unauthorized privilege entry | Φ privilege trap   |
| unauthorized boundary exit   | Ω / Ψ denial       |
| unauthorized policy update   | Ψ denial           |
| role leak on return          | Φ / Ψ return fault |

Trace contribution:

```text id="a9wytj"
Ω
```

Architectural invariant:

```text id="xjhg69"
Ω gates privileged action.
```

### 4.9 Θ-Family — Ordering, Fences, Progression

The Θ-family structures progression and ordering.

Typical Θ instructions:

```asm id="qe1pk2"
TICK
SLEEP  ticks
FENCE
YIELD
```

Θ-family instructions may:

```text id="38so1r"
advance logical CPU progression
encode ordering markers
enforce fences
yield execution
structure scheduler-visible progression
constrain memory reordering
record interrupt priority order
record trap nesting order
structure happens-before metadata
```

Typical preconditions:

```text id="f1sk20"
ordering context exists
∧ fence or progression target is meaningful
∧ policy permits progression or yield
∧ boundary/commit state remains coherent if ordering affects visibility
```

Typical state effects:

```text id="ah95ec"
m.ordering' = update_ordering(m.ordering, instruction)
R_pc'       = next
```

Θ is not physical time itself.

Clocks, deadlines, durations, and timestamps are data in state or meta-state. Θ orders transitions involving that data.

Failure modes:

| Failure                     | Typed handling   |
| --------------------------- | ---------------- |
| no progression target       | stuck / Φ fault  |
| fence conflicts with policy | Ψ denial         |
| ordering state inconsistent | Φ ordering fault |
| scheduler yield invalid     | Φ / Ψ failure    |

Trace contribution:

```text id="vdl79x"
Θ
```

Architectural invariant:

```text id="fjpavd"
Θ orders transitions.
```

### 4.10 Φ-Family — Trap, Interrupt, Exception, Recontextualization

The Φ-family recontextualizes execution.

Typical Φ instructions:

```asm id="l34d2d"
EXC_RAISE   code
EXC_SET     table_ptr
TRAP        code
EXC_RET
REFRAME     ctx
```

Φ-family instructions may:

```text id="k816q6"
raise an exception
enter a trap handler
dispatch an interrupt
set exception vector table state
return from exception
reframe a computation
move execution into a handler context
restore prior execution context
represent fault recovery
represent invalid boundary-exit recovery
```

Typical preconditions:

```text id="qgm5zs"
cause distinguished
∧ handler or continuation exists
∧ frame transition valid
∧ role transition valid
∧ boundary state preserved
∧ policy permits entry or return
```

Typical state effects:

```text id="bxm3n6"
trap_frame' = save_or_restore_context(...)
R_role'     = handler_or_restored_role
R_fr'       = handler_or_restored_frame
R_pc'       = handler_entry_or_return_address
m.trap'     = update_trap_metadata(...)
```

Φ does not erase the previous context.

It makes the context shift explicit, recoverable, and traceable.

Failure modes:

| Failure                              | Typed handling  |
| ------------------------------------ | --------------- |
| no handler                           | stuck / Φ fault |
| invalid return frame                 | Φ return fault  |
| unauthorized handler role            | Ω / Ψ denial    |
| boundary leak during trap            | Χ / Ψ violation |
| nested trap policy violation         | Ψ denial        |
| unbalanced ISO_EXIT recovery missing | Φ / Ψ failure   |

Trace contribution:

```text id="bduigs"
Φ
```

Architectural invariant:

```text id="lpwujt"
Φ recontextualizes without untyped erasure.
```

### 4.11 Χ-Family — Distance Projection, Boundary, Isolation

The Χ-family implements PMS-CPU’s projection of PMS Base Distance.

PMS Base 1.3:

```text id="eg7wki"
Χ = Distance
```

PMS-CPU projection:

```text id="2qqj5j"
Χ projects as virtual CPU boundary, reachability, protection-domain,
isolation-domain, sandbox, access-separation, and boundary-exit discipline.
```

Typical Χ instructions:

```asm id="z7xhum"
ISO_FORK     ctx
ISO_ENTER    ctx
ISO_EXIT
ISO_RESTRICT mask
```

Χ-family instructions may:

```text id="4o4h9l"
select isolation domain
enter protected context
leave protected context
restrict visibility
create bounded subcontext
update reachability metadata
enforce protected-domain access
partition frame visibility
mark quarantine state
close active boundary context
```

Typical preconditions:

```text id="hlv6dj"
target context distinguished
∧ active frame/domain exists
∧ role/capability permits boundary operation
∧ active policy permits boundary transition
∧ boundary metadata is coherent
```

For boundary exit, the precondition is stricter:

```text id="l01juh"
ISO_EXIT requires:
    active boundary / isolation context
    ∧ role/capability permits exit
    ∧ active policy permits exit
    ∧ declared CPU profile permits boundary closure
```

The active boundary context may be recorded in:

```text id="oh5j9e"
R_iso
m.boundary_metadata
m.boundary_stack
m.isolation_stack
```

Unbalanced exit is invalid:

```text id="dwnzsk"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

An invalid `ISO_EXIT` must produce typed CPU behavior under the declared profile:

```text id="w64749"
Χ violation
Φ trap
Ψ denial
Σ audit / rejection commit
halt
stuck
```

Typical state effects:

```text id="gnighh"
R_iso'              = new_domain_or_restored_domain
m.boundary_graph'   = update_boundary(...)
m.reachability'     = restrict_or_restore(...)
m.isolation_stack'  = update_isolation_stack(...)
m.boundary_stack'   = update_boundary_stack(...)
m.sealed_state'     = update_sealed_state_if_relevant(...)
```

A sealed isolation context has a distinct rule:

```text id="1j0we4"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="6hk2ka"
valid exit
closure
rollback
audit
commit
```

Sealing a context is not trapping execution forever.

It binds the scope against expansion while preserving valid closure paths.

This is the PMS-CPU implementation-layer projection of Χ.

It does not redefine PMS Base Χ.

Failure modes:

| Failure                                                | Typed handling      |
| ------------------------------------------------------ | ------------------- |
| no active frame/domain                                 | Φ boundary fault    |
| unauthorized boundary entry                            | Ω / Ψ denial        |
| `ISO_EXIT` without active boundary / isolation context | Χ violation + Φ / Ψ |
| sealed context expansion attempt                       | Χ / Ψ denial        |
| boundary state inconsistent                            | Φ boundary fault    |
| policy forbids reachability                            | Ψ denial            |

Trace contribution:

```text id="h0880i"
Χ
```

Architectural invariant:

```text id="o4b8e8"
PMS Base Χ = Distance; PMS-CPU projects Χ as boundary, reachability,
protection-domain, isolation-domain, access-separation, and boundary-exit
discipline.
```

PMS-RUST mapping note:

```text id="eo2nfq"
PMS-CPU ISO_EXIT is an architecture-level virtual ISA instruction for
leaving a declared isolation or boundary context.

PMS-RUST chi_exit is an artifact/runtime command that evidences a bounded
runtime isolation-exit discipline.

The two correspond at the boundary-exit concept level, but they are not the
same layer.
```

Shared rule:

```text id="uv9ip7"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary:

```text id="lpyu2g"
ISO_EXIT does not redefine PMS Base Χ.

chi_exit does not complete PMS-CPU.

chi_exit does not validate PMS Base.
```

### 4.12 Σ-Family — Integration, Commit, Atomicity

The Σ-family integrates prior activity.

Typical Σ instructions:

```asm id="f9o6u6"
TX_BEGIN
TX_COMMIT
TX_ABORT

ATOMIC_ADD  FR+Rn, Rsrc
ATOMIC_CAS  FR+Rn, Rcmp, Rnew

COMMIT_BARRIER
```

Σ-family instructions may:

```text id="my5dct"
begin a transaction
commit staged writes
abort staged changes
perform atomic read-modify-write
establish commit barriers
integrate isolated state
finalize call lifecycle points
finalize trap lifecycle points
finalize transaction lifecycle points
make store-buffer effects visible
commit valid boundary closure
commit audit or rejection records
```

Typical preconditions:

```text id="8frk3d"
committable or staged state exists where required
∧ active frame is coherent
∧ role/capability permits integration
∧ boundary permits visibility or closure
∧ ordering constraints are satisfied
∧ policy permits commit
```

Typical state effects:

```text id="ba6hl1"
transaction_state' = update_transaction(...)
MEM'               = commit_staged_writes(...)
m.commit_log'      = record_commit(...)
m.store_buffer'    = clear_or_update_store_buffer(...)
m.boundary_stack'  = close_context_if_commit_is_boundary_closure(...)
```

Σ requires committable prior activity.

A commit without staged or produced structure is invalid.

`TX_ABORT` belongs to the transaction/commit family because it closes a staged integration context by refusing integration. It may also be Φ-readable as rollback or recovery.

A sealed isolation context may permit valid commit or rollback under declared policy, but it does not permit reachability growth.

Failure modes:

| Failure                                    | Typed handling           |
| ------------------------------------------ | ------------------------ |
| no committable state                       | commit-blocked / Φ fault |
| policy denies commit                       | Ψ denial                 |
| boundary forbids visibility                | Χ / Ψ denial             |
| sealed context would expand through commit | Χ / Ψ denial             |
| ordering not satisfied                     | Θ / Ψ failure            |
| transaction state incoherent               | Φ transaction fault      |

Trace contribution:

```text id="e0l98b"
Σ
```

Architectural invariant:

```text id="8xe31n"
Σ integrates committable prior structure.
```

### 4.13 Ψ-Family — Policy, Invariant, Self-Binding

The Ψ-family defines and enforces policy.

Typical Ψ instructions:

```asm id="tqchba"
SET_POL      pol_id, Rcfg
CHK_POL      pol_id, label_fail
CHK_ALL_POL
HALT_IF_POL  pol_id
```

Ψ-family instructions may:

```text id="mco3zj"
install policy
update policy
check policy
enforce invariants
halt on policy
trap on policy violation
restrict future execution
constrain roles
constrain frames
constrain commits
constrain traps
constrain boundary crossing
constrain boundary exit
constrain memory ordering
seal an isolation context against further expansion
```

Typical preconditions:

```text id="l15aqn"
policy object distinguished
∧ policy scope is valid
∧ active role/capability permits policy operation
∧ higher-order policy permits update if applicable
```

Typical state effects:

```text id="n0urs7"
P'        = update_policy(P, params)
R_flag.P' = policy_violation_flag
R_pc'     = next_or_policy_handler
m.policy' = update_policy_metadata(...)
m.sealed_state' = update_sealed_state_if_policy_seals_context(...)
```

Ψ changes the valid future language of execution:

```text id="gxhryt"
L_PMS,Ψ ⊆ L_PMS
```

At CPU level:

```text id="x0sseo"
active Ψ restricts future valid instruction traces.
```

A Ψ seal over an isolation context closes scope against further expansion.

It does not automatically forbid valid exit, closure, audit, rollback, or commit.

Failure modes:

| Failure                     | Typed handling        |
| --------------------------- | --------------------- |
| malformed policy            | Φ / Ψ failure         |
| missing authority           | Ω / Ψ denial          |
| policy denies instruction   | Ψ denial              |
| policy denies commit        | Ψ + Σ failure         |
| policy denies boundary exit | Ψ + Χ failure         |
| policy requires halt        | halt / terminal state |
| policy requires trap        | Φ policy trap         |

Trace contribution:

```text id="8x0q3g"
Ψ
```

Architectural invariant:

```text id="9yanum"
Ψ constrains future valid execution.
```

### 4.14 Operator Family Summary

| PMS Op | PMS-CPU family                                 | Typical instructions                                                              |
| ------ | ---------------------------------------------- | --------------------------------------------------------------------------------- |
| Δ      | distinction / compare / branch                 | `CMP`, `CMPI`, `TST`, `BEQ`, `BNE`, `JMP`, `NDIF`                                 |
| ∇      | action / mutation / execution                  | `MOV`, `LOAD`, `STORE`, `ADD`, `CALL`, `RET`, `IN`, `OUT`                         |
| □      | frame / context                                | `FRM_ENTER`, `FRM_LEAVE`, `FRM_SET`, `FRM_CALL`, `FRM_RET`                        |
| Λ      | non-event / wait / idle                        | `WAIT`, `POLL`, `NOP_SEM`                                                         |
| Α      | pattern / macro                                | `PATTERN`, `LOOP_P`                                                               |
| Ω      | role / capability / privilege                  | `SET_ROLE`, `CHK_CAP`, `ENTER_PRIV`, `EXIT_PRIV`                                  |
| Θ      | ordering / fence / progression                 | `TICK`, `SLEEP`, `FENCE`, `YIELD`                                                 |
| Φ      | trap / interrupt / exception                   | `EXC_RAISE`, `EXC_SET`, `TRAP`, `EXC_RET`, `REFRAME`                              |
| Χ      | Distance projection / boundary / boundary exit | `ISO_FORK`, `ISO_ENTER`, `ISO_EXIT`, `ISO_RESTRICT`                               |
| Σ      | integration / commit / atomicity               | `TX_BEGIN`, `TX_COMMIT`, `TX_ABORT`, `ATOMIC_ADD`, `ATOMIC_CAS`, `COMMIT_BARRIER` |
| Ψ      | policy / invariant / seal                      | `SET_POL`, `CHK_POL`, `CHK_ALL_POL`, `HALT_IF_POL`                                |

### 4.15 Operator Family Failure Summary

| Family | Characteristic failure                                                                                           |
| ------ | ---------------------------------------------------------------------------------------------------------------- |
| Δ      | invalid distinction, unavailable operand, invalid branch target                                                  |
| ∇      | mutation without distinguished target or required authority                                                      |
| □      | invalid frame entry, frame mismatch, invalid frame return                                                        |
| Λ      | absence without expectation                                                                                      |
| Α      | invalid pattern expansion                                                                                        |
| Ω      | missing role/capability or unauthorized privilege transition                                                     |
| Θ      | invalid ordering or fence state                                                                                  |
| Φ      | trap/recontextualization without cause, handler, or continuation                                                 |
| Χ      | boundary transition without valid frame/domain/authority/policy; unbalanced `ISO_EXIT`; sealed-context expansion |
| Σ      | commit without committable state or invalid visibility / closure integration                                     |
| Ψ      | malformed, unauthorized, violated, higher-order-forbidden policy, or invalid seal/exit policy                    |

Failure remains operator-typed.

It may be represented through:

```text id="c0g39i"
Φ fault
Ψ denial
Χ violation
Λ absence
Σ audit / rejection commit
halt
stuck
```

depending on the declared PMS-CPU profile.

### 4.16 Operator Family Invariants

```text id="h6oucu"
CPU-OF1: every PMS-CPU instruction belongs to one primary Δ–Ψ operator family

CPU-OF2: Π_CPU denotes the PMS-CPU program domain

CPU-OF3: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-OF4: the operator family determines structural role, validity checks,
         state effects, failure modes, and trace contribution

CPU-OF5: ISA opcode specifies concrete CPU operation inside an operator family

CPU-OF6: Δ distinguishes; it does not primarily mutate memory

CPU-OF7: ∇ performs primary mutation or action

CPU-OF8: □ establishes CPU frame/context

CPU-OF9: Λ requires expectation

CPU-OF10: Α expands to valid operator structure

CPU-OF11: Ω qualifies authority before protected action

CPU-OF12: Θ orders execution and memory visibility; it is not wall-clock time

CPU-OF13: Φ recontextualizes traps, interrupts, faults, invalid exits, and
          handlers

CPU-OF14: PMS Base Χ = Distance

CPU-OF15: PMS-CPU projects Χ as virtual CPU boundary, reachability,
          protection-domain, isolation-domain, access-separation, and
          boundary-exit discipline

CPU-OF16: ISO_EXIT is the PMS-CPU architecture-level boundary-exit instruction

CPU-OF17: ISO_EXIT requires an active boundary / isolation context

CPU-OF18: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-OF19: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-OF20: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
          not the PMS-CPU ISO_EXIT instruction

CPU-OF21: Σ integrates committable prior structure

CPU-OF22: Ψ restricts future valid CPU execution and may seal scopes against
          expansion

CPU-OF23: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-OF24: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-OF25: concrete PMS-CPU traces belong to L_PMS or L_PMS,Ψ

CPU-OF26: operator family definitions are virtual ISA architecture claims,
          not fabricated hardware and not PMS Base validation
```

### 4.17 Boundary Statement

The correct boundary for this chapter is:

```text id="o0o2wv"
PMS Operator Families at CPU Level define how each Δ–Ψ operator appears as
a virtual CPU instruction family with declared validity conditions, state
effects, failure modes, and trace meaning.

This is a virtual CPU / ISA operator-family architecture claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

This chapter does not specify physical hardware, does not complete a
simulator, does not redefine PMS Base, and does not validate PMS Base.
```

---

## 5. Instruction Set Architecture

The PMS-CPU instruction set architecture is a virtual ISA organized by PMS operator family.

An instruction has the form:

```text id="xe5xpn"
Instr = (mnemonic, op ∈ O, operands, constraints)
```

where:

| Field         | Meaning                                                                             |
| ------------- | ----------------------------------------------------------------------------------- |
| `mnemonic`    | human-readable instruction name                                                     |
| `op`          | PMS operator family Δ–Ψ                                                             |
| `operands`    | registers, immediates, frame identifiers, roles, policies, addresses, labels        |
| `constraints` | dependency, frame, role, boundary, commit, ordering, and policy validity conditions |

The ISA is operator-typed.

The PMS operator tag is not documentation; it is part of the instruction’s semantic class.

The active PMS-CPU program is:

```text id="bhxxlr"
π_CPU ∈ Π_CPU
```

where:

```text id="m0vvsj"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The central ISA claim is:

```text id="keoy86"
PMS-CPU defines a virtual instruction set whose instruction families are
classified by Δ–Ψ and whose validity depends on operand form, frame state,
role/capability state, boundary state, commit state, ordering state, and
active policy.
```

Claim type:

```text id="jjrm2r"
virtual CPU / ISA specification claim
```

Boundary:

```text id="7h24dp"
This ISA specifies executable virtual instruction semantics for simulators,
emulators, compilers, kernels, runtimes, validators, and formal models.

It does not assert fabricated hardware.

It does not imply that a complete PMS-CPU simulator already exists.

It does not validate PMS Base.
```

A concrete PMS-CPU run produces:

```text id="h2ewl4"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="gddsg2"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="z7f4fd"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="oo86g0"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 5.1 ISA Design Principle

The design principle is:

```text id="l1dvse"
every instruction is both an opcode and an operator-typed transition.
```

A conventional ISA may treat opcodes as machine actions.

PMS-CPU treats opcodes as operator-projected machine actions.

The relation is:

```text id="twq3fr"
operator family
    → instruction family
    → opcode
    → operands
    → constraints
    → state transition
    → trace event
```

The ISA is therefore not a flat mnemonic list.

It is a typed execution interface over PMS-CPU state.

### 5.2 General ISA Conventions

PMS-CPU operands may include:

| Operand kind             | Example                          |
| ------------------------ | -------------------------------- |
| register                 | `R0`, `R1`, `Rdst`, `Rsrc`       |
| immediate                | `imm`, `ticks`, `code`           |
| label                    | `label`, `label_fail`, `handler` |
| frame identifier         | `fid`, `FR_KERNEL_STACK`         |
| effective address        | `FR+Rn`, `FR+offset`             |
| role identifier          | `ROLE_USER`, `ROLE_KERNEL`       |
| privilege level          | `level`                          |
| capability identifier    | `cap`                            |
| policy identifier        | `pol_id`                         |
| policy configuration     | `Rcfg`                           |
| context identifier       | `ctx`                            |
| pattern identifier       | `pid`                            |
| port / device identifier | `port`, `dev_id`                 |

Canonical instruction syntax:

```asm id="dq5o4e"
MNEMONIC operand0, operand1, ...
```

Each instruction belongs to exactly one primary PMS operator family.

A concrete implementation may introduce:

```text id="z9s5jz"
aliases
compressed encodings
pseudo-instructions
macro-instructions
profile-specific extensions
```

but those must expand into operator-typed ISA structure.

### 5.3 Operand Validity

Operand validity is part of ISA validity.

A valid instruction must satisfy:

```text id="s59u2f"
operands_valid(I, s_cpu) = true
```

Examples:

```text id="1zzvpm"
register operands name existing logical registers

immediate operands fit declared width

label operands resolve to valid code positions in π_CPU

frame identifiers name valid frame descriptors

effective addresses resolve inside a valid frame

role identifiers name valid roles

capability identifiers name valid capability classes

policy identifiers name valid policy objects

context identifiers name valid boundary/isolation contexts
```

Operand validity does not by itself imply execution validity.

A valid operand may still fail because of:

```text id="qgzb0p"
frame constraints
role/capability denial
boundary denial
policy denial
commit precondition failure
ordering failure
trap condition
sealed-isolation constraint
unbalanced boundary exit
```

### 5.4 Δ-Family ISA

Δ-family instructions distinguish values, classify conditions, and redirect control.

```asm id="f1iysu"
CMP   Rdst, Rsrc
CMPI  Rdst, imm
TST   Rdst, Rsrc
TSTI  Rdst, imm

BEQ   label
BNE   label
BGT   label
BLT   label
BGE   label
BLE   label

JMP   label
NDIF
```

Instruction roles:

| Instruction | Role                                                  |
| ----------- | ----------------------------------------------------- |
| `CMP`       | compare two registers                                 |
| `CMPI`      | compare register with immediate                       |
| `TST`       | test register relation or bit structure               |
| `TSTI`      | test register against immediate                       |
| `BEQ`       | branch if equal / zero condition                      |
| `BNE`       | branch if not equal                                   |
| `BGT`       | branch if greater than                                |
| `BLT`       | branch if less than                                   |
| `BGE`       | branch if greater or equal                            |
| `BLE`       | branch if less or equal                               |
| `JMP`       | unconditional control distinction / jump              |
| `NDIF`      | distinguish non-difference / no-distinction condition |

Validity:

```text id="hemzsp"
operands available
∧ active frame permits read
∧ role/capability permits observation if protected
∧ branch target is valid if branch is taken
∧ policy permits distinction / branch
```

State effects:

```text id="jqemrp"
R_flag' = update_flags(...)
R_pc'   = next_or_branch_target
m'      = update_distinction_metadata(...)
```

Failure:

```text id="n8x1rz"
invalid operand
invalid branch target
policy-forbidden observation
frame fault
boundary-forbidden observation
```

Trace contribution:

```text id="ecxi36"
Δ
```

### 5.5 ∇-Family ISA

∇-family instructions perform primary state-changing action.

```asm id="z8bvr0"
MOV    Rdst, Rsrc
MOVI   Rdst, imm
LOAD   Rdst, FR+Rn
STORE  FR+Rn, Rsrc

ADD    Rdst, Rsrc
ADDI   Rdst, imm
SUB    Rdst, Rsrc
MUL    Rdst, Rsrc
DIV    Rdst, Rsrc

AND    Rdst, Rsrc
OR     Rdst, Rsrc
XOR    Rdst, Rsrc
NOT    Rdst
SHL    Rdst, imm
SHR    Rdst, imm

PUSH   Rsrc
POP    Rdst
CALL   label
RET

IN     Rdst, port
OUT    port, Rsrc
```

Instruction roles:

| Instruction group                       | Role                                      |
| --------------------------------------- | ----------------------------------------- |
| `MOV`, `MOVI`                           | register update                           |
| `LOAD`, `STORE`                         | memory transfer                           |
| `ADD`, `SUB`, `MUL`, `DIV`              | arithmetic                                |
| `AND`, `OR`, `XOR`, `NOT`, `SHL`, `SHR` | logical / bitwise operations              |
| `PUSH`, `POP`                           | stack update                              |
| `CALL`, `RET`                           | call/return control and frame interaction |
| `IN`, `OUT`                             | virtual I/O                               |

Validity:

```text id="mikuvt"
target distinguished
∧ operands valid
∧ frame permits access
∧ role/capability permits operation where protected
∧ boundary permits reachability where relevant
∧ active policy permits mutation
```

State effects:

```text id="jycbv9"
RF'   = update_register_file(...)
MEM'  = update_memory_or_stage_write(...)
R_sp' = update_stack_pointer_if_needed(...)
R_pc' = next_or_control_target
m'    = update_action_metadata(...)
```

Failure:

```text id="1rrhj4"
missing target distinction
invalid address
frame fault
role/capability denial
boundary violation
policy denial
arithmetic fault
```

Trace contribution:

```text id="k3fovi"
∇
```

### 5.6 □-Family ISA

□-family instructions manage frame and context.

```asm id="w3grbw"
FRM_ENTER  fid
FRM_LEAVE
FRM_SET    FR, Rsrc
FRM_CALL   fid, label
FRM_RET
```

Instruction roles:

| Instruction | Role                       |
| ----------- | -------------------------- |
| `FRM_ENTER` | enter a frame              |
| `FRM_LEAVE` | leave active frame         |
| `FRM_SET`   | set frame register         |
| `FRM_CALL`  | call into a specific frame |
| `FRM_RET`   | return from frame context  |

Validity:

```text id="fnwuz8"
target frame distinguished
∧ target frame exists or can be validly established
∧ frame type supports operation
∧ role/capability permits transition
∧ boundary permits frame reachability
∧ active policy permits transition
```

State effects:

```text id="o7e3g9"
R_fr' = new_or_restored_frame
m.frame_stack' = update_frame_stack(...)
R_pc' = next_or_frame_entry_or_return
```

Failure:

```text id="tfsh83"
unknown frame
invalid frame type
unauthorized frame entry
boundary violation
invalid frame return
```

Trace contribution:

```text id="plm7a5"
□
```

### 5.7 Λ-Family ISA

Λ-family instructions handle absence, waiting, polling, timeout, and idle semantics.

```asm id="mko1lz"
WAIT       cond_reg, timeout_reg
POLL       cond_reg
NOP_SEM    code
```

Instruction roles:

| Instruction | Role                                                    |
| ----------- | ------------------------------------------------------- |
| `WAIT`      | wait for a condition or readiness bound                 |
| `POLL`      | test readiness without forcing the expected event       |
| `NOP_SEM`   | semantic no-op / idle marker with typed absence meaning |

Validity:

```text id="j2ffug"
expectation exists
∧ condition is distinguished
∧ timeout or absence case is meaningful
∧ policy permits waiting / idle / absence path
```

State effects:

```text id="dtzyi1"
m.pending_non_event' = update_wait_or_timeout(...)
R_flag'              = update_absence_status(...)
R_pc'                = next_or_absence_handler
```

Failure:

```text id="h7u57u"
absence without expectation
invalid timeout register
missing absence handler
policy-denied wait
```

Trace contribution:

```text id="wufz4e"
Λ
```

### 5.8 Α-Family ISA

Α-family instructions activate reusable operator patterns.

```asm id="kf2i4d"
PATTERN   pid
PATTERN   pid, Rarg0, Rarg1
LOOP_P    pid, count_reg
```

Instruction roles:

| Instruction                 | Role                           |
| --------------------------- | ------------------------------ |
| `PATTERN pid`               | activate pattern by identifier |
| `PATTERN pid, Rarg0, Rarg1` | activate parameterized pattern |
| `LOOP_P pid, count_reg`     | repeat a checked pattern       |

Validity:

```text id="bgg95m"
pattern exists
∧ arguments are valid
∧ expansion belongs to PMS-valid operator structure
∧ expansion is valid for the PMS-CPU profile
∧ active policy permits expansion
```

If the current boundary / isolation context is sealed, expansion has an additional constraint:

```text id="gb06b3"
sealed isolation
    forbids expansion that creates new entry, reachability growth, or scope
    enlargement
```

State effects:

```text id="j6ja2t"
m.active_pattern'   = pid
m.expansion_state'  = update_expansion_state(...)
R_pc'               = pattern_entry or next
```

Failure:

```text id="esnht6"
unknown pattern
invalid expansion
policy-denied expansion
boundary-invalid expansion
sealed-isolation expansion violation
commit-invalid expansion
```

Trace contribution:

```text id="n8rwnp"
Α
```

### 5.9 Ω-Family ISA

Ω-family instructions manage role, capability, and privilege.

```asm id="umhxqg"
SET_ROLE   role
CHK_CAP    cap, label_fail
ENTER_PRIV level
EXIT_PRIV
```

Instruction roles:

| Instruction  | Role                                   |
| ------------ | -------------------------------------- |
| `SET_ROLE`   | set or switch role                     |
| `CHK_CAP`    | check capability and branch on failure |
| `ENTER_PRIV` | enter privileged execution level       |
| `EXIT_PRIV`  | leave privileged execution level       |

Validity:

```text id="g82v0j"
role/capability relation distinguished
∧ role exists
∧ capability exists where required
∧ current role may perform transition/check
∧ active policy permits role/capability operation
```

State effects:

```text id="hfz364"
R_role' = new_role or R_role
R_cap'  = updated_capability_state
R_pc'   = next_or_failure_label
m.auth' = update_authority_metadata(...)
```

Failure:

```text id="peu6lk"
missing role
missing capability
unauthorized privilege transition
unauthorized boundary-exit authority
policy-denied authority change
```

Trace contribution:

```text id="uvj2oj"
Ω
```

### 5.10 Θ-Family ISA

Θ-family instructions manage ordering, fences, yielding, and progression.

```asm id="s1hvr3"
TICK
SLEEP  ticks
FENCE
YIELD
```

Instruction roles:

| Instruction | Role                                 |
| ----------- | ------------------------------------ |
| `TICK`      | advance logical execution order      |
| `SLEEP`     | enter ordered wait/progression state |
| `FENCE`     | prevent reordering across a boundary |
| `YIELD`     | yield scheduling progression         |

Validity:

```text id="n5rpff"
ordering context meaningful
∧ fence or yield target valid
∧ active policy permits progression
∧ ordering does not violate memory/profile constraints
```

State effects:

```text id="h8oj2a"
m.ordering' = update_ordering(...)
R_pc'       = next
```

Failure:

```text id="biv55j"
invalid ordering state
policy-denied yield
fence conflicts with transaction or boundary state
```

Trace contribution:

```text id="bezgka"
Θ
```

Θ is not physical time itself.

Clocks, deadlines, durations, and timestamps are data in state or meta-state. Θ orders transitions involving that data.

### 5.11 Φ-Family ISA

Φ-family instructions handle traps, exceptions, interrupts, and recontextualization.

```asm id="ln3fz8"
EXC_RAISE   code
EXC_SET     table_ptr
TRAP        code
EXC_RET
REFRAME     ctx
```

Instruction roles:

| Instruction | Role                                                |
| ----------- | --------------------------------------------------- |
| `EXC_RAISE` | raise exception                                     |
| `EXC_SET`   | set exception table or handler pointer              |
| `TRAP`      | controlled trap, syscall, or explicit handler entry |
| `EXC_RET`   | return from exception/trap context                  |
| `REFRAME`   | enter a new interpretive or execution context       |

Validity:

```text id="cssqmk"
cause or target context distinguished
∧ handler / continuation exists
∧ frame transition valid
∧ role transition valid
∧ boundary state preserved
∧ policy permits entry or return
```

State effects:

```text id="u9jwzw"
trap_frame' = save_or_restore_context(...)
R_role'     = handler_or_restored_role
R_fr'       = handler_or_restored_frame
R_pc'       = handler_entry_or_return_address
m.trap'     = update_trap_state(...)
```

Failure:

```text id="rxdpeo"
missing handler
invalid trap return
unauthorized handler role
boundary leak
policy-denied trap return
invalid ISO_EXIT recovery path
```

Trace contribution:

```text id="iyt4dl"
Φ
```

`TRAP` may be used as the PMS-CPU control-transfer mechanism for entering handler or kernel contexts.

This is not the PMS-OS syscall ABI.

The OS-level syscall ABI is defined in `04_pms_os.md` on top of the CPU trap mechanism.

### 5.12 Χ-Family ISA

Χ-family instructions manage PMS-CPU boundary and reachability state as a projection of PMS Base Distance.

```asm id="h48v0t"
ISO_FORK     ctx
ISO_ENTER    ctx
ISO_EXIT
ISO_RESTRICT mask
```

Instruction roles:

| Instruction    | Role                                             |
| -------------- | ------------------------------------------------ |
| `ISO_FORK`     | create separated execution or visibility context |
| `ISO_ENTER`    | enter protected domain                           |
| `ISO_EXIT`     | leave protected domain                           |
| `ISO_RESTRICT` | restrict visibility or access mask               |

PMS Base 1.3:

```text id="kwngtq"
Χ = Distance
```

PMS-CPU projection:

```text id="f0gs9v"
Χ projects as virtual CPU boundary, reachability, protection-domain,
isolation-domain, sandbox, access-separation, and boundary-exit discipline.
```

General Χ validity:

```text id="blhbkc"
target context distinguished
∧ active frame/domain exists
∧ role/capability permits boundary operation
∧ active policy permits transition
∧ boundary metadata is coherent
```

`ISO_EXIT` has a stricter validity rule:

```text id="eft5d6"
ISO_EXIT requires:
    active boundary / isolation context
    ∧ role/capability permits exit
    ∧ active policy permits exit
    ∧ declared CPU profile permits boundary closure
```

The active boundary context may be recorded in:

```text id="rc1wry"
R_iso
m.boundary_metadata
m.boundary_stack
m.isolation_stack
```

Unbalanced exit is invalid:

```text id="e4ipzu"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

An invalid `ISO_EXIT` must produce typed CPU behavior:

```text id="h23zpa"
Χ violation
Φ trap
Ψ denial
Σ audit / rejection commit
halt
stuck
```

State effects:

```text id="hmpj4t"
R_iso'              = new_domain_or_restored_domain
m.boundary_graph'   = update_boundary(...)
m.reachability'     = update_reachability(...)
m.isolation_stack'  = update_isolation_stack(...)
m.boundary_stack'   = update_boundary_stack(...)
m.sealed_state'     = update_sealed_state_if_relevant(...)
```

A sealed isolation context has a distinct rule:

```text id="qoe1q0"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="hgwq1p"
valid exit
closure
rollback
audit
commit
```

Sealing a context is not trapping execution forever.

It binds scope against expansion while preserving valid closure paths.

Failure:

```text id="ppl5dt"
unknown context
no active frame/domain
unauthorized boundary transition
unauthorized boundary exit
policy-denied reachability
inconsistent boundary state
unbalanced ISO_EXIT
sealed-isolation expansion violation
```

Boundary:

```text id="ez2gtn"
PMS Base Χ = Distance.

PMS-CPU projects Χ as virtual CPU boundary and reachability semantics.
```

PMS-RUST mapping note:

```text id="iumdgj"
PMS-CPU ISO_EXIT is an architecture-level virtual ISA instruction for
leaving a declared isolation or boundary context.

PMS-RUST chi_exit is an artifact/runtime command that evidences a bounded
runtime isolation-exit discipline.

The two correspond at the boundary-exit concept level, but they are not the
same layer.
```

Shared rule:

```text id="lucern"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary of the mapping:

```text id="v24li4"
ISO_EXIT does not redefine PMS Base Χ.

chi_exit does not complete PMS-CPU.

chi_exit does not validate PMS Base.
```

Trace contribution:

```text id="lpf4al"
Χ
```

### 5.13 Σ-Family ISA

Σ-family instructions manage integration, transactions, atomic operations, and commit barriers.

```asm id="lg7sf6"
TX_BEGIN
TX_COMMIT
TX_ABORT

ATOMIC_ADD  FR+Rn, Rsrc
ATOMIC_CAS  FR+Rn, Rcmp, Rnew

COMMIT_BARRIER
```

Instruction roles:

| Instruction      | Role                                        |
| ---------------- | ------------------------------------------- |
| `TX_BEGIN`       | begin transaction or staged commit context  |
| `TX_COMMIT`      | commit staged changes                       |
| `TX_ABORT`       | abort staged changes / close staged context |
| `ATOMIC_ADD`     | atomic addition over memory                 |
| `ATOMIC_CAS`     | atomic compare-and-swap                     |
| `COMMIT_BARRIER` | force integration or visibility boundary    |

Validity:

```text id="mghjfn"
committable or staged state exists where required
∧ active frame is coherent
∧ role/capability permits integration
∧ boundary permits visibility or closure
∧ ordering constraints are satisfied
∧ active policy permits commit
```

State effects:

```text id="jiid46"
transaction_state' = update_transaction(...)
MEM'               = commit_staged_writes(...)
m.commit_log'      = record_commit(...)
m.store_buffer'    = update_store_buffer(...)
m.boundary_stack'  = close_context_if_commit_is_boundary_closure(...)
```

Failure:

```text id="zmx6go"
no committable state
policy-denied commit
boundary-denied visibility
sealed-context reachability growth through commit
transaction incoherence
ordering violation
```

Trace contribution:

```text id="p8fdr1"
Σ
```

A sealed isolation context may permit valid commit, audit, rollback, or closure under declared policy.

It does not permit reachability growth through commit.

### 5.14 Ψ-Family ISA

Ψ-family instructions define, check, and enforce policy.

```asm id="mfscy2"
SET_POL      pol_id, Rcfg
CHK_POL      pol_id, label_fail
CHK_ALL_POL
HALT_IF_POL  pol_id
```

Instruction roles:

| Instruction   | Role                                   |
| ------------- | -------------------------------------- |
| `SET_POL`     | install or update policy               |
| `CHK_POL`     | check one policy and branch on failure |
| `CHK_ALL_POL` | check all active policies              |
| `HALT_IF_POL` | halt if a policy condition is active   |

Validity:

```text id="w0h90r"
policy object distinguished
∧ policy scope valid
∧ role/capability permits policy definition or enforcement
∧ higher-order policy permits update where applicable
```

State effects:

```text id="uqkp33"
P'         = update_policy(P, params)
R_flag.P' = update_policy_status(...)
R_pc'      = next_or_policy_handler_or_halt
m.policy' = update_policy_metadata(...)
m.sealed_state' = update_sealed_state_if_policy_seals_context(...)
```

Failure:

```text id="bw4s3c"
malformed policy
unknown policy object
missing authority
policy denial
higher-order policy conflict
invalid seal or invalid boundary-exit policy
```

Ψ restricts future valid execution:

```text id="xvkvxy"
L_PMS,Ψ ⊆ L_PMS
```

At PMS-CPU level:

```text id="r6qyx5"
active Ψ restricts future valid instruction traces.
```

A Ψ seal over isolation closes scope against further entry, expansion, or reachability growth.

It does not automatically forbid valid exit, closure, rollback, audit, or commit.

### 5.15 ISA Validity

A PMS-CPU instruction is ISA-valid when:

```text id="pfoth1"
mnemonic belongs to exactly one operator family
∧ π_CPU ∈ Π_CPU
∧ operands have valid form
∧ instruction format is valid
∧ dependency requirements are available
∧ frame constraints are satisfied
∧ role/capability constraints are satisfied
∧ boundary constraints are satisfied where relevant
∧ commit preconditions are satisfied where relevant
∧ ordering constraints are satisfied where relevant
∧ active Ψ policy permits the instruction
```

This can be written:

```text id="r1h0ri"
valid_isa_instr(I, s_cpu) iff
    op(I) ∈ O
    ∧ π_CPU ∈ Π_CPU
    ∧ operands_valid(I, s_cpu)
    ∧ format_valid(I)
    ∧ dependencies_available(op(I), s_cpu)
    ∧ frame_ok(I, s_cpu)
    ∧ role_ok(I, s_cpu)
    ∧ boundary_ok(I, s_cpu)
    ∧ commit_ok(I, s_cpu)
    ∧ ordering_ok(I, s_cpu)
    ∧ policy_ok(P, s_cpu, I)
```

For `ISO_EXIT`, the validity rule is:

```text id="jwq8gl"
valid_isa_instr(ISO_EXIT, s_cpu) iff
    op(ISO_EXIT) = Χ
    ∧ active_boundary_context(s_cpu) = true
    ∧ role_ok(ISO_EXIT, s_cpu)
    ∧ boundary_ok(ISO_EXIT, s_cpu)
    ∧ policy_ok(P, s_cpu, ISO_EXIT)
    ∧ profile_allows(profile, ISO_EXIT)
```

Invalid:

```text id="nm3b3s"
active_boundary_context(s_cpu) = false
    ⇒ ISO_EXIT invalid
```

The ISA is therefore a typed execution interface over PMS-CPU state.

Validation here means acceptance or rejection under a declared schema, model, profile, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 5.16 Pseudo-Instructions and Aliases

A PMS-CPU profile may define pseudo-instructions.

A pseudo-instruction is valid only if it expands into operator-valid ISA instructions.

Example:

```asm id="m1qc6t"
CLEAR R1
```

may expand to:

```asm id="fmdfph"
MOVI R1, 0
```

Operator reading:

```text id="khff71"
CLEAR → ∇
```

Example:

```asm id="fm2mky"
RET_SAFE
```

may expand to:

```asm id="ayg9tf"
CHK_POL POL_RETURN, return_fail
FRM_RET
RET
```

Operator reading:

```text id="cty3u2"
Ψ □ ∇
```

Example:

```asm id="qqucin"
ISO_EXIT_SAFE
```

may expand to:

```asm id="uhiqvy"
CHK_CAP CAP_ISO_EXIT, exit_fail
CHK_POL POL_ISO_EXIT, exit_fail
ISO_EXIT
```

Operator reading:

```text id="ay6dt8"
Ω Ψ Χ
```

Validity condition:

```text id="p57f6x"
valid(pseudo) iff valid(expand(pseudo))
```

Aliases and pseudo-instructions must not erase operator identity.

A pseudo-instruction that hides unbalanced boundary exit, bypasses policy, or permits sealed-scope expansion is not PMS-CPU-conformant.

### 5.17 Profile-Specific Extensions

A PMS-CPU profile may extend the ISA with additional instructions.

Extension rule:

```text id="ibh620"
every extension instruction must declare:
    mnemonic
    operator family
    operand format
    validity constraints
    state effects
    failure modes
    trace contribution
```

An extension is invalid if it introduces untyped behavior.

Correct:

```text id="5t0m2g"
profile-specific instruction belongs to Δ–Ψ and preserves PMS-CPU validity.
```

Incorrect:

```text id="9wc5wi"
profile-specific instruction bypasses frame, role, boundary, commit,
ordering, or policy discipline.
```

For Χ extensions, the profile must also declare:

```text id="egvizk"
active-boundary requirements
unbalanced-exit behavior
sealed-isolation behavior
closure / rollback / audit / commit behavior
```

### 5.18 ISA Summary

| PMS Op | ISA families                                                                                                                                           |
| ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Δ      | `CMP`, `CMPI`, `TST`, `TSTI`, `BEQ`, `BNE`, `BGT`, `BLT`, `BGE`, `BLE`, `JMP`, `NDIF`                                                                  |
| ∇      | `MOV`, `MOVI`, `LOAD`, `STORE`, `ADD`, `ADDI`, `SUB`, `MUL`, `DIV`, `AND`, `OR`, `XOR`, `NOT`, `SHL`, `SHR`, `PUSH`, `POP`, `CALL`, `RET`, `IN`, `OUT` |
| □      | `FRM_ENTER`, `FRM_LEAVE`, `FRM_SET`, `FRM_CALL`, `FRM_RET`                                                                                             |
| Λ      | `WAIT`, `POLL`, `NOP_SEM`                                                                                                                              |
| Α      | `PATTERN`, `LOOP_P`                                                                                                                                    |
| Ω      | `SET_ROLE`, `CHK_CAP`, `ENTER_PRIV`, `EXIT_PRIV`                                                                                                       |
| Θ      | `TICK`, `SLEEP`, `FENCE`, `YIELD`                                                                                                                      |
| Φ      | `EXC_RAISE`, `EXC_SET`, `TRAP`, `EXC_RET`, `REFRAME`                                                                                                   |
| Χ      | `ISO_FORK`, `ISO_ENTER`, `ISO_EXIT`, `ISO_RESTRICT`                                                                                                    |
| Σ      | `TX_BEGIN`, `TX_COMMIT`, `TX_ABORT`, `ATOMIC_ADD`, `ATOMIC_CAS`, `COMMIT_BARRIER`                                                                      |
| Ψ      | `SET_POL`, `CHK_POL`, `CHK_ALL_POL`, `HALT_IF_POL`                                                                                                     |

### 5.19 ISA Invariants

```text id="iryjgo"
CPU-ISA1: PMS-CPU ISA is virtual

CPU-ISA2: every instruction belongs to one primary Δ–Ψ family

CPU-ISA3: Π_CPU denotes the PMS-CPU program domain

CPU-ISA4: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
          program image, or binary image

CPU-ISA5: instruction validity depends on operands, format, dependencies,
          frame, role, boundary, commit, ordering, and policy

CPU-ISA6: pseudo-instructions must expand to valid operator-typed ISA
          sequences

CPU-ISA7: profile-specific extensions must declare operator family,
          validity constraints, state effects, failure modes, and trace
          contribution

CPU-ISA8: ISA-level Χ remains a PMS-CPU projection of PMS Base Distance

CPU-ISA9: PMS Base Χ = Distance

CPU-ISA10: PMS-CPU projects Χ as virtual CPU boundary, reachability,
           protection-domain, isolation-domain, access-separation, and
           boundary-exit discipline

CPU-ISA11: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
           instruction

CPU-ISA12: ISO_EXIT requires an active boundary / isolation context

CPU-ISA13: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-ISA14: sealed isolation forbids entry, expansion, and reachability growth
           while permitting valid exit, closure, rollback, audit, or commit
           under declared profile

CPU-ISA15: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
           not the PMS-CPU ISO_EXIT instruction

CPU-ISA16: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-ISA17: Trace(...) denotes the set of possible PMS-CPU executions under a
           declared machine/program/profile

CPU-ISA18: ISA traces belong to L_PMS or L_PMS,Ψ under active policy

CPU-ISA19: ISA validity is distinct from hardware implementation

CPU-ISA20: ISA validity is distinct from PMS Base validation
```

### 5.20 Architectural Consequence

The PMS-CPU ISA gives PMS-STACK a virtual instruction layer whose operations remain structurally transparent.

The consequence is:

```text id="londar"
Every PMS-CPU instruction is classified by Δ–Ψ, checked against frame,
role, boundary, ordering, commit, and policy state, and executed as a
PMS-UM specialization over register and memory state.
```

This includes boundary-exit discipline:

```text id="ap9tjf"
ISO_EXIT requires active boundary / isolation context.

Unbalanced ISO_EXIT is invalid.

Sealed isolation forbids expansion but permits valid closure paths under
declared policy.
```

This is a virtual CPU / ISA architecture claim.

It does not claim fabricated hardware.

It defines the operator-typed execution layer that `04_pms_os.md`, `05_pmsl_pms_ir.md`, simulators, compilers, validators, runtimes, and formal tooling can target.

PMS-RUST-style `chi_exit` may evidence bounded runtime boundary-exit discipline.

It does not complete PMS-CPU and does not validate PMS Base.

### 5.21 Boundary Statement

The correct boundary for this chapter is:

```text id="pmo5jt"
The PMS-CPU Instruction Set Architecture defines a virtual ISA whose
instructions are typed by Δ–Ψ and constrained by operands, dependencies,
frames, roles, boundaries, ordering, commits, and policies.

This is a virtual CPU / ISA specification claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

The ISA does not claim fabricated hardware, does not imply a completed
simulator, does not redefine PMS Base, and does not validate PMS Base.
```

---

## 6. Calling Conventions

PMS-CPU defines a canonical virtual calling convention.

The purpose of the calling convention is not only to pass arguments and return values. It makes function entry, function exit, recursion, tail calls, privilege crossing, trap entry, syscall entry, handler return, frame restoration, role restoration, boundary preservation, boundary exit, and commit visibility visible as operator-typed CPU structure.

The active PMS-CPU program is:

```text id="opbpey"
π_CPU ∈ Π_CPU
```

where:

```text id="k1ifzj"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The convention is organized around:

```text id="ni9xsw"
□ frames
Ω roles / capabilities
Χ boundary discipline
Σ integration / restoration points
Ψ invariants
Φ trap and syscall transitions
Θ ordering where call/return sequencing matters
```

A PMS-CPU call is not merely a jump.

It is a controlled transition across:

```text id="v9bhrp"
code position
stack state
frame context
register preservation rules
role/capability constraints
boundary constraints
policy invariants
return validity
commit / integration discipline
```

The central claim is:

```text id="nitazx"
PMS-CPU calling conventions define operator-typed control-transfer
discipline for function calls, returns, tail calls, syscalls, traps, and
handler transitions.
```

Claim type:

```text id="hk0rq3"
virtual CPU calling-convention architecture claim
```

Boundary:

```text id="flfpc5"
This defines a canonical virtual calling convention.

It does not claim a platform ABI, physical hardware ABI, operating-system
ABI, or completed compiler backend.

It does not validate PMS Base.
```

A concrete PMS-CPU call/return execution contributes to:

```text id="ljmmvb"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="j7esvn"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="oivhcx"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="h4ruwq"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 6.1 Register Classification

The canonical calling convention uses the following register roles.

| Register class         | Registers             | Role                                       |
| ---------------------- | --------------------- | ------------------------------------------ |
| argument registers     | `R0–R3`               | first four arguments                       |
| return registers       | `R0`, optionally `R1` | primary and secondary return values        |
| caller-saved registers | `R0–R3`               | caller must preserve if needed             |
| callee-saved registers | `R4–R7`               | callee must restore before return          |
| stack pointer          | `R_sp`                | active stack position                      |
| frame pointer          | `R_fp`                | stable frame reference, if used            |
| frame register         | `R_fr`                | active □ execution context                 |
| role register          | `R_role`              | active Ω privilege/role state              |
| capability register    | `R_cap`               | active Ω capability state                  |
| flag register          | `R_flag`              | Δ / Φ / Ψ / Χ status flags                 |
| isolation register     | `R_iso`               | active Χ boundary / isolation-domain state |
| policy register        | `R_pol`, optional     | active or fast policy-domain state         |

A concrete PMS-CPU profile may define more registers.

This convention fixes the architectural minimum used by examples and later documents.

Boundary note:

```text id="ft6bbs"
The ordinary PMS-CPU function calling convention is distinct from the
PMS-CPU trap/syscall control-transfer convention and distinct from the
PMS-OS syscall ABI.

ordinary PMS-CPU function call convention
    ≠ PMS-CPU trap/syscall control-transfer convention
    ≠ PMS-OS syscall ABI
```

### 6.2 Stack Frame Layout

A canonical stack frame has the following shape:

```text id="sb3u02"
+-------------------------+
| Caller frame            |
+-------------------------+
| Arg spill area          |
+-------------------------+
| Return address (R_pc)   |
| Saved role/status       |
| Saved boundary/domain   |
| Saved frame register    |
| Saved R4..R7            |
+-------------------------+ <-- R_sp after prolog
| Locals / temporaries    |
+-------------------------+
```

The stack frame is a □-structured context.

It is not merely memory.

It provides the execution scope in which:

```text id="c5ty5j"
saved registers
locals
return addresses
temporary values
saved roles
saved frame registers
saved boundary domains
policy-relevant metadata
```

have meaning.

Stack-frame correctness is a Ψ-governed invariant:

```text id="qcvvfj"
saved callee registers are restored exactly once
∧ return address is frame-valid
∧ stack pointer returns to a coherent position
∧ frame context is restored or validly replaced
∧ role/capability state is restored or validly transformed
∧ boundary state is preserved or validly closed
∧ active policy permits return
```

### 6.3 Normal Function Call

A normal function call has a caller sequence and a callee sequence.

**Caller sequence**

The caller prepares arguments:

```asm id="tn6m3t"
MOV R0, Ra
MOV R1, Rb
MOV R2, Rc
MOV R3, Rd
```

Extra arguments are spilled onto the stack:

```asm id="ubmvd2"
PUSH Re
```

If the call is protected, the caller performs capability or policy checks:

```asm id="svrr87"
CHK_CAP CAP_CALL_FOO, label_fail
CHK_POL POL_CALL_FOO, label_fail
```

If the call crosses a frame or boundary, it may perform frame or boundary preparation:

```asm id="aunr7f"
FRM_CALL FR_FOO, foo_label
```

or:

```asm id="pfuvo7"
ISO_ENTER ctx
CALL foo_label
```

If the call closes an active boundary context, the profile may use:

```asm id="q9jvfy"
ISO_EXIT
CALL foo_label
```

but only when an active boundary / isolation context exists and policy permits exit.

Then the call is performed:

```asm id="pwrncc"
CALL foo_label
```

After return, the caller cleans the outgoing argument area if needed:

```asm id="b7gtmv"
ADDI R_sp, R_sp, n_extra * WORD_SIZE
```

Return values are placed in:

```text id="qfqwed"
R0
```

and optionally:

```text id="sm6h1v"
R1
```

Operator reading:

| Step                    | Operator reading                               |
| ----------------------- | ---------------------------------------------- |
| argument movement       | ∇                                              |
| stack spill             | ∇ under □ frame discipline                     |
| capability check        | Ω                                              |
| policy check            | Ψ                                              |
| frame call              | □ + ∇                                          |
| boundary entry          | Χ                                              |
| boundary exit           | Χ through `ISO_EXIT`, only with active context |
| call transfer           | ∇ with frame/control implications              |
| cleanup                 | ∇ under □ frame discipline                     |
| return-value acceptance | Σ-readable integration                         |

**Callee prolog**

The callee saves callee-preserved registers:

```asm id="vnwv3a"
PUSH R4
PUSH R5
PUSH R6
PUSH R7
```

It may save structural registers when the profile requires:

```asm id="be4tt7"
PUSH R_fr
PUSH R_flag
```

It may save role and boundary state when the call crosses authority or boundary structure:

```asm id="ujqqbb"
PUSH R_role
PUSH R_iso
```

It allocates local storage:

```asm id="qakshq"
SUBI R_sp, R_sp, frame_size_locals
```

It may establish a frame pointer or frame register:

```asm id="b8bl17"
FRM_SET R_fr, R_sp
```

Operator reading:

| Step                  | Operator reading                 |
| --------------------- | -------------------------------- |
| save registers        | ∇                                |
| save structural state | ∇ under □ / Ω / Χ / Ψ discipline |
| allocate locals       | ∇                                |
| set frame context     | □                                |
| enforce frame policy  | Ψ                                |

**Callee body**

The callee uses:

```text id="gdd9bx"
R0–R3  = arguments / caller-saved temporaries
R4–R7  = preserved local registers
R_sp   = stack pointer
R_fp   = frame pointer if used
R_fr   = active frame context
R_role = active role
R_iso  = active boundary / isolation domain
```

All memory access remains:

```text id="ttapvk"
frame-constrained
role/capability-constrained
boundary-constrained
policy-constrained
```

**Callee epilog**

The callee places the return value in `R0`:

```asm id="lxm5w1"
MOV R0, Rresult
```

It releases local storage and restores saved registers:

```asm id="so1m8x"
ADDI R_sp, R_sp, frame_size_locals
POP  R7
POP  R6
POP  R5
POP  R4
```

It restores structural state if saved:

```asm id="dr6v00"
POP R_flag
POP R_fr
```

It restores role and boundary state if saved:

```asm id="xgw0x1"
POP R_iso
POP R_role
```

It returns:

```asm id="cgahij"
RET
```

`RET` is an ∇-family control instruction with frame-restoration obligations.

At the calling-convention level, a valid return is also Σ-readable because it integrates the callee’s result and restores the caller-visible execution state.

This does not make `RET` a base Σ operator.

It means the calling convention imposes integration discipline on the return boundary.

### 6.4 Call Validity

A call is valid when:

```text id="f9kkfc"
target distinguished
∧ target label lies in executable frame
∧ π_CPU ∈ Π_CPU
∧ argument registers are prepared
∧ stack frame is coherent
∧ caller-saved / callee-saved convention is respected
∧ role/capability state permits call
∧ boundary state permits transfer or valid closure
∧ active policy permits call
∧ return path is valid
```

In compact form:

```text id="icbwlv"
valid_call(s_cpu, target) iff
    Δ_target(target)
    ∧ π_CPU ∈ Π_CPU
    ∧ frame_valid(target, s_cpu)
    ∧ role_ok(call, s_cpu)
    ∧ boundary_ok(call, s_cpu)
    ∧ policy_ok(P, s_cpu, call)
    ∧ return_context_available(s_cpu)
```

Invalid call outcomes are typed:

```text id="kks8or"
invalid target
    → Φ control fault

missing capability
    → Ω / Ψ denial

invalid frame
    → □ / Φ fault

boundary violation
    → Χ / Ψ denial

unbalanced boundary exit
    → Χ violation / Φ trap / Ψ denial

policy denial
    → Ψ denial / Φ policy trap
```

### 6.5 Return Validity

A return is valid when:

```text id="nifljl"
return address is present
∧ return address lies in executable permitted frame
∧ stack pointer is restored
∧ callee-saved registers are restored
∧ frame register is restored or validly updated
∧ role/capability state is not leaked
∧ boundary state is preserved or validly closed
∧ active policy permits return
∧ result integration is valid
```

In compact form:

```text id="c76hnq"
valid_return(s_cpu) iff
    return_address_valid(s_cpu)
    ∧ frame_restore_valid(s_cpu)
    ∧ register_restore_valid(s_cpu)
    ∧ role_restore_valid(s_cpu)
    ∧ boundary_restore_valid(s_cpu)
    ∧ policy_ok(P, s_cpu, RET)
    ∧ result_integration_valid(s_cpu)
```

Return failure remains operator-typed:

```text id="xkepri"
invalid return address
    → Φ return fault

role leak
    → Ω / Ψ denial

boundary leak
    → Χ / Ψ denial

unbalanced ISO_EXIT on return path
    → Χ violation / Φ trap / Ψ denial

frame mismatch
    → □ / Φ fault

invalid result integration
    → Σ / Φ failure
```

### 6.6 Leaf Functions

A leaf function performs no nested call.

A minimal leaf sequence is:

```asm id="bkklgb"
SUBI R_sp, R_sp, frame_size_locals
; body
ADDI R_sp, R_sp, frame_size_locals
RET
```

Leaf functions may omit callee-saved register spills if they do not modify preserved registers.

Leaf validity requires:

```text id="tqi2aw"
stack pointer restored
∧ frame invariants preserved
∧ return target valid
∧ role/capability state not leaked
∧ boundary state preserved
∧ active Ψ policy permits return
```

Leaf functions are not exempt from operator discipline.

They are simplified call frames under the same invariants.

### 6.7 Tail Calls

A tail call reuses the current frame when the function returns directly into another function call.

Example:

```asm id="pxxvoy"
MOV R0, Rarg0
MOV R1, Rarg1
MOV R2, Rarg2
MOV R3, Rarg3
JMP g_label
```

A tail call is valid when:

```text id="j4ywfb"
current frame can be reused
∧ caller-visible invariants are preserved
∧ target function is authorized
∧ boundary state permits transfer
∧ policy permits the transfer
```

Operator reading:

```text id="visz3a"
argument preparation  = ∇
target distinction    = Δ
transfer              = Δ / ∇ control transition
frame reuse           = □ preservation
boundary preservation = Χ where relevant
policy constraint     = Ψ
```

Tail calls are frame-preserving control transfers under □, Χ, and Ψ invariants.

They are not untyped jumps.

### 6.8 Recursive Calls

Recursion is valid when each invocation creates or reuses a coherent frame.

Recursive validity requires:

```text id="d09h79"
new frame or valid reused frame
∧ stack bounds respected under policy
∧ callee-saved registers preserved per invocation
∧ return address valid per invocation
∧ role/capability state not leaked across frames
∧ boundary state coherent across nested calls
```

A Ψ policy may define:

```text id="vr1ern"
maximum recursion depth
stack bounds
allowed recursive targets
audit obligations
tail-call conversion conditions
boundary-depth limits
```

Recursive calls remain normal PMS-CPU calls under stronger frame and policy constraints.

### 6.9 Reentrancy

Reentrancy is valid when a function can be entered while prior execution of the same function or protected region remains active.

Reentrancy requires:

```text id="x34c1s"
frame independence or protected shared state
∧ role/capability safety
∧ boundary safety
∧ commit discipline for shared writes
∧ policy-compatible interruption or re-entry
```

Reentrancy may involve:

```text id="g19ucx"
interrupt handler re-entry
recursive entry
callback entry
scheduler-induced entry
concurrent abstract contexts
```

A reentrant function must make shared state safe through:

```text id="e2qxfq"
Θ ordering
Χ boundary separation
Σ commit discipline
Ψ policy constraints
```

### 6.10 System Call / Trap Calling Convention

System calls cross a role and protection boundary.

In PMS-CPU, user-to-kernel entry is represented as:

```text id="r9zaag"
Φ + Ω + □ + Χ + Ψ
```

This is a PMS-CPU trap/syscall control-transfer convention.

It is not the ordinary PMS-CPU function calling convention.

It is also not the PMS-OS syscall ABI.

The required distinction is:

```text id="w8g3co"
ordinary PMS-CPU function calling convention
    uses R0–R3 as argument registers,
    R0/R1 as return registers,
    and R4–R7 as callee-saved registers.

PMS-CPU trap/syscall control-transfer convention
    defines the operator-typed transition into a handler or kernel context:
    Φ + Ω + □ + Χ + Ψ.

PMS-OS syscall ABI
    is the OS-level kernel-service register/profile convention specified in
    04_pms_os.md.
```

The user-side CPU trap convention may place syscall number and arguments in registers:

```asm id="k0f7uy"
MOVI R0, SYS_WRITE
MOV  R1, Rfd
MOV  R2, Rbuf
MOV  R3, Rlen
```

Then it executes a trap:

```asm id="qg40sk"
TRAP #0
```

The result returns in:

```text id="dmqie8"
R0
```

Operator reading:

| Step                 | Operator reading       |
| -------------------- | ---------------------- |
| syscall number       | Δ                      |
| arguments            | ∇                      |
| trap entry           | Φ                      |
| role transition      | Ω                      |
| kernel frame entry   | □                      |
| user/kernel boundary | Χ                      |
| syscall policy check | Ψ                      |
| result return        | Σ-readable integration |

The trap entry is Φ.

The role transition is Ω.

The frame switch is □.

The boundary crossing is Χ.

The policy checks are Ψ.

The syscall result is integrated through Σ-readable return discipline.

### 6.11 Kernel Handler Convention

A kernel handler entered through Φ saves context:

```asm id="c3u0yx"
PUSH R4
PUSH R5
PUSH R6
PUSH R7
PUSH R_fr
PUSH R_flag
PUSH R_pc
```

It may save boundary and role state:

```asm id="rbbspl"
PUSH R_role
PUSH R_iso
```

It enters the kernel frame:

```asm id="cwb41j"
FRM_ENTER FR_KERNEL_STACK
```

It switches role:

```asm id="m1t7bb"
SET_ROLE ROLE_KERNEL
```

It dispatches by syscall number using Δ:

```asm id="i91rlq"
CMPI R0, SYS_WRITE
BEQ  sys_write
```

Return path:

```asm id="iet59c"
SET_ROLE ROLE_USER
FRM_LEAVE
EXC_RET
```

The kernel return is valid only if:

```text id="a7k2ki"
kernel role is not leaked
∧ user frame is restored
∧ return address is user-frame valid
∧ boundary constraints are preserved or validly closed
∧ active policy permits return
∧ result state is validly integrated
```

### 6.12 Trap and Exception Calling Convention

A trap or exception follows the same structural discipline as a syscall, but its cause may be fault, explicit trap, interrupt, policy violation, boundary violation, unbalanced boundary exit, timeout escalation, or exceptional arithmetic.

Trap entry:

```text id="rs9esc"
save context
→ enter handler frame
→ establish handler role
→ record trap cause
→ branch to handler
```

Operator reading:

```text id="jejyl9"
Φ entry
Ω handler authority
□ handler frame
Χ boundary preservation where relevant
Ψ trap policy
Σ-readable restoration on return
```

Exception return:

```asm id="vdfpgw"
EXC_RET
```

is Φ-family behavior.

It returns execution to a saved context while restoring frame, role, boundary, flags, and control state.

Exception return is valid only if:

```text id="q30gn6"
saved context exists
∧ saved frame is valid
∧ saved role is permitted
∧ saved boundary domain is coherent
∧ return address executable
∧ policy permits return
```

### 6.13 Boundary-Preserving Calls

Some calls cross boundary domains.

Examples:

```text id="hc9s7b"
user → kernel
sandbox → host
module → privileged service
transaction context → external frame
handler → interrupted frame
```

Boundary-preserving call validity requires:

```text id="l92me6"
Χ relation declared
∧ source frame valid
∧ target frame valid
∧ role/capability permits crossing
∧ policy permits crossing
∧ return boundary is valid
∧ no protected data leaks across boundary
```

Boundary exit through `ISO_EXIT` has an additional rule:

```text id="ehjaj7"
ISO_EXIT requires active boundary / isolation context.
```

Invalid:

```text id="hqp79v"
ISO_EXIT without active boundary / isolation context
```

Typed result:

```text id="vnghhj"
Χ violation
→ Φ trap or Ψ denial
→ optional Σ audit / rejection commit
```

A sealed isolation context has a distinct rule:

```text id="b3oa6a"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="c6pxix"
valid exit
closure
rollback
audit
commit
```

If the boundary cannot be preserved or validly closed, the call must fail through:

```text id="xutwvm"
Χ violation
Ψ denial
Φ trap
Σ audit / rejection commit where required
```

Boundary-preserving calls are a CPU-level projection of PMS Base Distance.

They do not redefine Χ.

### 6.14 Calling Convention and Commit Discipline

Call return is integration-sensitive.

A valid return integrates:

```text id="foes59"
callee result
restored registers
restored frame
restored role state
restored boundary state
return address
caller-visible state
```

This is Σ-readable at the calling-convention level.

The call instruction may remain ∇-family and the return instruction may remain ∇-family in the ISA.

But the calling convention imposes Σ discipline on the call/return boundary.

Correct:

```text id="zewf2w"
RET is an ∇ control instruction with Σ-readable integration discipline.
```

Incorrect:

```text id="b03voz"
RET redefines the base Σ operator.
```

Commit discipline also applies to boundary closure:

```text id="yh5k27"
ISO_EXIT may require Σ-readable closure or audit integration under a
declared profile.
```

This does not make `ISO_EXIT` a Σ instruction.

It means the boundary-exit path may impose integration obligations.

### 6.15 Reentrancy, Recursion, and Ψ Invariants

PMS-CPU uses Ψ invariants to maintain calling-convention correctness.

Key invariants:

| Invariant               | Meaning                                                            |
| ----------------------- | ------------------------------------------------------------------ |
| frame correctness       | `R_sp`, `R_fp`, and `R_fr` define a coherent □ frame               |
| register preservation   | callee-saved registers are restored exactly once                   |
| caller responsibility   | caller-saved registers may be clobbered                            |
| return validity         | return address lies in an executable permitted frame               |
| role safety             | elevated Ω state is not returned to unauthorized code              |
| boundary safety         | user frames do not acquire kernel or protected-domain reachability |
| boundary-exit safety    | `ISO_EXIT` requires active boundary / isolation context            |
| sealed-isolation safety | sealed contexts forbid expansion but permit valid closure paths    |
| policy safety           | active Ψ constraints are preserved across call/return              |
| commit safety           | result integration occurs only at valid return boundary            |
| trap safety             | trap frames restore only valid saved contexts                      |

Recursion is valid when each invocation creates or reuses a coherent frame and the frame stack remains well-formed.

Reentrancy is valid when shared state, role state, boundary state, and commit points remain policy-compatible.

### 6.16 Calling Convention Validity Predicate

A compact predicate is:

```text id="c5c4uy"
valid_calling_convention_step(s_cpu, I, s_cpu') iff
    π_CPU ∈ Π_CPU
    ∧ call_instruction_or_return(I)
    ∧ frame_discipline_valid(s_cpu, I, s_cpu')
    ∧ register_discipline_valid(s_cpu, I, s_cpu')
    ∧ role_discipline_valid(s_cpu, I, s_cpu')
    ∧ boundary_discipline_valid(s_cpu, I, s_cpu')
    ∧ policy_ok(P, s_cpu, I)
    ∧ return_or_call_target_valid(s_cpu, I, s_cpu')
    ∧ integration_discipline_valid(s_cpu, I, s_cpu')
```

This predicate applies to:

```text id="nxjsvz"
CALL
RET
FRM_CALL
FRM_RET
TRAP
EXC_RET
tail call
syscall entry
kernel return
handler return
```

For boundary exit inside call or return structure:

```text id="pe58cw"
valid_calling_convention_step(s_cpu, ISO_EXIT, s_cpu') iff
    π_CPU ∈ Π_CPU
    ∧ active_boundary_context(s_cpu) = true
    ∧ role_discipline_valid(s_cpu, ISO_EXIT, s_cpu')
    ∧ boundary_discipline_valid(s_cpu, ISO_EXIT, s_cpu')
    ∧ policy_ok(P, s_cpu, ISO_EXIT)
    ∧ integration_discipline_valid(s_cpu, ISO_EXIT, s_cpu') where required
```

Unbalanced `ISO_EXIT` is invalid:

```text id="y5wzzd"
active_boundary_context(s_cpu) = false
    ⇒ ISO_EXIT invalid
```

### 6.17 Calling Convention Summary

The PMS-CPU calling convention defines:

```text id="eyy071"
arguments in R0–R3

return in R0 / R1

caller-saved R0–R3

callee-saved R4–R7

stack-based frames

frame-register discipline

trap-based user/kernel crossing

role-aware call boundaries

boundary-aware call boundaries

policy-aware call boundaries

ISO_EXIT active-context discipline

sealed-isolation closure discipline

Σ-readable return integration
```

Architectural consequence:

```text id="gjiyji"
A PMS-CPU call is valid when it preserves frame, register, role,
boundary, commit, and policy invariants across control transfer.
```

### 6.18 PMS-RUST Boundary-Exit Mapping Note

PMS-CPU names the architecture-level boundary-exit instruction:

```text id="b88i3f"
ISO_EXIT
```

PMS-RUST exposes a bounded artifact/runtime command:

```text id="g75yyb"
chi_exit
```

The conceptual alignment is:

```text id="cm91yu"
PMS-CPU ISO_EXIT
    = virtual CPU architecture-level boundary-exit instruction

PMS-RUST chi_exit
    = runtime / DSL / validator command evidencing bounded boundary-exit
      behavior under the PMS-RUST v0.1 profile

PMS Base Χ
    = Distance
```

Shared rule:

```text id="y0g39d"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary:

```text id="k7a6ow"
chi_exit does not complete PMS-CPU ISO_EXIT.

chi_exit does not redefine PMS Base Χ.

chi_exit does not validate PMS Base.
```

### 6.19 Calling Convention Invariants

```text id="qfscwr"
CPU-CC1: PMS-CPU calling convention is virtual, not a platform ABI claim

CPU-CC2: Π_CPU denotes the PMS-CPU program domain

CPU-CC3: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-CC4: arguments use R0–R3 by canonical convention

CPU-CC5: returns use R0 and optionally R1

CPU-CC6: R0–R3 are caller-saved

CPU-CC7: R4–R7 are callee-saved

CPU-CC8: stack frames are □-structured contexts

CPU-CC9: role/capability state is Ω-governed across calls

CPU-CC10: PMS Base Χ = Distance

CPU-CC11: boundary state is Χ-governed across protected calls

CPU-CC12: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-CC13: ISO_EXIT requires an active boundary / isolation context

CPU-CC14: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-CC15: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-CC16: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
          not the PMS-CPU ISO_EXIT instruction

CPU-CC17: active policy Ψ constrains call, return, trap entry, trap return,
          and boundary exit

CPU-CC18: RET remains an ∇-family control instruction with Σ-readable
          integration discipline

CPU-CC19: syscall/trap entry is Φ + Ω + □ + Χ + Ψ structured at the PMS-CPU
          control-transfer level

CPU-CC20: PMS-CPU trap/syscall control transfer is distinct from the ordinary
          PMS-CPU function calling convention and distinct from the PMS-OS
          syscall ABI

CPU-CC21: recursive and reentrant calls require frame, role, boundary,
          commit, and policy coherence

CPU-CC22: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-CC23: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-CC24: calling convention specification is a virtual CPU architecture
          claim and does not validate PMS Base
```

### 6.20 Boundary Statement

The correct boundary for this chapter is:

```text id="x09psx"
The PMS-CPU calling convention defines operator-typed control-transfer
discipline for ordinary calls, returns, leaf functions, tail calls,
recursive calls, reentrant calls, syscalls, traps, handlers, boundary exits,
and exception returns.

This is a virtual CPU calling-convention architecture claim.

The ordinary PMS-CPU function calling convention is distinct from the
PMS-CPU trap/syscall control-transfer convention and distinct from the
PMS-OS syscall ABI.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

This chapter does not claim a physical ABI, platform ABI, operating-system
ABI, completed compiler backend, fabricated hardware, or PMS Base
validation.
```

---

## 7. Interrupts, Traps, and Recontextualization

PMS-CPU handles interrupts, traps, faults, syscalls, policy denials, boundary violations, boundary-exit violations, timeouts, and exceptional control flow through operator-typed event transitions.

The active PMS-CPU program is:

```text id="ooeqeg"
π_CPU ∈ Π_CPU
```

where:

```text id="y6pddm"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The primary operator is:

```text id="g6ev4c"
Φ
```

Φ is the recontextualization operator. At the virtual CPU level, Φ changes the execution context while preserving trace accountability. It does not erase the old state; it packages the old state into a recoverable, auditable, or restorable context.

The PMS-CPU event model uses:

| Phenomenon                  | Operator structure                                      |
| --------------------------- | ------------------------------------------------------- |
| interrupt                   | Φ                                                       |
| trap / syscall              | Φ + Ω + □ + Χ + Ψ                                       |
| fault                       | Φ                                                       |
| timeout / missing event     | Λ, optionally followed by Φ                             |
| handler frame entry         | □                                                       |
| role / privilege transition | Ω                                                       |
| protected-domain crossing   | Χ projection                                            |
| boundary exit               | Χ through `ISO_EXIT`, only with active boundary context |
| unbalanced boundary exit    | Χ violation → Φ / Ψ / Σ-audit / halt / stuck            |
| policy validation           | Ψ                                                       |
| exception return            | Φ with Σ-readable restoration discipline                |
| audit / rejection commit    | Σ where profile requires integration                    |

The central claim is:

```text id="fymtfr"
PMS-CPU represents interrupts, traps, syscalls, faults, timeouts, policy
denials, boundary violations, and boundary-exit violations as
operator-typed transitions rather than external control anomalies.
```

Claim type:

```text id="o03jc4"
virtual CPU interrupt/trap architecture claim
```

Boundary:

```text id="zfwfbs"
This defines the PMS-CPU virtual event and recontextualization model.

It does not claim a physical interrupt controller.

It does not specify fabricated hardware.

It does not complete a kernel implementation.

It does not validate PMS Base.
```

A concrete PMS-CPU event run records:

```text id="sx3c5k"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="wwm245"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="qctts3"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="h4ehug"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 7.1 Recontextualization Principle

A trap or interrupt does not leave PMS-CPU execution.

It changes the current execution context.

The recontextualization structure is:

```text id="iu2dqy"
current context
    → cause distinguished
    → context saved
    → handler frame selected
    → role/capability adjusted
    → boundary checked
    → policy checked
    → handler entered
```

Operator reading:

```text id="c0z7wi"
Δ cause
∇ save state
Ω establish handler authority
□ enter handler frame
Χ preserve or mediate boundary
Ψ permit entry
Φ recontextualize
```

On return:

```text id="ywltgx"
handler context
    → result / effect integrated where required
    → saved frame restored
    → saved role restored
    → saved boundary state restored or validly closed
    → saved PC restored
    → execution resumes
```

Operator reading:

```text id="ilyapg"
Φ return
Σ-readable restoration discipline
□ restore frame
Ω restore role
Χ restore boundary
Ψ permit return
```

Φ therefore preserves continuity.

It is not untyped escape.

### 7.2 Event Sources

PMS-CPU recognizes the following virtual event sources.

| Event source           | Description                                               | Operator reading                             |
| ---------------------- | --------------------------------------------------------- | -------------------------------------------- |
| asynchronous interrupt | event external to the current instruction stream          | Δ cause → Φ handler entry                    |
| synchronous trap       | event caused by the executing instruction                 | Φ + Ω transition                             |
| syscall                | controlled user-to-kernel transition                      | Φ + Ω + □ + Χ + Ψ                            |
| fault                  | invalid or exceptional execution condition                | failed validity check → Φ                    |
| timeout                | expected event absent                                     | Λ, optionally Φ                              |
| policy denial          | active Ψ forbids continuation                             | Ψ denial → Φ / halt / audit                  |
| boundary violation     | Χ-projected boundary is crossed invalidly                 | Χ violation → Φ / Ψ                          |
| unbalanced `ISO_EXIT`  | boundary exit without active boundary / isolation context | Χ violation → Φ / Ψ / Σ-audit / halt / stuck |
| invalid commit         | Σ precondition fails                                      | Σ failure → Φ / Ψ                            |
| explicit reframe       | instruction requests interpretive/context shift           | Φ                                            |

**Asynchronous interrupts**

Asynchronous interrupts originate outside the current instruction stream.

Examples:

```text id="utayfh"
timer interrupt
device interrupt
inter-processor interrupt in a multi-core virtual profile
external signal
host event admitted through virtual boundary
```

Operator reading:

```text id="wi758g"
external condition distinguished
→ Φ handler entry
```

**Synchronous traps**

Synchronous traps are caused by the executing instruction.

Examples:

```text id="gi2n29"
TRAP
syscall entry
breakpoint
privileged operation from unauthorized role
explicit recontextualization
unbalanced ISO_EXIT
```

Operator reading:

```text id="w8flhz"
instruction event
→ Φ + Ω transition
```

**Faults**

Faults represent invalid or exceptional execution conditions.

Examples:

```text id="v0qal0"
illegal opcode
invalid frame access
role/capability violation
divide error
invalid memory access
boundary violation
policy violation
commit failure
unbalanced boundary exit
sealed-isolation expansion violation
```

Operator reading:

```text id="wgpl3x"
failed Δ / □ / Ω / Χ / Σ / Ψ check
→ Φ fault path
```

**Non-events**

Non-events represent expected conditions that fail to occur.

Examples:

```text id="mvcg1a"
WAIT timeout
no device readiness
empty queue
scheduler idle
missing interrupt
missing host response
```

Operator reading:

```text id="g72mqw"
expected event absent
→ Λ
```

Λ may later escalate into Φ if the system recontextualizes execution into a scheduler, timeout handler, denial handler, or recovery path.

### 7.3 Interrupt Vector Table

PMS-CPU dispatches interrupts and traps through a virtual vector table.

Example:

```text id="h4ks66"
IVT[0] = reset
IVT[1] = timer_interrupt
IVT[2] = device0_interrupt
IVT[3] = syscall_entry
IVT[4] = illegal_instruction
IVT[5] = boundary_fault
IVT[6] = policy_fault
IVT[7] = unbalanced_iso_exit
IVT[8] = sealed_isolation_fault
...
```

The interrupt or trap cause is distinguished through Δ:

```asm id="ouzj5j"
CMPI R_irq, irq
JMP  IVT + irq
```

Handler entry is Φ:

```text id="eb8be7"
cause → handler context
```

A valid vector dispatch requires:

```text id="z9o3o2"
cause distinguished
∧ vector entry exists
∧ handler frame exists
∧ role transition is permitted
∧ boundary rules permit handler access
∧ policy permits entry
```

A missing or invalid vector entry is a Φ fault or Ψ denial depending on profile.

The vector table is virtual architecture state.

It does not specify physical interrupt-controller hardware.

### 7.4 Φ Entry Protocol

A Φ entry saves the interrupted context, switches frame and role, records cause metadata, validates boundary and policy, and transfers control to a handler.

Canonical entry sequence:

```asm id="ydxb03"
PUSH R_pc
PUSH R_flag
PUSH R_fr
PUSH R_role
PUSH R_iso
PUSH R4
PUSH R5
PUSH R6
PUSH R7
```

Switch role:

```asm id="b8w9gu"
SET_ROLE ROLE_KERNEL
```

Switch frame:

```asm id="p1rblj"
FRM_ENTER FR_KERNEL_STACK
```

Record cause metadata:

```text id="g1mhiy"
m.trap.cause        = cause_code
m.trap.depth        = m.trap.depth + 1
m.trap.return_frame = previous_frame
m.trap.return_role  = previous_role
m.trap.return_iso   = previous_boundary_domain
m.trap.return_pc    = previous_pc
```

Jump to handler:

```text id="z8xk4q"
R_pc' = handler_entry
```

Operator reading:

| Entry step                    | Operator |
| ----------------------------- | -------- |
| distinguish cause             | Δ        |
| save interrupted context      | ∇        |
| switch role                   | Ω        |
| switch frame                  | □        |
| preserve/check boundary state | Χ        |
| install trap metadata         | Φ        |
| validate handler policy       | Ψ        |
| dispatch handler              | Δ / Φ    |

A Φ entry is valid only if:

```text id="v2ocbr"
cause exists
∧ handler exists
∧ handler frame exists
∧ role transition is authorized
∧ boundary state is preserved or validly transformed
∧ active policy permits handler entry
```

### 7.5 Handler Execution

Handlers execute inside a privileged or otherwise declared handler frame and role context.

A handler may:

```text id="j1pr40"
acknowledge an interrupt
inspect fault cause
update scheduler state
repair or terminate a context
perform syscall dispatch
update kernel data structures
record audit events
trigger policy enforcement
resolve boundary violation
resolve unbalanced boundary-exit attempt
abort or commit transaction state
return to interrupted context
```

Handler execution remains PMS-CPU execution.

It does not leave the operator model.

Typical handler structure:

```text id="jg2jlu"
Δ distinguish cause
Ω confirm authority
□ operate inside handler frame
Χ preserve boundary / reachability discipline
Ψ enforce handler policy
∇ mutate handler-visible state
Θ update ordering metadata
Σ commit handler-visible effects if required
Φ return or recontextualize further
```

A handler is valid when:

```text id="gjc9x7"
handler frame is coherent
∧ handler role is authorized
∧ handler memory access is frame-valid
∧ boundary constraints are preserved
∧ policy permits handler effects
∧ return path remains available unless handler halts or kills context
```

### 7.6 Φ Exit and Exception Return

A Φ exit restores context and returns from the handler.

Canonical exit sequence:

```asm id="wy1hyz"
SET_ROLE ROLE_USER
FRM_LEAVE
POP R7
POP R6
POP R5
POP R4
POP R_iso
POP R_role
POP R_fr
POP R_flag
POP R_pc
EXC_RET
```

`EXC_RET` is a Φ-family instruction.

It recontextualizes execution back into the saved context.

A valid exception return requires:

```text id="g3jvgd"
saved frame is valid
∧ saved role is permitted
∧ saved boundary domain is coherent
∧ return address is executable
∧ policy permits return
∧ trap nesting depth is coherent
∧ handler-visible effects have been committed, discarded, or staged
  according to the active profile
```

At the calling-convention level, exception return is also Σ-readable:

```text id="wfl8o3"
handler result / restored context
    → integrated into resumed execution
```

This is integration discipline on the return path.

It does not redefine Φ as Σ.

### 7.7 Syscall Entry and Kernel Boundary

A syscall is a structured trap from user or application context into a kernel or service context.

User-side PMS-CPU trap convention:

```asm id="i7oi78"
MOVI R0, SYS_WRITE
MOV  R1, Rfd
MOV  R2, Rbuf
MOV  R3, Rlen
TRAP #0
```

Operator reading:

```text id="xkzn9n"
Δ syscall number
∇ argument placement
Φ trap entry
Ω role transition
□ kernel frame entry
Χ user/kernel boundary mediation
Ψ syscall policy check
Σ-readable result integration
```

A syscall entry is valid only if:

```text id="wb1uvt"
syscall number is distinguished
∧ syscall vector exists
∧ user frame is valid
∧ kernel frame exists
∧ role transition is permitted
∧ user/kernel boundary is preserved
∧ policy permits syscall entry
```

A syscall return is valid only if:

```text id="yllry2"
kernel role is not leaked
∧ user frame is restored
∧ user boundary state is coherent
∧ return address is user-executable
∧ policy permits return
∧ result is integrated through the declared return convention
```

This prepares PMS-OS to treat syscalls as operator-typed kernel events.

Boundary:

```text id="wl2v4o"
This is the PMS-CPU trap/syscall control-transfer convention.

It is distinct from the ordinary PMS-CPU function calling convention.

It is also distinct from the PMS-OS syscall ABI specified in 04_pms_os.md.
```

### 7.8 Nested Interrupts

Nested interrupts are allowed when the CPU status and active policy permit them.

Example condition:

```text id="jw463d"
R_flag.interrupt_enable = 1
```

Each nested Φ entry must:

```text id="ro6wq3"
push a new handler frame
increment nesting depth
preserve previous return state
respect boundary restrictions
respect role/capability restrictions
respect Ψ nesting policy
```

A policy may define:

```text id="lu9493"
max_interrupt_depth
allowed_preemption_classes
non-reentrant handlers
critical sections
priority rules
deferred delivery rules
```

Nested interrupts are not uncontrolled recursion.

They are Φ transitions constrained by:

```text id="tgfrj3"
□ frame discipline
Ω authority
Χ boundary preservation
Θ ordering
Ψ nesting policy
```

Failure modes:

| Failure                      | Typed handling     |
| ---------------------------- | ------------------ |
| nesting depth exceeded       | Ψ denial / Φ fault |
| handler not reentrant        | Ψ denial           |
| boundary cannot be preserved | Χ / Ψ denial       |
| priority conflict            | Θ / Ψ handling     |
| trap-frame overflow          | Φ fault / halt     |

### 7.9 Faults and Policy Violations

Faults occur when CPU execution fails a validity condition.

| Failure                              | Operator reading                                         |
| ------------------------------------ | -------------------------------------------------------- |
| illegal opcode                       | Δ classification failure → Φ                             |
| invalid frame access                 | □ violation → Φ                                          |
| privileged instruction in user mode  | Ω violation → Φ                                          |
| invalid memory access                | Δ / □ / Χ failure → Φ                                    |
| boundary violation                   | Χ projection failure → Φ / Ψ                             |
| unbalanced `ISO_EXIT`                | Χ boundary-exit failure → Φ / Ψ / Σ-audit / halt / stuck |
| sealed-isolation expansion violation | Χ / Ψ failure → Φ                                        |
| policy denial                        | Ψ violation → Φ or halt                                  |
| invalid commit                       | Σ precondition failure → Φ / Ψ                           |
| timeout                              | Λ, optionally Φ scheduler path                           |
| invalid return                       | Φ return fault / Ψ denial                                |
| trap nesting violation               | Θ / Ψ violation                                          |

PMS-CPU does not treat these as untyped errors.

Each failure remains operator-readable.

A fault path may:

```text id="e0tcos"
trap into handler
halt
record audit
deny continuation
rollback staged effects
quarantine boundary state
discard transaction state
```

depending on active profile and policy.

### 7.10 Timeouts and Λ

Timeouts and idle conditions are represented through Λ.

Example:

```asm id="cn31hj"
WAIT cond_reg, timeout_reg
```

If readiness occurs:

```text id="fva6wt"
continue through normal ∇ / Θ progression
```

If readiness is absent:

```text id="gs8yqy"
Λ records non-event
```

The non-event may:

```text id="do52ay"
branch to timeout handler
leave CPU idle
trigger scheduler entry
raise Φ recontextualization
be policy-denied if absence exceeds Ψ bound
commit audit event if profile requires
```

Example escalation:

```text id="l5f4to"
Λ_timeout → Φ_scheduler
```

Λ represents absence.

Φ represents context shift caused by how the system handles that absence.

Λ is valid only when an expectation exists.

### 7.11 Isolation, Boundary Exit, and Interrupts

If an isolation domain is active:

```text id="ekzb0a"
R_iso = domain_id
```

then interrupt and trap handling must preserve boundary discipline.

Rules:

```text id="qnnsyu"
handler may not access isolated regions unless Ψ permits

EXC_RET must restore boundary state coherently

trap frames must not leak protected data

kernel frame entry must be authorized

boundary violations remain Χ / Ψ-readable
```

`ISO_EXIT` is the PMS-CPU architecture-level boundary-exit instruction.

It is valid only when:

```text id="swk9o6"
active boundary / isolation context exists
∧ role/capability permits exit
∧ active policy permits exit
∧ declared CPU profile permits boundary closure
```

Unbalanced exit is invalid:

```text id="vqyfm9"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

Typed result:

```text id="v0kh7v"
Χ violation
Φ trap
Ψ denial
Σ audit / rejection commit
halt
stuck
```

A sealed isolation context has a distinct rule:

```text id="eryzc1"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="ftk7zo"
valid exit
closure
rollback
audit
commit
```

An interrupt handler may need a privileged view of some state, but this view must be explicitly mediated:

```text id="u9i5lw"
Ω handler authority
∧ □ handler frame
∧ Χ boundary relation
∧ Ψ handler policy
```

PMS-CPU Χ remains an implementation-layer projection of PMS Base Distance.

Interrupt handling must not collapse Distance into untyped access.

PMS-RUST mapping note:

```text id="uf3d1s"
PMS-CPU ISO_EXIT is an architecture-level virtual ISA instruction.

PMS-RUST chi_exit is an artifact/runtime boundary-exit command.

Both share the bounded rule that exit requires active isolation / boundary
context, but they are not the same layer.
```

Boundary:

```text id="fsbv4f"
chi_exit does not complete PMS-CPU ISO_EXIT.

chi_exit does not redefine PMS Base Χ.

chi_exit does not validate PMS Base.
```

### 7.12 Interrupt Ordering and Θ

Interrupt processing is ordered through Θ.

Θ may represent:

```text id="c2qoeo"
interrupt priority order
handler nesting order
scheduler progression
happens-before relation among events
fence or critical-section ordering
deferred interrupt delivery
trap-return ordering
```

Example policy:

```text id="xqeayj"
higher-priority interrupts may preempt lower-priority handlers
```

or:

```text id="iq9izl"
critical section forbids asynchronous Φ entry until Θ boundary exits
```

Θ is ordering, not physical time.

Hardware timers, timestamps, durations, and deadlines are data in CPU state or meta-state.

A timer interrupt is a Φ event whose readiness may be determined by temporal data, while Θ orders its delivery and handler relation.

### 7.13 Event Trace Form

A PMS-CPU event trace entry may have the form:

```text id="p9r28j"
event = (
    cycle,
    op,
    event_kind,
    cause,
    R_pc,
    R_fr,
    R_role,
    R_iso,
    policy_result,
    handler,
    result,
    meta
)
```

Examples:

```text id="k26gwv"
Φ trap entry

Λ timeout

Ψ denial

Χ boundary violation

Χ unbalanced ISO_EXIT violation

Σ audit commit
```

A concrete event execution records:

```text id="u84sma"
trace_cpu(...)
```

A declared event profile determines:

```text id="m6c2hv"
Trace(...)
```

Trace metadata supports:

```text id="ys9w72"
debugging
kernel handoff
audit
replay
golden fixtures
trap validation
syscall validation
boundary violation analysis
unbalanced-exit validation
sealed-isolation validation
```

Trace evidence remains artifact evidence.

It is not PMS Base validation.

### 7.14 Event Model Summary

| Phenomenon                 | PMS operator              | Structural meaning                                  |
| -------------------------- | ------------------------- | --------------------------------------------------- |
| interrupt                  | Φ                         | asynchronous context shift                          |
| trap                       | Φ + Ω                     | controlled role/context transition                  |
| syscall                    | Φ + Ω + □ + Χ + Ψ         | user-to-kernel entry                                |
| fault                      | Φ                         | invalid state recontextualized into handler         |
| timeout                    | Λ                         | absence of expected event                           |
| handler return             | Φ                         | restoration of prior context                        |
| context restore            | Φ + Σ-readable discipline | re-enter saved execution state                      |
| isolation violation        | Χ + Ψ                     | boundary/policy failure                             |
| unbalanced `ISO_EXIT`      | Χ + Φ / Ψ                 | invalid boundary exit without active context        |
| sealed-isolation expansion | Χ + Ψ                     | forbidden reachability or scope growth              |
| priority / ordering        | Θ                         | ordered event progression                           |
| policy denial              | Ψ                         | invalid future continuation under active policy     |
| audit closure              | Σ                         | integration of audit/rejection event where required |

### 7.15 Event Model Invariants

```text id="kmoqxg"
CPU-IT1: interrupts, traps, faults, syscalls, and timeouts are operator-typed

CPU-IT2: Π_CPU denotes the PMS-CPU program domain

CPU-IT3: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-IT4: Φ recontextualizes execution without untyped erasure

CPU-IT5: Λ represents absence only under expectation

CPU-IT6: syscall entry is Φ + Ω + □ + Χ + Ψ structured at PMS-CPU
         control-transfer level

CPU-IT7: PMS-CPU trap/syscall control transfer is distinct from the ordinary
         PMS-CPU function calling convention and distinct from the PMS-OS
         syscall ABI

CPU-IT8: handler entry requires valid cause, handler frame, role transition,
         boundary discipline, and policy permission

CPU-IT9: handler return requires valid saved context, frame, role, boundary,
         policy, and restoration discipline

CPU-IT10: nested interrupts are governed by Θ ordering and Ψ policy

CPU-IT11: PMS Base Χ = Distance

CPU-IT12: boundary-sensitive interrupts preserve PMS-CPU Χ as projection of
          PMS Base Distance

CPU-IT13: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-IT14: ISO_EXIT requires an active boundary / isolation context

CPU-IT15: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-IT16: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-IT17: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
          not the PMS-CPU ISO_EXIT instruction

CPU-IT18: faults remain typed through Δ, □, Ω, Χ, Σ, Ψ, Λ, and Φ

CPU-IT19: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-IT20: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-IT21: event traces support artifact evidence but do not validate PMS Base

CPU-IT22: PMS-CPU interrupt/trap structure is virtual CPU architecture, not
          physical interrupt-controller hardware
```

### 7.16 Architectural Consequence

The PMS-CPU interrupt and trap model gives exception handling the same operator structure as ordinary execution.

The consequence is:

```text id="fr6zkt"
Interrupts, traps, syscalls, faults, returns, policy denials, boundary
violations, unbalanced boundary exits, timeouts, and sealed-isolation
violations are not external control anomalies. They are operator-typed
transitions governed by Φ, Λ, Ω, □, Χ, Σ, Θ, and Ψ.
```

This allows PMS-OS to treat PMS-CPU traps, syscalls, and interrupts as structurally typed kernel events rather than opaque processor exceptions.

It also preserves the key boundary:

```text id="trr4ut"
PMS-CPU ISO_EXIT
    = virtual CPU architecture-level boundary-exit instruction

PMS-RUST chi_exit
    = bounded artifact/runtime command

PMS Base Χ
    = Distance
```

The mapping strengthens implementation-artifact clarity.

It does not validate PMS Base.

### 7.17 Boundary Statement

The correct boundary for this chapter is:

```text id="gv6e2y"
The PMS-CPU interrupt, trap, and recontextualization model defines virtual
CPU event semantics for interrupts, traps, syscalls, faults, timeouts,
boundary violations, unbalanced boundary exits, policy denials, handler
entry, and handler return.

This is a virtual CPU interrupt/trap architecture claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

This chapter does not specify physical interrupt hardware, does not complete
a kernel, does not imply a fabricated processor, does not redefine PMS Base
Χ, and does not validate PMS Base.
```

---

## 8. Binary Encoding

PMS-CPU defines a reference binary encoding for virtual ISA instructions.

The purpose of the encoding is to preserve Δ–Ψ operator identity at decode time.

A PMS-CPU binary instruction is not just an opcode.

It carries an explicit PMS operator class.

The active PMS-CPU program is:

```text id="sdg4c9"
π_CPU ∈ Π_CPU
```

where:

```text id="fyr5ab"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

This is a virtual binary encoding for:

```text id="e1dq9e"
simulators
emulators
tooling
trace validators
binary fixtures
compiler targets
formal models
possible implementation targets
```

It does not claim fabricated hardware.

The central claim is:

```text id="j85a5l"
PMS-CPU defines a reference virtual binary encoding whose top-level
instruction tag preserves Δ–Ψ operator identity before opcode and operand
interpretation.
```

Claim type:

```text id="p4svki"
virtual CPU binary-encoding specification claim
```

Boundary:

```text id="k5286m"
This section specifies a reference virtual encoding.

It does not claim physical instruction encoding in fabricated hardware.

It does not require a specific simulator implementation.

It does not validate PMS Base.
```

A concrete PMS-CPU binary execution records:

```text id="kh2scr"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="ihs61f"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="bticey"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="e8qskn"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 8.1 Encoding Principle

The encoding principle is:

```text id="pnzrpa"
operator class first;
opcode second;
operands third;
validity checks before execution.
```

Decode order:

```text id="dwonpv"
bits
    → PMS_OP
    → OPCODE
    → FORMAT
    → operands
    → constraints
    → operator-typed instruction
```

The first architectural distinction is:

```text id="lu6w1h"
bits[31:28] → PMS_OP
```

This makes the PMS operator family visible before subopcode interpretation.

Decode is therefore Δ-readable before execution reaches the instruction’s primary operator family.

### 8.2 Word Size and Endianness

The reference encoding uses:

```text id="rqf4sc"
instruction width = 32 bits
data memory       = little-endian
ordinary PC step  = 4 bytes
```

Thus, for ordinary sequential execution:

```text id="dc9923"
R_pc' = R_pc + 4
```

A concrete PMS-CPU simulator may implement this reference encoding directly.

Other encodings may be introduced if they preserve:

```text id="y97b4v"
operator tag recoverability
instruction-family classification
operand validity
trace reconstruction
failure typing
policy and role gating
boundary discipline
commit discipline
ordering discipline
```

Alternative encodings must not erase the `PMS_OP` level unless the profile provides an equivalent, lossless operator-recovery mechanism.

### 8.3 Top-Level Instruction Layout

A PMS-CPU instruction begins with a PMS operator tag.

Reference layout:

```text id="my4vq7"
31     28 27     22 21     17 16     12 11      7 6        0
+---------+---------+---------+---------+---------+----------+
| PMS_OP  | OPCODE  |   rd    |   rs1   |   rs2   | payload  |
+---------+---------+---------+---------+---------+----------+
   4 bits   6 bits    5 bits    5 bits    5 bits    7 bits
```

Not every instruction uses all fields.

Some formats reinterpret lower bits as:

```text id="g26429"
immediate
offset
system code
policy id
frame id
trap code
context id
function field
boundary-exit mode
sealed-state flag
```

The decoded instruction has the abstract form:

```text id="mh4r7h"
I = (mnemonic, op, operands, constraints)
```

or, at binary decode stage:

```text id="rvl4lf"
I_bin = (PMS_OP, OPCODE, FORMAT, operands, payload)
```

A valid binary instruction belongs to:

```text id="s39iyl"
π_CPU ∈ Π_CPU
```

and must decode into an operator-typed instruction accepted by the active PMS-CPU profile.

### 8.4 PMS Operator Tag Encoding

The PMS operator tag is 4 bits.

```text id="x44d1e"
PMS_OP (4 bits)

0000  Δ
0001  ∇
0010  □
0011  Λ
0100  Α
0101  Ω
0110  Θ
0111  Φ
1000  Χ
1001  Σ
1010  Ψ
1011  reserved
1100  reserved
1101  reserved
1110  reserved
1111  reserved
```

This makes the operator family visible before subopcode interpretation.

The decoder performs:

```text id="vkso1y"
Δ classify PMS_OP
Δ classify OPCODE
Δ classify format
Δ classify operands
```

Invalid tags or invalid operator/opcode combinations produce a Φ fault.

Reserved tags may be used by future profiles only if the profile declares:

```text id="t4lbgu"
operator family
opcode space
format
validity conditions
state effects
failure modes
trace contribution
```

Reserved tags cannot introduce untyped instructions.

A reserved tag used without a declared profile is invalid:

```text id="f4rhwm"
reserved PMS_OP without profile declaration
    → Δ classification failure
    → Φ illegal-instruction fault
```

### 8.5 Register Encoding

Registers are encoded with 5-bit fields:

```text id="dg9wv2"
00000–11111 = 32 logical register identifiers
```

A standard profile may reserve the space as follows:

| Range     | Role                                              |
| --------- | ------------------------------------------------- |
| `R0–R7`   | general-purpose registers                         |
| `R8–R15`  | extended general-purpose / reserved profile space |
| `R16–R23` | special/system registers                          |
| `R24–R31` | reserved or implementation-defined                |

Special registers such as:

```text id="lc940x"
R_pc
R_sp
R_fp
R_fr
R_role
R_cap
R_flag
R_iso
R_pol
```

may be encoded explicitly in the special-register range or treated implicitly by specific instructions.

Examples:

```text id="vki0gi"
CALL and RET may use R_pc implicitly

PUSH and POP may use R_sp implicitly

FRM_SET may write R_fr

SET_ROLE may update R_role

ISO_ENTER may update R_iso

ISO_EXIT may restore, pop, or close R_iso / boundary-stack state

SET_POL may update P or R_pol
```

Implicit register use must still be represented in instruction semantics and trace metadata where relevant.

### 8.6 Canonical Instruction Formats

PMS-CPU defines four canonical 32-bit formats.

#### R-type

Register-register format:

```text id="nxae7t"
31     28 27     22 21     17 16     12 11      7 6        0
+---------+---------+---------+---------+---------+----------+
| PMS_OP  | OPCODE  |   rd    |   rs1   |   rs2   |  fun7    |
+---------+---------+---------+---------+---------+----------+
```

Used for:

```text id="rblc1p"
ALU operations
register-register comparisons
atomic register operands
some capability checks
some policy checks
```

#### I-type

Register-immediate format:

```text id="w4teoa"
31     28 27     22 21     17 16     12 11                0
+---------+---------+---------+---------+------------------+
| PMS_OP  | OPCODE  |   rd    |   rs1   |      imm12       |
+---------+---------+---------+---------+------------------+
```

Used for:

```text id="o9vmum"
immediate arithmetic
immediate compare
load offsets
small constants
small policy/trap codes
small frame/context identifiers
```

#### B-type

Branch / offset format:

```text id="n74iwk"
31     28 27     22 21     17 16                         0
+---------+---------+---------+---------------------------+
| PMS_OP  | OPCODE  |   rs1   |          off17            |
+---------+---------+---------+---------------------------+
```

Used for:

```text id="aa6xwy"
branches
jumps
conditional failure targets
policy failure branches
capability failure branches
trap dispatch offsets
```

#### S-type

System/control format:

```text id="fwxeil"
31     28 27     22 21     17 16     12 11                0
+---------+---------+---------+---------+------------------+
| PMS_OP  | OPCODE  |   rs1   |   rs2   |      sys12       |
+---------+---------+---------+---------+------------------+
```

Used for:

```text id="ub6efk"
frame instructions
role and capability instructions
traps and exception operations
isolation operations
boundary-exit operations
transaction / commit operations
policy operations
system-control operations
```

### 8.7 Encoding by Operator Family

The `PMS_OP` tag selects the instruction family.

| PMS_OP | Operator | Example instructions                                                              |
| ------ | -------- | --------------------------------------------------------------------------------- |
| `0000` | Δ        | `CMP`, `CMPI`, `TST`, `BEQ`, `BNE`, `JMP`, `NDIF`                                 |
| `0001` | ∇        | `MOV`, `MOVI`, `LOAD`, `STORE`, `ADD`, `CALL`, `RET`, `IN`, `OUT`                 |
| `0010` | □        | `FRM_ENTER`, `FRM_LEAVE`, `FRM_SET`, `FRM_CALL`, `FRM_RET`                        |
| `0011` | Λ        | `WAIT`, `POLL`, `NOP_SEM`                                                         |
| `0100` | Α        | `PATTERN`, `LOOP_P`                                                               |
| `0101` | Ω        | `SET_ROLE`, `CHK_CAP`, `ENTER_PRIV`, `EXIT_PRIV`                                  |
| `0110` | Θ        | `TICK`, `SLEEP`, `FENCE`, `YIELD`                                                 |
| `0111` | Φ        | `TRAP`, `EXC_RAISE`, `EXC_SET`, `EXC_RET`, `REFRAME`                              |
| `1000` | Χ        | `ISO_FORK`, `ISO_ENTER`, `ISO_EXIT`, `ISO_RESTRICT`                               |
| `1001` | Σ        | `TX_BEGIN`, `TX_COMMIT`, `TX_ABORT`, `ATOMIC_ADD`, `ATOMIC_CAS`, `COMMIT_BARRIER` |
| `1010` | Ψ        | `SET_POL`, `CHK_POL`, `CHK_ALL_POL`, `HALT_IF_POL`                                |

The subopcode `OPCODE` selects the specific instruction inside the operator family.

The pair:

```text id="c0d2a0"
(PMS_OP, OPCODE)
```

must be valid under the active PMS-CPU profile.

For Χ-family instructions, the profile must additionally define:

```text id="ahshvw"
boundary context representation
active-boundary predicate
unbalanced-exit behavior
sealed-isolation behavior
closure / rollback / audit / commit behavior
```

### 8.8 Invalid Encodings

Not every 32-bit pattern is valid.

An encoding is invalid if:

```text id="gdratu"
PMS_OP is reserved
∨ OPCODE is undefined for PMS_OP
∨ FORMAT is invalid for OPCODE
∨ operand fields are invalid for selected format
∨ instruction violates current frame state
∨ instruction violates role/capability state
∨ instruction violates Χ boundary state
∨ instruction attempts ISO_EXIT without active boundary / isolation context
∨ instruction expands or grows reachability inside sealed isolation
∨ instruction violates commit preconditions
∨ instruction violates ordering constraints
∨ instruction violates active Ψ policy
```

Invalid binary classification is a Δ failure that produces Φ:

```text id="c7dngr"
cannot classify instruction
→ illegal-instruction trap
```

Policy-forbidden encodings are Ψ failures:

```text id="bl1k5y"
instruction structurally decodes
∧ Ψ forbids execution
→ policy trap / halt / denial path
```

Role-forbidden encodings are Ω failures:

```text id="wrdmdq"
instruction structurally decodes
∧ Ω denies authority
→ privilege trap
```

Boundary-forbidden encodings are Χ / Ψ failures:

```text id="bqmmx8"
instruction structurally decodes
∧ Χ boundary forbids reachability
→ boundary trap / denial path
```

Unbalanced boundary exit is a Χ failure:

```text id="cmoqt7"
instruction structurally decodes as ISO_EXIT
∧ active_boundary_context(s_cpu) = false
→ Χ violation
→ Φ trap / Ψ denial / Σ audit / halt / stuck under declared profile
```

Sealed-isolation expansion is a Χ / Ψ failure:

```text id="hx0tsy"
instruction structurally decodes
∧ sealed isolation forbids entry, expansion, or reachability growth
→ Χ / Ψ denial
```

A sealed isolation context may still permit valid exit, closure, rollback, audit, or commit under the declared profile.

### 8.9 Decode Pipeline

The binary decode pipeline is:

```text id="wvnsv0"
fetch 32-bit word
→ Δ classify PMS_OP
→ Δ classify OPCODE
→ Δ classify format
→ decode operands
→ validate operand shape
→ construct operator-typed instruction
→ perform Ω / Ψ / □ / Χ / Σ / Θ checks as required
→ execute instruction semantics
```

The decoded instruction has the abstract form:

```text id="bxlrm8"
I = (mnemonic, op, operands, constraints)
```

which corresponds to the ISA form defined in Section 5.

Decode is Δ-family behavior.

Execution belongs to the decoded operator family.

A concrete decoded run contributes to:

```text id="ocy5oe"
trace_cpu(...)
```

The declared binary/profile execution space is:

```text id="rb7g9k"
Trace(...)
```

A concrete trace is not the same thing as the full Trace set.

### 8.10 Example Encodings

Assume:

```text id="v9o0ud"
R0 = 00000
R1 = 00001
R2 = 00010
R3 = 00011
```

#### Example 1: `ADD R1, R2, R3`

Operator family:

```text id="z01wo7"
PMS_OP = ∇ = 0001
```

Assume:

```text id="o5mlts"
OPCODE(ADD) = 000000
rd   = R1 = 00001
rs1  = R2 = 00010
rs2  = R3 = 00011
fun7 = 0000000
```

Binary:

```text id="hd37f9"
0001 000000 00001 00010 00011 0000000
```

Operator reading:

```text id="drncbx"
∇ register mutation
```

#### Example 2: `TRAP #2`

Operator family:

```text id="cl6foi"
PMS_OP = Φ = 0111
```

Assume S-type:

```text id="wbofj7"
OPCODE(TRAP) = 000000
rs1 = 00000
rs2 = 00000
sys12 = 000000000010
```

Binary:

```text id="vwdq3d"
0111 000000 00000 00000 000000000010
```

Operator reading:

```text id="wqgtkg"
Φ recontextualization into trap handler
```

#### Example 3: `SET_ROLE ROLE_KERNEL`

Operator family:

```text id="a6bhx3"
PMS_OP = Ω = 0101
```

Assume:

```text id="t733ed"
ROLE_KERNEL = 1
OPCODE(SET_ROLE) = 000000
rs1 = 00000
rs2 = 00000
sys12 = 000000000001
```

Binary:

```text id="y6gscq"
0101 000000 00000 00000 000000000001
```

Operator reading:

```text id="nfa9zg"
Ω role transition
```

#### Example 4: `ISO_ENTER ctx`

Operator family:

```text id="mw2nl5"
PMS_OP = Χ = 1000
```

This is a PMS-CPU projection of Distance into a boundary-domain operation.

It selects or enters a protected domain.

It does not redefine PMS Base Χ.

#### Example 5: `ISO_EXIT`

Operator family:

```text id="eg10qp"
PMS_OP = Χ = 1000
```

Assume S-type:

```text id="n3g4v7"
OPCODE(ISO_EXIT) = 000010
rs1 = 00000
rs2 = 00000
sys12 = 000000000000
```

Binary:

```text id="d5ae86"
1000 000010 00000 00000 000000000000
```

Operator reading:

```text id="gm67bd"
Χ boundary exit
```

Validity:

```text id="d9ocv2"
active boundary / isolation context exists
∧ role/capability permits exit
∧ policy permits exit
∧ declared profile permits closure
```

Invalid:

```text id="pmhj2l"
ISO_EXIT without active boundary / isolation context
```

Typed result:

```text id="gj3mar"
Χ violation
→ Φ trap or Ψ denial
→ optional Σ audit / rejection commit
```

### 8.11 Binary Trace Recoverability

A PMS-CPU binary is trace-recoverable when each decoded instruction exposes:

```text id="bwa2px"
PMS_OP
OPCODE
operands
frame context
role/capability context
boundary context
policy result
commit result where relevant
failure mode where relevant
sealed-state effect where relevant
```

A trace entry may include:

```text id="jytuf4"
event = (
    cycle,
    R_pc,
    instr_word,
    PMS_OP,
    OPCODE,
    operands,
    frame,
    role,
    boundary,
    policy_result,
    commit_result,
    result
)
```

A concrete decoded execution records:

```text id="dv2s8f"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="px6623"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

For a declared binary/profile execution space:

```text id="r4mc09"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="eg5roh"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

This enables:

```text id="u32if8"
binary trace validation
golden fixture generation
ISA testing
compiler lowering checks
homomorphism evidence
debugging
audit
ISO_EXIT validation
sealed-isolation validation
```

Trace recoverability strengthens artifact evidence.

It does not validate PMS Base.

### 8.12 Encoding Profiles and Extensions

The reference encoding is one PMS-CPU profile.

A profile may define:

```text id="n9gj05"
additional opcodes
compressed instruction forms
larger immediate fields
wider registers
alternate endianness
extended system formats
specialized trap formats
specialized policy formats
specialized boundary-exit formats
```

A profile extension is valid only if it preserves:

```text id="k1mxrv"
operator-family recoverability
operand validity
failure typing
trace recoverability
policy gating
role/capability discipline
boundary discipline
commit discipline
ordering discipline
```

For Χ extensions, the profile must declare:

```text id="o6vv5l"
whether a boundary context is active
how ISO_EXIT closes or restores context
how unbalanced exit is rejected
how sealed isolation forbids expansion
which closure paths remain valid
```

Profile extensions must not erase the PMS_OP level.

### 8.13 PMS-RUST Boundary-Exit Mapping Note

PMS-CPU encodes architecture-level boundary exit as:

```text id="cpvglm"
ISO_EXIT
```

PMS-RUST exposes the corresponding artifact/runtime behavior as:

```text id="daw4f0"
chi_exit
```

The mapping is:

```text id="l08zqw"
PMS-CPU ISO_EXIT
    = virtual CPU architecture-level boundary-exit instruction

PMS-RUST chi_exit
    = runtime / DSL / validator command evidencing bounded boundary-exit
      behavior under the PMS-RUST v0.1 profile

PMS Base Χ
    = Distance
```

Shared rule:

```text id="a1vuzb"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary:

```text id="z42xef"
chi_exit does not complete PMS-CPU ISO_EXIT.

chi_exit does not redefine PMS Base Χ.

chi_exit does not validate PMS Base.
```

This mapping strengthens implementation-artifact clarity.

It does not collapse runtime artifact behavior into ISA completion.

### 8.14 Binary Encoding Summary

The reference binary encoding provides:

```text id="fag7bl"
32-bit fixed-width virtual instruction words
explicit 4-bit PMS_OP operator tag
6-bit subopcode
5-bit logical register fields
R/I/B/S canonical formats
operator-family dispatch
invalid-encoding trap behavior
policy-aware execution gating
role-aware execution gating
boundary-aware execution gating
ISO_EXIT active-context discipline
sealed-isolation expansion rejection
trace recoverability
```

Architectural consequence:

```text id="dv7ois"
PMS-CPU binaries remain recoverable as operator-typed instruction traces.
```

This allows PMS-CPU machine code to be:

```text id="z9q63s"
interpreted
simulated
validated
traced
tested through fixtures
mapped back to PMS-UM semantics
used as compiler target
used as formal-model input
```

through the defined `h_UM→CPU` relation.

### 8.15 Binary Encoding Invariants

```text id="jwni3z"
CPU-BE1: PMS-CPU binary encoding is virtual

CPU-BE2: Π_CPU denotes the PMS-CPU program domain

CPU-BE3: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-BE4: the top-level PMS_OP tag preserves operator identity at decode time

CPU-BE5: opcode interpretation occurs inside the selected operator family

CPU-BE6: invalid PMS_OP or invalid PMS_OP/OPCODE pair is Δ classification
         failure producing Φ fault

CPU-BE7: structurally decoded instructions may still fail Ω, Ψ, □, Χ, Σ,
         or Θ checks

CPU-BE8: PMS Base Χ = Distance

CPU-BE9: binary Χ encodings are PMS-CPU projections of Distance as virtual
         boundary, reachability, protection-domain, isolation-domain,
         access-separation, and boundary-exit discipline

CPU-BE10: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-BE11: ISO_EXIT requires an active boundary / isolation context

CPU-BE12: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-BE13: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-BE14: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
          not the PMS-CPU ISO_EXIT instruction

CPU-BE15: instruction formats are reference formats, not physical hardware
          requirements

CPU-BE16: encoding profiles may extend the reference encoding only if they
          preserve operator recoverability

CPU-BE17: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-BE18: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-BE19: trace recoverability supports artifact evidence but does not
          validate PMS Base

CPU-BE20: binary encoding is a virtual CPU specification claim, not fabricated
          hardware
```

### 8.16 Boundary Statement

The correct boundary for this chapter is:

```text id="hwnisq"
The PMS-CPU binary encoding defines a reference virtual instruction format
with explicit PMS_OP tags, opcode fields, operand formats, validity rules,
failure behavior, boundary-exit discipline, sealed-isolation constraints,
and trace recoverability.

This is a virtual CPU binary-encoding specification claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

This chapter does not specify fabricated hardware, does not require a
completed simulator, does not redefine PMS Base Χ, and does not validate
PMS Base.
```

---

## 9. Fetch–Decode–Execute Cycle

PMS-CPU executes virtual instructions through a Δ–Ψ-typed fetch–decode–execute cycle.

The cycle refines the PMS-UM step relation into a virtual CPU transition over:

```text id="yzpy33"
register state
memory state
program counter
concrete PMS-CPU program π_CPU ∈ Π_CPU
frame state
role/capability state
policy state
boundary state
trap/interrupt state
commit state
ordering metadata
operator history
```

A PMS-CPU step may be written:

```text id="uktztx"
s_cpu → s_cpu'
```

or, with program-counter and program emphasis:

```text id="qjlm2r"
(s_cpu, π_CPU, R_pc) → (s_cpu', π_CPU, R_pc')
```

where:

```text id="uls36i"
π_CPU ∈ Π_CPU
```

The key property is that every cycle phase is operator-readable.

Fetch, decode, validation, frame binding, boundary checking, boundary exit, execution, commit, program-counter update, and trap handling are not outside PMS.

They are PMS-CPU projections of the Δ–Ψ execution discipline.

The central claim is:

```text id="rxhnth"
The PMS-CPU fetch–decode–execute cycle is an operator-typed refinement of
the PMS-UM step relation over virtual processor state.
```

Claim type:

```text id="m4fril"
virtual CPU execution-cycle architecture claim
```

Boundary:

```text id="f5hsqn"
This defines PMS-CPU virtual execution semantics.

It does not claim a physical pipeline.

It does not claim fabricated hardware.

It does not imply a completed simulator.

It does not validate PMS Base.
```

A concrete PMS-CPU execution records:

```text id="xt852b"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="vvfiob"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="m4dcwh"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="fqf8rh"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 9.1 High-Level Cycle

A single PMS-CPU cycle has the following structure:

```text id="avonov"
1. Θ ordering step
2. Δ fetch
3. Δ decode
4. Ω / Ψ validation
5. □ frame binding
6. Χ boundary check where relevant
7. operator execution
8. Σ commit phase where required
9. R_pc update
10. Φ interrupt / trap check
```

Compact form:

```text id="lqptvy"
Θ
→ Δ_fetch
→ Δ_decode
→ Ω/Ψ check
→ □ bind
→ Χ boundary check
→ op_execute
→ Σ commit
→ R_pc update
→ Φ interrupt/trap check
```

This is the virtual CPU specialization of PMS-UM execution:

```text id="i24u8b"
fetch instruction
decode operator family
check dependency / frame / role / boundary / policy validity
execute operator semantics
record valid transition
advance or recontextualize
```

For Χ-family boundary exit, the high-level cycle includes an additional validity obligation:

```text id="r7vciy"
ISO_EXIT requires active boundary / isolation context.
```

Unbalanced exit is invalid:

```text id="zhxmup"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

### 9.2 Cycle Configuration

A PMS-CPU configuration may be written:

```text id="x6tp7v"
κ_cpu = (s_cpu, π_CPU, R_pc, h_cpu, e_cpu)
```

where:

```text id="s4ql05"
π_CPU ∈ Π_CPU
```

| Component | Meaning                                                          |
| --------- | ---------------------------------------------------------------- |
| `s_cpu`   | current virtual CPU state                                        |
| `π_CPU`   | concrete instruction memory, binary program image, or ISA stream |
| `R_pc`    | current program counter                                          |
| `h_cpu`   | operator history / concrete trace prefix                         |
| `e_cpu`   | environment: interrupts, device events, host signals             |

The program domain is:

```text id="j7qgcg"
Π_CPU
```

The active concrete program is:

```text id="xpzrza"
π_CPU ∈ Π_CPU
```

A cycle is valid only if:

```text id="o59qdx"
s_cpu is coherent
∧ π_CPU ∈ Π_CPU
∧ R_pc points to valid instruction position or terminal state
∧ h_cpu ∈ L_PMS or h_cpu ∈ L_PMS,Ψ
∧ environment events enter through operator-typed mechanisms
```

This configuration form aligns PMS-CPU with PMS-UM while preserving virtual processor structure.

### 9.3 Θ Ordering Step

At the beginning of a cycle, PMS-CPU advances or reads ordering metadata.

```text id="dtiees"
m.ordering' = T_Θ(m.ordering)
```

The Θ step may update:

```text id="liquidw"
instruction-order counters
pipeline-order metadata
fence state
scheduler-visible progression markers
interrupt-priority ordering
pending wait or timeout structures
happens-before metadata
```

Θ does not mean physical time.

Physical clocks, timestamps, durations, timer registers, and deadlines are data inside CPU state or meta-state.

Θ orders transitions that may read, compare, or update such data.

The ordering step provides the cycle’s progression context.

### 9.4 Δ Fetch

Instruction fetch reads the next virtual instruction word from the active concrete program.

For a frame-relative code model:

```text id="ciekqv"
instr_word = MEM[Frame(R_fr).code_base + R_pc]
```

or more generally:

```text id="xvj4um"
instr_word = fetch(π_CPU, MEM, R_fr, R_pc)
```

where:

```text id="o0yw9e"
π_CPU ∈ Π_CPU
```

Fetch is Δ-readable because the CPU distinguishes the next instruction word from program/memory state.

It does not yet perform the instruction’s main effect.

Fetch validity requires:

```text id="zismdx"
π_CPU ∈ Π_CPU
∧ R_pc points into an executable frame or valid program image location
∧ R_fr selects a valid code frame
∧ Ω permits code fetch where protected
∧ Χ permits reachability to the code frame
∧ Ψ permits execution from that frame
```

If fetch fails:

```text id="hd2t1m"
fetch failure → Φ instruction-fetch trap
```

Fetch failure may be caused by:

```text id="cl1d41"
invalid program image
invalid frame
invalid R_pc
boundary denial
role denial
policy denial
missing memory
```

### 9.5 Δ Decode

Decode classifies the fetched instruction.

The first classification extracts the PMS operator tag:

```text id="cog7kx"
PMS_OP = instr_word[31:28]
```

Then the CPU distinguishes:

```text id="ty3asj"
OPCODE
format
operand fields
immediates
system payload
```

The decoded instruction has the abstract ISA form:

```text id="n108wn"
I = (mnemonic, op, operands, constraints)
```

where:

```text id="y8hvam"
op ∈ { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

Decode is Δ-family behavior:

```text id="pskgfl"
bit pattern → operator class → opcode → operand structure
```

Invalid decode produces a Φ fault:

```text id="y1povw"
reserved PMS_OP
∨ undefined OPCODE
∨ malformed operand encoding
⇒ Φ illegal-instruction trap
```

Decode does not execute the instruction.

It creates an operator-typed instruction object for validation and execution.

### 9.6 Ω / Ψ Validation

After decode, PMS-CPU checks authority and policy.

Role validation is Ω-typed:

```text id="qa2to5"
role_ok(R_role, R_cap, I, s_cpu) = true
```

This checks whether the active role and capability state permit the instruction.

Examples:

```text id="dtspgp"
user mode may execute TRAP

user mode may be denied SET_POL

kernel mode may access kernel frames

transaction or isolation operations may require specific capabilities

MMIO or privileged frame access may require elevated authority

ISO_EXIT may require boundary-exit capability
```

Policy validation is Ψ-typed:

```text id="y2xq80"
policy_ok(P, s_cpu, I) = true
```

This checks whether active policies permit the instruction under the current state.

Policies may constrain:

```text id="zw4s14"
instruction families
memory regions
roles and capability transitions
frame entry and exit
boundary crossing
boundary exit
transaction commit
interrupt handling
trap return
speculative or reordered execution
sealed-isolation expansion
```

Failure of Ω validation yields a role/privilege fault:

```text id="z879h7"
Ω denial → Φ privilege trap
```

Failure of Ψ validation yields a policy denial path:

```text id="rvhbdi"
Ψ denial → Φ policy trap / halt / denial handler
```

The exact response is profile-specific.

It remains operator-typed.

### 9.7 □ Frame Binding

Before executing the instruction, PMS-CPU binds the instruction to the relevant execution frame.

Frame binding resolves:

```text id="ug1n4a"
active code frame
data frame
stack frame
MMIO frame
kernel/user frame
transactional overlay
handler frame
isolated domain frame
```

The binding operation can be written:

```text id="icbnc4"
f* = BindFrame(R_fr, FrameTable, I, s_cpu)
```

Frame binding checks:

```text id="gtt2m6"
target frame exists
∧ frame type supports the instruction
∧ permissions allow requested access
∧ role/capability state permits the frame relation
∧ boundary state permits reachability
∧ policy permits the frame relation
```

□ does not primarily mutate memory.

It establishes the context in which the instruction’s operands and effects have meaning.

Frame failure produces Φ:

```text id="fzmqtf"
invalid frame binding → Φ frame fault
```

### 9.8 Χ Boundary Check

If an instruction is boundary-sensitive, PMS-CPU checks the Χ projection.

PMS Base 1.3:

```text id="ljw131"
Χ = Distance
```

At PMS-CPU level, Χ is the implementation-layer projection of PMS Base Distance as:

```text id="t73t1m"
MMU boundary
address-space identity
protected domain
isolation selector
sandbox state
reachability restriction
access-separation metadata
boundary-exit discipline
```

The check may be written:

```text id="q2d72e"
boundary_ok(R_iso, m.boundary_metadata, f*, I, s_cpu) = true
```

Boundary-sensitive examples include:

```text id="mskkcx"
memory access across protected regions
entering isolation domains
exiting isolation domains through ISO_EXIT
trap entry into privileged handler
returning from kernel to user frame
transaction commit across domains
MMIO access
inter-context call or frame transition
```

For `ISO_EXIT`, the check is stricter:

```text id="h00v6x"
boundary_ok(R_iso, m.boundary_metadata, f*, ISO_EXIT, s_cpu) = true
only if:
    active_boundary_context(s_cpu) = true
    ∧ role_ok(ISO_EXIT, s_cpu)
    ∧ policy_ok(P, s_cpu, ISO_EXIT)
    ∧ profile_allows(profile, ISO_EXIT)
```

Unbalanced exit is invalid:

```text id="k3yn0t"
active_boundary_context(s_cpu) = false
    ⇒ ISO_EXIT invalid
```

A sealed isolation context has a distinct rule:

```text id="esz1xu"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="byjeay"
valid exit
closure
rollback
audit
commit
```

Failure yields a Χ / Ψ-readable fault:

```text id="qnk8qs"
Χ boundary violation → Φ boundary trap or Ψ denial
```

Invalid boundary exit yields typed CPU behavior:

```text id="btzjo1"
unbalanced ISO_EXIT
    → Χ violation
    → Φ trap / Ψ denial / Σ audit / halt / stuck
```

This preserves the version boundary:

```text id="pgm5kl"
PMS Base 1.3:
    Χ = Distance

PMS-CPU:
    Χ projects as boundary / isolation / reachability / access-separation /
    boundary-exit control
```

### 9.9 Operator Execution

After fetch, decode, validation, frame binding, and boundary checks, PMS-CPU executes the instruction according to its operator family.

#### Δ execution

Δ instructions compare, test, classify, or branch.

Typical effects:

```text id="fz0umq"
R_flag' = update_flags(...)
R_pc' = branch_target or next
```

#### ∇ execution

∇ instructions mutate register, memory, stack, I/O, or control state.

Typical effects:

```text id="v8fl9w"
RF'   = update_register_file(...)
MEM'  = update_memory_or_stage_write(...)
R_sp' = update_stack_pointer(...)
R_pc' = next_or_call_target
```

#### □ execution

□ instructions update frame context.

Typical effects:

```text id="gutlfm"
R_fr' = new_frame
m.frame_stack' = update_frame_stack(...)
```

#### Λ execution

Λ instructions record or respond to absence.

Typical effects:

```text id="ilgu51"
m.pending_non_events' = update_wait_or_timeout(...)
R_pc' = next_or_absence_handler
```

#### Α execution

Α instructions activate or expand a pattern.

Typical effects:

```text id="mnhr3u"
m.active_pattern' = pattern_id
R_pc' = expansion_entry or next
```

The expansion must remain PMS-valid.

If the current context is sealed, Α expansion must not create new entry, reachability growth, or scope enlargement.

#### Ω execution

Ω instructions update or check role/capability state.

Typical effects:

```text id="jhzka2"
R_role' = new_role
R_cap' = updated_capabilities
R_pc' = next_or_failure_label
```

#### Θ execution

Θ instructions update ordering state, fences, or scheduler-visible progression.

Typical effects:

```text id="lihw3r"
m.ordering' = update_ordering(...)
R_pc' = next
```

#### Φ execution

Φ instructions enter or exit traps, exceptions, handlers, or reframed contexts.

Typical effects:

```text id="v5snyn"
trap_frame' = save_or_restore_context(...)
R_fr' = handler_or_restored_frame
R_role' = handler_or_restored_role
R_pc' = handler_or_return_address
m.trap' = update_trap_state(...)
```

#### Χ execution

Χ instructions update boundary and reachability state.

Typical effects:

```text id="txkhlv"
R_iso' = new_domain_or_restored_domain
m.boundary_metadata' = update_boundary(...)
m.boundary_stack' = update_boundary_stack(...)
m.isolation_stack' = update_isolation_stack(...)
m.reachability' = update_reachability(...)
m.sealed_state' = update_sealed_state_if_relevant(...)
```

For `ISO_EXIT`, execution is valid only when an active boundary / isolation context exists.

Unbalanced `ISO_EXIT` is invalid and must produce typed CPU behavior.

A sealed isolation context forbids further expansion while preserving valid closure paths under declared profile.

#### Σ execution

Σ instructions commit, integrate, or finalize prior activity.

Typical effects:

```text id="uzupjr"
MEM' = commit_staged_writes(...)
m.transaction_state' = update_transaction(...)
m.commit_log' = record_commit(...)
m.boundary_stack' = close_context_if_commit_is_boundary_closure(...)
```

Σ may integrate valid boundary closure or audit/rejection records.

It may not convert sealed-scope expansion into a valid commit.

#### Ψ execution

Ψ instructions update or enforce policy.

Typical effects:

```text id="p9whks"
P' = update_policy(...)
R_flag.P' = policy_status
R_pc' = next_or_policy_handler
m.sealed_state' = update_sealed_state_if_policy_seals_context(...)
```

A Ψ instruction may restrict future valid execution.

A Ψ seal may close isolation against expansion without forbidding valid exit, closure, rollback, audit, or commit.

### 9.10 Σ Commit Phase

Some instructions commit directly as part of their ordinary architectural effect.

Others produce staged effects requiring explicit or implicit Σ integration.

Commit may apply to:

```text id="cuq0h1"
register writeback
memory store visibility
transaction completion
atomic operation completion
call/return boundary restoration
trap return
isolation-domain closure
boundary exit
device or MMIO effect completion
policy-governed state finalization
audit / rejection record finalization
```

The commit check is:

```text id="xpmw7q"
commit_valid(s_cpu, I) = true
```

where:

```text id="hn2yg3"
committable prior structure exists
∧ frame conditions are coherent
∧ role/capability permits integration
∧ boundary conditions permit visibility or closure
∧ active policy permits commit
∧ ordering constraints are satisfied
```

If commit fails:

```text id="ih3q1w"
Σ failure → Φ commit fault / Ψ denial / rollback / audit
```

Commit discipline prevents PMS-CPU from treating visibility, writeback, trap return, transaction close, and boundary exit as untyped completion.

A sealed isolation context may permit valid commit, rollback, audit, or closure under declared policy.

It does not permit reachability growth through commit.

### 9.11 Program Counter Update

After execution and commit handling, PMS-CPU updates `R_pc`.

Ordinary sequential update:

```text id="r07zwq"
R_pc' = R_pc + 4
```

Branch update:

```text id="yu89uy"
R_pc' = R_pc + (off << 2)
```

Call update:

```text id="ix4h8h"
push return address
R_pc' = call_target
```

Return update:

```text id="dg3lzq"
R_pc' = pop return address
```

Trap entry:

```text id="qq3yx7"
R_pc' = handler_entry
```

Exception return:

```text id="bvgvfg"
R_pc' = restored_return_address
```

Policy halt:

```text id="fgkr9g"
R_pc' = halt
```

The program-counter update is part of the operator semantics.

It must preserve:

```text id="e12nbu"
frame validity
role/capability validity
boundary validity
policy constraints
return discipline
trap discipline
sealed-isolation constraints
```

If `R_pc` update follows `ISO_EXIT`, the post-exit context must be frame-valid, role-valid, boundary-valid, and policy-valid.

### 9.12 Φ Interrupt and Trap Check

At the end of a cycle, PMS-CPU checks pending interrupt, trap, and fault conditions.

Checks include:

```text id="sqh1pm"
external interrupts
timer or scheduler conditions
trap-pending flag
policy violation flag
isolation or boundary violation
unbalanced boundary exit
sealed-isolation expansion violation
transaction abort condition
illegal instruction fault
frame fault
role/capability fault
commit failure
```

If a pending condition is enabled and permitted:

```text id="er3bv3"
pending_interrupt_or_fault ∧ enabled ⇒ Φ handler entry
```

If the condition is absent or blocked, execution continues to the next cycle.

Interrupt and trap checks are ordered through Θ and constrained by Ψ.

Boundary-sensitive handler entry is constrained by Χ.

### 9.13 Full Step Validity Predicate

A PMS-CPU step is valid when:

```text id="hkynnf"
valid_cpu_step(s_cpu, I, s_cpu') iff
    valid_cpu_state(s_cpu)
    ∧ π_CPU ∈ Π_CPU
    ∧ Θ_order_valid(s_cpu)
    ∧ fetch_valid(π_CPU, MEM, R_fr, R_pc)
    ∧ decode_valid(instr_word)
    ∧ op(I) ∈ O
    ∧ operands_valid(I, s_cpu)
    ∧ dependencies_available(op(I), s_cpu)
    ∧ role_ok(I, s_cpu)
    ∧ policy_ok(P, s_cpu, I)
    ∧ frame_ok(I, s_cpu)
    ∧ boundary_ok(I, s_cpu)
    ∧ execute_valid(I, s_cpu, s_mid)
    ∧ commit_valid_if_required(I, s_mid)
    ∧ pc_update_valid(I, s_mid, s_cpu')
    ∧ trap_or_interrupt_state_valid(s_cpu')
    ∧ valid_cpu_state(s_cpu')
```

For `ISO_EXIT`:

```text id="ltld89"
valid_cpu_step(s_cpu, ISO_EXIT, s_cpu') iff
    valid_cpu_state(s_cpu)
    ∧ π_CPU ∈ Π_CPU
    ∧ op(ISO_EXIT) = Χ
    ∧ active_boundary_context(s_cpu) = true
    ∧ role_ok(ISO_EXIT, s_cpu)
    ∧ policy_ok(P, s_cpu, ISO_EXIT)
    ∧ boundary_ok(ISO_EXIT, s_cpu)
    ∧ profile_allows(profile, ISO_EXIT)
    ∧ execute_valid(ISO_EXIT, s_cpu, s_mid)
    ∧ commit_valid_if_required(ISO_EXIT, s_mid)
    ∧ pc_update_valid(ISO_EXIT, s_mid, s_cpu')
    ∧ valid_cpu_state(s_cpu')
```

Invalid:

```text id="wxcuh4"
active_boundary_context(s_cpu) = false
    ⇒ ISO_EXIT invalid
```

The trace update is:

```text id="k8gc1w"
h_cpu' = h_cpu · trace_contribution(cycle)
```

with:

```text id="oa7wjh"
h_cpu' ∈ L_PMS
```

and, under active policy:

```text id="emswvw"
h_cpu' ∈ L_PMS,Ψ
```

A complete concrete run satisfies:

```text id="uj5n61"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="kxlhxd"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

The set of possible runs under a declared profile satisfies:

```text id="pym0sp"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="wvnuhq"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 9.14 Formal Step Relation

A PMS-CPU step can be written:

```text id="vfrvej"
CPU_STEP(s_cpu, π_CPU) = s_cpu'
```

where:

```text id="rsxud3"
π_CPU ∈ Π_CPU
```

and:

```text id="zxf4if"
s_cpu'
=
Φ_check(
  PC_update(
    Σ_commit(
      EXECUTE(
        Χ_check(
          □_bind(
            ΩΨ_validate(
              Δ_decode(
                Δ_fetch(
                  Θ_order(s_cpu)
                )
              )
            )
          )
        )
      )
    )
  )
)
```

This notation is schematic.

It is not a required implementation call stack.

It expresses the architectural order of validity checks and state transformations.

The corresponding operator trace for a normal instruction may include:

```text id="pqq081"
Θ Δ Δ Ω Ψ □ Χ? op Σ? Φ?
```

where:

```text id="x56fk9"
op
    is the decoded instruction’s operator family

Χ?
    appears when boundary-sensitive checks occur

Σ?
    appears when commit or integration is required

Φ?
    appears when trap, interrupt, fault, invalid boundary exit, or
    recontextualization occurs
```

For `ISO_EXIT`, the trace includes Χ and may include Σ if closure or audit commit is required:

```text id="rumqbc"
Θ Δ Δ Ω Ψ □ Χ ISO_EXIT Σ? Φ?
```

If `ISO_EXIT` is unbalanced, the normal execution path is invalid and the profile must produce typed failure behavior.

### 9.15 Pipelined or Out-of-Order View

The reference PMS-CPU semantics is sequential at the architectural level.

A simulator or implementation may use pipelined or out-of-order execution if it preserves the same architectural trace at the defined observation points.

In a pipelined view:

```text id="vz92i5"
Δ fetch/decode may be staged

Ω and Ψ checks may occur early

frame and boundary checks may be resolved before memory access

speculative ∇ may be delayed until Σ commit

Θ fences constrain reordering

Φ traps flush or recontextualize the pipeline

Ψ may prohibit specific speculation

Χ may restrict speculative visibility

ISO_EXIT may not commit unless an active boundary / isolation context exists

sealed isolation may not be expanded through speculative execution
```

The rule is:

```text id="guvge9"
implementation scheduling may vary,
but the committed architectural trace must preserve Δ–Ψ validity.
```

This keeps PMS-CPU open to simulator, interpreter, JIT, symbolic engine, and future implementation strategies without turning the architecture claim into a hardware fabrication claim.

### 9.16 Deterministic and Nondeterministic CPU Profiles

A deterministic PMS-CPU profile satisfies:

```text id="v47wax"
∀s_cpu:
    | { s_cpu' | s_cpu → s_cpu' } | ≤ 1
```

This requires:

```text id="xznu0d"
deterministic fetch
deterministic decode
deterministic validation
functional instruction semantics
deterministic policy outcomes
deterministic boundary outcomes
deterministic boundary-exit outcomes
deterministic interrupt selection
closed or deterministic environment
```

A nondeterministic PMS-CPU profile permits:

```text id="ynsn7s"
∃s_cpu:
    | { s_cpu' | s_cpu → s_cpu' } | > 1
```

Sources may include:

```text id="auwxp9"
interrupt timing
environment events
scheduler choices
symbolic execution
policy alternatives
boundary alternatives
relaxed memory profiles
```

Both profiles remain PMS-CPU-conformant only if every possible trace remains in:

```text id="yrr0tv"
L_PMS
```

and, under active policy:

```text id="ntv2jv"
L_PMS,Ψ
```

More precisely:

```text id="fdujdu"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="b15xdu"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 9.17 Failure and Rejection During the Cycle

A cycle may fail at several points.

| Phase        | Failure                                                | Typed handling                               |
| ------------ | ------------------------------------------------------ | -------------------------------------------- |
| Θ order      | invalid ordering state                                 | Φ / Ψ                                        |
| Δ fetch      | invalid PC/frame/code access                           | Φ fetch fault                                |
| Δ decode     | invalid PMS_OP / OPCODE / operands                     | Φ illegal-instruction fault                  |
| Ω validation | role/capability denial                                 | Φ privilege trap                             |
| Ψ validation | policy denial                                          | Φ policy trap / halt                         |
| □ bind       | invalid frame                                          | Φ frame fault                                |
| Χ check      | boundary violation                                     | Φ boundary trap / Ψ denial                   |
| Χ exit       | `ISO_EXIT` without active boundary / isolation context | Χ violation / Φ / Ψ / Σ-audit / halt / stuck |
| Χ seal       | sealed-isolation expansion attempt                     | Χ / Ψ denial                                 |
| execute      | operator-specific fault                                | Φ / Ψ / halt                                 |
| Σ commit     | no committable state or invalid visibility / closure   | Φ / Ψ / rollback                             |
| PC update    | invalid target                                         | Φ control fault                              |
| Φ check      | invalid handler / return                               | Φ fault / halt                               |

A failed cycle must not silently mutate architectural state.

The PMS-CPU profile must define whether invalid partial effects are:

```text id="ngxkik"
rolled back
staged but not committed
recontextualized through Φ
denied through Ψ
recorded through Σ audit
halted
```

Validation here means acceptance or rejection under a declared schema, model, profile, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 9.18 Cycle Trace Event

A PMS-CPU cycle may emit a trace event:

```text id="ymgwv2"
event = (
    cycle,
    R_pc,
    instr_word,
    op,
    mnemonic,
    frame,
    role,
    boundary,
    policy_result,
    commit_result,
    trap_result,
    R_pc',
    meta
)
```

The trace event supports:

```text id="tikr11"
debugging
replay
simulation
binary validation
compiler lowering checks
trap/interrupt validation
memory-model testing
artifact evidence
ISO_EXIT validation
sealed-isolation validation
```

Trace emission is an artifact/design choice.

Operator-labeled representability is the architecture invariant.

A concrete trace records one execution:

```text id="uqy5v9"
trace_cpu(...)
```

The declared profile determines a trace set:

```text id="rrwb5a"
Trace(...)
```

Trace evidence supports bounded implementation-artifact claims.

It does not validate PMS Base.

### 9.19 PMS-RUST Boundary-Exit Mapping Note

PMS-CPU names the architecture-level boundary-exit instruction:

```text id="d33jdu"
ISO_EXIT
```

PMS-RUST exposes a bounded artifact/runtime command:

```text id="uaek4z"
chi_exit
```

The conceptual alignment is:

```text id="er2sz6"
PMS-CPU ISO_EXIT
    = virtual CPU architecture-level boundary-exit instruction

PMS-RUST chi_exit
    = runtime / DSL / validator command evidencing bounded boundary-exit
      behavior under the PMS-RUST v0.1 profile

PMS Base Χ
    = Distance
```

Shared rule:

```text id="htlf98"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary:

```text id="kpctt4"
chi_exit does not complete PMS-CPU ISO_EXIT.

chi_exit does not redefine PMS Base Χ.

chi_exit does not validate PMS Base.
```

This mapping strengthens implementation-artifact clarity.

It does not collapse runtime artifact behavior into ISA or CPU completion.

### 9.20 Execution Cycle Invariants

```text id="o2pgb3"
CPU-FDE1: PMS-CPU execution refines the PMS-UM step relation

CPU-FDE2: each cycle is operator-readable

CPU-FDE3: Π_CPU denotes the PMS-CPU program domain

CPU-FDE4: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
          program image, or binary image

CPU-FDE5: Θ orders cycle progression

CPU-FDE6: Δ fetches and decodes instruction structure

CPU-FDE7: Ω validates role/capability authority

CPU-FDE8: Ψ validates policy permission

CPU-FDE9: □ binds frame context

CPU-FDE10: PMS Base Χ = Distance

CPU-FDE11: PMS-CPU projects Χ as boundary/reachability/access-separation
           and boundary-exit checks during execution

CPU-FDE12: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
           instruction

CPU-FDE13: ISO_EXIT requires an active boundary / isolation context

CPU-FDE14: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-FDE15: sealed isolation forbids entry, expansion, and reachability growth
           while permitting valid exit, closure, rollback, audit, or commit
           under declared profile

CPU-FDE16: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
           not the PMS-CPU ISO_EXIT instruction

CPU-FDE17: op_execute follows the decoded instruction’s primary operator
           family

CPU-FDE18: Σ integrates effects where commit is required

CPU-FDE19: Φ handles traps, interrupts, faults, invalid boundary exits, and
           recontextualization

CPU-FDE20: R_pc update must preserve frame, role, boundary, and policy
           validity

CPU-FDE21: pipelining or out-of-order execution is allowed only if the
           committed architectural trace preserves Δ–Ψ validity

CPU-FDE22: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-FDE23: Trace(...) denotes the set of possible PMS-CPU executions under a
           declared machine/program/profile

CPU-FDE24: deterministic and nondeterministic CPU profiles remain valid
           only when all traces remain in L_PMS or L_PMS,Ψ

CPU-FDE25: execution-cycle architecture does not claim fabricated hardware
           and does not validate PMS Base
```

### 9.21 Architectural Consequence

The PMS-CPU fetch–decode–execute cycle makes virtual CPU execution structurally transparent.

The consequence is:

```text id="ehhl5s"
Every PMS-CPU cycle is an operator-typed refinement of the PMS-UM step
relation: ordered by Θ, fetched and decoded by Δ, authorized by Ω,
scoped by □, boundary-checked by Χ, constrained by Ψ, executed by its
operator family, integrated by Σ where required, and recontextualized
through Φ on traps, faults, interrupts, invalid boundary exits, or policy
events.
```

This is the execution model for the PMS-CPU virtual ISA.

It preserves the boundary-exit rule:

```text id="xld3an"
ISO_EXIT requires active boundary / isolation context.

Unbalanced ISO_EXIT is invalid.

Sealed isolation forbids expansion while permitting valid closure paths.
```

### 9.22 Boundary Statement

The correct boundary for this chapter is:

```text id="le02br"
The PMS-CPU fetch–decode–execute cycle defines virtual CPU execution as an
operator-typed refinement of the PMS-UM step relation over register, memory,
program, frame, role, boundary, policy, commit, trap, interrupt, and
ordering state.

This is a virtual CPU execution-cycle architecture claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

This chapter does not define physical pipeline hardware, does not claim
fabricated processor implementation, does not imply a completed simulator,
does not redefine PMS Base Χ, and does not validate PMS Base.
```

---

## 10. Commit Phase and Policy Checks

PMS-CPU separates instruction execution from commit and policy validation.

This separation is necessary because not every state update becomes architecturally visible immediately. Some effects may be:

```text id="eeiqtd"
staged
speculative
transactional
boundary-sensitive
trap-sensitive
interrupt-sensitive
policy-dependent
memory-order-dependent
```

The active PMS-CPU program is:

```text id="rpilds"
π_CPU ∈ Π_CPU
```

where:

```text id="v6ibca"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The commit phase is Σ-typed.

Policy checks are Ψ-typed.

Together, they define when an instruction’s effects become valid architectural CPU state.

The central claim is:

```text id="dkszhz"
PMS-CPU execution is valid only when produced effects can be integrated
through Σ under coherent frame, role, boundary, ordering, and Ψ policy
constraints.
```

Claim type:

```text id="dbebrn"
virtual CPU commit/policy architecture claim
```

Boundary:

```text id="fx9w9y"
This section defines virtual CPU commit and policy semantics.

It does not claim physical writeback hardware, cache hardware, reorder
buffers, fabricated transactional memory, or completed simulator behavior.

It does not validate PMS Base.
```

A concrete PMS-CPU execution records:

```text id="p1n4lr"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="q2akm8"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="k4xnj9"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="xnwk53"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 10.1 Commit as Architectural Integration

Σ integrates prior activity into visible state.

At PMS-CPU level, commit may apply to:

```text id="rz32nj"
register writeback
memory store visibility
transaction completion
atomic operation completion
call/return boundary restoration
trap return
isolation-domain closure
boundary exit
device or MMIO effect completion
policy-governed state finalization
audit record finalization
rollback / rejection closure
```

The basic rule is:

```text id="e0wsbk"
Σ requires committable prior activity.
```

A commit is invalid if there is no staged, produced, pending, or otherwise committable structure to integrate.

Correct:

```text id="r0c47h"
∇ produces staged effect
Σ integrates staged effect
Ψ permits or denies the integration
```

Incorrect:

```text id="yzx4y3"
Σ commits without committable prior state
```

Commit is not merely “the end of an instruction.”

It is the CPU-layer integration point at which prior effects become architecturally valid under the active PMS-CPU profile.

### 10.2 Execution, Staging, Commit

PMS-CPU distinguishes three phases:

```text id="juwj64"
execution
staging
commit
```

Execution produces an effect:

```text id="mrmy88"
∇ store
∇ register update
Φ handler effect
Χ boundary transition
Χ boundary exit
Ψ policy update
```

Staging records an effect that is not yet fully visible:

```text id="m5bd3o"
m.store_buffer
m.transaction_state
m.pending_writeback
m.trap_frame
m.isolation_delta
m.boundary_delta
m.policy_update_pending
m.audit_pending
```

Commit integrates the staged or produced effect:

```text id="if6ef2"
Σ commit
```

The general relation is:

```text id="xln2nt"
produced effect
    → staged or immediate effect
    → Σ integration if required
    → visible architectural state
```

Some instructions commit immediately.

Others require explicit commit, barrier, trap return, transaction close, boundary closure, or policy activation.

### 10.3 When Commit Is Required

Not every instruction requires an explicit Σ instruction.

Some instructions commit directly as part of their ordinary architectural effect. Others require an explicit commit phase, barrier, transaction close, or integration point.

Commit is required or relevant for:

| Situation          | Commit reading                                                     |
| ------------------ | ------------------------------------------------------------------ |
| register writeback | produced register value becomes visible                            |
| staged store       | write becomes visible to its visibility domain                     |
| transaction        | `TX_COMMIT` integrates staged changes                              |
| transaction abort  | `TX_ABORT` closes staged integration context without integration   |
| atomic operation   | read-modify-write completes as one integrated operation            |
| trap return        | handler state is restored into interrupted context                 |
| isolation exit     | isolated effects merge, discard, audit, close, or remain separated |
| boundary exit      | `ISO_EXIT` closes or restores an active boundary context           |
| call return        | callee result integrates into caller-visible state                 |
| memory barrier     | prior effects become ordered / visible                             |
| policy update      | future execution language changes after Ψ activation               |
| MMIO effect        | device-visible state is finalized                                  |
| audit event        | rejection, denial, or fault record becomes durable/visible         |

The architecture distinguishes:

```text id="up51r2"
execution produces effects
Σ integrates effects
Ψ permits or forbids execution and integration
Χ determines visibility / boundary domain
Θ determines order where relevant
```

### 10.4 Staged Effects

PMS-CPU may stage effects before committing them.

The meta-state may contain:

```text id="mg4sxs"
m.transaction_state
m.store_buffer
m.pending_writeback
m.trap_frame
m.isolation_delta
m.boundary_delta
m.policy_update_pending
m.audit_pending
m.speculation_state
m.rollback_state
m.sealed_state
```

A staged effect is not yet fully integrated into architectural state.

Example:

```text id="gc9itn"
STORE produces staged write
COMMIT_BARRIER or TX_COMMIT integrates it
```

A staged write may be:

```text id="lgm2sl"
committed through Σ
aborted through TX_ABORT / Φ rollback
denied by Ψ
hidden by Χ boundary restrictions
delayed by memory-consistency rules
made visible after Θ fence
recorded as audit metadata before becoming visible
```

A staged boundary effect may be:

```text id="sq2b12"
closed through ISO_EXIT
audited through Σ
rolled back through Φ recovery
denied by Ψ
kept separated by Χ
```

The architectural requirement is:

```text id="xd9n1p"
staged effects must remain traceable, typed, and governed.
```

Silent staging is invalid.

### 10.5 Σ-Family Commit Instructions

PMS-CPU exposes explicit Σ-family instructions.

```asm id="y7vt5s"
TX_BEGIN
TX_COMMIT
TX_ABORT

ATOMIC_ADD  FR+Rn, Rsrc
ATOMIC_CAS  FR+Rn, Rcmp, Rnew

COMMIT_BARRIER
```

Their architectural roles are:

| Instruction      | Commit role                                        |
| ---------------- | -------------------------------------------------- |
| `TX_BEGIN`       | create staged transaction context                  |
| `TX_COMMIT`      | integrate staged transaction state                 |
| `TX_ABORT`       | discard or close staged transaction state          |
| `ATOMIC_ADD`     | perform integrated read-modify-write               |
| `ATOMIC_CAS`     | compare and swap as one integrated effect          |
| `COMMIT_BARRIER` | force prior staged effects into ordered visibility |

`TX_ABORT` belongs to the Σ-family because it closes a staged integration context by refusing integration.

It is often Φ-readable as recovery or rollback behavior, but its ISA family remains tied to transaction/commit control.

A profile may represent abort as:

```text id="fu6hhd"
Σ-family transaction close
+ Φ-readable rollback semantics
```

This preserves both views without redefining either operator.

Boundary-exit closure may also become Σ-readable where a profile requires audit, rollback, durable closure, or integration of the post-exit state.

This does not make `ISO_EXIT` a Σ instruction.

`ISO_EXIT` remains Χ-family.

### 10.6 Commit Validity

A commit instruction is valid only when:

```text id="ssejrw"
committable prior structure exists
∧ π_CPU ∈ Π_CPU
∧ frame conditions are coherent
∧ role/capability permits integration
∧ boundary conditions permit visibility or closure
∧ active policy permits commit
∧ ordering constraints are satisfied
```

This can be written:

```text id="x1mahx"
commit_valid(s_cpu, I_Σ) iff
    has_committable_state(s_cpu, I_Σ)
    ∧ π_CPU ∈ Π_CPU
    ∧ frame_ok(I_Σ, s_cpu)
    ∧ role_ok(I_Σ, s_cpu)
    ∧ boundary_ok(I_Σ, s_cpu)
    ∧ ordering_ok(m.ordering, I_Σ)
    ∧ policy_ok(P, s_cpu, I_Σ)
```

Commit validity may depend on:

```text id="s8k5hm"
transaction state
store-buffer state
trap-frame state
call-return state
isolation-domain state
boundary-stack state
sealed-isolation state
policy-update state
MMIO state
audit state
```

A commit is invalid when any required structure is missing, incoherent, unauthorized, boundary-forbidden, unordered, or policy-denied.

### 10.7 Commit Failure

If commit validity fails, PMS-CPU may:

```text id="l18n3j"
raise a Φ trap
abort the transaction
deny the commit under Ψ
mark the state stuck
branch to recovery
halt if policy requires
record a Σ audit / rejection event
preserve staged state for handler inspection
discard staged state under declared rollback semantics
```

The failure remains operator-typed.

Common commit failures:

| Failure                                    | Operator reading           |
| ------------------------------------------ | -------------------------- |
| no staged state                            | Σ precondition failure     |
| frame mismatch                             | □ / Φ fault                |
| role lacks commit authority                | Ω / Ψ denial               |
| boundary forbids visibility                | Χ / Ψ denial               |
| policy forbids commit                      | Ψ denial                   |
| ordering constraint not satisfied          | Θ / Ψ failure              |
| transaction incoherent                     | Φ transaction fault        |
| trap return cannot restore context         | Φ return fault + Σ failure |
| audit commit required but unavailable      | Σ / Ψ failure              |
| sealed context would expand through commit | Χ / Ψ denial               |

A failed commit must not silently expose partial state.

### 10.8 Policy Checks

Ψ constrains both instruction execution and commit.

Policy checks may occur:

```text id="kmse0u"
before execution
during execution
before commit
after commit
at frame entry
at frame return
at boundary crossing
at isolation entry
at isolation exit
at trap entry
at trap return
at syscall entry
at interrupt delivery
at memory visibility
at policy activation
```

A policy check may evaluate:

```text id="q8sixx"
role authorization
capability availability
frame permission
boundary reachability
boundary-exit permission
transaction legality
memory-region permission
syscall permission
trap-return safety
interrupt nesting rules
speculation constraints
memory ordering invariants
executable-frame validity
commit eligibility
audit requirements
sealed-isolation constraints
```

The generic predicate is:

```text id="pixt57"
policy_ok(P, s_cpu, I) = true
```

For commit:

```text id="bb2nq0"
policy_ok(P, s_cpu, I_Σ) = true
```

For trap return:

```text id="efwmdd"
policy_ok(P, s_cpu, EXC_RET) = true
```

For boundary crossing:

```text id="v69wkp"
policy_ok(P, s_cpu, ISO_ENTER) = true
```

For boundary exit:

```text id="xs1ipm"
policy_ok(P, s_cpu, ISO_EXIT) = true
```

For memory visibility:

```text id="l0hsjg"
policy_ok(P, s_cpu, COMMIT_BARRIER) = true
```

### 10.9 Policy Failure

A failed Ψ check does not produce an untyped CPU error.

It may produce:

```text id="avlni9"
policy-denial flag
Φ policy trap
halt condition
rollback
transaction abort
boundary denial
boundary-exit denial
audit event
branch to denial handler
stuck state
```

Examples:

```asm id="xu1215"
CHK_POL POL_CALL_FOO, label_fail
HALT_IF_POL POL_CRITICAL
```

A policy check may branch:

```text id="fhynsr"
Ψ failure → label_fail
```

or recontextualize:

```text id="eeag25"
Ψ failure → Φ policy handler
```

or halt:

```text id="drvslt"
Ψ failure → S_H / halt
```

or record:

```text id="jz7yms"
Ψ failure → Σ_audit
```

The profile must declare how policy failure is represented.

The architecture requires that it remains operator-typed.

### 10.10 Interaction of Σ and Ψ

Σ and Ψ are tightly coupled.

Σ asks:

```text id="y73v96"
Can this produced state be integrated?
```

Ψ asks:

```text id="ddks0r"
Is this execution or integration permitted under active constraints?
```

The integration is valid only when both are satisfied:

```text id="y9gktq"
valid_integration =
    has_committable_state
    ∧ Σ preconditions hold
    ∧ Ψ permits integration
```

A structurally possible commit may be policy-invalid:

```text id="cgfz17"
TX_COMMIT is syntactically valid
∧ transaction state exists
∧ Ψ forbids commit
⇒ no valid commit transition
```

Policy may require commit:

```text id="r8s9o7"
Ψ requires staged writes to be committed before frame exit
```

Policy may prohibit commit:

```text id="pqmkx0"
Ψ forbids integration across a boundary domain
```

Policy may delay commit:

```text id="dsyiqe"
Ψ requires Θ_FENCE before visibility
```

Policy may transform commit failure:

```text id="f75gf0"
Ψ requires audit before rollback
```

Thus:

```text id="h2qqq3"
Σ integrates
Ψ governs whether integration may occur
```

### 10.11 Commit, Boundary, and Distance Projection

Boundary-sensitive commits require Χ validity.

PMS Base 1.3:

```text id="fdmuxi"
Χ = Distance
```

At PMS-CPU level, Χ projects PMS Base Distance into:

```text id="np9rre"
boundary state
reachability domains
visibility domains
address-space separation
protected execution domains
sandbox state
access-separation metadata
isolation-domain state
boundary-exit discipline
```

Examples:

```text id="gqgxuv"
committing a transaction inside one domain must not leak into another domain

exiting an isolation domain must either discard, explicitly integrate, audit,
or keep state separated under the declared profile

a trap return must not restore a frame with illegal reachability

MMIO writes must respect device boundary policy

user/kernel transitions must preserve access separation

audit records must not expose protected data across an invalid boundary
```

A boundary-sensitive commit is valid only if:

```text id="nt7hbk"
boundary_ok(s_cpu, I_Σ)
∧ policy_ok(P, s_cpu, I_Σ)
```

For `ISO_EXIT`, the boundary validity rule is:

```text id="nhxfhs"
ISO_EXIT requires active boundary / isolation context.
```

Invalid:

```text id="ovsja5"
ISO_EXIT without active boundary / isolation context
```

Typed result:

```text id="ujxvo1"
Χ violation
→ Φ trap or Ψ denial
→ optional Σ audit / rejection commit
```

A sealed isolation context has a distinct rule:

```text id="kkkqbd"
sealed isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="orraj9"
valid exit
closure
rollback
audit
commit
```

This preserves the PMS Base / PMS-STACK version boundary:

```text id="np71fx"
PMS Base 1.3:
    Χ = Distance

PMS-CPU:
    Χ projects as boundary, visibility, protection-domain, reachability,
    isolation-domain, access-separation, and boundary-exit discipline.
```

### 10.12 Policy Activation and Future Execution

Ψ may install or activate a new policy.

Example:

```asm id="a1t7zo"
SET_POL pol_id, Rcfg
```

Once activated, the policy restricts future execution:

```text id="ueiu96"
L_PMS,Ψ ⊆ L_PMS
```

At PMS-CPU level:

```text id="bhb5od"
future valid instruction traces are restricted by P'
```

A policy update may itself require commit or ordering discipline:

```asm id="mcy2e3"
SET_POL pol_id, Rcfg
COMMIT_BARRIER
```

or:

```asm id="a864qq"
SET_POL pol_id, Rcfg
FENCE
```

depending on the memory consistency and visibility model.

The architectural point is:

```text id="c25xwq"
Ψ is not a passive annotation.

Ψ changes the future valid execution language of PMS-CPU.
```

A policy update is valid only when:

```text id="lglmxp"
policy object distinguished
∧ authority exists
∧ scope is valid
∧ higher-order policy permits update
∧ activation visibility is ordered / committed where required
```

A policy may seal an isolation context against further expansion.

A policy seal does not automatically forbid valid exit, closure, rollback, audit, or commit.

### 10.13 Policy and Trap Return

Trap return is a critical policy point.

A trap return is valid only if:

```text id="wb0ckl"
saved context exists
∧ saved frame is valid
∧ saved role is permitted
∧ saved boundary domain is coherent
∧ return address is executable
∧ handler effects are committed, staged, or discarded according to profile
∧ active Ψ permits return
```

Policy may deny trap return when:

```text id="xbm6y9"
handler discovered invalid state
kernel role would leak
boundary state is inconsistent
return address is not executable
transaction state is unresolved
audit obligation is unsatisfied
sealed-isolation constraints would be violated
```

Denial may produce:

```text id="ni9bad"
Φ policy handler
Ψ halt
Σ audit
rollback
kill context
```

This prepares the PMS-OS syscall and trap semantics.

### 10.14 Commit and Boundary Exit

`ISO_EXIT` is the PMS-CPU architecture-level boundary-exit instruction.

It is Χ-family, not Σ-family.

However, an exit may require Σ-readable closure, audit, rollback, or commit under a declared CPU profile.

The validity rule is:

```text id="ibobn6"
valid_boundary_exit(s_cpu, ISO_EXIT) iff
    active_boundary_context(s_cpu) = true
    ∧ role_ok(ISO_EXIT, s_cpu)
    ∧ policy_ok(P, s_cpu, ISO_EXIT)
    ∧ boundary_ok(ISO_EXIT, s_cpu)
    ∧ profile_allows(profile, ISO_EXIT)
```

Unbalanced exit is invalid:

```text id="c1j3k9"
active_boundary_context(s_cpu) = false
    ⇒ ISO_EXIT invalid
```

A sealed isolation context permits `ISO_EXIT` only as a valid closure path:

```text id="z1ae65"
sealed isolation permits:
    valid exit
    closure
    rollback
    audit
    commit

sealed isolation forbids:
    new entry
    expansion
    reachability growth
    hidden visibility extension
```

Boundary-exit commit may take several profile-defined forms:

```text id="i0610l"
discard isolated effects

integrate isolated effects through Σ

record audit and close boundary

rollback staged state

restore previous boundary context

halt or trap on invalid closure
```

The architecture requires that the chosen profile remains operator-typed and traceable.

### 10.15 PMS-RUST Boundary-Exit Mapping Note

PMS-CPU names the architecture-level boundary-exit instruction:

```text id="n8v1pq"
ISO_EXIT
```

PMS-RUST exposes a bounded artifact/runtime command:

```text id="p44rhl"
chi_exit
```

The conceptual alignment is:

```text id="yvivn3"
PMS-CPU ISO_EXIT
    = virtual CPU architecture-level boundary-exit instruction

PMS-RUST chi_exit
    = runtime / DSL / validator command evidencing bounded boundary-exit
      behavior under the PMS-RUST v0.1 profile

PMS Base Χ
    = Distance
```

Shared rule:

```text id="jmkyd0"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary:

```text id="t7917a"
chi_exit does not complete PMS-CPU ISO_EXIT.

chi_exit does not redefine PMS Base Χ.

chi_exit does not validate PMS Base.
```

This mapping strengthens implementation-artifact clarity.

It does not collapse runtime artifact behavior into ISA or CPU completion.

### 10.16 Audit and Trace Effects

Commit and policy checks are important trace points.

A PMS-CPU trace may record:

```text id="qwn9do"
cycle
R_pc
op
mnemonic
frame
role
boundary domain
policy result
commit result
trap result
metadata
```

A commit/policy trace event may have the form:

```text id="qi7b4e"
event = (
    cycle,
    op,
    mnemonic,
    frame,
    role,
    boundary,
    policy_id,
    policy_result,
    commit_kind,
    commit_result,
    trap_result,
    audit_ref,
    meta
)
```

A concrete commit/policy execution records:

```text id="w0ovb3"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="v1a79d"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

The declared execution profile determines:

```text id="r6r17f"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="msctoe"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

This supports:

```text id="wgvsmu"
debugging
verification
replay
simulation
policy auditing
golden trace comparison
artifact evidence
ISO_EXIT validation
sealed-isolation validation
```

Trace emission is an implementation/artifact choice.

Operator-labeled representability is the architecture invariant.

Trace evidence strengthens bounded implementation-artifact claims.

It does not validate PMS Base.

### 10.17 Commit and Policy Validity Summary

| Check               | Operator | Question                                                   |
| ------------------- | -------- | ---------------------------------------------------------- |
| committable state   | Σ        | is there prior structure to integrate?                     |
| frame coherence     | □        | is the integration frame-valid?                            |
| role/capability     | Ω        | is the actor allowed to integrate, update, or exit?        |
| ordering            | Θ        | is visibility ordered correctly?                           |
| boundary validity   | Χ        | does integration or exit respect Distance projection?      |
| policy permission   | Ψ        | is execution, integration, or exit permitted?              |
| recontextualization | Φ        | is failure handled through typed context shift?            |
| absence / wait      | Λ        | is commit blocked by expected but absent condition?        |
| distinction         | Δ        | is the target/effect/policy/boundary object distinguished? |

This table is a validity summary, not a new operator set.

### 10.18 Commit and Policy Invariants

```text id="m7wl7s"
CPU-CP1: PMS-CPU separates execution, staging, and commit where required

CPU-CP2: Π_CPU denotes the PMS-CPU program domain

CPU-CP3: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-CP4: Σ integrates prior committable activity into visible state

CPU-CP5: Σ is invalid without committable prior structure

CPU-CP6: Ψ constrains instruction execution, commit, trap entry, trap return,
         boundary crossing, boundary exit, and memory visibility

CPU-CP7: structurally possible commit may be policy-invalid

CPU-CP8: policy update changes future valid CPU traces

CPU-CP9: PMS Base Χ = Distance

CPU-CP10: PMS-CPU projects Χ as boundary, visibility, protection-domain,
          reachability, isolation-domain, access-separation, and
          boundary-exit discipline

CPU-CP11: boundary-sensitive commits require Χ and Ψ validity

CPU-CP12: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-CP13: ISO_EXIT requires an active boundary / isolation context

CPU-CP14: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-CP15: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-CP16: PMS-RUST chi_exit is an artifact/runtime boundary-exit command,
          not the PMS-CPU ISO_EXIT instruction

CPU-CP17: failed commit or failed policy check must remain operator-typed

CPU-CP18: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-CP19: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-CP20: trace and audit events strengthen artifact evidence but do not
          validate PMS Base

CPU-CP21: commit/policy architecture is virtual CPU architecture, not
          physical hardware
```

### 10.19 Architectural Consequence

The commit and policy phase gives PMS-CPU its integration discipline.

The consequence is:

```text id="pm7n73"
PMS-CPU execution is valid only when produced effects can be integrated
through Σ under coherent frame, role, boundary, ordering, and Ψ policy
constraints.
```

This prevents the virtual CPU from treating writes, returns, traps, transaction exits, policy updates, boundary crossings, and boundary exits as unstructured side effects.

They become operator-typed integration points in the PMS-STACK execution model.

The boundary-exit consequence is:

```text id="yjb6bw"
ISO_EXIT is valid only with active boundary / isolation context.

Unbalanced ISO_EXIT is invalid.

Sealed isolation forbids expansion while permitting valid closure paths.
```

### 10.20 Boundary Statement

The correct boundary for this chapter is:

```text id="bm1l3j"
The PMS-CPU commit and policy model defines how produced effects become
valid architectural state through Σ under active Ψ constraints, frame
coherence, role/capability authority, Χ boundary discipline, Θ ordering,
and declared boundary-exit rules.

This is a virtual CPU commit/policy architecture claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.
PMS-RUST chi_exit is an artifact/runtime boundary-exit command. The two
correspond at the boundary-exit concept level but are not the same layer.

This chapter does not specify physical writeback hardware, cache hardware,
reorder buffers, fabricated transactional memory, completed simulator
behavior, PMS Base Χ redefinition, or PMS Base validation.
```

---

## 11. Memory Consistency Model

PMS-CPU defines memory consistency through the Δ–Ψ operator discipline.

The memory consistency model specifies when reads, writes, commits, fences, frame changes, boundary transitions, boundary exits, and policy constraints become visible to execution.

It is a virtual CPU memory model.

It does not claim a physical cache hierarchy or fabricated hardware protocol.

The active PMS-CPU program is:

```text id="qkr2so"
π_CPU ∈ Π_CPU
```

where:

```text id="t9tew5"
Π_CPU = set of PMS-CPU programs / instruction streams / binary images

π_CPU = one concrete PMS-CPU program / instruction stream / binary image
```

The central PMS-CPU memory principle is:

```text id="m12h67"
memory effects are valid only when distinction, action, ordering,
visibility domain, integration, and policy constraints are coherent.
```

Claim type:

```text id="cd2dap"
virtual CPU memory-consistency architecture claim
```

Boundary:

```text id="5tdx52"
This section defines a virtual CPU memory-consistency model.

It does not claim physical cache-coherence hardware.

It does not define fabricated memory-controller behavior.

It does not imply implementation of all memory profiles.

It does not validate PMS Base.
```

A concrete PMS-CPU memory execution records:

```text id="d0vl02"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="uvsofk"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="v4own9"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="dwv9ab"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

At CPU level, the relevant operators are:

| Operator | Memory-consistency role                                                                                  |
| -------- | -------------------------------------------------------------------------------------------------------- |
| Δ        | read, classify, compare, distinguish address/value                                                       |
| ∇        | write, load/store, register update, memory mutation                                                      |
| □        | frame and address-context selection                                                                      |
| Ω        | authority over memory access                                                                             |
| Θ        | ordering, fences, happens-before structure                                                               |
| Φ        | abort, fault, trap, recontextualization on invalid memory event                                          |
| Χ        | Distance projected as visibility domain, isolation boundary, access separation, boundary-exit discipline |
| Σ        | commit, write visibility, transaction integration, memory barrier, closure integration                   |
| Ψ        | memory policy, invariant, permission, ordering constraint, sealed-isolation constraint                   |
| Λ        | timeout or absence while waiting for visibility/event                                                    |
| Α        | memory-access pattern, loop, protocol, or transaction template                                           |

### 11.1 Memory State

PMS-CPU memory is modeled as:

```text id="ml77np"
MEM : Address → Byte
```

or, at a word-level abstraction:

```text id="sk9kpm"
MEM : Address → Word
```

Memory access is interpreted relative to:

```text id="j1cwzb"
active frame
active role/capability
active boundary domain
active policy
ordering state
commit state
concrete program π_CPU ∈ Π_CPU
```

A memory location is not merely an address.

It is an address under:

```text id="jisb19"
□ frame context
Ω authority context
Χ visibility/boundary context
Ψ policy context
Θ ordering context
Σ commit context
```

### 11.2 Memory Operations

A load is a Δ/∇-structured operation:

```text id="mmtbec"
Δ distinguish address / frame / permission
Ω authorize read if required
Χ check reachability if boundary-sensitive
Ψ check policy
∇ transfer value into register
```

A store is a Δ/□/Ω/Χ/Ψ/∇/Σ-structured operation:

```text id="fxuyss"
Δ distinguish address / target
□ bind active frame
Ω authorize write
Χ check boundary / visibility domain
Ψ permit mutation
∇ produce write
Σ commit or stage visibility
```

The write may become visible immediately or may remain staged depending on:

```text id="g751gb"
memory model
transaction state
store-buffer state
fence state
boundary domain
policy constraints
sealed-isolation state
```

A memory operation is valid only if:

```text id="c4y56g"
address is distinguished
∧ π_CPU ∈ Π_CPU
∧ frame permits the address
∧ role/capability permits access
∧ boundary permits reachability
∧ active policy permits operation
∧ ordering and commit constraints are satisfied where relevant
```

### 11.3 Fundamental Ordering Dimensions

PMS-CPU memory consistency is governed by three structural dimensions.

#### Axis A — Intrinsic operator ordering

A normal memory effect follows:

```text id="mbm7cn"
Δ ≺ ∇ ≺ Σ
```

Meaning:

```text id="n16axh"
distinguish target before action
perform action before commit
commit before externally visible integration
```

This is not a physical pipeline claim.

It is the architectural dependency order for valid memory effects.

#### Axis B — Θ ordering

Θ establishes ordering boundaries.

Examples:

```asm id="x1kiuf"
FENCE
TICK
YIELD
COMMIT_BARRIER
```

A Θ fence may prevent reordering across an architectural boundary:

```text id="l8uc74"
effects before Θ_FENCE must be observed before effects after Θ_FENCE
```

Θ structures happens-before relations.

It is not physical time.

#### Axis C — □ / Χ visibility domains

Frames and Distance projections define where memory effects are visible.

```text id="xdz2lw"
□ selects the frame / address context

Χ projects Distance as boundary, reachability, isolation, access separation,
and boundary-exit discipline
```

A write may be visible inside one frame or domain but not another until Σ integrates it across a permitted boundary.

A boundary exit may close, discard, audit, roll back, or integrate isolated state only if the active CPU profile permits it.

### 11.4 Baseline Sequential Consistency: PMS-SC

The baseline PMS-CPU memory model is:

```text id="rcivoc"
PMS-SC
```

PMS-SC means that all architecturally visible memory operations appear in a total order that respects:

```text id="k8n6ce"
program order
∧ Δ before ∇
∧ ∇ before Σ
∧ Θ fences
∧ □ frame validity
∧ Χ visibility domains
∧ Ψ policy constraints
```

A simplified order is:

```text id="w8gqo8"
Δ ≺ ∇ ≺ Σ
```

with Θ establishing ordering boundaries and □/Χ establishing visibility domains.

PMS-SC is the default reference model for:

```text id="hp1r2l"
clear reasoning
tests
simulators
golden fixtures
specification examples
formal baseline models
```

PMS-SC is a virtual memory-model profile.

It does not claim physical sequential consistency of fabricated hardware.

### 11.5 Happens-Before Relation

PMS-CPU defines a happens-before relation:

```text id="u5xqsa"
HB
```

`HB` is the transitive closure of:

```text id="yf0fq6"
program_order
Θ ordering boundaries
Σ commit visibility
□ frame-local ordering
Χ boundary visibility constraints
Ω authorization dependencies
Ψ policy constraints
Φ trap / recovery ordering
Λ timeout / absence ordering where relevant
```

Schematic definition:

```text id="p0epr4"
HB = transitive_closure(
    program_order
    ∪ theta_order
    ∪ sigma_commit_order
    ∪ frame_order
    ∪ boundary_order
    ∪ authority_order
    ∪ policy_order
    ∪ trap_order
    ∪ absence_order
)
```

A memory effect is visible to another operation only if visibility is permitted by:

```text id="rtukxl"
HB
∧ frame compatibility
∧ boundary compatibility
∧ role authorization
∧ active policy
```

`HB` is an architectural relation.

It is not a physical timing statement.

### 11.6 Store Buffers and Delayed Σ

PMS-CPU may model delayed store visibility through staged writes.

A store may produce:

```text id="hdpj0b"
m.store_buffer += (addr, value, frame, role, domain, policy_meta)
```

This is an ∇ effect that has not yet been globally integrated.

Σ integrates the staged write:

```text id="eiu9d2"
MEM' = commit(m.store_buffer, MEM)
```

A delayed store is valid only if:

```text id="dfmm1r"
the staged write is tracked
∧ the commit condition is explicit
∧ ordering state permits delayed visibility
∧ policy permits delayed visibility
∧ boundary visibility is preserved
```

This gives PMS-CPU a clean way to express:

```text id="j4zs55"
write buffers
transactional staging
deferred visibility
MMIO completion
speculative store rollback
```

without losing operator structure.

### 11.7 Relaxed Consistency as Structural Relaxation

Relaxed memory models arise by relaxing when Δ, ∇, Θ, Χ, and Σ become visible relative to one another.

PMS-CPU can express relaxations without abandoning its operator discipline.

#### R1 — Out-of-order Δ

Reads may be speculated or reordered:

```text id="ylz9es"
Δ_read may occur before earlier unresolved effects
```

Valid only if:

```text id="dd60sl"
Ψ permits speculation
∧ rollback or Φ recovery is defined
∧ final committed trace preserves architectural validity
```

#### R2 — Delayed Σ

Writes may be staged before becoming visible:

```text id="s0wvxg"
∇_store occurs
Σ_commit delayed
```

This models store buffering.

#### R3 — Frame-based reordering

Effects in different frames may be reordered when:

```text id="b9er9q"
□ frame independence holds
∧ Ψ permits reordering
∧ no HB relation forbids it
```

#### R4 — Boundary-based reordering

Effects in different Χ domains may be delayed, isolated, or integrated separately.

This models:

```text id="nn8d2z"
transactions
sandboxes
isolated contexts
protected domains
tenant domains
kernel/user separation
```

Rule:

```text id="cz7rqh"
Χ separates visibility
Σ integrates when permitted
Ψ governs whether integration is allowed
```

A sealed isolation context adds:

```text id="o8p60n"
sealed isolation forbids further entry, expansion, or reachability growth
```

while still permitting, under declared profile:

```text id="qcbm1o"
valid exit
closure
rollback
audit
commit
```

### 11.8 Θ_FENCE and Commit Barriers

PMS-CPU uses Θ-family and Σ-family mechanisms for ordering and visibility control.

A Θ fence:

```asm id="yjf6ww"
FENCE
```

prevents specified reorderings across an ordering boundary.

A commit barrier:

```asm id="y9ddtz"
COMMIT_BARRIER
```

forces staged effects to become integrated or visible according to the active memory model.

The relation is:

```text id="r5n0g4"
Θ_FENCE constrains order

Σ / COMMIT_BARRIER integrates effects

Ψ determines whether the operation is permitted

Χ determines the visibility domain
```

Examples:

```text id="ej2qtt"
acquire fence
    = Θ constraint on later reads/writes

release fence
    = Θ constraint on earlier writes before publication

full fence
    = Θ constraint in both directions

commit barrier
    = Σ visibility integration point
```

A fence without policy permission is invalid.

A commit barrier without committable state is invalid unless the profile explicitly permits no-op barriers.

A boundary-exit closure may require both Θ and Σ:

```text id="hvjv8a"
Θ orders pre-exit effects

Σ integrates, audits, discards, or closes them according to profile

Χ determines whether exit is valid

Ψ permits or denies closure
```

### 11.9 PMS-SC Profile

The PMS-SC profile can be stated as:

```text id="g4ov5q"
all visible memory operations are totally ordered
∧ program order is preserved
∧ reads observe the latest visible write in that order
∧ Σ determines write visibility
∧ Θ fences constrain ordering
∧ □/Χ define visibility domains
∧ Ψ may further restrict visibility
```

Read rule:

```text id="klai05"
read(addr) observes write(addr) iff
    write(addr) is the latest visible committed write to addr
    under HB, frame compatibility, boundary compatibility, role authority,
    and policy permission
```

Write rule:

```text id="y9ukuf"
write(addr, value) becomes visible iff
    ∇_store produced the write
    ∧ Σ integrated it
    ∧ boundary permits visibility
    ∧ policy permits visibility
```

PMS-SC is the default reference profile.

### 11.10 TSO-Style Model

A TSO-style PMS-CPU model can be expressed as:

```text id="vfqzsl"
stores may be delayed in a store buffer
loads may read from own store buffer
store → store order preserved
store → load reordering may occur through delayed Σ
FENCE forces Σ visibility
```

Operator reading:

| TSO feature           | PMS-CPU interpretation                |
| --------------------- | ------------------------------------- |
| store buffer          | ∇ store staged before Σ               |
| load bypass           | Δ read may observe local staged state |
| preserved store order | Θ ordering over staged writes         |
| fence                 | Θ + Σ visibility boundary             |
| atomic RMW            | ∇ + Σ indivisible integration         |

This is not a claim that PMS-CPU implements x86 TSO.

It states that a TSO-style memory model can be represented through PMS-CPU operators.

### 11.11 ARM/POWER-Style Weak Models

A weaker PMS-CPU model may permit more reorderings.

Examples:

```text id="hrcfk9"
loads may reorder
stores may be delayed
dependencies may constrain reads
acquire/release fences establish local order
policy may forbid unsafe speculation
```

Operator reading:

| Weak-model feature    | PMS-CPU interpretation            |
| --------------------- | --------------------------------- |
| reordered reads       | Δ relaxation                      |
| delayed stores        | delayed Σ                         |
| acquire               | Θ fence on later effects          |
| release               | Θ fence on earlier effects        |
| dependency ordering   | Δ/∇ relation preserved by Ψ       |
| speculation recovery  | Φ rollback or recontextualization |
| unsafe pattern denial | Ψ constraint                      |
| boundary visibility   | Χ domain-specific reachability    |

This shows that PMS-CPU can specify weak memory behavior structurally, while still requiring explicit policy and recovery discipline.

### 11.12 Transactional Memory

Transactional memory is expressed through:

```text id="ee47q0"
Χ + Σ + Ψ
```

A transaction creates or enters a separated visibility context:

```asm id="ngcdg3"
TX_BEGIN
```

Writes inside the transaction are staged:

```text id="fzqa4g"
m.transaction_state += writes
```

Commit integrates:

```asm id="rsmuit"
TX_COMMIT
```

Abort recontextualizes or closes the staged context without integration:

```asm id="wq2c29"
TX_ABORT
```

Operator reading:

| Transaction phase | PMS operator structure                           |
| ----------------- | ------------------------------------------------ |
| begin             | Χ / Σ setup depending on profile                 |
| read/write        | Δ / ∇ inside transaction domain                  |
| validate          | Ψ                                                |
| commit            | Σ                                                |
| abort             | Φ-readable rollback / Σ-family transaction close |
| isolation         | Χ                                                |
| ordering          | Θ                                                |

A transaction is valid only if:

```text id="vp34qr"
transaction state exists
∧ boundary domain is coherent
∧ no conflicting visibility rule is violated
∧ ordering constraints are satisfied
∧ Ψ permits commit
```

Transactional memory is a virtual CPU memory-model profile.

It does not claim fabricated transactional hardware.

### 11.13 Boundary Exit and Visibility

Boundary exit is memory-consistency relevant because it may change which effects become visible, remain isolated, are discarded, or are audited.

At PMS-CPU level, boundary exit is represented by:

```text id="tlxw44"
ISO_EXIT
```

`ISO_EXIT` is Χ-family.

It is valid only when:

```text id="jl2mqo"
active boundary / isolation context exists
∧ role/capability permits exit
∧ active policy permits exit
∧ declared CPU profile permits boundary closure
```

Unbalanced exit is invalid:

```text id="gsdzz6"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

Typed outcome:

```text id="axc8uz"
Χ violation
→ Φ trap or Ψ denial
→ optional Σ audit / rejection commit
```

A sealed isolation context has a distinct memory-visibility rule:

```text id="qtbehl"
sealed isolation forbids:
    entry
    expansion
    reachability growth
    hidden visibility extension
```

but permits, under declared profile and active boundary context:

```text id="rf0x99"
valid exit
closure
rollback
audit
commit
```

Boundary-exit visibility may be profile-defined:

```text id="onn5yw"
discard isolated effects
commit selected effects
audit and close
rollback staged state
restore previous visibility domain
preserve separation after exit
halt or trap on invalid closure
```

The architecture requires that the selected behavior remains:

```text id="cyot1a"
operator-typed
traceable
frame-valid
role-authorized
boundary-valid
policy-permitted
ordering-coherent
```

### 11.14 Language-Level Memory Models

PMS-CPU can support language-level memory models through mappings from language constructs to Θ, Σ, Χ, and Ψ.

| Language-level concept   | PMS-CPU operator interpretation                       |
| ------------------------ | ----------------------------------------------------- |
| `seq_cst`                | Ψ + Θ full fence + Σ visibility discipline            |
| `acquire`                | Θ acquire fence                                       |
| `release`                | Θ release fence + Σ publication                       |
| `relaxed`                | Δ/∇ without additional fence, still Ψ-governed        |
| atomic read/write        | ∇ with Ω/Ψ authorization                              |
| atomic read-modify-write | ∇ + Σ indivisible integration                         |
| publication safety       | Σ + Ψ                                                 |
| data-race denial         | Ψ policy over conflicting ∇ traces                    |
| isolation boundary       | Χ visibility restriction                              |
| boundary exit            | Χ with optional Σ-readable closure / audit discipline |

This connects PMS-CPU to PMSL/PMS-IR without claiming that PMSL’s complete memory model is fixed here.

`05_pmsl_pms_ir.md` refines the language-level side.

### 11.15 Memory Faults

Invalid memory behavior is operator-typed.

| Fault                          | Operator reading            |
| ------------------------------ | --------------------------- |
| invalid address                | Δ / □ failure → Φ           |
| permission failure             | Ω / Ψ failure → Φ           |
| boundary violation             | Χ / Ψ failure → Φ           |
| unbalanced boundary exit       | Χ failure → Φ / Ψ / Σ-audit |
| sealed-isolation expansion     | Χ / Ψ failure → Φ           |
| commit without staged state    | Σ failure → Φ / Ψ           |
| speculative violation          | Ψ failure → Φ rollback      |
| timeout waiting for visibility | Λ                           |
| frame mismatch                 | □ failure → Φ               |
| transaction conflict           | Χ / Σ / Ψ failure           |
| invalid MMIO access            | Ω / Χ / Ψ failure           |

A memory fault is not merely an exception code.

It is a recontextualized operator failure with trace meaning.

Fault handling may:

```text id="a088em"
trap
halt
rollback
audit
deny continuation
quarantine boundary state
abort transaction
```

depending on active policy and profile.

### 11.16 Memory Trace Events

A memory trace event may have the form:

```text id="di1j2t"
mem_event = (
    cycle,
    op,
    address,
    frame,
    role,
    boundary_domain,
    access_kind,
    ordering_state,
    commit_state,
    policy_result,
    visibility_result,
    trap_result,
    meta
)
```

This supports:

```text id="j20fbr"
memory-model testing
store-buffer debugging
transaction testing
compiler lowering checks
data-race analysis
policy auditing
artifact evidence
ISO_EXIT testing
sealed-isolation testing
```

A concrete memory execution records:

```text id="tloeno"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="qaejrz"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

The declared memory/profile execution space is:

```text id="nvlfgw"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="wmt47c"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

Trace events remain bounded artifact evidence.

They do not validate PMS Base.

### 11.17 Memory Consistency Claim

The PMS-CPU memory consistency claim is:

```text id="on6tyj"
PMS-CPU defines memory ordering and visibility through Δ distinction,
∇ mutation, □ frame binding, Ω authority, Θ ordering, Χ visibility domains,
Σ commit, and Ψ policy constraints.
```

This gives PMS-CPU a unified way to express:

```text id="aii1ex"
sequential consistency
store buffering
weak memory relaxations
fences
transactions
isolation domains
boundary exits
language-level atomics
policy-governed memory safety
fault handling
auditability
```

Claim type:

```text id="x40owa"
virtual CPU memory-consistency architecture claim
```

Boundary:

```text id="snv6wi"
This is a virtual CPU memory-model specification.

It does not claim a physical cache-coherence protocol.

It does not claim fabricated hardware.

It does not imply that all profiles are implemented.

It does not validate PMS Base.
```

### 11.18 Memory Consistency Invariants

```text id="zqxv6z"
CPU-MC1: PMS-CPU memory consistency is defined through Δ–Ψ operator
         discipline

CPU-MC2: Π_CPU denotes the PMS-CPU program domain

CPU-MC3: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-MC4: memory effects require distinction, action, frame, authority,
         boundary, ordering, commit, and policy coherence where relevant

CPU-MC5: the baseline profile is PMS-SC

CPU-MC6: PMS-SC orders visible memory operations by program order, Θ fences,
         Σ commit visibility, □ frame validity, Χ visibility domains, and
         Ψ policy constraints

CPU-MC7: HB is an architectural relation, not physical time

CPU-MC8: store buffers are staged ∇ effects requiring explicit or implicit Σ
         visibility

CPU-MC9: relaxed models are structural relaxations, not untyped behavior

CPU-MC10: Θ fences constrain order; Σ barriers integrate effects

CPU-MC11: PMS Base Χ = Distance

CPU-MC12: PMS-CPU projects Χ as visibility domain, boundary, isolation,
          access-separation, and boundary-exit discipline

CPU-MC13: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-MC14: ISO_EXIT requires an active boundary / isolation context

CPU-MC15: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-MC16: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-MC17: transactional memory is Χ + Σ + Ψ structured

CPU-MC18: memory faults are operator-typed through Φ, Ψ, Χ, Σ, Λ, Δ, □, or Ω

CPU-MC19: language-level memory models may map into PMS-CPU but are refined
          in PMSL/PMS-IR documentation

CPU-MC20: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-MC21: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-MC22: memory trace events support artifact evidence but do not validate
          PMS Base

CPU-MC23: PMS-CPU memory consistency is virtual CPU architecture, not physical
          cache-coherence hardware
```

### 11.19 Architectural Consequence

The memory consistency model gives PMS-CPU a unified visibility discipline.

The consequence is:

```text id="gn329m"
PMS-CPU memory behavior is valid only when reads, writes, staging,
visibility, fences, commits, transactions, faults, boundaries, boundary
exits, and policies remain expressible as operator-typed transitions over
Δ–Ψ.
```

This keeps memory behavior inside PMS-STACK architecture rather than treating memory ordering, transactions, isolation, boundary exits, and policy as external add-ons.

The boundary-exit consequence is:

```text id="t9yl7f"
ISO_EXIT requires active boundary / isolation context.

Unbalanced ISO_EXIT is invalid.

Sealed isolation forbids expansion while permitting valid closure paths.
```

### 11.20 Boundary Statement

The correct boundary for this chapter is:

```text id="h1r4di"
The PMS-CPU memory consistency model defines virtual memory ordering,
visibility, staging, fences, commits, relaxed profiles, transactions,
boundary exits, faults, and language-level memory mappings through Δ–Ψ
operator structure.

This is a virtual CPU memory-consistency architecture claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction. Its
memory-consistency role is to govern valid boundary closure and visibility
under an active boundary / isolation context.

This chapter does not define physical cache-coherence hardware, physical
memory controllers, fabricated transactional memory, completed simulator
behavior, PMS Base Χ redefinition, or PMS Base validation.
```

---

## 12. PMS-CPU as PMS-UM Instance

PMS-CPU is a specialized instance of PMS-UM.

PMS-UM defines the general abstract machine:

```text id="m9adp8"
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

PMS-CPU instantiates that tuple with virtual processor structures.

The result is:

```text id="pnnouh"
M_CPU =
    (S_CPU, Γ_CPU, F_CPU, R_CPU, PSet_CPU, O,
     ISA, Π_CPU, δ_CPU, s₀_CPU, S_H_CPU)
```

where PMS-CPU uses the same operator alphabet:

```text id="ndmlnw"
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The PMS-CPU program domain is:

```text id="e9knj7"
Π_CPU
```

A concrete PMS-CPU program, instruction stream, or binary image is:

```text id="ixkeng"
π_CPU ∈ Π_CPU
```

The central claim is:

```text id="fyf1g7"
PMS-CPU is a PMS-UM instance whose state space is virtual processor state,
whose instructions are PMS-operator-typed ISA instructions, whose programs
are virtual instruction streams, and whose transition relation is the
fetch–decode–execute cycle constrained by frame, role, boundary, commit,
ordering, trap, interrupt, and policy rules.
```

Claim type:

```text id="tgdznv"
virtual CPU as PMS-UM-instance architecture claim
```

Boundary:

```text id="abz2i1"
This section defines the formal relationship between PMS-UM and PMS-CPU.

It does not claim fabricated hardware.

It does not imply that a complete PMS-CPU simulator already exists.

It does not validate PMS Base.
```

A concrete PMS-CPU execution records:

```text id="avlrrl"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="srvbbj"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="n1gfsc"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="r99l36"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 12.1 Tuple Mapping

The PMS-UM tuple is:

```text id="vq0v10"
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

The PMS-CPU tuple is:

```text id="yve3ye"
M_CPU =
    (S_CPU, Γ_CPU, F_CPU, R_CPU, PSet_CPU, O,
     ISA, Π_CPU, δ_CPU, s₀_CPU, S_H_CPU)
```

Mapping:

| PMS-UM component | PMS-CPU instance                                                       |
| ---------------- | ---------------------------------------------------------------------- |
| `S`              | set of coherent PMS-CPU states                                         |
| `Γ`              | byte/word alphabet for memory and registers                            |
| `F`              | CPU frame table and frame identifiers                                  |
| `R`              | CPU role, privilege, and capability modes                              |
| `PSet`           | CPU policy sets                                                        |
| `O`              | Δ–Ψ operator alphabet                                                  |
| `Inst`           | PMS-CPU ISA instruction schemata                                       |
| `Π`              | PMS-CPU program domain: programs / binary images / instruction streams |
| `δ`              | PMS-CPU fetch–decode–execute transition relation                       |
| `s₀`             | initial CPU state                                                      |
| `S_H`            | CPU halt, trap-halt, or policy-halt states                             |

This mapping is direct.

PMS-CPU does not require a second foundation.

It specializes PMS-UM into a virtual processor architecture.

### 12.2 State Mapping

PMS-UM execution state:

```text id="ge5ohs"
s⁺ = (s_c, f, r, P, m, ip)
```

PMS-CPU state:

```text id="m29y5w"
s_cpu =
    (RF, MEM, R_pc, R_sp, R_fp, R_fr,
     R_role, R_cap, R_flag, R_iso, P, m)
```

Mapping:

| PMS-UM state component | PMS-CPU state component                                                     |
| ---------------------- | --------------------------------------------------------------------------- |
| `s_c`                  | `RF`, `MEM`, `R_pc`, `R_sp`, `R_fp`, `R_flag`                               |
| `f`                    | `R_fr`, `FrameTable`                                                        |
| `r`                    | `R_role`, `R_cap`                                                           |
| `P`                    | active CPU policy set, optional `R_pol`                                     |
| `m`                    | ordering, trap, interrupt, transaction, boundary, audit, non-event metadata |
| `ip`                   | `R_pc`                                                                      |

Thus, PMS-CPU is a PMS-UM whose core data domain is register/memory execution state.

The core specialization is:

```text id="pwnnbr"
PMS-UM core state
    → virtual CPU register and memory state
```

The frame specialization is:

```text id="j1lzia"
PMS-UM frame
    → CPU frame register and frame table
```

The role specialization is:

```text id="du7b31"
PMS-UM role
    → CPU role register and capability state
```

The policy specialization is:

```text id="m1g0mv"
PMS-UM policy
    → active CPU policy set
```

The meta-state specialization is:

```text id="r05oud"
PMS-UM meta-state
    → ordering, trap, interrupt, boundary, transaction, audit,
      non-event, sealed-isolation, boundary-exit, and trace metadata
```

The boundary-state specialization preserves the version boundary:

```text id="c4bhut"
PMS Base 1.3:
    Χ = Distance

PMS-CPU:
    Χ projects as virtual CPU boundary, reachability, visibility-domain,
    protection-domain, isolation-domain, access-separation, and
    boundary-exit discipline.
```

### 12.3 Program Mapping

PMS-UM programs are finite sequences of operator-typed instructions:

```text id="k4wz0g"
π = ⟨ I₁, I₂, …, Iₙ ⟩
```

with:

```text id="zgl0vh"
π ∈ Π
```

PMS-CPU programs are virtual instruction streams or binary images:

```text id="fcb5ea"
π_CPU = ⟨ Instr₁, Instr₂, …, Instrₙ ⟩
```

or:

```text id="xs3m4a"
π_CPU : Address → InstrWord
```

with:

```text id="s51ti8"
π_CPU ∈ Π_CPU
```

A PMS-CPU program is therefore a PMS-UM program whose instructions have ISA-level shape.

PMS-UM instruction:

```text id="o6iqjp"
I = (op, params, pre, post)
```

PMS-CPU instruction:

```text id="jjdpgd"
Instr = (mnemonic, op, operands, constraints)
```

The mapping is:

| PMS-UM instruction field | PMS-CPU instruction field                                                |
| ------------------------ | ------------------------------------------------------------------------ |
| `op`                     | operator family Δ–Ψ                                                      |
| `params`                 | operands, immediates, labels, frame ids, role ids, policy ids            |
| `pre`                    | constraints: dependency, frame, role, boundary, commit, ordering, policy |
| `post`                   | ISA execution semantics / CPU state update                               |

A PMS-CPU instruction stream is valid only when concrete executions satisfy:

```text id="g54o1r"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="q3vdm7"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

For a declared machine/program/profile, the possible executions must satisfy:

```text id="qz2fcz"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="sddn4l"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 12.4 Instruction Mapping

A PMS-UM instruction has the form:

```text id="r0xtu4"
I = (op, params, pre, post)
```

A PMS-CPU instruction has the form:

```text id="eavm5g"
Instr = (mnemonic, op, operands, constraints)
```

The mapping is:

```text id="q2m4kc"
mnemonic
    → machine-level instruction name

op
    → PMS operator family

operands
    → PMS-UM params

constraints
    → precondition structure

execution
    → postcondition / transition relation
```

Example:

```asm id="tffnos"
ADD R1, R2
```

maps to:

```text id="zayl7f"
I_ADD = (∇, params=(R1, R2), pre_ADD, post_ADD)
```

where:

```text id="rirn7g"
pre_ADD checks:
    register availability
    frame coherence
    role/capability validity
    boundary validity if relevant
    policy validity

post_ADD updates:
    RF[R1]
    R_flag
    ordering / trace metadata where relevant
```

Example:

```asm id="y98qm8"
TRAP #0
```

maps to:

```text id="rtx0m3"
I_TRAP = (Φ, params=(0), pre_TRAP, post_TRAP)
```

where:

```text id="ue23ur"
pre_TRAP checks:
    trap cause / trap code
    handler table
    role transition permission
    frame validity
    boundary validity
    policy permission

post_TRAP:
    saves context
    enters handler frame
    switches role
    records trap metadata
    sets handler program counter
```

Example:

```asm id="xv9jiw"
ISO_ENTER ctx
```

maps to:

```text id="t7l6ne"
I_ISO_ENTER = (Χ, params=(ctx), pre_ISO_ENTER, post_ISO_ENTER)
```

where:

```text id="cuxyuo"
pre_ISO_ENTER checks:
    context exists
    frame/domain validity
    authority
    policy permission

post_ISO_ENTER:
    updates R_iso
    updates boundary metadata
    updates reachability state
```

Example:

```asm id="e6ldcu"
ISO_EXIT
```

maps to:

```text id="y0823x"
I_ISO_EXIT = (Χ, params=(), pre_ISO_EXIT, post_ISO_EXIT)
```

where:

```text id="r82tfp"
pre_ISO_EXIT checks:
    active boundary / isolation context exists
    role/capability permits exit
    policy permits exit
    declared CPU profile permits closure

post_ISO_EXIT:
    restores or closes boundary context
    updates R_iso
    updates boundary stack / isolation stack
    records closure, rollback, audit, or commit metadata where required
```

Unbalanced exit is invalid:

```text id="wztmkp"
ISO_EXIT without active boundary / isolation context
    → invalid transition
```

This is a PMS-CPU projection of PMS Base Distance.

It does not redefine Χ.

### 12.5 Transition Mapping

PMS-UM transition:

```text id="lvntug"
(s⁺, π) ⇒ (s⁺', π)
```

where:

```text id="rg9sph"
π ∈ Π
```

PMS-CPU transition:

```text id="rkzmcz"
(s_cpu, π_CPU) → (s_cpu', π_CPU)
```

or, with configuration:

```text id="qhrqxq"
κ_cpu → κ_cpu'
```

where:

```text id="fc2cma"
κ_cpu = (s_cpu, π_CPU, R_pc, h_cpu, e_cpu)
π_CPU ∈ Π_CPU
```

The PMS-CPU transition is the PMS-UM step relation specialized by fetch–decode–execute:

```text id="g0jivy"
δ_CPU =
    Θ_order
    ; Δ_fetch
    ; Δ_decode
    ; ΩΨ_validate
    ; □_bind
    ; Χ_check
    ; execute_op
    ; Σ_commit?
    ; update_R_pc
    ; Φ_check
```

Expanded:

```text id="e6qv7q"
s_cpu'
=
Φ_check(
  PC_update(
    Σ_commit(
      EXECUTE(
        Χ_check(
          □_bind(
            ΩΨ_validate(
              Δ_decode(
                Δ_fetch(
                  Θ_order(s_cpu)
                )
              )
            )
          )
        )
      )
    )
  )
)
```

This expression is schematic.

It states the architectural transition structure.

It is not a required implementation call stack.

A simulator, interpreter, symbolic engine, proof model, or JIT backend may implement the checks differently as long as the same architectural obligations are preserved.

For `ISO_EXIT`, `δ_CPU` must enforce:

```text id="s65k0l"
active_boundary_context(s_cpu) = true
```

Unbalanced exit must become typed failure under the declared profile:

```text id="vzr89h"
Χ violation
Φ trap
Ψ denial
Σ audit / rejection commit
halt
stuck
```

A sealed isolation context forbids:

```text id="ns529l"
entry
expansion
reachability growth
hidden visibility extension
```

but may permit:

```text id="q2i7mt"
valid exit
closure
rollback
audit
commit
```

### 12.6 Trace Mapping

Every PMS-CPU instruction produces or contributes to an operator trace.

For a decoded instruction:

```text id="juvmir"
Instr = (mnemonic, op, operands, constraints)
```

the primary operator contribution is:

```text id="zyfak3"
op
```

The full CPU cycle may also include architectural support operators:

```text id="qrcxm0"
Θ Δ Δ Ω Ψ □ Χ? op Σ? Φ?
```

Examples:

| Instruction | Primary trace contribution |
| ----------- | -------------------------- |
| `ADD`       | `∇`                        |
| `CMP`       | `Δ`                        |
| `TRAP`      | `Φ`                        |
| `SET_ROLE`  | `Ω`                        |
| `TX_COMMIT` | `Σ`                        |
| `ISO_ENTER` | `Χ`                        |
| `ISO_EXIT`  | `Χ`                        |
| `CHK_POL`   | `Ψ`                        |
| `FENCE`     | `Θ`                        |
| `WAIT`      | `Λ`                        |
| `PATTERN`   | `Α`                        |

A concrete PMS-CPU execution trace is valid when:

```text id="x0lmbm"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="u3obd4"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

For a declared machine, program, environment, and profile:

```text id="o2q5yh"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="kaz6tq"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

Trace metadata may include:

```text id="rlfggl"
cycle
R_pc
instruction word
operator family
mnemonic
frame
role
boundary domain
policy result
commit result
trap result
memory visibility result
boundary-exit result
sealed-isolation result
```

This trace mapping is the basis for:

```text id="i2gh07"
binary validation
simulator traces
golden fixtures
compiler-lowering checks
formal transition inspection
artifact evidence paths
```

Trace evidence supports bounded implementation-artifact claims.

It does not validate PMS Base.

### 12.7 Homomorphic Relation to PMS-UM

The PMS-UM to PMS-CPU mapping is domain-restricted:

```text id="jzyaq1"
h_UM→CPU : L_UM ⊆ L_PMS → ISA*
```

A valid PMS-UM operator word in the mapping domain becomes a sequence of PMS-CPU ISA instructions.

Example:

```text id="c7eioz"
Δ ∇ Θ Σ
```

may map to:

```asm id="xkjzmx"
CMP   R1, R2
ADD   R3, R4
FENCE
COMMIT_BARRIER
```

provided the operands, frame, role, boundary, ordering, commit, and policy constraints are valid.

Example with boundary exit:

```text id="x9ffb5"
Χ Σ
```

may map to:

```asm id="qbo0hf"
ISO_EXIT
COMMIT_BARRIER
```

only if an active boundary / isolation context exists and the declared profile requires or permits commit/audit/closure integration.

Validity preservation is:

```text id="w8l1hg"
w ∈ dom(h_UM→CPU) ∩ L_PMS
    ⇒ h_UM→CPU(w) is PMS-CPU ISA-valid
```

Policy preservation is:

```text id="irllk8"
w ∈ dom(h_UM→CPU) ∩ L_PMS,Ψ
    ⇒ h_UM→CPU(w) satisfies PMS-CPU policy constraints
```

This prevents overclaim.

It does not state that every valid PMS word has a direct CPU encoding.

PMS-CPU encodes the PMS-UM-executable subset.

### 12.8 Deterministic and Nondeterministic Instance Profiles

PMS-CPU may instantiate PMS-UM deterministically or nondeterministically.

Deterministic PMS-CPU profile:

```text id="ys4tjf"
∀κ_cpu:
    | { κ_cpu' | κ_cpu → κ_cpu' } | ≤ 1
```

Requires:

```text id="kczjfr"
deterministic fetch
deterministic decode
functional instruction semantics
deterministic policy result
deterministic boundary result
deterministic boundary-exit result
deterministic interrupt selection
closed or deterministic environment
```

Nondeterministic PMS-CPU profile:

```text id="rdbxme"
∃κ_cpu:
    | { κ_cpu' | κ_cpu → κ_cpu' } | > 1
```

Sources may include:

```text id="g2iz68"
interrupt arrival
scheduler choice
environment input
symbolic execution
policy alternatives
boundary alternatives
relaxed memory profiles
```

Both profiles remain PMS-CPU instances only if every concrete run satisfies:

```text id="j4ww82"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="f0km8x"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

and if all possible runs under the declared profile satisfy:

```text id="ko91ao"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="e2tdnj"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 12.9 PMS-UM Tuple Consistency

PMS-CPU must preserve the tuple structure of PMS-UM.

Correct tuple:

```text id="e8zlj9"
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

Correct CPU instance:

```text id="i62s1h"
M_CPU =
    (S_CPU, Γ_CPU, F_CPU, R_CPU, PSet_CPU, O,
     ISA, Π_CPU, δ_CPU, s₀_CPU, S_H_CPU)
```

The inclusion of:

```text id="zt5yy8"
Π
```

is required because programs are part of the abstract machine specification.

The inclusion of:

```text id="f2yuog"
Π_CPU
```

is required because PMS-CPU is not merely an instruction semantics table.

It is a virtual CPU machine over concrete instruction streams and binary images.

A PMS-CPU instance is not complete as an abstract machine relation without its program domain or instruction-stream domain.

This synchronizes PMS-CPU with `02_pms_um.md`.

### 12.10 PMS-CPU Instance Validity

A PMS-CPU instance is valid when:

```text id="k1v4ji"
valid_cpu_instance(M_CPU) iff
    S_CPU defines coherent CPU states
    ∧ Γ_CPU defines byte/word/register-value alphabet
    ∧ F_CPU defines valid CPU frames
    ∧ R_CPU defines valid role/capability states
    ∧ PSet_CPU defines active policy domains
    ∧ O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
    ∧ ISA defines operator-typed instruction schemata
    ∧ Π_CPU defines programs / binary images / instruction streams
    ∧ δ_CPU defines fetch–decode–execute transition
    ∧ s₀_CPU is coherent
    ∧ S_H_CPU defines halt/trap-halt/policy-halt states
    ∧ trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS for valid concrete runs
    ∧ Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS under declared profile
```

Under active policy, the policy-constrained validity condition is:

```text id="hfyn3d"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ

Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

This predicate is architectural helper notation.

A concrete artifact may implement it through:

```text id="qxei6z"
type definitions
validators
execution tests
trace schemas
golden fixtures
formal transition rules
```

Validation here means acceptance or rejection under a declared schema, model, profile, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 12.11 PMS-CPU Instance Invariants

```text id="mm9ppz"
CPU-UM1: PMS-CPU is a specialized PMS-UM instance

CPU-UM2: PMS-UM tuple includes Π, the program domain

CPU-UM3: PMS-CPU tuple includes Π_CPU, the CPU program / instruction-stream
         domain

CPU-UM4: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-UM5: PMS-CPU uses the same Δ–Ψ operator alphabet as PMS-UM

CPU-UM6: PMS-CPU state specializes PMS-UM state into register, memory,
         frame, role, capability, policy, boundary, trap, interrupt,
         commit, and ordering state

CPU-UM7: PMS-CPU instructions specialize PMS-UM instructions into virtual
         ISA instructions

CPU-UM8: PMS-CPU δ specializes PMS-UM stepping into fetch–decode–execute

CPU-UM9: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-UM10: Trace(...) denotes the set of possible PMS-CPU executions under a
          declared machine/program/profile

CPU-UM11: concrete PMS-CPU traces remain in L_PMS or L_PMS,Ψ

CPU-UM12: h_UM→CPU is domain-restricted

CPU-UM13: PMS Base Χ = Distance

CPU-UM14: PMS-CPU projects Χ as virtual CPU boundary, visibility,
          reachability, isolation-domain, access-separation, and
          boundary-exit discipline

CPU-UM15: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-UM16: ISO_EXIT requires an active boundary / isolation context

CPU-UM17: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-UM18: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-UM19: PMS-CPU as PMS-UM instance is a virtual CPU architecture claim,
          not fabricated hardware and not PMS Base validation
```

### 12.12 PMS-CPU Instance Claim

The PMS-CPU-as-PMS-UM claim is:

```text id="jv7glh"
PMS-CPU is a PMS-UM instance whose state space is virtual processor state,
whose program domain is virtual instruction streams or binary images, whose
instructions are PMS-operator-typed ISA instructions, and whose transition
relation is the fetch–decode–execute cycle constrained by frame, role,
boundary, ordering, commit, trap, interrupt, and policy rules.
```

This is a strong architecture claim.

It means PMS-CPU has a precise formal position inside PMS-STACK.

It does not mean PMS-CPU is fabricated hardware.

It does not mean a complete PMS-CPU simulator already exists.

It does not validate PMS Base.

### 12.13 Architectural Consequence

The architectural consequence is:

```text id="vc67ax"
PMS-CPU is not an analogy to PMS-UM.

It is the PMS-UM abstract-machine tuple instantiated as a virtual processor:
CPU state specializes PMS-UM state, ISA instructions specialize PMS-UM
instructions, Π_CPU specializes Π, and δ_CPU specializes δ through
fetch–decode–execute semantics.
```

This establishes PMS-CPU as the virtual CPU layer of PMS-STACK.

It also preserves the claim boundary:

```text id="mv6ezf"
PMS-CPU specifies a virtual CPU / ISA architecture.

It does not claim physical hardware fabrication.

It does not validate PMS Base.
```

### 12.14 Boundary Statement

The correct boundary for this chapter is:

```text id="ovgt1t"
PMS-CPU is a specialized PMS-UM instance. It instantiates the PMS-UM tuple
with virtual processor state, CPU frames, CPU roles/capabilities, CPU
policy sets, operator-typed ISA instructions, CPU program streams, and a
fetch–decode–execute transition relation.

This is a virtual CPU as PMS-UM-instance architecture claim.

PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction within
that virtual CPU instance; it requires active boundary / isolation context
and does not redefine PMS Base Χ.

This chapter does not claim fabricated hardware, does not imply a completed
simulator, does not redefine PMS Base, and does not validate PMS Base.
```

---

Zum Abschluss von Block 03 ist Kapitel 13 genau der richtige Ort für die **gebündelte Claim-Boundary**: Hier darf `chi_exit` nochmals explizit erscheinen, weil dieses Kapitel PMS-RUST, Artifact Evidence und den direkten PMS-CPU-Implementierungspfad zusammenführt. Ich habe zusätzlich `π_CPU ∈ Π_CPU`, `trace_cpu(...)`/`Trace(...)`, `ISO_EXIT`, sealed isolation, Evidence-Boundary und die finale starke Architekturformel synchronisiert. 

---

## 13. Implementation Boundary

PMS-CPU is a virtual CPU / ISA architecture specification.

It defines how PMS-UM execution is refined into a processor-shaped execution model with:

```text id="nykn95"
registers
memory
program counter
stack pointer
frame register
role and capability state
boundary state
trap handling
interrupt handling
commit semantics
policy checks
binary encoding
fetch–decode–execute cycle
memory consistency
PMS-UM instance mapping
```

The implementation boundary is precise:

```text id="i2677s"
PMS-CPU specifies a virtual processor architecture.

It does not claim fabricated hardware.
```

The PMS-CPU program domain is:

```text id="z816bm"
Π_CPU
```

A concrete PMS-CPU program, instruction stream, or binary image is:

```text id="fjh4aa"
π_CPU ∈ Π_CPU
```

The central final claim is:

```text id="wxinlu"
PMS-CPU is a complete virtual CPU / ISA architecture specification derived
as a PMS-UM specialization over the Δ–Ψ operator grammar.
```

Claim type:

```text id="pux98t"
implementation-layer virtual CPU / ISA architecture claim
```

Boundary:

```text id="x8s0v1"
This strengthens the PMS-STACK implementation-layer architecture claim.

It does not claim fabricated hardware.

It does not imply that a complete PMS-CPU simulator already exists.

It does not function as PMS Base validation.
```

A concrete PMS-CPU execution records:

```text id="w7j20w"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS
```

and, under active policy:

```text id="e8sup3"
trace_cpu(M_CPU, π_CPU, s₀_CPU) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="i9e458"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS
```

and, under active policy:

```text id="zs9wks"
Trace(M_CPU, π_CPU, s₀_CPU) ⊆ L_PMS,Ψ
```

### 13.1 What PMS-CPU Specifies

PMS-CPU specifies the following.

First, it specifies a virtual CPU state model:

```text id="ia7wn0"
s_cpu =
    (RF, MEM, R_pc, R_sp, R_fp, R_fr,
     R_role, R_cap, R_flag, R_iso, P, m)
```

Second, it specifies operator-typed instruction families:

```text id="bzk3z5"
Instr = (mnemonic, op ∈ O, operands, constraints)
```

where:

```text id="cvi5xz"
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

Third, it specifies a reference ISA organized by PMS operator family:

```text id="bqx7th"
Δ
    compare / branch / distinction

∇
    ALU / load / store / call / return

□
    frame operations

Λ
    wait / poll / absence

Α
    pattern expansion

Ω
    role / capability / privilege

Θ
    ordering / fence / yield

Φ
    trap / interrupt / exception

Χ
    Distance projection / boundary / boundary exit

Σ
    commit / transaction / atomicity

Ψ
    policy / invariant
```

Fourth, it specifies a binary encoding with explicit operator tags:

```text id="t0lt52"
PMS_OP → OPCODE → operands → operator-typed instruction
```

Fifth, it specifies a fetch–decode–execute cycle:

```text id="uvwdm8"
Θ
→ Δ_fetch
→ Δ_decode
→ Ω/Ψ validation
→ □ binding
→ Χ boundary check
→ operator execution
→ Σ commit where required
→ R_pc update
→ Φ interrupt/trap check
```

Sixth, it specifies a trap and interrupt model:

```text id="nhuobu"
interrupt
trap
syscall
fault
timeout
policy denial
boundary violation
unbalanced boundary exit
handler entry
handler return
```

as operator-typed event transitions.

Seventh, it specifies a memory consistency model in terms of:

```text id="ccfjp0"
Δ distinction
∇ mutation
□ frame binding
Ω authority
Θ ordering
Χ visibility domain / boundary / boundary exit
Σ commit
Ψ policy
```

Eighth, it specifies its own formal relationship to PMS-UM:

```text id="rd1wk3"
M_CPU =
    (S_CPU, Γ_CPU, F_CPU, R_CPU, PSet_CPU, O,
     ISA, Π_CPU, δ_CPU, s₀_CPU, S_H_CPU)
```

These are architectural specifications.

They are sufficiently concrete to support:

```text id="zg764v"
simulator
emulator
trace validator
compiler target
formal model
symbolic engine
binary decoder
golden fixtures
runtime instrumentation
future hardware design input
```

### 13.2 What PMS-CPU Does Not Specify

PMS-CPU does not specify fabricated hardware.

It does not specify:

```text id="c2nn12"
transistor layout
physical pipeline implementation
cache-coherence circuitry
silicon timing
microarchitectural hazards
branch-predictor design
hardware verification collateral
manufacturing process
physical interrupt controller design
actual MMU circuitry
actual device bus protocol
physical memory controller
physical reorder buffer
physical cache hierarchy
```

PMS-CPU may describe virtual structures that resemble hardware concepts:

```text id="g4cl3l"
MMU-like boundary
ASID-like isolation domain
interrupt-like event
trap-like recontextualization
register-like state
memory-like map
frame table
policy register
commit barrier
boundary-exit instruction
```

These are virtual architecture constructs unless a later implementation explicitly realizes them in hardware.

Correct:

```text id="eyucai"
PMS-CPU is a virtual CPU / ISA specification.
```

Incorrect:

```text id="vgcvpa"
PMS-CPU is already fabricated hardware.
```

### 13.3 Implementation Targets

PMS-CPU can be implemented at several levels.

#### Interpreter

The simplest implementation is an interpreter.

```text id="fipw80"
decode instruction
check frame / role / boundary / policy
execute operator semantics
update state
emit trace
```

This is the most direct implementation route for the PMS-CPU architectural model.

#### Emulator

An emulator may execute PMS-CPU binary encodings.

```text id="fd4en9"
32-bit instruction word
→ PMS_OP
→ OPCODE
→ operands
→ virtual CPU transition
```

This makes the binary encoding executable.

#### Trace validator

A trace validator may check whether an observed PMS-CPU trace satisfies:

```text id="r0zm1n"
operator dependency
frame validity
role validity
boundary validity
ordering validity
commit validity
policy validity
memory-order validity
trap validity
boundary-exit validity
sealed-isolation validity
```

This does not require executing a full simulator.

It checks whether a produced trace is architecturally valid under a declared profile.

#### Compiler target

PMSL/PMS-IR may target PMS-CPU by lowering language constructs into ISA families.

Example:

```text id="aqkj2l"
PMSL type distinction
    → Δ-family

PMSL effect
    → ∇-family

PMSL scope/module
    → □-family

PMSL absence/timeout
    → Λ-family

PMSL pattern/macro
    → Α-family

PMSL role annotation
    → Ω-family

PMSL ordering/fence
    → Θ-family

PMSL exception
    → Φ-family

PMSL isolation construct
    → Χ-family

PMSL commit block
    → Σ-family

PMSL policy block
    → Ψ-family
```

A compiler-target claim requires artifact evidence when stated as implementation.

#### JIT or VM Backend

A PMS-CPU implementation may operate as a VM backend, translating PMS-CPU instruction sequences into host-machine code while preserving architectural Δ–Ψ trace semantics.

A JIT backend is valid only if it preserves:

```text id="ozx3cu"
operator identity
dependency validity
frame discipline
role/capability discipline
boundary discipline
ordering discipline
commit discipline
policy constraints
trace recoverability at declared observation points
```

#### Formal Model

PMS-CPU may also be implemented as a formal transition system for:

```text id="jxi0w0"
model checking
symbolic execution
proof-oriented tooling
state-space exploration
memory-model analysis
trap/interrupt validation
boundary-exit validation
```

Formal modeling strengthens verification claims only under stated model, assumptions, properties, and proof method.

The common requirement across all targets is:

```text id="fbuu6x"
implementation strategy may vary;
operator identity, dependency validity, frame/role/boundary/policy checks,
ordering discipline, commit semantics, typed failure, and trace recoverability
must be preserved.
```

### 13.4 Minimal Executable Slice

A minimal executable PMS-CPU slice requires only a subset of the full architecture.

Minimum viable slice:

```text id="owlb2h"
register file
memory map
program counter
basic flags
frame table
role state
policy state
operator-tagged instruction representation
fetch/decode
core Δ / ∇ / □ / Ω / Φ / Χ / Σ / Ψ instructions
trace emission
validation checks
halt behavior
```

A first simulator does not need to implement every ISA instruction.

A minimal slice may begin with:

```asm id="w2y8zl"
CMP
BEQ
MOV
LOAD
STORE
ADD
FRM_ENTER
FRM_LEAVE
CHK_CAP
TRAP
EXC_RET
ISO_ENTER
ISO_EXIT
TX_BEGIN
TX_COMMIT
CHK_POL
HALT_IF_POL
```

This is enough to demonstrate:

```text id="r0h2wp"
distinction and branching
register and memory mutation
frame-aware addressing
role/capability checks
trap entry and return
boundary-sensitive access
active-context boundary exit
commit discipline
policy denial
operator-labeled trace generation
```

The `ISO_EXIT` rule is part of the minimal boundary discipline:

```text id="ms99xc"
ISO_EXIT requires active boundary / isolation context.

Unbalanced ISO_EXIT is invalid.

Sealed isolation forbids entry, expansion, and reachability growth while
permitting valid exit, closure, rollback, audit, or commit under declared
profile.
```

This minimal slice strengthens implementation-path claims.

It does not complete PMS-CPU.

### 13.5 Evidence Boundary

An implementation of PMS-CPU may produce evidence.

Examples:

```text id="sc65qp"
passing simulator tests
golden traces
ISA validation fixtures
binary decode tests
trap/interrupt tests
memory-model tests
policy-denial tests
boundary-exit tests
sealed-isolation tests
compiler-lowering tests
trace replay tests
formal transition checks
symbolic execution results
```

These strengthen implementation-artifact claims.

They do not validate PMS Base.

The correct claim form is:

```text id="uaj9z7"
A PMS-CPU simulator or emulator can provide artifact evidence that the
virtual CPU architecture is executable and testable.
```

Boundary:

```text id="koulam"
This strengthens the PMS-CPU implementation-artifact claim.

It does not function as PMS Base validation.
```

Trace evidence is bounded:

```text id="lr2w3a"
a trace records an observed execution under a declared profile
```

not:

```text id="czpqgx"
a trace proves all behavior
```

Test evidence is bounded:

```text id="szdet4"
a test checks a declared property under a declared fixture
```

not:

```text id="im0817"
a test proves PMS Base
```

Validator evidence is bounded:

```text id="xkx5eo"
a validator accepts or rejects under a declared schema, profile, fixture,
gate, or conformance rule
```

not:

```text id="c32bch"
a validator externally validates PMS Base
```

### 13.6 Relation to PMS-RUST

PMS-RUST is relevant to PMS-CPU as an executable evidence spine for PMS-STACK, not as a completed PMS-CPU implementation.

PMS-RUST strengthens the PMS-STACK implementation-artifact claim by showing that Δ–Ψ operator programs can be:

```text id="s10i67"
represented
executed
validated
traced
tested
surfaced through developer tooling
```

For PMS-CPU specifically, PMS-RUST is evidence for the lower implementation discipline:

```text id="vgdf76"
operator representation
operator-typed program construction
deterministic stepping
stateful validation
event emission
golden trace discipline
frame / isolation / commit / policy test surfaces
REPL / script-driven execution
```

This supports the plausibility and implementation path of PMS-CPU.

It does not yet equal a PMS-CPU simulator.

A completed PMS-CPU implementation would additionally require:

```text id="suj81z"
CpuState
RegisterFile
MEM : Address → Byte
R_pc / R_sp / R_fp / R_fr / R_role / R_cap / R_flag / R_iso
PMS-CPU Instruction enum
CMP / ADD / LOAD / STORE / TRAP / EXC_RET / FENCE / TX_COMMIT / ...
ISO_ENTER / ISO_EXIT
32-bit binary decoder
fetch–decode–execute loop
CPU-level trap frames
CPU-level memory consistency profiles
CPU-level ISA golden tests
CPU-level trace schema
```

The boundary-exit mapping is:

```text id="my4zma"
PMS-CPU ISO_EXIT
    = virtual CPU architecture-level boundary-exit instruction

PMS-RUST chi_exit
    = runtime / DSL / validator command evidencing bounded boundary-exit
      behavior under the PMS-RUST v0.1 profile

PMS Base Χ
    = Distance
```

Shared rule:

```text id="rahfd3"
exit requires an active isolation / boundary context

exit without active isolation / boundary context is rejected
```

Boundary:

```text id="lul3vg"
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.

PMS-RUST chi_exit does not redefine PMS Base Χ.

PMS-RUST chi_exit does not validate PMS Base.
```

The correct relationship is:

```text id="hno2ad"
PMS-STACK
    = implementation-layer architecture specification

PMS-UM
    = abstract machine model

PMS-CPU
    = virtual CPU / ISA architecture

PMS-RUST
    = bounded executable PMS-STACK evidence spine

future pms-cpu
    = direct PMS-CPU simulator / emulator artifact
```

Thus PMS-RUST strengthens the PMS-CPU implementation path by already realizing the operator-kernel, validation, tracing, tooling discipline, and bounded boundary-exit discipline on which a PMS-CPU simulator can be built.

Boundary:

```text id="md25e5"
This strengthens the PMS-STACK and PMS-CPU implementation-artifact path.

It does not imply that a complete PMS-CPU simulator already exists.

It does not function as PMS Base validation.
```

### 13.7 Implementation Roadmap

A direct PMS-CPU implementation can proceed in stages.

#### Stage 1 — Structural Simulator

Implement:

```text id="tu8sc7"
CPU state
instruction enum
operator tag
step function
trace emission
basic Δ / ∇ instructions
halt behavior
```

Claim strengthened:

```text id="yiwjwn"
basic virtual CPU execution path
```

Boundary:

```text id="yfdvjj"
not full PMS-CPU
```

#### Stage 2 — Frame, Role, and Policy Checks

Add:

```text id="fhva0y"
frame table
R_fr
R_role
R_cap
P
CHK_CAP
CHK_POL
FRM_ENTER / FRM_LEAVE
policy-denial paths
```

Claim strengthened:

```text id="n7odlj"
operator-visible frame, role, and policy discipline
```

Boundary:

```text id="c6zmqw"
not full OS, not full security certification
```

#### Stage 3 — Trap and Recontextualization Model

Add:

```text id="g61f2w"
TRAP
EXC_RAISE
EXC_RET
trap frames
handler table
role/frame switch on Φ
nested trap checks
```

Claim strengthened:

```text id="p4cyd7"
virtual interrupt/trap architecture
```

Boundary:

```text id="fzx4v2"
not physical interrupt hardware
```

#### Stage 4 — Boundary and Commit Discipline

Add:

```text id="zs9tkh"
R_iso
ISO_ENTER / ISO_EXIT
boundary checks
active-boundary validation
unbalanced-exit rejection
sealed-isolation state
TX_BEGIN / TX_COMMIT / TX_ABORT
COMMIT_BARRIER
commit validation
```

Claim strengthened:

```text id="fx9ek8"
Χ-projected boundary discipline and Σ commit discipline
```

Boundary:

```text id="bas5m5"
PMS Base Χ remains Distance; implementation does not validate PMS Base
```

PMS-RUST `chi_exit` may evidence bounded runtime boundary-exit discipline for this stage.

It does not complete PMS-CPU `ISO_EXIT`.

#### Stage 5 — Binary Decoder

Add:

```text id="npygs9"
32-bit instruction words
PMS_OP tag decoding
OPCODE decoding
R/I/B/S formats
invalid encoding traps
binary fixture tests
```

Claim strengthened:

```text id="sutlbi"
executable binary-encoding profile
```

Boundary:

```text id="a4nhwe"
virtual encoding, not fabricated hardware encoding
```

#### Stage 6 — Memory Consistency Profiles

Add:

```text id="tdlmc4"
PMS-SC
store buffering
Θ fences
Σ visibility points
transactional memory profile
weak-model profiles
memory trace tests
boundary-exit visibility tests
```

Claim strengthened:

```text id="ax2sy2"
virtual CPU memory-model artifact
```

Boundary:

```text id="ynmdgh"
not physical cache-coherence hardware
```

#### Stage 7 — Compiler / PMS-IR Interface

Add:

```text id="t0zaa1"
PMS-IR lowering to PMS-CPU ISA
trace equivalence tests
homomorphic validity checks
golden fixtures
profile declarations
```

Claim strengthened:

```text id="nlqbr5"
PMSL / PMS-IR to PMS-CPU implementation path
```

Boundary:

```text id="d3exwo"
not complete PMSL compiler unless artifact evidence establishes it
```

This roadmap is implementation-oriented.

It does not expand the architecture claim beyond its boundary.

### 13.8 Claim Boundary Table

| Statement                                                    | Claim type                                   | Boundary                                                      |
| ------------------------------------------------------------ | -------------------------------------------- | ------------------------------------------------------------- |
| PMS-CPU is a complete virtual CPU / ISA architecture         | architecture claim                           | not fabricated hardware                                       |
| PMS-CPU specializes PMS-UM                                   | formal architecture claim                    | not PMS Base validation                                       |
| PMS-CPU defines registers and memory                         | virtual state-model claim                    | not physical register file / cache                            |
| PMS-CPU defines ISA families                                 | ISA specification claim                      | not completed simulator                                       |
| PMS-CPU defines binary encoding                              | virtual encoding claim                       | not silicon encoding                                          |
| PMS-CPU defines FDE cycle                                    | execution semantics claim                    | not physical pipeline                                         |
| PMS-CPU defines traps and interrupts                         | virtual event-model claim                    | not physical interrupt controller                             |
| PMS-CPU defines commit / policy rules                        | virtual commit/policy claim                  | not physical writeback hardware                               |
| PMS-CPU defines memory consistency                           | virtual memory-model claim                   | not cache-coherence hardware                                  |
| PMS-CPU defines ISO_EXIT                                     | virtual CPU boundary-exit architecture claim | requires active boundary context; not PMS Base Χ redefinition |
| PMS-CPU can be implemented                                   | implementation-path claim                    | artifact required for implementation status                   |
| PMS-RUST supports the path                                   | bounded artifact-evidence claim              | not completed PMS-CPU and not PMS Base validation             |
| PMS-RUST chi_exit evidences bounded boundary-exit discipline | runtime artifact-evidence claim              | not PMS-CPU ISO_EXIT completion                               |

### 13.9 Safe Wording

Preferred:

```text id="de5lqu"
PMS-CPU specifies a virtual CPU / ISA architecture.
```

Preferred:

```text id="p0fldd"
PMS-CPU derives virtual processor state, instruction families, execution
cycle, traps, commits, policies, boundary exits, and memory consistency from
Δ–Ψ.
```

Preferred:

```text id="wv4s6y"
This strengthens the PMS-STACK implementation-layer architecture claim.
```

Preferred:

```text id="zhs3zw"
It does not claim fabricated hardware.
```

Preferred:

```text id="gcydy0"
It does not imply that a complete PMS-CPU simulator already exists.
```

Preferred:

```text id="jvjpbb"
It does not function as PMS Base validation.
```

Avoid:

```text id="lidvpu"
PMS-CPU is hardware.
```

Avoid:

```text id="myjp1t"
PMS-CPU proves PMS.
```

Avoid:

```text id="ozf2hf"
PMS-RUST completes PMS-CPU.
```

Avoid:

```text id="gzsw1u"
Tests validate PMS Base.
```

Avoid:

```text id="bhhj3n"
Χ means isolation in PMS Base.
```

Correct Χ wording:

```text id="s8a2gq"
PMS Base 1.3 Χ = Distance.

PMS-CPU projects Χ as virtual CPU boundary, reachability,
protection-domain, isolation-domain, access-separation, and boundary-exit
discipline.
```

Correct `ISO_EXIT` wording:

```text id="t2pqz5"
PMS-CPU ISO_EXIT is an architecture-level boundary-exit instruction.

It requires active boundary / isolation context.

Unbalanced ISO_EXIT is invalid.
```

Correct `chi_exit` wording:

```text id="fnq3mu"
PMS-RUST chi_exit is an artifact/runtime boundary-exit command.

It may evidence bounded runtime boundary-exit discipline.

It does not complete PMS-CPU ISO_EXIT and does not validate PMS Base.
```

### 13.10 Implementation Boundary Invariants

```text id="fru49l"
CPU-IB1: PMS-CPU is a virtual CPU / ISA architecture specification

CPU-IB2: PMS-CPU is a PMS-UM specialization

CPU-IB3: PMS-CPU tuple includes Π_CPU as program / instruction-stream domain

CPU-IB4: π_CPU ∈ Π_CPU denotes one concrete PMS-CPU instruction stream,
         program image, or binary image

CPU-IB5: PMS-CPU does not claim fabricated hardware

CPU-IB6: PMS-CPU does not imply a completed simulator

CPU-IB7: PMS-CPU defines state, ISA, binary encoding, FDE cycle, traps,
         commits, policy checks, boundary exits, and memory consistency at
         the virtual architecture level

CPU-IB8: trace_cpu(...) denotes one concrete PMS-CPU execution

CPU-IB9: Trace(...) denotes the set of possible PMS-CPU executions under a
         declared machine/program/profile

CPU-IB10: implementation artifacts may strengthen bounded implementation
          claims

CPU-IB11: tests, traces, fixtures, simulators, and validators do not validate
          PMS Base

CPU-IB12: PMS-RUST strengthens the PMS-STACK evidence spine but does not
          complete PMS-CPU

CPU-IB13: PMS-RUST chi_exit may evidence bounded runtime boundary-exit
          discipline but does not complete PMS-CPU ISO_EXIT

CPU-IB14: future pms-cpu would be the direct PMS-CPU simulator/emulator
          artifact

CPU-IB15: PMS Base Χ = Distance

CPU-IB16: PMS-CPU projects Χ as virtual CPU boundary, reachability,
          protection-domain, isolation-domain, access-separation, and
          boundary-exit discipline

CPU-IB17: ISO_EXIT is the PMS-CPU architecture-level boundary-exit
          instruction

CPU-IB18: ISO_EXIT requires an active boundary / isolation context

CPU-IB19: unbalanced ISO_EXIT is invalid and must produce typed CPU behavior

CPU-IB20: sealed isolation forbids entry, expansion, and reachability growth
          while permitting valid exit, closure, rollback, audit, or commit
          under declared profile

CPU-IB21: boundary discipline preserves strong architecture claims by typing
          them correctly
```

### 13.11 Final Boundary Statement

PMS-CPU is the virtual processor layer of PMS-STACK.

It defines:

```text id="ar20fq"
CPU state
register model
memory model
frame model
role/capability model
boundary projection
policy model
operator-typed ISA
binary encoding
fetch–decode–execute cycle
trap and interrupt semantics
commit phase
memory consistency model
PMS-UM instance mapping
```

The correct final claim is:

```text id="yaqkeg"
PMS-CPU is a complete virtual CPU / ISA architecture specification derived
as a PMS-UM specialization over the Δ–Ψ operator grammar.
```

Boundary:

```text id="tdlw7w"
This is an implementation-layer virtual CPU / ISA architecture claim.

It strengthens the PMS-STACK architecture claim.

It does not claim fabricated hardware.

It does not imply that a complete PMS-CPU simulator already exists.

It does not function as PMS Base validation.
```

### 13.12 Closing Claim

The closing PMS-CPU claim is:

```text id="itss3c"
PMS-CPU makes PMS-UM processor-shaped.

It specifies how Δ–Ψ execution becomes a virtual CPU: with registers,
memory, instruction families, binary encoding, calling conventions, traps,
interrupts, commits, policies, boundary exits, memory consistency, and a
formal PMS-UM instance relation.
```

This strengthens the PMS-STACK implementation-layer architecture.

It does not validate PMS Base.

It does not claim fabricated hardware.

It does not complete PMS-CPU as an implementation artifact.

It defines the virtual CPU architecture that a future direct PMS-CPU simulator, emulator, compiler target, trace validator, or formal model can implement and evidence.
