---
document_id: PMS-STACK-DOC-09
title: "Non-Goals and Claim Boundary"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "claim-boundary / non-goal / release-discipline specification"
pms_base_status: "source of Δ–Ψ operator identity and PMS 1.3 Χ = Distance"
stack_status: "implementation-layer architecture specification; strong claim typed by boundary"
pms_rust_status: "bounded executable PMS-STACK Evidence Spine v0.1; artifact evidence, not PMS Base validation"
chi_status: "PMS Base 1.3 Χ = Distance; PMS-STACK projects Χ at implementation layers; PMS-RUST chi_exit evidences bounded runtime boundary-exit discipline and does not redefine Base Χ"
depends_on:
  - "00_overview.md"
  - "01_architecture.md"
  - "02_pms_um.md"
  - "03_pms_cpu.md"
  - "04_pms_os.md"
  - "05_pmsl_pms_ir.md"
  - "06_runtime_security.md"
  - "07_distributed_systems.md"
  - "08_relation_to_pms_rust.md"
---

# Non-Goals and Claim Boundary

## 1. Purpose of This Boundary Document

This document defines the claim discipline of PMS-STACK.

PMS-STACK is an ambitious architecture specification. It is designed to specify a complete operator-grounded computing stack from Δ–Ψ:

```text
PMS-UM
PMS-CPU
PMS-OS
memory
storage
IPC
drivers
networking
security
governance
PMSL / PMS-IR
runtime
verification
simulation
boot
distributed systems
cluster extensions
```

This document does not weaken that claim.

It types it.

The governing rule is:

```text
strong claim → claim type → boundary
```

PMS-STACK may make strong claims when they are correctly typed.

It may claim:

```text
architecture completeness
operator-grounded specification
formal expressiveness
computational universality of PMS-UM
cross-layer semantic uniformity
extensibility discipline
security/governance architecture
distributed-systems architecture
classical-framework expressibility
```

It may not silently convert those claims into:

```text
completed implementation
PMS Base validation
external validation
full formal proof
production OS status
hardware silicon status
complete language compiler status
complete distributed runtime status
clinical, psychological, moral, legal, or social authority
```

This document exists to keep PMS-STACK scientifically serious without making it timid.

### 1.1 Boundary Function

The function of this document is to state:

```text
what PMS-STACK claims
what kind of claim each statement is
what PMS-STACK does not claim
what remains unimplemented
what remains unproven
what PMS-RUST evidence may strengthen
what PMS-RUST evidence does not establish
how to write about PMS-STACK safely and strongly
```

The purpose is not defensive minimalism.

The purpose is precision.

PMS-STACK is strongest when its claims are not blurred across layers.

### 1.2 Layer Discipline

This document distinguishes the following layers:

```text
PMS Base
    source of operator identity and PMS 1.3 theory grammar

PMS-STACK
    implementation-layer architecture specification

PMS-RUST
    bounded executable PMS-STACK Evidence Spine / implementation artifact

PMSL / PMS-IR
    language and intermediate-representation architecture

PMS-CPU
    virtual CPU / ISA architecture

PMS-OS
    operating-system architecture

runtime security
    security/governance implementation discipline

distributed PMS-STACK
    optional networked / clustered / federated architecture profiles

tests / traces / fixtures
    artifact evidence

formal proof
    separate proof claim under explicitly stated model

external validation
    independent validation under external protocol

AI / tooling
    proposal, analysis, drafting, and inspection support under host-side
    validation
```

No lower layer automatically validates a higher or more basic layer.

The relation is:

```text
PMS Base defines operator identity.
PMS-STACK projects operator identity into systems architecture.
PMS-RUST implements bounded slices.
Tests and traces inspect bounded executions.
Formal proofs prove specified properties under models.
External validation validates under external protocol.
AI proposes; host validates; runtime/kernel executes accepted artifacts.
```

### 1.3 Claim-Type Table

| Claim type | Meaning | Example | Boundary |
| ---------- | ------- | ------- | -------- |
| Base/theory claim | PMS Base operator identity or theory grammar | `Χ = Distance` in PMS 1.3 | not changed by runtime dialect |
| Architecture claim | specification of a system layer | PMS-STACK defines PMS-CPU architecture | not implemented merely by specification |
| Formal claim | property stated under a formal model | PMS-UM is Turing-complete via embedding sketch | proof scope must be named |
| Implementation claim | code implements a bounded slice | PMS-RUST executes bounded opcode programs | not full STACK completion |
| Artifact claim | evidence exists as tests/traces/fixtures | JSONL traces show one run profile | not proof of all behavior |
| Verification claim | property checked under model/profile | validator rejects invalid adjacency | not external validation |
| Security claim | runtime/security invariant or scenario | unauthorized role escalation is denied | not universal deployment security |
| Distributed claim | cluster/network profile behavior | Σᴳ commit under Ψᴳ quorum | not algorithm proof by itself |
| Roadmap claim | planned future artifact | PMS-CPU simulator planned | not implemented evidence |
| AI/tooling claim | host-mediated proposal or analysis support | AI suggests an opcode program | not compiler authority or verification evidence |

### 1.4 Positive Boundary Form

Use positive boundaries.

Preferred:

```text
This strengthens the PMS-STACK architecture claim.
It does not function as PMS Base validation.
```

Preferred:

```text
This is an implementation-layer architecture claim.
It specifies the target structure; it does not assert that every target
layer has already been implemented.
```

Preferred:

```text
This executable artifact strengthens implementation-artifact evidence for
a bounded runtime slice.
It does not complete PMS-STACK.
```

Avoid boundary-as-apology.

Do not write:

```text
PMS-STACK is merely speculative.
PMS-RUST is only a toy.
Nothing is proven.
Maybe it could be useful.
```

Write:

```text
PMS-STACK is a complete implementation-layer architecture specification.

PMS-RUST is a bounded executable evidence spine for selected STACK
structures.

The architecture claim is strong.
The implementation claim is bounded.
The PMS Base validation claim is not made.
```

### 1.5 Why Claim Boundaries Matter

PMS-STACK crosses many domains that are usually separated:

```text
formal computation
CPU architecture
operating systems
programming languages
security
networking
distributed systems
verification
governance
simulation
runtime tooling
AI/tooling
```

Because the architecture is broad, claim drift is easy.

Examples of drift:

```text
architecture completeness
    misread as implemented completeness

Turing-completeness sketch
    misread as full formal proof of all system properties

security scenarios
    misread as universal security certification

cluster extension architecture
    misread as completed distributed runtime

PMS-RUST traces
    misread as PMS Base validation

classical-framework expressibility
    misread as equivalence to every concrete classical implementation

AI-generated candidate programs
    misread as compiler output, verification evidence, or trusted execution
```

This document prevents that drift.

### 1.6 Strong Claim Discipline

Claim discipline does not forbid strength.

It forbids untyped strength.

Correct strong statement:

```text
PMS-STACK is the implementation-layer architecture specification of PMS:
a complete systems architecture deriving CPU, OS, runtime, language,
security, networking, distributed systems, tooling, simulation, and boot
from Δ–Ψ.
```

Claim type:

```text
architecture/specification claim
```

Boundary:

```text
does not assert that every layer is implemented;
does not validate PMS Base;
does not replace formal proof or external validation.
```

Correct strong statement:

```text
PMS-UM is claimed as computationally universal at the abstract-machine
architecture layer through constructive and reduction-based expressiveness
routes specified by PMS-STACK.
```

Claim type:

```text
computational expressiveness / formal sketch claim
```

Boundary:

```text
does not prove every PMS-STACK subsystem correct;
does not validate PMS Base as a theory of praxis.
```

Correct strong statement:

```text
PMS-STACK security is not bolted on; it is specified as operator ordering,
role, boundary, policy, trap, absence, commit, and audit structure.
```

Claim type:

```text
security architecture claim
```

Boundary:

```text
does not certify every implementation or deployment as secure.
```

### 1.7 Scope of This Document

This document covers:

```text
architectural claims
formal claims
computational expressiveness claims
OS and CPU specification claims
PMSL and runtime claims
security and governance claims
distributed systems claims
non-goals
implementation boundaries
proof boundaries
classical-framework relations
safe wording rules
```

It does not re-specify every PMS-STACK subsystem.

It defines how to speak about them.

### 1.8 Core Boundary Formula

The core formula is:

```text
PMS-STACK specifies.
Artifacts evidence.
Tests inspect.
Traces record.
Validators accept or reject under declared profiles.
Formal proofs prove stated properties under models.
External validation validates under external protocols.
PMS Base remains the source of operator identity.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
```

No element in this chain may silently become another.

Global trace notation:

```text
trace(artifact, profile, input) ∈ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible executions under a declared profile is:

```text
Trace(artifact, profile) ⊆ L_PMS
```

Under active policy:

```text
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Boundary:

```text
A recorded trace usually evidences one concrete trace(...).

It does not by itself enumerate or prove the whole Trace(...) set.
```

### 1.9 Purpose Summary

The purpose of `09_non_goals_and_claim_boundary.md` is therefore:

```text
to preserve the full ambition of PMS-STACK while making every claim
scientifically typed, layer-aware, implementation-aware, proof-aware,
trace-aware, and artifact-aware.
```

This is the document that lets the architecture be stated strongly without being overstated.

---

## 2. Architectural Claims

PMS-STACK’s primary claim is architectural.

It specifies a complete systems architecture grounded in Δ–Ψ.

The central architectural claim is:

```text
PMS-STACK is the implementation-layer architecture specification of PMS:
a complete operator-grounded systems architecture deriving abstract
machine, virtual CPU, operating system, memory, storage, IPC, drivers,
runtime, language, security, networking, distributed systems, simulation,
verification, boot, and cluster profiles from Δ–Ψ.
```

This claim is strong.

Its claim type is:

```text
implementation-layer architecture specification
```

Its boundary is:

```text
it does not assert completed implementation of every layer;
it does not validate PMS Base;
it does not prove every layer correct;
it does not certify all deployments.
```

### 2.1 Architecture Specification, Not Finished Product Claim

PMS-STACK specifies the architecture of:

```text
PMS-UM
PMS-CPU
PMS-OS
PMSL / PMS-IR
runtime security
network stack
distributed systems
simulation
verification
boot
cluster extensions
```

It does not claim that every specified layer already exists as production implementation.

Correct:

```text
PMS-STACK defines PMS-OS as an operating-system architecture.
```

Incorrect:

```text
PMS-STACK is already a finished production operating system.
```

Correct:

```text
PMS-STACK defines PMS-CPU as a virtual CPU / ISA architecture.
```

Incorrect:

```text
PMS-STACK is already a fabricated hardware CPU.
```

Correct:

```text
PMS-STACK defines PMSL/PMS-IR as the language/runtime path.
```

Incorrect:

```text
PMSL is already a complete compiler toolchain unless artifact evidence
shows it.
```

### 2.2 Complete Architecture vs Completed Implementation

PMS-STACK can be architecturally complete without being fully implemented.

Architectural completeness means:

```text
the specification supplies operator-grounded structures for the full
systems stack.
```

Completed implementation would mean:

```text
the specified structures have corresponding executable artifacts,
tests, traces, fixtures, validators, documentation, and acceptance gates
under declared runtime profiles.
```

These are different claim types.

Correct:

```text
PMS-STACK is architecturally complete at the specification layer.
```

Boundary:

```text
implementation remains artifact-specific and profile-dependent.
```

### 2.3 Universal Systems Architecture

PMS-STACK claims that major IT constructs reduce to controlled compositions of the operator grammar.

```text
CPU instruction
syscall
trap
message
filesystem operation
IPC operation
network exchange
security policy decision
commit
rollback
distributed proposal
cluster boot transition
```

can be represented as operator sequences over:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

Claim type:

```text
architecture / operational-semantics claim
```

Boundary:

```text
does not imply every concrete IT implementation is already mapped,
verified, or equivalent in all details.
```

At PMS Base level:

```text
Χ = Distance
```

At PMS-STACK implementation layers, Χ may project as:

```text
boundary
isolation
reachability control
access separation
namespace visibility
sandboxing
containment
quarantine
```

This projection does not redefine PMS Base Χ.

### 2.4 Cross-Layer Architecture

PMS-STACK claims cross-layer uniformity.

The same operator grammar structures:

```text
abstract machine
CPU/ISA
OS kernel
language/runtime
network
security
distributed systems
verification
```

Examples:

```text
□ as abstract frame, memory domain, process frame, language frame,
network session, cluster frame

Ω as abstract role relation, privilege/capability register, OS role,
runtime capability, node role

Σ as integration, writeback, transaction commit, trace commit,
distributed commit

Ψ as invariant, guard, policy, security constraint, global cluster policy
```

Claim type:

```text
cross-layer architecture claim
```

Boundary:

```text
a mapping table does not implement all mapped layers.
```

### 2.5 Architecture of PMS-UM

PMS-STACK claims that PMS-UM is the abstract computational core.

It specifies:

```text
state
operator pointer
frame stack / frame configuration
role state
policy state
meta-state
ordering
absence
recontextualization
boundary
commit
```

Claim type:

```text
abstract-machine architecture claim
```

Boundary:

```text
an abstract-machine specification is not automatically a full simulator
or runtime implementation.
```

### 2.6 Architecture of PMS-CPU

PMS-STACK claims a virtual CPU / ISA architecture.

It specifies how CPU-like mechanisms correspond to operators:

```text
fetch/decode        → Δ
execution           → ∇
frame/memory domain → □
privilege           → Ω
trap/interrupt      → Φ
ordering/tick       → Θ
boundary/isolation  → Χ projection
commit/writeback    → Σ
policy/guard        → Ψ
absence/timeout     → Λ where relevant
```

Claim type:

```text
virtual CPU / ISA architecture claim
```

Boundary:

```text
does not assert fabricated silicon, completed emulator, binary encoding,
or full instruction implementation unless artifacts provide that evidence.
```

### 2.7 Architecture of PMS-OS

PMS-STACK claims an OS architecture.

It specifies operator-grounded forms of:

```text
kernel/supervisor
process
thread
syscall
scheduler
memory manager
filesystem
IPC
driver model
resource accounting
security
audit
boot
```

Claim type:

```text
operating-system architecture claim
```

Boundary:

```text
does not assert a complete production OS or POSIX replacement.
```

### 2.8 Architecture of PMSL / PMS-IR

PMS-STACK claims a language/runtime architecture.

It specifies:

```text
operator-typed source constructs
PMS-IR
compiler/lowering path
runtime profile
policy-aware execution
frame constructs
role constructs
commit constructs
absence constructs
trap/reframe constructs
```

Claim type:

```text
language/runtime architecture claim
```

Boundary:

```text
does not assert a complete compiler implementation unless artifact evidence
supports that claim.
```

AI/tooling may propose PMS-IR or opcode programs under host-side validation.

AI output is not:

```text
PMSL semantics
compiler authority
verifier authority
verification evidence
trusted executable code
PMS Base evidence
```

### 2.9 Architecture of Security and Governance

PMS-STACK claims that security and governance are structurally native.

Security is expressed through:

```text
Δ identity / object distinction
Ω roles and capabilities
Χ Distance projection as boundary/isolation/reachability
Ψ policies and invariants
Θ ordering and audit order
Φ trap/recontextualization
Λ absence/failure conditions
Σ commit/audit integration
```

Claim type:

```text
security/governance architecture claim
```

Boundary:

```text
does not certify all implementations as secure;
does not turn governance into a tribunal;
does not create moral, clinical, legal, or social verdict authority.
```

### 2.10 Architecture of Distributed Systems

PMS-STACK claims distributed expressiveness through operator lifting.

It specifies:

```text
node frames
session frames
route frames
PMS Protocol Suite
resilience pipeline
cluster frame □ᴳ
global roles Ωᴳ
global policies Ψᴳ
distributed ordering Θᴳ
cross-node Distance projection Χᴳ
distributed commit Σᴳ
cluster boot
cluster upgrade
distributed audit
```

Claim type:

```text
distributed-systems architecture claim
```

Boundary:

```text
does not require every runtime to be clustered;
does not mandate one consensus algorithm;
does not claim all distributed failures are solvable;
does not claim a full distributed runtime already exists.
```

The superscript `ᴳ` marks distributed or cluster-frame scope.

It does not introduce new PMS Base operators.

### 2.11 Architecture of Simulation and Verification

PMS-STACK claims a simulation and verification architecture.

It specifies:

```text
PMS-UM simulator
PMS-CPU simulator
hybrid simulator
deterministic execution
nondeterministic exploration
debug hooks
policy hooks
boundary hooks
replay
symbolic paths
scenario testing
trace unification
```

Claim type:

```text
tooling / simulation / verification architecture claim
```

Boundary:

```text
does not assert that all simulators, model checkers, proof systems, or
verification suites are implemented.
```

Validation under a simulator, validator, trace gate, or artifact profile is not PMS Base validation.

### 2.12 Architecture Claim Invariants

```text
AC1: PMS-STACK is an implementation-layer architecture specification

AC2: architectural completeness is not completed implementation

AC3: cross-layer mapping is a specification relation, not automatic artifact
     completion

AC4: PMS-CPU is a virtual CPU / ISA architecture claim unless implemented
     artifacts are cited

AC5: PMS-OS is an OS architecture claim unless implemented artifacts are cited

AC6: PMSL/PMS-IR is a language/runtime architecture claim unless implemented
     artifacts are cited

AC7: security/governance is a runtime architecture claim, not tribunal or
     moral authority

AC8: distributed systems support is architecture/profile-dependent, not
     mandatory for all runtimes

AC9: simulation/verification architecture does not equal completed tooling

AC10: no architecture claim validates PMS Base

AC11: PMS Base Χ = Distance; implementation-layer Χ projections do not
      redefine Base Χ

AC12: AI/tooling may assist, propose, or summarize; it may not act as compiler
      authority, verifier authority, verification evidence, trusted execution,
      or PMS Base evidence
```

### 2.13 Architectural Claim Boundary Statement

The correct architectural boundary is:

```text
PMS-STACK specifies the complete implementation-layer architecture.
Implementation artifacts may realize and evidence selected slices.
No architecture claim alone asserts completed implementation, external
validation, formal proof of all properties, or PMS Base validation.
```

---

## 3. Formal Claims

PMS-STACK makes formal claims.

Formal claims must name their model, property, proof status, and boundary.

The central formal-claim rule is:

```text
A PMS-STACK formal claim is valid when it specifies the formal object,
the property asserted, the proof route or proof status, and the scope in
which the property holds.
```

Formal claims are not rhetorical intensifiers.

They are typed commitments.

### 3.1 Formal Object: Operator Alphabet

The basic formal object is the operator alphabet:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

PMS-STACK treats computation as structured words over `O`.

```text
w ∈ O*
```

Claim type:

```text
formal architecture / operator calculus claim
```

Boundary:

```text
the runtime dialect must preserve operator identity and state deviations
explicitly.
```

Important PMS 1.3 boundary:

```text
PMS Base:
    Χ = Distance

PMS-STACK implementation layer:
    Χ may project as isolation, reachability control, boundary management,
    access separation, sandboxing, and quarantine.
```

This implementation projection does not redefine PMS Base Χ.

### 3.2 Formal Object: Operator Words

A PMS-STACK execution can be represented as an operator word.

Example high-level form:

```text
w = Δ* ; Ω* ; □* ; (Θ* ∇* Λ* Φ* Χ*)* ; Σ* ; Ψ*
```

This is a canonical structural form.

It should be read as:

```text
distinguish
authorize / role-bind
frame
order and act
represent absence
recontextualize
preserve boundary / Distance projection
commit
remain policy-bound
```

Claim type:

```text
normal-form / formal-structure claim
```

Boundary:

```text
normal form is not the same as proof that every implementation emits that
exact syntactic sequence in concrete runtime order.
```

### 3.3 Formal Object: Dependency Grammar

PMS-STACK uses dependency discipline between operators.

Examples:

```text
authority requires distinguished subject

protected mutation requires role/policy basis

commit requires valid staged state

timeout requires expected event and τ/window context

recontextualization must preserve relevant policy obligations

boundary crossing must be explicit

global commit requires global policy satisfaction
```

Claim type:

```text
operator dependency claim
```

Boundary:

```text
dependency grammar supports formal analyzability;
it does not by itself prove all implementations obey it.
```

### 3.4 Formal Object: Trace and Trace Set

A concrete execution produces a trace.

```text
trace(artifact, profile, input) ∈ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible executions under a declared profile is:

```text
Trace(artifact, profile) ⊆ L_PMS
```

Under active policy:

```text
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Claim type:

```text
formal trace / execution-language claim
```

Boundary:

```text
a recorded trace evidences one concrete execution unless the claim states
a model, enumeration method, proof, or exhaustive analysis of Trace(...).
```

Trace notation rule:

```text
trace(...) denotes a single observed or constructed execution.

Trace(...) denotes a set of possible executions under declared scope.
```

### 3.5 Formal Claim: Universal Operational Semantics

PMS-STACK claims universal operational semantics for IT mechanisms.

Statement:

```text
Every IT mechanism specified by PMS-STACK can be represented as an
operator sequence respecting the dependency grammar.
```

Claim type:

```text
formal architecture / operational-semantics claim
```

Supported by:

```text
layer mappings
operator tables
UM/CPU/OS/PMSL projections
network and distributed projections
classical-framework embeddings
```

Boundary:

```text
this is not a proof that every possible real-world implementation,
protocol, or system has been exhaustively modeled.
```

### 3.6 Formal Claim: Homomorphic Embedding

PMS-STACK can express classical machines through mappings of the form:

```text
h : Instr* → O*
```

with:

```text
h(I₁ ; I₂) = h(I₁) ; h(I₂)
```

and operational preservation:

```text
execute(I, s) ≈ execute(h(I), h_state(s))
```

This supports computation-model embedding.

Claim type:

```text
formal reduction / embedding claim
```

Boundary:

```text
embedding of a computational model proves expressiveness for that model;
it does not prove all PMS-STACK subsystems correct.
```

### 3.7 Formal Claim: Internal Completeness of Specification

PMS-STACK claims internal specification completeness when:

```text
all operators have implementation-layer representatives

OS mechanisms map to operator sequences

language constructs map through PMSL / IR / ISA path

Ψ invariants are definable at all layers

Σ commits define integration semantics across major domains

boot reaches a declared normal form

extensions require no new primitive operators
```

Claim type:

```text
architecture completeness claim
```

Boundary:

```text
internal specification completeness does not mean completed implementation,
external validation, or formal proof of all properties.
```

### 3.8 Formal Claim: Extensibility Closure

PMS-STACK claims extensibility closure.

A feature is admissible if:

```text
Feature F ∈ PMS-STACK
iff
    F reduces to valid Δ–Ψ structure
    ∧ F respects dependency constraints
    ∧ F introduces no new primitive operator
```

Claim type:

```text
formal extensibility / closure claim
```

Boundary:

```text
a proposed extension still requires mapping, validation, and artifact
evidence before implementation claims can be made.
```

### 3.9 Formal Claim: Equivalence to Classical Frameworks

PMS-STACK claims expressibility of classical frameworks.

It can express:

```text
deterministic Turing machines
nondeterministic Turing machines
lambda-calculus-like computation
register machines
pushdown automata
actor models
POSIX-like processes
capability systems
microkernels
monolithic kernels
virtual machines
distributed consensus profiles
CRDT-like merge profiles
state-machine replication
imperative languages
functional languages
transactional languages
```

Claim type:

```text
expressibility / embedding / specialization claim
```

Boundary:

```text
expressibility is not identity with every concrete framework;
specialization is not full equivalence;
embedding is not implementation completion.
```

### 3.10 Formal Proof Status

Not every formal claim has the same proof status.

Use these statuses:

```text
specified
    formally defined in architecture

sketched
    proof route given but full formal proof deferred

constructive
    explicit construction given at design level

reduction-based
    mapping from known model described

artifact-backed
    executable artifact supports a bounded case

validated-under-profile
    accepted or rejected by a declared validator, profile, gate, schema, or
    conformance rule; not PMS Base validation and not external validation

verified-under-model
    property checked or proven under stated model

externally validated
    independently validated under external protocol
```

Example:

```text
PMS-UM Turing completeness:
    constructive / reduction-based sketch

PMS-STACK full security:
    architecture claim, not universal proof

PMS-RUST deterministic trace:
    artifact-backed bounded execution claim

PMS Base adequacy:
    not established by PMS-STACK or PMS-RUST
```

### 3.11 Formal Claims and PMS Base

PMS-STACK formal claims do not validate PMS Base.

They show that:

```text
given the operator grammar,
a complete systems architecture can be specified.
```

They do not show that:

```text
the PMS Base theory is final
PMS Base is empirically validated
PMS Base is uniquely adequate
PMS Base captures all praxis
PMS Base is externally confirmed
```

Correct statement:

```text
PMS-STACK strengthens implementation-layer formal architecture claims.
It does not function as PMS Base validation.
```

### 3.12 Formal Claim Invariants

```text
FC1: every formal claim states its object

FC2: every formal claim states its property

FC3: every formal claim states proof status

FC4: every formal claim states scope

FC5: operator-word formalism is an architecture formalism, not runtime proof

FC6: Turing-completeness is an expressiveness claim, not an OS correctness claim

FC7: classical-framework embedding is an expressibility claim, not full
     equivalence to every implementation

FC8: internal closure is architecture closure, not artifact completion

FC9: PMS Base identity remains separate from PMS-STACK formalization

FC10: no formal claim in PMS-STACK alone validates PMS Base

FC11: trace(...) denotes a concrete execution; Trace(...) denotes a declared
      possible-execution set under profile

FC12: validated-under-profile means artifact/profile/gate acceptance or
      rejection, not PMS Base validation or external validation
```

### 3.13 Formal Claim Boundary Statement

The correct formal boundary is:

```text
PMS-STACK provides a formal operator architecture for computing systems.
It supports expressiveness, embedding, normal-form, trace, and
extensibility claims under the Δ–Ψ grammar.
These claims do not by themselves prove all implementation properties,
complete all artifacts, or validate PMS Base.
```

---

## 4. Computational Expressiveness Claims

PMS-STACK makes a computational expressiveness claim.

The central computational claim is:

```text
PMS-UM is specified as computationally universal at the abstract-machine
architecture layer: the Δ–Ψ operator grammar is sufficient to encode
arbitrary computable functions through constructive encoding or reduction
from known Turing-complete models.
```

Claim type:

```text
computational expressiveness claim
```

Boundary:

```text
computational universality does not imply completed OS implementation,
security correctness, distributed correctness, PMS Base validation, or
external adequacy.
```

### 4.1 Turing-Completeness Claim

PMS-STACK claims that PMS-UM is Turing-complete at the abstract-machine architecture layer.

The claim can be stated as:

```text
For any computable function f, there exists a PMS-UM operator program w ∈ O*
such that PMS-UM execution of w computes f under the encoded state model.
```

This is an expressiveness claim.

It means PMS-UM can express general computation.

It does not mean PMS-STACK has proven every property of every program.

### 4.2 Constructive Route

The constructive route shows that Δ–Ψ can encode the ingredients needed for classical computation.

Required ingredients:

```text
Boolean distinction
writable memory
state update
conditional branching
loop/progression
commit of state
control transfer
```

Operator mapping:

```text
Δ
    distinguishes conditions, states, symbols, and branches

∇
    performs updates

Σ
    commits persistent transitions

Θ
    orders progression

Α
    represents reusable loop/pattern expansion

Φ
    supports control transfer, branch recontextualization, trap-like jumps

□
    provides program/state/context frames
```

This is sufficient to encode register-machine or Minsky-machine style computation.

Claim type:

```text
constructive expressiveness sketch
```

Boundary:

```text
a constructive universality sketch is not a full formal proof of all system
properties.
```

### 4.3 Reduction Route

The reduction route maps a known Turing-complete instruction language into PMS operators.

Let:

```text
Instr*
```

be the instruction language of a register machine, RAM machine, or equivalent model.

Construct:

```text
h : Instr* → O*
```

such that:

```text
h preserves concatenation
h preserves operational behavior
```

Example mappings:

```text
register increment / decrement
    → ∇ state update + Σ commit

conditional jump
    → Δ branch distinction + Φ recontextualization

memory write
    → ∇ write + Σ commit

program counter
    → □ context / Θ progression

halt
    → Σ final commit or declared terminal state
```

If execution of `I` in the source machine corresponds to execution of `h(I)` in PMS-UM, then PMS-UM inherits computational universality.

Claim type:

```text
reduction / homomorphic embedding claim
```

Boundary:

```text
the reduction establishes computational expressiveness;
it does not establish implementation completeness.
```

### 4.4 Expressiveness vs Practical Implementation

Computational expressiveness is necessary for a universal computing architecture.

It is not sufficient for a full system implementation.

Turing-completeness tells us:

```text
PMS-UM can express arbitrary computable functions.
```

It does not tell us:

```text
the PMS-CPU is implemented

the PMS-OS kernel is implemented

the PMSL compiler is implemented

the security model is verified

the distributed runtime is complete

all programs terminate

all policies are correct

all traces prove behavior

PMS Base is validated
```

Correct statement:

```text
Turing-completeness supports PMS-UM as a computational substrate.
It does not discharge OS, language, security, distributed, or validation
obligations.
```

### 4.5 Expressiveness vs Safety

A universal computational model can express both safe and unsafe programs.

PMS-STACK safety claims therefore require additional structures:

```text
Ω roles and capabilities
Χ Distance projections / boundaries
Ψ policies and invariants
Θ ordering discipline
Φ trap/recontextualization
Λ absence/failure handling
Σ commit discipline
audit evidence
validation gates
```

Computational expressiveness alone does not create safety.

Safety requires policy and runtime discipline.

Correct statement:

```text
PMS-UM expressiveness gives the machine computational reach.
PMS-STACK security and governance specify the constraints under which
that reach is made safe.
```

### 4.6 Expressiveness vs Totality

Turing-complete systems can express non-terminating computations.

Therefore PMS-STACK does not claim:

```text
all PMS programs terminate

all PMSL programs are total

all operator words reach Σ

all distributed proposals commit

all simulations finish
```

Instead, PMS-STACK can specify:

```text
termination policies

timeout handling

Λ absence states

bounded execution profiles

fuel / tick limits

commit conditions

failure states

liveness assumptions
```

Correct statement:

```text
PMS-STACK can express total, partial, terminating, non-terminating,
deterministic, nondeterministic, and environment-driven execution profiles.
```

### 4.7 Expressiveness vs Determinism

PMS-STACK can express deterministic and nondeterministic execution.

Deterministic execution:

```text
fixed inputs
fixed ordering
fixed scheduler/profile
fixed policy state
reproducible trace
```

Nondeterministic execution:

```text
branching scheduler
environment events
fault injection
concurrent interleavings
distributed choices
symbolic paths
```

Expressiveness claim:

```text
PMS-STACK can represent both deterministic and nondeterministic execution
as structural modes.
```

Boundary:

```text
representing nondeterminism is not the same as resolving all nondeterminism
or proving all nondeterministic paths safe.
```

Trace boundary:

```text
a deterministic recorded trace shows one trace(...).

It does not enumerate Trace(...).
```

### 4.8 Expressiveness vs Classical Models

PMS-STACK claims it can express classical computation models.

Examples:

```text
deterministic Turing machines
nondeterministic Turing machines
register machines
pushdown automata
lambda-calculus-like computation
actor models
imperative languages
functional languages
transactional languages
```

Claim type:

```text
classical model expressibility
```

Boundary:

```text
expressing a model does not imply all concrete implementations of that
model are PMS-STACK-conformant without mapping and validation.
```

### 4.9 Expressiveness vs PMSL

PMS-UM may be computationally universal even if a particular PMSL profile is restricted.

A language can be:

```text
total
sandboxed
capability-restricted
transactional
deterministic
domain-specific
profile-limited
```

while the underlying PMS-UM remains universal.

Correct statement:

```text
PMS-UM expressiveness is not identical to PMSL surface expressiveness.
```

This matters for PMS-RUST:

```text
a bounded script or builder interface may expose a restricted subset while
the architecture remains universal at the UM layer.
```

AI may propose candidate PMS-IR or opcode programs.

AI output is not PMSL semantics, compiler authority, verifier authority, verification evidence, or trusted executable code.

### 4.10 Expressiveness vs PMS-RUST Evidence

PMS-RUST may support computational-expressiveness claims indirectly by showing:

```text
operator programs can be represented

bounded operator programs can execute

validation can constrain programs

traces can record execution

fixtures can stabilize examples
```

But PMS-RUST does not need to prove Turing-completeness to be valuable.

Its correct role is:

```text
bounded executable evidence spine for selected PMS-STACK structures.
```

Boundary:

```text
PMS-RUST evidence strengthens implementation-artifact claims.
It does not establish PMS-UM universality by itself unless a formal or
artifact-backed universality demonstration is explicitly provided.
```

Validation under PMS-RUST means acceptance or rejection under artifact profile.

It does not mean PMS Base validation.

### 4.11 Computational Expressiveness Invariants

```text
CE1: PMS-UM computational universality is an expressiveness claim

CE2: Turing-completeness supports PMS-UM as abstract computational substrate

CE3: Turing-completeness does not imply OS correctness

CE4: Turing-completeness does not imply security correctness

CE5: Turing-completeness does not imply distributed correctness

CE6: Turing-completeness does not imply all programs terminate

CE7: deterministic and nondeterministic execution are structural modes

CE8: classical computation models embed as expressibility specializations

CE9: PMSL surface expressiveness may be profile-restricted while PMS-UM
     remains universal

CE10: PMS-RUST bounded execution evidence does not by itself prove
      PMS-UM universality or validate PMS Base

CE11: trace(...) denotes concrete execution evidence; Trace(...) denotes a
      declared possible-execution set

CE12: validation means profile/gate acceptance or rejection, not PMS Base
      validation or external validation
```

### 4.12 Computational Claim Boundary Statement

The correct computational boundary is:

```text
PMS-UM is claimed as computationally universal through constructive and
reduction-based expressiveness arguments.

This supports PMS-STACK as a general computing architecture.

It does not establish completed implementation, universal safety,
distributed correctness, full formal verification, or PMS Base validation.
```

---

## 5. OS and CPU Specification Claims

PMS-STACK makes strong OS and CPU claims.

They are specification claims.

The central claim is:

```text
PMS-STACK specifies PMS-CPU as a virtual CPU / ISA architecture and
PMS-OS as an operator-typed operating-system architecture derived from
PMS-UM and constrained by Δ–Ψ.
```

Claim type:

```text
implementation-layer architecture specification
```

Boundary:

```text
This does not claim fabricated hardware.
This does not claim a completed production operating system.
This does not claim POSIX reimplementation.
This does not validate PMS Base.
```

At PMS Base level:

```text
Χ = Distance
```

At PMS-CPU and PMS-OS implementation layers, Χ may project as:

```text
execution domain
memory boundary
address-space boundary
process isolation
privilege boundary
kernel/user boundary
namespace boundary
sandbox boundary
reachability boundary
```

This projection does not redefine PMS Base Χ.

### 5.1 PMS-CPU Claim

The PMS-CPU claim is:

```text
PMS-CPU is a PMS-UM instance whose state space is virtual processor
state, whose instructions are PMS-operator-typed ISA instructions, and
whose transition relation is the fetch–decode–execute cycle constrained
by frame, role, boundary, commit, and policy rules.
```

This is a virtual CPU / ISA architecture claim.

It specifies the processor-shaped refinement of PMS-UM.

It does not claim physical hardware.

### 5.2 What PMS-CPU Specifies

PMS-CPU specifies:

```text
virtual CPU state
register model
memory model
program counter
instruction position
frame state
role and capability state
boundary / Distance-projection state
policy state
meta-state
operator-typed instruction families
ISA organization
calling conventions
interrupts
traps
exceptions
binary encoding
fetch–decode–execute cycle
commit phase
policy checks
memory consistency model
trace mapping
homomorphic relation to PMS-UM
```

A representative CPU state is:

```text
s_cpu = (
    RF,
    MEM,
    R_pc,
    R_sp,
    R_fp,
    R_fr,
    R_role,
    R_cap,
    R_flag,
    R_iso,
    P,
    m
)
```

Here:

```text
R_iso
    denotes an implementation-level isolation or execution-domain register.

It is not the PMS Base operator Χ itself.

It is a CPU-level value through which PMS Base Χ = Distance may be
projected as boundary, domain separation, memory visibility, or isolation.
```

A PMS-CPU instruction has the form:

```text
Instr = (
    mnemonic,
    op ∈ O,
    operands,
    constraints
)
```

where:

```text
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

### 5.3 PMS-CPU Operator Families

PMS-CPU specifies ISA families according to operator role:

```text
Δ   compare / branch / decode / distinguish
∇   ALU / load / store / call / return / mutate
□   frame operations / execution domains
Λ   wait / poll / absence / idle
Α   pattern expansion / macro-instruction
Ω   role / capability / privilege
Θ   ordering / fence / yield / tick
Φ   trap / interrupt / exception / handler entry
Χ   Distance projection / boundary / isolation
Σ   commit / transaction / atomicity / writeback
Ψ   policy / invariant / guard
```

These are virtual architecture constructs.

They are concrete enough to support:

```text
simulator
emulator
trace validator
compiler target
formal model
JIT or VM backend
```

They are not proof of physical CPU implementation.

### 5.4 PMS-CPU Fetch–Decode–Execute Claim

The PMS-CPU execution cycle is operator-typed.

Canonical form:

```text
Θ
→ Δ_fetch
→ Δ_decode
→ Ω/Ψ validation
→ □ binding
→ Χ boundary check
→ operator execution
→ Σ commit where required
→ R_pc update
→ Φ interrupt/trap check
```

Claim type:

```text
virtual execution architecture claim
```

Boundary:

```text
This defines the PMS-CPU execution model.
It does not claim completed emulator, fabricated hardware, full binary
toolchain, or hardware verification collateral unless those artifacts
are separately provided.
```

A concrete CPU-artifact execution trace would be written as:

```text
trace(artifact, cpu_profile, input) ∈ L_PMS
```

The possible execution set would be written as:

```text
Trace(artifact, cpu_profile) ⊆ L_PMS
```

A recorded CPU trace evidences one execution.

It does not enumerate or prove the full `Trace(...)` set.

### 5.5 PMS-CPU Binary Encoding Claim

PMS-CPU may specify binary encoding.

Correct claim:

```text
PMS-CPU specifies a binary encoding model with explicit operator tags.
```

Example:

```text
PMS_OP → OPCODE → operands → operator-typed instruction
```

Boundary:

```text
A binary encoding specification is not a hardware manufacturing claim.
It is not proof that compilers, assemblers, loaders, emulators, and
hardware backends are complete.
```

### 5.6 PMS-CPU Memory Consistency Claim

PMS-CPU specifies memory consistency in operator terms.

Relevant operators:

```text
Δ   distinguish addresses, values, locations, conditions
∇   perform load/store/mutation
□   bind frame / address space / memory domain
Θ   order memory visibility and execution progression
Χ   control visibility domain / boundary
Σ   commit writeback or integration
Ψ   enforce consistency policy
```

Claim type:

```text
virtual CPU memory-model architecture claim
```

Boundary:

```text
This specifies memory consistency profiles.
It does not prove every implementation satisfies them.
```

### 5.7 PMS-CPU as PMS-UM Specialization

PMS-CPU is not separate from PMS-UM.

It is a domain-restricted specialization:

```text
h_UM→CPU : L_UM ⊆ L_PMS → ISA*
```

A valid PMS-UM word in the CPU mapping domain may become a sequence of PMS-CPU instructions.

Validity preservation:

```text
w ∈ dom(h_UM→CPU) ∩ L_PMS
⇒ h_UM→CPU(w) is PMS-CPU ISA-valid
```

Policy preservation:

```text
w ∈ dom(h_UM→CPU) ∩ L_PMS,Ψ
⇒ h_UM→CPU(w) satisfies PMS-CPU policy constraints
```

Boundary:

```text
PMS-CPU encodes the PMS-UM-executable subset.
It does not require that every valid PMS word has direct CPU encoding.
```

### 5.8 What PMS-CPU Does Not Claim

PMS-CPU does not claim:

```text
fabricated hardware
transistor layout
physical pipeline implementation
cache-coherence circuitry
silicon timing
branch-predictor design
hardware verification collateral
manufacturing process
actual MMU circuitry
actual device bus protocol
completed emulator
completed assembler
completed compiler backend
complete hardware platform
PMS Base validation
```

Correct statement:

```text
PMS-CPU specifies a virtual processor architecture.
```

Incorrect statement:

```text
PMS-CPU is already a fabricated hardware CPU.
```

### 5.8a PMS-CPU ISO_EXIT and PMS-RUST chi_exit Boundary

PMS-CPU may specify boundary-exit behavior at the ISA architecture layer.

The PMS-CPU instruction target is:

```text
ISO_EXIT
```

Meaning:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context
```

PMS-RUST may contain or support a runtime/artifact-level boundary-exit behavior:

```text
PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

The relation is:

```text
ISO_EXIT and chi_exit correspond at the boundary-exit concept level.

They are not the same claim layer.
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Boundary:

```text
PMS-RUST chi_exit does not redefine PMS Base Χ.
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.
PMS-RUST chi_exit does not complete PMS-OS isolation.
PMS-RUST chi_exit does not validate PMS Base.
```

Correct statement:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared artifact profile.
```

Incorrect statement:

```text
PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

### 5.9 PMS-OS Claim

The PMS-OS claim is:

```text
PMS-OS is an operator-typed operating-system architecture in which
kernel execution mediates process, memory, syscall, scheduling, storage,
IPC, device, and policy transitions through Δ–Ψ.
```

Claim type:

```text
implementation-layer OS architecture claim
```

Boundary:

```text
This does not claim that a complete PMS operating-system kernel already
exists.
It does not claim POSIX reimplementation.
It does not validate PMS Base.
```

### 5.10 What PMS-OS Specifies

PMS-OS specifies:

```text
kernel model
kernel trust boundary
process model
thread model
scheduler
syscall interface
isolation and protection
policy engine
resource accounting
virtual memory
allocation and reclamation
filesystem
storage
IPC
synchronization
events
device model
driver lifecycle
audit and trace state
boot relation
kernel invariants
```

It specializes PMS-CPU execution into:

```text
kernel context
processes
threads
scheduler state
syscall dispatch
address spaces
filesystem frames
IPC frames
device frames
driver roles
resource accounts
kernel policies
```

### 5.11 PMS-OS as Kernel Mediation Layer

The PMS-OS kernel mediates transitions that user processes cannot perform directly.

At OS level:

```text
Δ   syscall classification, object lookup, process/thread distinction
∇   resource mutation, filesystem write, IPC enqueue/dequeue
□   process frames, address spaces, namespaces, file frames, device frames
Λ   wait states, timeouts, empty queues, absent events
Α   reusable kernel patterns: fork, exec, journaling, driver binding
Ω   privilege roles, capabilities, credentials, driver permissions
Θ   scheduling, ordering, fairness, timers, dispatch sequencing
Φ   syscall entry, trap handling, interrupt handling, page faults
Χ   Distance projected as process isolation and address-space boundary
Σ   commit, synchronization, syscall return, accounting update
Ψ   kernel invariants, policy engine, lifecycle closure, access constraints
```

The kernel is the privileged PMS-OS locus where these transitions become coherent across the system.

### 5.12 PMS-OS as Privileged PMS Program

PMS-OS may be described as:

```text
a privileged PMS program configuring PMS-CPU operator algebra into a
multi-process, policy-governed system.
```

The relation is:

```text
PMS-CPU = virtual execution substrate
PMS-OS  = privileged system architecture over that substrate
```

The kernel interprets:

```text
CPU-level traps
roles
frames
isolation domains
commit points
policy checks
```

as OS-level system structure.

### 5.13 Kernel Entry and Exit Claim

User processes enter the kernel through controlled Φ transitions.

Canonical entry:

```text
(f_user, r_user, IDom_user)
    --Φ_syscall / Φ_trap / Φ_interrupt-->
(KF, KERNEL, IDom_global)
```

Canonical return:

```text
(KF, KERNEL, IDom_global)
    --Φ_return-->
(f_user, r_user, IDom_user)
```

Claim type:

```text
OS transition architecture claim
```

Boundary:

```text
This specifies kernel entry/exit semantics.
It does not claim an implemented syscall ABI unless artifact evidence
exists.
```

Notation boundary:

```text
IDom_user and IDom_global are OS-level isolation-domain values.

If legacy examples use X_user, X_global, or X in this context, those names
also denote OS-level isolation-domain values.

They are not the PMS Base operator Χ.

They name concrete PMS-OS domain values through which PMS Base Χ =
Distance is projected as boundary, reachability, namespace separation,
and isolation.
```

### 5.14 Process and Thread Claim

At OS level, a process is not merely an executable image.

A PMS-OS process is:

```text
Process = (
    FrameSet,
    RoleState,
    IsolationDomain,
    LocalPolicy,
    Threads,
    Resources
)
```

or:

```text
PProcess = (
    id,
    f,
    r,
    IDom,
    P_local,
    regs,
    meta
)
```

where:

```text
id       Δ process distinction
f        □ frame / address-space context
r        Ω role and capability state
IDom     OS-level isolation-domain value projecting PMS Base Χ = Distance
P_local  Ψ process-local policy
regs     saved PMS-CPU state
meta     Θ / Φ / Λ / Σ metadata
```

Compatibility note:

```text
Older examples may write X, X_user, or X_global for isolation-domain values.

In this document, those names are OS/runtime domain values, not the PMS
Base operator Χ itself.
```

A thread is:

```text
a Θ-scheduled execution strand inside a process frame.
```

Claim type:

```text
OS process/thread architecture claim
```

Boundary:

```text
This defines the OS model.
It does not claim a complete process scheduler implementation unless
artifacts exist.
```

### 5.15 PMS-OS and Classical OS Concepts

PMS-OS retypes familiar OS structures.

| Classical OS concept | PMS-OS projection |
| -------------------- | ----------------- |
| process | `□` frame set + Χ-projected `IDom` boundary + `Ω` role + `Ψ` local policy |
| thread | `Θ`-scheduled execution strand |
| syscall | `Φ` entry + `Ω` privilege adjustment + `Δ` dispatch + `Ψ` check + `Σ/Φ` return |
| address space | `□` frame hierarchy with Χ-projected isolation domain |
| capability | `Ω`-directed permission edge |
| scheduler | `Θ` selection under `Ψ` constraints |
| signal / fault / interrupt | `Φ` recontextualization |
| file descriptor | `□` handle frame with `Ω` permissions and `Ψ` constraints |
| IPC channel | `□` message frame with `Δ/Ω/Λ/Θ/Σ` semantics |
| device driver | `Ω`-governed role inside `□` device/driver frame |
| quota | `Ψ` rule over `Σ`-committed accounting data |

Claim type:

```text
classical OS expressibility / architecture mapping claim
```

Boundary:

```text
Mapping classical OS concepts into PMS-OS does not make PMS-OS a POSIX
reimplementation or prove equivalence to every classical OS.
```

### 5.16 PMS-OS Protection Claim

PMS-OS protection is structural.

An OS-level access is valid only when:

```text
frame context permits it
role authority permits it
boundary reachability permits it
commit state permits it
policy constraints permit it
```

Canonical access validity:

```text
valid_access(subject, object, op) iff
    Δ(subject, object, op)
    ∧ □_context_valid(subject, object)
    ∧ Ω_authorized(subject, op, object)
    ∧ Χ_projected_domain_permits(subject, object)
    ∧ Ψ_allows(subject, op, object)
```

Claim type:

```text
OS protection architecture claim
```

Boundary:

```text
This specifies protection semantics.
It does not certify every implementation as secure.
```

### 5.17 PMS-OS Policy Engine Claim

The Kernel Policy Engine is the OS-level Ψ mechanism.

It defines:

```text
policy objects
policy hooks
policy evaluation
policy decisions
policy enforcement actions
policy lifecycle
policy caching
policy audit
```

Claim type:

```text
OS policy architecture claim
```

Boundary:

```text
The OS policy engine is not the full runtime-security architecture.
Adversarial taxonomy, distributed trust, evidence pipelines, governance
workflows, and runtime attestation belong to runtime security and
distributed-system layers.
```

### 5.18 PMS-OS Non-Claims

PMS-OS does not claim:

```text
finished production OS
complete POSIX compatibility
classical microkernel implementation
monolithic-kernel implementation
hardware driver ecosystem
completed filesystem implementation
completed network stack implementation
completed scheduler implementation
completed syscall ABI implementation
complete PMS-OS isolation lifecycle implementation
deployment security certification
forensic authority
policy-enforcement tribunal
PMS Base validation
```

Correct:

```text
PMS-OS specifies the OS architecture.
```

Incorrect:

```text
PMS-OS is already a complete operating system distribution.
```

### 5.19 PMS-RUST Relation

PMS-RUST may strengthen OS and CPU implementation paths.

It may provide:

```text
operator representation
bounded deterministic execution
model validation
stateful validation
trace output
golden fixtures
vFS service surface
REPL/script tooling
AI proposal boundary
bounded runtime isolation-exit discipline through chi_exit where declared
```

These support claims such as:

```text
bounded operator execution is implementable
model validation can constrain programs
traceable runtime events can be emitted
host-service boundaries can be tested
runtime boundary-exit discipline can be fixture-backed
```

They do not establish:

```text
complete PMS-CPU
complete PMS-OS
complete PMS-CPU ISO_EXIT architecture
complete PMS-OS isolation lifecycle
complete PMSL compiler
complete distributed runtime
trusted AI execution
PMS Base validation
```

### 5.20 OS and CPU Claim Invariants

```text
OCC1: PMS-CPU is a virtual CPU / ISA architecture specification

OCC2: PMS-CPU does not claim fabricated hardware

OCC3: PMS-CPU does not claim complete emulator, compiler backend, or
      hardware implementation unless artifacts support that claim

OCC4: PMS-OS is an operating-system architecture specification

OCC5: PMS-OS does not claim complete production kernel implementation

OCC6: PMS-OS is not a POSIX reimplementation claim

OCC7: PMS-CPU refines PMS-UM into processor-shaped execution

OCC8: PMS-OS refines PMS-CPU execution into kernel-governed system structure

OCC9: OS and CPU traces remain valid only when operator-typed, dependency-valid,
      frame-aware, boundary-aware, commit-aware, and policy-constrained

OCC10: OS and CPU specification claims strengthen PMS-STACK architecture;
       they do not function as PMS Base validation

OCC11: IDom_user, IDom_global, X_user, X_global, and comparable notation in
       OS examples denote OS-level isolation-domain values, not PMS Base Χ

OCC12: PMS Base Χ = Distance; PMS-CPU/PMS-OS project Χ as boundary,
       isolation, reachability control, namespace separation, and domain
       separation

OCC13: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
       under a declared profile; it does not complete PMS-CPU ISO_EXIT,
       complete PMS-OS isolation, redefine PMS Base Χ, or validate PMS Base
```

### 5.21 Boundary Statement

The correct OS/CPU boundary is:

```text
PMS-CPU specifies the virtual processor architecture.
PMS-OS specifies the operating-system architecture over that processor.
Together they define the machine/kernel core of PMS-STACK.

They do not claim fabricated hardware, completed production OS status,
complete compiler/backend ecosystem, deployment certification, completed
PMS-CPU ISO_EXIT implementation, completed PMS-OS isolation lifecycle, or
PMS Base validation.
```

---

## 6. PMSL and Runtime Claims

PMS-STACK makes language, IR, and runtime claims.

The central claim is:

```text
PMSL is the PMS-STACK language specification for operator-typed
programming; PMS-IR is the operator-preserving intermediate form that
keeps Δ–Ψ structure visible to runtimes, analyzers, simulators,
verification tools, and execution backends.
```

Claim type:

```text
language / IR / runtime architecture specification
```

Boundary:

```text
This does not claim a complete PMSL compiler.
This does not claim a complete standard library.
This does not claim a complete verified toolchain.
This does not validate PMS Base.
```

### 6.1 PMSL as Language-Level Operator Surface

PMSL exposes Δ–Ψ as programmable semantic structure.

A PMSL program may include:

```text
bindings
types
functions
modules
frames
roles
capabilities
policy scopes
commit blocks
channels
tasks
traps
handlers
timeouts
matches
FFI declarations
runtime calls
standard-library calls
```

Each construct has an operator reading.

```text
source construct → operator word → PMS-IR → runtime/backend behavior
```

Examples:

```text
type distinction        → Δ
statement/effect        → ∇
scope/function/module   → □
timeout/none/no-event   → Λ
macro/pattern/loop      → Α
role/capability         → Ω
sequencing/await        → Θ
trap/exception/handler  → Φ
module isolation        → Χ
return/transaction      → Σ
policy/invariant        → Ψ
```

Claim type:

```text
language-level operator-surface claim
```

Boundary:

```text
The language specification defines the mapping.
It does not by itself implement parser, compiler, optimizer, runtime, or
standard library.
```

### 6.2 PMS-IR Claim

PMS-IR is the operator-preserving intermediate representation.

It is the bridge between:

```text
PMSL source
static analysis
compiler lowering
runtime execution
PMS-UM
PMS-CPU
PMS-OS
PMS-RUST-style executable slices
simulators
verification tools
trace systems
```

Correct claim:

```text
PMS-IR preserves Δ–Ψ structure across analysis, lowering, execution, and
tooling.
```

Boundary:

```text
PMS-IR specification is not a completed optimizer, bytecode format,
compiler backend, or verified IR implementation unless artifacts provide
that evidence.
```

### 6.3 PMSL/PMS-IR Pipeline Claim

The intended language pipeline is:

```text
PMSL source
→ PMSL AST
→ PMS-IR
→ validation / analysis
→ runtime lowering
→ PMS-UM / PMS-CPU / PMS-OS / host runtime / PMS-RUST slice
→ traces / model checks / simulations / verification artifacts
```

Claim type:

```text
compiler/runtime architecture claim
```

Boundary:

```text
A specified pipeline is not a completed compiler toolchain.
Each pipeline stage requires artifact evidence.
```

### 6.4 Operator-Typed Programming Claim

PMSL does not treat operators as comments or decorative annotations.

Operators are semantic obligations.

A construct tagged or inferred as an operator family must preserve the obligations of that family.

Examples:

```text
Δ obligation:
    distinction must classify something relevant before dependent use

Ω obligation:
    role/capability authority must exist before privileged action

Χ obligation:
    boundary / Distance projection must be preserved where crossing occurs

Σ obligation:
    commit must integrate only valid staged state

Ψ obligation:
    policy must constrain protected transition
```

Claim type:

```text
language-semantics claim
```

Boundary:

```text
Operator-typed source discipline must still be implemented by parser,
type checker, IR validator, runtime checks, or backend artifacts.
```

### 6.5 Type-System Claim

PMSL may specify a type system that tracks:

```text
data types
frame types
role types
capability types
policy types
boundary/process types
effect types
absence types
trap types
commit types
function types
module types
channel types
task types
foreign types
lifetimes / ownership
```

Claim type:

```text
language type-system architecture claim
```

Boundary:

```text
This is not a completed type checker unless an implementation exists.
Type-system design does not itself prove type soundness unless a formal
soundness proof is supplied.
```

Correct claim:

```text
PMSL specifies a type system designed to preserve operator obligations
through source constructs and PMS-IR emission.
```

Incorrect claim:

```text
PMSL already has a fully proven, implemented type system.
```

### 6.6 Runtime Claim

The PMSL runtime mediates execution between language/IR artifacts and lower layers.

Runtime responsibilities include:

```text
program loading
module loading
linking
frame management
task scheduling
channel/event handling
memory/runtime object management
policy enforcement
capability management
boundary management
commit management
exception handling
FFI mediation
standard-library dispatch
backend adapters
trace and audit emission
runtime validation
failure handling
```

Claim type:

```text
runtime architecture claim
```

Boundary:

```text
This does not claim that all runtime components are implemented or
verified.
```

A concrete runtime execution produces:

```text
trace(artifact, runtime_profile, input) ∈ L_PMS
```

The set of possible runtime executions under a declared profile is:

```text
Trace(artifact, runtime_profile) ⊆ L_PMS
```

A recorded trace supports observed-run evidence.

It does not prove all possible runtime behavior.

### 6.7 Concurrency and IPC Claims

PMSL specifies concurrency and IPC through operator structure.

Concepts include:

```text
tasks
task frames
spawn
await
join
cancellation
task groups
channels
send
receive
select
request/response
mailboxes
events
timers
timeouts
synchronization primitives
backpressure
flow control
structured concurrency
supervisors
```

Operator reading:

```text
task/frame              → □
spawn/action            → ∇ + Θ
await/join              → Θ + Λ
channel/message         → Δ + □
send/receive            → Ω + Θ + Σ
timeout                 → Λ
cancellation            → Φ
policy-governed channel → Ψ
boundary-protected IPC  → Χ
```

Claim type:

```text
language/runtime concurrency architecture claim
```

Boundary:

```text
Specifying concurrency constructs does not prove scheduler correctness,
deadlock freedom, liveness, fairness, or complete runtime implementation.
Those require profile-specific analysis, tests, proofs, or artifacts.
```

### 6.8 Error and Exception Claims

PMSL distinguishes absence, error, trap, and recontextualization.

Important distinction:

```text
Λ = absence / non-event / timeout / missing expected event

Φ = recontextualization / trap / exception / handler transition
```

PMSL error architecture may include:

```text
Result
Option
trap forms
try / else / finally
policy violation handling
authority failure
boundary failure
commit failure
cancellation
panic/abort
rollback
compensation
resource cleanup
diagnostics
```

Claim type:

```text
language error/recontextualization architecture claim
```

Boundary:

```text
Error-handling architecture does not prove all failures are recoverable
or all programs safe.
```

### 6.9 Module Claims

PMSL modules are frames.

A module may specify:

```text
module frame
symbol table
imports
exports
interfaces
roles
capabilities
policies
isolation
boundary profiles
versioning
initialization
finalization
hot reload
module-to-module calls
resource accounting
error boundaries
```

Operator reading:

```text
module identity         → Δ
module frame            → □
import/export authority → Ω
module boundary         → Χ
module policy           → Ψ
module initialization   → Θ / Σ
module replacement      → Φ
```

Claim type:

```text
module-system architecture claim
```

Boundary:

```text
Module architecture is not a completed package manager, linker, loader,
or verified module system unless artifacts support that claim.
```

### 6.10 FFI and Host Interoperability Claims

PMSL may interoperate with host systems through FFI.

FFI is not treated as invisible escape.

It is a structured boundary:

```text
Φ   recontextualization into host/foreign frame
Ω   authority for foreign call
Χ   host/runtime boundary
Ψ   FFI policy
Σ   commit of accepted result
Θ   order / audit sequence
Λ   absent response / timeout / unavailable host service
```

Claim type:

```text
FFI / host-boundary architecture claim
```

Boundary:

```text
FFI support does not mean arbitrary host calls are PMS-valid.
Host behavior must be mapped, bounded, authorized, policy-checked, and
traced where relevant.
```

### 6.11 Standard Library Claim

PMSL may specify standard-library profiles for:

```text
filesystem
networking
time
logging
policies
concurrency
IO
resources
security
serialization
diagnostics
```

Claim type:

```text
standard-library architecture claim
```

Boundary:

```text
Standard-library specification is not completed library implementation.
```

### 6.12 Runtime Profiles

Runtime claims must be profile-specific.

Possible profiles:

```text
deterministic runtime
script runtime
REPL runtime
simulation runtime
host-adapter runtime
PMS-CPU backend
PMS-OS backend
PMS-RUST evidence-spine runtime
distributed runtime
verification runtime
boundary-exit runtime
AI-bridge runtime
```

Profile rule:

```text
behavior under profile P
≠ behavior under all profiles.
```

Correct:

```text
This claim holds for the deterministic PMS-RUST v0.1 evidence-spine
profile.
```

Incorrect:

```text
This claim holds for every PMSL runtime.
```

Validation under a runtime profile means:

```text
accepted or rejected by declared profile, validator, gate, schema, or
conformance rule.
```

It does not mean PMS Base validation or external validation.

### 6.13 PMS-RUST Relation

PMS-RUST may strengthen PMSL/PMS-IR/runtime claims through bounded evidence.

It may provide:

```text
PmsBuilder
opcode buffer
script runner
REPL commands
model validation
stateful validation
deterministic kernel execution
JSONL traces
golden fixtures
vFS service surface
AI proposal boundary
chi_exit boundary-exit evidence where declared
```

Supported claims:

```text
bounded operator programs can be built
bounded programs can be validated
bounded programs can be executed
runtime events can be traced
host-service boundaries can be exposed
AI proposals can be gated
runtime boundary-exit discipline can be fixture-backed
```

Boundary:

```text
PMS-RUST is not a complete PMSL compiler.
It is not a complete PMSL standard library.
It is not a complete verified runtime.
It is not PMS Base validation.
It does not complete PMS-CPU ISO_EXIT.
```

### 6.14 AI Boundary for PMSL and Runtime

AI/tooling may assist PMSL, PMS-IR, and runtime development.

AI may:

```text
propose PMS-IR candidates
propose opcode programs
summarize traces
explain diagnostics
suggest fixtures
draft scripts
identify possible policy gaps
```

AI may not serve as:

```text
trusted executable code
compiler authority
verifier authority
verification evidence
runtime policy authority
PMSL semantics
PMS Base evidence
```

Standard rule:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

This is a strong architecture boundary.

It permits AI-assisted tooling without making AI authoritative.

### 6.15 What PMSL and Runtime Do Not Claim

PMSL/PMS-IR/runtime claims do not establish:

```text
complete compiler implementation
complete parser
complete type checker
complete optimizer
complete backend
complete standard library
complete verified runtime
complete OS shell
complete distributed runtime
complete boundary-exit runtime
full formal type-soundness proof
all programs terminate
all programs are safe
all FFI calls are trusted
AI-generated programs are trusted
AI output is compiler authority
AI output is verifier authority
AI output is verification evidence
PMS Base validation
```

### 6.16 Safe PMSL and Runtime Wording

Correct:

```text
PMSL specifies the language-level expression of Δ–Ψ.

PMS-IR specifies an operator-preserving intermediate representation.

The runtime architecture specifies how PMSL/PMS-IR programs are loaded,
validated, executed, traced, and connected to lower layers.

PMS-RUST v0.1 strengthens bounded runtime and PMS-IR construction claims.

PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile.
```

Incorrect:

```text
PMSL is already a complete compiler.

PMS-IR proves PMS.

The REPL is PMSL.

The builder is the full language.

The script runner is the full runtime.

AI output is trusted PMS code.

AI output is compiler output.

AI output is verification evidence.

PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

### 6.17 PMSL and Runtime Claim Invariants

```text
LRC1: PMSL is a language specification, not automatically a completed compiler

LRC2: PMS-IR is an operator-preserving IR specification, not automatically a
      completed optimizer or backend

LRC3: operator tags are semantic obligations, not decorative comments

LRC4: runtime behavior is profile-specific

LRC5: FFI and host services are boundary-mediated, not invisible escapes

LRC6: concurrency claims require runtime/profile/fairness boundaries

LRC7: error-handling architecture does not prove all failures recoverable

LRC8: module architecture does not equal completed linker/package ecosystem

LRC9: PMS-RUST may strengthen builder/script/runtime evidence claims

LRC10: PMS-RUST does not complete PMSL/PMS-IR

LRC11: language/runtime claims strengthen PMS-STACK architecture

LRC12: language/runtime claims do not function as PMS Base validation

LRC13: AI output is not trusted executable code, compiler authority, verifier
       authority, verification evidence, PMSL semantics, runtime policy
       authority, or PMS Base evidence

LRC14: validation means acceptance or rejection under a declared runtime
       profile, validator, gate, schema, or conformance rule, not PMS Base
       validation

LRC15: trace(...) denotes a concrete runtime execution; Trace(...) denotes a
       possible-execution set under declared profile

LRC16: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline;
       it does not complete PMS-CPU ISO_EXIT, redefine PMS Base Χ, or validate
       PMS Base
```

### 6.18 Boundary Statement

The correct PMSL/runtime boundary is:

```text
PMSL specifies operator-typed programming.
PMS-IR specifies operator-preserving intermediate representation.
The PMSL runtime specifies the execution, validation, tracing, host-boundary,
AI-boundary, boundary-exit, and backend architecture for such programs.

These are language/runtime architecture claims.
They do not assert a completed compiler, complete standard library,
complete verified runtime, trusted AI execution, verifier authority,
compiler authority, verification evidence, completed PMS-CPU ISO_EXIT, or
PMS Base validation.
```

---

## 7. Security and Governance Claims

PMS-STACK makes strong security and governance claims.

They are runtime-architecture claims.

The central claim is:

```text
Runtime security in PMS-STACK is valid when every security-relevant
transition is Δ-distinguished, Ω-authorized, □-framed, Χ-bounded,
Θ-ordered, Φ-recontextualized when needed, Σ-committed when stable,
and Ψ-constrained by active invariants and policies.
```

Claim type:

```text
implementation-layer runtime-security architecture claim
```

Boundary:

```text
This does not certify every implementation as secure.
This does not provide deployment security guarantees by itself.
This does not turn governance into a tribunal.
This does not validate PMS Base.
```

At PMS Base level:

```text
Χ = Distance
```

At runtime-security level, Χ projects as:

```text
isolation
boundary
visibility control
reachability control
containment
access separation
sandboxing
quarantine
trust-domain separation
```

This projection does not redefine PMS Base Χ.

### 7.1 Security as Operator Structure

PMS-STACK treats security as operator structure.

Security is not primarily defined as:

```text
permission bits
ACLs
labels
sandbox flags
network filters
key stores
audit logs
compliance reports
```

Those may exist as implementation mechanisms.

The underlying security semantics are:

```text
Δ   distinguish actor, action, object, context, credential, event
∇   perform mutation, IO, transfer, allocation, execution
□   locate transition inside frame, scope, module, process, session
Λ   represent missing resource, absent permission, timeout, no-route
Α   encode recurring security/governance patterns
Ω   assign role, capability, privilege, delegation, authorization
Θ   order execution, audit sequence, expiry checks, event progression
Φ   recontextualize traps, denials, identity mappings, escalation, recovery
Χ   project Distance as isolation, boundary, visibility, containment
Σ   commit stable state, audit record, trust binding, revocation, policy update
Ψ   bind policies, invariants, compliance rules, governance constraints
```

Claim type:

```text
security architecture claim
```

Boundary:

```text
Operator-structured security specifies obligations.
It does not prove all implementations satisfy them.
```

### 7.2 Security Is Not an Add-On

A PMS-STACK security event is:

```text
security event = operator-constrained transition
```

A filesystem write, for example, is not merely IO.

It is:

```text
Δ classify path and operation
Ω verify write authority
□ locate process/module/filesystem frame
Χ check namespace and boundary reachability
Ψ evaluate policy
∇ perform or stage write
Σ commit visible or durable result
Θ order trace/audit event
Φ handle denial, IO trap, rollback, or recovery
```

Claim type:

```text
runtime-security integration claim
```

Boundary:

```text
A structural security model is not the same as security certification.
```

### 7.3 Governance Claim

Governance in PMS-STACK means policy-governed runtime structure.

It covers:

```text
policy definition
policy activation
policy evaluation
policy update
policy revocation
role/capability lifecycle
trust-anchor lifecycle
audit requirements
compliance reports
failure escalation
quarantine
rollback
distributed policy where applicable
```

Governance is expressed through:

```text
Ω   authority to govern
Ψ   policy / invariant
Θ   ordered evaluation and lifecycle
Φ   escalation, fallback, recontextualization
Χ   boundary and containment
Σ   committed governance state / audit artifact
```

Claim type:

```text
runtime governance architecture claim
```

Boundary:

```text
Governance is not a tribunal.
Governance is not legal authority.
Governance is not moral judgment.
Governance is not clinical classification.
Governance is runtime policy discipline.
```

### 7.4 Identity and Principal Claims

Runtime security may define:

```text
identity objects
principals
roles
capabilities
delegations
credentials
sessions
trust bindings
```

Operator reading:

```text
Δ   identity distinction
Ω   role/capability assignment
□   identity frame / principal scope
Χ   visibility and boundary relation
Ψ   identity and authorization policy
Σ   committed identity/trust binding
Φ   identity recontextualization or denial
Θ   expiry, ordering, audit sequence
```

Claim type:

```text
identity / principal architecture claim
```

Boundary:

```text
PMS-STACK identity is computational and structural.
It is not personhood classification.
It is not psychological typing.
It is not moral ranking.
It is not legal identity adjudication.
```

### 7.5 Role and Capability Claims

Roles and capabilities are Ω structures.

They govern:

```text
which actions may be performed
which frames may be entered
which boundaries may be crossed
which policies may be changed
which commits may become stable
which network or distributed roles may participate
```

Typical rule:

```text
(id ▷ op) ⇔
    op ∈ Ω(id)
    ∧ Ψ(id, op, params, state) = allow
    ∧ Χ-compatible(id, op, target)
```

Claim type:

```text
role/capability architecture claim
```

Boundary:

```text
Role/capability architecture does not prove all implementations enforce
permissions correctly.
```

### 7.6 Policy Claims

Ψ is the policy and invariant operator.

A policy may be represented as:

```text
pol = (
    scope,
    conditions,
    actions,
    priority
)
```

Policy function:

```text
Ψ : S → {allow, deny, transform, halt}
```

or:

```text
(id, op, params, s) is valid
⇔ Ψ(s, id, op, params) = allow
```

Claim type:

```text
policy/invariant architecture claim
```

Boundary:

```text
Policy machinery does not establish the external adequacy or justice of
the policies.
It establishes how policies constrain runtime transitions.
```

Validation under policy means acceptance or rejection under a declared profile, validator, schema, gate, or conformance rule.

It does not mean PMS Base validation or external validation.

### 7.7 Χ / Distance Boundary in Security

This document must preserve the PMS 1.3 Χ boundary.

```text
PMS Base 1.3:
    Χ = Distance

PMS-STACK runtime-security layer:
    Χ projects as isolation, boundary, visibility, reachability,
    containment, access separation, sandboxing, quarantine, and
    trust-domain separation.
```

Correct:

```text
PMS-STACK uses Χ as an implementation-layer projection of Distance.
```

Incorrect:

```text
PMS-STACK redefines PMS Base Χ as isolation.
```

Security boundary:

```text
Isolation is a runtime projection of Distance, not a new base operator.
```

### 7.8 Boundary-Exit Security Claim

Runtime security may include explicit boundary-exit discipline.

PMS-RUST may expose this through `chi_exit` where declared.

PMS-CPU may specify the corresponding architecture concern as `ISO_EXIT`.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Claim type:

```text
runtime boundary-exit / isolation-exit discipline claim
```

Boundary:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared artifact profile.

It does not redefine PMS Base Χ.
It does not complete PMS-CPU ISO_EXIT.
It does not complete PMS-OS isolation.
It does not validate PMS Base.
```

### 7.9 Trust and Key Claims

Runtime security may define:

```text
keys
trust anchors
trust state
key lifecycle
rotation
revocation
expiry
session keys
driver/firmware keys
cluster governance keys
trust graph
trust cache
```

Important rule:

```text
key material is not authority by itself.
```

Trust is interpretation under policy.

A key or credential becomes operationally meaningful only when:

```text
Δ credential / key distinguished
Ψ trust policy evaluates it
Φ maps it into local trust context if needed
Ω assigns role/capability if permitted
Χ binds boundary / scope
Σ commits trust/session/key state where required
```

Claim type:

```text
trust-anchor / key-management architecture claim
```

Boundary:

```text
This does not claim a completed cryptographic system, PKI, deployment
security model, or external trust validation.
```

### 7.10 Audit and Compliance Claims

Audit in PMS-STACK is trace/commit structure.

Audit-relevant events may include:

```text
role assignment
capability grant
policy update
kernel entry
boundary crossing
boundary exit
filesystem commit
IPC delivery
network session
trust-anchor update
quarantine
rollback
distributed commit
AI/tooling boundary event
```

Audit event form:

```text
AuditEvent = (
    event_id,
    order,
    operator,
    actor,
    action,
    frame,
    role?,
    policy?,
    boundary?,
    commit_ref?,
    result,
    meta
)
```

Claim type:

```text
audit/compliance architecture claim
```

Boundary:

```text
Auditability is not compliance certification.
Compliance reports are artifacts under declared profiles.
They do not prove all behavior or external legal compliance by themselves.
```

A concrete audit trace records a concrete execution:

```text
trace(artifact, security_profile, input) ∈ L_PMS
```

The possible execution set is:

```text
Trace(artifact, security_profile) ⊆ L_PMS
```

A recorded audit trace does not enumerate or prove the whole `Trace(...)` set.

### 7.11 Failure, Absence, and Attack Handling Claims

PMS-STACK distinguishes:

```text
absence
failure
attack attempt
policy denial
boundary violation
authority failure
commit failure
trust failure
audit failure
resource exhaustion
```

Operator reading:

```text
Λ   absence / expected event missing
Φ   trap / failure recontextualization
Ψ   policy denial / failure rule
Ω   authority failure
Χ   boundary failure / quarantine
Σ   rollback / commit / audit
Θ   ordered response
```

Claim type:

```text
failure and attack-handling architecture claim
```

Boundary:

```text
Attack-handling scenarios show structural expected behavior.
They are not penetration-test results, vulnerability absence proofs, or
deployment security certification.
```

### 7.12 Security Scenario Claims

Security scenarios are valid when they state:

```text
setup
attempted operator word
rejection point
expected runtime response
linked invariants
expected evidence
acceptance gate
boundary
```

Example attempted word:

```text
w_attack = Δ_target ∇_read Χ_bypass Ω_escalate
```

Expected response may include:

```text
Ω denial
Ψ denial
Φ trap
Χ restriction
Σ rollback
Σ audit
```

Claim type:

```text
scenario / acceptance-gate architecture claim
```

Boundary:

```text
A scenario demonstrates the intended structural response.
It does not prove the implementation prevents all attacks in the same
class unless tests, proofs, or deployment evidence establish that.
```

### 7.13 Quarantine Claim

Quarantine is a stronger isolation state.

It may apply to:

```text
process
thread
driver
device
IPC endpoint
filesystem subtree
namespace
container
node
session
AI/tooling interface
```

Operator form:

```text
Φ_quarantine_trigger
→ Χ_quarantine(subject)
→ Ω_revoke_or_attenuate(subject)
→ Ψ_quarantine_policy
→ Σ_quarantine_state
→ Θ/Σ audit
```

Boundary:

```text
Quarantine is not a moral, forensic, legal, or clinical judgment.
It is a runtime containment response to a policy or invariant condition.
```

### 7.14 AI / Tooling Security Boundary

AI and tooling may support security work.

They may:

```text
propose security scenarios
summarize traces
draft fixtures
explain diagnostics
suggest policy gaps
generate candidate opcode programs
```

They may not serve as:

```text
trusted executable code
runtime policy authority
compiler authority
verifier authority
verification evidence
security certification
PMS Base evidence
```

Standard rule:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

Claim type:

```text
AI/tooling security-boundary claim
```

Boundary:

```text
AI/tooling may assist security inspection and fixture generation.
It does not authorize execution, prove security, validate PMS Base, or
replace policy evaluation.
```

### 7.15 Network and Distributed Security Claims

Runtime security integrates with network and distributed layers.

It may specify:

```text
remote principal mapping
network session establishment
network capabilities
network boundaries
message security
authentication
authorization
route and reachability policy
network trust anchors
freshness and replay handling
quarantine and session restriction
distributed trust anchors
cross-node policy
global commit security
```

Claim type:

```text
network/distributed security architecture claim
```

Boundary:

```text
This does not claim a completed network-security implementation or
distributed runtime.
```

### 7.16 PMS-RUST Relation

PMS-RUST may strengthen security/governance claims through bounded evidence.

It may provide:

```text
stateful validation
fail-closed rejection
model validation
JSONL traces
golden fixtures
vFS boundary tests
AI bridge containment
script-mode rejection of unsupported host commands
runtime guard behavior
chi_exit boundary-exit evidence where declared
```

Supported claims:

```text
selected runtime invariants can be enforced
selected invalid programs can be rejected
selected events can be traced
AI proposals can be prevented from becoming trusted execution
host-service boundaries can be exposed and tested
runtime boundary-exit discipline can be fixture-backed
```

Boundary:

```text
PMS-RUST does not establish universal runtime security.
It does not complete runtime-security architecture.
It does not complete PMS-CPU ISO_EXIT.
It does not complete PMS-OS isolation.
It does not validate PMS Base.
```

### 7.17 What Security and Governance Do Not Claim

PMS-STACK security and governance do not claim:

```text
universal security
absence of vulnerabilities
complete adversarial coverage
complete exploit taxonomy
complete formal verification
deployment certification
legal compliance certification
forensic attribution
moral judgment
clinical judgment
person-ranking
policy-enforcement tribunal
AI trustworthiness
AI verifier authority
AI compiler authority
AI verification evidence
complete runtime-security implementation
complete distributed security implementation
complete PMS-CPU ISO_EXIT implementation
complete PMS-OS isolation lifecycle
PMS Base validation
```

### 7.18 Safe Security Wording

Correct:

```text
PMS-STACK specifies security as operator-governed runtime structure.

PMS-STACK security scenarios define expected structural responses to
typed attack attempts.

PMS-RUST strengthens bounded fail-closed, validation, trace, boundary-exit,
and AI-boundary claims where artifacts exist.
```

Incorrect:

```text
PMS-STACK is proven secure.

PMS-STACK prevents all attacks.

PMS-STACK is a governance tribunal.

PMS-RUST validates security.

Audit logs prove compliance.

Quarantine proves malicious intent.

AI output is trusted security verification.

PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

### 7.19 Security and Governance Invariants

```text
SG1: security-relevant transitions are Δ-distinguished

SG2: protected actions require Ω authority

SG3: protected actions are □-framed

SG4: protected boundary crossings preserve Χ as implementation-layer
     projection of PMS Base Distance

SG5: protected transitions are Ψ-constrained

SG6: stable security-relevant effects require Σ where commit is declared

SG7: failures, denials, traps, and attacks are Φ/Λ/Ψ-typed where relevant

SG8: audit-required events are Θ-ordered and evidence-capable

SG9: governance means runtime policy discipline, not tribunal authority

SG10: identity and roles are computational structures, not personhood,
      personality, clinical, moral, or legal classifications

SG11: trust is interpretation under policy; key material is not authority
      by itself

SG12: quarantine is runtime containment, not moral or forensic judgment

SG13: security scenarios define expected structural behavior, not universal
      security proof

SG14: PMS-RUST evidence may strengthen bounded implementation claims

SG15: security/governance claims do not function as PMS Base validation

SG16: trace(...) denotes one concrete security-relevant execution; Trace(...)
      denotes the possible-execution set under declared profile

SG17: validation means profile/gate acceptance or rejection, not PMS Base
      validation or external validation

SG18: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline;
      it does not complete PMS-CPU ISO_EXIT, complete PMS-OS isolation,
      redefine PMS Base Χ, or validate PMS Base

SG19: AI output is not trusted executable code, runtime policy authority,
      compiler authority, verifier authority, verification evidence, or
      PMS Base evidence
```

### 7.20 Boundary Statement

The correct security/governance boundary is:

```text
PMS-STACK specifies security and governance as operator-constrained runtime
structure: identity, authority, boundary, policy, ordering, trap,
absence, commit, audit, trust, failure handling, boundary exit, and
quarantine.

This is a strong security architecture claim.

It does not certify all implementations, prove absence of vulnerabilities,
provide legal or moral authority, complete formal verification, establish
deployment security, complete PMS-CPU ISO_EXIT, complete PMS-OS isolation,
or validate PMS Base.
```

---

## 8. Distributed Systems Claims

PMS-STACK makes distributed-systems claims.

They are architecture/profile claims.

The central claim is:

```text
Distributed PMS-STACK specifies how local PMS-STACK semantics scale into
networked, clustered, and federated systems by lifting Δ–Ψ into explicit
node, session, route, service, shard, replica, cluster, and federation
frames without introducing a new base operator alphabet.
```

Claim type:

```text
distributed-systems architecture claim
```

Boundary:

```text
This does not require every PMS-STACK implementation to be distributed.
This does not claim a completed distributed runtime.
This does not mandate one consensus algorithm.
This does not prove all distributed failures solvable.
This does not validate PMS Base.
```

### 8.1 Distributed Systems as Semantic Scaling

Distributed PMS-STACK is semantic scaling.

```text
semantic scaling =
    local operator semantics remain stable,
    while the frame of application changes.
```

Local:

```text
Σ
    integrates state inside one local runtime frame.
```

Distributed:

```text
Σᴳ
    integrates state across a higher-order distributed frame.
```

Local:

```text
Ψ
    constrains transitions inside a local runtime frame.
```

Distributed:

```text
Ψᴳ
    constrains transitions across cluster or federation frames.
```

Local:

```text
Χ
    PMS Base: Distance
    implementation projection: boundary / reachability / isolation
```

Distributed:

```text
Χᴳ
    distributed Distance projection across nodes, partitions, tenants,
    trust domains, shards, services, routes, and cluster frames.
```

This is not a new theory.

It is the same operator grammar at broader scope.

### 8.2 Global Operator Claims

Distributed PMS-STACK may use global operator notation:

```text
Δᴳ
∇ᴳ
□ᴳ
Λᴳ
Αᴳ
Ωᴳ
Θᴳ
Φᴳ
Χᴳ
Σᴳ
Ψᴳ
```

Claim type:

```text
implementation-layer lifting notation
```

Boundary:

```text
global notation does not create new PMS Base operators.
It marks scope.
```

Correct:

```text
Σᴳ is Σ interpreted over a global / cluster frame.
```

Incorrect:

```text
Σᴳ is a new primitive beyond PMS Base.
```

The superscript `ᴳ` marks distributed or cluster-frame scope.

It does not introduce a new PMS Base operator.

### 8.3 Distributed Frame Claim

A distributed PMS-STACK system may define higher-order frames.

Canonical cluster frame:

```text
□ᴳ = Frame(
    nodes,
    topology,
    shared_policy_domain,
    capabilities
)
```

Expanded:

```text
ClusterFrame = (
    cluster_id,
    nodes,
    topology,
    services,
    storage,
    runtime,
    security,
    trust,
    policies,
    roles,
    boundaries,
    ordering,
    resources,
    audit,
    commit,
    lifecycle,
    meta
)
```

Claim type:

```text
distributed frame architecture claim
```

Boundary:

```text
Specifying □ᴳ does not mean every PMS-STACK runtime instantiates a cluster.
```

### 8.4 Node and Membership Claims

Distributed PMS-STACK may specify:

```text
node identity
node role
node trust state
node membership state
node resource state
node audit state
node routing state
node boundary state
node lifecycle
```

Membership transitions are operator-typed:

```text
Δᴳ classify node
Ψᴳ verify membership policy
Ωᴳ assign role/capability
Χᴳ bind boundary / quarantine state
Θᴳ order membership event
Σᴳ commit membership view
```

Claim type:

```text
cluster membership architecture claim
```

Boundary:

```text
Membership architecture is not a completed membership service unless an
implementation provides the required artifacts.
```

### 8.5 Networking Claim

Distributed PMS-STACK specifies a network architecture grounded in operators.

Networking includes:

```text
transport frames
timeouts
addressing
routing
PMS Protocol Suite
network security
resilience
failover
congestion handling
audit
distributed extension points
```

Operator reading:

```text
□   connection/session/route frame
Θ   ordering, progress, heartbeats, delivery order
Λ   timeout, missing response, missing route, no quorum
Φ   failover, fallback, migration, recovery
Ω   peer authority, session roles, route authority
Χ   reachability and boundary projection
Σ   delivery/session/route/commit stabilization
Ψ   policy, security, routing and resilience constraints
```

Claim type:

```text
networking architecture claim
```

Boundary:

```text
This does not claim a completed transport implementation, production
network stack, or deployment security.
```

### 8.6 PMS Protocol Suite Claim

PMS-STACK may specify protocol forms such as:

```text
P-REQ
P-EVT
P-CTRL
```

Canonical forms:

```text
P-REQ:
    Δ_req ; Ω_caps ; Θ_progress ; {∇, Φ, Λ}* ; Σ_response

P-EVT:
    Δ_evt ; Θ_emit ; {Φ, Λ}* ; Σ_deliver

P-CTRL:
    Δ_ctrl ; Ω_auth ; Ψ_validate ; Φ_recontext ; Θ_apply ; Σ_commit
```

Claim type:

```text
protocol grammar architecture claim
```

Boundary:

```text
A protocol grammar is not a wire-format implementation, network daemon,
or complete distributed runtime unless those artifacts exist.
```

### 8.7 Distributed Commit Claim

PMS-STACK specifies distributed commit through `Σᴳ`.

Central claim:

```text
A PMS-STACK distributed commit is valid when a proposed multi-node state
transition is Δᴳ-classified, Ωᴳ-authorized, Θᴳ-ordered, Χᴳ-boundary-valid,
Ψᴳ-policy-valid, audit-capable where required, and Σᴳ-integrated under a
declared commit profile.
```

Claim type:

```text
distributed commit architecture claim
```

Boundary:

```text
Σᴳ does not mandate a specific consensus algorithm.
Σᴳ is not proof that all distributed commits are safe in all deployments.
```

Local success boundary:

```text
Σᵢ success does not imply Σᴳ success.
```

Local success is evidence of local state transition only.

It is not global truth, cluster agreement, distributed correctness, or Σᴳ commit unless the declared distributed commit profile says so.

### 8.8 Consensus Claim

Consensus is not a new primitive in PMS-STACK.

It is represented as:

```text
Σᴳ under Ψᴳ.
```

Quorum example:

```text
Σᴳ(proposal) valid iff
    Ψᴳ_commitQuorum(votes(nodes), proposal) = true
```

Consensus-related mechanisms may include:

```text
majority quorum
weighted quorum
role-based quorum
leader/coordinator profile
replicated log
two-phase commit
barrier commit
single-controller profile
federated policy profile
simulation profile
```

Claim type:

```text
consensus-adjacent architecture claim
```

Boundary:

```text
PMS-STACK does not prove Paxos, Raft, PBFT, CRDTs, 2PC, or any specific
algorithm correct by naming them as profiles.
```

Correct:

```text
A consensus algorithm may be an implementation mechanism for satisfying
declared Ψᴳ conditions so that Σᴳ may commit.
```

Incorrect:

```text
PMS-STACK automatically proves consensus correctness.
```

### 8.9 Cross-Node Isolation Claim

Cross-node isolation is the distributed projection of Χ.

Important boundary:

```text
PMS Base 1.3:
    Χ = Distance

Distributed PMS-STACK:
    Χᴳ projects as cross-node boundary, reachability, containment,
    partition boundary, trust-domain separation, tenant separation,
    shard boundary, service boundary, route visibility, and quarantine.
```

Claim type:

```text
distributed boundary / cross-node isolation architecture claim
```

Boundary:

```text
Cross-node isolation architecture does not prove every networked
deployment preserves isolation.
```

A protected cross-node action is valid only when:

```text
Δᴳ identities classified
Ωᴳ authority present
Χᴳ boundary permits
Ψᴳ policy permits
Θᴳ order valid where needed
Σᴳ commit valid where stable global state changes
```

### 8.10 Partition and Failure Claims

Distributed PMS-STACK represents partition, no-quorum, missing response, and failure as typed conditions.

Examples:

```text
Λᴳ_no_response
Λᴳ_no_quorum
Λᴳ_partition_suspected
Λᴳ_missing_heartbeat
Λᴳ_route_timeout
```

Failure response may include:

```text
Φᴳ degraded frame
Φᴳ recovery frame
Φᴳ failover
Χᴳ quarantine
Ωᴳ role attenuation
Σᴳ abort / defer / recovery commit
Θᴳ audit ordering
```

Claim type:

```text
distributed failure-handling architecture claim
```

Boundary:

```text
Representing distributed failure does not mean all failure modes are
solvable or that CAP-style tradeoffs disappear.
```

Liveness always depends on declared fairness, timing, failure, partition, retry, and runtime-profile assumptions.

### 8.11 Cluster Boot and Upgrade Claims

Cluster boot and upgrade are optional distributed lifecycle profiles.

Cluster boot may be represented as:

```text
Δᴳ → □ᴳ → Ωᴳ → Ψᴳ → Θᴳ → Σᴳ
```

Upgrade/migration may use:

```text
Φᴳ_prepare → Ψᴳ_validate → Σᴳ_commit
```

Failure path:

```text
Ψ_fail → Φᴳ_fallback → Σᴳ_rollback
```

Claim type:

```text
optional cluster lifecycle architecture claim
```

Boundary:

```text
Cluster boot and upgrade do not apply to every PMS-STACK runtime.
They apply when a runtime claims a cluster profile.
```

### 8.12 Distributed Verification and Audit Claims

Distributed PMS-STACK may specify:

```text
operator-tagged distributed traces
node-local audit streams
Σ-chaining
cluster audit summaries
compliance reports
distributed trace conformance
safety checks
liveness checks under assumptions
partition evidence
quorum evidence
upgrade evidence
```

Claim type:

```text
distributed verification/audit architecture claim
```

Boundary:

```text
Distributed audit evidence is not proof of all distributed behavior.
Verification claims must state property, model, profile, assumptions,
evidence range, and limitations.
```

Correct property form:

```text
Safety property P holds over EvidenceRange E under model/profile M.
```

Incorrect property form:

```text
The distributed system is safe.
```

### 8.13 Distributed Trace Boundary

A concrete distributed execution produces:

```text
traceᴳ(D, profile, input) ∈ L_PMS
```

Under active distributed policy:

```text
traceᴳ(D, profile, input) ∈ L_PMS,Ψᴳ
```

The set of possible distributed executions under a declared profile is:

```text
Traceᴳ(D, profile) ⊆ L_PMS
```

and under policy:

```text
Traceᴳ(D, profile) ⊆ L_PMS,Ψᴳ
```

Boundary:

```text
A recorded distributed trace evidences one traceᴳ(...).

It does not enumerate Traceᴳ(...).
It does not prove all distributed behavior.
```

### 8.14 Optionality Claim

Distributed PMS-STACK is optional by deployment profile.

Valid profiles include:

```text
single-node
networked
clustered
federated
simulation
audit-only distributed
quorum cluster
high-availability cluster
```

Correct:

```text
PMS-STACK includes a distributed-systems architecture.
```

Also correct:

```text
A PMS-STACK implementation may be single-node and still be PMS-STACK-conformant
if its declared profile does not claim distributed features.
```

Incorrect:

```text
Every PMS-STACK runtime must implement cluster boot, consensus, and Σᴳ.
```

Full cluster boot, global consensus, Σᴳ global commit, multi-node upgrade, distributed audit fabric, and federated trust are profile-bound extension claims.

### 8.15 Distributed PMS-RUST Relation

PMS-RUST v0.1 may strengthen distributed paths only where artifacts exist.

Current bounded evidence may support:

```text
operator representation
deterministic execution
trace format
fixture discipline
validation discipline
roadmap pressure
```

Future PMS-RUST-style distributed artifacts may support:

```text
mock node frames
PPS message fixtures
quorum commit fixtures
no-quorum failure fixtures
distributed audit chains
cross-node isolation fixtures
validation gates
JSONL traces
golden tests
```

It does not currently establish:

```text
full distributed runtime
network transport
PPS implementation
cluster membership
Σᴳ distributed commit
quorum consensus
cross-node isolation implementation
cluster boot
distributed audit fabric
partition handling
distributed upgrade
```

Correct:

```text
PMS-RUST may provide groundwork and future gates for distributed PMS-STACK.
```

Incorrect:

```text
PMS-RUST v0.1 implements distributed PMS.
```

PMS-RUST-style evidence strengthens bounded implementation-artifact claims.

It does not complete distributed PMS-STACK, prove consensus algorithms, prove deployment security, or validate PMS Base.

### 8.16 Distributed AI / Tooling Boundary

AI/tooling may assist distributed PMS-STACK work.

It may:

```text
explain distributed traces
draft fixtures
summarize quorum/no-quorum outcomes
suggest scenarios
identify possible policy gaps
help inspect audit chains
```

It may not serve as:

```text
distributed policy authority
consensus authority
compiler authority
verifier authority
verification evidence
trusted executable code
PMS Base evidence
```

Standard rule:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

### 8.17 Distributed Systems Non-Claims

Distributed PMS-STACK does not claim:

```text
every runtime is distributed

every deployment requires cluster boot

every deployment requires consensus

one mandated consensus algorithm

proof of Paxos/Raft/PBFT/CRDT correctness

all partitions are solvable

all failures preserve both availability and consistency

all networked deployments are secure

all cross-node isolation policies are externally adequate

complete distributed runtime implementation

PMS-RUST v0.1 implements distributed PMS

distributed traces prove all distributed behavior

distributed audit proves external compliance

AI output is consensus authority

AI output is distributed verification evidence

PMS Base validation
```

### 8.18 Distributed Systems Invariants

```text
DSC1: distributed PMS-STACK is semantic scaling, not a new operator theory

DSC2: global operator notation marks scope, not new PMS Base primitives

DSC3: □ᴳ is a higher-order distributed frame

DSC4: Ωᴳ roles are cluster/federation-scoped authority structures

DSC5: Ψᴳ policies constrain global state transitions

DSC6: Σᴳ commit requires declared global policy satisfaction

DSC7: consensus is Σᴳ under Ψᴳ, not a separate primitive

DSC8: PMS-STACK does not mandate one consensus algorithm

DSC9: Χᴳ is a distributed implementation projection of PMS Base Distance

DSC10: distributed failure is Λᴳ/Φᴳ/Ψᴳ/Σᴳ-typed under profile

DSC11: cluster boot and upgrade are optional distributed profiles

DSC12: distributed verification/audit claims require model, evidence, profile,
       assumptions, and limitations

DSC13: distributed architecture does not imply distributed implementation

DSC14: distributed evidence strengthens implementation-layer claims where
       artifacts exist

DSC15: distributed claims do not function as PMS Base validation

DSC16: traceᴳ(...) denotes one concrete distributed execution; Traceᴳ(...)
       denotes a declared possible-execution set under profile

DSC17: Σᵢ success does not imply Σᴳ success unless the declared distributed
       commit profile establishes that relation

DSC18: AI/tooling output is not distributed policy authority, consensus
       authority, verifier authority, verification evidence, trusted
       executable code, or PMS Base evidence
```

### 8.19 Boundary Statement

The correct distributed-systems boundary is:

```text
PMS-STACK specifies a distributed architecture by semantically scaling
the local Δ–Ψ structure into node, session, route, service, shard,
replica, cluster, and federation frames.

This supports strong claims about distributed specification, operator
lifting, networking, resilience, global policy, cross-node isolation,
distributed commit, cluster lifecycle, and distributed audit.

It does not require every runtime to implement distributed profiles,
does not mandate a consensus algorithm, does not prove all distributed
systems correct, does not complete distributed implementation, does not
grant AI/tooling distributed authority, and does not validate PMS Base.
```

---

## 9. Non-Goals

This section states the non-goals of PMS-STACK.

Non-goals do not weaken PMS-STACK.

They prevent category errors.

The central non-goal claim is:

```text
PMS-STACK is a computational systems architecture. It is not a POSIX
reimplementation, not a classical microkernel claim, not a fabricated
hardware specification, not an application framework, and not a
psychological, sociological, clinical, moral, legal, or tribunal system.
```

Claim type:

```text
scope and boundary statement
```

Boundary:

```text
Non-goals preserve the strength of the architecture claim by preventing
claim drift across implementation, proof, validation, authority, and
social-domain boundaries.
```

### 9.1 Not a POSIX Reimplementation

PMS-STACK can express POSIX-like concepts.

Examples:

```text
process
file descriptor
permission
signal
namespace
scheduler
pipe
socket
poll / epoll
filesystem operation
```

PMS-STACK maps them to operator structures.

Example:

```text
process               → □ frame + Χ boundary + Ω role + Ψ policy
file descriptor table → Δ object set + □ handle frame
signal                → Φ trap/recontextualization
access control        → Ω/Ψ
namespace isolation   → Χ projection
event readiness       → Θ
timeout               → Λ
commit                → Σ
```

Non-goal:

```text
PMS-STACK does not aim to be a POSIX clone.
```

Correct:

```text
PMS-STACK can project POSIX-like mechanisms into operator structure.
```

Incorrect:

```text
PMS-STACK must reproduce POSIX semantics exactly to be valid.
```

### 9.2 Not a Classical Microkernel Claim

PMS-STACK can express microkernel ideas.

Examples:

```text
capabilities
IPC
user-space services
minimal trusted core
fault isolation
message passing
```

Operator projection:

```text
capability        → Ω
IPC message       → Δ + Θ + Σ
service frame     → □
fault             → Φ
service isolation → Χ
IPC policy        → Ψ
timeout           → Λ
```

Non-goal:

```text
PMS-STACK is not claiming to be a classical microkernel.
```

It may support microkernel-like profiles.

It is broader than the microkernel design pattern.

### 9.3 Not a Monolithic Kernel Claim

PMS-STACK can express monolithic-kernel designs as one possible profile.

Non-goal:

```text
PMS-STACK is not a monolithic-kernel architecture claim.
```

Correct:

```text
PMS-STACK can represent monolithic, microkernel, hybrid, unikernel,
VM-hosted, and simulator-hosted profiles as operator projections.
```

Incorrect:

```text
PMS-STACK must choose one classical kernel family.
```

### 9.4 Not Fabricated Hardware

PMS-CPU is a virtual CPU / ISA architecture.

Non-goal:

```text
PMS-STACK does not claim physical hardware fabrication.
```

It does not provide by itself:

```text
transistor layout
pipeline microarchitecture
cache hierarchy implementation
silicon timing
bus electrical specification
FPGA bitstream
ASIC design
hardware verification collateral
manufacturing process
```

Correct:

```text
PMS-CPU specifies a virtual processor architecture.
```

Incorrect:

```text
PMS-CPU is already a manufactured chip.
```

### 9.5 Not an Application Framework

PMS-STACK is not a web framework, app framework, UI framework, business framework, or product SDK.

It specifies:

```text
machine
OS
runtime
language
security
networking
distributed architecture
verification
simulation
```

Non-goal:

```text
PMS-STACK does not provide domain application abstractions as its primary
purpose.
```

Applications may be built on PMSL or PMS-OS profiles later.

That is downstream.

### 9.6 Not a Psychological or Sociological Metaphor

PMS-STACK is computational.

Its operators are used as computational semantics.

Non-goal:

```text
PMS-STACK is not a psychological metaphor.
PMS-STACK is not a sociological metaphor.
PMS-STACK is not personality analysis.
PMS-STACK is not moral classification.
```

Even when PMS Base has broader praxeological context, PMS-STACK uses the operator grammar as an implementation-layer computing architecture.

Correct:

```text
In PMS-STACK, operators describe computational structure.
```

Incorrect:

```text
PMS-STACK can rank people, diagnose people, or classify social worth.
```

### 9.7 Not Clinical, Forensic, Moral, or Legal Authority

PMS-STACK does not make claims about:

```text
clinical diagnosis
mental health classification
personality ranking
moral worth
legal responsibility
criminal attribution
forensic certainty
rights status
personhood
sentience
consciousness
```

Security and governance structures are runtime structures.

They are not tribunals.

Correct:

```text
A runtime may quarantine a process, node, session, or service under policy.
```

Incorrect:

```text
The system judges the moral status or intent of a person.
```

### 9.8 Not PMS Base Validation

PMS-STACK is not PMS Base validation.

It shows:

```text
given the PMS operator grammar,
a complete systems architecture can be specified.
```

It does not show:

```text
PMS Base is final
PMS Base is empirically validated
PMS Base captures all praxis
PMS Base is uniquely adequate
PMS Base is externally confirmed
```

Non-goal:

```text
PMS-STACK does not validate PMS Base.
```

This applies equally to PMS-RUST, tests, traces, fixtures, validators, gates, documentation, AI/tooling, and roadmap material.

### 9.9 Not Full Formal Verification of All Properties

PMS-STACK contains formal structure.

It does not claim full formal verification of all properties.

Non-goal:

```text
PMS-STACK is not a completed proof suite.
```

It does not by itself prove:

```text
all programs safe
all programs terminating
all policies adequate
all implementations correct
all distributed profiles safe
all runtime traces complete
all security properties verified
```

Formal verification is a separate claim requiring:

```text
formal model
property statement
proof method
checked proof or model result
assumptions
scope
limitations
```

### 9.10 Not Universal Security Certification

PMS-STACK specifies security architecture.

It does not certify all deployments.

Non-goal:

```text
PMS-STACK is not universal security certification.
```

It does not claim:

```text
absence of vulnerabilities
complete adversarial coverage
secure deployment in all environments
legal compliance
regulatory certification
penetration-test success
supply-chain security
cryptographic implementation correctness
```

Security claims remain profile- and artifact-specific.

### 9.11 Not Complete Distributed Runtime by Default

PMS-STACK specifies distributed architecture.

Non-goal:

```text
PMS-STACK does not require every runtime to implement distributed systems.
```

It does not claim:

```text
every runtime has cluster boot
every runtime has Σᴳ
every runtime has consensus
every runtime has distributed audit
every runtime has cross-node isolation
every runtime solves partitions
```

Distributed profiles are optional unless claimed.

### 9.12 Not One Consensus Algorithm

PMS-STACK does not mandate:

```text
Paxos
Raft
PBFT
2PC
3PC
CRDTs
gossip
leader leases
central coordinator
```

Non-goal:

```text
PMS-STACK does not define one mandatory consensus algorithm.
```

Correct:

```text
Consensus mechanisms are implementation profiles for satisfying Ψᴳ so
that Σᴳ may commit.
```

### 9.13 Not PMS-RUST Completion

PMS-RUST may strengthen selected implementation-artifact claims.

Non-goal:

```text
PMS-RUST is not PMS-STACK completion.
```

PMS-RUST does not automatically provide:

```text
full PMS-OS
full PMS-CPU / ISA
full PMSL compiler
full distributed runtime
complete runtime security
complete formal verification
PMS Base validation
```

Correct:

```text
PMS-RUST is a bounded executable PMS-STACK Evidence Spine v0.1.
```

Boundary:

```text
PMS-RUST evidences selected executable slices.
It does not complete the architecture.
```

### 9.14 Not Proof by Tests or Traces

Tests and traces are evidence.

Non-goal:

```text
PMS-STACK does not treat tests or traces as proof of all claims.
```

Correct:

```text
Tests strengthen bounded artifact-quality claims.
Traces strengthen inspectability and replay claims.
```

Incorrect:

```text
Tests prove PMS.
Traces validate PMS Base.
```

Global trace notation:

```text
trace(artifact, profile, input) ∈ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible executions under a declared profile is:

```text
Trace(artifact, profile) ⊆ L_PMS
```

Under active policy:

```text
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Boundary:

```text
A recorded trace usually evidences one concrete trace(...).

It does not by itself enumerate or prove the whole Trace(...) set.
```

Preferred vocabulary:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

### 9.15 Not Implementation by Documentation

Documentation states scope, structure, and boundary.

Non-goal:

```text
Documentation does not implement the artifact by assertion.
```

Correct:

```text
A document can specify PMS-CPU.
```

Incorrect:

```text
A document alone implements PMS-CPU.
```

Documentation can make a claim inspectable.

It cannot replace code, tests, traces, fixtures, validators, gates, proofs, or external validation where those are required by the claim type.

### 9.15a Not Trusted AI Execution or Verification

AI/tooling may support PMS-STACK and PMS-RUST.

It may:

```text
propose PMS-IR candidates
propose opcode programs
summarize traces
explain diagnostics
draft fixtures
suggest scenarios
assist developer workflow
identify possible policy gaps
```

Non-goal:

```text
PMS-STACK does not treat AI output as trusted executable code, compiler
authority, verifier authority, verification evidence, policy authority,
or PMS Base evidence.
```

AI may not:

```text
execute directly
grant authority
bypass validation
define PMSL semantics
define PMS Base
validate PMS Base
prove PMS-STACK
act as formal verifier
commit runtime state without host/kernel mediation
```

Standard rule:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

Boundary:

```text
AI-assisted tooling can strengthen proposal, drafting, diagnostic, and
observability workflows.

It does not become compiler authority, verifier authority, verification
evidence, trusted executable code, runtime policy authority, or PMS Base
validation.
```

### 9.16 Not Boundary-Exit Completion by Runtime Command

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline.

Non-goal:

```text
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.
```

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Boundary:

```text
PMS-RUST chi_exit does not redefine PMS Base Χ.
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.
PMS-RUST chi_exit does not complete PMS-OS isolation.
PMS-RUST chi_exit does not validate PMS Base.
```

### 9.17 Non-Goal Invariants

```text
NG1: PMS-STACK is not a POSIX reimplementation

NG2: PMS-STACK is not a classical microkernel claim

NG3: PMS-STACK is not a monolithic-kernel claim

NG4: PMS-CPU is not fabricated hardware

NG5: PMS-STACK is not an application framework

NG6: PMS-STACK is not a psychological or sociological metaphor

NG7: PMS-STACK is not clinical, forensic, moral, or legal authority

NG8: PMS-STACK does not validate PMS Base

NG9: PMS-STACK is not a completed proof suite

NG10: PMS-STACK is not universal security certification

NG11: distributed PMS-STACK is not mandatory for every runtime

NG12: PMS-STACK does not mandate one consensus algorithm

NG13: PMS-RUST is not PMS-STACK completion

NG14: tests and traces are not proof of all claims

NG15: documentation is not implementation by assertion

NG16: AI output is not trusted executable code, compiler authority, verifier
      authority, verification evidence, runtime policy authority, PMSL
      semantics, or PMS Base evidence

NG17: trace(...) denotes a concrete execution; Trace(...) denotes a declared
      possible-execution set under profile

NG18: PMS-RUST chi_exit evidences bounded runtime isolation-exit discipline
      only under a declared artifact profile; it does not complete PMS-CPU
      ISO_EXIT, complete PMS-OS isolation, redefine PMS Base Χ, or validate
      PMS Base
```

### 9.18 Non-Goal Boundary Statement

The correct non-goal boundary is:

```text
PMS-STACK is a computational systems architecture specification. It
generalizes and structures classical computing concepts through Δ–Ψ.
It is not a POSIX clone, not a classical kernel family, not fabricated
hardware, not an application framework, not a social or psychological
classification system, not a tribunal, not universal security
certification, not a proof suite, not trusted AI execution, not completed
boundary-exit implementation, and not PMS Base validation.
```

---

## 10. What Is Not Yet Implemented

This section distinguishes specification status from implementation status.

The central implementation-boundary claim is:

```text
PMS-STACK is architecturally complete at the specification layer, while
implementation remains artifact-specific, staged, profile-dependent, and
evidence-bound.
```

Claim type:

```text
implementation status boundary
```

Boundary:

```text
Unimplemented status does not weaken the architecture claim.
It identifies the artifact work required to realize the architecture.
```

### 10.1 Architecture Target vs Artifact Status

PMS-STACK defines architecture targets.

Artifacts implement slices.

Correct relation:

```text
PMS-STACK target
→ implementation slice
→ validation
→ trace
→ fixture
→ acceptance gate
→ limitation
```

Incorrect relation:

```text
PMS-STACK target
→ assume implementation complete
```

Every implementation claim should state:

```text
which layer
which profile
which artifact
which tests
which traces
which limitations
```

Validation in this section means:

```text
accepted or rejected under a declared artifact profile, validator, gate,
schema, fixture, or conformance rule.
```

It does not mean PMS Base validation or external validation.

### 10.2 PMS-UM Implementation Status

PMS-STACK specifies PMS-UM as abstract machine.

Not yet necessarily implemented unless artifact evidence exists:

```text
complete PMS-UM simulator
nondeterministic UM executor
symbolic PMS-UM path explorer
full UM trace equivalence checker
complete UM proof environment
UM debugger
UM replay engine across all profiles
```

Implemented evidence may exist only for bounded runtime slices.

Boundary:

```text
abstract machine specification
≠ complete simulator implementation.
```

### 10.3 PMS-CPU Implementation Status

PMS-STACK specifies PMS-CPU as virtual CPU / ISA architecture.

Not yet implemented unless artifacts exist:

```text
complete register-file emulator
complete memory model implementation
complete instruction enum
complete binary decoder
complete assembler
complete disassembler
complete fetch–decode–execute loop
complete trap/interrupt subsystem
complete CPU-level trace system
complete PMS-CPU simulator
complete ISA test suite
complete compiler backend
complete PMS-CPU ISO_EXIT implementation
hardware backend
FPGA or ASIC implementation
```

Boundary:

```text
PMS-CPU specification
≠ completed PMS-CPU implementation.
```

PMS-RUST may support this path through:

```text
operator enum
opcode execution
validation
trace emission
golden fixtures
chi_exit runtime evidence where declared
```

but that is not full PMS-CPU.

### 10.4 PMS-OS Implementation Status

PMS-STACK specifies PMS-OS.

Not yet implemented unless artifacts exist:

```text
complete kernel
process manager
thread scheduler
syscall ABI
virtual memory subsystem
filesystem
IPC subsystem
device model
driver framework
resource accounting
kernel policy engine
kernel audit subsystem
bootloader
kernel/user separation in a real runtime
complete PMS-OS isolation lifecycle
package/process lifecycle
production deployment profile
```

Boundary:

```text
PMS-OS architecture
≠ completed production operating system.
```

PMS-RUST may provide bounded service or runtime slices.

That does not complete PMS-OS.

### 10.5 PMSL Compiler Implementation Status

PMS-STACK specifies PMSL and PMS-IR.

Not yet implemented unless artifacts exist:

```text
complete PMSL parser
complete AST
complete type checker
effect checker
policy checker
capability checker
IR lowering pipeline
optimizer
backend to PMS-CPU
backend to host runtime
module linker
package manager
standard library
compiler diagnostics
source maps
compiler test suite
formal type-soundness proof
```

Boundary:

```text
PMS-IR builder or script runner
≠ complete PMSL compiler.
```

AI may propose PMS-IR candidates or opcode programs.

AI output is not compiler authority, verifier authority, verification evidence, PMSL semantics, trusted executable code, or PMS Base evidence.

### 10.6 Runtime Implementation Status

PMS-STACK specifies runtime responsibilities.

Not yet implemented unless artifacts exist:

```text
complete module loader
complete scheduler
complete task runtime
complete channel/event runtime
complete policy runtime
complete capability runtime
complete boundary manager
complete commit manager
complete exception/trap runtime
complete FFI runtime
complete standard library runtime
complete trace/audit runtime
complete host adapter suite
complete boundary-exit runtime
complete AI-gated proposal runtime
```

PMS-RUST may implement:

```text
bounded deterministic kernel
builder/script path
validation
trace output
REPL surface
vFS surface
AI proposal bridge
chi_exit boundary-exit discipline where declared
```

Boundary:

```text
bounded runtime evidence
≠ complete runtime implementation.
```

### 10.7 Security Implementation Status

PMS-STACK specifies security/governance architecture.

Not yet implemented unless artifacts exist:

```text
complete identity/principal subsystem
complete role/capability lifecycle
complete policy language
complete policy engine
complete key/trust-anchor management
complete audit/compliance pipeline
complete adversarial scenario suite
complete quarantine mechanism
complete revocation system
complete security monitor
complete runtime attestation
complete distributed trust system
complete boundary-exit security lifecycle
external security review
deployment certification
```

Boundary:

```text
security architecture
≠ universal security implementation.
```

### 10.8 Networking Implementation Status

PMS-STACK specifies networking.

Not yet implemented unless artifacts exist:

```text
transport implementation
connection frame runtime
timeout/retry engine
addressing and routing table implementation
PMS Protocol Suite implementation
network security implementation
resilience/failover runtime
congestion handling
service discovery
session layer
route audit
network test harness
network simulator
```

Boundary:

```text
network architecture
≠ completed network stack.
```

### 10.9 Distributed Runtime Implementation Status

PMS-STACK specifies distributed systems architecture.

Not yet implemented unless artifacts exist:

```text
node runtime
membership service
cluster frame manager
distributed policy service
distributed commit runtime
consensus profile implementation
quorum engine
cross-node isolation enforcement
cluster boot
rolling upgrade
distributed audit chain
partition detector
failover controller
replication system
multi-node test harness
distributed simulator
```

Boundary:

```text
distributed architecture
≠ completed distributed runtime.
```

PMS-RUST-style distributed artifacts may later provide:

```text
mock node frames
PPS message fixtures
quorum commit fixtures
no-quorum failure fixtures
distributed audit chains
cross-node isolation fixtures
validation gates
JSONL traces
golden tests
```

Those would strengthen bounded distributed implementation-artifact claims.

They would not by themselves prove distributed correctness or validate PMS Base.

### 10.10 Verification Tooling Implementation Status

PMS-STACK specifies verification/tooling architecture.

Not yet implemented unless artifacts exist:

```text
complete PMS-UM simulator
complete PMS-CPU simulator
hybrid simulator
symbolic executor
model checker
trace equivalence checker
proof assistant formalization
property-specification language
coverage tool
audit verifier
distributed trace verifier
scenario generator
security scenario harness
cluster simulator
AI-assisted trace analysis gate
```

Boundary:

```text
verification architecture
≠ completed verification suite.
```

AI-assisted trace analysis is advisory observability.

It is not verification evidence, verifier authority, proof, or PMS Base validation.

### 10.11 PMS-RUST Evidence Spine Status

PMS-RUST may currently function as bounded evidence spine for selected slices.

It may implement or support:

```text
operator representation
bounded opcode programs
deterministic kernel execution
model validation
stateful validation
JSONL traces
REPL/script tooling
vFS service surface
demos
golden fixtures
AI proposal boundary
bounded runtime isolation-exit discipline through chi_exit where declared
repository documentation
acceptance gates
```

It does not yet implement:

```text
full PMS-UM simulator
full PMS-CPU / ISA
complete PMS-CPU ISO_EXIT architecture
full PMS-OS
complete PMS-OS isolation lifecycle
full PMSL compiler
full distributed runtime
complete runtime security
complete PMS 1.3 migration
trusted AI execution
full formal verification
external validation
```

Boundary:

```text
PMS-RUST strengthens selected implementation-artifact claims.
It does not complete PMS-STACK.
```

### 10.11a PMS-RUST chi_exit Boundary

PMS-RUST `chi_exit` evidences bounded runtime isolation-exit discipline.

It corresponds to the PMS-CPU `ISO_EXIT` architecture concern only at the boundary-exit concept level.

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Boundary:

```text
PMS-RUST chi_exit does not redefine PMS Base Χ.
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.
PMS-RUST chi_exit does not complete PMS-OS isolation.
PMS-RUST chi_exit does not validate PMS Base.
```

Correct statement:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile.
```

Incorrect statement:

```text
PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

### 10.12 Roadmap vs Implementation

Roadmap items are not implementation evidence.

Roadmap may include:

```text
PMSL parser/compiler prototype
PMS-CPU simulator
PMS-CPU ISO_EXIT implementation
OS/process/capability layer
PMS-OS isolation lifecycle
distributed PMS profile
cluster fixtures
stronger event format
formal verification work
PMS 1.3 migration
additional acceptance gates
```

Correct:

```text
Roadmap identifies implementation pressure.
```

Incorrect:

```text
Roadmap equals implemented feature.
```

Roadmap discipline:

```text
roadmap ≠ implemented evidence

documented_slice ≠ executable evidence

implemented_slice requires code, test, trace, fixture, validator, or gate
evidence for bounded scope
```

### 10.13 Artifact Evidence Required for Implementation Claims

An implementation claim should be backed by:

```text
code
tests
fixtures
traces
validator
documentation
acceptance gate
runtime profile
limitations
```

Minimum useful form:

```text
ImplementedSlice = (
    layer,
    profile,
    artifact,
    supported_claim,
    tests,
    trace_or_fixture,
    limitation
)
```

Example:

```text
Layer:
    PMS-RUST bounded runtime

Artifact:
    deterministic kernel execution

Evidence:
    code + validator + fixture + JSONL trace

Claim:
    bounded operator programs can execute under declared profile

Limitation:
    not full PMS-OS, PMS-CPU, PMSL, distributed runtime, or PMS Base validation
```

Boundary-exit example:

```text
Layer:
    PMS-RUST bounded runtime

Artifact:
    chi_exit boundary-exit behavior where declared

Evidence:
    stateful validator + valid-exit fixture + unbalanced-exit rejection
    fixture + trace

Claim:
    bounded runtime isolation-exit discipline can be enforced under a
    declared profile

Limitation:
    not complete PMS-CPU ISO_EXIT, not complete PMS-OS isolation lifecycle,
    not PMS Base Χ redefinition, and not PMS Base validation
```

### 10.14 Implementation Status Labels

Use stable status labels.

```text
specified
    defined in PMS-STACK architecture

implemented_slice
    bounded artifact exists

validator_backed
    validator checks declared constraints

trace_backed
    trace or event output exists

fixture_backed
    reproducible fixture exists

gate_backed
    acceptance gate enforces the behavior

validated-under-profile
    accepted or rejected by a declared validator, profile, gate, schema, or
    conformance rule; not PMS Base validation and not external validation

roadmap
    planned future artifact

boundary
    named layer, claim, or version distinction

tracked_boundary
    named migration or alignment issue that remains governed

out_of_scope
    explicitly not in current scope

not_claimed
    no claim is made
```

Avoid ambiguous labels:

```text
done
proven
finished
complete
validated
realized
production-ready
```

unless the object and claim type are explicitly stated.

Careful wording rule:

```text
validated
    use only with explicit object and scope, e.g. validated under profile P
    by validator V; never use as shorthand for PMS Base validation
```

### 10.15 Implementation Boundary Matrix

| STACK component | Current claim type | Implementation boundary |
| --------------- | ------------------ | ----------------------- |
| PMS-UM | abstract machine architecture | complete simulator not implied |
| PMS-CPU | virtual CPU / ISA architecture | hardware/emulator/toolchain not implied |
| PMS-CPU ISO_EXIT | architecture-level boundary-exit instruction | PMS-RUST chi_exit is not completion |
| PMS-OS | OS architecture | production kernel not implied |
| PMS-OS isolation | OS isolation lifecycle architecture | runtime chi_exit does not complete it |
| PMSL | language architecture | complete compiler not implied |
| PMS-IR | IR architecture | optimizer/backend not implied |
| Runtime | runtime architecture | complete runtime not implied |
| Security | security architecture | certification not implied |
| Networking | networking architecture | transport stack not implied |
| Distributed | distributed architecture | cluster runtime not implied |
| Verification | verification architecture | proof suite not implied |
| PMS-RUST | bounded evidence spine | full STACK not implied |
| AI bridge | proposal-boundary tooling | trusted AI execution not implied |

### 10.16 What “Not Yet Implemented” Does Not Mean

“Not yet implemented” does not mean:

```text
architecturally invalid
weak
unscientific
unusable
speculative in the pejorative sense
```

It means:

```text
specified at architecture layer,
awaiting or requiring artifact realization for implementation claims.
```

Correct:

```text
The PMS-CPU architecture is specified; implementation artifacts remain
future or bounded by current evidence.
```

Incorrect:

```text
Because PMS-CPU is not fabricated hardware, the PMS-CPU architecture is
not meaningful.
```

### 10.17 Implementation Boundary Invariants

```text
NFI1: architecture specification is distinct from implementation artifact

NFI2: PMS-STACK may be architecturally complete while implementation remains
      staged

NFI3: every implementation claim must name artifact and profile

NFI4: every implemented slice must state limitation

NFI5: PMS-RUST implemented slices do not complete PMS-STACK

NFI6: roadmap items are not implemented evidence

NFI7: documentation is not implementation by assertion

NFI8: tests and traces support bounded implementation claims

NFI9: unimplemented status does not weaken architecture specification status

NFI10: implementation artifacts do not function as PMS Base validation

NFI11: validated-under-profile means acceptance or rejection under declared
       artifact/profile/gate/schema/conformance rule, not PMS Base validation
       or external validation

NFI12: trace(...) denotes concrete execution evidence; Trace(...) denotes a
       declared possible-execution set

NFI13: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
       under a declared profile; it does not complete PMS-CPU ISO_EXIT,
       complete PMS-OS isolation, redefine PMS Base Χ, or validate PMS Base

NFI14: AI output is not trusted executable code, compiler authority, verifier
       authority, verification evidence, PMSL semantics, runtime policy
       authority, or PMS Base evidence
```

### 10.18 Boundary Statement

The correct implementation boundary is:

```text
PMS-STACK is architecturally complete at the specification layer.
Implementation is staged, artifact-specific, profile-dependent, and
evidence-bound.

PMS-RUST strengthens selected implementation-artifact claims, including
bounded runtime isolation-exit discipline where chi_exit is declared, but
does not complete PMS-STACK, PMS-CPU ISO_EXIT, PMS-OS isolation, or
validate PMS Base.
```

---

## 11. What Is Not Proven

This section states what PMS-STACK does not prove.

This is not a weakening section.

It protects the difference between:

```text
specified
expressible
sketched
artifact-backed
tested
traced
validator-backed
validated-under-profile
verified under model
externally validated
proven
```

The central proof-boundary claim is:

```text
PMS-STACK establishes a complete implementation-layer architecture and
strong computational expressiveness claims, but it does not by itself
prove every implementation correct, every security property satisfied,
every distributed profile safe, every policy externally adequate, every
artifact complete, every AI/tooling output valid, or PMS Base validated.
```

Claim type:

```text
proof-boundary statement
```

Boundary:

```text
The absence of a proof claim does not weaken the architecture claim.
It identifies where proof, verification, implementation evidence, or
external validation would be separate work.
```

Validation in this section means:

```text
accepted or rejected under a declared artifact profile, validator, gate,
schema, fixture, or conformance rule.
```

It does not mean PMS Base validation or external validation.

### 11.1 Specification Is Not Proof

A specification can be complete at the architecture layer without proving all properties of all implementations.

PMS-STACK specifies:

```text
operator grammar
abstract machine
virtual CPU architecture
OS architecture
language/runtime architecture
security/governance architecture
networking architecture
distributed architecture
simulation and verification architecture
boot and cluster profiles
```

This does not automatically prove:

```text
all implementations conform

all programs are safe

all programs terminate

all policies are adequate

all distributed protocols satisfy their intended properties

all runtime traces are complete

all security scenarios are covered

all extensions preserve semantics

PMS Base is validated
```

Correct:

```text
PMS-STACK specifies a complete operator-grounded systems architecture.
```

Incorrect:

```text
PMS-STACK specification alone proves every implementation correct.
```

### 11.2 Turing-Completeness Is Not System Correctness

PMS-UM is claimed as computationally universal at the abstract-machine architecture layer.

That claim supports PMS-UM as a general computational substrate.

It does not prove:

```text
OS correctness
CPU implementation correctness
scheduler fairness
memory safety
type soundness
security policy adequacy
distributed consensus correctness
liveness
termination
deployment safety
```

Turing-completeness means:

```text
the machine can express arbitrary computable functions.
```

It does not mean:

```text
every expressed function is safe, terminating, useful, verified, or correct.
```

Correct:

```text
PMS-UM Turing-completeness is a computational expressiveness claim.
```

Incorrect:

```text
Because PMS-UM is Turing-complete, PMS-STACK is proven correct.
```

### 11.3 Architecture Completeness Is Not Artifact Completion

PMS-STACK may claim architecture completeness when the architecture supplies operator-grounded structures for all major system layers.

This does not prove or establish:

```text
complete PMS-CPU implementation
complete PMS-OS kernel
complete PMSL compiler
complete PMSL runtime
complete standard library
complete network stack
complete distributed runtime
complete verification suite
complete simulator suite
complete security implementation
complete PMS-CPU ISO_EXIT implementation
complete PMS-OS isolation lifecycle
trusted AI execution
```

Correct:

```text
The architecture is complete at specification level.
```

Incorrect:

```text
All architecture targets are implemented.
```

Architecture completeness strengthens PMS-STACK as a specification.

It does not collapse specification into artifact completion.

### 11.4 Expressibility Is Not Equivalence

PMS-STACK can express classical frameworks.

It can express:

```text
Turing machines
register machines
actor models
lambda-calculus-like computation
POSIX-like process models
capability systems
microkernels
monolithic-kernel profiles
virtual machines
distributed consensus profiles
CRDT-like merge profiles
state-machine replication
imperative languages
functional languages
transactional languages
```

This does not prove:

```text
identity with every concrete implementation

behavioral equivalence to every POSIX system

correctness of every expressed consensus algorithm

equivalence to JVM, CLR, WASM, Unix, seL4, Linux, Raft, Paxos, or CRDT
implementations

automatic compatibility with all classical tooling
```

Correct:

```text
Classical frameworks can be represented as PMS-STACK specializations or
operator projections.
```

Incorrect:

```text
Every classical framework is fully equivalent to PMS-STACK in all
implementation details.
```

### 11.5 Security Architecture Is Not Universal Security Proof

PMS-STACK specifies security as operator structure.

It defines:

```text
identity
roles
capabilities
boundaries
policies
traps
absence handling
commit discipline
audit
trust anchors
quarantine
governance lifecycle
boundary-exit discipline where declared
```

This does not prove:

```text
absence of vulnerabilities
complete adversarial coverage
secure deployment in all environments
correct cryptographic implementation
correct key management
complete policy adequacy
regulatory compliance
forensic certainty
universal attack prevention
complete PMS-CPU ISO_EXIT implementation
complete PMS-OS isolation lifecycle
```

Correct:

```text
PMS-STACK specifies a security and governance architecture.
```

Incorrect:

```text
PMS-STACK is proven secure.
```

### 11.6 Security Scenarios Are Not Exhaustive Security Proofs

Security scenarios are valuable.

They show expected structural responses to typed attack attempts.

Example scenario form:

```text
setup
attempted operator word
rejection point
expected trap/reframe
expected rollback or quarantine
linked Ψ invariants
expected audit evidence
```

A scenario may show:

```text
how unauthorized privilege escalation should be rejected

how isolation leak attempts should trap

how failed transactions should rollback

how distributed fake commit should be denied

how unbalanced boundary exit should be rejected where profile declares
boundary-exit discipline
```

It does not show:

```text
all attacks in that class are impossible

all implementations enforce the rule

all side channels are closed

all deployment contexts are secure

all vulnerabilities are absent
```

Correct:

```text
Security scenarios define expected PMS-STACK structural behavior.
```

Incorrect:

```text
Security scenarios prove full security.
```

### 11.7 Governance Is Not Moral, Legal, or Clinical Proof

PMS-STACK governance means runtime policy discipline.

It includes:

```text
policy definition
policy update
capability lifecycle
trust-anchor lifecycle
audit
quarantine
rollback
escalation
distributed policy
```

It does not prove or authorize:

```text
moral judgment
legal guilt
clinical diagnosis
personality ranking
forensic attribution
personhood status
rights status
social worth
sentience
consciousness
```

Correct:

```text
A PMS runtime may quarantine a process, session, node, or service under
declared policy.
```

Incorrect:

```text
PMS governance judges people.
```

### 11.8 Distributed Architecture Is Not Distributed Correctness Proof

PMS-STACK specifies distributed structures:

```text
□ᴳ global frame
Ωᴳ global roles
Ψᴳ global policies
Θᴳ distributed ordering
Χᴳ cross-node Distance projection
Σᴳ distributed commit
Λᴳ no-quorum / missing heartbeat / no-response
Φᴳ recovery / failover / partition recontextualization
```

This does not prove:

```text
all distributed algorithms correct

all partitions solvable

consensus correctness for every algorithm

availability and consistency under all failure modes

correct implementation of membership

correct implementation of quorum

correct implementation of distributed audit

secure cross-node isolation in every deployment
```

Correct:

```text
PMS-STACK specifies the architecture in which distributed profiles can be
typed, implemented, tested, and verified.
```

Incorrect:

```text
PMS-STACK automatically proves distributed correctness.
```

### 11.9 Consensus Profile Is Not Consensus Proof

Consensus in PMS-STACK is represented as:

```text
Σᴳ under Ψᴳ.
```

Example:

```text
Σᴳ(proposal) valid iff
    Ψᴳ_commitQuorum(votes(nodes), proposal) = true
```

This specifies the semantic location of consensus-adjacent behavior.

It does not prove:

```text
Paxos
Raft
PBFT
2PC
3PC
CRDT convergence
leader election
replicated log safety
Byzantine fault tolerance
```

Correct:

```text
A consensus algorithm may be an implementation profile for satisfying Ψᴳ
so that Σᴳ may commit.
```

Incorrect:

```text
PMS-STACK proves Raft/Paxos by rephrasing them.
```

### 11.10 Tests Are Not Proof

Tests are important artifact evidence.

They can show:

```text
this fixture passes

this invalid case rejects

this trace matches expected output

this validator catches this error

this runtime path is reproducible

this gate currently passes
```

They do not prove:

```text
all cases are covered

all properties hold

all implementations conform

all bugs are absent

all policies are adequate

PMS Base is valid
```

Correct:

```text
Tests strengthen bounded implementation-artifact claims.
```

Incorrect:

```text
Tests prove PMS.
```

Preferred vocabulary:

```text
tests check
traces record
validators accept/reject
fixtures stabilize known cases
gates discipline releases
proofs prove stated properties under assumptions
external validation requires external protocol
```

### 11.11 Traces Are Not Proof

Traces are important.

They show recorded behavior.

A concrete execution produces:

```text
trace(artifact, profile, input) ∈ L_PMS
```

Under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
```

The set of possible executions under a declared profile is:

```text
Trace(artifact, profile) ⊆ L_PMS
```

Under active policy:

```text
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Traces can support:

```text
debugging
audit surface
fixture comparison
replay
regression analysis
acceptance gates
trace conformance checks
```

They do not show:

```text
all possible executions

all unobserved behavior

all causal explanations

all correctness

all audit sufficiency

external validation
```

Correct:

```text
Trace evidence makes execution inspectable.
```

Incorrect:

```text
A trace proves the system correct.
```

Boundary:

```text
A recorded trace usually evidences one concrete trace(...).

It does not by itself enumerate or prove the whole Trace(...) set.
```

### 11.12 Validators Are Not External Adequacy Proofs

Validators enforce declared rules.

They may check:

```text
operator adjacency
stateful frame constraints
commit constraints
boundary constraints
profile constraints
trace schema
AI proposal shape
fixture expectations
boundary-exit preconditions
```

They do not prove:

```text
the rules are externally adequate

the rules are complete

the theory is true

all runtime states are covered

all attacks are prevented
```

Correct:

```text
A validator enforces declared constraints under a profile.
```

Incorrect:

```text
A validator proves PMS Base.
```

### 11.13 Formal Verification Requires a Separate Claim

A formal verification claim must state:

```text
formal model
property
assumptions
proof method
tool or proof artifact
scope
limitations
```

Without these, the correct status is not “proven”.

Use:

```text
specified
sketched
artifact-backed
tested
trace-backed
validator-backed
validated-under-profile
verified-under-model
```

as appropriate.

Correct:

```text
Property P is verified under model M with assumptions A and proof artifact V.
```

Incorrect:

```text
PMS-STACK is formally verified.
```

unless the exact scope and proof artifact exist.

### 11.14 AI Output Is Not Proof or Verification Evidence

AI/tooling may assist PMS-STACK and PMS-RUST work.

It may:

```text
propose PMS-IR candidates
propose opcode programs
summarize traces
explain diagnostics
draft fixtures
suggest scenarios
assist developer workflow
identify possible policy gaps
```

AI output does not prove:

```text
PMS Base
PMS-STACK correctness
runtime correctness
security correctness
distributed correctness
compiler correctness
policy adequacy
```

AI output is not:

```text
trusted executable code
compiler authority
verifier authority
verification evidence
runtime policy authority
PMSL semantics
PMS Base evidence
```

Correct:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

Incorrect:

```text
AI output verifies PMS-STACK.
```

### 11.15 PMS-RUST Does Not Prove PMS-STACK

PMS-RUST may strengthen PMS-STACK implementation-artifact claims.

It may show:

```text
operator programs can be represented

bounded programs can execute deterministically

model validation can reject invalid sequences

stateful validation can enforce selected invariants

JSONL traces can be emitted

golden fixtures can stabilize expected behavior

REPL/script tooling can expose developer workflows

AI proposals can be gated

chi_exit-style boundary-exit discipline can be evidenced where declared
```

It does not prove:

```text
PMS-STACK complete implementation

PMS-CPU complete implementation

PMS-CPU ISO_EXIT completion

PMS-OS complete implementation

PMS-OS isolation lifecycle completion

PMSL complete compiler

distributed runtime complete

PMS Base valid

all STACK claims externally validated
```

Correct:

```text
PMS-RUST strengthens implementation-artifact claims under declared scope.
```

Incorrect:

```text
PMS-RUST proves PMS-STACK.
```

### 11.16 PMS-RUST chi_exit Does Not Prove ISO_EXIT Completion

PMS-RUST `chi_exit` may evidence bounded runtime isolation-exit discipline.

PMS-CPU `ISO_EXIT` is the architecture-level virtual ISA instruction target.

Mapping:

```text
PMS-CPU ISO_EXIT
    architecture-level virtual ISA instruction for leaving a declared
    isolation or boundary context

PMS-RUST chi_exit
    artifact/runtime command or opcode-level behavior evidencing bounded
    runtime isolation-exit discipline
```

Validity rule:

```text
exit requires an active boundary context.
unbalanced exit is invalid.
```

Sealed isolation rule:

```text
sealed isolation forbids further entry, expansion, or reachability growth.

sealed isolation still permits valid exit, closure, rollback, audit, or
commit under the declared runtime profile and active boundary context.
```

Boundary:

```text
PMS-RUST chi_exit does not redefine PMS Base Χ.
PMS-RUST chi_exit does not complete PMS-CPU ISO_EXIT.
PMS-RUST chi_exit does not complete PMS-OS isolation.
PMS-RUST chi_exit does not validate PMS Base.
```

Correct:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile.
```

Incorrect:

```text
PMS-RUST chi_exit proves the PMS-CPU isolation model complete.
```

### 11.17 PMS-STACK Does Not Prove PMS Base

This is the highest-priority proof boundary.

PMS-STACK shows:

```text
given PMS Base operator grammar,
a complete implementation-layer systems architecture can be specified.
```

It does not show:

```text
PMS Base is final

PMS Base is empirically validated

PMS Base is uniquely adequate

PMS Base captures all praxis

PMS Base is externally confirmed

PMS Base is immune to rival theories

PMS Base has no non-capture cases
```

Correct:

```text
PMS-STACK strengthens PMS implementation-layer architecture claims.
```

Incorrect:

```text
PMS-STACK validates PMS Base.
```

### 11.18 Proof-Status Vocabulary

Use precise proof-status terms.

```text
specified
    defined in the architecture

sketched
    proof route or construction is described but not fully formalized

constructive
    explicit construction is given at design level

reduction-based
    mapping from known model is described

artifact-backed
    code/tests/traces/fixtures support a bounded implementation claim

trace-backed
    observed execution evidence exists for a declared profile

validator-backed
    validator checks declared constraints

validated-under-profile
    accepted or rejected by a declared validator, profile, gate, schema, or
    conformance rule; not PMS Base validation and not external validation

verified-under-model
    formal property checked or proven under stated model and assumptions

externally validated
    independent validation under external protocol

not claimed
    no claim is made
```

Avoid using:

```text
proven
validated
complete
secure
verified
production-ready
finished
universal
```

without object, model, scope, and boundary.

Careful wording rule:

```text
validated
    use only with explicit object and scope, e.g. validated under profile P
    by validator V; never use as shorthand for PMS Base validation.
```

### 11.19 What Is Not Proven — Matrix

| Statement | Correct status |
| --------- | -------------- |
| PMS-STACK specifies complete systems architecture | architecture claim |
| PMS-UM is Turing-complete | expressiveness / proof-sketch claim |
| PMS-CPU is defined | virtual CPU specification claim |
| PMS-OS is defined | OS architecture claim |
| PMSL/PMS-IR are defined | language/runtime specification claim |
| Security is operator-structured | security architecture claim |
| Security scenarios reject typed attacks | scenario / profile claim |
| Distributed commit is Σᴳ under Ψᴳ | distributed architecture claim |
| PMS-RUST executes bounded programs | implementation-artifact claim |
| PMS-RUST traces execution | trace evidence claim |
| PMS-RUST chi_exit rejects unbalanced exit where implemented | boundary-exit artifact claim |
| Tests pass | artifact-quality claim |
| Validators reject invalid cases | validated-under-profile / validator-backed claim |
| AI proposes candidate artifacts | AI/tooling proposal claim |
| PMS Base is validated | not claimed |
| All implementations are correct | not claimed |
| All deployments are secure | not claimed |
| Full formal verification exists | not claimed unless separate artifact exists |

### 11.20 Proof Boundary Invariants

```text
NP1: specification is not proof of implementation correctness

NP2: architecture completeness is not artifact completion

NP3: Turing-completeness is not OS/security/distributed correctness

NP4: expressibility is not full equivalence

NP5: security architecture is not universal security certification

NP6: security scenarios are not exhaustive attack proofs

NP7: governance is not tribunal, moral authority, legal authority, or clinical
     authority

NP8: distributed architecture is not distributed correctness proof

NP9: consensus profile is not consensus algorithm proof

NP10: tests are bounded evidence, not proof of all behavior

NP11: traces are recorded evidence, not proof of all behavior

NP12: validators enforce declared rules, not external adequacy

NP13: formal verification requires explicit model, property, proof artifact,
      assumptions, and scope

NP14: AI output is not trusted executable code, compiler authority, verifier
      authority, verification evidence, runtime policy authority, PMSL
      semantics, or PMS Base evidence

NP15: PMS-RUST does not prove PMS-STACK

NP16: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline;
      it does not complete PMS-CPU ISO_EXIT, complete PMS-OS isolation,
      redefine PMS Base Χ, or validate PMS Base

NP17: PMS-STACK does not validate PMS Base

NP18: trace(...) denotes one concrete execution; Trace(...) denotes a declared
      possible-execution set under profile

NP19: validated-under-profile means profile/gate/schema/conformance acceptance
      or rejection, not PMS Base validation or external validation
```

### 11.21 Boundary Statement

The correct proof boundary is:

```text
PMS-STACK makes strong architecture, expressiveness, mapping, security,
runtime, and distributed-systems claims. These claims are valid at their
declared layer.

They do not by themselves prove all implementations correct, all programs
safe, all policies adequate, all distributed profiles correct, all
artifacts complete, all AI outputs valid, or PMS Base validated.
```

---

## 12. Relation to Classical Frameworks

PMS-STACK is structurally continuous with classical computation, OS, VM, language, security, and distributed-systems frameworks.

It does not reject classical systems.

It re-expresses their core mechanisms through a unified operator grammar.

The central relation claim is:

```text
PMS-STACK can express classical computation, OS, VM, language, security,
and distributed-systems frameworks as specializations or projections of
Δ–Ψ; this is an expressibility and architecture-mapping claim, not a
claim of full implementation equivalence to every concrete classical
system.
```

Claim type:

```text
classical-framework relation / expressibility claim
```

Boundary:

```text
Classical mapping does not mean PMS-STACK is POSIX, JVM, WASM, seL4,
Linux, Raft, Paxos, CRDT, or any other concrete framework.
It means PMS-STACK can represent their structural obligations in
operator terms.
```

At PMS Base level:

```text
Χ = Distance
```

At implementation layers, classical isolation, sandboxing, namespace boundaries, host boundaries, process separation, and cross-node reachability are projections of Χ.

They do not redefine PMS Base Χ.

### 12.1 Classical Computation

PMS-STACK can express classical computation models.

Examples:

```text
deterministic Turing machines
nondeterministic Turing machines
register machines
Minsky machines
pushdown automata
lambda-calculus-like evaluation
actor models
imperative computation
functional computation
transactional computation
```

Operator reading:

```text
state distinction        → Δ
state update             → ∇
machine configuration    → □
branch / jump            → Δ + Φ
progression              → Θ
memory write             → ∇ + Σ
absence / wait           → Λ
macro / loop pattern     → Α
policy or invariant      → Ψ
```

Claim type:

```text
computational expressibility claim
```

Boundary:

```text
Expressing a model does not automatically provide optimized runtime,
compiler, proof environment, or compatibility with every classical tool.
```

### 12.2 Turing Machines and Register Machines

A Turing or register-machine instruction language can be mapped into PMS operator words.

Sketch form:

```text
h : Instr* → O*
```

Mappings:

```text
increment / decrement
    → ∇ update + Σ commit

conditional branch
    → Δ distinction + Φ recontextualization

program counter
    → Θ progression + □ frame/context

halt
    → terminal Σ or declared final state
```

Claim type:

```text
reduction / embedding claim
```

Boundary:

```text
This supports computational universality.
It does not imply OS or security correctness.
```

### 12.3 Unix/POSIX Relation

PMS-STACK can represent POSIX-like concepts.

| POSIX concept | PMS-STACK projection |
| ------------- | -------------------- |
| process | `□` frame + Χ-projected boundary + `Ω` role |
| effective UID/GID | `Ω` role/capability state |
| file descriptor | `Δ` distinguished handle inside `□` frame |
| permissions | `Ψ` policy over `∇` operations |
| signal | `Φ` trap/recontextualization |
| pipe/socket | `□` channel/session frame with `Δ/Ω/Θ/Λ/Σ/Ψ` semantics |
| namespace | `Χ` implementation projection of Distance |
| `select`/`epoll` | `Θ` wait/probe + `Λ` timeout |
| `fsync`/commit | `Σ` integration |

Claim type:

```text
OS expressibility / projection claim
```

Boundary:

```text
PMS-STACK is not a POSIX reimplementation.
POSIX compatibility would require a separate compatibility profile and
artifact evidence.
```

### 12.4 Microkernel Relation

PMS-STACK can express microkernel concepts.

| Microkernel concept | PMS-STACK projection |
| ------------------- | -------------------- |
| minimal kernel | restricted privileged `□` frame |
| capability | `Ω` authority structure |
| IPC | `Δ` message + `Ω` authority + `Θ` order + `Σ` delivery |
| user-space service | service `□` frame |
| fault isolation | `Χ` boundary + `Φ` trap |
| policy | `Ψ` invariant |
| scheduling | `Θ` ordering |

Claim type:

```text
microkernel expressibility / architecture relation claim
```

Boundary:

```text
PMS-STACK is not a classical microkernel claim.
It can host or express microkernel-like profiles.
```

### 12.5 Monolithic and Hybrid Kernel Relation

PMS-STACK can express monolithic and hybrid designs.

A monolithic profile may use:

```text
large privileged kernel frame
internal subsystem frames
shared kernel address domain
Ω kernel roles
Ψ internal policies
Χ internal boundaries where declared
Σ subsystem commits
Φ trap/fault handling
Θ scheduler and interrupt order
```

A hybrid profile may combine:

```text
kernel services
user-space services
capability IPC
host runtime services
driver frames
```

Claim type:

```text
kernel-family expressibility claim
```

Boundary:

```text
PMS-STACK does not require one classical kernel family.
```

### 12.6 Virtual Machine Relation

PMS-STACK can express VM/runtime concepts.

| VM concept | PMS-STACK projection |
| ---------- | -------------------- |
| bytecode | operator word / PMS-IR form |
| stack frame | `□` execution frame |
| method invocation | `Δ` distinction + `∇` evaluation + `Θ` order |
| sandbox | `Χ` boundary + `Ψ` policy |
| runtime check | `Ψ` validation |
| exception | `Φ` recontextualization |
| host call | `Φ` host boundary + `Ω` authority + `Ψ` policy + `Σ` accepted result |

Claim type:

```text
VM/runtime expressibility claim
```

Boundary:

```text
PMSL is not merely another VM.
It defines semantic structure into which VM-like systems can be mapped.
```

A PMS-RUST runtime slice may look VM-like.

Its correct claim type remains bounded executable PMS-STACK evidence, not generic VM completion.

### 12.7 WASM Relation

WASM is a useful comparison because it has clear module, memory, and host boundaries.

| WASM concept | PMS-STACK projection |
| ------------ | -------------------- |
| module | `□` frame |
| linear memory | `□` memory frame + `Χ` boundary |
| import/export | `Ω` authority + `Ψ` policy |
| host function | `Φ` host recontextualization |
| validation | `Ψ` check |
| instruction execution | `Δ/∇/Θ` |
| result stabilization | `Σ` |

Claim type:

```text
VM/sandbox expressibility claim
```

Boundary:

```text
PMS-STACK can represent WASM-like structures.
It is not identical to WASM and does not claim WASM compatibility without
a compatibility profile.
```

Host functions, FFI calls, and AI/tooling calls remain boundary-mediated.

They are not automatically PMS operator execution.

### 12.8 Actor Model Relation

Actor systems can be represented through:

```text
actor identity       → Δ
actor mailbox        → □
message              → Δ message distinction
send                 → ∇ send + Θ order
receive              → Θ receive + Λ no-message
actor state update   → ∇ + Σ
supervision          → Ω/Ψ/Φ
actor isolation      → Χ
```

Claim type:

```text
actor-model expressibility claim
```

Boundary:

```text
Expressing actor semantics does not make every actor framework
PMS-STACK-conformant without explicit mapping.
```

### 12.9 Language Theory Relation

PMS-STACK can represent multiple language styles.

```text
imperative
functional
transactional
capability-secured
event-driven
concurrent
policy-aware
sandboxed
```

Examples:

```text
variable binding      → Δ
expression evaluation → ∇
function scope        → □
effect typing         → Ψ / Ω / Χ / Σ obligations
exception handling    → Φ
sequencing            → Θ
commit block          → Σ
timeout branch        → Λ
```

Claim type:

```text
language expressibility / PMSL architecture claim
```

Boundary:

```text
PMSL specification does not automatically implement all language styles
as compiler features.
```

AI may propose PMS-IR candidates or opcode programs.

AI output is not PMSL semantics, compiler authority, verifier authority, verification evidence, or trusted executable code.

### 12.10 Security Framework Relation

PMS-STACK can express classical security frameworks.

Examples:

```text
RBAC
ABAC
capability systems
MAC
sandboxing
namespaces
containers
seccomp-like filters
audit logs
policy engines
trust anchors
```

Operator projection:

```text
RBAC / roles          → Ω
attributes            → Δ + Ψ
capabilities          → Ω edges
MAC                   → Ψ mandatory constraints
sandbox               → Χ boundary
namespace             → □ + Χ
filter                → Ψ
audit                 → Θ + Σ event records
trust anchor          → Δ + Ψ + Ω + Σ
boundary exit         → ISO_EXIT at PMS-CPU architecture level, chi_exit as
                         bounded PMS-RUST runtime evidence where declared
```

Claim type:

```text
security-framework expressibility claim
```

Boundary:

```text
Expressing security frameworks does not certify PMS-STACK deployments or
prove external adequacy of policies.
```

`chi_exit` evidence may support bounded runtime isolation-exit discipline.

It does not complete PMS-CPU ISO_EXIT, complete PMS-OS isolation, redefine PMS Base Χ, or validate PMS Base.

### 12.11 Distributed Systems Relation

PMS-STACK can express distributed-system frameworks.

Examples:

```text
Paxos
Raft
2PC
3PC
state-machine replication
leader election
CRDT-like merge profiles
eventual consistency
strong consistency
quorum systems
federated trust
```

Operator projection:

```text
proposal               → Δᴳ
participant role       → Ωᴳ
ordering / term        → Θᴳ
vote / acknowledgement → ∇ᴳ / Σᵢ
quorum policy          → Ψᴳ
global commit          → Σᴳ
no quorum              → Λᴳ
failover               → Φᴳ
partition boundary     → Χᴳ
```

Claim type:

```text
distributed-framework expressibility claim
```

Boundary:

```text
PMS-STACK does not prove those algorithms correct merely by mapping them.
Algorithm correctness requires algorithm-specific proof or verification.
```

The superscript `ᴳ` marks distributed or cluster-frame scope.

It does not introduce new PMS Base operators.

Local `Σᵢ` success does not imply global `Σᴳ` success unless the declared distributed commit profile establishes that relation.

### 12.12 Classical Frameworks as Specializations

The correct relation is:

```text
classical framework
    → specialization / projection / embedding inside PMS-STACK
```

not:

```text
classical framework
    = PMS-STACK in all details
```

PMS-STACK uses classical models as:

```text
orientation aids
embedding targets
migration paths
compatibility-profile candidates
implementation references
stress tests
```

It does not subordinate itself to any single classical framework.

### 12.13 Classical Trace Boundary

Classical framework projections may be supported by traces.

A concrete artifact execution produces:

```text
trace(artifact, profile, input) ∈ L_PMS
```

The set of possible executions is:

```text
Trace(artifact, profile) ⊆ L_PMS
```

For distributed profiles:

```text
traceᴳ(D, profile, input) ∈ L_PMS

Traceᴳ(D, profile) ⊆ L_PMS
```

Boundary:

```text
A recorded trace supports observed behavior under a profile.

It does not prove full equivalence to a classical framework and does not
enumerate the whole Trace(...) or Traceᴳ(...) set.
```

### 12.14 Classical Framework Boundary Matrix

| Classical framework | PMS-STACK relation | Boundary |
| ------------------- | ------------------ | -------- |
| Turing machine | computational embedding | not OS correctness |
| register machine | reduction target | not hardware implementation |
| POSIX | projection/migration target | not POSIX clone |
| microkernel | expressible profile | not classical microkernel claim |
| monolithic kernel | expressible profile | not required design |
| JVM/CLR | VM-like mapping | not merely another VM |
| WASM | sandbox/module mapping | not WASM compatibility |
| actor model | message/frame mapping | not every actor runtime |
| RBAC/ABAC/MAC | security projection | not security certification |
| ISO_EXIT / chi_exit | boundary-exit relation | runtime evidence is not ISA completion |
| Paxos/Raft | consensus-profile mapping | not algorithm proof |
| CRDT | merge-profile mapping | not convergence proof by mapping |

### 12.15 PMS-RUST Relation to Classical Frameworks

PMS-RUST may look like classical artifacts in places.

It may resemble:

```text
small VM
script runner
REPL
runtime kernel
trace tool
validation harness
vFS service
test fixture suite
AI proposal bridge
```

Correct relation:

```text
PMS-RUST is a bounded executable PMS-STACK Evidence Spine.
```

Not:

```text
generic VM
finished OS
finished CPU
finished compiler
formal proof system
external validation package
trusted AI execution environment
```

PMS-RUST may support classical mapping work by providing:

```text
operator execution
validation
traces
fixtures
host-service boundary
AI proposal gating
chi_exit boundary-exit evidence where declared
```

Boundary:

```text
classical resemblance does not define PMS-RUST's claim type.
```

### 12.16 Classical Relation Invariants

```text
CR1: PMS-STACK is continuous with classical computing frameworks

CR2: PMS-STACK generalizes classical mechanisms through Δ–Ψ

CR3: classical frameworks appear as projections, embeddings, or
     specializations

CR4: expressibility is not full implementation equivalence

CR5: POSIX projection is not POSIX reimplementation

CR6: microkernel projection is not classical microkernel identity

CR7: VM projection is not “merely another VM”

CR8: security-framework projection is not security certification

CR9: distributed-framework projection is not algorithm proof

CR10: PMS-RUST resemblance to VM/runtime tooling does not determine its
      architecture claim

CR11: classical comparisons orient readers; they do not validate PMS Base

CR12: classical mappings strengthen PMS-STACK architecture claims, not PMS
      Base validation claims

CR13: trace(...) denotes concrete execution evidence; Trace(...) denotes a
      declared possible-execution set under profile

CR14: PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline;
      it does not complete PMS-CPU ISO_EXIT, complete PMS-OS isolation,
      redefine PMS Base Χ, or validate PMS Base

CR15: AI output is not compiler authority, verifier authority, verification
      evidence, PMSL semantics, trusted executable code, runtime policy
      authority, or PMS Base evidence
```

### 12.17 Boundary Statement

The correct classical-framework boundary is:

```text
PMS-STACK does not stand outside classical computer science. It gives a
single operator-grounded architecture in which classical computation,
OS, VM, language, security, and distributed-systems frameworks can be
represented as projections or specializations.

This is an expressibility and architecture relation.

It is not implementation identity, compatibility certification, algorithm
proof, security certification, trusted AI execution, boundary-exit
completion, or PMS Base validation.
```

---

## 13. Safe Wording Rules for PMS-STACK

This section gives wording rules for writing about PMS-STACK without weakening it or overstating it.

The central wording rule is:

```text
Write strong claims, type them explicitly, and state the boundary.
```

Use:

```text
PMS-STACK defines...
PMS-STACK specifies...
PMS-STACK derives...
PMS-STACK treats...
PMS-STACK projects...
PMS-STACK provides an architecture for...
PMS-RUST strengthens implementation-artifact claims...
```

Avoid:

```text
PMS-STACK proves...
PMS-RUST validates...
tests prove...
traces prove...
finished OS...
fabricated CPU...
complete compiler...
universal security...
trusted AI execution...
```

unless the precise claim object, proof artifact, implementation artifact, validation protocol, model, or scope exists.

### 13.1 Canonical Claim Pattern

Use the pattern:

```text
claim
claim type
boundary
```

Example:

```text
Claim:
    PMS-STACK specifies PMS-CPU as a virtual CPU / ISA architecture.

Claim type:
    implementation-layer architecture claim.

Boundary:
    This does not assert fabricated hardware, completed emulator,
    completed compiler backend, hardware verification, or PMS Base validation.
```

Example:

```text
Claim:
    PMS-RUST executes bounded operator programs and emits JSONL traces.

Claim type:
    implementation-artifact claim.

Boundary:
    This strengthens bounded runtime evidence. It does not complete
    PMS-STACK or validate PMS Base.
```

Example:

```text
Claim:
    PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
    under a declared profile.

Claim type:
    implementation-artifact / boundary-exit evidence claim.

Boundary:
    This does not redefine PMS Base Χ, complete PMS-CPU ISO_EXIT, complete
    PMS-OS isolation, or validate PMS Base.
```

### 13.2 Preferred Global Wording

Preferred:

```text
PMS-STACK is the implementation-layer architecture specification of PMS:
a complete systems architecture deriving CPU, OS, runtime, language,
security, networking, distributed systems, simulation, verification, boot,
and cluster profiles from Δ–Ψ.
```

Then immediately type:

```text
This is an architecture/specification claim.
```

Then boundary:

```text
It does not claim completed implementation of every layer and does not
function as PMS Base validation.
```

Preferred final relation:

```text
PMS-STACK specifies.
Artifacts evidence.
Tests inspect.
Traces record.
Validators accept or reject under declared profiles.
Formal proofs prove stated properties under models.
External validation validates under external protocols.
PMS Base remains the source of operator identity.
AI proposes.
Host validates.
Runtime/kernel executes accepted artifacts.
```

### 13.3 Preferred PMS-CPU Wording

Use:

```text
PMS-CPU is a virtual CPU / ISA architecture derived from PMS-UM and
operator-typed Δ–Ψ execution.
```

Use:

```text
PMS-CPU specifies processor-state, instruction, privilege, trap, boundary,
commit, and policy semantics.
```

Use:

```text
PMS-CPU ISO_EXIT is the architecture-level virtual ISA instruction for
leaving a declared isolation or boundary context.
```

Avoid:

```text
PMS-CPU is a fabricated hardware CPU.
```

Avoid:

```text
PMS-CPU hardware is complete.
```

Avoid:

```text
PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

unless the claim is backed by actual hardware, ISA, emulator, validator, fixture, trace, and conformance artifacts under declared scope.

### 13.4 Preferred PMS-OS Wording

Use:

```text
PMS-OS is an operator-typed operating-system architecture in which kernel,
process, memory, syscall, scheduling, IPC, storage, driver, security,
and audit mechanisms are represented through Δ–Ψ.
```

Use:

```text
PMS-OS specifies the OS architecture.
```

Use:

```text
IDom_user, IDom_global, X_user, X_global, and comparable OS examples name
OS-level isolation-domain values, not the PMS Base operator Χ.
```

Avoid:

```text
PMS-OS is already a production operating system.
```

Avoid:

```text
PMS-OS is POSIX.
```

Preferred boundary:

```text
PMS-OS is not a POSIX reimplementation claim; POSIX-like concepts can be
projected into PMS-OS structures.
```

### 13.5 Preferred PMSL/PMS-IR Wording

Use:

```text
PMSL specifies the language-level expression of Δ–Ψ.

PMS-IR specifies an operator-preserving intermediate representation for
analysis, lowering, runtime execution, tracing, simulation, and verification.
```

Use:

```text
PMS-RUST strengthens bounded PMS-IR construction-path claims through
builder/script/opcode artifacts where present.
```

Avoid:

```text
PMSL compiler is complete.
```

Avoid:

```text
The builder is the full language.
```

Avoid:

```text
The REPL is PMSL.
```

Avoid:

```text
AI output is PMSL semantics.
```

### 13.6 Preferred Runtime Wording

Use:

```text
Runtime behavior is profile-specific.
```

Use:

```text
This claim holds under the declared runtime profile.
```

Use:

```text
The runtime mediates validation, execution, tracing, host boundaries,
commit, and policy enforcement under its profile.
```

Use:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared artifact profile.
```

Avoid:

```text
The runtime proves PMS.
```

Avoid:

```text
Behavior under one profile holds for all PMS-STACK profiles.
```

Avoid:

```text
A runtime command redefines PMS Base operator identity.
```

### 13.7 Preferred Security Wording

Use:

```text
PMS-STACK specifies security as operator-governed runtime structure.
```

Use:

```text
Security-relevant transitions are Δ-distinguished, Ω-authorized,
□-framed, Χ-bounded, Ψ-constrained, Θ-ordered where relevant,
Φ-recontextualized on failure, and Σ-committed when stable.
```

Use:

```text
Security scenarios define expected structural responses to typed attack
attempts.
```

Use:

```text
Boundary-exit discipline is valid only under an active boundary context;
unbalanced exit is invalid.
```

Avoid:

```text
PMS-STACK is proven secure.
```

Avoid:

```text
PMS-STACK prevents all attacks.
```

Avoid:

```text
Audit proves compliance.
```

Avoid:

```text
Quarantine proves malicious intent.
```

### 13.8 Preferred Governance Wording

Use:

```text
Governance in PMS-STACK means runtime policy discipline.
```

Use:

```text
Policy updates, trust-anchor updates, role changes, quarantine, rollback,
and audit are operator-typed runtime transitions.
```

Avoid:

```text
Governance is tribunal.
```

Avoid:

```text
PMS-STACK judges people.
```

Avoid:

```text
Quarantine proves malicious intent.
```

### 13.9 Preferred Distributed Wording

Use:

```text
Distributed PMS-STACK is semantic scaling of local PMS-STACK across node,
session, route, service, shard, replica, cluster, and federation frames.
```

Use:

```text
Σᴳ is global commit under Ψᴳ policy.
```

Use:

```text
Consensus mechanisms are implementation profiles for satisfying Ψᴳ so
that Σᴳ may commit.
```

Use:

```text
The superscript ᴳ marks distributed or cluster-frame scope; it does not
introduce new PMS Base operators.
```

Use:

```text
Σᵢ success does not imply Σᴳ success unless the declared distributed
commit profile establishes that relation.
```

Avoid:

```text
PMS-STACK mandates Raft.
```

Avoid:

```text
PMS-STACK proves consensus correctness.
```

Avoid:

```text
Every PMS-STACK runtime is clustered.
```

### 13.10 Preferred PMS-RUST Wording

Use:

```text
PMS-RUST is a bounded executable PMS-STACK Evidence Spine v0.1.
```

Use:

```text
PMS-RUST strengthens implementation-artifact claims for bounded operator
representation, validation, deterministic execution, traces, fixtures,
REPL/script tooling, vFS service surface, boundary-exit discipline where
declared, and AI proposal boundaries.
```

Use:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile.
It does not redefine PMS Base Χ, complete PMS-CPU ISO_EXIT, complete
PMS-OS isolation, or validate PMS Base.
```

Avoid:

```text
PMS-RUST validates PMS Base.
```

Avoid:

```text
PMS-RUST completes PMS-STACK.
```

Avoid:

```text
PMS-RUST is full PMS-OS / PMS-CPU / PMSL / distributed PMS runtime.
```

Avoid:

```text
PMS-RUST chi_exit completes PMS-CPU ISO_EXIT.
```

### 13.11 Preferred Test and Trace Wording

Use:

```text
Tests strengthen bounded artifact-quality claims.
```

Use:

```text
Traces make execution inspectable under declared profile.
```

Use:

```text
Golden fixtures stabilize known expected behavior.
```

Use:

```text
trace(artifact, profile, input) ∈ L_PMS
```

Use under active policy:

```text
trace(artifact, profile, input) ∈ L_PMS,Ψ
```

Use for possible execution sets:

```text
Trace(artifact, profile) ⊆ L_PMS
```

Use under active policy:

```text
Trace(artifact, profile) ⊆ L_PMS,Ψ
```

Boundary:

```text
A recorded trace usually evidences one concrete trace(...).

It does not by itself enumerate or prove the whole Trace(...) set.
```

Avoid:

```text
Tests prove PMS.
```

Avoid:

```text
Traces validate PMS Base.
```

Avoid:

```text
Fixture coverage implies universal correctness.
```

### 13.12 Preferred Formal Wording

Use:

```text
This property is specified.
```

Use:

```text
This property is sketched via constructive/reduction route.
```

Use:

```text
This property is verified under model M with assumptions A.
```

Use:

```text
This claim is artifact-backed under profile P.
```

Use:

```text
This artifact is validated under profile P by validator V.
```

Avoid:

```text
formally proven
```

unless a proof artifact, model, property, assumptions, and scope are supplied.

Avoid:

```text
validated
```

unless a validation protocol and scope are supplied.

Preferred definition:

```text
validated-under-profile
    accepted or rejected by a declared validator, profile, gate, schema, or
    conformance rule; not PMS Base validation and not external validation
```

### 13.13 Preferred Classical-Framework Wording

Use:

```text
PMS-STACK can express POSIX-like, microkernel, VM, WASM-like, actor-model,
security-framework, and distributed-framework structures as operator
projections or specializations.
```

Use:

```text
Classical comparisons orient readers and show structural continuity.
```

Avoid:

```text
PMS-STACK is POSIX.
```

Avoid:

```text
PMS-STACK is merely a VM.
```

Avoid:

```text
PMS-STACK proves Raft/Paxos/CRDTs.
```

### 13.14 Preferred Χ / Chi Wording

Use:

```text
PMS Base 1.3 defines Χ as Distance.
```

Use:

```text
PMS-STACK projects Χ at implementation layers as boundary, isolation,
reachability control, namespace separation, sandboxing, containment,
quarantine, and trust-domain separation.
```

Use:

```text
PMS-RUST v0.1 Chi / Χ behavior is an implementation-layer boundary or
isolation projection.
```

Avoid:

```text
PMS-RUST redefines PMS Base Χ.
```

Avoid:

```text
Χ means isolation at PMS Base level.
```

Preferred boundary:

```text
Isolation is a layer projection of PMS Base Χ = Distance.
It is not a new base operator.
```

### 13.15 Preferred AI / Tooling Wording

Use:

```text
AI proposes.
Host validates.
Runtime/kernel executes only accepted artifacts.
Policy remains Ψ-governed.
```

Use:

```text
AI/tooling may propose PMS-IR candidates, opcode programs, scenarios,
diagnostic summaries, trace explanations, and fixture drafts.
```

Avoid:

```text
AI output is trusted executable code.
AI output is compiler authority.
AI output is verifier authority.
AI output is verification evidence.
AI output is PMSL semantics.
AI output is runtime policy authority.
AI output is PMS Base evidence.
```

Preferred boundary:

```text
AI-assisted tooling strengthens proposal, drafting, diagnostic, and
observability workflows.
It does not become execution authority, compiler authority, verifier
authority, verification evidence, or PMS Base validation.
```

### 13.16 Words to Use Carefully

Use these words only with object and scope:

```text
complete
proven
validated
verified
secure
finished
universal
formal
implementation-ready
production-ready
equivalent
```

Examples:

```text
complete architecture specification
```

is acceptable.

```text
complete implementation
```

requires artifact evidence.

```text
verified under model M
```

is acceptable when proof/check exists.

```text
verified system
```

is too broad without scope.

```text
validated under profile P by validator V
```

is acceptable.

```text
validated PMS Base
```

is not claimed by PMS-STACK or PMS-RUST.

### 13.17 Safe Replacement Patterns

Instead of:

```text
PMS-STACK proves all computation.
```

Use:

```text
PMS-STACK specifies an operator-grounded universal operational semantics
for computing systems.
```

Instead of:

```text
PMS-STACK is a complete OS.
```

Use:

```text
PMS-STACK specifies PMS-OS as a complete operating-system architecture.
```

Instead of:

```text
PMS-RUST validates PMS.
```

Use:

```text
PMS-RUST strengthens bounded PMS-STACK implementation-artifact claims.
```

Instead of:

```text
The trace proves correctness.
```

Use:

```text
The trace makes this execution inspectable under the declared runtime
profile.
```

Instead of:

```text
PMS security is proven.
```

Use:

```text
PMS-STACK specifies security as operator-constrained runtime structure;
implementation and verification claims require artifacts, models, and
scope.
```

Instead of:

```text
AI generated valid PMS code.
```

Use:

```text
AI proposed a candidate artifact. Host tooling validated it under the
declared profile before runtime/kernel execution.
```

Instead of:

```text
chi_exit implements ISO_EXIT.
```

Use:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile. PMS-CPU ISO_EXIT remains the architecture-level
instruction target.
```

### 13.18 Claim Review Checklist

Before accepting a PMS-STACK sentence, ask:

```text
1. What is the claim object?

2. What is the claim type?

3. Which layer does it belong to?

4. Is this specification, implementation, artifact evidence, proof,
   validation, or roadmap?

5. Does the sentence imply completed implementation?

6. Does the sentence imply PMS Base validation?

7. Does the sentence imply universal security?

8. Does the sentence imply external validation?

9. Does the sentence confuse trace/test evidence with proof?

10. Does the sentence confuse runtime dialect with PMS Base?

11. Does the sentence need a profile boundary?

12. Does the sentence need artifact evidence?

13. Does the sentence preserve Χ = Distance at PMS Base level?

14. Does the sentence avoid tribunal/person-ranking/clinical/moral/legal
    drift?

15. Does the sentence distinguish PMS-RUST chi_exit from PMS-CPU ISO_EXIT?

16. Does the sentence require active boundary context for boundary exit?

17. Does the sentence treat unbalanced exit as invalid?

18. Does the sentence distinguish sealed isolation from trapped execution?

19. Does the sentence avoid treating AI output as compiler authority,
    verifier authority, verification evidence, trusted executable code, or
    PMS Base evidence?

20. Does the sentence distinguish roadmap from implemented evidence?

21. Can the claim be written as:
        strong claim → claim type → boundary?
```

### 13.19 Final Safe Wording Template

Use this template throughout PMS-STACK documentation:

```text
PMS-STACK [defines/specifies/derives/treats] X as Y.

This is a [claim type] claim.

It strengthens [architecture / implementation / artifact / verification]
status for [scope].

It does not [boundary].
```

Example:

```text
PMS-STACK specifies distributed commit as Σᴳ under Ψᴳ global policy.

This is a distributed-systems architecture claim.

It strengthens the claim that cluster commit, quorum, membership, policy,
and audit can be represented within the Δ–Ψ implementation architecture.

It does not mandate a specific consensus algorithm, prove all distributed
profiles correct, complete a distributed runtime, or validate PMS Base.
```

Example:

```text
PMS-RUST chi_exit may evidence bounded runtime isolation-exit discipline
under a declared profile.

This is an implementation-artifact / boundary-exit evidence claim.

It strengthens the PMS-RUST evidence-spine relation to PMS-STACK runtime
security and PMS-CPU ISO_EXIT architecture planning.

It does not redefine PMS Base Χ, complete PMS-CPU ISO_EXIT, complete
PMS-OS isolation, or validate PMS Base.
```

### 13.20 Safe Wording Invariants

```text
SWR1: write strong claims

SWR2: type every strong claim

SWR3: state the boundary

SWR4: distinguish architecture completeness from implementation completion

SWR5: distinguish expressibility from equivalence

SWR6: distinguish tests/traces from proof

SWR7: distinguish validation under profile from PMS Base validation

SWR8: distinguish runtime dialect from PMS Base operator identity

SWR9: distinguish security architecture from security certification

SWR10: distinguish governance from tribunal authority

SWR11: distinguish distributed architecture from distributed correctness proof

SWR12: distinguish PMS-RUST evidence from PMS-STACK completion

SWR13: preserve PMS Base Χ = Distance and mark implementation projections

SWR14: avoid proof, validation, completeness, security, and equivalence words
       without object and scope

SWR15: prefer positive boundaries over apologetic weakening

SWR16: distinguish PMS-RUST chi_exit from PMS-CPU ISO_EXIT and PMS Base Χ;
       chi_exit evidences bounded runtime boundary-exit discipline only
       under a declared artifact profile

SWR17: boundary exit requires active boundary context; unbalanced exit is
       invalid under declared boundary-exit profiles

SWR18: sealed isolation forbids entry, expansion, and reachability growth,
       while still permitting valid exit, closure, rollback, audit, or commit
       under declared policy and active boundary context

SWR19: AI output is not compiler authority, verifier authority, verification
       evidence, trusted executable code, PMSL semantics, runtime policy
       authority, or PMS Base evidence

SWR20: trace(...) denotes a concrete execution; Trace(...) denotes a declared
       possible-execution set under profile

SWR21: roadmap identifies implementation pressure; it is not implemented
       evidence
```

### 13.21 Final Boundary Statement

The final wording rule is:

```text
PMS-STACK should be written with maximum architectural confidence and
maximum claim precision.
```

The acceptable final form is:

```text
strong architecture
typed claim
clear boundary
artifact-aware implementation status
proof-aware formal language
trace-aware evidence language
profile-aware validation language
AI-aware trust boundary
clear chi_exit / ISO_EXIT mapping
no PMS Base validation drift
```

This completes the purpose of `09_non_goals_and_claim_boundary.md`:

```text
PMS-STACK remains ambitious.
PMS-STACK remains scientific.
PMS-STACK remains implementation-oriented.
PMS-STACK remains claim-disciplined.
```
