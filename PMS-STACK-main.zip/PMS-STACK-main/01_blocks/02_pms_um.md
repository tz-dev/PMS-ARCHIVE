---
document_id: PMS-STACK-DOC-02
title: "PMS Universal Machine"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "abstract-machine / implementation-layer architecture claim"
pms_base_status: "source of Δ–Ψ operator identity"
stack_status: "abstract-machine specification layer of PMS-STACK"
chi_status: "PMS Base 1.3 Χ = Distance; PMS-UM projects Χ as abstract-machine boundary and reachability discipline"
depends_on:
  - "01_architecture.md"
links_forward_to:
  - "03_pms_cpu.md"
  - "04_pms_os.md"
  - "05_pmsl_pms_ir.md"
  - "08_relation_to_pms_rust.md"
  - "09_non_goals_and_claim_boundary.md"
---

# PMS Universal Machine

## 1. Role of PMS-UM in PMS-STACK

PMS-UM is the abstract machine model of PMS-STACK.

It is the first computational layer in which the Δ–Ψ operator grammar becomes executable as a state-transition system at the abstract-machine level. PMS-UM does not yet specify a virtual CPU, kernel, filesystem, driver model, runtime, programming language, network stack, or distributed protocol. It defines the operator-typed abstract machine substrate from which those later layers are projected.

The central role of PMS-UM is:

```text
PMS Base Δ–Ψ operator grammar
    ↓
01_architecture.md validity, state, transition, and homomorphism model
    ↓
PMS-UM abstract machine
    ↓
PMS-CPU / PMS-OS / PMSL / PMS-IR / runtime security / network /
distributed projections
```

PMS-UM therefore occupies a precise position in the PMS-STACK architecture:

```text
PMS Base
    defines operator identity

01_architecture.md
    defines the shared PMS-STACK architecture grammar

02_pms_um.md
    defines the first abstract-machine execution layer over that grammar

03–07
    specialize PMS-UM into virtual CPU, OS, language/runtime,
    security, network, and distributed profiles

08
    relates bounded executable artifacts to the architecture

09
    governs non-goals and claim boundaries
```

The primary PMS-UM claim is:

```text
PMS-UM is the abstract-machine specification of PMS-STACK: a
dependency-constrained, operator-typed transition system over the Δ–Ψ
grammar.
```

Claim type:

```text
abstract-machine / implementation-layer architecture claim
```

Boundary:

```text
PMS-UM strengthens the PMS-STACK architecture claim by defining its
abstract execution substrate.

It does not validate PMS Base.

It does not imply that PMS-CPU, PMS-OS, PMSL, PMS-RUST, or distributed
PMS-STACK are complete implementations.
```

### 1.1 PMS-UM as the First Machine-Level Execution Projection

PMS-STACK begins with the operator grammar:

```text
Δ → ∇ → □ → Λ → Α → Ω → Θ → Φ → Χ → Σ → Ψ
```

`01_architecture.md` defines the shared architecture around this grammar:

```text
operator identity
valid operator language
dependency constraints
state/configuration/transition semantics
cross-layer homomorphisms
architectural invariants
claim boundaries
```

PMS-UM takes that architecture and gives it a machine form.

The machine form consists of:

```text
state
configuration
operator-typed instruction
program
transition relation
trace
Trace set
halting / stuck / policy-denied conditions
deterministic and nondeterministic execution modes
```

This is the first point in the modular PMS-STACK specification where Δ–Ψ becomes executable as abstract-machine behavior.

PMS-UM is therefore not a metaphorical machine.

It is the abstract machine layer of the stack.

It is executable in the architecture sense:

```text
operator words become machine-level transition rules
```

not in the artifact-completion sense:

```text
a completed runtime, simulator, VM, CPU, OS, or compiler already exists
```

### 1.2 PMS-UM Is Not PMS-CPU

PMS-UM is more abstract than PMS-CPU.

PMS-UM defines:

```text
operator-typed state transitions
abstract machine state
operator-tagged instructions
dependency-constrained execution
valid trace language
deterministic and nondeterministic step semantics
```

PMS-CPU later defines:

```text
virtual register model
virtual memory model
ISA instruction families
calling conventions
interrupt/trap behavior
binary encoding
fetch/decode/execute cycle
memory consistency
```

The relation is:

```text
PMS-UM
    abstract operator machine

PMS-CPU
    virtual CPU / ISA projection of PMS-UM
```

Correct:

```text
PMS-CPU refines PMS-UM into a virtual processor architecture.
```

Incorrect:

```text
PMS-UM is already the PMS-CPU.
```

### 1.3 PMS-UM Is Not PMS-OS

PMS-UM is also more abstract than PMS-OS.

PMS-UM does not specify:

```text
process table
scheduler queues
syscall ABI
kernel/user mode
filesystem structures
IPC queues
device lifecycle
driver model
kernel audit subsystem
```

Those belong to `04_pms_os.md`.

PMS-UM provides the abstract transition substrate that PMS-OS later specializes into kernel transitions.

The relation is:

```text
PMS-UM transition
    ↓
PMS-OS kernel transition
```

Example:

```text
PMS-UM:
    Δ object distinction
    Ω role check
    Ψ policy check
    ∇ abstract action
    Σ commit

PMS-OS:
    Δ syscall/file/process distinction
    Ω credential/capability check
    Ψ kernel policy check
    ∇ resource mutation
    Σ syscall return / filesystem commit / IPC delivery
```

Correct:

```text
PMS-OS is an operator-typed operating-system architecture refined from
the PMS-UM transition model.
```

Incorrect:

```text
PMS-UM is already an implemented operating system.
```

### 1.4 PMS-UM Is Not PMSL or PMS-IR

PMS-UM is not a programming language.

It does not define:

```text
PMSL source syntax
type system
module system
standard library
compiler pipeline
IR optimizer
source-level diagnostics
package system
```

Those belong to `05_pmsl_pms_ir.md`.

PMS-UM defines the abstract machine that PMSL and PMS-IR target, preserve, analyze, simulate, or lower into.

The relation is:

```text
PMSL source
    ↓
PMS-IR
    ↓
PMS-UM / PMS-CPU / PMS-OS / runtime targets
```

PMSL is the language-level expression of Δ–Ψ.

PMS-UM is the abstract-machine execution substrate of Δ–Ψ.

They are related but not identical.

### 1.5 PMS-UM and Operator-Typed Execution

The defining property of PMS-UM is operator-typed execution.

A PMS-UM instruction is not an opaque command.

It carries an operator tag:

```text
op ∈ O
```

where:

```text
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The operator tag determines the structural family of the transition.

| Operator | PMS-UM transition family                               |
| -------- | ------------------------------------------------------ |
| Δ        | distinction, classification, branch, read/compare      |
| ∇        | action, mutation, write, update                        |
| □        | frame establishment or context switch                  |
| Λ        | absence, timeout, missing event                        |
| Α        | pattern, macro, reusable operator structure            |
| Ω        | role, capability, authority, asymmetry                 |
| Θ        | ordering, progression, step                            |
| Φ        | recontextualization, trap, handler shift               |
| Χ        | Distance projected as boundary/reachability discipline |
| Σ        | integration, commit, finalization                      |
| Ψ        | policy, invariant, self-binding constraint             |

Because each instruction is operator-typed, PMS-UM traces are not merely execution logs.

They are operator words:

```text
h = o₁ o₂ … oₙ
```

where:

```text
oᵢ ∈ O
```

Valid PMS-UM traces must satisfy the PMS-STACK validity discipline:

```text
h ∈ L_PMS
```

and, under active policy:

```text
h ∈ L_PMS,Ψ
```

This links PMS-UM directly to the monoid and valid-sequence language defined in `01_architecture.md`.

### 1.6 PMS-UM and the Χ Boundary

PMS Base 1.3 defines:

```text
Χ = Distance
```

PMS-UM does not redefine Χ.

In the PMS-UM abstract machine, Χ is projected into machine-level boundary semantics:

```text
protected subcontext
reachability restriction
abstract sandbox
boundary state
visibility separation
partitioned store
quarantine marker
```

This is an implementation-layer projection of Distance.

Correct:

```text
PMS-UM projects Χ as abstract-machine boundary and reachability discipline.
```

Incorrect:

```text
PMS-UM changes Χ from Distance into isolation.
```

The correct relation is:

```text
PMS Base Χ:
    Distance

PMS-UM Χ:
    Distance projected into abstract-machine boundary,
    reachability, visibility, and access-separation semantics
```

Later layers refine this projection further:

```text
PMS-CPU:
    MMU boundary, ASID, protected domain

PMS-OS:
    process isolation, namespace boundary, sandbox

PMSL / Runtime:
    module boundary, host boundary, visibility boundary

Network:
    route boundary, segmentation, trust zone

Distributed:
    cross-node isolation, tenant boundary, shard boundary
```

### 1.7 PMS-UM and Valid Trace Language

PMS-UM execution is not merely a sequence of state changes.

It is a sequence of valid operator-labeled transitions.

Let:

```text
O* = all finite operator words over O
```

PMS-UM does not accept arbitrary words in `O*`.

It accepts only words that satisfy PMS-STACK well-formedness:

```text
L_PMS ⊆ O*
```

Under active policy:

```text
L_PMS,Ψ ⊆ L_PMS
```

A concrete PMS-UM run produces:

```text
trace(M, π, s₀) ∈ L_PMS
```

and, under active policy:

```text
trace(M, π, s₀) ∈ L_PMS,Ψ
```

The set of possible runs for a declared machine, program, initial state, and execution profile is:

```text
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

Thus:

```text
trace(...)
    denotes one concrete observed or selected run

Trace(...)
    denotes the set of possible runs under a declared profile
```

This is the machine-level form of PMS-STACK execution discipline.

A program that produces invalid operator history is not a valid PMS-UM execution, even if a generic automaton could step through it.

### 1.8 PMS-UM and Later Homomorphisms

PMS-UM is the source layer for later homomorphic refinement.

A central mapping is:

```text
h_UM→CPU : L_UM ⊆ L_PMS → ISA*
```

This maps PMS-UM operator words into PMS-CPU virtual instruction sequences on the declared domain.

Other later mappings include:

```text
PMS-UM
    → PMS-CPU
    → PMS-OS
    → PMSL / PMS-IR / Runtime
```

and:

```text
PMS-OS
    → Network
    → Distributed PMS
```

PMS-UM therefore gives later architecture layers a common abstract source.

A PMS-CPU instruction trace, OS syscall trace, runtime trace, network trace, or distributed trace remains PMS-STACK-conformant when it preserves the relevant PMS-UM operator structure under its layer-specific projection.

### 1.9 PMS-UM and Computational Expressiveness

PMS-UM is designed to support classical computation.

The key expressiveness claim is:

```text
PMS-UM can encode deterministic classical Turing Machine execution.
```

This is an encoding and simulation claim inside the defined abstract machine.

It means:

```text
For every deterministic classical Turing Machine T, there exists a PMS-UM
machine M_T and program π_T such that T's step behavior is simulated by
valid PMS-UM operator traces.
```

This supports the claim that PMS-UM is specified as at least Turing-complete as an abstract machine.

Boundary:

```text
Turing completeness is a computational expressiveness claim for PMS-UM.

It does not validate PMS Base.

It does not prove PMS as a complete theory of praxis.

It does not imply that PMS-CPU, PMS-OS, PMSL, PMS-RUST, or distributed
PMS-STACK are complete implementations.
```

This boundary is central to `02_pms_um.md`.

### 1.10 Architectural Role Summary

PMS-UM has six architectural roles.

First:

```text
It turns Δ–Ψ into machine-level abstract execution transitions.
```

Second:

```text
It gives PMS-STACK a state/configuration/transition substrate.
```

Third:

```text
It defines operator-typed instruction semantics before CPU, OS, language,
runtime, network, or distributed specialization.
```

Fourth:

```text
It produces valid concrete operator traces in L_PMS or L_PMS,Ψ and
profile-bounded Trace sets in L_PMS or L_PMS,Ψ.
```

Fifth:

```text
It provides the source model for later cross-layer homomorphisms.
```

Sixth:

```text
It supports a claim-disciplined computational expressiveness result through
classical Turing Machine encoding.
```

### 1.11 Role Boundary Statement

The correct boundary for this chapter is:

```text
PMS-UM is the abstract-machine layer of PMS-STACK. It defines how Δ–Ψ
operator words become executable as dependency-constrained, operator-typed
state transitions at the abstract-machine level.

This is an implementation-layer abstract-machine architecture claim.

It strengthens PMS-STACK by giving it a formal execution substrate.

It does not validate PMS Base, does not assert completed implementation of
later layers, and does not turn Turing-completeness into explanatory
universality.
```

---

## 2. Machine Tuple

A PMS Universal Machine is an operator-typed abstract machine.

It can be specified as the tuple:

```text
M = (S, Γ, F, R, PSet, O, Inst, Π, δ, s₀, S_H)
```

where:

| Component | Meaning                                                           |
| --------- | ----------------------------------------------------------------- |
| `S`       | set of PMS-UM machine states                                      |
| `Γ`       | symbol alphabet used in the core state                            |
| `F`       | set of frames, corresponding to □ contexts                        |
| `R`       | set of roles or capability modes, corresponding to Ω structures   |
| `PSet`    | set of possible active policy sets, corresponding to Ψ structures |
| `O`       | PMS operator alphabet Δ–Ψ                                         |
| `Inst`    | set of operator-typed instruction schemata                        |
| `Π`       | set of PMS-UM programs                                            |
| `δ`       | transition relation                                               |
| `s₀`      | initial machine state                                             |
| `S_H`     | set of halting states                                             |

This tuple is the abstract-machine specialization of the state/configuration/transition model defined in `01_architecture.md`.

It is not a hardware specification.

It is not a kernel specification.

It is not a programming-language specification.

It is the PMS-STACK abstract machine.

### 2.1 Operator Alphabet

The operator alphabet is:

```text
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

Each PMS-UM instruction is tagged by one element of `O`.

A program execution therefore produces a word over `O`:

```text
h = o₁ o₂ … oₙ
```

with:

```text
h ∈ O*
```

A valid concrete PMS-UM execution produces a word in:

```text
h ∈ L_PMS
```

and, under active policy:

```text
h ∈ L_PMS,Ψ
```

The set of possible PMS-UM executions under a declared profile is written:

```text
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

The tuple therefore includes both the raw operator alphabet and the transition discipline needed to restrict raw words into valid execution traces.

### 2.2 State Space `S`

The state space is:

```text
S = S_c × F × R × PSet × MMeta
```

A state has the shared PMS-STACK form:

```text
s = (s_c, f, r, P, m)
```

where:

| State component | Meaning                        |
| --------------- | ------------------------------ |
| `s_c ∈ S_c`     | core abstract machine state    |
| `f ∈ F`         | active frame context           |
| `r ∈ R`         | active role or capability mode |
| `P ∈ PSet`      | active policy set              |
| `m ∈ MMeta`     | meta-state                     |

The component `S_c` is the machine-specific core state domain.

It may be instantiated as:

```text
tape
store
graph
abstract memory
register-like cell set
structured symbol map
queue system
finite or countable data domain
```

PMS-UM does not force one concrete memory model.

It defines the operator-typed transition discipline over whatever computable domain the PMS-UM instance uses.

### 2.3 Symbol Alphabet `Γ`

`Γ` is the symbol alphabet used by the core state.

For Turing-machine encodings, `Γ` functions as the tape alphabet:

```text
tape : ℤ → Γ
```

For other PMS-UM instances, `Γ` may support:

```text
cell values
labels
symbols
tokens
instruction parameters
abstract store entries
message kinds
state labels
```

The symbol alphabet is part of the abstract machine substrate.

It does not determine the full state model by itself.

### 2.4 Frame Set `F`

`F` is the set of possible frames.

A frame corresponds to □ structure.

Frames may represent:

```text
store regions
local scopes
subprogram contexts
execution contexts
machine contexts
macro-expansion contexts
protected subcontexts
abstract module boundaries
```

The active frame:

```text
f ∈ F
```

determines where names, symbols, resources, or transitions have meaning.

A context-sensitive instruction is invalid when it lacks a valid frame.

### 2.5 Role Set `R`

`R` is the set of possible roles or capability modes.

Roles correspond to Ω structure.

Roles may represent:

```text
default execution mode
read-only mode
write-capable mode
trusted mode
untrusted mode
verifier role
interpreter role
privileged abstract role
capability-scoped execution mode
```

The active role:

```text
r ∈ R
```

constrains which transitions are allowed.

Protected actions, frame switches, boundary operations, commits, and policy updates may require specific role/capability conditions.

### 2.6 Policy Set `PSet`

`PSet` is the set of possible active policy sets.

A policy set corresponds to Ψ structure.

A policy may define:

```text
forbidden transitions
required roles
required frames
boundary requirements
commit rules
halting conditions
stuck-state behavior
audit obligations
fairness assumptions
recovery paths
```

The active policy set:

```text
P ∈ PSet
```

restricts the valid language of execution:

```text
L_PMS,Ψ ⊆ L_PMS
```

A program may be structurally valid and still policy-invalid.

### 2.7 Meta-State Domain `MMeta`

`MMeta` is the domain of PMS-UM meta-state.

Meta-state records execution structure not directly represented in the core data domain.

Typical meta-state fields include:

```text
history
distinction flags
branch flags
dependency markers
active expectations
timeout markers
ordering counters
logical step index
pattern-expansion state
role-check metadata
recontextualization state
boundary / reachability graph
committable state
policy-enforcement state
audit metadata
halt marker
stuck marker
```

The meta-state may also include a temporal data object:

```text
τ
```

containing:

```text
logical timestamps
deadlines
durations
scheduler counters
timer values
```

Θ orders transitions that may read or update such temporal data.

Θ is not physical time itself.

### 2.8 Instruction Set `Inst`

The instruction set is a set of operator-typed instruction schemata.

A generic instruction has the form:

```text
I = (op, params, pre, post)
```

where:

| Field    | Meaning                                 |
| -------- | --------------------------------------- |
| `op ∈ O` | PMS operator tag                        |
| `params` | machine-specific parameters             |
| `pre`    | precondition predicate                  |
| `post`   | state transformer or successor relation |

The instruction contract is:

```text
op ∈ O
∧ pre is at least as strong as the dependency rule for op
∧ post respects the allowed mutation profile of op
∧ active Ψ permits the transition
```

This contract makes PMS-UM operator-typed rather than instruction-opaque.

### 2.9 Program Set `Π`

`Π` is the set of PMS-UM programs.

A concrete PMS-UM program is written:

```text
π ∈ Π
```

A program is a finite sequence of operator-typed instructions:

```text
π = ⟨ I₁, I₂, …, Iₙ ⟩
```

where:

```text
I_k ∈ Inst
```

Each instruction carries an operator tag:

```text
op(I_k) ∈ O
```

A concrete execution produces:

```text
trace(π, s₀) = o₁ o₂ … oₙ
```

where each `oᵢ` is the operator tag of an executed instruction.

A concrete execution is structurally valid when:

```text
trace(π, s₀) ∈ L_PMS
```

and, under active policy:

```text
trace(π, s₀) ∈ L_PMS,Ψ
```

A program is admissible under a PMS-UM instance when all possible executions satisfy:

```text
Trace(π, s₀) ⊆ L_PMS
```

and, under active policy:

```text
Trace(π, s₀) ⊆ L_PMS,Ψ
```

Equivalently, using the machine parameter explicitly:

```text
trace(M, π, s₀) ∈ L_PMS
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text
trace(M, π, s₀) ∈ L_PMS,Ψ
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

Thus:

```text
Π
    denotes the PMS-UM program set

π ∈ Π
    denotes one concrete PMS-UM program

trace(...)
    denotes one concrete execution

Trace(...)
    denotes the set of possible executions under a declared profile
```

This harmonizes PMS-UM notation with the global PMS-STACK program-domain convention.

### 2.10 Transition Relation `δ`

The transition relation is:

```text
δ ⊆ S⁺ × Inst × S⁺
```

where:

```text
S⁺ = S × IP
```

and `IP` is the instruction-pointer domain.

A transition:

```text
(s⁺, I, s⁺') ∈ δ
```

means:

```text
instruction I is validly applicable in execution state s⁺ and may produce
successor execution state s⁺'
```

For deterministic PMS-UM instances, each instruction postcondition is functional:

```text
post_I : S⁺ → S⁺
```

and:

```text
(s⁺, I, s⁺') ∈ δ
    iff pre_I(s⁺) holds and s⁺' = post_I(s⁺)
```

For nondeterministic PMS-UM instances, postconditions are relational:

```text
post_I : S⁺ → P(S⁺)
```

and:

```text
(s⁺, I, s⁺') ∈ δ
    iff pre_I(s⁺) holds and s⁺' ∈ post_I(s⁺)
```

The transition relation is valid only when it preserves:

```text
operator dependency
state coherence
frame validity
role/capability constraints
boundary constraints
commit discipline
active policy constraints
valid trace update
```

### 2.11 Initial State `s₀`

The initial state is:

```text
s₀ ∈ S
```

An execution-oriented initial state is:

```text
s₀⁺ = (s₀, ip₀)
```

where `ip₀` selects the first instruction, entry label, or initial control point of the program.

The initial state must define:

```text
initial core state
initial frame
initial role
initial policy set
initial meta-state
initial instruction pointer
```

For Turing-machine encoding, this includes:

```text
initial tape
initial head position
initial control state
TM execution frame
TM execution role
TM policy set
initial rule-selection state
```

### 2.12 Halting Set `S_H`

The halting set is:

```text
S_H ⊆ S⁺
```

A PMS-UM run halts when:

```text
s⁺ ∈ S_H
```

or when the instruction pointer reaches a designated halt marker:

```text
ip = halt
```

A machine may also terminate under policy:

```text
Ψ_halt
```

or commit a final state:

```text
Σ_halt
```

These are PMS-UM halting conventions.

They should be declared by the PMS-UM instance.

Halting is not the same as stuckness.

```text
halted:
    a defined terminal condition has been reached

stuck:
    no valid transition applies, but the state is not declared halting
```

### 2.13 Environment and Input

Some PMS-UM instances are closed.

Others are environment-sensitive.

For environment-sensitive execution, configurations may include:

```text
e
```

where `e` is an environment or input source.

Then configurations use the more general PMS-STACK form:

```text
κ = (s, π, ip, h, e)
```

where:

```text
π ∈ Π
```

Environment input must enter the machine through operator-typed structure.

Examples:

```text
input symbol
    → Δ_input

missing input
    → Λ_absent

external error
    → Φ_error

policy-restricted input
    → Ψ_check

host or environment boundary
    → Χ_boundary
```

Environment interaction is not untyped intrusion.

It is admitted through the PMS-UM transition discipline.

### 2.14 Deterministic and Nondeterministic Instances

PMS-UM supports deterministic and nondeterministic instances.

Deterministic instance:

```text
∀s⁺, I:
    | { s⁺' | (s⁺, I, s⁺') ∈ δ } | ≤ 1
```

Nondeterministic instance:

```text
∃s⁺, I:
    | { s⁺' | (s⁺, I, s⁺') ∈ δ } | > 1
```

Nondeterminism may arise from:

```text
relational postconditions
multiple enabled instructions
environment events
scheduling choices
symbolic execution
policy alternatives
absence / timeout paths
recontextualization paths
```

Both deterministic and nondeterministic instances remain PMS-UM-conformant only when their concrete traces remain valid under `L_PMS` and active `L_PMS,Ψ`, and when their possible trace sets remain bounded by those languages:

```text
trace(M, π, s₀) ∈ L_PMS
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text
trace(M, π, s₀) ∈ L_PMS,Ψ
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

### 2.15 Machine Tuple Boundary

The PMS-UM tuple defines an abstract machine.

It does not define:

```text
PMS-CPU register file
PMS-CPU binary encoding
PMS-OS syscall ABI
PMS-OS scheduler
PMSL syntax
PMS-IR graph format
runtime standard library
network transport
distributed commit protocol
PMS-RUST implementation status
```

Those belong to later documents or artifacts.

The correct claim is:

```text
PMS-UM defines the abstract-machine tuple over which PMS-STACK execution
is modeled as operator-typed, dependency-constrained state transition.
```

Boundary:

```text
This strengthens the PMS-STACK abstract-machine architecture claim.

It does not complete later layers.

It does not validate PMS Base.
```

---

## 3. State and Configuration Model

PMS-UM uses the shared PMS-STACK state and configuration model defined in `01_architecture.md`.

The base machine state is:

```text id="f3pmsum"
s = (s_c, f, r, P, m)
```

where:

| Component | PMS-UM meaning                     |
| --------- | ---------------------------------- |
| `s_c`     | core abstract machine data         |
| `f`       | active frame context               |
| `r`       | active role or capability mode     |
| `P`       | active policy set                  |
| `m`       | meta-state for execution structure |

For program execution, PMS-UM extends this state with an instruction pointer:

```text id="cbokiu"
s⁺ = (s_c, f, r, P, m, ip)
```

The configuration form is:

```text id="fd9kxs"
κ = (s, π, ip, h, e)
```

where:

| Component | PMS-UM meaning                        |
| --------- | ------------------------------------- |
| `s`       | current PMS-UM state                  |
| `π`       | concrete PMS-UM program, with `π ∈ Π` |
| `ip`      | current instruction pointer           |
| `h`       | operator history                      |
| `e`       | optional environment/input source     |

This chapter defines how PMS-UM specializes the generic PMS-STACK execution model.

### 3.1 Core State `s_c`

The core state `s_c` stores the machine data manipulated by PMS-UM instructions.

Depending on the PMS-UM instance, `s_c` may contain:

```text id="hay39r"
tape
symbol store
graph
abstract memory
register-like cells
named cells
structured values
queues
maps
finite data domains
countable data domains
```

PMS-UM does not require one fixed concrete memory model.

Its role is to define the abstract operator-typed transition model.

Later layers specialize the core state:

```text id="8m2mey"
PMS-CPU:
    registers and memory

PMS-OS:
    process, resource, kernel, filesystem, IPC, and device state

PMSL / PMS-IR:
    runtime objects, values, scopes, IR nodes, effects

Runtime security:
    principals, sessions, trust state, capability state

Network:
    buffers, sessions, routes, packets, sequence state

Distributed PMS:
    nodes, replicas, shards, memberships, cluster state
```

The operators most directly affecting `s_c` are:

| Operator | Typical PMS-UM effect on `s_c`                                    |
| -------- | ----------------------------------------------------------------- |
| Δ        | observes, reads, classifies, or branches without primary mutation |
| ∇        | performs state-changing action                                    |
| Φ        | may transform or migrate state under recontextualization          |
| Σ        | integrates or commits prior activity                              |
| Ψ        | may enforce, update, deny, halt, or recover through policy        |

Other operators may affect `s_c` in specific instances, but their primary role is usually structural, contextual, or meta-state-oriented.

### 3.2 Frame Context `f`

The frame context `f` records active □ structure.

In PMS-UM, a frame may represent:

```text id="36gbjw"
active region of the abstract store
local scope
machine context
subprogram context
macro-expansion context
protected subcontext
logical execution frame
abstract module boundary
```

A PMS-UM action is frame-sensitive when its meaning depends on `f`.

Example:

```text id="1cavtg"
write(x, v)
```

may refer to different abstract cells depending on the active frame.

Likewise:

```text id="cz9uyi"
policy P
```

may apply only inside a specific frame.

The □ operator updates, enters, exits, or selects frame context.

A well-formed PMS-UM transition may require a valid frame before instruction execution.

Example:

```text id="aid363"
Δ_cell □_frame ∇_write
```

reads as:

```text id="jzwd30"
cell distinguished
frame selected
write performed inside that frame
```

Frame invariant:

```text id="sjz748"
context-sensitive execution requires □.
```

### 3.3 Role Context `r`

The role context `r` records active Ω structure.

In minimal PMS-UM instances, `r` may be fixed:

```text id="tw3nfz"
r = r_default
```

A fixed role is not the absence of Ω structure.

It is a declared role context with no dynamic role switching.

In richer PMS-UM instances, roles may model:

```text id="i2q7ha"
privileged versus unprivileged execution
read-only versus write-capable mode
trusted versus untrusted subprogram
verifier role
interpreter role
actor role
capability-scoped execution
policy-administrator role
```

The Ω operator may:

```text id="dw9m4q"
check role
assume role
switch role
delegate capability
revoke capability
establish role relation
deny role relation
```

The role context constrains:

```text id="cbh31n"
∇ action
□ frame transition
Χ boundary operation
Σ commit
Ψ policy update
Φ privileged recontextualization
```

Example:

```text id="fknftl"
Δ_target Ω_write ∇_write
```

reads as:

```text id="afpf8t"
target distinguished
write authority established
write action performed
```

Role invariant:

```text id="v1j459"
privileged action requires Ω.
```

### 3.4 Policy Context `P`

The policy context `P` records active Ψ constraints.

A PMS-UM policy may define:

```text id="m281we"
halting conditions
forbidden transitions
required frame conditions
required roles
boundary rules
commit rules
dependency checks
audit obligations
fairness assumptions
recovery paths
stuck-state behavior
```

Policies restrict the valid language of execution:

```text id="t6w3jq"
L_PMS,Ψ ⊆ L_PMS
```

A PMS-UM instruction may be structurally valid and still forbidden by active policy.

Example:

```text id="x016by"
Δ □ Ω ∇ Σ ∈ L_PMS
```

but:

```text id="urr1d8"
Δ □ Ω ∇ Σ ∉ L_PMS,Ψ
```

if active Ψ policy forbids the action or commit.

Ψ is therefore not an external annotation.

It is part of PMS-UM state and directly constrains the transition relation.

Policy may produce:

```text id="3jpomm"
allow
deny
halt
audit
recontextualize
delay
rollback
require commit
require boundary check
```

Policy invariant:

```text id="6ok58h"
Ψ constrains future valid execution.
```

### 3.5 Meta-State `m`

The meta-state `m` records execution structure that is not the primary machine data.

In PMS-UM, `m` may contain:

```text id="0tkpmq"
history
dependency markers
distinction flags
branch flags
ordering counters
logical step metadata
pending expectations
timeout markers
non-event markers
trap or recontextualization flags
boundary / reachability metadata
committable-state markers
audit trail
macro-expansion state
policy-enforcement metadata
halt marker
stuck marker
```

The meta-state is where PMS-UM records many structures needed by dependency-constrained execution.

Examples:

```text id="bwtp8g"
Δ
    may write classification flags into m

Θ
    may update ordering counters or logical step metadata

Λ
    may record an expected event that did not occur

Φ
    may record a recontextualization cause or handler state

Χ
    may record boundary or reachability metadata

Σ
    may clear committable-state markers or write commit logs

Ψ
    may record policy enforcement or audit obligations
```

The meta-state may also contain a temporal data object:

```text id="m8ebbc"
τ
```

Physical time, clocks, timestamps, or deadlines are data in `m`.

Θ orders transitions that may read or update such data.

Correct:

```text id="ys02en"
Θ = ordering / temporality operator

τ = temporal data object in meta-state
```

Incorrect:

```text id="5oaq6z"
Θ = wall-clock time
```

### 3.6 Boundary State and Χ

Boundary and reachability state is part of PMS-UM meta-state and sometimes frame state.

In PMS Base 1.3:

```text id="5zg93f"
Χ = Distance
```

In PMS-UM, Χ is projected as abstract-machine boundary discipline:

```text id="w6eyaa"
boundary relation
reachability restriction
protected subcontext
visibility separation
partitioned store
sandbox marker
quarantine marker
access-separation marker
```

A fixed or trivial closed-machine boundary is not the absence of Χ.

It is a declared boundary condition with no dynamic cross-boundary transition.

A boundary-sensitive PMS-UM transition must check whether the current boundary state permits the transition.

Representative predicate:

```text id="lp2rxo"
boundary_allows(f, r, P, m, instruction) = true
```

This predicate means:

```text id="ok9a46"
the active frame, role, policy, and boundary state permit the transition
under the PMS-UM projection of Χ as Distance
```

Boundary invariant:

```text id="pac5qm"
unsafe reachability requires Χ mediation.
```

This is an implementation-layer projection.

It is not a PMS Base redefinition.

### 3.7 Instruction Pointer `ip`

The execution-oriented state is:

```text id="qcqofh"
s⁺ = (s_c, f, r, P, m, ip)
```

The instruction pointer `ip` identifies the current execution position.

It may refer to:

```text id="7x72z9"
index in a finite program sequence
current operator instruction
macro-expanded instruction generated by Α
branch target selected by Δ
handler location entered by Φ
halt marker
stuck marker
waiting marker
```

The instruction pointer is not part of PMS Base.

It is an implementation-layer machine component used by PMS-UM to define abstract executable computation.

Typical update:

```text id="cxbb1q"
ip' = ip + 1
```

Branch update:

```text id="6xhja2"
ip' = branch_target
```

Handler update:

```text id="btmdcs"
ip' = handler_target
```

Halting update:

```text id="2zax3e"
ip' = halt
```

### 3.8 Programs

The PMS-UM program set is:

```text id="n7dcym"
Π
```

A concrete PMS-UM program is written:

```text id="wgl45h"
π ∈ Π
```

A PMS-UM program is a finite sequence of operator-typed instructions:

```text id="8gnhfi"
π = ⟨ I₁, I₂, …, Iₙ ⟩
```

Each instruction has the generic form:

```text id="zvdo8v"
I_k = (op, params, pre, post)
```

where:

```text id="t9c9m7"
op ∈ O
```

A program is therefore not merely a list of machine commands.

It is a sequence of Δ–Ψ-typed transition schemata.

A concrete execution of `π` from initial state `s₀` produces one operator trace:

```text id="rmpnpt"
trace(π, s₀) = o₁ o₂ … oₙ
```

A concrete execution is structurally valid when:

```text id="uhzf9a"
trace(π, s₀) ∈ L_PMS
```

and, under active policy:

```text id="zuqgkd"
trace(π, s₀) ∈ L_PMS,Ψ
```

A program is structurally admissible when all possible executions under the declared machine/profile satisfy:

```text id="jy36hi"
Trace(π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="vrtr27"
Trace(π, s₀) ⊆ L_PMS,Ψ
```

Equivalently, with the machine parameter explicit:

```text id="fsbjtk"
trace(M, π, s₀) ∈ L_PMS
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="xqay57"
trace(M, π, s₀) ∈ L_PMS,Ψ
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

This does not require that the program text literally contain the full PMS Base dependency path before each instruction.

It requires that each executed step has the relevant dependencies available in prefix, state, frame, role, policy, meta-state, or committed history.

### 3.9 Operator History `h`

The operator history is:

```text id="y8b7mw"
h ∈ O*
```

During execution, each successful step appends the operator tag of the executed instruction:

```text id="p4s550"
h' = h · op
```

For valid PMS-UM execution:

```text id="59xmmw"
h' ∈ L_PMS
```

and, under active policy:

```text id="zqjl37"
h' ∈ L_PMS,Ψ
```

The history is not merely a log.

It participates in dependency availability, validation, replay, audit, simulation, and evidence mapping.

A trace may also carry metadata:

```text id="qm5wlh"
event = (
    step,
    op,
    frame,
    role,
    policy,
    boundary,
    params,
    result,
    meta
)
```

This makes PMS-UM traceable without turning trace evidence into proof.

Trace boundary:

```text id="l0rfst"
A concrete trace records one observed or selected execution under a
declared machine/profile.

It does not enumerate the full Trace(...) set.

It does not prove all possible behavior.

It does not validate PMS Base.
```

### 3.10 Environment `e`

Some PMS-UM machines are closed.

Others are environment-sensitive.

The optional environment/input source is:

```text id="s5kv5d"
e
```

It may provide:

```text id="8jozuz"
input symbol
external event
nondeterministic choice
timeout condition
missing event
host response
fault injection
verification oracle
AI/tooling proposal
```

Environment input must enter through operator-typed structure.

Examples:

```text id="x13mbp"
input arrives
    → Δ_input

expected input absent
    → Λ_absent

external error
    → Φ_error

host response accepted
    → Φ_host_boundary Ω_auth Χ_boundary Ψ_policy Σ_accept

AI/tooling proposal
    → Δ_proposal Ψ_validation_profile Φ_reject_or_accept
```

The environment is not allowed to mutate PMS-UM state as an untyped side channel.

AI/tooling boundary:

```text id="5kb3yh"
AI or tooling may propose candidate programs, traces, scenarios, or
diagnostics.

Host tooling validates.

PMS-UM execution uses only accepted artifacts under a declared profile.

AI/tooling output is not trusted executable code, compiler authority,
verifier authority, proof evidence, policy authority, or PMS Base evidence.
```

### 3.11 Configurations

A minimal PMS-UM configuration is:

```text id="d7iqdw"
C = (s⁺, π)
```

where:

```text id="xx06ex"
π ∈ Π
```

Expanded:

```text id="8ph6de"
C = ((s_c, f, r, P, m, ip), π)
```

For alignment with the general PMS-STACK architecture model, PMS-UM configurations may also be written:

```text id="kcwa57"
κ = (s, π, ip, h, e)
```

where:

| Component | PMS-UM meaning                        |
| --------- | ------------------------------------- |
| `s`       | current PMS-UM state                  |
| `π`       | concrete PMS-UM program, with `π ∈ Π` |
| `ip`      | current instruction pointer           |
| `h`       | operator history                      |
| `e`       | environment/input source              |

The two notations are compatible:

```text id="fx1ipg"
C
    minimal machine notation

κ
    full PMS-STACK configuration notation
```

A PMS-UM configuration is well-formed when:

```text id="3oe60m"
s is structurally coherent
∧ π ∈ Π
∧ ip is valid for π or is halt/stuck/waiting
∧ h ∈ L_PMS or h ∈ L_PMS,Ψ
∧ active frame/role/policy/boundary state is coherent
∧ environment input, if present, is admitted through operator-typed structure
```

### 3.12 Configuration Status

A PMS-UM configuration may have one of several statuses.

| Status           | Meaning                                                           |
| ---------------- | ----------------------------------------------------------------- |
| active           | the current instruction may be fetched and checked                |
| halted           | the state lies in `S_H` or `ip` is a halt marker                  |
| stuck            | no valid instruction applies, but the state is not halting        |
| policy-denied    | Ψ forbids continuation                                            |
| waiting          | execution awaits an event or ordering condition                   |
| non-event        | an expected event is absent and Λ is applicable                   |
| recontextualized | Φ has moved execution into a handler or new frame                 |
| boundary-denied  | Χ / Ψ prevents unsafe reachability                                |
| commit-blocked   | Σ cannot integrate because committable state is absent or invalid |

This status vocabulary is still operator-typed.

PMS-UM does not treat failure, waiting, denial, absence, or boundary rejection as outside the machine.

They are represented through:

```text id="p4lth3"
Λ
Φ
Χ
Σ
Ψ
```

and the meta-state.

### 3.13 Well-Formed Configuration Predicate

A compact predicate for PMS-UM configuration well-formedness is:

```text id="405v72"
well_formed_UM(κ) iff
    s = (s_c, f, r, P, m) is coherent
    ∧ π ∈ Π
    ∧ ip is valid for π or is an accepted status marker
    ∧ h ∈ L_PMS or h ∈ L_PMS,Ψ
    ∧ frame_state_valid(f, m)
    ∧ role_state_valid(r, m)
    ∧ policy_state_valid(P, m)
    ∧ boundary_state_valid(f, r, P, m)
    ∧ commit_state_valid(s_c, m)
    ∧ environment_state_valid(e, κ)
```

This is helper notation for the architecture.

A concrete PMS-UM instance may refine it.

The central requirement is that configuration validity be operator-aware, state-aware, boundary-aware, commit-aware, and policy-aware.

### 3.14 State and Configuration Invariants

```text id="9b69lq"
UM-SC1: PMS-UM state follows the shared PMS-STACK state model

UM-SC2: core state stores the abstract machine data domain

UM-SC3: frame context records active □ structure

UM-SC4: role context records active Ω structure

UM-SC5: policy context records active Ψ constraints

UM-SC6: meta-state records dependency, ordering, absence, boundary, commit,
        policy, trace, and status information

UM-SC7: PMS Base Χ = Distance

UM-SC8: PMS-UM projects Χ as abstract-machine boundary, reachability,
        visibility, and access-separation discipline

UM-SC9: instruction pointer is an implementation-layer execution component

UM-SC10: Π denotes the PMS-UM program set

UM-SC11: π ∈ Π denotes one concrete PMS-UM program

UM-SC12: operator history is a word over O

UM-SC13: valid PMS-UM histories belong to L_PMS or L_PMS,Ψ

UM-SC14: trace(...) denotes one concrete PMS-UM execution

UM-SC15: Trace(...) denotes the set of possible PMS-UM executions under a
         declared machine/profile

UM-SC16: environment input must enter through operator-typed structure

UM-SC17: failure, absence, denial, stuckness, and recontextualization are
         operator-typed

UM-SC18: AI/tooling output may propose or explain but is not executable,
         compiler, verifier, policy, proof, or PMS Base authority

UM-SC19: PMS-UM state/configuration semantics strengthen abstract-machine
         architecture claims and do not validate PMS Base
```

### 3.15 Architectural Consequence

The PMS-UM state and configuration model establishes the abstract execution substrate for the rest of PMS-STACK.

The result is:

```text id="hazser"
A PMS-UM execution is a sequence of configurations whose transitions are
operator-labeled, dependency-constrained, frame-aware, role-aware,
boundary-aware, commit-sensitive, profile-declared, and policy-constrained.
```

This is the abstract-machine specialization of the state/configuration/transition model defined in `01_architecture.md`.

PMS-UM therefore functions as the formal bridge between the PMS Base operator grammar and later implementation-layer specifications such as PMS-CPU, PMS-OS, PMSL/PMS-IR, runtime security, networking, and distributed systems.

### 3.16 Boundary Statement

The correct boundary for this chapter is:

```text id="51j938"
The PMS-UM state and configuration model defines the abstract execution
substrate of PMS-STACK.

It specifies how core state, frame context, role context, policy context,
meta-state, instruction pointer, program, history, and environment combine
into operator-typed machine configurations.

This is an abstract-machine architecture claim.

It does not implement PMS-CPU, PMS-OS, PMSL, PMS-RUST, or distributed
PMS-STACK, does not turn traces into proofs, does not turn AI/tooling output
into trusted execution or verification authority, and does not validate
PMS Base.
```

---

## 4. Programs and Operator-Typed Instructions

A PMS-UM program is a finite sequence of operator-typed instructions.

The PMS-UM program domain is:

```text id="6t9n3z"
Π
```

A concrete PMS-UM program is written:

```text id="btxh2o"
π ∈ Π
```

A program has the form:

```text id="vli0xj"
π = ⟨ I₁, I₂, …, Iₙ ⟩
```

Each instruction belongs to the instruction set `Inst` and has the generic form:

```text id="w57gkh"
I = (op, params, pre, post)
```

where:

| Field    | Meaning                                         |
| -------- | ----------------------------------------------- |
| `op`     | one PMS operator in `O`                         |
| `params` | machine-specific parameters                     |
| `pre`    | precondition predicate over configuration/state |
| `post`   | state transformer or successor relation         |

The operator tag is mandatory:

```text id="9jvm68"
op ∈ O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

This is the defining feature of PMS-UM. A PMS-UM instruction is not an opaque transition. It is a transition whose structural role is declared by its operator type.

PMS-UM therefore differs from a generic abstract machine in one decisive way:

```text id="v9yjhv"
generic abstract machine:
    instruction = arbitrary transition rule

PMS-UM:
    instruction = operator-typed transition rule constrained by Δ–Ψ
```

The central program claim is:

```text id="f8ah8p"
A PMS-UM program is a finite operator-typed instruction sequence whose
concrete executions produce valid Δ–Ψ traces and whose declared Trace set
is bounded by the PMS-STACK execution discipline.
```

Claim type:

```text id="scph64"
abstract-machine architecture claim
```

Boundary:

```text id="gxuj5x"
This defines PMS-UM program structure.

It does not define PMSL source syntax, PMS-IR graph format, PMS-CPU binary
encoding, PMS-OS syscall ABI, or PMS-RUST implementation status.

It does not validate PMS Base.
```

### 4.1 Program Domain

A PMS-UM program is a machine-level abstract program.

It is not yet:

```text id="9t7tsf"
PMSL source code
PMS-IR graph
PMS-CPU binary
PMS-OS syscall trace
runtime script
network protocol trace
distributed orchestration plan
```

Those later artifacts may map to or from PMS-UM programs through homomorphisms, compilation, interpretation, simulation, lowering, abstraction, or runtime execution.

The relation is:

```text id="g9imnb"
PMS-UM program
    = abstract operator-typed instruction sequence

PMSL program
    = language-level expression that may lower into PMS-IR / PMS-UM / runtime

PMS-IR
    = operator-preserving intermediate representation

PMS-CPU program
    = virtual ISA-level refinement of PMS-UM structure

PMS-RUST artifact
    = bounded executable implementation/evidence slice where applicable
```

Thus PMS-UM program validity is an abstract-machine property.

It is not compiler completion.

It is not CPU implementation.

It is not OS implementation.

It is not PMS-RUST artifact completion.

### 4.2 Instruction Form

Every PMS-UM instruction has the form:

```text id="ncc0vw"
I = (op, params, pre, post)
```

The instruction is selected and executed inside an execution-oriented state:

```text id="6s1xcz"
s⁺ = (s_c, f, r, P, m, ip)
```

and, in full configuration form:

```text id="lkfj4b"
κ = (s, π, ip, h, e)
```

where:

| Component | Meaning                               |
| --------- | ------------------------------------- |
| `s`       | current PMS-UM state                  |
| `π`       | concrete PMS-UM program, with `π ∈ Π` |
| `ip`      | current instruction pointer           |
| `h`       | operator history                      |
| `e`       | optional environment/input source     |

The instruction field `op` determines the operator family.

The field `params` determines the machine-specific content.

The field `pre` determines when the instruction may execute.

The field `post` determines the successor state or successor state set.

### 4.3 Operator Tag

The operator tag must be one of:

```text id="m4vqxw"
Δ
∇
□
Λ
Α
Ω
Θ
Φ
Χ
Σ
Ψ
```

The tag gives the instruction its architectural type.

Examples:

```text id="cafnyg"
I_Δ
    distinction / classification / branch / read-compare instruction

I_∇
    action / mutation / write / update instruction

I_□
    frame / context instruction

I_Λ
    non-event / timeout / absence instruction

I_Α
    pattern / macro / expansion instruction

I_Ω
    role / capability / authority instruction

I_Θ
    order / progression instruction

I_Φ
    recontextualization / trap / handler instruction

I_Χ
    Distance-projection / boundary / reachability instruction

I_Σ
    integration / commit instruction

I_Ψ
    policy / invariant / self-binding instruction
```

The operator tag is not decoration.

It determines:

```text id="wrf0cr"
dependency obligations
allowed state effects
failure type
trace representation
validity checking
homomorphic preservation
```

### 4.4 Parameters

`params` are machine-specific.

They may include:

```text id="fo2ypd"
symbol identifiers
cell names
tape positions
branch targets
frame identifiers
role identifiers
policy identifiers
pattern identifiers
timeout labels
boundary identifiers
commit handles
environment handles
```

Examples:

```text id="5xf904"
(Δ, read_symbol(pos), pre, post)

(∇, write_symbol(pos, γ), pre, post)

(□, enter_frame(f_id), pre, post)

(Λ, timeout(wait_id), pre, post)

(Α, expand_pattern(pattern_id), pre, post)

(Ω, check_capability(cap_id), pre, post)

(Θ, advance_step, pre, post)

(Φ, enter_handler(handler_id), pre, post)

(Χ, enter_boundary(boundary_id), pre, post)

(Σ, commit(handle), pre, post)

(Ψ, enforce_policy(policy_id), pre, post)
```

Parameter validity is part of instruction validity.

A valid operator tag does not make malformed parameters valid.

Example:

```text id="27yycq"
(Σ, commit(handle), pre, post)
```

is invalid if `handle` does not refer to committable prior structure.

Example:

```text id="lkgs9y"
(Χ, enter_boundary(boundary_id), pre, post)
```

is invalid if no active frame/domain exists or active policy forbids boundary transition.

### 4.5 Preconditions

The precondition `pre` determines whether an instruction may execute in the current configuration.

Generic form:

```text id="oifsyc"
pre_I(κ) = true
```

A valid PMS-UM instruction must include preconditions at least as strong as the operator dependency discipline:

```text id="0w9gu0"
pre_I(κ)
    ⇒ dependencies_available(op(I), κ)
```

Architecturally, a stronger and more useful reading is:

```text id="ecxjda"
valid_instruction(I, κ) iff
    op(I) ∈ O
    ∧ π ∈ Π
    ∧ dependencies_available(op(I), κ)
    ∧ pre_I(κ)
    ∧ policy_allows(P, I, κ)
    ∧ boundary_allows(f, r, P, m, I)
    ∧ profile_allows(profile, I)
```

where applicable.

Not every PMS-UM instance has an explicit runtime profile field. When it does, profile validity must be checked.

Typical preconditions:

```text id="v4ijmi"
pre_Δ:
    inspected object/state/symbol is available in the current frame

pre_∇:
    target distinguished
    ∧ frame valid if frame-sensitive
    ∧ role/policy permits if protected

pre_□:
    target frame distinguished
    ∧ frame entry/switch permitted

pre_Λ:
    expectation exists

pre_Α:
    pattern exists
    ∧ expansion is valid or can be validated

pre_Ω:
    role/capability relation distinguished
    ∧ policy permits role operation

pre_Θ:
    transition/order/progression target exists

pre_Φ:
    cause/context exists
    ∧ continuation or handler exists

pre_Χ:
    active frame/domain exists
    ∧ boundary operation permitted

pre_Σ:
    committable prior structure exists

pre_Ψ:
    policy object/scope/invariant distinguished
    ∧ authority exists if policy is modified
```

### 4.6 Postconditions

The postcondition `post` determines the successor state.

For deterministic PMS-UM instances:

```text id="p3yfpr"
post_I : S⁺ → S⁺
```

For nondeterministic PMS-UM instances:

```text id="0xe3uz"
post_I : S⁺ → P(S⁺)
```

The postcondition must respect the operator’s allowed mutation profile.

Examples:

```text id="wgwoz6"
post_Δ:
    may update distinction flags, branch metadata, or control position

post_∇:
    may mutate core state

post_□:
    may update active frame

post_Λ:
    may update absence / timeout / pending expectation metadata

post_Α:
    may expand or activate a valid pattern

post_Ω:
    may update or check role/capability state

post_Θ:
    may update ordering metadata or control progression

post_Φ:
    may update frame, role, policy, handler, or recontextualization state

post_Χ:
    may update boundary, reachability, visibility, or protected-domain state

post_Σ:
    may integrate staged state and clear committable markers

post_Ψ:
    may update, activate, enforce, or deny policy
```

A postcondition is invalid if it performs effects that contradict the operator role.

Example:

```text id="6ranw1"
Δ instruction performs ungoverned core mutation
```

is invalid unless the instruction is not actually Δ and should be retyped.

Example:

```text id="ve9euu"
Σ instruction commits without committable prior state
```

is invalid.

Example:

```text id="eg0qmi"
Ψ instruction changes active policy without authority
```

is invalid.

### 4.7 Instruction Contract

The PMS-UM instruction contract is:

```text id="1qadsb"
InstrValid(I, κ) iff
    op(I) ∈ O
    ∧ π ∈ Π
    ∧ params_valid(params(I), κ)
    ∧ dependencies_available(op(I), κ)
    ∧ pre_I(κ)
    ∧ boundary_allows(f, r, P, m, I)
    ∧ policy_allows(P, I, κ)
    ∧ post_I preserves the mutation discipline of op(I)
```

This contract makes PMS-UM operator-typed.

An instruction is not valid merely because it appears in the program.

It is valid only when its operator obligations, preconditions, boundary conditions, policy conditions, and postconditions hold.

### 4.8 Program Traces

Executing a PMS-UM program produces an operator history:

```text id="krswog"
h = o₁ o₂ … oₖ
```

where each `oᵢ` is the operator tag of an executed instruction.

The history is updated by concatenation:

```text id="ie9yd1"
h' = h · op
```

A concrete execution of a PMS-UM program produces one trace:

```text id="akpmk1"
trace(π, s₀) = o₁ o₂ … oₖ
```

A concrete execution is structurally valid when:

```text id="o2ovjx"
trace(π, s₀) ∈ L_PMS
```

and, under active policy:

```text id="jr6x61"
trace(π, s₀) ∈ L_PMS,Ψ
```

A PMS-UM program is architecturally admissible when its possible execution histories are valid PMS operator words:

```text id="e4scfk"
Trace(π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="xb31ku"
Trace(π, s₀) ⊆ L_PMS,Ψ
```

Equivalently, with the machine parameter explicit:

```text id="l2s3fp"
trace(M, π, s₀) ∈ L_PMS
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="uceqmg"
trace(M, π, s₀) ∈ L_PMS,Ψ
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

This means a program is not valid merely because its instructions are syntactically well-formed.

Its concrete traces and declared Trace set must satisfy:

```text id="264jqx"
operator dependency
∧ state/configuration preconditions
∧ boundary discipline
∧ commit discipline
∧ active Ψ policy constraints
```

Trace boundary:

```text id="cdczyk"
trace(...)
    denotes one concrete observed or selected execution

Trace(...)
    denotes the set of possible executions under a declared machine,
    initial state, and profile

A concrete trace does not enumerate the full Trace(...) set.
```

### 4.9 Static and Dynamic Program Validity

PMS-UM distinguishes static admissibility from dynamic execution validity.

Static admissibility asks:

```text id="eaczdh"
Can the program be interpreted as an operator-typed PMS-UM program?
```

Dynamic validity asks:

```text id="hy7fzx"
Does a particular execution from a particular state produce a valid
operator trace?
```

Static admissibility may check:

```text id="fh4t0q"
instruction shape
operator tags
parameter well-formedness
declared pattern expansions
declared branch targets
declared halting markers
declared policy references
```

Dynamic validity must also check:

```text id="mro3cf"
active state
active frame
active role
active policy
active boundary state
committable state
environment input
runtime/profile conditions
```

A program can be statically admissible and dynamically stuck.

Example:

```text id="v5khfq"
π contains a valid Σ instruction
```

but:

```text id="yke9mc"
execution reaches Σ with no committable prior state
```

The program is syntactically admissible.

The run is invalid or stuck at that point.

Thus:

```text id="f6qm6w"
static admissibility
    ≠ concrete trace validity

concrete trace validity
    ≠ Trace-set completeness

artifact acceptance
    ≠ PMS Base validation
```

### 4.10 Operator-Typed Instruction Schemata

Typical PMS-UM instruction schemata include:

```text id="qdvwvi"
I_Δ = (Δ, read_or_classify(params), pre_Δ, post_Δ)

I_∇ = (∇, act_or_mutate(params), pre_∇, post_∇)

I_□ = (□, enter_or_switch_frame(params), pre_□, post_□)

I_Λ = (Λ, handle_absence(params), pre_Λ, post_Λ)

I_Α = (Α, expand_or_activate_pattern(params), pre_Α, post_Α)

I_Ω = (Ω, check_or_set_role(params), pre_Ω, post_Ω)

I_Θ = (Θ, advance_order(params), pre_Θ, post_Θ)

I_Φ = (Φ, recontextualize(params), pre_Φ, post_Φ)

I_Χ = (Χ, manage_distance_projection(params), pre_Χ, post_Χ)

I_Σ = (Σ, commit_or_integrate(params), pre_Σ, post_Σ)

I_Ψ = (Ψ, define_enforce_or_bind_policy(params), pre_Ψ, post_Ψ)
```

These are abstract instruction schemata.

They are not PMS-CPU opcodes.

PMS-CPU later refines these schemata into virtual ISA instruction families.

### 4.11 Pattern Instructions and Α Expansion

Α may appear as an instruction-level pattern operator.

A PMS-UM instance may handle Α in either static or dynamic form.

Static expansion:

```text id="423tf5"
Α(pattern) ⇒ w_pattern
```

where:

```text id="tbpsrq"
w_pattern ∈ L_PMS
```

and, under active policy:

```text id="fs0e48"
w_pattern ∈ L_PMS,Ψ
```

In this mode, the runtime program may contain only the expanded sequence.

Dynamic expansion:

```text id="ro0vkl"
I_Α = (Α, pattern_id, pre_Α, post_Α)
```

where `post_Α` inserts, activates, or selects a valid operator subsequence.

In both modes:

```text id="pcmel6"
valid(Α(pattern)) iff valid(expand(pattern))
```

Α does not define a new primitive outside Δ–Ψ.

It packages valid operator structure.

Invalid:

```text id="rcmkol"
Α(pattern) ⇒ ∇ Σ
```

when no target is distinguished and no committable prior structure exists.

Valid:

```text id="b5p1qv"
Α(syscall_template)
    ⇒ Δ_syscall Φ_kernel □_kernel Ω_check Ψ_policy ∇_effect Σ_return
```

provided the expanded sequence is valid in the PMS-UM profile.

Pattern expansion may be supported by tools or artifacts, but artifact support is claim-bound:

```text id="mcz8ri"
A validator may accept or reject an expansion under a declared profile.

That strengthens a bounded implementation-artifact claim.

It does not prove all pattern expansion correct and does not validate PMS Base.
```

### 4.12 Branching Instructions

PMS-UM may branch through operator-typed instructions.

Branching is usually mediated by:

```text id="ueo1vm"
Δ
Φ
Ψ
Α
Θ
```

Common cases:

```text id="r2r78g"
Δ
    branch based on distinction, comparison, symbol read, state condition

Φ
    branch into handler, fallback, trap, or recovery context

Ψ
    branch on policy allow / deny / halt / audit condition

Α
    branch into expanded pattern or selected template

Θ
    branch according to ordered progression, phase, or scheduler step
```

Branching must update `ip` in a way that remains valid for the program:

```text id="c3487j"
ip' = branch_target
```

A branch target is valid only if:

```text id="u9mfx7"
branch_target ∈ domain(π)
```

or:

```text id="019r35"
branch_target ∈ {halt, stuck, waiting, handler_marker}
```

where such markers are declared by the PMS-UM instance.

### 4.13 Halting Instructions

PMS-UM may represent halting through:

```text id="lgm4ex"
S_H
ip = halt
Σ_halt
Ψ_halt
```

A halting instruction may be:

```text id="6k7f62"
I_Σ_halt = (Σ, halt_commit, pre, post)

I_Ψ_halt = (Ψ, halt_policy, pre, post)
```

Σ-halting reads halting as final integration:

```text id="se3am0"
final state committed
```

Ψ-halting reads halting as policy-bound termination:

```text id="sdc9pt"
future execution forbidden or closed
```

A PMS-UM instance must declare its halting convention.

Halting is not stuckness.

```text id="u4dltx"
halted:
    declared terminal state

stuck:
    no valid transition applies but terminal state was not reached
```

### 4.14 Environment-Mediated Instructions

If a PMS-UM instance includes environment input, environment behavior must be admitted through operator-typed instructions.

Examples:

```text id="t9huu2"
I_Δ_input
    distinguish input value

I_Λ_no_input
    record expected input absence

I_Φ_env_error
    recontextualize external error

I_Χ_host_boundary
    mediate environment boundary

I_Ψ_env_policy
    enforce environment-admission policy

I_Σ_accept_input
    commit accepted input into machine state
```

Environment input cannot directly mutate `s_c` outside the transition relation.

Correct:

```text id="grx2xh"
environment input
    → Δ_input
    → Ψ_policy
    → ∇_accept
    → Σ_commit
```

Incorrect:

```text id="mckkql"
environment mutates core state without operator-typed transition
```

AI/tooling proposals are environment-mediated inputs when present.

Correct:

```text id="dfmgxk"
AI/tooling proposal
    → Δ_proposal
    → Ψ_validation_profile
    → Φ_reject or ∇_accept_candidate
```

Boundary:

```text id="muj4l1"
AI proposes.

Host tooling validates.

PMS-UM execution uses only accepted artifacts under a declared profile.

Policy remains Ψ-governed.

AI/tooling output is not trusted executable code, compiler authority,
verifier authority, proof evidence, policy authority, or PMS Base evidence.
```

### 4.15 Program Equivalence

Two PMS-UM programs may be equivalent under a declared observation profile.

Notation:

```text id="gxx1wq"
π₁ ≈_obs π₂
```

means:

```text id="0puqum"
π₁ and π₂ produce indistinguishable behavior under observation profile obs
```

Observation may include:

```text id="ixdvp7"
final core state
operator trace
Trace set
commit trace
policy result
halting behavior
external output
audit events
```

Equivalence is profile-specific.

Example:

```text id="j5jds0"
Two programs may differ in internal Θ ordering metadata but produce the
same committed final state under a final-state observation profile.
```

Example:

```text id="mzf5c8"
Two programs may produce the same core state but different audit traces;
they are not equivalent under audit-sensitive observation.
```

A concrete trace comparison is weaker than full behavioral equivalence.

```text id="hwtzq9"
trace₁(...) = trace₂(...)
```

does not by itself imply:

```text id="yu58gp"
Trace(π₁, s₀) = Trace(π₂, s₀)
```

Boundary:

```text id="1xzavj"
Program equivalence is not universal identity.

It must state observation profile, execution profile, and whether it refers
to concrete traces or Trace sets.
```

### 4.16 Program Validity Levels

A PMS-UM program may be described at several validity levels.

| Level                           | Meaning                                                                              |
| ------------------------------- | ------------------------------------------------------------------------------------ |
| syntactic                       | sequence of instruction tuples has valid shape                                       |
| operator-typed                  | every instruction has `op ∈ O`                                                       |
| parameter-valid                 | instruction parameters are valid for the machine instance                            |
| structurally admissible         | possible traces can satisfy `L_PMS`                                                  |
| policy-admissible               | possible traces can satisfy `L_PMS,Ψ`                                                |
| state-executable                | program can step from a given initial state                                          |
| single-run trace-valid          | `trace(...) ∈ L_PMS` or `trace(...) ∈ L_PMS,Ψ`                                       |
| program/profile Trace-set-valid | `Trace(...) ⊆ L_PMS` or `Trace(...) ⊆ L_PMS,Ψ`                                       |
| halting                         | execution reaches `S_H` or halt marker                                               |
| stuck                           | execution cannot proceed and is not halted                                           |
| artifact-supported              | a concrete artifact can parse, execute, validate, or trace it under declared profile |

These levels must not collapse.

Correct:

```text id="q03qn7"
This program is syntactically admissible.
```

does not imply:

```text id="e5ea7j"
This program halts.
```

Correct:

```text id="t6ofzx"
This concrete run is trace-valid.
```

does not imply:

```text id="9tv3g7"
All possible runs are Trace-set-valid.
```

Correct:

```text id="ymt7xn"
This program is accepted by a bounded artifact under profile P.
```

does not imply:

```text id="azyb6y"
This program validates PMS Base.
```

Validation in this context means acceptance or rejection under a declared schema, profile, model, validator, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 4.17 Program Invariants

```text id="brtr50"
UM-P1: every PMS-UM program is a finite sequence of operator-typed instructions

UM-P2: Π denotes the PMS-UM program set

UM-P3: π ∈ Π denotes one concrete PMS-UM program

UM-P4: every PMS-UM instruction has an operator tag op ∈ O

UM-P5: operator tags determine dependency obligations and mutation discipline

UM-P6: params are machine-specific and must be valid in the PMS-UM instance

UM-P7: preconditions must be at least as strong as the dependency rules

UM-P8: postconditions must preserve the operator's structural role

UM-P9: program execution produces an operator history h ∈ O*

UM-P10: trace(...) denotes one concrete PMS-UM execution

UM-P11: Trace(...) denotes the set of possible PMS-UM executions under a
       declared machine/profile

UM-P12: valid concrete execution histories belong to L_PMS or L_PMS,Ψ

UM-P13: admissible program/profile Trace sets are subsets of L_PMS or L_PMS,Ψ

UM-P14: Α expands to valid operator structure

UM-P15: environment behavior must enter through operator-typed instructions

UM-P16: AI/tooling output may propose or explain but is not executable,
        compiler, verifier, policy, proof, or PMS Base authority

UM-P17: halting and stuckness are distinct

UM-P18: program validity is level-specific and claim-bound

UM-P19: PMS-UM programs are not PMSL source, PMS-IR graphs, PMS-CPU binaries,
        PMS-OS syscall traces, or PMS-RUST artifacts by default

UM-P20: PMS-UM program semantics strengthen abstract-machine architecture
        claims and do not validate PMS Base
```

### 4.18 Boundary Statement

The correct boundary for this chapter is:

```text id="gobbjj"
PMS-UM programs are finite operator-typed instruction sequences.
Each instruction carries a Δ–Ψ tag, machine-specific parameters,
preconditions, and postconditions.

Program validity is defined by operator typing, dependency availability,
state/configuration preconditions, boundary discipline, commit discipline,
active Ψ policy constraints, and declared execution profile.

A concrete run produces trace(...).

A declared machine/program/profile determines Trace(...).

This is an abstract-machine architecture claim.

It does not define PMSL source syntax, PMS-IR graph format, PMS-CPU binary
encoding, PMS-OS syscall ABI, PMS-RUST implementation status, or PMS Base
validation. It does not turn traces into proofs, Trace sets into external
validation, artifact support into PMS-STACK completion, or AI/tooling output
into trusted execution or verification authority.
```

---

## 5. Step Relation

The PMS-UM step relation defines how a configuration advances by one operator-typed instruction.

A minimal PMS-UM configuration is:

```text id="gq3bp8"
C = (s⁺, π)
```

where:

```text id="qd7wop"
s⁺ = (s_c, f, r, P, m, ip)
```

and:

```text id="j6fwhw"
π ∈ Π
```

with:

```text id="q2rzr3"
π = ⟨ I₁, I₂, …, Iₙ ⟩
```

For alignment with the general PMS-STACK configuration model, the same configuration may also be represented as:

```text id="ndvx1i"
κ = (s, π, ip, h, e)
```

where `π ∈ Π`, `h` is the operator history, and `e` is an optional environment or input source.

The central step claim is:

```text id="lxhpwj"
A PMS-UM step is valid when an operator-typed instruction selected by the
current configuration satisfies dependency, precondition, boundary,
policy, profile, and postcondition requirements, producing a successor
configuration whose updated history remains in L_PMS or L_PMS,Ψ.
```

Claim type:

```text id="rtynar"
abstract-machine transition semantics claim
```

Boundary:

```text id="c9anc4"
This defines PMS-UM execution.

It does not implement PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking, or
distributed PMS-STACK.

It does not validate PMS Base.

It does not turn traces into proofs.
```

### 5.1 Basic Step Form

The one-step transition relation is written:

```text id="c6e9ph"
C ⇒ C'
```

or, in expanded operator-labeled form:

```text id="5yzpzq"
κ --I/op--> κ'
```

If the current instruction pointer selects instruction `I_k`, then:

```text id="pdps41"
I_k = (op, params, pre, post)
```

with:

```text id="d8a0a3"
op ∈ O
```

A step is valid when:

```text id="fi9ezy"
(s⁺, π) ⇒ (s⁺', π)
```

iff:

```text id="tk3n68"
1. π ∈ Π
2. s⁺ is not halted
3. ip selects an instruction I_k in π
4. op(I_k) ∈ O
5. dependencies_available(op(I_k), κ) holds
6. params_valid(params(I_k), κ) holds
7. pre_I(κ) holds
8. boundary_allows(f, r, P, m, I_k) holds
9. policy_allows(P, I_k, κ) holds
10. profile_allows(profile, I_k) holds if a profile is declared
11. s⁺' ∈ post_I(s⁺)
12. the updated history remains in L_PMS or L_PMS,Ψ
```

For deterministic PMS-UM instances:

```text id="e2ht3y"
s⁺' = post_I(s⁺)
```

For nondeterministic PMS-UM instances:

```text id="lmxew4"
s⁺' ∈ post_I(s⁺)
```

The history update is:

```text id="b4rh4t"
h' = h · op
```

and the updated history must remain valid:

```text id="k4fjzi"
h' ∈ L_PMS
```

or, under active policy:

```text id="dwg2hk"
h' ∈ L_PMS,Ψ
```

This means one accepted step preserves the validity of the concrete execution history.

### 5.2 Step Pipeline

A PMS-UM step can be read as a structured pipeline.

```text id="svdzez"
1. configuration status check
2. policy pre-check
3. instruction fetch
4. operator tag check
5. parameter check
6. dependency check
7. instruction precondition check
8. boundary / reachability check
9. policy permission check
10. postcondition application
11. instruction-pointer update
12. history update
13. trace validity check
14. status update
```

This pipeline is an architectural reading.

A concrete implementation may fuse or reorder checks as long as semantic obligations remain preserved.

For example:

```text id="m0icf5"
policy check may be fused with precondition check

boundary check may be implemented as part of policy check

dependency check may be implemented by stateful validator

instruction fetch and operator tag check may be fused

history update may be part of trace emission
```

Optimization is valid only when the resulting transition preserves PMS-UM validity.

### 5.3 Configuration Status Check

Before stepping, PMS-UM checks whether the configuration is allowed to continue.

A configuration may be:

```text id="eil5t2"
active
halted
stuck
waiting
policy-denied
non-event
recontextualized
boundary-denied
commit-blocked
```

A step proceeds normally only from an active configuration.

If the configuration is halted:

```text id="4wexst"
κ ⇒ no successor
```

unless the PMS-UM instance defines explicit post-halt observation behavior.

If the configuration is waiting, a step may require an environment event or may take a Λ path.

If the configuration is policy-denied, it may halt, trap, audit, or recontextualize depending on the declared policy behavior.

This status check is part of the abstract-machine execution semantics.

It is not a PMS Base operator by itself.

### 5.4 Policy Pre-Check

A PMS-UM step occurs under active policy.

Let:

```text id="cj490k"
policy_ok(P, κ)
```

mean that the active Ψ constraints permit continuation.

If:

```text id="y7l5w1"
policy_ok(P, κ) = false
```

then the machine may:

```text id="ez723b"
halt
become stuck
enter a controlled recovery state
raise a Φ recontextualization path
produce a Ψ-denial event
withhold Σ
produce a Σ_audit event
```

The exact behavior is instance-specific.

The architectural requirement is that policy denial remains operator-typed.

Policy denial is not an unstructured failure.

A policy-denied transition path may be represented as:

```text id="fmqy91"
Ψ_deny Φ_error Σ_audit
```

or another declared operator-typed denial path.

### 5.5 Instruction Fetch

If:

```text id="x87w68"
1 ≤ ip ≤ n
```

then PMS-UM fetches:

```text id="39p90f"
I_ip = (op, params, pre, post)
```

If `ip` is outside the program range, or if `ip` is a halt marker, the machine is halted or stuck according to the machine definition.

Instruction fetch is not itself a new PMS Base operator.

It is part of the PMS-UM execution mechanism.

The fetched instruction, however, always carries a Δ–Ψ operator tag.

### 5.6 Operator Tag and Parameter Check

After fetch, PMS-UM checks:

```text id="o7wf9r"
op(I) ∈ O
```

and:

```text id="ep9j0y"
params_valid(params(I), κ)
```

Malformed instruction parameters reject the step even if the operator tag is valid.

Examples:

```text id="f2r9pn"
branch target outside π

unknown frame identifier

unknown policy identifier

commit handle without staged state

boundary identifier not present in m

pattern identifier not defined

role identifier not in R
```

Invalid parameters may produce:

```text id="x06n07"
stuck state
Φ_error
Ψ_denial
Σ_audit
```

depending on the PMS-UM instance.

The rejection path must be declared by the machine profile.

### 5.7 Dependency Check

Before executing an instruction, PMS-UM checks operator dependency availability.

Dependency validity is:

```text id="y49bye"
deps(op) ⊆ available(h, s, π, ip, e)
```

where availability may come from:

```text id="n2clu4"
operator history
active frame
active role/capability
active policy
meta-state markers
boundary state
committed history
pending expectations
pattern-expansion context
environment state
```

This is not mere adjacency.

A dependency may have been established earlier and recorded in state.

Example:

```text id="qzabgd"
∇_write
```

is valid only when its target has been distinguished and the relevant frame, role, boundary, and policy conditions are available.

Example:

```text id="xc2y80"
Σ_commit
```

is valid only when prior activity produced committable structure.

### 5.8 Precondition Check

Instruction-specific preconditions are evaluated after or together with dependency checks:

```text id="ufwjwq"
pre_I(κ) = true
```

The dependency check enforces the PMS-STACK execution discipline.

The precondition check enforces machine-specific requirements.

Examples:

```text id="axfm61"
symbol exists in current core state

frame exists in F

role belongs to R

policy belongs to PSet

pattern expansion exists

timeout expectation is pending

boundary exists in m

commit handle refers to staged state
```

A step is invalid if either dependency or precondition check fails.

### 5.9 Boundary / Reachability Check

Boundary-sensitive instructions require Χ-mediated validity.

Representative predicate:

```text id="nz3jpm"
boundary_allows(f, r, P, m, I) = true
```

This predicate checks whether the active frame, role, policy, and meta-state allow the instruction across the relevant boundary.

Examples:

```text id="p0fhvk"
write across protected subcontext

read from isolated abstract region

enter or exit sandbox

accept environment input through host boundary

commit across separated contexts

switch to handler with restricted visibility
```

This is the PMS-UM projection of PMS Base Χ as Distance.

It is not a PMS Base redefinition.

If boundary check fails, the machine may produce:

```text id="bpujw4"
Χ_violation
Ψ_denial
Φ_trap
Σ_audit
```

depending on the declared policy.

A fixed closed-machine boundary is still a boundary condition.

It is not the absence of Χ.

### 5.10 Policy Permission Check

Policy check determines whether active Ψ permits the transition.

Representative predicate:

```text id="xsp3yk"
policy_allows(P, I, κ) = true
```

Policy may:

```text id="ofhdoa"
allow
deny
halt
audit
delay
require recontextualization
require boundary condition
require role condition
require commit condition
```

A structurally valid instruction may fail policy:

```text id="ff8cya"
dependencies available
∧ pre_I(κ)
∧ boundary_allows(...)
∧ policy_allows(...) = false
```

The transition does not execute as a normal step.

It must enter a typed denial, halt, recontextualization, audit, or stuck path.

### 5.11 Applying the Instruction

If all validity checks pass, PMS-UM applies the instruction’s postcondition.

Deterministic case:

```text id="qgs5yo"
s⁺' = post_I(s⁺)
```

Nondeterministic case:

```text id="sdusfh"
s⁺' ∈ post_I(s⁺)
```

The postcondition updates state according to operator semantics.

Examples:

```text id="vg06u9"
Δ
    update distinction flags or branch metadata

∇
    mutate core state

□
    update active frame

Λ
    record absence or timeout

Α
    activate or expand pattern

Ω
    update or check role/capability state

Θ
    update ordering metadata

Φ
    switch to handler or recontextualized frame

Χ
    update boundary/reachability state

Σ
    commit staged state

Ψ
    update, enforce, or deny policy
```

The postcondition must preserve the operator’s structural role.

A successful postcondition is still valid only if the resulting state and updated history satisfy the declared PMS-UM validity rules.

### 5.12 Instruction Pointer Update

The instruction pointer is updated according to instruction semantics.

Sequential case:

```text id="lrk4fa"
ip' = ip + 1
```

Branching case:

```text id="08o9rw"
ip' = branch_target
```

Pattern expansion:

```text id="3wq8vf"
ip' = expansion_start
```

Handler or recontextualization:

```text id="ohr1if"
ip' = handler_target
```

Waiting:

```text id="c6slfm"
ip' = wait_marker
```

Halting:

```text id="vhnvyp"
ip' = halt
```

Stuckness:

```text id="3pt2pd"
ip' = stuck
```

The instruction pointer is an implementation-layer machine component.

It is not a PMS Base operator.

### 5.13 History Update

The operator history updates by concatenation:

```text id="yzkbdf"
h' = h · op
```

The updated history must satisfy:

```text id="5qgutx"
h' ∈ L_PMS
```

and, under active policy:

```text id="8taj49"
h' ∈ L_PMS,Ψ
```

If history validity fails, the step is invalid.

A PMS-UM instance may handle this by:

```text id="ig2jgd"
rejecting before state update
rolling back the postcondition
entering Φ_error
recording Ψ_denial
committing Σ_audit
becoming stuck
```

The implementation choice must be declared.

A valid concrete execution accumulates its history into a concrete trace:

```text id="l7rtme"
trace(κ₀ … κₙ) = o₁ o₂ … oₙ
```

with:

```text id="n2b39k"
trace(κ₀ … κₙ) ∈ L_PMS
```

or, under active policy:

```text id="eup1uw"
trace(κ₀ … κₙ) ∈ L_PMS,Ψ
```

### 5.14 Status Update

After a step, the resulting configuration status is recomputed.

Possible statuses include:

```text id="xkhkjh"
active
halted
stuck
waiting
policy-denied
non-event
recontextualized
boundary-denied
commit-blocked
```

Status is derived from:

```text id="kh8jjx"
s⁺'
ip'
P'
m'
S_H
available instructions
pending expectations
boundary state
committable state
policy state
```

A step may succeed and still place the machine into a waiting, halted, or recontextualized status.

Example:

```text id="hfhyjv"
Λ_timeout
```

may produce non-event status.

Example:

```text id="8pr6w3"
Φ_handler
```

may produce recontextualized status.

Example:

```text id="wx21a7"
Σ_halt
```

may produce halted status.

### 5.15 Halted and Stuck States

A PMS-UM run may end in several structurally distinct ways.

| End condition    | Meaning                                                               |
| ---------------- | --------------------------------------------------------------------- |
| halted           | state enters `S_H` or `ip = halt`                                     |
| stuck            | no valid instruction applies, but the machine is not halted           |
| policy-denied    | Ψ forbids continuation                                                |
| absent event     | Λ records expected event failure                                      |
| recontextualized | Φ moves execution into a new handler/context                          |
| boundary-denied  | Χ / Ψ blocks unsafe reachability                                      |
| commit failure   | Σ cannot integrate because committable structure is absent or invalid |

This distinction matters.

PMS-UM does not collapse all failure into one untyped error.

Failure, absence, denial, boundary rejection, commit failure, and recontextualization remain operator-typed.

### 5.16 Multi-Step Runs

A run of PMS-UM on program `π` from initial state `s₀⁺` is a sequence:

```text id="own3lo"
(s₀⁺, π) ⇒ (s₁⁺, π) ⇒ (s₂⁺, π) ⇒ …
```

In full configuration form:

```text id="gpzzn9"
κ₀ --I₁/o₁--> κ₁ --I₂/o₂--> κ₂ ... --Iₙ/oₙ--> κₙ
```

The associated operator trace is:

```text id="zaulbe"
trace(κ₀ … κₙ) = o₁ o₂ … oₙ
```

A finite run halts if:

```text id="rc60t1"
sₙ⁺ ∈ S_H
```

or:

```text id="4wc06b"
ipₙ = halt
```

A run diverges if it continues indefinitely without halting.

A run gets stuck if no valid instruction applies and the state is not a halting state.

A big-step evaluation may be written:

```text id="nawuc1"
(s₀⁺, π) ⇓ s_f⁺
```

meaning that zero or more valid steps lead to a final halting state:

```text id="bb6pml"
s_f⁺ ∈ S_H
```

The big-step notation is derivative.

The one-step relation remains the primary PMS-UM execution definition.

### 5.17 Trace Semantics

The trace of one concrete run is:

```text id="wncxx8"
trace(κ₀ … κₙ) = o₁ o₂ … oₙ
```

For valid execution:

```text id="rfnxfd"
trace(κ₀ … κₙ) ∈ L_PMS
```

and, under active policy:

```text id="q8favl"
trace(κ₀ … κₙ) ∈ L_PMS,Ψ
```

For a declared machine, program, initial state, and execution profile, the set of possible runs is:

```text id="lqgz4u"
Trace(M, π, s₀) = { w₁, w₂, …, wₙ }
```

with:

```text id="s7ic0y"
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="tywoqs"
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

A trace may be enriched with metadata:

```text id="ntdl2h"
event = (
    step,
    op,
    instruction,
    frame,
    role,
    policy,
    boundary,
    params,
    result,
    status,
    meta
)
```

Trace metadata supports:

```text id="rnc3cd"
debugging
validation
audit
replay
fixture comparison
homomorphism evidence
artifact evidence
```

Boundary:

```text id="48ca1x"
A concrete trace records one observed or selected run under a declared
PMS-UM instance or profile.

It is not proof of all possible behavior.

It does not enumerate the full Trace(...) set.

It is not PMS Base validation.
```

Validation in this context means acceptance or rejection under a declared schema, profile, model, validator, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 5.18 Deterministic Step Relation

A deterministic PMS-UM instance satisfies:

```text id="diqjck"
∀κ: | { κ' | κ ⇒ κ' } | ≤ 1
```

This typically requires:

```text id="ln75ri"
one instruction selected by ip
functional postconditions
unique policy result
unique boundary result
unique scheduler/progression result
no environment race
```

For deterministic instruction postcondition:

```text id="08hqby"
post_I : S⁺ → S⁺
```

A valid step produces exactly one successor.

A deterministic run from a fixed machine, program, initial state, environment, and profile produces one concrete trace:

```text id="n0kog7"
trace(M, π, s₀) ∈ L_PMS
```

or, under active policy:

```text id="ya0bc1"
trace(M, π, s₀) ∈ L_PMS,Ψ
```

This is the mode used for deterministic Turing-machine encoding.

### 5.19 Nondeterministic Step Relation

A nondeterministic PMS-UM instance permits:

```text id="3fv1wz"
∃κ: | { κ' | κ ⇒ κ' } | > 1
```

This may arise from:

```text id="uerwg5"
relational postconditions
multiple enabled instructions
environment input
scheduler interleavings
symbolic execution
policy alternatives
absence / timeout alternatives
recontextualization paths
```

For nondeterministic postcondition:

```text id="ggs2b3"
post_I : S⁺ → P(S⁺)
```

A valid step chooses:

```text id="kkfc75"
s⁺' ∈ post_I(s⁺)
```

Nondeterminism does not mean unstructured execution.

Every possible trace must remain in:

```text id="bsgkc5"
L_PMS
```

and, under active policy:

```text id="hrot87"
L_PMS,Ψ
```

Equivalently, the nondeterministic Trace set must satisfy:

```text id="jp1755"
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="obxh6p"
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

### 5.20 Rejection and Rollback

A PMS-UM instance may reject a step before committing its postcondition.

Typical rejection points:

```text id="30qg78"
operator tag invalid
params invalid
dependency unavailable
precondition false
boundary check failed
policy denied
postcondition would violate invariant
history would leave L_PMS or L_PMS,Ψ
```

Rejection may be represented as:

```text id="z563qc"
Ψ_denial
Φ_error
Χ_violation
Λ_absence
Σ_audit
stuck
halt
```

If a postcondition has partially updated state before validation fails, the PMS-UM instance must either:

```text id="ys9cd6"
roll back
```

or:

```text id="lvr54z"
represent the partial update as an explicit operator-typed failure path
```

Silent invalid mutation is not PMS-UM-conformant.

Rollback is an implementation-layer recovery convention.

It does not convert invalid execution into valid execution unless the rollback path itself is operator-typed and policy-valid.

### 5.21 Step Relation Invariants

```text id="lyxqid"
UM-SR1: PMS-UM steps are operator-labeled transitions

UM-SR2: a step is selected by program, instruction pointer, and configuration

UM-SR3: π ∈ Π for the active PMS-UM program

UM-SR4: the selected instruction must have op ∈ O

UM-SR5: parameters must be valid for the machine instance

UM-SR6: dependencies must be available before execution

UM-SR7: instruction preconditions must hold

UM-SR8: boundary-sensitive transitions require valid Χ projection

UM-SR9: active Ψ policy must permit the transition

UM-SR10: postconditions must preserve the operator's mutation discipline

UM-SR11: each successful step appends the operator tag to history

UM-SR12: updated history must remain in L_PMS or L_PMS,Ψ

UM-SR13: trace(...) denotes one concrete PMS-UM execution

UM-SR14: Trace(...) denotes the set of possible PMS-UM executions under a
         declared machine/profile

UM-SR15: halted and stuck states are distinct

UM-SR16: rejection, denial, absence, boundary failure, and recontextualization
         are operator-typed

UM-SR17: deterministic and nondeterministic step relations are both valid
         PMS-UM profiles when trace and Trace-set validity are preserved

UM-SR18: validation means acceptance or rejection under a declared profile,
         schema, model, fixture, gate, or conformance rule

UM-SR19: PMS-UM step semantics define abstract-machine execution and do not
         validate PMS Base
```

### 5.22 Architectural Consequence

The PMS-UM step relation is the abstract-machine specialization of the PMS-STACK transition relation.

Its central form is:

```text id="iuzkiv"
operator-typed instruction
+ dependency check
+ frame / role / boundary / policy check
+ state transition
+ valid trace update
```

This establishes PMS-UM as a disciplined abstract execution model rather than a generic automaton.

Concrete implementations, validators, simulators, and artifacts may evidence slices of this step relation when they state:

```text id="boln0w"
supported program subset
declared profile
accepted and rejected cases
trace output
limitations
```

That strengthens bounded implementation-artifact claims.

It does not complete PMS-STACK and does not validate PMS Base.

### 5.23 Boundary Statement

The correct boundary for this chapter is:

```text id="g95jff"
The PMS-UM step relation defines how operator-typed instructions advance
machine configurations under dependency, state, boundary, commit, profile,
and policy constraints.

It provides the abstract execution semantics for PMS-STACK.

A concrete run produces trace(...).

A declared machine/program/profile determines Trace(...).

This is an abstract-machine transition semantics claim.

It does not implement PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking, or
distributed PMS-STACK. It does not turn traces into proofs, Trace sets into
external validation, validators into PMS Base validation, or artifacts into
PMS-STACK completion.
```

---

## 6. Operator Semantics Δ–Ψ

This section defines the PMS-UM instruction semantics for each operator.

The execution-oriented state is:

```text id="yts6ho"
s⁺ = (s_c, f, r, P, m, ip)
```

A full configuration is:

```text id="g4v6j1"
κ = (s, π, ip, h, e)
```

where:

```text id="a0p1uw"
π ∈ Π
```

Each instruction has the form:

```text id="aq62l7"
I = (op, params, pre, post)
```

where:

```text id="zv8s2g"
op ∈ O
```

The semantics below specify:

```text id="3zwqgc"
required precondition structure
typical postcondition structure
allowed state effects
failure modes
architectural invariant
```

Concrete PMS-CPU, PMS-OS, PMSL/PMS-IR, runtime-security, networking, and distributed-system layers refine these semantics into their own instruction forms.

PMS-UM fixes the abstract operator-typed machine behavior.

The central semantics claim is:

```text id="q6ogxt"
Every PMS-UM instruction is an operator-labeled transition whose
preconditions, postconditions, state effects, and failure modes are typed
by Δ–Ψ.
```

Claim type:

```text id="cvv121"
abstract-machine operator-semantics claim
```

Boundary:

```text id="obnaq0"
This defines PMS-UM operator semantics.

It does not redefine PMS Base.

It does not implement PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking, or
distributed PMS-STACK.

It does not validate PMS Base.

It does not turn abstract operator semantics into completed artifact
evidence.
```

### 6.1 Δ — Difference / Distinction

Δ creates or detects a distinction.

Instruction form:

```text id="n9fhur"
I_Δ = (Δ, params, pre_Δ, post_Δ)
```

Typical PMS-UM roles:

```text id="rwh4lq"
read symbol
classify state
compare value
select branch
distinguish target
distinguish rule
distinguish object
distinguish event
distinguish condition
```

Typical precondition:

```text id="6pvavf"
pre_Δ(κ)
```

requires that the inspected object, symbol, state region, instruction field, or branch condition is available in the current frame.

Because Δ is the minimal semantic distinction, its dependency requirements are usually minimal.

Domain-specific requirements may still apply:

```text id="u9ysmg"
frame validity
readability
symbol availability
policy-permitted observation
```

Typical postcondition:

```text id="dq391f"
s_c' = s_c
```

Δ does not primarily mutate core state.

It may update meta-state:

```text id="v8j1va"
m'.distinction = result
m'.branch_flag = result
m'.last_read = value
m'.history = m.history · Δ
```

It may update control position:

```text id="qowfsm"
ip' = ip + 1
```

or branch:

```text id="yomx8x"
ip' = branch_target
```

Allowed state effects:

| Component | Typical effect                                                  |
| --------- | --------------------------------------------------------------- |
| `s_c`     | unchanged, unless the machine records observation in core state |
| `f`       | unchanged                                                       |
| `r`       | unchanged                                                       |
| `P`       | unchanged                                                       |
| `m`       | updates distinction/branch/read metadata                        |
| `ip`      | advances or branches                                            |

Failure modes:

```text id="3bn8ck"
inspected object unavailable

frame does not contain the target

policy forbids observation

branch target invalid
```

Architectural invariant:

```text id="c567dt"
Δ distinguishes before action.
```

Δ is observational with respect to core state. It classifies, selects, compares, or branches; it does not perform the main mutation.

### 6.2 ∇ — Impulse / Enactment

∇ performs directed action.

Instruction form:

```text id="k6wmbb"
I_∇ = (∇, params, pre_∇, post_∇)
```

Typical PMS-UM roles:

```text id="1v9fog"
write symbol
update cell
move pointer
enqueue
dequeue
allocate
mutate store
perform arithmetic update
perform abstract action
accept input
send output
```

Typical precondition:

```text id="vsg3z3"
pre_∇(κ)
```

must ensure that:

```text id="0pt3hn"
a relevant Δ distinction is available
```

and, where needed:

```text id="6cl8gt"
active frame f is valid
active role r authorizes the action
active Χ boundary permits reachability
active policy P permits the action
```

Typical postcondition:

```text id="j5xdo7"
s_c' = A_∇(s_c, f, r, params)
```

where `A_∇` is a machine-specific action function or relation.

The frame, role, and policy usually remain stable:

```text id="oyqypo"
f' = f
r' = r
P' = P
```

unless the action itself is defined to alter them through explicit Ω, Φ, Χ, Σ, or Ψ structure.

Meta-state may record:

```text id="bajyd0"
m'.action_log = ...
m'.committable_state = updated
m'.history = m.history · ∇
```

Control usually advances:

```text id="iqvly8"
ip' = ip + 1
```

Allowed state effects:

| Component | Typical effect                                         |
| --------- | ------------------------------------------------------ |
| `s_c`     | primary mutation                                       |
| `f`       | usually unchanged                                      |
| `r`       | usually unchanged                                      |
| `P`       | usually unchanged                                      |
| `m`       | updates action log / staged state / dependency markers |
| `ip`      | advances or follows action-specific control            |

Failure modes:

```text id="dhrxi4"
no distinguished target

target not in current frame

role/capability missing

boundary forbids access

policy forbids mutation

postcondition would violate invariant
```

Architectural invariant:

```text id="c4apm3"
∇ is the primary state-changing action operator.
```

An ∇ instruction without a distinguished target is invalid.

### 6.3 □ — Frame / Context

□ establishes, enters, exits, or switches context.

Instruction form:

```text id="65lscm"
I_□ = (□, params, pre_□, post_□)
```

Typical PMS-UM roles:

```text id="hsyhrj"
enter frame
exit frame
switch frame
create local context
activate subprogram context
enter macro-expansion context
select protected subcontext
establish scope
```

Typical precondition:

```text id="785zbv"
pre_□(κ)
```

must ensure that:

```text id="uk9qdf"
target frame is distinguished
∧ frame exists or can be validly created
∧ role and policy permit frame entry / exit / switch
```

Typical postcondition:

```text id="8e4c66"
f' = f_new
```

The core state is usually not primarily mutated:

```text id="jyi9a3"
s_c' = s_c
```

but the active view of `s_c` may change because interpretation is now frame-relative.

Meta-state may record:

```text id="706sbx"
m'.frame_stack = update_frame_stack(...)
m'.active_context = f_new
m'.history = m.history · □
```

Control usually advances:

```text id="8t3mhz"
ip' = ip + 1
```

Allowed state effects:

| Component | Typical effect                                |
| --------- | --------------------------------------------- |
| `s_c`     | unchanged or re-viewed under new frame        |
| `f`       | primary update                                |
| `r`       | may be restricted by frame                    |
| `P`       | may activate frame-scoped policies            |
| `m`       | updates frame stack / context metadata        |
| `ip`      | advances or enters frame-specific entry point |

Failure modes:

```text id="u08itf"
frame not distinguished

frame does not exist

role lacks authority to enter frame

policy forbids frame transition

frame switch would violate boundary
```

Architectural invariant:

```text id="z5n1tm"
□ grounds contextual meaning.
```

A frame is not merely a container. It determines where symbols, resources, roles, policies, and transitions have meaning.

A fixed execution frame is not the absence of □ structure.

It is a declared frame condition without dynamic frame switching.

### 6.4 Λ — Non-Event / Absence

Λ represents meaningful absence.

Instruction form:

```text id="itcrd5"
I_Λ = (Λ, params, pre_Λ, post_Λ)
```

Typical PMS-UM roles:

```text id="ai2i3l"
timeout
no input
empty queue
missing symbol
failed poll
no applicable event
missing response
absence branch
```

Typical precondition:

```text id="4kduwl"
pre_Λ(κ)
```

requires an expectation context.

Expectation may come from:

```text id="x83hgv"
ordered wait
prior request
pending receive
timer or deadline in meta-state
empty queue check
failed poll
protocol expectation
environment input expectation
```

Typical postcondition:

```text id="4ysgoz"
s_c' = s_c
```

Λ does not perform the expected main action.

It records that the expected event did not occur.

Meta-state may update:

```text id="plvsc7"
m'.non_event = true
m'.timeout_marker = ...
m'.pending_expectation = resolved_or_failed
m'.history = m.history · Λ
```

Control may continue:

```text id="crsid2"
ip' = ip + 1
```

or branch to absence handling:

```text id="yv1om9"
ip' = absence_handler
```

Allowed state effects:

| Component | Typical effect                                       |
| --------- | ---------------------------------------------------- |
| `s_c`     | unchanged                                            |
| `f`       | unchanged                                            |
| `r`       | unchanged                                            |
| `P`       | unchanged unless policy records absence              |
| `m`       | updates absence/timeout/pending expectation metadata |
| `ip`      | advances or branches to absence handler              |

Failure modes:

```text id="8m9w0o"
no expectation exists

absence asserted in wrong frame

timeout marker invalid

policy forbids absence path

absence handler missing
```

Architectural invariant:

```text id="5h5x5t"
Λ requires expectation.
```

Absence is meaningful only where something was expected.

### 6.5 Α — Attractor / Pattern

Α provides reusable operator structure.

Instruction form:

```text id="bn1v1s"
I_Α = (Α, params, pre_Α, post_Α)
```

Typical PMS-UM roles:

```text id="ivzau6"
macro expansion
loop pattern
rule-template activation
protocol template
transition pattern
reusable operator word
subprogram pattern
```

Typical precondition:

```text id="wwvxt2"
pre_Α(κ)
```

must ensure that:

```text id="btdi3x"
pattern is defined
∧ its expansion is PMS-valid
∧ policy permits expansion or activation
```

Α may be interpreted statically:

```text id="y1vlyb"
Α(pattern) ⇒ w_pattern
```

or dynamically:

```text id="1fozv5"
post_Α(κ) inserts, activates, or selects w_pattern
```

where:

```text id="3gzxts"
w_pattern ∈ L_PMS
```

and, under active policy:

```text id="pdyevl"
w_pattern ∈ L_PMS,Ψ
```

Typical postcondition may update:

```text id="u8l4ad"
m'.active_pattern = pattern_id
m'.expansion_state = ...
m'.history = m.history · Α
```

Control may move to the first expanded instruction:

```text id="jfwzvu"
ip' = expansion_start
```

or continue after static expansion:

```text id="vj0vn8"
ip' = ip + 1
```

Allowed state effects:

| Component | Typical effect                     |
| --------- | ---------------------------------- |
| `s_c`     | usually unchanged                  |
| `f`       | may enter pattern frame            |
| `r`       | usually unchanged                  |
| `P`       | may activate pattern-scoped policy |
| `m`       | updates expansion/pattern metadata |
| `ip`      | enters expansion or advances       |

Failure modes:

```text id="phgz9v"
pattern undefined

expansion not in L_PMS

expansion violates active Ψ

pattern target invalid

pattern expansion would bypass dependency, boundary, or policy constraints
```

Architectural invariant:

```text id="85r5o8"
Α must expand to PMS-valid operator structure.
```

Α does not introduce a new primitive outside Δ–Ψ. It packages and reuses valid operator structure.

### 6.6 Ω — Asymmetry / Role

Ω establishes, checks, changes, or records role, authority, capability, or privilege asymmetry.

Instruction form:

```text id="ox1cmp"
I_Ω = (Ω, params, pre_Ω, post_Ω)
```

Typical PMS-UM roles:

```text id="rrf9ci"
check role
assume role
switch role
grant capability
revoke capability
verify authority
establish actor asymmetry
deny authority
```

Typical precondition:

```text id="5lu3vl"
pre_Ω(κ)
```

must ensure that:

```text id="brzy1u"
relevant role or capability relation is distinguished
∧ current role may check, assume, delegate, revoke, or switch
∧ active policy permits the role operation
```

Typical postcondition may update role context:

```text id="fqhkgj"
r' = r_new
```

or confirm current role:

```text id="cx9xie"
r' = r
```

Core state is usually unchanged:

```text id="owaz08"
s_c' = s_c
```

unless capability state is encoded inside `s_c`.

Meta-state may record:

```text id="yn33bp"
m'.role_check = result
m'.capability_event = ...
m'.history = m.history · Ω
```

Control may continue:

```text id="g69lmt"
ip' = ip + 1
```

or branch on denial:

```text id="n7zqlo"
ip' = denied_or_handler_target
```

Allowed state effects:

| Component | Typical effect                             |
| --------- | ------------------------------------------ |
| `s_c`     | usually unchanged                          |
| `f`       | unchanged                                  |
| `r`       | primary update or check                    |
| `P`       | unchanged unless policy-driven role update |
| `m`       | updates role/capability metadata           |
| `ip`      | advances or branches on authority result   |

Failure modes:

```text id="xb7l0a"
role relation not distinguished

role not in R

capability missing

delegation not permitted

policy forbids role transition

authority check fails
```

Architectural invariant:

```text id="4psz51"
Ω gates privileged action.
```

Ω does not perform the protected action itself. It establishes or verifies who may perform it.

A fixed role is not the absence of Ω structure.

It is a declared role context without dynamic role switching.

### 6.7 Θ — Temporality / Ordering

Θ imposes ordering and progression.

Instruction form:

```text id="yiix59"
I_Θ = (Θ, params, pre_Θ, post_Θ)
```

Typical PMS-UM roles:

```text id="j80j7x"
advance step
order transition
advance phase
record sequencing
schedule next context
mark happens-before
advance retry
advance wait
advance logical computation cycle
```

Typical precondition:

```text id="tjm8u6"
pre_Θ(κ)
```

requires an ordering context, such as:

```text id="xhzp6l"
sequence metadata
phase metadata
pending wait state
scheduler metadata
retry structure
logical progression state
prior action or expectation
```

Typical postcondition updates meta-state:

```text id="dbpjac"
m'.step = m.step + 1
m'.order = update_order(m.order)
m'.history = m.history · Θ
```

Core state is usually not primarily mutated:

```text id="d6ig85"
s_c' = s_c
```

Control usually advances:

```text id="tmpkt1"
ip' = ip + 1
```

or follows structured control semantics.

Allowed state effects:

| Component | Typical effect                             |
| --------- | ------------------------------------------ |
| `s_c`     | usually unchanged                          |
| `f`       | unchanged                                  |
| `r`       | unchanged                                  |
| `P`       | unchanged                                  |
| `m`       | primary ordering/progression update        |
| `ip`      | advances or follows scheduler/control rule |

Failure modes:

```text id="wv9zkp"
no progression target

ordering metadata invalid

scheduler context missing

policy forbids progression

ordering would violate invariant
```

Architectural invariant:

```text id="i1y6wq"
Θ orders transitions; it is not physical time itself.
```

Physical time, clocks, deadlines, durations, and timestamps are data in meta-state, often represented through `τ`. Θ orders transitions that may read or update such data.

### 6.8 Φ — Recontextualization / Shift

Φ changes the interpretive or execution context of a situation.

Instruction form:

```text id="es2wt9"
I_Φ = (Φ, params, pre_Φ, post_Φ)
```

Typical PMS-UM roles:

```text id="e5bpaw"
enter handler
trap
exception
fallback
recover
migrate context
reinterpret state
branch to error context
switch version/context
handle policy denial
handle boundary violation
```

Typical precondition:

```text id="871ngh"
pre_Φ(κ)
```

must ensure that:

```text id="79d0m4"
there is something to recontextualize
∧ an active frame or cause exists
∧ a meaningful continuation or handler exists
```

The cause may be:

```text id="vj6clh"
exception
trap
failed policy check
type mismatch
version change
migration condition
fallback condition
boundary violation
undefined transition
```

Typical postcondition may update:

```text id="smxx5r"
f' = f_new
r' = r_new
P' = P_new
m'.handler = ...
m'.recontextualization_cause = ...
ip' = handler_or_new_context
```

Core state may remain unchanged:

```text id="mmxuly"
s_c' = s_c
```

or may be transformed if recontextualization includes migration or recovery:

```text id="lcc46y"
s_c' = migrate_or_recover(s_c, params)
```

Allowed state effects:

| Component | Typical effect                                    |
| --------- | ------------------------------------------------- |
| `s_c`     | unchanged or transformed under recovery/migration |
| `f`       | may change                                        |
| `r`       | may change                                        |
| `P`       | may change or activate handler policy             |
| `m`       | updates handler/cause/context metadata            |
| `ip`      | jumps to handler or new context                   |

Failure modes:

```text id="58157z"
no cause

no active context

handler missing

continuation invalid

policy forbids recontextualization

recontextualization erases required trace context
```

Architectural invariant:

```text id="bhtv9f"
Φ changes context without untyped erasure.
```

The prior state remains structurally recoverable, auditable, or meaningfully transformed.

### 6.9 Χ — Distance / Implementation-Layer Boundary Projection

In PMS Base 1.3, Χ denotes Distance.

In PMS-UM, Χ is projected into the abstract machine as boundary, reachability, access-separation, sandbox, visibility, or protected-subcontext structure.

Instruction form:

```text id="bgvq19"
I_Χ = (Χ, params, pre_Χ, post_Χ)
```

Typical PMS-UM roles:

```text id="y9zg85"
enter boundary
exit boundary
check reachability
partition context
restrict view
create sandbox
quarantine context
separate subcontext
protect store region
```

Typical precondition:

```text id="pygncd"
pre_Χ(κ)
```

must ensure that:

```text id="ixhkv8"
an active frame or domain exists
∧ boundary operation is distinguished
∧ role and policy permit the boundary operation
```

For boundary exit, the precondition is stricter:

```text id="wja7jj"
pre_Χ_exit(κ)
    requires active boundary context
    ∧ role and policy permit exit
    ∧ declared machine/profile permits boundary closure
```

Unbalanced boundary exit is invalid:

```text id="jh6qd1"
Χ_exit without active boundary context
    → invalid transition
```

Typical postcondition may update meta-state:

```text id="v6w0sp"
m'.boundary_graph = update_boundary_graph(...)
m'.reachability = update_reachability(...)
m'.visibility = update_visibility(...)
m'.quarantine = update_quarantine(...)
m'.history = m.history · Χ
```

It may also update frame or role context:

```text id="9jwi46"
f' = restricted_or_partitioned_frame
r' = restricted_role
```

Core state may be unchanged, duplicated, partitioned, restricted, or viewed through a boundary relation:

```text id="5br0zo"
s_c' = s_c
```

or:

```text id="mwe2bn"
s_c' = partition_or_restrict(s_c, params)
```

Allowed state effects:

| Component | Typical effect                                         |
| --------- | ------------------------------------------------------ |
| `s_c`     | unchanged, restricted, partitioned, or boundary-viewed |
| `f`       | may restrict or partition frame context                |
| `r`       | may restrict role context                              |
| `P`       | may activate boundary policy                           |
| `m`       | primary boundary/reachability/visibility update        |
| `ip`      | advances or branches on boundary result                |

Failure modes:

```text id="vwldpi"
no active frame/domain

boundary operation not distinguished

role lacks boundary authority

policy forbids boundary transition

reachability violation

boundary state inconsistent

boundary exit without active boundary context
```

Architectural invariant:

```text id="4x1c2b"
Χ preserves Distance as boundary/reachability discipline in the
implementation layer.
```

Χ does not redefine PMS Base Distance as mere sandboxing. Sandboxing, isolation, reachability control, and access separation are PMS-UM projections of Distance.

A fixed or trivial closed-machine boundary is not the absence of Χ.

It is a declared boundary condition without dynamic boundary transition.

### 6.10 Σ — Integration / Commit

Σ integrates, commits, or finalizes prior activity.

Instruction form:

```text id="m46txm"
I_Σ = (Σ, params, pre_Σ, post_Σ)
```

Typical PMS-UM roles:

```text id="4cu00b"
commit staged state
integrate prior action
finalize transaction
commit output
commit accepted input
commit recovery result
commit audit record
halt commit
clear pending state
```

Typical precondition:

```text id="7t9w5m"
pre_Σ(κ)
```

must ensure that:

```text id="haupq4"
committable prior structure exists
∧ relevant boundary conditions are satisfied
∧ active policy permits commit
```

Committable prior structure may come from:

```text id="4p2vg0"
prior ∇ action
staged writes
ordered progression
transaction state
pattern expansion results
protocol delivery
recovery state
accepted environment input
```

Typical postcondition:

```text id="k3qvij"
s_c' = C_Σ(s_c, f, m, params)
```

where `C_Σ` is a commit or integration function/relation.

Meta-state may update:

```text id="s08x23"
m'.pending = cleared
m'.committable_state = cleared
m'.commit_log = append(...)
m'.history = m.history · Σ
```

Control usually advances:

```text id="pdj91d"
ip' = ip + 1
```

or enters an after-commit continuation.

Allowed state effects:

| Component | Typical effect                             |
| --------- | ------------------------------------------ |
| `s_c`     | integrates or commits prior changes        |
| `f`       | usually unchanged                          |
| `r`       | usually unchanged                          |
| `P`       | may activate post-commit policy            |
| `m`       | updates commit logs / clears pending state |
| `ip`      | advances or enters after-commit target     |

Failure modes:

```text id="6b7lko"
no committable prior state

boundary invalid at commit time

policy denies commit

commit target invalid

commit would violate invariant
```

Architectural invariant:

```text id="431cqx"
Σ requires committable prior activity.
```

A commit with nothing to integrate is invalid.

### 6.11 Ψ — Self-Binding / Policy

Ψ defines, updates, activates, enforces, denies, or binds policy, invariant, contract, or self-binding constraint.

Instruction form:

```text id="774wfq"
I_Ψ = (Ψ, params, pre_Ψ, post_Ψ)
```

Typical PMS-UM roles:

```text id="sj5lw6"
install policy
activate policy
enforce policy
deny transition
bind invariant
check invariant
halt by policy
require audit
require boundary
require role
restrict future language
```

Typical precondition:

```text id="h3ct2i"
pre_Ψ(κ)
```

must ensure that:

```text id="onwz58"
policy object, scope, invariant, or governance condition is distinguished
∧ current role may define, update, or enforce it
∧ active frame gives it scope
```

Ψ has two primary PMS-UM modes.

#### Policy definition or activation

A Ψ instruction may update the active policy set:

```text id="nw4wkm"
P' = U_Ψ(P, params)
```

Core state usually remains unchanged:

```text id="krke6z"
s_c' = s_c
```

Meta-state records policy activation:

```text id="zkcvrl"
m'.policy_event = ...
m'.history = m.history · Ψ
```

#### Policy enforcement or denial

A Ψ instruction may evaluate:

```text id="yq2pbu"
policy_ok(P, κ)
```

If policy permits continuation:

```text id="15d7pa"
s⁺' = s⁺ with audit/meta updates
ip' = ip + 1
```

If policy denies continuation, PMS-UM may:

```text id="0jvkk0"
halt
become stuck
branch to recovery
trigger Φ
withhold Σ
roll back
record policy-denial event
commit audit record
```

Allowed state effects:

| Component | Typical effect                                              |
| --------- | ----------------------------------------------------------- |
| `s_c`     | usually unchanged, except recovery/enforcement side effects |
| `f`       | may define policy scope                                     |
| `r`       | may require authority                                       |
| `P`       | primary update/check                                        |
| `m`       | updates enforcement/audit/denial metadata                   |
| `ip`      | advances, halts, denies, or branches                        |

Failure modes:

```text id="m8jwhz"
policy object not distinguished

scope missing

role lacks authority

policy malformed

policy denies continuation

policy update would violate higher-order policy
```

Architectural invariant:

```text id="i0wutk"
Ψ restricts future valid execution.
```

Ψ induces policy-constrained sublanguages:

```text id="nv9cy7"
L_PMS,Ψ ⊆ L_PMS
```

A structurally valid instruction sequence may still be invalid under active Ψ.

### 6.12 Operator Semantics Summary Table

| Operator | Primary PMS-UM role                  | Primary state effects                                                                                              |
| -------- | ------------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| Δ        | distinguish / classify / branch      | updates `m`, branch/control state, `ip`; does not primarily mutate `s_c`                                           |
| ∇        | act / mutate / execute               | updates `s_c`, `m`, `ip`                                                                                           |
| □        | frame / context                      | updates `f`, contextual metadata, `ip`; fixed frame remains declared □ structure                                   |
| Λ        | absence / non-event                  | updates `m`, pending expectation state, `ip`                                                                       |
| Α        | pattern / macro / reusable structure | updates expansion state, `m`, `ip`; expands to valid operator words                                                |
| Ω        | role / capability / authority        | updates or checks `r`, authorization metadata, `ip`; fixed role remains declared Ω structure                       |
| Θ        | ordering / progression               | updates `m`, ordering metadata, `ip`                                                                               |
| Φ        | recontextualization / handler shift  | may update `f`, `r`, `P`, `m`, `ip`, and sometimes `s_c`                                                           |
| Χ        | Distance projection / boundary       | updates boundary graph, reachability metadata, frame separation state; fixed boundary remains declared Χ structure |
| Σ        | integration / commit                 | updates `s_c`, commit state, durable/integrated state, `m`, `ip`                                                   |
| Ψ        | policy / invariant / self-binding    | updates or checks `P`, enforcement state, audit metadata, recovery path                                            |

### 6.13 Operator Semantics Failure Table

| Operator | Failure mode                                                     | Typed handling                        |
| -------- | ---------------------------------------------------------------- | ------------------------------------- |
| Δ        | target unavailable or ambiguous                                  | stuck, Φ_error, Ψ_deny                |
| ∇        | action without distinguished target or authority                 | Ψ_deny, Φ_error, Σ_audit              |
| □        | invalid frame transition                                         | Φ_error, Ψ_deny                       |
| Λ        | no expectation exists                                            | stuck, Φ_error                        |
| Α        | expansion invalid                                                | Φ_error, Ψ_deny                       |
| Ω        | role/capability missing                                          | Ψ_deny, Φ_error, Σ_audit              |
| Θ        | no meaningful progression target                                 | stuck, Φ_error                        |
| Φ        | no cause, frame, or continuation                                 | stuck, Ψ_deny                         |
| Χ        | no frame/domain, boundary forbidden, or unbalanced boundary exit | Χ_violation, Ψ_deny, Φ_error, Σ_audit |
| Σ        | no committable state                                             | commit-blocked, Φ_error, Σ_audit      |
| Ψ        | malformed policy, missing authority, or denial                   | halt, stuck, Φ, Σ_audit               |

The typed handling column is not mandatory behavior for every PMS-UM instance.

It names architecturally valid ways to represent failure.

Silent invalid mutation is not PMS-UM-conformant.

### 6.14 Minimal Classical Computation Subset

Classical deterministic computation can be encoded using a subset of PMS-UM operators.

The minimal Turing-machine subset uses:

```text id="cyj12f"
Δ
∇
Θ
Σ or Ψ for declared halting / closure convention
```

with fixed or trivial:

```text id="e1gmpj"
□
Ω
Χ
```

and optional:

```text id="d8jpw7"
Λ
Α
Φ
```

This does not weaken the full PMS-UM operator set.

It clarifies the expressiveness claim.

PMS-UM is specified as computationally expressive because it contains a valid operator-typed subset sufficient to simulate deterministic classical computation.

The fixed/trivial operators are still declared structures:

```text id="bba87c"
□ = fixed TM execution frame

Ω = fixed TM execution role

Χ = fixed/trivial closed-machine boundary
```

The TM encoding does not require dynamic `□`, `Ω`, or `Χ` transitions.

It does not remove frame, role, or boundary structure from PMS-UM.

The full operator set makes PMS-UM a richer systems architecture substrate: computation occurs with frames, roles, boundaries, non-events, recontextualization, commits, and policies.

### 6.15 Operator Semantics Invariants

```text id="3vlcz9"
UM-OS1: every PMS-UM instruction is tagged by one Δ–Ψ operator

UM-OS2: π ∈ Π for the active PMS-UM program

UM-OS3: operator tags determine precondition structure and allowed state effects

UM-OS4: Δ distinguishes but does not primarily mutate core state

UM-OS5: ∇ performs primary state-changing action

UM-OS6: □ establishes context; fixed frame is declared □ structure, not
        absence of frame

UM-OS7: Λ requires expectation

UM-OS8: Α expands to valid operator structure

UM-OS9: Ω establishes or checks role/capability asymmetry; fixed role is
        declared Ω structure, not absence of role

UM-OS10: Θ orders transitions and is not wall-clock time itself

UM-OS11: Φ recontextualizes without untyped erasure

UM-OS12: PMS Base Χ = Distance

UM-OS13: PMS-UM projects Χ as abstract-machine boundary, reachability,
         visibility, access-separation, sandboxing, and quarantine discipline

UM-OS14: fixed/trivial closed-machine boundary is declared Χ structure, not
         absence of boundary

UM-OS15: boundary exit requires an active boundary context; unbalanced exit
         is invalid

UM-OS16: Σ integrates or commits prior committable structure

UM-OS17: Ψ restricts future valid execution

UM-OS18: failure modes are operator-typed

UM-OS19: trace(...) denotes one concrete PMS-UM execution

UM-OS20: Trace(...) denotes the set of possible PMS-UM executions under a
         declared machine/profile

UM-OS21: operator semantics define PMS-UM abstract-machine behavior and do
         not validate PMS Base
```

### 6.16 Architectural Consequence

The operator semantics make PMS-UM a formally structured abstract machine.

The result is:

```text id="5dgtng"
Every PMS-UM instruction is an operator-labeled transition whose
preconditions, postconditions, state effects, and failure modes are typed
by Δ–Ψ.
```

This is the abstract-machine layer of PMS-STACK.

A concrete execution records:

```text id="cozqqm"
trace(...)
```

while a declared machine/program/profile determines:

```text id="mfxago"
Trace(...)
```

Later layers may refine these semantics into:

```text id="9qkfmz"
virtual CPU instructions
kernel operations
language constructs
IR nodes
runtime checks
network events
distributed traces
artifact evidence
```

but they should preserve the operator identity and dependency discipline fixed here.

### 6.17 Boundary Statement

The correct boundary for this chapter is:

```text id="d6wc8d"
PMS-UM operator semantics define how Δ–Ψ operators act as abstract-machine
instruction families.

They specify preconditions, postconditions, typical state effects, failure
modes, and invariants for PMS-UM execution.

This strengthens the PMS-UM abstract-machine architecture claim.

It does not redefine PMS Base, does not implement later PMS-STACK layers,
does not turn traces into proofs, does not turn artifact evidence into
implementation completion, and does not validate PMS Base.
```

---

## 7. Dependency-Constrained Execution

PMS-UM execution is not defined by instruction order alone.

A PMS-UM program may be syntactically well-formed as a sequence of operator-typed instructions and still fail architecturally if an instruction fires without its required operator prerequisites.

PMS-UM therefore executes under dependency constraints inherited from the Δ–Ψ grammar and projected into the abstract-machine state model.

The central rule is:

```text id="wk0ltk"
An instruction may step only if the dependencies of its operator are
available in the current history, state, frame, role, policy, boundary
state, committed history, meta-state, environment context, or declared
machine/profile context.
```

This follows the general PMS-STACK validity discipline defined in `01_architecture.md`.

The core PMS-UM validity relation is:

```text id="1py5lf"
valid_step(I, κ) iff
    op(I) ∈ O
    ∧ π ∈ Π
    ∧ dependencies_available(op(I), κ)
    ∧ params_valid(params(I), κ)
    ∧ pre_I(κ)
    ∧ boundary_allows(f, r, P, m, I)
    ∧ policy_allows(P, I, κ)
    ∧ profile_allows(profile, I) where a profile is declared
    ∧ post_I preserves op(I)
    ∧ updated history remains in L_PMS or L_PMS,Ψ
```

The central claim is:

```text id="lu7y26"
PMS-UM execution is dependency-constrained: every executed instruction must
preserve the operator dependency discipline of Δ–Ψ under the current
machine configuration.
```

Claim type:

```text id="gfae5g"
abstract-machine well-formedness claim
```

Boundary:

```text id="a9dxsj"
This defines PMS-UM execution validity.

It does not validate PMS Base.

It does not prove that every implementation enforces these constraints.

It does not imply that PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking, or
distributed PMS-STACK are complete.
```

### 7.1 Dependency Availability

Let the current PMS-UM configuration be:

```text id="wak2pz"
κ = (s, π, ip, h, e)
```

where:

```text id="mcsxa2"
π ∈ Π
```

and:

```text id="1rie0r"
s = (s_c, f, r, P, m)
```

and:

```text id="8yngnr"
h ∈ O*
```

is the operator history.

Let the selected instruction be:

```text id="jzf2f4"
I = (op, params, pre, post)
```

with:

```text id="pxecmd"
op ∈ O
```

The dependency check is:

```text id="ozbkk3"
deps(op) ⊆ available(h, s, π, ip, e)
```

where `available(...)` may include:

```text id="4khazc"
prior operators in h
active frame context f
active role/capability context r
active policy set P
meta-state markers in m
committed history
pending expectation state
boundary and reachability state
macro-expansion context
environment/input state
runtime/profile state where declared
declared fixed/trivial machine structures
```

This is stricter than syntactic occurrence and more flexible than adjacency.

The prerequisite for an operator does not always have to be the immediately previous operator.

It must be structurally available at the time of execution.

Example:

```text id="cabw8h"
Δ_file □_fs Ω_write Χ_namespace Ψ_policy ∇_write Σ_commit
```

Here, `∇_write` is valid because the necessary structures are available:

```text id="l4oa8y"
target distinguished
filesystem frame active
write authority present
namespace boundary valid
policy permits write
```

The instruction is not valid merely because it appears in a program.

It is valid because the configuration carries the structures required by its operator type.

A concrete valid execution records:

```text id="d29xmr"
trace(...)
```

while a declared machine/program/profile determines:

```text id="938kf5"
Trace(...)
```

### 7.2 Dependency Path

PMS-UM uses the PMS Base 1.3 dependency path as operator-identity reference and `01_architecture.md` as the implementation-layer validity reference.

| Operator | PMS Base dependency | PMS-UM execution reading                                                       |
| -------- | ------------------- | ------------------------------------------------------------------------------ |
| Δ        | none                | may begin or refine a trace                                                    |
| ∇        | Δ                   | requires distinguished target/action field                                     |
| □        | Δ, ∇                | requires distinguished context and operational relevance                       |
| Λ        | □                   | requires expectation context                                                   |
| Α        | Δ, ∇, □, Λ          | expands to PMS-valid operator structure                                        |
| Ω        | Α                   | requires distinguished role/capability relation                                |
| Θ        | Ω, Α                | orders progression, scheduling, timeout, retry, or commit                      |
| Φ        | Θ, Ω, □             | requires context to reframe and meaningful continuation                        |
| Χ        | Φ, Θ, □             | Distance projected as valid boundary/reachability/access-separation discipline |
| Σ        | Χ, Φ                | requires committable prior structure and valid integration conditions          |
| Ψ        | Σ, Θ, Χ             | binds future execution through policy/invariant constraints                    |

This table should not be read as requiring every PMS-UM program to literally spell out the full PMS Base dependency path before every instruction.

Dependencies may be satisfied by:

```text id="jvunwc"
state
history
frame
role
policy
boundary state
meta-state
committed history
declared runtime profile
declared fixed frame, role, policy, or boundary condition
```

The table defines what must be structurally available.

It does not impose a mandatory adjacent textual sequence.

### 7.3 Dependency vs. Adjacency

Dependency is not adjacency.

Adjacency means:

```text id="n8x6fp"
operator B immediately follows operator A
```

Dependency means:

```text id="vb3khm"
operator B is valid only if the structural effect of operator A is
available in the current execution context.
```

For PMS-UM, this distinction is essential.

Example:

```text id="z9usk6"
h = Δ □ Ω Ψ ∇
```

The `∇` action may be valid even though it is not immediately adjacent to `Δ`.

The relevant distinction may be stored in:

```text id="upkse0"
m.distinctions
```

or in the current frame.

Example:

```text id="sp32ps"
Σ_commit
```

may be valid long after the original `∇` action if committable state remains available in:

```text id="v0rm8q"
m.committable_state
```

or committed/staged machine state.

A simple validator may check adjacency as a bounded approximation.

The PMS-UM architecture requires structural dependency.

Correct:

```text id="q8r326"
adjacency validation may be an artifact/profile rule.
```

Incorrect:

```text id="glvvn8"
adjacency is the whole PMS-UM dependency discipline.
```

Artifact boundary:

```text id="5cfwwu"
An artifact may implement an adjacency-oriented validator as a declared
bounded profile.

That may strengthen implementation-artifact evidence for that profile.

It does not replace PMS-UM structural dependency semantics and does not
validate PMS Base.
```

### 7.4 Instruction-Level Dependency Rule

For each instruction:

```text id="s8jv24"
I = (op, params, pre, post)
```

the instruction precondition must be at least as strong as the dependency rule for `op`.

A compact rule is:

```text id="k1x278"
valid_instruction(I, κ) iff
    op(I) ∈ O
    ∧ π ∈ Π
    ∧ deps(op(I)) are available
    ∧ params_valid(params(I), κ)
    ∧ pre_I(κ)
    ∧ boundary_allows(f, r, P, m, I)
    ∧ policy_allows(P, I, κ)
    ∧ profile_allows(profile, I) where declared
```

The instruction may add stricter requirements than the operator dependency rule.

It may not weaken the dependency rule.

Examples:

```text id="5ee45g"
I_∇
    must require a distinguished target

I_Λ
    must require an expectation context

I_Ω
    must require a distinguished role/capability relation

I_Χ
    must require an active frame or domain and relevant boundary conditions

I_Χ_exit
    must require active boundary context

I_Σ
    must require committable prior activity

I_Ψ
    must require a distinguished policy object, invariant, or governance scope
```

If a precondition omits the operator dependency, the instruction is not PMS-UM-conformant.

### 7.5 History and Meta-State

PMS-UM tracks dependency availability through both operator history and meta-state.

The history is the operator word:

```text id="l6etbz"
h = o₁ o₂ … oₙ
```

The meta-state records current availability:

```text id="rmbbb5"
m.history
m.distinctions
m.active_frames
m.pending_expectations
m.roles
m.ordering
m.recontextualization_state
m.boundary_graph
m.boundary_stack
m.sealed_boundary_state
m.committable_state
m.active_policy
```

Raw history says which operators have occurred.

Meta-state says whether their effects remain available.

This distinction matters.

A prior □ may have established a frame, but that frame may no longer be active.

A prior Ω may have established a role, but later policy may have revoked it.

A prior ∇ may have produced staged state, but later Φ may have moved execution into a context where that staged state is no longer committable.

A prior Χ may have entered a boundary, but a later valid exit may have closed that boundary context.

Therefore:

```text id="4ztjnd"
history is not a checklist

history + state + meta-state determine availability
```

A concrete trace records one run:

```text id="z0a0en"
trace(κ₀ … κₙ) ∈ L_PMS
```

or, under active policy:

```text id="o9pwxm"
trace(κ₀ … κₙ) ∈ L_PMS,Ψ
```

It does not by itself enumerate all possible availability states in:

```text id="llc7dp"
Trace(M, π, s₀)
```

### 7.6 Prefix, State, and Committed History

Dependency may be satisfied through:

```text id="91p6wc"
prefix history
active state
committed history
configuration metadata
declared machine/profile structure
```

Prefix history:

```text id="9lnsqd"
a required operator occurred earlier in h
```

Active state:

```text id="5c2fsf"
its structural effect is present in s = (s_c, f, r, P, m)
```

Committed history:

```text id="zokzyf"
a previous Σ integrated the relevant structure into stable state
```

Configuration metadata:

```text id="9iop2s"
the machine instance declares a fixed frame, role, policy, or boundary
condition
```

Example:

```text id="rzgqlv"
r = r_TM
```

may satisfy a fixed Ω-like execution role for deterministic Turing-machine encoding, even if the minimal TM trace does not dynamically execute Ω at every step.

Example:

```text id="p4pbtz"
f = f_TM
```

may satisfy the frame requirement for TM execution.

Example:

```text id="298dby"
Χ = fixed closed-machine boundary
```

may satisfy closed-machine boundary discipline without dynamic boundary entry or exit.

This is valid when the machine instance declares it.

It is not valid to silently assume undeclared state.

### 7.7 Fixed, Trivial, and Active Dependencies

PMS-UM may use fixed or trivial structures for some operators.

For example, in the minimal deterministic TM encoding:

```text id="5387ai"
□ = fixed TM execution frame
Ω = fixed TM execution role
Χ = fixed/trivial closed-machine boundary
```

This means:

```text id="h1qaas"
the dependency is satisfied by declared machine configuration
```

not:

```text id="ix9xlu"
the operator does not matter
```

A fixed frame is still a frame.

A fixed role is still an Ω structure.

A trivial closed boundary is still a declared Χ projection.

The TM encoding does not require dynamic `□`, `Ω`, or `Χ` transitions.

It does not remove frame, role, or boundary structure from PMS-UM.

This distinction allows PMS-UM to encode deterministic classical computation without requiring every Δ–Ψ operator to appear dynamically in every trace.

### 7.8 Policy-Constrained Execution

Active Ψ policy restricts valid execution.

A structurally valid instruction may still be forbidden:

```text id="k3sfec"
dependencies_available(op, κ)
∧ pre_I(κ)
∧ boundary_allows(f, r, P, m, I)
∧ policy_allows(P, I, κ) = false
```

In that case the instruction does not execute as a normal valid transition.

The machine may:

```text id="ym84ch"
halt
become stuck
branch to recovery
trigger Φ
record Ψ-denial
withhold Σ
produce Σ_audit
```

The specific response belongs to the PMS-UM instance.

The denial remains operator-typed.

Policy-constrained execution induces:

```text id="c1sr1l"
L_PMS,Ψ ⊆ L_PMS
```

PMS-UM concrete traces must remain in:

```text id="lox69x"
trace(...) ∈ L_PMS
```

and, under active policy:

```text id="bdpj7h"
trace(...) ∈ L_PMS,Ψ
```

For declared possible execution sets:

```text id="5z4zh8"
Trace(...) ⊆ L_PMS
```

and, under active policy:

```text id="wg20w6"
Trace(...) ⊆ L_PMS,Ψ
```

### 7.9 Boundary-Constrained Execution

PMS-UM uses Χ as the abstract-machine projection of PMS Base Distance.

At the PMS-UM layer, Χ may appear as:

```text id="h017hq"
boundary state
reachability restriction
protected subcontext
sandbox
partitioned state
visibility restriction
access-separation marker
quarantine marker
boundary stack
sealed boundary marker
```

A boundary-sensitive instruction is valid only if the relevant Χ conditions are available and policy-permitted.

Representative rule:

```text id="3iexay"
boundary-sensitive transition
    ⇒ valid Χ projection available
```

Examples:

```text id="44oclb"
∇ across a protected region requires a valid boundary gate

Σ across separated contexts requires valid Χ constraints

Φ after a boundary violation must preserve trace accountability

Ψ may require audit or denial for boundary-sensitive actions
```

Boundary exit requires an active boundary context:

```text id="71j5a9"
Χ_exit valid only if active_boundary_context(m) = true
```

Unbalanced boundary exit is invalid:

```text id="pj952j"
Χ_exit without active boundary context
    → invalid transition
```

A sealed boundary or isolation context has a stricter rule:

```text id="s6q45g"
sealed boundary / isolation
    forbids further entry, expansion, or reachability growth
```

but still permits, under declared profile and active boundary context:

```text id="22qc1z"
valid exit
closure
rollback
audit
commit
```

This is an implementation-layer projection.

It does not redefine PMS Base Χ.

PMS Base 1.3 Χ remains:

```text id="0k77ee"
Distance
```

### 7.10 Commit-Constrained Execution

Σ requires committable prior structure.

PMS-UM must distinguish:

```text id="8c6dpr"
staged state
committable state
committed state
```

A Σ instruction is valid only if:

```text id="uuhmq0"
committable_state_available(s, m, params) = true
```

and:

```text id="9c2vqm"
policy_allows(P, Σ, κ) = true
```

and, where relevant:

```text id="jpi58x"
boundary_allows(f, r, P, m, Σ) = true
```

Invalid:

```text id="joex89"
Δ_file Σ_commit
```

if no prior action has produced committable state.

Valid:

```text id="t389ml"
Δ_target ∇_action Θ_order Σ_commit
```

when `∇_action` produced staged/committable state and `Θ_order` records valid progression.

Commit discipline is essential because PMS-UM is not merely a transition system.

It distinguishes state mutation from integration.

### 7.11 Recontextualization-Constrained Execution

Φ requires something to recontextualize.

A Φ instruction is valid only if:

```text id="v13od3"
cause_available(κ) = true
```

and:

```text id="gmhbr7"
continuation_available(κ) = true
```

Typical causes:

```text id="wu02np"
exception
trap
failed policy check
invalid parameter
boundary violation
unbalanced boundary exit
undefined transition
environment error
migration condition
fallback condition
```

Typical continuations:

```text id="t4sxf8"
handler
recovery path
new frame
fallback branch
halt path
audit path
```

Invalid:

```text id="sh6dlf"
Φ_handler
```

with no cause and no declared handler.

Valid:

```text id="m0dp72"
Δ_error Φ_handler Σ_audit
```

when the error has been distinguished, handler exists, and audit commit is permitted.

Φ is not untyped escape.

It is structured context change with continuity.

### 7.12 Absence-Constrained Execution

Λ requires expectation.

A Λ instruction is valid only if an expected event, input, transition, response, or condition is pending.

Representative predicate:

```text id="w34gtp"
expectation_available(m, params) = true
```

Examples of valid expectation contexts:

```text id="uc3dyv"
pending input
pending receive
ordered wait
timer/deadline metadata
empty queue check
missing rule lookup
environment response expectation
```

Invalid:

```text id="5k7mzm"
Λ_timeout
```

if no timeout or expectation was active.

Valid:

```text id="rpavxp"
Δ_request Θ_wait Λ_timeout Φ_retry
```

when a request was distinguished, wait progression was ordered, and the expected response failed to occur.

Λ is not a generic failure marker.

It is typed absence under expectation.

### 7.13 Automaton Reading

Dependency-constrained PMS-UM execution can be read as an automaton.

The automaton state records currently available structural prerequisites:

```text id="xxgip3"
A_state =
(
    seen_Δ,
    active_□,
    available_Ω,
    ordered_Θ,
    pending_Λ_expectation,
    active_Φ_context,
    active_Χ_boundary,
    sealed_Χ_state,
    committable_Σ_state,
    active_Ψ_policy
)
```

An operator is accepted when it can move the automaton from one valid prerequisite state to another:

```text id="b3bxxh"
A_state --op--> A_state'
```

where:

```text id="e6gpcz"
preconditions(op, A_state) hold
postconditions(op, A_state') hold
```

This automaton reading supports:

```text id="7ozr0w"
PMS-UM program validation
static checking of operator traces
dependency linting
symbolic execution
test generation
audit trace validation
later PMS-CPU and PMS-OS validation paths
```

The automaton is not a new theory.

It is the executable reading of the dependency discipline.

Validation here means acceptance or rejection under a declared profile, schema, model, validator, fixture, gate, or conformance rule.

It does not mean external validation of PMS Base.

### 7.14 Stateful Validator Sketch

A PMS-UM validator may track:

```text id="a2spxn"
ValidatorState = (
    distinguished,
    active_frames,
    roles,
    expectations,
    ordering,
    recontextualization,
    boundaries,
    sealed_boundaries,
    committable,
    policies,
    status
)
```

Representative preconditions:

```text id="kg6871"
pre(∇):
    distinguished target exists
    ∧ active frame if required
    ∧ role/policy permits if protected

pre(□):
    distinguished context exists

pre(Λ):
    expectation exists

pre(Α):
    expansion valid

pre(Ω):
    role/capability relation distinguished

pre(Θ):
    transition or expectation to order exists

pre(Φ):
    context/cause exists
    ∧ continuation exists

pre(Χ):
    active frame/domain exists

pre(Χ_exit):
    active boundary context exists
    ∧ exit permitted by role/policy/profile

pre(Σ):
    committable state exists

pre(Ψ):
    policy object/scope distinguished
    ∧ authority exists if policy is modified
```

Representative postconditions:

```text id="jsm3m8"
post(Δ):
    distinguished := true

post(□):
    active_frames.update(...)

post(Λ):
    expectations.resolve_or_mark_absent(...)

post(Ω):
    roles.update(...)

post(Θ):
    ordering.advance(...)

post(Φ):
    recontextualization.update(...)

post(Χ):
    boundaries.update(...)

post(Χ_exit):
    boundaries.close_or_pop(...)

post(Σ):
    committable := false
    committed_state.update(...)

post(Ψ):
    policies.update(...)
```

This validator is illustrative.

A concrete PMS-UM artifact may implement a simpler or richer profile, provided the profile is declared.

### 7.15 Invalidity and Stuckness

A PMS-UM execution may fail because a dependency is unavailable.

Typical failure classes:

| Failure type                | Description                                                     | Operator involved |
| --------------------------- | --------------------------------------------------------------- | ----------------- |
| missing distinction         | action target or branch condition not distinguished             | Δ / ∇             |
| missing frame               | context-sensitive transition has no active frame                | □                 |
| missing expectation         | absence asserted without expected event                         | Λ                 |
| invalid pattern             | Α expands to non-valid word                                     | Α                 |
| missing role                | capability or authority unavailable                             | Ω                 |
| unordered progression       | ordering step has no meaningful progression target              | Θ                 |
| invalid recontextualization | Φ lacks frame, cause, or continuation                           | Φ                 |
| invalid boundary projection | Χ lacks frame/domain or violates policy                         | Χ                 |
| unbalanced boundary exit    | boundary exit attempted without active boundary context         | Χ / Φ / Ψ         |
| sealed-boundary violation   | sealed context permits entry, expansion, or reachability growth | Χ / Ψ             |
| empty commit                | Σ lacks committable prior activity                              | Σ                 |
| policy denial               | Ψ forbids otherwise possible transition                         | Ψ                 |

A stuck PMS-UM configuration is one where no valid transition applies and the state is not halting:

```text id="ea3rnw"
stuck(κ) iff
    κ ∉ S_H
    ∧ no instruction at ip satisfies dependency, parameter, precondition,
      boundary, policy, profile, and postcondition requirements
```

Stuckness is not halting.

Halting is a declared terminal condition.

Stuckness is failure of valid continuation.

### 7.16 Rejection as Valid Machine Behavior

A PMS-UM instance may reject an instruction before executing it.

Rejection points include:

```text id="x88cs7"
invalid operator tag
invalid parameters
unavailable dependency
false precondition
boundary denial
unbalanced boundary exit
sealed-boundary violation
policy denial
invalid postcondition
trace would leave L_PMS or L_PMS,Ψ
```

A rejection may be represented through:

```text id="f9p0oy"
Ψ_denial
Φ_error
Χ_violation
Λ_absence
Σ_audit
stuck
halt
```

Rejection is valid machine behavior when it is operator-typed.

Silent invalid mutation is not valid machine behavior.

A rejected candidate execution is not a valid normal execution trace.

It may still be evidence of fail-closed behavior under a declared artifact/profile.

### 7.17 Example: Valid Abstract Write

Reference word:

```text id="zz2v7g"
w = Δ_cell □_frame Ω_write Χ_scope Ψ_policy ∇_write Θ_order Σ_commit
```

Interpretation:

```text id="nzst3f"
cell distinguished
frame active
write authority established
scope boundary valid
policy permits
write performed
order recorded
commit integrates result
```

Validity requires:

```text id="b1o532"
w ∈ L_PMS
```

and, under active policy:

```text id="qqmuw7"
w ∈ L_PMS,Ψ
```

The corresponding PMS-UM concrete execution is valid only if the state and meta-state contain the necessary frame, role, boundary, policy, and committable-state structures.

As a concrete run:

```text id="bkth5n"
trace(M, π, s₀) = w
trace(M, π, s₀) ∈ L_PMS
```

and, under active policy:

```text id="25igff"
trace(M, π, s₀) ∈ L_PMS,Ψ
```

### 7.18 Example: Invalid Commit

Word:

```text id="c3qk36"
w = Δ_cell Σ_commit
```

Syntactically:

```text id="lt0bxi"
w ∈ O*
```

But structurally, it is invalid unless committable state was already available.

Failure:

```text id="l8mkkv"
Σ without committable prior structure
```

A valid explicit form is:

```text id="4t6u3g"
Δ_cell ∇_write Θ_order Σ_commit
```

or, with full discipline:

```text id="eu70n9"
Δ_cell □_frame Ω_write Χ_scope Ψ_policy ∇_write Θ_order Σ_commit
```

This shows the distinction between syntactic operator word and valid PMS-UM execution.

### 7.19 Example: Policy-Denied Action

Word:

```text id="dzmhsa"
w = Δ_cell □_frame Ω_write Χ_scope ∇_write Σ_commit
```

This may be structurally valid.

But under policy:

```text id="05d27o"
Ψ_readonly
```

the action is forbidden:

```text id="p9hmlh"
w ∈ L_PMS

w ∉ L_PMS,Ψ
```

A valid denial path may be:

```text id="k3gpzl"
Δ_cell □_frame Ω_write Χ_scope Ψ_deny Φ_error Σ_audit
```

This preserves operator typing.

The denial trace is not a successful write trace.

It is a valid typed rejection/audit trace under the declared policy profile.

### 7.20 Relation to PMS-RUST-Style Validators

A bounded executable artifact may implement a PMS-UM-like validator.

It may check:

```text id="fnwvx6"
operator adjacency
stateful dependency
frame stack
role availability
boundary/isolation state
sealed or committed state
policy permission
trace schema
artifact profile limits
```

It may also evidence bounded runtime boundary-exit discipline where declared:

```text id="vox62z"
chi_exit requires active boundary context

unbalanced chi_exit is rejected

sealed isolation forbids entry, expansion, or reachability growth while
permitting valid exit, closure, rollback, audit, or commit under profile
```

Such a validator strengthens bounded implementation-artifact claims.

It does not validate PMS Base.

It does not complete PMS-UM unless its scope covers the declared PMS-UM semantics.

It does not complete PMS-CPU `ISO_EXIT`, PMS-OS isolation, PMSL/PMS-IR, networking, or distributed PMS-STACK.

Correct:

```text id="wf9umv"
This artifact enforces a bounded PMS-UM validation profile.
```

Incorrect:

```text id="kc6mbo"
This validator proves PMS-UM or PMS Base.
```

Evidence discipline:

```text id="kwpvnx"
tests check
traces record
validators accept or reject under profile
fixtures stabilize known cases
artifacts evidence bounded implementation claims
proofs prove stated properties under assumptions
external validation validates externally
```

### 7.21 Dependency-Constrained Execution Invariants

```text id="nuz7n9"
UM-DC1: PMS-UM execution is dependency-constrained

UM-DC2: π ∈ Π for the active PMS-UM program

UM-DC3: dependencies are structural, not merely adjacent

UM-DC4: dependency availability may come from history, state, frame, role,
        policy, boundary state, meta-state, committed history, environment,
        declared fixed structures, or profile

UM-DC5: instruction preconditions must be at least as strong as operator
        dependency requirements

UM-DC6: history records what occurred; meta-state records what remains available

UM-DC7: fixed/trivial frame, role, and boundary structures must be declared

UM-DC8: active Ψ restricts execution from L_PMS to L_PMS,Ψ

UM-DC9: trace(...) denotes one concrete PMS-UM execution

UM-DC10: Trace(...) denotes the set of possible PMS-UM executions under a
         declared machine/profile

UM-DC11: boundary-sensitive transitions require valid Χ projection

UM-DC12: PMS Base Χ = Distance

UM-DC13: PMS-UM projects Χ as abstract-machine boundary, reachability,
         visibility, and access-separation discipline

UM-DC14: boundary exit requires active boundary context; unbalanced exit is
         invalid

UM-DC15: sealed isolation forbids entry, expansion, and reachability growth
         while permitting valid exit, closure, rollback, audit, or commit
         under declared profile

UM-DC16: Σ requires committable prior structure

UM-DC17: Φ requires cause/context and continuation

UM-DC18: Λ requires expectation

UM-DC19: rejection, denial, absence, stuckness, and boundary failure are
         operator-typed

UM-DC20: validation means acceptance or rejection under a declared profile,
         schema, model, validator, fixture, gate, or conformance rule

UM-DC21: PMS-RUST-style validators may evidence bounded validation profiles
         but do not complete PMS-UM and do not validate PMS Base

UM-DC22: dependency-constrained execution strengthens PMS-UM architecture
         and does not validate PMS Base
```

### 7.22 Architectural Consequence

Dependency-constrained execution gives PMS-UM its formal discipline.

The central result is:

```text id="hh9430"
A PMS-UM run is valid only if every executed instruction preserves operator
dependency, state/configuration preconditions, boundary discipline, commit
discipline, declared profile constraints, and active Ψ policy constraints.
```

This makes PMS-UM an operator-constrained abstract machine rather than a generic transition system.

It also gives later layers a validation spine:

```text id="496i42"
PMS-CPU instruction validity
PMS-OS syscall validity
PMSL/PMS-IR lowering validity
runtime-security policy validity
network trace validity
distributed trace validity
artifact evidence profiles
```

These later uses remain layer-typed.

They do not convert PMS-UM dependency discipline into PMS Base validation.

### 7.23 Boundary Statement

The correct boundary for this chapter is:

```text id="t73z0q"
Dependency-constrained execution defines the well-formedness discipline of
PMS-UM. It specifies when operator-typed instructions may execute based on
history, state, frame, role, policy, boundary state, commit state, meta-state,
environment context, declared fixed structures, and profile constraints.

This is an abstract-machine validity claim.

It does not validate PMS Base, does not prove every implementation correct,
does not turn validators or traces into proofs, does not turn PMS-RUST-style
artifact evidence into PMS-STACK completion, and does not complete PMS-CPU,
PMS-OS, PMSL, networking, or distributed PMS-STACK.
```

---

## 8. Determinism and Non-Determinism

PMS-UM can be deterministic or nondeterministic depending on the structure of its transition relation, instruction applicability, environment model, policy behavior, boundary behavior, commit behavior, and scheduling semantics.

The distinction is architectural.

PMS-UM does not force all machines to be deterministic.

It defines the conditions under which determinism holds and the structurally typed sources from which nondeterminism may arise.

Let the active PMS-UM program be:

```text id="3zph2n"
π ∈ Π
```

The central distinction is:

```text id="f1vah6"
deterministic PMS-UM:
    each valid configuration has at most one valid successor

nondeterministic PMS-UM:
    at least one valid configuration has more than one valid successor
```

The central claim is:

```text id="69a5b3"
Determinism and nondeterminism in PMS-UM are properties of the declared
transition relation and execution profile, not departures from the Δ–Ψ
execution discipline.
```

Claim type:

```text id="rb6x6n"
abstract-machine execution-profile claim
```

Boundary:

```text id="ee0f0z"
This defines PMS-UM execution modes.

It does not imply that every implementation supports both modes.

It does not prove termination, fairness, correctness, security, or
distributed correctness.

It does not turn bounded exploration into proof.

It does not validate PMS Base.
```

### 8.1 Deterministic PMS-UM

A PMS-UM instance is deterministic iff every configuration has at most one valid successor.

Using configurations:

```text id="2r57ns"
∀κ: | { κ' | κ ⇒ κ' } | ≤ 1
```

Using execution-oriented states and programs:

```text id="c95uso"
∀(s⁺, π): | { s⁺' | (s⁺, π) ⇒ (s⁺', π) } | ≤ 1
```

where:

```text id="6h750r"
π ∈ Π
```

A deterministic PMS-UM usually satisfies:

```text id="duwm62"
one instruction selected by ip
∧ instruction parameters are fixed
∧ precondition result is boolean and unique
∧ postcondition is functional
∧ boundary check returns a unique result
∧ policy outcome is unique
∧ scheduler/order semantics select one successor
∧ no environment transition races the internal step
```

For a deterministic instruction:

```text id="81oj1l"
post_I : S⁺ → S⁺
```

and if `pre_I(s⁺)` holds, there is exactly one successor:

```text id="o22l1v"
s⁺' = post_I(s⁺)
```

A deterministic PMS-UM run from fixed machine, program, initial state, environment, and profile produces at most one concrete trace:

```text id="3prapu"
trace(M, π, s₀) ∈ L_PMS
```

and, under active policy:

```text id="lob9sg"
trace(M, π, s₀) ∈ L_PMS,Ψ
```

Classical deterministic Turing-machine encodings are PMS-UM instances of this kind when each `(state, symbol)` pair selects one rule and all relevant postconditions are functional.

### 8.2 Deterministic Execution Profile

A deterministic PMS-UM profile declares:

```text id="078b53"
fixed program
fixed initial state
single instruction pointer
functional postconditions
deterministic policy outcomes
deterministic boundary outcomes
deterministic commit outcomes
deterministic instruction-pointer update
deterministic environment or no environment
```

A deterministic profile may still contain:

```text id="4p25ug"
Λ paths
Φ paths
Ψ denials
Χ boundary denials
Σ commit failures
```

but each such case must be uniquely determined by configuration.

Example:

```text id="z03nmn"
if timeout condition is true:
    Λ_timeout

if timeout condition is false:
    continue
```

is deterministic when the timeout condition is uniquely determined by state.

Nondeterminism appears only if both paths are valid from the same configuration.

A deterministic profile therefore constrains:

```text id="q2bzmr"
Trace(M, π, s₀)
```

to contain at most one valid trace:

```text id="u4773s"
|Trace(M, π, s₀)| ≤ 1
```

### 8.3 Nondeterministic PMS-UM

A PMS-UM instance is nondeterministic when at least one configuration has more than one valid successor:

```text id="8eufd2"
∃κ: | { κ' | κ ⇒ κ' } | > 1
```

For nondeterministic instructions:

```text id="jjwzev"
post_I : S⁺ → P(S⁺)
```

and execution selects one successor from a set:

```text id="ujb8gq"
s⁺' ∈ post_I(s⁺)
```

Nondeterminism may be intentional.

PMS-UM can model:

```text id="rra3mp"
search
interleaving
environment response
scheduling choice
unresolved input
policy alternatives
symbolic exploration
multiple valid recovery paths
```

Nondeterminism remains PMS-UM-conformant only if every possible successor preserves:

```text id="q5t6ze"
dependency validity
state coherence
boundary discipline
commit discipline
policy constraints
trace validity
```

Thus the possible trace set must satisfy:

```text id="dq16sy"
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="gipbkh"
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

### 8.4 Sources of Nondeterminism

PMS-UM nondeterminism may arise from several structurally typed sources.

#### Multiple enabled instructions

A program or transition system may allow more than one enabled instruction for the same control position.

```text id="ngsqnf"
pre_a(κ) = true
pre_b(κ) = true
```

If both instructions are valid and produce different successors, execution is nondeterministic.

#### Relational postconditions

An instruction may intentionally define multiple successor states:

```text id="ugww83"
post_I(s⁺) = { s₁⁺, s₂⁺, … }
```

This is useful for:

```text id="6t4zm7"
abstract interpretation
symbolic execution
nondeterministic choice
search
specification-level modeling
```

#### Environment-induced transitions

Reactive systems may include environment transitions:

```text id="gpn7cb"
δ_total = δ_internal ∪ δ_env
```

The environment may:

```text id="kqjpzh"
deliver input
withhold input
cause timeout
trigger Λ
induce Φ through exceptional conditions
produce multiple possible responses
submit AI/tooling proposals
```

Environment behavior must still enter through operator-typed transitions.

Example:

```text id="fdn0qk"
environment input
    → Δ_input
    → Ψ_policy
    → ∇_accept
    → Σ_commit
```

AI/tooling proposals, where present, are environment-side proposals, not execution authority:

```text id="1xsecq"
AI proposes.
Host tooling validates.
PMS-UM execution uses only accepted artifacts under a declared profile.
Policy remains Ψ-governed.
```

#### Scheduling and interleaving

When PMS-UM models multiple subcontexts, Χ and Θ may support interleaving semantics.

Χ may maintain separated execution contexts.

Θ may order steps among them.

If the scheduler can choose among several ready contexts, the machine is nondeterministic unless Ψ or scheduler policy fixes the choice.

#### Policy and role alternatives

Ψ and Ω may produce structured branching.

Examples:

```text id="88c2ij"
role check may branch to allowed or denied path

policy may allow multiple recovery options

governance rule may require audit, recontextualization, halt, or delayed
commit depending on configured semantics
```

#### Absence and timeout

Λ introduces nondeterminism in environment-sensitive machines because the expected event may occur or fail to occur.

```text id="ttvmoh"
event arrives
    ⇒ continue via Δ / ∇ / Θ

event absent
    ⇒ Λ path
```

The absence path is not unstructured.

It is an operator-typed branch.

#### Recontextualization alternatives

Φ may introduce multiple valid continuations:

```text id="bs0iho"
handler_a
handler_b
halt
audit
retry
fallback
```

This is nondeterministic only if the configuration admits more than one valid continuation under active policy.

### 8.5 Execution Modes

PMS-UM supports several execution modes.

#### Pure deterministic mode

In pure deterministic mode:

```text id="1t5vsk"
one instruction is selected by ip
each instruction has a functional postcondition
there is no environment race
Ψ and Ω checks return unique outcomes
Χ boundary checks return unique outcomes
Θ selects a unique successor
Σ commit behavior is uniquely determined
```

This mode is suitable for:

```text id="eqnp7q"
classical computation
deterministic simulations
deterministic PMS-UM programs
Turing-machine encodings
golden trace fixtures
```

#### Environment-driven nondeterministic mode

In environment-driven mode:

```text id="2zqpd3"
input may arrive or not arrive
timeouts may occur
external events may trigger Λ or Φ
δ_env participates in execution
```

This mode is suitable for:

```text id="mp3o8a"
reactive systems
protocol models
I/O models
runtime interaction
host boundary models
AI/tooling proposal surfaces
```

Environment-driven execution remains valid only when environment events enter through operator-typed structure.

#### Concurrent or interleaving mode

In concurrent/interleaving mode:

```text id="cb4pnf"
Χ maintains separated contexts
Θ orders transitions among contexts
Ω and Ψ constrain which contexts may act
scheduler may choose among enabled contexts
```

This mode is suitable for modeling:

```text id="h17j7h"
threads
actors
isolated submachines
protocol participants
parallel abstract computations
distributed prefigurations
```

Interleaving does not weaken boundary discipline.

Each possible interleaving must preserve:

```text id="q0xzlm"
frame validity
role validity
boundary validity
policy validity
trace validity
```

#### Symbolic or specification mode

In symbolic/specification mode:

```text id="w47fdx"
postconditions may be relational
multiple successor states represent possible executions
policies constrain the successor set
traces may be explored rather than executed concretely
```

This mode is suitable for:

```text id="e3n1ys"
verification
model checking
static analysis
design-space exploration
proof-oriented semantics
```

Symbolic exploration is not proof by itself.

It becomes proof-relevant only when tied to a declared model, property, assumptions, coverage argument, and proof artifact.

### 8.6 Determinism and Policy

Policy may preserve determinism or introduce controlled branching.

Deterministic policy:

```text id="5pt7ls"
policy_allows(P, I, κ) ∈ {allow, deny}
```

with exactly one result for each configuration.

Nondeterministic policy:

```text id="hgpfln"
policy_allows(P, I, κ) ∈ {allow, deny, audit, recontextualize, delay, halt}
```

with multiple valid responses from the same configuration.

A PMS-UM instance should declare whether policy behavior is:

```text id="lmri7z"
functional

relational

priority-ordered

nondeterministic

externally supplied
```

Policy nondeterminism is still constrained by Ψ.

It is not arbitrary behavior.

Policy branches must still produce traces in:

```text id="xssrot"
L_PMS
```

and, under active policy:

```text id="rft5f3"
L_PMS,Ψ
```

### 8.7 Determinism and Boundary Behavior

Boundary behavior may also be deterministic or nondeterministic.

Deterministic boundary check:

```text id="m3w806"
boundary_allows(f, r, P, m, I) ∈ {true, false}
```

Nondeterministic boundary behavior may occur when:

```text id="3lcbwa"
boundary relation is abstract

multiple routes are available

environment affects reachability

symbolic boundary states are explored

policy allows more than one containment path
```

Regardless of mode, Χ remains the PMS-UM projection of PMS Base Distance.

Boundary nondeterminism must remain:

```text id="i8i7kh"
frame-grounded
role-constrained
policy-constrained
traceable
```

Boundary exit remains constrained:

```text id="z22rnd"
Χ_exit requires active boundary context
```

Unbalanced exit is invalid:

```text id="g26i52"
Χ_exit without active boundary context
    → invalid transition
```

Sealed isolation has a stricter constraint:

```text id="v9b508"
sealed boundary / isolation
    forbids further entry, expansion, or reachability growth
```

while still permitting, under declared profile and active boundary context:

```text id="j5mwfd"
valid exit
closure
rollback
audit
commit
```

These constraints hold in deterministic and nondeterministic modes.

### 8.8 Determinism and Commit

Commit can also affect determinism.

Deterministic commit:

```text id="ep5sn5"
Σ maps one committable prior state to one committed successor
```

Nondeterministic commit:

```text id="hf2s3t"
Σ may select one of several valid integrations
```

This may be useful for:

```text id="1chzyp"
abstract merge semantics
nondeterministic reduction
symbolic transaction models
specification of possible commit orders
```

But every commit successor must satisfy:

```text id="hegp6h"
committable prior structure exists
∧ boundary conditions remain valid
∧ active policy permits integration
```

Nondeterministic commit is not ungoverned merging.

It remains Σ-typed integration over committable prior structure.

### 8.9 Fairness Assumptions

When nondeterministic PMS-UM models scheduling or environment interaction, fairness assumptions may be required.

Weak fairness:

```text id="5d1z16"
If an instruction or context remains continuously enabled,
it is eventually selected.
```

Strong fairness:

```text id="nzl8xg"
If an instruction or context is enabled infinitely often,
it is eventually selected infinitely often.
```

In PMS-UM, fairness assumptions are represented as Ψ-level constraints over execution traces.

A fairness policy may restrict valid traces:

```text id="k3py9n"
L_PMS,Ψ_fair ⊆ L_PMS
```

This means an unfair trace may be structurally possible but policy-invalid under the fairness rule.

Fairness is therefore a policy condition.

It is not automatically present unless declared.

Boundary:

```text id="q6709z"
Declaring a fairness assumption does not prove fairness of an artifact.

An artifact must separately evidence, check, model-check, or prove the
fairness property under stated assumptions and scope.
```

### 8.10 Observational Semantics

A concrete PMS-UM run yields an observable operator trace:

```text id="lrfefx"
trace(κ₀ … κₙ) = o₁ o₂ … oₙ
```

For a deterministic PMS-UM instance, a fixed program and initial state produce at most one concrete trace under a fixed profile:

```text id="4e6yqa"
trace(M, π, s₀) ∈ L_PMS
```

and, under active policy:

```text id="o62jog"
trace(M, π, s₀) ∈ L_PMS,Ψ
```

The corresponding Trace set has at most one valid member:

```text id="jtoey3"
|Trace(M, π, s₀)| ≤ 1
```

For nondeterministic PMS-UM instances, execution produces a set of possible traces:

```text id="n2osmm"
Trace(M, π, s₀) ⊆ O*
```

Valid trace sets satisfy:

```text id="tevty7"
Trace(M, π, s₀) ⊆ L_PMS
```

and, under active policy:

```text id="n2ff5x"
Trace(M, π, s₀) ⊆ L_PMS,Ψ
```

This trace semantics is the basis for:

```text id="aglr4k"
verification
audit
runtime evidence
homomorphic projection
artifact trace comparison
```

Trace boundary:

```text id="xx8ssc"
trace(...)
    denotes one concrete observed or selected run

Trace(...)
    denotes a set of possible runs under a declared machine/program/profile

A concrete trace does not enumerate the full Trace(...) set.

Trace evidence does not validate PMS Base.
```

### 8.11 Trace Sets

For deterministic PMS-UM:

```text id="mucva4"
|Trace(M, π, s₀)| ≤ 1
```

For nondeterministic PMS-UM:

```text id="fv7dhx"
|Trace(M, π, s₀)| may be greater than 1
```

A trace set may be:

```text id="8olljr"
finite

countably infinite

symbolically represented

bounded by fuel/depth/profile

restricted by Ψ policy
```

A bounded exploration profile may define:

```text id="qn0nwb"
Trace_k(M, π, s₀)
```

as all traces up to depth `k`.

This is useful for:

```text id="9jk4kh"
testing
model checking
symbolic execution
artifact validation
golden fixture generation
```

Boundary:

```text id="ydbrak"
bounded trace exploration is not proof of all behavior unless the proof
scope and model establish coverage.

Trace_k(...) is a bounded exploration set.

It must not be presented as Trace(...) unless the bound is the declared
complete execution space.
```

### 8.12 Deterministic Turing-Machine Encoding

The deterministic Turing-machine encoding in Section 9 uses a deterministic PMS-UM profile.

This requires:

```text id="vp3ea7"
one matching rule for each defined (q, γ)

functional write / move / state-update postconditions

deterministic Θ step update

fixed TM frame f_TM

fixed TM role r_TM

fixed or deterministic policy P_TM

fixed/trivial closed-machine boundary Χ_TM

closed environment
```

Under those conditions:

```text id="mkcwyc"
T deterministic
    ⇒ M_T deterministic
```

for the TM-simulation configurations.

The fixed/trivial structures remain declared PMS-UM structures:

```text id="cv979x"
□ = fixed TM execution frame

Ω = fixed TM execution role

Χ = fixed/trivial closed-machine boundary
```

The deterministic TM encoding does not require dynamic `□`, `Ω`, or `Χ` transitions.

It does not remove frame, role, or boundary structure from PMS-UM.

If additional nondeterministic environment, boundary, policy, scheduler, or commit behavior is added, the resulting PMS-UM machine may no longer be an exact deterministic TM simulation unless those behaviors are excluded from the simulation profile.

### 8.13 Nondeterminism and Verification

Nondeterministic PMS-UM is useful for verification.

It can represent:

```text id="i7eh6u"
all possible scheduler interleavings

all possible environment responses

all possible symbolic input paths

all possible recovery paths

all possible policy outcomes under abstract policy

all possible boundary outcomes under symbolic reachability
```

Verification may then ask whether all traces satisfy a property:

```text id="1kwd5f"
∀w ∈ Trace(M, π, s₀): Property(w)
```

or whether some trace satisfies a property:

```text id="yd5iwn"
∃w ∈ Trace(M, π, s₀): Property(w)
```

This is a verification-oriented use of PMS-UM.

It is not automatically a proof unless a formal verification artifact, model, assumptions, and property statement are supplied.

Correct:

```text id="lo1a1q"
model checking checks a property under a stated model and assumptions.
```

Correct:

```text id="3f1v3t"
proof requires a proof artifact and stated assumptions.
```

Incorrect:

```text id="61lkwk"
exploring some nondeterministic traces proves all behavior.
```

### 8.14 Determinism, Nondeterminism, and Artifacts

An artifact may implement a deterministic PMS-UM profile, a nondeterministic exploration profile, or both.

Artifact claim examples:

```text id="d6t9im"
This runtime executes a deterministic PMS-UM subset.
```

```text id="aym7f9"
This symbolic engine explores nondeterministic PMS-UM successor sets.
```

```text id="uxsdcw"
This validator rejects traces outside its declared PMS-UM profile.
```

```text id="qtxpru"
This PMS-RUST-style artifact evidences bounded deterministic execution,
validation, trace emission, or boundary-exit discipline under a declared
profile.
```

Boundaries:

```text id="6a7gqo"
a deterministic runtime
    ≠ full PMS-UM

a nondeterministic explorer
    ≠ proof of all properties by itself

a trace set
    ≠ PMS Base validation

a bounded exploration
    ≠ complete coverage unless stated and proven

PMS-RUST-style artifact evidence
    ≠ PMS-UM completion

chi_exit-style boundary-exit evidence
    ≠ PMS-CPU ISO_EXIT completion
    ≠ PMS Base Χ redefinition
```

Evidence discipline:

```text id="wtdgoz"
tests check
traces record
validators accept or reject under profile
fixtures stabilize known cases
artifacts evidence bounded implementation claims
model checking checks model properties under assumptions
proofs prove stated properties under assumptions
external validation validates externally
```

### 8.15 Execution Mode Table

| Mode               | Successor structure                           | Typical use                                                      | Boundary                                                                          |
| ------------------ | --------------------------------------------- | ---------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| deterministic      | at most one successor per configuration       | TM encoding, golden fixtures, deterministic simulation           | does not imply all PMS-UM profiles are deterministic                              |
| environment-driven | successors depend on input or absence         | I/O, reactive models, host boundary, AI/tooling proposal surface | environment must enter through operator typing                                    |
| interleaving       | scheduler chooses among contexts              | concurrency, actors, abstract parallelism                        | requires Θ/Χ/Ω/Ψ discipline                                                       |
| symbolic           | relational successor sets                     | verification, model checking, analysis                           | exploration is proof only under stated model/coverage                             |
| policy-branching   | Ψ admits multiple valid outcomes              | governance/recovery modeling                                     | policy alternatives must be declared                                              |
| boundary-branching | Χ admits multiple valid reachability outcomes | abstract reachability or containment analysis                    | Χ remains Distance projection                                                     |
| commit-branching   | Σ admits multiple valid integration outcomes  | abstract merge / symbolic transaction modeling                   | every successor requires committable prior structure and policy-valid integration |

### 8.16 Determinism Invariants

```text id="u2ipxf"
UM-DN1: deterministic PMS-UM has at most one valid successor per configuration

UM-DN2: nondeterministic PMS-UM has at least one configuration with multiple
        valid successors

UM-DN3: π ∈ Π for the active PMS-UM program

UM-DN4: determinism depends on transition relation, policy, boundary,
        environment, scheduler, commit, and postcondition behavior

UM-DN5: nondeterminism is operator-typed and constrained by Δ–Ψ

UM-DN6: every deterministic or nondeterministic concrete trace must remain in
        L_PMS

UM-DN7: under active policy, every concrete trace must remain in L_PMS,Ψ

UM-DN8: Trace(...) denotes the set of possible PMS-UM executions under a
        declared machine/program/profile

UM-DN9: deterministic profiles satisfy |Trace(M, π, s₀)| ≤ 1

UM-DN10: nondeterministic profiles may satisfy |Trace(M, π, s₀)| > 1

UM-DN11: environment behavior must enter through operator-typed transitions

UM-DN12: AI/tooling proposals are environment-side proposals and are not
         execution, compiler, verifier, proof, policy, or PMS Base authority

UM-DN13: fairness assumptions are Ψ-level constraints when used

UM-DN14: PMS Base Χ = Distance

UM-DN15: PMS-UM projects Χ as boundary, reachability, visibility,
         access-separation, sandboxing, and quarantine discipline

UM-DN16: boundary exit requires active boundary context; unbalanced exit is
         invalid

UM-DN17: sealed isolation forbids entry, expansion, and reachability growth
         while permitting valid exit, closure, rollback, audit, or commit
         under declared profile

UM-DN18: deterministic TM encoding uses a deterministic PMS-UM profile with
         fixed frame, fixed role, fixed/trivial boundary, deterministic policy,
         and closed environment

UM-DN19: symbolic and bounded exploration strengthen verification/artifact
         claims only under declared model and scope

UM-DN20: determinism/nondeterminism profiles do not validate PMS Base
```

### 8.17 Architectural Consequence

Determinism and nondeterminism in PMS-UM are not ad hoc execution modes.

They are structural properties of the transition relation and execution profile.

The central result is:

```text id="bk3x7m"
PMS-UM supports deterministic and nondeterministic execution profiles while
preserving the same operator-typed validity discipline.
```

This gives PMS-UM enough expressive range to model:

```text id="2fffog"
deterministic computation
reactive systems
abstract nondeterminism
concurrent interleavings
symbolic execution
verification-oriented transition systems
bounded artifact profiles
```

without leaving the Δ–Ψ execution discipline.

### 8.18 Boundary Statement

The correct boundary for this chapter is:

```text id="1lwlu1"
Determinism and nondeterminism in PMS-UM are defined by the successor
structure of the transition relation under a declared execution profile.

Both deterministic and nondeterministic PMS-UM instances remain valid only
when their traces preserve dependency validity, state/configuration
preconditions, boundary discipline, commit discipline, profile constraints,
and active Ψ policy constraints.

A concrete run produces trace(...).

A declared machine/program/profile determines Trace(...).

This is an abstract-machine execution-profile claim.

It does not prove termination, correctness, fairness, security,
distributed correctness, artifact completeness, or PMS Base validation.
It does not turn bounded exploration into proof, PMS-RUST-style evidence
into PMS-UM completion, or AI/tooling proposals into execution or
verification authority.
```

---

## 9. Classical Turing Machine Encoding

This section states the classical Turing Machine encoding for PMS-UM.

The claim is precise:

```text id="bq6e5s"
A classical deterministic Turing Machine can be encoded as a PMS-UM
instance whose transitions are simulated by finite, valid Δ–Ψ operator
traces.
```

This is an encoding and simulation claim inside the defined abstract PMS-UM machine.

It supports the computational expressiveness claim of PMS-UM.

It does not function as PMS Base validation.

It does not imply that PMS as a whole explains all computation, all systems, or all praxis.

Claim type:

```text id="ragj0d"
abstract-machine computational expressiveness claim
```

Boundary:

```text id="pjgwtx"
The Turing Machine encoding establishes classical computational
expressiveness for PMS-UM as an abstract machine.

It does not validate PMS Base.

It does not prove PMS-STACK implementation completion.

It does not prove PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking, or
distributed PMS-STACK correctness or completion.

It does not turn Turing-completeness into explanatory universality.
```

### 9.1 Encoding Strategy

The encoding strategy is direct.

A deterministic classical Turing Machine has:

```text id="uiyl0r"
control state
tape alphabet
unbounded tape
head position
transition function
halting states
```

PMS-UM represents these using:

```text id="qtj4rh"
core state s_c
instruction pointer ip
operator-typed instruction blocks
Δ distinctions
∇ state mutations
Θ ordered progression
Σ or Ψ halting / closure convention
```

The essential simulation pattern is:

```text id="iyqp72"
read current TM condition
    → Δ

write symbol
    → ∇

advance logical computation order
    → Θ

move head
    → ∇

update control state
    → ∇

halt / close final state
    → Σ or Ψ under declared convention
```

This is sufficient to simulate deterministic Turing-machine execution.

The full Δ–Ψ operator set is available in PMS-UM, but the minimal deterministic TM encoding does not require every operator dynamically.

The canonical per-step operator shape used in this document is:

```text id="kuewfr"
Δ ∇ Θ ∇ ∇
```

This shape makes the logical computation step explicit before head movement and control-state update.

### 9.2 Classical Turing Machine Form

A classical deterministic Turing Machine may be written as:

```text id="ndhi2b"
T = (Q, Γ, b, Σ_in, δ_T, q₀, F)
```

where:

| Component  | Meaning                      |
| ---------- | ---------------------------- |
| `Q`        | finite set of control states |
| `Γ`        | tape alphabet                |
| `b ∈ Γ`    | blank symbol                 |
| `Σ_in ⊆ Γ` | input alphabet               |
| `δ_T`      | transition function          |
| `q₀ ∈ Q`   | initial control state        |
| `F ⊆ Q`    | accepting or halting states  |

The transition function has the standard deterministic form:

```text id="qqbnzk"
δ_T : Q × Γ → Q × Γ × {L, R}
```

A transition:

```text id="31zqcp"
δ_T(q, γ) = (q', γ', move)
```

means:

```text id="hhpb2f"
if the machine is in control state q
and the current tape symbol is γ,
then write γ',
move the head left or right,
and enter control state q'.
```

For variants that include a stay-put move, the target set can be extended:

```text id="wzugki"
{L, R, S}
```

This does not change the encoding structure.

### 9.3 PMS-UM Machine for a Turing Machine

For every deterministic Turing Machine `T`, construct a PMS-UM machine:

```text id="5e2g3a"
M_T = (S, Γ, F_UM, R_UM, PSet, O, Inst, Π, δ, s₀, S_H)
```

The PMS-UM operator alphabet is:

```text id="hzq344"
O = { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The TM simulation uses a valid subset of this alphabet.

The minimal active subset is:

```text id="s7zbdw"
O_TM_min = { Δ, ∇, Θ }
```

with halting represented through a declared convention such as:

```text id="7x3t2h"
S_H membership
ip = halt
Σ_halt
Ψ_halt
```

Other operators may be fixed, trivial, or optionally used:

```text id="gymujw"
□
    fixed TM execution frame

Ω
    fixed TM execution role

Χ
    fixed/trivial closed-machine boundary for deterministic simulation

Λ
    optional undefined-transition / no-rule representation

Α
    optional rule-block packaging

Φ
    optional error / undefined-transition / recovery representation

Σ
    optional final integration / halt commit

Ψ
    optional halt policy / invalid-transition policy
```

This is important for claim discipline:

```text id="cz17qj"
Turing-machine simulation does not require all Δ–Ψ operators to be
dynamically used.

It requires that PMS-UM contain a valid operator-typed subset sufficient
for deterministic classical computation.
```

Fixed or trivial structures are still declared PMS-UM structures:

```text id="emge0r"
fixed frame ≠ no frame

fixed role ≠ no Ω structure

fixed/trivial closed boundary ≠ no Χ projection
```

### 9.4 Encoding TM State in PMS-UM State

PMS-UM uses the execution-oriented state:

```text id="9qku4z"
s⁺ = (s_c, f, r, P, m, ip)
```

A Turing Machine configuration is encoded into PMS-UM as follows.

The core state stores the tape, head position, and control state:

```text id="mvwjz4"
s_c = (
    tape : ℤ → Γ,
    pos  : ℤ,
    q    : Q
)
```

where:

| Component | Meaning                                                                    |
| --------- | -------------------------------------------------------------------------- |
| `tape`    | unbounded tape represented as a function from integer positions to symbols |
| `pos`     | current head position                                                      |
| `q`       | current TM control state                                                   |

The active frame is fixed:

```text id="sgx7ic"
f = f_TM
```

The active role is fixed:

```text id="oe1o3o"
r = r_TM
```

The active policy set is:

```text id="l2g3z7"
P = P_TM
```

`P_TM` enforces the structural rules of the simulation, such as:

```text id="k94gw2"
only valid TM-rule blocks may execute
only tape symbols in Γ may be written
head movement follows declared move instructions
halting states terminate or close execution
undefined transitions are handled according to declared convention
```

The fixed boundary condition is:

```text id="gmacxj"
Χ_TM = fixed/trivial closed-machine boundary
```

This boundary condition means that the deterministic TM simulation has no dynamic cross-boundary reachability transition.

It does not mean that PMS-UM lacks Χ structure.

The meta-state records:

```text id="x9hiv8"
operator history
last read symbol
selected rule
rule-selection flags
logical step counter
halting marker
optional stuck marker
optional undefined-transition marker
fixed frame / role / boundary declarations
```

The instruction pointer:

```text id="fjn1h5"
ip
```

ranges over the PMS-UM program that encodes the TM transition table.

### 9.5 Initial State Encoding

Given an input word:

```text id="4e9svj"
x = x₀ x₁ … xₖ
```

with:

```text id="ty6p98"
xᵢ ∈ Σ_in
```

the PMS-UM initial core state is:

```text id="yjyzxv"
s_c₀ = (
    tape₀,
    pos₀,
    q₀
)
```

where:

```text id="1bumsh"
tape₀(i) = xᵢ     for 0 ≤ i ≤ k

tape₀(i) = b      otherwise

pos₀ = 0

q₀ = initial control state of T
```

The remaining initial state components are:

```text id="h9y2ab"
f₀ = f_TM

r₀ = r_TM

P₀ = P_TM

m₀ = initial meta-state

ip₀ = entry point of π_T
```

The encoded program satisfies:

```text id="t5j5hr"
π_T ∈ Π
```

Thus:

```text id="t4wob9"
s₀⁺ = (s_c₀, f_TM, r_TM, P_TM, m₀, ip₀)
```

This PMS-UM state represents the initial TM configuration.

### 9.6 Encoding a TM Transition Rule

For each TM transition rule:

```text id="le8q8q"
δ_T(q, γ) = (q', γ', move)
```

PMS-UM constructs an operator-typed instruction block.

The canonical rule-block shape for this document is:

```text id="x1ps4r"
Δ_read
∇_write
Θ_step
∇_move
∇_state
```

with operator word:

```text id="bg4oyn"
Δ ∇ Θ ∇ ∇
```

This form treats the TM step as:

```text id="qol3vo"
distinguish current rule condition
write selected symbol
record ordered computation step
move head
update control state
```

A PMS-UM instance may declare a different but valid equivalent convention, but this document uses:

```text id="fduxbt"
Δ ∇ Θ ∇ ∇
```

as the canonical rule-block shape.

The instruction meanings are:

| PMS-UM instruction | Operator | TM role                              |
| ------------------ | -------- | ------------------------------------ |
| `Δ_read(q, γ)`     | Δ        | distinguish current `(q, tape[pos])` |
| `∇_write(γ')`      | ∇        | write `γ'` to `tape[pos]`            |
| `Θ_step`           | Θ        | record ordered computation step      |
| `∇_move(move)`     | ∇        | update `pos` left or right           |
| `∇_state(q')`      | ∇        | update control state `q := q'`       |

### 9.7 Rule-Block Preconditions

For a TM rule:

```text id="tzx8p9"
δ_T(q, γ) = (q', γ', move)
```

the PMS-UM rule block has preconditions.

For `Δ_read(q, γ)`:

```text id="0ntbsw"
pre_Δ(s⁺) iff
    s_c.q = q
    ∧ s_c.tape[s_c.pos] = γ
    ∧ f = f_TM
    ∧ r = r_TM
    ∧ Χ_TM is the declared closed-machine boundary
    ∧ policy_allows(P_TM, read_current_rule)
```

For `∇_write(γ')`:

```text id="4pd2y1"
pre_∇write(s⁺) iff
    last_read = (q, γ)
    ∧ γ' ∈ Γ
    ∧ f = f_TM
    ∧ r = r_TM
    ∧ policy_allows(P_TM, write_symbol)
```

For `Θ_step`:

```text id="xj5iyf"
pre_Θ(s⁺) iff
    a valid rule has been selected
    ∧ step progression is permitted
```

For `∇_move(move)`:

```text id="qe8agf"
pre_∇move(s⁺) iff
    move ∈ {L, R}
```

or, if stay-put is admitted:

```text id="b9d1xn"
move ∈ {L, R, S}
```

For `∇_state(q')`:

```text id="zlhhp1"
pre_∇state(s⁺) iff
    q' ∈ Q
```

Each precondition is stronger than the generic operator dependency rule.

That is required by PMS-UM.

The fixed `□`, `Ω`, and `Χ` structures are explicitly declared and therefore available as configuration structure.

They are not silently omitted.

### 9.8 Rule-Block Postconditions

For the selected rule:

```text id="amjs9v"
δ_T(q, γ) = (q', γ', move)
```

postconditions are:

For `Δ_read(q, γ)`:

```text id="xomqqn"
m'.last_read = (q, γ)
m'.selected_rule = (q, γ, q', γ', move)
```

For `∇_write(γ')`:

```text id="g8p28p"
s_c'.tape[s_c.pos] = γ'
```

For `Θ_step`:

```text id="135pea"
m'.step = m.step + 1
m'.order = update_order(m.order)
```

For `∇_move(move)`:

```text id="no56uk"
if move = L:
    s_c'.pos = s_c.pos - 1

if move = R:
    s_c'.pos = s_c.pos + 1

if move = S:
    s_c'.pos = s_c.pos
```

For `∇_state(q')`:

```text id="eyki2f"
s_c'.q = q'
```

At every instruction step, the operator history appends the corresponding operator:

```text id="qjtogh"
h' = h · op
```

The resulting concrete history remains in:

```text id="fctb4a"
L_PMS
```

and, under active `P_TM`:

```text id="q5iz5y"
L_PMS,Ψ
```

Equivalently, a completed concrete rule-block execution yields:

```text id="5ko4nj"
trace(rule_block(q, γ)) = Δ ∇ Θ ∇ ∇
```

with:

```text id="wr4c4m"
trace(rule_block(q, γ)) ∈ L_PMS
```

and, under active policy:

```text id="zojb7b"
trace(rule_block(q, γ)) ∈ L_PMS,Ψ
```

### 9.9 Encoding the Transition Table

The full transition table `δ_T` becomes a PMS-UM program:

```text id="k40ndu"
π_T = encode(δ_T)
```

where:

```text id="fd7x86"
π_T ∈ Π
```

One construction is:

```text id="bfkt15"
π_T = ⟨ block(q, γ) | (q, γ) ∈ dom(δ_T) ⟩
```

Each block begins with a Δ instruction that checks whether the current machine condition matches the rule:

```text id="i4akui"
(s_c.q = q) ∧ (s_c.tape[s_c.pos] = γ)
```

If the condition matches, the block executes the associated write, step, move, and state update.

If the condition does not match, execution branches to the next rule block or to the rule-selection mechanism.

A schematic block is:

```text id="6gws3j"
I₁ = (Δ, read_current(q, γ), pre_Δ, post_Δ_match_or_skip)

I₂ = (∇, write(γ'), pre_∇write, post_∇write)

I₃ = (Θ, step, pre_Θ, post_Θ)

I₄ = (∇, move(move), pre_∇move, post_∇move)

I₅ = (∇, set_state(q'), pre_∇state, post_∇state)
```

An optional cycle marker may be used:

```text id="nvuf7m"
I₆ = (Θ, next_rule_cycle, pre_Θcycle, post_Θcycle)
```

The canonical per-rule trace is therefore:

```text id="4i1bdi"
Δ ∇ Θ ∇ ∇
```

or, with declared cycle marking:

```text id="zkpew9"
Δ ∇ Θ ∇ ∇ Θ
```

Both remain finite valid PMS-UM operator words under the declared encoding convention.

The canonical base convention for this document remains:

```text id="fdqgnm"
Δ ∇ Θ ∇ ∇
```

### 9.10 Determinism Preservation

If `T` is deterministic, then for each pair:

```text id="e4kr7y"
(q, γ)
```

there is at most one transition:

```text id="vg2k65"
δ_T(q, γ)
```

The PMS-UM program `π_T` preserves this determinism when:

```text id="z22bpw"
exactly one block matches each defined (q, γ)

rule selection is deterministic

postconditions are functional

P_TM produces unique allow/deny outcomes

Χ_TM produces a unique closed-boundary outcome

no environment transition races the internal TM step
```

Then:

```text id="u7is5h"
∀κ: | { κ' | κ ⇒ κ' } | ≤ 1
```

for the TM-simulation configurations of `M_T`.

This establishes step-by-step deterministic simulation.

For the deterministic simulation profile:

```text id="sfvnik"
|Trace(M_T, π_T, s₀)| ≤ 1
```

and the concrete run, when it exists, satisfies:

```text id="ujymwh"
trace(M_T, π_T, s₀) ∈ L_PMS
```

and, under active policy:

```text id="4go3xs"
trace(M_T, π_T, s₀) ∈ L_PMS,Ψ
```

If PMS-UM is run in a nondeterministic profile, the TM encoding must either constrain the profile to deterministic rule selection or state that the resulting machine is no longer simulating a deterministic TM exactly.

### 9.11 Halting

A Turing Machine halts when:

```text id="hsvb6z"
q ∈ F
```

PMS-UM may encode halting in several standard ways.

#### Halting by Halting Set

The PMS-UM halting set includes all execution states whose core control state is halting:

```text id="fzn0aw"
S_H = { s⁺ | s_c.q ∈ F }
```

Then execution stops when:

```text id="f86tgh"
s⁺ ∈ S_H
```

#### Halting by Instruction Pointer

A PMS-UM instance may set:

```text id="zqq49l"
ip = halt
```

when the TM control state reaches `F`.

#### Σ-Halting

A special Σ instruction commits the final configuration:

```text id="1tyyhx"
Σ_halt
```

This integrates the final tape, head position, and control state into a halting state:

```text id="2ril4l"
s⁺ ∈ S_H
```

Σ-halting reads halting as final integration.

#### Ψ-Halting

A Ψ policy forbids further execution once the control state is halting:

```text id="mttzqe"
Ψ_halt : q ∈ F ⇒ no further ∇ / Θ transitions permitted
```

Ψ-halting reads halting as policy-bound closure of future execution.

All four conventions are PMS-UM-valid when declared.

A given PMS-UM instance should state which convention it uses.

Halting is not stuckness.

A stuck configuration is a failure of valid continuation unless the machine convention explicitly treats it as terminal.

### 9.12 Accepting and Rejecting States

If the TM distinguishes accepting and rejecting halting states:

```text id="tvyoox"
F_accept ⊆ F

F_reject ⊆ F
```

PMS-UM may encode them through:

```text id="lcsi5n"
m'.halt_kind = accept
```

or:

```text id="cuxlvp"
m'.halt_kind = reject
```

or through distinct policies:

```text id="5wd98r"
Ψ_accept

Ψ_reject
```

or through distinct commit forms:

```text id="saeie0"
Σ_accept

Σ_reject
```

This is a representation choice.

It does not change the simulation claim.

The central requirement is:

```text id="4g12oy"
accept / reject status in T corresponds to accept / reject status in M_T
under the declared observation profile.
```

### 9.13 Undefined Transitions

If no TM rule applies for the current pair:

```text id="8goir7"
(q, tape[pos])
```

then the PMS-UM simulation may represent this as one of:

```text id="sk59te"
stuck configuration
Λ no-rule / expected transition absent
Ψ denial under P_TM
Φ recontextualization into error context
Σ audit or rejection commit
```

For strict deterministic TM simulation, the simplest reading is:

```text id="rr2hqb"
no applicable rule ⇒ stuck or halt, according to the chosen TM convention
```

If PMS-UM uses Λ, Ψ, Φ, or Σ for undefined transitions, it is adding an operator-typed account of the missing transition.

It is not changing the simulated TM transition function.

The undefined-transition convention must be declared because it affects the observable trace and halting/stuck distinction.

### 9.14 Unbounded Tape

A classical Turing Machine requires an unbounded tape.

PMS-UM supports this by allowing the core state to contain:

```text id="aj1a25"
tape : ℤ → Γ
```

Only finitely many cells differ from the blank symbol in any finite run.

A practical representation may use a finite map with default blank:

```text id="ld5omf"
tape : finite_map(ℤ, Γ) with default b
```

This is extensionally equivalent for finite executions.

The PMS-UM specification can therefore state:

```text id="ydxyei"
abstract tape:
    ℤ → Γ

implementation representation:
    finite support map + blank default
```

The encoding claim concerns the abstract machine.

Implementation artifacts may choose finite-support representations as long as they preserve the abstract tape semantics for all visited positions under the declared profile.

Artifact evidence for finite-support tape behavior strengthens bounded implementation-artifact claims.

It does not by itself prove all abstract tape behavior unless coverage, model, property, and proof scope are stated.

### 9.15 Simulation Trace

A single TM transition maps to a finite PMS-UM operator trace.

Canonical mapping:

```text id="drr8f4"
step_T ↦ Δ ∇ Θ ∇ ∇
```

A finite run of `k` TM steps maps to:

```text id="vsnxd7"
(step_T)^k ↦ (Δ ∇ Θ ∇ ∇)^k
```

With declared cycle marking:

```text id="mpohl9"
(step_T)^k ↦ (Δ ∇ Θ ∇ ∇ Θ)^k
```

If the run halts with Σ-halting:

```text id="nk4j5e"
(Δ ∇ Θ ∇ ∇)^k Σ
```

If the run halts with Ψ-halting:

```text id="9b5ik0"
(Δ ∇ Θ ∇ ∇)^k Ψ
```

If halting is represented purely by membership in `S_H` or `ip = halt`, the final trace may contain no additional halting operator.

The observation profile must state which convention is used.

For a concrete run:

```text id="rjqzr8"
trace(M_T, π_T, s₀) = (Δ ∇ Θ ∇ ∇)^k
```

or the corresponding declared halting variant.

Validity is:

```text id="puadz6"
trace(M_T, π_T, s₀) ∈ L_PMS
```

and, under active policy:

```text id="7o5m6v"
trace(M_T, π_T, s₀) ∈ L_PMS,Ψ
```

For the deterministic TM simulation profile:

```text id="64g2g1"
Trace(M_T, π_T, s₀)
```

contains at most one valid run.

### 9.16 Step Correspondence

Let:

```text id="836v60"
C_T
```

be a Turing Machine configuration and:

```text id="nsiubm"
enc(C_T)
```

be its PMS-UM encoding.

For each deterministic TM transition:

```text id="27qegg"
C_T →_T C_T'
```

there exists a finite PMS-UM run:

```text id="8uquqc"
enc(C_T) ⇒* enc(C_T')
```

whose operator trace is the declared rule-block word:

```text id="qch0b1"
Δ ∇ Θ ∇ ∇
```

or its declared variant.

Conversely, for TM-simulation states of `M_T`, every completed rule-block run corresponds to one valid TM transition.

This gives the simulation relation:

```text id="z72pq2"
C_T →_T C_T'
    iff
enc(C_T) ⇒*_πT enc(C_T')
```

where `⇒*_πT` is the finite PMS-UM execution of the corresponding rule block under program `π_T`.

The exact equivalence holds under the declared encoding convention and observation profile.

It also depends on excluding nondeterministic environment, scheduler, boundary, policy, or commit behavior not part of the deterministic TM simulation profile.

### 9.17 Halting Correspondence

Halting correspondence is:

```text id="7bgy8w"
T halts on input x
    iff
M_T halts on enc(x)
```

under the declared halting convention:

```text id="o08vld"
S_H membership

ip = halt

Σ_halt

Ψ_halt
```

If `T` does not halt, then `M_T` does not reach the corresponding PMS-UM halt condition and continues simulating steps, unless the PMS-UM instance adds an external policy such as fuel, timeout, fairness cutoff, resource limit, or observation cutoff.

Such external policies are not part of the pure TM simulation unless explicitly declared.

A bounded artifact may impose fuel or depth limits.

That can support bounded testing or bounded exploration.

It does not change the unbounded abstract-machine encoding claim.

### 9.18 Encoding Invariants

```text id="edfy6o"
UM-TM1: every TM control state q ∈ Q is represented in PMS-UM core state

UM-TM2: every tape symbol γ ∈ Γ is represented in PMS-UM core state

UM-TM3: the tape is represented as an unbounded ℤ-indexed function or
        an equivalent finite-support map with blank default

UM-TM4: the head position is represented as an integer position in core state

UM-TM5: every defined TM transition maps to a finite PMS-UM instruction block

UM-TM6: π_T ∈ Π

UM-TM7: each rule block begins with Δ distinction over current state/symbol

UM-TM8: the canonical rule-block shape is Δ ∇ Θ ∇ ∇

UM-TM9: tape write, head movement, and control-state update are represented
        through ∇ actions

UM-TM10: Θ records ordered step progression

UM-TM11: halting is represented through S_H, ip = halt, Σ_halt, or Ψ_halt
         under a declared convention

UM-TM12: deterministic TM execution maps to deterministic PMS-UM execution
         when rule selection, boundary behavior, policy behavior, commit
         behavior, and postconditions are functional

UM-TM13: fixed TM frame is declared □ structure, not absence of frame

UM-TM14: fixed TM role is declared Ω structure, not absence of role

UM-TM15: fixed/trivial closed-machine boundary is declared Χ structure, not
         absence of boundary

UM-TM16: undefined transitions are represented as stuck, Λ, Ψ, Φ, or Σ-audit
         according to declared convention

UM-TM17: trace(...) denotes one concrete PMS-UM execution

UM-TM18: Trace(...) denotes the set of possible PMS-UM executions under a
         declared machine/program/profile

UM-TM19: the encoding uses a valid Δ–Ψ subset and does not require all PMS
         operators to be dynamically active

UM-TM20: the encoding establishes PMS-UM computational expressiveness and
         does not validate PMS Base

UM-TM21: bounded artifact evidence for this encoding strengthens bounded
         implementation-artifact claims and does not prove all abstract
         machine behavior unless proof scope is declared
```

### 9.19 Encoding Claim

The encoding establishes the following PMS-UM claim:

```text id="cdu3r7"
For every deterministic classical Turing Machine T, there exists a PMS-UM
machine M_T and program π_T ∈ Π such that each valid step of T is simulated
by a finite valid PMS-UM operator trace, and halting of T corresponds to
halting of M_T under the chosen halting convention.
```

This is a simulation claim inside the abstract PMS-UM machine model.

It does not assert that PMS Base is validated by Turing completeness.

It does not claim that PMS explains all computation as a theory of praxis.

It states that PMS-UM, as an implementation-layer abstract machine, can encode deterministic classical Turing Machine execution.

A stronger operational reading is:

```text id="y0785t"
PMS-UM is specified as at least Turing-complete as an abstract machine.
```

Claim type:

```text id="w15a03"
computational expressiveness / abstract-machine architecture claim
```

Boundary:

```text id="0u3cru"
This is not PMS Base validation.

This is not PMS-STACK implementation completion.

This is not PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking, or distributed
runtime completion.

This is not proof that PMS as a praxis theory is complete.
```

### 9.20 Boundary Statement

The correct boundary for this chapter is:

```text id="jdg97w"
The classical Turing Machine encoding shows that PMS-UM can simulate
deterministic classical Turing Machine execution through finite valid
operator-typed traces.

This strengthens the PMS-UM computational expressiveness claim.

It does not validate PMS Base, does not prove PMS as a total theory of
praxis, does not complete PMS-STACK implementation, and does not establish
correctness or completion of PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking,
or distributed PMS-STACK.

It does not turn Turing-completeness into explanatory universality, traces
into proofs, bounded artifact evidence into full coverage, or PMS-RUST-style
evidence into PMS-UM completion.
```

---

## 10. Computational Expressiveness

PMS-UM is computationally expressive because it contains the machinery required for classical computation:

```text id="0u3r0i"
distinguishable state
mutable storage
ordered progression
control state
branching
halting
unbounded data domain
operator-typed transition rules
```

The expressiveness claim is grounded in the encoding given in Section 9.

The central claim is:

```text id="zemzoo"
PMS-UM is specified as at least as computationally expressive as a
classical deterministic Turing Machine because every deterministic
classical Turing Machine can be encoded as a PMS-UM instance with
equivalent step-by-step simulation under a declared encoding convention.
```

Claim type:

```text id="jfurc0"
abstract-machine computational expressiveness claim
```

Boundary:

```text id="41fqpo"
This claim concerns PMS-UM as a defined abstract machine.

It does not validate PMS Base.

It does not prove all PMS-STACK layers implemented.

It does not imply explanatory universality.

It does not turn Turing-completeness into PMS Base validation.
```

### 10.1 Minimal Computational Ingredients

A computational model capable of simulating a classical Turing Machine needs:

| Ingredient                     | PMS-UM realization                          |
| ------------------------------ | ------------------------------------------- |
| distinguishable symbols/states | Δ over `s_c`                                |
| mutable storage                | ∇ over `s_c`                                |
| ordered progression            | Θ over meta-state/order                     |
| control state                  | encoded in `s_c.q` and `ip`                 |
| head position / pointer        | encoded in `s_c.pos`                        |
| unbounded tape                 | encoded as `tape : ℤ → Γ`                   |
| transition table               | encoded as PMS-UM instruction blocks        |
| branching / rule selection     | Δ plus `ip` update                          |
| halting                        | encoded through `S_H`, `ip = halt`, Σ, or Ψ |

These ingredients are sufficient for the TM encoding.

Therefore PMS-UM has classical computational capacity at least equal to deterministic Turing Machines under the declared abstract-machine encoding.

### 10.2 Turing-Completeness Claim

The PMS-UM Turing-completeness claim is:

```text id="230qh8"
PMS-UM is specified as at least Turing-complete as an abstract machine.
```

Expanded:

```text id="66012w"
For every deterministic classical Turing Machine T, PMS-UM can construct
a machine M_T and program π_T ∈ Π that simulate T's state transitions and
halting behavior under a declared encoding convention.
```

Equivalently:

```text id="1wz7z7"
Classical deterministic TM behavior ⊆ PMS-UM simulation capacity
```

This is an expressiveness result for the defined PMS-UM machine model.

It should be read narrowly and precisely:

```text id="0wmiyw"
It concerns PMS-UM as specified in this document.

It concerns encoding/simulation of deterministic classical Turing Machine
behavior.

It assumes PMS-UM core state can represent an unbounded tape.

It assumes the instruction set includes the required Δ, ∇, Θ, and halting
structures.

It assumes fixed or declared □, Ω, and Χ structures for the minimal TM
profile.

It does not require all Δ–Ψ operators to be dynamically used in the
minimal TM subset.

It does not make PMS Base empirically, formally, or philosophically
validated.
```

### 10.3 Operators Required for Classical Computation

The deterministic TM encoding uses a small subset of the full operator alphabet.

| Operator | TM encoding role                                     |
| -------- | ---------------------------------------------------- |
| Δ        | read, distinguish symbol/control state, select rule  |
| ∇        | write symbol, move head, update control state        |
| Θ        | order discrete computation steps                     |
| Σ        | optional final-state integration / halting           |
| Ψ        | optional halting policy or invalid-transition policy |

Other operators are not required dynamically for the minimal deterministic TM simulation.

| Operator | Status in minimal TM encoding                                                   |
| -------- | ------------------------------------------------------------------------------- |
| □        | fixed as `f_TM`; no dynamic frame changes required                              |
| Λ        | optional for undefined rule / missing transition                                |
| Α        | optional for packaging repeated rule blocks                                     |
| Ω        | fixed as `r_TM`; no dynamic role changes required                               |
| Φ        | optional for error/recovery or undefined-transition handling                    |
| Χ        | fixed/trivial for closed TM simulation; no dynamic boundary management required |

This is not a weakness.

It is a precise expressiveness result:

```text id="wjvd5p"
PMS-UM contains a valid operator-typed subset sufficient for deterministic
classical computation.
```

The fixed/trivial operators remain declared PMS-UM structures:

```text id="uszyq4"
fixed frame ≠ no frame

fixed role ≠ no Ω structure

fixed/trivial closed boundary ≠ no Χ projection
```

The remaining operators make PMS-UM a richer systems-architecture machine, not a different class of hypercomputation.

### 10.4 Beyond the Minimal TM Subset

The full Δ–Ψ operator set gives PMS-UM a systems-oriented structure beyond the minimal TM subset.

| Operator | Additional PMS-UM expressiveness                                            |
| -------- | --------------------------------------------------------------------------- |
| □        | scoped execution, framed computation, contextual interpretation             |
| Λ        | explicit non-event, timeout, absent transition                              |
| Α        | reusable patterns, macro expansion, structured repeated forms               |
| Ω        | role/capability-sensitive execution                                         |
| Φ        | recontextualization, exception, fallback, migration                         |
| Χ        | Distance projection, boundary/reachability discipline, isolated subcontexts |
| Σ        | integration, commit, finalization, durable closure                          |
| Ψ        | active policy, invariant enforcement, future-language restriction           |

These operators do not make PMS-UM “more than computable” in the classical sense.

They make PMS-UM architecturally richer as a systems model.

In PMS-UM, computation is not merely symbol rewriting.

It is symbol rewriting and state transition inside:

```text id="dlglr0"
frames
roles
boundaries
ordering
absence handling
recontextualization paths
commit structures
policy constraints
```

This is the systems-architecture value of PMS-UM.

### 10.5 Deterministic Expressiveness

Deterministic PMS-UM instances can simulate deterministic computation.

A deterministic PMS-UM instance satisfies:

```text id="lzhv6p"
∀κ: | { κ' | κ ⇒ κ' } | ≤ 1
```

For a deterministic TM encoding, determinism requires:

```text id="5f4s4m"
unique rule selection
functional postconditions
fixed frame and role
fixed/trivial closed boundary
fixed or deterministic policy result
deterministic commit behavior
no environment race
no nondeterministic scheduler choice
```

Under those conditions, a deterministic TM run maps to a deterministic PMS-UM run.

A concrete deterministic run satisfies:

```text id="6s55uh"
trace(M_T, π_T, s₀) ∈ L_PMS
```

and, under active policy:

```text id="48lbke"
trace(M_T, π_T, s₀) ∈ L_PMS,Ψ
```

The deterministic simulation profile satisfies:

```text id="53io4h"
|Trace(M_T, π_T, s₀)| ≤ 1
```

This supports the classical computational universality claim for PMS-UM as an abstract machine.

### 10.6 Nondeterministic Expressiveness

PMS-UM can also be instantiated nondeterministically.

A nondeterministic PMS-UM instance allows:

```text id="2v79fb"
∃κ: | { κ' | κ ⇒ κ' } | > 1
```

Nondeterminism may arise from:

```text id="5qp7ql"
relational postconditions
multiple enabled instructions
environment input
scheduler interleavings
symbolic execution
policy alternatives
absence / timeout alternatives
recontextualization paths
boundary alternatives
commit alternatives
```

Nondeterminism remains operator-constrained.

Each concrete execution trace must satisfy:

```text id="v6yjmr"
trace(...) ∈ L_PMS
```

and, under active policy:

```text id="mn5v5w"
trace(...) ∈ L_PMS,Ψ
```

The set of possible executions must satisfy:

```text id="320zqz"
Trace(...) ⊆ L_PMS
```

and, under active policy:

```text id="d9d963"
Trace(...) ⊆ L_PMS,Ψ
```

This allows PMS-UM to model:

```text id="eumf7d"
nondeterministic machines
search
symbolic execution
abstract interpretation
model-checking state spaces
reactive systems
scheduler interleavings
environment-sensitive systems
```

without leaving the Δ–Ψ execution discipline.

### 10.7 Expressiveness vs. Architecture Correctness

Computational expressiveness is not the same as correctness.

The TM encoding shows:

```text id="98125z"
PMS-UM can simulate deterministic classical computation.
```

It does not show:

```text id="024srs"
every PMS-UM program is correct

every PMS-UM program halts

every PMS-UM trace is policy-valid

every PMS-UM Trace set is fully explored

every PMS-CPU refinement is correct

every PMS-OS kernel transition is safe

every PMSL compiler pass preserves semantics

every distributed profile satisfies consensus properties

every implementation artifact conforms to PMS-STACK

PMS Base is validated
```

Correctness claims require additional objects:

```text id="r64643"
property
model
assumptions
proof method
artifact or theorem
scope boundary
coverage argument
```

Thus:

```text id="c4vu0j"
Turing completeness
    ≠ implementation correctness

Turing completeness
    ≠ security correctness

Turing completeness
    ≠ distributed correctness

Turing completeness
    ≠ PMS Base validation
```

### 10.8 Expressiveness vs. Explanation

Computational expressiveness is not explanatory totality.

The Turing-completeness result means that PMS-UM can encode arbitrary deterministic classical computation in the standard simulation sense.

It does not mean:

```text id="0xiiri"
PMS Base is proven

PMS explains all possible systems

PMS-STACK explains all computation as a theory of praxis

PMSL automatically supports every programming-language feature

PMS-CPU, PMS-OS, or PMSL are already implemented

runtime traces prove PMS Base

simulations validate the broader PMS theory
```

The correct reading is:

```text id="ev07v6"
PMS-UM is specified as having classical computational universality as an
abstract machine.
```

The boundary is:

```text id="8xnl2l"
This strengthens the PMS-UM and PMS-STACK implementation-layer architecture
claims.

It does not function as PMS Base validation.
```

### 10.9 Expressiveness and Later Layers

PMS-UM expressiveness matters because later PMS-STACK layers refine PMS-UM rather than inventing new computational foundations.

The refinement chain is:

```text id="y4j7ql"
PMS-UM abstract computation
    ↓
PMS-CPU virtual ISA execution
    ↓
PMS-OS kernel transition system
    ↓
PMSL / PMS-IR language and analysis layer
    ↓
runtime security
    ↓
networking
    ↓
distributed systems
```

The Turing-machine encoding establishes that the abstract machine substrate is computationally adequate.

Later PMS-STACK blocks then specify:

```text id="6wpwqh"
virtual CPU architecture
operating-system architecture
language/runtime specification
security/governance discipline
networking architecture
distributed semantic scaling
implementation-artifact relation
claim boundaries
```

The expressiveness result is therefore foundational for PMS-STACK architecture.

It does not complete the architecture as implementation.

### 10.10 Expressiveness and PMS-RUST

A bounded executable artifact such as PMS-RUST may strengthen implementation-artifact claims by executing, validating, tracing, or rejecting selected PMS-UM-like operator programs.

This relation has the form:

```text id="3l5ctj"
PMS-UM architecture claim
    → bounded executable slice
    → validation rule
    → golden fixture
    → trace evidence
    → limitation
```

PMS-RUST evidence may support claims such as:

```text id="pjp5go"
operator programs can be represented

bounded validation can reject invalid sequences

deterministic runtime traces can be emitted

fixtures can stabilize accepted and rejected examples

bounded boundary-exit discipline can be evidenced under a declared profile
```

It does not establish:

```text id="ym132t"
full PMS-UM implementation

full PMS-CPU

full PMS-OS

full PMSL compiler

full distributed runtime

PMS Base validation
```

PMS-RUST-style `chi_exit` evidence, where present, is artifact/runtime boundary-exit evidence.

It does not complete PMS-CPU `ISO_EXIT`.

It does not redefine PMS Base Χ.

It does not validate PMS Base.

This relation belongs primarily to `08_relation_to_pms_rust.md`, but PMS-UM preserves the boundary.

### 10.11 Expressiveness Invariants

```text id="yliy5x"
UM-CE1: PMS-UM can encode deterministic classical Turing Machine execution

UM-CE2: the encoding uses PMS-UM state, operator-typed instructions,
        transition relation, and valid traces

UM-CE3: π_T ∈ Π for the encoded TM program

UM-CE4: Δ, ∇, and Θ are sufficient for the core deterministic TM step pattern

UM-CE5: Σ or Ψ may encode halting/closure under declared convention

UM-CE6: □, Ω, and Χ may be fixed/trivial in the minimal TM encoding

UM-CE7: fixed frame is declared □ structure, not absence of frame

UM-CE8: fixed role is declared Ω structure, not absence of role

UM-CE9: fixed/trivial closed boundary is declared Χ structure, not absence of
        boundary

UM-CE10: Λ, Α, and Φ may be used for undefined transitions, pattern packaging,
         or structured error/recovery but are not required for the minimal
         deterministic encoding

UM-CE11: trace(...) denotes one concrete PMS-UM execution

UM-CE12: Trace(...) denotes the set of possible PMS-UM executions under a
         declared machine/program/profile

UM-CE13: Turing completeness is an abstract-machine expressiveness claim

UM-CE14: computational expressiveness is not implementation correctness

UM-CE15: computational expressiveness is not explanatory totality

UM-CE16: PMS-RUST-style artifact evidence may strengthen bounded
         implementation-artifact claims but does not complete PMS-UM

UM-CE17: PMS-UM expressiveness strengthens PMS-STACK architecture but does
         not validate PMS Base
```

### 10.12 Boundary Statement

The correct boundary for this chapter is:

```text id="r4bwmo"
Computational expressiveness means that PMS-UM, as an abstract machine,
can encode deterministic classical Turing Machine execution and is therefore
specified as at least Turing-complete.

This is an abstract-machine expressiveness claim.

It does not prove implementation correctness, security correctness,
distributed correctness, PMS-STACK artifact completion, or PMS Base
validation.

It does not turn Turing-completeness into explanatory universality, traces
into proofs, bounded Trace exploration into full coverage, or PMS-RUST-style
evidence into PMS-UM completion.
```

---

## 11. Boundary of the PMS-UM Claim

PMS-UM is the abstract-machine layer of PMS-STACK.

It defines how Δ–Ψ operator words become executable as dependency-constrained, operator-typed state transitions at the abstract-machine level.

This chapter states the claim boundary for the whole `02_pms_um.md` document.

The central claim is:

```text id="4eaum5"
PMS-UM is the abstract-machine specification of PMS-STACK: a stateful,
dependency-constrained, operator-typed transition system over the Δ–Ψ
grammar.
```

Claim type:

```text id="ybdmgc"
abstract-machine / implementation-layer architecture claim
```

Boundary:

```text id="5qva7z"
PMS-UM strengthens the PMS-STACK architecture claim.

It does not validate PMS Base.

It does not imply that later layers are already implemented.

It does not turn Turing completeness into explanatory universality.

It does not turn traces, validators, tests, or artifacts into proofs.
```

### 11.1 What PMS-UM Claims

PMS-UM claims the following.

#### Claim 1 — Abstract Machine Layer

```text id="xegkcj"
PMS-UM is the abstract-machine layer of PMS-STACK.
```

It defines:

```text id="rbg2j1"
machine state
configuration
operator-typed instruction
program
transition relation
valid trace language
halting/stuck behavior
deterministic and nondeterministic execution modes
```

Claim type:

```text id="jvf69c"
abstract-machine architecture claim
```

#### Claim 2 — Operator-Typed Execution

```text id="xnjl9k"
PMS-UM instructions are typed by Δ–Ψ.
```

Each instruction carries:

```text id="xhhagj"
op ∈ { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

The operator tag determines:

```text id="wxp7io"
dependency obligations
allowed state effects
failure mode
trace representation
validity checking
```

Claim type:

```text id="86yemg"
operator-semantics architecture claim
```

#### Claim 3 — Dependency-Constrained Execution

```text id="jy4y3t"
PMS-UM execution is valid only when operator dependencies are available
in history, state, frame, role, policy, boundary state, committed history,
meta-state, environment context, or declared machine/profile structure.
```

Claim type:

```text id="twd2ej"
well-formedness / validity claim
```

#### Claim 4 — Trace and Policy-Constrained Execution

A concrete PMS-UM run produces:

```text id="4e2wsh"
trace(...) ∈ L_PMS
```

and, under active policy:

```text id="5q266b"
trace(...) ∈ L_PMS,Ψ
```

A declared machine/program/profile determines:

```text id="01fbyx"
Trace(...) ⊆ L_PMS
```

and, under active policy:

```text id="xlcuei"
Trace(...) ⊆ L_PMS,Ψ
```

Claim type:

```text id="nczr6d"
trace-language / policy-constrained execution claim
```

#### Claim 5 — Abstract-Machine Expressiveness

```text id="pobzpb"
PMS-UM can encode deterministic classical Turing Machine execution.
```

A stronger safe wording is:

```text id="b3v8df"
PMS-UM is specified as at least Turing-complete as an abstract machine.
```

Claim type:

```text id="kq46n8"
computational expressiveness / simulation claim
```

#### Claim 6 — Refinement Substrate

```text id="mcl1iq"
PMS-UM provides the abstract execution substrate refined by PMS-CPU,
PMS-OS, PMSL/PMS-IR, runtime security, networking, and distributed systems.
```

Claim type:

```text id="81w4gr"
cross-layer architecture claim
```

#### Claim 7 — Bounded Artifact Evidence Relation

```text id="go0tec"
PMS-UM may be evidenced by bounded executable artifacts that parse,
validate, execute, reject, or trace declared subsets/profiles.
```

Claim type:

```text id="rqkv3j"
implementation-artifact evidence relation claim
```

Boundary:

```text id="u9iwsl"
Artifact evidence strengthens bounded implementation claims.

It does not complete PMS-UM.

It does not validate PMS Base.
```

### 11.2 What PMS-UM Does Not Claim

PMS-UM does not claim the following.

It does not validate PMS Base.

It does not prove PMS as a complete praxis theory.

It does not claim that all PMS-STACK layers are already implemented.

It does not claim that PMS-CPU is fabricated hardware.

It does not claim that PMS-OS is an implemented operating system.

It does not claim that PMSL/PMS-IR is a complete compiler or runtime artifact.

It does not claim that PMS-RUST is a full PMS-STACK implementation.

It does not claim that Turing completeness proves the truth of PMS.

It does not claim that computational universality equals explanatory universality.

It does not claim that every valid PMS Base structure must correspond to a PMS-UM program.

It does not claim that every PMS-UM program halts.

It does not claim that every PMS-UM program is safe.

It does not claim that every concrete PMS-UM trace is externally validated.

It does not claim that one concrete trace enumerates the full `Trace(...)` set.

It does not claim that all cross-layer homomorphisms are implemented.

It does not claim that bounded artifact execution is proof of all behavior.

It does not claim that validators prove PMS Base.

It does not claim that tests are proofs.

It does not claim that PMS-RUST-style `chi_exit` completes PMS-CPU `ISO_EXIT`.

It does not claim that AI/tooling output is trusted executable code, compiler authority, verifier authority, proof evidence, policy authority, or PMS Base evidence.

It does not claim that classical computational expressiveness proves OS, security, runtime, network, or distributed correctness.

### 11.3 PMS-UM Claim Table

| PMS-UM statement                                                        | Claim type                             | Boundary                                                                |
| ----------------------------------------------------------------------- | -------------------------------------- | ----------------------------------------------------------------------- |
| PMS-UM is an abstract machine over Δ–Ψ                                  | abstract-machine architecture claim    | not PMS Base validation                                                 |
| PMS-UM instructions are operator-typed                                  | operator-semantics claim               | not CPU opcode implementation                                           |
| PMS-UM programs are finite operator-typed instruction sequences         | program-structure claim                | not PMSL source syntax                                                  |
| PMS-UM transitions are dependency-constrained                           | validity / well-formedness claim       | not full formal verification                                            |
| `trace(...) ∈ L_PMS` / `trace(...) ∈ L_PMS,Ψ`                           | single-run trace-language claim        | not proof of all behavior                                               |
| `Trace(...) ⊆ L_PMS` / `Trace(...) ⊆ L_PMS,Ψ`                           | trace-set/profile claim                | requires declared machine/program/profile                               |
| PMS-UM can encode deterministic Turing Machines                         | expressiveness / simulation claim      | not explanatory universality                                            |
| PMS-UM is specified as at least Turing-complete                         | abstract-machine expressiveness claim  | not PMS Base validation                                                 |
| PMS-UM supports deterministic and nondeterministic instances            | transition-relation claim              | profile must be declared                                                |
| PMS-UM provides source semantics for PMS-CPU                            | refinement substrate claim             | not fabricated hardware                                                 |
| PMS-UM provides source semantics for PMS-OS                             | architecture substrate claim           | not implemented OS                                                      |
| PMS-UM provides source semantics for PMSL/PMS-IR                        | language/runtime substrate claim       | not complete compiler                                                   |
| PMS-UM may be evidenced by artifacts                                    | implementation-artifact relation claim | evidence is bounded                                                     |
| PMS-RUST-style `chi_exit` may evidence bounded boundary-exit discipline | implementation-artifact evidence claim | not PMS-CPU `ISO_EXIT` completion                                       |
| PMS-UM Χ projects Distance as boundary/reachability discipline          | implementation-layer projection claim  | PMS Base Χ remains Distance                                             |
| AI/tooling may propose or analyze PMS-UM-like artifacts                 | optional tooling/profile claim         | not execution, compiler, verifier, proof, policy, or PMS Base authority |

### 11.4 PMS-UM and PMS Base

PMS Base defines operator identity.

PMS-UM projects that identity into abstract-machine architecture.

The relation is:

```text id="m0zktx"
PMS Base
    defines Δ–Ψ operator identity and base grammar

PMS-UM
    defines an abstract machine over Δ–Ψ

PMS-STACK later layers
    refine PMS-UM into implementation-layer architectures

PMS-RUST and other artifacts
    may implement bounded executable slices
```

Correct:

```text id="kgppuu"
PMS-UM uses PMS Base operators as its machine alphabet.
```

Incorrect:

```text id="w9k3n6"
PMS-UM proves PMS Base.
```

Correct:

```text id="bpksxa"
PMS-UM can encode deterministic classical computation.
```

Incorrect:

```text id="35lnsr"
Turing completeness validates PMS as a theory of praxis.
```

### 11.5 PMS-UM and Χ

The Χ boundary is explicit.

PMS Base 1.3:

```text id="7nyrpx"
Χ = Distance
```

PMS-UM projection:

```text id="rrafz3"
Χ = Distance projected into abstract-machine boundary, reachability,
visibility, access-separation, sandboxing, quarantine, and protected
subcontext semantics.
```

Correct:

```text id="gtgvoe"
PMS-UM projects Χ into machine-level boundary discipline.
```

Incorrect:

```text id="wwbj9i"
PMS-UM redefines Χ as sandboxing.
```

Later layers may refine this projection:

```text id="ad7zl4"
PMS-CPU:
    MMU boundary, ASID, protected domain, ISO_EXIT concern

PMS-OS:
    process isolation, namespace boundary

PMSL / Runtime:
    module sandbox, host boundary

Network:
    route boundary, trust zone

Distributed:
    tenant boundary, shard boundary, cross-node isolation
```

No such refinement changes PMS Base operator identity.

Boundary-exit discipline:

```text id="qtudrp"
boundary exit requires active boundary context

unbalanced exit is invalid

sealed isolation forbids entry, expansion, and reachability growth while
permitting valid exit, closure, rollback, audit, or commit under declared
profile
```

PMS-RUST-style `chi_exit` may evidence bounded artifact/runtime boundary-exit discipline.

It does not redefine PMS Base Χ.

It does not complete PMS-CPU `ISO_EXIT`.

It does not validate PMS Base.

### 11.6 PMS-UM and Artifacts

A runtime artifact may implement or evidence a subset of PMS-UM.

An artifact may provide:

```text id="dt4yqm"
operator representation
operator program parser
model validation
stateful validation
deterministic execution
nondeterministic exploration
JSONL trace emission
golden fixtures
REPL/script tooling
acceptance gates
bounded boundary-exit discipline
AI/tooling proposal gates
```

This supports bounded implementation-artifact claims.

Correct:

```text id="7axju2"
This artifact executes a bounded PMS-UM-like operator program profile.
```

Incorrect:

```text id="6pkfbx"
This artifact completes PMS-UM, PMS-STACK, or PMS Base.
```

Artifact relation:

```text id="fzpl47"
PMS-UM claim
    → executable slice
    → validation rule
    → fixture
    → trace evidence
    → limitation
```

Evidence discipline:

```text id="ysr6ux"
tests check
traces record
validators accept or reject under profile
fixtures stabilize known cases
artifacts evidence bounded implementation claims
model checking checks model properties under assumptions
proofs prove stated properties under assumptions
external validation validates externally
```

This relation is strengthened in `08_relation_to_pms_rust.md`.

### 11.7 Safe Wording for PMS-UM

Preferred wording:

```text id="7zg088"
PMS-UM defines the abstract-machine layer of PMS-STACK.
```

```text id="478zo8"
PMS-UM specifies dependency-constrained, operator-typed state transitions
over the Δ–Ψ grammar.
```

```text id="o5go3n"
PMS-UM can encode deterministic classical Turing Machine execution.
```

```text id="c33018"
PMS-UM is specified as at least Turing-complete as an abstract machine.
```

```text id="7oh79y"
A concrete PMS-UM execution produces trace(...).
```

```text id="6brsix"
A declared machine/program/profile determines Trace(...).
```

```text id="i7q30g"
This strengthens the PMS-UM implementation-layer architecture claim.
```

```text id="b2p9z9"
It does not function as PMS Base validation.
```

Avoid:

```text id="sudghu"
PMS-UM proves PMS.
```

```text id="i95sxb"
Turing completeness proves PMS Base.
```

```text id="txleqj"
PMS-UM explains all computation.
```

```text id="k65ic7"
PMS-UM means all PMS-STACK layers are implemented.
```

```text id="zqnxl3"
PMS-RUST validates PMS-UM completely.
```

```text id="x6mw3o"
Χ means isolation in PMS Base.
```

```text id="6r1zla"
A trace proves all behavior.
```

Preferred Χ wording:

```text id="s4qe4r"
PMS Base 1.3 Χ = Distance.

PMS-UM projects Χ as abstract-machine boundary and reachability discipline.
```

Preferred artifact wording:

```text id="764i1c"
PMS-RUST may evidence a bounded PMS-UM-like implementation profile.

It does not complete PMS-UM and does not validate PMS Base.
```

Preferred AI/tooling wording:

```text id="75p7v6"
AI/tooling may propose candidate programs, traces, diagnostics, or analyses.

Host tooling validates.

PMS-UM execution uses only accepted artifacts under a declared profile.

Policy remains Ψ-governed.
```

### 11.8 Boundary Invariants

```text id="87i1cz"
UM-B1: PMS-UM is an abstract-machine architecture claim

UM-B2: PMS-UM uses PMS Base Δ–Ψ operator identity

UM-B3: PMS-UM does not redefine PMS Base

UM-B4: PMS-UM instructions are operator-typed

UM-B5: PMS-UM transitions are dependency-constrained

UM-B6: trace(...) denotes one concrete PMS-UM execution

UM-B7: Trace(...) denotes the set of possible PMS-UM executions under a
       declared machine/program/profile

UM-B8: PMS-UM concrete traces belong to L_PMS or L_PMS,Ψ

UM-B9: PMS-UM Trace sets are bounded by L_PMS or L_PMS,Ψ only under declared
       profile/model scope

UM-B10: PMS-UM can encode deterministic classical Turing Machine execution

UM-B11: Turing completeness is an expressiveness claim, not PMS Base validation

UM-B12: PMS-UM does not imply PMS-CPU, PMS-OS, PMSL, PMS-RUST, networking,
        or distributed PMS-STACK completion

UM-B13: PMS-UM Χ is an implementation-layer projection of PMS Base Distance

UM-B14: boundary exit requires active boundary context; unbalanced exit is
        invalid

UM-B15: sealed isolation forbids entry, expansion, and reachability growth
        while permitting valid exit, closure, rollback, audit, or commit
        under declared profile

UM-B16: artifact evidence may strengthen bounded implementation claims but
        does not complete PMS-STACK

UM-B17: PMS-RUST-style chi_exit may evidence bounded runtime boundary-exit
        discipline but does not complete PMS-CPU ISO_EXIT and does not
        redefine PMS Base Χ

UM-B18: tests check; traces record; validators accept or reject under
        profile; proofs require stated properties, assumptions, and proof
        artifacts

UM-B19: AI/tooling output is not trusted executable code, compiler authority,
        verifier authority, proof evidence, policy authority, or PMS Base
        evidence

UM-B20: PMS-UM boundaries preserve strong architecture claims by typing them
        correctly
```

### 11.9 Closing Statement

PMS-UM is the first abstract-machine execution projection of PMS-STACK.

It converts the Δ–Ψ operator grammar into a machine model with:

```text id="ibom7f"
state
configuration
operator-typed instruction
program
dependency-constrained step relation
valid trace language
deterministic and nondeterministic execution modes
classical computation encoding
claim-typed expressiveness boundary
```

All later PMS-STACK layers refine this substrate.

They may specialize:

```text id="5yhiic"
state space
instruction format
transition relation
policy model
boundary mechanism
commit semantics
trace format
runtime profile
artifact evidence
```

but they should preserve the PMS-UM principle:

```text id="sfgzfi"
valid execution is operator-labeled, dependency-constrained,
layer-typed, boundary-aware, commit-sensitive, profile-declared, and
policy-constrained.
```

The closing PMS-UM claim is:

```text id="x3gfai"
PMS-UM is the abstract-machine specification of PMS-STACK: a
dependency-constrained, operator-typed transition system over Δ–Ψ,
specified as computationally expressive enough to encode deterministic
classical Turing Machine execution.
```

Claim type:

```text id="nofo44"
abstract-machine / implementation-layer architecture claim
```

Boundary:

```text id="t4vacz"
This strengthens the PMS-STACK implementation-layer architecture claim.

It does not validate PMS Base.

It does not complete PMS-STACK as implementation.

It does not turn computational expressiveness into explanatory universality.

It does not turn traces into proofs, Trace sets into external validation,
validators into PMS Base validation, PMS-RUST-style evidence into PMS-UM
completion, or AI/tooling output into execution or verification authority.
```
