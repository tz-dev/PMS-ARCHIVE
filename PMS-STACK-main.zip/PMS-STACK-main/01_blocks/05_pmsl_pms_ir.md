---
document_id: PMS-STACK-DOC-05
title: "PMSL and PMS-IR"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "implementation-layer language/runtime/IR architecture claim"
pms_base_status: "source of Δ–Ψ operator identity"
stack_status: "PMS-STACK projection into operator-typed programming language, runtime architecture, intermediate representation, standard-library API profiles, validation, observability, simulation, and verification interfaces"
chi_status: "PMS Base 1.3 Χ = Distance; PMSL/PMS-IR projects Χ as module boundary, task boundary, channel endpoint visibility, filesystem namespace visibility, network reachability, host boundary, runtime boundary, sandbox boundary, memory-domain separation, access separation, cross-frame transfer discipline, and tooling-visible boundary obligation"
pms_rust_status: "bounded executable PMS-STACK Evidence Spine v0.1; supports implementation-artifact claims through opcode construction, program buffering, model validation, stateful runtime validation, deterministic kernel execution, JSONL traces, REPL/script tooling, vFS service boundaries, golden fixtures, and AI proposal gating; does not complete PMSL/PMS-IR or validate PMS Base"
ai_bridge_status: "optional PMS-RUST tooling/profile for proposing PMS-IR/opcode programs or analyzing traces under host-side validation; not PMSL semantics, compiler authority, verifier authority, trusted executable code, policy authority, or PMS Base evidence"
depends_on:
  - "01_architecture.md"
  - "02_pms_um.md"
  - "03_pms_cpu.md"
  - "04_pms_os.md"
links_forward_to:
  - "06_runtime_security.md"
  - "07_distributed_systems.md"
  - "08_relation_to_pms_rust.md"
  - "09_non_goals_and_claim_boundary.md"
---

# PMSL and PMS-IR

PMSL is the language-level specification of PMS-STACK.

It exposes Δ–Ψ as a programmable semantic discipline: not as comments, naming conventions, or informal annotations, but as the structural typing layer through which programs, modules, policies, effects, concurrency, errors, commits, and verification obligations become analyzable.

PMS-IR is the corresponding operator-preserving intermediate representation. It is the compiler, analyzer, model-checker, runtime, and tooling bridge between PMSL source programs and lower-level PMS-STACK execution layers: PMS-UM, PMS-CPU, PMS-OS, PMS-RUST-style executable slices, simulators, and verification tools.

This document defines the PMSL/PMS-IR architecture as an implementation-layer language, runtime, IR, and tooling specification. It does not claim that a complete PMSL compiler, complete PMSL standard library, complete PMS-IR optimizer, or complete verified toolchain already exists. PMS-RUST v0.1 supplies bounded executable evidence for parts of this layer — especially builder-style opcode construction, program buffering, model validation, stateful runtime validation, deterministic kernel execution, JSONL traces, REPL/script tooling, vFS-service boundaries, golden fixtures, and AI proposal gating — but it is not identical with the full PMSL language specified here.

The positive claim is:

```text
PMSL is the PMS-STACK language specification for operator-typed
programming; PMS-IR is the operator-preserving intermediate form that
keeps Δ–Ψ structure visible to runtimes, analyzers, simulators,
verification tools, and execution backends.
```

The boundary is:

```text
This document strengthens the PMS-STACK language/runtime/IR architecture
claim. It does not function as PMS Base validation, and it does not by
itself assert a complete existing PMSL implementation.
```

## 1. Role of PMSL in PMS-STACK

PMSL is the programming-language layer of PMS-STACK.

Its role is to make the operator grammar of PMS programmable without erasing the structural distinctions that earlier layers expose. PMSL gives programmers, runtimes, analyzers, and tools a language in which frames, roles, policies, non-events, exceptions, commits, concurrency, boundary projections, and effects are first-class semantic structures.

PMSL is not an unrelated surface syntax above PMS-STACK. It is the language-level projection of the same Δ–Ψ architecture used by PMS-UM, PMS-CPU, and PMS-OS.

At stack level:

```text
PMS Base
  → operator grammar Δ–Ψ

PMS-STACK Architecture
  → implementation-layer derivation of machine, CPU, OS, runtime,
    language, security, networking, distributed systems

PMSL
  → language-level expression of Δ–Ψ

PMS-IR
  → operator-preserving intermediate representation

Runtime / Tooling
  → execution, validation, analysis, tracing, simulation, verification

Backends
  → PMS-UM, PMS-CPU, PMS-OS, host runtime, PMS-RUST-style evidence spine
```

### 1.1 PMSL as Language-Level Operator Surface

PMSL exposes operator-typed computation in source form.

A PMSL program may contain:

```text
bindings
types
functions
modules
frames
roles
capabilities
policy scopes
commit blocks
channels
tasks
traps
handlers
timeouts
matches
FFI declarations
runtime calls
standard-library calls
```

Each construct has an operator reading.

```text
source construct → operator word → PMS-IR → runtime/backend behavior
```

Examples:

```text
type distinction        → Δ
statement/effect        → ∇
scope/function/module   → □
timeout/none/no-event   → Λ
macro/pattern/loop      → Α
role/capability         → Ω
sequencing/await        → Θ
trap/exception/handler  → Φ
module boundary         → Χ projection
return/transaction      → Σ
policy/invariant        → Ψ
```

PMSL therefore preserves the structural commitments of PMS-STACK at the language level.

### 1.2 PMSL as Bridge Between OS and Tooling

PMSL sits above PMS-OS and below high-level developer tooling.

```text
PMSL source
  → PMS-IR
  → static checks
  → runtime lowering
  → syscalls / runtime calls / host calls
  → traces / model checks / proofs / simulations
```

PMSL programs may target:

```text
PMS-UM execution
PMS-CPU lowering
PMS-OS syscalls
PMS runtime services
host interop layers
simulation environments
PMS-RUST-style opcode/runtime artifacts
```

This bridge has two obligations.

First, PMSL must be expressive enough to write structured programs:

```text
services
tasks
protocols
filesystem operations
IPC patterns
policy scopes
driver-facing routines
runtime libraries
verification examples
```

Second, PMSL must preserve enough operator structure for analysis:

```text
who acted?
inside which frame?
under which role?
with which policy?
which absence path existed?
which commit boundary closed the effect?
which boundary projection prevented reachability?
which exception reframed execution?
```

A language that erases these distinctions during compilation would not be PMSL-conformant.

### 1.3 PMSL and PMS-IR

PMSL and PMS-IR are distinct layers.

```text
PMSL   = source language
PMS-IR = operator-tagged intermediate representation
```

PMSL gives humans and tools a structured syntax.

PMS-IR gives compilers, analyzers, runtimes, simulators, and verification systems a canonical representation.

PMSL/PMS-IR does not redefine Χ.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At the PMSL/PMS-IR layer, Χ projects as:

```text
module boundary
sandbox boundary
host boundary
visibility control
runtime boundary
foreign-frame boundary
reachability discipline
tooling-visible boundary obligation
```

This projection is architectural and implementation-facing. It preserves PMS Base Χ as Distance while specifying how distance becomes enforceable or analyzable in language, IR, runtime, module, host, and tooling contexts.

A PMSL fragment such as:

```pmsl
policy with P_write {
    frame enter F_log {
        write(file, data)
    }
}
```

has a structural lowering:

```text
Ψ enter policy scope
Δ classify frame and file
Ω check role/capability
□ enter frame
∇ perform write effect
Σ commit or stage effect
Φ handle policy, IO, or runtime fault if needed
□ leave frame
Ψ close policy scope
```

PMS-IR must preserve these operator tags.

A backend may optimize, transform, inline, reorder, or lower code, but it may not erase the semantic commitments attached to operator classes.

### 1.4 PMSL as Specification, Not Completed Implementation Claim

PMSL in PMS-STACK is a language specification.

It defines:

```text
syntax direction
semantic mapping
operator-typed constructs
runtime architecture
standard-library domains
IR structure
analysis obligations
verification hooks
debugging and observability model
simulation interface
example fragments
```

It does not assert:

```text
a complete parser exists
a complete compiler exists
a complete standard library exists
a complete optimizer exists
a complete proof engine exists
a complete PMSL runtime exists
all PMSL examples already execute unchanged
```

The implementation relation is layered.

```text
PMSL specification
  → defines language/runtime/IR obligations

PMS-RUST v0.1
  → demonstrates bounded executable slices:
     opcode construction, program buffering, model validation,
     stateful runtime validation, deterministic kernel execution,
     REPL/script tooling, JSONL traces, vFS service surface,
     golden fixtures, AI proposal gating

Future artifacts
  → may implement more of PMSL, PMS-IR, runtime, standard library,
     compiler lowering, verification, and simulation
```

PMS-RUST v0.1 strengthens implementation-artifact claims.

It does not complete:

```text
PMSL
PMS-IR
PMS-CPU
PMS-OS
distributed runtime
PMS Base validation
```

Validation in this document means acceptance or rejection under a declared schema, model, runtime profile, backend profile, tool profile, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, theoretical adequacy, or full behavioral coverage.

AI Bridge Boundary:

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

It is not:

```text
PMSL semantics
compiler authority
verifier authority
trusted executable code
policy authority
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses, canonicalizes, maps, and validates.
Kernel/runtime executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output is therefore a proposal artifact. It is not PMSL source authority, not PMS-IR truth, not verification evidence, not trusted executable code, and not PMS Base validation.

This boundary preserves the strength of the PMSL architecture claim without conflating specification, tooling, AI assistance, executable slices, and PMS Base status.

### 1.5 PMSL in the Homomorphic Stack

PMSL participates in the homomorphic stack described by PMS-STACK.

At a high level:

```text
PMS operator word
  → PMS-UM instruction sequence
  → PMS-CPU ISA trace
  → PMS-OS kernel primitive sequence
  → PMSL source construct
  → PMS-IR operator-tagged program
```

The important direction for this document is bidirectional readability:

```text
PMSL source can lower into operator words.
Operator-level behavior can be surfaced back into PMSL-level tooling.
```

This enables:

```text
source-level debugging of operator effects
static detection of role/capability violations
policy-aware linting
commit-boundary analysis
exception/recontextualization analysis
non-event and timeout checking
trace-to-source mapping
model checking over program structure
```

PMSL is therefore not just a frontend language. It is the human-facing surface of an operator-preserving toolchain.

### 1.6 PMSL Runtime Role

The PMSL runtime provides the specified execution substrate for PMSL programs.

It mediates between source-level constructs and lower-level execution.

Runtime responsibilities include:

```text
task scheduling
frame stack management
role/capability state
policy scope activation
exception and trap handling
channel and IPC coordination
commit-region management
allocation and resource integration
FFI boundary handling
standard-library service dispatch
trace and audit emission
```

The runtime does not replace PMS-OS. It sits above it.

```text
PMSL runtime task
  → may map to PMS-OS thread/process/task
  → may call PMS-OS syscalls
  → may use PMS-OS IPC, filesystem, timer, and policy services
```

The runtime may also run in a host profile:

```text
PMSL runtime on host OS
PMSL runtime on PMS-RUST-style deterministic kernel
PMSL runtime in simulator
PMSL runtime on future PMS-OS
```

The PMSL runtime is specified as an architecture layer. Concrete runtime artifacts may implement bounded profiles. PMS-RUST v0.1 is one such bounded evidence spine, not the full PMSL runtime.

The architectural obligation is the same across profiles: preserve operator semantics.

### 1.7 PMSL Standard Library Role

The PMSL standard library provides canonical, operator-typed API profiles for recurring domains.

Likely standard-library domains include:

```text
Core
Frame
Role
Policy
Task
Channel
Event
Time
FS
Net
Log
Trace
Runtime
FFI
Verify
```

These standard-library domains are architecture-level API profiles. They define operator profiles, type/effect obligations, and runtime contracts. They do not claim that every listed API already exists as a completed library implementation.

The standard library should not hide Δ–Ψ behind untyped convenience APIs. It should expose safe, compositional patterns whose operator effects are known.

Example:

```text
FS.write(path, data)
```

should have a known operator profile:

```text
Δ path distinction
Ω write authority
Χ-projected namespace visibility
Ψ filesystem policy
∇ write effect
Σ commit or stage write
Φ error/recovery path
Λ no-resource/no-target cases
```

The standard library therefore acts as the canonical Α-layer for common PMSL patterns.

### 1.8 PMSL Tooling Role

PMSL tooling depends on operator preservation.

Tools include:

```text
formatter
parser
type checker
PMS-IR generator
dependency checker
operator-word validator
role/capability analyzer
policy checker
commit checker
exception checker
concurrency checker
model checker
simulator
debugger
trace viewer
linting system
AI proposal gate
```

The tooling claim is:

```text
PMSL programs are analyzable because their source constructs map to
operator-tagged PMS-IR rather than to opaque untyped control flow.
```

A PMSL toolchain should be able to answer:

```text
Which code mutates state?
Which code requires authority?
Which frame is active?
Which policy applies?
Which non-event paths are possible?
Which commits close which effects?
Which exceptions recontextualize which continuations?
Which boundary projections are crossed?
Which AI-proposed artifacts were rejected, accepted, or executed after acceptance?
```

This is the reason PMS-IR must preserve operator tags.

### 1.9 PMSL Claim Type

The claim type of this document is:

```text
LANGUAGE / RUNTIME / IR ARCHITECTURE CLAIM
```

It states that PMS-STACK specifies a complete implementation-layer language/runtime/IR architecture specification derivable from Δ–Ψ.

It does not state that:

```text
PMSL validates PMS Base
PMS-IR validates PMS Base
PMS-RUST is the complete PMSL implementation
tests prove the language specification
traces prove PMS theory
host interoperability equals PMS-OS equivalence
AI output is PMSL source authority
AI output is compiler authority
AI output is verification evidence
```

The positive boundary is:

```text
PMSL strengthens the PMS-STACK implementation-layer architecture claim by
showing how Δ–Ψ becomes programmable source structure, runtime behavior,
standard-library organization, IR representation, tooling discipline,
host-boundary control, and evidence-producing executable slices.
```

## 2. PMSL Design Principle: Operator-Typed Programming

The design principle of PMSL is operator-typed programming.

Operator-typed programming means that source constructs are classified by the PMS operator role they perform and by the obligations that follow from that role.

A PMSL program is not only a sequence of statements. It is a structured operator word with type, effect, authority, frame, ordering, boundary, commit, exception, and policy information preserved.

The central design claim is:

```text
PMSL programs are valid when their source constructs lower to
well-formed, operator-typed PMS-IR whose Δ–Ψ obligations are explicit,
checkable, and preserved across runtime and backend execution.
```

### 2.1 Operators as Semantic Types

In PMSL, an operator tag is a semantic type class.

```text
Δ-class construct  → distinction / classification / branch / match
∇-class construct  → effect / mutation / execution
□-class construct  → scope / frame / module / runtime context
Λ-class construct  → absence / timeout / no-event / optional branch
Α-class construct  → pattern / macro / loop / reusable protocol
Ω-class construct  → role / capability / authority / access scope
Θ-class construct  → order / sequence / await / progression
Φ-class construct  → trap / exception / handler / recontextualization
Χ-class construct  → Distance-projected boundary / visibility / reachability discipline
Σ-class construct  → return / commit / integration / transaction close
Ψ-class construct  → invariant / policy / effect guard
```

A construct may carry multiple operator roles, but one role normally dominates its semantic obligation.

Examples:

```text
match x { ... }          → Δ-dominant
x = x + 1                → ∇-dominant
frame enter F { ... }    → □/Ω/Χ-projection dominant
timeout after t { ... }  → Λ/Θ-dominant
policy with P { ... }    → Ψ-dominant
commit Σ { ... }         → Σ-dominant
trap on E { ... }        → Φ-dominant
spawn task { ... }       → Θ/□/Χ-projection dominant
```

### 2.2 Operator Tags Are Obligations

An operator tag is not decoration.

It imposes obligations on the compiler, runtime, analyzer, and backend.

| Operator | Obligation                                                                                                             |
| -------- | ---------------------------------------------------------------------------------------------------------------------- |
| Δ        | distinguish target, kind, type, branch, or symbol before dependent use                                                 |
| ∇        | record or type state-changing effect                                                                                   |
| □        | establish valid frame/scope/context before enclosed operations                                                         |
| Λ        | represent absence as a defined program path                                                                            |
| Α        | expand to a well-formed operator word                                                                                  |
| Ω        | verify role/capability before protected action                                                                         |
| Θ        | preserve required ordering and scheduling relation                                                                     |
| Φ        | preserve continuation/recontextualization semantics                                                                    |
| Χ        | preserve PMS Base Distance as a layer projection into boundary, visibility, sandbox, host, or reachability obligations |
| Σ        | commit, integrate, return, or close transactional state explicitly                                                     |
| Ψ        | enforce invariant, policy, or effect guard                                                                             |

Thus:

```text
operator tag ⇒ static obligation + runtime obligation + tooling obligation
```

Example:

```pmsl
commit Σ {
    write(file, data)
}
```

requires:

```text
Σ scope exists
write effect is known
commit boundary is explicit
failure path is defined
post-commit state is visible according to policy
```

### 2.3 Operator-Typed Lowering

PMSL compilation begins by lowering source constructs to operator-tagged PMS-IR.

Generic lowering:

```text
PMSL source
  → parse tree
  → typed AST
  → operator-typed AST
  → PMS-IR
  → validation / analysis / backend lowering
```

Each PMS-IR operation should retain:

```text
operator tag
source span
operand types
frame context
role/capability requirements
policy context
effect class
commit behavior
absence behavior
exception behavior
boundary-projection behavior
```

A PMSL compiler may choose different concrete representations, but the semantic shape must remain inspectable.

### 2.4 Operator Word Validity

PMSL source must lower to well-formed operator words.

A local operator word:

```text
w = op_1 ; op_2 ; ... ; op_n
```

is valid only if:

```text
w satisfies operator dependency constraints
∧ type obligations hold
∧ role/capability obligations hold
∧ frame obligations hold
∧ boundary-projection obligations hold
∧ commit obligations hold
∧ policy obligations hold
```

Example valid sequence:

```text
Δ classify file
Ω check write capability
□ enter IO frame
Χ check projected namespace visibility
Ψ check policy
∇ perform write
Σ commit or stage effect
Φ handle failure if needed
```

Example invalid sequence:

```text
∇ write file
```

because the effect lacks:

```text
Δ target distinction
Ω authority
□ context
Χ-projected visibility / reachability discipline
Ψ policy
Σ commit/failure semantics
```

In source form, PMSL may make some steps implicit, but the compiler must reconstruct them in PMS-IR.

### 2.5 Explicit and Implicit Operator Syntax

PMSL supports both explicit and implicit operator structure.

#### Explicit operator syntax

Explicit syntax makes the operator visible in source.

```pmsl
commit Σ {
    write(file, data)
}
```

```pmsl
policy with P_write {
    write(file, data)
}
```

```pmsl
frame enter F_user {
    let x = 1 + 2
}
```

#### Implicit operator syntax

Implicit syntax uses ordinary language constructs that lower into operator classes.

```pmsl
let x = 1 + 2
```

lowers to:

```text
Δ classify binding x
∇ evaluate expression
Σ bind value into local frame
```

```pmsl
match msg.kind {
    "open" => handle_open(msg)
    "close" => handle_close(msg)
}
```

lowers to:

```text
Δ classify message kind
Θ select branch order
∇ execute selected handler
Σ integrate result if required
```

Both styles are valid. The requirement is not visual operator density; the requirement is operator-preserving semantics.

### 2.6 PMSL Construct Mapping

The following table defines the core mapping used throughout this document.

| PMSL construct        | Primary operators           | Meaning                                             |
| --------------------- | --------------------------- | --------------------------------------------------- |
| `let`, `const`, `var` | Δ, ∇, Σ                     | distinguish binding, compute value, bind into frame |
| expression            | Δ, ∇, Θ                     | classify operands, evaluate, order substeps         |
| block                 | □, Θ, Σ                     | scoped execution and integration                    |
| function              | □, Δ, Ω, Σ                  | callable frame with signature, role, return         |
| call                  | Δ, Ω, □, Θ, Φ, Σ            | distinguish target, authorize, enter frame, return  |
| `match`               | Δ, Θ                        | classify branch and order selected path             |
| `if`                  | Δ, Θ                        | condition distinction and path selection            |
| loop                  | Α, Θ, Δ, Λ                  | recurring pattern with termination/non-event paths  |
| `frame enter`         | Δ, Ω, □, Χ projection       | classify and enter protected context                |
| `policy with`         | Ψ, Ω, □                     | activate policy scope                               |
| `role`                | Ω                           | assign or require role/capability                   |
| `channel<T>`          | Δ, Ω, Θ, Λ, Σ, Φ            | typed communication medium                          |
| `send`                | Δ, Ω, Χ projection, ∇, Θ, Σ | message delivery                                    |
| `recv`                | Δ, Ω, Χ projection, Λ, ∇, Φ | receive or absence path                             |
| `spawn`               | □, Ω, Χ projection, Θ, Ψ    | create ordered concurrent locus                     |
| `cancel`              | Φ, Ψ, Σ                     | recontextualize and close task lifecycle            |
| `trap` / `on`         | Φ, Δ, Ψ                     | exception/recontextualization handling              |
| `commit Σ`            | Σ, Ψ                        | explicit integration boundary                       |
| FFI call              | □, Ω, Χ projection, Φ, Σ, Ψ | foreign-frame transition and return                 |

This table is normative for the architecture. Later sections refine each construct.

### 2.7 Operator-Typed Effects

PMSL effects are operator-typed.

An effect type records what a piece of code may do.

Example effect classes:

```text
Effect<Δ>        classification / lookup / branch
Effect<∇>        mutation / IO / state change
Effect<□>        frame enter/leave
Effect<Ω>        capability use / role transition
Effect<Θ>        scheduling / ordering / await
Effect<Φ>        trap / exception / reframe
Effect<Χ>        Distance-projected boundary crossing / sandbox entry / visibility control
Effect<Σ>        commit / transaction close
Effect<Ψ>        policy activation / invariant check
Effect<Λ>        timeout / absence / optional no-event path
```

A function signature may expose effects:

```pmsl
fn write_log(path: Path, data: Bytes)
    -> Result<Unit, IOTrap>
    effects(Δ, Ω, Χ, ∇, Σ, Φ, Ψ)
```

Meaning:

```text
the function distinguishes a path,
requires authority,
checks boundary-projected visibility,
performs a write effect,
commits or stages the effect,
may trap,
and is policy-governed.
```

Effects are not optional metadata. They are compiler- and analyzer-visible obligations.

### 2.8 Operator-Typed Capabilities

Capabilities are Ω-typed values or declarations.

Example:

```pmsl
role LogWriter {
    cap fs.write("/var/log/**")
    cap log.append
}
```

A call requiring the capability:

```pmsl
with role LogWriter {
    FS.write("/var/log/app.log", msg)
}
```

lowers to:

```text
Δ classify path
Ω verify LogWriter has fs.write capability
Χ verify projected namespace visibility
Ψ check active filesystem policy
∇ write
Σ commit/stage
```

Capability use is explicit in PMS-IR even where source syntax permits inference.

### 2.9 Operator-Typed Frames

Frames are □-typed contexts.

PMSL frames include:

```text
lexical block
function body
module
task
channel
policy scope
transaction
foreign call frame
runtime context
sandbox
```

A frame has:

```text
identity
scope
visible symbols
role/capability environment
policy environment
Χ-projected boundary state
resource context
commit behavior
exception handlers
```

Frame entry:

```text
Δ classify frame
Ω verify entry authority
Χ check projected boundary / visibility / reachability constraints
□ enter frame
Ψ activate frame policy
```

Frame exit:

```text
Σ commit local obligations if required
Φ recontextualize to parent continuation
□ restore parent frame
Ψ close or restore policy context
```

### 2.10 Operator-Typed Policies

Policies are Ψ-typed program constraints.

Example:

```pmsl
policy P_write_tmp {
    allow fs.write where path.starts_with("/tmp/")
    deny  fs.write where path.starts_with("/secure/")
}
```

Policy activation:

```pmsl
policy with P_write_tmp {
    FS.write("/tmp/a.txt", data)
}
```

lowering:

```text
Ψ activate policy
Δ classify path and operation
Ω verify write capability
Χ verify projected namespace visibility
Ψ evaluate write rule
∇ perform write
Σ commit/stage
Ψ close scope
```

Policies may constrain:

```text
effects
roles
frames
resources
channels
FFI calls
commit conditions
timeouts
exception recovery
module imports
standard-library APIs
```

### 2.11 Operator-Typed Absence

PMSL treats absence as Λ, not as unstructured failure.

Absence appears in:

```text
optional value missing
channel empty
timeout expired
future not ready
file absent
route unavailable
no event
no matching branch
```

Example:

```pmsl
recv ch timeout 50ms on timeout {
    handle_absence()
}
```

operator reading:

```text
Δ classify channel
Ω check receive capability
Θ wait/order receive interval
Λ no-message before deadline
Φ or branch into timeout handler
Σ integrate result
```

This makes no-event paths analyzable instead of incidental.

### 2.12 Operator-Typed Recontextualization

Exceptions, traps, migrations, fallbacks, handler frames, and foreign ABI crossings are Φ-typed.

Example:

```pmsl
trap on PolicyViolation as e {
    recover(e)
}
```

lowering:

```text
Δ classify trap
Φ enter handler context
□ install handler frame
Ω verify handler authority
Ψ check recovery policy
∇ run recovery
Σ commit recovery result
Φ return or abort
```

PMSL does not treat exceptions as uncontrolled jumps. They are structured recontextualizations.

### 2.13 Operator-Typed Commit

Commit is explicit through Σ.

Commit appears in:

```text
return values
transaction blocks
filesystem writes
message delivery
policy installation
module linking
trace emission
runtime state publication
```

Example:

```pmsl
commit Σ {
    FS.write(path, data)
    Log.info("written")
}
```

Commit block reading:

```text
Δ classify enclosed effects
Ω verify authority for each effect
Ψ check policy
∇ stage mutations
Σ integrate staged effects
Φ rollback/recover if commit fails
```

A PMSL program must distinguish:

```text
effect executed
effect staged
effect committed
effect rolled back
effect visible
effect durable
```

These are not interchangeable.

### 2.14 Operator-Typed Patterns

PMSL uses Α for reusable patterns.

Patterns may include:

```text
loop
retry
request/response
supervised task
transaction
resource acquisition/release
pipeline
pub-sub handler
filesystem update
upgrade/migration
```

Example pattern:

```pmsl
pattern retry<N>(op) {
    loop until success or attempts == N {
        op()
    }
}
```

operator reading:

```text
Α retry pattern
Θ order attempts
Δ classify success/failure
Λ represent no-success attempt
Φ handle failure if policy requires
Σ integrate final result
Ψ enforce retry policy
```

Α is not a magic macro. It must expand to a valid operator word.

### 2.15 Operator-Typed Concurrency

PMSL concurrency is not raw thread spawning.

Concurrency constructs are typed by:

```text
□ task frame
Ω task authority
Χ task-boundary projection
Θ scheduling and await order
Λ absence / timeout / not-ready
Φ cancellation or failure
Σ join / completion commit
Ψ task policy
```

Example:

```pmsl
spawn task T_worker {
    process_messages(ch)
}
```

lowering:

```text
Δ classify task
Ω verify spawn capability
□ create task frame
Χ establish projected task boundary
Ψ attach task policy
Θ schedule task
Σ commit task creation
```

A `join` or `await` similarly produces ordering, absence, and commit obligations.

### 2.16 Operator-Typed Modules

Modules are □/Χ/Ω/Ψ structures.

A module defines:

```text
symbol frame
export boundary
import relation
capability surface
policy surface
version
lifecycle
```

Module import:

```text
Δ identify module and exported symbol
Ω verify import capability
Χ verify projected module visibility
Ψ check import policy
Σ commit link relation
```

A PMSL module may be compiled separately, analyzed separately, linked under policy, or sandboxed as a runtime frame.

### 2.17 Operator-Typed FFI

Foreign calls are explicit frame transitions.

```pmsl
foreign fn host_read(path: HostPath) -> Bytes
    effects(□, Ω, Χ, Φ, Σ, Ψ)
```

FFI call reading:

```text
Δ classify foreign symbol
Ω verify foreign-call capability
Χ establish projected host boundary
Φ reframe ABI/context
∇ perform host call
Σ integrate returned value or effect
Φ map foreign error into PMSL trap/absence
Ψ enforce FFI policy
```

No FFI call is semantically invisible. Foreign execution is a controlled boundary operation.

### 2.18 Operator-Typed Verification

Operator-typed programming creates verification hooks.

A PMSL checker can verify under a declared model, runtime profile, tool profile, or conformance rule:

```text
all protected effects have Ω authority
all frame transitions are □-valid
all boundary crossings respect Χ-projected visibility
all policies are Ψ-compatible
all commits close required effects
all traps have handlers or declared propagation
all Λ paths are handled or declared
all Α patterns expand to valid operator words
all concurrent operations preserve Θ ordering obligations
```

This is why PMSL and PMS-IR are specified together.

PMSL is the source form.

PMS-IR is the verification substrate.

Verification results remain property-specific and profile-bound. They do not validate PMS Base, prove all possible executions, or establish theoretical finality.

### 2.19 Design Consequence

The consequence of operator-typed programming is:

```text
A PMSL program is well-formed when its source constructs lower to an
operator-preserving PMS-IR whose distinctions, effects, frames,
absences, patterns, authorities, orderings, recontextualizations,
boundary projections, commits, and policies remain explicit and checkable.
```

This design gives PMSL a direct role in PMS-STACK: it is the programmable surface of Δ–Ψ, and PMS-IR is the artifact format that keeps that surface semantically accountable across compilation, runtime, tooling, simulation, and verification.

---

## 3. Lexical and Grammar Overview

PMSL syntax is designed to make operator-typed programming readable without forcing every program to be written directly as symbolic Δ–Ψ code.

The grammar therefore has two surfaces:

```text
ordinary language surface
  → modules, functions, bindings, blocks, calls, types, channels,
    policies, roles, traps, commits, FFI declarations

operator-explicit surface
  → Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ annotations,
    operator blocks, effect annotations, and operator-aware macros
```

Both surfaces lower into PMS-IR.

The central grammar claim is:

```text
PMSL syntax is valid when its lexical forms, declarations, statements,
expressions, types, annotations, and blocks can be lowered into
operator-preserving PMS-IR without erasing Δ–Ψ obligations.
```

This section defines the language surface at specification level. It is a grammar and syntax architecture claim, not a completed parser, completed compiler, completed formatter, or completed language-server claim.

Claim type:

```text
LANGUAGE GRAMMAR / SYNTAX ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies the PMSL lexical and grammar architecture.

It does not claim that a complete PMSL parser, complete compiler,
complete macro expander, complete formatter, complete standard library,
or complete PMSL implementation already exists.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

### 3.1 Scope of the Grammar

This grammar overview defines:

```text
source text conventions
tokens
keywords
identifiers
literals
operator glyphs
ASCII fallbacks
punctuation
comments
annotations
module skeleton
declaration skeleton
statement skeleton
expression skeleton
type skeleton
operator block syntax
effect annotation syntax
PMS-IR lowering hooks
normalization rules
diagnostic source-span obligations
```

It does not define:

```text
full parser implementation
complete precedence table
complete standard library
complete compiler lowering algorithm
complete macro expander
complete formatter
complete language server
production grammar stability
```

Those are implementation artifacts that may be produced by future PMSL/PMS-IR tooling.

The architectural requirement is:

```text
syntax must preserve operator meaning
```

not:

```text
every possible syntactic detail is finalized here
```

AI-generated source or PMS-IR-like text is not a grammar authority. If an AI Bridge proposes PMSL-like syntax, PMS-IR, or opcode programs, those proposals remain advisory until host-side parsing, canonicalization, mapping, validation, and profile acceptance succeed.

### 3.2 Source Text and Character Set

PMSL source files are Unicode text.

A PMSL implementation profile should support:

```text
UTF-8 source encoding
Unicode operator glyphs
ASCII fallbacks for operator glyphs
line comments
block comments
string literals
numeric literals
identifier names
module paths
source spans for diagnostics
```

Canonical operator glyphs:

```text
Δ ∇ □ Λ Α Ω Θ Φ Χ Σ Ψ
```

Recommended ASCII fallbacks:

| Glyph | ASCII fallback | PMSL role                                                                                    |
| ----- | -------------- | -------------------------------------------------------------------------------------------- |
| `Δ`   | `DELTA`        | distinction / classification                                                                 |
| `∇`   | `NABLA`        | enactment / mutation / execution                                                             |
| `□`   | `FRAME`        | frame / context                                                                              |
| `Λ`   | `LAMBDA`       | absence / non-event                                                                          |
| `Α`   | `ALPHA`        | attractor / pattern                                                                          |
| `Ω`   | `OMEGA`        | role / capability / authority                                                                |
| `Θ`   | `THETA`        | ordering / sequencing                                                                        |
| `Φ`   | `PHI`          | recontextualization / trap / exception                                                       |
| `Χ`   | `CHI`          | PMS Base Distance projected at this layer as boundary / visibility / reachability discipline |
| `Σ`   | `SIGMA`        | commit / integration                                                                         |
| `Ψ`   | `PSI`          | policy / invariant / self-binding                                                            |

The ASCII form is for portability and tooling normalization. It does not create a separate operator.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At the PMSL/PMS-IR layer, Χ is projected into grammar-visible boundary obligations such as:

```text
module boundary
sandbox boundary
host boundary
foreign-frame boundary
runtime boundary
visibility control
reachability discipline
boundary-crossing effect
```

Thus, a PMSL grammar production may use `Χ` or `CHI` to mark a boundary obligation, but this remains a layer projection of PMS Base Χ = Distance rather than a redefinition of Χ.

Example:

```pmsl
commit Σ {
    FS.write(path, data)
}
```

and:

```pmsl
commit SIGMA {
    FS.write(path, data)
}
```

may be accepted as equivalent by a profile that supports ASCII fallback normalization.

### 3.3 Comments

PMSL supports comments for documentation and literate operator explanation.

Line comment:

```pmsl
// comment
```

Block comment:

```pmsl
/* comment */
```

Comments have no runtime effect.

However, tools may read structured comments for documentation, examples, literate specifications, or generated diagnostics.

Example:

```pmsl
// Δ: classify file path
// Ω: require write capability
// Σ: commit staged write
commit Σ {
    FS.write(path, data)
}
```

A PMSL compiler must not depend on comments for semantic correctness. Operator obligations must be represented in syntax, type information, annotations, declarations, profile rules, or PMS-IR.

A comment may explain an operator reading. It may not be the only place where the obligation exists.

### 3.4 Whitespace and Layout

Whitespace separates tokens.

PMSL is block-delimited by braces.

```pmsl
block {
    statement
    statement
}
```

A profile may define formatter conventions, but the grammar is not indentation-sensitive at architecture level.

Recommended layout:

```pmsl
module app.log

role LogWriter {
    cap fs.write("/var/log/**")
}

fn main() -> Unit {
    policy with P_log {
        commit Σ {
            FS.write("/var/log/app.log", "boot")
        }
    }
}
```

The formatter should preserve operator-visible structures:

```text
policy scopes
frame scopes
commit scopes
trap handlers
channel declarations
role/capability blocks
module boundaries
foreign-frame boundaries
```

Formatter output is a tooling artifact. Formatting must not change operator obligations, frame structure, policy scope, commit boundaries, or Χ-projected boundary obligations.

### 3.5 Identifiers

Identifiers name modules, functions, variables, types, roles, capabilities, policies, frames, channels, and patterns.

Informal lexical form:

```ebnf
Identifier =
    Letter { Letter | Digit | "_" } ;
```

Reserved keywords are not valid ordinary identifiers unless escaped by a future profile.

Examples:

```pmsl
LogWriter
P_write_tmp
F_user
channel_in
read_file
Σ_tx
Φ_trap
Δ_kind
```

Operator-prefixed names are allowed as naming conventions:

```pmsl
type Σ_tx<FileWrite>
type Φ_trap<IOError>
type Δ_kind<Message>
```

These names do not by themselves create operator obligations.

They are type or symbol names that tools may use for inference, diagnostics, or proof obligations if the active profile permits it.

The obligation-bearing forms are:

```text
operator annotations
effect clauses
requirement clauses
operator blocks
typed declarations
profile rules
PMS-IR operator tags
```

A name such as `Σ_tx` may suggest commit semantics, but the compiler must still derive or check an actual Σ obligation from declarations, annotations, types, or PMS-IR lowering.

### 3.6 Literals

PMSL may support the following literal families.

```text
integer
float
boolean
string
byte string
symbol
duration
path
none / absence marker
```

Examples:

```pmsl
let n = 42
let ratio = 0.75
let ok = true
let msg = "hello"
let t = 50ms
let path = "/tmp/a.txt"
let missing = none
```

Literal classification is Δ-governed:

```text
literal token
→ Δ classify literal kind
→ assign literal type
→ lower into PMS-IR constant or value node
```

Absence-like literals must not erase Λ semantics.

For example:

```pmsl
none
```

may be a value-level absence marker, but:

```pmsl
recv ch timeout 50ms
```

creates a Λ-capable operation path because an expected event may fail to arrive.

The grammar must preserve this distinction:

```text
absence value      ≠ no-event path
optional encoding  ≠ Λ handling by itself
timeout syntax     ⇒ Λ-capable path
```

### 3.7 Reserved Keywords

The core reserved keywords are:

```text
frame
enter
leave
with
policy
commit
role
channel
send
recv
spawn
cancel
trap
on
match
```

The full PMSL specification may extend this set.

Recommended additional specification-level keywords include:

```text
module
import
export
fn
let
const
var
type
struct
enum
interface
impl
return
if
else
loop
while
for
break
continue
await
timeout
as
effects
requires
ensures
foreign
pattern
invariant
allow
deny
cap
sandbox
```

A PMSL profile may choose a smaller or larger keyword set, but it must preserve the operator mapping of the constructs it supports.

A profile that omits a keyword does not remove the corresponding operator class from PMSL architecture. It only defines a smaller implementation or tooling surface.

### 3.8 Operators and Punctuation

PMSL uses punctuation for blocks, calls, types, paths, annotations, and generics.

Recommended punctuation:

| Token                | Use                                                                                  |        |               |
| -------------------- | ------------------------------------------------------------------------------------ | ------ | ------------- |
| `{ }`                | block, frame body, policy body, commit body                                          |        |               |
| `( )`                | calls, grouping, parameter lists                                                     |        |               |
| `[ ]`                | indexing, attributes, optional syntax                                                |        |               |
| `< >`                | generic types, channel payload types, comparison where grammar context disambiguates |        |               |
| `:`                  | type annotation                                                                      |        |               |
| `::`                 | module path                                                                          |        |               |
| `.`                  | member access                                                                        |        |               |
| `,`                  | separator                                                                            |        |               |
| `;`                  | optional statement terminator                                                        |        |               |
| `->`                 | return type                                                                          |        |               |
| `=>`                 | match arm                                                                            |        |               |
| `=`                  | binding                                                                              |        |               |
| `==`, `!=`, `<`, `>` | comparison forms                                                                     |        |               |
| `&&`, `              |                                                                                      | `, `!` | logical forms |
| `?`                  | optional propagation profile, if supported                                           |        |               |
| `@`                  | annotation marker, if supported                                                      |        |               |

Operator glyphs may appear in:

```text
operator blocks
effect annotations
type names
comments
diagnostics
IR dumps
documentation
```

Example:

```pmsl
fn write_log(path: Path, data: Bytes)
    -> Result<Unit, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
```

The grammar must disambiguate generic angle brackets from comparison operators through context, tokenization rules, or profile-specific parser rules.

This section does not finalize the complete precedence table.

### 3.9 Operator Annotations

PMSL supports operator annotations where explicitness helps analysis.

Effect annotation:

```pmsl
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
```

Policy annotation:

```pmsl
requires Ψ(P_write)
```

Capability annotation:

```pmsl
requires Ω(fs.write)
```

Frame annotation:

```pmsl
frame F_log
```

Commit annotation:

```pmsl
commit Σ
```

Trap annotation:

```pmsl
trap on Φ_trap<IOError>
```

Operator annotations impose obligations on PMS-IR.

They must not be treated as decorative comments.

```text
operator annotation
⇒ PMS-IR operator tag
⇒ analysis obligation
⇒ runtime/backend preservation obligation
```

For `Χ` annotations, the obligation is explicitly layer-projected:

```text
Χ annotation
⇒ PMSL/PMS-IR boundary, visibility, sandbox, host, module,
   runtime, or reachability obligation
```

This preserves PMS Base Χ as Distance while making the language-level projection analyzable.

### 3.10 Operator Macro Notation

PMSL permits explicit operator macro notation.

Examples:

```pmsl
frame enter F_user {
    run_user_code()
}
```

```pmsl
policy with P_write {
    FS.write(path, data)
}
```

```pmsl
commit Σ {
    FS.write(path, data)
}
```

Each macro expands to an operator word.

Example:

```pmsl
frame enter F_user { body }
```

expands conceptually to:

```text
Δ classify frame
Ω verify frame-entry authority
Χ check projected frame boundary / visibility / reachability constraints
□ enter F_user
body
Σ close required local effects
□ restore parent frame
```

Example:

```pmsl
policy with P_write { body }
```

expands conceptually to:

```text
Ψ activate policy scope
body
Ψ close or restore prior policy scope
```

Example:

```pmsl
commit Σ { body }
```

expands conceptually to:

```text
Δ classify staged effects
Ψ check commit policy
∇ stage or perform effects
Σ integrate visible result
Φ recover/rollback if commit fails
```

Macro expansion is valid only if the expanded operator word is valid.

Α-pattern and macro syntax may reduce source repetition, but it may not hide invalid operator order, untyped effects, missing authority, missing boundary checks, missing absence paths, or missing commit behavior.

### 3.11 High-Level Grammar Overview

A PMSL program consists of modules, imports, declarations, and executable definitions.

```ebnf
Program =
    { ModuleDecl | ImportDecl | Declaration } ;

ModuleDecl =
    "module" ModulePath ;

ImportDecl =
    "import" ModulePath [ "as" Identifier ] ;

Declaration =
      FunctionDecl
    | TypeDecl
    | RoleDecl
    | PolicyDecl
    | FrameDecl
    | ChannelDecl
    | PatternDecl
    | ForeignDecl
    | ModuleBlock ;
```

This grammar is intentionally skeletal. It defines architectural shape, not a parser-complete formal grammar.

A future parser artifact may refine:

```text
precedence
associativity
generic disambiguation
attribute syntax
operator-block variants
macro expansion phases
error recovery
diagnostic spans
formatting rules
```

Such refinements must remain PMSL-conformant by preserving Δ–Ψ lowering obligations.

### 3.12 Modules

Module syntax:

```ebnf
ModuleBlock =
    "module" ModulePath Block ;
```

Example:

```pmsl
module app.log {
    import Std.FS
    import Std.Log

    fn main() -> Unit {
        Log.info("start")
    }
}
```

Module operator reading:

```text
Δ identify module
□ establish module frame
Χ establish projected module boundary
Ω define import/export capability surface
Ψ attach module policy
Σ commit module linkage
```

Modules are refined in Section 8.

The module boundary is a PMSL/PMS-IR projection of PMS Base Χ = Distance. It controls visibility, import reachability, sandboxing, host exposure, and runtime linkage; it does not redefine Χ at base level.

### 3.13 Declarations

#### Function declaration

```ebnf
FunctionDecl =
    "fn" Identifier "(" [ ParamList ] ")"
    [ "->" Type ]
    [ EffectClause ]
    [ RequirementClause ]
    Block ;
```

Example:

```pmsl
fn write_log(path: Path, data: Bytes)
    -> Result<Unit, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
    requires Ω(fs.write)
{
    commit Σ {
        FS.write(path, data)
    }
}
```

#### Type declaration

```ebnf
TypeDecl =
      "type" Identifier [ TypeParams ] "=" Type
    | "struct" Identifier [ TypeParams ] StructBody
    | "enum" Identifier [ TypeParams ] EnumBody ;
```

#### Role declaration

```ebnf
RoleDecl =
    "role" Identifier RoleBody ;
```

Example:

```pmsl
role LogWriter {
    cap fs.write("/var/log/**")
    cap log.append
}
```

#### Policy declaration

```ebnf
PolicyDecl =
    "policy" Identifier PolicyBody ;
```

Example:

```pmsl
policy P_write_tmp {
    allow fs.write where path.starts_with("/tmp/")
    deny  fs.write where path.starts_with("/secure/")
}
```

#### Channel declaration

```ebnf
ChannelDecl =
    "channel" Identifier ":" "channel" "<" Type ">" ;
```

Example:

```pmsl
channel events: channel<Event>
```

#### Foreign declaration

```ebnf
ForeignDecl =
    "foreign" "fn" Identifier "(" [ ParamList ] ")"
    [ "->" Type ]
    [ EffectClause ]
    [ RequirementClause ] ;
```

FFI is refined in Section 9.

All declarations must preserve enough source-span, type, effect, role, policy, frame, boundary, absence, exception, and commit metadata to lower into PMS-IR.

### 3.14 Blocks

A block is a □-structured scope.

```ebnf
Block =
    "{" { Statement } "}" ;
```

Example:

```pmsl
{
    let x = 1
    let y = x + 1
    return y
}
```

Block reading:

```text
□ establish lexical frame
Θ order statements
Σ integrate local result if needed
□ restore parent context
```

Not every block is a security boundary. Some blocks are lexical frames only.

Sandboxes, module boundaries, policy scopes, foreign frames, runtime frames, and host transitions add stronger Χ/Ω/Ψ meaning.

The grammar must preserve this distinction:

```text
lexical block      → □
protected frame    → □ + Ω + Χ projection + Ψ
policy scope       → □ + Ψ
foreign frame      → □ + Ω + Χ projection + Φ + Ψ
commit block       → □ + Σ + Ψ
```

### 3.15 Statements

```ebnf
Statement =
      LetStmt
    | AssignStmt
    | ExprStmt
    | ReturnStmt
    | IfStmt
    | MatchStmt
    | LoopStmt
    | FrameStmt
    | PolicyStmt
    | CommitStmt
    | SendStmt
    | RecvStmt
    | SpawnStmt
    | CancelStmt
    | TrapStmt
    | AwaitStmt ;
```

#### Binding

```ebnf
LetStmt =
    ( "let" | "const" | "var" ) Identifier [ ":" Type ] "=" Expr ;
```

Operator reading:

```text
Δ distinguish binding
∇ evaluate initializer
Σ bind value into current frame
```

#### Assignment

```ebnf
AssignStmt =
    PlaceExpr "=" Expr ;
```

Operator reading:

```text
Δ distinguish target
Ω check mutation authority if protected
∇ mutate target
Σ commit local state if required
```

#### Return

```ebnf
ReturnStmt =
    "return" [ Expr ] ;
```

Operator reading:

```text
Σ integrate function result
Φ recontextualize to caller continuation
```

#### Frame statement

```ebnf
FrameStmt =
    "frame" "enter" Identifier Block ;
```

#### Policy statement

```ebnf
PolicyStmt =
    "policy" "with" Identifier Block ;
```

#### Commit statement

```ebnf
CommitStmt =
    "commit" [ "Σ" | "SIGMA" ] Block ;
```

#### Trap statement

```ebnf
TrapStmt =
    "trap" "on" Type [ "as" Identifier ] Block ;
```

Statements may have implicit operator effects, but PMS-IR lowering must make those effects inspectable.

### 3.16 Expressions

```ebnf
Expr =
      Literal
    | Identifier
    | CallExpr
    | MemberExpr
    | BinaryExpr
    | UnaryExpr
    | MatchExpr
    | IfExpr
    | BlockExpr
    | AwaitExpr
    | RecvExpr ;
```

Expression evaluation is Θ-ordered and Δ-classified.

```text
Δ classify operands and operation
Θ order evaluation
∇ compute result where evaluation has action content
Σ bind or return result if required
```

Pure expressions may not carry external ∇ effects.

Effectful expressions must expose their effect class through type/effect inference, annotations, declaration effects, or PMS-IR lowering.

A source-level expression that performs IO, mutation, foreign execution, message delivery, policy installation, or boundary crossing is not pure merely because it appears in expression position.

### 3.17 Types

```ebnf
Type =
      TypeName
    | GenericType
    | FunctionType
    | ResultType
    | ChannelType
    | FrameType
    | RoleType
    | PolicyType
    | EffectType
    | TrapType
    | CommitType ;
```

Examples:

```pmsl
Path
Bytes
Unit
Result<Unit, Φ_trap<IOError>>
channel<Message>
Frame<F_user>
Role<LogWriter>
Policy<P_write>
Effect<Σ>
Σ_tx<FileWrite>
```

PMSL type syntax is operator-aware.

Type families may include:

```text
Δ_type<T>
Φ_trap<E>
Σ_tx<T>
Ω_cap<C>
Χ_boundary<B>
Ψ_policy<P>
Λ_absent<T>
```

`Χ_boundary<B>` names a PMSL/PMS-IR boundary type family. It is a layer-level projection of PMS Base Χ = Distance into a typed boundary obligation.

Type families are refined in Section 5.

### 3.18 Effect Clauses

Functions, foreign calls, patterns, and modules may declare effects.

```ebnf
EffectClause =
    "effects" "(" OperatorList ")" ;
```

Example:

```pmsl
fn recv_event(ch: channel<Event>)
    -> Result<Event, Λ_absent<Event>>
    effects(Δ, Ω, Χ, Θ, Λ, ∇, Σ, Φ, Ψ)
```

Effect clauses define what operator classes a declaration may perform.

The compiler may infer effects, but explicit effect clauses are useful for APIs, verification, FFI, and module boundaries.

Effect declarations must be interpreted as obligations, not decoration.

```text
effects(Δ, Ω, Χ, Θ, Λ, ∇, Σ, Φ, Ψ)
⇒ PMS-IR effect metadata
⇒ static analysis obligations
⇒ runtime/backend preservation obligations
```

### 3.19 Requirement Clauses

Declarations may require roles, capabilities, policies, frames, or boundaries.

```ebnf
RequirementClause =
    "requires" Requirement { "," Requirement } ;
```

Examples:

```pmsl
requires Ω(fs.write)
requires Ψ(P_write_tmp)
requires Χ(namespace.tmp)
requires Frame<F_log>
```

Requirement clauses lower into PMS-IR preconditions.

```text
Requirement
→ pre-execution check
→ static obligation where decidable
→ runtime obligation where dynamic
```

`requires Χ(namespace.tmp)` denotes a PMSL/PMS-IR boundary or visibility requirement under the layer projection of Χ. It does not redefine PMS Base Χ.

### 3.20 Channels and IPC Syntax

PMSL includes channel syntax because IPC is a central language/runtime boundary.

Channel declaration:

```pmsl
channel inbox: channel<Message>
```

Send:

```pmsl
send inbox <- msg
```

Receive:

```pmsl
let msg = recv inbox timeout 50ms
```

Receive with absence handler:

```pmsl
recv inbox timeout 50ms on timeout {
    handle_absence()
}
```

Operator reading:

```text
send:
    Δ classify channel and message
    Ω verify send capability
    Χ verify projected endpoint visibility
    Ψ check channel policy
    ∇ enqueue/deliver
    Θ order delivery
    Σ commit delivery state

recv:
    Δ classify channel
    Ω verify receive capability
    Χ verify projected endpoint visibility
    Θ wait/order receive interval
    Λ if message absent before deadline
    ∇ dequeue if present
    Φ recontextualize into handler if needed
    Σ commit receive state
```

Concurrency and IPC are refined in Section 6 and Section 12.

### 3.21 Task Syntax

Task syntax expresses structured concurrency.

```pmsl
spawn task Worker {
    process_messages(inbox)
}
```

Await:

```pmsl
await Worker
```

Cancel:

```pmsl
cancel Worker
```

Operator reading:

```text
spawn:
    Δ classify task
    Ω verify spawn authority
    □ create task frame
    Χ establish projected task boundary
    Ψ attach task policy
    Θ schedule task
    Σ commit creation

await:
    Θ wait for completion
    Λ if not complete within selected mode
    Σ integrate result if completed

cancel:
    Φ recontextualize task lifecycle
    Ψ check cancellation policy
    Σ commit closure
```

A task boundary may be lexical, runtime-local, sandboxed, host-backed, or future PMS-OS-backed depending on the implementation profile. The grammar preserves the boundary obligation; the runtime profile determines how it is enforced.

### 3.22 Frame, Policy, and Commit Blocks

PMSL has three high-value block forms.

#### Frame block

```pmsl
frame enter F {
    body
}
```

Primary meaning:

```text
□ context switch
```

with Δ/Ω/Χ/Ψ obligations depending on frame type.

#### Policy block

```pmsl
policy with P {
    body
}
```

Primary meaning:

```text
Ψ policy activation
```

#### Commit block

```pmsl
commit Σ {
    body
}
```

Primary meaning:

```text
Σ integration / visibility / transaction closure
```

These blocks may be nested:

```pmsl
policy with P_write {
    frame enter F_log {
        commit Σ {
            FS.write(path, data)
        }
    }
}
```

Nested reading:

```text
Ψ activate policy
□ enter frame
∇ perform effect
Σ commit effect
□ leave frame
Ψ close policy
```

If the frame is protected, sandboxed, foreign, or module-scoped, the expanded reading must include Ω and Χ-projected obligations.

### 3.23 Match and Branch Syntax

`match` is Δ-dominant.

```pmsl
match msg.kind {
    "open"  => handle_open(msg)
    "close" => handle_close(msg)
    _       => handle_unknown(msg)
}
```

Operator reading:

```text
Δ classify discriminant
Θ select branch
∇ execute branch if effectful
Σ integrate branch result
```

`if` is also Δ-dominant:

```pmsl
if allowed {
    commit Σ { run() }
} else {
    deny()
}
```

Branching must preserve type, effect, absence, trap, and commit obligations across all paths.

A branch that commits in one arm and leaves effects uncommitted in another must be rejected or explicitly typed as profile-dependent behavior.

### 3.24 Pattern Syntax

Patterns are Α-dominant reusable structures.

```pmsl
pattern retry<N>(op) {
    loop until success or attempts == N {
        op()
    }
}
```

Pattern expansion must produce valid operator words.

```text
Α pattern
→ expansion
→ PMS-IR sequence
→ dependency validation
→ type/effect validation
```

Patterns are allowed to abstract common structures. They are not allowed to hide invalid operator order.

A pattern definition is therefore valid only if:

```text
expanded operator word is valid
∧ type obligations are preserved
∧ effect obligations are preserved
∧ role/capability obligations are preserved
∧ boundary obligations are preserved
∧ absence paths are represented where applicable
∧ commit behavior is explicit where required
```

### 3.25 Foreign Syntax

Foreign declarations enter a host or non-PMS frame.

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Φ_trap<HostError>>
    effects(□, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.read)
```

Foreign calls require explicit boundary semantics.

```text
Δ identify symbol
Ω verify foreign-call authority
Χ establish projected host boundary
Φ reframe ABI
∇ execute call
Σ integrate result
Φ map foreign error
Ψ enforce FFI policy
```

FFI is refined in Section 9.

No foreign call is semantically invisible. Foreign execution is a controlled boundary operation under PMSL/PMS-IR layer projection of Χ.

### 3.26 Grammar Hooks for PMS-IR

Every grammar form must expose PMS-IR hooks.

At minimum, each lowered IR node should preserve:

```text
source span
operator tag
syntactic construct
type
effect class
frame context
role/capability requirement
policy context
boundary context
commit behavior
absence behavior
exception behavior
profile origin
```

Example source:

```pmsl
commit Σ {
    FS.write(path, data)
}
```

PMS-IR outline:

```text
IRNode {
    op: Σ
    construct: CommitBlock
    children: [
        IRNode {
            op: ∇
            construct: CallExpr(FS.write)
            effects: [Δ, Ω, Χ, Ψ, ∇, Σ, Φ]
        }
    ]
}
```

This preserves source-level readability and machine-level analyzability.

Validation of this lowered form means acceptance or rejection under a declared grammar, IR, model, runtime, backend, tool, or conformance profile. It does not mean PMS Base validation.

### 3.27 Ambiguity and Normalization

PMSL syntax may permit surface variation.

Examples:

```pmsl
commit Σ { body }
commit SIGMA { body }
```

```pmsl
frame enter F { body }
with frame F { body }
```

A profile may normalize these forms into one PMS-IR representation.

Normalization must preserve:

```text
operator class
source span
diagnostic origin
effect obligations
policy obligations
boundary obligations
commit obligations
absence obligations
trap obligations
```

Normalization must not silently rewrite a protected operation into an unprotected one.

Normalization must not silently remove:

```text
Ω authority checks
Χ-projected boundary checks
Ψ policy checks
Σ commit boundaries
Λ absence paths
Φ trap/recontextualization paths
```

AI-proposed syntax or PMS-IR-like output follows the same rule. It may be normalized only by host tooling under a declared profile, and only after parsing, canonicalization, mapping, and validation.

### 3.28 Minimal PMSL Program

A minimal PMSL fragment:

```pmsl
module hello.frame

fn main() -> Unit {
    frame enter F_user {
        commit Σ {
            Log.info("hello frame")
        }
    }
}
```

Operator reading:

```text
Δ identify module
□ establish module frame
Δ identify function main
□ enter function frame
Δ classify F_user
Ω verify frame entry if required
Χ check projected frame boundary if required
□ enter F_user
Δ classify Log.info
Ω check log capability if required
∇ emit log event
Σ commit log effect
□ leave F_user
Σ return Unit
```

This example illustrates grammar-to-operator readability. It does not assert that this exact source fragment already executes unchanged in a completed PMSL compiler.

A PMS-RUST-style executable slice may represent related operator behavior through opcode programs, builder buffers, model validation, deterministic kernel execution, and JSONL traces. That strengthens implementation-artifact claims; it does not complete PMSL or validate PMS Base.

### 3.29 Grammar-Level Invariants

PMSL grammar must preserve the following invariants.

```text
I1: every source file has a module or implementation-defined root frame
I2: every declaration has a distinguishable name or explicit anonymous scope
I3: every block establishes a syntactic frame
I4: every operator-explicit construct lowers to a matching PMS-IR operator tag
I5: implicit constructs lower to defined operator classes
I6: reserved keywords are not ordinary identifiers
I7: effectful constructs expose effect information to PMS-IR
I8: protected constructs expose Ω requirements
I9: policy scopes expose Ψ requirements
I10: frame and sandbox constructs expose □/Χ-projected requirements
I11: commit blocks expose Σ boundaries
I12: absence-capable constructs expose Λ paths
I13: trap-capable constructs expose Φ paths
I14: pattern constructs expand to valid operator words
I15: source spans are preserved for diagnostics and trace mapping
I16: foreign declarations expose host-boundary and ABI-reframing obligations
I17: ASCII operator fallbacks normalize to canonical operator identities
I18: AI-proposed grammar artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level constraints.

They are not evidence that a complete parser or compiler already exists.

### 3.30 Grammar Consequence

The consequence of PMSL grammar design is:

```text
PMSL source is a human-readable syntax for operator-typed programs:
ordinary constructs and explicit Δ–Ψ annotations both lower into
operator-preserving PMS-IR, allowing source programs to remain readable
while preserving the structural commitments required by PMS-STACK.
```

This prepares Section 4, which defines the core constructs and their operator mappings in detail.

### 3.31 Grammar Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL lexical and grammar overview specifies how source text,
operator glyphs, ASCII fallbacks, declarations, statements, expressions,
types, effects, requirements, channels, tasks, FFI declarations, macros,
and blocks preserve Δ–Ψ obligations through PMS-IR lowering.

This is a language grammar / syntax architecture claim.

It does not claim a completed parser, completed compiler, completed
standard library, completed macro expander, completed formatter,
completed language server, or completed PMSL implementation.

It does not validate PMS Base.
```

---

## 4. Core Constructs and Operator Mapping

PMSL core constructs are defined by their operator role.

A PMSL construct is not valid merely because it parses. It is valid when it lowers into a PMS-IR form whose Δ–Ψ obligations are explicit: what is distinguished, what is mutated, which frame is active, which absence path exists, which pattern is expanded, which role authorizes the action, which order is imposed, which exception recontextualizes control, which boundary projection is crossed, which commit closes the effect, and which policy constrains the transition.

The central construct-mapping claim is:

```text
PMSL core constructs are language-level projections of Δ–Ψ. Each construct
has a primary operator role, secondary operator obligations, and a PMS-IR
lowering form that preserves those obligations for analysis, runtime,
tooling, simulation, and verification under declared profiles.
```

This section defines the mapping from PMSL source constructs to operator-typed PMS-IR. Later sections refine type system, concurrency, errors, modules, FFI, runtime, standard library, verification, observability, simulation, and examples.

Claim type:

```text
LANGUAGE CONSTRUCT / OPERATOR-MAPPING ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies how PMSL source constructs map to operator-typed
PMS-IR.

It does not claim a completed compiler, completed lowering implementation,
completed runtime, completed standard library, completed verifier, or
completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

### 4.1 Construct Mapping Rule

Every PMSL construct has the following semantic shape:

```text
PMSLConstruct = (
    syntax,
    primary_operator,
    secondary_operators,
    static_obligations,
    runtime_obligations,
    lowering_pattern,
    failure_paths
)
```

where:

| Field                 | Meaning                                  |
| --------------------- | ---------------------------------------- |
| `syntax`              | source-level form                        |
| `primary_operator`    | dominant Δ–Ψ role                        |
| `secondary_operators` | additional required operators            |
| `static_obligations`  | parser/type/effect/analysis obligations  |
| `runtime_obligations` | checks or behavior required at execution |
| `lowering_pattern`    | PMS-IR shape                             |
| `failure_paths`       | Λ, Φ, Ψ, or Σ failure behavior           |

A construct may be syntactically compact while lowering into a richer operator word.

Example:

```pmsl
FS.write(path, data)
```

is not just a function call. Its operator reading includes:

```text
Δ classify symbol, path, operation, and data
Ω verify write authority
Χ verify projected namespace or boundary visibility
Ψ check filesystem and runtime policy
∇ perform or stage write effect
Σ commit, stage, or return effect state
Φ handle IO, permission, or policy fault
Λ represent absence/no-target/no-resource where applicable
```

The source form may be short. The PMS-IR must keep the operator structure visible.

Validation of a lowered construct means acceptance or rejection under a declared grammar, IR, model, runtime, backend, tool, conformance, or verification profile.

It does not mean PMS Base validation.

### 4.2 Global Operator Mapping

The global PMSL mapping is:

| Operator | PMSL role                                                                                                                          |
| -------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| Δ        | type distinction, symbol resolution, pattern match, branch, discriminant                                                           |
| ∇        | statement execution, mutation, assignment, call effect, IO effect                                                                  |
| □        | lexical scope, function frame, module frame, runtime context, task frame                                                           |
| Λ        | timeout, no-event, missing value, empty receive, optional absence                                                                  |
| Α        | macro, loop, reusable pattern, protocol pattern, library pattern                                                                   |
| Ω        | role, capability, authority, access requirement                                                                                    |
| Θ        | sequencing, await, scheduling relation, evaluation order                                                                           |
| Φ        | exception, trap, handler, migration, fallback, ABI recontextualization                                                             |
| Χ        | PMS Base Distance projected as module boundary, sandbox boundary, visibility boundary, reachability control, host/runtime boundary |
| Σ        | return, commit block, transaction closure, integration point                                                                       |
| Ψ        | policy, invariant, effect guard, contract, conformance condition                                                                   |

Version boundary:

```text
PMS Base 1.3 Χ = Distance.

At PMSL/PMS-IR level, Χ is projected as module boundary, sandbox,
visibility boundary, reachability control, foreign-frame boundary,
host/runtime boundary, and boundary-crossing effect discipline.
```

PMSL must not silently redefine the base operator. It uses a language-layer projection of it.

### 4.3 Construct Summary Table

| PMSL construct         | Primary operator | Secondary operators            | Core meaning                                                                      |
| ---------------------- | ---------------- | ------------------------------ | --------------------------------------------------------------------------------- |
| `let`, `const`, `var`  | Δ                | ∇, Σ                           | distinguish binding, evaluate value, bind into frame                              |
| assignment             | ∇                | Δ, Ω, Χ projection, Σ, Ψ       | mutate a place under authority, boundary visibility, and policy                   |
| expression             | Δ / ∇            | Θ, Σ                           | classify operands, evaluate, return value                                         |
| block                  | □                | Θ, Σ                           | establish lexical frame and ordered body                                          |
| function               | □                | Δ, Ω, Σ, Φ, Ψ                  | callable frame with signature, authority, contract, return                        |
| call                   | ∇                | Δ, Ω, □, Θ, Φ, Σ, Ψ            | invoke callable effect or computation                                             |
| `if`                   | Δ                | Θ, Σ                           | distinguish condition and select path                                             |
| `match`                | Δ                | Θ, Σ, Λ / Φ                    | classify discriminant and select arm; expose non-exhaustive path where applicable |
| loop                   | Α                | Θ, Δ, Λ, Φ, Σ, Ψ               | recurring pattern with exit/absence/failure paths                                 |
| `frame enter`          | □                | Δ, Ω, Χ projection, Ψ, Σ       | enter a typed context                                                             |
| `policy with`          | Ψ                | Ω, □, Σ                        | activate policy scope                                                             |
| `role` declaration     | Ω                | Δ, Ψ, Σ                        | define authority surface                                                          |
| capability declaration | Ω                | Δ, Ψ, Σ                        | define permitted relation                                                         |
| `channel<T>`           | □ / Δ            | Ω, Χ projection, Θ, Λ, Σ, Φ, Ψ | typed communication endpoint                                                      |
| `send`                 | ∇                | Δ, Ω, Χ projection, Θ, Σ, Ψ    | deliver/enqueue message                                                           |
| `recv`                 | Λ / ∇            | Δ, Ω, Χ projection, Θ, Φ, Σ, Ψ | receive or expose absence path                                                    |
| `spawn`                | □ / Θ            | Δ, Ω, Χ projection, Ψ, Σ       | create task frame and schedule it                                                 |
| `await`                | Θ                | Λ, Φ, Σ                        | wait for ordered completion                                                       |
| `cancel`               | Φ                | Ω, Ψ, Σ                        | recontextualize task lifecycle                                                    |
| `trap on`              | Φ                | Δ, □, Ω, Ψ, Σ                  | install or enter handler frame                                                    |
| `commit Σ`             | Σ                | Δ, ∇, Ψ, Φ, Λ                  | integrate staged effects                                                          |
| module                 | □                | Δ, Ω, Χ projection, Ψ, Σ       | symbol frame and boundary                                                         |
| import/export          | Δ / Σ            | Ω, Χ projection, Ψ             | resolve and commit linkage                                                        |
| FFI call               | Φ / □            | Δ, Ω, Χ projection, ∇, Σ, Ψ    | enter foreign context and integrate result                                        |
| pattern                | Α                | Δ, Θ, Ψ, Σ                     | reusable operator-valid expansion                                                 |

This table is architectural. Later sections refine each row.

### 4.4 Bindings

Bindings introduce names into a frame.

Syntax:

```pmsl
let x = expr
const y: Int = 1
var z: Bytes = read()
```

Primary operator:

```text
Δ
```

because the binding distinguishes a symbol in the current lexical frame.

Lowering:

```text
Δ distinguish binding name
Δ classify declared or inferred type
∇ evaluate initializer if effectful
Σ bind value into current frame
Ψ check binding policy if constrained
```

PMS-IR sketch:

```text
IR.Binding {
    op: Δ,
    name: x,
    type: inferred_or_declared,
    init: IR.Expr,
    commit: Σ_local_bind
}
```

Binding invariants:

```text
I1: binding name is distinguishable in the active frame
I2: initializer type is compatible with binding type
I3: mutable binding requires mutation policy
I4: captured binding obeys frame and boundary-projection rules
I5: binding becomes visible only after local Σ binding commit
```

A binding is not merely an assignment. It is a distinction plus integration into a frame.

### 4.5 Assignment and Mutation

Assignment mutates an existing place.

Syntax:

```pmsl
x = x + 1
buffer[i] = value
state.count = state.count + 1
```

Primary operator:

```text
∇
```

Lowering:

```text
Δ distinguish target place
Δ classify value expression
Ω verify mutation authority if target is protected
Χ verify projected boundary visibility if target crosses frame, module, sandbox, runtime, or host boundary
Ψ check mutation policy
∇ mutate target
Σ commit local mutation
Φ handle invalid target, policy denial, or trap
```

PMS-IR sketch:

```text
IR.Assign {
    op: ∇,
    target,
    value,
    authority: Ω?,
    boundary: Χ_projection?,
    policy: Ψ?,
    commit: Σ
}
```

Assignment is invalid when:

```text
target not distinguishable
target immutable
capability missing
boundary projection denies visibility
policy denies mutation
commit state cannot be established
```

Assignment may be syntactically local but semantically protected. PMS-IR lowering must preserve the distinction.

### 4.6 Expressions

Expressions produce values.

Syntax examples:

```pmsl
1 + 2
path.starts_with("/tmp/")
msg.kind
read_optional()
```

Primary operator depends on expression class:

```text
literal / name / member   → Δ
pure computation          → ∇ with pure effect class
call expression           → ∇ plus call obligations
match expression          → Δ / Θ
await expression          → Θ / Λ / Σ
```

Generic expression lowering:

```text
Δ classify expression kind
Δ classify operands
Θ order subexpression evaluation
∇ compute value if computation is active
Σ return value to enclosing expression or frame
Φ propagate trap if expression is trap-capable
Λ propagate absence if expression is absence-capable
```

Pure expressions may be effect-free at external state level, but they still require Δ classification and Θ evaluation order.

Effectful expressions must expose their effects.

A source-level expression that performs IO, mutation, foreign execution, message delivery, policy installation, boundary crossing, or runtime service interaction is not pure merely because it appears in expression position.

### 4.7 Blocks

Blocks create lexical frames.

Syntax:

```pmsl
{
    let x = 1
    let y = x + 1
    return y
}
```

Primary operator:

```text
□
```

Lowering:

```text
□ establish lexical frame
Θ order statements
execute body
Σ integrate block result if expression-valued
□ restore parent frame
```

PMS-IR sketch:

```text
IR.Block {
    op: □,
    frame_kind: lexical,
    statements: [...],
    result: optional,
    exit: restore_parent
}
```

Block invariants:

```text
I1: local bindings are visible inside the block
I2: local bindings do not leak unless explicitly returned or captured
I3: statement order is Θ-defined
I4: block exit restores parent frame
I5: uncommitted effects must be closed, staged, propagated, or rejected
```

Not every block is an isolation boundary. A normal lexical block is □. A sandbox, module, foreign context, task, protected frame, or host transition adds Χ projection, Ω, and Ψ obligations.

The distinction is architectural:

```text
lexical block      → □
protected frame    → □ + Ω + Χ projection + Ψ
policy scope       → □ + Ψ
foreign frame      → □ + Ω + Χ projection + Φ + Ψ
commit block       → □ + Σ + Ψ
```

### 4.8 Functions

A function is a callable frame with typed entry and exit.

Syntax:

```pmsl
fn write_log(path: Path, data: Bytes)
    -> Result<Unit, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
{
    commit Σ {
        FS.write(path, data)
    }
}
```

Primary operator:

```text
□
```

because a function body is an execution frame.

Secondary operators:

```text
Δ signature, name, parameters, return type
Ω required role/capabilities
Θ ordered body execution
Φ trap/return continuation
Σ return integration
Ψ function contract/effect policy
Χ projection where module, sandbox, runtime, or host boundary is crossed
```

Function declaration lowering:

```text
Δ distinguish function name
Δ classify parameter and return types
□ define callable frame
Ω attach required capabilities if declared
Ψ attach effects/contracts/policies
Σ commit function into module symbol table
```

Function call lowering:

```text
Δ resolve function symbol
Δ classify arguments
Ω verify call authority if protected
Ψ check call/effect policy
□ enter function frame
Θ order argument binding and body
∇ execute body effects
Σ integrate return value
Φ return to caller continuation
```

A function is valid when its declared effects cover its body effects.

A function that crosses module, task, runtime, sandbox, or host boundaries must also expose Χ-projected boundary obligations.

### 4.9 Calls

Calls invoke functions, methods, runtime services, standard-library APIs, or FFI stubs.

Syntax:

```pmsl
Log.info("start")
FS.write(path, data)
process(msg)
```

Primary operator:

```text
∇
```

because call execution is an action, though pure calls may have restricted effect classes.

Lowering:

```text
Δ resolve callee
Δ classify argument list
Ω check call capability if required
Χ check projected module/runtime/host boundary if relevant
Ψ check callee policy and effect policy
□ enter call frame if function-like
Θ order argument evaluation and call
∇ execute callee behavior
Σ integrate return value or effect state
Φ handle trap
Λ handle no-result/no-event where declared
```

Call invariants:

```text
I1: callee is distinguishable
I2: argument types match parameter types
I3: required capabilities are present
I4: effects are permitted in the current frame
I5: boundary projection permits the call where relevant
I6: trap and absence paths are declared or handled
I7: returned value is integrated through Σ
```

A call construct is not PMSL-conformant if it hides authority, boundary, policy, absence, trap, or commit behavior from PMS-IR.

### 4.10 Conditional Branches

`if` is Δ-dominant.

Syntax:

```pmsl
if allowed {
    run()
} else {
    deny()
}
```

Lowering:

```text
Δ classify condition
Θ select branch
execute selected branch
Σ integrate branch result if expression-valued
Ψ check branch policy if constrained
```

PMS-IR sketch:

```text
IR.If {
    op: Δ,
    condition,
    then_branch,
    else_branch,
    merge: Σ?
}
```

Branch invariants:

```text
I1: condition is distinguishable as boolean or policy-compatible predicate
I2: both branches satisfy type constraints
I3: effect differences are reflected in inferred effect type
I4: commit obligations are closed on all reachable paths
I5: trap and absence paths remain visible
```

A conditional may be syntactically simple but semantically effectful. The PMS-IR merge point must retain type, effect, policy, trap, absence, and commit information.

### 4.11 Pattern Matching

`match` is a structured distinction.

Syntax:

```pmsl
match msg.kind {
    "open"  => handle_open(msg)
    "close" => handle_close(msg)
    _       => handle_unknown(msg)
}
```

Primary operator:

```text
Δ
```

Lowering:

```text
Δ classify discriminant
Δ distinguish matching arm
Θ select branch according to match order or pattern specificity
execute selected arm
Σ integrate result if expression-valued
Ψ enforce exhaustiveness or policy if required
```

PMS-IR sketch:

```text
IR.Match {
    op: Δ,
    discriminant,
    arms: [
        { pattern, body },
        ...
    ],
    default,
    merge: Σ?
}
```

Match invariants:

```text
I1: discriminant type is known
I2: each pattern is valid for the discriminant type
I3: arm selection is deterministic unless profile defines otherwise
I4: non-exhaustive matches expose Λ or Φ path
I5: all result-producing arms integrate compatible values
```

A non-exhaustive match may be valid only if absence or failure is explicit.

A match over policy, authority, boundary, or FFI result types must preserve the associated Ψ, Ω, Χ-projected, and Φ obligations.

### 4.12 Loops and Recurring Patterns

Loops are Α-dominant because they define reusable recurrence.

Syntax:

```pmsl
loop {
    step()
}
```

```pmsl
while condition {
    step()
}
```

```pmsl
for item in items {
    process(item)
}
```

Primary operator:

```text
Α
```

Secondary operators:

```text
Δ condition/item distinction
Θ iteration order
Λ termination or no-next-item
∇ body effects
Σ loop result or final state
Ψ loop invariant/policy
Φ break/continue/trap
```

Generic lowering:

```text
Α establish loop pattern
Θ begin iteration order
Δ classify condition or next item
Λ exit if no further iteration / condition false
∇ execute body
Σ commit iteration-local effects if required
Θ advance next iteration
Φ handle break, continue, trap, cancellation
```

Loop invariants:

```text
I1: loop pattern expands to valid operator words
I2: iteration order is Θ-defined
I3: termination or non-termination profile is explicit
I4: loop-carried effects are visible to analysis
I5: break/continue/trap paths are Φ-visible
I6: loop invariants are Ψ-checkable where declared
```

Loops are recurring operator patterns, not opaque control-flow cycles. A loop that mutates state, performs IO, crosses a boundary, or commits effects must expose those obligations.

### 4.13 Patterns

Patterns are explicit Α constructs.

Syntax:

```pmsl
pattern retry<N>(op) {
    loop until success or attempts == N {
        op()
    }
}
```

Primary operator:

```text
Α
```

Lowering:

```text
Α define reusable operator pattern
Δ classify pattern parameters
Ψ check pattern constraints
expand into PMS-IR template
validate expanded operator word
Σ commit instantiated pattern where used
```

Pattern invariants:

```text
I1: pattern expansion is operator-valid
I2: pattern parameters are typed
I3: pattern does not hide protected effects
I4: pattern exposes absence, trap, and commit behavior
I5: policy constraints are preserved after expansion
```

Patterns are not textual macros without semantics. They are reusable operator structures.

A pattern may abstract a recurring PMSL idiom, but it may not convert invalid order, missing authority, missing boundary projection, missing policy, missing absence path, or missing commit behavior into an apparently valid construct.

### 4.14 Frame Entry

Frame entry establishes a context.

Syntax:

```pmsl
frame enter F_user {
    body
}
```

Primary operator:

```text
□
```

Lowering:

```text
Δ classify target frame
Ω verify frame-entry authority
Χ check projected boundary and visibility obligations
Ψ check frame policy
□ enter frame
execute body
Σ close required local effects
□ restore parent frame
Φ handle invalid frame or trap if needed
```

PMS-IR sketch:

```text
IR.FrameEnter {
    op: □,
    frame: F_user,
    authority: Ω?,
    boundary: Χ_projection?,
    policy: Ψ?,
    body,
    exit: restore_parent
}
```

Frame-entry invariants:

```text
I1: target frame is distinguishable
I2: caller may enter the frame
I3: projected boundary relation permits entry
I4: frame policy is active during body execution
I5: frame exit restores parent context
I6: effects that cannot leave the frame are closed or rejected
```

Frame entry is a language-level projection of □ with possible Ω, Χ, and Ψ obligations.

It is not a redefinition of PMS Base Χ. Where Χ appears, it marks the PMSL/PMS-IR projection of Distance into boundary, visibility, sandbox, runtime, or reachability discipline.

### 4.15 Policy Scope

Policy scopes activate Ψ constraints.

Syntax:

```pmsl
policy with P_write {
    FS.write(path, data)
}
```

Primary operator:

```text
Ψ
```

Lowering:

```text
Δ identify policy
Ω verify policy activation authority if required
Ψ activate policy scope
execute body under policy
Σ commit policy-scoped effects where required
Ψ close or restore previous policy scope
```

Policy-scope invariants:

```text
I1: policy is distinguishable
I2: policy activation is permitted
I3: body effects are checked against active policy
I4: policy scope is restored on normal and exceptional exit
I5: policy denial has defined Ψ/Φ/Λ response
```

Policy scopes may constrain:

```text
effects
resources
frames
roles
channels
FFI
standard-library calls
commit behavior
exception recovery
```

Policy activation is not external governance authority. It is a PMSL/PMS-IR program constraint under Ψ.

### 4.16 Roles and Capabilities

Roles and capabilities define Ω structures.

Syntax:

```pmsl
role LogWriter {
    cap fs.write("/var/log/**")
    cap log.append
}
```

Primary operator:

```text
Ω
```

Declaration lowering:

```text
Δ distinguish role name
Δ distinguish capability names and scopes
Ω define role/capability relation
Ψ check role policy
Σ commit role into module or runtime policy table
```

Use lowering:

```text
Δ classify protected operation
Ω verify active role/capability
Ψ check capability policy
continue protected operation
```

Capability invariants:

```text
I1: capability names are distinguishable
I2: capability scope is explicit
I3: authority is checked before protected action
I4: capability transfer is explicit if allowed
I5: local roles cannot weaken enclosing policy
```

Capabilities may gate filesystem operations, IPC endpoints, module imports, FFI calls, runtime services, task operations, policy installation, and boundary crossings.

### 4.17 Commit Blocks

Commit blocks make integration explicit.

Syntax:

```pmsl
commit Σ {
    FS.write(path, data)
    Log.info("written")
}
```

Primary operator:

```text
Σ
```

Lowering:

```text
Δ classify enclosed effects
Ψ check commit policy
∇ stage or perform effects
Σ integrate visible result
Φ rollback/recover if commit fails
Λ no-resource/no-target path where applicable
```

PMS-IR sketch:

```text
IR.Commit {
    op: Σ,
    effects: [...],
    policy: Ψ?,
    rollback: Φ?,
    absence: Λ?,
    result
}
```

Commit invariants:

```text
I1: every committed effect is distinguishable
I2: every protected effect is authorized
I3: commit policy permits integration
I4: visibility and durability claims match backend semantics
I5: failure path is explicit
I6: post-commit state satisfies declared invariants
```

PMSL distinguishes:

```text
effect executed
effect staged
effect committed
effect visible
effect durable
effect rolled back
```

A construct that erases these distinctions is not PMSL-conformant.

Backend-specific durability is profile-bound. A PMSL commit specifies integration semantics under a declared runtime/backend profile; it does not by itself prove physical durability or implementation correctness.

### 4.18 Absence Constructs

Absence is Λ, not untyped failure.

Syntax examples:

```pmsl
let msg = recv inbox timeout 50ms
```

```pmsl
recv inbox timeout 50ms on timeout {
    handle_absence()
}
```

```pmsl
let x: Option<Int> = none
```

Primary operator:

```text
Λ
```

Lowering:

```text
Δ classify expected event/value
Θ order wait or evaluation interval
Λ represent non-event if expected value/event does not occur
Φ enter absence handler if defined as handler
Σ integrate absence result if expression-valued
Ψ enforce timeout/no-event policy
```

Absence invariants:

```text
I1: expected event or value is distinguishable
I2: absence is typed
I3: timeout/order behavior is Θ-defined where temporal
I4: absence path is handled or declared
I5: absence is not silently collapsed into exception
```

Examples of Λ in PMSL:

```text
empty channel
timeout
missing optional value
not-yet-ready future
file not found as expected case
no matching event
no route
```

PMSL must preserve the difference between:

```text
Λ absence / no-event
Φ exception / trap
Ψ policy denial
Σ commit failure
```

### 4.19 Trap and Exception Constructs

Trap handling is Φ-dominant.

Syntax:

```pmsl
trap on Φ_trap<IOError> as e {
    recover(e)
}
```

Primary operator:

```text
Φ
```

Lowering:

```text
Δ classify trap type
□ establish handler frame
Ω verify handler authority if protected
Ψ check recovery policy
Φ enter handler context
∇ execute handler body
Σ commit recovery result or propagation
Φ return, propagate, abort, or rethrow
```

Trap invariants:

```text
I1: trap type is distinguishable
I2: handler frame is valid
I3: handler effects are declared
I4: recovery policy permits the handler action
I5: unhandled traps are declared or routed to runtime policy
```

PMSL exceptions are not uncontrolled jumps. They are recontextualizations with typed continuation behavior.

A trap handler may recover, propagate, abort, or transform a continuation, but the transformation remains Φ-typed and policy-governed.

### 4.20 Channels

Channels are typed communication frames.

Syntax:

```pmsl
channel inbox: channel<Message>
send inbox <- msg
let msg = recv inbox timeout 50ms
```

Primary operators:

```text
channel declaration → □ / Δ
send                → ∇
recv                → Λ / ∇
```

Channel declaration lowering:

```text
Δ classify channel name and payload type
□ create endpoint/frame abstraction
Ω attach send/receive capabilities
Χ define projected visibility boundary
Ψ attach channel policy
Σ commit channel declaration
```

Send lowering:

```text
Δ classify channel and message
Ω verify send authority
Χ verify projected endpoint visibility
Ψ check channel policy
∇ enqueue or deliver message
Θ order delivery
Σ commit send state
Φ handle send failure
```

Receive lowering:

```text
Δ classify channel
Ω verify receive authority
Χ verify projected endpoint visibility
Θ order wait/receive
Λ if no message available
∇ dequeue message if present
Σ commit receive state
Φ enter handler if trap or timeout policy requires
```

Full concurrency and IPC semantics are refined in Section 6 and Section 12.

A channel is not merely a queue. It is a typed communication frame with authority, visibility, ordering, absence, commit, trap, and policy obligations.

### 4.21 Tasks and Structured Concurrency

Task constructs create concurrent execution frames.

Syntax:

```pmsl
spawn task Worker {
    process_messages(inbox)
}

await Worker
cancel Worker
```

Primary operators:

```text
spawn  → □ / Θ
await  → Θ / Λ / Σ
cancel → Φ / Ψ / Σ
```

Spawn lowering:

```text
Δ classify task
Ω verify spawn authority
□ create task frame
Χ establish projected task boundary
Ψ attach task policy
Θ schedule task
Σ commit task creation
```

Await lowering:

```text
Δ classify awaited task
Θ wait for completion
Λ if not complete within selected mode
Σ integrate task result if completed
Φ handle task failure
```

Cancel lowering:

```text
Δ classify task lifecycle
Ω verify cancel authority
Ψ check cancellation policy
Φ recontextualize task state
Σ commit cancellation or closure
```

Structured concurrency invariants:

```text
I1: spawned task has a frame
I2: task authority is explicit
I3: task boundary projection is visible to analysis
I4: cancellation is policy-governed
I5: join/await integrates or propagates result
```

Task constructs specify language/runtime architecture. A concrete runtime profile determines whether tasks map to host tasks, PMS-RUST-style deterministic execution, simulator tasks, or future PMS-OS execution units.

### 4.22 Modules

Modules are named frames with boundaries, imports, exports, policies, and lifecycle state.

Syntax:

```pmsl
module app.log {
    import Std.FS
    export write_log

    fn write_log(path: Path, data: Bytes) -> Unit {
        FS.write(path, data)
    }
}
```

Primary operator:

```text
□
```

Secondary operators:

```text
Δ module identity and symbol resolution
Ω import/export authority
Χ projected module boundary and visibility
Ψ module policy
Σ link/commit
Φ version/reload/migration
```

Module lowering:

```text
Δ identify module
□ establish module frame
Χ establish projected symbol and visibility boundary
Ω define import/export capability surface
Ψ attach module policy
Σ commit module declaration or linkage
```

Modules are refined in Section 8.

A module boundary is not PMS Base Χ itself. It is the PMSL/PMS-IR projection of Χ = Distance into symbol visibility, import reachability, sandboxing, host exposure, and runtime linkage.

### 4.23 Import and Export

Imports and exports are linkage constructs.

Syntax:

```pmsl
import Std.FS
import Std.Log as Log
export write_log
```

Primary operators:

```text
import → Δ / Ω / Χ projection / Ψ / Σ
export → Δ / Ω / Χ projection / Ψ / Σ
```

Import lowering:

```text
Δ resolve module path
Ω verify import capability
Χ verify projected module visibility
Ψ check import policy
Σ commit linkage
```

Export lowering:

```text
Δ distinguish exported symbol
Ω verify export authority
Χ define projected visibility surface
Ψ check export policy
Σ commit export relation
```

Linkage invariants:

```text
I1: imported symbol is distinguishable
I2: export surface is explicit
I3: capability requirements are preserved
I4: module boundary is not bypassed
I5: policy controls visible interface
```

Import/export syntax is a language-level boundary mechanism. It must remain inspectable in PMS-IR.

### 4.24 Standard-Library Calls

Standard-library calls are PMSL constructs with known operator profiles.

Example:

```pmsl
FS.write(path, data)
```

Profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
```

Example:

```pmsl
Log.info(msg)
```

Profile:

```text
effects(Δ, ∇, Σ, Ψ)
```

Example:

```pmsl
Time.sleep(50ms)
```

Profile:

```text
effects(Δ, Θ, Λ, Σ)
```

Example:

```pmsl
Policy.check(P, action)
```

Profile:

```text
effects(Δ, Ω, Ψ, Σ)
```

A standard-library function must expose:

```text
effect class
capability requirements
absence behavior
trap behavior
commit behavior
policy behavior
boundary behavior where relevant
```

The standard library is refined in Section 11 and Section 12.

The PMSL standard-library domains are architecture-level API profiles. They define operator profiles, type/effect obligations, and runtime contracts. They do not claim that every listed API already exists as a completed library implementation.

### 4.25 FFI and Host Calls

Foreign calls cross into non-PMS or host contexts.

Syntax:

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Φ_trap<HostError>>
    effects(□, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.read)
```

Primary operators:

```text
□ / Φ
```

Lowering:

```text
Δ classify foreign symbol
Ω verify foreign-call authority
Χ establish projected foreign/host boundary
Φ reframe into host ABI/context
∇ perform host action
Σ integrate result into PMSL frame
Φ map host error into PMSL trap
Ψ enforce FFI policy
```

FFI invariants:

```text
I1: foreign symbol is distinguishable
I2: foreign authority is explicit
I3: host boundary projection is explicit
I4: host effects are declared
I5: host errors are mapped to Φ/Λ/Result forms
I6: foreign calls cannot bypass PMSL policy
```

FFI is refined in Section 9.

A foreign call is not an escape from PMSL semantics. It is a controlled boundary operation whose host-side behavior is mediated through explicit authority, boundary projection, ABI recontextualization, integration, error mapping, and policy.

### 4.26 Policies and Invariants

Policy constructs are Ψ-dominant.

Syntax:

```pmsl
policy P_write_tmp {
    allow fs.write where path.starts_with("/tmp/")
    deny  fs.write where path.starts_with("/secure/")
}
```

Primary operator:

```text
Ψ
```

Policy declaration lowering:

```text
Δ distinguish policy name
Δ classify policy rules
Ω check policy-definition authority if required
Ψ define constraint set
Σ commit policy into module/runtime context
```

Policy evaluation lowering:

```text
Δ classify action and context
Ω identify actor role/capability state
Ψ evaluate policy
Σ commit decision if required
Φ handle violation if exceptional
Λ defer if decision depends on absent state
```

Policy invariants:

```text
I1: policy rules are distinguishable
I2: policy scope is explicit
I3: policy does not weaken enclosing policy
I4: policy denial has defined response
I5: policy decisions are visible to PMS-IR tooling
```

Policy constructs provide program-level constraints and runtime checks. They are not moral verdicts, forensic determinations, governance tribunals, or PMS Base validation.

### 4.27 Return

Return integrates function result and recontextualizes to caller.

Syntax:

```pmsl
return value
```

Primary operator:

```text
Σ
```

Secondary operator:

```text
Φ
```

Lowering:

```text
Δ classify return value
Σ integrate value into function result
Φ restore caller continuation
□ exit function frame
Ψ check postconditions if declared
```

Return invariants:

```text
I1: returned value matches declared return type
I2: required local effects are committed, staged, or propagated
I3: function frame is closed
I4: caller continuation is restored
I5: postconditions are checked where declared
```

Return is not only a control-flow jump. It is a result integration plus continuation recontextualization.

### 4.28 Result, Option, and Declared Failure Forms

PMSL uses explicit result forms to keep Φ and Λ visible.

Examples:

```pmsl
Result<T, Φ_trap<E>>
Option<T>
Λ_absent<T>
```

Operator mapping:

```text
Result<T, Φ_trap<E>> → value or recontextualized trap
Option<T>            → value or absence marker
Λ_absent<T>          → typed non-event / no-value path
```

A function that may fail must expose the kind of failure:

```pmsl
fn read(path: Path) -> Result<Bytes, Φ_trap<IOError>>
fn try_recv(ch: channel<Message>) -> Result<Message, Λ_absent<Message>>
```

Failure-form invariants:

```text
I1: absence is not confused with trap
I2: trap is not confused with policy denial
I3: policy denial is represented through Ψ/Φ as declared
I4: callers handle or propagate declared failure forms
```

PMSL failure typing preserves operator distinctions. It must not collapse Λ, Φ, Ψ, and Σ failure into one undifferentiated error category.

### 4.29 Construct-to-IR Lowering Pattern

All construct lowering follows this architecture:

```text
source construct
→ parsed AST node
→ typed AST node
→ operator-typed AST node
→ PMS-IR node
→ validation
→ backend/runtime lowering
```

A PMS-IR node should preserve:

```text
node id
source span
construct kind
operator tag
type
effect set
frame context
role/capability requirement
policy context
boundary context
commit behavior
absence behavior
trap behavior
child nodes
```

Generic IR shape:

```text
IRNode = (
    id,
    op,
    construct,
    type,
    effects,
    frame,
    role_requirements,
    policy_requirements,
    boundary,
    commit,
    absence,
    trap,
    children,
    source_span
)
```

The same source construct may lower to multiple IR nodes.

Example:

```pmsl
policy with P_write {
    commit Σ {
        FS.write(path, data)
    }
}
```

PMS-IR outline:

```text
IR.PolicyScope(op=Ψ, policy=P_write)
 └── IR.Commit(op=Σ)
      └── IR.Call(op=∇, callee=FS.write)
           ├── IR.Resolve(op=Δ, symbol=FS.write)
           ├── IR.Require(op=Ω, capability=fs.write)
           ├── IR.Boundary(op=Χ, namespace=active)
           ├── IR.PolicyCheck(op=Ψ, policy=P_write)
           └── IR.FailurePaths(op=Φ/Λ)
```

Here `IR.Boundary(op=Χ, ...)` denotes the PMSL/PMS-IR projection of PMS Base Χ = Distance into a concrete boundary or visibility obligation.

Validation of the PMS-IR outline is profile-local acceptance/rejection. It is not proof of implementation correctness and not PMS Base validation.

### 4.30 Implicit Operator Reconstruction

PMSL permits concise source.

Example:

```pmsl
FS.write(path, data)
```

The compiler must reconstruct implicit operators:

```text
Δ symbol/path classification
Ω capability check
Χ projected namespace visibility
Ψ policy check
∇ write effect
Σ effect state
Φ/Λ failure paths
```

Implicit reconstruction is allowed only when:

```text
the operator profile is known
∧ required capabilities can be inferred or declared
∧ policy context is available
∧ boundary obligations are inferable or declared
∧ absence/trap behavior is represented
∧ commit behavior is explicit or defaulted by profile
```

If the compiler cannot reconstruct obligations, it must require explicit syntax or reject the construct.

AI-proposed PMSL/PMS-IR artifacts do not bypass this rule. They become admissible only after host-side parsing, canonicalization, mapping, validation, and profile acceptance.

### 4.31 Static Obligations by Construct

| Construct class | Static obligation                                                       |
| --------------- | ----------------------------------------------------------------------- |
| binding         | name/type uniqueness and frame visibility                               |
| assignment      | target mutability, effect classification, authority and boundary checks |
| call            | callee resolution, argument compatibility, effect exposure              |
| block           | scope and local effect closure                                          |
| function        | signature/effect/body consistency                                       |
| branch/match    | type/effect merge and exhaustiveness                                    |
| loop/pattern    | expansion validity and termination/absence profile                      |
| frame           | frame identity, entry authority, boundary rules                         |
| policy          | policy availability and non-weakening                                   |
| role/capability | authority graph coherence                                               |
| commit          | staged effects and commit compatibility                                 |
| channel         | payload type, endpoint authority, failure paths                         |
| task            | frame/capability/lifecycle structure                                    |
| trap            | handler type and recovery policy                                        |
| FFI             | foreign boundary and effect declaration                                 |
| module          | import/export visibility and linkage                                    |

These obligations feed Section 14 static analysis and linting.

Static analysis checks declared obligations under a profile. It does not by itself prove all possible runtime behavior and does not validate PMS Base.

### 4.32 Runtime Obligations by Construct

| Construct class | Runtime obligation                          |
| --------------- | ------------------------------------------- |
| binding         | allocate/register local slot or value       |
| assignment      | perform mutation under active policy        |
| call            | enter callable context and integrate result |
| block           | manage frame entry/exit                     |
| function        | bind arguments, run body, return            |
| branch/match    | select executable path                      |
| loop/pattern    | order iterations and exit paths             |
| frame           | switch active runtime context               |
| policy          | activate/evaluate/restore policy            |
| role/capability | validate authority                          |
| commit          | integrate or rollback/stage effects         |
| channel         | enqueue/dequeue/wait/fail                   |
| task            | create/schedule/cancel/join                 |
| trap            | recontextualize into handler                |
| FFI             | cross host boundary and map result          |
| module          | load/link/enforce boundary                  |

These obligations feed Section 10 runtime architecture.

The PMSL runtime is specified as an architecture layer. Concrete runtime artifacts may implement bounded profiles. PMS-RUST v0.1 is one such bounded evidence spine, not the full PMSL runtime.

### 4.33 Construct-Level Failure Paths

PMSL failure paths are operator-typed.

| Failure                   | Operator reading                |
| ------------------------- | ------------------------------- |
| unknown symbol            | Δ failure → Φ diagnostic/trap   |
| invalid target            | Δ / Φ                           |
| unauthorized action       | Ω / Ψ                           |
| boundary violation        | Χ projection / Ψ / Φ            |
| policy denial             | Ψ / Φ                           |
| no message                | Λ                               |
| timeout                   | Λ                               |
| invalid commit            | Σ failure → Φ rollback/recovery |
| unhandled exception       | Φ propagation                   |
| invalid pattern expansion | Α / Ψ rejection                 |
| FFI error                 | Φ mapping                       |
| absent resource           | Λ or Φ depending on profile     |

The architecture requires that failures remain typed. A construct that collapses all failure into a generic error loses PMSL structure.

Failure typing is profile-local and implementation-facing. It supports analysis and runtime discipline; it does not validate PMS Base.

### 4.34 Construct-Level Invariants

PMSL maintains the following construct-level invariants.

```text
I1: every construct lowers to one or more PMS-IR nodes
I2: every PMS-IR node has an operator tag
I3: every effectful construct exposes its effect class
I4: every protected construct exposes Ω requirements
I5: every frame construct exposes □ context behavior
I6: every boundary-crossing construct exposes Χ-projected behavior
I7: every policy-governed construct exposes Ψ behavior
I8: every absence-capable construct exposes Λ behavior
I9: every trap-capable construct exposes Φ behavior
I10: every commit-capable construct exposes Σ behavior
I11: every pattern construct expands to valid operator-typed IR
I12: every branch or match preserves type/effect merge obligations
I13: every function body satisfies its declared signature and effects
I14: every FFI construct preserves host-boundary semantics
I15: no construct may erase operator obligations during lowering
I16: AI-proposed construct artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level constraints for PMSL/PMS-IR conformance.

They do not claim that a complete compiler or verifier already enforces all of them.

### 4.35 Boundary to Later Sections

This section defines the construct-to-operator mapping.

It does not fully define:

| Topic                               | Primary section |
| ----------------------------------- | --------------- |
| type system details                 | Section 5       |
| concurrency and IPC semantics       | Section 6       |
| error and exception typing          | Section 7       |
| module system                       | Section 8       |
| FFI and host interoperability       | Section 9       |
| runtime implementation architecture | Section 10      |
| standard library                    | Section 11      |
| concurrency and IO APIs             | Section 12      |
| PMS-IR full format                  | Section 13      |
| static analysis and linting         | Section 14      |
| model checking and verification     | Section 15      |
| debugging and observability         | Section 16      |
| simulation and emulation            | Section 17      |
| examples                            | Section 18      |

The mapping here is the common reference used by those sections.

### 4.36 Architectural Consequence

The consequence of the PMSL construct model is:

```text
PMSL constructs are valid when they are readable as source-level syntax
and lowerable as operator-preserving PMS-IR. Bindings, blocks, calls,
branches, loops, frames, policies, roles, commits, channels, tasks,
modules, traps, FFI calls, and standard-library APIs all remain
analyzable as Δ–Ψ structures.
```

This gives PMSL its position in PMS-STACK: it is a readable programming language surface whose semantic power comes from preserving the operator structure that PMS-UM, PMS-CPU, PMS-OS, runtime tooling, verification systems, simulators, and executable PMS-RUST-style artifacts can inspect and constrain.

### 4.37 Construct Mapping Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL core-construct model specifies how language constructs lower into
operator-preserving PMS-IR with explicit distinctions, effects, frames,
absences, patterns, authorities, orderings, recontextualizations,
boundary projections, commits, and policies.

This is a language construct / operator-mapping architecture claim.

It does not claim a completed compiler, completed lowering implementation,
completed runtime, completed standard library, completed verifier, or
completed PMSL implementation.

PMS-RUST v0.1 may support bounded implementation-artifact evidence for
related opcode construction, validation, deterministic kernel execution,
JSONL traces, REPL/script tooling, vFS service boundaries, golden fixtures,
and AI proposal gating. It does not complete PMSL/PMS-IR and does not
validate PMS Base.
```

---

## 5. Type System

The PMSL type system is an operator-validity system.

PMSL types do not classify data shapes alone. They classify whether a value, expression, function, task, channel, module, frame, role, policy, boundary crossing, commit, or effect is admissible under the active Δ–Ψ context.

The central type-system claim is:

```text
A PMSL type is a structural admissibility profile for operator-typed
programs: it constrains which Δ–Ψ transitions are valid, in which frame,
under which role, under which policy, across which boundary projection,
with which absence, trap, effect, and commit behavior.
```

This section defines the type-system architecture. It is a language/type-system architecture claim, not a claim that a complete PMSL type checker, complete compiler, complete proof engine, complete runtime, or complete verified toolchain already exists.

Claim type:

```text
LANGUAGE TYPE-SYSTEM / OPERATOR-VALIDITY ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies the PMSL type-system architecture as an
operator-validity discipline.

It does not claim a completed PMSL type checker, completed compiler,
completed verifier, completed proof engine, completed runtime, completed
standard library, or completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared type-system rule, schema, compiler profile, runtime profile, backend profile, tool profile, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, theoretical adequacy, or full behavioral coverage.

### 5.1 Type System Role

The PMSL type system connects four levels:

```text
source syntax
→ typed AST
→ operator-typed AST
→ PMS-IR
→ runtime/backend obligations
```

Its role is to ensure that PMSL programs preserve operator structure before they reach PMS-IR, runtime execution, simulation, static analysis, trace generation, or verification tooling.

A classical type system asks:

```text
Does expression e have value type T?
```

PMSL asks the stronger structural question:

```text
Is expression e admissible as an operator-typed transition under the
current frame, role, policy, boundary projection, effect, absence, trap,
and commit context?
```

Thus, a PMSL type judgment does not only mention value type. It mentions the execution situation.

### 5.2 Type Judgment Form

The general PMSL judgment form is:

```text
Γ ; F ; R ; P ; Bχ ; E ⊢ e : T ! ε
```

where:

| Component | Meaning                                                                           |
| --------- | --------------------------------------------------------------------------------- |
| `Γ`       | binding environment                                                               |
| `F`       | active frame type                                                                 |
| `R`       | active role type                                                                  |
| `P`       | active policy type                                                                |
| `Bχ`      | active PMSL/PMS-IR boundary, process, sandbox, host, module, or isolation profile |
| `E`       | effect environment                                                                |
| `e`       | expression, statement, declaration, or construct                                  |
| `T`       | resulting value/type                                                              |
| `ε`       | operator-typed effect set or effect word                                          |

Read:

```text
Under environment Γ, frame F, role R, policy P, boundary projection Bχ,
and effect environment E, construct e has type T and produces operator
effects ε.
```

`Bχ` is a PMSL/PMS-IR type-system component. It is not PMS Base Χ itself.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At the PMSL/PMS-IR level, Χ is projected into boundary, visibility, sandbox, module, runtime, host, process, and reachability disciplines. `Bχ` names that layer projection inside the type judgment.

A simpler expression-level form may be used where context is implicit:

```text
Γ ⊢ e : T
```

but this is shorthand for the full structural judgment.

### 5.3 Type Components

A PMSL type may contain several components.

```text
Type = (
    data_shape,
    frame_constraints,
    role_constraints,
    policy_constraints,
    boundary_constraints,
    effect_constraints,
    absence_constraints,
    trap_constraints,
    commit_constraints,
    lifetime_constraints,
    meta
)
```

Not every type uses every component. A primitive integer may mainly use `data_shape`. A channel type uses frame, role, boundary, effect, absence, ordering, and commit components. A foreign function type uses boundary, role, policy, trap, ABI, and commit components.

The design consequence is:

```text
types classify values and the admissible operator behavior around values
```

not merely memory layout.

### 5.4 Kind-Level Categories

PMSL defines several interacting type kinds.

```text
DataType
FrameType
RoleType
CapabilityType
PolicyType
BoundaryType
ProcessType
EffectType
AbsenceType
TrapType
CommitType
ChannelType
TaskType
ModuleType
ForeignType
PatternType
```

Operator alignment:

| Kind             | Primary operator                 |
| ---------------- | -------------------------------- |
| `DataType`       | Δ / Σ                            |
| `FrameType`      | □                                |
| `RoleType`       | Ω                                |
| `CapabilityType` | Ω                                |
| `PolicyType`     | Ψ                                |
| `BoundaryType`   | Χ projection                     |
| `ProcessType`    | Χ projection / Θ                 |
| `EffectType`     | Δ–Ψ                              |
| `AbsenceType`    | Λ                                |
| `TrapType`       | Φ                                |
| `CommitType`     | Σ                                |
| `ChannelType`    | Δ / Ω / Χ projection / Θ / Λ / Σ |
| `TaskType`       | □ / Θ / Χ projection / Ψ         |
| `ModuleType`     | □ / Χ projection / Ω / Ψ         |
| `ForeignType`    | Φ / □ / Χ projection             |
| `PatternType`    | Α                                |

The type checker operates over these kinds jointly.

The `Χ projection` wording is deliberate. PMSL/PMS-IR does not redefine Χ. It types the implementation-facing layer projection of PMS Base Χ = Distance.

### 5.5 Data Types

Data types are Δ-derived distinctions and Σ-integrated structures.

Primitive examples:

```text
Bool   := Δ{true, false}
Int    := Δ over integer domain
Float  := Δ over floating domain
String := Δ* over character alphabet
Bytes  := Δ* over byte alphabet
Unit   := Σ{} or committed empty result
```

Composite examples:

```text
Tuple<T1, T2>    := Σ(T1, T2)
Record{...}      := Σ(named fields)
Enum{...}        := Δ(alternatives)
List<T>          := Α(sequence pattern over T)
Map<K, V>        := Α(key/value distinction pattern)
Option<T>        := Δ{some: T, none: Λ}
Result<T, E>     := Δ{ok: T, err: E}
```

Data-type rules:

```text
sum type       → Δ
product type   → Σ
sequence type  → Θ / Α
optional type  → Δ + Λ
error type     → Δ + Φ
policy type    → Ψ
capability     → Ω
frame handle   → □
boundary token → Χ projection
```

This gives data typing an operator basis without reducing the language to symbolic operator code.

### 5.6 Frame Types

A frame type describes the contextual domain in which values, symbols, effects, and computations are valid.

```text
FrameType F := {
    name: Identifier,
    allowed_ops: Set<Operator>,
    symbols: SymbolMap,
    subframes: Set<FrameType>,
    policies: Set<PolicyType>,
    roles: Set<RoleType>,
    boundary: BoundaryType?,
    lifetime: LifetimeSpec,
    meta: Meta
}
```

Examples:

```text
LexicalFrame
FunctionFrame
ModuleFrame
TransactionFrame
PolicyFrame
TaskFrame
ChannelFrame
ForeignFrame
SandboxFrame
RuntimeFrame
```

A frame type determines:

```text
which symbols are visible
which effects are allowed
which policies apply
which roles may act
which boundaries exist
which commits are required
which traps may be handled
which child frames may be entered
```

Frame entry judgment:

```text
Γ ; F ; R ; P ; Bχ ; E ⊢ enter F2 { body } : T ! ε
```

is valid only if:

```text
Δ identifies F2
∧ Ω permits entry
∧ Χ-projected boundary profile Bχ permits reachability
∧ Ψ/P permits frame transition
∧ body is valid under F2
∧ frame exit restores or commits required state
```

### 5.7 Frame Subtyping

Frame subtyping is structural.

```text
F1 ≤ F2
```

when:

```text
allowed_ops(F1) ⊆ allowed_ops(F2)
∧ visible_symbols(F1) ⊆ visible_symbols(F2) or safely restricted
∧ policies(F1) strengthen or preserve policies(F2)
∧ boundary(F1) is no weaker than boundary(F2)
```

This means a more restricted frame may be used where a broader frame is expected if the expected operation set is still satisfied.

Example:

```text
ReadOnlyFrame ≤ FileFrame
SandboxFrame  ≤ RuntimeFrame
TransactionFrame ≤ FunctionFrame
```

under policy-specific definitions.

Frame subtyping must not weaken policy, authority, or boundary discipline.

```text
F_sub may restrict.
F_sub may not silently grant more authority.
F_sub may not silently weaken Ψ.
F_sub may not silently bypass Χ-projected reachability constraints.
```

### 5.8 Role Types

A role type describes authority.

```text
RoleType R := {
    name: Identifier,
    capabilities: Set<CapabilityType>,
    allowed_ops: Set<Operator>,
    may_enter: Set<FrameType>,
    may_call: Set<FunctionType>,
    may_import: Set<ModuleType>,
    may_transfer: Set<CapabilityType>,
    escalation: Set<RoleType>,
    downgrade: Set<RoleType>,
    policy: PolicyType?,
    meta: Meta
}
```

Examples:

```text
User
Admin
LogWriter
FSReader
FSWriter
PolicyInstaller
ModuleLoader
ForeignCaller
RuntimeSupervisor
```

Role-type validity:

```text
role action valid iff
    action is Δ-classified
    ∧ capability exists in R
    ∧ active frame permits action
    ∧ active boundary projection permits reachability
    ∧ active policy permits action
```

Role-typed function example:

```pmsl
fn write_log(path: Path, data: Bytes)
    -> Result<Unit, Φ_trap<IOError>>
    requires Ω(LogWriter)
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
```

Meaning:

```text
the function may be called only under a role environment that satisfies
the LogWriter authority requirement.
```

### 5.9 Capability Types

A capability type is an Ω-typed permission object.

```text
CapabilityType C := {
    action: ActionName,
    target: TargetPattern,
    modes: Set<Mode>,
    transfer: TransferPolicy,
    lifetime: LifetimeSpec,
    boundary: BoundaryType?,
    policy: PolicyType?,
    meta: Meta
}
```

Examples:

```text
cap fs.read("/home/**")
cap fs.write("/var/log/**")
cap net.connect("service://audit")
cap policy.install(P)
cap module.import(Std.FS)
cap ffi.call(host.fs.read)
cap channel.send<Event>(events)
cap channel.recv<Event>(events)
```

Capability subtyping:

```text
C1 ≤ C2
```

when:

```text
target(C1) is narrower than target(C2)
∧ modes(C1) ⊆ modes(C2)
∧ transfer(C1) is no more permissive
∧ lifetime(C1) is no longer
∧ policy(C1) is no weaker
∧ boundary(C1) is no more permissive
```

Example:

```text
fs.write("/var/log/app.log") ≤ fs.write("/var/log/**")
```

Capability types support least-authority programming.

A capability can authorize an action only inside compatible frame, policy, and boundary conditions. Ω alone does not override Ψ or Χ-projected boundary rules.

### 5.10 Policy Types

A policy type encodes Ψ constraints.

```text
PolicyType P := {
    name: Identifier,
    invariants: Set<Invariant>,
    scope: FrameType | ModuleType | RuntimeScope,
    enforcement_points: Set<Operator>,
    decision_space: DecisionSet,
    failure_response: FailurePolicy,
    meta: Meta
}
```

Policy types do not classify values alone. They classify trajectories.

A policy constrains:

```text
which effects are allowed
which roles may act
which frames may be entered
which boundaries may be crossed
which commits are valid
which traps may recover
which absence paths may retry
which modules may link
which foreign calls may execute
```

Policy subtyping follows strengthening:

```text
P1 ≤ P2 iff invariants(P1) ⊇ invariants(P2)
```

A stronger policy is a subtype because it permits fewer transitions.

Example policy types:

```text
SafeFS
NoNetwork
ReadOnlyFrame
NoFFI
AuditRequired
NoUnboundedSpawn
CommitBeforeReturn
SandboxOnly
```

Policy composition:

```text
P_combined = Σ(P1, P2)
```

Composition is valid only if the resulting invariant set is coherent.

Policy typing is a program-constraint discipline. It is not moral judgment, forensic attribution, governance authority, or PMS Base validation.

### 5.11 Boundary and Process Types

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR level, Χ is projected as boundary, visibility, sandbox, module separation, process isolation, host separation, runtime isolation, and reachability control.

A boundary type describes where values, effects, calls, and frames may be visible.

```text
BoundaryType Bχ := {
    domain: DomainId,
    visibility: VisibilityRules,
    reachable_frames: Set<FrameType>,
    import_rules: ImportRules,
    export_rules: ExportRules,
    transfer_rules: TransferRules,
    policy: PolicyType?,
    meta: Meta
}
```

A process type describes an execution locus.

```text
ProcessType Proc := {
    isolation_level: IsolationLevel,
    namespace: FrameType,
    allowed_syscalls: Set<SyscallProfile>,
    scheduler_class: SchedulerType,
    resource_profile: ResourceProfile,
    policy: PolicyType,
    meta: Meta
}
```

Examples:

```text
Proc_sandbox
Proc_user
Proc_service
Proc_system
Proc_test
Proc_simulated
```

Process/boundary subtyping:

```text
Proc_sandbox ≤ Proc_user ≤ Proc_system
```

when interpreted as capability containment:

```text
sandbox has fewer permitted transitions
user has normal user transitions
system has broader but still policy-bound transitions
```

Boundary typing prevents accidental cross-domain capture.

Example invalid transition:

```text
value: Secret in Boundary<Host>
used in Boundary<Sandbox>
```

unless an explicit, policy-approved transfer exists.

Boundary typing is a PMSL/PMS-IR implementation-layer projection of Χ. It does not redefine PMS Base Χ.

### 5.12 Effect Types

An effect type records operator behavior.

```text
EffectType ε := Set<OperatorEffect>
```

Examples:

```text
Effect<Δ>
Effect<∇>
Effect<Ω, Ψ>
Effect<Δ, Ω, Χ, Ψ, ∇, Σ, Φ>
Effect<Θ, Λ, Σ>
```

A function may declare effects:

```pmsl
fn send_event(ch: channel<Event>, ev: Event)
    -> Result<Unit, Φ_trap<SendError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)
```

Effect inclusion:

```text
ε1 ≤ ε2 iff ε1 ⊆ ε2
```

Meaning:

```text
a function with fewer effects may be used where a broader effect allowance
is expected
```

Effect checking ensures:

```text
body_effects(fn) ⊆ declared_effects(fn)
```

and:

```text
declared_effects(fn) permitted by active frame/policy/role/boundary profile
```

Effect typing is specification-level. A concrete tool may check a bounded effect subset under a declared profile.

### 5.13 Operator Effect Families

PMSL uses effect families.

```text
Effect<Δ>  distinguish / resolve / classify
Effect<∇>  mutate / perform IO / execute effect
Effect<□>  enter/leave frame
Effect<Λ>  produce absence / timeout / no-event
Effect<Α>  expand or instantiate pattern
Effect<Ω>  require or use authority
Effect<Θ>  order / await / schedule
Effect<Φ>  trap / recover / recontextualize
Effect<Χ>  enforce or cross layer-projected boundary
Effect<Σ>  commit / integrate / return
Effect<Ψ>  check or activate policy
```

Effect typing is central to PMSL because source programs must remain analyzable as operator words.

`Effect<Χ>` denotes the PMSL/PMS-IR projection of PMS Base Χ = Distance into boundary, visibility, sandbox, module, host, runtime, or reachability behavior.

### 5.14 Absence Types

Absence types represent Λ paths.

```text
AbsenceType A := {
    expected: Type,
    absence_kind: AbsenceKind,
    timeout: Duration?,
    retry_policy: PolicyType?,
    handler: HandlerType?,
    meta: Meta
}
```

Examples:

```pmsl
Option<T>
Λ_absent<T>
Timeout<T>
NoMessage<Msg>
NotReady<T>
Missing<Path>
```

Example:

```pmsl
fn try_recv(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message>>
    effects(Δ, Ω, Χ, Θ, Λ, ∇, Σ)
```

Absence typing rule:

```text
if e may produce Λ, then Λ must be:
    handled,
    returned,
    converted to Φ under declared policy,
    or statically ruled out under the active profile
```

Absence is not automatically an exception. PMSL distinguishes:

```text
absence as normal expected non-event
trap as recontextualized exceptional path
policy denial as Ψ outcome
commit failure as Σ/Φ path
```

### 5.15 Trap Types

Trap types represent Φ paths.

```text
TrapType E := {
    kind: TrapKind,
    payload: Type?,
    source: SourceClass,
    handler_requirements: Set<CapabilityType>,
    recovery_policy: PolicyType?,
    meta: Meta
}
```

Examples:

```pmsl
Φ_trap<IOError>
Φ_trap<PolicyViolation>
Φ_trap<BoundaryFault>
Φ_trap<ForeignError>
Φ_trap<TypeFault>
```

Trap typing rule:

```text
if e may produce Φ, then Φ must be:
    handled,
    declared in the result/effect type,
    propagated,
    or ruled out statically under the active profile
```

Example:

```pmsl
fn read_file(path: Path)
    -> Result<Bytes, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
```

Trap handlers are themselves typed frames.

```text
HandlerType<E, T> := Φ handler that maps E to T or propagates Φ
```

Trap typing keeps recontextualization explicit. It must not be collapsed into untyped failure.

### 5.16 Commit Types

Commit types represent Σ obligations.

```text
CommitType C := {
    subject: Type,
    mode: CommitMode,
    visibility: VisibilityLevel,
    durability: DurabilityLevel,
    rollback: TrapType?,
    policy: PolicyType?,
    meta: Meta
}
```

Commit modes:

```text
local
transactional
durable
staged
eventual
audit
message_delivery
filesystem_commit
policy_install
module_link
```

Examples:

```pmsl
Σ_tx<FileWrite>
Σ_local<Binding>
Σ_durable<AuditRecord>
Σ_delivery<Message>
Σ_module<Linkage>
```

Commit typing rule:

```text
effect executed ≠ effect committed
```

A function that promises committed state must expose a Σ type or effect.

Example:

```pmsl
fn append_audit(record: AuditRecord)
    -> Result<Σ_durable<AuditRecord>, Φ_trap<AuditError>>
    effects(Δ, Ω, Ψ, ∇, Σ, Φ)
```

Commit typing is profile-bound. A durable commit type is meaningful only relative to a declared backend/runtime durability profile.

### 5.17 Function Types

Function types include parameter types, return type, effect type, required role/capability, frame requirement, policy requirement, boundary requirement, and failure profile.

```text
FunctionType := {
    params: [Type],
    result: Type,
    effects: EffectType,
    requires_role: RoleType?,
    requires_caps: Set<CapabilityType>,
    requires_policy: PolicyType?,
    frame: FrameType?,
    boundary: BoundaryType?,
    traps: Set<TrapType>,
    absences: Set<AbsenceType>,
    commits: Set<CommitType>,
    meta: Meta
}
```

Surface example:

```pmsl
fn write_log(path: Path, data: Bytes)
    -> Result<Σ_durable<Unit>, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(LogWriter), Ψ(AuditRequired)
```

Function type validity:

```text
body effects ⊆ declared effects
required capabilities are sufficient
called functions are admissible under current frame/role/policy/boundary
all Λ and Φ paths are handled or declared
all Σ obligations are closed or returned
```

A function type is therefore a structured operator contract, not only a parameter/result signature.

### 5.18 Module Types

A module type describes a module’s symbol frame, exports, imports, role surface, policy surface, boundary, and lifecycle.

```text
ModuleType M := {
    name: ModulePath,
    exports: SymbolMap,
    imports: ImportSet,
    frame: FrameType,
    boundary: BoundaryType,
    required_roles: Set<RoleType>,
    policies: Set<PolicyType>,
    effects: EffectType,
    version: Version,
    lifecycle: ModuleLifecycle,
    meta: Meta
}
```

Module type checking verifies:

```text
all imports are visible
all exports are declared
exported effects are part of the public contract
internal capabilities do not leak
module policy is no weaker than enclosing policy
module boundary is preserved
version/reload constraints are explicit
```

Module types are refined in Section 8.

A module boundary is a PMSL/PMS-IR projection of PMS Base Χ = Distance into symbol visibility, import reachability, sandboxing, host exposure, and runtime linkage.

### 5.19 Channel Types

A channel type is an operator-typed communication type.

```text
ChannelType<T> := {
    payload: T,
    direction: Direction,
    send_role: RoleType?,
    recv_role: RoleType?,
    boundary: BoundaryType,
    ordering: OrderingPolicy,
    absence: AbsenceType?,
    delivery: DeliveryPolicy,
    commit: CommitType?,
    policy: PolicyType?,
    meta: Meta
}
```

Examples:

```pmsl
channel<Event>
SendChannel<Event>
RecvChannel<Event>
channel<Message> requires Ω(ServiceClient)
```

Channel send type rule:

```text
Γ ; F ; R ; P ; Bχ ; E ⊢ send ch <- msg : Σ_delivery<Unit> ! ε
```

valid if:

```text
ch : ChannelType<T>
∧ msg : T
∧ R satisfies send_role(ch)
∧ Bχ permits endpoint visibility
∧ P permits channel send
∧ ε includes Δ, Ω, Χ, Ψ, ∇, Θ, Σ
```

Channel receive type rule:

```text
recv ch timeout t : Result<T, Λ_absent<T> | Φ_trap<RecvError>>
```

depending on channel policy.

Channel types are refined in Section 6 and Section 12.

### 5.20 Task Types

A task type describes a concurrent execution locus.

```text
TaskType<T> := {
    result: T,
    frame: FrameType,
    role: RoleType,
    boundary: BoundaryType,
    scheduler: SchedulerType,
    cancellation: CancellationPolicy,
    effects: EffectType,
    absences: Set<AbsenceType>,
    traps: Set<TrapType>,
    policy: PolicyType,
    meta: Meta
}
```

Spawn typing:

```pmsl
spawn task Worker {
    body
}
```

requires:

```text
body type-checks under task frame
spawn role has task creation capability
boundary can be established
scheduler class is permitted
task policy is attached
task creation commits through Σ
```

Await typing:

```text
await Worker : Result<T, Λ_absent<T> | Φ_trap<TaskError>>
```

Task types ensure that concurrency is typed as frame, boundary, role, order, absence, trap, and commit structure.

A concrete runtime profile determines whether task types map to host tasks, PMS-RUST-style deterministic execution, simulator tasks, or future PMS-OS execution units.

### 5.21 Pattern Types

A pattern type describes an Α expansion.

```text
PatternType := {
    params: [Type],
    expansion: OperatorTemplate,
    constraints: Set<Constraint>,
    effects: EffectType,
    policy: PolicyType?,
    meta: Meta
}
```

Example:

```pmsl
pattern retry<N>(op) {
    loop until success or attempts == N {
        op()
    }
}
```

Pattern type validity:

```text
expansion produces valid operator words
parameters are typed
effect profile is declared or inferable
Λ/Φ/Σ behavior is exposed
policy constraints are preserved after expansion
```

A pattern may abstract structure. It may not hide invalid operator sequences.

Pattern typing is therefore not macro decoration. It is an operator-validity discipline for reusable structures.

### 5.22 Foreign Types

Foreign types describe host or non-PMS values and calls.

```text
ForeignType := {
    host_name: Identifier,
    abi: ABIProfile,
    representation: Representation,
    boundary: BoundaryType,
    allowed_ops: Set<Operator>,
    policy: PolicyType,
    meta: Meta
}
```

Foreign function type:

```text
ForeignFunctionType := {
    params: [ForeignType | Type],
    result: ForeignType | Type,
    effects: EffectType,
    boundary: BoundaryType,
    traps: Set<TrapType>,
    policy: PolicyType
}
```

Example:

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.read)
```

Foreign-type rule:

```text
foreign value may not cross into PMSL frame unless translated, wrapped,
copied, pinned, or represented through an explicit boundary policy
```

FFI is refined in Section 9.

A foreign type is not an escape from PMSL obligations. It is a typed boundary object under Ω, Χ projection, Φ, Σ, and Ψ.

### 5.23 Lifetimes and Ownership

PMSL may include lifetime and ownership disciplines to keep frame and boundary validity explicit.

Lifetime kinds:

```text
local
frame
module
task
transaction
borrowed
owned
shared
foreign
static
ephemeral
```

Ownership is not necessarily Rust-style ownership. In PMSL, ownership means:

```text
which frame/role/policy/boundary is responsible for the value lifecycle
```

Generic ownership type:

```text
Owned<T, F>
Borrowed<T, F, Lifetime>
Shared<T, Policy>
ForeignOwned<T, Boundary>
```

Lifecycle rule:

```text
a value cannot outlive the frame, boundary, policy, or resource context
that makes it valid
```

Example invalid movement:

```text
Borrowed<T, TransactionFrame> returned after transaction frame closes
```

unless the value is committed, copied, or lifted through a valid Σ/Φ transition.

Ownership and lifetime typing are architecture-level PMSL disciplines. They do not assert that PMSL already implements a Rust-style borrow checker.

### 5.24 Subtyping Summary

PMSL subtyping is structural and policy-aware.

Data subtyping:

```text
T1 ≤ T2
```

when values of `T1` may be used where `T2` is expected.

Frame subtyping:

```text
F1 ≤ F2
```

when `F1` is at least as restrictive or context-compatible as `F2`.

Role subtyping:

```text
R1 ≤ R2
```

when `capabilities(R1) ⊆ capabilities(R2)`.

Policy subtyping:

```text
P1 ≤ P2
```

when `invariants(P1) ⊇ invariants(P2)`.

Effect subtyping:

```text
ε1 ≤ ε2
```

when `ε1 ⊆ ε2`.

Boundary subtyping:

```text
Bχ1 ≤ Bχ2
```

when `Bχ1` is no more permissive than `Bχ2`.

Commit subtyping depends on commit mode:

```text
Σ_durable<T> ≤ Σ_visible<T> ≤ Σ_staged<T>
```

where a stronger commit may satisfy a weaker visibility requirement, but not the reverse.

Subtyping may restrict. It may not silently grant authority, weaken policy, erase absence, hide traps, bypass boundary projection, or upgrade commit guarantees without a declared rule.

### 5.25 Type Checking Pipeline

A PMSL type checker proceeds in stages.

```text
parse source
→ build AST
→ resolve symbols
→ infer data types
→ infer operator effects
→ check frame constraints
→ check role/capability constraints
→ check policy constraints
→ check boundary constraints
→ check absence/trap paths
→ check commit obligations
→ emit operator-typed AST
→ lower to PMS-IR
```

Pipeline form:

```text
Δ symbol/type resolution
Ω role/capability checking
□ frame checking
Χ boundary-projection checking
Ψ policy checking
Θ evaluation/order checking
Λ absence checking
Φ trap checking
Σ commit checking
Α pattern expansion checking
```

This pipeline aligns the type system with PMS-IR generation.

This section specifies the pipeline architecture. It does not claim that a complete PMSL type checker or compiler already implements every stage.

### 5.26 Type Inference

PMSL may infer types, effects, and obligations.

Example:

```pmsl
let x = 1
```

inference:

```text
x : Int
effects(Δ, ∇, Σ)
```

Example:

```pmsl
FS.write(path, data)
```

inference requires the known standard-library profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
requires Ω(fs.write)
requires path boundary visibility
```

Inference is allowed only when obligations are reconstructable.

If inference cannot recover:

```text
required authority
active policy
boundary visibility
absence path
trap path
commit behavior
```

the compiler must require explicit annotation or reject the construct.

AI-proposed type annotations, effect clauses, or PMS-IR fragments do not bypass this rule. They remain proposal artifacts until host-side parsing, canonicalization, mapping, validation, and profile acceptance succeed.

### 5.27 Type-Level Policies and Contracts

PMSL policies may appear at type level.

Examples:

```pmsl
type SafePath = Path where Ψ(path.starts_with("/home/"))
type NonEmptyString = String where Ψ(len > 0)
type ReadOnly<T> = T where Ψ(no ∇ mutation)
```

Function contracts:

```pmsl
fn open(path: SafePath)
    -> Result<Handle<ReadOnly>, Φ_trap<IOError>>
    requires Ω(fs.read)
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
```

Contract checking:

```text
preconditions check before body
postconditions check before return/Σ
invariants hold across visible transitions
policy denial produces Ψ/Φ outcome
```

Type-level policies are part of Ψ, not a new PMS Base operator.

Passing a type-level contract check is profile-local conformance. It does not validate PMS Base and does not by itself prove implementation correctness.

### 5.28 Type-Level Effects and Effect Guards

Effect guards constrain operator effects.

Example:

```pmsl
fn pure_hash(data: Bytes) -> Hash
    effects(Δ, ∇)
    ensures Ψ(no_io, no_boundary_crossing, no_policy_mutation)
```

Example:

```pmsl
fn update_index(idx: Index, item: Item)
    -> Result<Σ_tx<Index>, Φ_trap<IndexError>>
    effects(Δ, Ω, Ψ, ∇, Σ, Φ)
```

Effect guard rule:

```text
declared effect set must contain all effects produced by body
```

and:

```text
active frame/policy must permit declared effects
```

This supports linting, model checking, and verification in later sections.

Effect guards are not proof by themselves. They create explicit obligations that tools, runtimes, model checkers, or proof artifacts may check under declared assumptions.

### 5.29 Type-Level Absence and Trap Separation

PMSL keeps Λ and Φ distinct.

```text
Λ = expected non-event or absence under a frame
Φ = recontextualization, trap, exception, recovery, or fallback
```

Example:

```pmsl
fn poll(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message>>
```

No message is a normal absence path.

Example:

```pmsl
fn read(path: Path)
    -> Result<Bytes, Φ_trap<IOError>>
```

I/O failure is a recontextualized error path.

Example mixed form:

```pmsl
fn recv_or_fail(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message> | Φ_trap<RecvError>>
```

Type checker obligation:

```text
callers must handle or propagate both absence and trap forms separately
```

This separation prevents generic error handling from erasing PMSL operator structure.

### 5.30 Type-Level Commit Discipline

Commit types prevent visibility confusion.

Example:

```pmsl
fn write_buffer(buf: Bytes) -> Staged<Bytes>
```

does not promise durability.

```pmsl
fn flush(buf: Staged<Bytes>) -> Result<Σ_durable<Bytes>, Φ_trap<IOError>>
```

does promise durable commit if successful under the declared backend/runtime profile.

Commit modes:

```text
Staged<T>
Visible<T>
Committed<T>
Σ_local<T>
Σ_tx<T>
Σ_durable<T>
Σ_delivery<T>
Σ_audit<T>
```

Rule:

```text
T
```

is not interchangeable with:

```text
Σ_durable<T>
```

unless a declared proof artifact under stated assumptions, runtime commit evidence, backend profile, or policy-approved coercion exists.

Commit typing does not turn execution into proof. It records and constrains the integration claim a program is making.

### 5.31 Type-Level Boundary Transfer

Boundary transfer requires Χ-typed evidence.

Example:

```pmsl
fn export_to_sandbox<T>(
    value: T,
    target: Boundary<Sandbox>
) -> Result<Transferred<T, Sandbox>, Φ_trap<BoundaryFault>>
    effects(Δ, Ω, Χ, Ψ, Φ, Σ)
```

Transfer validity:

```text
source boundary can expose value
target boundary can receive value
role can transfer
policy permits transfer
value representation is safe or transformed
commit records transfer state
```

No value may silently cross a boundary by ordinary assignment.

Here `Χ-typed evidence` means PMSL/PMS-IR evidence for a layer-projected boundary transfer. It does not redefine PMS Base Χ.

### 5.32 Type-Level Role Transitions

Role transitions are Ω-typed operations.

Example:

```pmsl
with role LogWriter {
    FS.write(path, data)
}
```

Type rule:

```text
current role environment may enter LogWriter
∧ LogWriter has required capabilities
∧ active policy permits role activation
∧ role scope closes on exit
```

Role transition type:

```text
RoleScope<R, T>
```

meaning:

```text
computation T performed under role R
```

Role escalation must be explicit:

```text
R_current → R_target valid iff R_target ∈ escalation(R_current)
∧ Ψ permits escalation
```

Role typing is authority typing. It does not override policy, boundary, frame, absence, trap, or commit obligations.

### 5.33 Type-Level Pattern Expansion

Pattern types ensure Α is safe.

Example:

```pmsl
pattern bracket<Resource>(acquire, use, release) {
    let r = acquire()
    trap on Φ_trap<any> {
        release(r)
    }
    let x = use(r)
    release(r)
    return x
}
```

Pattern type obligations:

```text
acquire effects declared
use effects declared
release effects declared
trap path closes resource
commit or rollback state is defined
expanded operator word is valid
```

This makes reusable patterns analyzable rather than syntactic tricks.

A pattern may propose a reusable operator structure. It becomes admissible only if expansion, type obligations, effect obligations, absence paths, trap paths, boundary obligations, and commit behavior remain valid.

### 5.34 Typed PMS-IR Emission

After type checking, a PMSL toolchain may emit typed PMS-IR.

Typed IR node:

```text
TypedIRNode = (
    id,
    op,
    construct,
    value_type,
    effect_type,
    frame_type,
    role_type,
    policy_type,
    boundary_type,
    absence_type?,
    trap_type?,
    commit_type?,
    children,
    source_span
)
```

Example:

```pmsl
commit Σ {
    FS.write(path, data)
}
```

Typed PMS-IR outline:

```text
IR.Commit {
    op: Σ,
    commit_type: Σ_tx<FileWrite>,
    policy_type: ActivePolicy,
    children: [
        IR.Call {
            op: ∇,
            callee: FS.write,
            effects: Effect<Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ>,
            role_requirement: Capability<fs.write>,
            boundary_requirement: BoundaryVisibility<active_namespace>,
            trap_type: Φ_trap<IOError>,
            absence_type: Λ_absent<Target>?
        }
    ]
}
```

Typed PMS-IR is the substrate for Sections 13–16.

Typed PMS-IR emission is a toolchain obligation. This section specifies its architecture; it does not claim a complete PMSL compiler already emits every typed PMS-IR node form.

### 5.35 Structural Type Soundness

PMSL type soundness is structural.

A conventional soundness claim says:

```text
well-typed programs do not get stuck
```

PMSL refines this:

```text
well-typed PMSL programs do not perform operator-invalid transitions
within the declared frame, role, policy, boundary projection, effect,
absence, trap, and commit context.
```

Informal preservation target:

```text
If Γ ; F ; R ; P ; Bχ ; E ⊢ e : T ! ε
and e → e',
then Γ' ; F' ; R' ; P' ; Bχ' ; E' ⊢ e' : T' ! ε'
```

provided the transition is permitted by the active operator rules.

Informal progress target:

```text
A well-typed construct is either:
    a value,
    able to take a valid operator step,
    waiting through a typed Λ path,
    recontextualizing through a typed Φ path,
    or closed through a typed Σ/Ψ outcome.
```

This is not a machine-checked proof in this document.

It is the structural soundness target of PMSL.

A future proof artifact may prove stated properties under a declared formal semantics and assumptions. Such a proof would prove those stated properties under those assumptions; it would not by itself validate PMS Base.

### 5.36 Example: Fully Typed Fragment

Example:

```pmsl
module app.log

role LogWriter {
    cap fs.write("/var/log/**")
    cap log.append
}

policy P_audit {
    allow fs.write where path.starts_with("/var/log/")
    require log.audit
}

fn write_log(path: Path, data: Bytes)
    -> Result<Σ_durable<Unit>, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(LogWriter), Ψ(P_audit)
{
    policy with P_audit {
        commit Σ {
            FS.write(path, data)
            Log.info("written")
        }
    }
}
```

Typing environment:

```text
Γ contains:
    path : Path
    data : Bytes
    FS.write : FunctionType
    Log.info : FunctionType
    LogWriter : RoleType
    P_audit : PolicyType
```

Active structural context:

```text
F  = FunctionFrame(write_log)
R  = LogWriter
P  = P_audit
Bχ = active namespace boundary projection
E  = Effect<Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ>
```

Typing obligations:

```text
path : Path
data : Bytes
LogWriter has fs.write("/var/log/**")
P_audit permits path.starts_with("/var/log/")
active boundary projection permits FS visibility
FS.write effects fit declared function effects
commit block closes write/log effects
IOError trap is returned or handled
durable commit claim is supported by FS.write profile and backend policy
```

Operator reading:

```text
Δ classify module, role, policy, function, path, calls
Ω verify LogWriter capabilities
Ψ activate P_audit and check rules
Χ check projected namespace visibility
∇ perform write/log effects
Σ commit durable result under declared backend profile
Φ return or trap on IO failure
Λ expose no-target/no-resource if profile permits
```

This example illustrates the type-system architecture. It does not assert that this exact PMSL source already executes unchanged in a complete PMSL compiler.

### 5.37 Type Errors

PMSL type errors are operator-typed diagnostics.

Examples:

| Error                     | Operator reading                 |
| ------------------------- | -------------------------------- |
| unknown symbol            | Δ failure                        |
| invalid assignment        | ∇ / Ω / Ψ failure                |
| frame not visible         | □ / Χ-projection failure         |
| missing capability        | Ω failure                        |
| policy denial             | Ψ failure                        |
| unhandled timeout         | Λ failure                        |
| unhandled exception       | Φ failure                        |
| uncommitted staged effect | Σ failure                        |
| unsafe FFI call           | Φ / Χ projection / Ω / Ψ failure |
| invalid pattern expansion | Α / Ψ failure                    |
| effect not declared       | EffectType failure               |

Example diagnostic:

```text
type error:
    FS.write requires Capability<fs.write("/var/log/**")>
    active role User does not provide it
operator:
    Ω
source:
    FS.write(path, data)
```

Diagnostics should preserve:

```text
operator class
source span
failed obligation
active frame
active role
active policy
active boundary projection
declared effect profile
```

A diagnostic is a tooling result under a declared profile. It is not PMS Base validation.

### 5.38 Type-System Invariants

PMSL maintains the following type-system invariants.

```text
I1: every expression has a data type or an explicit non-value type
I2: every construct has an operator effect profile
I3: every frame-dependent construct has a valid FrameType
I4: every protected construct has RoleType/CapabilityType obligations
I5: every policy-governed construct has a PolicyType context
I6: every boundary-crossing construct has a BoundaryType or ProcessType context
I7: every absence-capable construct exposes a Λ type or handles it
I8: every trap-capable construct exposes a Φ type or handles it
I9: every commit-capable construct exposes a Σ type or closes the effect
I10: every pattern type expands to a valid operator-typed form
I11: every function body fits its declared type and effect profile
I12: every module preserves import/export authority and boundary rules
I13: every foreign type preserves host-boundary semantics
I14: subtyping may restrict authority but may not silently weaken policy
I15: type inference may infer obligations only when they are reconstructable
I16: typed PMS-IR preserves the type/effect/frame/role/policy/boundary profile
I17: Χ-typed boundary structures remain PMSL/PMS-IR projections of PMS Base Χ = Distance
I18: AI-proposed type annotations, effects, or PMS-IR fragments remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are architecture-level PMSL conformance constraints.

They are not claims that a complete toolchain already enforces every invariant.

### 5.39 Boundary to Later Sections

This section defines the PMSL type system.

It does not fully define:

| Topic                                      | Primary section |
| ------------------------------------------ | --------------- |
| IPC and channel runtime behavior           | Section 6       |
| error, trap, and absence handling details  | Section 7       |
| module loading/linking/versioning          | Section 8       |
| FFI ABI and host interoperability          | Section 9       |
| runtime architecture                       | Section 10      |
| standard library type profiles             | Section 11      |
| concurrency and IO APIs                    | Section 12      |
| PMS-IR full node format                    | Section 13      |
| static analysis and linting implementation | Section 14      |
| model checking and verification            | Section 15      |
| debugging and observability                | Section 16      |
| simulation and emulation                   | Section 17      |
| examples                                   | Section 18      |

Those sections refine the type-system structures defined here.

### 5.40 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for parts of the type-system-adjacent implementation path.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This strengthens implementation-artifact claims for bounded executable slices.

It does not complete:

```text
PMSL type checker
PMSL compiler
PMS-IR optimizer
PMSL standard library
PMSL runtime
PMS-CPU
PMS-OS
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is therefore evidence for bounded artifact behavior, not proof of the PMSL type-system specification and not validation of PMS Base.

### 5.41 AI Type-System Boundary

The AI Bridge may propose:

```text
type annotations
effect clauses
capability requirements
policy hints
PMS-IR fragments
opcode programs
diagnostic explanations
missing-obligation hypotheses
trace-analysis summaries
```

It may not function as:

```text
PMSL semantics
type-checker authority
compiler authority
verifier authority
policy authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output is not PMSL source authority, not PMS-IR truth, not verification evidence, not trusted executable code, and not PMS Base validation.

### 5.42 Architectural Consequence

The consequence of the PMSL type system is:

```text
PMSL types are operator-validity contracts. They classify values, frames,
roles, capabilities, policies, boundary projections, effects, absences,
traps, commits, modules, channels, tasks, patterns, and foreign calls so
that source programs lower into PMS-IR without losing Δ–Ψ structure.
```

This gives PMSL its central language-level discipline: a well-typed PMSL program is not merely value-consistent; it is structurally admissible under the active operator context.

### 5.43 Type-System Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL type system specifies operator-validity contracts for values,
frames, roles, capabilities, policies, boundary projections, effects,
absences, traps, commits, modules, channels, tasks, patterns, foreign
calls, typed PMS-IR emission, and structural soundness targets.

This is a language type-system / operator-validity architecture claim.

It does not claim a completed PMSL type checker, completed compiler,
completed verifier, completed proof engine, completed runtime, completed
standard library, completed PMSL implementation, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR and does not validate
PMS Base.
```

---

## 6. Concurrency and IPC in PMSL

PMSL defines concurrency and IPC as operator-typed coordination.

A PMSL concurrent program is not a set of raw threads sharing memory. It is a system of task frames, channel frames, message types, wait states, ordering relations, capability gates, boundary projections, absence paths, commit points, trap paths, and active policies.

The central concurrency claim is:

```text
PMSL concurrency is valid when tasks, channels, messages, waits, events,
locks, cancellations, joins, and delivery guarantees lower to PMS-IR as
□-framed, Δ-classified, Ω-authorized, Χ-projected, Θ-ordered,
Λ-aware, ∇-executed, Σ-committed, Φ-recontextualized, and
Ψ-constrained coordination structures.
```

This section defines concurrency and IPC at the PMSL language/runtime specification level.

The OS substrate is defined in `04_pms_os.md`.

Distributed messaging, cross-node event delivery, cluster-level consistency, replication, distributed fault domains, and inter-node protocols are defined in `07_distributed_systems.md`.

Claim type:

```text
LANGUAGE CONCURRENCY / IPC ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL concurrency and IPC as operator-typed
language/runtime architecture.

It does not claim a completed PMSL runtime, completed scheduler,
completed standard-library concurrency implementation, completed IPC
backend, completed distributed runtime, completed PMS-OS kernel, or
completed PMSL compiler.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared type-system, runtime, backend, scheduler, IPC, tool, conformance, simulation, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, scheduler fairness, distributed correctness, theoretical adequacy, or full behavioral coverage.

### 6.1 Concurrency Model

PMSL concurrency uses structured execution loci.

The primary source-level constructs are:

```text
task
spawn
await
cancel
channel<T>
send
recv
select
event
timer
mutex
rwlock
semaphore
condvar
task_group
supervisor
```

The primary semantic entities are:

```text
TaskFrame
ChannelFrame
MessageFrame
SyncFrame
EventFrame
WaitFrame
CancellationFrame
SupervisorFrame
```

The common coordination pattern is:

```text
Δ classify task/channel/message/sync object/event
Ω check authority
Χ check projected visibility, boundary, sandbox, module, runtime, or host relation
Ψ check policy
Θ order scheduling, waiting, delivery, or wakeup
Λ represent absence, timeout, no-space, no-message, or not-ready
∇ mutate queue, task state, sync state, or event state
Σ commit creation, delivery, wakeup, cancellation, join, or closure
Φ recontextualize on trap, cancellation, failed delivery, or invalid state
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR concurrency level, Χ is projected as:

```text
task boundary
channel visibility
endpoint reachability
sandbox separation
module/runtime boundary
host boundary
shared-memory boundary
IPC visibility
cross-frame transfer discipline
```

This aligns PMSL concurrency with the OS-level IPC substrate while preserving language-level types, effects, source spans, and PMS-IR analyzability.

### 6.2 Task Frames

A PMSL task is a typed concurrent execution frame.

```text
TaskFrame = (
    id,
    name,
    parent,
    body,
    state,
    role,
    boundary,
    policy,
    scheduler,
    resources,
    result,
    meta
)
```

where:

| Field | Meaning |
| ----- | ------- |
| `id` | task identifier |
| `name` | optional source-level name |
| `parent` | parent task or task group |
| `body` | PMS-IR body |
| `state` | NEW, READY, RUNNING, BLOCKED, CANCELLED, COMPLETED, FAILED |
| `role` | Ω role/capability context |
| `boundary` | PMSL/PMS-IR task-boundary projection of Χ |
| `policy` | Ψ task policy |
| `scheduler` | Θ scheduling profile |
| `resources` | task resource account or runtime resource profile |
| `result` | typed result or trap/absence state |
| `meta` | trace, timing, source span, diagnostic metadata |

A task is valid when:

```text
task body type-checks
∧ task frame can be created
∧ spawn authority exists
∧ boundary projection can be established
∧ policy permits task creation
∧ task result type is known
∧ cancellation behavior is defined
∧ join/await behavior is defined
```

A task frame is a language/runtime structure. It may lower to a host async task, host thread, PMS-RUST-style deterministic event, simulator task, future PMS-OS thread/process, or another declared backend profile. The backend may vary; the operator obligations must remain visible.

### 6.3 Spawn

`spawn` creates a task frame and schedules it.

Syntax:

```pmsl
spawn task Worker {
    process_messages(inbox)
}
```

Primary operators:

```text
□ / Θ
```

Lowering:

```text
Δ classify task declaration
Δ classify task body and result type
Ω verify spawn authority
□ create TaskFrame
Χ establish projected task boundary
Ψ attach task policy
Θ enqueue task for scheduling
Σ commit task creation
```

PMS-IR sketch:

```text
IR.Spawn {
    op: □/Θ,
    task_name: Worker,
    frame: TaskFrame,
    body: IR.Block,
    role_requirement: Ω?,
    boundary: Χ_projection?,
    policy: Ψ?,
    commit: Σ_create_task
}
```

Spawn failure paths:

```text
missing spawn capability       → Ω / Ψ denial
task frame cannot be created   → Λ no-resource or Φ runtime trap
boundary cannot be established → Χ projection / Φ
policy denies creation         → Ψ
scheduler cannot enqueue       → Λ not-ready or Φ runtime trap
```

Spawn invariants:

```text
I1: every spawned task has a TaskFrame
I2: every task has a parent or explicit detached policy
I3: task creation is not visible until Σ commit
I4: task boundary projection is known before scheduling
I5: task body effects fit task policy
I6: task result, cancellation, and trap behavior are typed
```

### 6.4 Await and Join

`await` orders the current task on another task, future, event, channel, or completion object.

Syntax:

```pmsl
let result = await Worker
```

Primary operator:

```text
Θ
```

Secondary operators:

```text
Λ, Σ, Φ
```

Lowering:

```text
Δ classify awaited object
Ω verify await/join authority
Χ verify projected visibility
Ψ check await policy
Θ create wait relation
Λ represent not-ready if completion absent
Σ integrate result if completed
Φ recontextualize if awaited task failed or was cancelled
```

Await result type:

```pmsl
await Worker : Result<T, Λ_absent<T> | Φ_trap<TaskError>>
```

A blocking await:

```text
await Worker
```

may suspend the current task until completion.

A bounded await:

```pmsl
await Worker timeout 50ms
```

adds explicit Λ behavior:

```text
Θ wait until deadline
Λ if completion absent
```

Await invariants:

```text
I1: awaited object is distinguishable
I2: caller may observe completion
I3: wait state is explicit
I4: timeout produces Λ, not untyped failure
I5: successful completion integrates through Σ
I6: failed completion recontextualizes through Φ
I7: invisible or unauthorized awaited objects are rejected through Χ projection / Ω / Ψ
```

### 6.5 Cancellation

Cancellation is a Φ/Ψ-controlled lifecycle recontextualization.

Syntax:

```pmsl
cancel Worker
```

or:

```pmsl
cancel Worker reason Timeout
```

Primary operator:

```text
Φ
```

Lowering:

```text
Δ classify target task
Ω verify cancellation authority
Χ verify projected task visibility
Ψ check cancellation policy
Φ recontextualize task lifecycle
Θ order cancellation delivery
Σ commit cancellation state
```

Cancellation may be:

```text
cooperative
forced
deferred
scope-bound
deadline-bound
policy-denied
```

Cancellation type:

```text
CancelResult<T> =
    Cancelled
  | AlreadyCompleted<T>
  | Denied<Ψ>
  | Failed<Φ_trap<CancellationError>>
```

Cancellation invariants:

```text
I1: cancellation target is distinguishable
I2: caller may cancel target
I3: cancellation policy is active
I4: cancellation does not erase committed effects
I5: partially staged effects are committed, rolled back, or explicitly abandoned by policy
I6: cancellation propagates only along declared task hierarchy or capability relation
I7: cancellation result is integrated or propagated through typed Σ/Φ/Ψ outcomes
```

Cancellation is not an untyped kill primitive. It is a policy-governed recontextualization of task lifecycle.

### 6.6 Task Groups

A task group is a structured parent frame for multiple tasks.

Syntax:

```pmsl
task_group Workers {
    spawn task A { work_a() }
    spawn task B { work_b() }

    await all
}
```

Semantic entity:

```text
TaskGroupFrame = (
    id,
    children,
    policy,
    boundary,
    supervisor,
    result_policy,
    cancellation_policy,
    meta
)
```

Primary operators:

```text
□, Θ, Σ, Ψ
```

Task group lowering:

```text
□ create task-group frame
Ψ attach group policy
Χ establish projected group boundary
Θ order child task scheduling
Σ commit group lifecycle state
```

Group completion modes:

```text
await all
await any
await quorum(n)
await until policy condition
cancel remaining on first failure
continue on failure
```

Operator reading:

```text
await all       → Θ wait for all completions + Σ integrate set
await any       → Θ wait for first completion + Λ for absent others if bounded
quorum(n)       → Δ count completions + Θ order arrivals + Σ integrate quorum
failure policy  → Φ/Ψ recontextualization
```

Task groups provide structured concurrency: children cannot disappear outside their parent lifecycle unless explicitly detached under policy.

Task group validity requires:

```text
child lifecycle is closed, awaited, cancelled, or detached under policy
∧ group result policy is explicit
∧ group failure behavior is typed
∧ group boundary projection is preserved
```

### 6.7 Detached Tasks

Detached tasks require explicit policy.

Syntax:

```pmsl
spawn detached task Maintenance {
    run_periodic_cleanup()
}
```

Detached task validity:

```text
Ω permits detachment
∧ Ψ defines lifecycle owner
∧ resource account or runtime resource profile exists
∧ cancellation or shutdown path exists
∧ trace/audit policy is defined where required
∧ boundary projection is explicit
```

Detached tasks may be useful for:

```text
runtime services
background cleanup
event routers
timer services
log flushing
supervisors
```

A detached task is invalid when it has no lifecycle owner, no cancellation path, no boundary discipline, or no resource policy.

Detachment is not a loophole out of structured concurrency. It is an explicit lifecycle transition governed by Ω, Χ projection, Ψ, Θ, Φ, and Σ.

### 6.8 Channels

A PMSL channel is a typed communication endpoint.

Syntax:

```pmsl
channel inbox: channel<Message>
```

Semantic frame:

```text
ChannelFrame<T> = (
    id,
    payload_type,
    direction,
    buffer,
    capacity,
    closed,
    wait_send,
    wait_recv,
    send_role,
    recv_role,
    boundary,
    ordering,
    delivery,
    policy,
    meta
)
```

Channel direction may be:

```text
send_only
recv_only
bidirectional
request_response
broadcast
```

Channel capacity may be:

```text
zero_capacity
bounded(n)
unbounded_by_policy
latest_value
```

Channel declaration lowering:

```text
Δ classify channel name and payload type
□ create ChannelFrame<T>
Ω attach send/receive capabilities
Χ attach projected visibility boundary
Ψ attach channel policy
Σ commit channel declaration
```

Channel invariants:

```text
I1: every channel has a payload type
I2: every channel has a projected visibility boundary
I3: send and receive capabilities are explicit
I4: buffer capacity is policy-defined
I5: close behavior is defined
I6: absence/no-space behavior is typed
I7: delivery profile is explicit where guarantees are claimed
```

A channel is not merely a queue. It is a typed communication frame with authority, boundary projection, ordering, absence, delivery, trap, commit, and policy semantics.

### 6.9 Send

`send` transmits a typed message into a channel.

Syntax:

```pmsl
send inbox <- msg
```

or explicit block form:

```pmsl
send inbox {
    msg
}
```

Primary operator:

```text
∇
```

Lowering:

```text
Δ classify channel
Δ classify payload
Δ verify payload type matches Channel<T>
Ω verify SEND capability
Χ verify sender can reach channel under projected boundary rules
Ψ check channel policy
∇ enqueue or deliver message
Θ order delivery / wake receiver
Σ commit send state
Φ handle invalid channel, closed channel, policy denial, or malformed payload
Λ no-space if nonblocking and buffer full
```

Send type:

```pmsl
send inbox <- msg : Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<SendError>>
```

Send profiles:

```text
blocking send
nonblocking send
timed send
best-effort send
committed send
transactional send
```

Examples:

```pmsl
send inbox <- msg
```

```pmsl
send inbox <- msg timeout 50ms
```

```pmsl
try_send inbox <- msg
```

Send invariants:

```text
I1: payload type matches channel type
I2: sender has SEND capability
I3: channel boundary is visible to sender
I4: channel policy permits delivery
I5: buffer mutation is ∇-represented
I6: delivery visibility is Σ-defined
I7: full-buffer behavior is Λ/Θ/Φ/Ψ-defined
```

A send operation that appears successful without exposing delivery, staging, absence, trap, or policy outcome is not PMSL-conformant.

### 6.10 Receive

`recv` receives a typed message from a channel.

Syntax:

```pmsl
let msg = recv inbox
```

Timed receive:

```pmsl
let msg = recv inbox timeout 50ms
```

Receive with handler:

```pmsl
recv inbox timeout 50ms on timeout {
    handle_absence()
}
```

Primary operators:

```text
Λ / ∇
```

Lowering:

```text
Δ classify channel
Ω verify RECEIVE capability
Χ verify receiver can observe channel under projected boundary rules
Ψ check receive policy
Θ order receive attempt or wait
Λ represent no-message if absent
∇ dequeue message if present
Σ commit receive state
Φ handle malformed message, closed channel, or trap policy
```

Receive type:

```pmsl
recv inbox : Result<Message, Λ_absent<Message> | Φ_trap<RecvError>>
```

Blocking receive:

```text
if no message:
    Θ enqueue receiver in wait_recv
    Λ wait until message or timeout
```

Nonblocking receive:

```text
if no message:
    Λ no-message
```

Receive invariants:

```text
I1: receiver has RECEIVE capability
I2: channel boundary is visible to receiver
I3: absence is represented through Λ
I4: dequeued payload is type-checked
I5: receive state commits through Σ
I6: closed-channel behavior is typed
```

PMSL receive semantics distinguish absence, trap, policy denial, and commit failure. They are not interchangeable.

### 6.11 Select

`select` waits on multiple communication or event sources.

Syntax:

```pmsl
select {
    msg = recv inbox => handle_msg(msg)
    ev  = recv events => handle_event(ev)
    timeout 100ms => handle_timeout()
}
```

Primary operators:

```text
Δ, Θ, Λ
```

Lowering:

```text
Δ classify selectable arms
Ω verify authority for each endpoint
Χ verify projected visibility for each endpoint
Ψ check select policy
Θ order readiness evaluation
Λ represent no-ready-source or timeout
∇ execute selected arm
Σ integrate selected result
Φ handle invalid or failed selected arm
```

Selection policies:

```text
first-ready
fair
priority
randomized
deadline
source-order
policy-defined
```

Select invariants:

```text
I1: every arm is type-checked
I2: every endpoint is authority-checked
I3: readiness ordering is Θ-defined
I4: timeout/no-ready-source is Λ-defined
I5: selected arm result merges with other arms
I6: unselected arms do not mutate state unless policy defines readiness side effects
```

A `select` construct is valid only if readiness, timeout, authority, boundary projection, and result-merge behavior remain visible in PMS-IR.

### 6.12 Request/Response

Request/response is an Α pattern over channels or mailboxes.

Syntax:

```pmsl
let response = request server <- Request(data) timeout 500ms
```

Semantic pattern:

```text
Α_REQRESP(client, server)
```

Lowering:

```text
client:
    Δ classify request
    Ω check send authority
    Χ check projected server endpoint visibility
    Ψ check request policy
    ∇ enqueue request
    Σ commit request visibility

server:
    Δ inspect request queue
    Ω check receive authority
    Χ check projected client/server relation
    ∇ dequeue request
    ∇ execute handler

server:
    Δ classify response
    Ω check reply authority
    Χ check projected reply endpoint
    Ψ check response policy
    ∇ enqueue response
    Σ commit response

client:
    Θ wait for response
    Λ timeout if absent
    ∇ dequeue response if present
    Φ recontextualize on error response
    Σ integrate response
```

Request type:

```pmsl
Request<TReq, TResp>
```

Response type:

```pmsl
Result<TResp, Λ_absent<TResp> | Φ_trap<RequestError>>
```

Request/response invariants:

```text
I1: request and response types are paired
I2: client may send request
I3: server may receive request
I4: server may reply to client
I5: timeout path is explicit
I6: response commit is defined
I7: error response is Φ-typed or result-typed
```

Request/response is a reusable protocol pattern, not a primitive that bypasses channel, policy, boundary, authority, absence, or commit obligations.

### 6.13 Mailboxes and Queues

A mailbox is a process/task/service-owned receive endpoint.

```text
Mailbox<T> = ChannelFrame<T> with owner-receive semantics
```

A queue is a multi-producer or multi-consumer communication frame.

```text
Queue<T> = ChannelFrame<T> with shared production/consumption semantics
```

Mailbox role profile:

```text
owner may receive
authorized peers may send
policy may allow inspection or signal delivery
```

Queue role profile:

```text
producers may send
consumers may receive
policy governs fairness and capacity
```

PMSL declarations:

```pmsl
mailbox inbox: mailbox<Message>
queue jobs: queue<Job> capacity 1024
```

Operator reading:

```text
Δ classify endpoint
□ create endpoint frame
Ω assign producer/consumer/owner roles
Χ define projected endpoint visibility
Ψ attach endpoint policy
Σ commit endpoint declaration
```

Mailbox and queue constructs are channel profiles. They do not introduce new base operators.

### 6.14 Events

Events are typed transition triggers.

Syntax:

```pmsl
event UserLoggedIn(user_id: UserId)

subscribe events.UserLoggedIn as ev {
    handle_login(ev)
}
```

Event type:

```text
Event<T> = (
    kind,
    payload_type,
    source,
    target,
    policy,
    delivery,
    meta
)
```

Event publish lowering:

```text
Δ classify event kind and payload
Ω verify publish authority
Χ verify projected topic/event visibility
Ψ check event policy
∇ enqueue event
Θ order dispatch
Σ commit event publication
```

Event receive/dispatch lowering:

```text
Δ classify event subscription
Ω verify receive authority
Χ verify projected subscriber visibility
Ψ check subscription policy
Θ dispatch event
∇ execute handler
Σ commit handler result if required
Φ handle failed handler
Λ no-event if bounded wait expires
```

Events provide a language-level surface for timer events, IPC notifications, runtime events, filesystem events, policy events, and user-defined events.

An event is not automatically delivered merely because it is declared. Delivery depends on declared runtime/backend profile, policy, boundary visibility, scheduling, and commit semantics.

### 6.15 Timers and Timeouts

Timers create Θ/Λ coordination.

Syntax:

```pmsl
timer every 1s as tick {
    send heartbeat <- Tick()
}
```

Timeout syntax:

```pmsl
recv inbox timeout 50ms
```

Timer entity:

```text
TimerFrame = (
    id,
    deadline,
    interval,
    target,
    policy,
    state,
    meta
)
```

Timer creation lowering:

```text
Δ classify timer
Ω verify timer authority
Ψ check timer policy
Θ register deadline/order
Σ commit timer registration
```

Timer firing:

```text
Θ compare ordered deadline
Λ if timer event absent or missed under policy
∇ enqueue timer event
Σ commit event visibility
Φ handle timer failure or cancellation
```

PMSL distinguishes:

```text
duration value
deadline
timer event
timeout absence
scheduled task
```

These must not collapse into one untyped time primitive.

Timer behavior is profile-bound. PMSL may specify timing obligations; concrete precision, jitter, dispatch latency, and clock source semantics belong to declared runtime/OS profiles.

### 6.16 Synchronization Primitives

PMSL may expose synchronization primitives as typed wrappers over SyncFrames.

Primitive families:

```text
Mutex<T>
RwLock<T>
Semaphore
CondVar
Barrier
Latch
Futex<T>
Atomic<T>
```

Generic sync object:

```text
Sync<T> = (
    frame,
    protected_value,
    state,
    waiters,
    roles,
    policy,
    meta
)
```

General sync operation pattern:

```text
Δ inspect primitive state
Ω check operation capability
Χ verify projected visibility
Ψ check synchronization policy
Θ order waiters if blocking
Λ represent timeout/unavailable state
∇ mutate sync state
Σ commit lock/wake/state transition
Φ handle invalid state or owner death
```

Synchronization primitives are useful where shared state is required.

PMSL nevertheless keeps message passing and structured tasks as the primary concurrency surface because they preserve boundaries and effect profiles more directly.

Low-level synchronization is a profile-governed systems surface, not an untyped escape from task/channel discipline.

### 6.17 Mutex

Syntax:

```pmsl
let lock: Mutex<State> = Mutex.new(state)

with lock.lock() as state {
    state.count = state.count + 1
}
```

Mutex lock lowering:

```text
Δ classify mutex state
Ω verify LOCK capability
Χ verify projected mutex visibility
Ψ check lock policy
if unlocked:
    ∇ set owner/current state
    Σ commit lock
else:
    Θ enqueue waiter
    Λ wait or timeout
```

Mutex unlock lowering:

```text
Δ verify owner
Ω verify UNLOCK capability
∇ release lock
Θ wake waiter if present
Σ commit unlock
Φ on invalid owner or poisoned lock
```

Mutex invariants:

```text
I1: protected value is accessed only while lock is held
I2: lock acquisition is authority-checked
I3: lock wait is Θ/Λ represented
I4: unlock is owner-validated
I5: poisoning or owner death is Φ/Ψ-defined
I6: lock visibility respects Χ-projected boundary rules
```

Mutexes type shared state access. They do not erase policy, absence, trap, ordering, boundary, or commit obligations.

### 6.18 RwLock

Syntax:

```pmsl
with cache.read() as c {
    inspect(c)
}

with cache.write() as c {
    update(c)
}
```

RW-lock state:

```text
RwLockState = (
    readers,
    writer_active,
    reader_waiters,
    writer_waiters,
    policy
)
```

Read lock:

```text
Δ check writer_active = false
Ω verify READ_LOCK capability
Ψ check reader/writer policy
∇ readers := readers + 1
Σ commit read lock
```

Write lock:

```text
Δ check readers = 0 and writer_active = false
Ω verify WRITE_LOCK capability
Ψ check writer policy
∇ writer_active := true
Σ commit write lock
```

If unavailable:

```text
Θ enqueue waiter
Λ wait or timeout
```

Policy may define:

```text
reader preference
writer preference
FIFO fairness
priority inheritance
maximum hold time
```

RW-lock typing must preserve reader/writer distinction, wait behavior, policy, and visibility. It is not an opaque host lock abstraction.

### 6.19 Semaphore

Syntax:

```pmsl
with permits.acquire() {
    run_limited_work()
}
```

Semaphore state:

```text
SemaphoreState = (
    count,
    max,
    waiters,
    policy
)
```

Acquire:

```text
Δ check count > 0
Ω verify ACQUIRE capability
if available:
    ∇ count := count - 1
    Σ commit acquire
else:
    Θ enqueue waiter
    Λ wait or timeout
```

Release:

```text
Δ check count < max
Ω verify RELEASE capability
∇ count := count + 1
Θ wake waiter if present
Σ commit release
```

Semaphore policy controls fairness, bounds, timeout, and ownership requirements.

Semaphore use is valid only when acquisition, wait, release, ownership, and failure behavior are typed.

### 6.20 Condition Variables

Syntax:

```pmsl
with mutex.lock() as state {
    while !state.ready {
        cond.wait(mutex)
    }
}
```

Wait lowering:

```text
Δ verify associated mutex is held
Ω verify WAIT capability
∇ release mutex
Θ enqueue waiter
Λ wait until signal/broadcast/timeout
Θ resume
∇ reacquire mutex
Σ commit resumed state
```

Signal lowering:

```text
Δ inspect waiters
Ω verify SIGNAL capability
Θ select waiter
Σ commit wake
```

Broadcast lowering:

```text
Δ inspect waiters
Ω verify BROADCAST capability
Θ select all eligible waiters
Σ commit wake set
```

Φ handles invalid mutex relation, owner death, policy violation, or invalid wakeup.

Condition variables are valid only with explicit association, wait ordering, wake semantics, timeout/absence behavior, and recovery paths.

### 6.21 Atomics and Futex-Like Primitives

PMSL may expose low-level atomic primitives for runtime and systems programming.

Syntax examples:

```pmsl
atomic.compare_exchange(ptr, old, new)
futex.wait(word, expected, timeout 50ms)
futex.wake(word, n)
```

Atomic fast path:

```text
Δ classify atomic location and expected value
Ω verify access authority
Χ verify projected memory boundary
∇ perform atomic operation
Σ commit local memory effect
Ψ check memory-order policy
```

Futex wait slow path:

```text
Δ compare memory word
Ω verify wait authority
Θ enqueue waiter
Λ wait or timeout
Φ return on owner death, cancellation, or policy trap
```

Futex wake:

```text
Δ identify waiters
Ω verify wake authority
Θ select waiters
Σ commit wake
```

Low-level primitives are part of PMSL runtime/system profiles. Application profiles may restrict or forbid them.

A low-level primitive is not allowed to bypass PMSL authority, boundary, policy, absence, trap, or commit semantics.

### 6.22 Structured Concurrency

Structured concurrency ensures task lifetimes remain framed.

Core rule:

```text
child task lifetime is contained by parent frame unless explicitly detached
under policy
```

Structured block:

```pmsl
task_group G {
    spawn task A { a() }
    spawn task B { b() }
    await all
}
```

Operator reading:

```text
□ enter task group frame
Θ schedule children
Λ wait for completions
Φ handle child failure/cancellation
Σ integrate group result
□ exit group frame
Ψ enforce group policy
```

Structured concurrency invariants:

```text
I1: child tasks have a parent frame
I2: parent exit requires child lifecycle closure
I3: failure propagation is policy-defined
I4: cancellation propagation is policy-defined
I5: group result integrates through Σ
I6: detached tasks require explicit lifecycle owner
I7: child task boundaries remain visible to analysis
```

Structured concurrency is the default PMSL discipline for task lifecycles. Detached or background work must be explicitly profile- and policy-governed.

### 6.23 Supervisors

A supervisor manages child task policy.

Syntax:

```pmsl
supervisor ServiceSupervisor policy RestartOnFailure {
    spawn task Worker { serve() }
}
```

Supervisor frame:

```text
SupervisorFrame = (
    children,
    restart_policy,
    failure_policy,
    resource_policy,
    boundary,
    meta
)
```

Failure handling:

```text
Δ classify child failure
Ψ evaluate supervisor policy
Φ recontextualize child lifecycle
Θ order restart/backoff
Σ commit new child state or final failure
```

Supervisor policies may include:

```text
restart
backoff
escalate
quarantine
cancel_group
ignore
degrade
halt_service
```

Supervision is an Α pattern over task lifecycle, Φ recovery, Θ retry/backoff, and Ψ policy.

A supervisor is not a governance tribunal. It is a runtime/language policy frame for child-task lifecycle handling.

### 6.24 Backpressure and Flow Control

Backpressure is a first-class Ψ/Λ/Θ condition.

Sources:

```text
full channel
slow receiver
resource quota
scheduler saturation
policy throttle
network or device delay
downstream unavailability
```

Backpressure outcomes:

```text
blocking send     → Θ wait + Λ no-space until resolved
nonblocking send  → Λ no-space
drop policy       → Ψ drop + Σ audit if required
retry policy      → Θ retry
escalation        → Φ recontextualize
```

PMSL backpressure type:

```pmsl
Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<BackpressureError>>
```

Backpressure invariants:

```text
I1: full buffers are not hidden as successful sends
I2: drop policy is explicit
I3: retry ordering is Θ-defined
I4: resource pressure is Ψ-visible
I5: caller observes delivery, staging, absence, or failure according to type
```

Backpressure is therefore part of the typed coordination contract. It must not disappear into opaque runtime scheduling behavior.

### 6.25 Delivery Guarantees

PMSL channels may declare delivery profiles.

```pmsl
channel jobs: channel<Job>
    delivery at_least_once
    capacity 1024
```

Profiles:

```text
best_effort
at_most_once
at_least_once
exactly_once_within_runtime_scope
transactional
latest_value
coalesced
```

Delivery typing:

```text
DeliveryProfile<T> = (
    commit_policy,
    ack_policy,
    retry_policy,
    dedup_policy,
    failure_policy
)
```

Operator readings:

```text
at_most_once:
    Σ commit dequeue
    Ψ forbid duplicate delivery

at_least_once:
    sender retains staged copy
    Λ timeout if no ack
    Θ retry
    Σ commit ack

exactly_once_within_runtime_scope:
    Δ identify message id
    Σ commit delivery
    Ψ reject duplicate
    Φ recover ambiguity
```

Exactly-once is a policy-bound runtime profile, not a universal default.

The phrase `exactly_once_within_runtime_scope` is deliberate. It states a bounded runtime/profile claim. It does not assert distributed exactly-once delivery, backend durability, or cross-node correctness outside the declared profile.

### 6.26 Channel Protocols

A channel may carry a protocol type.

Example:

```pmsl
protocol FileService {
    request Open(Path) -> Result<Handle, Φ_trap<IOError>>
    request Read(Handle, Int) -> Result<Bytes, Φ_trap<IOError>>
    event Closed(Handle)
}
```

Channel declaration:

```pmsl
channel fs: protocol<FileService>
```

Protocol typing ensures:

```text
message kind is Δ-classified
request/response pairs match
sender role can send this message kind
receiver role can handle this message kind
timeout/absence paths are declared
trap/result paths are declared
commit behavior is known
```

Protocol violation:

```text
unknown message kind
wrong payload type
missing response
unauthorized sender
unexpected event
version mismatch
```

maps to:

```text
Δ failure
Ω / Ψ denial
Λ timeout/no-response
Φ protocol trap
```

Protocol typing keeps IPC semantics visible to PMS-IR. It must not collapse message structure into opaque byte streams unless the active profile explicitly models that byte-stream boundary.

### 6.27 Shared Memory IPC

PMSL may support shared memory IPC through explicit frame/boundary typing.

Syntax:

```pmsl
shared frame SharedBuf<Bytes> between A and B policy P_shared {
    // shared access region
}
```

Shared memory validity:

```text
Δ classify shared frame
Ω authorize participants
Χ establish projected bridge boundary
Ψ check sharing policy
□ create shared frame
Σ commit shared visibility
```

Shared memory requires synchronization:

```text
Mutex<T>
RwLock<T>
Atomic<T>
Channel<ControlMessage>
```

Shared memory invariants:

```text
I1: shared frame has explicit participants
I2: boundary bridge is committed
I3: access authority is role-checked
I4: synchronization discipline is declared
I5: lifetime and reclamation are explicit
I6: shared memory does not bypass channel or policy constraints
```

Shared memory is an advanced systems profile. A PMSL implementation profile may restrict or omit it while remaining conformant for non-shared-memory concurrency.

### 6.28 Concurrency Effects

PMSL concurrency constructs carry effects.

Examples:

```pmsl
effects(□, Ω, Χ, Ψ, Θ, Σ)              // spawn
effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)    // send
effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)    // receive
effects(Θ, Λ, Σ, Φ)                   // await
effects(Φ, Ψ, Σ)                      // cancel
effects(Δ, Ω, Θ, Λ, ∇, Σ, Φ, Ψ)       // mutex/condvar
```

A function that performs concurrency must declare or infer these effects.

Example:

```pmsl
fn serve(inbox: channel<Request>)
    -> Result<Unit, Φ_trap<ServiceError>>
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
```

Effect checking ensures that concurrency does not become hidden control flow.

`Effect<Χ>` denotes the PMSL/PMS-IR projection of PMS Base Χ = Distance into endpoint visibility, task boundary, sandbox, shared-memory bridge, module boundary, runtime boundary, or host boundary obligations.

### 6.29 Concurrency Memory Model

PMSL concurrency uses a Θ/Σ/Ψ memory model with Χ-projected visibility.

Core concepts:

```text
program order
task order
channel delivery order
synchronization order
commit visibility
boundary visibility
policy constraints
```

A write becomes visible to another task only when the relevant visibility condition holds.

Examples:

```text
same task local binding:
    Σ local binding sufficient

message passing:
    send Σ_delivery establishes visibility to receiver

mutex:
    unlock Σ establishes visibility to later lock holder under policy

shared memory:
    atomic or lock discipline establishes allowed visibility

boundary crossing:
    Χ-projected transfer relation + Σ commit required
```

Memory-model rule:

```text
visibility requires ordering + commit + boundary permission
```

or:

```text
Visible(value, task_b) iff
    Θ orders producing event before consuming event
    ∧ Σ commits producing state
    ∧ Χ-projected boundary profile permits visibility
    ∧ Ψ permits access
```

This is a PMSL memory-model architecture. It does not assert that every backend already implements the complete memory model.

### 6.30 Fairness and Scheduling

Scheduling is Θ-governed and policy-constrained.

PMSL may expose scheduling hints:

```pmsl
spawn task Worker priority high { ... }
yield
await
sleep 10ms
```

Scheduling policy remains runtime/OS-governed.

PMSL may request:

```text
priority
deadline
fairness class
cooperative yield
bounded wait
background task
real-time-like profile
```

But PMSL cannot directly guarantee OS-level dispatch unless the runtime and OS profile support it.

Scheduling rule:

```text
PMSL expresses scheduling obligations and hints.
Runtime/OS performs Θ dispatch under Ψ policy.
```

Fairness is therefore a profile-bound runtime property. It is not implied by syntax alone.

### 6.31 Resource Accounting

Concurrent PMSL programs consume resources.

Resources include:

```text
task count
channel count
message bytes
queue depth
waiter count
timer count
event backlog
sync object count
task stack/heap
runtime scheduler budget
```

Resource checking:

```text
Δ classify resource event
Ω verify account authority
Ψ check quota
∇ update usage
Σ commit resource accounting
```

Resource failure:

```text
Λ no-resource
Ψ denial
Φ runtime trap
Θ throttle
```

PMSL APIs should expose resource failure paths rather than converting them to untyped exceptions.

Resource accounting at this layer is a runtime/API obligation. PMS-OS resource accounting is specified separately in `04_pms_os.md`.

### 6.32 Runtime and OS Boundary

PMSL concurrency maps onto runtime and OS substrates.

Possible implementation profiles:

```text
green tasks on PMSL runtime scheduler
native OS threads
PMS-OS threads
PMS-UM simulation tasks
PMS-RUST-style deterministic runtime events
host async runtime
hybrid profile
```

The source-level semantics remain:

```text
TaskFrame
ChannelFrame
WaitFrame
SyncFrame
EventFrame
```

The backend may choose concrete mechanisms, but must preserve:

```text
task lifecycle
ordering semantics
boundary checks
capability checks
policy checks
absence behavior
trap behavior
commit behavior
traceability
```

A backend that erases send/receive commit, timeout absence, task boundaries, cancellation policy, endpoint visibility, or policy checks does not preserve PMSL concurrency semantics.

This section specifies the PMSL language/runtime architecture. It does not claim that a completed runtime, completed PMS-OS backend, or completed host adapter already exists.

### 6.33 PMSL and PMS-OS IPC Relation

PMSL channels and tasks are language/runtime projections of OS IPC and scheduling concepts.

Mapping:

| PMSL construct | PMS-OS substrate                                            |
| -------------- | ----------------------------------------------------------- |
| `task`         | thread, process, runtime task, or scheduled execution locus |
| `channel<T>`   | MessageFrame / ChannelFrame                                 |
| `send`         | IPC enqueue/delivery                                        |
| `recv`         | IPC dequeue/wait                                            |
| `await`        | WaitFrame / scheduler wait                                  |
| `cancel`       | Φ lifecycle recontextualization                             |
| `event`        | EventFrame                                                  |
| `timer`        | TimerFrame                                                  |
| `mutex`        | SyncFrame                                                   |
| `semaphore`    | SyncFrame                                                   |
| `condvar`      | SyncFrame + WaitQueue                                       |
| `select`       | Θ readiness selection over endpoints                        |

The language layer may abstract over the OS layer. It may not remove the OS-layer obligations when those obligations are semantically active.

The mapping strengthens PMS-STACK architecture coherence across PMSL, PMS-IR, PMS-OS, runtime, and tooling. It does not claim PMS-OS implementation completion.

### 6.34 Static Checks for Concurrency

A PMSL checker should verify:

```text
channel payload type correctness
send/receive authority
endpoint visibility
task lifecycle closure
unhandled cancellation paths
unhandled timeout paths
unhandled channel-close paths
uncommitted delivery state
unsafe shared memory access
missing synchronization around shared mutable state
deadlock-prone lock ordering where detectable
effect declarations for spawn/send/recv/await/cancel
policy constraints on task creation and IPC
```

These checks feed Section 14 static analysis and linting.

Static checks accept or reject under a declared tool/conformance profile. They do not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

### 6.35 Concurrency Failure Paths

Concurrency failures are operator-typed.

| Failure                    | Operator reading               |
| -------------------------- | ------------------------------ |
| no message                 | Λ                              |
| timeout                    | Λ                              |
| channel full               | Λ / Θ / Ψ                      |
| channel closed             | Φ or typed closed-state result |
| missing send capability    | Ω / Ψ                          |
| missing receive capability | Ω / Ψ                          |
| boundary not visible       | Χ projection / Ψ / Φ           |
| malformed message          | Δ / Φ                          |
| protocol mismatch          | Δ / Φ                          |
| cancelled task             | Φ / Ψ / Σ                      |
| task panic/trap            | Φ                              |
| join on invisible task     | Χ projection / Ω / Ψ           |
| deadlock detected          | Δ / Ψ / Φ                      |
| resource exhausted         | Λ / Ψ / Φ                      |
| uncommitted delivery       | Σ failure / Φ recovery         |

A PMSL API should expose these through `Result`, `Option`, `Λ_absent<T>`, `Φ_trap<E>`, or policy-defined outcomes.

The architecture requires failure typing. It does not require every runtime profile to detect every failure statically.

### 6.36 Trace and Observation Convention for Concurrency

PMSL concurrency produces observable runtime events under declared profiles.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL concurrency run:

```text
trace_pmsl(runtime, concurrency_artifact, input_profile) ∈ L_PMS
```

For the set of possible runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, concurrency_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, concurrency_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, concurrency_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A concrete trace records observed execution under a declared profile. It is artifact evidence for bounded implementation behavior. It is not proof of all possible behavior and not PMS Base validation.

### 6.37 Example: Channel Send/Receive

Source:

```pmsl
module examples.ipc

role Sender {
    cap channel.send<Message>(C)
}

role Receiver {
    cap channel.recv<Message>(C)
}

channel C: channel<Message> capacity 16

fn sender(msg: Message)
    -> Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<SendError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)
    requires Ω(Sender)
{
    send C <- msg
}

fn receiver()
    -> Result<Message, Λ_absent<Message> | Φ_trap<RecvError>>
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
    requires Ω(Receiver)
{
    recv C timeout 100ms
}
```

Operator reading:

```text
sender:
    Δ classify C and msg
    Ω verify Sender has channel.send<Message>(C)
    Χ verify C is visible under projected boundary rules
    Ψ check channel policy
    ∇ enqueue msg
    Θ wake receiver if waiting
    Σ commit send visibility
    Λ no-space if buffer full and policy returns absence
    Φ trap on closed channel or send error

receiver:
    Δ classify C
    Ω verify Receiver has channel.recv<Message>(C)
    Χ verify C is visible under projected boundary rules
    Ψ check receive policy
    Θ wait up to 100ms
    Λ no-message if timeout expires
    ∇ dequeue if message exists
    Σ commit receive
    Φ trap on malformed message or closed-channel policy
```

This example illustrates PMSL concurrency typing and operator-preserving lowering. It does not assert that this exact PMSL source already runs unchanged in a complete PMSL compiler.

### 6.38 Example: Structured Task Group

Source:

```pmsl
fn run_pair()
    -> Result<Pair<ResultA, ResultB>, Φ_trap<TaskError>>
    effects(□, Ω, Χ, Ψ, Θ, Λ, Φ, Σ, ∇)
{
    task_group G {
        spawn task A { compute_a() }
        spawn task B { compute_b() }

        let a = await A
        let b = await B

        return Pair(a, b)
    }
}
```

Operator reading:

```text
□ create task group frame
Ψ attach group policy
Δ classify tasks A and B
Ω verify spawn authority
Χ establish projected child task boundaries
Θ schedule A and B
Σ commit task creation
Θ await A and B completion
Λ represent not-ready while waiting
Φ handle child failure
Σ integrate Pair(a, b)
□ close group frame
```

The example shows structured task lifecycle and result integration. It does not imply completed runtime implementation.

### 6.39 Example: Supervised Service

Source:

```pmsl
supervisor ServiceSupervisor policy RestartOnFailure {
    spawn task Worker {
        serve(inbox)
    }
}
```

Operator reading:

```text
□ create SupervisorFrame
Ψ activate RestartOnFailure policy
Δ classify Worker
Ω verify spawn authority
Χ establish projected worker boundary
Θ schedule Worker
Σ commit Worker creation

on failure:
    Δ classify failure
    Φ recontextualize Worker lifecycle
    Ψ evaluate restart policy
    Θ order restart/backoff
    Σ commit restarted or failed state
```

This example shows how PMSL represents service resilience without hiding recovery policy.

### 6.40 Example: Invalid Concurrency Sequence

Invalid source sketch:

```pmsl
send C <- msg
```

under a context where:

```text
C is not visible
or Sender lacks channel.send<Message>(C)
or active policy denies send
or commit behavior is undefined
```

Invalid operator reading:

```text
∇ enqueue msg
```

because the operation lacks required:

```text
Δ channel/message classification
Ω send authority
Χ-projected endpoint visibility
Ψ channel policy
Σ delivery or staging semantics
Φ/Λ failure typing
```

A PMSL compiler, checker, runtime validator, or PMS-IR validator must reject this under the declared profile or require explicit annotations/handlers that restore the missing obligations.

### 6.41 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for concurrency-adjacent slices when those slices are represented through its supported runtime/profile surface.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR concurrency-adjacent behavior, such as deterministic event stepping, trace emission, validator acceptance/rejection, bounded service calls, and proposal gating.

It does not complete:

```text
PMSL concurrency runtime
PMSL scheduler
PMSL channel implementation
PMSL standard-library concurrency APIs
PMS-IR optimizer
PMS-CPU
PMS-OS IPC
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL concurrency implementation and does not validate PMS Base.

### 6.42 AI Concurrency Boundary

The AI Bridge may propose:

```text
PMS-IR concurrency fragments
opcode programs
task/channel sketches
trace-analysis summaries
missing-obligation hypotheses
candidate static-analysis diagnostics
simulation scenarios
```

It may not function as:

```text
PMSL semantics
scheduler authority
type-checker authority
compiler authority
verifier authority
policy authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI-assisted concurrency suggestions are not simulation results, verification results, scheduler decisions, or execution authority. They become executable scenarios only after host-side parsing, canonicalization, PMS-IR mapping, validation, profile selection, and runtime/simulator acceptance.

### 6.43 Concurrency Invariants

PMSL maintains the following concurrency and IPC invariants.

```text
I1: every spawned task has a TaskFrame
I2: every task has an explicit lifecycle owner or detached policy
I3: every channel has a ChannelFrame and payload type
I4: every send is Δ-classified and Ω-authorized
I5: every receive is Δ-classified and Ω-authorized
I6: every channel operation respects Χ-projected visibility
I7: every channel operation is Ψ policy-governed
I8: message delivery and receive state are Σ-defined
I9: no-message, no-space, timeout, and not-ready are Λ-typed
I10: task failure, cancellation, protocol violation, and invalid channel state are Φ-typed
I11: task scheduling, waiting, wakeups, retries, and selects are Θ-ordered
I12: shared mutable state requires declared synchronization discipline
I13: synchronization primitives are SyncFrame-backed or profile-equivalent
I14: structured concurrency closes child lifecycles before parent frame exit unless detached by policy
I15: delivery guarantees are declared as Ψ/Σ profiles
I16: concurrency effects are visible in function effects and PMS-IR
I17: backend execution may vary, but operator obligations must be preserved
I18: no concurrency fast path bypasses Ω, Χ projection, Ψ, Λ, Φ, or Σ obligations
I19: traces record observed runs under declared profiles; they do not validate PMS Base
I20: AI-proposed concurrency artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL runtime or checker already enforces every invariant.

### 6.44 Boundary to Error Handling and Runtime Architecture

This section defines PMSL concurrency and IPC constructs.

It does not fully define:

| Topic                                         | Primary section             |
| --------------------------------------------- | --------------------------- |
| error, trap, and exception discipline         | Section 7                   |
| module-level visibility and linking           | Section 8                   |
| FFI async calls and host callbacks            | Section 9                   |
| runtime scheduler implementation              | Section 10                  |
| standard library concurrency domains          | Section 11                  |
| concrete concurrency and IO APIs              | Section 12                  |
| PMS-IR node format for concurrency            | Section 13                  |
| static analysis checks                        | Section 14                  |
| model checking of concurrent programs         | Section 15                  |
| trace/debug representation                    | Section 16                  |
| simulation and emulation                      | Section 17                  |
| distributed channels and cross-node messaging | `07_distributed_systems.md` |

The language-level concurrency model remains compatible with PMS-OS and distributed systems sections because it preserves task, channel, event, wait, failure, boundary, commit, policy, and trace structure rather than collapsing coordination into untyped threads or opaque host callbacks.

### 6.45 Architectural Consequence

The consequence of PMSL concurrency is:

```text
PMSL treats concurrency as structured operator coordination: tasks are
frames, channels are typed communication frames, sends and receives are
authorized and boundary-governed transitions, waits and timeouts are
Λ-visible, scheduling is Θ-ordered, failures recontextualize through Φ,
delivery and lifecycle closure commit through Σ, and policies constrain
the entire coordination surface through Ψ.
```

This gives PMSL a concurrency model that remains source-readable, runtime-executable under declared profiles, PMS-IR-visible, analyzable, simulatable, traceable, and compatible with PMS-OS IPC without reducing language-level concurrency to untyped threads or opaque host-runtime behavior.

### 6.46 Concurrency Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL concurrency and IPC model specifies operator-typed coordination:
tasks, task groups, channels, messages, events, timers, waits, selects,
locks, synchronization objects, supervisors, delivery profiles,
backpressure, shared-memory profiles, runtime mappings, static checks,
trace conventions, PMS-RUST evidence boundaries, and AI proposal
boundaries.

This is a language concurrency / IPC architecture claim.

It does not claim a completed PMSL runtime, completed scheduler,
completed channel implementation, completed standard-library concurrency
surface, completed PMS-OS IPC backend, completed distributed runtime,
completed verifier, or completed PMSL implementation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR concurrency and does
not validate PMS Base.
```

---

## 7. Error and Exception Handling

PMSL defines errors, exceptions, traps, absence, cancellation, policy denial, authority failure, boundary failure, commit failure, rollback, compensation, and recovery as operator-typed control and state transitions.

The language does not collapse all abnormal outcomes into one generic error mechanism. PMSL distinguishes:

```text
Λ — expected non-event / absence / timeout / no-result
Φ — trap / exception / recontextualization / recovery context
Ψ — policy denial / invariant constraint / validity decision
Ω — authority failure
Χ — PMS Base Distance projected as boundary / visibility / reachability failure
Σ — commit failure / rollback / incomplete integration
Δ — classification failure / unknown symbol / invalid kind
```

The central error-handling claim is:

```text
PMSL error handling is valid when every abnormal outcome remains
operator-readable: absence is Λ, recontextualization is Φ, policy
decision is Ψ, authority failure is Ω/Ψ, boundary failure is a
Χ-projected Ψ/Φ outcome, commit failure is Σ/Φ, and recovery occurs
inside typed handler frames.
```

This section defines source-level error and exception handling for PMSL and its lowering into PMS-IR.

CPU-level traps and OS-level faults are defined in `03_pms_cpu.md` and `04_pms_os.md`. PMSL projects them into language-level types, handlers, results, absence branches, runtime policies, trace-visible outcomes, and verification obligations.

Claim type:

```text
LANGUAGE ERROR-HANDLING / EXCEPTION ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL error and exception handling as an
operator-typed language/runtime architecture.

It does not claim a completed PMSL runtime, completed exception engine,
completed standard-library error hierarchy, completed compiler,
completed verifier, completed proof system, completed PMS-OS fault layer,
or completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared type-system, runtime, backend, error-profile, tool, conformance, simulation, or verification rule.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, recovery completeness, theoretical adequacy, or full behavioral coverage.

### 7.1 Error Model Overview

PMSL recognizes several outcome classes.

```text
normal value
absence / non-event
recoverable trap
policy denial
authority failure
boundary failure
commit failure
cancellation
runtime abort
critical halt
```

Operator reading:

| Outcome                | Primary operator     | Meaning                                        |
| ---------------------- | -------------------- | ---------------------------------------------- |
| normal value           | Σ                    | value integrated into continuation             |
| missing optional value | Λ                    | expected value absent                          |
| timeout                | Λ / Θ                | expected event absent within ordered interval  |
| empty channel          | Λ                    | no message available                           |
| recoverable exception  | Φ                    | execution recontextualizes into handler        |
| policy violation       | Ψ / Φ                | policy denies or traps                         |
| missing capability     | Ω / Ψ                | authority unavailable                          |
| boundary violation     | Χ projection / Ψ / Φ | visibility or reachability invalid             |
| failed commit          | Σ / Φ                | integration failed, rollback/recovery required |
| cancellation           | Φ / Ψ / Σ            | lifecycle recontextualized and closed          |
| panic / abort          | Φ / Ψ                | unrecoverable runtime path                     |
| halt                   | Ψ                    | critical invariant response                    |

This distinction is architectural. It lets PMSL tools analyze what kind of abnormal path exists and what obligations follow.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR error-handling level, Χ is projected as boundary failure, sandbox visibility failure, module reachability failure, host-boundary violation, runtime isolation fault, or cross-frame transfer violation. PMSL does not redefine Χ.

### 7.2 Absence Is Not Exception

PMSL keeps Λ distinct from Φ.

Λ means:

```text
an expected event, value, readiness state, message, resource, or response
did not materialize in the current frame.
```

Examples:

```text
optional value is none
channel has no message
timeout expires
future not ready
file not found as expected case
resource not available in nonblocking mode
no matching event
no response before deadline
```

Absence type examples:

```pmsl
Option<T>
Λ_absent<T>
Timeout<T>
NoMessage<T>
NoResource<T>
NotReady<T>
```

Example:

```pmsl
fn try_recv(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message>>
    effects(Δ, Ω, Χ, Θ, Λ, ∇, Σ)
```

Operator reading:

```text
Δ classify channel
Ω verify receive capability
Χ check projected endpoint visibility
Θ attempt receive or wait
Λ if no message occurs
∇ dequeue if message exists
Σ integrate received message
```

A Λ path may later become Φ if the program or runtime recontextualizes absence into a handler, failure, fallback, or recovery path.

```text
Λ_timeout → Φ_timeout_handler
```

But the operators remain distinct.

PMSL must not collapse expected non-events into generic exceptions.

### 7.3 Trap and Exception as Φ

Φ represents recontextualization.

In PMSL, exceptions and traps are language-level Φ paths. A Φ path changes the active interpretation context while preserving cause, continuation, frame, policy, boundary projection, and recovery metadata.

Examples:

```text
IO trap
policy violation trap
boundary fault
foreign-call trap
invalid type or payload trap
task failure
channel protocol violation
runtime invariant failure
commit failure
```

Trap type form:

```pmsl
Φ_trap<E>
```

Examples:

```pmsl
Φ_trap<IOError>
Φ_trap<PolicyViolation>
Φ_trap<BoundaryFault>
Φ_trap<ForeignError>
Φ_trap<ProtocolError>
Φ_trap<CommitError>
Φ_trap<TaskError>
```

A trap is valid when:

```text
cause is Δ-classified
∧ handler frame is available or propagation is declared
∧ role/capability context is coherent
∧ boundary state is preserved or explicitly transformed
∧ policy permits handling or propagation
∧ result or abort state is Σ-defined
```

A trap is not an unstructured jump. It is a typed recontextualization event.

### 7.4 Error Values vs. Error Contexts

PMSL distinguishes error values from error contexts.

An error value is data.

```pmsl
struct IOError {
    code: Int
    message: String
}
```

An error context is a Φ transition.

```pmsl
Φ_trap<IOError>
```

The difference:

```text
IOError
    = Δ/Σ-classified data value

Φ_trap<IOError>
    = recontextualization path carrying IOError as payload
```

This distinction prevents a common ambiguity:

```text
having an error value ≠ being inside an exception context
```

A function may return an error value normally:

```pmsl
fn parse(data: Bytes) -> Result<Value, ParseError>
```

or may trap:

```pmsl
fn read(path: Path) -> Result<Bytes, Φ_trap<IOError>>
```

The type signature decides whether the path is ordinary value-level branching or Φ recontextualization.

### 7.5 Result, Option, and Trap Forms

PMSL supports explicit failure forms.

```pmsl
Option<T>
Result<T, E>
Result<T, Φ_trap<E>>
Result<T, Λ_absent<T>>
Result<T, Λ_absent<T> | Φ_trap<E>>
```

Recommended usage:

```text
Option<T>
    value-level absence without runtime waiting

Λ_absent<T>
    operator-visible absence / non-event

Result<T, E>
    value-level error branch

Result<T, Φ_trap<E>>
    recoverable recontextualization path

Result<T, Λ_absent<T> | Φ_trap<E>>
    absence and trap both possible and distinct
```

Example:

```pmsl
fn poll(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message>>
```

No message is an expected non-event.

Example:

```pmsl
fn read_file(path: Path)
    -> Result<Bytes, Φ_trap<IOError>>
```

I/O failure recontextualizes execution into error handling.

Example:

```pmsl
fn recv_or_fail(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message> | Φ_trap<RecvError>>
```

Both paths are visible.

This form is normative for the architecture: callers must preserve the distinction between value-level branching, absence, trap, policy denial, boundary failure, and commit failure.

### 7.6 Exception Syntax

PMSL may express exception handling through `trap on`.

```pmsl
trap on Φ_trap<IOError> as e {
    recover_io(e)
}
```

General form:

```pmsl
trap on TrapType [as binding] {
    handler_body
}
```

Operator reading:

```text
Δ classify trap type
□ establish handler frame
Ω verify handler authority if required
Χ preserve or transform projected boundary state
Ψ check recovery policy
Φ enter handler context
∇ execute handler body
Σ integrate recovery result or propagated trap
Φ return, propagate, abort, or rethrow
```

Handler frame:

```text
HandlerFrame = (
    trap_type,
    payload,
    saved_continuation,
    saved_frame,
    saved_role,
    saved_boundary,
    active_policy,
    recovery_policy,
    result_type,
    meta
)
```

A handler is a typed frame, not an unstructured jump target.

The `saved_boundary` field records PMSL/PMS-IR boundary state, not PMS Base Χ itself. It is the layer projection of Χ = Distance into handler-visible boundary, sandbox, host, module, runtime, or reachability information.

### 7.7 Try / Else / Finally

PMSL may support a structured `try` form.

```pmsl
try {
    risky()
} trap on Φ_trap<IOError> as e {
    recover_io(e)
} else {
    after_success()
} finally {
    cleanup()
}
```

Operator reading:

```text
try:
    □ enter protected evaluation frame
    ∇ execute body
    Φ if trap occurs
    Σ integrate success if no trap

trap:
    Δ classify trap
    Φ enter handler frame
    ∇ execute recovery
    Σ integrate recovery result

else:
    Θ run after successful body only
    ∇ execute success continuation
    Σ integrate if needed

finally:
    Θ run after body/handler according to policy
    ∇ execute cleanup
    Σ commit cleanup obligations
    Φ preserve original trap if cleanup traps under policy
```

`finally` is a Σ/Ψ-sensitive construct because cleanup may need to close resources, staged effects, locks, frame entries, or runtime handles.

Finally invariants:

```text
I1: cleanup effects are typed
I2: cleanup cannot silently erase an active Φ trap
I3: cleanup cannot commit effects denied by policy
I4: cleanup failure has defined precedence
I5: resource closure is Σ-visible
```

A `finally` block is not a semantic eraser. It must preserve or explicitly transform active absence, trap, policy, boundary, and commit states.

### 7.8 Propagation

A trap may be propagated.

```pmsl
fn read_config(path: Path)
    -> Result<Config, Φ_trap<IOError>>
{
    let data = read_file(path)?
    parse_config(data)
}
```

If a `?`-style propagation profile is supported, it lowers to:

```text
Δ inspect result
if ok:
    Σ unwrap value into continuation
if trap:
    Φ propagate trap to caller context
```

Propagation is valid only if the caller’s function type declares the trap or handles it.

Propagation rule:

```text
body may propagate Φ_trap<E>
only if function result/effect type exposes Φ_trap<E>
or handler eliminates it
```

Similarly for Λ:

```text
body may propagate Λ_absent<T>
only if function result/effect type exposes Λ_absent<T>
or absence handler eliminates it
```

A propagation operator cannot convert Λ into Φ, Ψ into success, or Σ failure into ordinary value unless a declared profile explicitly provides that transformation.

### 7.9 Absence Handling

PMSL may handle Λ explicitly.

Example:

```pmsl
recv inbox timeout 50ms on timeout {
    handle_absence()
}
```

General absence handling:

```pmsl
on absence Λ_absent<T> {
    fallback()
}
```

Operator reading:

```text
Δ classify expected event/value
Θ wait or evaluate
Λ observe absence
Φ optionally enter absence-handler frame if handler form is used
∇ execute fallback
Σ integrate fallback result
```

Absence handling may choose:

```text
return absence
retry
fallback
default value
defer
escalate to Φ
deny under Ψ
```

Example escalation:

```pmsl
recv inbox timeout 50ms on timeout {
    trap Φ_trap<TimeoutError>(...)
}
```

This makes escalation explicit:

```text
Λ_timeout → Φ_timeout_trap
```

Absence handling remains typed even when it uses a handler frame. Λ does not disappear merely because the program chooses to handle it.

### 7.10 Policy Violation Handling

Policy violations are Ψ outcomes. Some are simple denials. Others recontextualize through Φ.

Example:

```pmsl
policy with P_write_tmp {
    FS.write("/secure/secret.txt", data)
}
```

Operator reading:

```text
Δ classify path and operation
Ω verify write role
Χ check projected namespace visibility
Ψ evaluate P_write_tmp
Ψ denial
Φ enter violation handler if policy defines trap behavior
```

Policy violation outcomes:

```text
deny and return typed error
trap into handler
audit and deny
quarantine frame/task/module
degrade operation
require escalation
abort transaction
halt under critical invariant
```

Policy-denial type:

```pmsl
Ψ_denial<P>
```

Trap type:

```pmsl
Φ_trap<PolicyViolation<P>>
```

Policy handling rule:

```text
policy denial may not be silently converted into ordinary success
```

It must be represented as a Ψ outcome, Φ trap, or declared result branch.

Policy handling is not moral judgment, forensic attribution, or governance authority. It is program/runtime constraint handling under Ψ.

### 7.11 Authority Failure

Authority failure is Ω/Ψ.

Example:

```pmsl
FS.write(path, data)
```

may fail if the active role lacks:

```text
cap fs.write(path)
```

Operator reading:

```text
Δ classify requested action
Ω check capability
Ψ check role/policy constraints
if denied:
    Ω/Ψ failure
    Φ trap or typed denial result
```

Type examples:

```pmsl
Φ_trap<AuthError>
Ψ_denial<MissingCapability>
```

Authority failure is distinct from:

```text
file absent        → Λ or Φ depending on profile
permission denied  → Ω/Ψ
boundary fault     → Χ projection / Ψ / Φ
IO device failure  → Φ
```

Ω grants action only within compatible frame, policy, boundary, and commit contexts. It does not override Ψ or Χ-projected constraints.

### 7.12 Boundary Failure

Boundary failure is Χ projected as PMSL visibility/reachability failure.

Example:

```pmsl
sandboxed_task.read(host_secret)
```

Operator reading:

```text
Δ classify target
Χ check projected boundary relation
Ψ check boundary policy
if invalid:
    Χ/Ψ denial
    Φ boundary trap if configured
```

Boundary trap type:

```pmsl
Φ_trap<BoundaryFault>
```

Boundary failure may produce:

```text
deny access
return boundary error
trap into handler
quarantine task/module/frame
copy through approved bridge
request explicit transfer
```

Boundary handling must preserve PMS Base operator discipline:

```text
PMS Base Χ = Distance.
PMSL projects Χ as boundary, sandbox, visibility, and reachability control.
```

A boundary failure is therefore not proof about PMS Base. It is a language/runtime outcome under the PMSL/PMS-IR projection of Χ.

### 7.13 Commit Failure

Commit failure is a Σ/Φ path.

Examples:

```text
transaction cannot commit
filesystem write cannot be made durable
message delivery cannot be committed
module link cannot be integrated
policy install cannot be finalized
audit record cannot be persisted
```

Commit block:

```pmsl
commit Σ {
    FS.write(path, data)
}
```

Commit failure reading:

```text
Δ classify staged effects
Ψ check commit policy
Σ attempt integration
if commit fails:
    Φ enter rollback/recovery context
    Ψ choose recovery policy
    Σ commit recovery state if possible
```

Commit failure type:

```pmsl
Φ_trap<CommitError>
```

or more specific:

```pmsl
Φ_trap<DurabilityError>
Φ_trap<TransactionAbort>
Φ_trap<RollbackError>
```

Commit invariants:

```text
I1: staged effect is not the same as committed effect
I2: failed commit leaves typed state
I3: rollback/recovery path is defined
I4: visibility claim is not made unless Σ succeeds
I5: policy determines abort, retry, rollback, or halt
```

Commit failure is profile-bound. A durable-commit failure has meaning only relative to a declared backend/runtime durability profile.

### 7.14 Cancellation as Φ

Cancellation recontextualizes lifecycle.

Example:

```pmsl
cancel Worker
```

Operator reading:

```text
Δ classify target task
Ω verify cancellation authority
Ψ check cancellation policy
Φ recontextualize task state
Θ order cancellation delivery
Σ commit cancelled or closed state
```

Cancellation result types:

```pmsl
Cancelled
AlreadyCompleted<T>
Denied<Ψ>
Φ_trap<CancellationError>
```

Cancellation is not ordinary absence.

```text
task not ready  → Λ
task cancelled  → Φ lifecycle shift + Σ closure
```

Cancellation is also not an untyped kill primitive. It is a policy-governed lifecycle transition.

### 7.15 Runtime Panic and Abort

A runtime panic is a Φ path selected by runtime policy.

Examples:

```text
unhandled trap
critical invariant failure
invalid runtime state
unrecoverable boundary breach
commit recovery failure
resource failure in critical context
```

Runtime panic reading:

```text
Δ classify runtime violation
Ψ determine severity
Φ enter runtime panic context
Σ commit audit/failure state if possible
Ψ abort, terminate, quarantine, or halt
```

Abort/halt is policy-bound.

```text
halt is Ψ critical invariant response
```

PMSL should distinguish:

```text
recoverable trap
runtime panic
process/task abort
system halt
```

These may all involve Φ, but they have different policy and commit consequences.

A runtime panic is an implementation/runtime outcome under a declared profile. It is not PMS Base validation.

### 7.16 Default Runtime Handlers

The PMSL runtime may provide default handlers.

Default handler classes:

```text
unhandled trap handler
unhandled absence handler
policy denial handler
boundary fault handler
commit failure handler
task failure handler
cancellation handler
foreign error mapper
panic handler
```

Default handler responsibilities:

```text
classify cause
preserve trace context
preserve frame/role/boundary state
apply runtime policy
commit audit record if required
return typed result, propagate trap, terminate task, quarantine, or halt
```

Default handler rule:

```text
default runtime behavior must be explicit in the runtime profile
```

A PMSL program cannot assume an implicit universal exception policy.

Default handlers are runtime architecture obligations. This section does not claim a completed default-handler implementation.

### 7.17 Handler Selection

Handler selection is Δ/Θ/Ψ.

When multiple handlers may match, PMSL requires a defined selection rule.

Possible selection policies:

```text
most specific trap type
nearest lexical handler
nearest frame handler
policy-priority handler
module-level handler
runtime default handler
supervisor handler
```

Selection flow:

```text
Δ classify trap kind and payload
Δ classify available handlers
Ψ filter handlers by policy
Θ select according to handler-order rule
Φ enter selected handler frame
```

Handler ambiguity is invalid unless the active profile defines a deterministic resolution rule.

Handler selection is therefore analyzable and profile-bound, not implementation folklore.

### 7.18 Nested Traps

A trap may occur while handling another trap.

Nested trap flow:

```text
Φ active handler context
Δ classify new trap
Ψ check nested-trap policy
if allowed:
    Φ enter nested handler
else:
    Φ escalate to runtime handler
    Ψ abort/quarantine/halt if critical
```

Nested-trap policy may constrain:

```text
maximum nesting depth
handler reentrancy
allowed trap classes
non-recoverable trap classes
critical-section traps
cleanup traps
```

Nested traps must preserve:

```text
saved continuations
handler frame stack
boundary state
role state
policy state
commit/rollback state
```

A nested trap that erases the original handler context is not PMSL-conformant.

### 7.19 Recovery Patterns

Recovery is an Α pattern over Φ, Ψ, Θ, ∇, and Σ.

Common recovery patterns:

```text
retry
fallback
rollback
compensate
degrade
quarantine
restart task
restart supervisor child
return default
escalate
abort
```

Example retry:

```pmsl
pattern retry<N>(op) {
    loop until success or attempts == N {
        try {
            return op()
        } trap on Φ_trap<TransientError> {
            wait backoff(attempts)
        }
    }
}
```

Operator reading:

```text
Α retry pattern
Θ order attempts
Δ classify success/failure
Φ handle transient trap
Λ no-success if attempts exhausted
Ψ enforce retry policy
Σ integrate final result
```

Recovery pattern validity:

```text
pattern expands to valid operator words
∧ effects are declared
∧ retries are bounded or policy-governed
∧ absence/trap/commit behavior is explicit
```

Recovery patterns are reusable operator structures. They are not semantic exceptions to PMSL validity rules.

### 7.20 Rollback and Compensation

Rollback reverses or neutralizes staged state when commit fails.

Compensation performs a follow-up effect that restores a higher-level invariant when direct rollback is impossible.

Rollback reading:

```text
Σ failure
Φ enter rollback context
∇ reverse staged effects where possible
Σ commit rollback state
Ψ validate invariant
```

Compensation reading:

```text
Σ committed effect cannot be undone directly
Φ enter compensation context
∇ perform compensating effect
Σ commit compensation
Ψ validate resulting invariant
```

Examples:

```text
transaction rollback
message cancellation
task shutdown
filesystem temporary-file cleanup
foreign-call compensation
audit correction record
```

Compensation must not pretend to erase history. It creates a new committed corrective state.

Rollback and compensation are implementation-facing recovery structures. They do not prove that every external effect can be undone.

### 7.21 Resource Cleanup

Cleanup is a Σ/Ψ obligation.

Resource examples:

```text
file handle
channel endpoint
lock guard
foreign handle
task group
transaction frame
temporary buffer
shared frame
policy scope
```

Resource cleanup rule:

```text
if a resource is acquired, then its lifecycle must be closed, transferred,
committed, or intentionally leaked under explicit policy.
```

RAII-like pattern:

```pmsl
with resource acquire() as r {
    use(r)
}
```

Operator reading:

```text
Δ classify resource
Ω verify acquisition authority
∇ acquire
Σ commit resource ownership
□ enter resource frame
∇ use
Σ close/release on exit
Φ cleanup on trap
Ψ enforce lifecycle policy
```

Cleanup failure must be typed:

```pmsl
Φ_trap<CleanupError>
```

or policy-handled.

Cleanup is not optional bookkeeping. It is a language/runtime obligation for acquired resources.

### 7.22 Error Interaction with Concurrency

Concurrency errors combine Φ, Λ, Θ, Σ, and Ψ.

Examples:

| Concurrency case   | Operator reading               |
| ------------------ | ------------------------------ |
| no message         | Λ                              |
| timeout            | Λ / Θ                          |
| task failure       | Φ                              |
| cancellation       | Φ / Ψ / Σ                      |
| failed join        | Φ / Λ                          |
| channel closed     | Φ or typed closed-state result |
| protocol mismatch  | Δ / Φ                          |
| backpressure       | Λ / Ψ / Θ                      |
| deadlock detected  | Δ / Ψ / Φ                      |
| supervisor restart | Α / Φ / Θ / Σ / Ψ              |

Example:

```pmsl
let msg = recv inbox timeout 50ms
```

outcomes:

```text
message received → Σ integrate message
no message       → Λ_absent<Message>
channel error    → Φ_trap<RecvError>
policy denial    → Ψ / Φ
```

A function using this receive must type all reachable outcomes.

Concurrency error handling is refined by Section 6 and Section 12. This section defines the shared error discipline.

### 7.23 Error Interaction with FFI

Foreign calls require Φ mapping.

A foreign error is not automatically a PMSL trap. It must be mapped.

FFI error mapping:

```text
foreign error code
→ Δ classify host error
→ Φ map into PMSL trap or Λ absence
→ Ψ check FFI policy
→ Σ integrate mapped result
```

Example:

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
```

FFI failure outcomes:

```text
host error code
host timeout
host permission denial
host resource absence
host crash
invalid ABI result
boundary violation
```

Each must map to:

```text
Λ
Φ
Ψ
Χ projection / Φ
Σ failure
```

according to the FFI profile.

FFI error mapping is refined in Section 9. A foreign call may not leak host failure semantics into PMSL as opaque untyped failure.

### 7.24 Error Interaction with Policies

Policies may:

```text
deny
trap
audit
defer
retry
quarantine
degrade
escalate
terminate
halt
```

Policy action table:

| Policy action | Operator reading     |
| ------------- | -------------------- |
| deny          | Ψ                    |
| trap          | Ψ → Φ                |
| audit         | Δ → Σ                |
| defer         | Ψ → Θ / Λ            |
| retry         | Ψ → Θ / Α            |
| quarantine    | Ψ → Χ projection / Σ |
| degrade       | Ψ → Φ / Σ            |
| escalate      | Ψ → Φ                |
| terminate     | Ψ → Φ / Σ            |
| halt          | Ψ critical response  |

Policy errors are therefore not outside error handling. They are one of the main inputs into PMSL exception behavior.

Policy action remains program/runtime constraint handling. It is not governance authority, moral adjudication, or forensic attribution.

### 7.25 Error Interaction with Commit Blocks

Inside a commit block, errors affect integration.

Example:

```pmsl
commit Σ {
    FS.write(path, data)
    Log.info("written")
}
```

If `FS.write` traps before commit:

```text
Φ trap
Σ block does not commit normal result
rollback/recovery policy applies
```

If `Log.info` fails after write staging:

```text
Φ trap
Ψ decides rollback, continue, compensate, or abort
Σ commits selected recovery outcome
```

Commit block failure policy may be:

```text
all_or_nothing
best_effort
staged
compensating
audit_required
rollback_required
commit_on_partial_success
```

The active policy must define which one applies.

Commit blocks do not make effects safe by syntax alone. Their meaning depends on declared commit, rollback, policy, runtime, and backend profiles.

### 7.26 Error Effects

Errors appear in effect types.

Examples:

```pmsl
effects(Φ)
effects(Λ)
effects(Ψ, Φ)
effects(Σ, Φ)
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
```

A function that may trap must declare Φ or return a trap-bearing result.

A function that may return absence must declare Λ or return an absence-bearing result.

A function that may deny by policy must expose Ψ or map it to a declared result/trap type.

Effect rule:

```text
body error effects ⊆ declared error effects
```

or the construct is invalid.

Error effects are compiler- and analyzer-visible obligations, not comments.

### 7.27 PMS-IR Representation

PMS-IR must preserve error structure.

Generic error-capable IR node:

```text
IRNode = (
    id,
    op,
    construct,
    type,
    effects,
    normal_result,
    absence_paths,
    trap_paths,
    policy_paths,
    authority_paths,
    boundary_paths,
    commit_paths,
    handler_links,
    source_span,
    meta
)
```

Trap node:

```text
IR.Trap {
    op: Φ,
    trap_type,
    payload_type,
    cause,
    saved_frame,
    saved_role,
    saved_boundary,
    handler,
    policy,
    source_span
}
```

Absence node:

```text
IR.Absence {
    op: Λ,
    expected_type,
    absence_kind,
    timeout?,
    continuation,
    handler?,
    source_span
}
```

Policy denial node:

```text
IR.PolicyDecision {
    op: Ψ,
    policy,
    action,
    decision,
    denial_result?,
    trap?,
    audit?,
    source_span
}
```

Commit failure node:

```text
IR.CommitFailure {
    op: Σ / Φ,
    commit_type,
    staged_effects,
    failure_cause,
    rollback?,
    compensation?,
    policy,
    source_span
}
```

Boundary failure node:

```text
IR.BoundaryFailure {
    op: Χ,
    boundary_profile,
    attempted_relation,
    denial?,
    trap?,
    policy,
    source_span
}
```

This representation lets analysis distinguish error families instead of collapsing them.

Validation of this representation means acceptance/rejection under a declared PMS-IR schema, tool profile, runtime profile, or conformance rule. It is not PMS Base validation.

### 7.28 Static Checking

A PMSL checker should verify:

```text
all Φ-producing constructs are handled, propagated, or declared
all Λ-producing constructs are handled, propagated, or declared
all Ψ denials have defined result, trap, or enforcement behavior
all Ω failures are represented through declared policy/trap/result paths
all Χ-projected failures have boundary-safe handling
all Σ failures have rollback/recovery/abort policy
all cleanup paths close required resources
all handler frames type-check under their active role/policy/boundary
all finally blocks preserve or explicitly transform active traps
all pattern-based recovery expands to valid operator words
```

Static checker outputs should include:

```text
source span
operator class
failed obligation
available handlers
declared result type
suggested missing effect or handler
```

Static checks are profile-local acceptance/rejection. They do not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

### 7.29 Runtime Checking

Some errors can only be resolved at runtime.

Examples:

```text
dynamic policy denial
runtime capability state
channel closed at runtime
timeout
resource exhaustion
foreign call failure
commit durability failure
task cancellation
boundary relation changed
```

Runtime checking flow:

```text
Δ classify runtime event
Ω/Χ/Ψ/Σ/Λ/Φ determine event class
select typed outcome
commit runtime state if required
return value, absence, trap, denial, abort, or halt
```

Runtime handlers must preserve traceability.

A runtime may optimize error paths, but it may not erase operator classification.

Runtime checking is an implementation profile. This section specifies the architecture of obligations, not a completed runtime.

### 7.30 Diagnostics

Diagnostics are operator-labeled.

Example missing capability:

```text
error[Ω]:
    missing capability fs.write("/var/log/**")

source:
    FS.write(path, data)

required by:
    Function write_log effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)

active role:
    User

suggested:
    require Ω(LogWriter)
```

Example unhandled absence:

```text
error[Λ]:
    receive may produce Λ_absent<Message>, but function result does not
    declare absence and no handler is present

source:
    recv inbox timeout 50ms
```

Example commit failure:

```text
error[Σ/Φ]:
    commit block may fail, but rollback or trap path is not declared

source:
    commit Σ { FS.write(path, data) }
```

Diagnostics should make the failed operator obligation visible.

Diagnostics are tooling outputs under a declared profile. They are not proof of PMS Base and not external validation.

### 7.31 Trace and Observation Convention for Error Handling

PMSL error handling produces observable runtime events under declared profiles.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL error-handling run:

```text
trace_pmsl(runtime, error_artifact, input_profile) ∈ L_PMS
```

For the set of possible runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, error_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, error_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, error_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A concrete trace records observed execution under a declared profile. It is artifact evidence for bounded implementation behavior. It is not proof of all possible behavior and not PMS Base validation.

### 7.32 Example: Policy Violation

Source:

```pmsl
policy P_write_tmp {
    allow fs.write where path.starts_with("/tmp/")
    deny  fs.write where path.starts_with("/secure/")
}

fn write_secret(path: Path, data: Bytes)
    -> Result<Unit, Φ_trap<PolicyViolation>>
    effects(Δ, Ω, Χ, Ψ, ∇, Φ)
{
    policy with P_write_tmp {
        FS.write("/secure/secret.txt", data)
    }
}
```

Operator reading:

```text
Ψ activate P_write_tmp
Δ classify path as /secure/...
Ω check write capability
Χ check projected namespace visibility
Ψ deny write under policy
Φ construct PolicyViolation trap
Σ integrate trap result into function return
```

The trap is a valid outcome because the function declares it.

This example is local to the declared PMSL/PMS-IR profile. It does not assert completed compiler execution.

### 7.33 Example: Absence Handling

Source:

```pmsl
fn poll_once(ch: channel<Message>)
    -> Result<Message, Λ_absent<Message>>
    effects(Δ, Ω, Χ, Θ, Λ, ∇, Σ)
{
    recv ch timeout 10ms
}
```

Operator reading:

```text
Δ classify channel
Ω verify receive authority
Χ verify projected endpoint visibility
Θ wait up to 10ms
Λ if no message arrives
∇ dequeue if message exists
Σ integrate result
```

No message is not an exception here. It is the declared Λ result.

### 7.34 Example: Trap Recovery

Source:

```pmsl
fn safe_read(path: Path)
    -> Result<Bytes, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
{
    try {
        FS.read(path)
    } trap on Φ_trap<IOError> as e {
        Log.info("read failed")
        return recover_default(e)
    }
}
```

Operator reading:

```text
Δ classify path and read operation
Ω check read authority
Χ check projected namespace visibility
Ψ check filesystem policy
∇ perform read
Φ if IO trap occurs
□ enter handler frame
∇ log recovery event
Σ integrate recovered value or propagated trap
Φ return to caller continuation
```

Recovery is typed because the handler frame and function result expose the relevant Φ path.

### 7.35 Example: Commit Failure

Source:

```pmsl
fn write_audit(record: AuditRecord)
    -> Result<Σ_durable<Unit>, Φ_trap<CommitError>>
    effects(Δ, Ω, Ψ, ∇, Σ, Φ)
{
    commit Σ {
        Audit.append(record)
    }
}
```

Operator reading:

```text
Δ classify audit record
Ω verify audit append authority
Ψ check audit policy
∇ stage append
Σ attempt durable commit
Φ CommitError if durable commit fails
Σ integrate durable result if commit succeeds
```

The return type promises durable commit only on success under the declared backend/runtime profile.

### 7.36 Example: Invalid Error Collapse

Invalid source sketch:

```pmsl
fn read_or_default(path: Path) -> Bytes {
    FS.read(path) catch { Bytes.empty() }
}
```

Invalidity condition:

```text
FS.read may produce Φ_trap<IOError>
active policy may deny through Ψ
path may be boundary-invisible through Χ projection
resource absence may be Λ under profile
commit state may be Σ-sensitive
```

Invalid operator collapse:

```text
Φ / Ψ / Χ / Λ / Σ → ordinary Bytes
```

without declared recovery policy, handler frame, boundary-safe fallback, audit rule, or result typing.

A conformant version must expose the transformation:

```pmsl
fn read_or_default(path: Path)
    -> Result<Bytes, Φ_trap<IOError | BoundaryFault>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
{
    try {
        FS.read(path)
    } trap on Φ_trap<IOError> as e {
        policy with P_default_read {
            return Bytes.empty()
        }
    }
}
```

or return a result type that preserves the distinct abnormal paths.

### 7.37 Error-Handling Invariants

PMSL maintains the following error and exception invariants.

```text
I1: absence is represented through Λ, not untyped failure
I2: traps and exceptions are represented through Φ
I3: policy denial is represented through Ψ and optionally Φ
I4: authority failure is represented through Ω/Ψ and optionally Φ
I5: boundary failure is represented through Χ projection / Ψ / Φ
I6: commit failure is represented through Σ/Φ
I7: every Φ path has a handler, propagation path, default runtime policy, or abort policy
I8: every Λ path is handled, propagated, converted, or declared
I9: every handler executes inside a valid HandlerFrame
I10: handler frame entry preserves role, boundary, and policy discipline
I11: cleanup/finally paths do not silently erase active traps
I12: rollback and compensation are explicit Σ/Φ structures
I13: recovery patterns expand to valid operator words
I14: foreign errors are mapped through declared FFI profiles
I15: runtime panic and halt are policy-defined outcomes
I16: PMS-IR preserves absence, trap, policy, boundary, authority, and commit failure structure
I17: diagnostics identify the failed operator obligation
I18: no error-handling fast path bypasses Ω, Χ projection, Σ, Ψ, Λ, or Φ obligations
I19: traces record observed runs under declared profiles; they do not validate PMS Base
I20: AI-proposed error-handling artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL compiler, checker, runtime, or verifier already enforces every invariant.

### 7.38 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for error-handling-adjacent slices when those slices are represented through its supported runtime/profile surface.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR error-handling-adjacent behavior, such as validator acceptance/rejection, deterministic trap-like outcomes, JSONL trace emission, bounded service errors, and proposal gating.

It does not complete:

```text
PMSL error-handling runtime
PMSL exception engine
PMSL type checker
PMSL compiler
PMSL standard-library error hierarchy
PMS-IR optimizer
PMS-CPU trap layer
PMS-OS fault layer
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL error-handling implementation and does not validate PMS Base.

### 7.39 AI Error-Handling Boundary

The AI Bridge may propose:

```text
PMS-IR error-handling fragments
opcode programs
handler sketches
missing-obligation hypotheses
candidate diagnostics
trace-analysis summaries
recovery-pattern suggestions
simulation scenarios
```

It may not function as:

```text
PMSL semantics
type-checker authority
compiler authority
verifier authority
policy authority
runtime exception authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI-assisted error-handling suggestions are not diagnostics, verification results, policy decisions, runtime exception decisions, or execution authority until host-validated under a declared tooling/profile gate.

### 7.40 Boundary to Runtime, Security, and Verification

This section defines PMSL error and exception handling.

It does not fully define:

| Topic                                   | Primary section          |
| --------------------------------------- | ------------------------ |
| module-level handler registration       | Section 8                |
| foreign error mapping details           | Section 9                |
| runtime default-handler implementation  | Section 10               |
| standard-library error types            | Section 11               |
| async IO error profiles                 | Section 12               |
| PMS-IR full trap/absence node format    | Section 13               |
| static error analysis and linting       | Section 14               |
| verification of recovery properties     | Section 15               |
| trace and debugging representation      | Section 16               |
| simulation and emulation of error paths | Section 17               |
| runtime-security policy enforcement     | `06_runtime_security.md` |
| OS-level trap/fault behavior            | `04_pms_os.md`           |

The language-level obligation is clear: every abnormal path remains operator-typed.

### 7.41 Architectural Consequence

The consequence of PMSL error handling is:

```text
PMSL treats abnormal control flow as structured operator behavior:
absence remains Λ, traps and exceptions remain Φ, policy denials remain
Ψ-governed, authority and boundary failures remain Ω/Χ-readable,
commit failures remain Σ/Φ-visible, and every handler, rollback,
cleanup, propagation, recovery, abort, and runtime default path remains
typed, framed, policy-constrained, boundary-aware, and visible in PMS-IR.
```

This gives PMSL an error model suitable for source programming, runtime execution, static analysis, model checking, tracing, simulation, and verification without collapsing all failures into generic exceptions or untyped result codes.

### 7.42 Error-Handling Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL error and exception model specifies operator-typed abnormal
control flow: absence, traps, policy denial, authority failure, boundary
failure, commit failure, cancellation, runtime panic, handlers,
propagation, rollback, compensation, cleanup, diagnostics, traces,
PMS-RUST evidence boundaries, and AI proposal boundaries.

This is a language error-handling / exception architecture claim.

It does not claim a completed PMSL runtime, completed exception engine,
completed standard-library error hierarchy, completed compiler, completed
verifier, completed proof system, completed PMS-OS fault layer, or
completed PMSL implementation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR error handling and does
not validate PMS Base.
```

---

## 8. Module System

PMSL defines modules as operator-typed structural units.

A module is not merely a file, namespace, package, or linker artifact. In PMSL, a module is a □-framed symbol and execution context with explicit imports, exports, roles, capabilities, policies, boundary projections, lifecycle state, versioning semantics, and commit obligations.

The central module-system claim is:

```text
A PMSL module is a □-framed, Δ-addressable, Ω-role-bearing,
Χ-projection-governed, Ψ-policy-constrained, Σ-linked,
Θ-lifecycle-ordered, and Φ-reframeable program unit whose imports,
exports, interfaces, capabilities, state, and interactions remain visible
in PMS-IR.
```

This section defines the PMSL module system at language/runtime specification level. It does not claim that a complete PMSL module loader, linker, package manager, compiler, runtime loader, or module-verification tool already exists. It defines the conformance obligations that such artifacts must preserve.

Claim type:

```text
LANGUAGE MODULE-SYSTEM / LINKAGE ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL modules as operator-typed language/runtime
architecture.

It does not claim a completed PMSL module loader, completed linker,
completed package manager, completed compiler, completed runtime loading
system, completed module verifier, completed PMS-OS loader, or completed
PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared module-system rule, linker profile, runtime profile, PMS-IR schema, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, module-loader correctness, package-manager correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR module level, Χ is projected as module boundary, sandbox boundary, symbol visibility, import/export reachability, runtime isolation, host boundary, access separation, and cross-frame transfer discipline.

PMSL/PMS-IR does not redefine Χ.

### 8.1 Module Role in PMSL

The module system provides five architectural functions.

```text
symbol organization
frame construction
authority scoping
policy attachment
boundary control
```

More explicitly, modules define:

```text
which names exist
which types/functions/values are exported
which symbols are imported
which role the module runs under
which capabilities the module requires or provides
which policies constrain the module
which boundary projection protects the module
which lifecycle hooks run at load/unload
which version/reframe rules govern upgrades
```

Thus a PMSL module is both:

```text
compile-time structure
runtime structure
```

Compile-time:

```text
module path
symbol table
import/export graph
interface contracts
type/effect signatures
capability requirements
policy constraints
boundary profile
```

Runtime:

```text
module frame
active role
policy set
resource state
task/channel endpoints
initialization state
finalization state
trace/audit identity
runtime boundary profile
```

A PMSL module therefore acts as the language-level unit through which frames, authority, policy, linkage, visibility, lifecycle, and recontextualization become analyzable.

### 8.2 Basic Module Declaration

Basic syntax:

```pmsl
module M {
    export fn f(x: Int) -> Int {
        x + 1
    }

    let internal_data = 0

    import N { g }
}
```

Canonical operator reading:

```text
Δ identify module M
□ create module frame
Δ distinguish local symbols
Δ distinguish imports and exports
Ω assign module role
Ψ attach module policy
Χ attach projected module boundary where applicable
Σ commit module declaration
```

A module declaration creates a named frame.

```text
module M
⇒ ModuleFrame(M)
```

Source-level nesting:

```pmsl
module A {
    module B {
        fn inner() -> Unit { }
    }
}
```

creates a frame stack:

```text
ModuleFrame(A)
 └── ModuleFrame(A.B)
```

Nested modules inherit, restrict, or explicitly override role, capability, policy, and boundary structure according to module policy.

A nested module may restrict authority or strengthen boundary projection. It may not silently weaken enclosing policy, bypass imports, or widen authority.

### 8.3 Extended Module Declaration

PMSL may support an extended form with explicit structural constraints.

```pmsl
module M : ModuleType {
    requires role UserSpace
    requires policy SafeFS
    requires cap fs.read("/etc/**")

    provides interface I {
        fn f(x: Int) -> Int
    }
}
```

Structural reading:

```text
Δ identify module and declared type
Ω require UserSpace role
Ψ require SafeFS policy
Ω require fs.read capability
□ establish module frame
Χ attach projected boundary profile if declared or inferred
Σ commit provided interface
```

The extended form is valuable for tooling because it makes module obligations explicit.

A compiler may infer some obligations, but the PMS-IR must preserve them whether they were explicit or inferred.

If the compiler cannot reconstruct required authority, policy, boundary projection, lifecycle state, trap behavior, or commit obligations, it must require explicit syntax or reject the module under the active profile.

### 8.4 ModuleFrame

Every PMSL module has a module frame.

```text
ModuleFrame = (
    id,
    path,
    symbols,
    imports,
    exports,
    interfaces,
    role,
    capabilities,
    policies,
    boundary,
    state,
    lifecycle,
    version,
    resources,
    meta
)
```

where:

| Field | Meaning |
| ----- | ------- |
| `id` | stable module identifier |
| `path` | module path or qualified name |
| `symbols` | local types, functions, values, roles, policies, patterns |
| `imports` | imported module symbols |
| `exports` | public module surface |
| `interfaces` | declared public contracts |
| `role` | active Ω role assigned to the module |
| `capabilities` | required/provided capability set |
| `policies` | Ψ constraints attached to the module |
| `boundary` | PMSL/PMS-IR module-boundary projection of Χ |
| `state` | lifecycle state |
| `lifecycle` | initialization/finalization hooks |
| `version` | version and compatibility metadata |
| `resources` | runtime resource profile |
| `meta` | source spans, trace IDs, audit tags, diagnostics |

Module-frame validity requires:

```text
module identity is Δ-distinguished
∧ symbol table is coherent
∧ import graph is resolvable
∧ export surface is explicit
∧ role is defined
∧ policy set is attached
∧ boundary behavior is known
∧ lifecycle state is explicit
∧ linkage is Σ-committed before public use
```

A `ModuleFrame` is a language/runtime structure. It may lower to different backend mechanisms: static compilation unit, runtime module object, host module, simulator module, PMS-RUST-style artifact slice, future PMS-OS loadable unit, or distributed placement profile. The concrete backend may vary; the operator obligations must remain visible.

### 8.5 Modules as Frames

The primary operator of modules is:

```text
□
```

A module creates a lexical and execution frame.

```text
M.frame = {
    symbols,
    imports,
    exports,
    memory_or_state_region,
    policies,
    roles,
    boundary,
    lifecycle
}
```

Entering module scope is:

```text
□ enter ModuleFrame(M)
```

Leaving module scope is:

```text
□ restore parent frame
```

Module-frame entry may also activate:

```text
Ω module role
Ψ module policy set
Χ-projected module boundary
Θ lifecycle order
```

A simple module enter sequence:

```text
Δ identify M
□ enter M.frame
Ω install M.role
Ψ activate M.policies
Χ apply projected M.boundary if isolated or visibility-governed
```

Module scope provides:

```text
symbol resolution
type namespace
capability scope
policy scope
resource scope
runtime identity
trace scope
```

Not every module is isolated. A simple module may be a lexical/symbolic frame only. An isolated, sandboxed, foreign, runtime, or distributed module adds stronger Χ-projected boundary obligations.

### 8.6 Symbol Tables

A module symbol table is a Δ-structured map.

```text
SymbolTable = Name → Symbol
```

Symbol kinds include:

```text
type
function
value
constant
role
capability
policy
frame
channel
event
pattern
module
foreign symbol
```

Symbol resolution:

```text
Δ resolve name
```

Resolution flow:

```text
Δ classify name
Δ inspect local symbol table
Δ inspect imported symbols if not local
Χ check projected visibility boundary
Ω check access/export authority if protected
Ψ check module policy
return symbol or Λ/Φ diagnostic
```

Unknown symbol:

```text
Δ failure
```

Unauthorized symbol:

```text
Ω / Ψ failure
```

Invisible symbol:

```text
Χ projection / Ψ failure
```

Ambiguous symbol:

```text
Δ conflict
```

A PMSL compiler must preserve source spans for symbol-resolution diagnostics.

Symbol tables are not untyped maps. They are Δ-governed structures whose visibility, authority, policy, and boundary obligations must remain visible in PMS-IR.

### 8.7 Imports

Imports create explicit dependency edges.

Syntax:

```pmsl
import Std.FS
import Std.Log as Log
import Net.Transport { connect, listen }
```

Import entity:

```text
ImportEdge = (
    importer,
    imported_module,
    symbols,
    alias,
    required_capabilities,
    policy,
    boundary,
    commit_state,
    meta
)
```

Import lowering:

```text
Δ resolve imported module path
Δ resolve requested symbols
Ω verify import capability
Χ verify projected module visibility
Ψ check import policy
Σ commit import edge
```

Import invariants:

```text
I1: imported module is distinguishable
I2: requested symbols exist and are exported
I3: importer may see the imported module
I4: importer may use imported symbols under active policy
I5: import edge is committed before use
I6: import does not silently widen module authority
I7: import does not bypass module boundary projection
```

An import is not a textual include. It is a policy-checked, boundary-governed linkage relation.

### 8.8 Exports

Exports define the public surface of a module.

Syntax:

```pmsl
export write_log
export type LogRecord
export policy P_log
export interface LogService
```

Export entity:

```text
ExportEntry = (
    module,
    symbol,
    public_name,
    type_signature,
    effect_signature,
    required_role,
    required_capability,
    policy,
    boundary,
    meta
)
```

Export lowering:

```text
Δ identify exported symbol
Ω verify export authority
Χ define projected visibility surface
Ψ check export policy
Σ commit export entry
```

Export invariants:

```text
I1: exported symbol exists locally
I2: exported type/effect signature is complete
I3: exported capability requirements are explicit
I4: exported policy obligations are explicit
I5: export surface does not leak internal symbols
I6: export is visible only after Σ linkage commit
I7: export does not weaken module boundary profile
```

The export surface is a contract.

A module may expose a symbol only with its type, effects, failure behavior, authority requirements, policy requirements, and boundary obligations intact.

### 8.9 Interfaces

An interface is an exported contract over functions, types, effects, roles, and policies.

Syntax:

```pmsl
interface LogService {
    fn write_log(path: Path, data: Bytes)
        -> Result<Σ_durable<Unit>, Φ_trap<IOError>>
        effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
        requires Ω(LogWriter)
}
```

Interface entity:

```text
InterfaceFrame = (
    name,
    functions,
    types,
    required_roles,
    required_capabilities,
    policies,
    effects,
    boundary,
    version,
    meta
)
```

Interface declaration lowering:

```text
Δ identify interface
□ create interface frame
Δ classify signatures
Ω attach role/capability requirements
Χ attach projected boundary requirements where applicable
Ψ attach policy constraints
Σ commit interface contract
```

A module may implement an interface:

```pmsl
module AppLog implements LogService {
    export fn write_log(...) { ... }
}
```

Implementation check:

```text
exported symbols satisfy interface signatures
∧ effects are compatible
∧ required capabilities are preserved
∧ policy obligations are no weaker
∧ boundary behavior is compatible
```

Interface implementation is a conformance relation under a declared module/type/effect profile. It is not proof of PMS Base and not proof of all possible runtime behavior.

### 8.10 Module Roles

Each module has an Ω role.

Examples:

```text
Pure
UserSpace
KernelSpace
Driver
TrustedModule
SandboxedModule
NetProtocolModule
PolicyModule
ResourceModule
TestModule
SimulationModule
```

Role declaration:

```pmsl
module FS requires role TrustedModule {
    ...
}
```

Role semantics constrain:

```text
which effects may appear
which syscalls may be used
which modules may be imported
which capabilities may be required or provided
which frames may be entered
which FFI calls may be performed
which policies may be installed
which resources may be managed
```

Module-role activation:

```text
Ω_set_role(M.role)
```

Type-checking obligations:

```text
exported symbols obey module role constraints
imported modules are role-compatible
internal calls do not exceed module role authority
public interface does not expose stronger authority than declared
```

A module role is not decorative metadata. It participates in compile-time and runtime admissibility.

A role does not override policy or boundary projection. Ω must remain compatible with Ψ and Χ-projected visibility/reachability constraints.

### 8.11 Module Capabilities

Modules may require, provide, consume, or transfer capabilities.

Example:

```pmsl
module FS {
    capability read_file
    capability write_file
}
```

Caller requirement:

```pmsl
requires Ω(FS.write_file)
```

Capability relationship:

```text
ModuleCapability = (
    name,
    action,
    target,
    mode,
    transfer_policy,
    lifetime,
    policy,
    meta
)
```

Capability check:

```text
Δ classify capability
Ω verify capability is present
Ψ check capability policy
continue operation or deny/trap
```

Capability use examples:

```text
module may read filesystem
module may open network connection
module may spawn tasks
module may import privileged module
module may call foreign host function
module may publish event
module may install policy
```

Capability invariants:

```text
I1: capability names are Δ-distinguished
I2: capability scope is explicit
I3: capabilities do not leak through exports unless declared
I4: capability transfer is policy-governed
I5: imported capabilities do not silently expand module authority
I6: capability use remains boundary-compatible
```

Capabilities support least-authority module design. They are not a mechanism for bypassing module policies or boundary projections.

### 8.12 Module Policies

Modules attach Ψ policies.

Syntax:

```pmsl
module AppLog requires policy SafeFS {
    ...
}
```

Policy set:

```text
ModulePolicySet = {
    safety_policies,
    security_policies,
    lifecycle_policies,
    resource_policies,
    import_export_policies,
    error_policies,
    audit_policies
}
```

Policy examples:

```text
no FFI
read-only imports
audit all exports
all public calls require capability check
no unbounded spawn
no mutable global state
all traps must be handled or declared
module must finalize resources before unload
module may only write /var/log/**
```

Module policy activation:

```text
Ψ_apply(M.policies)
```

Policy enforcement points:

```text
module declaration
import resolution
export commit
function call
frame entry
task spawn
channel creation
FFI declaration
lifecycle hook
version reframe
module unload
```

Violation outcomes:

```text
Ψ denial
Φ trap
Σ rollback of linkage or initialization
Χ-projected quarantine/isolation strengthening
halt under critical runtime policy
```

Module policy is a program/runtime constraint. It is not moral judgment, forensic attribution, or governance authority.

### 8.13 Module Isolation

Modules may be isolated.

Syntax:

```pmsl
module M isolated {
    ...
}
```

Operator reading:

```text
Χ enter projected module isolation context
□ enter module frame
Ω install module role
Ψ activate module policies
```

Isolation properties may include:

```text
no direct pointer sharing
IPC-only interaction
controlled resource access
separate process or sandbox profile
deterministic execution profile
separate runtime heap
restricted import/export surface
restricted FFI access
```

At PMS Base level:

```text
Χ = Distance
```

At PMSL module level:

```text
Χ projects as module boundary, sandbox, visibility control,
reachability discipline, and access separation.
```

Cross-isolation calls must use explicit communication:

```text
message passing
capability token
shared frame with policy
foreign bridge
runtime service call
```

No isolated module may be accessed by ordinary symbol lookup if the boundary forbids it.

Module isolation is a PMSL/PMS-IR layer projection. It does not redefine PMS Base Χ and does not imply fabricated hardware isolation or a completed OS sandbox implementation.

### 8.14 Module Boundary Profiles

A module boundary may have different profiles.

```text
lexical
visibility_only
sandboxed
process_isolated
runtime_isolated
capability_isolated
foreign_boundary
distributed_boundary
```

Examples:

```pmsl
module Math pure { ... }

module Plugin sandboxed { ... }

module Driver isolated requires role Driver { ... }

module RemoteClient distributed { ... }
```

Boundary profile determines:

```text
symbol visibility
memory sharing
call style
IPC requirement
serialization requirement
capability transfer
resource accounting
trace identity
failure containment
```

Boundary compatibility:

```text
caller boundary can reach callee boundary
∧ callee export surface permits call
∧ policy permits crossing
∧ required capability exists
```

A `distributed_boundary` is a language/module profile. Cross-node placement and distributed consistency are defined in `07_distributed_systems.md`.

### 8.15 Import/Export Linking

Module linking is Δ + Σ.

Linking flow:

```text
Δ classify module graph
Δ resolve imports
Δ resolve exports
Ω verify import/export authority
Χ check projected module visibility and boundary compatibility
Ψ check linkage policies
Σ commit link graph
```

Link graph:

```text
ModuleGraph = (
    modules,
    import_edges,
    export_edges,
    interface_edges,
    capability_edges,
    policy_edges,
    version_edges,
    meta
)
```

A link is valid only when:

```text
all imported symbols resolve
∧ required exports exist
∧ no forbidden cycle exists
∧ effect signatures are compatible
∧ capability requirements are satisfiable
∧ policy constraints compose
∧ boundary constraints are compatible
```

Link failure paths:

```text
unknown module              → Δ failure
unknown symbol              → Δ failure
missing capability          → Ω / Ψ
boundary incompatible       → Χ projection / Ψ / Φ
policy conflict             → Ψ
version mismatch            → Φ / Ψ
commit failure              → Σ / Φ
```

Link validation means profile-local acceptance or rejection. It does not prove implementation correctness and does not validate PMS Base.

### 8.16 Module Dependency Graph

A PMSL program forms a module dependency graph.

```text
G_modules = (V_modules, E_imports)
```

where:

```text
V_modules = modules
E_imports = import edges
```

The dependency graph supports analysis of:

```text
cycles
capability flow
policy composition
visibility surfaces
FFI exposure
trusted/untrusted boundaries
resource dependencies
initialization order
finalization order
upgrade impact
trace attribution
```

Cycles may be:

```text
forbidden
allowed only through interfaces
allowed only through lazy linkage
allowed only through runtime service boundary
policy-governed
```

Cycle handling is a Ψ policy choice, not an ad hoc linker behavior.

A dependency graph is an analysis structure. It may support static analysis, model checking, trace mapping, and tooling, but it does not by itself prove module correctness.

### 8.17 Module Initialization

Module initialization is Θ-ordered and Σ-committed.

Lifecycle state:

```text
ModuleState ∈ {
    DECLARED,
    RESOLVED,
    LINKED,
    INITIALIZING,
    ACTIVE,
    DEGRADED,
    REFRAMING,
    FINALIZING,
    UNLOADED,
    FAILED
}
```

Initialization flow:

```text
Δ identify module
Δ resolve imports and required interfaces
Ω install module role
Ψ activate module policy
Χ establish projected boundary
Θ order dependency initialization
∇ run init hook if present
Σ commit initialized state
Ψ post-check invariants
```

Init hook syntax:

```pmsl
module M {
    init {
        prepare()
    }
}
```

Init hook constraints:

```text
effects declared
required capabilities available
policy active
imports initialized or explicitly lazy
resources accounted
failure path declared
boundary projection established before protected access
```

Initialization is not visible as complete until Σ commits module state.

### 8.18 Module Finalization

Finalization closes module lifecycle.

Syntax:

```pmsl
module M {
    finalize {
        flush()
        close()
    }
}
```

Finalization flow:

```text
Θ order finalization before unload
Ψ check unload policy
∇ run finalizers
Σ close resources
Σ commit final module state
Χ retire projected boundary or mark it unreachable under policy
```

Finalization obligations:

```text
close open handles
drain channels if required
cancel or transfer tasks
flush staged commits
release capabilities
persist module state if required
emit audit/trace if policy requires
```

Finalization failure:

```text
Φ finalization trap
Σ partial-close state
Ψ decide retry, quarantine, force unload, or abort
```

A module may not be considered unloaded while live resources remain unless policy explicitly defines forced closure.

Finalization is a lifecycle/commit obligation. It is not optional cleanup folklore.

### 8.19 Module Lifecycle Ordering

Module lifecycle is Θ + Σ.

Canonical order:

```text
DECLARE
→ RESOLVE
→ LINK
→ INIT
→ ACTIVE
→ FINALIZE
→ UNLOAD
```

Expanded sequence:

```text
Δ declare module
Δ resolve symbols
Σ commit declaration
Δ resolve imports
Σ commit linkage
Θ order initialization
∇ run init
Σ commit active state
Θ order finalization
∇ run finalize
Σ commit unload
```

Lifecycle invariants:

```text
module cannot be ACTIVE before linkage commit
module cannot export usable symbols before export commit
module cannot unload while required resources remain live
module cannot reframe without preserving or explicitly closing old obligations
module cannot weaken active policy during lifecycle transition
module cannot bypass boundary projection during state transitions
```

Lifecycle ordering is part of the module semantics. A backend may optimize loading, but it may not erase lifecycle order, policy, boundary, or commit obligations.

### 8.20 Module Versioning

Module versioning is Φ-governed.

Version metadata:

```text
ModuleVersion = (
    name,
    semantic_version,
    interface_hash,
    effect_profile,
    policy_profile,
    compatibility_rules,
    migration_rules,
    meta
)
```

Version compatibility checks:

```text
exports preserved or migration supplied
effect profile not unexpectedly expanded
policy obligations not weakened
capability requirements not silently widened
boundary profile compatible
state migration defined if persistent state exists
```

Version mismatch may produce:

```text
Φ reframe required
Ψ denial
Λ compatible version absent
Σ rollback linkage
```

Versioning is not just a package-manager concern. It changes how a module is interpreted in the active program.

Compatibility checking is profile-bound. It does not prove all future behavior of the upgraded module.

### 8.21 Module Reframing

Reframing upgrades or reinterprets a module under Φ.

Syntax:

```pmsl
reframe M to Version2
```

Operator reading:

```text
Δ identify old module frame
Δ identify target version frame
Ψ check upgrade/reframe policy
Φ recontextualize M.old_frame → M.new_frame
Ω adjust role/capability surface if valid
Χ preserve or transform projected boundary
∇ migrate state if required
Σ commit new module frame
Ψ post-check invariants
```

Reframing use cases:

```text
live upgrade
compatibility layer
ABI migration
policy migration
hot-swapping subsystem
degraded-mode replacement
sandbox strengthening
```

Reframing failure paths:

```text
target version absent        → Λ
policy rejects migration     → Ψ
state migration fails        → Φ
capability mismatch          → Ω / Ψ
boundary mismatch            → Χ projection / Φ
commit failure               → Σ / Φ
```

Reframing must not silently preserve invalid old assumptions.

A reframe event is a typed module recontextualization. It is not proof that old and new modules are semantically equivalent.

### 8.22 Hot Reload and Replacement

Hot reload is a constrained module reframing profile.

```text
hot_reload(M, M_new)
```

Valid hot reload requires:

```text
M_new interface compatible or migration provided
∧ active calls are drained, completed, or redirected
∧ task/channel state is migrated or closed
∧ policy permits live replacement
∧ commit point is defined
∧ boundary transition is explicit
```

Hot reload sequence:

```text
Θ quiesce module activity
Φ create migration context
□ instantiate new ModuleFrame
Ω assign new role/capabilities
Ψ apply new policies
Χ establish or transform projected boundary
∇ migrate state
Σ commit replacement
Χ retire old boundary or quarantine old frame
```

Hot reload is a language/runtime architecture concept.

Concrete implementation belongs to runtime, deployment, loader, and backend profiles.

Hot reload does not imply semantic equivalence, uninterrupted service, or completed runtime support unless such properties are separately specified and evidenced.

### 8.23 Module Types

Modules can be classified by operator composition.

| Module type | Structural profile |
| ----------- | ------------------ |
| Pure Module | mostly Δ, ∇, □, Σ; no privileged IO |
| Isolated Module | uses Χ-projected boundary profile |
| Privileged Module | requires Ω capabilities and stronger Ψ policy |
| Protocol Module | exports typed channels/events/protocol interfaces |
| Transactional Module | exposes Σ commit semantics |
| Reframe Module | supports Φ version shifts or migrations |
| Resource Module | manages memory, storage, IPC, handles, or runtime objects |
| Policy Module | defines or evaluates Ψ constraints |
| Foreign Adapter Module | wraps FFI under □/Χ/Φ/Ω/Ψ |
| Simulation Module | runs under simulator/runtime profile |

These are not new PMS operators. They are module profiles defined by dominant operator obligations.

A module profile may constrain implementation strategy, but it does not imply that a corresponding completed runtime subsystem already exists.

### 8.24 Module-to-Module Calls

A direct module call is valid only within compatible boundaries.

Same-boundary call:

```pmsl
A.f(x)
```

may lower to:

```text
Δ resolve A.f
Ω verify call/export capability
Ψ check call policy
□ enter callee frame
∇ execute
Σ integrate return
Φ handle trap
```

Cross-boundary call must use an explicit bridge.

Possible bridges:

```text
IPC channel
request/response protocol
capability token
shared frame under policy
foreign boundary wrapper
runtime service call
distributed protocol
```

Cross-isolation module call:

```pmsl
send M_inbox <- Request(params)
let response = recv response_ch timeout 500ms
```

Operator reading:

```text
Δ classify request
Ω check caller capability
Χ enforce projected module boundary
Ψ check interaction policy
∇ enqueue request
Σ commit request
Θ wait for response
Λ timeout if absent
Φ handle remote/module trap
Σ integrate response
```

Thus module interaction reuses the concurrency and IPC discipline defined in Section 6.

A call construct may not bypass module boundary, policy, or capability checks merely because both modules are compiled into the same artifact.

### 8.25 Module State

A module may own state.

State categories:

```text
compile-time constants
runtime local state
persistent state
transactional state
cached state
foreign state proxy
shared state
policy state
```

Module-owned state is valid only inside the module frame or through exported interfaces.

State access rule:

```text
access module state valid iff
    symbol is Δ-resolved
    ∧ caller has Ω authority
    ∧ boundary permits reachability
    ∧ policy permits access
    ∧ state lifecycle is active
```

Persistent state requires commit typing.

```text
Persistent<T> requires Σ_persist<T>
```

Transactional module state requires explicit commit/rollback behavior.

```text
Σ_tx<ModuleState>
Φ_trap<TransactionAbort>
```

Module state may not leak through imports, exports, traces, FFI, or shared frames unless an explicit policy and boundary profile permits it.

### 8.26 Module Resource Accounting

Modules consume resources.

Module resource account:

```text
ModuleResourceAccount = (
    memory,
    tasks,
    channels,
    handles,
    timers,
    FFI_handles,
    message_bytes,
    storage,
    CPU_budget,
    policy,
    meta
)
```

Resource accounting flow:

```text
Δ classify module resource event
Ω verify module/resource relation
Ψ check quota
∇ update usage
Σ commit accounting
```

Resource policy examples:

```text
max tasks
max channels
max heap
max open files
max FFI handles
max pending messages
max initialization time
max reload frequency
```

Resource exhaustion outcomes:

```text
Λ no-resource
Ψ denial
Φ runtime trap
Θ throttle
Χ-projected quarantine of module boundary
```

Resource accounting is a runtime/backend profile obligation. PMSL specifies the module-level accounting shape; it does not claim a completed resource-accounting implementation.

### 8.27 Module Error Boundaries

Modules are error boundaries when their boundary or policy defines them as such.

Module-level error handling may include:

```text
trap handlers
default handlers
supervisor policy
quarantine policy
restart policy
degraded-mode policy
export-level error mapping
```

Example:

```pmsl
module Service isolated policy RestartOnFailure {
    trap on Φ_trap<ServiceError> as e {
        recover(e)
    }
}
```

Operator reading:

```text
Φ enter module handler
Ψ apply module recovery policy
∇ execute recovery
Σ commit recovered/degraded/failed state
```

Module error-boundary invariants:

```text
traps crossing module boundary are declared
internal traps do not leak raw implementation state
policy decides recovery/escalation/quarantine
boundary state remains valid during handling
```

A module error boundary is a language/runtime profile. It does not imply a completed supervisor runtime or complete recovery implementation.

### 8.28 Module Policies and Runtime Security

Module policies connect directly to runtime security.

A module policy may specify:

```text
allowed roles
allowed imports
allowed exports
allowed syscalls
allowed FFI
allowed channels
audit requirements
capability requirements
quarantine triggers
version constraints
resource limits
```

This section defines module-level policy attachment. `06_runtime_security.md` defines runtime-security enforcement, identity, trust anchors, audit/compliance hooks, and governance scenarios.

Boundary:

```text
PMSL module policies define language/runtime obligations.
Runtime security defines system-wide enforcement discipline.
```

Module policy enforcement remains program/runtime constraint handling. It is not governance tribunal behavior, moral verdict, or PMS Base validation.

### 8.29 Modules and PMS-IR

PMS-IR must preserve module structure.

Module IR node:

```text
IR.Module = (
    id,
    op = □,
    path,
    symbols,
    imports,
    exports,
    interfaces,
    role,
    capabilities,
    policies,
    boundary,
    lifecycle,
    version,
    body,
    source_span,
    meta
)
```

Import IR node:

```text
IR.Import = (
    op = Δ/Σ,
    importer,
    imported_module,
    symbols,
    alias,
    capability_requirements,
    policy_requirements,
    boundary_requirements,
    source_span
)
```

Export IR node:

```text
IR.Export = (
    op = Σ,
    module,
    symbol,
    public_signature,
    effect_profile,
    required_role,
    required_capability,
    policy,
    boundary,
    source_span
)
```

Reframe IR node:

```text
IR.ModuleReframe = (
    op = Φ,
    old_module,
    new_module,
    migration,
    policy,
    commit,
    source_span
)
```

Boundary node:

```text
IR.ModuleBoundary = (
    op = Χ,
    module,
    boundary_profile,
    visibility_rules,
    reachability_rules,
    import_export_rules,
    transfer_rules,
    policy,
    source_span
)
```

These IR forms allow static analysis, linting, model checking, debugging, simulation, and trace mapping to reason about module structure.

`IR.ModuleBoundary(op = Χ, ...)` denotes the PMSL/PMS-IR projection of PMS Base Χ = Distance into concrete module-boundary obligations.

### 8.30 Static Checks for Modules

A PMSL checker should verify:

```text
module path uniqueness
symbol table coherence
import resolution
export completeness
interface implementation
role compatibility
capability availability
policy non-weakening
boundary compatibility
effect signature compatibility
absence/trap propagation across exports
resource policy declarations
lifecycle hook validity
version compatibility
reframe migration obligations
FFI exposure declarations
cross-isolation communication discipline
```

Example static errors:

```text
unresolved import
exported function uses undeclared capability
module policy weaker than required imported policy
isolated module performs direct pointer sharing
reframe target lacks migration rule
public interface hides Φ trap path
finalizer may leave resource unclosed
```

Each diagnostic should identify:

```text
source span
operator class
failed obligation
module path
affected symbol/interface
```

Static checks are profile-local acceptance/rejection. They do not prove all possible module behavior and do not validate PMS Base.

### 8.31 Runtime Obligations for Modules

A PMSL runtime or backend must preserve module obligations.

Runtime obligations include:

```text
activate module frame
install module role
activate module policies
enforce module boundary
track module lifecycle
commit linkage and initialization
enforce import/export access
account module resources
route module traps
trace module events
support finalization
support reframing only under policy
```

Runtime event examples:

```text
module_declared
module_resolved
module_linked
module_initialized
module_active
module_trap
module_quarantined
module_reframed
module_finalized
module_unloaded
```

These events should be operator-labeled where tracing is enabled.

Runtime obligations are architecture-level requirements. A concrete runtime artifact may implement bounded profiles. PMS-RUST v0.1 may evidence selected bounded slices, but it is not the full PMSL module runtime.

### 8.32 Module Failure Paths

Module failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown module | Δ failure |
| unknown exported symbol | Δ failure |
| import cycle violation | Δ / Ψ |
| missing capability | Ω / Ψ |
| policy conflict | Ψ |
| boundary violation | Χ projection / Ψ / Φ |
| initialization failure | Φ / Σ |
| finalization failure | Φ / Σ |
| version mismatch | Φ / Ψ |
| migration failure | Φ |
| resource exhaustion | Λ / Ψ / Φ |
| commit/link failure | Σ / Φ |
| foreign exposure violation | Χ projection / Ω / Ψ / Φ |

A module system that reports all of these as one undifferentiated linker error loses PMSL structure.

Failure paths must remain visible in PMS-IR, diagnostics, traces, and runtime outcomes under the declared profile.

### 8.33 Trace and Observation Convention for Modules

PMSL modules may emit or participate in trace events under declared runtime profiles.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL module run:

```text
trace_pmsl(runtime, module_artifact, input_profile) ∈ L_PMS
```

For the set of possible module runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, module_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, module_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, module_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A concrete trace records observed execution under a declared profile. It is artifact evidence for bounded implementation behavior. It is not proof of all possible behavior and not PMS Base validation.

### 8.34 Module-Level Invariants

PMSL maintains the following module-system invariants.

```text
I1: every module has a ModuleFrame
I2: every module path is Δ-distinguishable
I3: every local symbol belongs to exactly one defining module frame
I4: every import resolves to a committed export or declared absence/failure path
I5: every export has a type/effect/capability/policy signature
I6: every module has an assigned role or explicit default role
I7: every protected module operation is Ω-authorized
I8: every module policy is Ψ-active during module evaluation
I9: every isolated module has an explicit Χ-projected boundary profile
I10: cross-isolation module calls use IPC, capability bridges, or explicit boundary transfer
I11: module linkage is Σ-committed before exported symbols are used
I12: module initialization and finalization are Θ-ordered
I13: persistent or transactional module state is Σ-typed
I14: module reframe/upgrade is Φ-mediated and Ψ-checked
I15: module capabilities do not leak through exports unless declared
I16: module imports do not silently widen authority
I17: module resource use is accounted where the runtime profile supports accounting
I18: module failure paths remain operator-typed in PMS-IR
I19: module metadata preserves source spans for diagnostics and traces
I20: no module fast path bypasses Ω, Χ projection, Ψ, or Σ obligations
I21: traces record observed module runs under declared profiles; they do not validate PMS Base
I22: AI-proposed module artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL compiler, linker, loader, runtime, or verifier already enforces every invariant.

### 8.35 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for module-adjacent slices when those slices are represented through its supported runtime/profile surface.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR module-adjacent behavior, such as validator acceptance/rejection, deterministic runtime stepping, bounded service calls, JSONL trace emission, golden fixture comparison, and proposal gating.

It does not complete:

```text
PMSL module system
PMSL compiler
PMSL linker
PMSL loader
PMSL package manager
PMSL runtime
PMS-IR optimizer
PMS-CPU
PMS-OS loader
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL module-system implementation and does not validate PMS Base.

### 8.36 AI Module Boundary

The AI Bridge may propose:

```text
module sketches
interface sketches
import/export suggestions
capability requirements
policy hints
PMS-IR module fragments
missing-obligation hypotheses
trace-analysis summaries
candidate diagnostics
simulation scenarios
```

It may not function as:

```text
PMSL semantics
module-system authority
linker authority
type-checker authority
compiler authority
verifier authority
policy authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI-assisted module suggestions are not authoritative module declarations, linker results, verification evidence, policy decisions, or execution authority until host-validated under a declared tooling/profile gate.

### 8.37 Boundary to FFI and Host Interoperability

This section defines PMSL modules.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| foreign symbols and host ABI | Section 9 |
| runtime loading and execution substrate | Section 10 |
| standard-library module domains | Section 11 |
| concrete module APIs | Section 12 |
| PMS-IR complete serialization | Section 13 |
| static module analysis implementation | Section 14 |
| verification of module properties | Section 15 |
| module trace/debug views | Section 16 |
| simulation and emulation of module behavior | Section 17 |
| runtime-security enforcement | `06_runtime_security.md` |
| distributed module placement | `07_distributed_systems.md` |

FFI should be understood as a special module boundary profile in which the callee belongs to a host or non-PMS context. Section 9 refines that boundary.

### 8.38 Architectural Consequence

The consequence of the PMSL module system is:

```text
A PMSL module is a structural program unit: a frame with a symbol table,
role, capability surface, policy set, boundary projection, import/export
contract, lifecycle, version state, and commit discipline. Modules make
program structure analyzable because their linkage, authority, isolation,
effects, traps, state, and upgrades remain visible as Δ–Ψ structure in
PMS-IR.
```

This gives PMSL modularity a direct PMS-STACK role: modules are the language-level mechanism through which frames, authority, policy, boundary projection, integration, lifecycle ordering, and recontextualization become programmable without collapsing into untyped packages or opaque linker behavior.

### 8.39 Module-System Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL module system specifies operator-typed modules: module frames,
symbol tables, imports, exports, interfaces, roles, capabilities,
policies, boundary profiles, linking, dependency graphs, lifecycle,
versioning, reframing, hot reload, module state, resource accounting,
error boundaries, runtime obligations, traces, PMS-RUST evidence
boundaries, and AI proposal boundaries.

This is a language module-system / linkage architecture claim.

It does not claim a completed PMSL module loader, completed linker,
completed package manager, completed compiler, completed runtime loading
system, completed module verifier, completed PMS-OS loader, completed
distributed module runtime, or completed PMSL implementation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR module semantics and
does not validate PMS Base.
```

---

## 9. FFI and Host Interoperability

PMSL defines foreign-function interaction as a controlled boundary operation.

An FFI call is not an untyped escape from PMSL into arbitrary host behavior. It is a □/Φ/Χ-mediated transition into a foreign frame under explicit role, capability, policy, memory, error, commit, trace, and validation constraints.

The central FFI claim is:

```text
PMSL FFI is valid when host calls, native functions, external libraries,
foreign memory, callbacks, service handles, host errors, AI/tooling
services, and simulation harnesses are represented as Δ-classified,
Ω-authorized, Χ-projection-bounded, Φ-recontextualized,
Ψ-constrained, and Σ-integrated transitions across a ForeignFrame or
HostService boundary.
```

This section defines FFI and host interoperability at PMSL/PMS-IR specification level. It does not claim that a complete PMSL FFI implementation, ABI compiler, host binding generator, sandbox runtime, host service bridge, or AI/tooling bridge already exists.

Claim type:

```text
LANGUAGE FFI / HOST-INTEROPERABILITY ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL FFI and host interoperability as an
operator-typed language/runtime architecture.

It does not claim a completed PMSL FFI implementation, completed ABI
compiler, completed host binding generator, completed sandbox runtime,
completed host-service bridge, completed AI/tooling bridge, completed
runtime adapter, completed verifier, or completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared FFI schema, ABI profile, host-service profile, runtime profile, sandbox profile, PMS-IR schema, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, ABI correctness, host-sandbox correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR FFI level, Χ is projected as host boundary, sandbox boundary, memory visibility, handle reachability, process boundary, ABI boundary, runtime boundary, service boundary, and tooling boundary.

PMSL/PMS-IR does not redefine Χ.

### 9.1 Role of FFI in PMSL

FFI connects PMSL programs to systems outside the PMSL semantic frame.

Examples:

```text
host OS calls
C ABI functions
Rust functions
native libraries
filesystem APIs
network APIs
database clients
cryptographic libraries
device APIs
runtime services
AI/tooling services
simulation harnesses
test fixtures
```

PMSL treats all such interactions through a structural rule:

```text
foreign interaction = controlled frame transition
```

The source-level call may look ordinary:

```pmsl
host_read(path)
```

but its operator reading is not ordinary:

```text
Δ classify foreign symbol
Ω verify foreign-call capability
Χ establish projected foreign boundary
Φ reframe PMSL calling context into host ABI/context
∇ execute host action
Σ integrate returned value or effect state
Φ map host error into PMSL trap/absence/result
Ψ enforce FFI policy
```

FFI therefore belongs to the same operator discipline as syscalls, traps, modules, channels, runtime services, and host-backed tooling.

A PMSL implementation may run on an existing host OS, call native libraries, and interact with services. That supports execution profiles; it does not make host behavior equivalent to PMS-OS and does not validate PMS Base.

### 9.2 ForeignFrame

A foreign call executes inside a `ForeignFrame`.

```text
ForeignFrame = (
    id,
    host,
    abi,
    symbol,
    input_types,
    output_type,
    memory_model,
    boundary,
    capabilities,
    policy,
    error_map,
    commit_profile,
    trace_profile,
    meta
)
```

where:

| Field | Meaning |
| ----- | ------- |
| `id` | stable foreign-frame identifier |
| `host` | host runtime, OS, library, process, VM, service, or tooling surface |
| `abi` | calling convention / ABI profile |
| `symbol` | foreign function or service symbol |
| `input_types` | PMSL-to-host argument mapping |
| `output_type` | host-to-PMSL result mapping |
| `memory_model` | copy, borrow, pin, shared, opaque handle, serialized |
| `boundary` | PMSL/PMS-IR host-boundary projection of Χ |
| `capabilities` | Ω permissions required |
| `policy` | Ψ FFI constraints |
| `error_map` | host error → Λ/Φ/Ψ/Σ mapping |
| `commit_profile` | visibility/durability/effect integration profile |
| `trace_profile` | trace/audit representation |
| `meta` | source span, diagnostics, version, security metadata |

A `ForeignFrame` is valid when:

```text
foreign symbol is Δ-distinguishable
∧ ABI is known
∧ argument and result mappings are typed
∧ caller has required Ω capability
∧ host boundary projection is explicit
∧ memory transfer is defined
∧ host effects are declared
∧ host errors are mapped
∧ commit behavior is defined
∧ policy permits the call
```

A `ForeignFrame` is a PMSL/PMS-IR structure. It may be implemented by different backend mechanisms under declared profiles.

### 9.3 Foreign Declarations

PMSL declares foreign functions explicitly.

Syntax:

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.read)
```

General form:

```pmsl
foreign fn name(params...)
    -> ReturnType
    effects(...)
    requires ...
```

Foreign declaration lowering:

```text
Δ distinguish foreign function name
Δ classify host symbol and ABI
□ create ForeignFrame
Ω attach required capabilities
Χ attach projected host boundary
Ψ attach FFI policy
Σ commit declaration into module symbol table
```

A foreign declaration is a contract. It must state or allow inference of:

```text
foreign symbol
ABI profile
argument mapping
return mapping
effects
capability requirements
policy requirements
boundary behavior
error mapping
commit behavior
trace behavior where required
```

A compiler may infer some obligations, but PMS-IR must preserve them whether explicit or inferred.

If an implementation cannot reconstruct required authority, policy, boundary, memory transfer, host error mapping, or commit profile, it must require explicit syntax or reject the declaration under the active profile.

### 9.4 Foreign Calls

A foreign call enters a foreign frame.

Syntax:

```pmsl
let data = host_read(path)
```

Primary operators:

```text
Φ / □
```

Lowering:

```text
Δ resolve foreign symbol
Δ classify arguments
Ω verify foreign-call capability
Χ verify host boundary access
Ψ check FFI policy
Φ reframe PMSL call into foreign ABI
□ enter ForeignFrame
∇ execute host call
Φ map host result/error into PMSL representation
Σ integrate result or effect state
□ restore PMSL frame
```

PMS-IR sketch:

```text
IR.ForeignCall {
    op: Φ/□,
    symbol: host_read,
    foreign_frame: ForeignFrame,
    args,
    result_type,
    effects,
    capability: Ω(host.fs.read),
    boundary: Χ_projection(host),
    policy: Ψ(ffi_policy),
    error_map,
    commit_profile,
    source_span
}
```

Foreign-call invariants:

```text
I1: foreign symbol is resolvable
I2: argument mapping is typed
I3: caller has foreign-call authority
I4: host boundary projection is explicit
I5: host effects are declared
I6: host errors are mapped
I7: PMSL frame is restored or explicitly recontextualized
I8: result integration occurs through Σ
I9: trace/audit obligations are preserved where policy requires them
```

A foreign call is not PMSL-conformant if it hides host effects, host error semantics, memory transfer, policy, authority, boundary, or commit behavior.

### 9.5 FFI as Recontextualization

FFI is Φ-governed because execution changes interpretation context.

Before FFI:

```text
PMSL frame
PMSL types
PMSL role/capability state
PMSL policy
PMSL memory model
PMSL error model
```

During FFI:

```text
foreign frame
host ABI
host memory model
host error model
host scheduling / blocking behavior
host resource model
```

After FFI:

```text
PMSL value, absence, trap, denial, or committed effect
```

Recontextualization rule:

```text
foreign context may be entered only through explicit Φ
and may return only through typed PMSL integration.
```

This prevents host semantics from being silently treated as PMSL semantics.

The host context may execute real host behavior, but PMSL only admits the result through declared PMSL/PMS-IR mappings.

### 9.6 Capability Gating

Foreign calls require Ω authority.

Examples:

```pmsl
requires Ω(host.fs.read)
requires Ω(host.fs.write)
requires Ω(host.net.connect)
requires Ω(host.process.spawn)
requires Ω(host.crypto.use_key)
requires Ω(host.ai.request)
```

Capability check:

```text
Δ classify requested host action
Ω verify active role/capability
Ψ check FFI policy
continue or deny/trap
```

A PMSL module may expose a foreign binding without granting all callers the ability to use it.

Example:

```pmsl
module HostFS isolated {
    foreign fn raw_read(path: HostPath)
        -> Result<Bytes, Φ_trap<HostError>>
        effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
        requires Ω(host.fs.read)

    export fn read(path: Path)
        -> Result<Bytes, Φ_trap<IOError>>
        requires Ω(fs.read)
    {
        raw_read(map_host_path(path))
    }
}
```

The exported function may narrow or wrap the foreign capability surface.

Ω does not override policy or boundary projection. A caller with a capability still requires compatible Ψ policy and Χ-projected reachability.

### 9.7 Boundary and Sandbox Rules

At PMS Base level:

```text
Χ = Distance
```

At PMSL FFI level:

```text
Χ projects as host boundary, sandbox boundary, memory visibility,
handle reachability, process boundary, ABI boundary, runtime boundary,
and service boundary.
```

Foreign boundary profiles:

```text
in_process_native
sandboxed_native
host_os_service
out_of_process_service
wasm_host_function
vm_host_call
network_service
test_harness
simulation_host
tooling_service
```

Boundary rule:

```text
PMSL value or capability may cross into a foreign boundary only through
an explicit transfer, copy, borrow, serialization, handle, or bridge profile.
```

Boundary failure produces:

```text
Χ projection / Ψ denial
Φ_trap<BoundaryFault>
```

or a typed result branch.

No host call may receive implicit access to PMSL frames, module state, task state, policy state, or capabilities unless the FFI profile explicitly exposes them.

FFI boundary discipline is an implementation-layer projection of PMS Base Χ = Distance. It does not redefine Χ and does not imply completed OS/hardware isolation.

### 9.8 Memory Interaction

Foreign memory interaction must be typed.

Memory transfer profiles:

```text
copy_in
copy_out
copy_in_out
borrow_readonly
borrow_mut
pin
opaque_handle
shared_buffer
serialized_message
mapped_region
```

Example declaration:

```pmsl
foreign fn host_hash(data: Borrowed<Bytes, readonly>)
    -> Result<Hash, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.crypto.hash)
```

Memory rules:

```text
copy_in:
    host receives copy, no PMSL memory alias

copy_out:
    host produces value copied into PMSL frame

borrow_readonly:
    host may read during call lifetime only

borrow_mut:
    host may mutate bounded region under policy

pin:
    PMSL memory region cannot move during foreign call

opaque_handle:
    PMSL receives handle, not raw memory

shared_buffer:
    explicit shared frame with synchronization discipline

mapped_region:
    host-visible mapping under Χ/Ψ constraints
```

Memory invariants:

```text
I1: host pointer access is bounded
I2: host cannot access PMSL memory outside declared region
I3: mutable borrow is exclusive or synchronized
I4: lifetime does not outlive valid frame
I5: ownership transfer is explicit
I6: raw host pointers do not become ordinary PMSL references
I7: foreign memory errors map to Φ/Ψ outcomes
I8: memory transfer preserves boundary projection
```

Memory interaction is a high-risk interoperability surface. PMSL makes it analyzable by keeping transfer profile, authority, boundary, policy, and failure behavior explicit.

### 9.9 Foreign Handles

Many host systems return handles.

Examples:

```text
file handle
socket handle
database connection
thread handle
library context
device handle
AI session handle
process handle
```

PMSL represents them as typed foreign handles:

```pmsl
ForeignHandle<HostFile>
ForeignHandle<HostSocket>
ForeignHandle<HostSession>
```

Handle structure:

```text
ForeignHandle<T> = (
    id,
    host,
    resource_type,
    ownership,
    capabilities,
    boundary,
    lifetime,
    close_policy,
    meta
)
```

Handle validity:

```text
handle is Δ-distinguished
∧ handle owner is known
∧ active role may use handle
∧ boundary relation remains valid
∧ resource is live
∧ policy permits operation
```

Handle closure:

```text
Δ classify handle
Ω verify close authority
Ψ check lifecycle policy
∇ perform host close
Σ commit handle closed
Φ map close failure if any
```

A foreign handle is not an untyped integer. It is a frame-bound, capability-governed resource.

A handle leak is a Σ/Ψ lifecycle failure and may map to Φ under the active runtime policy.

### 9.10 Host Error Mapping

Host errors must be mapped into PMSL outcome classes.

Host outcomes:

```text
success
not found
timeout
permission denied
invalid argument
resource exhausted
interrupted
would block
foreign exception
host panic
ABI mismatch
boundary violation
commit failure
```

Mapping table:

| Host outcome | PMSL operator reading |
| ------------ | --------------------- |
| success | Σ integration |
| not found as expected | Λ |
| timeout | Λ / Θ |
| permission denied | Ω / Ψ / Φ |
| invalid argument | Δ / Φ |
| resource exhausted | Λ / Ψ / Φ |
| would block | Λ |
| interrupted | Φ |
| foreign exception | Φ |
| host panic | Φ / Ψ |
| ABI mismatch | Φ / Ψ |
| boundary violation | Χ projection / Ψ / Φ |
| durability failure | Σ / Φ |

Foreign error map:

```text
ForeignErrorMap = HostErrorCode → PMSLOutcome
```

Example:

```pmsl
error_map host_fs_errors {
    ENOENT      -> Λ_absent<Path>
    EACCES      -> Φ_trap<AuthError>
    ETIMEDOUT   -> Λ_absent<Response>
    EIO         -> Φ_trap<IOError>
    ENOSPC      -> Λ_absent<Space> | Φ_trap<ResourceError>
}
```

The map must be explicit or provided by a standard FFI profile.

A foreign error may not leak into PMSL as an opaque host integer unless the active profile declares such an opaque representation.

### 9.11 Host Blocking and Scheduling

Host calls may block.

PMSL must represent blocking as Θ/Λ/Ψ structure.

Blocking profiles:

```text
nonblocking
may_block
blocking_with_timeout
async_host_call
runtime_thread_offload
event_loop_integration
foreign_callback
```

Example:

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Λ_absent<Bytes> | Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Θ, Λ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.read)
```

Blocking call reading:

```text
Δ classify call
Ω verify capability
Χ enter projected host boundary
Θ suspend or offload current task
Λ timeout/not-ready if configured
∇ perform host action
Σ integrate result
Φ map host error
```

Policy may restrict blocking calls:

```text
no blocking in event loop
no blocking in interrupt-like runtime context
no unbounded host call
timeout required
offload required
```

Scheduling behavior is runtime/profile-bound. PMSL may express the scheduling obligation; it does not guarantee host scheduler behavior by syntax alone.

### 9.12 Async Foreign Calls

An async foreign call separates call initiation from completion.

Syntax:

```pmsl
let fut = foreign_async host_read(path)
let data = await fut timeout 100ms
```

Semantic entity:

```text
ForeignFuture<T> = (
    id,
    foreign_call,
    state,
    result,
    boundary,
    policy,
    meta
)
```

Initiation:

```text
Δ classify foreign async call
Ω verify authority
Χ establish projected host boundary
Ψ check async policy
∇ submit host operation
Σ commit pending future
```

Await:

```text
Θ wait for host completion
Λ if completion absent before timeout
Φ map host error
Σ integrate result
```

Async FFI invariants:

```text
I1: pending future is distinguishable
I2: host operation has lifecycle owner
I3: cancellation path is defined
I4: timeout path is Λ-visible
I5: host completion is mapped into PMSL outcome
I6: resources are closed on cancellation or drop according to policy
I7: boundary state remains valid until completion or cancellation
```

Async FFI must not hide pending host work outside PMSL lifecycle discipline.

### 9.13 Callbacks from Host into PMSL

A host may call back into PMSL only through an explicit callback frame.

Callback declaration:

```pmsl
callback fn on_event(ev: HostEvent)
    -> Result<Unit, Φ_trap<CallbackError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
```

Callback entry flow:

```text
Δ classify callback symbol and payload
Χ enter PMSL callback boundary
Ω verify callback authority or token
Ψ check callback policy
Φ recontextualize host event into PMSL handler frame
□ enter callback frame
∇ execute callback body
Σ integrate callback result
Φ map PMSL trap back to host profile
```

Callback invariants:

```text
I1: callback is registered explicitly
I2: host cannot invoke arbitrary PMSL functions
I3: callback payload is typed and validated
I4: callback executes under defined role and policy
I5: reentrancy behavior is policy-defined
I6: trap propagation back to host is mapped
I7: callback boundary projection remains explicit
```

Host callbacks are controlled re-entry points. They are not general access to PMSL execution.

### 9.14 Host Services

Some host interactions are service calls rather than raw functions.

Examples:

```text
host filesystem service
host networking service
host logging service
host AI proposal service
host clock service
host random service
host test harness
```

Service call form:

```pmsl
service HostFS.read(path)
```

Service profile:

```text
HostService = (
    name,
    operations,
    request_type,
    response_type,
    capabilities,
    boundary,
    policy,
    trace_profile,
    meta
)
```

Service call lowering:

```text
Δ classify service and operation
Ω verify service capability
Χ enter projected service boundary
Ψ check service policy
∇ send/request operation
Θ await result if async
Λ represent no-response/timeout
Φ map service error
Σ integrate response
```

Host services are often better than raw FFI because they can preserve typed request/response structure, traceability, and policy hooks.

A host service is still a foreign boundary. It is not PMSL semantic authority.

### 9.15 AI and Tooling Services as Host Services

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

AI-related tooling is not a PMSL language feature.

If an AI bridge is connected to PMSL/PMS-IR tooling, it is treated as an optional host/tooling service boundary.

Permitted role:

```text
AI proposes PMS-IR or opcode programs.
AI analyzes traces.
AI suggests explanations.
AI proposes missing-obligation hypotheses.
AI drafts diagnostics or simulation scenarios.
```

Not permitted role:

```text
AI defines PMSL semantics.
AI authorizes execution.
AI validates PMS-IR.
AI replaces policy evaluation.
AI becomes trusted executable code.
AI emits verification evidence.
AI validates PMS Base.
```

Host-service reading:

```text
Δ classify AI task
Ω verify tooling capability
Χ enter tooling/host boundary
Ψ enforce proposal policy
∇ submit request
Φ/Λ handle malformed, absent, or failed response
Σ integrate advisory result if accepted by host tooling
```

Authority boundary:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output is not PMSL source authority.

AI output is not PMS-IR truth.

AI output is not verification evidence.

AI output is not trusted executable code.

AI output is not PMS Base validation.

The detailed AI proposal boundary belongs in Section 13, AI-assisted trace analysis belongs in Section 16, and simulation-related AI boundaries belong in Section 17. This section establishes the FFI/host-service interpretation.

### 9.16 Host OS Interoperability

PMSL may run on a host OS before a full PMS-OS exists.

In that profile, host OS services are treated as foreign or service frames.

Examples:

```text
host_open
host_read
host_write
host_socket
host_spawn
host_time
host_random
host_env
host_log
```

Host OS projection:

```text
POSIX/Windows/host primitive
→ ForeignFrame or HostService
→ PMSL operator profile
→ PMS-IR-visible call
```

Example mapping:

| Host concept | PMSL projection |
| ------------ | --------------- |
| file descriptor | `ForeignHandle<HostFile>` |
| host process | `ForeignHandle<HostProcess>` / `ProcessBoundary` |
| host thread | `ForeignHandle<HostThread>` / `RuntimeTask` |
| socket | `ForeignHandle<HostSocket>` |
| host error code | Λ/Φ/Ψ mapped outcome |
| environment variable | HostService query |
| signal | Φ callback/trap |
| host timeout | Λ/Θ |
| permission denial | Ω/Ψ/Φ |

This allows PMSL to run on existing systems while preserving operator semantics.

Portability boundary:

```text
Host interop supports execution profiles.
It does not make host OS behavior equivalent to PMS-OS.
```

Host OS interoperability is implementation-facing. It does not claim PMS-OS completion or host/PMS-OS semantic equivalence.

### 9.17 Native ABI Profiles

A native ABI profile describes call representation.

```text
ABIProfile = (
    name,
    calling_convention,
    parameter_layout,
    return_layout,
    stack_rules,
    register_rules,
    alignment,
    ownership_rules,
    error_rules,
    unwind_rules,
    meta
)
```

Examples:

```text
C_ABI
Rust_ABI_profile
SystemV
Windows_x64
WASM_host
CustomRuntimeABI
```

ABI profile obligations:

```text
argument layout known
return layout known
ownership/lifetime known
error/unwind behavior known
stack/register rules known if native
policy permits ABI crossing
boundary profile permits ABI crossing
```

Unspecified ABI behavior is invalid for safe PMSL FFI.

An ABI profile is a declared interoperability contract. It is not a proof that a host compiler or native library behaves correctly.

### 9.18 Foreign Type Mapping

PMSL values must be mapped into host representations.

Type mapping:

```text
PMSLType ↔ HostType
```

Examples:

| PMSL type | Host representation |
| --------- | ------------------ |
| `Int` | fixed-width integer |
| `Bool` | ABI boolean |
| `String` | UTF-8 pointer/length or host string object |
| `Bytes` | pointer/length buffer |
| `Path` | encoded host path |
| `Result<T,E>` | tagged representation or error-map convention |
| `Option<T>` | nullable/flagged representation |
| `ForeignHandle<T>` | opaque host handle |
| `Channel<T>` | not passed raw unless bridge exists |
| `Task<T>` | not passed raw unless runtime profile exists |

Mapping rules:

```text
lossless where required
policy-approved where lossy
boundary-safe
lifetime-safe
ownership-explicit
```

Invalid mapping produces:

```text
Δ / Φ type-mapping error
```

Foreign type mapping must not silently erase traps, absence, policy denial, boundary state, or commit semantics.

### 9.19 Serialization Boundaries

Some FFI profiles require serialization.

Examples:

```text
JSON
CBOR
MessagePack
binary schema
PMS-IR JSON
host protocol envelope
```

Serialization flow:

```text
Δ classify value and schema
Ψ check serialization policy
∇ encode value
Σ commit encoded message
Χ transfer across projected boundary
Φ map decode/encode failure
```

Deserialization flow:

```text
Δ classify incoming payload
Ψ validate schema/policy
∇ decode
Σ integrate value
Φ trap on invalid payload
```

Serialization is useful when:

```text
crossing process boundary
calling service API
communicating with AI/tooling service
running tests
simulating distributed runtime
isolating plugins
```

Serialization validates data shape only under the declared schema/profile. It is not verification of semantic correctness and not PMS Base validation.

### 9.20 FFI and Effects

Foreign declarations must expose effects.

Effect examples:

```pmsl
effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
effects(Δ, Ω, Χ, Θ, Λ, Φ, ∇, Σ, Ψ)
effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ, Λ)
```

Common profiles:

```text
pure_foreign
read_only_foreign
stateful_foreign
blocking_foreign
async_foreign
callback_foreign
resource_foreign
unsafe_foreign
service_foreign
tooling_foreign
```

Effect checking rule:

```text
foreign call effects must be declared
∧ declared effects must be permitted by active frame, role, policy, and boundary
```

A foreign function that mutates host state cannot be typed as pure.

`Effect<Χ>` denotes the PMSL/PMS-IR projection of PMS Base Χ = Distance into a host, service, memory, ABI, sandbox, runtime, or tooling boundary obligation.

### 9.21 Unsafe FFI

Some FFI operations may be marked unsafe.

Syntax:

```pmsl
unsafe foreign fn raw_call(ptr: HostPtr)
    -> Result<Int, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.unsafe)
```

Unsafe FFI means:

```text
the compiler cannot fully enforce all safety obligations statically
```

It does not mean:

```text
operator discipline is suspended
```

Unsafe FFI still requires:

```text
explicit capability
explicit boundary
explicit policy
explicit type mapping
explicit error mapping
explicit commit behavior
traceability where required
```

Unsafe FFI is a higher-risk profile, not an ungoverned one.

Unsafe FFI may strengthen the need for audit, sandboxing, dynamic validation, or proof obligations. It does not remove PMSL/PMS-IR conformance obligations.

### 9.22 FFI Policies

FFI policies constrain foreign interaction.

Examples:

```text
NoFFI
AllowReadOnlyHostFS
DenyProcessSpawn
RequireTimeout
RequireAudit
NoBlockingHostCalls
SandboxForeignCalls
NoRawPointers
NoMutableBorrowAcrossHost
AllowAIProposalOnly
RequireSerialization
```

Policy evaluation:

```text
Δ classify foreign call
Ω inspect caller capability
Χ inspect projected boundary profile
Ψ evaluate FFI policy
continue / deny / trap / audit / quarantine
```

FFI policy may govern:

```text
allowed hosts
allowed symbols
allowed libraries
allowed ABIs
allowed memory transfer profiles
allowed callbacks
allowed blocking behavior
allowed handle lifetimes
allowed error mappings
required audit
required sandbox
```

FFI policies are program/runtime constraints. They are not moral verdicts, forensic attribution, or governance authority.

### 9.23 FFI Commit Semantics

Foreign calls may have effects that require commit interpretation.

Examples:

```text
host file write
database transaction
socket send
audit emission
process spawn
service request
AI proposal acceptance
device operation
```

Commit profiles:

```text
no_commit
local_result
visible_host_effect
durable_host_effect
transactional_host_effect
eventual_host_effect
advisory_result
```

Example:

```pmsl
foreign fn host_write(path: HostPath, data: Bytes)
    -> Result<Σ_visible<Unit>, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
```

Commit rule:

```text
PMSL must not claim stronger commit semantics than the host profile provides.
```

A host write that only buffers data cannot be typed as:

```text
Σ_durable<Unit>
```

unless the FFI profile includes the required durability guarantee.

A PMSL commit type records the integration claim under a declared profile. It is not proof that the host physically persisted the data unless that property is separately evidenced under declared assumptions.

### 9.24 FFI Trace and Audit

Foreign interaction should be traceable when policy requires it.

Trace record:

```text
ForeignCallTrace = (
    event_id,
    module,
    function,
    foreign_symbol,
    host,
    abi,
    actor_role,
    boundary,
    policy_decision,
    effects,
    result_class,
    commit_state,
    timestamp_or_order,
    source_span,
    meta
)
```

Trace flow:

```text
Δ classify foreign call
Ψ decide trace requirement
∇ perform call
Σ commit trace record if required
Φ record trap if failure occurs
```

Trace must distinguish:

```text
foreign call requested
foreign call denied
foreign call executed
foreign call returned absence
foreign call trapped
foreign call committed effect
foreign call left pending async state
```

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL FFI run:

```text
trace_pmsl(runtime, ffi_artifact, input_profile) ∈ L_PMS
```

For the set of possible FFI runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, ffi_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, ffi_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, ffi_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A concrete trace records observed execution under a declared profile. It is artifact evidence for bounded implementation behavior. It is not proof of all possible behavior and not PMS Base validation.

### 9.25 FFI and PMS-IR

PMS-IR must preserve foreign structure.

Foreign declaration IR:

```text
IR.ForeignDecl = (
    id,
    op = □,
    name,
    host_symbol,
    abi,
    params,
    result,
    effects,
    capabilities,
    boundary,
    policy,
    error_map,
    commit_profile,
    source_span
)
```

Foreign call IR:

```text
IR.ForeignCall = (
    id,
    op = Φ/□/∇,
    decl,
    args,
    memory_transfer,
    boundary,
    capability_check,
    policy_check,
    result_mapping,
    error_mapping,
    commit_behavior,
    source_span
)
```

Foreign handle IR:

```text
IR.ForeignHandle = (
    id,
    op = □,
    host,
    resource_type,
    owner,
    capability,
    lifetime,
    close_policy,
    boundary,
    source_span
)
```

Host service IR:

```text
IR.HostServiceCall = (
    id,
    op = Δ/Ω/Χ/Ψ/∇/Σ,
    service,
    operation,
    request,
    response_type,
    timeout?,
    error_map,
    commit_profile,
    source_span
)
```

AI/tooling service IR:

```text
IR.ToolingServiceCall = (
    id,
    op = Δ/Ω/Χ/Ψ/∇/Σ,
    service,
    advisory_request,
    advisory_response_type,
    proposal_status,
    validation_gate,
    execution_status,
    source_span
)
```

These nodes let tools analyze FFI rather than treating it as an opaque black box.

`IR.ToolingServiceCall` may represent AI proposal surfaces, but it does not make AI output executable or authoritative.

### 9.26 Static Checks for FFI

A PMSL checker should verify:

```text
foreign symbol declaration exists
ABI profile is specified
argument and result mappings are valid
foreign effect set is declared
required capability exists
boundary profile is explicit
memory transfer profile is safe or marked unsafe
host errors are mapped
blocking behavior is declared
callback entry is registered and typed
foreign handle lifecycle is closed or transferred
commit claims match host guarantees
FFI policy permits the call
unsafe FFI is isolated and capability-gated
AI/tooling service output remains advisory until host validation
```

Example static errors:

```text
foreign call lacks capability
raw pointer crosses boundary without transfer profile
host error map missing timeout case
blocking host call in nonblocking task context
foreign handle returned without lifetime policy
declared durable commit unsupported by host profile
callback may reenter module without policy
AI proposal treated as executable PMS-IR without validation gate
```

Static FFI checks are profile-local acceptance/rejection. They do not prove host behavior and do not validate PMS Base.

### 9.27 Runtime Checks for FFI

Runtime checks include:

```text
capability validation
policy evaluation
boundary activation
argument validation
memory pin/copy/borrow setup
timeout installation
host call execution
host error mapping
result validation
commit-state recording
handle lifecycle tracking
trace emission
cleanup on trap/cancellation
AI/tooling proposal status tracking where applicable
```

Runtime failure paths:

```text
capability missing        → Ω/Ψ
boundary invalid          → Χ projection / Ψ / Φ
argument invalid          → Δ/Φ
host timeout              → Λ
host error                → Φ or mapped Λ/Ψ
commit failure            → Σ/Φ
unsafe memory violation   → Φ/Ψ, quarantine if policy requires
callback violation        → Φ/Ψ
AI response malformed     → Δ/Φ
AI response absent        → Λ
AI proposal rejected      → Ψ/profile rejection
```

Runtime optimizations must preserve these classifications.

Runtime checking is implementation-facing. This section specifies the obligation architecture, not a completed runtime.

### 9.28 FFI Failure Paths

FFI failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown foreign symbol | Δ failure |
| ABI mismatch | Φ / Ψ |
| missing foreign capability | Ω / Ψ |
| host boundary denied | Χ projection / Ψ / Φ |
| invalid argument mapping | Δ / Φ |
| memory transfer violation | Χ projection / Φ / Ψ |
| host timeout | Λ / Θ |
| host would-block | Λ |
| host permission denied | Ω / Ψ / Φ |
| host resource exhausted | Λ / Ψ / Φ |
| foreign exception | Φ |
| host panic | Φ / Ψ |
| callback violation | Φ / Ψ |
| handle leak | Σ / Ψ |
| close failure | Φ / Σ |
| commit mismatch | Σ / Φ |
| trace/audit failure | Σ / Ψ / Φ |
| malformed AI/tooling response | Δ / Φ |
| rejected AI/tooling proposal | Ψ / validation rejection |

This table is normative for preserving structure in diagnostics and PMS-IR.

A foreign subsystem that collapses all failures into one opaque host error loses PMSL structure.

### 9.29 Example: Host Filesystem Read

Source:

```pmsl
foreign fn host_read(path: HostPath)
    -> Result<Bytes, Λ_absent<Path> | Φ_trap<HostIOError>>
    effects(Δ, Ω, Χ, Θ, Λ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.read)

fn read_config(path: Path)
    -> Result<Bytes, Λ_absent<Path> | Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Θ, Λ, Φ, ∇, Σ, Ψ)
    requires Ω(fs.read)
{
    let hp = map_to_host_path(path)
    host_read(hp)
}
```

Operator reading:

```text
Δ classify PMSL path
Ω verify fs.read capability
Ψ check path policy
Φ map Path → HostPath
Δ classify foreign symbol host_read
Ω verify host.fs.read capability
Χ enter projected host filesystem boundary
Θ account for possible blocking
Λ map not-found/timeout if expected
∇ execute host read
Φ map host IO error
Σ integrate bytes into PMSL frame
```

This example illustrates host-service projection. It does not imply that host filesystem behavior is equivalent to PMS-OS filesystem behavior.

### 9.30 Example: Foreign Handle Lifecycle

Source:

```pmsl
foreign fn host_open(path: HostPath)
    -> Result<ForeignHandle<HostFile>, Φ_trap<HostIOError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.open)

foreign fn host_close(file: ForeignHandle<HostFile>)
    -> Result<Σ_local<Unit>, Φ_trap<HostIOError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.fs.close)

fn with_file(path: Path)
    -> Result<Unit, Φ_trap<IOError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
{
    let f = host_open(map_to_host_path(path))?
    try {
        use_file(f)
    } finally {
        host_close(f)
    }
}
```

Operator reading:

```text
host_open:
    Δ classify host path
    Ω verify open capability
    Χ enter projected host boundary
    ∇ acquire host file handle
    Σ integrate ForeignHandle<HostFile>

finally:
    Δ classify handle
    Ω verify close capability
    ∇ close host resource
    Σ commit closure
    Φ map close failure if policy requires
```

The handle lifecycle is visible and typed.

The example demonstrates the FFI lifecycle architecture; it does not claim a completed host binding generator or completed runtime implementation.

### 9.31 Example: Host Service / AI Proposal Boundary

Source sketch:

```pmsl
service AIProposal {
    fn propose_ir(prompt: String)
        -> Result<Advisory<PMSIRFragment>, Φ_trap<ServiceError>>
        effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
        requires Ω(host.ai.request)
}
```

Operator reading:

```text
Δ classify advisory request
Ω verify AI tooling capability
Χ enter host/tooling boundary
Ψ enforce proposal-only policy
∇ submit request
Φ map malformed or failed response
Σ integrate advisory artifact
```

Required boundary:

```text
Advisory<PMSIRFragment> is not executable.
```

Execution requires separate host validation:

```text
parse
canonicalize
map
validate
policy-check
runtime/kernel acceptance
```

This keeps AI tooling outside PMSL semantics.

The AI proposal may be useful. It is not PMSL source authority, not PMS-IR truth, not verification evidence, not trusted executable code, and not PMS Base validation.

### 9.32 Example: Invalid FFI Escape

Invalid source sketch:

```pmsl
foreign fn raw_host_write(ptr: HostPtr, len: Int)
    -> Unit
```

Invalidity condition:

```text
no ABI profile
no memory transfer profile
no capability requirement
no boundary profile
no error map
no commit profile
no policy
```

Invalid operator collapse:

```text
host effect → ordinary Unit
```

without required:

```text
Δ foreign symbol classification
Ω host authority
Χ projected host boundary
Ψ FFI policy
Φ host error mapping
Σ host effect integration
```

A conformant declaration must restore the missing obligations, for example:

```pmsl
unsafe foreign fn raw_host_write(ptr: HostPtr, len: Int)
    -> Result<Σ_visible<Unit>, Φ_trap<HostError>>
    effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
    requires Ω(host.unsafe), Ψ(AllowRawHostWrite)
```

Unsafe FFI remains governed. It is not an operator-free escape hatch.

### 9.33 FFI Invariants

PMSL maintains the following FFI and host-interoperability invariants.

```text
I1: every foreign symbol is Δ-distinguishable
I2: every foreign declaration has a ForeignFrame or HostService profile
I3: every foreign call is Ω-authorized
I4: every foreign call crosses an explicit Χ-projected boundary
I5: every foreign call is Ψ-policy-constrained
I6: every foreign call recontextualizes through Φ
I7: every argument and result mapping is typed
I8: every memory transfer profile is explicit
I9: raw pointers do not become ordinary PMSL references
I10: foreign handles have lifecycle and close policy
I11: host errors map to Λ, Φ, Ψ, Χ projection, Ω, or Σ outcomes
I12: blocking behavior is declared through Θ/Λ profiles
I13: async foreign calls have explicit lifecycle owners
I14: callbacks require explicit registration and authority
I15: host services are represented as service boundaries, not hidden calls
I16: FFI commit claims do not exceed host guarantees
I17: unsafe FFI remains capability-gated and policy-constrained
I18: FFI traces preserve operator classification where tracing is enabled
I19: PMS-IR preserves foreign declarations, calls, handles, policies, and error maps
I20: no FFI path bypasses Ω, Χ projection, Ψ, Φ, or Σ obligations
I21: host interoperability does not imply PMS-OS equivalence
I22: AI/tooling services remain advisory until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL compiler, runtime, FFI bridge, sandbox, verifier, or host binding generator already enforces every invariant.

### 9.34 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for FFI-adjacent and host-service-adjacent slices when those slices are represented through its supported runtime/profile surface.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR FFI-adjacent behavior, such as validator acceptance/rejection, deterministic runtime stepping, host-like service boundaries, vFS calls, JSONL trace emission, golden fixture comparison, and AI proposal gating.

It does not complete:

```text
PMSL FFI implementation
PMSL ABI compiler
PMSL host binding generator
PMSL sandbox runtime
PMSL host-service bridge
PMSL AI/tooling bridge
PMSL runtime
PMS-IR optimizer
PMS-CPU
PMS-OS host-equivalence layer
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL FFI implementation and does not validate PMS Base.

### 9.35 AI FFI Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

The AI Bridge may propose:

```text
PMS-IR fragments
opcode programs
FFI wrapper sketches
host-service schemas
error-map suggestions
trace-analysis summaries
candidate diagnostics
simulation scenarios
```

It may not function as:

```text
PMSL semantics
FFI authority
ABI authority
type-checker authority
compiler authority
verifier authority
policy authority
runtime execution authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI-assisted FFI suggestions are not authoritative foreign declarations, ABI mappings, verification evidence, policy decisions, runtime decisions, or execution authority until host-validated under a declared tooling/profile gate.

### 9.36 Boundary to Runtime Architecture and PMS-IR

This section defines PMSL FFI and host interoperability.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| runtime scheduling and host-call execution | Section 10 |
| standard-library host-backed APIs | Section 11 |
| concrete IO and service APIs | Section 12 |
| PMS-IR full serialization and builder representation | Section 13 |
| static FFI linting implementation | Section 14 |
| verification of foreign-call properties | Section 15 |
| trace/debug representation | Section 16 |
| simulation of host calls | Section 17 |
| AI proposal boundary in PMS-IR tooling | Section 13 |
| AI-assisted trace analysis | Section 16 |
| PMS-RUST artifact relation | `08_relation_to_pms_rust.md` |

The boundary is:

```text
FFI defines how PMSL crosses into host contexts.
Runtime architecture defines how those crossings execute.
PMS-IR defines how they are represented.
Tooling defines how they are checked, traced, simulated, and verified.
```

### 9.37 Architectural Consequence

The consequence of PMSL FFI is:

```text
PMSL host interoperability is a disciplined boundary architecture:
foreign functions, native libraries, host services, callbacks, handles,
memory transfers, host errors, blocking calls, async completions, AI/tooling
services, and simulation harnesses are admitted only when they remain
Δ-classified, Ω-authorized, Χ-projection-bounded,
Φ-recontextualized, Ψ-constrained, and Σ-integrated in PMS-IR.
```

This lets PMSL run on host systems, call native libraries, wrap services, and interact with tooling without treating host behavior as untyped semantic authority or confusing host interoperability with PMS-OS equivalence.

### 9.38 FFI Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL FFI and host-interoperability model specifies operator-typed
foreign interaction: ForeignFrames, host services, foreign declarations,
foreign calls, ABI profiles, memory transfer, foreign handles, host error
mapping, blocking and async calls, callbacks, FFI policies, commit
profiles, traces, AI/tooling service boundaries, PMS-RUST evidence
boundaries, and PMS-IR representation.

This is a language FFI / host-interoperability architecture claim.

It does not claim a completed PMSL FFI implementation, completed ABI
compiler, completed host binding generator, completed sandbox runtime,
completed host-service bridge, completed AI/tooling bridge, completed
runtime adapter, completed verifier, completed PMS-OS host-equivalence
layer, or completed PMSL implementation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR FFI and does not
validate PMS Base.
```

---

## 10. Runtime Architecture

The PMSL runtime is the execution substrate that preserves PMSL/PMS-IR semantics during program execution.

It is not a generic virtual machine, scheduler, interpreter, standard-library host, or syscall wrapper. It is the layer that keeps operator-typed source structure executable: frames remain frames, roles remain authority contexts, boundary projections remain visible, policies remain active, exceptions remain Φ paths, absences remain Λ paths, commits remain Σ transitions, validation remains profile-bound, and traces remain operator-readable.

The central runtime claim is:

```text
The PMSL runtime is valid when PMSL source and PMS-IR execute through
□-framed runtime contexts, Δ-classified operations, Ω-authorized actions,
Χ-projection-bounded visibility, Θ-ordered scheduling, Λ-aware waits,
Φ-typed recontextualization, Σ-committed effects, and Ψ-enforced policies.
```

This section defines the runtime architecture at specification level.

It does not claim that a complete PMSL runtime already exists.

PMS-RUST v0.1 demonstrates bounded executable slices — deterministic kernel execution, opcode construction, program buffering, model validation, stateful runtime validation, REPL/script tooling, JSONL traces, vFS service boundaries, golden fixtures, and controlled AI proposal gating — but it is not identical with the full PMSL runtime specified here.

Claim type:

```text
LANGUAGE RUNTIME ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies the PMSL runtime as an implementation-layer
language/runtime architecture.

It does not claim a completed PMSL runtime, completed VM, completed
scheduler, completed interpreter, completed standard-library host,
completed syscall wrapper, completed PMS-OS backend, completed
distributed runtime, completed verifier, or completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared runtime profile, PMS-IR schema, backend profile, scheduler profile, policy profile, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, runtime correctness, scheduler fairness, backend equivalence, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR runtime level, Χ is projected as module boundary, task boundary, host boundary, sandbox boundary, runtime isolation, visibility control, reachability discipline, memory-domain separation, and cross-frame transfer discipline.

PMSL/PMS-IR does not redefine Χ.

### 10.1 Runtime Role in the Stack

The PMSL runtime sits between PMSL/PMS-IR and concrete execution substrates.

```text
PMSL source
  → typed AST
  → PMS-IR
  → PMSL runtime
  → execution substrate
```

Possible execution substrates include:

```text
PMS-UM interpreter
PMS-CPU backend
PMS-OS syscall surface
host OS runtime profile
PMS-RUST-style deterministic kernel slice
simulator / emulator
future native PMSL runtime
```

The runtime has one primary obligation:

```text
preserve operator semantics during execution
```

This means that lowering PMSL to executable behavior must not erase:

```text
frame context
role/capability state
boundary state
policy state
effect class
absence path
trap path
commit behavior
source/trace relation
```

The PMSL runtime is therefore an architecture layer. Concrete runtime artifacts may implement bounded profiles. PMS-RUST v0.1 is one bounded evidence spine, not the full PMSL runtime.

### 10.2 Runtime Components

A PMSL runtime consists of the following components.

```text
RuntimeCore
FrameManager
TaskScheduler
ChannelRuntime
SyncRuntime
PolicyEngine
CapabilityManager
BoundaryManager
MemoryManager
ExceptionRuntime
CommitManager
ModuleLoader
FFIRuntime
StdlibDispatcher
TraceEmitter
ValidationLayer
BackendAdapter
```

Each component corresponds to operator responsibilities.

| Runtime component | Dominant operators |
| ----------------- | ------------------ |
| `RuntimeCore` | Δ–Ψ integration |
| `FrameManager` | □, Φ, Σ |
| `TaskScheduler` | Θ, Λ, Φ, Σ |
| `ChannelRuntime` | Δ, Ω, Χ projection, Θ, Λ, ∇, Σ |
| `SyncRuntime` | Ω, Θ, Λ, ∇, Σ |
| `PolicyEngine` | Ψ |
| `CapabilityManager` | Ω |
| `BoundaryManager` | Χ projection |
| `MemoryManager` | □, Ω, Χ projection, ∇, Σ, Λ, Φ, Ψ |
| `ExceptionRuntime` | Φ, Λ, Ψ, Σ |
| `CommitManager` | Σ, Φ, Ψ |
| `ModuleLoader` | □, Δ, Ω, Χ projection, Ψ, Σ, Φ |
| `FFIRuntime` | Φ, □, Χ projection, Ω, Ψ, Σ |
| `StdlibDispatcher` | Α, Δ, Ω, Ψ, Σ |
| `TraceEmitter` | Θ, Δ, Σ |
| `ValidationLayer` | Δ, Ψ |
| `BackendAdapter` | Φ, Σ, Χ projection |

The exact implementation may vary. The operator obligations may not.

A runtime profile may omit or restrict components, but it must reject unsupported constructs rather than silently erase their obligations.

### 10.3 Runtime State

Runtime state is structured as a set of frames, tasks, policies, capabilities, queues, modules, boundaries, and commit records.

```text
RuntimeState = (
    frames,
    tasks,
    modules,
    channels,
    sync_objects,
    policies,
    capabilities,
    boundaries,
    heap_domains,
    foreign_frames,
    commit_log,
    trace_log,
    scheduler_state,
    meta
)
```

Runtime state is valid when:

```text
all live tasks have frames
∧ all frame entries are coherent
∧ all active roles are defined
∧ all capabilities are attached to roles or frames
∧ all boundaries are explicit
∧ all policies are active in known scopes
∧ all pending commits are tracked
∧ all pending waits have Λ/Θ state
∧ all trap continuations are typed
```

The runtime is therefore a structured PMS transition system, not an untyped execution loop.

The `boundaries` component records PMSL/PMS-IR boundary projections. It is not PMS Base Χ itself.

### 10.4 Runtime Configurations

A PMSL runtime configuration can be represented as:

```text
RuntimeConfig = (
    program,
    ir,
    state,
    active_task,
    active_frame,
    active_role,
    active_policy,
    active_boundary,
    continuation,
    event_queue,
    trace
)
```

A runtime step has the form:

```text
RuntimeConfig → RuntimeConfig'
```

and must preserve the relevant invariants.

Generic step:

```text
Δ classify next operation
□ locate active frame
Ω verify authority if required
Χ verify projected boundary if required
Ψ evaluate policy if required
∇ perform operation
Θ update ordering/scheduler state
Σ commit result if required
Φ/Λ handle trap or absence if required
```

Not every step uses every operator explicitly. Every step remains valid only under the operator obligations attached to its construct.

A runtime configuration is an execution model under a declared profile. It is not a proof of all possible execution behavior.

### 10.5 Runtime Execution Cycle

The runtime execution cycle is:

```text
fetch IR node
classify operator
load active context
check role/capability
check boundary
check policy
execute operation
commit or stage result
emit trace event if required
schedule continuation
handle absence/trap/failure
```

Operator form:

```text
Δ → □ → Ω? → Χ? → Ψ? → ∇/Θ/Λ/Φ → Σ? → Θ
```

Example for a PMSL call:

```text
Δ resolve callee
Δ classify arguments
Ω check call capability
Χ check module/host boundary if relevant
Ψ check effect policy
□ enter call frame
∇ execute body or backend call
Σ integrate result
Φ handle trap if produced
□ restore caller frame
```

Example for a channel receive:

```text
Δ classify channel
Ω check receive capability
Χ check endpoint visibility
Ψ check channel policy
Θ inspect readiness / wait
Λ if no message
∇ dequeue if present
Σ commit receive state
```

The execution cycle is an architecture pattern. A concrete implementation may fuse steps, cache checks, or use specialized fast paths, but it may not bypass Ω, Χ projection, Ψ, Λ, Φ, or Σ obligations.

### 10.6 Runtime Profiles

PMSL may run under different runtime profiles.

```text
InterpreterRuntime
DeterministicRuntime
HostRuntime
PMSOSRuntime
SimulatorRuntime
EmbeddedRuntime
TestRuntime
DistributedRuntime
```

Each profile must specify:

```text
task model
memory model
module loading model
policy model
FFI availability
stdlib availability
trace behavior
determinism guarantees
resource accounting
error handling
backend substrate
```

Examples:

| Profile | Meaning |
| ------- | ------- |
| `InterpreterRuntime` | executes PMS-IR directly |
| `DeterministicRuntime` | executes under reproducible event/order profile |
| `HostRuntime` | maps runtime services to host OS facilities |
| `PMSOSRuntime` | maps runtime calls to PMS-OS syscalls |
| `SimulatorRuntime` | executes in simulated time/state |
| `TestRuntime` | exposes fixtures, deterministic scheduling, diagnostics |
| `DistributedRuntime` | adds node/session/cluster coordination |

Profiles may differ in implementation. They must preserve PMSL/PMS-IR semantics.

Runtime profiles are bounded execution claims. A supported profile does not imply support for every PMSL construct, every backend, every OS, or distributed correctness outside the declared profile.

### 10.7 PMSL Process Model vs. Kernel Processes

A PMSL task is not automatically an OS process.

Possible mappings:

```text
PMSL task → green task
PMSL task → host thread
PMSL task → PMS-OS thread
PMSL task → PMS-OS process
PMSL task → simulator event
PMSL task → deterministic kernel event
```

A PMSL module is also not automatically an OS process.

Possible mappings:

```text
module → lexical/runtime frame
module → isolated runtime unit
module → process boundary
module → sandbox
module → host dynamic library
module → distributed service
```

The runtime must preserve the language-level meaning independently of backend choice.

```text
PMSL task semantics
  ≠ backend thread identity

PMSL module boundary
  ≠ necessarily OS process boundary

PMSL commit
  ≠ necessarily durable OS write
```

Concrete backend profiles must state how each semantic unit is realized.

Backend portability is not semantic equivalence. Porting a runtime profile to a host substrate evidences a bounded implementation path; it does not make host behavior equal to PMS-OS behavior.

### 10.8 Frame Management

The runtime manages frame stacks and frame graphs.

Frame classes:

```text
LexicalFrame
FunctionFrame
ModuleFrame
TaskFrame
PolicyFrame
CommitFrame
HandlerFrame
ChannelFrame
ForeignFrame
RuntimeFrame
SandboxFrame
```

Frame entry:

```text
Δ identify frame
Ω verify entry authority if protected
Χ check projected boundary if relevant
Ψ activate frame policy
□ enter frame
Σ commit frame activation if externally visible
```

Frame exit:

```text
Σ close or stage local effects
Φ restore continuation if recontextualizing
Ψ close policy scope
□ restore parent frame
```

Frame invariants:

```text
I1: active execution always has an active frame
I2: protected frame entry is Ω-checked
I3: boundary frame entry is Χ-projection-checked
I4: policy frame entry activates Ψ constraints
I5: unclosed effects cannot disappear on frame exit
I6: handler frames preserve trap cause and continuation
```

A frame fast path may be optimized, but it must not erase frame entry, exit, policy, boundary, trap, absence, or commit obligations.

### 10.9 Task Scheduler

The runtime scheduler orders PMSL tasks.

Scheduler state:

```text
SchedulerState = (
    ready_queue,
    blocked_tasks,
    timers,
    event_sources,
    priorities,
    policies,
    current_task,
    meta
)
```

Scheduling step:

```text
Δ classify runnable tasks
Ψ apply scheduling policy
Θ select next task
Φ switch task context if required
Σ commit scheduler state
```

Blocking step:

```text
Δ classify wait reason
Θ enqueue wait
Λ represent non-event until wake condition occurs
Σ commit blocked state
```

Wake step:

```text
Δ classify wake event
Ψ check wake policy
Θ move task to ready queue
Σ commit wake state
```

Scheduler profiles may include:

```text
cooperative
preemptive
deterministic
priority-based
deadline-based
event-loop
simulation-time
host-adapted
```

The runtime may use host scheduling underneath. It must still preserve PMSL-level Θ/Λ/Σ semantics.

Scheduler fairness is a profile-bound property. It is not implied by syntax alone.

### 10.10 Runtime Channels and Events

The runtime implements PMSL channels, events, timers, and wait objects.

Runtime entities:

```text
ChannelFrame
EventFrame
TimerFrame
WaitFrame
MessageFrame
```

Channel send:

```text
Δ classify channel/message
Ω verify send authority
Χ verify endpoint visibility
Ψ check channel policy
∇ enqueue or deliver
Θ wake receiver if needed
Σ commit delivery state
```

Channel receive:

```text
Δ classify channel
Ω verify receive authority
Χ verify endpoint visibility
Θ wait or inspect queue
Λ if no message
∇ dequeue if present
Σ commit receive state
```

Timer registration:

```text
Δ classify timer
Ω verify timer authority
Ψ check timer policy
Θ register deadline
Σ commit timer state
```

Event dispatch:

```text
Δ classify event
Ω verify publish/subscribe authority
Χ check topic visibility
Ψ check event policy
Θ dispatch
∇ execute handler
Σ commit handler result
```

Runtime channels and events implement the language/runtime side of the Section 6 concurrency model. They do not by themselves claim completed PMS-OS IPC or distributed messaging.

### 10.11 Runtime Memory Model

The runtime memory model sits above PMS-OS memory and below PMSL values.

Runtime memory domains may include:

```text
task stack
runtime heap
module heap
transaction arena
channel buffer pool
foreign handle table
trace buffer
intern table
GC heap
reference-counted heap
borrowed host region
shared runtime frame
```

Allocation flow:

```text
Δ classify allocation request
□ select allocation domain
Ω verify allocation authority
Ψ check resource/quota policy
Χ verify projected boundary constraints
∇ allocate or reserve memory
Σ commit allocation
Λ/Φ on no-resource or fault
```

Runtime memory must preserve:

```text
frame ownership
lifetime boundaries
module boundaries
task boundaries
foreign memory boundaries
commit state
resource accounting
trace/audit requirements
```

The runtime may use reference counting, garbage collection, region allocation, arenas, host allocation, or OS allocation. The profile must specify which memory obligations it preserves.

A memory strategy is an implementation profile. It is not part of PMS Base and does not redefine Δ–Ψ.

### 10.12 Runtime Resource Accounting

The runtime accounts for language-level resources.

Resources include:

```text
tasks
frames
channels
messages
timers
handlers
foreign handles
heap bytes
stack bytes
trace bytes
module instances
pending commits
policy objects
```

Accounting flow:

```text
Δ classify resource event
Ω verify owner/account
Ψ check quota
∇ update counters
Σ commit accounting
Λ no-resource if optional/nonblocking
Φ runtime trap if critical
```

Runtime resource accounts may be attached to:

```text
task
module
role
policy domain
process
runtime instance
test scenario
simulation node
```

Resource accounting is required for bounded runtime profiles and verification-oriented profiles.

Resource accounting at this layer is a runtime/API obligation. PMS-OS resource accounting is specified separately in `04_pms_os.md`.

### 10.13 Runtime Policy Engine

The runtime policy engine enforces Ψ at language/runtime level.

Policy sources:

```text
module policy
function contract
role/capability policy
channel policy
task policy
FFI policy
commit policy
stdlib policy
runtime profile policy
host policy
test/simulation policy
```

Policy evaluation:

```text
Δ classify transition
Ω inspect role/capability
Χ inspect projected boundary
Ψ evaluate policy
return allow / deny / trap / audit / defer / quarantine / terminate
```

Policy enforcement points include:

```text
module load
function call
frame entry
task spawn
channel send/receive
FFI call
foreign callback
memory allocation
commit block
trap handler entry
stdlib call
trace emission
runtime shutdown
```

Runtime policy may not silently weaken PMSL static policy. It may refine or strengthen it.

Runtime policy is program/runtime constraint handling. It is not moral judgment, forensic attribution, governance tribunal behavior, or PMS Base validation.

### 10.14 Capability Management

The runtime maintains active role and capability state.

Capability state:

```text
CapabilityState = (
    roles,
    capabilities,
    delegations,
    active_scopes,
    transfer_rules,
    revocations,
    meta
)
```

Capability check:

```text
Δ classify protected action
Ω verify active capability
Ψ apply capability policy
continue or produce denial/trap
```

Capability scopes:

```text
module scope
function scope
task scope
policy scope
FFI scope
channel endpoint scope
temporary delegation
```

Capability transfer must be explicit:

```text
Δ classify transfer
Ω verify transfer authority
Χ check projected recipient boundary
Ψ check transfer policy
Σ commit transfer
```

Capability management supports least-authority runtime execution. Ω does not override Ψ policy or Χ-projected boundary discipline.

### 10.15 Boundary Management

The runtime manages Χ projections as module boundaries, task boundaries, host boundaries, sandbox boundaries, memory domains, and visibility domains.

Boundary state:

```text
BoundaryState = (
    domains,
    reachability_edges,
    transfer_rules,
    shared_frames,
    foreign_frames,
    policies,
    meta
)
```

Boundary check:

```text
Δ classify source and target
Χ check reachability / visibility
Ψ check boundary policy
allow, deny, trap, or require bridge
```

Boundary crossings include:

```text
module import
module call
task communication
channel send/receive
shared frame access
FFI call
foreign callback
host service request
distributed service call
```

Boundary rule:

```text
no runtime object crosses a boundary without declared visibility,
transfer, copy, serialization, shared frame, capability, or service bridge.
```

This is a PMSL/PMS-IR projection of PMS Base Χ = Distance. It is not a redefinition of Χ and does not imply completed hardware, OS, or sandbox implementation.

### 10.16 Commit Management

The runtime tracks Σ.

Commit subjects include:

```text
local binding
function return
channel delivery
task creation
task completion
module linkage
module initialization
foreign result
filesystem write
trace record
policy installation
transaction block
resource accounting update
```

Commit manager state:

```text
CommitState = (
    staged_effects,
    committed_effects,
    rollback_handlers,
    compensation_handlers,
    visibility_state,
    durability_state,
    policy,
    meta
)
```

Commit flow:

```text
Δ classify staged effects
Ψ check commit policy
Σ integrate result
Φ rollback/recover if commit fails
Σ commit recovery state if possible
```

The runtime must distinguish:

```text
executed
staged
visible
committed
durable
rolled_back
compensated
failed
```

A backend may provide weaker or stronger commit guarantees. The runtime profile must expose them.

A runtime may not claim stronger commit semantics than the active backend/profile supports.

### 10.17 Exception Runtime

The exception runtime handles Φ and Λ.

Trap handling:

```text
Δ classify trap
□ create HandlerFrame
Ω verify handler authority
Χ preserve projected boundary state
Ψ check recovery policy
Φ enter handler
∇ execute handler body
Σ integrate recovery or propagation
```

Absence handling:

```text
Δ classify expected event/value
Θ observe wait/evaluation interval
Λ produce absence
Φ enter absence handler if source form uses handler context
Σ integrate fallback/result
```

Runtime handler classes:

```text
trap handler
absence handler
policy-denial handler
boundary-fault handler
commit-failure handler
task-failure handler
foreign-error mapper
panic handler
shutdown handler
```

The runtime may provide defaults. Defaults must be explicit in the runtime profile.

Default handlers are runtime architecture obligations. This section does not claim a completed default-handler implementation.

### 10.18 Module Loader

The runtime module loader realizes Section 8 at execution time.

Module load flow:

```text
Δ identify module
Δ resolve imports/exports
Ω verify loader authority
Χ establish projected module boundary
Ψ check module policy
Θ order dependency initialization
∇ run init hook if present
Σ commit active module state
Φ handle load/init failure
```

Module unload flow:

```text
Ψ check unload policy
Θ order finalization
∇ run finalizers
Σ close resources
Σ commit unloaded state
Χ retire or quarantine projected boundary
Φ handle finalization failure
```

The module loader must preserve source-level module contracts:

```text
exports
imports
roles
capabilities
policies
boundary profiles
versions
lifecycle hooks
resource accounts
```

Module loading is a runtime obligation. This section does not claim a completed module loader.

### 10.19 FFI Runtime

The FFI runtime implements Section 9.

Foreign call flow:

```text
Δ resolve foreign declaration
Ω verify foreign-call capability
Χ enter projected foreign boundary
Ψ check FFI policy
Φ reframe to host ABI
∇ execute host call or service request
Φ map host error
Λ map expected absence/no-response
Σ integrate result/effect
```

FFI runtime responsibilities:

```text
argument mapping
result mapping
memory transfer
handle lifecycle
timeout installation
callback entry
host error mapping
trace emission
commit-profile tracking
resource cleanup
```

Unsafe FFI remains runtime-governed. It does not suspend operator obligations.

Host interoperability supports execution profiles. It does not make host OS behavior equivalent to PMS-OS.

### 10.20 Standard-Library Dispatch

The runtime dispatches standard-library calls according to known operator profiles.

Example profiles:

```text
FS.write      → Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ
Channel.recv  → Δ, Ω, Χ, Θ, Λ, ∇, Σ, Φ, Ψ
Time.sleep    → Δ, Θ, Λ, Σ
Log.info      → Δ, ∇, Σ, Ψ
Policy.check  → Δ, Ω, Ψ, Σ
```

Dispatch flow:

```text
Δ resolve standard-library symbol
Δ classify operation profile
Ω check required authority
Χ check boundary if relevant
Ψ check standard-library policy
∇ call runtime/OS/host backend
Σ integrate result
Φ/Λ handle declared outcomes
```

Standard-library domains are specified in Section 11.

The PMSL standard-library domains are architecture-level API profiles. They define operator profiles, type/effect obligations, and runtime contracts. They do not claim that every listed API already exists as a completed library implementation.

### 10.21 Backend Adapters

A backend adapter maps PMSL runtime operations to a concrete substrate.

Adapter examples:

```text
UMAdapter
CPUAdapter
OSAdapter
HostAdapter
RustSpineAdapter
SimulatorAdapter
DistributedAdapter
```

Adapter interface:

```text
BackendAdapter = (
    capabilities,
    supported_effects,
    memory_profile,
    scheduling_profile,
    FFI_profile,
    commit_profile,
    trace_profile,
    policy_profile,
    meta
)
```

Adapter obligation:

```text
preserve PMSL/PMS-IR operator meaning
or reject unsupported constructs
```

A backend may reject:

```text
durable commits
native FFI
preemptive scheduling
process isolation
distributed channels
host callbacks
unsafe memory transfer
```

Rejection must be typed:

```text
Λ unsupported / absent feature
Φ backend trap
Ψ policy denial
```

Backend support is a profile-local implementation claim. It is not portability equivalence and not PMS Base validation.

### 10.22 Deterministic Runtime Profile

A deterministic runtime profile is important for testing, simulation, reproducible traces, and evidence-spine artifacts.

Deterministic profile constraints:

```text
fixed scheduling order
deterministic event ordering
deterministic trace emission
controlled timers
controlled random sources
bounded host interaction
explicit input fixtures
stable serialization
```

Operator reading:

```text
Θ is controlled
Λ outcomes are reproducible under the same inputs
Σ trace commits are stable
Ψ profile policy forbids nondeterministic effects unless declared
```

This profile is especially useful for:

```text
golden tests
model validation
script execution
simulation
trace comparison
regression testing
PMS-RUST-style evidence slices
```

A deterministic runtime profile is a runtime artifact claim, not PMS Base validation.

Determinism is bounded by the declared profile, input fixtures, backend model, and host-interaction constraints.

### 10.23 Trace and Audit Emission

Runtime traces connect execution to observability, debugging, model checking, conformance checks, and verification workflows.

Runtime event record:

```text
RuntimeEvent = (
    event_id,
    task,
    module,
    frame,
    role,
    boundary,
    operation,
    operator_class,
    policy_decision,
    effect_class,
    commit_state,
    result_class,
    source_span,
    order,
    meta
)
```

Trace emission flow:

```text
Δ classify event
Ψ check trace policy
Θ order event
Σ commit trace record
```

Runtime trace classes:

```text
frame_enter
frame_exit
task_spawn
task_await
channel_send
channel_recv
policy_check
capability_check
boundary_check
commit
trap
absence
ffi_call
module_load
module_unload
resource_event
```

Trace output may be JSONL, binary event log, in-memory trace, simulator trace, or audit stream depending on runtime profile.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL runtime execution:

```text
trace_pmsl(runtime, runtime_artifact, input_profile) ∈ L_PMS
```

For the set of possible executions under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, runtime_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, runtime_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, runtime_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A trace stream records concrete runtime events.

JSONL trace output is an artifact evidence format. It records observed execution under a declared profile. It is not proof of all possible behavior and not PMS Base validation.

### 10.24 Runtime Validation

The runtime may validate PMS-IR before execution.

Validation layers:

```text
syntax validation
operator-tag validation
dependency validation
type/effect validation
stateful validation
policy validation
backend-support validation
```

Pre-execution validation:

```text
Δ inspect PMS-IR nodes
Ψ validate operator dependencies and active constraints
reject invalid sequence or continue
```

Stateful validation examples:

```text
Σ requires committable state
Φ requires handler or propagation path
Ω requires active role/capability
Χ requires active boundary projection
Λ requires expected event/value
□ requires valid frame
```

Validation in this section means acceptance or rejection under a declared schema, model, runtime profile, backend profile, tool profile, or conformance rule.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, or theoretical adequacy.

Runtime validation strengthens implementation-artifact discipline. It does not convert tests into proof.

### 10.25 Runtime Failure Paths

Runtime failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| invalid IR node | Δ / Ψ |
| unsupported construct | Λ / Φ / Ψ |
| missing capability | Ω / Ψ |
| boundary violation | Χ projection / Ψ / Φ |
| policy denial | Ψ / Φ |
| task failure | Φ / Σ |
| timeout | Λ / Θ |
| no resource | Λ / Ψ / Φ |
| commit failure | Σ / Φ |
| module load failure | Δ / Φ / Σ |
| FFI failure | Φ / Λ / Ψ |
| trace commit failure | Σ / Ψ / Φ |
| runtime invariant failure | Ψ / Φ |
| critical halt | Ψ |

A runtime that reports all failures as generic errors loses PMSL structure.

Runtime failures must remain visible in PMS-IR outcomes, diagnostics, traces, and profile-local conformance results.

### 10.26 Runtime Security Boundary

The PMSL runtime enforces language/runtime policies, roles, capabilities, and boundaries.

It does not replace the full runtime-security architecture.

Boundary:

```text
05_pmsl_pms_ir.md
    defines runtime mechanisms required by PMSL/PMS-IR execution

06_runtime_security.md
    defines system-wide identity, principals, trust anchors, audit,
    enforcement, security policies, and governance discipline
```

The PMSL runtime therefore provides enforcement points. Runtime security defines broader security architecture and governance semantics.

Runtime policy enforcement remains program/runtime constraint handling. It is not moral judgment, forensic attribution, or governance tribunal behavior.

### 10.27 Runtime Relation to PMS-RUST

PMS-RUST v0.1 is relevant as bounded executable evidence for runtime/tooling slices.

It demonstrates:

```text
deterministic kernel execution
opcode construction
program buffering
model validation
stateful runtime validation
REPL/script tooling
JSONL trace/audit output
vFS service boundaries
golden fixtures
controlled AI proposal gating
```

It does not claim:

```text
complete PMSL runtime
complete PMSL compiler
complete PMSL standard library
complete PMS-IR optimizer
complete PMS-OS
complete PMS-CPU/ISA
distributed PMS runtime
PMS Base validation
```

The correct relation is:

```text
PMSL runtime architecture
  → specifies runtime obligations

PMS-RUST v0.1
  → demonstrates bounded executable slices of those obligations
```

This strengthens the implementation-artifact claim, not PMS Base.

PMS-RUST v0.1 is therefore a bounded executable evidence spine. It is not the full PMSL runtime, not the full PMS-IR optimizer, not PMS-OS, and not PMS Base validation.

### 10.28 AI Runtime Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

The runtime may interact with AI/tooling services only through host/tooling service profiles.

The AI Bridge may propose:

```text
PMS-IR fragments
opcode programs
runtime scenarios
missing-obligation hypotheses
trace-analysis summaries
candidate diagnostics
simulation inputs
```

It may not function as:

```text
PMSL semantics
runtime authority
scheduler authority
type-checker authority
compiler authority
verifier authority
policy authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI-assisted runtime suggestions are not execution results, scheduler decisions, verification evidence, policy decisions, or runtime authority until host-validated under a declared tooling/profile gate.

AI output is not PMSL source authority.

AI output is not PMS-IR truth.

AI output is not verification evidence.

AI output is not trusted executable code.

AI output is not PMS Base validation.

### 10.29 Runtime Invariants

PMSL maintains the following runtime invariants.

```text
I1: every executing construct has an active runtime frame
I2: every runtime operation is Δ-classified before execution
I3: every protected operation is Ω-authorized
I4: every boundary crossing is Χ-projection-checked
I5: every policy-governed operation is Ψ-evaluated
I6: every task has a TaskFrame and lifecycle state
I7: every wait, timeout, or not-ready state is Λ/Θ-visible
I8: every trap enters a typed HandlerFrame or declared propagation path
I9: every commit-capable operation has Σ behavior
I10: every module load/link/init transition is Σ/Θ/Ψ-governed
I11: every FFI call enters a ForeignFrame or HostService profile
I12: every runtime resource event is attributable to an owner/account where the profile supports accounting
I13: every trace event preserves operator class where tracing is enabled
I14: backend adapters preserve operator meaning or reject unsupported constructs
I15: runtime validation may reject invalid PMS-IR before execution
I16: runtime security hooks may strengthen but not silently weaken language constraints
I17: deterministic profiles produce reproducible ordering under the same inputs
I18: no runtime fast path bypasses Ω, Χ projection, Ψ, Λ, Φ, or Σ obligations
I19: traces record observed runtime executions under declared profiles; they do not validate PMS Base
I20: AI-proposed runtime artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL runtime, scheduler, interpreter, VM, backend adapter, verifier, or PMS-OS backend already enforces every invariant.

### 10.30 Boundary to Standard Library and PMS-IR

This section defines the PMSL runtime architecture.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| standard-library domains | Section 11 |
| concrete concurrency and IO APIs | Section 12 |
| PMS-IR full representation | Section 13 |
| static analysis and linting | Section 14 |
| model checking and verification | Section 15 |
| debugging and observability tools | Section 16 |
| simulation and emulation | Section 17 |
| example PMSL fragments | Section 18 |
| runtime security and governance | `06_runtime_security.md` |
| PMS-RUST artifact mapping | `08_relation_to_pms_rust.md` |
| non-goals and implementation boundary | `09_non_goals_and_claim_boundary.md` |

The runtime executes PMSL/PMS-IR. The standard library exposes canonical API profiles. PMS-IR records the executable structure. Tooling analyzes, verifies, observes, and simulates that structure under declared profiles.

### 10.31 Architectural Consequence

The consequence of the PMSL runtime architecture is:

```text
The PMSL runtime is the execution layer that keeps operator-typed
programs semantically intact. It manages frames, tasks, modules,
channels, memory, policies, capabilities, boundary projections,
exceptions, commits, foreign calls, standard-library dispatch,
validation, traces, and backend adaptation as Δ–Ψ-governed runtime
structure.
```

This gives PMSL a runtime model that is executable without becoming opaque: every major runtime operation remains frame-aware, authority-aware, boundary-aware, policy-aware, commit-aware, failure-aware, traceable, and preservable in PMS-IR.

### 10.32 Runtime Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL runtime architecture specifies operator-typed execution:
runtime state, frames, tasks, scheduling, channels, events, memory,
resource accounting, policy enforcement, capability management, boundary
management, commit management, exception handling, module loading, FFI,
standard-library dispatch, backend adapters, deterministic profiles,
traces, validation, PMS-RUST evidence boundaries, and AI proposal
boundaries.

This is a language runtime architecture claim.

It does not claim a completed PMSL runtime, completed VM, completed
scheduler, completed interpreter, completed standard-library host,
completed syscall wrapper, completed PMS-OS backend, completed
distributed runtime, completed verifier, completed PMSL implementation,
or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, program buffering, model validation, stateful
runtime validation, deterministic execution, JSONL traces, REPL/script
tooling, vFS service boundaries, golden fixtures, and AI proposal gating.
It does not complete PMSL/PMS-IR runtime architecture and does not
validate PMS Base.
```

---

## 11. Standard Library Domains

The PMSL standard library is the canonical operator-typed API layer of PMSL.

It does not hide PMSL semantics behind opaque convenience functions. It packages recurring program structures as typed, policy-aware, effect-declared, PMS-IR-visible APIs.

The central standard-library claim is:

```text
The PMSL standard library is valid when its domains expose reusable
Α-patterns and APIs whose Δ distinctions, ∇ effects, □ frames,
Λ absences, Ω authorities, Θ ordering, Φ traps, Χ-projected boundaries,
Σ commits, and Ψ policies remain explicit in type signatures,
effect profiles, runtime behavior, and PMS-IR lowering.
```

This section defines standard-library domains at specification level. It does not claim that a complete PMSL standard library already exists. It defines the architectural obligations for standard-library modules and APIs.

Claim type:

```text
LANGUAGE STANDARD-LIBRARY / API-DOMAIN ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL standard-library domains as architecture-level
API profiles.

It does not claim a completed PMSL standard library, completed library
implementation, completed runtime backend, completed host adapter,
completed PMS-OS library surface, completed distributed library surface,
completed verifier, or completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

The PMSL standard-library domains are architecture-level API profiles. They define operator profiles, type/effect obligations, runtime contracts, PMS-IR lowering obligations, and profile-local conformance requirements. They do not claim that every listed API already exists as a completed library implementation.

Validation in this section means acceptance or rejection under a declared API profile, type/effect rule, runtime profile, backend profile, standard-library profile, PMS-IR schema, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, library correctness, backend correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR standard-library level, Χ is projected as namespace boundary, module boundary, host boundary, filesystem visibility, network reachability, endpoint visibility, runtime boundary, service boundary, sandbox boundary, and cross-frame transfer discipline.

PMSL/PMS-IR does not redefine Χ.

### 11.1 Role of the Standard Library

The PMSL standard library provides canonical APIs for common domains.

Its role is to make frequent structures:

```text
files
networking
time
logging
policy
tasks
channels
events
runtime services
frames
roles
capabilities
tracing
verification
FFI
PMS-IR tooling
diagnostics
```

available through well-typed library modules instead of ad hoc program-specific wrappers.

A standard-library call must provide:

```text
type signature
effect signature
role/capability requirements
policy requirements
boundary behavior
absence behavior
trap behavior
commit behavior
PMS-IR lowering profile
```

Example:

```pmsl
FS.write(path, data)
```

must not mean:

```text
some hidden host write happened
```

It must lower through a known operator profile:

```text
Δ classify path and operation
Ω check write capability
Χ check projected namespace/boundary visibility
Ψ check filesystem policy
∇ perform or stage write effect
Σ commit/stage result
Φ trap on IO/error path
Λ represent absence/no-space/no-target where declared
```

The standard library is therefore a disciplined PMSL/PMS-IR API layer, not a semantic shortcut around the language.

### 11.2 Standard Library as Α-Layer

The standard library is an Α layer.

It packages recurring operator words into reusable patterns.

Examples:

```text
open → read → close
send → await response
with lock → mutate → unlock
start task group → spawn children → await all
policy with P → check → perform action
log event → commit trace record
foreign call → map result → close handle
```

Each standard-library function is therefore:

```text
StdFunction = (
    name,
    domain,
    type_signature,
    effect_profile,
    capability_requirements,
    policy_requirements,
    boundary_profile,
    absence_profile,
    trap_profile,
    commit_profile,
    lowering_pattern,
    meta
)
```

A standard-library API is valid when its lowering pattern is operator-valid and visible to PMS-IR.

A standard-library abstraction may compress recurring syntax. It may not hide invalid operator order, missing authority, missing boundary projection, missing policy, missing absence path, missing trap path, or missing commit behavior.

### 11.3 Domain Profile Form

Each standard-library domain should declare a domain profile.

```text
StdDomain = (
    name,
    module_path,
    exported_types,
    exported_functions,
    required_roles,
    capabilities,
    policies,
    effects,
    boundaries,
    runtime_dependencies,
    host_dependencies,
    commit_profiles,
    trace_profiles,
    meta
)
```

Domain validity:

```text
domain module has a ModuleFrame
∧ exported functions have complete type/effect signatures
∧ capability requirements are explicit
∧ policies are explicit
∧ backend/runtime dependencies are explicit
∧ absence/trap/commit behavior is declared
∧ PMS-IR lowering profiles are known
```

The standard library is therefore a collection of operator-typed modules, not a bag of primitive functions.

A runtime profile may implement only a subset of domains. Unsupported APIs must fail through typed Λ/Φ/Ψ outcomes or profile-local rejection, not through silent semantic erasure.

### 11.4 Core Domain: `Core`

`Core` contains primitive values, results, options, basic collections, and minimal language-support functions.

Typical exports:

```text
Bool
Int
Float
String
Bytes
Unit
Option<T>
Result<T, E>
List<T>
Map<K, V>
Set<T>
Pair<A, B>
```

Operator profile:

```text
Δ type/value distinction
Σ product/result integration
Λ optional absence
Φ trap-bearing result forms
Α collection patterns
```

Examples:

```pmsl
let x: Option<Int> = none
let r: Result<Bytes, Φ_trap<IOError>> = read_file(path)
```

`Core` must keep absence and traps distinct:

```text
Option<T>       → value-level absence
Λ_absent<T>     → operator-visible non-event
Φ_trap<E>       → recontextualization path
Result<T, E>    → explicit branch over success/failure form
```

`Core` is the minimum API domain for value, result, and collection structure. It is not a proof that all higher-level domains are implemented.

### 11.5 Frame Domain: `Frame`

`Frame` provides APIs for explicit frame handling.

Typical exports:

```text
Frame<T>
FrameId
FrameToken
enter
leave
current
with_frame
frame_meta
```

Example:

```pmsl
Frame.with(F_user) {
    run_user_code()
}
```

Operator profile:

```text
Δ classify frame
Ω verify frame-entry capability if protected
Χ check projected boundary if relevant
Ψ check frame policy
□ enter frame
Σ close local frame effects
Φ trap on invalid frame
```

`Frame` APIs are low-level. Many user programs should use module, task, policy, or transaction constructs instead of manually managing frames.

A frame API may not bypass frame-entry policy, boundary projection, authority, trap, or commit obligations.

### 11.6 Role and Capability Domain: `Auth`

`Auth` provides role and capability APIs.

Typical exports:

```text
Role
Capability
CapabilitySet
has_cap
require_cap
with_role
delegate
revoke
```

Example:

```pmsl
Auth.require_cap(fs.write("/var/log/**"))
```

Operator profile:

```text
Δ classify requested capability
Ω inspect active role/capability state
Ψ check capability policy
Σ commit delegation/revocation if mutating
Φ trap or return denial if missing
```

Capability APIs must not grant authority implicitly. Authority transfer requires explicit Ω/Ψ/Σ behavior.

Ω does not override Ψ policy or Χ-projected boundary constraints.

### 11.7 Policy Domain: `Policy`

`Policy` provides APIs for Ψ constraints.

Typical exports:

```text
Policy
PolicyDecision
PolicyViolation
allow
deny
check
with_policy
install
remove
compose
audit_required
```

Example:

```pmsl
Policy.with(P_write_tmp) {
    FS.write(path, data)
}
```

Operator profile:

```text
Δ classify policy/action/context
Ω verify policy activation or installation authority
Ψ evaluate or activate policy
Σ commit policy decision or installation
Φ trap on violation if policy defines trap behavior
```

Policy APIs may return:

```pmsl
PolicyDecision
Ψ_denial<P>
Φ_trap<PolicyViolation>
```

Policy library rule:

```text
policy checks must remain visible to PMS-IR
```

Policy APIs are program/runtime constraint APIs. They are not moral verdicts, forensic attribution, or governance tribunal mechanisms.

### 11.8 Filesystem Domain: `FS`

`FS` provides filesystem APIs.

Typical exports:

```text
Path
File
Dir
Handle
OpenMode
ReadResult
WriteResult
Metadata
open
read
write
append
close
exists
stat
mkdir
remove
rename
sync
with_file
```

Example:

```pmsl
let h = FS.open(path, mode)
let data = FS.read(h, 4096)
FS.close(h)
```

Common effect profiles:

```text
FS.exists:
    effects(Δ, Ω, Χ, Ψ, Λ, Σ)

FS.open:
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)

FS.read:
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)

FS.write:
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)

FS.sync:
    effects(Δ, Ω, Ψ, ∇, Σ, Φ)
```

Filesystem operation reading:

```text
Δ classify path/handle/operation
Ω check filesystem capability
Χ check projected namespace/mount/boundary visibility
Ψ check filesystem policy
∇ perform read/write/metadata mutation
Σ commit handle state, file state, or durability state
Λ represent missing path/no-space/no-data where declared
Φ trap on IO, invalid handle, policy, or backend failure
```

`FS` must distinguish:

```text
missing path as Λ
permission denial as Ω/Ψ
boundary denial as Χ projection / Ψ / Φ
IO failure as Φ
write staging as ∇ without durable Σ
durable sync as Σ_durable
```

Filesystem APIs may be backed by host services, PMS-OS syscalls, vFS surfaces, test fixtures, or simulators. The backing profile may vary; the operator obligations remain.

### 11.9 Networking Domain: `Net`

`Net` provides networking APIs.

Typical exports:

```text
Address
Endpoint
Connection
Listener
Packet
Request
Response
connect
listen
accept
send
recv
close
resolve
request
publish
subscribe
```

Common effect profiles:

```text
Net.connect:
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, Φ, ∇, Σ)

Net.send:
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)

Net.recv:
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)

Net.request:
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Λ, Φ, Σ, Α)
```

Networking operation reading:

```text
Δ classify endpoint/message/protocol
Ω check network capability
Χ check projected network boundary
Ψ check routing/security/policy
Θ order connection, timeout, retry, delivery
Λ no-route/no-response/timeout
∇ send/receive/connect/listen
Σ commit connection or delivery state
Φ trap on protocol/backend/security failure
```

`Net` is a local/runtime API domain. Cross-node semantics, distributed protocols, cluster consistency, replication, and inter-node failure domains are refined in `07_distributed_systems.md`.

A local `Net` API profile must not claim distributed correctness unless paired with the distributed profile that specifies and evidences it.

### 11.10 Time Domain: `Time`

`Time` provides ordering, deadlines, delays, timers, and virtual-time support.

Typical exports:

```text
Duration
Instant
Deadline
Timer
sleep
now
deadline_after
timeout
interval
virtual_time
```

Effect profiles:

```text
Time.now:
    effects(Δ, Θ, Σ)

Time.sleep:
    effects(Δ, Θ, Λ, Σ)

Time.timeout:
    effects(Δ, Θ, Λ, Φ?, Σ)

Time.interval:
    effects(Δ, Θ, Λ, ∇, Σ)
```

Time operation reading:

```text
Δ classify time request
Θ order wait/deadline/timer
Λ represent elapsed/no-event/missed deadline
Σ commit timer registration or wake result
Ψ check timing policy where constrained
```

Important distinction:

```text
τ-derived data may appear as time/accounting metadata.
Θ is the ordering operator.
```

Time APIs should not treat wall-clock time as equivalent to PMS ordering.

Concrete precision, jitter, clock source semantics, and host clock behavior belong to declared runtime/OS/host profiles.

### 11.11 Logging Domain: `Log`

`Log` provides structured logging.

Typical exports:

```text
LogLevel
LogRecord
LogContext
debug
info
warn
error
audit
with_context
```

Effect profile:

```text
Log.info:
    effects(Δ, ∇, Σ, Ψ)

Log.audit:
    effects(Δ, Ω, Ψ, ∇, Σ, Φ)
```

Logging operation reading:

```text
Δ classify log level/message/context
Ψ check logging/audit policy
∇ emit or stage log record
Σ commit log record to runtime trace, buffer, or backend
Φ trap only if policy treats log failure as exceptional
Λ represent dropped/deferred log where declared
```

`Log` should integrate with `Trace`, but logging and tracing are distinct.

```text
Log = program-visible event emission
Trace = runtime/operator execution record
Audit = policy-significant committed record
```

A log record is not automatically a proof artifact. It records an event under a declared logging/audit profile.

### 11.12 Trace Domain: `Trace`

`Trace` provides program/runtime trace access where the runtime profile permits it.

Typical exports:

```text
TraceEvent
TraceSpan
TraceId
start_span
end_span
emit
current_trace
dump
```

Effect profile:

```text
Trace.emit:
    effects(Δ, Ω, Ψ, ∇, Θ, Σ, Φ)
```

Trace operation reading:

```text
Δ classify trace event
Ω verify trace emission/access authority
Ψ check trace/audit policy
Θ order trace event
∇ emit trace record
Σ commit trace event
Φ trap on trace failure if policy-critical
```

Trace records should preserve:

```text
operator_class
frame
role
policy decision
boundary
effect class
commit state
result class
source span
ordering metadata
```

Trace APIs support debugging, observability, simulation, verification workflows, and PMS-RUST-style event streams.

In this document, `Trace` may name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL standard-library run:

```text
trace_pmsl(runtime, stdlib_artifact, input_profile) ∈ L_PMS
```

For the set of possible standard-library runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, stdlib_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, stdlib_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, stdlib_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A trace records observed execution under a declared profile. It is artifact evidence for bounded implementation behavior. It is not proof of all possible behavior and not PMS Base validation.

### 11.13 Concurrency Domain: `Task`

`Task` provides task and structured-concurrency APIs.

Typical exports:

```text
Task<T>
TaskGroup<T>
Supervisor
spawn
await
cancel
yield
task_group
supervise
```

Effect profiles:

```text
Task.spawn:
    effects(Δ, Ω, □, Χ, Ψ, Θ, Σ, Φ, Λ)

Task.await:
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, Σ, Φ)

Task.cancel:
    effects(Δ, Ω, Ψ, Φ, Θ, Σ)
```

Task operation reading:

```text
Δ classify task
Ω check task authority
□ create or enter task frame
Χ establish projected task boundary
Ψ apply task policy
Θ schedule/wait/cancel
Λ not-ready/no-resource/timeout where declared
Σ commit lifecycle transition
Φ trap/recontextualize task failure or cancellation
```

`Task` APIs must preserve structured concurrency unless the function explicitly uses a detached profile under policy.

Task APIs may map to green tasks, host tasks, PMS-OS tasks, simulator events, or deterministic runtime events under declared profiles.

### 11.14 Channel and IPC Domain: `Channel`

`Channel` provides typed message-passing APIs.

Typical exports:

```text
Channel<T>
Sender<T>
Receiver<T>
send
try_send
recv
try_recv
select
close
request
reply
```

Effect profiles:

```text
Channel.send:
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)

Channel.recv:
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)

Channel.select:
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
```

Channel operation reading:

```text
Δ classify endpoint and payload
Ω check send/receive authority
Χ check projected endpoint visibility
Ψ check channel policy
Θ order delivery/wait/selection
Λ no-message/no-space/timeout
∇ enqueue/dequeue
Σ commit delivery/receive state
Φ trap on closed channel, protocol error, or policy violation
```

`Channel` is the standard-library projection of PMSL IPC.

Distributed channels, cross-node message delivery, and cluster-level semantics are defined outside this local API domain in `07_distributed_systems.md`.

### 11.15 Synchronization Domain: `Sync`

`Sync` provides synchronization primitives.

Typical exports:

```text
Mutex<T>
RwLock<T>
Semaphore
CondVar
Barrier
Atomic<T>
Futex<T>
lock
unlock
read
write
wait
signal
broadcast
compare_exchange
```

Effect profile:

```text
Sync.lock:
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
```

Synchronization operation reading:

```text
Δ classify sync object/state
Ω verify lock/wait/signal authority
Χ check projected visibility
Ψ check sync policy
Θ order waiters
Λ unavailable/timeout
∇ mutate sync state
Σ commit lock/wake/state transition
Φ trap on invalid ownership, poisoning, or policy violation
```

`Sync` APIs should be used where shared state is required. Message-passing APIs remain the preferred boundary-preserving coordination surface.

Synchronization APIs are profile-governed systems APIs. They do not suspend authority, boundary, policy, absence, trap, or commit discipline.

### 11.16 Event Domain: `Event`

`Event` provides event declaration, publication, subscription, and dispatch APIs.

Typical exports:

```text
Event<T>
Topic<T>
Subscription<T>
publish
subscribe
unsubscribe
dispatch
timer_event
```

Effect profiles:

```text
Event.publish:
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)

Event.subscribe:
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
```

Event operation reading:

```text
Δ classify event/topic/payload
Ω check publish/subscribe authority
Χ check projected topic visibility
Ψ check event policy
∇ enqueue or register event/subscription
Θ order dispatch
Σ commit publication or subscription
Λ no-event/no-subscriber where declared
Φ trap on invalid payload, policy denial, or dispatch failure
```

Events provide a typed standard-library surface for runtime events, user events, timer events, IPC notifications, policy events, and profile-specific backend events.

### 11.17 Runtime Domain: `Runtime`

`Runtime` exposes controlled access to runtime services.

Typical exports:

```text
current_task
current_frame
current_role
current_policy
current_boundary
resource_usage
profile
capabilities
shutdown
yield
```

Effect profiles vary by operation.

Examples:

```text
Runtime.current_frame:
    effects(Δ, □, Σ)

Runtime.resource_usage:
    effects(Δ, Ψ, Σ)

Runtime.shutdown:
    effects(Δ, Ω, Ψ, Φ, Σ)
```

Runtime APIs must not grant uncontrolled introspection. Access to role, policy, boundary, trace, or resource state is capability- and policy-governed.

`Runtime` APIs expose runtime architecture state under declared profiles. They do not imply a completed production runtime.

### 11.18 Module Domain: `Module`

`Module` provides runtime module introspection and loading APIs where the runtime profile permits it.

Typical exports:

```text
ModuleId
ModuleInfo
load
unload
reload
resolve
exports
imports
version
```

Effect profile:

```text
Module.load:
    effects(Δ, Ω, Χ, Ψ, Θ, ∇, Σ, Φ, Λ)

Module.reload:
    effects(Δ, Ω, Χ, Ψ, Φ, Θ, ∇, Σ)
```

Module operation reading:

```text
Δ classify module
Ω verify loader authority
Χ check projected module boundary
Ψ check module policy
Θ order lifecycle
∇ load/unload/reload
Σ commit module state
Φ trap on version/load/finalization failure
Λ module absent or unsupported profile
```

These APIs are privileged in most runtime profiles.

A module API profile does not imply a completed package manager, dynamic loader, or hot-reload runtime.

### 11.19 FFI and Host Domain: `Host`

`Host` provides host-service and FFI wrapper APIs.

Typical exports:

```text
HostService
ForeignHandle<T>
HostPath
HostError
call
service
close_handle
map_error
```

Effect profile:

```text
Host.call:
    effects(Δ, Ω, Χ, Ψ, Φ, ∇, Σ, Λ)
```

Host operation reading:

```text
Δ classify host service/symbol
Ω check host capability
Χ enter projected host boundary
Ψ check host/FFI policy
Φ reframe to host context
∇ execute host operation
Λ represent no-response/timeout where declared
Φ map host error
Σ integrate result
```

`Host` is not a semantic escape hatch. It is a standard-library surface over the FFI discipline defined in Section 9.

Host interoperability supports execution profiles. It does not make host OS behavior equivalent to PMS-OS.

### 11.20 Verification Domain: `Verify`

`Verify` provides APIs and annotations for validation, assertions, model-checking hooks, golden fixtures, property registration, and test profiles.

Typical exports:

```text
assert
assume
invariant
precondition
postcondition
check_effects
check_policy
model_state
golden_trace
```

Effect profile:

```text
Verify.assert:
    effects(Δ, Ψ, Φ, Σ)

Verify.invariant:
    effects(Δ, Ψ, Σ)

Verify.golden_trace:
    effects(Δ, Θ, Σ, Ψ, Φ)
```

Verification operation reading:

```text
Δ classify property
Ψ evaluate or register property
Σ commit assertion/invariant result if traceable
Φ trap on violation if configured
```

Validation in this domain means profile-local acceptance or rejection under a declared schema, model, runtime profile, tool profile, or conformance rule.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, or theoretical adequacy.

`Verify` supports implementation-layer validation, analysis, testing, conformance checking, model checking hooks, and proof workflows. It does not validate PMS Base.

### 11.21 PMS-IR Domain: `IR`

`IR` provides controlled APIs for PMS-IR construction, inspection, serialization, and validation.

Typical exports:

```text
IRNode
IRProgram
OpTag
EffectSet
Builder
validate
serialize
deserialize
inspect
```

Effect profile:

```text
IR.validate:
    effects(Δ, Ψ, Σ, Φ)

IR.serialize:
    effects(Δ, ∇, Σ, Φ)

IR.build:
    effects(Δ, ∇, Σ, Ψ)
```

IR operation reading:

```text
Δ classify IR node/operator
Ψ validate structural constraints
∇ construct or transform IR
Σ commit IR program/buffer state
Φ trap on invalid node or failed serialization
```

This domain is especially relevant for tooling, REPLs, script runners, validation layers, and PMS-RUST-style builder surfaces. It is not a substitute for PMSL language semantics.

`IR.validate` means acceptance/rejection under a declared PMS-IR schema or tool profile. It is not verification evidence by itself and not PMS Base validation.

### 11.22 Diagnostics Domain: `Diag`

`Diag` provides structured diagnostics.

Typical exports:

```text
Diagnostic
DiagnosticCode
SourceSpan
emit_error
emit_warning
emit_note
operator_error
```

Effect profile:

```text
Diag.emit_error:
    effects(Δ, Ψ, ∇, Σ)
```

Diagnostic operation reading:

```text
Δ classify failed obligation
Ψ classify severity/policy
∇ emit diagnostic
Σ commit diagnostic record
```

Diagnostics should preserve:

```text
source span
operator class
failed obligation
expected type/effect/policy
actual type/effect/policy
suggested correction where available
```

Diagnostics are tooling outputs under a declared profile. They are not proof artifacts and not PMS Base validation.

### 11.23 Tooling and AI Boundary

AI-related tooling is not a PMSL standard-library semantics domain.

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

The standard library may expose host/tooling-service wrappers only as advisory host services, for example through `Host`, `IR`, `Trace`, `Diag`, or profile-specific tooling modules.

Permitted role:

```text
AI proposes PMS-IR or opcode programs.
AI analyzes traces.
AI suggests explanations.
AI proposes missing-obligation hypotheses.
AI drafts diagnostics or simulation scenarios.
```

Not permitted role:

```text
AI defines PMSL semantics.
AI authorizes execution.
AI validates PMS-IR.
AI replaces policy evaluation.
AI becomes trusted executable code.
AI emits verification evidence.
AI validates PMS Base.
```

Required boundary:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output is not PMSL source authority.

AI output is not PMS-IR truth.

AI output is not verification evidence.

AI output is not trusted executable code.

AI output is not PMS Base validation.

### 11.24 Standard Library Domain Table

Summary:

| Domain | Main role | Dominant operators |
| ------ | --------- | ------------------ |
| `Core` | primitive values and result forms | Δ, Λ, Φ, Σ, Α |
| `Frame` | frame management | □, Ω, Χ projection, Ψ, Σ |
| `Auth` | roles and capabilities | Ω, Ψ, Σ |
| `Policy` | policy activation/checks | Ψ, Ω, Φ, Σ |
| `FS` | filesystem APIs | Δ, Ω, Χ projection, Ψ, ∇, Σ, Φ, Λ |
| `Net` | networking APIs | Δ, Ω, Χ projection, Ψ, Θ, Λ, ∇, Σ, Φ |
| `Time` | timers and ordering | Θ, Λ, Σ |
| `Log` | program logging | Δ, ∇, Σ, Ψ |
| `Trace` | runtime trace/audit hooks | Δ, Θ, Σ, Ψ |
| `Task` | structured concurrency | □, Θ, Λ, Φ, Σ, Ψ |
| `Channel` | IPC/message passing | Δ, Ω, Χ projection, Θ, Λ, ∇, Σ |
| `Sync` | locks/sync primitives | Ω, Θ, Λ, ∇, Σ, Φ |
| `Event` | pub/sub and event routing | Δ, Ω, Χ projection, Θ, ∇, Σ |
| `Runtime` | runtime introspection/control | Δ, □, Ω, Ψ, Σ |
| `Module` | module lifecycle | Δ, □, Ω, Χ projection, Ψ, Θ, Φ, Σ |
| `Host` | FFI/host services | Φ, □, Χ projection, Ω, Ψ, Σ |
| `Verify` | assertions/validation hooks | Δ, Ψ, Φ, Σ |
| `IR` | PMS-IR construction/validation | Δ, ∇, Ψ, Σ, Φ |
| `Diag` | diagnostics | Δ, Ψ, Σ |

This table is architectural. It defines API-domain obligations, not a completed implementation inventory.

### 11.25 Standard Library Profiles

Not every runtime profile must support every standard-library domain.

Profiles may include:

```text
minimal
core_only
deterministic_test
host_runtime
pms_os_runtime
simulation
embedded
security_hardened
distributed
tooling
```

Example minimal profile:

```text
Core
Diag
IR
Verify subset
```

Example host runtime profile:

```text
Core
Frame
Auth
Policy
FS
Net
Time
Log
Trace
Task
Channel
Sync
Runtime
Module
Host
Diag
```

Example deterministic test profile:

```text
Core
Time virtualized
Task deterministic scheduler
Channel deterministic queues
Trace stable JSONL
IR validation
Verify golden traces
Host restricted or disabled
```

Profile rule:

```text
unsupported standard-library APIs must fail as declared absence,
backend trap, or policy denial.
```

Runtime profile support is a bounded implementation claim. It does not imply a complete standard library or complete runtime.

### 11.26 Standard Library and PMS-IR

Standard-library calls must lower into PMS-IR with known profiles.

Example:

```pmsl
FS.write(path, data)
```

PMS-IR outline:

```text
IR.StdCall {
    domain: FS,
    function: write,
    op: ∇,
    effects: [Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ],
    capability: fs.write,
    policy: active_fs_policy,
    commit_profile: write_profile,
    absence_profile: no_space_or_missing_target,
    trap_profile: IOError,
    source_span: ...
}
```

Example:

```pmsl
Time.sleep(50ms)
```

PMS-IR outline:

```text
IR.StdCall {
    domain: Time,
    function: sleep,
    op: Θ,
    effects: [Δ, Θ, Λ, Σ],
    absence_profile: interrupted_or_cancelled_wait,
    commit_profile: wake_state,
    source_span: ...
}
```

This allows standard-library calls to remain analyzable.

`IR.StdCall` nodes may be executed by PMSL runtime services, host services, PMS-OS syscalls, simulator adapters, or PMS-RUST-style bounded slices under declared profiles. The backend may vary; the operator profile remains visible.

### 11.27 Static Analysis of Standard Library Calls

A PMSL checker should verify:

```text
required capability exists
active frame permits the effect
active boundary permits access
active policy permits the call
declared absence paths are handled or propagated
declared trap paths are handled or propagated
commit profile matches the caller’s expectation
unsupported runtime profile is handled
resource usage is policy-compatible where known
```

Example error:

```text
error[Ω]:
    FS.write requires cap fs.write(path)
    active role lacks capability
```

Example error:

```text
error[Σ]:
    caller expects Σ_durable<Unit>
    FS.write profile provides only Σ_visible<Unit>
    call FS.sync or use durable_write profile
```

Static analysis accepts or rejects under a declared profile. It does not prove all possible library behavior and does not validate PMS Base.

### 11.28 Runtime Obligations

The runtime must provide standard-library dispatch.

Dispatch flow:

```text
Δ resolve domain/function
Δ load standard-library profile
Ω check authority
Χ check projected boundary
Ψ evaluate policy
∇ invoke runtime/OS/host/backend service
Σ integrate result
Λ/Φ handle declared non-event or trap
Θ update ordering where relevant
```

Runtime obligations:

```text
standard-library symbol resolution
effect-profile lookup
capability enforcement
policy enforcement
backend support check
trace emission where required
resource accounting where supported
error/absence/commit mapping
```

Standard-library functions may be implemented in PMSL, PMS-IR, host code, PMS-OS syscalls, runtime services, or simulator operations. Their operator profiles remain the same.

This section specifies runtime obligations for API profiles. It does not claim that every runtime profile already implements every domain.

### 11.29 Standard Library Failure Paths

Standard-library failures are operator-typed.

| Failure | Operator reading |
| ------- | ---------------- |
| unknown domain/function | Δ failure |
| unsupported runtime profile | Λ / Φ / Ψ |
| missing capability | Ω / Ψ |
| boundary denial | Χ projection / Ψ / Φ |
| policy denial | Ψ / Φ |
| no message / no event | Λ |
| timeout | Λ / Θ |
| IO failure | Φ |
| no resource | Λ / Ψ / Φ |
| commit mismatch | Σ / Φ |
| host failure | Φ / Λ / Ψ |
| trace failure | Σ / Ψ / Φ |
| invalid IR | Δ / Ψ / Φ |
| AI/tooling proposal rejected | Ψ / validation rejection |

A standard-library implementation must preserve these categories.

A library profile that collapses all failures into one opaque runtime error loses PMSL structure.

### 11.30 Standard Library Invariants

PMSL maintains the following standard-library invariants.

```text
I1: every standard-library domain is a module or module family
I2: every exported standard-library API has a type signature
I3: every exported standard-library API has an effect profile
I4: protected APIs declare Ω capability requirements
I5: boundary-crossing APIs declare Χ-projected behavior
I6: policy-governed APIs declare Ψ behavior
I7: absence-capable APIs declare Λ outcomes
I8: trap-capable APIs declare Φ outcomes
I9: commit-capable APIs declare Σ profiles
I10: standard-library calls lower to PMS-IR as StdCall or equivalent operator-visible nodes
I11: runtime profiles declare supported domains
I12: unsupported APIs fail through typed Λ/Φ/Ψ outcomes
I13: host-backed APIs use FFI/Host profiles rather than hidden host behavior
I14: standard-library logging, trace, and audit APIs preserve ordering and commit state where required
I15: standard-library APIs may abstract patterns but may not hide operator obligations
I16: standard-library profiles are architecture-level API profiles, not proof of completed library implementation
I17: traces record observed library/runtime events under declared profiles; they do not validate PMS Base
I18: AI/tooling-assisted library artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL standard library, runtime dispatcher, backend adapter, verifier, or PMS-OS library surface already enforces every invariant.

### 11.31 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for standard-library-adjacent slices when those slices are represented through its supported runtime/profile surface.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR standard-library-adjacent behavior, such as validator acceptance/rejection, deterministic runtime stepping, vFS-like service calls, JSONL trace emission, golden fixture comparison, and AI proposal gating.

It does not complete:

```text
PMSL standard library
PMSL runtime dispatcher
PMSL FS domain
PMSL Net domain
PMSL concurrency APIs
PMSL host-service bridge
PMSL compiler
PMS-IR optimizer
PMS-CPU
PMS-OS library surface
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL standard-library implementation and does not validate PMS Base.

### 11.32 Boundary to Concurrency and IO APIs

This section defines standard-library domains.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| concrete concurrency and IO API signatures | Section 12 |
| PMS-IR full representation of StdCall nodes | Section 13 |
| static standard-library linting | Section 14 |
| verification over library calls | Section 15 |
| trace/debug views for library calls | Section 16 |
| simulation of library behavior | Section 17 |
| runtime security of library APIs | `06_runtime_security.md` |
| distributed standard-library/network profiles | `07_distributed_systems.md` |
| PMS-RUST evidence mapping | `08_relation_to_pms_rust.md` |

Section 12 refines the concurrency and IO APIs as concrete standard-library surfaces.

### 11.33 Architectural Consequence

The consequence of the PMSL standard library is:

```text
The PMSL standard library is the canonical API layer for reusable
operator-typed programming. It packages common domains — Core, Frame,
Auth, Policy, FS, Net, Time, Log, Trace, Task, Channel, Sync, Event,
Runtime, Module, Host, Verify, IR, and Diagnostics — as analyzable
Α-patterns whose type signatures, effect profiles, capability
requirements, boundary behavior, absence paths, trap paths, commit
profiles, and policy constraints remain visible in PMS-IR.
```

This gives PMSL a standard library that is convenient without becoming opaque: every library abstraction remains a structured projection of Δ–Ψ rather than an untyped runtime shortcut.

### 11.34 Standard-Library Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL standard-library model specifies architecture-level API domains:
Core, Frame, Auth, Policy, FS, Net, Time, Log, Trace, Task, Channel, Sync,
Event, Runtime, Module, Host, Verify, IR, Diagnostics, standard-library
profiles, PMS-IR StdCall lowering, static analysis, runtime dispatch,
failure paths, PMS-RUST evidence boundaries, and AI/tooling boundaries.

This is a language standard-library / API-domain architecture claim.

It does not claim a completed PMSL standard library, completed library
implementation, completed runtime dispatcher, completed host adapter,
completed PMS-OS library surface, completed distributed library surface,
completed verifier, completed PMSL implementation, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, program buffering, model validation, stateful runtime
validation, deterministic execution, JSONL traces, REPL/script tooling,
vFS service boundaries, golden fixtures, and AI proposal gating. It does
not complete PMSL/PMS-IR standard-library implementation and does not
validate PMS Base.
```

---

## 12. Concurrency and IO APIs

PMSL concurrency and IO APIs are the concrete standard-library surfaces through which tasks, channels, events, timers, synchronization objects, filesystem operations, network operations, host calls, asynchronous completions, resource pressure, cancellation, and runtime-profile obligations become programmable.

These APIs are not thin wrappers around host threads, POSIX calls, sockets, or opaque async runtimes. They are source-level and library-level interfaces whose behavior remains operator-typed and PMS-IR-visible.

The central API claim is:

```text
PMSL concurrency and IO APIs are valid when their calls expose
□ task/frame structure, Δ operation classification, Ω authority,
Χ-projected visibility, Ψ policy, Θ ordering, Λ absence, ∇ effect,
Σ commit, and Φ recovery/trap behavior in their signatures, effects,
runtime profiles, and PMS-IR lowering.
```

This section refines Sections 6 and 11 into concrete API families. It remains a specification-layer API architecture, not a claim that every API listed here already exists as a complete implementation.

Claim type:

```text
LANGUAGE CONCURRENCY / IO API ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL concurrency and IO APIs as architecture-level
standard-library API profiles.

It does not claim a completed PMSL concurrency library, completed IO
library, completed async runtime, completed scheduler, completed channel
implementation, completed filesystem backend, completed network backend,
completed host adapter, completed PMS-OS syscall surface, completed
distributed runtime, completed verifier, or completed PMSL implementation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

The API families in this section are architecture-level API profiles. They define type signatures, effect obligations, authority requirements, boundary projections, runtime contracts, PMS-IR lowering, and profile-local conformance obligations. They do not claim that every listed API already exists as a completed library/runtime implementation.

Validation in this section means acceptance or rejection under a declared API profile, type/effect rule, runtime profile, backend profile, IO profile, standard-library profile, PMS-IR schema, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, API correctness, backend correctness, scheduler fairness, distributed correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR concurrency and IO API level, Χ is projected as task boundary, channel endpoint visibility, filesystem namespace visibility, network reachability, host boundary, runtime boundary, sandbox boundary, memory-domain separation, handle reachability, service boundary, and cross-frame transfer discipline.

PMSL/PMS-IR does not redefine Χ.

### 12.1 API Design Rule

Every PMSL concurrency or IO API has the form:

```text
API = (
    name,
    domain,
    signature,
    effects,
    requires,
    absence_profile,
    trap_profile,
    commit_profile,
    runtime_profile,
    lowering
)
```

where:

| Field | Meaning |
| ----- | ------- |
| `name` | API symbol |
| `domain` | Task, Channel, Sync, Event, FS, Net, Time, Host, Runtime |
| `signature` | value-level types |
| `effects` | Δ–Ψ effect profile |
| `requires` | roles, capabilities, policies, boundary profiles |
| `absence_profile` | Λ outcomes |
| `trap_profile` | Φ outcomes |
| `commit_profile` | Σ visibility/durability/lifecycle claim |
| `runtime_profile` | required backend/runtime support |
| `lowering` | PMS-IR form |

A concurrency or IO API is valid when:

```text
signature is type-correct
∧ effects are complete
∧ authority is explicit
∧ boundary behavior is explicit as a Χ projection
∧ policy behavior is explicit
∧ absence and trap outcomes are typed
∧ commit behavior is not overstated
∧ unsupported runtime profiles fail through typed outcomes
```

An API may be convenient. It may not become opaque.

A PMSL API that hides authority, boundary projection, absence, trap, commit, policy, or runtime-profile behavior is not PMSL-conformant.

### 12.2 API Domains

This section covers these API families:

```text
Task API
TaskGroup API
Supervisor API
Channel API
Request/Response API
Select API
Event API
Timer/Timeout API
Synchronization API
Filesystem IO API
Network IO API
Async IO API
Stream API
Resource and Backpressure API
Cancellation API
Runtime IO Profile API
```

They are interdependent, but each has its own dominant operator structure.

These API families refine the Section 11 standard-library domains into concrete surfaces. They remain specification-level API profiles unless implemented by a concrete runtime/library artifact under a declared profile.

### 12.3 Task API

The Task API creates, observes, joins, cancels, and scopes PMSL tasks.

Core types:

```pmsl
Task<T>
TaskId
TaskHandle<T>
TaskResult<T>
TaskError
CancellationToken
TaskPolicy
```

Core functions:

```pmsl
Task.spawn<T>(body: fn() -> T) -> Result<TaskHandle<T>, Φ_trap<TaskError>>
Task.await<T>(task: TaskHandle<T>) -> Result<T, Λ_absent<T> | Φ_trap<TaskError>>
Task.cancel(task: TaskHandle<any>) -> Result<Σ_local<Unit>, Φ_trap<CancellationError>>
Task.yield() -> Σ_local<Unit>
Task.current() -> TaskId
```

Spawn profile:

```text
effects(Δ, Ω, □, Χ, Ψ, Θ, Σ, Φ, Λ)
requires Ω(task.spawn)
```

Spawn lowering:

```text
Δ classify task body and result type
Ω verify spawn authority
□ create TaskFrame
Χ establish projected task boundary
Ψ attach task policy
Θ enqueue task
Σ commit task creation
Λ no-resource if task frame cannot be created
Φ trap on invalid task body or runtime failure
```

Await profile:

```text
effects(Δ, Ω, Χ, Ψ, Θ, Λ, Σ, Φ)
requires Ω(task.await)
```

Await lowering:

```text
Δ classify task handle
Ω verify await authority
Χ verify projected task visibility
Ψ check await policy
Θ wait for completion
Λ not-ready or timeout if bounded
Σ integrate task result
Φ propagate task failure
```

Task API invariants:

```text
I1: every task handle references a TaskFrame
I2: spawned tasks have lifecycle owners unless detached by policy
I3: await integrates result through Σ
I4: cancellation recontextualizes through Φ
I5: task creation and completion are traceable where profile enables tracing
I6: task boundaries remain PMSL/PMS-IR Χ projections, not PMS Base redefinitions
```

A task may lower to a green task, host thread, PMS-OS task, simulator event, or deterministic runtime event under a declared backend profile. The mapping may vary; the operator obligations remain.

### 12.4 TaskGroup API

The TaskGroup API provides structured concurrency.

Core types:

```pmsl
TaskGroup<T>
TaskGroupPolicy
GroupResult<T>
Quorum<N>
```

Core functions:

```pmsl
TaskGroup.new<T>(policy: TaskGroupPolicy) -> TaskGroup<T>
TaskGroup.spawn<T>(group: TaskGroup<T>, body: fn() -> T) -> TaskHandle<T>
TaskGroup.await_all<T>(group: TaskGroup<T>) -> Result<List<T>, Φ_trap<TaskGroupError>>
TaskGroup.await_any<T>(group: TaskGroup<T>) -> Result<T, Λ_absent<T> | Φ_trap<TaskGroupError>>
TaskGroup.cancel_all(group: TaskGroup<any>) -> Result<Σ_local<Unit>, Φ_trap<CancellationError>>
```

TaskGroup profile:

```text
effects(Δ, Ω, □, Χ, Ψ, Θ, Λ, Φ, Σ)
```

Group creation:

```text
□ create TaskGroupFrame
Ψ attach group lifecycle policy
Χ establish projected group boundary
Σ commit group frame
```

Group await:

```text
Θ wait for selected completion condition
Λ not-ready if bounded condition absent
Φ handle child failure according to policy
Σ integrate group result
```

TaskGroup invariants:

```text
I1: group children are frame-contained
I2: parent frame cannot close while child tasks remain live unless policy detaches them
I3: failure propagation is Ψ-defined
I4: group result is Σ-integrated
I5: task leaks are rejected unless explicit detached policy applies
I6: detached behavior is policy-governed, not implicit background work
```

Structured concurrency is the default discipline. Detachment is an explicit lifecycle transition, not an escape from task ownership.

### 12.5 Supervisor API

The Supervisor API encodes recovery and lifecycle policy over child tasks.

Core types:

```pmsl
Supervisor
SupervisorPolicy
RestartPolicy
FailurePolicy
BackoffPolicy
```

Core functions:

```pmsl
Supervisor.new(policy: SupervisorPolicy) -> Supervisor
Supervisor.spawn<T>(sup: Supervisor, body: fn() -> T) -> TaskHandle<T>
Supervisor.restart(task: TaskHandle<any>) -> Result<Σ_local<Unit>, Φ_trap<SupervisorError>>
Supervisor.status(sup: Supervisor) -> SupervisorState
```

Supervisor operation reading:

```text
Δ classify child failure or lifecycle event
Ψ evaluate supervisor policy
Φ recontextualize child task lifecycle
Θ order restart/backoff
Σ commit restarted, degraded, or failed state
```

Supervisor policies may include:

```text
restart
restart_with_backoff
degrade
escalate
quarantine
cancel_group
halt_service
```

Supervisor API invariant:

```text
supervision is an Α pattern over Φ recovery, Θ restart order,
Σ lifecycle commit, and Ψ failure policy.
```

A supervisor is not a governance tribunal. It is a runtime/API policy frame for child-task lifecycle handling.

### 12.6 Channel API

The Channel API provides typed message passing.

Core types:

```pmsl
Channel<T>
Sender<T>
Receiver<T>
ChannelPolicy
DeliveryProfile
ChannelClosed
SendError
RecvError
```

Core functions:

```pmsl
Channel.new<T>(capacity: Capacity, policy: ChannelPolicy)
    -> Result<Channel<T>, Φ_trap<ChannelError>>

Channel.split<T>(ch: Channel<T>)
    -> Pair<Sender<T>, Receiver<T>>

Channel.send<T>(tx: Sender<T>, msg: T)
    -> Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<SendError>>

Channel.recv<T>(rx: Receiver<T>)
    -> Result<T, Λ_absent<T> | Φ_trap<RecvError>>

Channel.try_send<T>(tx: Sender<T>, msg: T)
    -> Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<SendError>>

Channel.try_recv<T>(rx: Receiver<T>)
    -> Result<T, Λ_absent<T> | Φ_trap<RecvError>>

Channel.close<T>(ch: Channel<T>)
    -> Result<Σ_local<Unit>, Φ_trap<ChannelError>>
```

Send profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)
requires Ω(channel.send<T>)
```

Receive profile:

```text
effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
requires Ω(channel.recv<T>)
```

Send lowering:

```text
Δ classify channel and payload
Ω verify SEND capability
Χ verify projected endpoint visibility
Ψ check channel policy
∇ enqueue message
Θ wake receiver if waiting
Σ commit delivery state
Λ no-space if full under nonblocking/bounded profile
Φ trap on closed channel or invalid payload
```

Receive lowering:

```text
Δ classify channel
Ω verify RECEIVE capability
Χ verify projected endpoint visibility
Ψ check receive policy
Θ wait or inspect queue
Λ no-message if empty under selected profile
∇ dequeue payload
Σ commit receive state
Φ trap on closed channel, invalid payload, or policy failure
```

Channel close lowering:

```text
Δ classify open/closed state
Ω verify CLOSE capability
Ψ check close policy
∇ mark closed
Θ wake waiters
Σ commit close
Φ mark future invalid operations where profile requires
```

A channel is a typed communication frame, not a raw queue. Endpoint visibility, authority, policy, absence, trap, and commit behavior remain visible in PMS-IR.

### 12.7 Select API

The Select API waits over multiple receivers, timers, events, or futures.

Core types:

```pmsl
Select<T>
SelectArm<T>
SelectPolicy
Ready<T>
```

Example syntax:

```pmsl
select {
    msg = Channel.recv(inbox) => handle_msg(msg)
    ev  = Event.recv(events)  => handle_event(ev)
    Time.timeout(100ms)       => handle_timeout()
}
```

API form:

```pmsl
Select.run<T>(arms: List<SelectArm<T>>, policy: SelectPolicy)
    -> Result<T, Λ_absent<T> | Φ_trap<SelectError>>
```

Operator profile:

```text
effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
```

Lowering:

```text
Δ classify selectable arms
Ω verify authority for each arm
Χ verify projected visibility for each source
Ψ check select policy
Θ order readiness evaluation
Λ no-ready-source or timeout
∇ execute selected continuation
Σ integrate selected result
Φ trap on invalid arm or selected-source failure
```

Select policy may be:

```text
first_ready
fair
priority
deadline
source_order
randomized_by_policy
deterministic_test_order
```

Select invariants:

```text
I1: every arm has compatible result type
I2: every arm exposes effects and failure paths
I3: readiness ordering is Θ-defined
I4: no-ready outcome is Λ-visible
I5: selected result integrates through Σ
```

A select API may be deterministic under a test/runtime profile or policy-defined under another profile. The profile must state the selection rule.

### 12.8 Request/Response API

The Request/Response API packages a common Α pattern.

Core types:

```pmsl
Request<TReq, TResp>
Response<TResp>
Client<TReq, TResp>
Server<TReq, TResp>
RequestId
```

Core functions:

```pmsl
Request.send<TReq, TResp>(
    client: Client<TReq, TResp>,
    req: TReq,
    timeout: Duration
) -> Result<TResp, Λ_absent<TResp> | Φ_trap<RequestError>>

Request.reply<TResp>(
    req_id: RequestId,
    response: TResp
) -> Result<Σ_delivery<Unit>, Φ_trap<ResponseError>>
```

Client request lowering:

```text
Δ classify request and response type
Ω verify request authority
Χ check projected server endpoint visibility
Ψ check request policy
∇ enqueue request
Σ commit request visibility
Θ wait for response
Λ timeout/no-response
Φ trap on protocol or remote error
Σ integrate response
```

Server reply lowering:

```text
Δ classify reply target and payload
Ω verify reply authority
Χ check projected client reply endpoint
Ψ check response policy
∇ enqueue response
Σ commit response visibility
```

Request/Response invariant:

```text
request and response types remain paired across the whole protocol path.
```

Request/response is a reusable protocol pattern. It does not bypass channel, endpoint, policy, boundary, absence, trap, or commit obligations.

### 12.9 Event API

The Event API exposes typed publication and subscription.

Core types:

```pmsl
Event<T>
Topic<T>
Subscription<T>
EventPolicy
EventId
```

Core functions:

```pmsl
Event.topic<T>(name: String, policy: EventPolicy)
    -> Topic<T>

Event.publish<T>(topic: Topic<T>, payload: T)
    -> Result<Σ_delivery<Unit>, Λ_absent<Subscriber> | Φ_trap<EventError>>

Event.subscribe<T>(topic: Topic<T>, handler: fn(T) -> Unit)
    -> Result<Subscription<T>, Φ_trap<EventError>>

Event.unsubscribe<T>(sub: Subscription<T>)
    -> Result<Σ_local<Unit>, Φ_trap<EventError>>
```

Publish profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ)
```

Publish lowering:

```text
Δ classify topic and payload
Ω verify publish authority
Χ verify projected topic visibility
Ψ check event policy
∇ enqueue/publicize event
Θ order dispatch
Σ commit publication
Λ no-subscriber if declared as absence
Φ trap on invalid payload or policy failure
```

Subscription lowering:

```text
Δ classify topic and handler
Ω verify subscribe authority
Χ verify projected topic visibility
Ψ check subscription policy
Σ commit subscription
```

Events are typed transition triggers. They are not automatically delivered merely because they are declared; delivery depends on runtime/backend profile, policy, boundary visibility, scheduling, and commit semantics.

### 12.10 Timer and Timeout API

The Time API provides deadlines, sleeps, intervals, and timeouts.

Core types:

```pmsl
Duration
Instant
Deadline
Timer
Interval
Timeout<T>
```

Core functions:

```pmsl
Time.now() -> Instant

Time.sleep(duration: Duration)
    -> Result<Σ_local<Unit>, Λ_absent<Waker> | Φ_trap<TimeError>>

Time.timeout<T>(duration: Duration, op: fn() -> T)
    -> Result<T, Λ_absent<T> | Φ_trap<TimeError>>

Time.interval(duration: Duration)
    -> Stream<Tick>
```

Sleep profile:

```text
effects(Δ, Θ, Λ, Σ, Φ)
```

Timeout lowering:

```text
Δ classify duration and operation
Θ register deadline and order wait
∇ execute or begin operation
Λ if completion absent before deadline
Σ integrate completed result
Φ trap on timer/runtime failure
```

Timer invariants:

```text
I1: timer ordering is Θ-defined
I2: timeout is Λ, not generic exception
I3: virtual-time profiles may replace wall-clock sources
I4: τ-derived data is metadata; Θ is the ordering operator
```

Concrete precision, jitter, clock source semantics, and host clock behavior belong to declared runtime/OS/host profiles. Time APIs do not equate wall-clock behavior with PMS ordering.

### 12.11 Filesystem IO API

The Filesystem IO API provides typed file and directory operations.

Core types:

```pmsl
Path
File
Dir
Handle<T>
OpenMode
Metadata
ReadBuf
WriteBuf
FileError
```

Core functions:

```pmsl
FS.open(path: Path, mode: OpenMode)
    -> Result<Handle<File>, Λ_absent<Path> | Φ_trap<FileError>>

FS.read(h: Handle<File>, n: Int)
    -> Result<Bytes, Λ_absent<Bytes> | Φ_trap<FileError>>

FS.write(h: Handle<File>, data: Bytes)
    -> Result<Σ_visible<Unit>, Λ_absent<Space> | Φ_trap<FileError>>

FS.sync(h: Handle<File>)
    -> Result<Σ_durable<Unit>, Φ_trap<FileError>>

FS.close(h: Handle<File>)
    -> Result<Σ_local<Unit>, Φ_trap<FileError>>

FS.exists(path: Path)
    -> Result<Bool, Φ_trap<FileError>>

FS.stat(path: Path)
    -> Result<Metadata, Λ_absent<Path> | Φ_trap<FileError>>

FS.mkdir(path: Path)
    -> Result<Σ_visible<Unit>, Φ_trap<FileError>>

FS.remove(path: Path)
    -> Result<Σ_visible<Unit>, Λ_absent<Path> | Φ_trap<FileError>>

FS.rename(src: Path, dst: Path)
    -> Result<Σ_visible<Unit>, Φ_trap<FileError>>
```

Open profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
requires Ω(fs.open)
```

Read profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
requires Ω(fs.read)
```

Write profile:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
requires Ω(fs.write)
```

Sync profile:

```text
effects(Δ, Ω, Ψ, ∇, Σ, Φ)
requires Ω(fs.sync)
```

Filesystem API rule:

```text
write ≠ durable commit
```

A write may produce:

```text
Σ_visible<Unit>
```

whereas sync may produce:

```text
Σ_durable<Unit>
```

A PMSL API must not claim durable commit where the runtime/backend provides only visible or staged state.

Filesystem APIs may be backed by host filesystem services, PMS-OS syscalls, vFS-like runtime surfaces, test fixtures, or simulators. The backing profile may vary; type/effect and commit obligations remain.

### 12.12 Async Filesystem IO

Async filesystem APIs separate initiation, wait, and completion.

Core types:

```pmsl
IOFuture<T>
IORequest<T>
IOCompletion<T>
```

Core functions:

```pmsl
FS.read_async(h: Handle<File>, n: Int)
    -> Result<IOFuture<Bytes>, Φ_trap<FileError>>

FS.write_async(h: Handle<File>, data: Bytes)
    -> Result<IOFuture<Σ_visible<Unit>>, Φ_trap<FileError>>

IO.await<T>(fut: IOFuture<T>, timeout: Duration)
    -> Result<T, Λ_absent<T> | Φ_trap<IOError>>

IO.cancel<T>(fut: IOFuture<T>)
    -> Result<Σ_local<Unit>, Φ_trap<CancellationError>>
```

Async read initiation:

```text
Δ classify IO request
Ω verify IO authority
Χ check projected handle/boundary visibility
Ψ check IO policy
∇ submit request
Σ commit pending IOFuture
```

Async completion:

```text
Θ wait for completion
Λ no-completion before timeout
Φ map IO failure
Σ integrate completed result
```

Async IO invariant:

```text
submission commit and completion commit are distinct Σ states.
```

Async IO must not hide pending work outside lifecycle, cancellation, boundary, and resource accounting discipline.

### 12.13 Network IO API

The Network API exposes endpoints, connections, packets, streams, and request/response forms.

Core types:

```pmsl
Address
Endpoint
Connection
Listener
Packet
Stream<T>
NetError
```

Core functions:

```pmsl
Net.connect(addr: Address)
    -> Result<Connection, Λ_absent<Connection> | Φ_trap<NetError>>

Net.listen(endpoint: Endpoint)
    -> Result<Listener, Φ_trap<NetError>>

Net.accept(listener: Listener)
    -> Result<Connection, Λ_absent<Connection> | Φ_trap<NetError>>

Net.send(conn: Connection, data: Bytes)
    -> Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<NetError>>

Net.recv(conn: Connection, max: Int)
    -> Result<Bytes, Λ_absent<Bytes> | Φ_trap<NetError>>

Net.close(conn: Connection)
    -> Result<Σ_local<Unit>, Φ_trap<NetError>>
```

Connect profile:

```text
effects(Δ, Ω, Χ, Ψ, Θ, Λ, Φ, ∇, Σ)
requires Ω(net.connect)
```

Send/receive profiles mirror Channel and FS semantics, but with network-specific failure and boundary states.

Network IO outcomes:

```text
no route        → Λ or Φ depending on profile
timeout         → Λ
connection lost → Φ
backpressure    → Λ / Θ / Ψ
policy denial   → Ψ / Φ
delivery commit → Σ_delivery
```

Cross-node and distributed consistency are refined in `07_distributed_systems.md`.

A `Net` API profile is not, by itself, a distributed-system correctness claim.

### 12.14 Stream API

The Stream API abstracts ordered sequences of items.

Core types:

```pmsl
Stream<T>
StreamItem<T>
StreamEnd
StreamError
```

Core functions:

```pmsl
Stream.next<T>(s: Stream<T>)
    -> Result<T, Λ_absent<T> | Φ_trap<StreamError>>

Stream.send<T>(s: Stream<T>, item: T)
    -> Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<StreamError>>

Stream.close<T>(s: Stream<T>)
    -> Result<Σ_local<Unit>, Φ_trap<StreamError>>

Stream.map<T, U>(s: Stream<T>, f: fn(T) -> U)
    -> Stream<U>

Stream.filter<T>(s: Stream<T>, p: fn(T) -> Bool)
    -> Stream<T>
```

Stream reading:

```text
Δ classify stream and item
Ω check stream authority
Χ check projected endpoint visibility
Ψ check stream policy
Θ order items
Λ end/no-item/not-ready
∇ produce/consume item
Σ commit item delivery or stream closure
Φ trap on protocol/backend failure
```

Stream APIs are Α patterns over channels, events, files, or network connections.

A stream abstraction may not hide backpressure, end-of-stream, trap, policy, or commit behavior.

### 12.15 Synchronization API

The Synchronization API exposes shared-state coordination.

Core types:

```pmsl
Mutex<T>
RwLock<T>
Semaphore
CondVar
Barrier
Atomic<T>
Futex<T>
LockGuard<T>
ReadGuard<T>
WriteGuard<T>
```

Core functions:

```pmsl
Mutex.new<T>(value: T) -> Mutex<T>
Mutex.lock<T>(m: Mutex<T>) -> Result<LockGuard<T>, Λ_absent<LockGuard<T>> | Φ_trap<LockError>>
Mutex.try_lock<T>(m: Mutex<T>) -> Result<LockGuard<T>, Λ_absent<LockGuard<T>> | Φ_trap<LockError>>
Mutex.unlock<T>(g: LockGuard<T>) -> Result<Σ_local<Unit>, Φ_trap<LockError>>

RwLock.read<T>(l: RwLock<T>) -> Result<ReadGuard<T>, Λ_absent<ReadGuard<T>> | Φ_trap<LockError>>
RwLock.write<T>(l: RwLock<T>) -> Result<WriteGuard<T>, Λ_absent<WriteGuard<T>> | Φ_trap<LockError>>

Semaphore.acquire(s: Semaphore) -> Result<Permit, Λ_absent<Permit> | Φ_trap<SyncError>>
Semaphore.release(p: Permit) -> Result<Σ_local<Unit>, Φ_trap<SyncError>>
```

Mutex lock lowering:

```text
Δ classify mutex state
Ω verify lock authority
Χ verify projected mutex visibility
Ψ check sync policy
if unlocked:
    ∇ set owner
    Σ commit lock acquisition
else:
    Θ enqueue waiter
    Λ wait or timeout
```

Unlock lowering:

```text
Δ verify owner/guard
Ω verify unlock authority
∇ release lock
Θ wake waiter if present
Σ commit unlock
Φ trap on invalid owner or poisoned state
```

Synchronization API rule:

```text
shared mutable state must be guarded by typed synchronization or rejected
by the active profile.
```

Synchronization APIs are low-level runtime/system APIs. They do not suspend authority, boundary, policy, absence, trap, or commit obligations.

### 12.16 Atomic API

The Atomic API exposes low-level memory coordination.

Core types:

```pmsl
Atomic<T>
MemoryOrder
CompareExchangeResult<T>
```

Core functions:

```pmsl
Atomic.load<T>(a: Atomic<T>, order: MemoryOrder) -> T
Atomic.store<T>(a: Atomic<T>, value: T, order: MemoryOrder) -> Σ_local<Unit>
Atomic.compare_exchange<T>(
    a: Atomic<T>,
    expected: T,
    replacement: T,
    order: MemoryOrder
) -> Result<T, Λ_absent<T> | Φ_trap<AtomicError>>
```

Operator reading:

```text
Δ classify atomic location and expected value
Ω verify memory access authority
Χ verify projected boundary visibility
Ψ check memory-order policy
∇ perform atomic operation
Θ enforce order constraints
Σ commit visible memory state
Λ represent compare-exchange mismatch if profile uses absence
Φ trap on invalid atomic state
```

Atomic APIs are runtime/system-profile APIs. Application profiles may restrict them.

A memory-order profile is an API/runtime contract. It is not a host-memory-model proof unless a corresponding backend/property proof is separately supplied.

### 12.17 Backpressure API

Backpressure is a typed resource and scheduling condition.

Core types:

```pmsl
Backpressure
Capacity
Quota
NoSpace
Throttle
```

Core functions:

```pmsl
Channel.capacity<T>(ch: Channel<T>) -> Capacity
Channel.backpressure<T>(ch: Channel<T>) -> Backpressure
Runtime.throttle(policy: ThrottlePolicy) -> Result<Σ_local<Unit>, Φ_trap<ResourceError>>
```

Backpressure outcomes:

```text
Λ_absent<Space>
Λ_absent<Capacity>
Ψ denial
Θ wait/retry
Φ trap on critical resource state
```

Backpressure API invariant:

```text
full queues, saturated tasks, unavailable buffers, and exhausted
runtime resources must not be reported as successful delivery.
```

Backpressure is part of the typed coordination contract. It must not disappear into opaque runtime behavior.

### 12.18 Cancellation API

Cancellation is shared by tasks, futures, IO, streams, and host calls.

Core types:

```pmsl
CancellationToken
CancellationScope
CancellationError
Cancelled
```

Core functions:

```pmsl
Cancellation.token() -> CancellationToken
Cancellation.cancel(tok: CancellationToken) -> Result<Σ_local<Unit>, Φ_trap<CancellationError>>
Cancellation.check(tok: CancellationToken) -> Result<Unit, Φ_trap<Cancelled>>
Cancellation.scope<T>(tok: CancellationToken, body: fn() -> T) -> Result<T, Φ_trap<Cancelled>>
```

Cancellation lowering:

```text
Δ classify cancellation target/token
Ω verify cancellation authority
Ψ check cancellation policy
Φ recontextualize active operation/task/IO lifecycle
Θ order cancellation delivery
Σ commit cancelled state
```

Cancellation API invariant:

```text
cancellation is not absence; it is Φ lifecycle recontextualization
with Ψ policy and Σ closure.
```

Cancellation may produce absence-related outcomes in surrounding waits, but the cancellation event itself remains Φ/Ψ/Σ lifecycle behavior.

### 12.19 Async/Await API

PMSL async/await is a language/runtime pattern over tasks, futures, events, and IO completions.

Core types:

```pmsl
Future<T>
Promise<T>
Completion<T>
```

Core functions:

```pmsl
Future.await<T>(f: Future<T>) -> Result<T, Λ_absent<T> | Φ_trap<FutureError>>
Future.poll<T>(f: Future<T>) -> Result<T, Λ_absent<T> | Φ_trap<FutureError>>
Promise.complete<T>(p: Promise<T>, value: T) -> Result<Σ_local<Unit>, Φ_trap<FutureError>>
Promise.fail<T>(p: Promise<T>, trap: Φ_trap<any>) -> Result<Σ_local<Unit>, Φ_trap<FutureError>>
```

Await lowering:

```text
Δ classify future
Ω verify observe authority
Χ verify projected visibility
Ψ check await policy
Θ wait or poll
Λ not-ready
Σ integrate result on completion
Φ propagate failure
```

Future completion:

```text
Δ classify promise
Ω verify completion authority
∇ set completed value or trap
Σ commit completion
Θ wake waiters
```

Async/await API invariant:

```text
polling, waiting, completion, cancellation, and failure are separate
operator states.
```

An async API profile may be deterministic, host-adapted, simulator-backed, or PMS-OS-backed. The profile must state its ordering, cancellation, failure, and commit behavior.

### 12.20 IO Handle API

IO handles must be typed and lifecycle-governed.

Core types:

```pmsl
Handle<T>
Readable<T>
Writable<T>
Closable<T>
ResourceOwner
```

Core functions:

```pmsl
IO.close<T>(h: Handle<T>) -> Result<Σ_local<Unit>, Φ_trap<IOError>>
IO.is_open<T>(h: Handle<T>) -> Bool
IO.owner<T>(h: Handle<T>) -> ResourceOwner
IO.transfer<T>(h: Handle<T>, target: Boundary<any>) -> Result<Transferred<Handle<T>>, Φ_trap<BoundaryFault>>
```

Handle rule:

```text
a handle is a frame-bound capability-bearing resource, not an integer.
```

Handle use requires:

```text
Δ classify handle
Ω verify operation capability
Χ verify projected boundary visibility
Ψ check lifecycle policy
∇ perform operation
Σ commit handle state
Φ trap on invalid/closed handle
```

Handle transfer requires explicit boundary and policy approval. A handle may not silently cross a module, task, host, or sandbox boundary.

### 12.21 IO Transaction API

Some IO APIs use transaction profiles.

Core types:

```pmsl
IOTransaction<T>
TransactionPolicy
RollbackError
```

Core functions:

```pmsl
IO.transaction<T>(policy: TransactionPolicy, body: fn() -> T)
    -> Result<Σ_tx<T>, Φ_trap<TransactionError>>

IO.rollback<T>(tx: IOTransaction<T>)
    -> Result<Σ_local<Unit>, Φ_trap<RollbackError>>

IO.commit<T>(tx: IOTransaction<T>)
    -> Result<Σ_tx<T>, Φ_trap<CommitError>>
```

Transaction lowering:

```text
□ create transaction frame
Ψ attach transaction policy
∇ stage effects
Σ commit transaction
Φ rollback/recover on failure
```

Transaction invariants:

```text
I1: staged IO is not visible as committed IO
I2: commit profile is explicit
I3: rollback/compensation path is declared
I4: policy determines partial failure behavior
```

Transaction APIs specify commit discipline under a declared runtime/backend profile. They do not prove external durability or complete reversibility.

### 12.22 Memory Consistency for User-Level APIs

PMSL user-level concurrency APIs define visibility through Θ, Σ, Χ, and Ψ.

Visibility rule:

```text
Visible(value, consumer) iff
    Θ orders producer before consumer
    ∧ Σ commits producer state
    ∧ Χ permits consumer visibility
    ∧ Ψ permits access
```

Examples:

```text
Channel.send Σ_delivery
    → value visible to receiver after receive authority/boundary check

Mutex.unlock Σ
    → protected state visible to next valid lock holder

Atomic.store with order
    → visibility according to memory-order policy

Task.await Σ
    → task result visible to awaiter

FS.sync Σ_durable
    → write durable under backend profile
```

Memory consistency is not a hidden host guarantee. It is part of the API profile.

The `Χ` component in this rule denotes PMSL/PMS-IR layer-projected visibility/reachability, not a redefinition of PMS Base Χ.

### 12.23 Runtime Profile Declarations

Each API may require runtime profile support.

Example:

```pmsl
requires runtime async_io
requires runtime deterministic_scheduler
requires runtime host_fs
requires runtime pms_os_syscalls
requires runtime trace_jsonl
```

Unsupported API behavior:

```text
Λ unsupported / absent feature
Φ_trap<UnsupportedRuntimeFeature>
Ψ denial by runtime policy
```

API declarations may include:

```pmsl
fn FS.read_async(...)
    requires runtime async_io
```

or:

```pmsl
fn Net.connect(...)
    requires runtime network_io
```

This prevents accidental portability claims.

Runtime-profile support is a bounded implementation claim. It does not imply complete runtime support, complete host equivalence, PMS-OS completion, or distributed correctness.

### 12.24 API Lowering to PMS-IR

Every API call lowers to PMS-IR with a known profile.

Generic API call IR:

```text
IR.ApiCall = (
    id,
    domain,
    function,
    op,
    args,
    result_type,
    effects,
    capability_requirements,
    boundary_requirements,
    policy_requirements,
    absence_profile,
    trap_profile,
    commit_profile,
    runtime_profile,
    source_span
)
```

Example:

```pmsl
Channel.send(tx, msg)
```

PMS-IR outline:

```text
IR.ApiCall {
    domain: Channel,
    function: send,
    op: ∇,
    effects: [Δ, Ω, Χ, Ψ, ∇, Θ, Σ, Φ, Λ],
    capability: channel.send<T>,
    commit_profile: Σ_delivery<Unit>,
    absence_profile: Λ_absent<Space>,
    trap_profile: Φ_trap<SendError>
}
```

Example:

```pmsl
FS.sync(h)
```

PMS-IR outline:

```text
IR.ApiCall {
    domain: FS,
    function: sync,
    op: Σ,
    effects: [Δ, Ω, Ψ, ∇, Σ, Φ],
    capability: fs.sync,
    commit_profile: Σ_durable<Unit>,
    trap_profile: Φ_trap<FileError>
}
```

PMS-IR API nodes make library calls analyzable. They are not opaque host calls.

### 12.25 Static Checks for Concurrency and IO APIs

A PMSL checker should verify:

```text
API symbol exists
argument types match
effect profile is permitted by caller
required capabilities are present
boundary visibility holds
policy permits call
runtime profile supports API
absence paths are handled or propagated
trap paths are handled or propagated
commit profile matches caller expectation
handle lifetimes are valid
task/future/channel lifecycle is valid
backpressure is handled where declared
cancellation path is defined where relevant
```

Example static errors:

```text
error[Ω]:
    Channel.send requires channel.send<Message>(C)
    active role lacks capability
```

```text
error[Σ]:
    caller expects Σ_durable<Unit>
    FS.write provides Σ_visible<Unit>
    use FS.sync or durable_write profile
```

```text
error[Λ]:
    recv may produce Λ_absent<Message>
    function does not declare or handle absence
```

Static checks accept or reject under a declared profile. They do not prove all possible API behavior and do not validate PMS Base.

### 12.26 Runtime Obligations

The runtime must implement or reject APIs according to profile.

Runtime obligations include:

```text
API profile lookup
capability check
boundary check
policy check
task/channel/timer/sync state mutation
IO backend dispatch
host/OS/syscall dispatch
absence/trap mapping
commit-state tracking
trace emission where required
resource accounting where supported
```

Runtime API execution flow:

```text
Δ classify API call
Ω check authority
Χ check projected boundary
Ψ evaluate policy/profile
∇ dispatch operation
Θ order/wait/schedule if required
Λ produce absence if expected event/resource absent
Φ map errors
Σ integrate result or commit state
```

A runtime may optimize API dispatch. It may not erase operator classification, authority, boundary, policy, absence, trap, or commit behavior.

### 12.27 API Failure Paths

API failures remain operator-typed.

| API failure | Operator reading |
| ----------- | ---------------- |
| unknown API | Δ failure |
| unsupported runtime profile | Λ / Φ / Ψ |
| missing capability | Ω / Ψ |
| boundary not visible | Χ projection / Ψ / Φ |
| policy denial | Ψ / Φ |
| no message | Λ |
| no space | Λ / Ψ |
| timeout | Λ / Θ |
| cancelled | Φ / Ψ / Σ |
| invalid handle | Δ / Φ |
| closed channel | Φ or typed closed-state |
| IO failure | Φ |
| network failure | Φ / Λ |
| no resource | Λ / Ψ / Φ |
| commit mismatch | Σ / Φ |
| backend panic | Φ / Ψ |
| trace failure | Σ / Ψ / Φ |
| rejected AI/tooling proposal | Ψ / validation rejection |

A runtime or library profile must not collapse these into generic failures where their operator distinction matters.

### 12.28 Trace and Observation Convention for APIs

Concurrency and IO APIs may produce observable events under declared runtime profiles.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL API execution:

```text
trace_pmsl(runtime, api_artifact, input_profile) ∈ L_PMS
```

For the set of possible API executions under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, api_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, api_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, api_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A trace records observed execution under a declared profile. It is artifact evidence for bounded implementation behavior. It is not proof of all possible behavior and not PMS Base validation.

### 12.29 Example: Async File Read

Source:

```pmsl
fn read_config_async(path: Path)
    -> Result<Bytes, Λ_absent<Bytes> | Φ_trap<FileError>>
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, Φ, ∇, Σ)
    requires Ω(fs.read)
{
    let h = FS.open(path, OpenMode.read)?
    let fut = FS.read_async(h, 4096)?
    let data = IO.await(fut, timeout = 100ms)?
    FS.close(h)?
    return data
}
```

Operator reading:

```text
FS.open:
    Δ classify path/mode
    Ω check fs.read
    Χ check projected namespace visibility
    Ψ check FS policy
    ∇ open handle
    Σ commit handle state
    Λ path absent
    Φ IO trap

FS.read_async:
    Δ classify handle/request
    Ω check read authority
    ∇ submit IO request
    Σ commit pending IOFuture

IO.await:
    Θ wait for completion
    Λ timeout/not-ready
    Φ map IO failure
    Σ integrate Bytes

FS.close:
    ∇ close handle
    Σ commit resource closure
```

This example illustrates API-level operator preservation. It does not assert that this exact PMSL source already executes unchanged in a complete PMSL compiler/runtime.

### 12.30 Example: Request/Response Service

Source:

```pmsl
fn ask_service(req: RequestData)
    -> Result<ResponseData, Λ_absent<ResponseData> | Φ_trap<ServiceError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Λ, Φ, Σ, Α)
    requires Ω(service.request)
{
    Request.send(client, req, timeout = 500ms)
}
```

Operator reading:

```text
Α request/response pattern
Δ classify request and response type
Ω verify service.request capability
Χ verify projected service endpoint visibility
Ψ check service policy
∇ enqueue request
Σ commit request visibility
Θ wait for response
Λ no response before timeout
Φ service/protocol trap
Σ integrate response
```

This example is local to the declared PMSL/PMS-IR API profile. Distributed behavior requires the distributed profile defined in `07_distributed_systems.md`.

### 12.31 Example: Channel Select

Source:

```pmsl
select {
    msg = Channel.recv(inbox) => handle_msg(msg)
    tick = Time.timeout(1s)  => handle_tick()
}
```

Operator reading:

```text
Δ classify selectable arms
Ω check receive/timer authority
Χ check projected endpoint visibility
Ψ check select policy
Θ order readiness
Λ timeout/no-ready event
∇ execute selected handler
Σ integrate handler result
Φ trap on selected-arm failure
```

The example shows select as a typed coordination construct, not an opaque async runtime primitive.

### 12.32 Example: Invalid Durable Write Claim

Invalid source sketch:

```pmsl
fn write_config(path: Path, data: Bytes)
    -> Result<Σ_durable<Unit>, Φ_trap<FileError>>
{
    FS.write(path, data)
}
```

Invalidity condition:

```text
FS.write provides Σ_visible<Unit>
but caller claims Σ_durable<Unit>
without FS.sync, durable_write profile, or declared backend guarantee.
```

Invalid operator collapse:

```text
Σ_visible → Σ_durable
```

without a declared commit rule.

A conformant version must use an API whose commit profile supports the claim:

```pmsl
fn write_config(path: Path, data: Bytes)
    -> Result<Σ_durable<Unit>, Φ_trap<FileError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(fs.write), Ω(fs.sync)
{
    let h = FS.open(path, OpenMode.write)?
    FS.write(h, data)?
    FS.sync(h)?
    FS.close(h)?
    return Σ_durable<Unit>
}
```

The durable result remains profile-bound. It is not a proof of external storage correctness outside the declared backend/runtime assumptions.

### 12.33 API Invariants

PMSL maintains the following concurrency and IO API invariants.

```text
I1: every API has a type signature
I2: every API has an effect profile
I3: protected APIs declare Ω requirements
I4: boundary-sensitive APIs declare Χ-projected behavior
I5: policy-sensitive APIs declare Ψ behavior
I6: async APIs distinguish submission Σ from completion Σ
I7: absence-capable APIs declare Λ outcomes
I8: trap-capable APIs declare Φ outcomes
I9: commit-capable APIs declare Σ profiles
I10: blocking and waiting APIs declare Θ/Λ behavior
I11: task APIs preserve TaskFrame lifecycle
I12: channel APIs preserve ChannelFrame delivery and receive semantics
I13: filesystem APIs distinguish visible, staged, and durable commit
I14: network APIs distinguish delivery, timeout, and protocol failure
I15: handle APIs preserve ownership, lifetime, and close behavior
I16: cancellation is Φ/Ψ/Σ lifecycle behavior, not Λ absence
I17: runtime profile support is explicit
I18: PMS-IR preserves all API obligations
I19: unsupported APIs fail through typed Λ/Φ/Ψ outcomes
I20: no API fast path bypasses Ω, Χ projection, Ψ, Λ, Φ, or Σ obligations
I21: traces record observed API executions under declared profiles; they do not validate PMS Base
I22: AI-proposed API artifacts remain non-authoritative until host-validated under a declared tooling/profile gate
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL concurrency library, IO library, scheduler, async runtime, backend adapter, verifier, or PMS-OS syscall surface already enforces every invariant.

### 12.34 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for concurrency/IO-API-adjacent slices when those slices are represented through its supported runtime/profile surface.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR API-adjacent behavior, such as validator acceptance/rejection, deterministic runtime stepping, vFS-like service calls, JSONL trace emission, golden fixture comparison, and AI proposal gating.

It does not complete:

```text
PMSL concurrency API implementation
PMSL IO API implementation
PMSL async runtime
PMSL scheduler
PMSL channel implementation
PMSL filesystem backend
PMSL network backend
PMSL host-service bridge
PMSL compiler
PMS-IR optimizer
PMS-CPU
PMS-OS syscall surface
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL concurrency/IO API implementation and does not validate PMS Base.

### 12.35 AI API Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

The AI Bridge may propose:

```text
PMS-IR fragments
opcode programs
API call sketches
missing-obligation hypotheses
candidate diagnostics
trace-analysis summaries
simulation scenarios
test fixtures
```

It may not function as:

```text
PMSL semantics
API authority
runtime authority
scheduler authority
type-checker authority
compiler authority
verifier authority
policy authority
trusted executable code
PMS Base evidence
```

The governing pipeline is:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI-assisted API suggestions are not authoritative API definitions, runtime results, scheduler decisions, verification evidence, policy decisions, or execution authority until host-validated under a declared tooling/profile gate.

AI output is not PMSL source authority.

AI output is not PMS-IR truth.

AI output is not verification evidence.

AI output is not trusted executable code.

AI output is not PMS Base validation.

### 12.36 Boundary to PMS-IR

This section defines concrete PMSL concurrency and IO APIs.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| PMS-IR node structure | Section 13 |
| static analysis and linting over API calls | Section 14 |
| model checking of concurrency/IO properties | Section 15 |
| debugging and observability for API calls | Section 16 |
| simulation of API behavior | Section 17 |
| example PMSL fragments | Section 18 |
| runtime-security enforcement | `06_runtime_security.md` |
| distributed networking and cross-node semantics | `07_distributed_systems.md` |
| PMS-RUST executable artifact relation | `08_relation_to_pms_rust.md` |

The next section defines how these APIs are represented in PMS-IR.

### 12.37 Architectural Consequence

The consequence of the PMSL concurrency and IO API layer is:

```text
PMSL exposes concrete APIs for tasks, task groups, supervisors, channels,
select, request/response, events, timers, files, networks, streams,
synchronization, atomics, backpressure, cancellation, async IO, handles,
and transactions without turning them into opaque runtime calls. Each API
remains an operator-typed program surface whose authority, boundary
projection, policy, ordering, absence, trap, commit, and runtime-profile
obligations are preserved in PMS-IR.
```

This gives PMSL a practical systems-programming API surface while preserving PMS-STACK’s implementation-layer architecture discipline.

### 12.38 Concurrency and IO API Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL concurrency and IO API model specifies architecture-level API
profiles for tasks, task groups, supervisors, channels, select,
request/response, events, timers, filesystem IO, async filesystem IO,
network IO, streams, synchronization, atomics, backpressure,
cancellation, async/await, IO handles, IO transactions, memory
consistency, runtime-profile declarations, PMS-IR API lowering, static
checks, runtime obligations, traces, PMS-RUST evidence boundaries, and AI
proposal boundaries.

This is a language concurrency / IO API architecture claim.

It does not claim a completed PMSL concurrency library, completed IO
library, completed async runtime, completed scheduler, completed channel
implementation, completed filesystem backend, completed network backend,
completed host adapter, completed PMS-OS syscall surface, completed
distributed runtime, completed verifier, completed PMSL implementation,
or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, program buffering, model validation, stateful runtime
validation, deterministic execution, JSONL traces, REPL/script tooling,
vFS service boundaries, golden fixtures, and AI proposal gating. It does
not complete PMSL/PMS-IR concurrency and IO APIs and does not validate
PMS Base.
```

---

## 13. PMS-IR

PMS-IR is the operator-preserving intermediate representation of PMSL and PMS-STACK executable artifacts.

It is the canonical form in which PMSL source, standard-library calls, runtime operations, policy checks, FFI boundaries, concurrency constructs, module linkage, error paths, commits, traces, validation artifacts, simulation artifacts, verification inputs, and backend targets remain analyzable as Δ–Ψ structure.

The central PMS-IR claim is:

```text
PMS-IR is valid when every executable or analyzable artifact preserves
operator identity, dependency constraints, frame context, role/capability
state, boundary projections, policy obligations, absence paths, trap
paths, commit semantics, source mapping, validation status, trace mapping,
and backend-lowering obligations.
```

PMS-IR is not merely bytecode.

It is also not a free-form JSON trace, not a compiler-private AST, not a log format, not a proof object by itself, and not PMS Base validation.

It is an operator-tagged representation layer shared by compilers, runtimes, analyzers, validators, simulators, debuggers, verification tools, and executable evidence-spine artifacts.

This section defines PMS-IR at specification level. It does not claim that a complete PMSL compiler, complete PMS-IR optimizer, complete PMS-IR verifier, complete PMSL runtime, or complete executable backend already exists.

PMS-RUST v0.1 provides bounded executable evidence for a narrower layer: opcode construction, program buffering, model validation, stateful runtime validation, deterministic kernel execution, JSONL trace/audit output, vFS service events, REPL/script tooling, golden fixtures, and AI proposal gating.

That strengthens the PMS-STACK implementation-artifact claim; it does not validate PMS Base.

Claim type:

```text
LANGUAGE IR / OPERATOR-REPRESENTATION ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMS-IR as the operator-preserving representation
layer for PMSL/PMS-STACK executable and analyzable artifacts.

It does not claim a completed PMSL compiler, completed PMS-IR optimizer,
completed PMS-IR verifier, completed runtime backend, completed PMS-OS
backend, completed distributed runtime, completed proof system, completed
PMSL implementation, or PMS Base validation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared PMS-IR schema, operator-dependency model, type/effect rule, stateful validation rule, runtime profile, backend profile, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, theoretical adequacy, runtime correctness, backend correctness, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR level, Χ is projected as boundary, isolation, visibility, reachability control, access separation, host/runtime boundary, sandbox boundary, module boundary, task boundary, memory-domain separation, and cross-frame transfer discipline.

PMS-IR does not redefine Χ.

### 13.1 Role of PMS-IR

PMS-IR has five architectural roles.

```text
compiler representation
runtime representation
analysis representation
verification representation
trace/debug bridge
```

As compiler representation, PMS-IR receives PMSL lowering.

```text
PMSL source
→ typed AST
→ operator-typed AST
→ PMS-IR
```

As runtime representation, PMS-IR provides executable operator programs.

```text
PMS-IR
→ runtime validation
→ deterministic or profile-specific execution
→ trace/audit output
```

As analysis representation, PMS-IR exposes structural obligations.

```text
operator dependency
frame validity
role/capability validity
boundary validity
policy validity
absence/trap coverage
commit closure
```

As verification representation, PMS-IR gives model checking, validation, and proof-oriented tools a stable object.

```text
IR graph
→ dependency checks
→ effect checks
→ stateful checks
→ trace conformance checks
→ model/property checks
```

As trace/debug bridge, PMS-IR preserves source spans and operator classes.

```text
source span
→ IR node
→ runtime event
→ trace/debug view
```

The key claim is:

```text
PMS-IR makes PMSL executable without making PMSL opaque.
```

This is an implementation-layer representation claim. It is not PMS Base validation.

### 13.2 Representation Layers

PMS-IR is not one single physical format. It is a representation family with several compatible layers.

```text
High-Level PMS-IR
  → source-near, typed, structured, module-aware

Core PMS-IR
  → normalized operator-tagged instruction/control representation

Executable PMS-IR
  → opcode-like program suitable for runtime/kernel execution

Trace-Mapping PMS-IR
  → observed execution events mapped back to IR/source

Serialized PMS-IR
  → JSON, binary, or other exchange format for tools
```

Layer relation:

```text
PMSL source
  → High-Level PMS-IR
  → Core PMS-IR
  → Executable PMS-IR
  → runtime/backend execution
  → trace/debug/observation artifacts
```

Each layer may remove syntactic sugar.

No layer may erase operator obligations.

`Trace-Mapping PMS-IR` means an IR-to-observation mapping view. It is not the mathematical `Trace(...)` set convention used across PMS-STACK.

### 13.3 High-Level PMS-IR

High-Level PMS-IR is source-near.

It preserves:

```text
modules
functions
blocks
bindings
types
effects
policies
roles
capabilities
channels
tasks
traps
commit blocks
FFI declarations
standard-library calls
source spans
```

Example:

```pmsl
policy with P_write {
    commit Σ {
        FS.write(path, data)
    }
}
```

High-Level PMS-IR outline:

```text
IR.PolicyScope {
    op: Ψ,
    policy: P_write,
    source_span,
    body: IR.Commit {
        op: Σ,
        source_span,
        body: IR.StdCall {
            op: ∇,
            domain: FS,
            function: write,
            args: [path, data],
            effects: [Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ],
            source_span
        }
    }
}
```

High-Level PMS-IR is useful for:

```text
source diagnostics
effect inference
policy checking
module checking
type checking
linting
debugging
source-to-trace mapping
```

High-Level PMS-IR is still an IR layer, not PMSL source itself.

### 13.4 Core PMS-IR

Core PMS-IR normalizes source constructs into operator-tagged nodes.

Core node form:

```text
IRNode = (
    id,
    op,
    kind,
    operands,
    result,
    type_profile,
    effect_profile,
    frame_profile,
    role_profile,
    capability_profile,
    boundary_profile,
    policy_profile,
    absence_profile,
    trap_profile,
    commit_profile,
    children,
    control_edges,
    data_edges,
    source_span,
    meta
)
```

Where:

| Field | Meaning |
| ----- | ------- |
| `id` | stable node identifier |
| `op` | primary Δ–Ψ operator tag |
| `kind` | construct or instruction kind |
| `operands` | input values, symbols, handles, frames |
| `result` | output value or state |
| `type_profile` | value/type information |
| `effect_profile` | operator effects produced |
| `frame_profile` | active or required frame |
| `role_profile` | active role or required role |
| `capability_profile` | Ω requirements |
| `boundary_profile` | PMSL/PMS-IR boundary projection of Χ |
| `policy_profile` | Ψ requirements/decisions |
| `absence_profile` | Λ outcomes |
| `trap_profile` | Φ outcomes |
| `commit_profile` | Σ state |
| `children` | nested IR nodes |
| `control_edges` | Θ/Φ/Λ/branch edges |
| `data_edges` | value dependencies |
| `source_span` | source mapping |
| `meta` | tool/runtime metadata |

A simple normalized sequence:

```text
IR.Resolve(op=Δ, symbol=FS.write)
IR.Require(op=Ω, capability=fs.write)
IR.BoundaryCheck(op=Χ, namespace=active)
IR.PolicyCheck(op=Ψ, policy=P_write)
IR.Call(op=∇, target=FS.write)
IR.Commit(op=Σ, commit_profile=Σ_visible<Unit>)
IR.TrapPath(op=Φ, trap=FileError)
IR.AbsencePath(op=Λ, absence=NoSpace | MissingTarget)
```

This structure allows tools to inspect the operation before execution.

### 13.5 Executable PMS-IR

Executable PMS-IR is the lower form used by runtimes, interpreters, kernels, or evidence-spine artifacts.

A minimal executable instruction has the form:

```text
Instruction = (
    op: Operator,
    params: OperatorParams,
    meta?: NodeMeta
)
```

PMS-RUST v0.1 demonstrates a concrete bounded version of this form:

```text
OpCode {
    op: Operator,
    params: OpParams
}
```

with operator variants corresponding to:

```text
Delta
Nabla
Frame
Lambda
Attractor
Omega
Theta
Phi
Chi
Sigma
Psi
```

and parameter families such as:

```text
NewEntity
Advance
NewFrame
Asymmetry
Impulse
Integrate
Expectation
Attractor
Reframe
IsolationEnter
IsolationExit
Commit
```

This executable form is intentionally narrower than full PMS-IR.

It is useful because it shows:

```text
operator-tagged programs can be built
operator-tagged programs can be validated
operator-tagged programs can be executed deterministically
operator-tagged events can be emitted
operator-tagged traces can be inspected
```

Boundary:

```text
Executable opcode form is an implementation profile of PMS-IR.
It is not the whole PMSL language and not the whole PMS-IR specification.
```

PMS-RUST `IsolationExit` / `chi_exit`-style behavior is an artifact/runtime boundary-exit command under a bounded runtime profile.

It is not PMS Base Χ.

The exit rule is:

```text
exit requires an active boundary/isolation context;
unbalanced exit is invalid.
```

A sealed isolation context may forbid further entry, expansion, or authority growth while still permitting valid exit and closure under the declared profile.

### 13.6 Operator Tagging

Every PMS-IR node must have an operator tag.

```text
op ∈ { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

Operator tag roles:

| Operator | PMS-IR role |
| -------- | ----------- |
| Δ | distinguish, resolve, classify, decode, branch |
| ∇ | execute, mutate, perform effect, call |
| □ | frame, scope, module, task, handler, foreign context |
| Λ | absence, timeout, no-event, not-ready |
| Α | pattern, macro, reusable expansion |
| Ω | role, capability, authority |
| Θ | sequence, schedule, wait, order |
| Φ | trap, recontextualization, exception, migration |
| Χ | Distance projected as boundary, isolation, visibility, reachability |
| Σ | commit, integrate, return, close lifecycle |
| Ψ | policy, invariant, guard, seal, self-binding |

Operator tags are not comments.

```text
operator tag
⇒ dependency obligations
⇒ validation obligations
⇒ runtime obligations
⇒ analysis obligations
```

A transformation may rewrite an IR graph. It may not remove or falsify operator identity.

### 13.7 Χ Boundary Note

PMS Base uses Χ as Distance.

PMS-IR at implementation layer uses Χ as a projection:

```text
PMS Base Χ
  → Distance

PMS-STACK / PMSL / PMS-IR Χ projection
  → boundary
  → isolation
  → visibility
  → reachability control
  → access separation
  → host/runtime boundary
```

Executable artifacts may use a runtime dialect.

Example PMS-RUST v0.1 dialect:

```text
Chi = isolation / boundary enter-exit discipline
```

This is valid as a runtime projection when bounded explicitly.

It must not be silently treated as a redefinition of PMS Base Χ.

Therefore:

```text
IR.BoundaryCheck(op=Χ, ...)
IR.IsolationEnter(op=Χ, ...)
IR.IsolationExit(op=Χ, ...)
```

mean PMSL/PMS-IR layer-projected boundary behavior, not a new base operator.

### 13.8 PMS-IR Program

A PMS-IR program is a structured operator graph or sequence.

Sequential form:

```text
IRProgram = [ IRNode_0, IRNode_1, ..., IRNode_n ]
```

Graph form:

```text
IRProgram = (
    nodes,
    control_edges,
    data_edges,
    module_graph,
    frame_graph,
    policy_graph,
    capability_graph,
    boundary_graph,
    meta
)
```

Executable opcode form:

```text
Program = Vec<OpCode>
```

All forms must preserve:

```text
operator order
operator dependencies
frame context
role/capability context
policy context
boundary context
commit state
absence/trap paths
source mapping
```

The graph form is preferred for analysis.

The sequence form is preferred for deterministic execution profiles.

Both are PMS-IR profiles, not proof artifacts by themselves.

### 13.9 Instruction Format

A PMS-IR instruction has a primary operator and structured parameters.

Generic format:

```text
IRInstruction {
    id: NodeId,
    op: Operator,
    opcode: InstructionKind,
    operands: OperandList,
    result: ResultSlot?,
    effects: EffectSet,
    context: ContextRef,
    source_span: SourceSpan?,
    meta: Meta
}
```

Executable minimal form:

```text
OpCode {
    op: Operator,
    params: OpParams
}
```

Examples:

```text
Δ.NewEntity { name }
□.NewFrame { kind }
Ω.Asymmetry { from, to, weight, desc }
∇.Impulse { entity, intensity, desc }
Σ.Integrate { note }
Λ.Expectation { horizon, desc }
Α.Attractor { label }
Φ.Reframe { from, to }
Χ.IsolationEnter { label }
Χ.IsolationExit
Ψ.Commit { note }
```

Specification-level PMS-IR may define many more instruction kinds.

Examples:

```text
Δ.ResolveSymbol
Δ.Match
∇.StdCall
∇.Assign
□.EnterFunction
□.EnterModule
Λ.Timeout
Α.ExpandPattern
Ω.RequireCapability
Θ.Schedule
Φ.Raise
Χ.BoundaryCheck
Σ.CommitBlock
Ψ.PolicyCheck
```

The bounded executable artifact may start small.

The specification remains broader.

`Χ.IsolationExit` is valid only when an active boundary/isolation context exists. An unbalanced exit is invalid under the stateful validation profile.

### 13.10 Context Records

PMS-IR nodes refer to contexts.

```text
Context = (
    frame,
    module,
    task,
    role,
    capabilities,
    boundary,
    policy,
    commit_scope,
    handler_scope,
    source_scope
)
```

Context references allow a node to answer:

```text
inside which frame?
inside which module?
under which task?
under which role?
with which capabilities?
under which policy?
across which boundary?
inside which commit scope?
with which handler scope?
from which source span?
```

This is essential for static analysis and runtime validation.

The `boundary` field records a PMSL/PMS-IR boundary projection. It does not redefine PMS Base Χ.

### 13.11 Control Flow Graph

PMS-IR may include a control-flow graph.

```text
CFG = (
    blocks,
    edges,
    entry,
    exits,
    trap_edges,
    absence_edges,
    commit_edges
)
```

Control edge types:

```text
normal
branch
loop
call
return
trap
absence
policy_denial
commit_success
commit_failure
cancel
timeout
```

Operator mapping:

```text
normal order        → Θ
branch/match        → Δ / Θ
loop                → Α / Θ
trap edge           → Φ
absence edge        → Λ
policy denial edge  → Ψ / Φ
commit edge         → Σ
boundary edge       → Χ projection
```

Example:

```text
IR.Block(entry)
 ├─ normal → IR.Call(FS.write)
 ├─ trap   → IR.Handler(FileError)
 ├─ absence → IR.Absence(NoSpace)
 └─ commit_success → IR.Return(Unit)
```

CFG structure lets PMSL error, concurrency, and commit behavior remain explicit.

### 13.12 Data Flow and SSA

PMS-IR may use SSA or SSA-like value representation.

SSA is useful for:

```text
value identity
effect dependencies
branch merge
commit visibility
policy guard propagation
absence/trap merge
optimization
verification
```

Example:

```text
v1 = Δ.Resolve(path)
v2 = Ω.Require(fs.write, v1)
v3 = Ψ.Check(P_write, v2)
v4 = ∇.Call(FS.write, v1, data)
v5 = Σ.Commit(v4)
```

Φ nodes in classical SSA must be distinguished from PMS operator Φ.

Recommended terminology:

```text
SSA merge node = Merge
PMS Φ operator = Recontextualization / Trap / Reframe
```

Do not overload Φ for SSA merge in PMS-IR notation.

A merge node may still be operator-typed:

```text
IR.Merge(op=Σ or Δ, inputs=[...])
```

depending on whether it integrates values or distinguishes branch outcomes.

### 13.13 Effect Representation

Every PMS-IR node carries effect information.

```text
EffectSet = Set<OperatorEffect>
```

Example:

```text
effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
```

Effect profile fields:

```text
primary_op
secondary_ops
required_ops
produced_ops
may_trap
may_absent
may_commit
may_cross_boundary
requires_policy
requires_capability
```

Example:

```text
IR.StdCall(FS.write)
effects:
    primary: ∇
    secondary: [Δ, Ω, Χ, Ψ, Σ, Φ, Λ]
```

Effect checking rule:

```text
node.effects ⊆ enclosing_function.declared_effects
```

and:

```text
node.effects permitted by active frame, role, policy, boundary, and runtime profile
```

`Effect<Χ>` denotes PMSL/PMS-IR layer-projected boundary, isolation, visibility, reachability, host-boundary, or runtime-boundary behavior.

### 13.14 Dependency Validation

PMS-IR validation includes operator dependency checking.

Validation asks:

```text
is this operator occurrence structurally admissible here?
```

Examples:

```text
∇ requires prior or dominating Δ
Ω requires protected operation or authority context
Σ requires committable effect or state
Λ requires expected event/value or temporal condition
Φ requires trap/recontextualization context
Χ requires boundary relation
Ψ requires policy/invariant context
□ requires valid frame transition
Α requires valid expansion
```

A minimal adjacency validator checks immediate predecessor constraints.

```text
op_i → op_{i+1}
```

A stronger validator checks graph ancestry and stateful constraints.

```text
dominators
active frame stack
active isolation stack
sealed states
capability scope
policy scope
commit scope
handler scope
```

PMS-RUST v0.1 demonstrates both a model-adjacency validation layer and a stateful validation layer in bounded runtime form.

Validation here means acceptance/rejection under a declared model/profile. It is not proof and not PMS Base validation.

### 13.15 Stateful Validation

Stateful validation checks program validity without executing side effects.

It tracks shadow state such as:

```text
active frame?
frame sealed?
active isolation stack?
current isolation sealed?
available capabilities?
active policies?
pending commits?
handler availability?
```

Example stateful rules:

```text
Ω requires active frame
Α requires active frame
Σ requires active frame
Ω forbidden after current frame is Ψ-sealed
Α forbidden after current frame is Ψ-sealed
Χ enter forbidden after current isolation is Ψ-sealed
Χ exit requires active isolation
```

These rules are runtime-profile-specific where needed.

Boundary:

```text
Stateful validation strengthens executable artifact discipline.
It does not define PMS Base by itself.
```

Sealed isolation means:

```text
no further entry, expansion, or authority growth inside that sealed
boundary context unless explicitly permitted by the profile.
```

It does not mean:

```text
valid exit and closure are forbidden.
```

Valid exit remains permitted when an active boundary context exists and the profile allows closure.

### 13.16 Policy and Capability Validation

PMS-IR makes Ω and Ψ checkable.

Capability validation:

```text
IR.RequireCapability {
    op: Ω,
    capability,
    target,
    source_span
}
```

Policy validation:

```text
IR.PolicyCheck {
    op: Ψ,
    policy,
    action,
    context,
    decision_path,
    source_span
}
```

Validation checks:

```text
capability exists
capability scope covers target
role can hold capability
policy permits capability use
policy is active in frame
policy does not weaken enclosing policy
denial path is represented
```

Capability and policy checks may be static, runtime, or mixed.

Policy validation is program/runtime constraint checking. It is not moral judgment, forensic attribution, governance tribunal behavior, or PMS Base validation.

### 13.17 Boundary Validation

PMS-IR must make Χ projection visible.

Boundary node:

```text
IR.BoundaryCheck {
    op: Χ,
    source_boundary,
    target_boundary,
    relation,
    transfer_profile,
    policy,
    source_span
}
```

Boundary cases:

```text
module import
module call
task communication
channel send/recv
shared frame access
FFI call
host service call
distributed call
AI/tooling service call
```

Validation asks:

```text
can source reach target?
can value cross?
is transfer profile defined?
is policy satisfied?
is commit state defined?
```

Failure maps to:

```text
Χ projection / Ψ / Φ
```

or a declared typed result.

PMS-IR boundary validation checks the implementation-layer projection of PMS Base Χ = Distance. It does not redefine PMS Base Χ.

### 13.18 Absence and Trap Representation

PMS-IR keeps Λ and Φ distinct.

Absence path:

```text
IR.AbsencePath {
    op: Λ,
    expected,
    absence_kind,
    timeout?,
    continuation,
    handler?,
    source_span
}
```

Trap path:

```text
IR.TrapPath {
    op: Φ,
    trap_type,
    cause,
    payload_type,
    handler?,
    propagation?,
    source_span
}
```

Examples:

```text
Channel.recv timeout → Λ_absent<Message>
FS.read IO failure   → Φ_trap<FileError>
Policy violation     → Ψ denial or Φ_trap<PolicyViolation>
Commit failure       → Σ / Φ
```

Validation rule:

```text
every Λ path is handled, propagated, or declared
every Φ path is handled, propagated, or declared
```

PMS-IR must not collapse expected non-events into generic exceptions or generic failures.

### 13.19 Commit Representation

Commit is explicit in PMS-IR.

Commit node:

```text
IR.Commit {
    op: Σ,
    commit_kind,
    subject,
    staged_effects,
    visibility,
    durability,
    rollback?,
    compensation?,
    policy,
    source_span
}
```

Commit kinds:

```text
local_bind
function_return
channel_delivery
task_creation
task_completion
module_link
module_init
foreign_result
filesystem_visible
filesystem_durable
trace_record
transaction
policy_install
```

PMS-IR must distinguish:

```text
executed
staged
visible
committed
durable
rolled_back
compensated
failed
```

This prevents false equivalence between effect execution and integration.

A backend may not emit a stronger commit claim than the declared runtime/backend profile supports.

### 13.20 Serialization

PMS-IR may be serialized for tooling.

Formats may include:

```text
JSON
JSONL
binary encoding
canonical text
debug graph
trace event stream
```

Serialized PMS-IR must preserve:

```text
operator tag
instruction kind
parameters
source span
effect profile
context references
absence/trap/commit paths
policy/capability/boundary metadata
```

Example JSON-like form:

```json
{
  "id": "n42",
  "op": "Sigma",
  "kind": "Commit",
  "commit_profile": "Σ_visible<Unit>",
  "children": ["n41"],
  "source_span": {
    "file": "app.pmsl",
    "line": 12,
    "column": 5
  }
}
```

Executable traces may use stable event lines.

Example:

```text
tick=4 op=Sigma msg="integrate frame_id=0 note=written consumed=[1,2]"
```

Trace format is not identical with PMS-IR, but it should be mappable back to PMS-IR where source and node metadata exist.

Serialization validates representation shape only under a declared schema/profile. It is not semantic proof and not PMS Base validation.

### 13.21 PMS-IR and Traces

PMS-IR and runtime traces are related but distinct.

```text
PMS-IR
  = intended / compiled / validated program structure

trace
  = observed runtime event sequence for one concrete run
```

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL/PMS-IR run:

```text
trace_pmsl(runtime, ir_artifact, input_profile) ∈ L_PMS
```

For the set of possible runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, ir_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, ir_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, ir_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

Relation:

```text
IR node
→ runtime event(s)
→ trace record
→ debugging / replay / validation
```

Trace conformance checks:

```text
did runtime event order respect IR ordering?
did operator classes match?
did policy checks occur?
did commits happen where expected?
did traps and absences match declared paths?
did boundary checks occur before crossings?
```

Trace conformance checks whether an observed trace conforms to a declared IR/profile/property expectation.

It does not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

A trace may strengthen implementation-artifact claims. It does not validate PMS Base.

### 13.22 PMS-IR Transformations

PMS-IR may be transformed.

Transformation classes:

```text
normalization
desugaring
macro expansion
effect inference
dead-code elimination
inlining
frame lowering
policy specialization
capability specialization
backend lowering
trace instrumentation
serialization
optimization
```

Transformation rule:

```text
IR transformation is valid iff it preserves operator obligations.
```

Preservation requirements:

```text
operator tag preservation
dependency preservation
effect preservation or safe refinement
absence/trap preservation
commit preservation
policy preservation
boundary preservation
source mapping preservation where diagnostics require it
```

Invalid transformation examples:

```text
remove Ω check before protected call
erase Λ timeout path
turn policy denial into success
merge staged and committed state
inline across Χ boundary without bridge
erase Φ handler edge
treat host call as pure PMSL call
treat AI proposal as accepted PMS-IR without validation
```

A transformation may optimize. It may not launder semantics.

### 13.23 Lowering to Runtime and Backends

PMS-IR may lower to several targets.

```text
PMS-UM
PMS-CPU
PMS-OS syscall layer
PMSL runtime
host runtime
PMS-RUST-style opcode kernel
simulator
emulator
trace validator
distributed runtime
```

Lowering relation:

```text
PMS-IR node
→ backend instruction / runtime call / opcode / trace specification
```

Examples:

| PMS-IR construct | Backend lowering |
| ---------------- | ---------------- |
| `Δ.Resolve` | symbol lookup / decode / compare |
| `∇.StdCall` | runtime call / syscall / host call |
| `□.EnterFrame` | frame push / call frame / module frame |
| `Λ.Timeout` | wait object / timer / non-event |
| `Ω.RequireCapability` | capability check |
| `Θ.Schedule` | scheduler operation / ordering tick |
| `Φ.Trap` | handler entry / exception / reframe |
| `Χ.BoundaryCheck` | namespace/sandbox/process/host check |
| `Σ.Commit` | transaction/return/delivery/trace commit |
| `Ψ.PolicyCheck` | runtime guard / policy evaluator |

Backend rule:

```text
backend may choose implementation strategy;
it may not erase operator identity or obligations.
```

Unsupported lowering must be typed:

```text
Λ unsupported
Φ backend trap
Ψ policy denial
```

Backend lowering is a profile-bound implementation claim. It is not backend equivalence and not PMS Base validation.

### 13.24 Relation to PmsBuilder and Opcode Buffers

PMS-RUST `pms-ir` provides a bounded IR convenience layer.

Its role:

```text
PmsBuilder
→ builds small opcode programs
→ maintains an opcode buffer
→ allows read-only buffer inspection
→ drains buffer transactionally on run
```

This is best interpreted as:

```text
PmsBuilder = executable PMS-IR construction surface for a bounded runtime profile
```

not:

```text
PmsBuilder = complete PMSL compiler
PmsBuilder = complete PMS-IR specification
PmsBuilder = PMS Base formalization
```

The builder pattern is useful because it makes a program buffer explicit.

```text
builder calls
→ OpCode buffer
→ validation
→ deterministic kernel execution
→ trace output
```

This supports the implementation-artifact claim:

```text
operator programs can be constructed, inspected, validated, executed,
and traced in a bounded executable spine.
```

It does not complete PMSL/PMS-IR and does not validate PMS Base.

### 13.25 AI Proposal Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

An AI bridge may be treated as an optional PMS-IR producer.

It may propose:

```text
operator-tagged opcode sequences
scenario compilations
trace-analysis comments
candidate explanations
candidate PMS-IR fragments
missing-obligation hypotheses
candidate diagnostics
simulation scenarios
```

It may not:

```text
execute
validate
authorize
define PMSL semantics
define PMS-IR truth
replace policy evaluation
replace static analysis
replace model checking
serve as verification evidence
serve as PMS Base evidence
```

Required pipeline:

```text
AI text
→ JSON envelope parse
→ task/result-shape check
→ opcode whitelist
→ canonicalization
→ PMS-IR / builder mapping
→ model validation
→ stateful validation
→ policy/runtime acceptance
→ kernel/runtime execution only after acceptance
```

Authority boundary:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output is therefore:

```text
proposal artifact
```

not:

```text
trusted executable code
compiler authority
verifier
policy engine
verification evidence
PMS Base validation
```

This belongs in PMS-IR because AI may produce candidate IR/opcode fragments.

It remains optional tooling, not a PMSL construct and not PMSL semantics.

### 13.26 PMS-IR Validation Pipeline

A complete PMS-IR validation pipeline may include:

```text
parse / deserialize
schema validation
operator tag validation
dependency validation
type validation
effect validation
frame validation
role/capability validation
boundary validation
policy validation
absence/trap coverage
commit validation
backend-support validation
runtime-profile validation
serialization/trace compatibility
```

Pipeline form:

```text
PMS-IR
→ structural validation
→ model/dependency validation
→ stateful validation
→ type/effect validation
→ policy/capability/boundary validation
→ backend admissibility check
→ accepted executable artifact
```

Validation failure is typed:

```text
Δ invalid node / unknown symbol
Ω missing capability
Χ invalid boundary projection
Ψ policy/dependency denial
Λ unsupported or absent feature
Φ trap/error path
Σ invalid commit profile
```

Validation strengthens the toolchain.

It does not prove PMS Base.

It does not by itself prove semantic completeness, implementation correctness, runtime correctness, or full behavioral coverage.

### 13.27 PMS-IR and Model Checking

PMS-IR is the substrate for model checking.

Checkable properties:

```text
operator dependency safety
frame reachability
capability safety
policy non-weakening
boundary non-bypass
absence coverage
trap coverage
commit closure
task lifecycle closure
channel protocol validity
module linkage validity
FFI boundary safety
trace conformance
```

Model-checking object:

```text
IR graph + transition relation + property set
```

Example property:

```text
No path reaches FS.write without Ω(fs.write) and Ψ filesystem policy check.
```

Example property:

```text
Every Channel.recv timeout path reaches either Λ return, handler, or declared propagation.
```

Example property:

```text
No Σ_durable claim is emitted by a backend that provides only Σ_visible.
```

Model checking supports implementation-layer confidence. It does not validate PMS Base.

A model-checking result proves or refutes the stated property only under the declared model, abstraction, transition relation, and assumptions.

### 13.28 PMS-IR and Source Mapping

Every PMS-IR node should preserve source mapping where possible.

```text
SourceSpan = (
    file,
    module,
    line,
    column,
    length,
    macro_origin?,
    expansion_origin?
)
```

Source mapping supports:

```text
diagnostics
debugging
trace-to-source mapping
linting
coverage
audit review
model-checker counterexamples
AI-assisted advisory explanations
```

Macro expansion must preserve origin chains.

```text
PMSL source
→ macro/pattern expansion
→ IR nodes
→ source span + expansion span
```

This prevents Α patterns from hiding responsibility.

Source mapping is a tooling and accountability feature. It is not proof and not PMS Base validation.

### 13.29 PMS-IR Metadata

PMS-IR metadata may include:

```text
stable ids
debug labels
profile requirements
version information
tool annotations
trace ids
audit tags
test fixture ids
validation status
backend support notes
```

Metadata rule:

```text
metadata may support tooling;
metadata may not override operator semantics.
```

Example:

```text
meta.ai_suggested = true
```

does not make a node executable.

Example:

```text
meta.validated_by = "stateful_v2"
```

records validation status but does not prove PMS Base.

Metadata may strengthen traceability and tool discipline. It may not become semantic authority.

### 13.30 Golden Fixtures and Regression Evidence

PMS-IR artifacts may be used in golden fixtures.

A golden fixture may contain:

```text
input PMS-IR
expected validation result
expected runtime trace
expected diagnostic
expected rejection reason
expected commit/absence/trap outcome
```

Fixture use:

```text
PMS-IR artifact
→ validator/runtime
→ observed result
→ compare with expected fixture
```

Golden fixtures stabilize regression expectations.

They do not prove PMS Base, semantic completeness, or full behavioral coverage.

A golden fixture is evidence for a bounded artifact behavior under a declared profile.

It is not an external validation of PMS Base.

### 13.31 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for PMS-IR-adjacent behavior.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMS-IR behavior, such as:

```text
operator program construction
program-buffer inspection
profile-local validation
stateful validation
deterministic execution
trace emission
golden fixture comparison
proposal gating
```

It does not complete:

```text
PMSL compiler
PMS-IR specification
PMS-IR optimizer
PMS-IR verifier
PMSL runtime
PMS-CPU
PMS-OS
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL/PMS-IR implementation and does not validate PMS Base.

### 13.32 PMS-IR Invariants

PMS-IR maintains the following invariants.

```text
I1: every IR node has an operator tag
I2: every operator tag imposes validation obligations
I3: every effectful node exposes its effect profile
I4: every protected node exposes Ω capability requirements
I5: every policy-governed node exposes Ψ requirements
I6: every boundary-crossing node exposes Χ-projected behavior
I7: every frame-dependent node exposes □ context
I8: every absence-capable node exposes Λ paths
I9: every trap-capable node exposes Φ paths
I10: every commit-capable node exposes Σ behavior
I11: every pattern expansion preserves Α origin and expanded operator validity
I12: every module, task, channel, FFI, standard-library, and runtime API call has a known IR profile
I13: transformations preserve operator obligations
I14: serialization preserves operator tag and required metadata
I15: runtime traces remain mappable to IR where trace/profile metadata is present
I16: backend lowering preserves operator identity or rejects unsupported constructs
I17: validation failure remains operator-typed
I18: AI-generated artifacts remain proposals until parsed, canonicalized, mapped, validated, and accepted
I19: executable opcode profiles are bounded implementation profiles of PMS-IR, not the full PMSL/PMS-IR specification
I20: PMS-IR artifact evidence strengthens implementation-layer claims and does not function as PMS Base validation
I21: trace conformance records observed execution under declared profiles; it does not prove all possible behavior without a stated model, coverage argument, or proof artifact
I22: PMS-RUST chi_exit / IsolationExit-style commands are artifact/runtime boundary-exit commands and require active boundary context
```

These invariants are specification-level PMSL/PMS-IR conformance constraints.

They do not claim that a completed PMSL compiler, PMS-IR verifier, optimizer, runtime, backend, or proof system already enforces every invariant.

### 13.33 Boundary to Static Analysis and Verification

This section defines PMS-IR.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| static analysis and linting passes | Section 14 |
| model checking and verification methods | Section 15 |
| debugging and observability | Section 16 |
| simulation and emulation | Section 17 |
| example PMSL fragments | Section 18 |
| runtime security enforcement | `06_runtime_security.md` |
| PMS-RUST evidence mapping | `08_relation_to_pms_rust.md` |
| non-goals and claim boundary | `09_non_goals_and_claim_boundary.md` |

PMS-IR is the representation substrate.

Sections 14–17 define how tools analyze, verify, observe, simulate, and execute around it.

### 13.34 Architectural Consequence

The consequence of PMS-IR is:

```text
PMS-IR is the operator-preserving artifact layer of PMSL and PMS-STACK.
It turns source programs, modules, policies, tasks, channels, FFI calls,
standard-library calls, runtime operations, validation artifacts, traces,
simulation inputs, verification inputs, and backend targets into
analyzable Δ–Ψ structure without collapsing them into opaque bytecode,
generic ASTs, untyped logs, or host-specific runtime behavior.
```

This gives PMSL its implementation bridge: PMSL remains readable as source, PMS-IR remains checkable as structure, runtimes remain executable as operator programs, traces remain inspectable as bounded artifact evidence, and tooling remains governed by explicit claim discipline.

### 13.35 PMS-IR Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-IR model specifies the operator-preserving representation layer
for PMSL and PMS-STACK artifacts: high-level IR, core IR, executable IR,
operator tags, context records, control/data flow, effect profiles,
dependency validation, stateful validation, capability/policy validation,
boundary validation, absence/trap representation, commit representation,
serialization, trace mapping, transformations, backend lowering,
PmsBuilder/opcode-buffer relation, AI proposal boundaries, validation
pipelines, model-checking substrates, source mapping, metadata, golden
fixtures, PMS-RUST evidence boundaries, and PMS-IR invariants.

This is a language IR / operator-representation architecture claim.

It does not claim a completed PMSL compiler, completed PMS-IR optimizer,
completed PMS-IR verifier, completed runtime backend, completed PMS-OS
backend, completed distributed runtime, completed proof system, completed
PMSL implementation, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, program buffering, model validation, stateful runtime
validation, deterministic execution, JSONL traces, REPL/script tooling,
vFS service boundaries, golden fixtures, and AI proposal gating. It does
not complete PMSL/PMS-IR and does not validate PMS Base.
```

---

## 14. Static Analysis and Linting

Static analysis is the pre-execution discipline of PMSL and PMS-IR.

Its purpose is to inspect source programs, typed ASTs, PMS-IR graphs, module graphs, effect profiles, policies, capabilities, boundary projections, error paths, concurrency structures, standard-library calls, FFI profiles, runtime profiles, backend profiles, validation reports, and claim-boundary metadata before runtime execution.

It identifies operator-invalid transitions, missing obligations, unsafe abstractions, unsupported runtime assumptions, incomplete coverage, and claim-boundary risks.

The central static-analysis claim is:

```text
PMSL/PMS-IR static analysis is valid when it checks that source and IR
artifacts are operator-well-formed, layer-typed, policy-constrained,
effect-explicit, boundary-aware, role-authorized, absence-covered,
trap-covered, commit-valid, backend-admissible, and claim-boundary-clean
before execution.
```

Static analysis is not proof of PMS Base.

Linting is not verification.

Passing a checker strengthens the PMS-STACK implementation/tooling claim by showing that a program satisfies specified structural constraints under a declared profile.

It does not establish final semantic adequacy of PMS as a base theory.

Claim type:

```text
LANGUAGE STATIC-ANALYSIS / LINTING ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL/PMS-IR static analysis and linting as
implementation-layer tooling architecture.

It does not claim a completed PMSL analyzer, completed linter, completed
compiler, completed PMS-IR verifier, completed proof system, completed
runtime, completed backend, completed PMSL implementation, or PMS Base
validation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared static-analysis profile, lint profile, PMS-IR schema, operator-dependency model, type/effect rule, runtime profile, backend profile, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, runtime correctness, backend correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR static-analysis level, Χ is projected as module boundary, task boundary, endpoint visibility, namespace visibility, host boundary, runtime boundary, sandbox boundary, memory-domain separation, reachability control, and cross-frame transfer discipline.

Static analysis checks the PMSL/PMS-IR projection of Χ.

It does not redefine Χ.

### 14.1 Role of Static Analysis

Static analysis sits between PMSL/PMS-IR construction and runtime execution.

```text
PMSL source
→ parser
→ typed AST
→ operator-typed AST
→ PMS-IR
→ static analysis / linting
→ validation
→ runtime or backend
```

Its role is to answer:

```text
Is this program structurally admissible before it runs?
```

More specifically:

```text
Are operators dependency-valid?
Are constructs layer-valid?
Are effects declared?
Are roles sufficient?
Are capabilities present?
Are policies active?
Are boundaries respected?
Are absences handled?
Are traps handled?
Are commits valid?
Are modules linkable?
Are FFI calls bounded?
Are APIs supported by the runtime profile?
Are implementation claims properly typed?
```

Static analysis therefore enforces the architecture discipline described earlier:

```text
valid_execution(w, layer, P) =
    valid_PMS(w)
    ∧ valid_layer(w, layer)
    ∧ valid_policy(w, P)
```

At the PMSL/PMS-IR layer, this becomes:

```text
valid_pmsl_ir(program, profile, policy) =
    operator_valid(program)
    ∧ type_valid(program)
    ∧ effect_valid(program)
    ∧ frame_valid(program)
    ∧ authority_valid(program)
    ∧ boundary_valid(program)
    ∧ policy_valid(program)
    ∧ failure_paths_valid(program)
    ∧ commit_valid(program)
    ∧ backend_admissible(program, profile)
```

The predicate `valid_pmsl_ir` is a profile-local implementation/tooling predicate.

It is not PMS Base validation.

### 14.2 Static Analysis vs. Linting

PMSL distinguishes static analysis from linting.

Static analysis checks validity obligations.

Linting checks style, clarity, risk, maintainability, portability, hardening, and claim-boundary obligations.

```text
static analysis
  → required for admissibility

linting
  → advisory, profile-dependent, hardening-oriented
```

Examples of static-analysis failures:

```text
missing capability before protected FS.write
unhandled Φ trap path
unhandled Λ timeout path
commit block with no committable state
FFI call without boundary profile
module export hiding required effect
isolated module accessed without bridge
AI proposal treated as executable PMS-IR without validation gate
```

Examples of lint findings:

```text
effect signature is broader than needed
policy block could be narrowed
timeout lacks explicit reason
module export surface is too wide
FFI wrapper should use HostService profile
task is detached without lifecycle comment
claim text says "verified" when only static checking occurred
```

Linting may be elevated to error by policy.

```text
lint warning + Ψ strict profile → static rejection
```

Static analysis and linting are both tooling disciplines. Neither is PMS Base validation.

### 14.3 Analysis Inputs

A PMSL analyzer may consume several artifact forms.

```text
PMSL source files
typed AST
operator-typed AST
PMS-IR graph
serialized PMS-IR
module graph
effect table
policy table
capability graph
boundary graph
runtime profile
backend profile
trace schema
standard-library profile
FFI profile
AI/tooling proposal metadata
```

Minimal input:

```text
PMS-IR with operator tags and effect profiles
```

Preferred input:

```text
source + typed AST + PMS-IR + module graph + runtime profile
```

The richer the input, the stronger the diagnostics.

An analyzer must state which inputs were available. Analysis incompleteness must not be reported as successful validation.

### 14.4 Analysis Pipeline

Canonical static-analysis pipeline:

```text
parse
→ resolve symbols
→ build type environment
→ infer effects
→ lower to operator-typed AST
→ build PMS-IR
→ check operator dependencies
→ check layer validity
→ check types/effects
→ check frames
→ check roles/capabilities
→ check policies
→ check boundaries
→ check absences and traps
→ check commits
→ check modules
→ check FFI
→ check concurrency and IO APIs
→ check backend/runtime profile support
→ check AI/tooling proposal gates where present
→ emit diagnostics and lint results
```

Operator reading:

```text
Δ symbol/type distinction
Ω authority checking
□ frame checking
Χ boundary checking as PMSL/PMS-IR projection
Ψ policy checking
Θ order/wait checking
Λ absence coverage checking
Φ trap/recontextualization checking
Σ commit checking
Α pattern expansion checking
```

The pipeline may be implemented incrementally. A bounded analyzer may support only a subset. Unsupported checks must be declared by profile.

### 14.5 Operator Dependency Analysis

Operator dependency analysis checks whether PMS-IR nodes satisfy the dependency discipline of Δ–Ψ.

It checks that:

```text
∇ has distinguished target/action
□ has distinguished context
Λ has expectation context
Α expands to valid operator structure
Ω has role/capability relation
Θ orders meaningful progression
Φ has frame/cause/continuation context
Χ has boundary/domain context
Σ has committable prior structure
Ψ binds valid policy/invariant structure
```

Example invalid sequence:

```text
∇ write_file
```

Diagnostic:

```text
error[Δ/Ω/Ψ/Σ]:
    write_file is effectful but lacks visible target distinction,
    authority check, policy check, and commit behavior.
```

Example invalid commit:

```text
commit Σ { }
```

Diagnostic:

```text
error[Σ]:
    commit block has no staged or committable effect.
```

Dependency analysis may be local or graph-based.

```text
local adjacency check
  → op_i may be followed by op_j?

graph ancestry check
  → required prerequisites dominate or reach this node?

stateful check
  → active frame/capability/policy/boundary exists here?
```

Dependency analysis accepts or rejects under a declared dependency model. It is not a proof of PMS Base.

### 14.6 Layer-Typed Validity Analysis

A PMS-IR node may be operator-valid but invalid in a specific layer.

Example:

```text
filesystem Σ
```

requires:

```text
filesystem/runtime/storage context
```

Example:

```text
PMSL policy block
```

requires:

```text
language/runtime policy context
```

Layer analysis checks:

```text
construct valid in PMSL?
construct valid in target runtime profile?
construct valid in backend profile?
construct valid under active standard-library profile?
construct valid under active FFI profile?
construct valid under active simulation or test profile?
```

Example:

```pmsl
FS.sync(h)
```

is invalid in a runtime profile that does not support durable filesystem commits unless the function declares:

```text
Λ unsupported feature
```

or:

```text
Φ_trap<UnsupportedRuntimeFeature>
```

Layer validity protects PMSL from accidental portability overclaim.

Layer validity also prevents runtime artifacts from being misdescribed as complete PMS-OS, complete PMS-CPU, or PMS Base validation.

### 14.7 Type and Effect Analysis

Type/effect analysis checks that PMSL values and effects match declared signatures.

Checks include:

```text
expression type compatibility
function body result compatibility
effect set inclusion
effect inference consistency
standard-library profile matching
FFI effect declaration
API effect support under runtime profile
AI/tooling proposal effect visibility where present
```

Effect rule:

```text
body_effects(fn) ⊆ declared_effects(fn)
```

Frame/policy rule:

```text
declared_effects(fn) permitted by active frame, policy, role, and boundary
```

Example:

```pmsl
fn pure_hash(data: Bytes) -> Hash
    effects(Δ, ∇)
{
    Log.info("hashing")
    hash(data)
}
```

Diagnostic:

```text
error[Effect/Ψ]:
    function declares effects(Δ, ∇), but body calls Log.info,
    which requires effects(Δ, ∇, Σ, Ψ).
```

Effect analysis treats `Effect<Χ>` as layer-projected boundary/visibility/reachability behavior, not a redefinition of PMS Base Χ.

### 14.8 Frame Analysis

Frame analysis checks □ obligations.

It verifies:

```text
every block has a valid lexical frame
every function call enters a valid function frame
every module has a ModuleFrame
every task has a TaskFrame
every handler has a HandlerFrame
every FFI call has a ForeignFrame
every commit block has a CommitFrame or equivalent commit context
```

Frame analysis also checks:

```text
no local binding escapes invalid frame
no borrowed value outlives its frame
no handler uses stale continuation
no module state is accessed outside module frame
no resource is used after its frame closes
```

Example invalid escape:

```pmsl
fn leak_ref() -> Borrowed<Bytes, TransactionFrame> {
    transaction {
        let b = FS.read(...)
        return borrow(b)
    }
}
```

Diagnostic:

```text
error[□/Σ]:
    returned borrowed value is tied to TransactionFrame that closes before return.
```

Frame analysis is a structural admissibility check. It does not prove all runtime lifetimes unless paired with a stated model or proof artifact.

### 14.9 Role and Capability Analysis

Role/capability analysis checks Ω obligations.

It verifies:

```text
protected calls have required capabilities
active role satisfies required role constraints
capabilities are not used outside scope
capability delegation is explicit
capabilities do not leak through exports
module imports do not silently widen authority
FFI calls require foreign-call capabilities
channel send/recv require endpoint capabilities
AI/tooling service requests require tooling capabilities
```

Example:

```pmsl
FS.write(path, data)
```

requires:

```text
Ω(fs.write(path))
```

Diagnostic:

```text
error[Ω]:
    FS.write requires capability fs.write(path).
    Active role does not provide it.
```

Capability analysis may produce hardening lints:

```text
lint[Ω]:
    function requires fs.write("/**"), but all writes target "/var/log/**".
    Consider narrowing capability.
```

Ω does not override Ψ policy or Χ-projected boundary constraints.

### 14.10 Policy Analysis

Policy analysis checks Ψ obligations.

It verifies:

```text
required policies are active
policy scopes do not weaken enclosing policy
policy denials have declared outcomes
policy installs require authority
policy composition is coherent
standard-library policy hooks are present
FFI policies are explicit
module policies are compatible with imports/exports
AI/tooling proposal policies are enforced where present
```

Example:

```pmsl
policy with P_readonly {
    FS.write(path, data)
}
```

Diagnostic:

```text
error[Ψ]:
    active policy P_readonly denies FS.write.
```

Policy analysis also checks future-binding effects.

Example:

```pmsl
Policy.install(P_relaxed)
```

must be checked against:

```text
Ω policy.install
Ψ non-weakening rule
Σ policy commit behavior
```

Policy analysis is program/runtime constraint checking. It is not moral judgment, forensic attribution, governance tribunal behavior, or PMS Base validation.

### 14.11 Boundary Analysis

Boundary analysis checks Χ obligations as PMSL/PMS-IR layer projections.

It verifies:

```text
module boundaries are respected
isolated modules are not directly accessed
task boundaries are respected
channel endpoint visibility holds
shared frames have explicit participants
FFI calls enter ForeignFrame
host services have boundary profile
distributed calls have node/session boundary profile
AI/tooling services remain advisory host/tooling boundaries
```

Boundary check form:

```text
Visible(source, target) iff
    Χ permits reachability under the active PMSL/PMS-IR boundary profile
    ∧ Ω permits access
    ∧ Ψ permits transition
```

Example:

```pmsl
sandboxed_module.internal_state
```

Diagnostic:

```text
error[Χ/Ψ]:
    direct access crosses isolated module boundary.
    Use exported interface, channel, or explicit transfer profile.
```

Boundary lints include:

```text
lint[Χ]:
    module is marked isolated but exports mutable state handle.
```

Boundary analysis checks the implementation-layer projection of PMS Base Χ = Distance. It does not redefine Χ.

### 14.12 Absence Coverage Analysis

Absence analysis checks Λ paths.

It verifies:

```text
timeouts are handled or declared
no-message paths are handled or declared
missing optional values are handled
no-resource outcomes are handled
unsupported runtime features are handled
no-response paths in request/response APIs are handled
tooling-service non-response paths are handled where present
```

Example:

```pmsl
let msg = Channel.recv(inbox, timeout = 50ms)
process(msg)
```

Diagnostic:

```text
error[Λ]:
    Channel.recv may produce Λ_absent<Message>.
    Absence is neither handled nor declared in function return type.
```

Valid forms:

```pmsl
recv inbox timeout 50ms on timeout {
    handle_absence()
}
```

or:

```pmsl
fn poll(...) -> Result<Message, Λ_absent<Message>>
```

Absence analysis keeps non-events from collapsing into untyped exceptions.

### 14.13 Trap Coverage Analysis

Trap analysis checks Φ paths.

It verifies:

```text
trap-capable calls are handled or declared
handler frames type-check
handler effects are declared
nested trap policy exists where required
cleanup/finally preserves active trap
FFI errors map into PMSL traps
task failures propagate through typed paths
AI/tooling malformed-response traps remain advisory unless validated
```

Example:

```pmsl
fn read(path: Path) -> Bytes {
    FS.read(path)
}
```

Diagnostic:

```text
error[Φ]:
    FS.read may produce Φ_trap<FileError>.
    Function return type does not declare trap and no handler is present.
```

Valid forms:

```pmsl
fn read(path: Path) -> Result<Bytes, Φ_trap<FileError>>
```

or:

```pmsl
try {
    FS.read(path)
} trap on Φ_trap<FileError> as e {
    recover(e)
}
```

Trap coverage analysis is structural. It does not guarantee recovery completeness unless paired with a property model or proof artifact.

### 14.14 Commit Analysis

Commit analysis checks Σ obligations.

It verifies:

```text
effects are not mistaken for commits
staged effects are committed, rolled back, or propagated
commit profile matches caller expectation
durability claims match backend/runtime profile
channel delivery commit is explicit
module linkage commit is explicit
task lifecycle commits are explicit
trace/audit commit behavior is declared
AI/tooling proposal acceptance does not count as executable commit
```

Example:

```pmsl
fn save(data: Bytes) -> Σ_durable<Unit> {
    FS.write(path, data)
}
```

Diagnostic:

```text
error[Σ]:
    FS.write provides Σ_visible<Unit>, not Σ_durable<Unit>.
    Use FS.sync or a durable_write profile.
```

Commit analysis prevents false visibility and false durability claims.

A commit claim is profile-bound. It is not external validation of storage, runtime, or PMS Base unless separately evidenced under stated assumptions.

### 14.15 Pattern Expansion Analysis

Pattern analysis checks Α.

It verifies:

```text
patterns expand to valid operator words
macro expansion preserves source spans
pattern effects are declared
pattern absence/trap/commit paths are exposed
retry/backoff loops are bounded or policy-governed
resource acquisition patterns close resources
AI-generated patterns remain proposals until host-validated
```

Example:

```pmsl
pattern retry_forever(op) {
    loop {
        op()
    }
}
```

Diagnostic:

```text
lint[Α/Θ/Ψ]:
    unbounded retry pattern lacks policy, backoff, cancellation, or resource bound.
```

A strict profile may promote this to error.

Pattern expansion may abstract structure. It may not hide missing authority, boundary, policy, absence, trap, or commit obligations.

### 14.16 Concurrency and IPC Analysis

Concurrency analysis checks task, channel, event, select, and sync correctness.

It verifies:

```text
spawn authority
task lifecycle owner
structured concurrency closure
detached task policy
await visibility
cancellation policy
channel payload type
send/receive capability
endpoint visibility
timeout handling
backpressure handling
select arm compatibility
shared-state synchronization
lock ordering where detectable
```

Example:

```pmsl
spawn detached task Worker {
    serve()
}
```

Diagnostic:

```text
lint[□/Ψ]:
    detached task lacks explicit lifecycle owner and shutdown policy.
```

Example:

```pmsl
send C <- msg
```

without send capability:

```text
error[Ω]:
    Channel.send requires channel.send<T>(C).
```

Concurrency analysis checks structural and profile-local properties. It does not explore all interleavings unless paired with model checking.

### 14.17 Module Analysis

Module analysis checks module frames, imports, exports, versions, lifecycle, and policy surfaces.

It verifies:

```text
module path uniqueness
symbol table coherence
import resolution
export completeness
interface satisfaction
effect signature compatibility
capability requirements on exports
policy non-weakening
boundary compatibility
lifecycle hook validity
version compatibility
reframe migration obligations
resource closure on unload
```

Example:

```pmsl
export fn read_secret() -> Secret
```

from isolated module without boundary transfer profile:

```text
error[Χ/Σ]:
    export exposes boundary-protected value without transfer profile.
```

Module lints:

```text
lint[Ω]:
    exported interface requires broad Admin role; consider narrower capability surface.
```

Module analysis protects linkage and boundary integrity. It does not claim a completed linker or module loader.

### 14.18 FFI and Host Analysis

FFI analysis checks Section 9 obligations.

It verifies:

```text
foreign symbol declaration exists
ABI profile is specified
argument/result mappings are valid
foreign effect profile is declared
foreign-call capability exists
host boundary profile is explicit
memory transfer profile is explicit
host error map is complete
blocking behavior is declared
foreign handle lifecycle is closed
callback entry is authorized
unsafe FFI is policy-gated
commit claims do not exceed host guarantees
AI/tooling host-service responses remain advisory unless validated
```

Example:

```pmsl
foreign fn raw_write(ptr: HostPtr) -> Unit
```

Diagnostic:

```text
error[Χ/Φ/Ψ]:
    foreign declaration lacks memory transfer profile,
    error mapping, boundary profile, and FFI policy.
```

Unsafe FFI is allowed only when explicitly bounded.

```text
unsafe FFI
  ≠ operator suspension
```

FFI analysis checks the declared FFI profile. It does not prove host library behavior.

### 14.19 Standard-Library and API Analysis

Standard-library analysis checks domain profiles.

It verifies:

```text
API exists in active standard-library profile
runtime profile supports API
required capability exists
effect profile is permitted
absence/trap/commit paths are handled
backend support is declared
```

Example:

```pmsl
Net.connect(addr)
```

in a runtime profile without network support:

```text
error[Λ/Φ/Ψ]:
    Net.connect requires runtime network_io.
    Active runtime profile does not support it.
```

The program may remain valid if it declares:

```pmsl
Result<Connection, Λ_absent<RuntimeFeature> | Φ_trap<UnsupportedRuntimeFeature>>
```

depending on the profile.

Standard-library and API analysis verifies profile-local API admissibility. It does not claim a completed standard library or completed runtime backend.

### 14.20 Resource and Lifecycle Analysis

Resource analysis checks that handles, frames, channels, tasks, modules, and foreign resources have valid lifecycles.

It verifies:

```text
opened handles are closed or transferred
tasks are awaited, cancelled, or detached under policy
channels are closed or ownership-transferred
foreign handles have close policy
transactions commit or rollback
locks release on all paths
module finalizers close resources
trace/audit buffers have commit behavior
```

Example:

```pmsl
let h = FS.open(path, read)
return h
```

Diagnostic:

```text
error[□/Ω/Σ]:
    file handle escapes without ownership transfer or lifetime declaration.
```

Resource analysis is one of the main places where linting becomes hardening.

It is still a structural analysis unless paired with model checking or proof over all paths.

### 14.21 Diagnostics

Static analysis diagnostics must be operator-labeled.

Diagnostic form:

```text
Diagnostic = (
    severity,
    operator,
    code,
    message,
    source_span,
    failed_obligation,
    required_context,
    actual_context,
    notes,
    suggestions
)
```

Example:

```text
error[Ω]:
    missing capability fs.write("/var/log/**")

source:
    FS.write(path, data)

required:
    Ω(fs.write)

active role:
    User

suggestion:
    require Ω(LogWriter) or narrow operation to permitted path.
```

Example:

```text
error[Λ]:
    timeout path is not handled

source:
    recv inbox timeout 50ms

required:
    handle Λ_absent<Message> or declare it in return type.
```

Diagnostics should not merely say:

```text
type error
```

They should say which operator obligation failed.

Diagnostics are tool outputs under a declared profile. They are not proof artifacts and not PMS Base validation.

### 14.22 Severity Levels

Recommended severity levels:

```text
fatal
error
warning
lint
note
info
```

Severity meaning:

| Severity | Meaning |
| -------- | ------- |
| `fatal` | analysis cannot continue |
| `error` | program is not admissible |
| `warning` | program is admissible but risky or profile-dependent |
| `lint` | hardening or clarity issue |
| `note` | explanatory context |
| `info` | non-blocking metadata |

Policy may promote or demote severities.

```text
strict_security profile:
    broad capability lint → error

deterministic_test profile:
    nondeterministic host call warning → error

debug profile:
    trace missing note → warning
```

Severity is profile-local. A warning in one profile may be a rejection in another.

### 14.23 Lint Categories

PMSL lint categories include:

```text
operator clarity
effect precision
capability narrowing
policy hardening
boundary clarity
absence explicitness
trap explicitness
commit precision
module hygiene
FFI hardening
concurrency lifecycle
resource closure
traceability
runtime portability
determinism
documentation
claim boundary
AI/tooling boundary
```

Examples:

```text
lint[effect_precision]:
    function declares effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    but inferred body effects are effects(Δ, ∇, Σ).
```

```text
lint[claim_boundary]:
    comment claims "verified safe" but artifact has only static-analysis pass status.
    Use "statically checked under profile P" unless model checking or proof artifact exists.
```

Claim-boundary linting is important for PMS-STACK documents and tooling because implementation artifacts must not be presented as PMS Base validation.

### 14.24 Autofix and Rewrite Suggestions

A PMSL analyzer may suggest fixes.

Examples:

```text
add missing effect to function signature
wrap call in policy scope
add required capability declaration
add absence branch
add trap handler
insert commit block
narrow capability path
replace direct module access with exported interface
add FFI error map
add timeout to blocking call
mark runtime profile requirement
insert AI/tooling validation gate
```

Autofix rule:

```text
automatic rewrites may add explicit obligations;
they may not silently weaken policy, authority, boundary, absence,
trap, or commit discipline.
```

Example safe fix:

```text
add effects(Λ) to signature
```

Potentially unsafe fix:

```text
silently catch Φ_trap<any> and return default
```

The second requires explicit user decision, declared policy approval, or a profile-specific recovery rule.

Autofix suggestions are not compiler authority unless accepted and rechecked by host tooling.

### 14.25 AI-Assisted Static Analysis Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

AI may assist static analysis only as advisory tooling.

Permitted AI roles:

```text
summarize diagnostics
suggest possible missing obligations
explain operator failures
propose PMS-IR fragments
suggest lint fixes
analyze traces for likely causes
draft candidate test fixtures
draft candidate simulation scenarios
```

Forbidden AI roles:

```text
define PMSL semantics
authorize execution
replace static analyzer
replace model checker
replace verifier
replace policy engine
silently rewrite code into executable form
serve as verification evidence
serve as PMS Base validation
```

Required boundary:

```text
AI finding
→ host-side parsing
→ canonicalization
→ static analyzer check
→ policy check
→ human or tool acceptance
```

Expanded execution boundary:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output status:

```text
advisory finding
```

not:

```text
verified result
trusted compiler output
policy decision
proof artifact
trusted executable code
PMS Base validation
```

This mirrors the PMS-IR AI proposal boundary: AI may propose; host tooling validates.

### 14.26 Analysis Outputs

Static analysis may emit:

```text
diagnostic list
lint list
effect table
capability report
policy report
boundary report
module graph report
FFI report
absence/trap coverage report
commit report
runtime-profile compatibility report
PMS-IR validation report
machine-readable JSON/JSONL diagnostics
```

Report example:

```text
AnalysisReport = (
    program_id,
    profile,
    status,
    diagnostics,
    operator_summary,
    effects,
    capabilities,
    policies,
    boundaries,
    absences,
    traps,
    commits,
    modules,
    ffi,
    runtime_support,
    meta
)
```

Status values:

```text
accepted
accepted_with_warnings
rejected
unsupported_profile
analysis_incomplete
```

`analysis_incomplete` must not be presented as success.

An `accepted` report means accepted under the declared analysis profile. It does not mean verified, proven, externally validated, or PMS Base-validated.

### 14.27 Trace, Fixture, and Report Evidence

Static analysis may operate together with traces and golden fixtures.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed analysis-supported run:

```text
trace_pmsl(runtime, analyzed_artifact, input_profile) ∈ L_PMS
```

For the set of possible runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, analyzed_artifact, input_profile) ⊆ L_PMS
```

Trace conformance checks whether an observed trace conforms to a declared IR/profile/property expectation.

It does not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

Golden fixtures may contain:

```text
input source or PMS-IR
expected diagnostics
expected acceptance/rejection
expected trace
expected validation error
expected lint category
```

Golden fixtures stabilize regression expectations.

They do not prove PMS Base, semantic completeness, or full behavioral coverage.

### 14.28 Static Analysis and PMS-RUST Evidence

PMS-RUST v0.1 may support bounded executable evidence for static-analysis-adjacent and validation-adjacent slices.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR static-analysis-adjacent behavior, such as:

```text
operator-tagged program construction
model/dependency validation
stateful validation
validator acceptance/rejection
script execution
JSONL trace emission
golden fixture comparison
proposal gating
```

It does not complete:

```text
PMSL static analyzer
PMSL linter
PMSL compiler
PMS-IR verifier
PMS-IR optimizer
PMSL runtime
PMS-CPU
PMS-OS
distributed runtime
PMS Base validation
```

The correct relation is:

```text
PMSL/PMS-IR static analysis specification
  → defines analysis obligations

PMS-RUST v0.1
  → demonstrates bounded executable slices of validation and tooling
```

Boundary:

```text
This strengthens the implementation-artifact claim.
It does not prove PMS Base.
It does not equal a complete PMSL compiler or complete PMS-IR analyzer.
```

### 14.29 Static Analysis Invariants

PMSL/PMS-IR maintains the following static-analysis invariants.

```text
I1: every analyzed artifact is tied to a declared profile
I2: every IR node has an operator tag
I3: every operator tag imposes validation obligations
I4: every effectful construct exposes an effect profile
I5: every protected operation exposes Ω requirements
I6: every policy-governed operation exposes Ψ requirements
I7: every boundary-crossing operation exposes Χ-projected behavior
I8: every frame-dependent construct exposes □ context
I9: every absence-capable construct exposes Λ paths
I10: every trap-capable construct exposes Φ paths
I11: every commit-capable construct exposes Σ behavior
I12: every pattern expansion preserves Α origin and validates after expansion
I13: every module export preserves type/effect/capability/policy signature
I14: every FFI call has boundary, ABI, effect, memory, error, and commit profiles
I15: every concurrency API exposes lifecycle, cancellation, and absence behavior
I16: every unsupported runtime feature is typed as Λ/Φ/Ψ outcome
I17: diagnostics identify the failed operator obligation
I18: linting may harden but may not silently change semantics
I19: AI-assisted findings remain advisory until validated by host tooling
I20: passing static analysis strengthens implementation confidence but does not function as PMS Base validation
I21: trace conformance and golden fixtures evidence bounded artifact behavior; they do not prove all executions without a stated model, coverage argument, or proof artifact
I22: PMS-RUST evidence supports bounded validation/tooling claims; it does not complete PMSL/PMS-IR static analysis
```

These invariants are specification-level PMSL/PMS-IR tooling constraints.

They do not claim that a completed analyzer, linter, compiler, verifier, proof system, runtime, or backend already enforces every invariant.

### 14.30 Boundary to Model Checking and Verification

Static analysis checks structural admissibility before execution.

It does not fully establish:

```text
all reachable runtime states
all temporal properties
all interleavings
all distributed executions
all model properties
all proof obligations
all external adequacy claims
```

Those belong to Section 15.

Boundary:

```text
Static analysis:
    checks local and graph-level structural obligations.

Model checking:
    explores state spaces and transition systems.

Verification:
    establishes specified properties under explicit assumptions.

Proof:
    requires formal statement, semantics, assumptions, and derivation.

PMS Base validation:
    is not produced by any of these implementation artifacts.
```

This boundary enables strong tool claims without claim-type confusion.

### 14.31 Architectural Consequence

The consequence of PMSL/PMS-IR static analysis is:

```text
PMSL programs and PMS-IR artifacts become checkable before execution:
their operator dependencies, layer validity, type/effect profiles,
frames, roles, capabilities, policies, boundary projections, absences,
traps, commits, modules, FFI calls, concurrency structures,
standard-library uses, runtime-profile assumptions, diagnostics, lint
findings, trace expectations, fixture expectations, and claim boundaries
remain explicit and machine-inspectable.
```

This gives PMSL/PMS-IR a strong tooling layer: programs can be rejected, hardened, explained, or profile-bounded before runtime, while preserving the claim boundary that static analysis is implementation-layer discipline, not PMS Base validation.

### 14.32 Static-Analysis Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL/PMS-IR static-analysis and linting model specifies
implementation-layer tooling discipline: analysis inputs, analysis
pipelines, operator dependency analysis, layer validity, type/effect
analysis, frame analysis, role/capability analysis, policy analysis,
boundary analysis, absence/trap coverage, commit analysis, pattern
analysis, concurrency analysis, module analysis, FFI analysis,
standard-library/API analysis, resource lifecycle analysis, diagnostics,
severity levels, lint categories, autofix constraints, AI-assisted
analysis boundaries, analysis outputs, trace/fixture/report evidence,
PMS-RUST evidence boundaries, and static-analysis invariants.

This is a language static-analysis / linting architecture claim.

It does not claim a completed PMSL analyzer, completed linter, completed
compiler, completed PMS-IR verifier, completed proof system, completed
runtime, completed backend, completed PMSL implementation, or PMS Base
validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, program buffering, model validation, stateful runtime
validation, deterministic execution, JSONL traces, REPL/script tooling,
vFS service boundaries, golden fixtures, and AI proposal gating. It does
not complete PMSL/PMS-IR static analysis and does not validate PMS Base.
```

---

## 15. Model Checking and Verification

Model checking and verification are the formal assurance layer of PMSL and PMS-IR.

They do not replace the language, runtime, static analyzer, policy engine, or PMS Base. They operate on explicitly defined models: PMS-IR graphs, transition systems, runtime profiles, backend profiles, property sets, traces, golden fixtures, proof obligations, and bounded execution artifacts.

The central verification claim is:

```text
PMSL/PMS-IR verification is valid when explicitly stated properties are
checked against explicitly defined PMS-IR transition systems, runtime
models, backend profiles, traces, fixtures, or proof objects, while
preserving the claim boundary that verified artifacts strengthen
implementation-layer assurance and do not function as PMS Base validation.
```

Verification in PMSL is therefore strong but typed.

It can establish that a program, IR graph, trace, runtime slice, backend profile, or proof artifact satisfies a stated property under stated assumptions.

It does not establish that PMS Base is final, complete, universally adequate, or externally validated as praxis grammar.

Claim type:

```text
LANGUAGE MODEL-CHECKING / VERIFICATION ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL/PMS-IR model checking and verification as
implementation-layer assurance architecture.

It does not claim a completed model checker, completed verifier,
completed proof system, completed formal semantics, completed compiler,
completed runtime, completed backend, completed PMSL implementation, or
PMS Base validation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation and verification in this section are claim-typed.

Validation means acceptance or rejection under a declared schema, model, runtime profile, tool profile, conformance rule, trace expectation, or verification profile.

Verification means checking or proving a stated property of a stated artifact under stated assumptions, using a stated model, abstraction, transition relation, proof system, or tool.

Neither validation nor verification means external validation of PMS Base unless an external-validation study is explicitly designed, performed, and claim-typed as such.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR verification level, Χ is checked as the implementation-layer projection of Distance into module boundary, task boundary, endpoint visibility, namespace visibility, host boundary, runtime boundary, sandbox boundary, memory-domain separation, reachability control, and cross-frame transfer discipline.

Verification checks this PMSL/PMS-IR projection.

It does not redefine Χ.

### 15.1 Role of Verification in PMSL/PMS-IR

Verification sits after static analysis and before, beside, or after runtime execution depending on the tool.

```text
PMSL source
→ PMS-IR
→ static analysis
→ model extraction
→ property specification
→ model checking / symbolic execution / proof / trace validation
→ verification report
```

Its role is to answer:

```text
Does this modeled artifact satisfy this stated property under this
profile and assumption set?
```

Examples:

```text
No path reaches FS.write without Ω(fs.write).
Every Channel.recv timeout path is represented as Λ.
Every committed durable result passes through Σ_durable.
No FFI call enters a host boundary without Χ and Ψ checks.
Every spawned task is awaited, cancelled, or detached under policy.
Every module export preserves its declared type/effect/capability profile.
```

Verification is therefore property-specific.

It does not ask:

```text
Is PMS true?
```

It asks:

```text
Does this PMSL/PMS-IR artifact satisfy property P under model M?
```

This distinction allows strong verification claims while preventing claim-type inflation.

### 15.2 Verification Ladder

PMSL/PMS-IR uses a ladder of assurance forms.

| Assurance form | What it establishes | What it does not establish |
| -------------- | ------------------- | -------------------------- |
| Parsing | source is syntactically accepted | semantic validity |
| Type checking | types/effects fit declared rules | runtime adequacy or PMS Base validation |
| Static analysis | operator obligations are structurally satisfied | all reachable behavior |
| Model validation | IR obeys declared model/dependency constraints | proof of implementation correctness or PMS Base validation |
| Model checking | finite or abstracted state space satisfies properties | correctness outside model assumptions |
| Symbolic execution | path constraints satisfy or violate properties | exhaustive global proof unless bounded as such |
| Trace conformance | observed trace conforms to declared IR/profile/property expectations | all possible executions unless paired with stated model, coverage, or proof artifact |
| Golden fixtures | regression output matches expected fixture | PMS Base, semantic completeness, or full behavioral coverage |
| Proof artifact | stated theorem follows from formal premises | validity of premises or PMS Base |
| External validation | independent tests/applications may support external warrant | PMS Base validation or theoretical finality |

The ladder prevents claim inflation.

A passing model checker result is valuable.

It is not PMS Base validation.

A proof over a formal PMS-IR semantics is valuable.

It proves the theorem over that semantics.

It does not prove that PMS captures all relevant structures of praxis or computation outside the stated model.

### 15.3 Verification Objects

Verification may operate on several objects.

```text
PMS-IR graph
PMS-IR program sequence
typed AST
module graph
capability graph
policy graph
boundary graph
task/channel graph
runtime transition system
backend profile
serialized trace
golden fixture
symbolic state space
formal semantics
proof obligation set
```

Each verification object must declare:

```text
scope
profile
assumptions
operators included
operators abstracted
state components
transition rules
property language
soundness boundary
unsupported features
```

Example:

```text
VerificationObject:
    artifact: PMS-IR graph
    profile: deterministic_runtime
    scope: task/channel/commit subset
    excluded: FFI, distributed nodes, host scheduling
    property: no send without channel.send capability
```

This object can support a strong result about that subset.

It cannot support claims about FFI, distributed runtime, host scheduler behavior, or PMS Base.

### 15.4 Model Extraction

Model checking begins by extracting a model from PMS-IR.

```text
PMS-IR
→ abstract transition system
```

Generic model:

```text
Model = (
    States,
    InitialState,
    TransitionRelation,
    Labels,
    Properties,
    FairnessAssumptions,
    Abstractions,
    Boundaries
)
```

PMSL/PMS-IR model components:

```text
States:
    frames
    tasks
    modules
    roles
    capabilities
    policies
    boundaries
    channels
    sync objects
    commit state
    trap state
    absence state
    resource state

Labels:
    Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ
```

Transition relation:

```text
s --op/action--> s'
```

Example:

```text
s --Ω.require(fs.write)--> s'
s --Ψ.check(P_write)--> s''
s --∇.FS.write(path,data)--> s'''
s --Σ.commit(visible_write)--> s''''
```

The model must state which details are concrete and which are abstracted.

Model extraction is a tooling transformation. It is not proof unless paired with a proof of extraction correctness.

### 15.5 Transition System

The PMSL/PMS-IR transition system has the form:

```text
T = (S, A, →, s0, L)
```

where:

| Symbol | Meaning |
| ------ | ------- |
| `S` | states |
| `A` | actions / IR steps |
| `→` | transition relation |
| `s0` | initial state |
| `L` | labeling function |

A labeled transition:

```text
s --a/op--> s'
```

where:

```text
op ∈ { Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ }
```

Example state:

```text
s = (
    active_frame = F,
    active_role = R,
    active_policy = P,
    active_boundary = Bχ,
    channel_state = C,
    task_state = T,
    commit_state = K,
    handler_state = H
)
```

Transition validity:

```text
valid_transition(s, a, s') iff
    operator_valid(a)
    ∧ preconditions_hold(s, a)
    ∧ policy_allows(s, a)
    ∧ boundary_allows(s, a)
    ∧ postconditions_hold(s', a)
```

`Bχ` denotes the active PMSL/PMS-IR boundary projection. It is not PMS Base Χ itself.

### 15.6 Property Language

PMSL/PMS-IR properties may be expressed in several forms.

```text
invariant
reachability property
safety property
liveness property
temporal property
trace property
refinement property
noninterference property
resource property
commit property
protocol property
```

Canonical forms:

```text
always P
eventually P
never P
if P then eventually Q
P until Q
for all paths P
there exists a path P
no transition labeled op occurs unless condition C holds
```

Examples:

```text
always no FS.write without Ω(fs.write)
```

```text
always Χ boundary crossing implies Ψ boundary policy check
```

```text
always committed_durable(x) implies prior Σ_durable(x)
```

```text
if task spawned then eventually task completed or cancelled or detached_by_policy
```

```text
never host_call executes without ForeignFrame
```

Property language must remain explicit about path quantification, abstraction level, runtime profile, and fairness assumptions.

### 15.7 Safety Properties

Safety properties state that bad states do not occur.

Examples:

```text
No protected call occurs without capability.
No isolated module state is directly accessed from outside.
No FFI call bypasses ForeignFrame.
No policy denial is treated as success.
No Σ_durable claim is emitted from a Σ_visible-only backend.
No handler executes outside a HandlerFrame.
No task result is observed before task completion commit.
No channel receives a payload of the wrong type.
```

General safety form:

```text
∀ reachable s. bad(s) = false
```

Operator-specific safety examples:

```text
Ω safety:
    protected_action ⇒ capability_present

Χ safety:
    boundary_crossing ⇒ boundary_relation_valid

Ψ safety:
    policy_governed_action ⇒ policy_checked

Σ safety:
    visible_result ⇒ commit_occurred

Φ safety:
    trap_handler_entry ⇒ handler_frame_valid

Λ safety:
    absence_result ⇒ expected_event_or_value_missing
```

Safety results are bounded by the transition system, abstraction, and assumptions used.

### 15.8 Liveness Properties

Liveness properties state that expected progress eventually occurs under assumptions.

Examples:

```text
A ready task eventually runs under fair scheduling.
A committed send eventually becomes visible to a receiver under delivery assumptions.
A bounded timeout eventually produces Λ if no event occurs.
A finalizer eventually closes a resource under shutdown policy.
A retry pattern eventually succeeds, fails, or returns declared absence under bounded policy.
```

General liveness form:

```text
if condition P holds, eventually Q holds
```

Example:

```text
if Channel.send commits delivery and receiver remains live,
then receiver eventually can observe message
```

Liveness requires assumptions.

```text
scheduler fairness
resource availability
network availability
host responsiveness
no permanent policy denial
bounded queue behavior
```

A liveness claim without assumptions is invalid.

A liveness result proves the stated liveness property only within the declared fairness/resource assumptions.

### 15.9 Reachability Analysis

Reachability analysis asks whether a state can occur.

Examples:

```text
Can untrusted module reach Host.call?
Can task enter cancelled and completed states simultaneously?
Can a policy-denied action still reach Σ success?
Can FFI return host handle without close policy?
Can a module become ACTIVE without init commit?
Can channel receive occur after close?
```

Reachability query:

```text
∃ path s0 →* s_target
```

Unreachability result:

```text
No path reaches target state under model M.
```

Boundary:

```text
unreachable under model M
```

not:

```text
impossible in all implementations
```

unless model M is proven equivalent to the implementation.

Reachability is powerful because it gives counterexamples, but its claim is bounded by the modeled state space.

### 15.10 Operator Dependency Verification

Operator dependency verification checks Δ–Ψ dependency properties over all modeled paths.

Examples:

```text
Every ∇ effectful action has a prior dominating Δ classification.
Every Ω check refers to an active role/capability context.
Every Χ boundary crossing has a boundary relation.
Every Σ commit has a staged or committable subject.
Every Ψ policy decision has an active policy context.
Every Φ trap has handler, propagation, or abort policy.
Every Λ absence path corresponds to an expected event/value.
Every Α pattern expands to an operator-valid subgraph.
```

Generic property:

```text
∀ node n.
    op(n) = Σ
    ⇒ ∃ m. dominates(m,n) ∧ committable_subject(m,n)
```

Example diagnostic from failed model check:

```text
counterexample[Σ]:
    path reaches Σ_durable<FileWrite>
    without prior backend durability transition.
```

Operator dependency verification checks implementation-layer representation discipline. It does not validate PMS Base operator adequacy.

### 15.11 Type and Effect Verification

Type/effect verification checks that all modeled executions respect declared type and effect profiles.

Properties:

```text
function body effects are subsets of declared effects
standard-library call effects match profile
FFI effects are declared
module exports preserve effect signatures
branch merges preserve type/effect compatibility
absence and trap effects are declared or handled
```

Example property:

```text
∀ calls c.
    effects(c) ⊆ effects(enclosing_function(c))
```

Example property:

```text
∀ exported functions f.
    public_effect_signature(f) includes all reachable body effects
```

Counterexample:

```text
function declared effects(Δ, ∇)
but path reaches Log.audit requiring effects(Δ, Ω, Ψ, ∇, Σ, Φ)
```

Type/effect verification depends on the declared PMSL/PMS-IR type and effect semantics.

It does not prove PMS Base.

### 15.12 Frame Verification

Frame verification checks □ properties.

Properties:

```text
every running task has an active frame
every function call enters and exits a FunctionFrame
every handler executes inside HandlerFrame
every FFI call executes inside ForeignFrame
every module symbol belongs to a ModuleFrame
no value escapes a frame beyond its lifetime
all frame exits close, transfer, or declare local effects
```

Example property:

```text
∀ running_state s.
    active_task(s) ⇒ active_frame(s) ≠ none
```

Example property:

```text
∀ value v.
    lifetime(v) ≤ lifetime(owner_frame(v))
```

Counterexample:

```text
Borrowed<Bytes, TransactionFrame> returned after transaction frame exit.
```

Frame verification can be local, whole-program, symbolic, or model-based depending on the profile.

### 15.13 Role and Capability Verification

Role/capability verification checks Ω properties.

Properties:

```text
no protected operation without required capability
no capability used outside lifetime
no capability transferred without policy
no module export leaks internal capability unless declared
no role escalation without escalation rule
```

Example property:

```text
∀ protected actions a.
    reachable(a) ⇒ active_role_has(required_capability(a))
```

Example property:

```text
∀ capability transfers t.
    transfer(t) ⇒ Ω.allows(t) ∧ Ψ.allows(t)
```

Counterexample:

```text
path reaches Host.call with active role User
but required capability host.call is absent.
```

Capability verification does not make Ω absolute authority. Ω remains constrained by Ψ policy and Χ-projected boundary discipline.

### 15.14 Policy Verification

Policy verification checks Ψ properties.

Properties:

```text
every policy-governed action checks active policy
policy scopes do not weaken enclosing policy
policy denial does not reach success commit
policy install requires authority
policy composition remains coherent
critical invariant violation reaches abort/quarantine/halt path
```

Example property:

```text
∀ actions a.
    requires_policy(a) ⇒ prior_or_dominating Ψ.check(a)
```

Example property:

```text
Ψ.denied(a) ⇒ not eventually Σ.success(a)
```

unless the model includes an explicit approved recontextualization:

```text
Ψ.denied(a) → Φ.recover → alternative Σ outcome
```

Policy verification must distinguish:

```text
policy denial
trap recovery
successful alternative action
```

Policy verification is not moral judgment, forensic attribution, governance tribunal behavior, or PMS Base validation.

### 15.15 Boundary Verification

Boundary verification checks Χ-projected properties.

Properties:

```text
no cross-module access without export/import relation
no isolated module direct state access
no FFI call without ForeignFrame
no host callback without registered callback boundary
no value crosses boundary without transfer/copy/serialization profile
no distributed message crosses node boundary without protocol profile
```

Generic property:

```text
∀ boundary crossings c.
    crossing(c) ⇒ Χ.valid_relation(c) ∧ Ψ.allows(c)
```

Counterexample:

```text
Sandboxed module reads HostSecret through ordinary symbol lookup.
```

Boundary verification must maintain the version boundary:

```text
PMS Base Χ = Distance.
PMSL/PMS-IR Χ = implementation-layer boundary/reachability projection.
```

A verified boundary property is a property of the declared implementation-layer model.

It is not a redefinition or validation of PMS Base Χ.

### 15.16 Absence Verification

Absence verification checks Λ paths.

Properties:

```text
every timeout path is represented
every no-message path is represented
every unsupported runtime feature is represented
every optional absence is handled or declared
absence is not collapsed into untyped exception
```

Example property:

```text
∀ receive operations r.
    has_timeout(r) ⇒ reachable Λ_absent<Message> path
```

Example property:

```text
∀ Λ paths l.
    l is handled ∨ l is returned ∨ l is converted to declared Φ ∨ l is declared impossible
```

Counterexample:

```text
recv timeout path reaches untyped panic.
```

Absence verification protects non-event semantics. It does not prove that all real runtime non-events have been modeled unless the model explicitly covers them.

### 15.17 Trap and Exception Verification

Trap verification checks Φ paths.

Properties:

```text
every trap has handler, propagation, or abort policy
handler frame is valid
handler effects are declared
finally cleanup preserves active trap unless policy overrides
nested trap policy exists where nested traps are possible
FFI host errors map into declared PMSL trap or absence type
```

Example property:

```text
∀ Φ_trap<E>.
    reachable(Φ_trap<E>) ⇒ handled(E) ∨ propagated(E) ∨ runtime_default(E)
```

Counterexample:

```text
FS.read may produce Φ_trap<FileError>
but path reaches function return type Bytes with no trap declaration.
```

Trap verification checks modeled trap structure. It does not guarantee recovery adequacy unless recovery adequacy is itself specified and verified.

### 15.18 Commit Verification

Commit verification checks Σ properties.

Properties:

```text
staged effects are committed, rolled back, or propagated
visible results require visibility commit
durable results require durability commit
channel delivery commit precedes receiver visibility
task creation commit precedes scheduling visibility
module link commit precedes export use
trace commit occurs if audit policy requires it
```

Example property:

```text
Σ_durable(x) ⇒ prior durable_backend_commit(x)
```

Example property:

```text
receive(message) ⇒ prior Σ_delivery(message)
```

Counterexample:

```text
function returns Σ_durable<Unit>
after FS.write only, without FS.sync or durable backend profile.
```

Commit verification prevents overclaim at runtime/API level.

It proves commit properties only under the declared backend/runtime assumptions.

### 15.19 Concurrency Verification

Concurrency verification checks task, channel, event, wait, cancellation, and sync behavior.

Properties:

```text
every spawned task has lifecycle owner
parent task group closes child lifecycles before exit
detached tasks have explicit detached policy
await only observes visible tasks
cancel requires authority and policy
channel sends match payload type
channel receives follow delivery policy
select arms have compatible result types
locks are released on all paths
shared mutable state is synchronized
deadlock states are unreachable or reported
```

Example property:

```text
∀ tasks t.
    spawned(t) ⇒ eventually completed(t) ∨ cancelled(t) ∨ detached_by_policy(t)
```

Example property:

```text
∀ channel messages m.
    received(m) ⇒ sent(m) ∧ type(m) = payload_type(channel(m))
```

Concurrency verification often requires bounded or abstracted state spaces.

If interleavings are bounded, the verification report must state the bound.

### 15.20 FFI Verification

FFI verification checks host-boundary properties.

Properties:

```text
every foreign call has ForeignFrame
every foreign call has capability check
every host boundary crossing has Χ profile
every host error maps to Λ/Φ/Ψ/Σ outcome
every foreign handle is closed or transferred
every memory transfer profile is valid
unsafe FFI is capability-gated and policy-constrained
blocking FFI is not used in forbidden contexts
```

Example property:

```text
∀ foreign calls f.
    reachable(f) ⇒ ForeignFrame(f) ∧ Ω.check(f) ∧ Χ.boundary(f) ∧ Ψ.policy(f)
```

Counterexample:

```text
foreign raw_write executes with HostPtr argument but no memory transfer profile.
```

FFI verification must state host assumptions.

It does not prove host library correctness unless host behavior is modeled, constrained, or separately verified.

### 15.21 Module Verification

Module verification checks module graph properties.

Properties:

```text
all imports resolve to committed exports
module policies do not weaken dependencies
exported functions expose full type/effect/capability profiles
module boundaries are respected
module init commits before ACTIVE state
module finalization closes resources
reframe migrations preserve or explicitly transform obligations
version compatibility checks hold
```

Example property:

```text
ACTIVE(M) ⇒ LINKED(M) ∧ INIT_COMMITTED(M)
```

Example property:

```text
use_export(A,B,symbol) ⇒ exported(B,symbol) ∧ import_committed(A,B,symbol)
```

Counterexample:

```text
module reaches ACTIVE while required policy SafeFS is not active.
```

Module verification checks model-level module obligations. It does not claim a completed module loader.

### 15.22 Runtime Profile Verification

Runtime-profile verification checks whether PMSL/PMS-IR assumptions match the target runtime.

Properties:

```text
runtime supports required standard-library domains
runtime supports required commit profiles
runtime supports required scheduling model
runtime supports required FFI profile
runtime supports required trace/audit output
runtime supports deterministic execution if requested
runtime rejects unsupported constructs through typed outcomes
```

Example property:

```text
requires runtime async_io ⇒ profile.supports(async_io)
```

Counterexample:

```text
program uses FS.read_async under runtime profile core_only.
```

A program may still be valid if it handles unsupported-feature absence/trap:

```text
Λ_absent<RuntimeFeature>
Φ_trap<UnsupportedRuntimeFeature>
Ψ denial
```

Runtime-profile verification prevents portability overclaims.

Profile conformance is not backend equivalence and not PMS Base validation.

### 15.23 Trace Conformance

Trace conformance checks observed execution against PMS-IR expectations.

Inputs:

```text
PMS-IR program
runtime trace
trace schema
runtime profile
property set
```

Trace conformance asks:

```text
Does this observed trace correspond to an admissible execution of this IR?
```

Checks:

```text
operator order
required checks before protected actions
frame enter/exit balance
capability checks
boundary checks
policy checks
absence/trap paths
commit events
task lifecycle
channel delivery
FFI mapping
trace schema validity
```

Example trace property:

```text
No event op=Sigma commit=durable appears unless prior op=Nabla write
and backend profile supports durability.
```

Trace conformance checks whether an observed trace conforms to a declared IR/profile/property expectation.

It does not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

A trace supports bounded implementation-artifact evidence.

It does not validate PMS Base.

### 15.24 Golden Fixtures

Golden fixtures are regression artifacts.

They may include:

```text
input PMSL script
input PMS-IR program
expected diagnostics
expected JSONL trace
expected event sequence
expected validation result
expected AI proposal rejection/acceptance boundary
```

Golden fixture relation:

```text
input artifact
→ toolchain execution
→ observed output
→ compare with expected output
```

Golden fixtures establish:

```text
this toolchain version reproduces this expected behavior under this profile
```

They do not establish:

```text
PMS truth
complete semantic coverage
external validation
proof of all properties
```

Golden fixtures stabilize regression expectations.

They do not prove PMS Base, semantic completeness, or full behavioral coverage.

Golden fixtures are valuable because they stabilize implementation behavior and prevent regressions.

### 15.25 Symbolic Execution

Symbolic execution explores paths with symbolic inputs.

Symbolic state:

```text
SymbolicState = (
    path_condition,
    frame_state,
    role_state,
    policy_state,
    boundary_state,
    heap_model,
    channel_model,
    commit_model,
    trap_model,
    absence_model
)
```

Symbolic execution can check:

```text
path feasibility
missing capability paths
policy-denial paths
unhandled trap paths
commit mismatch paths
boundary violation paths
resource leak paths
```

Example query:

```text
Is there an input path such that user-controlled path reaches FS.write
outside allowed namespace?
```

Result:

```text
SAT with counterexample path
```

or:

```text
UNSAT under stated constraints
```

Symbolic execution is bounded by path explosion, abstraction choices, solver assumptions, and model fidelity.

A symbolic result is not PMS Base validation.

### 15.26 Abstract Interpretation

Abstract interpretation computes conservative approximations of program behavior.

Abstract domains may include:

```text
effect domain
capability domain
policy domain
boundary domain
absence domain
trap domain
commit domain
resource domain
task lifecycle domain
```

Example abstract effect state:

```text
EffectsSeen = { Δ, Ω, Χ, Ψ, ∇, Σ }
MayTrap = true
MayAbsent = false
CommitLevel = visible
```

Abstract interpretation can establish:

```text
all paths include Ω before protected action
all paths close handle
no path reaches host boundary
some paths may produce Λ
some paths may lack Σ_durable
```

It is useful for scalable whole-program analysis where exhaustive model checking is too expensive.

Abstract interpretation establishes properties under the chosen abstraction. It does not prove properties outside that abstraction.

### 15.27 Proof Obligations

Verification may generate proof obligations.

Examples:

```text
PO1: Every call to FS.write is preceded by Ω(fs.write) and Ψ filesystem policy check.
PO2: Every path leaving transaction frame commits or rolls back staged effects.
PO3: Every Host.call enters ForeignFrame and maps host errors.
PO4: Every spawned task is joined, cancelled, or detached under policy.
PO5: Every module reframe preserves public interface compatibility or declares migration.
```

Proof obligation form:

```text
Assumptions ⊢ Property
```

Example:

```text
A_runtime ∧ A_policy ∧ A_backend ⊢ NoUnauthorizedWrite
```

A proof obligation must state:

```text
assumptions
artifact version
semantics version
runtime profile
property
proof method
trusted base
limitations
```

Proof obligations support rigorous tooling.

They do not erase the need for claim boundaries.

A proof proves the stated property under the stated premises. It does not prove PMS Base unless PMS Base validation is itself the explicit subject of a separately designed validation program.

### 15.28 Refinement Verification

Refinement checks that a lower representation preserves a higher one.

Refinement relations:

```text
PMSL source ⊑ High-Level PMS-IR
High-Level PMS-IR ⊑ Core PMS-IR
Core PMS-IR ⊑ Executable PMS-IR
PMS-IR ⊑ runtime trace
PMS-IR ⊑ backend execution
```

Refinement property:

```text
lower artifact simulates or preserves required behavior of higher artifact
```

Example:

```text
FS.write source construct
⊑ IR sequence with Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ
```

Invalid refinement:

```text
lowering removes Ω check
lowering collapses Λ into Φ without declaration
lowering treats staged effect as committed
lowering erases boundary check
lowering treats host call as pure call
```

Refinement verification is central to compiler and backend correctness.

A refinement result must state the preserved behavior relation and the behaviors outside its scope.

### 15.29 Equivalence and Non-Equivalence

PMSL verification distinguishes equivalence from refinement, simulation, and conformance.

```text
equivalence
    both artifacts preserve the same relevant behaviors

refinement
    lower artifact preserves required higher-level behavior

simulation
    one transition system can mimic another under relation R

conformance
    artifact satisfies a specification or trace schema
```

Portability boundary:

```text
A host runtime implementation may conform to a PMSL runtime profile.
It is not therefore equivalent to PMS-OS.
```

Artifact boundary:

```text
PMS-RUST may demonstrate bounded executable PMS-STACK evidence.
It is not therefore complete PMSL/PMS-IR or PMS Base validation.
```

Verification must state which relation is being claimed.

Untyped “equivalence” language is invalid in release documentation.

### 15.30 Verification Reports

Verification output should be machine-readable and human-readable.

Report form:

```text
VerificationReport = (
    artifact_id,
    artifact_hash,
    profile,
    model,
    properties,
    result,
    counterexamples,
    assumptions,
    abstractions,
    coverage,
    limitations,
    tool_version,
    meta
)
```

Result values:

```text
proved
checked_true
checked_false
counterexample_found
unknown
inconclusive
unsupported
timeout
assumption_violation
```

A report with result `unknown`, `timeout`, `unsupported`, or `inconclusive` must not be presented as success.

Counterexample form:

```text
Counterexample = (
    path,
    states,
    transitions,
    failed_property,
    operator_labels,
    source_spans,
    explanation
)
```

Counterexamples should preserve operator labels.

Report status is part of the claim boundary. A report may support a property claim only at the result level it actually establishes.

### 15.31 Verification Diagnostics

Verification diagnostics are operator-labeled.

Example:

```text
verification failure[Ω]:

property:
    no FS.write without Ω(fs.write)

counterexample:
    n1 Δ.Resolve(FS.write)
    n2 Ψ.Check(P_log)
    n3 ∇.StdCall(FS.write)
    n4 Σ.Commit(visible_write)

missing:
    Ω.Require(fs.write)
```

Example:

```text
verification failure[Σ]:

property:
    returned value has Σ_durable<Unit>

counterexample:
    FS.write produces Σ_visible<Unit>
    no FS.sync or durable backend commit occurs
```

Example:

```text
verification failure[Χ]:

property:
    isolated module state inaccessible from outside

counterexample:
    external module reads M.internal_state through direct symbol edge
```

Diagnostics should identify:

```text
property
model
counterexample path
operator obligation
source span
assumption set
```

Verification diagnostics are tool outputs. They are not PMS Base validation.

### 15.32 AI-Assisted Verification Boundary

AI may assist verification workflows only as advisory tooling.

Permitted roles:

```text
explain counterexamples
summarize verification reports
suggest candidate properties
suggest missing assumptions
suggest likely causes of proof failure
propose test cases
propose PMS-IR fragments for host validation
draft proof-obligation text
draft simulation scenarios
```

Forbidden roles:

```text
declare property proven without verifier result
replace model checker
replace proof checker
replace verifier
replace policy engine
authorize execution
validate PMS Base
treat generated explanation as proof
```

AI-assisted verification output is advisory until checked by a formal tool, human reviewer, or declared verification artifact.

Boundary:

```text
AI explanation
→ advisory text

model checker result
→ tool result over model

proof checker result
→ formal result over premises

PMS Base validation
→ not supplied by AI, tests, traces, fixtures, gates, or implementation artifacts
```

AI may support comprehension.

It is not verification authority.

### 15.33 Verification and PMS-RUST Evidence

PMS-RUST v0.1 may support bounded executable evidence for verification-adjacent slices.

Relevant evidence areas include:

```text
opcode construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
JSONL traces
REPL/script tooling
vFS service boundaries
golden fixtures
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR verification-adjacent behavior, such as:

```text
model/dependency validation
stateful validation
validator acceptance/rejection
deterministic kernel execution
script/REPL execution
JSONL trace emission
golden fixture comparison
proposal gating
```

The correct relation is:

```text
PMSL/PMS-IR verification specification
  → defines possible assurance obligations and property classes

PMS-RUST v0.1
  → demonstrates bounded executable artifact-backed slices:
     validation, deterministic execution, traces, fixtures, gates,
     and proposal boundaries
```

Boundary:

```text
PMS-RUST strengthens the implementation/artifact claim.
It does not prove PMS Base.
It does not complete PMSL/PMS-IR verification.
It does not make tests or traces proof.
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full verifier, not the full model checker, not the full PMSL/PMS-IR implementation, and not PMS Base validation.

### 15.34 External Validation Boundary

External validation is distinct from internal tests, traces, fixtures, model checking, and proof artifacts.

External validation may include:

```text
independent reproduction
independent implementation comparison
external benchmark use
external audit
application study
cross-tool comparison
formal review by independent parties
```

External validation may support external warrant for a stated claim.

It does not automatically validate PMS Base.

External validation must state:

```text
validated artifact
claim under test
method
independent party or process
data
criteria
limitations
scope
```

A PMSL runtime passing its own tests is not external validation.

A PMS-RUST fixture passing is not external validation.

A trace matching an expected JSONL output is not external validation.

These are implementation-artifact evidence unless independently designed and claim-typed otherwise.

### 15.35 Verification Invariants

PMSL/PMS-IR maintains the following verification invariants.

```text
I1: every verification claim states its artifact, model, property, and profile
I2: every model states its assumptions and abstractions
I3: every checked property has explicit scope
I4: every result distinguishes checked_true, proved, counterexample, unknown, timeout, and unsupported
I5: every counterexample preserves operator labels where available
I6: every refinement claim states source, target, and preservation relation
I7: every equivalence claim states the behavior space over which equivalence is asserted
I8: every liveness property states fairness/resource assumptions
I9: every trace-conformance result is bounded to observed traces
I10: every golden fixture result is bounded to regression behavior
I11: every proof object is bounded to its formal premises
I12: every FFI proof states host assumptions
I13: every backend proof states backend profile assumptions
I14: every distributed or concurrency proof states scheduling/interleaving assumptions
I15: every AI-assisted verification output remains advisory unless accepted by formal tooling, human review, or declared verification artifact
I16: every artifact-backed result strengthens only the correct implementation/tooling claim
I17: no verification result silently upgrades PMS-STACK to PMS Base validation
I18: no passing test, trace, gate, fixture, model check, or proof is treated as external validation unless external validation is explicitly designed and performed
I19: every Χ property is stated as PMSL/PMS-IR boundary/reachability projection unless explicitly discussing PMS Base Χ = Distance
I20: PMS-RUST evidence supports bounded validation/execution/trace/fixture claims; it does not complete PMSL/PMS-IR verification
```

These invariants are specification-level PMSL/PMS-IR verification constraints.

They do not claim that a completed model checker, verifier, proof system, formal semantics, compiler, runtime, or backend already enforces every invariant.

### 15.36 Boundary to Debugging, Observability, and Simulation

This section defines model checking and verification.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| debugging and observability | Section 16 |
| simulation and emulation | Section 17 |
| example PMSL fragments | Section 18 |
| runtime security verification | `06_runtime_security.md` |
| distributed-system verification | `07_distributed_systems.md` |
| PMS-RUST evidence mapping | `08_relation_to_pms_rust.md` |
| non-goals and claim boundary | `09_non_goals_and_claim_boundary.md` |

The next section defines how execution becomes inspectable through debugging, traces, diagnostics, observability, and advisory analysis.

### 15.37 Architectural Consequence

The consequence of PMSL/PMS-IR model checking and verification is:

```text
PMSL and PMS-IR can support rigorous assurance workflows: model
extraction, property specification, dependency verification, type/effect
verification, frame/role/policy/boundary checking, absence/trap/commit
coverage, concurrency analysis, FFI safety checks, trace conformance,
symbolic execution, abstract interpretation, proof obligations,
refinement checks, golden fixtures, external-validation boundaries, and
verification reports.
```

The strength of this layer is precise:

```text
Verification can establish stated properties of stated artifacts under
stated assumptions.
```

The boundary is equally precise:

```text
This strengthens PMSL/PMS-IR implementation, tooling, and artifact
claims. It does not function as PMS Base validation, external validation,
or proof that PMS is complete as a theory of praxis.
```

### 15.38 Model-Checking and Verification Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL/PMS-IR model-checking and verification model specifies
implementation-layer assurance discipline: verification objects, model
extraction, transition systems, property languages, safety and liveness
properties, reachability, operator dependency verification, type/effect
verification, frame verification, role/capability verification, policy
verification, boundary verification, absence/trap verification, commit
verification, concurrency verification, FFI verification, module
verification, runtime-profile verification, trace conformance, golden
fixtures, symbolic execution, abstract interpretation, proof obligations,
refinement verification, equivalence boundaries, verification reports,
operator-labeled diagnostics, AI-assisted verification boundaries,
PMS-RUST evidence boundaries, external-validation boundaries, and
verification invariants.

This is a language model-checking / verification architecture claim.

It does not claim a completed model checker, completed verifier,
completed proof system, completed formal semantics, completed compiler,
completed runtime, completed backend, completed PMSL implementation, or
PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
opcode construction, program buffering, model validation, stateful runtime
validation, deterministic execution, JSONL traces, REPL/script tooling,
vFS service boundaries, golden fixtures, and AI proposal gating. It does
not complete PMSL/PMS-IR verification and does not validate PMS Base.
```

---

## 16. Debugging and Observability

Debugging and observability are the inspection layer of PMSL and PMS-IR.

They make execution, validation, runtime behavior, failures, policy decisions, traces, commits, absences, traps, frame transitions, task lifecycles, channel events, FFI crossings, host-service calls, module events, backend behavior, golden comparisons, and advisory analyses visible without converting visibility into proof.

The central observability claim is:

```text
PMSL/PMS-IR observability is valid when source programs, IR artifacts,
runtime states, traces, diagnostics, debug sessions, reports, and
advisory analyses preserve operator identity, source relation, frame
context, role/capability state, boundary projections, policy decisions,
absence paths, trap paths, commit state, ordering, runtime-profile
metadata, and claim-boundary status.
```

This section defines debugging and observability at PMSL/PMS-IR specification level. It does not claim that a complete debugger, complete trace viewer, complete observability stack, complete replay engine, complete audit subsystem, or complete AI-assisted diagnostic tool already exists.

PMS-RUST v0.1 demonstrates bounded executable slices: REPL/script tooling, JSONL trace/audit output, golden fixtures, validation UX, vFS service events, deterministic execution traces, and AI proposal/analysis boundaries. These strengthen the PMS-STACK implementation-artifact claim. They do not validate PMS Base.

Claim type:

```text
LANGUAGE DEBUGGING / OBSERVABILITY ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL/PMS-IR debugging and observability as
implementation-layer inspection architecture.

It does not claim a completed debugger, completed trace viewer,
completed observability stack, completed replay engine, completed audit
subsystem, completed AI-assisted diagnostic tool, completed runtime,
completed backend, completed PMSL implementation, or PMS Base validation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared trace schema, observability profile, runtime profile, debug profile, report profile, replay profile, golden-fixture profile, tool profile, conformance rule, simulation rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, runtime correctness, debugger correctness, trace completeness, backend correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR observability level, Χ is projected as module boundary, task boundary, endpoint visibility, namespace visibility, host boundary, runtime boundary, sandbox boundary, memory-domain separation, reachability control, and cross-frame transfer discipline.

Debugging and observability inspect this PMSL/PMS-IR projection.

They do not redefine Χ.

### 16.1 Role of Debugging and Observability

Debugging asks:

```text
What happened?
Where did it happen?
Which source construct produced it?
Which operator obligation was active?
Which frame, role, policy, and boundary projection applied?
Why did the program continue, trap, wait, deny, commit, roll back, or abort?
```

Observability asks the same questions across time, execution profiles, traces, modules, tasks, channels, host calls, service calls, runtime events, simulation runs, and report artifacts.

A PMSL/PMS-IR observability layer should expose:

```text
source span
IR node
operator tag
runtime event
frame context
task context
module context
role/capability context
boundary context
policy decision
effect class
absence/trap/commit state
ordering metadata
backend/runtime profile
claim-boundary metadata
```

The purpose is not merely logging.

The purpose is operator-readable execution inspection.

A debugging or observability artifact may strengthen implementation-layer confidence. It is not proof of PMS Base.

### 16.2 Observability Objects

The observability layer may inspect several artifact classes.

```text
PMSL source
typed AST
operator-typed AST
PMS-IR graph
serialized PMS-IR
runtime configuration
task state
frame stack
module graph
channel state
event queues
sync objects
policy state
capability state
boundary state
FFI state
host-service state
trace stream
diagnostic report
verification report
golden fixture output
debug session state
AI advisory report
```

Each object must preserve enough metadata to answer:

```text
which operator?
which source?
which context?
which policy?
which boundary projection?
which outcome?
which profile?
which limitation?
```

If the metadata is absent, the report must say so. Missing observability data must not be presented as full visibility.

### 16.3 Debugging vs. Observability

PMSL distinguishes debugging and observability.

```text
debugging
  → interactive or targeted inspection of a program, IR graph, trace,
    report, or runtime state

observability
  → continuous or structured emission of execution signals for later
    inspection, comparison, replay, audit, or validation
```

Debugging tools include:

```text
REPL
stepper
breakpoint engine
watch expressions
IR inspector
trace explorer
diagnostic viewer
counterexample viewer
policy decision viewer
module graph viewer
task/channel viewer
commit inspector
boundary inspector
FFI/host-call viewer
```

Observability tools include:

```text
trace emitter
JSONL event stream
audit log
runtime metrics
span system
event log
golden trace comparison
validation report
structured diagnostics
replay report
observability report
```

Both must remain operator-typed.

A debug feature may be interactive. An observability stream may be passive. Neither may bypass Ω authority, Χ-projected boundary discipline, or Ψ policy.

### 16.4 Runtime Event Model

A runtime event represents an observed execution step.

Generic event:

```text
RuntimeEvent = (
    event_id,
    tick,
    op,
    kind,
    module,
    function,
    frame,
    task,
    role,
    capabilities,
    boundary,
    policy,
    effect,
    result,
    absence?,
    trap?,
    commit?,
    source_span?,
    ir_node?,
    profile,
    meta
)
```

Minimal event:

```text
event = (
    tick,
    op,
    kind,
    result
)
```

Preferred event:

```text
event = (
    tick,
    op,
    kind,
    frame,
    role,
    policy,
    boundary,
    source_span,
    ir_node,
    result,
    profile,
    meta
)
```

The `boundary` field records a PMSL/PMS-IR boundary projection, not PMS Base Χ itself.

The event model is extensible, but the operator tag should remain first-class.

### 16.5 Operator-Labeled Events

Every runtime event should carry an operator label where meaningful.

Examples:

```text
Δ.resolve_symbol
∇.std_call
□.enter_frame
Λ.timeout
Α.expand_pattern
Ω.require_capability
Θ.schedule
Φ.raise_trap
Χ.boundary_check
Σ.commit
Ψ.policy_check
```

Example event lines:

```text
tick=1 op=Delta kind=resolve symbol=FS.write result=ok
tick=2 op=Omega kind=require capability=fs.write result=ok
tick=3 op=Psi kind=policy_check policy=P_write result=allow
tick=4 op=Nabla kind=std_call target=FS.write result=staged
tick=5 op=Sigma kind=commit profile=Σ_visible<Unit> result=ok
```

Operator-labeled events make traces analyzable instead of merely chronological.

A trace event that says only:

```text
error
```

is less useful than one that says:

```text
op=Omega result=missing_capability
```

or:

```text
op=Lambda kind=timeout expected=Message
```

### 16.6 Trace Streams

A trace stream is an ordered event sequence.

```text
trace = [ event_0, event_1, ..., event_n ]
```

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed PMSL/PMS-IR execution:

```text
trace_pmsl(runtime, observability_artifact, input_profile) ∈ L_PMS
```

For the set of possible executions under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, observability_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, observability_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, observability_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

Trace validity:

```text
trace is operator-readable
∧ layer-valid under its declared profile
∧ profile-valid under its runtime/debug schema
∧ policy-visible where required
```

Trace classes:

```text
execution trace
validation trace
diagnostic trace
policy trace
security/audit trace
FFI trace
module lifecycle trace
task/channel trace
simulation trace
verification trace
golden fixture trace
AI advisory trace
```

Trace order may be:

```text
runtime tick
logical time
scheduler order
source order
event order
distributed logical order
simulation order
```

The ordering scheme must be declared.

A concrete trace records observed execution under a declared profile. It is bounded artifact evidence. It is not proof of all possible executions and not PMS Base validation.

### 16.7 JSONL Trace Profile

A JSONL trace profile is useful for tooling and evidence-spine artifacts.

Each line represents one event.

Example:

```json
{"tick":1,"op":"Delta","kind":"resolve","symbol":"FS.write","result":"ok"}
{"tick":2,"op":"Omega","kind":"require","capability":"fs.write","result":"ok"}
{"tick":3,"op":"Psi","kind":"policy_check","policy":"P_write","decision":"allow"}
{"tick":4,"op":"Nabla","kind":"std_call","target":"FS.write","effect":"write","result":"staged"}
{"tick":5,"op":"Sigma","kind":"commit","profile":"Σ_visible<Unit>","result":"ok"}
```

A JSONL profile should define:

```text
required fields
optional fields
operator naming
event ordering
serialization stability
schema version
source-span encoding
trace truncation rules
redaction rules
audit rules
```

JSONL is an exchange format.

It is not PMS-IR itself.

```text
PMS-IR = intended operator-preserving program structure
JSONL trace = observed event stream
```

The two should be mappable where metadata exists.

A JSONL trace strengthens implementation-artifact visibility. It does not validate PMS Base.

### 16.8 Source-to-Trace Mapping

A useful debugger maps:

```text
source span
→ typed AST node
→ PMS-IR node
→ runtime event
→ trace line
```

Mapping record:

```text
SourceTraceMap = (
    source_span,
    ir_node_id,
    event_ids,
    operator,
    construct,
    profile,
    meta
)
```

This allows a user or tool to ask:

```text
which source construct produced this policy denial?
which commit corresponds to this return value?
which handler consumed this trap?
which timeout produced this Λ result?
which FFI declaration produced this host call?
which API call generated this trace record?
```

Macro and pattern expansion must preserve origin chains.

```text
source construct
→ Α pattern expansion
→ PMS-IR nodes
→ runtime events
```

This prevents reusable patterns from hiding responsibility.

Source-to-trace mapping is a debugging and accountability mechanism. It is not proof by itself.

### 16.9 Debugger Core

A PMSL debugger should expose:

```text
step by source construct
step by IR node
step by operator event
step over frame
step into frame
step out of frame
step until policy decision
step until trap
step until absence
step until commit
step until boundary crossing
step until capability check
```

Debugger state:

```text
DebugSession = (
    program,
    source_map,
    ir,
    runtime_state,
    trace,
    breakpoints,
    watches,
    profile,
    policy,
    meta
)
```

Debugger actions:

```text
run
pause
step
continue
inspect
rewind if trace/replay profile permits
set breakpoint
set watch
dump frame
dump task
dump policy
dump capability
dump boundary
dump commit state
dump trace
```

The debugger must respect policy.

Debugging is not authority bypass.

A debug session is an observability artifact under a declared profile. It is not a proof object unless paired with a formal property and verification method.

### 16.10 Breakpoints

Breakpoints may be source-level, IR-level, operator-level, or runtime-level.

Breakpoint kinds:

```text
source breakpoint
IR node breakpoint
operator breakpoint
policy breakpoint
capability breakpoint
boundary breakpoint
trap breakpoint
absence breakpoint
commit breakpoint
task breakpoint
channel breakpoint
FFI breakpoint
host-service breakpoint
```

Examples:

```text
break on op=Ψ
break on policy=P_write deny
break on Φ_trap<FileError>
break on Λ_timeout
break on Σ_durable
break on Χ host boundary
break on Ω missing capability
break on module=HostFS
break on channel=C recv
```

Breakpoint condition:

```text
Breakpoint = (
    kind,
    predicate,
    source_span?,
    ir_node?,
    operator?,
    profile,
    meta
)
```

Breakpoint evaluation is itself policy-governed when it reveals protected state.

A breakpoint is an inspection mechanism. It must not change program semantics unless the active debug profile explicitly models that intervention.

### 16.11 Watchpoints

Watchpoints observe state changes.

Watchable objects:

```text
variable
binding
frame
role
capability
policy
boundary
task state
channel queue
resource counter
commit state
foreign handle
module state
trace event
```

Example:

```text
watch capability fs.write
watch policy P_write decision
watch channel inbox depth
watch task Worker state
watch commit profile Σ_durable
```

Watchpoint event:

```text
Δ classify watched object
Ω verify observer authority
Χ check projected visibility
Ψ check debug visibility policy
Θ observe ordered state change
Σ record watch event
```

A watchpoint must not expose protected state without authority.

Watchpoint output is observability data. It is not a verification result by itself.

### 16.12 Frame Inspection

A debugger should show frame state.

Frame view:

```text
FrameView = (
    frame_id,
    frame_kind,
    module,
    function,
    bindings,
    active_policy,
    active_role,
    active_boundary,
    pending_commits,
    handlers,
    source_span
)
```

Frame operations:

```text
show frame stack
show current frame
show parent frame
show module frame
show handler frame
show foreign frame
show commit frame
```

Frame inspection helps explain:

```text
why a symbol resolved
why a binding was visible
why a policy applied
why a boundary projection was active
why a commit was required
why a handler was selected
```

Frame inspection must preserve □ context and must not leak frame-local state across policy or boundary restrictions.

### 16.13 Task and Concurrency Inspection

Concurrency debugging requires task and channel views.

Task view:

```text
TaskView = (
    task_id,
    name,
    state,
    parent,
    frame,
    role,
    boundary,
    policy,
    wait_reason,
    cancellation_state,
    result,
    trace_span
)
```

Channel view:

```text
ChannelView = (
    channel_id,
    payload_type,
    capacity,
    depth,
    senders,
    receivers,
    wait_send,
    wait_recv,
    policy,
    boundary,
    delivery_profile
)
```

Useful queries:

```text
why is task blocked?
which task owns this resource?
which channel is full?
which sender committed this message?
which receiver consumed it?
which timeout produced this absence?
which cancellation propagated here?
```

Concurrency observability must preserve Θ ordering and Λ not-ready states.

If a runtime profile cannot expose all interleavings, the report must state the visibility limit.

### 16.14 Policy and Capability Inspection

Policy debugging should show decisions, not just outcomes.

Policy decision view:

```text
PolicyDecisionView = (
    policy,
    action,
    actor_role,
    capabilities,
    target,
    boundary,
    decision,
    reason,
    source_span,
    trace_event
)
```

Capability view:

```text
CapabilityView = (
    active_role,
    required_capability,
    available_capabilities,
    scope,
    delegation_chain,
    lifetime,
    result
)
```

Example:

```text
policy P_write:
    action: FS.write("/secure/a.txt")
    decision: deny
    reason: path outside allowed prefix
    operator: Ψ
```

This is important because policy denial is not an untyped error.

It is a Ψ outcome, optionally recontextualized through Φ.

Policy inspection is not governance tribunal behavior, moral judgment, or forensic attribution. It is program/runtime constraint observability.

### 16.15 Boundary Inspection

Boundary debugging shows Χ projections.

Boundary view:

```text
BoundaryView = (
    source,
    target,
    relation,
    boundary_kind,
    transfer_profile,
    policy,
    decision,
    source_span,
    trace_event
)
```

Boundary kinds:

```text
module boundary
task boundary
sandbox boundary
host boundary
foreign frame boundary
channel endpoint boundary
shared memory boundary
distributed node boundary
tooling/AI service boundary
```

A debugger should be able to answer:

```text
why could this value cross?
why was this call denied?
which transfer profile was used?
which policy allowed or denied the boundary crossing?
which runtime profile supplied the boundary relation?
```

Version boundary:

```text
PMS Base Χ = Distance.
PMSL/PMS-IR observability shows implementation-layer Χ projections:
boundary, sandbox, isolation, visibility, reachability, host crossing,
runtime boundary, and service crossing.
```

Boundary inspection does not redefine PMS Base Χ.

### 16.16 Commit Inspection

Commit debugging shows Σ state.

Commit view:

```text
CommitView = (
    commit_id,
    commit_kind,
    subject,
    staged_effects,
    visibility,
    durability,
    status,
    rollback,
    compensation,
    policy,
    trace_events
)
```

Commit states:

```text
staged
visible
committed
durable
rolled_back
compensated
failed
```

Example query:

```text
why did this function return Σ_visible<Unit> instead of Σ_durable<Unit>?
```

The debugger should show:

```text
FS.write staged/visible write
FS.sync absent
backend durability profile
return type expectation
failed Σ obligation
```

This prevents false interpretation of effect execution as commit.

Commit inspection supports debugging and artifact evidence. It does not prove external durability outside the declared backend/profile assumptions.

### 16.17 Absence and Trap Inspection

Absence and trap debugging must keep Λ and Φ distinct.

Absence view:

```text
AbsenceView = (
    absence_id,
    expected,
    absence_kind,
    timeout?,
    wait_context,
    handler?,
    result,
    source_span,
    trace_event
)
```

Trap view:

```text
TrapView = (
    trap_id,
    trap_type,
    cause,
    payload,
    source_frame,
    handler_frame?,
    propagation?,
    recovery?,
    policy,
    source_span,
    trace_event
)
```

Example distinction:

```text
Channel.recv timeout
  → Λ_absent<Message>

Channel protocol violation
  → Φ_trap<ProtocolError>
```

A debugger that collapses both into:

```text
error
```

loses PMSL structure.

Absence and trap inspection must also preserve handler, propagation, and recovery context where available.

### 16.18 FFI and Host Observability

FFI observability shows host crossings.

Foreign call view:

```text
ForeignCallView = (
    foreign_symbol,
    host,
    abi,
    foreign_frame,
    capability,
    boundary,
    policy,
    memory_transfer,
    blocking_profile,
    error_map,
    commit_profile,
    result,
    trace_event
)
```

Host-service view:

```text
HostServiceView = (
    service,
    operation,
    request,
    response,
    boundary,
    policy,
    timeout,
    advisory?,
    trace_event
)
```

A debugger should show:

```text
which host symbol was called
which capability authorized it
which boundary was crossed
which memory transfer profile was used
how host errors were mapped
whether result was advisory, visible, durable, pending, absent, or trapped
```

Host behavior is observable through PMSL/PMS-IR boundary profiles.

It is not silently treated as native PMSL semantics.

Host interoperability does not imply PMS-OS equivalence.

### 16.19 Module Observability

Module observability shows lifecycle and linkage.

Module view:

```text
ModuleView = (
    module_path,
    state,
    imports,
    exports,
    role,
    capabilities,
    policies,
    boundary,
    version,
    lifecycle,
    resource_account,
    trace_span
)
```

Module events:

```text
module_declared
module_resolved
module_linked
module_initialized
module_active
module_trap
module_quarantined
module_reframed
module_finalized
module_unloaded
```

Module debugging should answer:

```text
why did import fail?
which export hid a trap path?
why did module initialization not commit?
which policy prevented reload?
which boundary prevented access?
which version mismatch required Φ reframe?
```

Module observability does not claim a completed module loader or package manager.

It specifies what a conformant tool/runtime profile should expose.

### 16.20 Diagnostics Integration

Diagnostics and debugging should share the same operator vocabulary.

Diagnostic form:

```text
Diagnostic = (
    severity,
    operator,
    code,
    message,
    source_span,
    ir_node,
    trace_event?,
    failed_obligation,
    notes,
    suggestions
)
```

Debug view can link:

```text
diagnostic
→ source span
→ IR node
→ trace event
→ runtime state
```

Example:

```text
error[Ω]:
    missing capability fs.write("/var/log/**")

debug:
    active_role = User
    required = LogWriter
    source = FS.write(path, data)
    trace = event 42
```

Diagnostics are not separate from observability.

They are structured explanations of failed operator obligations.

Diagnostics are tool outputs under declared profiles. They are not proof artifacts and not PMS Base validation.

### 16.21 Trace Comparison and Golden Outputs

Trace comparison supports regression and artifact stability.

Inputs:

```text
expected trace
observed trace
comparison profile
normalization rules
redaction rules
allowed nondeterminism
```

Comparison results:

```text
match
mismatch
missing event
extra event
operator mismatch
ordering mismatch
metadata mismatch
policy-decision mismatch
commit-state mismatch
```

Golden trace examples:

```text
non-event trace
integrate-consumes trace
commit-seals-frame trace
commit-seals-isolation trace
minimal timeline trace
```

Golden traces establish regression stability under a profile.

They do not prove PMS Base.

Correct claim:

```text
This trace matches the expected artifact behavior under this runtime profile.
```

Not:

```text
This trace validates PMS.
```

Golden fixtures stabilize implementation behavior. They do not prove semantic completeness or full behavioral coverage.

### 16.22 Replay and Time Travel

A deterministic runtime profile may support replay.

Replay inputs:

```text
program / IR
input events
scheduler order
timer source
random seed
runtime profile
trace
```

Replay checks:

```text
same operator sequence?
same policy decisions?
same absence outcomes?
same commits?
same traps?
same final state?
```

Replay is useful for:

```text
debugging
regression
counterexample inspection
simulation
model-checker trace reproduction
```

Replay boundary:

```text
deterministic replay proves reproducibility under captured conditions,
not correctness outside those conditions.
```

Time-travel debugging is valid only under profiles that preserve enough state or event information to reconstruct execution.

Replay strengthens artifact reproducibility claims. It is not PMS Base validation.

### 16.23 Metrics

Metrics are aggregated observability values.

Examples:

```text
task count
blocked task count
channel depth
timeout count
trap count
policy denial count
commit success/failure count
FFI call count
resource usage
trace volume
handler latency
scheduler ticks
```

Metric event:

```text
Δ classify metric
Ψ check metric visibility policy
Θ sample at declared point/order
Σ commit metric sample
```

Metrics must not replace traces where causality matters.

```text
metric = aggregate signal
trace = ordered event evidence
```

A metric can show many policy denials occurred.

A trace can show which policy denied which operation under which context.

Metrics are observability summaries. They are not proof objects.

### 16.24 Observability Policy and Redaction

Observability itself is policy-governed.

Sensitive data may include:

```text
capability tokens
foreign handles
secret values
paths
network endpoints
policy internals
user data
module state
trace payloads
AI prompts/responses
host-service responses
```

Redaction flow:

```text
Δ classify observable field
Ω verify observer authority
Χ check projected visibility boundary
Ψ apply observability policy
Σ emit redacted or full event
```

Observability policy actions:

```text
allow
redact
hash
summarize
deny
audit access
quarantine trace
```

Debugging must not become a privileged bypass.

Inspection is itself an operation subject to Ω, Χ projection, and Ψ.

A redacted trace or report must say that it is redacted. A truncated trace must say that it is truncated.

### 16.25 AI-Assisted Trace Analysis

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

A PMSL/PMS-IR toolchain may allow AI-assisted trace analysis as an optional advisory observability surface.

AI-assisted analysis may summarize:

```text
operator sequence
commit points
non-event occurrences
policy denials
trap paths
boundary crossings
capability failures
trace anomalies
candidate explanations
possible missing obligations
candidate diagnostics
simulation scenarios
```

It may not replace:

```text
static analysis
model checking
runtime validation
policy evaluation
human review
proof checking
execution authorization
```

AI analysis pipeline:

```text
trace / IR / diagnostic report
→ host-side redaction
→ task envelope construction
→ AI advisory request
→ JSON/text response
→ host-side parse
→ host-side classification
→ optional diagnostic proposal
→ human/tool acceptance
```

Authority boundary:

```text
AI observes and proposes.
Host tooling validates and classifies.
Runtime/kernel execution remains separate.
Policy remains Ψ-governed.
```

AI output status:

```text
advisory explanation
```

not:

```text
verified diagnostic
proof
policy decision
trusted executable artifact
verification evidence
PMS Base evidence
```

This is the observability counterpart of the PMS-IR AI proposal boundary in Section 13.

### 16.26 Debugging AI-Proposed Artifacts

If an AI bridge proposes PMS-IR or opcode fragments, the observability layer should make the proposal status explicit.

Trace/proposal metadata:

```text
meta.proposal_source = "ai"
meta.proposal_status = proposed | parsed | canonicalized | validated | rejected | accepted
meta.execution_status = not_executed | executed_after_acceptance
```

Required visibility:

```text
which text was proposed
which JSON envelope was parsed
which opcodes were accepted or rejected
which validation rule failed
which host-side canonicalization occurred
which runtime accepted or denied execution
```

This prevents AI-generated artifacts from being mistaken for compiler output, trusted IR, proof output, verifier output, or PMS Base evidence.

AI-proposed artifacts remain proposals until host-side parsing, canonicalization, mapping, validation, policy acceptance, and runtime/kernel acceptance occur under a declared profile.

### 16.27 Observability Reports

An observability system may emit reports.

Report types:

```text
debug report
trace report
policy report
capability report
boundary report
commit report
task report
module report
FFI report
diagnostic report
AI advisory report
golden comparison report
replay report
```

Generic report:

```text
ObservabilityReport = (
    artifact_id,
    runtime_profile,
    trace_profile,
    source_map,
    event_summary,
    operator_summary,
    failures,
    diagnostics,
    redactions,
    advisory_findings,
    limitations,
    meta
)
```

Report status:

```text
complete
partial
redacted
profile-limited
trace-truncated
advisory-only
inconclusive
```

Reports must not overstate their status.

A partial trace report is not full runtime observability.

An advisory AI report is not verification.

A redacted report is not complete evidence of all runtime causes.

A complete report under one profile is still bounded to that profile.

### 16.28 Observability and Runtime Security

Observability supports runtime security but does not replace it.

It can expose:

```text
capability checks
policy decisions
boundary crossings
FFI calls
audit commits
trap paths
resource anomalies
module lifecycle events
network events
distributed events
```

Runtime security defines enforcement, identity, trust anchors, audit/compliance semantics, and governance constraints in `06_runtime_security.md`.

Boundary:

```text
Observability makes enforcement inspectable.
Runtime security defines and enforces the security discipline.
```

An observable system is not automatically secure.

A secure system should make relevant enforcement observable under policy.

Observability policy remains program/runtime constraint handling. It is not moral judgment, forensic attribution, or governance tribunal behavior.

### 16.29 Observability and PMS-RUST Evidence

PMS-RUST v0.1 may support bounded executable evidence for observability-adjacent behavior.

Relevant evidence areas include:

```text
REPL/script execution surfaces
validation UX
operator-labeled runtime events
JSONL trace/audit output
golden fixture comparison
vFS service events
deterministic kernel execution
AI proposal and trace-analysis boundaries
```

Correct relation:

```text
PMSL/PMS-IR observability specification
  → defines inspection obligations

PMS-RUST v0.1
  → demonstrates bounded executable slices of inspection,
     tracing, validation, golden-output discipline, deterministic
     execution, and advisory AI boundaries
```

Boundary:

```text
This strengthens implementation-artifact claims.
It does not validate PMS Base.
It does not equal complete PMSL observability.
It does not prove correctness of all runtime behavior.
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full debugger, full observability stack, full verifier, full runtime, or PMS Base validation.

### 16.30 Observability Failure Paths

Observability itself can fail.

| Failure | Operator reading |
| ------- | ---------------- |
| missing source map | Δ / Λ |
| missing IR node | Δ / Λ |
| trace truncation | Λ / Ψ |
| redacted field | Ψ |
| unauthorized inspection | Ω / Ψ |
| boundary-hidden state | Χ projection / Ψ |
| trace serialization failure | Σ / Φ |
| runtime event loss | Λ / Φ |
| debugger cannot attach | Χ projection / Ω / Ψ |
| AI advisory parse failure | Δ / Φ |
| AI advisory timeout | Λ |
| golden mismatch | Δ / Θ / Σ |
| replay mismatch | Θ / Σ / Φ |

A debugging system should represent these failures rather than pretending observability is complete.

Observability failure paths must be typed. They are not grounds for silently inventing visibility.

### 16.31 Observability Invariants

PMSL/PMS-IR maintains the following debugging and observability invariants.

```text
I1: every runtime event should carry an operator label where meaningful
I2: every trace has a declared ordering profile
I3: every debug view is tied to a runtime/profile context
I4: source-to-trace mapping preserves source span and IR node where available
I5: frame, task, module, policy, role, boundary, trap, absence, and commit state are inspectable where profile and policy permit
I6: debugging does not bypass Ω authority
I7: observability respects Χ-projected boundaries
I8: observability is Ψ-policy governed
I9: trace events distinguish Λ absence from Φ trap
I10: trace events distinguish ∇ effect from Σ commit
I11: FFI trace events preserve ForeignFrame and host-boundary metadata
I12: golden trace comparison is profile-bounded
I13: replay is valid only under declared deterministic or captured-input assumptions
I14: metrics do not replace ordered traces where causality matters
I15: redaction and truncation are explicit
I16: AI-assisted trace analysis remains advisory
I17: AI-proposed artifacts remain proposals until host-validated and runtime-accepted
I18: observability reports state their completeness, redaction, profile, and limitation status
I19: traces, reports, and debug sessions strengthen implementation-artifact claims
I20: no trace, debug session, metric, golden fixture, or AI explanation functions as PMS Base validation
I21: trace conformance records observed behavior under declared profiles; it does not prove all possible behavior without stated model, coverage, or proof artifact
I22: PMS-RUST observability evidence is bounded artifact evidence; it does not complete PMSL/PMS-IR observability
```

These invariants are specification-level PMSL/PMS-IR observability constraints.

They do not claim that a completed debugger, trace viewer, replay engine, observability stack, verifier, runtime, or backend already enforces every invariant.

### 16.32 Boundary to Simulation and Emulation

This section defines debugging and observability.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| simulation and emulation | Section 17 |
| example PMSL fragments | Section 18 |
| runtime security enforcement | `06_runtime_security.md` |
| distributed trace semantics | `07_distributed_systems.md` |
| PMS-RUST artifact relation | `08_relation_to_pms_rust.md` |
| non-goals and claim boundary | `09_non_goals_and_claim_boundary.md` |

The next section defines how PMSL/PMS-IR behavior can be simulated, replayed, emulated, or executed under controlled profiles.

### 16.33 Architectural Consequence

The consequence of PMSL/PMS-IR debugging and observability is:

```text
PMSL and PMS-IR execution can be inspected as operator-typed runtime
behavior. Source constructs, IR nodes, frame transitions, role checks,
policy decisions, boundary crossings, task events, channel operations,
FFI calls, host-service calls, absences, traps, commits, diagnostics,
traces, metrics, golden comparisons, replay sessions, reports, and
AI-assisted advisory analyses remain readable as Δ–Ψ structure.
```

This gives PMSL/PMS-IR an observability model that is strong enough to support debugging, audit, regression, validation, simulation, and bounded artifact evidence while preserving the claim boundary: observability strengthens implementation-layer confidence; it does not validate PMS Base.

### 16.34 Debugging and Observability Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL/PMS-IR debugging and observability model specifies
implementation-layer inspection architecture: runtime events,
operator-labeled traces, JSONL trace profiles, source-to-trace mapping,
debugger state, breakpoints, watchpoints, frame inspection, task/channel
inspection, policy/capability inspection, boundary inspection, commit
inspection, absence/trap inspection, FFI/host observability, module
observability, diagnostics integration, trace comparison, golden outputs,
replay, metrics, observability policy/redaction, AI-assisted trace
analysis, AI-proposal observability, observability reports, runtime
security boundaries, PMS-RUST evidence boundaries, observability failure
paths, and observability invariants.

This is a language debugging / observability architecture claim.

It does not claim a completed debugger, completed trace viewer, completed
observability stack, completed replay engine, completed audit subsystem,
completed AI-assisted diagnostic tool, completed runtime, completed
backend, completed PMSL implementation, or PMS Base validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
REPL/script tooling, validation UX, deterministic execution, JSONL
traces, vFS service events, golden fixtures, and AI proposal/analysis
gating. It does not complete PMSL/PMS-IR observability and does not
validate PMS Base.
```

---

## 17. Simulation and Emulation

Simulation and emulation are controlled execution environments for PMSL and PMS-IR artifacts.

They allow PMSL programs, PMS-IR graphs, runtime configurations, module systems, task/channel interactions, FFI profiles, policy decisions, commit behavior, traces, backend mappings, golden fixtures, and fault scenarios to be executed, replayed, inspected, compared, and stress-tested under declared assumptions.

The central simulation claim is:

```text
PMSL/PMS-IR simulation is valid when a declared model executes or explores
operator-typed behavior while preserving Δ distinctions, ∇ effects,
□ frames, Λ non-events, Α patterns, Ω authority, Θ ordering, Φ traps,
Χ-projected boundaries, Σ commits, and Ψ policies as observable
simulation state.
```

The central emulation claim is:

```text
PMSL/PMS-IR emulation is valid when a lower-level executable target,
such as PMS-UM, PMS-CPU, PMS-OS, host runtime, or PMS-RUST-style opcode
program, behaves as a profile-conformant implementation of PMS-IR while
preserving operator identity, validation obligations, traceability, and
claim boundaries.
```

Simulation and emulation strengthen implementation-layer confidence. They do not validate PMS Base.

A simulator can execute a model.

An emulator can run a target.

A trace can show observed behavior.

A golden fixture can stabilize regression behavior.

None of these, by themselves, proves PMS as a complete or final grammar.

Claim type:

```text
LANGUAGE SIMULATION / EMULATION ARCHITECTURE CLAIM
```

Boundary:

```text
This section specifies PMSL/PMS-IR simulation and emulation as
implementation-layer execution, replay, and controlled-profile
architecture.

It does not claim a completed PMSL simulator, completed emulator,
completed PMS-CPU emulator, completed PMS-OS simulator, completed PMSL
runtime, completed compiler, completed distributed runtime, completed
verification system, completed PMSL implementation, or PMS Base
validation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared simulation profile, emulation profile, runtime profile, backend profile, trace schema, golden-fixture profile, tool profile, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, runtime correctness, emulator correctness, simulator correctness, backend equivalence, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR simulation and emulation level, Χ is projected as module boundary, task boundary, endpoint visibility, namespace visibility, host boundary, runtime boundary, sandbox boundary, memory-domain separation, reachability control, node/session boundary, and cross-frame transfer discipline.

Simulation and emulation execute or inspect this PMSL/PMS-IR projection.

They do not redefine Χ.

### 17.1 Role of Simulation and Emulation

Simulation and emulation provide controlled execution without requiring a complete final PMSL compiler, PMS-OS, PMS-CPU, distributed runtime, or native deployment stack.

They support:

```text
program exploration
runtime design
trace generation
debugging
model checking
golden fixtures
fault injection
policy testing
backend validation
compiler-lowering validation
teaching/examples
artifact evidence
```

They answer questions such as:

```text
What does this PMS-IR program do under profile P?
Which operator sequence is produced?
Which policy denies the transition?
Which commit becomes visible?
Which task blocks?
Which channel produces Λ?
Which trap enters Φ?
Which backend feature is unsupported?
Which trace matches the golden fixture?
```

They do not answer, by themselves:

```text
Is PMS Base validated?
Is PMS universally adequate?
Is this runtime complete?
Is every backend equivalent?
Is every possible environment captured?
```

Simulation and emulation are implementation-layer execution disciplines. Their strength comes from explicit profiles, explicit assumptions, explicit traces, and explicit boundaries.

### 17.2 Simulation vs. Emulation

PMSL distinguishes simulation from emulation.

```text
simulation
  → executes or explores an abstract model of behavior

emulation
  → executes a lower-level target as if it were the intended machine/runtime
```

Simulation examples:

```text
simulate PMS-IR transition system
simulate task/channel scheduling
simulate filesystem effects
simulate policy decisions
simulate timeouts and non-events
simulate distributed message delivery
simulate resource exhaustion
simulate FFI failure mapping
```

Emulation examples:

```text
emulate PMS-CPU instructions
emulate PMS-UM state transitions
emulate PMS-OS syscall behavior
emulate a PMSL runtime profile on a host OS
emulate PMS-IR opcode execution in deterministic kernel
```

A simulator may abstract.

An emulator must preserve the target’s observable behavior under its declared profile.

A simulator claim must state the abstraction.

An emulator claim must state the target architecture/profile it conforms to.

Neither claim implies PMS Base validation.

### 17.3 Interpretation, Simulation, Emulation, Replay

PMSL/PMS-IR tooling should distinguish four execution modes.

| Mode | Meaning |
| ---- | ------- |
| interpretation | directly executes PMS-IR or opcode nodes |
| simulation | executes an abstract or controlled model |
| emulation | executes a lower-level target conforming to an architecture |
| replay | re-executes or revalidates a captured trace/input schedule |

Examples:

```text
PMS-IR interpreter:
    run IR nodes directly

PMS-IR simulator:
    explore abstract states under controlled time/resources

PMS-CPU emulator:
    execute encoded PMS-CPU instructions

trace replay:
    compare observed events against expected operator sequence
```

All four may produce traces.

The trace must declare which mode produced it.

Mode confusion is a claim-boundary error. Interpretation is not automatically emulation. Replay is not automatically verification. Simulation is not automatically proof.

### 17.4 Simulation Objects

Simulation may operate on several objects.

```text
PMSL source fragment
typed AST
PMS-IR graph
Executable PMS-IR sequence
PMS-UM configuration
PMS-CPU instruction stream
PMS-OS syscall model
runtime configuration
module graph
task/channel graph
policy graph
FFI profile
standard-library profile
distributed node/session model
trace fixture
```

Each simulation object requires a declared profile.

```text
SimulationObject = (
    artifact,
    profile,
    assumptions,
    state_model,
    transition_rules,
    inputs,
    outputs,
    trace_schema,
    meta
)
```

A simulation without a profile is ambiguous.

A simulation report must state:

```text
what was simulated
which parts were concrete
which parts were abstract
which assumptions were active
which features were unsupported
which result was observed
```

### 17.5 Simulation State

A PMSL/PMS-IR simulation state should expose operator-relevant structure.

```text
SimulationState = (
    program_counter,
    ir_node,
    active_frame,
    active_task,
    active_module,
    active_role,
    capabilities,
    active_policy,
    active_boundary,
    heap_model,
    channel_state,
    event_queue,
    timer_state,
    commit_state,
    trap_state,
    absence_state,
    resource_state,
    foreign_state,
    trace,
    meta
)
```

The simulator may abstract some fields, but it must state the abstraction.

Example abstraction:

```text
heap_model = symbolic
network = nondeterministic bounded delay
filesystem = in-memory map
time = deterministic logical ticks
FFI = mocked host service
```

The abstraction is part of the claim.

The `active_boundary` field records a PMSL/PMS-IR boundary projection of PMS Base Χ = Distance. It is not PMS Base Χ itself.

### 17.6 Simulation Step

A simulation step is an operator-labeled transition.

```text
SimulationState --op/action--> SimulationState'
```

Generic step:

```text
Δ classify next action
□ load active frame
Ω check authority if protected
Χ check projected boundary if crossing
Ψ evaluate policy if constrained
Θ order event, schedule task, or advance time
Λ produce absence if expected event/value is missing
∇ perform simulated effect
Φ recontextualize on trap/failure
Σ commit visible simulated state
emit trace event
```

A simulation step may be deterministic or nondeterministic.

Deterministic:

```text
one next state under same input/profile
```

Nondeterministic:

```text
set of possible next states
```

Nondeterminism must be explicit.

A simulator may collapse internal implementation steps, but it may not silently erase authority, boundary, policy, absence, trap, or commit obligations.

### 17.7 Deterministic Simulation Profile

A deterministic simulation profile supports reproducibility.

Profile constraints:

```text
fixed scheduler order
fixed random seed
logical time
stable event ordering
stable serialization
controlled inputs
mocked host calls
bounded resource model
explicit absence outcomes
stable trace schema
```

Useful for:

```text
golden fixtures
regression tests
debugging
trace comparison
artifact demos
model validation
AI proposal acceptance tests
```

Example deterministic profile:

```text
profile deterministic_test {
    scheduler = source_order
    time = logical_ticks
    random = seed(0)
    host = mocked
    filesystem = in_memory
    trace = jsonl_stable
}
```

This profile can strongly support reproducible implementation evidence.

Boundary:

```text
Reproducible simulation strengthens artifact confidence.
It does not validate PMS Base.
```

Determinism is bounded by the declared profile, inputs, mocks, scheduler rule, and host-interaction constraints.

### 17.8 Nondeterministic Simulation Profile

Some systems require nondeterministic simulation.

Examples:

```text
concurrency interleavings
network delay
message loss
resource contention
host failure
timeout races
distributed node partitions
scheduler fairness variations
```

Nondeterministic profile:

```text
profile nondeterministic {
    scheduler = all_interleavings_bounded
    network = loss_delay_reorder
    time = bounded_drift
    resources = bounded_nondeterministic
}
```

Nondeterministic simulation is useful for:

```text
race exploration
deadlock detection
liveness testing
failure-mode testing
distributed-system stress
policy resilience checks
```

It must report coverage:

```text
explored states
explored transitions
bounds
unexplored paths
cutoffs
assumptions
```

A nondeterministic simulation result is bounded by its exploration strategy. It does not prove all behavior unless paired with an exhaustive state-space argument or proof artifact.

### 17.9 Time Simulation

Time simulation is Θ/Λ-governed.

Time model fields:

```text
logical_tick
wall_clock_mock
deadline_queue
timer_events
interval_events
timeout_events
scheduler_clock
drift_model
meta
```

Time step:

```text
Θ advance logical order
Δ identify due timers
Λ produce timeout if expected event absent
Σ commit timer event or absence
```

Time profiles:

```text
logical_time
deterministic_ticks
virtual_wall_clock
bounded_drift
real_host_time
manual_advance
```

PMSL simulation should distinguish:

```text
time metadata
ordering relation
deadline
timeout absence
timer event
scheduler tick
```

Time is not a hidden global authority.

It is simulated under a declared Θ profile.

`τ`-derived values may appear as metadata, but Θ remains the ordering operator.

### 17.10 Task and Scheduler Simulation

Task simulation explores task lifecycle and scheduling.

Task states:

```text
NEW
READY
RUNNING
BLOCKED
CANCELLED
COMPLETED
FAILED
DETACHED
```

Scheduler simulation fields:

```text
ready_queue
blocked_tasks
wait_reasons
priorities
fairness_policy
current_task
tick
```

Scheduler transition:

```text
Δ classify runnable tasks
Ψ apply scheduling policy
Θ select next task
Φ switch context if required
Σ commit scheduler state
```

Simulation can check:

```text
task leak
unawaited child
deadlock
starvation under profile
cancellation propagation
structured-concurrency closure
supervisor restart behavior
```

Example property:

```text
every child task completes, cancels, or detaches before parent frame exits
```

Scheduler fairness is profile-bound. A simulator must state whether fairness is assumed, explored, or not modeled.

### 17.11 Channel and IPC Simulation

Channel simulation models message delivery.

Channel state:

```text
payload_type
capacity
queue
send_waiters
recv_waiters
closed_state
delivery_profile
policy
boundary
```

Send simulation:

```text
Δ classify payload
Ω check send authority
Χ check projected endpoint visibility
Ψ check channel policy
if capacity available:
    ∇ enqueue
    Θ wake receiver
    Σ commit delivery
else:
    Λ no-space or Θ wait
```

Receive simulation:

```text
Δ classify endpoint
Ω check receive authority
Χ check projected endpoint visibility
Ψ check receive policy
if message available:
    ∇ dequeue
    Σ commit receive
else:
    Λ no-message or Θ wait
```

Simulation can vary:

```text
capacity
delivery order
receiver scheduling
loss profile
closed-channel behavior
backpressure policy
```

This makes IPC properties testable before deployment.

Channel simulation is still a profile-local model. It does not by itself claim completed PMS-OS IPC or distributed messaging.

### 17.12 Filesystem Simulation

Filesystem simulation models paths, handles, reads, writes, commits, and durability.

Filesystem model:

```text
FileSystemModel = (
    namespace,
    files,
    directories,
    handles,
    permissions,
    mount_boundaries,
    staged_writes,
    visible_writes,
    durable_writes,
    error_policy,
    meta
)
```

Filesystem operation:

```text
Δ classify path/handle/op
Ω check filesystem capability
Χ check projected namespace/mount boundary
Ψ check filesystem policy
∇ mutate simulated state
Σ commit visible or durable state
Λ missing path/no-space/no-data where declared
Φ trap on IO/profile failure
```

Simulation should distinguish:

```text
write staged
write visible
write durable
write rolled back
write failed
```

This supports tests for commit-profile correctness.

A simulated durable write is durable under the simulated backend profile. It is not proof of external storage durability outside that profile.

### 17.13 Network Simulation

Network simulation models endpoints, sessions, delivery, loss, delay, and protocols.

Network model:

```text
NetworkModel = (
    nodes,
    endpoints,
    connections,
    messages,
    routes,
    partitions,
    delay_model,
    loss_model,
    reorder_model,
    policy,
    meta
)
```

Network send:

```text
Δ classify endpoint/message
Ω check network capability
Χ check projected network boundary
Ψ check network policy
∇ enqueue network message
Θ schedule delivery
Σ commit send state
Λ no-route/no-capacity/timeout
Φ trap on protocol or connection failure
```

Network receive:

```text
Θ advance delivery schedule
Λ no-message if absent
∇ deliver/dequeue
Σ commit receive state
```

Distributed semantics belong to `07_distributed_systems.md`.

This section defines local and controlled simulation surfaces.

A local network simulation is not a distributed correctness claim unless the distributed model and assumptions are explicitly included.

### 17.14 FFI and Host Simulation

FFI simulation replaces host behavior with controlled profiles.

Host simulation profiles:

```text
mock_success
mock_failure
mock_timeout
mock_permission_denied
mock_resource_exhaustion
mock_malformed_response
record_replay
real_host_passthrough
```

Foreign call simulation:

```text
Δ classify foreign symbol
Ω verify foreign-call capability
Χ enter projected host boundary
Ψ check FFI policy
Φ reframe into simulated host
∇ produce configured host outcome
Λ/Φ/Ψ map host result
Σ integrate simulated result
```

Host simulation is useful because real host behavior may be nondeterministic, unsafe, unavailable, or too broad for testing.

Boundary:

```text
mocked host success does not prove real host success.
real host passthrough does not make host behavior PMS-OS equivalent.
```

Host simulation supports implementation testing. It does not validate host correctness unless host assumptions are modeled and checked.

### 17.15 Policy Simulation

Policy simulation evaluates Ψ decisions under controlled scenarios.

Policy model:

```text
PolicyModel = (
    policies,
    roles,
    capabilities,
    targets,
    actions,
    decisions,
    denial_modes,
    audit_modes,
    meta
)
```

Policy simulation asks:

```text
which actions are allowed?
which actions are denied?
which denials trap?
which denials audit?
which denials quarantine?
which commits require policy approval?
```

Policy transition:

```text
Δ classify action/context
Ω inspect actor capability
Χ inspect projected boundary if relevant
Ψ evaluate policy
Σ commit decision/audit if required
Φ trap if policy response requires it
```

Simulation can test:

```text
policy non-weakening
role escalation denial
boundary enforcement
module import denial
FFI restriction
audit-required behavior
```

Policy simulation is program/runtime constraint simulation. It is not moral judgment, forensic attribution, governance tribunal behavior, or PMS Base validation.

### 17.16 Resource Simulation

Resource simulation models bounded execution.

Resources:

```text
task count
heap bytes
stack bytes
channel depth
message bytes
file handles
foreign handles
timers
trace buffer
scheduler budget
network queue
storage quota
```

Resource event:

```text
Δ classify resource request
Ω check resource authority
Ψ check quota
∇ update resource counter
Σ commit resource state
Λ no-resource if recoverable
Φ trap if critical
```

Resource simulation supports:

```text
backpressure testing
quota policy testing
no-resource paths
cleanup behavior
leak detection
bounded runtime validation
```

It is essential for implementation profiles that claim bounded behavior.

Resource simulation results are bounded by the resource model and profile.

### 17.17 Fault Injection

Simulation may inject faults.

Fault classes:

```text
timeout
no-resource
policy denial
capability revocation
boundary failure
channel close
message loss
task cancellation
FFI failure
commit failure
trace failure
module load failure
network partition
host panic
AI/tooling malformed response
AI/tooling timeout
```

Fault injection form:

```text
Fault = (
    trigger,
    operator,
    target,
    outcome,
    probability_or_schedule,
    policy,
    meta
)
```

Example:

```text
at tick=10:
    inject Λ_timeout on Channel.recv(inbox)
```

Example:

```text
on FS.sync:
    inject Φ_trap<DurabilityError>
```

Fault injection is useful for verifying that error paths are real, not merely declared.

Injected faults must be traceable. Hidden fault injection invalidates replay and golden-fixture claims.

### 17.18 Simulation of Absence and Non-Events

Simulation must make Λ visible.

Λ cases:

```text
timeout
no message
no resource
no response
unsupported feature
missing path
not ready
no route
no subscriber
```

A simulator should be able to produce absence intentionally.

Example:

```text
simulate recv inbox timeout 50ms with empty inbox
→ Λ_absent<Message>
```

Absence event:

```text
RuntimeEvent {
    op: Λ,
    kind: timeout,
    expected: Message,
    context: Channel.recv(inbox)
}
```

This is important because absence is not a generic exception.

A simulator that represents absence as untyped failure loses PMSL/PMS-IR structure.

### 17.19 Simulation of Traps and Recovery

Simulation must make Φ visible.

Φ cases:

```text
IO error
policy violation trap
boundary fault
invalid payload
commit failure
task failure
foreign exception
module reframe
panic
```

Trap event:

```text
RuntimeEvent {
    op: Φ,
    kind: trap,
    trap_type: FileError,
    handler: H?,
    source_span: ...
}
```

Recovery simulation:

```text
Φ enter handler
□ create HandlerFrame
Ψ check recovery policy
∇ execute recovery
Σ commit recovered state
```

This supports testing of:

```text
handler coverage
nested traps
finally cleanup
rollback
compensation
supervisor restart
```

Trap simulation checks modeled recovery behavior. It does not prove recovery adequacy unless that property is explicitly specified and verified.

### 17.20 Simulation of Commit Semantics

Simulation must preserve Σ distinctions.

Commit states:

```text
staged
visible
committed
durable
rolled_back
compensated
failed
```

Example:

```text
FS.write(path,data)
→ Σ_visible<Unit>

FS.sync(handle)
→ Σ_durable<Unit>
```

Simulation property:

```text
return Σ_durable<Unit>
requires simulated durable commit
```

Commit simulation supports:

```text
transaction testing
rollback testing
durability-profile testing
message-delivery testing
module-link testing
trace-audit testing
```

A simulator that collapses effect execution and commit loses PMSL structure.

Commit simulation results remain backend/profile-bound. They are not external durability proof.

### 17.21 PMS-UM Simulation

PMS-UM simulation executes the abstract universal machine layer.

PMS-UM simulator state:

```text
operator word
configuration
frame state
role state
policy state
boundary state
commit state
trace
```

PMS-UM simulation is useful for:

```text
operator-sequence validation
abstract computation semantics
minimal examples
teaching
model checking
formal transition relation testing
```

A PMS-UM simulator does not need to implement CPU binary encodings, OS syscalls, PMSL source syntax, or host interop.

It tests the abstract machine layer.

PMS-UM simulation strengthens the abstract-machine implementation claim. It does not validate PMS Base.

### 17.22 PMS-CPU Emulation

PMS-CPU emulation executes virtual CPU instructions.

Emulator flow:

```text
fetch instruction
decode instruction
classify PMS_OP
check frame / role / boundary / policy
execute operator semantics
update registers/memory/state
emit trace
```

Emulator state:

```text
registers
program_counter
memory
flags
frame_table
role_state
boundary_state
policy_state
trap_state
commit_state
trace
```

PMS-CPU emulator supports:

```text
ISA validation
binary instruction decoding
trap/interrupt testing
memory-model testing
policy-denial testing
compiler-lowering testing
trace generation
```

Boundary:

```text
PMS-CPU emulation strengthens the virtual CPU implementation claim.
It does not validate PMS Base.
```

PMS-CPU emulation is architecture-level virtual CPU emulation. It does not claim fabricated hardware.

### 17.23 PMS-OS Simulation

PMS-OS simulation models kernel/runtime services.

Simulated services:

```text
process/thread/task scheduling
memory allocation
filesystem
IPC
events
timers
devices
drivers
network stack
syscalls
security policy
audit/trace
```

PMS-OS syscall simulation:

```text
Δ classify syscall
Ω verify caller authority
Χ check projected kernel/user or namespace boundary
Ψ check syscall policy
∇ perform simulated kernel effect
Σ commit result
Λ/Φ represent absence/trap/failure
```

PMS-OS simulation is useful before a complete PMS-OS exists.

It lets PMSL/PMS-IR runtimes test kernel-facing assumptions.

PMS-OS simulation does not claim completed PMS-OS implementation or host/PMS-OS equivalence.

### 17.24 PMSL Runtime Simulation

PMSL runtime simulation executes PMSL/PMS-IR under a runtime profile.

Runtime simulation includes:

```text
frame manager
task scheduler
channel runtime
policy engine
capability manager
boundary manager
commit manager
exception runtime
FFI runtime
standard-library dispatcher
trace emitter
```

Simulation checks:

```text
does the runtime preserve operator obligations?
do APIs lower correctly?
are policies enforced?
are traps handled?
are absences visible?
are commits typed?
are traces emitted?
```

This is the main simulation target for `05_pmsl_pms_ir.md`.

A PMSL runtime simulation is not the full PMSL runtime unless a concrete implementation profile explicitly claims and evidences that scope.

### 17.25 Trace and Replay Convention

PMS-IR, runtime traces, and replay artifacts are related but distinct.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed simulation or emulation run:

```text
trace_pmsl(runtime, simulation_artifact, input_profile) ∈ L_PMS
```

For the set of possible simulation or emulation runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, simulation_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, simulation_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, simulation_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

Trace replay re-runs or revalidates an execution trace.

Replay inputs:

```text
PMS-IR program
trace file
input events
runtime profile
scheduler profile
host mock profile
expected outputs
```

Replay modes:

```text
validate trace only
re-execute deterministically
compare expected vs observed
minimize counterexample
explain divergence
```

Replay checks:

```text
operator sequence
ordering
policy decisions
capability checks
boundary checks
absence/trap paths
commit states
final state
```

Replay boundary:

```text
trace replay shows reproducibility or conformance for captured behavior.
It does not show all possible behaviors.
```

Trace conformance checks whether an observed trace conforms to a declared IR/profile/property expectation. It does not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

### 17.26 Golden Simulation Fixtures

Golden fixtures are fixed expected simulation artifacts.

Fixture components:

```text
input script or PMS-IR
runtime profile
expected trace
expected diagnostics
expected final state
expected rejection reason
expected AI proposal handling
```

Examples:

```text
non-event fixture
integrate-consumes fixture
commit-seals-frame fixture
commit-seals-isolation fixture
minimal-timeline fixture
script-rejects-service-command fixture
```

Golden fixture claim:

```text
artifact behavior is reproducible under this profile and expected output.
```

Boundary:

```text
golden fixtures support regression and artifact stability.
They do not prove PMS Base or complete semantic coverage.
```

Golden fixtures stabilize expected behavior. They do not establish truth, external validation, semantic completeness, or full behavioral coverage.

### 17.27 Simulation and Model Checking

Simulation and model checking are related but distinct.

```text
simulation
  → execute selected paths or scenarios

model checking
  → explore state space against properties
```

Simulation may generate:

```text
example traces
counterexample traces
test cases
coverage data
state snapshots
```

Model checking may use simulation models as transition systems.

The relation:

```text
simulator model
→ transition system
→ model checker
→ property result
```

Boundary:

```text
a simulator run is not exhaustive unless explicitly used in an exhaustive
or bounded state-space exploration with declared bounds.
```

A simulation trace can support debugging and artifact evidence. A model-checking result can support a property claim under model assumptions. Neither validates PMS Base.

### 17.28 Simulation and Verification Reports

Simulation may produce reports.

Report form:

```text
SimulationReport = (
    artifact_id,
    profile,
    mode,
    assumptions,
    inputs,
    explored_paths,
    trace,
    final_state,
    diagnostics,
    coverage,
    failures,
    unsupported_features,
    limitations,
    meta
)
```

Result statuses:

```text
completed
failed
rejected
timeout
unsupported
inconclusive
counterexample
matched_golden
mismatched_golden
```

A report must state:

```text
what was simulated
under which profile
with which assumptions
with which unsupported features
what the result means
what it does not mean
```

`completed` means completed under the declared simulation profile. It does not mean verified, proven, externally validated, or PMS Base-validated.

### 17.29 Simulation Profiles

Standard simulation profiles may include:

```text
minimal_operator
deterministic_runtime
concurrency_bounded
filesystem_in_memory
host_mocked
ffi_denied
policy_strict
resource_bounded
trace_jsonl
golden_fixture
distributed_local_cluster
pms_cpu_emulator
pms_os_syscall_model
```

Example:

```text
profile golden_fixture {
    runtime = deterministic_runtime
    time = logical_ticks
    scheduler = source_order
    fs = in_memory
    host = mocked
    ffi = denied
    trace = jsonl_stable
}
```

Example:

```text
profile concurrency_bounded {
    scheduler = all_interleavings_bound(4)
    channels = bounded_capacity
    time = logical
    trace = event_graph
}
```

Profiles make simulation claims precise.

A profile is a claim boundary. It defines what is inside the result and what remains outside it.

### 17.30 Simulation Diagnostics

Simulation diagnostics are operator-labeled.

Example:

```text
simulation error[Ω]:
    path reaches FS.write without active fs.write capability
```

Example:

```text
simulation error[Λ]:
    recv timeout produced Λ_absent<Message>, but source path lacks handler
```

Example:

```text
simulation error[Σ]:
    expected Σ_durable<Unit>, observed Σ_visible<Unit>
```

Example:

```text
simulation error[Χ]:
    FFI call attempted without ForeignFrame boundary
```

Diagnostics should include:

```text
profile
state
transition
operator
source span
IR node
trace event
assumption context
```

Simulation diagnostics are tool outputs under declared profiles. They are not proof artifacts by themselves.

### 17.31 AI-Assisted Simulation Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

AI may assist simulation workflows only as advisory tooling.

Permitted AI roles:

```text
summarize simulation reports
explain trace divergence
suggest fault-injection scenarios
suggest missing test cases
suggest possible model abstractions
propose PMS-IR scenarios for host validation
draft candidate diagnostics
draft candidate golden fixtures
```

Forbidden AI roles:

```text
define simulation semantics
replace simulator
replace model checker
declare verification success
authorize execution
replace policy engine
convert proposal into trusted executable artifact
serve as verification evidence
validate PMS Base
```

Pipeline:

```text
AI proposal
→ host parse
→ canonicalization
→ PMSL/PMS-IR/opcode mapping
→ validation
→ simulation profile selection
→ simulation execution
→ trace/report
```

Authority boundary:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI suggestions remain advisory until accepted and validated by host tooling.

AI output is not trusted executable code, compiler authority, simulator authority, verification evidence, policy authority, or PMS Base validation.

### 17.32 Simulation and PMS-RUST Evidence

PMS-RUST v0.1 may support bounded executable evidence for simulation/emulation-adjacent behavior.

Relevant evidence areas include:

```text
operator-tagged program construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
REPL/script execution
JSONL trace/audit output
golden fixtures
vFS service events
AI proposal gating
```

This can strengthen implementation-artifact claims for selected PMSL/PMS-IR simulation-adjacent behavior, such as:

```text
deterministic operator execution
profile-local validation
stateful validation
trace emission
scripted scenario execution
vFS-like service events
golden fixture comparison
AI proposal gating
```

Correct relation:

```text
PMSL/PMS-IR simulation specification
  → defines simulation/emulation obligations and profiles

PMS-RUST v0.1
  → demonstrates bounded executable artifact-backed slices of those
     obligations under specific runtime/tooling constraints
```

Boundary:

```text
This strengthens the PMS-STACK implementation-artifact claim.
It does not validate PMS Base.
It does not equal complete PMSL simulation, complete PMS-OS,
complete PMS-CPU, complete PMSL compiler, or distributed runtime.
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL simulator, not the full emulator, not complete PMS-CPU, not complete PMS-OS, not complete distributed runtime, and not PMS Base validation.

### 17.33 Simulation Failure Paths

Simulation can fail.

| Failure | Operator reading |
| ------- | ---------------- |
| invalid artifact | Δ / Ψ |
| unsupported feature | Λ / Φ / Ψ |
| missing runtime profile | Δ / Λ |
| profile conflict | Ψ |
| nondeterminism unbounded | Θ / Ψ |
| resource model exhausted | Λ / Ψ / Φ |
| host mock absent | Λ |
| FFI denied | Χ projection / Ψ |
| trace serialization failure | Σ / Φ |
| golden mismatch | Δ / Θ / Σ |
| replay divergence | Θ / Φ / Σ |
| model abstraction gap | Ψ / report limitation |
| simulator invariant failure | Φ / Ψ |
| AI proposal rejected | Ψ / validation rejection |
| timeout | Λ / Θ |

A simulation failure should be reported as part of the artifact result, not hidden as generic failure.

Simulation failure paths must preserve operator identity where the profile supports it.

### 17.34 Simulation and Emulation Invariants

PMSL/PMS-IR maintains the following simulation and emulation invariants.

```text
I1: every simulation has a declared artifact and profile
I2: every simulation profile declares assumptions and abstractions
I3: every simulation step is operator-labeled where meaningful
I4: every runtime event preserves operator identity where profile supports tracing
I5: every simulated frame, task, module, channel, policy, boundary, trap, absence, and commit is visible in simulation state where relevant
I6: deterministic simulations are reproducible under the same inputs/profile
I7: nondeterministic simulations declare bounds, coverage, and unexplored paths
I8: time simulation distinguishes Θ ordering from time metadata
I9: absence simulation preserves Λ as non-event, not generic error
I10: trap simulation preserves Φ as recontextualization
I11: commit simulation distinguishes staged, visible, durable, rolled back, compensated, and failed states
I12: FFI simulation uses explicit host/foreign profiles
I13: resource simulation exposes no-resource and backpressure paths
I14: fault injection is explicit and traceable
I15: PMS-CPU emulation preserves instruction/operator traceability
I16: PMS-OS simulation preserves syscall/frame/role/boundary/policy/commit semantics
I17: replay claims are bounded to captured input and profile
I18: golden fixtures support regression, not truth
I19: AI-assisted simulation support remains advisory until host-validated
I20: simulation and emulation strengthen implementation-artifact claims and do not function as PMS Base validation
I21: trace conformance records observed behavior under declared profiles; it does not prove all possible behavior without stated model, coverage, or proof artifact
I22: PMS-RUST evidence supports bounded simulation/emulation-adjacent claims; it does not complete PMSL/PMS-IR simulation, PMS-CPU, PMS-OS, or distributed runtime
```

These invariants are specification-level PMSL/PMS-IR simulation and emulation constraints.

They do not claim that a completed simulator, emulator, runtime, compiler, PMS-CPU emulator, PMS-OS simulator, distributed runtime, or verifier already enforces every invariant.

### 17.35 Boundary to Example PMSL Fragments

This section defines simulation and emulation.

It does not fully define:

| Topic | Primary section |
| ----- | --------------- |
| concrete PMSL examples | Section 18 |
| distributed-system simulation | `07_distributed_systems.md` |
| runtime-security simulation | `06_runtime_security.md` |
| PMS-RUST artifact mapping | `08_relation_to_pms_rust.md` |
| non-goals and claim boundary | `09_non_goals_and_claim_boundary.md` |

The next section provides PMSL fragments that illustrate the language, runtime, IR, analysis, tracing, and simulation structures defined in this document.

### 17.36 Architectural Consequence

The consequence of PMSL/PMS-IR simulation and emulation is:

```text
PMSL and PMS-IR can be executed, explored, replayed, emulated, and
stress-tested under declared profiles before complete native deployment.
Tasks, channels, filesystems, networks, FFI calls, policies, resources,
traps, absences, commits, modules, traces, backend mappings, golden
fixtures, and AI-assisted scenario proposals become observable
operator-typed simulation state rather than opaque runtime behavior.
```

The strength of this layer is precise:

```text
Simulation and emulation make PMSL/PMS-IR behavior operational,
reproducible, inspectable, and testable under explicit assumptions.
```

The boundary is equally precise:

```text
This strengthens PMS-STACK implementation-layer architecture and
artifact claims. It does not function as PMS Base validation, proof of
theory, universal runtime adequacy, or equivalence between host systems
and PMS-OS.
```

### 17.37 Simulation and Emulation Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL/PMS-IR simulation and emulation model specifies
implementation-layer controlled execution architecture: simulation
objects, simulation state, simulation steps, deterministic and
nondeterministic profiles, time simulation, task/scheduler simulation,
channel/IPC simulation, filesystem simulation, network simulation, FFI
and host simulation, policy simulation, resource simulation, fault
injection, absence simulation, trap/recovery simulation, commit
simulation, PMS-UM simulation, PMS-CPU emulation, PMS-OS simulation,
PMSL runtime simulation, trace/replay conventions, golden simulation
fixtures, simulation/model-checking boundaries, reports, profiles,
diagnostics, AI-assisted simulation boundaries, PMS-RUST evidence
boundaries, failure paths, and simulation/emulation invariants.

This is a language simulation / emulation architecture claim.

It does not claim a completed PMSL simulator, completed emulator,
completed PMS-CPU emulator, completed PMS-OS simulator, completed PMSL
runtime, completed compiler, completed distributed runtime, completed
verification system, completed PMSL implementation, or PMS Base
validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged program construction, program buffering, model validation,
stateful runtime validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR simulation, PMS-CPU
emulation, PMS-OS simulation, distributed simulation, or PMS Base
validation.
```

---

## 18. Example PMSL Fragments

This section provides example PMSL fragments.

The examples are written as literate specification fragments. They are not intended to replace the grammar, runtime, PMS-IR, static analysis, model-checking, observability, simulation, or verification sections above. Their role is to show how ordinary-looking PMSL code remains operator-typed and how language-level constructs lower into PMS-IR, runtime behavior, diagnostics, traces, validation obligations, and evidence boundaries.

The central example claim is:

```text
A PMSL example is useful when it shows not only source syntax, but also
the Δ–Ψ obligations carried by the fragment: distinction, effect, frame,
absence, pattern, authority, ordering, recontextualization, boundary
projection, commit, and policy.
```

These fragments are examples of the PMSL/PMS-IR architecture.

They do not claim final parser syntax, complete compiler implementation, complete runtime availability, complete standard-library implementation, complete verifier, complete simulator, or complete PMSL implementation.

Concrete profiles may choose different surface spellings while preserving the same PMS-IR obligations.

Claim type:

```text
LANGUAGE EXAMPLE / PMSL-FRAGMENT ILLUSTRATION ARCHITECTURE CLAIM
```

Boundary:

```text
This section illustrates PMSL/PMS-IR architecture through source-like
fragments, operator readings, PMS-IR sketches, diagnostics, trace
sketches, simulation fixtures, and boundary examples.

It does not claim final PMSL grammar, completed parser, completed
compiler, completed runtime, completed standard library, completed
verifier, completed simulator, completed PMSL implementation, or PMS
Base validation.

It strengthens the PMS-STACK language/runtime/IR architecture claim.
It does not validate PMS Base.
```

Validation in this section means acceptance or rejection under a declared grammar profile, type/effect rule, PMS-IR schema, static-analysis profile, runtime profile, simulation profile, trace profile, tool profile, conformance rule, or verification profile.

It does not mean external validation of PMS Base.

It does not by itself prove semantic completeness, implementation correctness, runtime correctness, compiler correctness, backend correctness, theoretical adequacy, or full behavioral coverage.

PMS Base 1.3 defines:

```text
Χ = Distance
```

At PMSL/PMS-IR example level, `Χ(...)` denotes the implementation-layer projection of Distance into boundary, visibility, reachability, host boundary, namespace boundary, task boundary, module boundary, sandbox boundary, endpoint boundary, and cross-frame transfer discipline.

The examples do not redefine Χ.

### 18.1 Reading Conventions

Each example may include four views.

```text
PMSL fragment
operator reading
PMS-IR sketch
analysis / runtime / trace notes
```

Pseudo-identifiers such as:

```text
Δ_path
Ω_write
Σ_visible
Φ_io
Λ_timeout
```

are explanatory labels. They are not required PMSL keywords.

The examples use these conventions:

```text
policy with P { ... }       activates Ψ policy scope
frame enter F { ... }       enters □ frame
requires Ω(x)               declares required authority/capability
effects(...)                declares operator effects
commit Σ { ... }            declares integration/commit region
trap on Φ_trap<E> { ... }   declares recontextualization handler
Λ_absent<T>                 represents absence/non-event
Σ_visible<T>                represents visible commit
Σ_durable<T>                represents durable commit
boundary Χ(x)               declares a PMSL/PMS-IR boundary projection
```

The examples distinguish:

```text
∇ effect
Σ commit

Λ absence
Φ trap

Ω authority
Ψ policy

Χ projection
□ frame
```

This distinction is the point of the examples.

### 18.2 Trace Convention in Examples

Trace sketches in this section are concrete observed event sequences.

They are not PMS-IR themselves and are not proof objects.

In this document, `Trace` may also name a PMSL standard-library or tooling domain, such as:

```text
Trace.emit
TraceEvent
TraceSpan
TraceStream
```

This is distinct from the mathematical trace convention used across PMS-STACK.

For one concrete observed example run:

```text
trace_pmsl(runtime, example_artifact, input_profile) ∈ L_PMS
```

For the set of possible runs under a declared PMSL/PMS-IR/runtime profile:

```text
Trace_pmsl(runtime, example_artifact, input_profile) ⊆ L_PMS
```

Under active policy:

```text
trace_pmsl(runtime, example_artifact, input_profile, Ψ) ∈ L_PMS,Ψ
```

and:

```text
Trace_pmsl(runtime, example_artifact, input_profile, Ψ) ⊆ L_PMS,Ψ
```

A trace sketch records expected or observed behavior under a declared profile. It is bounded artifact evidence when produced by a tool/runtime. It is not proof of all possible behavior and not PMS Base validation.

### 18.3 Minimal Frame

This fragment shows the smallest useful PMSL structure: enter a frame, compute a value, and leave the frame.

```pmsl
fn hello_frame()
    -> Result<Int, Φ_trap<FrameError>>
    effects(Δ, Ω, □, Χ, ∇, Σ, Φ)
{
    frame enter F_user
        requires Ω(role.user)
        boundary Χ(user_space)
    {
        let x: Int = 1 + 2

        return x
    }
}
```

Operator reading:

```text
Δ classify function hello_frame
Ω verify user role authority
Χ establish projected user-space boundary
□ enter F_user
Δ classify binding x
∇ evaluate 1 + 2
Σ integrate x into frame
Σ integrate return value
□ leave F_user
Φ trap if frame entry/exit fails
```

PMS-IR sketch:

```text
IR.Function {
    name: hello_frame,
    effects: [Δ, Ω, □, Χ, ∇, Σ, Φ],
    body: [
        IR.RequireCapability(op=Ω, capability=role.user),
        IR.BoundaryCheck(op=Χ, boundary=user_space),
        IR.EnterFrame(op=□, frame=F_user),
        IR.Bind(op=Δ/Σ, name=x, value=IR.Add(op=∇, 1, 2)),
        IR.Return(op=Σ, value=x),
        IR.ExitFrame(op=□)
    ]
}
```

Analysis notes:

```text
valid because:
    frame is explicit
    role is explicit
    boundary projection is explicit
    effect is explicit
    return integrates through Σ

invalid if:
    frame entry has no authority
    boundary projection is undeclared
    return value escapes a closed invalid frame
```

The boundary marker `Χ(user_space)` is a PMSL/PMS-IR projection of PMS Base Χ = Distance. It is not a new base operator.

### 18.4 Policy-Gated Filesystem Write

This fragment shows policy, authority, namespace boundary, write effect, visible commit, and trap handling.

```pmsl
policy P_log_write {
    allow FS.write where path.starts_with("/var/log/")
    deny  FS.write where path.starts_with("/secure/")
}

fn write_log(path: Path, data: Bytes)
    -> Result<Σ_visible<Unit>, Λ_absent<Space | Path> | Φ_trap<FileError | PolicyViolation>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(fs.write("/var/log/**"))
{
    policy with P_log_write {
        frame enter F_log
            requires Ω(role.log_writer)
            boundary Χ(log_namespace)
        {
            commit Σ {
                FS.write(path, data)
            }
        }
    }
}
```

Operator reading:

```text
Δ classify path, data, and operation
Ω verify fs.write("/var/log/**")
Ω verify role.log_writer
Χ check projected log namespace visibility
Ψ activate P_log_write
Ψ evaluate path policy
∇ perform write or stage write
Σ commit visible write result
Φ trap on IO failure or policy violation
Λ represent no-space / missing target if declared by profile
```

PMS-IR sketch:

```text
IR.PolicyScope(op=Ψ, policy=P_log_write)
  IR.RequireCapability(op=Ω, capability=fs.write("/var/log/**"))
  IR.BoundaryCheck(op=Χ, boundary=log_namespace)
  IR.EnterFrame(op=□, frame=F_log)
  IR.Commit(op=Σ, profile=Σ_visible<Unit>)
    IR.StdCall(
        op=∇,
        domain=FS,
        function=write,
        effects=[Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ]
    )
```

Static analysis checks:

```text
path policy is active
write capability is present
namespace boundary projection is declared
FS.write trap path is declared
Λ no-space / missing-target path is declared or handled
Σ_visible is not misrepresented as Σ_durable
```

Important boundary:

```text
FS.write gives visible commit under this profile.
It does not imply durable storage unless FS.sync or a durable profile occurs.
```

### 18.5 Durable Filesystem Write

This fragment adds durability.

```pmsl
fn write_log_durable(path: Path, data: Bytes)
    -> Result<Σ_durable<Unit>, Λ_absent<Space | Path> | Φ_trap<FileError | PolicyViolation>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(fs.write("/var/log/**"))
    requires Ω(fs.sync)
{
    policy with P_log_write {
        let h = FS.open(path, OpenMode.append)?
        FS.write(h, data)?
        FS.sync(h)?
        FS.close(h)?
        return Σ_durable(Unit)
    }
}
```

Operator reading:

```text
FS.open:
    Δ classify path/mode
    Ω verify open/write authority
    Χ check projected namespace boundary
    Ψ check policy
    ∇ open handle
    Σ commit handle state
    Λ missing path if declared
    Φ trap on open failure

FS.write:
    ∇ perform/stage write
    Σ_visible mark visible write

FS.sync:
    ∇ flush backend state
    Σ_durable commit durability under backend profile

FS.close:
    ∇ close handle
    Σ commit lifecycle closure
```

Verification property:

```text
Returned Σ_durable<Unit>
    ⇒ path includes FS.sync or backend durable-write profile.
```

Counterexample avoided:

```text
FS.write alone cannot satisfy Σ_durable<Unit>.
```

The durable result remains profile-bound. It is not external proof of physical storage durability outside the declared backend/runtime assumptions.

### 18.6 Absence-Aware Channel Receive

This fragment shows Λ as absence, not exception.

```pmsl
fn poll_inbox(inbox: Receiver<Message>)
    -> Result<Message, Λ_absent<Message> | Φ_trap<RecvError>>
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
    requires Ω(channel.recv<Message>(inbox))
{
    let msg = Channel.recv(inbox, timeout = 50ms)?

    return msg
}
```

Operator reading:

```text
Δ classify receiver and payload type
Ω verify receive capability
Χ check projected endpoint visibility
Ψ check channel policy
Θ wait up to 50ms
Λ produce Λ_absent<Message> if no message arrives
∇ dequeue if message exists
Σ integrate received message
Φ trap on closed channel, invalid payload, or runtime failure
```

PMS-IR sketch:

```text
IR.ApiCall {
    domain: Channel,
    function: recv,
    op: Θ/∇,
    effects: [Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ],
    absence_profile: Λ_absent<Message>,
    trap_profile: Φ_trap<RecvError>,
    commit_profile: receive_commit
}
```

Trace sketch:

```text
tick=1 op=Delta  kind=classify target=inbox result=ok
tick=2 op=Omega  kind=require capability=channel.recv<Message> result=ok
tick=3 op=Chi    kind=boundary_check endpoint=inbox result=ok
tick=4 op=Psi    kind=policy_check policy=channel_policy result=allow
tick=5 op=Theta  kind=wait timeout=50ms
tick=6 op=Lambda kind=absence expected=Message reason=timeout
```

This is a successful absence path, not a runtime exception.

### 18.7 Channel Send / Receive Pair

This fragment shows delivery commit.

```pmsl
fn send_message(outbox: Sender<Message>, msg: Message)
    -> Result<Σ_delivery<Unit>, Λ_absent<Space> | Φ_trap<SendError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Θ, Λ, Σ, Φ)
    requires Ω(channel.send<Message>(outbox))
{
    Channel.send(outbox, msg)
}
```

Operator reading:

```text
Δ classify sender and message type
Ω verify send capability
Χ check projected endpoint visibility
Ψ check channel policy
∇ enqueue message
Θ signal waiting receiver
Σ commit delivery state
Λ no-space if bounded channel full
Φ trap on closed channel or protocol failure
```

Corresponding receive:

```pmsl
fn wait_message(inbox: Receiver<Message>)
    -> Result<Message, Λ_absent<Message> | Φ_trap<RecvError>>
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, ∇, Σ, Φ)
    requires Ω(channel.recv<Message>(inbox))
{
    Channel.recv(inbox, timeout = 500ms)
}
```

Verification property:

```text
received(msg)
    ⇒ prior Σ_delivery(msg)
```

Boundary property:

```text
message crosses channel boundary only if Χ permits endpoint reachability
under the active PMSL/PMS-IR boundary profile and Ψ permits channel transfer.
```

### 18.8 Task Group with Cancellation

This fragment shows structured concurrency and cancellation.

```pmsl
fn run_workers(jobs: List<Job>)
    -> Result<List<ResultValue>, Φ_trap<TaskGroupError | Cancelled>>
    effects(Δ, Ω, □, Χ, Ψ, Θ, Λ, Φ, ∇, Σ, Α)
    requires Ω(task.spawn)
    requires Ω(task.await)
{
    let cancel = Cancellation.token()

    TaskGroup.scope<ResultValue>(policy = CancelOnFirstFailure) as group {
        for job in jobs {
            TaskGroup.spawn(group) {
                Cancellation.check(cancel)?
                process_job(job)
            }
        }

        let results = TaskGroup.await_all(group)?

        return results
    } trap on Φ_trap<TaskGroupError> as e {
        Cancellation.cancel(cancel)?
        return Φ_trap<TaskGroupError>(e)
    }
}
```

Operator reading:

```text
Α structured-concurrency pattern
□ create TaskGroupFrame
Ω verify spawn/await authority
Χ establish projected task boundary
Ψ activate group policy CancelOnFirstFailure
Θ schedule worker tasks
Φ recontextualize on child failure
Σ commit task completion results
Φ cancellation path recontextualizes remaining lifecycle
Σ commit cancelled/closed group state
```

Static analysis checks:

```text
child tasks are group-owned
group cannot exit while children remain live
cancellation path exists
trap path is declared
task spawn authority exists
await authority exists
```

Liveness property under fair scheduler:

```text
every spawned child eventually completes, traps, cancels, or is closed by group policy.
```

The liveness property is valid only under declared scheduler, resource, and cancellation assumptions.

### 18.9 Module with Exported Capability Surface

This fragment shows module frame, exports, capabilities, and policy.

```pmsl
module AppLog
    requires role LogModule
    requires policy P_log_write
    boundary Χ(log_namespace)
{
    export interface LogService {
        fn write(path: Path, data: Bytes)
            -> Result<Σ_visible<Unit>, Λ_absent<Space | Path> | Φ_trap<FileError | PolicyViolation>>
            effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
            requires Ω(fs.write("/var/log/**"))
    }

    export fn write(path: Path, data: Bytes)
        -> Result<Σ_visible<Unit>, Λ_absent<Space | Path> | Φ_trap<FileError | PolicyViolation>>
        effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
        requires Ω(fs.write("/var/log/**"))
    {
        policy with P_log_write {
            FS.write(path, data)
        }
    }
}
```

Operator reading:

```text
Δ classify module AppLog
□ create ModuleFrame(AppLog)
Ω assign LogModule role
Ψ attach P_log_write
Χ establish projected log namespace boundary
Σ commit export interface
Σ commit exported function surface
```

Module analysis checks:

```text
exported function exposes full effect profile
exported capability requirement is explicit
module boundary projection is explicit
module policy is active during implementation
export does not leak broader FS authority
```

PMS-IR sketch:

```text
IR.Module(op=□, path=AppLog)
  IR.PolicyAttach(op=Ψ, policy=P_log_write)
  IR.BoundaryProfile(op=Χ, boundary=log_namespace)
  IR.Export(op=Σ, symbol=LogService.write)
  IR.Export(op=Σ, symbol=write)
```

The module boundary is a PMSL/PMS-IR projection of PMS Base Χ = Distance. It does not imply completed OS sandboxing unless the runtime/backend profile provides and evidences it.

### 18.10 FFI Host Service Wrapper

This fragment wraps host behavior without treating host behavior as PMSL authority.

```pmsl
module HostClock
    boundary Χ(host_service)
    requires policy P_host_clock
{
    foreign fn host_now()
        -> Result<HostInstant, Φ_trap<HostError>>
        effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
        requires Ω(host.clock.read)

    export fn now()
        -> Result<Instant, Φ_trap<TimeError>>
        effects(Δ, Ω, Χ, Φ, ∇, Σ, Ψ)
        requires Ω(time.now)
    {
        let h = host_now()?
        return map_host_instant(h)
    }
}
```

Operator reading:

```text
Δ classify foreign symbol host_now
Ω verify host.clock.read
Χ enter projected host boundary
Ψ check P_host_clock
Φ reframe into HostClock ForeignFrame
∇ execute host service call
Φ map HostError to TimeError if needed
Σ integrate Instant result
```

FFI analysis checks:

```text
foreign symbol declared
host boundary exists
host capability exists
policy exists
host error is mapped
result is converted before export
host behavior is not treated as PMSL-native truth
```

Boundary:

```text
HostClock.now may provide a runtime time source.
It does not make host OS behavior equivalent to PMS-OS.
```

### 18.11 Transaction with Rollback

This fragment shows staged IO, commit, and rollback.

```pmsl
fn replace_file(path: Path, data: Bytes)
    -> Result<Σ_durable<Unit>, Λ_absent<Space | Path> | Φ_trap<FileError | CommitError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(fs.write(path))
    requires Ω(fs.sync)
{
    transaction IO.transaction(policy = AtomicReplace) {
        let tmp = FS.temp_near(path)?
        FS.write(tmp, data)?
        FS.sync(tmp)?
        FS.rename(tmp, path)?
        FS.sync_parent(path)?
        commit Σ_durable
    } rollback on Φ_trap<FileError | CommitError> as e {
        FS.remove_if_exists(tmp)
        return Φ_trap<CommitError>(e)
    }
}
```

Operator reading:

```text
□ enter TransactionFrame
Ψ activate AtomicReplace policy
∇ stage temp write
Σ commit temp durability
∇ stage rename
Σ commit parent/directory durability
Σ commit final durable replacement
Φ enter rollback on error
∇ remove temp if possible
Σ commit rollback/cleanup state
```

Commit analysis checks:

```text
staged state is not final state
rename is not durable until parent sync/profile commit
rollback path exists
trap path is declared
Σ_durable is justified by sync steps or backend profile
```

The transaction example specifies commit discipline under a declared backend/runtime profile. It does not prove external reversibility or storage durability outside that profile.

### 18.12 Upgrade / Reframe Example

This fragment shows Φ recontextualization for module upgrade.

```pmsl
module PolicyPackV1 {
    export policy P_access_v1 { ... }
}

module PolicyPackV2 {
    export policy P_access_v2 { ... }

    migration from PolicyPackV1 {
        fn migrate_state(old: PolicyStateV1)
            -> Result<PolicyStateV2, Φ_trap<MigrationError>>
            effects(Δ, Ω, Ψ, Φ, ∇, Σ)
    }
}

fn upgrade_policy_pack()
    -> Result<Σ_local<Unit>, Φ_trap<MigrationError | PolicyViolation>>
    effects(Δ, Ω, Ψ, Φ, Χ, ∇, Σ)
    requires Ω(module.reframe)
{
    reframe PolicyPackV1 to PolicyPackV2 {
        Ψ check UpgradePolicy
        migrate_state(...)
        Σ commit module reframe
    }
}
```

Operator reading:

```text
Δ classify old and new module frames
Ω verify module.reframe authority
Ψ check UpgradePolicy
Φ enter reframe context
Χ preserve or transform projected module boundary
∇ migrate state
Σ commit new module frame
Ψ post-check invariants
```

Validation checks:

```text
migration exists
policy permits upgrade
capability exists
boundary preserved or explicitly transformed
export interface compatibility checked
old obligations closed or migrated
```

Reframing is not semantic equivalence by default. Equivalence, refinement, or compatibility must be separately stated and checked under a declared profile.

### 18.13 AI Proposal Boundary Example

This fragment shows optional AI tooling as advisory host service, not PMSL authority.

```pmsl
service AIProposal
    boundary Χ(tooling_host)
    requires policy P_ai_proposal_only
{
    fn propose_ir(prompt: String)
        -> Result<Advisory<PMSIRFragment>, Λ_absent<Response> | Φ_trap<ServiceError>>
        effects(Δ, Ω, Χ, Ψ, Φ, ∇, Σ, Λ)
        requires Ω(host.ai.request)
}

fn compile_scenario_with_ai(prompt: String)
    -> Result<PMSIRProgram, Φ_trap<ValidationError | ServiceError>>
    effects(Δ, Ω, Χ, Ψ, Φ, ∇, Σ, Λ)
    requires Ω(host.ai.request)
{
    let proposal = AIProposal.propose_ir(prompt)?

    let parsed = IR.parse_advisory(proposal)?
    let canonical = IR.canonicalize(parsed)?
    let checked = IR.validate(canonical)?
    let accepted = Runtime.accept_ir(checked)?

    return accepted
}
```

Authority boundary:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host validates.
Runtime accepts.
Kernel/runtime executes only accepted PMS-IR.
Policy remains Ψ-governed.
```

Operator reading:

```text
Δ classify AI task and response
Ω verify host.ai.request
Χ enter projected tooling host boundary
Ψ enforce proposal-only policy
∇ request advisory artifact
Φ/Λ handle malformed, failed, or absent response
Σ integrate advisory result only as advisory
Δ parse/canonicalize PMS-IR
Ψ validate acceptance constraints
Σ commit accepted executable artifact only after validation
```

Static analysis rule:

```text
Advisory<PMSIRFragment> is not executable.
```

AI output is not PMSL source authority, PMS-IR truth, trusted executable code, verification evidence, policy authority, compiler authority, or PMS Base validation.

This example belongs to optional tooling, not core PMSL semantics.

### 18.14 PMS-IR Lowering Example

Source fragment:

```pmsl
policy with P_write {
    FS.write(path, data)?
}
```

Lowering sketch:

```text
n1 = IR.PolicyEnter {
    op: Ψ,
    policy: P_write
}

n2 = IR.Resolve {
    op: Δ,
    symbol: FS.write
}

n3 = IR.RequireCapability {
    op: Ω,
    capability: fs.write(path)
}

n4 = IR.BoundaryCheck {
    op: Χ,
    boundary: filesystem_namespace(path)
}

n5 = IR.StdCall {
    op: ∇,
    domain: FS,
    function: write,
    args: [path, data],
    effects: [Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ]
}

n6 = IR.Commit {
    op: Σ,
    commit_profile: Σ_visible<Unit>,
    subject: n5
}

n7 = IR.TrapPath {
    op: Φ,
    trap_type: FileError
}

n8 = IR.AbsencePath {
    op: Λ,
    absence_type: NoSpace | MissingTarget
}
```

Validation obligations:

```text
n2 dominates n5
n3 dominates n5
n4 dominates n5
n1 policy scope contains n5
n6 commit profile matches function return expectation
n7 is handled or declared
n8 is handled or declared
```

Trace sketch:

```text
tick=1 op=Psi   kind=policy_enter policy=P_write
tick=2 op=Delta kind=resolve symbol=FS.write
tick=3 op=Omega kind=require capability=fs.write result=ok
tick=4 op=Chi   kind=boundary_check target=filesystem_namespace result=ok
tick=5 op=Nabla kind=std_call target=FS.write result=staged
tick=6 op=Sigma kind=commit profile=Σ_visible<Unit> result=ok
```

Trace conformance checks whether the observed trace conforms to this declared IR/profile expectation. It does not prove all possible executions unless paired with a stated model, coverage argument, or proof artifact.

### 18.15 PMS-RUST-Style Executable Slice

A PMS-RUST-style operator script is narrower than full PMSL.

Example operator-program shape:

```text
entity agent
frame ctx
attractor focus
omega agent goal 1.0 asymmetry
theta 1
phi old_context new_context
integrate synthesized
psi demo_done
```

Specification interpretation:

```text
Δ entity distinction
□ frame creation
Α attractor/pattern marker
Ω asymmetry / authority-like relation in bounded runtime dialect
Θ advance/order
Φ reframe
Σ integrate
Ψ commit/seal/final policy-like closure
```

This executable slice demonstrates that operator-tagged programs can be:

```text
constructed
validated
executed
traced
compared against fixtures
```

Boundary:

```text
PMS-RUST-style scripts are bounded executable artifacts.
They are not full PMSL source syntax.
They do not equal a complete PMSL compiler.
They strengthen implementation-artifact claims.
They do not function as PMS Base validation.
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL/PMS-IR implementation.

### 18.16 PMS-RUST-Style Boundary Exit Slice

A PMS-RUST-style isolation-exit command may demonstrate bounded runtime boundary-exit discipline.

Example operator-program shape:

```text
frame sandbox_ctx
chi_enter plugin_boundary
entity plugin_task
integrate plugin_started
chi_exit
psi plugin_closed
```

Specification interpretation:

```text
□ create sandbox_ctx
Χ enter projected plugin boundary
Δ distinguish plugin_task
Σ integrate plugin_started
Χ exit projected boundary context
Ψ commit/seal closure
```

Stateful validation rule:

```text
chi_exit / IsolationExit requires active boundary context.
```

Invalid slice:

```text
entity plugin_task
chi_exit
```

Diagnostic:

```text
error[Χ]:
    boundary exit requires active boundary/isolation context.
    unbalanced exit is invalid under this runtime profile.
```

Sealed isolation rule:

```text
sealed isolation may forbid further entry, expansion, or authority growth;
it may still permit valid exit and closure.
```

Boundary:

```text
PMS-RUST chi_exit / IsolationExit evidences bounded runtime
isolation-exit discipline.
It does not redefine PMS Base Χ.
It does not complete PMS-CPU, PMS-OS, PMSL, or PMS Base validation.
```

### 18.17 Example: Invalid Operator Sequence

Invalid fragment:

```pmsl
fn invalid_write(path: Path, data: Bytes)
    -> Result<Σ_visible<Unit>, Φ_trap<FileError>>
    effects(∇, Σ, Φ)
{
    FS.write(path, data)
}
```

Static-analysis result:

```text
error[Δ]:
    FS.write target and path are not sufficiently classified in signature/effects.

error[Ω]:
    FS.write requires fs.write capability.

error[Χ]:
    filesystem namespace boundary projection is not declared or inferred.

error[Ψ]:
    filesystem policy is missing.

error[Λ]:
    FS.write may produce absence/no-space path under active profile.

error[Σ]:
    commit profile must be explicit: staged, visible, or durable.
```

Corrected fragment:

```pmsl
fn valid_write(path: Path, data: Bytes)
    -> Result<Σ_visible<Unit>, Λ_absent<Space> | Φ_trap<FileError>>
    effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ, Λ)
    requires Ω(fs.write(path))
{
    policy with P_fs_write {
        FS.write(path, data)
    }
}
```

The correction adds the missing operator obligations. It does not prove all runtime behavior of the filesystem backend.

### 18.18 Example: Boundary Violation

Invalid fragment:

```pmsl
module Plugin isolated {
    let secret_state: Secret = ...

    export fn leak() -> Secret {
        return secret_state
    }
}
```

Static-analysis result:

```text
error[Χ/Σ]:
    isolated module exports boundary-protected value without transfer profile.

error[Ω]:
    caller authority for Secret transfer is not declared.

error[Ψ]:
    export policy does not permit leaking internal state.
```

Corrected fragment:

```pmsl
module Plugin isolated {
    let secret_state: Secret = ...

    export fn summary()
        -> Result<PublicSummary, Φ_trap<PolicyViolation>>
        effects(Δ, Ω, Χ, Ψ, ∇, Σ, Φ)
        requires Ω(plugin.summary.read)
    {
        policy with P_public_summary {
            return summarize(secret_state)
        }
    }
}
```

Operator reading:

```text
secret remains inside isolated boundary
public summary is computed under policy
exported value has public transfer profile
Σ commits only the summary result
```

This example illustrates PMSL/PMS-IR boundary projection discipline. It does not claim completed sandbox implementation unless the runtime/backend profile supplies it.

### 18.19 Example: Runtime Unsupported Feature

Source:

```pmsl
fn connect_remote(addr: Address)
    -> Result<Connection, Λ_absent<RuntimeFeature> | Φ_trap<NetError>>
    effects(Δ, Ω, Χ, Ψ, Θ, Λ, Φ, ∇, Σ)
    requires Ω(net.connect)
    requires runtime network_io
{
    Net.connect(addr)
}
```

Runtime profile:

```text
profile core_only {
    supports network_io = false
}
```

Runtime result:

```text
Λ_absent<RuntimeFeature>(network_io)
```

not:

```text
generic panic
```

and not:

```text
silent success
```

This example prevents accidental portability overclaim.

A runtime profile is a claim boundary. Unsupported features must be rejected or represented through typed Λ/Φ/Ψ outcomes.

### 18.20 Example: Trace-Conformance Check

Expected property:

```text
No FS.write executes without Ω(fs.write) and Ψ policy check.
```

Observed trace:

```text
tick=1 op=Delta kind=resolve symbol=FS.write
tick=2 op=Nabla kind=std_call target=FS.write
tick=3 op=Sigma kind=commit profile=Σ_visible<Unit>
```

Verification result:

```text
verification failure[Ω/Ψ]:

missing:
    Ω.Require(fs.write)
    Ψ.PolicyCheck(P_write)

counterexample:
    Δ.Resolve(FS.write)
    ∇.StdCall(FS.write)
    Σ.Commit(visible_write)
```

Corrected trace shape:

```text
tick=1 op=Delta kind=resolve symbol=FS.write
tick=2 op=Omega kind=require capability=fs.write result=ok
tick=3 op=Psi   kind=policy_check policy=P_write decision=allow
tick=4 op=Nabla kind=std_call target=FS.write result=staged
tick=5 op=Sigma kind=commit profile=Σ_visible<Unit> result=ok
```

Trace-conformance result:

```text
observed trace conforms to property under declared trace/profile schema
```

not:

```text
PMS Base is validated
```

### 18.21 Example: Golden Simulation Fixture

Fixture:

```text
fixture non_event_recv_timeout {
    profile = deterministic_runtime
    input = Channel.recv(inbox, timeout = 50ms)
    initial_state = inbox_empty
    expected_trace = [
        Delta.classify(inbox),
        Omega.require(channel.recv<Message>),
        Chi.boundary_check(inbox),
        Psi.policy_check(channel_policy),
        Theta.wait(50ms),
        Lambda.absence(expected=Message, reason=timeout)
    ]
    expected_result = Λ_absent<Message>
}
```

Claim:

```text
the artifact reproduces this expected behavior under deterministic_runtime
```

Boundary:

```text
golden fixtures stabilize regression expectations.
They do not prove PMS Base, semantic completeness, or full behavioral coverage.
```

This example is useful for PMS-RUST-style fixture discipline and PMSL/PMS-IR simulation profiles.

### 18.22 Example: Advisory AI Trace Explanation

Input trace:

```text
tick=1 op=Delta kind=resolve symbol=FS.write
tick=2 op=Omega kind=require capability=fs.write result=missing
tick=3 op=Phi kind=trap trap_type=CapabilityError
```

AI-assisted advisory output may say:

```text
The write failed because the active role lacked fs.write.
The next diagnostic candidate is error[Ω].
```

Required host/tool status:

```text
proposal_source = ai
proposal_status = advisory
execution_status = not_executed
verification_status = not_verification_evidence
```

Valid use:

```text
human/tool reviews explanation
static analyzer confirms missing Ω capability
diagnostic is emitted by host tooling
```

Invalid use:

```text
AI explanation directly becomes verifier result
AI explanation directly rewrites policy
AI explanation directly authorizes execution
```

Boundary:

```text
AI-assisted explanation is advisory observability.
It is not proof, verification evidence, policy authority, trusted code,
or PMS Base validation.
```

### 18.23 Example Set Invariants

The examples in this section preserve the following invariants.

```text
I1: every effectful example exposes ∇ and Σ separately
I2: every protected operation declares Ω authority
I3: every policy-governed operation activates or references Ψ
I4: every boundary-sensitive operation exposes Χ as a PMSL/PMS-IR projection
I5: every frame-sensitive example enters □ explicitly or through module/task/function structure
I6: every absence-capable example exposes Λ
I7: every trap-capable example exposes Φ
I8: every commit-capable example declares visible, durable, local, delivery, or transaction commit
I9: every FFI/tooling example remains host-boundary-governed
I10: every AI example remains advisory until host-validated
I11: every PMS-IR sketch preserves operator tags
I12: every trace sketch is evidence of modeled behavior, not PMS Base validation
I13: every golden fixture is regression evidence, not proof of semantic completeness
I14: every PMS-RUST-style slice is bounded executable evidence, not full PMSL/PMS-IR completion
I15: every example claim remains profile-bound where runtime, backend, simulation, or verification behavior is involved
```

These invariants are illustrative conformance constraints for the example set.

They do not claim that a completed parser, compiler, runtime, verifier, simulator, standard library, or backend already enforces every fragment.

### 18.24 PMS-RUST Evidence Boundary

PMS-RUST v0.1 may support bounded executable evidence for selected example-adjacent behavior.

Relevant evidence areas include:

```text
operator-tagged program construction
program buffering
model validation
stateful runtime validation
deterministic kernel execution
REPL/script tooling
JSONL trace/audit output
golden fixtures
vFS service boundaries
AI proposal gating
```

This can strengthen implementation-artifact claims for selected examples, such as:

```text
operator script execution
validation acceptance/rejection
stateful boundary-exit discipline
JSONL trace emission
golden fixture comparison
vFS-like service behavior
AI proposal gating
```

It does not complete:

```text
PMSL source language
PMSL parser
PMSL compiler
PMSL standard library
PMS-IR optimizer
PMSL runtime
PMS-CPU
PMS-OS
distributed runtime
PMS Base validation
```

PMS-RUST v0.1 is a bounded executable evidence spine. It is not the full PMSL/PMS-IR implementation and does not validate PMS Base.

### 18.25 AI Example Boundary

The AI Bridge is an optional PMS-RUST tooling/profile surface for proposing PMS-IR/opcode programs or analyzing traces under host-side validation.

The examples may show AI proposal workflows only as optional tooling.

AI may propose:

```text
PMS-IR fragments
opcode programs
diagnostic explanations
trace summaries
simulation scenarios
candidate golden fixtures
missing-obligation hypotheses
```

AI may not function as:

```text
PMSL semantics
compiler authority
verifier authority
runtime authority
policy authority
trusted executable code
verification evidence
PMS Base evidence
```

Required pipeline:

```text
AI proposes.
Host parses.
Host canonicalizes.
Host maps to PMSL/PMS-IR/opcode structures.
Host validates under declared schema/model/tool/runtime profile.
Kernel/runtime/simulator executes only accepted PMS-IR or accepted opcode programs.
Policy remains Ψ-governed.
```

AI output in these examples is advisory until host-validated under a declared tooling/profile gate.

### 18.26 Architectural Consequence

The consequence of these PMSL fragments is:

```text
PMSL is readable as a systems language while remaining operator-typed.
Ordinary programming actions — frame entry, filesystem writes, channel
receives, task groups, module exports, FFI calls, transactions, upgrades,
AI proposal workflows, IR lowering, trace validation, simulation
fixtures, and PMS-RUST-style executable slices — remain visible as Δ–Ψ
structure rather than collapsing into opaque syntax or runtime magic.
```

The examples close the PMSL/PMS-IR chapter by showing how the specification works at source level:

```text
PMSL source
→ operator reading
→ PMS-IR representation
→ static analysis
→ runtime execution
→ trace/debug/verification surface
→ simulation/evidence boundary
```

This is the implementation-layer architecture claim of `05_pmsl_pms_ir.md`: PMSL and PMS-IR make PMS-STACK programmable, checkable, executable, observable, simulatable, and artifact-backed without turning implementation artifacts into PMS Base validation.

### 18.27 Example PMSL Fragments Boundary Statement

The correct boundary for this chapter is:

```text
The PMSL example-fragment model illustrates source-like PMSL programs,
operator readings, PMS-IR sketches, static-analysis obligations,
runtime/trace behavior, verification properties, simulation fixtures,
PMS-RUST-style executable slices, AI proposal boundaries, and example
invariants.

This is a language example / PMSL-fragment illustration architecture
claim.

It does not claim final PMSL grammar, completed parser, completed
compiler, completed runtime, completed standard library, completed
verifier, completed simulator, completed PMSL implementation, completed
PMS-CPU, completed PMS-OS, distributed runtime completion, or PMS Base
validation.

PMS-RUST v0.1 may evidence bounded implementation-artifact behavior for
operator-tagged program construction, program buffering, model validation,
stateful runtime validation, deterministic execution, JSONL traces,
REPL/script tooling, vFS service boundaries, golden fixtures, and AI
proposal gating. It does not complete PMSL/PMS-IR and does not validate
PMS Base.
```
