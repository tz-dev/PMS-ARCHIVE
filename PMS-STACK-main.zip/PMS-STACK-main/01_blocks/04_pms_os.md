---
document_id: PMS-STACK-DOC-04
title: "PMS Operating System"
status: "release-candidate"
version: "v0.1-rc"
claim_type: "implementation-layer OS architecture claim"
pms_base_status: "source of Δ–Ψ operator identity"
stack_status: "PMS-CPU specialization into kernel-governed operating-system architecture"
chi_status: "PMS Base 1.3 Χ = Distance; PMS-OS projects Χ as process isolation, address-space boundary, namespace separation, device boundary, IPC visibility, filesystem view, sandbox/container boundary, and reachability control"
depends_on:
  - "01_architecture.md"
  - "02_pms_um.md"
  - "03_pms_cpu.md"
links_forward_to:
  - "05_pmsl_pms_ir.md"
  - "06_runtime_security.md"
  - "07_distributed_systems.md"
  - "08_relation_to_pms_rust.md"
  - "09_non_goals_and_claim_boundary.md"
---

# PMS Operating System

## 1. Role of PMS-OS in the Stack

PMS-OS is the operating-system architecture layer of PMS-STACK.

It refines PMS-CPU execution into a kernel-governed, multi-process, multi-resource system with process frames, threads, scheduling, syscalls, virtual memory, storage, IPC, events, devices, drivers, resource accounting, and policy enforcement.

PMS-OS occupies the following position in the stack:

```text
PMS Base Δ–Ψ operator grammar
    ↓
01_architecture.md
    ↓
02_pms_um.md
    ↓
03_pms_cpu.md
    ↓
04_pms_os.md
    ↓
05_pmsl_pms_ir.md / 06_runtime_security.md / 07_distributed_systems.md
```

Its role is to transform the virtual CPU execution model into an operating-system model.

PMS-CPU defines:

```text
registers
memory
frames
roles
capabilities
traps
interrupts
binary execution
commit
policy checks
```

PMS-OS specializes this into:

```text
kernel context
processes
threads
scheduler
syscalls
address spaces
filesystem
IPC
synchronization
events
devices
drivers
resource accounting
kernel policies
```

The central PMS-OS claim is:

```text
PMS-OS is an operator-typed operating-system architecture in which
kernel execution mediates process, memory, syscall, scheduling, storage,
IPC, device, resource-accounting, and policy transitions through Δ–Ψ.
```

Claim type:

```text
implementation-layer OS architecture claim
```

Boundary:

```text
PMS-OS specifies the operating-system architecture layer of PMS-STACK.

It does not claim a completed kernel artifact.

It does not claim a production OS.

It does not claim fabricated hardware substrate.

It does not function as PMS Base validation.
```

### 1.1 PMS-OS as the Kernel Mediation Layer

The PMS-OS kernel mediates transitions that user processes cannot perform directly.

At OS level, the kernel is responsible for controlled transitions involving:

| Operator | Kernel-level role                                                                     |
| -------- | ------------------------------------------------------------------------------------- |
| Δ        | syscall classification, object lookup, process/thread distinction, event routing      |
| ∇        | state mutation, resource allocation, filesystem writes, IPC enqueue/dequeue           |
| □        | process frames, address spaces, namespaces, file frames, device frames                |
| Λ        | wait states, timeouts, empty queues, absent events, failed allocation outcomes        |
| Α        | reusable kernel patterns: fork, exec, journaling, driver binding, request/response    |
| Ω        | privilege roles, capabilities, credentials, driver permissions                        |
| Θ        | scheduling, ordering, fairness, timers, dispatch sequencing                           |
| Φ        | syscall entry, trap handling, interrupt handling, page faults, signal delivery        |
| Χ        | Distance projected as process isolation, address-space boundary, namespace separation |
| Σ        | commit, synchronization, syscall return, accounting update, journal integration       |
| Ψ        | kernel invariants, policy engine, lifecycle closure, access constraints               |

The kernel is the privileged PMS-OS locus where these transitions are made coherent across the whole system.

PMS Base 1.3 defines:

```text
Χ = Distance
```

PMS-OS projects Χ as concrete operating-system boundary structure:

```text
process isolation
address-space boundary
namespace separation
device boundary
IPC visibility
filesystem view
sandbox/container boundary
reachability control
```

This is a layer projection.

It does not redefine PMS Base Χ.

### 1.2 PMS-OS as a Privileged PMS Program

PMS-OS may be described as a privileged PMS program configuring PMS-CPU operator algebra into a multi-process system.

PMS-CPU provides the virtual processor substrate:

```text
trap entry
role switching
frame switching
boundary checks
policy checks
commit discipline
interrupt delivery
```

PMS-OS installs the operating-system structures that use that substrate:

```text
process table
thread table
scheduler state
frame table
address spaces
capability tables
syscall table
IPC frames
filesystem frames
device frames
driver roles
policy sets
resource accounts
```

Thus:

```text
PMS-CPU = virtual execution substrate
PMS-OS  = privileged system architecture over that substrate
```

The kernel does not replace PMS-CPU.

It interprets CPU-level traps, roles, frames, isolation domains, and commit points as OS-level system structure.

### 1.3 Kernel Entry and Exit

User processes enter the kernel only through controlled Φ transitions.

Kernel entry occurs through:

```text
syscalls
interrupts
exceptions
faults
signals
device events
```

These are all recontextualizations:

```text
(f_user, r_user, X_user)
    --Φ-->
(KF, KERNEL, X_global)
```

where:

| Symbol     | Meaning                                            |
| ---------- | -------------------------------------------------- |
| `f_user`   | user process frame                                 |
| `r_user`   | user role                                          |
| `X_user`   | OS-level user isolation-domain value               |
| `KF`       | kernel frame                                       |
| `KERNEL`   | kernel role                                        |
| `X_global` | OS-level kernel-visible global system-domain value |

Kernel exit also occurs through Φ:

```text
(KF, KERNEL, X_global)
    --Φ_return-->
(f_user, r_user, X_user)
```

`X_user` and `X_global` are OS-level isolation-domain values.

They are not the PMS Base operator `Χ`.

They name concrete PMS-OS boundary, reachability, namespace, and visibility domains through which PMS Base Χ = Distance is projected at OS level.

The kernel is therefore a persistent Φ-handler: it receives recontextualized control, performs privileged work, commits effects, and returns to the appropriate process context.

### 1.4 PMS-OS and Process Structure

At OS level, a process is not merely an executable image.

A PMS-OS process is:

```text
Process = (FrameSet, RoleState, IsolationDomain, LocalPolicy, Threads, ResourceAccount)
```

or, using kernel data-structure notation:

```text
PProcess = (id, f, r, X, P_local, regs, RAcc, meta)
```

where:

| Component | Operator role                                                                |
| --------- | ---------------------------------------------------------------------------- |
| `id`      | Δ process distinction                                                        |
| `f`       | □ active frame / address-space context                                       |
| `r`       | Ω role and capability state                                                  |
| `X`       | OS-level isolation-domain value; Χ projection as isolation / boundary domain |
| `P_local` | Ψ local process policy                                                       |
| `regs`    | saved PMS-CPU execution state                                                |
| `RAcc`    | ResourceAccount for quota and usage state                                    |
| `meta`    | Θ scheduling, Φ trap flags, Λ waits, Σ cleanup/accounting metadata           |

`X` is an OS isolation-domain value.

It is not PMS Base Χ itself.

A thread is a Θ-scheduled execution strand inside such a process. Threads perform Δ/∇ execution while remaining subject to frame, role, boundary, commit, and policy constraints.

### 1.5 PMS-OS and Classical OS Concepts

PMS-OS is not an alien replacement for operating-system concepts. It retypes familiar OS structures through the Δ–Ψ operator grammar.

| Classical OS concept       | PMS-OS projection                                                                                                        |
| -------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| process                    | □ frame set + Χ isolation projection + Ω role + Ψ local policy                                                           |
| thread                     | Θ-scheduled execution strand                                                                                             |
| syscall                    | Φ entry + Ω privilege adjustment + □ kernel frame + Χ boundary mediation + Δ dispatch + Ψ check + operation + Σ/Φ return |
| address space              | □ frame hierarchy with Χ isolation projection                                                                            |
| capability                 | Ω-directed permission edge                                                                                               |
| scheduler                  | Θ selection under Ψ constraints                                                                                          |
| signal / fault / interrupt | Φ recontextualization                                                                                                    |
| file descriptor            | □ handle frame with Ω permissions and Ψ constraints                                                                      |
| IPC channel                | □ message frame with Δ/Ω/Λ/Θ/Σ semantics                                                                                 |
| device driver              | Ω-governed role inside a □ device/driver frame                                                                           |
| quota                      | Ψ rule over Σ-committed `ResourceAccount` data                                                                           |

This makes classical OS structures more explicit, more compositional, and more traceable.

### 1.6 Boundary to Other PMS-STACK Documents

This document defines PMS-OS as an operating-system architecture specification.

It includes:

```text
kernel model
process/thread model
scheduling
isolation/protection
policy engine
syscall interface
resource accounting
virtual memory
allocation/reclamation
filesystem
storage drivers
cache/buffer management
IPC
synchronization
events
device/driver lifecycle
OS-level invariants
```

It does not fully define:

| Topic                                      | Primary document                     |
| ------------------------------------------ | ------------------------------------ |
| PMS operator foundation                    | `01_architecture.md`                 |
| abstract machine semantics                 | `02_pms_um.md`                       |
| virtual CPU and ISA                        | `03_pms_cpu.md`                      |
| language, IR, compiler, runtime projection | `05_pmsl_pms_ir.md`                  |
| runtime security and governance hardening  | `06_runtime_security.md`             |
| distributed OS / cluster semantics         | `07_distributed_systems.md`          |
| PMS-RUST artifact relation                 | `08_relation_to_pms_rust.md`         |
| non-goals and claim boundaries             | `09_non_goals_and_claim_boundary.md` |

The PMS-OS syscall convention is a dedicated OS-level syscall ABI built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It also does not replace the PMS-CPU trap/syscall control-transfer model; it specializes that model into kernel-service entry, dispatch, validation, commit, and return.

Security appears here only as kernel policy, role, capability, isolation, and invariant discipline. Full runtime-security architecture belongs in `06_runtime_security.md`.

Distributed systems appear here only as optional extension points for devices, IPC, storage, and scheduling. Full distributed PMS belongs in `07_distributed_systems.md`.

### 1.7 Architectural Consequence

PMS-OS gives PMS-STACK its operating-system layer.

The consequence is:

```text
A PMS-OS kernel is the privileged mediator that turns PMS-CPU execution
into a multi-process, policy-governed, frame-isolated, syscall-driven,
resource-accounted operating system.
```

This is an OS architecture specification.

It defines how a PMS-conformant kernel should structure processes, scheduling, memory, syscalls, IPC, storage, resources, and devices without claiming that every subsystem is already implemented.

### 1.8 Boundary Statement

The correct boundary for this chapter is:

```text
PMS-OS specifies the operating-system architecture layer of PMS-STACK: a
kernel-governed system of processes, threads, frames, roles, capabilities,
syscalls, virtual memory, scheduling, resources, storage, IPC, events,
devices, drivers, and kernel policy.

This is an implementation-layer OS architecture claim.

It does not claim a completed kernel artifact, production OS, fabricated
hardware substrate, external security validation, or PMS Base validation.
```

---

## 2. Kernel Goals and Trust Model

The PMS-OS kernel has a precise architectural role:

```text
mediate privileged operator transitions while preserving global Ψ invariants.
```

The kernel is trusted not because it is exempt from PMS structure, but because it is the system component responsible for enforcing that structure.

The PMS-OS kernel:

1. mediates Ω, □, Χ, Φ, Σ, Θ, and Ψ transitions;
2. enforces global Ψ-level invariants;
3. provides isolated, predictable execution contexts;
4. implements system services as PMS operator sequences;
5. converts CPU-level traps and interrupts into OS-level system events;
6. commits resource, scheduling, filesystem, IPC, and driver effects through Σ;
7. maintains the process, memory, device, resource, and policy state required for system integrity.

Claim type:

```text
kernel trust-model architecture claim
```

Boundary:

```text
This section specifies the PMS-OS kernel trust model.

It does not claim a completed production kernel.

It does not claim external security validation.

It does not make PMS-OS a moral tribunal, forensic authority, or governance oracle.

It does not validate PMS Base.
```

### 2.1 Kernel Trust Boundary

The kernel context is:

```text
Context_kernel = (f = KF, r ∈ {KERNEL, SUPERVISOR}, X = X_global)
```

where:

| Component  | Meaning                                            |
| ---------- | -------------------------------------------------- |
| `KF`       | kernel frame                                       |
| `r`        | privileged kernel or supervisor role               |
| `X_global` | OS-level kernel-visible global system-domain value |

At PMS-OS level, Χ remains a projection of PMS Base Distance. It appears as kernel/user separation, process isolation, address-space boundary, namespace boundary, driver boundary, and device-access separation.

`X_global`, `X_user`, and later `X_p` are OS-level isolation-domain values.

They are not the PMS Base operator `Χ`.

They name concrete PMS-OS boundary / reachability / namespace domains through which PMS Base Χ = Distance is projected at OS level.

The kernel may:

* create and destroy user frames;
* map and unmap address spaces;
* manage roles and capabilities;
* install and update policies;
* handle traps, faults, interrupts, and syscalls;
* perform scheduling and accounting;
* commit global kernel state;
* create isolated process, container, driver, or device domains;
* recontextualize failing processes or subsystems through Φ.

User processes may not directly perform kernel transitions. They enter kernel context only through Φ-controlled entry paths.

### 2.2 Kernel Rights

The kernel has rights over the OS state space.

These rights are operator-typed.

#### Ω-rights

The kernel may assign, modify, or revoke roles and capabilities.

Examples:

```text
grant capability
revoke capability
switch process role
validate privileged syscall
restrict driver capability
```

#### □-rights

The kernel may create, destroy, and bind frames.

Examples:

```text
create process address space
map file frame
create IPC frame
enter device frame
bind kernel stack frame
```

#### Χ-rights

The kernel may create and manage isolation domains.

Examples:

```text
create process boundary
enter sandbox
restrict namespace
quarantine driver
separate device DMA region
```

This is an implementation-layer projection of PMS Base Distance, not a redefinition of Χ.

#### Φ-rights

The kernel may enter, leave, and redirect contexts.

Examples:

```text
syscall entry
interrupt handler entry
page fault handler
signal delivery
driver recovery
process termination path
```

#### Θ-rights

The kernel may order execution.

Examples:

```text
schedule thread
preempt thread
advance timer queues
dispatch events
order device work
enforce fairness policy
```

#### Σ-rights

The kernel may commit global state.

Examples:

```text
context switch commit
resource accounting commit
filesystem journal commit
IPC delivery commit
driver binding commit
process termination commit
```

#### Ψ-rights

The kernel may define and enforce global invariants.

Examples:

```text
no user mapping of kernel frames
no uncontrolled role escalation
policy mutation only in kernel context
resource quota enforcement
safe trap return
safe driver teardown
```

### 2.3 Kernel Obligations

Kernel rights are paired with kernel obligations.

The kernel must preserve global invariants:

```text
Ψ(s_before) ⇒ Ψ(s_after)
```

This is the core trust condition.

Kernel actions may recontextualize, roll back, quarantine, or halt a subsystem, but they may not silently violate global invariants.

The kernel must maintain:

| Obligation               | Operator reading                  |
| ------------------------ | --------------------------------- |
| capability correctness   | Ω consistency                     |
| frame isolation          | □ / Χ                             |
| privilege monotonicity   | Ω + Φ                             |
| policy integrity         | Ψ                                 |
| scheduling integrity     | Θ + Ψ                             |
| commit correctness       | Σ + Ψ                             |
| safe recontextualization | Φ + Ψ                             |
| absence handling         | Λ with expectation context        |
| auditability             | operator-labeled representability |

### 2.4 Kernel Global Invariants

Let:

```text
P_kernel
```

be the kernel policy set.

The kernel maintains the following architectural invariants.

#### Ψ₁ — Capability Correctness

Every privileged action requires an authorized capability.

```text
Ψ₁(s): for all ∇ instructions or kernel actions I,
       requires_cap(I) ⊆ CapSet(r_s)
```

Meaning:

```text
a role may only perform actions supported by its capability set
```

No mutation of protected state may bypass Ω.

#### Ψ₂ — Frame Isolation

All memory and object accesses must be frame-valid.

```text
Ψ₂(s): Addr ∈ VisibleFrames(f_s)
```

Meaning:

```text
a process may only access frames visible from its active frame context
```

Frame isolation is specified through □ and Χ.

#### Ψ₃ — No Uncontrolled Privilege Escalation

Role escalation is permitted only through kernel-mediated Φ transitions.

```text
USER   → KERNEL only via Φ_trap
KERNEL → USER   only via Φ_return
```

No user process may directly become kernel.

No driver may silently acquire broader privileges than its declared role and capabilities allow.

#### Ψ₄ — Policy Integrity

Policy mutation is kernel-governed.

```text
Ψ-mutating operations allowed iff r_s = KERNEL
```

or, more generally:

```text
Ψ_update allowed iff Ω authorizes policy mutation in a kernel-governed frame
```

This prevents user or driver code from rewriting the rules that constrain it.

#### Ψ₅ — Scheduling Integrity

Scheduling must obey Θ/Ψ policy.

Optional fairness form:

```text
∀ runnable process p:
    p must eventually run
```

A specific PMS-OS profile may choose different scheduling policies: round-robin, priority, weighted fairness, deadline scheduling, or hierarchical scheduling. The invariant is that scheduling is Θ-ordered and Ψ-constrained, not arbitrary.

#### Ψ₆ — Safe Recontextualization

Φ must not break invariants.

```text
Φ(s) ⇒ s' satisfies Ψ₁…Ψ₅
```

A trap, exception, signal, interrupt, driver error, or page fault may change context, but the resulting context must still satisfy kernel policy.

#### Ψ₇ — Commit Validity

Σ requires valid prior structure and policy permission.

```text
Σ(s) valid only if:
    committable prior state exists
    ∧ frame conditions hold
    ∧ role/capability conditions hold
    ∧ boundary constraints hold
    ∧ Ψ permits integration
```

No filesystem commit, IPC delivery, context-switch save, driver binding, or accounting update may become globally visible if its preconditions fail.

### 2.5 Kernel Entry Discipline

All user-to-kernel transitions follow a controlled entry structure.

Canonical OS syscall path:

```text
Φ_enter
→ Ω_kernel_role_and_caller_authority
→ □_kernel_syscall_frame
→ Χ_user_kernel_boundary_mediation
→ Δ_syscall_id_and_argument_classification
→ Ψ_precheck
→ kernel operation
→ Σ_commit_if_needed
→ Ψ_postcheck
→ Φ_return
```

In compact form:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Meaning:

| Operator | Syscall role                     |
| -------- | -------------------------------- |
| Φ        | kernel entry / trap              |
| Ω        | kernel role and caller authority |
| □        | kernel syscall frame             |
| Χ        | user/kernel boundary mediation   |
| Δ        | syscall and argument distinction |
| Ψ        | precheck                         |
| `(…)`    | syscall body                     |
| `Σ?`     | commit where required            |
| Ψ        | postcheck                        |
| Φ        | return / close / recontextualize |

This applies to:

* syscalls;
* traps;
* page faults;
* interrupts;
* signal entry;
* driver callbacks;
* policy-denial handlers.

The kernel is not an arbitrary privileged procedure call target. It is a controlled recontextualization domain.

### 2.6 Kernel Exit Discipline

Kernel exit must restore a valid non-kernel context.

A valid kernel return requires:

```text
target frame is valid
∧ target role is permitted
∧ return address is executable
∧ boundary state is coherent
∧ policy permits return
∧ trap/interrupt nesting state is coherent
∧ pending commit state is valid or resolved
```

If these conditions fail, the kernel must not return silently.

It must instead:

* remain in kernel context;
* enter a recovery path;
* kill or suspend the process;
* quarantine the driver/subsystem;
* rollback staged state;
* or halt under a defined Ψ policy.

### 2.7 Trust Model of User Processes

A user process is trusted only inside its allowed frame, role, boundary, and policy context.

Each user process has:

```text
Process = (f_user, r_user, X_user, P_local, RAcc)
```

where:

* `f_user` is its frame set;
* `r_user` is its role/capability state;
* `X_user` is its OS-level isolation-domain value;
* `P_local` is its local policy set, subordinate to kernel policy;
* `RAcc` is its resource account.

A user process may:

* execute inside its frames;
* invoke allowed syscalls;
* use permitted IPC endpoints;
* access granted file handles;
* allocate within quotas;
* receive events and signals;
* terminate and commit resources through kernel paths.

A user process may not:

* access kernel frames directly;
* rewrite policies;
* grant itself capabilities;
* bypass syscall entry;
* break process isolation;
* directly access devices unless mapped and authorized;
* commit global state without kernel mediation.

### 2.8 Trust Model of Drivers

Drivers are privileged but not unbounded.

A driver is a role-bearing execution locus:

```text
Driver = (f_D, r_D, C_D, P_D, RAcc_D)
```

where:

| Component | Meaning                   |
| --------- | ------------------------- |
| `f_D`     | driver frame              |
| `r_D`     | driver role               |
| `C_D`     | driver capability set     |
| `P_D`     | driver policy constraints |
| `RAcc_D`  | driver resource account   |

Drivers may operate devices only through capability-checked frames and kernel-governed lifecycle transitions.

A driver may:

* access assigned device frames;
* handle assigned interrupts;
* enqueue bottom-half work;
* use declared DMA regions;
* allocate within driver budgets;
* report errors through Φ;
* commit device state through Σ.

A driver may not:

* access arbitrary kernel memory;
* DMA into unauthorized frames;
* ignore isolation domains;
* install capabilities for itself;
* bypass driver policy;
* remain active after quarantine;
* continue using stale device frames after hotplug detach.

Full driver lifecycle policy belongs later in this document. Runtime-security hardening is refined in `06_runtime_security.md`.

### 2.9 Kernel Policy Engine Role

The kernel policy engine is the concrete PMS-OS realization of Ψ.

It evaluates policy at hooks such as:

```text
syscall entry
memory mapping
capability update
frame switch
context switch
IPC send/receive
filesystem operation
device access
driver bind/unbind
commit boundary
trap return
```

A policy decision may:

* allow;
* deny;
* modify;
* defer;
* log;
* isolate;
* recontextualize;
* terminate;
* require explicit commit;
* trigger audit.

The kernel policy engine does not replace operator semantics. It constrains valid future execution:

```text
L_PMS,Ψ ⊆ L_PMS
```

At OS level:

```text
valid_kernel_trace ∈ L_PMS,Ψ_kernel
```

Policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

### 2.10 Positive Trust Boundary

The PMS-OS trust model is not “the kernel can do anything.”

It is:

```text
the kernel is trusted to enforce the operator-typed invariants that make
multi-process execution valid.
```

The kernel’s authority is real, but bounded by PMS-STACK architectural discipline:

```text
Ω gives the kernel privileged authority.
□ gives the kernel frame control.
Χ gives the kernel boundary control.
Φ gives the kernel context-shift control.
Θ gives the kernel scheduling control.
Σ gives the kernel commit authority.
Ψ binds all of this to invariants.
```

Thus the kernel is both privileged and constrained.

### 2.11 Kernel Goals Summary

The PMS-OS kernel goals are:

| Goal                        | Operator structure                             |
| --------------------------- | ---------------------------------------------- |
| mediate process execution   | □ + Θ + Φ                                      |
| enforce protection          | Ω + Χ + Ψ                                      |
| provide syscalls            | Φ + Ω + □ + Χ + Δ + Ψ + operation + Σ? + Ψ + Φ |
| schedule threads            | Θ under Ψ                                      |
| manage memory               | □ + Χ + Ω + Φ + Σ + Ψ                          |
| manage storage              | □ + ∇ + Σ + Ψ                                  |
| provide IPC and events      | Δ + Ω + Λ + Θ + Φ + Σ                          |
| control devices and drivers | □ + Ω + Χ + Φ + Θ + Σ + Ψ                      |
| account resources           | Δ + ∇ + Θ + Σ + Ψ                              |
| preserve invariants         | Ψ over all transitions                         |

### 2.12 Architectural Consequence

The PMS-OS kernel is the trust-bearing mediator of PMS-STACK.

The consequence is:

```text
PMS-OS treats the kernel as a privileged but invariant-bound PMS machine:
it may create frames, assign roles, control boundaries, handle traps,
schedule execution, commit global state, and enforce policies, but every
such act must preserve the kernel Ψ invariants.
```

This defines the kernel trust model for the remainder of `04_pms_os.md`.

### 2.13 Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-OS kernel trust model defines the kernel as a privileged but
invariant-bound mediator of OS-level frames, roles, boundaries,
recontextualization, scheduling, commits, resources, and policies.

This is an implementation-layer OS trust-model architecture claim.

It does not claim a completed kernel, production OS, external security
validation, governance authority, forensic authority, moral judgment, or PMS
Base validation.
```

---

## 3. Core Kernel Data Structures

PMS-OS kernel state is organized through operator-aligned data structures.

The kernel does not treat processes, frames, policies, messages, devices, or resources as untyped records. Each kernel object is a structured locus of Δ–Ψ behavior.

The central design rule is:

```text
kernel data structures are operator-bearing state structures.
```

A kernel object must expose:

```text
identity        → Δ
context         → □
authority       → Ω
boundary        → Χ
ordering        → Θ
absence/wait    → Λ
trap/error path → Φ
commit state    → Σ
policy state    → Ψ
```

This makes kernel state suitable for checking, tracing, policy evaluation, lifecycle control, and later implementation as a simulator, microkernel-like runtime, monolithic kernel, or hybrid kernel.

Claim type:

```text
OS-level kernel data-structure architecture claim
```

Boundary:

```text
This section specifies PMS-OS kernel data structures at the architecture
level.

It does not claim a completed kernel implementation, production OS data
layout, physical hardware substrate, or PMS Base validation.
```

### 3.1 Kernel State Overview

The PMS-OS kernel state may be modeled as:

```text
KState = (
    ProcessTable,
    ThreadTable,
    FrameTable,
    RoleTable,
    CapabilityTable,
    PolicySet,
    SchedulerState,
    SyscallTable,
    ResourceAccounts,
    MemoryState,
    IPCState,
    FilesystemState,
    DeviceTable,
    DriverTable,
    EventState,
    AuditState,
    MetaState
)
```

At a higher abstraction level:

```text
KState = (P, T, F, R, C, ΨK, ΘK, SCall, RAccTable, M, IPC, FS, DEV, DRV, E, A, m)
```

where:

| Component   | Meaning                                                                 |
| ----------- | ----------------------------------------------------------------------- |
| `P`         | process table                                                           |
| `T`         | thread table                                                            |
| `F`         | frame table                                                             |
| `R`         | role table                                                              |
| `C`         | capability table                                                        |
| `ΨK`        | kernel policy set                                                       |
| `ΘK`        | scheduler state                                                         |
| `SCall`     | syscall table                                                           |
| `RAccTable` | resource-account table                                                  |
| `M`         | memory and allocation state                                             |
| `IPC`       | message, channel, sync, event state                                     |
| `FS`        | filesystem and storage state                                            |
| `DEV`       | device table                                                            |
| `DRV`       | driver table                                                            |
| `E`         | event and notification state                                            |
| `A`         | audit and trace state                                                   |
| `m`         | meta-state: traps, interrupts, τ data, pending commits, lifecycle flags |

`RAcc` is the canonical shorthand for `ResourceAccount`.

`RF` must not be used in PMS-OS for resource accounting because `RF` denotes `RegisterFile` in PMS-CPU.

This section defines the core structures that later sections refine.

### 3.2 PProcess — Praxeological Process Control Block

The primary process descriptor is:

```text
PProcess = (id, f, r, X, P_local, regs, RAcc, meta)
```

where:

| Field     | Meaning                                                | Operator role     |
| --------- | ------------------------------------------------------ | ----------------- |
| `id`      | unique process identifier                              | Δ                 |
| `f`       | current frame / address-space context                  | □                 |
| `r`       | role / privilege / credential state                    | Ω                 |
| `X`       | OS-level isolation-domain value; Distance projection   | Χ                 |
| `P_local` | local process policy set                               | Ψ                 |
| `regs`    | saved PMS-CPU register state                           | ∇ / Φ / Σ         |
| `RAcc`    | resource account                                       | Δ / ∇ / Θ / Σ / Ψ |
| `meta`    | scheduling, wait, trap, accounting, lifecycle metadata | Θ / Λ / Φ / Σ     |

The process descriptor is the OS-level counterpart of PMS-CPU execution state.

It stores enough information to:

* resume execution;
* enter or exit kernel context;
* enforce role and capability constraints;
* validate memory and frame accesses;
* schedule threads;
* account resources;
* deliver signals and events;
* terminate and reclaim resources.

A process is valid when:

```text
id is unique
∧ f selects a valid FrameSet
∧ r is a valid role state
∧ X is a valid OS-level isolation domain
∧ P_local is subordinate to P_kernel
∧ regs are coherent with PMS-CPU state
∧ RAcc is coherent with quota and accounting state
∧ meta is lifecycle-consistent
```

`X` is not PMS Base Χ.

It is a concrete PMS-OS isolation-domain value through which PMS Base Χ = Distance is projected as process boundary and reachability control.

### 3.3 Thread Descriptor

A thread is the Θ-scheduled execution strand inside a process.

```text
Thread = (tid, parentPID, regs, state, Θ_budget, wait, RAcc_ref, meta)
```

where:

| Field       | Meaning                                                    | Operator role |
| ----------- | ---------------------------------------------------------- | ------------- |
| `tid`       | thread identifier                                          | Δ             |
| `parentPID` | owning process                                             | □ / Δ         |
| `regs`      | saved CPU registers                                        | ∇ / Φ / Σ     |
| `state`     | READY/RUNNING/BLOCKED/...                                  | Θ / Λ / Φ / Σ |
| `Θ_budget`  | scheduling budget, deadline, priority, fairness data       | Θ             |
| `wait`      | wait channel, timeout, pending event                       | Λ / Θ         |
| `RAcc_ref`  | reference to thread or process resource account            | Δ / Θ / Σ / Ψ |
| `meta`      | trap flags, accounting, signal state, kernel-stack pointer | Φ / Σ / Ψ     |

Threads inherit process-level:

```text
FrameSet
RoleState
IsolationDomain
LocalPolicy
ResourceAccount
```

A thread may have thread-local additions, but it cannot exceed the parent process’s frame, role, boundary, resource, or policy authority.

### 3.4 Frame

A frame is the kernel’s core □ structure.

```text
Frame = (id, base, size, type, perms, owner, links, meta)
```

where:

| Field   | Meaning                                                 |
| ------- | ------------------------------------------------------- |
| `id`    | frame identifier                                        |
| `base`  | base address or object root                             |
| `size`  | extent                                                  |
| `type`  | frame kind                                              |
| `perms` | access permissions                                      |
| `owner` | owning process, kernel subsystem, driver, or device     |
| `links` | sharing, clone, IPC, mount, COW, or device links        |
| `meta`  | cacheability, τ metadata, policy hooks, lifecycle state |

Frame types include:

```text
CODE
DATA
STACK
HEAP
MMIO
DEVICE
USER
KERNEL
SHARED
IPC
FILESYSTEM
DRIVER
CACHE
EVENT
SYNC
```

Frames define addressability and contextual interpretation.

A memory address, file handle, IPC endpoint, device mapping, or namespace is not interpreted independently of its frame.

Frame validity:

```text
frame_exists(fid)
∧ bounds_valid(base, size)
∧ owner_valid(owner)
∧ perms_valid(perms)
∧ policy_ok(P_kernel, Frame(fid))
∧ boundary_valid(X, Frame(fid))
```

`X` here is the active OS-level isolation-domain value.

It is not the PMS Base operator Χ.

### 3.5 FrameSet

A process does not own a single frame. It owns a frame set.

```text
FrameSet_p = {
    CodeFrame,
    DataFrame,
    HeapFrame,
    StackFrame,
    IPCFrames,
    SharedFrames,
    FilesystemHandles,
    KernelGatewayFrame
}
```

A frame set defines the address-space and object-visibility context of a process.

Frame-set validity requires:

```text
all frames are valid
∧ no kernel frame is directly writable by user process
∧ executable frames are not writable unless policy permits
∧ shared frames have explicit Ω and Χ permission
∧ local policy does not exceed kernel policy
```

The frame set is the OS-level projection of □ into address spaces, namespaces, memory mappings, IPC endpoints, and resource contexts.

### 3.6 Role and Capability Structures

Role state is Ω-typed.

```text
Role = (id, class, capabilities, constraints, meta)
```

Typical role classes include:

```text
USER
SERVICE
KERNEL
SUPERVISOR
DRIVER
DEVICE
ADMIN
GUEST
CONTAINER
```

A capability is a directed permission edge:

```text
Capability = (subject, action, target, scope, constraints)
```

Examples:

```text
Ω(read, FileFrame)
Ω(write, DeviceFrame)
Ω(map, SharedFrame)
Ω(send, MessageFrame)
Ω(bind, DriverFrame)
Ω(update, Policy)
Ω(enter, IsolationDomain)
```

The capability check is:

```text
cap_ok(subject, action, target, s) = true
```

An operation requiring authority is valid only if:

```text
Ω permits action
∧ Ψ permits action
```

Capabilities may be granted, revoked, reduced, delegated, or scoped only through kernel-governed Ω transitions.

### 3.7 Policy

A kernel policy is:

```text
Policy = (id, scope, predicate, action, priority, mode, meta)
```

where:

| Field       | Meaning                                                      |
| ----------- | ------------------------------------------------------------ |
| `id`        | policy identifier                                            |
| `scope`     | global/process/frame/role/object/device/subsystem            |
| `predicate` | condition over kernel state and operation                    |
| `action`    | allow, deny, modify, defer, log, trap, kill, isolate, commit |
| `priority`  | resolution order                                             |
| `mode`      | enforcing, permissive, disabled, audit-only                  |
| `meta`      | τ windows, audit tags, lifecycle state                       |

Policy scopes include:

```text
GLOBAL
PROCESS(pid)
THREAD(tid)
FRAME(fid)
ROLE(r)
OBJECT(obj_id)
DEVICE(dev_id)
DRIVER(driver_id)
IPC(endpoint)
FILESYSTEM(path/frame)
```

A policy evaluates:

```text
Eval_Ψ(policy, state, operation, context) → decision
```

Possible decisions:

```text
ALLOW
DENY
MODIFY
DEFER
LOGONLY
ESCALATE
ISOLATE
HALT
```

Policies enforce kernel invariants and restrict the valid OS execution language:

```text
valid_os_trace ∈ L_PMS,Ψ_kernel
```

Policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

### 3.8 Message

A message is the basic IPC object.

```text
Message = (id, sender, receiver, type, payload, meta)
```

where:

| Field      | Meaning                                                | Operator role         |
| ---------- | ------------------------------------------------------ | --------------------- |
| `id`       | message identifier                                     | Δ                     |
| `sender`   | sender PID/TID/role                                    | Ω                     |
| `receiver` | receiver PID/TID/endpoint                              | Ω / Χ                 |
| `type`     | REQ/RESP/EVT/CTRL/SIG/TIMEOUT/...                      | Δ                     |
| `payload`  | message content                                        | ∇                     |
| `meta`     | ordering, timeout, capability, commit, policy metadata | Θ / Λ / Ω / Χ / Σ / Ψ |

Messages are usually stored inside a `MessageFrame`.

```text
MessageFrame = (id, type, queue, perms, owner, meta)
```

Message validity requires:

```text
sender has SEND capability
∧ receiver has RECEIVE visibility
∧ payload satisfies endpoint policy
∧ queue limits are respected
∧ delivery semantics are defined
```

Delivery may require Σ commit, depending on the IPC guarantee.

### 3.9 Resource Account

A resource account tracks quota-relevant state.

Canonical shorthand:

```text
RAcc = ResourceAccount
```

Canonical structure:

```text
ResourceAccount = (owner, cpu, mem, ipc, storage, net, devices, limits, meta)
```

At OS level, resource accounting is Ψ-governed and Σ-committed.

Fields include:

| Field     | Meaning                                            |
| --------- | -------------------------------------------------- |
| `cpu`     | CPU usage, quanta, deadline and τ-derived counters |
| `mem`     | allocated memory, mapped pages, heap usage         |
| `ipc`     | queue size, message rate, outstanding requests     |
| `storage` | blocks, inodes, write volume                       |
| `net`     | packet and byte counts if networking is present    |
| `devices` | driver/device resource usage                       |
| `limits`  | hard and soft quotas                               |
| `meta`    | audit and τ-window data                            |

A resource mutation follows:

```text
Δ classify resource
Ω verify authority
Ψ check quota
∇ update usage
Σ commit accounting
Ψ post-check
```

Correct resource-account notation:

```text
RAcc.mem.used > RAcc.mem.max
RAcc.cpu.used ≥ RAcc.cpu.max
RAcc.x.used + delta ≤ RAcc.x.max
```

Hierarchy examples:

```text
SystemRAcc
ContainerRAcc
UserRAcc
ProcessRAcc
ThreadRAcc
DriverRAcc
DeviceRAcc
```

Forbidden shorthand in PMS-OS resource accounting:

```text
RF
SystemRF
ContainerRF
UserRF
ProcessRF
ThreadRF
DriverRF
DeviceRF
```

`RF` is reserved for `RegisterFile` in PMS-CPU.

It must not denote a resource frame or resource account in PMS-OS.

### 3.10 Syscall Table

The syscall table defines Φ-mediated kernel entry points.

```text
SyscallEntry = (
    id,
    handler,
    policy_requirements,
    allowed_roles,
    allowed_frames,
    allowed_domains,
    operator_class,
    meta
)
```

where:

| Field                 | Meaning                                                             |
| --------------------- | ------------------------------------------------------------------- |
| `id`                  | syscall identifier                                                  |
| `handler`             | kernel handler function or dispatch target                          |
| `policy_requirements` | Ψ constraints                                                       |
| `allowed_roles`       | Ω role mask                                                         |
| `allowed_frames`      | □ frame constraints                                                 |
| `allowed_domains`     | Χ user/kernel, process, namespace, or endpoint boundary constraints |
| `operator_class`      | dominant Δ–Ψ operation class                                        |
| `meta`                | tracing, audit, accounting, timeout behavior                        |

A syscall table is not merely a dispatch array. It is a typed contract:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Meaning:

```text
Φ  syscall/trap entry
Ω  caller authority and kernel role
□  kernel syscall frame
Χ  user/kernel or endpoint boundary mediation
Δ  syscall id and argument distinction
Ψ  precheck
(...) syscall operation
Σ? commit where required
Ψ  postcheck
Φ  return / recontextualization
```

This syscall-table contract specializes the PMS-CPU trap mechanism into an OS-level syscall ABI.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

### 3.11 Scheduler State

The scheduler state is Θ-typed.

```text
SchedulerState = (rq, rq_prio, τ_sched, history, fairness_tokens, policy_state)
```

where:

| Field             | Meaning                                   |
| ----------------- | ----------------------------------------- |
| `rq`              | ready queue                               |
| `rq_prio`         | priority queues, if used                  |
| `τ_sched`         | time/accounting data as kernel meta-state |
| `history`         | scheduling history                        |
| `fairness_tokens` | fairness or quota state                   |
| `policy_state`    | scheduler policy constraints              |

The scheduler selects execution loci:

```text
Θ_select : ReadySet → SelectedThread
```

under:

```text
Ψ_scheduler(sched_state, t) = true
```

`τ_sched` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived data is sampled, compared, or used.

### 3.12 Device and Driver Structures

Devices are represented as frames.

```text
DeviceFrame = (id, type, blocksize, capacity, perms, owner, ops, state)
```

Drivers are role-bearing execution loci.

```text
Driver = (id, f_D, r_D, C_D, P_D, RAcc_D, lifecycle, devices, meta)
```

where:

| Field       | Meaning                                                            |
| ----------- | ------------------------------------------------------------------ |
| `f_D`       | driver frame                                                       |
| `r_D`       | driver role                                                        |
| `C_D`       | driver capability set                                              |
| `P_D`       | driver policy                                                      |
| `RAcc_D`    | driver resource account                                            |
| `lifecycle` | installed/loaded/probed/bound/suspended/error/quarantined/unloaded |
| `devices`   | bound devices                                                      |
| `meta`      | IRQ state, workqueues, resource usage, audit state                 |

Device and driver structures are refined in later sections of this document.

### 3.13 Event and Sync Structures

Events and synchronization objects are also frames.

```text
EventFrame = (queue, routing, filters, perms, meta)
SyncFrame  = (id, type, state, waiters, perms, meta)
```

Examples:

```text
mutex
semaphore
channel
condition variable
signal frame
timer frame
topic frame
event router
```

They combine:

```text
Δ inspect
Ω authorize
Θ order
Λ wait/timeout
∇ mutate
Σ commit
Φ handle exceptional state
Χ isolate
Ψ enforce correctness
```

### 3.14 Audit and Trace State

Audit state records operator-labeled kernel events.

```text
AuditRecord = (
    event_id,
    timestamp_or_order,
    actor,
    operation,
    operator_class,
    target,
    decision,
    result,
    metadata
)
```

A PMS-OS implementation may emit:

```text
syscall events
policy decisions
capability changes
frame mappings
context switches
IPC deliveries
filesystem commits
driver lifecycle transitions
resource-accounting updates
trap and interrupt events
```

Trace emission is an implementation/artifact choice.

Operator-labeled representability is the architecture invariant.

Trace and audit records strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 3.15 Core Data Structure Summary

| Structure                  | Dominant operators  | Purpose                               |
| -------------------------- | ------------------- | ------------------------------------- |
| `PProcess`                 | Ω, □, Χ, Θ, Φ, Σ, Ψ | process identity and execution state  |
| `Thread`                   | Θ, Δ, ∇, Λ, Φ, Σ    | schedulable execution strand          |
| `Frame`                    | □, Ω, Χ, Ψ          | memory/object/context boundary        |
| `Role`                     | Ω                   | privilege and authority structure     |
| `Capability`               | Ω                   | directed permission relation          |
| `Policy`                   | Ψ, Ω, Φ, Σ          | invariant and response rule           |
| `Message`                  | Δ, Ω, Λ, Θ, Φ, Σ    | IPC object                            |
| `ResourceAccount` / `RAcc` | Δ, ∇, Θ, Σ, Ψ       | quota/accounting structure            |
| `SyscallEntry`             | Φ, Ω, □, Χ, Δ, Ψ, Σ | kernel entry contract                 |
| `SchedulerState`           | Θ, Ψ                | dispatch and fairness state           |
| `DeviceFrame`              | □, Ω, Χ, Φ, Σ       | device context                        |
| `Driver`                   | Ω, □, Χ, Θ, Φ, Ψ    | governed driver agent                 |
| `EventFrame`               | Δ, Ω, Θ, Λ, Φ, Σ    | event routing and notification        |
| `SyncFrame`                | Δ, Ω, Θ, Λ, ∇, Σ, Ψ | synchronization primitive             |
| `AuditRecord`              | Δ, Θ, Σ, Ψ          | committed trace/accountability record |

### 3.16 Architectural Consequence

The PMS-OS kernel data model makes system state structurally inspectable.

The consequence is:

```text
Every major kernel object is represented as an operator-bearing structure
with explicit identity, frame context, authority, boundary, ordering,
commit, policy, resource-accounting, and recontextualization semantics.
```

This allows later PMS-OS sections to define processes, scheduling, syscalls, memory, storage, IPC, devices, and invariants without introducing a separate ontology for each subsystem.

### 3.17 Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-OS core data-structure model defines kernel objects as
operator-bearing structures: processes, threads, frames, roles,
capabilities, policies, messages, resource accounts, syscall entries,
scheduler state, devices, drivers, events, sync objects, and audit records.

This is an OS-level kernel data-structure architecture claim.

It does not claim a completed kernel implementation, production OS layout,
fabricated hardware substrate, external validation, or PMS Base validation.
```

---

## 4. Process and Thread Model

PMS-OS defines processes and threads as operator-typed execution structures.

A process is the persistent OS object that combines frame environment, role state, isolation boundary, local policies, resources, and schedulable threads.

A thread is the Θ-scheduled execution strand that performs PMS-CPU computation inside the process context.

The design principle is:

```text
Processes provide structured context.
Threads provide ordered execution.
```

At PMS-OS level:

```text
Process = □ + Ω + Χ-projection + Ψ + ResourceAccount
Thread  = Θ + Δ + ∇ + Λ + Φ + Σ
```

PMS Base 1.3 defines:

```text
Χ = Distance
```

PMS-OS projects Χ as concrete operating-system boundary structure:

```text
process isolation
address-space boundary
namespace separation
sandbox/container boundary
IPC visibility boundary
device-access boundary
reachability control
```

This is a layer projection.

It does not redefine PMS Base Χ.

Claim type:

```text
OS-level process/thread architecture claim
```

Boundary:

```text
This section specifies the PMS-OS process and thread architecture.

It does not claim a completed kernel implementation, production process
manager, production scheduler, fabricated hardware substrate, external
security validation, or PMS Base validation.
```

A concrete PMS-OS execution produces:

```text
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible OS executions is:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 4.1 Conceptual Model

A PMS-OS process is:

```text
Process = (FrameSet, RoleState, IsolationDomain, LocalPolicy, ThreadSet, ResourceAccount)
```

or, in kernel representation:

```text
PProcess = (id, f, r, X_p, P_local, regs, RAcc, meta)
```

A PMS-OS thread is:

```text
Thread = (tid, parentPID, regs, state, Θ_budget, wait, RAcc_ref, meta)
```

Threads inherit the process-level context:

```text
Thread(t) inherits:
    FrameSet(parentPID)
    RoleState(parentPID)
    IsolationDomain(parentPID)
    LocalPolicy(parentPID)
    ResourceAccount(parentPID)
```

Thread-local state may refine scheduling, wait, signal, register, trap, or accounting metadata, but it may not exceed the parent process’s frame, role, boundary, resource, or policy authority.

`RAcc` is the canonical shorthand for `ResourceAccount`.

`RF` must not be used in PMS-OS for resource accounting because `RF` denotes `RegisterFile` in PMS-CPU.

### 4.2 Process Identity

A process identity is Δ-typed.

```text
PID = Δ-distinguished process identifier
```

A valid PID must be:

```text
unique
∧ bound to exactly one live or closing PProcess
∧ associated with a valid lifecycle state
∧ not reused before policy permits reuse
```

Process identity is used by:

* scheduler selection;
* syscall dispatch;
* resource accounting;
* signals;
* IPC;
* filesystem ownership;
* driver/client relationships;
* audit records;
* policy evaluation.

### 4.3 Process Frame Environment

The process frame environment is □-typed.

```text
FrameSet_p = {
    CodeFrame,
    DataFrame,
    HeapFrame,
    StackFrame,
    IPCFrames,
    SharedFrames,
    FilesystemHandles,
    KernelGatewayFrame
}
```

The frame environment defines:

* executable code;
* writable data;
* heap allocation region;
* stack regions;
* shared memory;
* IPC endpoints;
* filesystem handle frames;
* permitted kernel entry surfaces.

A process may only access objects visible through its frame set and allowed by boundary and policy rules.

Frame validity requires:

```text
∀ frame ∈ FrameSet_p:
    frame_valid(frame)
    ∧ Ω permits required access
    ∧ Χ boundary projection permits visibility
    ∧ Ψ permits use
```

Frame isolation is specified through □ and Χ.

At PMS-OS level, this means frame visibility is mediated by OS isolation-domain values such as `X_p`.

### 4.4 Role and Capability Environment

The role environment is Ω-typed.

```text
RoleState_p = (r_base, CapSet, constraints)
```

It defines what the process may do.

Role/capability state governs:

* allowed syscalls;
* file and device access;
* frame mappings;
* IPC send/receive rights;
* shared-memory operations;
* policy interactions;
* privilege transitions;
* debug or introspection access.

A process may not increase its role or capability set except through a kernel-mediated Ω/Φ path.

Canonical role or capability request:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Ω ; Σ? ; Ψ ; Φ
```

Expanded:

```text
Φ enter kernel through syscall/trap
→ Ω establish kernel role and caller authority
→ □ bind kernel syscall frame
→ Χ mediate user/kernel boundary
→ Δ classify requested capability transition
→ Ψ precheck
→ Ω update role/capability state if permitted
→ Σ commit grant or denial record where required
→ Ψ postcheck
→ Φ return or recontextualize
```

This is an OS-level syscall ABI pattern built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

### 4.5 Isolation Domain

The process isolation domain is the PMS-OS projection of Χ.

At PMS Base level:

```text
Χ = Distance
```

At PMS-OS level, this projects as:

```text
process boundary
address-space boundary
namespace boundary
sandbox boundary
container boundary
device-access boundary
IPC visibility boundary
filesystem view boundary
reachability control
```

A process isolation domain may be represented as:

```text
X_p = (domain_id, visible_frames, visible_namespaces, shared_edges, restrictions)
```

`X_p` is an OS-level isolation-domain value.

It is not the PMS Base operator `Χ`.

It names a concrete PMS-OS boundary / reachability / namespace domain through which PMS Base Χ = Distance is projected at OS level.

An access across domains requires an explicit bridge:

```text
Bridge(X_i, X_j)
```

or an explicit capability:

```text
Ω(subject, action, target)
```

and policy permission:

```text
Ψ permits cross-boundary relation
```

There is no spontaneous cross-process visibility.

### 4.6 Local Policy

Each process has local policy:

```text
P_local
```

which is subordinate to kernel policy:

```text
P_effective(p) = Combine(P_kernel, P_role, P_frame, P_process, P_object)
```

Local policy may constrain:

* syscall availability;
* memory limits;
* IPC visibility;
* filesystem namespace;
* scheduling class;
* signal handling;
* debugging;
* execution mode;
* sandbox restrictions;
* resource-accounting limits.

Local policy cannot override kernel invariants.

```text
P_local may restrict.
P_local may not weaken P_kernel.
```

### 4.7 Thread Model

A thread is the schedulable execution strand inside a process.

```text
Thread = (tid, parentPID, regs, state, Θ_budget, wait, RAcc_ref, meta)
```

A thread contains:

| Field       | Meaning                                                    |
| ----------- | ---------------------------------------------------------- |
| `tid`       | thread identifier                                          |
| `parentPID` | owning process                                             |
| `regs`      | saved CPU registers                                        |
| `state`     | lifecycle state                                            |
| `Θ_budget`  | scheduling budget, priority, deadline, fairness data       |
| `wait`      | wait channel, timeout, event expectation                   |
| `RAcc_ref`  | reference to thread or process resource account            |
| `meta`      | trap flags, signal state, accounting, pending commit state |

A thread performs actual CPU execution. It is dispatched by Θ, executes Δ/∇ operations, may wait through Λ, may trap through Φ, may update resource-accounting state through Σ-governed paths, and may terminate through Σ/Ψ closure.

### 4.8 Thread States

PMS-OS defines the following canonical thread states.

| State        | Operators | Meaning                                                                 |
| ------------ | --------- | ----------------------------------------------------------------------- |
| `READY`      | Δ, Θ      | eligible for scheduler dispatch                                         |
| `RUNNING`    | ∇, Θ      | currently executing                                                     |
| `BLOCKED`    | Λ, Φ      | waiting for event, timeout, I/O, trap handling, or synchronization      |
| `SUSPENDED`  | Χ, Ω      | blocked by isolation, capability, policy, or administrative restriction |
| `ZOMBIE`     | Σ         | terminated but not fully integrated/reclaimed                           |
| `TERMINATED` | Σ + Ψ     | final closed lifecycle state                                            |

A thread is `READY` when:

```text
ready(t) :=
    Δ(t)
    ∧ ¬Λ(t)
    ∧ ¬Φ(t)
    ∧ Ψ_allow(t)
```

A thread is `BLOCKED` when:

```text
BLOCKED(t) :=
    Λ_pending(t)
    ∨ Φ_pending(t)
```

A thread is `SUSPENDED` when:

```text
SUSPENDED(t) :=
    X_restriction(t)
    ∨ Ω_deny(t)
    ∨ Ψ_suspend(t)
```

Here `X_restriction(t)` denotes restriction by an OS-level isolation-domain value, not PMS Base Χ itself.

A thread is `ZOMBIE` when:

```text
ZOMBIE(t) :=
    Σ_pending(t)
```

A thread is `TERMINATED` when:

```text
TERMINATED(t) :=
    Σ_done(t)
    ∧ Ψ_close(t)
```

### 4.9 Thread State Transitions

The thread lifecycle is an operator-typed state machine.

#### READY → RUNNING

Scheduler dispatch:

```text
READY ─Θ_dispatch→ RUNNING
```

Meaning:

```text
Θ selects the thread
Σ commits outgoing context if needed
□ switches frame
Ω installs role/capability context
Χ installs OS isolation-domain context
thread begins execution
```

#### RUNNING → READY

Quantum expiration, yield, or preemption:

```text
RUNNING ─Θ_expire/yield/preempt→ READY
```

The outgoing CPU state is saved through Σ-readable context integration.

#### RUNNING → BLOCKED

Waiting or trap-induced block:

```text
RUNNING ─Λ_wait→ BLOCKED
RUNNING ─Φ_fault/trap→ BLOCKED
```

Examples:

* waiting on IPC;
* blocking on mutex;
* page fault;
* synchronous I/O;
* timer sleep;
* syscall requiring delayed completion.

#### BLOCKED → READY

Wake-up, event arrival, timeout resolution, or trap completion:

```text
BLOCKED ─event/¬Λ/Φ_resume→ READY
```

A timeout may also wake a thread into an error-return path.

#### RUNNING → SUSPENDED

Restriction by isolation, role, or policy:

```text
RUNNING ─Χ_restrict→ SUSPENDED
RUNNING ─Ω_restrict→ SUSPENDED
RUNNING ─Ψ_suspend→ SUSPENDED
```

#### SUSPENDED → READY

Restriction lifted:

```text
SUSPENDED ─Ω_allow/Χ_release/Ψ_resume→ READY
```

#### RUNNING → ZOMBIE

Thread exit begins:

```text
RUNNING ─Σ_pending→ ZOMBIE
```

The thread has stopped executing but still has resources or lifecycle effects to integrate.

#### ZOMBIE → TERMINATED

Final cleanup:

```text
ZOMBIE ─(Σ_complete ∧ Ψ_close)→ TERMINATED
```

### 4.10 Process States

A process state is derived from its threads, frame lifecycle, policy state, and resource closure.

| Process state | Condition                                                     |
| ------------- | ------------------------------------------------------------- |
| `RUNNING`     | at least one thread is `RUNNING`                              |
| `READY`       | at least one thread is `READY`, none is `RUNNING`             |
| `BLOCKED`     | all live threads are `BLOCKED`                                |
| `SUSPENDED`   | all live threads are suspended by Χ/Ω/Ψ                       |
| `ZOMBIE`      | threads have finished, but resources are not fully integrated |
| `TERMINATED`  | all threads terminated and Σ/Ψ closure is complete            |

A process is terminated when:

```text
∀ t ∈ Threads(p): TERMINATED(t)
∧ resources_reclaimed(p)
∧ accounting_committed(RAcc_p)
∧ policy_closed(p)
```

### 4.11 Process Lifecycle Transitions

The process lifecycle includes creation, execution, blocking, suspension, exit, and reclamation.

#### Process creation

A process is created by the kernel through:

```text
Δ classify executable / template
Ω authorize creation
□ allocate FrameSet
Χ assign OS isolation-domain value X_p
Ψ attach policies
Σ commit process table entry
Σ initialize ResourceAccount
Θ enqueue initial thread
```

A valid creation sequence yields:

```text
PProcess(id, f, r, X_p, P_local, regs, RAcc, meta)
```

#### Fork or clone

A fork-like operation uses:

```text
Δ distinguish parent state
□ duplicate or share FrameSet
Χ define parent/child visibility domains
Σ commit process table entry
Σ create or link ResourceAccount
Θ enqueue child thread
Ψ verify inherited constraints
```

Copy-on-write behavior is handled later under virtual memory.

#### Exec

An exec-like operation is a controlled recontextualization:

```text
Δ identify executable
Ψ check exec policy
Σ flush or close old execution state
□ install new code/data/stack frames
∇ load image
Φ reframe execution
Ψ validate post-state
```

#### Exit

Exit is an integration and closure operation:

```text
Φ enter exit path
Σ commit final status
Θ remove from run queues
Σ release resources
Σ commit ResourceAccount closure
Ψ close lifecycle
```

Exit may produce IPC messages, signals, parent notifications, resource-accounting updates, and audit records.

### 4.12 Role and Capability Transitions

Process role transitions are kernel-mediated.

A valid role transition has the canonical OS syscall structure:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Ω ; Σ? ; Ψ ; Φ
```

Expanded:

```text
Δ identify requested transition
Φ enter kernel
Ω establish kernel role and check current authority
□ bind kernel syscall frame
Χ mediate user/kernel boundary
Ψ evaluate policy
Ω update role/capability state
Σ commit role state where required
Ψ postcheck
Φ return
```

Invalid escalation produces:

```text
Ω denial → Φ trap / Ψ denial / process suspension or termination
```

The invariant is:

```text
USER → KERNEL only via Φ_trap
KERNEL → USER only via Φ_return
```

and more generally:

```text
stronger role acquisition requires kernel-governed Ω + Ψ permission.
```

This syscall-mediated transition is an OS-level syscall ABI pattern.

It does not redefine the ordinary PMS-CPU calling convention.

### 4.13 Waiting, Blocking, and Λ

Threads block when expected events are absent.

A wait state has the form:

```text
Wait = (object, condition, deadline, policy, continuation)
```

Examples:

* no message available;
* lock unavailable;
* timer not expired;
* I/O incomplete;
* page not resident;
* child process not exited;
* signal not yet delivered.

Λ represents the non-event:

```text
expected event did not occur within current execution step
```

A timeout is:

```text
Λ_timeout := τ.now ≥ deadline ∧ event_absent
```

Here `τ` denotes time/accounting metadata.

It is not introduced as an additional PMS Base operator.

Θ orders when τ-derived data is sampled, compared, or used.

The kernel may then:

* leave the thread blocked;
* wake it with timeout status;
* recontextualize through Φ;
* retry according to Θ;
* terminate or suspend under Ψ.

### 4.14 Trap and Fault Interaction

A running thread may enter Φ through:

* syscall;
* page fault;
* illegal instruction;
* divide fault;
* role/capability violation;
* boundary violation;
* policy violation;
* signal delivery;
* interrupt handling.

The thread transitions:

```text
RUNNING ─Φ→ BLOCKED or privileged kernel continuation
```

At OS level, the kernel may model the process as blocked while the kernel handler performs work, or it may model kernel execution as a privileged continuation of the same thread.

Both views are valid if the architectural invariants hold:

```text
trap state is saved
∧ kernel frame is active
∧ kernel role is active
∧ boundary is coherent
∧ return path is policy-valid
```

A syscall or trap path follows the canonical PMS-OS entry contract:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

### 4.15 Integration and Cleanup

Σ finalizes process and thread state.

Cleanup includes:

* saving final exit status;
* closing file handles;
* releasing frames;
* releasing IPC endpoints;
* notifying parent or supervisors;
* committing resource-accounting data;
* removing scheduler entries;
* clearing capabilities;
* closing policy state;
* auditing termination.

A process may be `ZOMBIE` while these actions are pending.

Final closure requires:

```text
Σ_cleanup_complete(p)
∧ Σ_accounting_committed(RAcc_p)
∧ Ψ_lifecycle_closed(p)
```

### 4.16 Process/Thread Invariants

PMS-OS maintains the following process/thread invariants.

```text
I1: every thread has exactly one parent process

I2: every live process has a valid FrameSet

I3: every live process has a valid role/capability state

I4: every live process has a valid OS-level isolation-domain value X_p

I5: X_p is not PMS Base Χ; it is an OS-domain value through which PMS Base
    Χ = Distance is projected as process boundary and reachability control

I6: every live process has a coherent ResourceAccount RAcc

I7: no thread runs outside the effective policy of its parent process

I8: READY threads are scheduler-visible

I9: BLOCKED threads have a wait or trap cause

I10: SUSPENDED threads have a Χ/Ω/Ψ restriction cause

I11: ZOMBIE threads/processes have pending Σ cleanup

I12: TERMINATED processes have no runnable threads

I13: process resource accounting is committed before final destruction

I14: kernel return never restores an invalid user context

I15: process and thread transitions contribute to trace_os(...) and remain
     within L_PMS or L_PMS,Ψ_kernel under the declared OS profile
```

### 4.17 Architectural Consequence

The PMS-OS process and thread model defines execution hierarchy in operator terms.

The consequence is:

```text
A PMS-OS process is a frame-, role-, boundary-, policy-, and
resource-structured execution context; a PMS-OS thread is a Θ-scheduled
execution strand that runs within that context and transitions through
READY, RUNNING, BLOCKED, SUSPENDED, ZOMBIE, and TERMINATED states under
Δ–Ψ.
```

This model gives the scheduler, syscall interface, virtual memory subsystem, IPC system, and resource-accounting subsystem a shared process/thread foundation.

### 4.18 Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-OS process and thread model specifies processes as OS-level
frame-, role-, boundary-, policy-, and resource-bearing execution contexts,
and threads as Θ-scheduled execution strands inside those contexts.

This is an OS-level process/thread architecture claim.

It does not claim a completed process manager, production scheduler,
production kernel implementation, fabricated hardware substrate, external
security validation, or PMS Base validation.
```

---

## 5. Scheduling

PMS-OS scheduling is the Θ-mediated selection of executable threads under frame, role, boundary, resource, and policy constraints.

The scheduler does not merely choose “the next task.” It orders execution loci in a system where every thread carries:

```text
process frame context     □
role/capability state     Ω
OS isolation domain       Χ projection
wait / absence state      Λ
commit obligations        Σ
resource account          RAcc
policy constraints        Ψ
```

The central scheduling claim is:

```text
Scheduling in PMS-OS is Θ-ordering over runnable execution strands,
constrained by Ψ policy and mediated by □, Ω, Χ, Λ, Φ, Σ, and RAcc-governed
resource accounting.
```

Claim type:

```text
OS-level scheduling architecture claim
```

Boundary:

```text
This section specifies PMS-OS scheduling architecture.

It does not claim a completed production scheduler, production kernel,
hardware timer implementation, hardware interrupt controller, external
performance validation, or PMS Base validation.
```

In this document, `τ` denotes time/accounting metadata used by OS profiles.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived data is sampled, compared, or used for scheduling.

A concrete scheduling execution contributes to:

```text
trace_os(K, π_os, s₀) ∈ L_PMS
```

and, under active kernel policy:

```text
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible scheduling executions under a declared OS profile is part of:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and, under policy:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 5.1 Scheduler Role

The scheduler owns the transition:

```text
READY → RUNNING
```

and participates in:

```text
RUNNING → READY
RUNNING → BLOCKED
BLOCKED → READY
RUNNING → SUSPENDED
SUSPENDED → READY
RUNNING → ZOMBIE
```

The scheduler does not own the entire lifecycle of a process or thread. It orders which valid execution strand receives CPU time.

A scheduling decision is valid only if:

```text
thread is READY
∧ parent process is not TERMINATED
∧ frame context is valid
∧ role/capability state is valid
∧ OS isolation-domain value permits dispatch
∧ policy permits execution
∧ resource quotas permit progress
```

### 5.2 Scheduler State

The scheduler state is Θ-typed.

```text
SchedulerState = (rq, rq_prio, τ_sched, history, fairness_tokens, RAcc_refs, policy_state)
```

where:

| Component         | Meaning                                                      |
| ----------------- | ------------------------------------------------------------ |
| `rq`              | primary ready queue                                          |
| `rq_prio`         | priority queues or scheduling classes                        |
| `τ_sched`         | scheduler time/accounting data in meta-state                 |
| `history`         | previous dispatches, yields, preemptions, waits              |
| `fairness_tokens` | fairness or share accounting                                 |
| `RAcc_refs`       | resource-account references relevant to scheduling decisions |
| `policy_state`    | active scheduling policies and limits                        |

The scheduler selection function is:

```text
Θ_select : ReadySet → SelectedThread
```

under policy:

```text
Ψ_sched(SchedulerState, SelectedThread) = true
```

### 5.3 Ready Set

The ready set contains threads eligible for dispatch.

```text
ReadySet = { t ∈ ThreadTable | state(t) = READY ∧ Ψ_allow(t) }
```

A thread enters the ready set when:

* it is created;
* it yields;
* its wait condition resolves;
* a timeout wakes it;
* an event arrives;
* a trap or syscall completes;
* policy resumes it;
* a suspension is lifted.

A thread leaves the ready set when:

* it is dispatched;
* it blocks;
* it is suspended;
* it exits;
* a policy makes it unselectable;
* resource limits prevent further execution.

### 5.4 Scheduling Cycle

A full scheduling cycle has the following structure:

```text
Θ_tick
→ Θ_update_queues
→ Ψ_sched_check
→ Θ_select
→ Θ_dispatch
→ execution interval
→ Θ_yield_or_preempt
```

Expanded:

```text
Θ_tick
; Θ_update_ready_set
; Δ classify runnable candidates
; Ψ evaluate scheduling constraints
; Δ classify ResourceAccount state where relevant
; Θ_select selected thread
; Σ save outgoing context if required
; □ switch frame context
; Ω install role/capability state
; Χ install OS isolation-domain context
; Ψ validate dispatch
; Θ_dispatch
```

The selected thread then executes PMS-CPU steps until it yields, blocks, traps, is preempted, or terminates.

### 5.5 Context Switch

A context switch is not merely a register swap.

A PMS-OS context switch is:

```text
Θ-triggered ordering transition
+ Σ-save of outgoing transient state
+ □ frame switch
+ Ω role/capability switch
+ Χ OS isolation-domain switch
+ Ψ validity check
```

Canonical form:

```text
Θ_switch(t_old, t_new) =
    Σ_save(t_old)
    ; □_set(frame(t_new))
    ; Ω_set(role(t_new))
    ; Χ_set(domain(t_new))
    ; Ψ_check(dispatch(t_new))
    ; Θ_start(t_new)
```

This means:

| Phase                  | Operator | Meaning                                 |
| ---------------------- | -------- | --------------------------------------- |
| select next thread     | Θ        | order execution                         |
| save outgoing state    | Σ        | integrate transient CPU state           |
| switch address/context | □        | install frame set                       |
| switch authority       | Ω        | install role/capabilities               |
| switch boundary        | Χ        | install OS isolation-domain value       |
| validate               | Ψ        | enforce scheduling and execution policy |
| resume                 | Θ        | begin ordered execution                 |

A context switch is invalid if it restores an incoherent frame, role, boundary, register, resource, or policy state.

### 5.6 Preemption

Preemption interrupts a running thread and returns it to an eligible or blocked state.

```text
RUNNING(t) ─Θ_preempt→ READY(t)
```

Preemption may be caused by:

* quantum expiration;
* higher-priority runnable thread;
* timer interrupt;
* policy trigger;
* resource quota;
* blocking system event;
* driver or interrupt completion requiring wakeup of another thread.

Preemption sources include:

```text
Θ_quantum_expire
Ω_priority_intrusion
Φ_interrupt
Ψ_policy_trigger
Λ_timeout_resolution
RAcc_quota_event
```

Preemption must preserve:

```text
register state
frame state
role/capability state
OS isolation-domain state
pending commit state
trap state
policy state
resource-accounting state
```

If this preservation cannot be guaranteed, preemption must enter a Φ recovery path rather than silently corrupting execution.

### 5.7 Blocking and Wake-Up

A running thread blocks when it waits for an event that is not yet present.

```text
RUNNING ─Λ_wait→ BLOCKED
```

Blocking causes include:

* waiting for IPC;
* waiting for a lock;
* waiting for a device completion;
* waiting for a timer;
* waiting for filesystem I/O;
* waiting for child exit;
* waiting for policy or resource availability.

A blocked thread becomes ready when the expected event occurs or the wait condition resolves:

```text
BLOCKED ─event/¬Λ→ READY
```

Timeouts are represented as Λ outcomes:

```text
Λ_timeout := τ.now ≥ deadline ∧ event_absent
```

A timeout may produce:

* normal timeout return;
* retry;
* scheduling delay;
* policy denial;
* Φ recontextualization;
* process termination under policy.

### 5.8 Scheduling Algorithms

PMS-OS does not mandate one concrete scheduling algorithm. It specifies the operator structure within which algorithms are valid.

#### Round-Robin

Round-robin scheduling is:

```text
Θ_select := Θ_rr(rq, ptr)
```

where `ptr` is the rotating queue index.

Quantum expiration:

```text
τ_sched.quantum(t) = 0 ⇒ Θ_switch(t, next)
```

Round-robin is valid when:

```text
all READY threads eventually become selectable
∧ policy does not exclude them
∧ resource constraints permit progress
```

#### Priority Scheduling

Priority scheduling uses Ω or policy-derived priority structure.

```text
Θ_select(rq_prio) :=
    pick highest-priority READY thread
```

Preemption condition:

```text
priority(t_new) > priority(t_current) ⇒ Θ_preempt
```

Priority scheduling is valid when starvation policy is explicit.

#### Weighted Fair Scheduling

Weighted fairness uses scheduler tokens.

```text
Θ_select(rq) := argmax_t fairness_tokens(t)
```

Fairness policy:

```text
∀ t:
    if ready(t) infinitely often
    ∧ Ψ permits t
    ⇒ scheduled(t) infinitely often
```

This is a Ψ-constrained fairness invariant, not an informal promise.

#### Deadline Scheduling

Deadline scheduling selects the thread with the earliest deadline.

```text
Θ_select(rq) := argmin_t deadline(t)
```

Deadlines are stored as scheduler meta-state data. Θ orders deadline checks; it is not physical time itself.

#### Hierarchical Scheduling

Hierarchical scheduling composes groups, roles, containers, or isolation domains.

```text
Θ_select =
    Θ(group)
    → Θ(role_class)
    → Θ(process)
    → Θ(thread)
```

Policy may constrain each level:

```text
Ψ_group ∧ Ψ_role ∧ Ψ_process ∧ Ψ_thread
```

Resource accounts may also constrain each level:

```text
SystemRAcc
ContainerRAcc
UserRAcc
ProcessRAcc
ThreadRAcc
```

### 5.9 Scheduler Policy

The scheduler policy engine is the Ψ layer over Θ.

It may enforce:

* no starvation;
* CPU share limits;
* max latency;
* priority ceilings;
* real-time reservations;
* isolation-domain quotas;
* per-role scheduling limits;
* driver and interrupt budget limits;
* fairness among containers or process groups;
* maximum blocked time;
* maximum lock hold time.

Policy evaluation:

```text
Ψ_sched(sched_state, candidate_thread) → decision
```

Possible outcomes:

```text
ALLOW_SELECT
DENY_SELECT
DEFER
DOWNGRADE_PRIORITY
SUSPEND
ESCALATE_TO_Φ
TERMINATE
```

A READY thread can therefore be scheduler-visible but temporarily unselectable under policy.

Scheduler escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

### 5.10 Scheduling and Resource Accounting

Scheduling interacts with resource accounting.

On each scheduling tick or dispatch interval:

```text
Θ orders accounting point
Δ classifies account and resource kind
∇ updates usage counters
Σ commits ResourceAccount state
Ψ checks quota
```

Canonical accounting flow:

```text
Θ_tick
→ Δ identify running thread
→ Δ identify RAcc
→ ∇ update CPU usage
→ Σ commit RAcc
→ Ψ check limits
```

Correct notation:

```text
RAcc.cpu.used ≥ RAcc.cpu.max
RAcc.x.used + delta ≤ RAcc.x.max
```

If a quota is exceeded, the kernel may:

* reduce priority;
* throttle the thread;
* stop selecting the thread;
* send a signal or event;
* suspend the process;
* terminate under policy.

Resource accounting is refined in Section 9.

`RF` is not used for resource accounting in PMS-OS.

### 5.11 Scheduling and Isolation Domains

Isolation domains may have independent scheduler instances.

```text
Χ(domain_i) ⟂ Χ(domain_j)
```

At OS level, the domain identifiers are concrete isolation-domain values, such as:

```text
X_i
X_j
X_p
```

These values are not PMS Base Χ.

They are OS-level domains through which PMS Base Χ = Distance is projected as boundary, reachability, namespace, and visibility control.

Each domain may have:

```text
Θ_i : ReadySet_i → SelectedThread_i
```

Examples:

* process group scheduler;
* container scheduler;
* VM scheduler;
* per-core scheduler;
* real-time scheduler domain;
* driver workqueue scheduler.

The global scheduler may compose these:

```text
Θ_global
→ Θ_domain
→ Θ_process
→ Θ_thread
```

Χ determines whether one domain can observe, influence, preempt, or account for another.

### 5.12 Scheduling and Φ Events

Interrupts, traps, syscalls, and faults interact with scheduling through Φ.

Examples:

```text
timer interrupt       → Φ_timer → Θ_preempt
page fault            → Φ_pagefault → BLOCKED
I/O completion IRQ    → Φ_device → READY(waiter)
syscall sleep         → Φ_syscall → BLOCKED
signal delivery       → Φ_signal → handler frame
policy violation      → Φ_policy → SUSPENDED or TERMINATED
```

The scheduler does not treat these as external anomalies. They are context-shift events that modify thread state and ready-set membership.

Syscall-induced scheduling changes follow the canonical PMS-OS syscall contract:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

### 5.13 Scheduler Correctness Conditions

A PMS-OS scheduler is valid when it satisfies:

```text
S1: only READY threads may be dispatched

S2: dispatched thread state becomes RUNNING

S3: outgoing thread state is saved before replacement

S4: frame switch is coherent

S5: role/capability switch is coherent

S6: OS isolation-domain state is coherent

S7: scheduling policy permits the selected thread

S8: resource accounting is updated according to policy

S9: blocked threads have a wait/trap/event cause

S10: suspended threads have a Χ/Ω/Ψ cause

S11: termination removes thread from future dispatch

S12: no scheduler transition silently violates Ψ_kernel

S13: X_p, X_i, and X_j are OS-level domain values, not PMS Base Χ

S14: scheduling traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile
```

### 5.14 Scheduling Summary

PMS-OS scheduling can be summarized as:

```text
Θ controls which thread runs, when, and under which ordered execution
conditions, while Ψ constrains fairness, priority, resource limits,
latency, and isolation boundaries.
```

The scheduler is the structural backbone of kernel execution because it connects:

```text
process lifecycle
thread states
interrupts
timeouts
syscalls
IPC
resource accounting
driver work
policy enforcement
```

### 5.15 Architectural Consequence

The PMS-OS scheduler is an operator-typed ordering engine.

The consequence is:

```text
PMS-OS scheduling is not an ad hoc queue discipline. It is Θ-mediated
execution ordering over valid threads, constrained by frame, role,
boundary, resource, trap, commit, and policy state.
```

This establishes the scheduling foundation for syscalls, memory management, IPC, events, devices, and drivers.

### 5.16 Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-OS scheduling model specifies Θ-mediated dispatch, preemption,
blocking, wake-up, context switching, scheduling policy, resource-account
interaction, and isolation-domain composition for OS-level threads.

This is an OS-level scheduling architecture claim.

It does not claim a completed production scheduler, hardware timer
implementation, hardware interrupt controller, production performance
validation, production kernel implementation, or PMS Base validation.
```

---

## 6. Isolation and Protection

PMS-OS isolation and protection define who may act, where they may act, and under which constraints.

At PMS-OS level, protection is built from:

```text id="z1g9bu"
□ frames
Ω roles and capabilities
Χ Distance projection as isolation / boundary / reachability
Ψ policy invariants
Φ fault and trap handling
Σ commit discipline
```

PMS Base 1.3 defines:

```text id="zm7ur1"
Χ = Distance
```

PMS-OS projects Χ as concrete operating-system boundary structure:

```text id="ov47sa"
process isolation
address-space separation
namespace boundary
sandbox boundary
container boundary
device boundary
driver boundary
IPC visibility boundary
filesystem view boundary
DMA boundary
reachability control
```

The central isolation claim is:

```text id="av3ex7"
PMS-OS protects system state by making every access frame-scoped,
capability-governed, boundary-constrained, policy-checked, and
commit-visible only under declared OS rules.
```

Claim type:

```text id="xjqdi7"
OS-level isolation and protection architecture claim
```

Boundary:

```text id="q0fsut"
This section defines OS-level isolation and protection architecture.

It does not claim a completed production kernel.

It does not claim external security validation.

It does not claim fabricated hardware substrate.

It does not replace the runtime-security architecture of
06_runtime_security.md.

It does not validate PMS Base.
```

A concrete PMS-OS protection execution produces:

```text id="ceuezi"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="orebbe"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible OS protection executions is:

```text id="via81q"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="tmj4fq"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 6.1 Isolation as Distance Projection

At PMS Base level:

```text id="utrzxm"
Χ = Distance
```

At PMS-OS level, Χ projects as:

```text id="d9ydl0"
process isolation
address-space separation
namespace boundary
sandbox boundary
container boundary
device boundary
driver boundary
IPC visibility boundary
filesystem view boundary
DMA boundary
```

This is an implementation-layer projection.

PMS-OS does not redefine Χ.

It makes Distance operational as system-level boundary and reachability control.

The concrete OS-level domain values used in this document include:

```text id="w0htb1"
X_user
X_global
X_p
X_i
X_j
```

These are OS-level isolation-domain values.

They are not the PMS Base operator `Χ`.

They name concrete PMS-OS boundary, reachability, namespace, filesystem-view, device, IPC, or process domains through which PMS Base Χ = Distance is projected at OS level.

### 6.2 Isolation as Frame Separation

The primary OS isolation structure is the frame.

A process owns or observes a set of frames:

```text id="ef7kmo"
FrameSet_p = { f_code, f_data, f_heap, f_stack, f_ipc, f_files, f_shared, ... }
```

Isolation means:

```text id="hvhhkg"
process p may access frame f
iff f ∈ VisibleFrames(p)
   ∧ Ω permits operation
   ∧ Χ projection permits reachability
   ∧ Ψ permits access
```

A direct cross-frame operation is invalid unless an explicit bridge exists.

```text id="h2i0v5"
Χ_isolated(f_i, f_j) ⇒ no direct Δ/∇/□ access
```

Shared access requires:

```text id="szkoiu"
Bridge(f_i, f_j)
∧ Ω grants operation
∧ Ψ permits sharing
∧ Σ commits the sharing relation
```

Frame isolation is specified through □ and Χ at OS architecture level.

It does not claim a particular hardware MMU implementation.

### 6.3 Isolation Graph

PMS-OS may model isolation as a graph.

```text id="tvw2ku"
G_iso = (F, E)
```

where:

| Symbol | Meaning                      |
| ------ | ---------------------------- |
| `F`    | frames or frame domains      |
| `E`    | permitted reachability edges |

Χ removes or prevents edges:

```text id="tyc2p7"
Χ_blocks(f_i, f_j) ⇒ (f_i, f_j) ∉ E
```

Policy may add, remove, restrict, or quarantine edges through kernel-mediated transitions.

Valid reachability:

```text id="ccrqe7"
reachable(f_i, f_j)
∧ Ω permits action
∧ Ψ permits relation
```

No spontaneous edge creation is allowed.

A new edge requires a typed kernel transition:

```text id="rbyfil"
Δ identify relation
Ω authorize relation
□ bind relevant frames
Χ update permitted reachability
Ψ check policy
Σ commit edge
```

### 6.4 Role of Ω in Protection

Ω defines asymmetric access.

A role determines the set of actions a subject may perform:

```text id="f56zij"
AllowedOps(role, target_frame)
```

or:

```text id="m3h928"
Ω(r, action, target) = allowed | denied
```

Examples:

```text id="b4zifo"
Ω(USER, read, own_data_frame) = allowed
Ω(USER, write, kernel_frame) = denied
Ω(KERNEL, map, user_frame) = allowed
Ω(DRIVER_NET, write, net_mmio_frame) = allowed
Ω(DRIVER_NET, write, storage_mmio_frame) = denied
```

Ω answers:

```text id="wmkfhm"
who may act?
```

Χ answers:

```text id="yhf00f"
what boundary or distance relation constrains visibility?
```

Ψ answers:

```text id="sykzyk"
is this action valid under active invariants and policies?
```

These three checks are distinct.

A permitted role does not automatically remove boundary constraints.

A reachable boundary does not automatically grant authority.

A syntactically valid action may still be policy-denied.

### 6.5 Capability Model

A capability is a directed permission relation.

```text id="ytb5uk"
Capability = (subject, action, target, scope, constraints)
```

Examples:

```text id="n5f32p"
C_read_file     = (pid, read, FileFrame, fd_scope, constraints)
C_write_ipc     = (pid, send, MessageFrame, endpoint_scope, constraints)
C_map_shared    = (pid, map, SharedFrame, mapping_scope, constraints)
C_driver_mmio   = (driver, write, DeviceFrame, driver_scope, constraints)
C_policy_update = (role, update, PolicySet, kernel_scope, constraints)
```

Capability validity:

```text id="q7r1br"
cap_valid(C, s) iff
    subject exists
    ∧ target exists
    ∧ action is defined
    ∧ scope is active
    ∧ constraints hold
    ∧ Ψ permits C
```

Capabilities may be:

* granted;
* revoked;
* delegated;
* narrowed;
* expired;
* suspended;
* quarantined;
* audited.

All such changes are Ω transitions and require kernel-mediated policy checks.

A capability grant follows the canonical OS syscall / kernel-entry structure when requested from user context:

```text id="rtfkt5"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Ω ; Σ? ; Ψ ; Φ
```

This is an OS-level syscall ABI pattern built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

### 6.6 Memory Protection

Memory protection combines frames, capabilities, and isolation domains.

A memory region is represented as a frame:

```text id="jh8j5r"
MemFrame = (id, base, size, type, perms, owner, links, meta)
```

Access rule:

```text id="sfn3c1"
AccessAllowed(subject, region, op) iff
    region ∈ VisibleFrames(subject)
    ∧ Ω(role(subject), op, region)
    ∧ no Χ-projected barrier blocks reachability
    ∧ Ψ permits op
```

For load/store:

```text id="yjyeqp"
∇_read/write(subject, region)
```

is valid only if:

```text id="sllmxi"
AccessAllowed(subject, region, read/write)
```

Violations produce Φ:

```text id="kkh3nt"
invalid memory access → Φ_pagefault / Φ_protection_fault
```

Memory protection may use MMU-like, page-table-like, segment-like, or frame-table-like mechanisms in an implementation.

This section specifies the OS-level protection semantics.

It does not claim actual MMU circuitry or fabricated memory hardware.

### 6.7 Kernel/User Separation

Kernel and user frames are separated.

```text id="tjvlsc"
□_user ⟂ □_kernel
```

Role hierarchy:

```text id="mu285i"
Ω(kernel) > Ω(user)
```

User code may enter kernel only through Φ:

```text id="mj6ylm"
USER → KERNEL only via Φ_trap
KERNEL → USER only via Φ_return
```

At the OS syscall level, controlled kernel entry follows:

```text id="dhm03e"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Meaning:

| Operator | OS syscall role                  |
| -------- | -------------------------------- |
| Φ        | kernel entry / trap              |
| Ω        | kernel role and caller authority |
| □        | kernel syscall frame             |
| Χ        | user/kernel boundary mediation   |
| Δ        | syscall and argument distinction |
| Ψ        | precheck                         |
| `(…)`    | syscall body                     |
| `Σ?`     | commit where required            |
| Ψ        | postcheck                        |
| Φ        | return / close / recontextualize |

The PMS-OS syscall convention is a dedicated OS-level syscall ABI built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It also does not replace the PMS-CPU trap/syscall control-transfer model; it specializes that model into kernel-service entry, dispatch, validation, commit, and return.

User code may not:

* map kernel frames;
* write kernel memory;
* execute kernel-only code;
* alter kernel policy;
* forge kernel capabilities;
* install device mappings;
* bypass syscall entry;
* return from kernel with elevated role.

Kernel return requires:

```text id="f8bdzb"
user frame valid
∧ user role restored
∧ boundary coherent
∧ policy permits return
```

### 6.8 Address Spaces as Frames

An address space is a frame set.

```text id="muuk9y"
VAS(p) = □_p
```

with mapping:

```text id="rwha65"
map_p : VirtualAddress → Frame
```

A memory operation resolves:

```text id="phm5xp"
VA
→ Δ classify page/segment
→ □ select frame
→ Ω check permission
→ Χ check boundary
→ Ψ check policy
→ ∇ read/write
→ Σ commit if required
```

Address-space switching is a □/Χ operation ordered by Θ and often caused by scheduling or Φ entry.

```text id="zmybfg"
context_switch(p_old, p_new):
    Σ_save(p_old)
    □_set(VAS(p_new))
    Χ_set(X_p_new)
    Ω_set(RoleState(p_new))
    Θ_resume(p_new)
```

`X_p_new` is an OS-level isolation-domain value.

It is not PMS Base Χ.

It records the process boundary / reachability domain installed for the resumed process.

### 6.9 Process Isolation

Each process has:

```text id="d7mtth"
X_p = (domain_id, visible_frames, visible_namespaces, restrictions)
```

`X_p` is an OS-level isolation-domain value.

It is not the PMS Base operator `Χ`.

It names a concrete PMS-OS boundary, reachability, namespace, and visibility domain through which PMS Base Χ = Distance is projected at OS level.

Process isolation ensures:

```text id="sckf77"
p_i cannot access p_j frames unless explicit sharing is established
```

Sharing requires:

```text id="x12rap"
Δ identify sharing request
Ω authorize both parties
Ψ evaluate sharing policy
□ create or expose shared frame
Χ add permitted bridge
Σ commit sharing relation
```

Without this sequence, cross-process access is invalid.

### 6.10 Namespace Isolation

PMS-OS treats namespaces as frame views.

Examples:

* filesystem root;
* mount namespace;
* IPC namespace;
* device namespace;
* network namespace;
* user/role namespace;
* process visibility namespace.

A namespace is:

```text id="dfyhnv"
NamespaceFrame = (id, root, entries, owner, perms, policy, meta)
```

Namespace isolation means:

```text id="sp7qmf"
process p sees name n only if n ∈ NamespaceFrame(p)
```

Cross-namespace resolution requires explicit policy and capability.

```text id="iw9u0s"
Δ resolve name
□ bind namespace frame
Ω authorize lookup
Χ permit namespace visibility
Ψ permit relation
```

### 6.11 IPC Protection

IPC endpoints are frames.

```text id="tz8g8s"
MessageFrame = (id, type, queue, perms, owner, meta)
```

A send is valid only if:

```text id="c0xrii"
Ω(sender, send, MessageFrame)
∧ Χ permits endpoint visibility
∧ Ψ permits message relation
```

A receive is valid only if:

```text id="xyempe"
Ω(receiver, receive, MessageFrame)
∧ Χ permits receiver visibility
∧ Ψ permits delivery
```

IPC protection prevents:

* unauthorized sends;
* unauthorized receives;
* capability smuggling;
* cross-domain message leaks;
* queue exhaustion beyond quota;
* uncommitted delivery ambiguity.

IPC delivery may update resource accounting:

```text id="u704vl"
Δ classify IPC resource
∇ update usage
Σ commit RAcc
Ψ check quota
```

Full IPC semantics are defined in Section 15.

### 6.12 Filesystem Protection

Filesystem objects are frames.

```text id="mzhmcq"
FileFrame
DirFrame
HandleFrame
MountFrame
NamespaceFrame
```

A file operation is valid when:

```text id="dwc2g1"
Δ resolves object
∧ Ω permits operation
∧ Χ permits namespace visibility
∧ Ψ permits filesystem policy
∧ Σ commits changes if mutating
```

Filesystem isolation supports:

* per-process roots;
* chroot-like views;
* container mount namespaces;
* read-only mounts;
* append-only logs;
* user and role permissions;
* per-object policies.

Full filesystem architecture is defined in Section 12.

### 6.13 Device and Driver Protection

Devices are frames, and drivers are Ω-governed roles.

```text id="nfgjfs"
DeviceFrame = (id, type, perms, owner, ops, state)
Driver = (id, f_D, r_D, C_D, P_D, RAcc_D)
```

Driver access is valid only if:

```text id="u2egp7"
driver role has capability
∧ device frame is assigned
∧ DMA or MMIO boundary is valid
∧ policy permits the operation
```

Device protection prevents:

* arbitrary MMIO access;
* DMA into unauthorized memory;
* driver access to unassigned devices;
* stale access after hotplug detach;
* driver continuation after quarantine;
* cross-device capability leakage.

Driver resource use is tracked through `RAcc_D`.

`RF` is not used as a resource-account shorthand in PMS-OS.

Full device and driver lifecycle is defined in Section 16.

### 6.14 Sandbox and Container Boundaries

A sandbox or container is a structured isolation domain.

```text id="yh0dfe"
Container = (FrameSet, NamespaceSet, RoleSet, PolicySet, RAcc)
```

It constrains:

* visible processes;
* address spaces;
* IPC endpoints;
* filesystem roots;
* devices;
* capabilities;
* network surfaces, if present;
* scheduler and resource shares.

Entering a container boundary requires:

```text id="k3v50k"
Δ identify container
Ω authorize entry
□ switch frame/namespace context
Χ enter OS isolation-domain value
Ψ attach policy
Σ commit context transition
```

Exiting requires a valid reverse path or a kernel-mediated Φ transition.

Container-domain identifiers are OS-level values.

They are not PMS Base Χ itself.

### 6.15 Quarantine

Quarantine is a stronger isolation state.

```text id="xigzkx"
Χ_quarantine(subject)
```

may apply to:

* process;
* thread;
* driver;
* device;
* IPC endpoint;
* filesystem subtree;
* namespace;
* container.

Quarantine effects may include:

* remove from ready set;
* revoke capabilities;
* restrict frame visibility;
* block device access;
* disable IPC delivery;
* freeze filesystem writes;
* redirect syscalls;
* require audit;
* terminate under policy.

Quarantine is not a moral or forensic judgment.

It is an OS-level isolation response to a policy or invariant condition.

Quarantine escalation is kernel-internal recontextualization and protection-state management.

It is not governance authority.

### 6.16 Protection Faults

Protection failures are Φ events.

Examples:

| Failure                     | Operator reading                 |
| --------------------------- | -------------------------------- |
| invalid address             | Δ/□ failure → Φ                  |
| unauthorized memory access  | Ω/Χ/Ψ failure → Φ                |
| illegal role transition     | Ω/Ψ failure → Φ                  |
| user access to kernel frame | Χ/Ω failure → Φ                  |
| unauthorized IPC send       | Ω/Ψ failure → Φ                  |
| policy violation            | Ψ failure → Φ or halt            |
| stale device access         | □/Χ/Ψ failure → Φ                |
| invalid commit              | Σ/Ψ failure → Φ                  |
| resource quota violation    | Ψ/RAcc failure → Φ or throttling |

Fault handling may:

* return an error;
* block the thread;
* kill the process;
* quarantine a subsystem;
* roll back state;
* log and continue;
* halt under critical policy.

Protection fault handling remains operator-typed.

It must not silently mutate kernel-visible state.

### 6.17 Isolation Invariants

PMS-OS maintains the following protection invariants.

```text id="d23s6f"
I1: user frames do not directly write kernel frames

I2: kernel entry occurs only through Φ

I3: kernel exit restores valid user frame, role, and boundary state

I4: every privileged action has an Ω capability basis

I5: every cross-boundary access has an explicit Χ-permitted relation

I6: every shared frame is policy-authorized

I7: every namespace crossing is policy-authorized

I8: every device mapping is driver- and policy-authorized

I9: every DMA region is bounded by an explicit frame

I10: every policy mutation occurs in a kernel-governed frame

I11: every protection failure has a Φ/Ψ-defined response

I12: no protection decision silently bypasses Ψ_kernel

I13: X_user, X_global, X_p, X_i, and X_j are OS-level isolation-domain
     values, not PMS Base Χ

I14: PMS Base Χ = Distance

I15: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, device boundary, IPC visibility, filesystem view,
     sandbox/container boundary, DMA boundary, and reachability control

I16: Resource accounting uses RAcc / ResourceAccount notation; RF is reserved
     for PMS-CPU RegisterFile

I17: protection traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile
```

### 6.18 Boundary to Runtime Security

This section defines OS-level isolation and protection.

It specifies the protection substrate:

```text id="k95gzf"
frames
roles
capabilities
boundaries
kernel policy
fault handling
commit discipline
resource-account interaction
```

It does not attempt to cover the full runtime-security architecture, such as:

* deep audit semantics;
* governance hardening;
* adversarial policy analysis;
* runtime attestation;
* exploit-class taxonomy;
* distributed trust;
* evidence pipelines;
* policy lifecycle across organizations;
* deployment-facing security profiles.

Those belong in `06_runtime_security.md`.

The boundary is:

```text id="dzp8r6"
04_pms_os.md defines OS-level protection substrate.

06_runtime_security.md defines runtime-security architecture, governance
hardening, adversarial security, audit/evidence hardening, and
deployment-facing security profiles.
```

This section does not make PMS-OS a moral tribunal, forensic authority, or governance oracle.

### 6.19 Architectural Consequence

PMS-OS protection is structural, not ad hoc.

The consequence is:

```text id="x0ezgi"
Every OS-level access is valid only when its frame context, role authority,
boundary reachability, commit state, resource-accounting state, and policy
constraints all permit it.
```

This gives PMS-OS a unified protection model for memory, processes, syscalls, IPC, filesystems, devices, drivers, namespaces, containers, and kernel entry/exit.

### 6.20 Boundary Statement

The correct boundary for this chapter is:

```text id="ht9u5v"
The PMS-OS isolation and protection model specifies OS-level frame
separation, role/capability authority, process and namespace isolation,
IPC/file/device protection, sandbox/container boundaries, quarantine,
protection faults, and protection invariants through Δ–Ψ operator
structure.

This is an OS-level isolation and protection architecture claim.

It does not claim a completed production kernel, production security
subsystem, fabricated hardware isolation mechanism, external security
validation, governance authority, forensic authority, moral judgment, or
PMS Base validation.
```

---

## 7. Kernel Policy Engine

The Kernel Policy Engine is the PMS-OS realization of Ψ.

It constrains kernel-visible execution by evaluating policies over operator-typed transitions. It does not replace the kernel’s functional subsystems; it binds their transitions to invariants, permissions, lifecycle rules, resource constraints, and recovery actions.

The Kernel Policy Engine may be written as:

```text id="z4y82a"
KPE = (PSet_k, Eval_Ψ, Hooks, Actions, Resolution, Cache, Audit)
```

where:

| Component    | Meaning                                       |
| ------------ | --------------------------------------------- |
| `PSet_k`     | active kernel policy set                      |
| `Eval_Ψ`     | policy evaluation function                    |
| `Hooks`      | operator-specific enforcement points          |
| `Actions`    | possible enforcement responses                |
| `Resolution` | combination logic for multiple policy results |
| `Cache`      | optional decision cache for repeated checks   |
| `Audit`      | optional committed trace/audit output         |

The central policy-engine claim is:

```text id="yltkv6"
PMS-OS treats policy as an operator-level validity constraint over
kernel transitions, not as an external advisory layer.
```

Claim type:

```text id="vub0yi"
OS-level kernel policy-engine architecture claim
```

Boundary:

```text id="u5js31"
This section specifies the PMS-OS kernel policy-engine architecture.

It does not claim a completed production policy engine.

It does not claim external security validation.

It does not make PMS-OS a moral tribunal, forensic authority, or governance
oracle.

It does not validate PMS Base.
```

A concrete PMS-OS policy-governed execution produces:

```text id="wq7iyn"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="uucll4"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible OS executions is:

```text id="f5qdrw"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="bm7b6g"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 7.1 Structural Role

The Kernel Policy Engine governs transitions involving:

```text id="vnllry"
Δ distinction
∇ mutation
□ frame changes
Ω role/capability changes
Θ scheduling and ordering
Λ waits and timeouts
Φ traps and recontextualization
Χ isolation and boundary changes
Σ commit and integration
```

A kernel transition is valid only if:

```text id="coimor"
operator_preconditions_hold
∧ frame/role/boundary conditions hold
∧ Eval_Ψ(PSet_k, state, operation, context) permits it
```

Policy therefore narrows the valid OS execution language:

```text id="aauj6f"
L_PMS,Ψ_kernel ⊆ L_PMS
```

At OS level:

```text id="x9fes8"
valid_os_trace ∈ L_PMS,Ψ_kernel
```

More explicitly:

```text id="qgk0s6"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

This is a kernel-architecture claim.

It does not make PMS-OS a moral tribunal, forensic authority, or governance oracle.

It defines how the OS constrains its own transitions.

### 7.2 Policy Object

A kernel policy is:

```text id="w415qe"
Policy = (id, scope, mode, priority, predicate, action, meta)
```

where:

| Field       | Meaning                                                |
| ----------- | ------------------------------------------------------ |
| `id`        | policy identifier                                      |
| `scope`     | where the policy applies                               |
| `mode`      | enforcing, permissive, disabled, audit-only            |
| `priority`  | resolution order                                       |
| `predicate` | condition over state, operation, and context           |
| `action`    | response if the predicate matches or fails             |
| `meta`      | τ windows, audit tags, version, owner, lifecycle state |

Typical scopes:

```text id="qpasft"
GLOBAL
PROCESS(pid)
THREAD(tid)
FRAME(fid)
ROLE(r)
OBJECT(obj_id)
DEVICE(dev_id)
DRIVER(driver_id)
IPC(endpoint)
FILESYSTEM(path_or_frame)
SYSCALL(syscall_id)
SCHEDULER(class_or_domain)
RESOURCE_ACCOUNT(RAcc_id)
```

A policy predicate may inspect:

```text id="l9hvb9"
actor
target
operator class
concrete operation
frame context
role/capability state
OS isolation-domain value
resource account RAcc
τ-derived timing/accounting data
history summary
pending commit state
trap or fault state
```

A policy must be expressible as a constraint over kernel state and operation context.

It is not an untyped side channel.

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived data is sampled, compared, cached, or used.

### 7.3 Policy Modes

PMS-OS supports multiple policy modes.

| Mode              | Meaning                                                               |
| ----------------- | --------------------------------------------------------------------- |
| `ENFORCING`       | policy decision affects execution                                     |
| `PERMISSIVE`      | decision is computed and audited, but execution proceeds              |
| `AUDIT_ONLY`      | policy exists for observation and reporting                           |
| `DISABLED`        | policy is inactive                                                    |
| `QUARANTINE_ONLY` | policy does not deny ordinary operation, but may isolate on violation |
| `FAIL_CLOSED`     | evaluation failure denies execution                                   |
| `FAIL_OPEN`       | evaluation failure permits execution but records an audit event       |

A PMS-OS profile should define which modes are available and which are allowed for each policy class.

Critical kernel invariants should normally be fail-closed.

Fail-open modes are profile-level decisions and must be explicitly scoped.

They must not silently weaken kernel invariants.

### 7.4 Policy Hooks

The Kernel Policy Engine attaches to operator-specific kernel hooks.

A hook is a point where the kernel asks:

```text id="xmqqmx"
May this operator-typed transition proceed?
```

The general hook interface is:

```text id="v2erq3"
PolicyHook = (operator_class, operation, state, context)
```

and evaluation is:

```text id="u6tqkt"
decision = Eval_Ψ(PSet_k, state, operation, context)
```

#### 7.4.1 Δ-hooks — Distinction and Decision

Δ-hooks apply when the kernel distinguishes among possible paths.

Examples:

* syscall dispatch;
* IPC route selection;
* filesystem lookup decision;
* scheduler candidate selection;
* device-driver match;
* namespace resolution;
* policy selection itself;
* resource-account selection.

Policy examples:

```text id="b9l97d"
deny syscall class for ROLE_GUEST
rewrite open(path) into process namespace root
deny following symlink across namespace boundary
deny driver probe for untrusted device class
classify RAcc before quota mutation
```

Δ-hooks constrain what distinctions may become executable branches.

For syscall dispatch, the Δ-hook appears inside the canonical PMS-OS syscall contract:

```text id="sl2csf"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

### 7.4.2 ∇-hooks — Mutation and State Change

∇-hooks apply before mutating operations.

Examples:

* write to memory;
* write to file;
* enqueue IPC message;
* create process;
* create thread;
* change frame mapping;
* allocate memory;
* change capability table;
* update driver state;
* write device register;
* update `ResourceAccount` state.

Policy examples:

```text id="yn4ffp"
deny writes to protected filesystem frames
deny memory allocation above quota
deny network connection creation outside allowed domain
log any mutation of policy-related state
deny RAcc update that would exceed hard quota
```

∇-hooks prevent unauthorized or invalid state mutation.

### 7.4.3 □-hooks — Frame and Context Changes

□-hooks apply when kernel execution changes frame context.

Examples:

* context switch;
* address-space switch;
* entering process frame;
* mapping shared memory;
* mounting filesystem subtree;
* switching namespace;
* entering device frame;
* binding driver frame.

Policy examples:

```text id="tg6uz4"
process may not enter frame outside its FrameSet
container may not mount host namespace
driver may not map unassigned MMIO frame
shared frame requires explicit policy approval
```

Frame-context transitions remain OS-level architecture behavior.

They do not imply a particular physical MMU implementation.

### 7.4.4 Ω-hooks — Role and Capability Changes

Ω-hooks apply when authority changes or is checked.

Examples:

* role switch;
* capability grant;
* capability revoke;
* setuid-like operation;
* driver capability assignment;
* syscall authority check;
* privilege entry or exit;
* impersonation.

Policy examples:

```text id="hstzaa"
unprivileged process cannot gain device capability
driver cannot acquire DMA scope outside assigned frame
service may impersonate only users with matching label
policy update requires kernel role and signed policy source
```

Ω-hooks ensure that authority transitions remain explicit and policy-bound.

### 7.4.5 Θ-hooks — Scheduling and Ordering

Θ-hooks apply at ordering and scheduling points.

Examples:

* scheduler tick;
* dispatch selection;
* preemption;
* workqueue dispatch;
* timer activation;
* interrupt priority decision;
* cache flush ordering;
* driver bottom-half scheduling;
* resource-accounting interval closure.

Policy examples:

```text id="olny1r"
process may not exceed CPU budget in τ-window
real-time thread must not be starved
driver interrupt handler must stay within budget
idle task must not starve policy-critical tasks
```

Θ-hooks govern order and progress, not physical time itself.

Physical time values are τ-derived data in kernel meta-state.

### 7.4.6 Λ-hooks — Absence, Wait, Timeout

Λ-hooks apply when an expected event is absent.

Examples:

* empty IPC queue;
* lock unavailable;
* timer missed;
* device not ready;
* allocation cannot be satisfied;
* expected hotplug event absent;
* blocking syscall timeout;
* quota reset not yet available.

Policy examples:

```text id="uosrdk"
timeout after τ deadline
retry with Θ backoff
escalate repeated absence to Φ
treat missing device response as quarantine trigger
block allocation until RAcc window resets
```

Λ-hooks convert non-events into typed OS behavior.

### 7.4.7 Φ-hooks — Trap, Fault, and Recontextualization

Φ-hooks apply when execution changes context due to syscall, interrupt, fault, signal, or recovery.

Examples:

* syscall entry;
* page fault;
* protection fault;
* interrupt entry;
* exception return;
* signal delivery;
* driver error;
* OOM handling;
* process kill path;
* quarantine entry.

Policy examples:

```text id="nndyre"
on page fault from sandbox, deny mapping and signal process
on repeated driver fault, quarantine device
on policy violation, enter audit frame
on trap return, verify target frame and role
```

Φ-hooks ensure that recontextualization preserves invariants.

Syscall entry is the central PMS-OS Φ path.

It follows the OS-level syscall ABI:

```text id="t1su1q"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

This is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

### 7.4.8 Χ-hooks — Isolation and Boundary Changes

Χ-hooks apply to boundary transitions.

At PMS Base level:

```text id="gv61hj"
Χ = Distance
```

At PMS-OS level, Χ is projected as:

```text id="w4v6ez"
process boundary
address-space boundary
namespace boundary
sandbox boundary
container boundary
device boundary
driver boundary
IPC visibility boundary
filesystem view boundary
DMA boundary
```

Concrete OS-level domain values include:

```text id="mkr4k5"
X_user
X_global
X_p
X_i
X_j
```

These are OS-level isolation-domain values.

They are not the PMS Base operator `Χ`.

They name concrete PMS-OS boundary, reachability, namespace, device, IPC, filesystem-view, sandbox/container, or process domains through which PMS Base Χ = Distance is projected at OS level.

Examples:

* entering sandbox;
* creating shared memory;
* joining namespace;
* mapping device memory;
* granting DMA region;
* creating container;
* bridging IPC endpoints;
* moving object into quarantine.

Policy examples:

```text id="zi6blz"
deny cross-container shared memory
require explicit bridge for IPC visibility
forbid DMA outside DMARegionFrame
quarantine process on forbidden boundary crossing
```

Χ-hooks control reachability and visibility changes.

### 7.4.9 Σ-hooks — Commit and Integration

Σ-hooks apply at commit boundaries.

Examples:

* filesystem journal commit;
* IPC delivery commit;
* context-switch state save;
* resource-accounting commit;
* process creation finalization;
* driver binding commit;
* policy update activation;
* storage writeback;
* transaction commit;
* quarantine-state commit.

Policy examples:

```text id="lgdkjc"
commit only if integrity tags match
deny filesystem commit if quota exceeded
audit every commit touching high-value resource
rollback staged state if postcondition fails
deny RAcc commit if parent quota would be exceeded
```

Σ-hooks ensure that produced effects become visible only when valid.

### 7.5 Policy Evaluation Pipeline

Every hook follows a common pipeline.

```text id="vwndax"
(state s, operation op, context c)
    → Eval_Ψ
    → decision
```

#### Step 1 — Collect Context

The kernel collects minimal required context.

```text id="mzpw61"
Context = (
    actor,
    target,
    operator_class,
    concrete_operation,
    frame_context,
    role_state,
    isolation_domain,
    resource_account,
    τ_data,
    history_summary,
    pending_commit_state,
    trap_state
)
```

The collection phase is Δ-like: it distinguishes the relevant facts for policy evaluation.

The `isolation_domain` field stores OS-level domain values such as `X_p`, not PMS Base Χ itself.

The `resource_account` field refers to `RAcc` / `ResourceAccount`, not `RF`.

#### Step 2 — Select Relevant Policies

The kernel selects policies whose scope matches the context.

```text id="usmzcp"
P_relevant =
    { p ∈ PSet_k | scope_matches(p.scope, context) }
```

Policies may be indexed by:

```text id="nxrlmo"
operator class
actor role
target frame
syscall id
device id
driver id
filesystem object
IPC endpoint
resource account RAcc
OS isolation-domain value
```

#### Step 3 — Evaluate Predicates

Each policy predicate is evaluated:

```text id="ntrfni"
result_i = Eval(policy_i.predicate, s, op, c)
```

Possible raw results include:

```text id="ltaasz"
ALLOW
DENY
MODIFY
DEFER
LOGONLY
ESCALATE
ISOLATE
HALT
```

#### Step 4 — Resolve Results

Multiple policy results are combined:

```text id="kt73va"
final_decision = Resolve(result_1, ..., result_n)
```

A typical resolution order is:

```text id="wy1nwk"
HALT
> ISOLATE
> DENY
> ESCALATE
> MODIFY
> DEFER
> LOGONLY
> ALLOW
```

A PMS-OS profile may define a different order, but it must be explicit.

#### Step 5 — Enforce Decision

The kernel applies the decision through an operator-typed action.

```text id="wbrkwh"
ALLOW      → continue
MODIFY     → rewrite operation or context
DEFER      → Θ delay or Λ wait
DENY       → return error or block
ESCALATE   → Φ recontextualize to handler
ISOLATE    → Χ restrict or quarantine
HALT       → Ψ halt path
LOGONLY    → Σ audit record, then continue
```

### 7.6 Policy Decisions

The KPE’s final decisions have precise OS meanings.

#### ALLOW

The transition proceeds unchanged.

```text id="hyk5eo"
Ψ permits op
```

#### MODIFY

The operation is rewritten before execution.

Examples:

```text id="kv46vs"
path rewrite into namespace
capability downgrade
frame remap
priority adjustment
resource limit reduction
```

Modification itself must be valid:

```text id="xs2y6w"
modified_op is valid
∧ modification is policy-authorized
```

#### DEFER

Execution is delayed.

Examples:

```text id="zb9xum"
wait for resource
schedule later
retry after Θ backoff
block until quota resets
```

DEFER usually creates or updates Λ/Θ state.

#### DENY

The transition is refused.

Examples:

```text id="y8mlee"
return permission error
fail syscall
reject IPC send
deny mmap
reject driver bind
deny ResourceAccount growth
```

#### ESCALATE

Execution recontextualizes into a handler.

```text id="hy2g07"
Φ_policy_handler
```

Examples:

```text id="w7ky8h"
audit handler
debug monitor
fault handler
security handler
kernel policy handler
```

OS policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

#### ISOLATE

The target is restricted through Χ.

Examples:

```text id="l0776y"
quarantine process
isolate driver
restrict device
freeze IPC endpoint
close namespace bridge
```

Isolation decisions operate on OS-level boundary/domain structures.

They do not redefine PMS Base Χ.

#### HALT

The kernel enters a defined halt or panic path.

```text id="rhr4xs"
Ψ_critical_violation → S_H
```

HALT is reserved for critical invariants where continuation would break the trust boundary.

#### LOGONLY

The decision is recorded but does not affect execution.

```text id="g2faft"
Σ_audit(decision)
```

### 7.7 Enforcement Actions

Actions must themselves be operator-typed.

| Action     | Operator structure                                |
| ---------- | ------------------------------------------------- |
| allow      | continue transition                               |
| modify     | Δ distinguish rewrite + ∇ apply rewrite + Ψ check |
| deny       | Ψ denial + optional Φ error return                |
| defer      | Θ delay + Λ wait/non-event                        |
| isolate    | Χ restrict + Σ commit isolation state             |
| quarantine | Χ isolate + Ω revoke + Σ commit + Φ notify        |
| log        | Δ prepare record + Σ commit audit                 |
| escalate   | Φ enter handler                                   |
| rollback   | Φ recovery + Σ rollback/integration discipline    |
| halt       | Ψ critical halt                                   |

The KPE cannot use untyped effects to enforce typed policy.

Enforcement must preserve the same operator discipline it applies to the rest of the kernel.

### 7.8 Policy Lifecycle

Policies have lifecycle states.

```text id="v1l67c"
PolicyState ∈ {
    CREATED,
    LOADED,
    ACTIVE,
    PERMISSIVE,
    AUDIT_ONLY,
    DISABLED,
    REPLACED,
    REVOKED,
    ERROR
}
```

Lifecycle operations include:

```text id="in5g62"
Ψ_CREATE(policy_spec) → PolicyId
Ψ_LOAD(PolicyId)
Ψ_ACTIVATE(PolicyId)
Ψ_UPDATE(PolicyId, new_spec)
Ψ_SET_MODE(PolicyId, mode)
Ψ_DISABLE(PolicyId)
Ψ_DELETE(PolicyId)
Ψ_REPLACE(old, new)
```

Policy lifecycle transitions require:

```text id="yrhiwn"
Δ identify policy
Ω authorize policy operation
Ψ check lifecycle transition
Σ commit policy state
```

Policy deletion or replacement must not leave ungoverned gaps in critical invariants.

### 7.9 Boot-Time Policy

During boot, PMS-OS loads a minimal mandatory policy set.

Boot-time policies include:

```text id="l82bd3"
kernel frame protection
user/kernel boundary
policy mutation restrictions
initial capability rules
initial scheduler policy
initial resource-accounting policy
device probing rules
filesystem root rules
audit initialization
```

Boot-time policy activation follows:

```text id="eyue2t"
Δ identify boot policy
Ω confirm kernel boot authority
Ψ check policy form
Σ commit active policy
```

Only after mandatory policies are active may the kernel expose user execution or device binding.

### 7.10 Policy Composition

Effective policy is compositional.

```text id="o7vjef"
P_eff(subject, target, op) =
    Combine(
        P_global,
        P_role(subject.role),
        P_process(subject.pid),
        P_frame(target.frame),
        P_object(target),
        P_device(target.device),
        P_driver(target.driver),
        P_resource(target.RAcc)
    )
```

A common composition rule is conjunction:

```text id="kf59he"
Ψ_total = Ψ0 ∧ Ψ1 ∧ Ψ2 ∧ Ψ3
```

But PMS-OS may support ordered override or priority logic if explicitly specified.

The important invariant is:

```text id="wplv8h"
local policy may restrict;
local policy may not weaken kernel invariants.
```

### 7.11 Policy Caching and Fast Paths

The KPE may cache decisions for performance.

A cache key may be:

```text id="i1dc68"
CacheKey = (
    actor_id,
    role,
    operator_class,
    concrete_operation,
    target_id,
    coarse_context,
    policy_epoch
)
```

A cached decision is valid only while:

```text id="u3x11y"
policy_epoch unchanged
∧ actor role/capability unchanged
∧ target frame/boundary state unchanged
∧ relevant resource and τ constraints unchanged
```

Fast paths are permitted when their preconditions are explicit:

```text id="d22y0m"
FastPathPre(s, op) ⇒ allow
```

A fast path is invalid if it bypasses a policy hook whose result could differ in the current state.

Fast paths may optimize enforcement.

They must not erase policy semantics.

### 7.12 Policy and Audit

Policy decisions may be committed to audit state.

An audit record may be:

```text id="d3ajfl"
PolicyAuditRecord = (
    event_id,
    actor,
    target,
    operator_class,
    operation,
    policy_ids,
    decision,
    action,
    timestamp_or_order,
    metadata
)
```

Audit commit:

```text id="u6ngup"
Δ prepare audit record
Σ commit audit record
Ψ enforce audit retention/integrity
```

A PMS-OS implementation may emit detailed audit traces, compact decision logs, or golden traces depending on artifact goals.

Trace emission is implementation-specific.

Operator-labeled representability is the architectural requirement.

Audit evidence strengthens bounded implementation-artifact claims.

It does not validate PMS Base.

### 7.13 Interaction with PMSL, PMS-IR, and Tooling

The KPE can interact with language and IR tooling.

Possible integrations:

* PMSL policy declarations compiled into kernel policy objects;
* PMS-IR tags attached to syscalls, frames, and capabilities;
* static analysis checking absence of forbidden transitions;
* model checking of policy combinations under stated model assumptions;
* simulator traces checked against `L_PMS,Ψ_kernel`;
* runtime hooks derived from IR annotations.

This section defines the OS-side policy engine only.

Language/runtime details belong in `05_pmsl_pms_ir.md`.

Runtime-security hardening belongs in `06_runtime_security.md`.

Distributed policy synchronization belongs in `07_distributed_systems.md`.

### 7.14 Boundary to Runtime Security

The Kernel Policy Engine is the OS-level Ψ mechanism.

It defines:

```text id="c0oi2d"
policy objects
policy hooks
policy evaluation
policy decisions
policy enforcement actions
policy lifecycle
policy caching
policy audit
```

It does not fully define:

* adversarial-security taxonomy;
* governance workflows;
* organizational policy authority;
* distributed trust;
* forensic attribution;
* runtime attestation;
* cross-node policy synchronization;
* evidence pipelines beyond OS trace/audit state.

Those are refined in `06_runtime_security.md` and `07_distributed_systems.md`.

Boundary:

```text id="huvk6m"
04_pms_os.md defines the OS-level policy mechanism.

06_runtime_security.md defines runtime-security architecture, governance
hardening, adversarial security, audit/evidence hardening, and
deployment-facing security profiles.

07_distributed_systems.md defines cross-node policy synchronization,
distributed trust, distributed delivery, and cluster-level policy semantics.
```

The Kernel Policy Engine is not a moral tribunal, forensic authority, governance oracle, or organizational policy authority.

### 7.15 Kernel Policy Engine Invariants

The KPE maintains the following invariants.

```text id="tccy3r"
I1: every critical kernel transition has a policy hook

I2: policy mutation is allowed only through Ω-authorized kernel paths

I3: policy decisions are resolved by explicit priority/composition rules

I4: enforcement actions are operator-typed

I5: local policies cannot weaken kernel invariants

I6: cached decisions are invalidated on relevant policy or context change

I7: audit records, when enabled, are Σ-committed

I8: policy failure mode is explicit: fail-open, fail-closed, audit-only, or disabled

I9: Φ recontextualization caused by policy must preserve kernel invariants

I10: Χ isolation caused by policy must be committed and visible to scheduler,
     resource, and lifecycle logic

I11: Σ commits must be policy-checked before global visibility

I12: no valid kernel transition silently bypasses active Ψ constraints

I13: X_user, X_global, X_p, X_i, and X_j are OS-level isolation-domain
     values, not PMS Base Χ

I14: PMS Base Χ = Distance

I15: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, device boundary, IPC visibility, filesystem view,
     sandbox/container boundary, DMA boundary, and reachability control

I16: RAcc / ResourceAccount is the resource-accounting notation; RF is
     reserved for PMS-CPU RegisterFile

I17: τ denotes time/accounting metadata, not a PMS Base operator

I18: policy traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile

I19: KPE decisions do not constitute moral judgment, forensic attribution,
     governance authority, or PMS Base validation
```

### 7.16 Architectural Consequence

The Kernel Policy Engine makes PMS-OS policy structural.

The consequence is:

```text id="nv400g"
PMS-OS policy is not a sidecar permission system. It is the Ψ layer over
kernel execution: every protected distinction, mutation, frame switch,
role change, boundary crossing, ordering step, trap, wait, commit, and
resource-accounting update can be constrained by explicit policy hooks and
operator-typed enforcement.
```

This gives the remaining PMS-OS subsystems — syscalls, resources, memory, storage, IPC, devices, and drivers — a shared policy substrate.

### 7.17 Boundary Statement

The correct boundary for this chapter is:

```text id="g7k8s8"
The PMS-OS Kernel Policy Engine specifies OS-level policy objects, hooks,
evaluation, decisions, enforcement actions, lifecycle, caching, and audit as
the kernel Ψ mechanism over operator-typed transitions.

This is an OS-level kernel policy-engine architecture claim.

It does not claim a completed production policy engine, external security
validation, governance authority, forensic authority, moral judgment,
organizational policy authority, distributed policy synchronization, or PMS
Base validation.
```

---

## 8. Syscall Interface

The PMS-OS syscall interface is the controlled boundary between user execution and kernel-governed system services.

A syscall is a structured Φ-mediated transition from user context into kernel context, followed by operator-typed dispatch, validation, execution, commit, and return.

The central syscall claim is:

```text id="epqbmw"
A PMS-OS syscall is a kernel-mediated operator contract:
Φ entry, Ω privilege and caller-authority check, □ kernel syscall-frame
binding, Χ user/kernel boundary mediation, Δ syscall and argument
identification, Ψ validation, operator-typed execution, Σ commit where
required, Ψ postcheck, and Φ return.
```

Claim type:

```text id="vdo4ws"
OS-level syscall-interface architecture claim
```

Boundary:

```text id="dy3230"
This section specifies the PMS-OS syscall interface as a dedicated OS-level
syscall ABI built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

It does not claim a completed production kernel, production syscall ABI,
external security validation, or PMS Base validation.
```

This makes syscalls the primary OS-level bridge between PMS-CPU execution and kernel services.

A concrete syscall execution produces:

```text id="eyrkwe"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="6xzlfl"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible syscall executions is:

```text id="qahfhk"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="a46jgn"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 8.1 Syscall as Controlled Recontextualization

A syscall begins when user execution enters the kernel through Φ.

Canonical user-to-kernel transition:

```text id="ax8xiw"
(f_user, r_user, X_user)
    --Φ_syscall-->
(KF, KERNEL, X_global)
```

Canonical return:

```text id="9xszl2"
(KF, KERNEL, X_global)
    --Φ_return-->
(f_user, r_user, X_user)
```

The syscall path changes:

| Dimension        | Before syscall         | During syscall               | After syscall                 |
| ---------------- | ---------------------- | ---------------------------- | ----------------------------- |
| frame            | user frame             | kernel syscall frame         | restored user frame           |
| role             | user role              | kernel/supervisor role       | restored user role            |
| isolation domain | user OS-domain value   | kernel-visible system domain | restored user OS-domain value |
| policy           | user + kernel policy   | kernel policy dominates      | user execution policy resumes |
| control context  | PMS-CPU user execution | kernel handler               | PMS-CPU user continuation     |

`X_user` and `X_global` are OS-level isolation-domain values.

They are not the PMS Base operator `Χ`.

They name concrete PMS-OS boundary, reachability, namespace, address-space, and visibility domains through which PMS Base Χ = Distance is projected at OS level.

The syscall interface is therefore Φ-centered. It changes execution context without erasing accountability for the previous context.

### 8.2 Syscall Operator Word

The canonical PMS-OS syscall operator word is:

```text id="y8bu0r"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded:

```text id="pqw8j1"
Φ_enter_kernel
→ Ω_install_kernel_role_and_check_caller_authority
→ □_install_kernel_syscall_frame
→ Χ_mediate_user_kernel_boundary
→ Δ_identify_syscall
→ Δ_validate_arguments
→ Ψ_precheck
→ execute syscall body
→ Σ_commit_if_required
→ Ψ_postcheck
→ Φ_return_to_user_or_recontextualize
```

Meaning:

| Operator | Syscall role                     |
| -------- | -------------------------------- |
| Φ        | kernel entry / trap              |
| Ω        | kernel role and caller authority |
| □        | kernel syscall frame             |
| Χ        | user/kernel boundary mediation   |
| Δ        | syscall and argument distinction |
| Ψ        | precheck                         |
| `(…)`    | syscall body                     |
| `Σ?`     | commit where required            |
| Ψ        | postcheck                        |
| Φ        | return / close / recontextualize |

The syscall body may use one or several operator families depending on the syscall kind.

Examples:

```text id="pvrb76"
write       → ∇ + Σ
mmap        → □ + Χ + Σ
sched_yield → Θ
setuid      → Ω + Σ
fsync       → Σ
policy_ctl  → Ψ + Σ
execve      → Φ + □ + ∇ + Σ
```

A syscall is valid only if every phase preserves the kernel invariants defined in Section 2.

### 8.3 Syscall Calling Convention

At PMS-CPU level, syscalls use the CPU trap mechanism.

Example:

```asm id="gxkqru"
TRAP syscall_id
```

The PMS-OS syscall convention is a dedicated OS-level syscall ABI built on top of that trap mechanism.

It is distinct from the ordinary PMS-CPU function calling convention.

It is also distinct from the PMS-CPU trap/syscall control-transfer model.

Required distinction:

```text id="ckuwu1"
ordinary PMS-CPU function calling convention
    ≠ PMS-CPU trap/syscall control-transfer convention
    ≠ PMS-OS syscall ABI
```

The OS-level syscall ABI specializes CPU trap entry into:

```text id="nso18h"
kernel-service entry
syscall dispatch
argument validation
authority and policy checks
kernel operation
commit
postcheck
return
```

The canonical register convention is:

```text id="i28nsx"
R0 = syscall_id
R1 = arg0
R2 = arg1
R3 = arg2
R4 = arg3
R5 = arg4
return value = R0
secondary return / error metadata = R1, if profile defines it
```

A syscall may also use a memory-backed argument frame when arguments exceed the register set.

```text id="2wt7v4"
R1 = pointer to SyscallArgFrame
```

where:

```text id="hv7o0z"
SyscallArgFrame = (syscall_id, argc, args, flags, meta)
```

The kernel validates this frame before use:

```text id="p9q1x3"
argument frame exists
∧ user frame may be read
∧ pointer lies in user-visible memory
∧ Χ projection permits user/kernel argument transfer
∧ argument layout matches syscall signature
∧ Ψ permits argument use
```

The calling convention is virtual and architectural. Concrete PMS-CPU/PMS-OS profiles may define exact register counts, error encodings, or ABI variants, but they must preserve the syscall operator contract.

### 8.4 Syscall Entry Sequence

A syscall entry proceeds as follows.

#### Phase 1 — Φ trap entry

The CPU performs a controlled trap into the kernel.

```text id="z78u3v"
Φ_syscall_entry
```

Effects:

```text id="e5zfz0"
save user R_pc / R_flag / R_fr / R_role / R_iso
switch to kernel frame
switch to kernel role
record syscall cause
jump to syscall dispatcher
```

The trap entry must preserve:

```text id="ve6hho"
user continuation
user frame identity
user role state
user OS isolation-domain state
pending return metadata
```

If any of these cannot be saved coherently, the kernel enters a Φ fault path instead of executing the syscall body.

#### Phase 2 — Ω privilege adjustment and caller-authority check

The kernel installs a privileged execution role.

```text id="2j34zs"
Ω_set(KERNEL)
```

This does not mean the caller becomes privileged. It means the kernel handler executes under kernel authority while preserving the caller’s original role for policy decisions.

The syscall context therefore contains both:

```text id="hzlld1"
caller_role
kernel_role
```

The caller’s role remains the subject of authorization.

#### Phase 3 — □ kernel syscall-frame binding

The kernel enters a syscall-handling frame.

```text id="y58gm1"
□_enter(SyscallFrame)
```

This frame contains:

```text id="jhn96t"
syscall dispatch table
argument decoding context
policy hooks
audit metadata
return frame
trap state
```

Syscall execution must not use user memory or user frames without explicit validation.

#### Phase 4 — Χ user/kernel boundary mediation

The kernel mediates the boundary between user context and kernel-visible system context.

```text id="0mlm6t"
Χ_mediate(X_user, X_global)
```

This does not redefine PMS Base Χ.

At PMS-OS level, Χ projects PMS Base Distance into:

```text id="1h8flo"
user/kernel separation
address-space boundary
pointer visibility
namespace visibility
IPC endpoint visibility
filesystem view
device access boundary
reachability control
```

`X_user` and `X_global` are OS-level domain values, not the PMS Base operator.

#### Phase 5 — Δ syscall identification

The kernel distinguishes the syscall ID.

```text id="7x5d7c"
syscall_id = R0
entry = SyscallTable[syscall_id]
```

If the ID is invalid:

```text id="5u9xq9"
Δ failure → Φ invalid-syscall return
```

or:

```text id="b18d7n"
Δ failure → Ψ denial / audit / kill policy
```

depending on kernel policy.

#### Phase 6 — Δ argument classification

The kernel classifies arguments according to the syscall signature.

```text id="fipkxz"
args = DecodeArgs(entry.signature, R1..R5 or SyscallArgFrame)
```

Argument classification includes:

* integer width;
* pointer type;
* buffer length;
* file descriptor;
* frame identifier;
* path reference;
* policy identifier;
* capability object;
* flags;
* timeout/deadline parameter;
* user/kernel address distinction.

Argument classification is Δ-typed. It precedes any mutation.

#### Phase 7 — Ψ precheck

The kernel policy engine evaluates syscall policy.

```text id="3dpmtk"
policy_ok(P_kernel, syscall_context) = true
```

The precheck may consider:

* caller process;
* caller thread;
* role/capability state;
* target object;
* syscall ID;
* argument values;
* resource account `RAcc`;
* resource quotas;
* namespace;
* OS isolation-domain value;
* current τ/accounting state;
* prior syscall history;
* driver/device policy;
* filesystem policy;
* security mode.

If Ψ denies, the syscall body does not execute.

#### Phase 8 — Operator-typed body execution

The syscall handler performs the requested kernel operation.

The body may use:

```text id="fl3ve5"
∇ mutation
□ frame creation / mapping / binding
Χ isolation or namespace adjustment
Θ scheduling or ordering
Σ commit or integration
Φ recontextualization
Λ wait / timeout / non-event
Ψ policy update or enforcement
Α reusable kernel pattern
```

The handler must remain operator-typed. Its internal structure is not exempt from PMS-OS validity.

#### Phase 9 — Σ commit

If the syscall produced durable, visible, shared, resource-accounted, or lifecycle state, it must commit through Σ.

Examples:

```text id="2sxopb"
file write visibility
process table update
memory mapping activation
IPC delivery
resource accounting update
driver binding
policy activation
filesystem journal update
```

A syscall may execute but fail to commit if a postcondition fails.

```text id="l8539f"
execution succeeds
∧ Σ fails
⇒ Φ rollback / error return / recovery path
```

#### Phase 10 — Ψ postcheck

The kernel checks postconditions.

Examples:

```text id="gloixq"
no kernel frame leaked
return pointer lies in user frame
resource accounting committed
capability state coherent
frame mapping policy still holds
filesystem invariant holds
IPC delivery guarantee satisfied
driver/device state coherent
```

If postcheck fails, the kernel must not return silently.

#### Phase 11 — Φ return

Finally, the kernel returns to user context.

```text id="mowbvy"
Φ_return
```

Return requires:

```text id="wg0qgk"
target user frame valid
∧ user role restored
∧ user OS isolation-domain value restored
∧ return address executable
∧ return registers valid
∧ pending commit state resolved
∧ policy permits return
```

### 8.5 Syscall Taxonomy

PMS-OS classifies syscalls by dominant operator family.

This taxonomy does not mean a syscall uses only one operator. It identifies the primary semantic role of the syscall.

All examples below are specializations of the canonical PMS-OS syscall contract:

```text id="sf56qj"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

#### 8.5.1 Δ-Class Syscalls

Δ-class syscalls distinguish, query, classify, or resolve system state.

Examples:

```text id="gczaln"
stat
getpid
gettid
getuid
resolve
lookup
poll_status
cap_query
policy_query
```

Typical structure:

```text id="shp0ko"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Δ_result ; Σ? ; Ψ ; Φ
```

Examples:

| Syscall        | Meaning                                |
| -------------- | -------------------------------------- |
| `getpid`       | distinguish current process identity   |
| `stat`         | distinguish filesystem object metadata |
| `resolve`      | classify path/name into object frame   |
| `cap_query`    | distinguish available capability set   |
| `policy_query` | inspect policy state if permitted      |

Δ-class syscalls should not mutate persistent kernel state except for optional audit/accounting.

#### 8.5.2 ∇-Class Syscalls

∇-class syscalls mutate state or perform action.

Examples:

```text id="rabwmn"
write
sendmsg
chmod
create
unlink
rename
kill
ioctl
bind
connect
```

Typical structure:

```text id="ivqkm6"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; ∇ ; Σ? ; Ψ ; Φ
```

They require strong prechecks because ∇ changes state.

Examples:

| Syscall   | Main action                         |
| --------- | ----------------------------------- |
| `write`   | mutate file/socket/device state     |
| `sendmsg` | enqueue IPC/network message         |
| `chmod`   | mutate permission metadata          |
| `create`  | create filesystem or kernel object  |
| `unlink`  | remove directory reference          |
| `kill`    | deliver signal or termination event |

#### 8.5.3 □-Class Syscalls

□-class syscalls create, bind, switch, or reconfigure frames.

Examples:

```text id="833zy2"
mmap
munmap
mprotect
exec
chroot
mount
unmount
clone_frame
map_shared
```

Typical structure:

```text id="c0at5u"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; □ ; Χ? ; Σ? ; Ψ ; Φ
```

Examples:

| Syscall      | Frame role                        |
| ------------ | --------------------------------- |
| `mmap`       | create or map memory frame        |
| `mprotect`   | alter frame permissions           |
| `exec`       | replace execution frame set       |
| `chroot`     | switch filesystem namespace frame |
| `mount`      | bind filesystem subtree frame     |
| `map_shared` | create shared frame edge          |

Frame syscalls are especially policy-sensitive because they change interpretation context.

#### 8.5.4 Ω-Class Syscalls

Ω-class syscalls change or inspect roles, credentials, or capabilities.

Examples:

```text id="its9im"
setuid
setgid
capset
capget
grant_cap
revoke_cap
impersonate
drop_privilege
```

Typical structure:

```text id="c6jsmp"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Ω ; Σ? ; Ψ ; Φ
```

These syscalls must preserve the no-uncontrolled-escalation invariant.

A capability gain is valid only if:

```text id="he6xua"
caller has delegation authority
∧ target capability is within grant scope
∧ Ψ permits transition
∧ Σ commits the new role state
```

Capability reduction is generally safer but still must be coherent:

```text id="3ybj4c"
drop_privilege
```

must not strand the process in a state unable to complete required cleanup unless policy permits.

#### 8.5.5 Θ-Class Syscalls

Θ-class syscalls affect scheduling, ordering, timers, or readiness.

Examples:

```text id="9wy4a2"
sched_yield
nanosleep
timer_create
timer_set
wait_event
set_priority
set_deadline
futex_wait
futex_wake
```

Typical structure:

```text id="tgtqrf"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Θ ; Λ? ; Σ? ; Ψ ; Φ
```

They may interact with τ-derived timing data in kernel meta-state.

Examples:

| Syscall        | Meaning                                  |
| -------------- | ---------------------------------------- |
| `sched_yield`  | yield current execution order            |
| `nanosleep`    | block until τ-derived deadline           |
| `timer_create` | create timer frame                       |
| `futex_wait`   | block on synchronization condition       |
| `futex_wake`   | reorder waiting threads into READY state |

Θ-class syscalls do not create physical time. They request kernel ordering behavior over τ-derived state.

`τ` denotes time/accounting metadata, not a PMS Base operator.

#### 8.5.6 Φ-Class Syscalls

Φ-class syscalls primarily recontextualize execution.

Examples:

```text id="nbltkd"
execve
sigreturn
raise
exit
ptrace_attach
checkpoint_restore
```

Typical structure:

```text id="g506ee"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Φ_body ; Σ? ; Ψ ; Φ_return_or_close
```

Examples:

| Syscall              | Recontextualization                     |
| -------------------- | --------------------------------------- |
| `execve`             | replace current execution image         |
| `sigreturn`          | restore pre-signal context              |
| `exit`               | enter termination path                  |
| `checkpoint_restore` | restore execution from saved context    |
| `ptrace_attach`      | reframe debugging relation if permitted |

Φ-class syscalls must preserve trace accountability. They cannot erase the old context without lifecycle closure.

#### 8.5.7 Χ-Class Syscalls

Χ-class syscalls change isolation, namespace, or boundary relations.

Examples:

```text id="4pa2gb"
unshare
clone_namespace
enter_sandbox
exit_sandbox
isolate
join_namespace
create_container
restrict_domain
```

Typical structure:

```text id="9u56wh"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Χ ; □? ; Σ? ; Ψ ; Φ
```

At PMS Base level:

```text id="aivrek"
Χ = Distance
```

At PMS-OS level:

```text id="188axr"
Χ is projected as boundary / isolation / reachability control.
```

Concrete OS-level domain values such as `X_user`, `X_global`, and `X_p` are not PMS Base Χ.

A boundary change is valid only if:

```text id="pn1hj6"
target domain exists or can be created
∧ role permits entry/exit
∧ policy permits boundary relation
∧ frame visibility remains coherent
∧ Σ commits boundary metadata
```

#### 8.5.8 Σ-Class Syscalls

Σ-class syscalls commit, synchronize, flush, checkpoint, or integrate state.

Examples:

```text id="l1ryte"
fsync
sync
checkpoint
commit_tx
rollback_tx
msync
flush_cache
commit_ipc
```

Typical structure:

```text id="4pjv9z"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Σ ; Ψ ; Φ
```

A Σ syscall requires committable prior state.

Examples:

| Syscall       | Commit target                                    |
| ------------- | ------------------------------------------------ |
| `fsync`       | file/storage state                               |
| `sync`        | global storage state                             |
| `checkpoint`  | process/system state                             |
| `msync`       | memory-mapped file pages                         |
| `commit_tx`   | transaction state                                |
| `rollback_tx` | staged state closure through recovery discipline |

Commit syscalls must be postchecked because they make state visible, durable, or globally integrated.

#### 8.5.9 Ψ-Class Syscalls

Ψ-class syscalls inspect, install, update, enable, disable, or query policy.

Examples:

```text id="mvg495"
policy_load
policy_update
policy_enable
policy_disable
policy_query
audit_config
seccomp_like_install
```

Typical structure:

```text id="nxqs5c"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ_precheck ; Ψ_update ; Σ? ; Ψ_postcheck ; Φ
```

These syscalls are highly privileged.

A policy mutation is valid only if:

```text id="qfp2q7"
caller role authorizes policy mutation
∧ target policy scope is permitted
∧ new policy does not weaken kernel invariants
∧ policy form is valid
∧ Σ commits policy epoch update
```

Policy syscalls alter future valid execution:

```text id="uiqzc5"
L_PMS,Ψ_new ⊆ L_PMS
```

#### 8.5.10 Λ-Related Syscall Outcomes

Λ is not usually a syscall class by itself, but many syscalls produce Λ outcomes.

Examples:

```text id="82tfsw"
read on empty nonblocking pipe
recv with no message
poll timeout
allocation unavailable
device not ready
lock unavailable
waitpid with no exited child
```

Λ outcome means:

```text id="13mxbr"
expected event did not occur
```

The syscall may return:

```text id="hx5fvq"
timeout
would-block
try-again
no-event
deferred
```

or may recontextualize through Φ if policy treats absence as exceptional.

#### 8.5.11 τ-Related Syscalls

Time-related syscalls interact with τ-derived data in kernel meta-state and Θ ordering.

Examples:

```text id="at5zc6"
clock_read
nanosleep
timer_create
timer_set
timer_cancel
getrusage
sched_accounting_query
```

Their operator structure is usually:

```text id="6qpmxq"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Θ/Δ over τ-data ; Λ? ; Σ? ; Ψ ; Φ
```

Important distinction:

```text id="5mxw2e"
τ stores or represents time/accounting data.

Θ orders when the kernel samples, compares, or schedules against it.
```

### 8.6 Syscall Table

The syscall table is a kernel contract table.

```text id="d3cc0c"
SyscallEntry = (
    SyscallId id,
    SyscallHandler handler,
    PolicyMask policy_requirements,
    RoleMask allowed_roles,
    FrameMask allowed_frames,
    DomainMask allowed_domains,
    OperatorClass op_class,
    ArgSchema args,
    CommitMode commit_mode,
    ReturnMode return_mode,
    AuditMode audit_mode,
    RAccMode resource_accounting_mode,
    Meta meta
)
```

where:

| Field                      | Meaning                                                                     |
| -------------------------- | --------------------------------------------------------------------------- |
| `id`                       | syscall identifier                                                          |
| `handler`                  | kernel function or handler entry                                            |
| `policy_requirements`      | required Ψ policies                                                         |
| `allowed_roles`            | Ω role mask                                                                 |
| `allowed_frames`           | □ frame constraints                                                         |
| `allowed_domains`          | Χ user/kernel, process, namespace, endpoint, or device boundary constraints |
| `op_class`                 | dominant PMS operator family                                                |
| `args`                     | argument schema for Δ validation                                            |
| `commit_mode`              | whether Σ is required, optional, forbidden, or deferred                     |
| `return_mode`              | ordinary return, blocking, async, no-return, error-only                     |
| `audit_mode`               | audit requirement                                                           |
| `resource_accounting_mode` | whether `RAcc` is read, updated, committed, or checked                      |
| `meta`                     | timeout, resource, tracing, versioning, compatibility data                  |

The syscall table is checked at boot and policy-update time.

A syscall table entry is valid when:

```text id="8naocg"
id unique
∧ handler exists
∧ op_class ∈ {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
∧ args schema defined
∧ policy requirements satisfiable
∧ role mask coherent
∧ frame constraints coherent
∧ domain constraints coherent
∧ commit mode compatible with op_class
∧ resource_accounting_mode compatible with syscall effects
```

“Checked” here means accepted or rejected under a declared OS profile, schema, fixture, or conformance rule.

It does not mean external validation of PMS Base.

### 8.7 Syscall Dispatch

Syscall dispatch is Δ-typed.

```text id="z0iymj"
entry = Dispatch(syscall_id)
```

Dispatch flow:

```text id="mwiulb"
Δ classify syscall_id
if missing:
    Φ invalid_syscall
else:
    load SyscallEntry
```

The dispatcher then performs:

```text id="yb3635"
Ω_check(entry.allowed_roles, caller)
□_bind(SyscallFrame)
Χ_check(entry.allowed_domains, caller_domain, kernel_domain, target_domain)
Ψ_check(entry.policy_requirements, context)
Δ_decode_args(entry.args)
handler_call(entry.handler)
```

The dispatch path is itself policy-governed. A syscall may be known but disabled by policy.

```text id="7hkrdb"
syscall_id valid
∧ Ψ disables syscall
⇒ policy denial
```

### 8.8 Argument Validation

Arguments are distinguished before use.

Argument validation includes:

```text id="4loxvq"
type validation
range validation
pointer validation
buffer validation
alignment validation
capability object validation
frame visibility validation
namespace resolution
policy-scope validation
resource-accounting impact classification
```

Pointer arguments require special care.

For a user pointer:

```text id="h5jxwo"
ptr ∈ user VisibleFrames
∧ Ω permits read/write as required
∧ Χ permits reachability
∧ Ψ permits access
```

For a buffer:

```text id="73gby9"
buffer = (ptr, len)
```

validity requires:

```text id="93fwk4"
ptr valid for len bytes
∧ no overflow
∧ frame permits access
∧ boundary permits access
∧ policy permits access
```

The kernel must not trust user pointers merely because they are syntactically valid.

### 8.9 Return Values and Error Semantics

The canonical return register is:

```text id="pgi025"
R0 = return value or error code
```

A PMS-OS profile may distinguish:

```text id="nb3wau"
success value
error code
policy denial
timeout / Λ outcome
trap or signal result
deferred completion token
```

Return is Φ-typed:

```text id="4tkhk2"
kernel context → user context
```

Return validity requires:

```text id="xu7sba"
return value encoded
∧ user context restored
∧ user OS isolation-domain value restored
∧ output buffers committed if required
∧ resource-accounting state committed if required
∧ policy permits return
∧ no kernel-only state leaked
```

Error returns are not untyped failures. They preserve the operator meaning of the failed path.

Examples:

| Error kind         | Operator reading          |
| ------------------ | ------------------------- |
| invalid syscall    | Δ failure                 |
| bad argument       | Δ / □ failure             |
| permission denied  | Ω / Ψ failure             |
| boundary denied    | Χ / Ψ failure             |
| would block        | Λ                         |
| timeout            | Λ over τ-derived deadline |
| interrupted        | Φ                         |
| commit failed      | Σ / Ψ failure             |
| resource exceeded  | Ψ / RAcc quota failure    |
| device unavailable | Λ / Φ depending on policy |

### 8.10 Blocking Syscalls

A syscall may block.

Blocking occurs when the requested event is expected but not currently available.

Examples:

```text id="kn9zlx"
read from empty pipe
wait for child
lock unavailable
device I/O pending
timer sleep
recv from empty queue
page fault waiting for backing storage
```

Blocking transition:

```text id="rq6ehr"
RUNNING
→ Φ syscall entry
→ Ω caller/kernel authority check
→ □ kernel syscall frame
→ Χ user/kernel boundary mediation
→ Δ classify wait condition
→ Ψ check blocking policy
→ Λ wait condition
→ Θ remove from running set
→ BLOCKED
```

Wake-up:

```text id="htr7mw"
event arrives or timeout resolves
→ Θ enqueue READY
→ Φ return or resume syscall
```

A blocking syscall must record a continuation:

```text id="sdxxae"
SyscallContinuation = (thread, syscall_id, args, wait_object, deadline, policy)
```

This makes the blocked syscall resumable and auditable.

### 8.11 Nonblocking and Deferred Syscalls

A nonblocking syscall returns Λ rather than blocking.

Example:

```text id="c9knvp"
recv_nonblocking(queue)
```

If no message exists:

```text id="47qlal"
Λ_no_message → return WOULD_BLOCK
```

A deferred syscall returns a token or handle representing pending completion.

```text id="p0cipi"
defer result
→ Σ commit pending operation
→ event or IPC notification later
```

Deferred syscall validity requires:

```text id="u43olv"
pending operation recorded
∧ caller has handle/capability
∧ completion route defined
∧ policy permits asynchronous completion
∧ RAcc impact is recorded or bounded where relevant
```

### 8.12 Syscall Commit Modes

A syscall has a commit mode.

| Commit mode            | Meaning                                           |
| ---------------------- | ------------------------------------------------- |
| `NO_COMMIT`            | no persistent or shared state integration         |
| `INLINE_COMMIT`        | effects commit before return                      |
| `DEFERRED_COMMIT`      | operation continues after return                  |
| `TRANSACTIONAL_COMMIT` | commit occurs at explicit Σ boundary              |
| `ROLLBACK_ON_FAILURE`  | staged effects are undone on failure              |
| `AUDIT_COMMIT`         | audit record is committed even if operation fails |
| `RACC_COMMIT`          | resource-accounting update must be committed      |

Examples:

```text id="er95y8"
getpid              → NO_COMMIT or AUDIT_COMMIT
write regular file  → INLINE_COMMIT or DEFERRED_COMMIT depending on mode
fsync               → INLINE_COMMIT
sendmsg             → INLINE_COMMIT or DEFERRED_COMMIT depending on delivery policy
mmap                → INLINE_COMMIT of mapping state + RACC_COMMIT
execve              → TRANSACTIONAL_COMMIT over execution frame replacement
policy_update       → INLINE_COMMIT with policy epoch change
```

Commit mode is part of the syscall table contract.

### 8.13 Canonical Syscall Template

Every syscall may be specified using a common template.

```text id="bjsyk5"
SyscallSpec = (
    id,
    name,
    op_class,
    args,
    preconditions,
    body,
    commit,
    postconditions,
    errors,
    audit
)
```

Template:

```text id="7vrgc4"
Entry:
    Φ enter kernel
    Ω install kernel role and check caller authority
    □ bind kernel syscall frame
    Χ mediate user/kernel boundary

Pre:
    Δ identify syscall and arguments
    Ψ check policy
    □ / Χ validate frame and boundary if needed
    RAcc classify resource impact if needed

Body:
    ∇ mutate state, or
    □ change frame, or
    Χ change boundary, or
    Θ alter scheduling/order, or
    Φ recontextualize, or
    Σ integrate state, or
    Ψ update/enforce policy

Commit:
    Σ commit produced state if required
    Σ commit ResourceAccount update if required

Post:
    Ψ verify invariants
    Φ return to caller or close context
```

This template is used for all PMS-OS syscall specifications.

### 8.14 Example: `write(fd, buf, len)`

`write` is primarily ∇-class with Σ commit semantics.

Preconditions:

```text id="g4xlld"
Φ enter kernel
Ω check caller authority
□ bind syscall frame
Χ mediate user/kernel and handle visibility boundary
Δ classify fd
Δ validate buf and len
Ω check write permission
Ψ check filesystem, quota, and policy rules
```

Body:

```text id="t76g3c"
∇ copy bytes from user buffer
∇ append or overwrite target file/socket/device buffer
Σ commit or stage write according to target mode
Σ commit RAcc update where required
```

Postconditions:

```text id="iwgsv2"
Ψ verify target invariants
Ψ verify quota/accounting invariants
Φ return bytes_written or error
```

Possible failures:

| Failure            | Operator reading |
| ------------------ | ---------------- |
| invalid fd         | Δ failure        |
| bad buffer         | □ / Χ failure    |
| permission denied  | Ω / Ψ failure    |
| quota exceeded     | Ψ / RAcc failure |
| would block        | Λ                |
| device unavailable | Λ / Φ            |
| commit failure     | Σ / Φ            |
| interrupted        | Φ                |

Canonical word:

```text id="wgcwv4"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; ∇ ; Σ? ; Ψ ; Φ
```

### 8.15 Example: `mmap(addr, size, flags)`

`mmap` is primarily □/Χ-class with Σ commit.

Preconditions:

```text id="og45fl"
Φ enter kernel
Ω check caller authority
□ bind syscall frame
Χ mediate user/kernel boundary
Δ classify address, size, flags
Ψ check memory policy and quota
Ω check mapping capability
Χ check boundary/domain rules
```

Body:

```text id="ri4adr"
□ create or select memory frame
□ bind virtual address range
Χ set visibility and isolation relation
Σ commit mapping
Σ commit RAcc update where required
```

Postconditions:

```text id="rc4xfk"
Ψ verify mapping invariants
Φ return mapped address or error
```

Invariants:

```text id="4d7kv5"
no user mapping of kernel frames
no W+X mapping unless policy permits
mapping lies inside allowed address space
resource accounting updated through RAcc
```

Canonical word:

```text id="ygh0cz"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; □ ; Χ ; Σ? ; Ψ ; Φ
```

### 8.16 Example: `execve(path, argv)`

`execve` is primarily Φ/□/Σ-class.

It replaces the current execution image while preserving process identity unless policy defines otherwise.

Preconditions:

```text id="yh098f"
Φ enter kernel
Ω check caller authority
□ bind syscall frame
Χ mediate user/kernel and namespace boundary
Δ resolve path
Δ validate argv/envp
Ω check execute permission
Ψ check exec policy
```

Body:

```text id="gy9zsp"
Σ close or stage old execution state
□ create new code/data/heap/stack frames
∇ load executable image
Φ reframe execution context
Σ commit new process image
Σ commit RAcc update where required
```

Postconditions:

```text id="xjelq4"
old executable frames no longer active
new R_pc points to valid entry
new stack frame valid
role/capability state policy-valid
resource accounting updated
```

Failure behavior:

```text id="3wddhh"
before commit  → old process image remains active
after commit   → new image must be coherent or process enters Φ failure path
```

Canonical word:

```text id="jk84op"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Σ ; □ ; ∇ ; Φ ; Σ? ; Ψ ; Φ
```

### 8.17 Example: `fsync(fd)`

`fsync` is Σ-class.

Preconditions:

```text id="h3n43y"
Φ enter kernel
Ω check caller authority
□ bind syscall frame
Χ mediate user/kernel and handle visibility boundary
Δ classify fd
Ψ check filesystem policy
Ω check sync authority
```

Body:

```text id="dfvqnl"
Σ commit dirty buffers
Σ commit journal entries
Θ enforce ordering if required
```

Postconditions:

```text id="5iu60o"
filesystem target stable according to selected consistency mode
audit/accounting updated if required
Φ return success or error
```

Canonical word:

```text id="naeesq"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Σ ; Θ? ; Ψ ; Φ
```

### 8.18 Example: `futex_wait(addr, expected, timeout)`

`futex_wait` is Θ/Λ-class with Δ validation.

Preconditions:

```text id="1u3fzo"
Φ enter kernel
Ω check caller authority
□ bind syscall frame
Χ mediate user/kernel memory boundary
Δ validate address
Δ compare *addr with expected
Ψ check wait policy
Ω check access to futex word
```

If comparison fails:

```text id="g4a8wd"
Δ mismatch → return immediately
```

If comparison succeeds:

```text id="ys2vws"
Θ enqueue thread on wait queue
Λ wait until wake or timeout
```

Wake-up:

```text id="vzhuia"
event arrives
→ Θ move thread to READY
→ Φ return
```

Timeout:

```text id="ehdzbr"
Λ_timeout → Φ return timeout status
```

Canonical word:

```text id="m1lohs"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Θ ; Λ ; Θ ; Ψ ; Φ
```

### 8.19 Example: `policy_update(policy_id, spec)`

`policy_update` is Ψ-class and highly privileged.

Preconditions:

```text id="zj9gqe"
Φ enter kernel
Ω check caller authority
□ bind syscall frame
Χ mediate user/kernel boundary
Δ identify policy_id
Δ validate policy spec
Ω verify policy-update authority
Ψ check that update does not weaken kernel invariants
```

Body:

```text id="lc5rqi"
Ψ update policy object
Σ commit policy epoch
Σ audit policy change
```

Postconditions:

```text id="g3ednm"
new policy active or staged according to mode
cached decisions invalidated
kernel invariants preserved
Φ return status
```

Canonical word:

```text id="ws495i"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Ψ_update ; Σ ; Ψ ; Φ
```

### 8.20 Syscall Security Boundary

The syscall boundary protects the kernel from user-controlled inputs.

The kernel must treat every syscall as untrusted until checked.

Mandatory checks:

```text id="4wvjcc"
syscall ID valid
arguments well-typed
pointers frame-valid
buffers length-safe
roles authorized
capabilities present
isolation boundaries preserved
policies satisfied
commits valid
resource accounting valid where relevant
return context safe
```

Forbidden behavior:

```text id="qyuc5r"
trusting user pointers without frame validation
mutating state before Δ/Ω/□/Χ/Ψ prechecks
returning with kernel role active
leaking kernel frame references
committing partial state without Σ discipline
bypassing policy for fast paths
allowing user-triggered policy weakening
bypassing RAcc quota checks for resource-affecting syscalls
```

This is OS-level syscall protection.

It is not an external security validation claim.

### 8.21 Syscall Audit and Trace

A syscall may produce an audit record.

```text id="iresei"
SyscallAuditRecord = (
    syscall_id,
    caller_pid,
    caller_tid,
    caller_role,
    caller_domain,
    op_class,
    args_summary,
    target,
    decision,
    commit_result,
    resource_accounting_result,
    return_code,
    timestamp_or_order,
    metadata
)
```

Audit flow:

```text id="0t1mxe"
Δ prepare audit record
Σ commit audit record
Ψ enforce retention / integrity policy
```

Audit may occur:

* at syscall entry;
* after policy decision;
* after commit;
* on error;
* on denied syscall;
* on policy mutation;
* on privileged operation;
* on boundary crossing;
* on resource-accounting mutation.

A concrete syscall trace is:

```text id="ovjoem"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="y3l9eh"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The declared syscall execution space is:

```text id="dqf2vd"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="z4hdf4"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Trace emission is an implementation/artifact choice.

The architecture requires that syscall transitions be operator-labeled and representable.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 8.22 Syscall Interface as PMS Contract

The syscall interface is the OS-level contract between user execution and kernel authority.

Canonical contract:

```text id="cijqqs"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

This contract ensures:

```text id="02kxsd"
entry is recontextualized
authority is checked
kernel syscall frame is bound
user/kernel boundary is mediated
operation and arguments are distinguished
policy is evaluated
effects are operator-typed
visible state is committed where required
postconditions are checked
return context is valid
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

### 8.23 Syscall Invariants

PMS-OS maintains the following syscall invariants.

```text id="2fijkn"
I1: user code enters kernel only through Φ-controlled entry

I2: PMS-OS syscall entry follows the canonical contract:
    Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (...) ; Σ? ; Ψ ; Φ

I3: syscall ID is Δ-classified before dispatch

I4: syscall arguments are Δ-validated before use

I5: privileged syscalls require Ω authority

I6: active Ψ policy is checked before protected execution

I7: kernel syscall frame binding is □-explicit

I8: user/kernel boundary mediation is Χ-explicit

I9: frame and boundary constraints are checked before pointer or object access

I10: mutating syscalls use ∇ only after Δ/Ω/□/Χ/Ψ preconditions

I11: commit-producing syscalls use Σ before global visibility

I12: syscall return uses Φ and restores coherent user context

I13: no syscall returns with kernel-only role, frame, or boundary state leaked

I14: blocking syscalls have explicit Λ/Θ state

I15: deferred syscalls have committed continuation state

I16: policy-mutating syscalls cannot weaken kernel invariants

I17: errors preserve operator meaning

I18: syscall fast paths do not bypass active Ψ constraints

I19: resource-affecting syscalls update and commit RAcc state where required

I20: X_user and X_global are OS-level isolation-domain values, not PMS Base Χ

I21: PMS Base Χ = Distance; PMS-OS projects Χ as user/kernel boundary,
     process isolation, address-space separation, namespace separation,
     filesystem view, IPC visibility, device boundary, and reachability
     control

I22: syscall traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile
```

### 8.24 Architectural Consequence

The PMS-OS syscall interface makes kernel entry explicit, typed, and auditable.

The consequence is:

```text id="q05m8b"
A PMS-OS syscall is a Φ-mediated kernel contract that enters a kernel
syscall frame, checks caller authority through Ω, mediates the user/kernel
boundary through Χ, classifies the requested operation through Δ, validates
policy through Ψ, performs an operator-typed body, integrates visible
effects through Σ where required, and returns only through a valid Φ
restoration of user context.
```

This gives PMS-OS a syscall layer that is compatible with process isolation, resource accounting, virtual memory, IPC, filesystem operations, device access, and kernel policy enforcement.

### 8.25 Boundary Statement

The correct boundary for this chapter is:

```text id="iu2tct"
The PMS-OS syscall interface specifies a dedicated OS-level syscall ABI:
Φ entry, Ω caller/kernel authority, □ kernel syscall-frame binding, Χ
user/kernel boundary mediation, Δ syscall and argument classification, Ψ
policy checks, operator-typed execution, Σ commit where required, Ψ
postcheck, and Φ return.

This is an OS-level syscall-interface architecture claim.

It is built on the PMS-CPU trap mechanism, but it does not redefine the
ordinary PMS-CPU calling convention and does not replace the PMS-CPU
trap/syscall control-transfer model.

It does not claim a completed production kernel, production syscall ABI,
external security validation, fabricated hardware substrate, or PMS Base
validation.
```

---

## 9. Resource Accounting and Quotas

PMS-OS treats resources as policy-governed, operator-visible system state.

Resource accounting records who used which system resource, under which role, in which frame, inside which OS-level isolation domain, during which ordered execution interval, and with which commit status. Quotas constrain future execution by turning resource use into Ψ-governed validity conditions.

The central resource-accounting claim is:

```text
PMS-OS accounts resources through Δ classification, Ω authority,
Θ ordering, τ-derived measurement data, ∇ usage updates, Σ accounting
commit, Χ-projected OS isolation domains, Λ non-events, Φ failure paths,
and Ψ quota policies.
```

Claim type:

```text
OS-level resource-accounting architecture claim
```

Boundary:

```text
This section specifies PMS-OS resource accounting and quota architecture.

It does not claim a completed production kernel, production quota subsystem,
external performance validation, external security validation, fabricated
hardware substrate, or PMS Base validation.
```

Resource accounting is therefore not a side database.

It is part of the kernel validity model.

Canonical notation:

```text
RAcc = ResourceAccount
```

`RF` must not be used for resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

A concrete PMS-OS resource-accounting execution produces:

```text
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible resource-accounting executions is:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 9.1 Resource Accounting Role

Resource accounting serves six architectural purposes.

1. It makes resource use explicit.

```text
actor
resource
amount
frame
role
OS isolation-domain value
time/accounting window
commit status
```

2. It gives Ψ policies concrete data.

```text
RAcc.mem.used > RAcc.mem.max ⇒ deny or reframe
```

3. It binds scheduling to accountable execution.

```text
Θ dispatches threads whose resource state is policy-valid
```

4. It supports isolation.

```text
resources consumed inside X_domain are attributed to that domain
```

`X_domain` is an OS-level isolation-domain value.

It is not the PMS Base operator `Χ`.

It names a concrete boundary, namespace, process, container, driver, or device domain through which PMS Base Χ = Distance is projected at OS level.

5. It supports graceful failure.

```text
Λ allocation-not-realized
Φ OOM / quota trap
Θ throttling
Ω priority downgrade
Σ audit commit
```

6. It produces artifact evidence when implemented.

```text
resource event → accounting update → quota decision → audit trace
```

Artifact evidence strengthens bounded implementation-artifact claims.

It does not validate PMS Base.

### 9.2 Resource Account Structure

The primary accounting object is a resource account.

```text
ResourceAccount = (
    owner,
    scope,
    cpu,
    mem,
    ipc,
    storage,
    net,
    devices,
    limits,
    policy,
    meta
)
```

Canonical shorthand:

```text
RAcc = ResourceAccount
```

where:

| Field     | Meaning                                                          |
| --------- | ---------------------------------------------------------------- |
| `owner`   | process, user, role, container, driver, device, group, or system |
| `scope`   | accounting scope                                                 |
| `cpu`     | CPU usage and scheduling counters                                |
| `mem`     | memory allocation and mapping counters                           |
| `ipc`     | IPC queues, messages, bytes, rate windows                        |
| `storage` | blocks, inodes, journaled writes, persistent usage               |
| `net`     | optional network usage counters                                  |
| `devices` | driver/device resource use                                       |
| `limits`  | hard and soft quotas                                             |
| `policy`  | active Ψ constraints over this account                           |
| `meta`    | τ windows, audit state, commit state, lifecycle markers          |

Correct notation:

```text
RAcc.cpu.used
RAcc.mem.used
RAcc.ipc.queue_bytes
RAcc.storage.blocks_used
RAcc.devices.irq_budget
RAcc.limits
```

Incorrect notation:

```text
RF.cpu.used
RF.mem.used
SystemRF
ProcessRF
ThreadRF
```

In PMS-OS, `RF` must not denote `ResourceFrame` or `ResourceAccount`.

### 9.3 Resource Frames

A resource account may be represented as a frame-like OS object.

```text
ResourceFrame = (
    id,
    owner,
    cpu,
    mem,
    ipc,
    storage,
    net,
    devices,
    limits,
    policies,
    meta
)
```

A `ResourceFrame` may carry or reference a `ResourceAccount`.

Resource frames allow quotas to compose with the rest of PMS-OS:

| Resource-frame aspect            | Operator role         |
| -------------------------------- | --------------------- |
| identity                         | Δ                     |
| ownership and role               | Ω                     |
| OS isolation-domain value        | Χ projection          |
| hierarchical scope               | □                     |
| usage update                     | ∇                     |
| accounting commit                | Σ                     |
| ordering / accounting window     | Θ over τ-derived data |
| non-event / unavailable resource | Λ                     |
| quota violation response         | Φ / Ψ                 |

A resource frame may belong to:

```text
process
thread
user
role
service
container
namespace
driver
device
filesystem
system
```

The resource account associated with such a frame is still denoted:

```text
RAcc
```

not:

```text
RF
```

### 9.4 Generic Accounting Flow

Every resource-affecting operation follows a common pattern.

```text
Δ classify resource request
Ω verify authority
Ψ check quota and policy
∇ perform or stage resource update
Σ commit accounting update
Ψ post-check invariants
```

In compact form:

```text
Δ → Ω → Ψ → ∇ → Σ → Ψ
```

If the resource cannot be provided:

```text
Λ resource-not-available
```

If the failure requires recontextualization:

```text
Φ quota fault / OOM / throttling / kill / recovery
```

This applies uniformly to CPU, memory, IPC, storage, devices, and optional network resources.

The accounting update is valid only when:

```text
RAcc exists
∧ owner is defined
∧ scope is active
∧ resource class is distinguished
∧ Ω permits update
∧ Ψ permits allocation or use
∧ Σ commits visible accounting state
```

### 9.5 CPU Accounting

CPU accounting is ordered by Θ and measured through τ-derived accounting data.

Θ determines when the kernel samples and attributes execution. τ stores or represents the relevant time/accounting values.

τ is metadata.

It is not introduced here as a PMS Base operator.

A CPU accounting step is:

```text
Θ_tick
→ Δ identify running thread
→ Δ identify RAcc
→ ∇ compute consumed quantum from τ-derived data
→ ∇ update RAcc.cpu.used
→ Σ commit accounting update
→ Ψ check CPU quota
```

A process or thread may have:

```text
RAcc.cpu.used
RAcc.cpu.max
RAcc.cpu.soft_limit
RAcc.cpu.hard_limit
RAcc.cpu.period
RAcc.cpu.deadline
RAcc.cpu.priority
RAcc.cpu.fairness_tokens
```

CPU usage may be attributed by:

```text
process
thread
role
frame
container
driver
kernel/user mode
OS isolation-domain value
```

Role-sensitive attribution:

```text
cpu_used(frame, role) += quantum
```

This supports questions such as:

```text
which process consumed CPU?
under which role?
inside which OS isolation domain?
during which scheduler window?
```

### 9.6 CPU Quota Models

PMS-OS supports soft and hard CPU quotas.

| Quota type | Meaning                                                                    |
| ---------- | -------------------------------------------------------------------------- |
| soft limit | execution may continue, but Ψ may lower priority, warn, audit, or throttle |
| hard limit | Ψ forbids further Θ dispatch that would advance execution beyond the limit |

Soft reaction examples:

```text
Ω downgrade priority
Θ reduce scheduling frequency
Σ commit warning/audit
Φ notify process
```

Hard reaction examples:

```text
Θ stop selecting thread
Φ deliver quota signal
Χ isolate process
Σ commit suspension state
Ψ terminate if policy requires
```

A hard CPU quota can be written:

```text
RAcc.cpu.used ≥ RAcc.cpu.max
⇒ Ψ forbids Θ_select(thread)
```

The scheduler may see a thread as READY but not selectable:

```text
state(t) = READY
∧ RAcc.cpu.used ≥ RAcc.cpu.max
⇒ Θ_select(t) denied by Ψ
```

### 9.7 Memory Accounting

Memory accounting tracks allocation, mapping, sharing, and reclamation.

Memory-affecting operations include:

```text
mmap
munmap
brk
heap expansion
page allocation
copy-on-write fault
shared-memory creation
driver DMA allocation
kernel buffer allocation
cache growth
```

Memory allocation flow:

```text
Δ classify allocation request
Ω verify allocation capability
Ψ check memory quota
□ select or create memory frame
Χ check isolation and sharing boundaries
∇ allocate memory / map frame
Σ commit allocation and accounting
Ψ post-check invariants
```

Memory account fields may include:

```text
RAcc.mem.used
RAcc.mem.max
RAcc.mem.mapped_pages
RAcc.mem.resident_pages
RAcc.mem.shared_pages
RAcc.mem.locked_pages
RAcc.mem.kernel_pages
RAcc.mem.device_dma_pages
RAcc.mem.cache_pages
```

A memory quota violation is:

```text
RAcc.mem.used + requested > RAcc.mem.max
```

Possible responses:

```text
Λ allocation-not-realized
Φ OOM handler
Θ reclaim scheduling
Χ isolate offender
Ω downgrade role or priority
Σ commit failure/audit
Ψ kill or suspend process
```

### 9.8 Memory Isolation and Quotas

Memory accounting must respect isolation.

A process may not satisfy its allocation by silently using another process’s frame.

Valid memory sharing requires:

```text
Δ identify sharing request
Ω authorize both sides
Ψ check sharing policy and quotas
□ create or expose shared frame
Χ add permitted visibility bridge
Σ commit sharing and accounting
```

Shared memory may be charged to:

```text
creator
receiver
both sides proportionally
container
system pool
driver/device account
```

The accounting policy must define attribution explicitly.

A valid shared-memory accounting rule must prevent:

```text
quota laundering
cross-domain uncharged allocation
kernel-frame leakage
driver DMA overreach
```

Shared memory attribution is always expressed through `RAcc` or explicit `ResourceAccount` references.

### 9.9 IPC Accounting

IPC consumes resources through messages, queues, buffers, handles, wakeups, and rate windows.

IPC account fields may include:

```text
RAcc.ipc.queue_bytes
RAcc.ipc.max_queue_bytes
RAcc.ipc.message_count
RAcc.ipc.max_messages
RAcc.ipc.bytes_sent
RAcc.ipc.bytes_received
RAcc.ipc.messages_per_window
RAcc.ipc.outstanding_requests
RAcc.ipc.blocked_senders
RAcc.ipc.blocked_receivers
```

IPC send accounting:

```text
Δ classify destination endpoint
Ω verify SEND capability
Δ measure message size
Ψ check queue and rate limits
∇ enqueue message
Σ commit message and accounting
Ψ post-check delivery constraints
```

IPC receive accounting:

```text
Δ inspect queue
Ω verify RECEIVE capability
Λ if no message exists
∇ dequeue message if present
Σ commit receive accounting
```

A blocking receive may create:

```text
Wait = (MessageFrame, condition, deadline, policy, continuation)
```

A timeout is:

```text
Λ_timeout := τ.now ≥ deadline ∧ message_absent
```

Θ orders when τ-derived data is sampled and compared.

### 9.10 IPC Quotas and Failure Modes

IPC quotas may constrain:

```text
RAcc.ipc.max_message_bytes
RAcc.ipc.max_queue_bytes
RAcc.ipc.max_messages_per_window
RAcc.ipc.max_outstanding_requests
RAcc.ipc.max_blocked_waiters
RAcc.ipc.max_endpoints_per_process
```

Quota violation may produce:

| Response                         | Operator reading |
| -------------------------------- | ---------------- |
| return `WOULD_BLOCK`             | Λ                |
| block sender                     | Θ + Λ            |
| throttle sender                  | Θ + Ψ            |
| deny send                        | Ψ                |
| downgrade capability             | Ω                |
| kill or isolate abusive endpoint | Φ / Χ / Ψ        |
| commit audit event               | Σ                |

IPC quota enforcement prevents one process or domain from exhausting kernel buffers or event queues.

### 9.11 Storage Accounting

Storage accounting tracks persistent space and filesystem-visible allocation.

Storage account fields may include:

```text
RAcc.storage.blocks_used
RAcc.storage.blocks_max
RAcc.storage.inodes_used
RAcc.storage.inodes_max
RAcc.storage.bytes_written
RAcc.storage.journal_bytes
RAcc.storage.snapshots
RAcc.storage.pending_writes
RAcc.storage.quota_class
```

Storage write or allocation flow:

```text
Δ resolve inode / file / block
Ω verify write or allocate permission
Ψ check storage quota
∇ allocate block or modify data
Σ commit filesystem/storage accounting
Ψ enforce filesystem invariants
```

Deletion or freeing:

```text
Δ identify object
Ω verify delete/free permission
∇ free blocks or unlink object
Σ decrement usage and commit metadata
Ψ post-check filesystem consistency
```

Storage quota violation may produce:

```text
Λ ENOSPC-like no-allocation event
Φ transaction rollback
Ψ deny write
Σ audit quota event
```

### 9.12 Storage Quotas and Journaling

Storage accounting interacts with journaling.

A journaled write may produce staged usage before final commit:

```text
∇ stage write
Σ journal intent
Σ apply data
Σ commit quota/accounting update
```

If the transaction aborts:

```text
Φ rollback
Σ commit rollback/accounting correction
```

Quota policy must define whether staged writes count:

```text
count on reservation
count on journal commit
count on final data commit
count on visible file size
```

The selected model must be explicit because it affects denial, rollback, and audit behavior.

### 9.13 Device and Driver Resource Accounting

Drivers and devices consume kernel resources.

Tracked resources may include:

```text
driver memory
DMA buffers
IRQ budget
bottom-half CPU time
workqueue time
device queue depth
MMIO mappings
I/O bandwidth
hotplug state
error/retry counters
```

Driver accounting flow:

```text
Δ identify driver/device/account
Ω verify driver capability
Ψ check driver/device resource policy
∇ allocate or use resource
Σ commit accounting
Ψ evaluate budget
```

Examples:

```text
driver exceeds IRQ budget
device queue grows beyond limit
DMA region exceeds allowed frame
hotplug attach exceeds system resource budget
repeated driver timeouts exceed policy
```

Responses may include:

```text
Θ throttle driver work
Ω reduce driver capabilities
Χ quarantine driver or device
Φ enter recovery path
Σ commit error/audit state
Ψ unload or disable driver
```

Driver and device accounts are denoted:

```text
DriverRAcc
DeviceRAcc
```

Full driver lifecycle appears in Section 16.

### 9.14 Network Accounting

If networking is present in the PMS-OS profile, network usage is accounted as a resource class.

Fields may include:

```text
RAcc.net.bytes_sent
RAcc.net.bytes_received
RAcc.net.packets_sent
RAcc.net.packets_received
RAcc.net.connections
RAcc.net.rate_window
RAcc.net.dropped_packets
RAcc.net.policy_class
```

Network operations follow the same pattern:

```text
Δ classify endpoint / packet / connection
Ω verify network capability
Ψ check policy and rate quota
∇ enqueue or transmit
Σ commit accounting
Λ if destination or buffer unavailable
Φ on transport or policy fault
```

Full distributed semantics are not defined here.

Cluster, quorum, remote consistency, distributed delivery guarantees, and global policy synchronization belong in `07_distributed_systems.md`.

### 9.15 Multi-Level Quotas

PMS-OS supports hierarchical quotas.

Resource accounts may form a hierarchy:

```text
SystemRAcc
 ├── ContainerRAcc
 │    ├── UserRAcc
 │    │    └── ProcessRAcc
 │    │         └── ThreadRAcc
 └── DriverRAcc
      └── DeviceRAcc
```

An accounting update propagates upward:

```text
for each ancestor RAcc:
    RAcc.x.used += delta
```

A resource operation is valid only if all relevant limits permit it:

```text
∀ RAcc ∈ Ancestors(local_RAcc):
    RAcc.x.used + delta ≤ RAcc.x.max
```

If a parent account is over quota, a child may be denied even if its local quota has headroom.

Example:

```text
ProcessRAcc has memory headroom
∧ ContainerRAcc memory exhausted
⇒ allocation denied by Ψ
```

This prevents quota bypass through nested ownership.

### 9.16 Quota Policy Types

PMS-OS distinguishes several quota types.

| Type                   | Meaning                                                   |
| ---------------------- | --------------------------------------------------------- |
| hard quota             | operation forbidden once limit would be exceeded          |
| soft quota             | operation allowed temporarily, with warning or throttling |
| burst quota            | short-term excess allowed within τ-window                 |
| reservation            | resource reserved before use                              |
| guarantee              | minimum resource share                                    |
| cap                    | maximum share                                             |
| proportional share     | relative allocation among groups                          |
| emergency reserve      | kernel-protected resource pool                            |
| driver budget          | driver-specific resource limit                            |
| isolation-domain quota | quota attached to an OS-level isolation-domain value      |

Each quota type must define:

```text
measured resource
scope
τ window if applicable
commit point
violation condition
enforcement action
audit mode
```

Again, τ is time/accounting metadata.

Θ orders when τ-derived windows are sampled, compared, or reset.

### 9.17 Quota Enforcement Actions

Quota violation is Ψ-governed.

Possible responses include:

| Action                   | Operator structure |
| ------------------------ | ------------------ |
| deny operation           | Ψ denial           |
| return no-resource       | Λ                  |
| block                    | Θ + Λ              |
| throttle                 | Θ policy           |
| downgrade priority       | Ω shift            |
| reduce capability        | Ω revoke/narrow    |
| reclaim resources        | Θ + ∇ + Σ          |
| rollback transaction     | Φ + Σ              |
| isolate offender         | Χ                  |
| terminate process        | Φ + Σ + Ψ          |
| quarantine driver/device | Χ + Φ + Σ          |
| audit                    | Δ + Σ              |

Examples:

```text
soft CPU overage       → Ω downgrade + Σ audit
hard memory overage    → Λ allocation failure or Φ OOM
IPC queue overflow     → deny send or block sender
storage quota exceeded → Λ ENOSPC-like outcome
driver IRQ budget hit  → Θ throttle bottom half
critical leak          → Χ quarantine + Φ recovery
```

Quota escalation is OS-level protection and resource-control behavior.

It is not moral judgment, forensic attribution, or governance authority.

### 9.18 Resource Reclamation

Reclamation is the controlled return of resources to available state.

Reclamation may apply to:

```text
memory pages
heap blocks
IPC buffers
file handles
storage blocks
cache pages
driver buffers
device queue entries
process frames
```

Generic reclamation flow:

```text
Δ identify reclaimable resource
Ω verify authority
Ψ ensure reclaim is allowed
∇ mark or free resource
Σ commit resource account update
Ψ post-check invariants
```

If reclamation requires context shift:

```text
Φ reclaim handler
```

If reclamation is delayed:

```text
Λ no-resource-yet
Θ schedule reclaim later
```

Allocation and reclamation are refined in Section 11.

### 9.19 Audit and Observability

Every resource-affecting event may produce an audit record.

```text
ResourceAuditRecord = (
    event_id,
    actor,
    role,
    frame,
    isolation_domain,
    resource_class,
    delta,
    account_before,
    account_after,
    limit,
    decision,
    action,
    timestamp_or_order,
    metadata
)
```

Audit flow:

```text
Δ prepare audit record
Σ commit audit record
Ψ enforce retention and integrity policy
```

Auditing may be enabled for:

```text
quota violations
privileged allocations
driver resource use
filesystem growth
IPC saturation
CPU throttling
OOM paths
resource reclamation
policy changes
```

Trace emission is implementation-specific.

The architecture requires that resource decisions be operator-labeled and representable.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 9.20 Interaction with Scheduling

Scheduling depends on resource state.

A thread may be READY but unselectable if resource policy denies execution.

```text
state(t) = READY
∧ RAcc.cpu.used ≥ RAcc.cpu.max
⇒ Θ_select(t) denied by Ψ
```

Resource state can influence:

```text
priority
fairness tokens
deadline eligibility
preemption
throttling
blocking
suspension
termination
```

A scheduling decision may update resource accounting:

```text
Θ dispatch
→ execution interval
→ Σ commit CPU usage
→ Ψ evaluate quota
```

This closes the loop between Section 5 and Section 9.

### 9.21 Interaction with Syscalls

Most resource changes occur through syscalls.

Examples:

| Syscall                | Resource                        |
| ---------------------- | ------------------------------- |
| `mmap`                 | memory                          |
| `write`                | storage / IPC / device          |
| `sendmsg`              | IPC / network                   |
| `fork` / `clone`       | process, memory, scheduler      |
| `execve`               | memory, file, process lifecycle |
| `open`                 | file handle                     |
| `timer_create`         | timer/event resources           |
| `register_irq_handler` | driver/device resources         |
| `policy_update`        | policy resource and audit state |

Syscall flow with accounting follows the canonical PMS-OS syscall contract:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded for resource accounting:

```text
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, endpoint, namespace, or resource-domain boundary
→ Δ classify syscall and resource
→ Ψ quota and policy precheck
→ operation
→ Σ commit resource update
→ Ψ postcheck
→ Φ return
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

### 9.22 Resource Accounting Invariants

PMS-OS maintains the following resource invariants.

```text
I1: every accounted resource has an owner or system scope

I2: resource mutation is Δ-classified before update

I3: protected resource use requires Ω authority

I4: quota policy is checked before allocation or commit

I5: accounting updates are Σ-committed before global visibility

I6: hierarchical quotas propagate to ancestor resource accounts

I7: local quotas cannot bypass parent quotas

I8: shared resources have explicit attribution rules

I9: CPU usage is ordered by Θ and measured through τ-derived data

I10: memory ownership respects frame and isolation boundaries

I11: IPC queue growth is bounded by policy

I12: storage usage is updated consistently with filesystem commits

I13: driver/device resource use is charged to driver/device accounts

I14: resource-denial outcomes are represented through Λ, Φ, or Ψ

I15: audit records, when enabled, are Σ-committed

I16: no resource exhaustion path silently bypasses Ψ_kernel

I17: RAcc / ResourceAccount is the resource-accounting notation

I18: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I19: SystemRAcc, ContainerRAcc, UserRAcc, ProcessRAcc, ThreadRAcc,
     DriverRAcc, and DeviceRAcc are the canonical hierarchy names

I20: X_domain, X_p, X_user, and X_global are OS-level isolation-domain
     values, not PMS Base Χ

I21: PMS Base Χ = Distance; PMS-OS projects Χ as process isolation,
     address-space boundary, namespace separation, device boundary, IPC
     visibility, filesystem view, sandbox/container boundary, and
     reachability control

I22: τ denotes time/accounting metadata, not a PMS Base operator

I23: resource-accounting traces remain operator-labeled and belong to
     L_PMS or L_PMS,Ψ_kernel under the declared OS profile
```

### 9.23 Boundary to Later Sections

This section defines the OS-level accounting and quota architecture.

Details are refined later:

| Topic                                         | Section                     |
| --------------------------------------------- | --------------------------- |
| allocation and reclamation mechanics          | Section 11                  |
| virtual memory and address spaces             | Section 10                  |
| filesystem storage accounting                 | Section 12                  |
| block devices and storage drivers             | Section 13                  |
| cache and buffer management                   | Section 14                  |
| IPC queue semantics                           | Section 15                  |
| device and driver lifecycle                   | Section 16                  |
| runtime-security evidence and audit hardening | `06_runtime_security.md`    |
| distributed quota and cluster accounting      | `07_distributed_systems.md` |

This section provides the OS-level resource-accounting substrate.

It does not define runtime-security evidence hardening or distributed quota synchronization.

### 9.24 Architectural Consequence

PMS-OS resource accounting makes resource use part of kernel validity.

The consequence is:

```text
A PMS-OS resource operation is valid only when the resource is identified,
the actor is authorized, the relevant quota and policy constraints hold,
the usage update is committed, and the resulting ResourceAccount state
preserves kernel invariants.
```

This gives PMS-OS a unified quota model for CPU, memory, IPC, storage, devices, drivers, optional networking, containers, users, roles, and processes.

### 9.25 Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-OS resource-accounting model specifies OS-level accounting objects,
quota hierarchies, CPU/memory/IPC/storage/device/network accounting,
quota enforcement, reclamation, syscall interaction, scheduling interaction,
and audit representability through Δ–Ψ operator structure.

This is an OS-level resource-accounting architecture claim.

It does not claim a completed production quota subsystem, production
scheduler, production memory manager, external performance validation,
external security validation, distributed quota synchronization, fabricated
hardware substrate, or PMS Base validation.
```

---

## 10. Virtual Memory and Address Spaces

PMS-OS defines virtual memory as a frame-structured address interpretation system.

Memory is not treated as a flat byte array with permissions added afterward. At OS level, memory is a hierarchy of frames, mappings, address spaces, protection domains, page-table entries, shared regions, and fault paths governed by □, Χ, Ω, Φ, Σ, and Ψ.

The central virtual-memory claim is:

```text id="ukc7na"
PMS-OS treats virtual memory as □-structured address interpretation,
Χ-projected isolation, Ω-governed access, Φ-mediated fault handling,
Σ-committed mapping state, RAcc-governed accounting, and Ψ-constrained
protection policy.
```

Claim type:

```text id="sli6dw"
OS-level virtual-memory and address-space architecture claim
```

Boundary:

```text id="azwmv6"
This section specifies PMS-OS virtual memory and address-space architecture.

It does not claim a completed production memory manager.

It does not claim physical MMU circuitry, physical page-table hardware,
physical TLB behavior, physical cache-coherence hardware, or fabricated
hardware substrate.

It does not claim external security validation.

It does not validate PMS Base.
```

Allocation and reclamation are defined in Section 11.

A concrete PMS-OS virtual-memory execution produces:

```text id="rkepko"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="fm8xq3"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible virtual-memory executions is:

```text id="drkiug"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="zqghyq"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

### 10.1 Conceptual Model

A virtual address is not self-interpreting.

A virtual address is meaningful only relative to:

```text id="epd5ys"
active process
active frame set
active role/capability state
active OS isolation-domain value
active policy state
mapping tables
resource account RAcc
```

A process address space is:

```text id="j2no59"
AddressSpace(p) = (FrameSet_p, Map_p, X_p, P_p, RAcc_p, meta)
```

where:

| Component    | Meaning                                                               |
| ------------ | --------------------------------------------------------------------- |
| `FrameSet_p` | frames visible to process `p`                                         |
| `Map_p`      | virtual-address resolution relation                                   |
| `X_p`        | OS-level process isolation-domain value                               |
| `P_p`        | effective process policy                                              |
| `RAcc_p`     | process resource account                                              |
| `meta`       | page faults, dirty/access bits, COW state, accounting, lifecycle data |

At PMS Base level:

```text id="bv974j"
Χ = Distance
```

At PMS-OS level, Χ projects as address-space separation, process isolation, namespace visibility, IPC visibility, device boundary, filesystem view, and reachability control.

`X_p` is an OS-level isolation-domain value.

It is not the PMS Base operator `Χ`.

It names a concrete PMS-OS boundary / reachability / namespace / address-space domain through which PMS Base Χ = Distance is projected at OS level.

At OS level:

```text id="cofroe"
virtual memory = frame interpretation + mapping + protection + fault semantics
```

### 10.2 Memory as Frames

The core memory object is a frame.

```text id="j9tpvv"
Frame = (id, base, size, type, perms, owner, links, meta)
```

For virtual memory, relevant frame types include:

```text id="lac4ic"
CODE
DATA
STACK
HEAP
SHARED
IPC
MMIO
DEVICE
KERNEL
USER
CACHE
GUARD
COW
```

A memory frame defines:

```text id="n30hti"
address interval
interpretation context
access permissions
owner
visibility links
policy hooks
commit state
fault behavior
resource-accounting relation
```

A process does not “own memory” directly. It owns or observes frames.

```text id="z18kp2"
FrameSet_p = {
    CodeFrame,
    DataFrame,
    HeapFrame,
    StackFrame,
    IPCFrames,
    SharedFrames,
    KernelGatewayFrame,
    GuardFrames,
    MappedFileFrames
}
```

Frame membership defines what can be resolved, accessed, shared, or faulted.

### 10.3 Address Spaces as Frame Sets

An address space is a process-specific frame view.

```text id="ydfdox"
VAS(p) = □_p
```

with a mapping function:

```text id="k3e2q7"
Map_p : VirtualAddress → FrameId × Offset × Permissions × Meta
```

A virtual address resolution is:

```text id="t1v56n"
Resolve(p, VA) =
    Δ classify VA
    → □ select mapped frame
    → Ω check access mode
    → Χ check boundary/reachability
    → Ψ check policy
    → RAcc check accounting constraints where relevant
    → physical/device/backing object interpretation
```

Thus:

```text id="nlni8w"
VA is valid iff Resolve(p, VA) succeeds under □, Ω, Χ, Ψ, and relevant
RAcc constraints.
```

Invalid resolution produces Φ.

### 10.4 Virtual Address Resolution

Given:

```text id="iwo6x3"
VA
AccessMode ∈ {read, write, execute, map, share}
```

the kernel resolves:

```text id="oc9rz8"
ResolvedAccess = (FrameId, Offset, AccessMode, EffectivePerms)
```

Resolution pipeline:

```text id="t5pu0a"
Δ classify VA
□ select address-space mapping
Ω verify caller capability
Χ verify boundary reachability
Ψ verify active memory policy
RAcc check resource/accounting constraints where relevant
Φ if missing or invalid
```

In compact form:

```text id="sc8gct"
VA
→ Δ
→ □
→ Ω
→ Χ
→ Ψ
→ RAcc?
→ access or Φ_fault
```

A resolution is valid when:

```text id="ez2j41"
mapping exists
∧ frame exists
∧ offset within frame bounds
∧ requested access allowed by frame perms
∧ role/capability state permits access
∧ boundary permits reachability
∧ policy permits access
∧ resource-accounting constraints hold where relevant
```

### 10.5 Segmentation-Style Resolution

PMS-OS permits a segmentation-style VM profile.

In this profile, the address space is a set of contiguous frames:

```text id="t75cy9"
CodeFrame | DataFrame | HeapFrame | StackFrame | SharedFrame | GuardFrame
```

Resolution is interval-based:

```text id="xput6e"
VA ∈ [frame.base, frame.base + frame.size)
⇒ select frame
```

This strategy is appropriate for:

* small kernels;
* embedded profiles;
* simple checking targets;
* deterministic simulator profiles;
* low-fragmentation runtimes;
* educational or minimal PMS-OS implementations.

Segmentation is a pure □-dominant memory model:

```text id="jlq7m9"
address interpretation = frame interval selection
```

Protection still requires Ω, Χ, and Ψ.

Segmentation-style resolution is an OS-level VM profile.

It does not claim physical segmentation hardware.

### 10.6 Paging-Style Resolution

PMS-OS also permits a paging-style VM profile.

Virtual address:

```text id="xi0nw6"
VA = (page_index, page_offset)
```

Page-table lookup:

```text id="uuajcv"
PageTable_p[page_index] = PTE
```

where:

```text id="xopw2z"
PTE = (FrameId, perms, flags, meta)
```

Resolution:

```text id="bd3mhs"
VA
→ Δ classify page index
→ PageTable_p[page_index]
→ □ select FrameId
→ Ω / Χ / Ψ checks
→ RAcc check if mapping or allocation affects accounting
→ Frame.base + page_offset
```

Paging is useful for:

* sparse address spaces;
* copy-on-write;
* demand paging;
* shared mappings;
* file-backed mappings;
* page-level protection;
* guard pages;
* lazy allocation;
* memory pressure handling.

Paging is not a separate theory.

It is □ frame selection at page granularity.

This is an OS-level paging model.

It does not claim physical page-table hardware, physical TLB behavior, or fabricated MMU circuitry.

### 10.7 Page Table Entry Structure

A page table entry is an OS-level mapping descriptor.

```text id="bjzy1t"
PTE = (
    FrameId,
    perms,
    flags,
    owner,
    isolation,
    policy,
    accounting,
    meta
)
```

Typical permissions:

```text id="feqfs4"
r  read
w  write
x  execute
u  user accessible
k  kernel accessible
s  shared
m  mappable
```

Typical flags:

```text id="ayw0nv"
present
dirty
accessed
copy_on_write
guard
shared
private
file_backed
anonymous
device
mmio
no_exec
write_protected
```

Meta fields may include:

```text id="o6bx1e"
version
τ-derived accounting data
locality hint
cacheability
encryption metadata
fault handler
journal/accounting handle
RAcc reference
```

The PTE is not merely a hardware artifact.

In PMS-OS it is the OS-level mapping descriptor connecting address interpretation, protection, policy, accounting, and fault behavior.

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived metadata is sampled, compared, or used.

### 10.8 Process Address Space Construction

A process address space is constructed by the kernel.

Creation flow:

```text id="rbr1mn"
Δ classify executable/template
Ω authorize process creation
□ create FrameSet_p
Χ create OS isolation-domain value X_p
Ψ attach process memory policy
Σ initialize ResourceAccount RAcc_p
Σ commit process address space
```

Initial address-space frames may include:

```text id="bljvna"
CodeFrame
ReadOnlyDataFrame
DataFrame
HeapFrame
MainStackFrame
GuardFrame
IPCFrameSet
KernelGatewayFrame
MappedFileFrames
```

The kernel must ensure:

```text id="wi38u7"
code frame executable and non-writable
stack frame writable and non-executable unless policy permits
heap frame writable and non-executable unless policy permits
kernel frames not user-writable
guard frames unmapped or faulting
shared frames explicitly authorized
RAcc_p initialized before resource-visible execution
```

### 10.9 User/Kernel Memory Boundary

Kernel and user memory are separate frame domains.

```text id="h5gb4f"
□_user ⟂ □_kernel
```

At PMS-OS level:

```text id="wz44to"
Χ_user_kernel = strict boundary projection
```

Concrete domain values:

```text id="xcosj1"
X_user
X_global
```

`X_user` and `X_global` are OS-level isolation-domain values.

They are not PMS Base Χ.

User code may not:

```text id="c2xl9i"
map kernel frames
write kernel memory
execute kernel-only code
inspect kernel-private metadata
forge kernel pointers
modify page tables directly
```

Kernel code may access user memory only through checked accessors.

A kernel read from user memory requires:

```text id="vl9yc5"
VA ∈ user VisibleFrames
∧ Ω permits kernel-mediated read
∧ Χ permits controlled reachability
∧ Ψ permits syscall-specific access
```

This prevents the syscall layer from treating user pointers as trusted data.

Syscall-mediated user-memory access follows the canonical PMS-OS syscall contract:

```text id="ip6od3"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

This is the OS-level syscall ABI built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

### 10.10 Mapping Operations

Mapping operations create, remove, or alter virtual-memory relations.

Typical mapping operations:

```text id="zwerpt"
map anonymous memory
map file-backed memory
map shared memory
map device memory
unmap region
change permissions
protect region
remap region
create guard page
```

Canonical mapping flow:

```text id="uc213z"
Δ classify mapping request
Ω verify mapping authority
Ψ check policy and quota
□ create or select frame
Χ establish visibility/boundary relation
Σ commit mapping
Σ commit RAcc update where required
Ψ post-check invariants
```

For `mmap`:

```text id="yga3ma"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel and address-space boundary
→ Δ classify addr/size/flags
→ Ψ check quota and policy
→ □ create/bind frame
→ Χ install boundary relation
→ Σ commit mapping
→ Σ commit RAcc update where required
→ Ψ postcheck
→ Φ return
```

Compact syscall form:

```text id="pld5jp"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; □ ; Χ ; Σ? ; Ψ ; Φ
```

### 10.11 Unmapping Operations

Unmapping removes address-space visibility.

Canonical unmap flow:

```text id="oy4o1u"
Δ identify mapped region
Ω verify unmap authority
Ψ check lifecycle constraints
□ detach frame from address space
Σ commit mapping removal
Σ commit RAcc update where required
Ψ post-check dangling references
```

If the unmapped frame is shared, unmapping may decrement a reference count or visibility edge rather than destroy the frame.

```text id="v5xznl"
unmap local relation ≠ destroy frame
```

Destruction belongs to reclamation and lifecycle closure.

### 10.12 Protection Rules

Virtual-memory protection combines frame permissions, roles, boundaries, policies, and resource-account state.

Access rule:

```text id="et4ssc"
AccessAllowed(p, VA, mode) iff
    Resolve(p, VA) = (f, off, perms)
    ∧ mode ∈ perms
    ∧ Ω(role(p), mode, f)
    ∧ Χ permits reachability from X_p to f
    ∧ Ψ permits access
    ∧ RAcc constraints hold where access changes resource-visible state
```

Violations include:

```text id="mhbiob"
unmapped address
out-of-bounds access
read without permission
write without permission
execute without permission
user access to kernel frame
cross-domain access without bridge
policy-forbidden access
resource-accounting violation
```

Each violation produces Φ:

```text id="wuw8du"
Φ_pagefault
Φ_protection_fault
Φ_policy_fault
Φ_boundary_fault
Φ_quota_fault
```

### 10.13 W^X and Executability

A typical PMS-OS memory invariant is:

```text id="evppzl"
no frame is both writable and executable unless policy explicitly permits
```

In policy form:

```text id="ihqjbx"
Ψ_WX(f):
    not (w ∈ perms(f) ∧ x ∈ perms(f))
    unless explicit exception is active
```

This applies to:

* user code pages;
* heap pages;
* stack pages;
* JIT-generated code;
* driver code;
* kernel modules;
* mapped files.

JIT or dynamic-code systems require an explicit transition:

```text id="d7fg62"
write code buffer
Σ commit write
□ change frame perms
Ψ check executable state
Σ commit permission change
```

This is an OS-level protection invariant.

It does not claim a complete runtime-security policy; runtime-security hardening is refined in `06_runtime_security.md`.

### 10.14 Page Faults as Φ Events

A page fault is a recontextualization.

Fault causes include:

```text id="l2qxth"
missing mapping
not-present page
write to read-only page
write to COW page
execute from non-executable frame
user access to kernel frame
access outside frame bounds
policy-denied mapping
resource-accounting denial
```

Fault path:

```text id="tocb5d"
Δ classify fault cause
Φ enter kernel fault handler
Ω check handler authority
□ inspect or modify mapping frames
Χ verify boundary relation
Ψ choose response
Σ commit mapping/update if resolved
Σ commit RAcc update where required
Φ return or terminate
```

Possible responses:

```text id="t8swm6"
map page
allocate frame
perform copy-on-write
load from backing store
deny and signal
kill process
quarantine domain
panic/halt under critical policy
```

A page fault is not an undefined exception.

It is a controlled Φ transition.

### 10.15 Copy-on-Write

Copy-on-write supports efficient fork, snapshot, and shared mapping behavior.

Fork-like setup:

```text id="wnixhe"
Δ classify parent address space
□ duplicate mapping metadata
Χ define parent/child sharing boundary
set writable pages to COW
Σ commit child address space
Σ create or link child RAcc
```

On write to a COW page:

```text id="d5h8hl"
Δ detect COW write
Φ enter COW fault handler
□ allocate new private frame
∇ copy old frame content
□ update PTE to private writable frame
Σ commit mapping and accounting
Φ return
```

Canonical sequence:

```text id="m9jikn"
Δ → Φ → □ → ∇ → Σ → Φ
```

COW is valid only if:

```text id="ndm5s9"
source frame remains visible
∧ target frame is private or policy-authorized
∧ accounting is updated through RAcc
∧ no cross-domain write leak occurs
```

### 10.16 Shared Memory

Shared memory is explicit frame sharing.

A shared frame:

```text id="x4q7hs"
SharedFrame = (id, base, size, perms, owners, links, policy, meta)
```

Mapping into processes:

```text id="ex0n0l"
SharedFrame(fid) → mapped into FrameSet_p and FrameSet_q
```

Creation flow:

```text id="i9n3qn"
Δ identify sharing request
Ω authorize participants
Ψ evaluate sharing policy
□ create or select SharedFrame
Χ create permitted bridge
Σ commit sharing relation
Σ commit RAcc attribution
```

Shared memory supports:

* zero-copy IPC;
* ring buffers;
* shared libraries;
* graphics buffers;
* shared cache structures;
* runtime coordination.

Policy must define:

```text id="x5lmzy"
who may map
read/write permissions
whether both sides may write
synchronization requirements
accounting attribution
lifetime and cleanup
```

Shared mapping attribution must prevent quota laundering and cross-domain uncharged allocation.

### 10.17 IPC Frames and Memory

IPC endpoints may be backed by frames.

Examples:

```text id="sgwb3b"
MessageFrame
ChannelFrame
RingBufferFrame
SharedMemoryFrame
EventFrame
SyncFrame
```

These frames are visible only through authorized boundaries.

```text id="cids0m"
IPC access valid iff
    endpoint frame visible
    ∧ Ω permits send/receive/map
    ∧ Χ permits process relation
    ∧ Ψ permits communication
```

This connects virtual memory to Section 15 without duplicating IPC semantics.

IPC-backed memory may affect `RAcc.ipc`, `RAcc.mem`, or both, depending on the declared OS profile.

### 10.18 File-Backed Mappings

A file-backed mapping binds a filesystem frame into a process address space.

```text id="dpmtx4"
MappedFileFrame = (FileFrame, offset, length, perms, cache_state, policy)
```

Mapping flow:

```text id="g4j2u8"
Δ resolve file
Ω check file and mapping permissions
Ψ check filesystem and memory policy
□ create MappedFileFrame
Χ attach to address space
Σ commit mapping
Σ commit RAcc update where required
```

Writes may be:

```text id="j1q4wi"
private COW
shared write-back
write-through
journaled
deferred
```

Commit behavior is controlled by Σ and refined in filesystem/cache sections.

### 10.19 Device and MMIO Mappings

Device memory is represented as a frame.

```text id="b68qtj"
DeviceFrame
MMIOFrame
DMARegionFrame
```

Mapping device memory into a process or driver requires strict authority:

```text id="y9w15n"
Ω(role, map, DeviceFrame)
∧ Χ permits device boundary
∧ Ψ permits device exposure
```

MMIO mapping flow:

```text id="e1pyu3"
Δ identify device region
Ω check driver/device capability
Ψ check driver policy
□ map MMIOFrame
Χ restrict reachable memory
Σ commit mapping
Σ commit DriverRAcc or DeviceRAcc update where required
```

DMA must be bounded by explicit frames:

```text id="n5zedi"
DMARegionFrame = (base, size, owner, device, perms, policy)
```

This prevents devices from writing arbitrary memory.

This is an OS-level device-memory mapping model.

It does not claim physical device-bus implementation or fabricated hardware behavior.

### 10.20 Context Switching and Address Spaces

A context switch changes which address space interprets memory references.

Context-switch memory phase:

```text id="jucq5k"
Σ save outgoing CPU/thread state
□ install AddressSpace(p_new)
Χ install OS isolation-domain value X_p_new
Ω install role/capability state
Ψ validate dispatch
Θ resume selected thread
```

A context switch is invalid if:

```text id="baxmpu"
new address space missing
∨ frame set incoherent
∨ role not compatible with mapping
∨ boundary metadata stale
∨ policy forbids dispatch
∨ resource-accounting state is incoherent
```

Thus scheduling and virtual memory are coupled through □, Χ, Ω, Θ, Σ, RAcc, and Ψ.

`X_p_new` is an OS-level isolation-domain value, not PMS Base Χ.

### 10.21 Versioned Memory Contexts

PMS-OS may support versioned memory views.

A versioned memory context is:

```text id="bl98bb"
MemoryVersion = (FrameSet, mappings, policy, version_id, RAcc_ref, meta)
```

Versioned memory enables:

* hot-patching;
* live migration;
* snapshotting;
* transactional memory contexts;
* ABI switching;
* library rebinding;
* checkpoint/restore.

Version switch:

```text id="w8dx9q"
Φ reframe memory context
□ install new FrameSet or mapping version
Ψ check version policy
Σ commit active version
Σ commit RAcc update where required
Φ resume execution
```

The logical process state may remain stable while its memory interpretation changes.

### 10.22 Demand Paging and Backing Store

A not-present page may be backed by storage.

Demand-paging fault:

```text id="xexmjz"
Δ classify missing page
Φ enter page-fault handler
Δ identify backing object
Ω check access
Ψ check memory/storage policy
∇ load page from backing store
□ install frame mapping
Σ commit page presence and accounting
Φ return
```

If backing data is unavailable:

```text id="jg17zq"
Λ backing-not-ready
Θ schedule I/O
BLOCKED until completion
```

If the backing object fails:

```text id="lfljj1"
Φ I/O fault
Ψ decide signal, retry, kill, or quarantine
```

Demand paging may update both memory and storage accounting:

```text id="3fck9n"
RAcc.mem.*
RAcc.storage.*
```

depending on the declared OS profile.

### 10.23 Guard Frames

Guard frames are deliberate fault frames.

Examples:

```text id="ig3svu"
stack guard page
heap red zone
kernel/user boundary guard
sandbox boundary guard
driver DMA guard
```

A guard frame is validly mapped as inaccessible.

```text id="dudy84"
Access(GuardFrame) ⇒ Φ_guard_fault
```

Guard frames are a positive VM feature: they encode expected protection boundaries.

They are OS-level protection structures, not fabricated hardware claims.

### 10.24 Memory Accounting Integration

Every mapping, allocation, and reclamation action interacts with resource accounting.

Accounting flow:

```text id="vmexax"
Δ classify memory event
Ω verify ownership
Ψ check quota
∇ update memory usage
Σ commit RAcc
Ψ post-check
```

Mapping may charge:

```text id="ifnq9o"
process
container
user
driver
device
shared-frame owners
system pool
```

Shared mappings require explicit attribution.

Memory accounting is defined in Section 9 and used by Section 11.

Correct notation:

```text id="suhxcx"
RAcc.mem.used
RAcc.mem.max
ProcessRAcc
ContainerRAcc
DriverRAcc
DeviceRAcc
```

Incorrect notation:

```text id="tmi3l6"
RF.mem.used
ProcessRF
ContainerRF
DriverRF
DeviceRF
```

`RF` is reserved for PMS-CPU `RegisterFile`.

It must not denote resource accounting in PMS-OS.

### 10.25 Virtual-Memory Trace and Audit

Virtual-memory events may produce trace and audit records.

Examples:

```text id="gzy0aa"
mapping creation
mapping removal
permission change
page fault
COW fault
shared-memory creation
file-backed mapping
device/MMIO mapping
DMA region setup
guard fault
demand-paging event
RAcc update
```

A virtual-memory audit record may be:

```text id="xfzt1q"
VMAuditRecord = (
    event_id,
    actor,
    process,
    frame,
    address_or_range,
    access_mode,
    isolation_domain,
    decision,
    fault_result,
    commit_result,
    resource_accounting_result,
    timestamp_or_order,
    metadata
)
```

Audit flow:

```text id="kippcp"
Δ prepare audit record
Σ commit audit record
Ψ enforce retention / integrity policy
```

Trace emission is an implementation/artifact choice.

Operator-labeled representability is the architecture invariant.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 10.26 Virtual-Memory Invariants

PMS-OS maintains the following VM invariants.

```text id="tfldhg"
I1: every valid virtual address resolves through an active address space

I2: every mapping selects a valid frame

I3: every access is bounds-checked against its frame

I4: every protected access is Ω-authorized

I5: every cross-domain visibility relation is Χ-permitted

I6: every user/kernel crossing is Φ-mediated

I7: user code cannot directly map or write kernel frames

I8: executable and writable permissions obey active Ψ policy

I9: COW writes create private frames before mutation becomes visible

I10: shared frames have explicit policy and accounting rules

I11: device and DMA mappings are bounded by explicit frames

I12: page faults are Φ-handled, not undefined behavior

I13: mapping changes are Σ-committed before global visibility

I14: memory accounting is updated through RAcc according to quota policy

I15: no VM fast path bypasses Ω, Χ, or Ψ constraints

I16: X_p, X_user, X_global, and related X_* symbols are OS-level
     isolation-domain values, not PMS Base Χ

I17: PMS Base Χ = Distance

I18: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, device boundary, IPC visibility, filesystem view,
     sandbox/container boundary, DMA boundary, and reachability control

I19: PTE denotes an OS-level mapping descriptor in this specification, not
     a physical hardware guarantee

I20: RAcc / ResourceAccount is the resource-accounting notation; RF is
     reserved for PMS-CPU RegisterFile

I21: τ denotes time/accounting metadata, not a PMS Base operator

I22: virtual-memory traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile
```

### 10.27 Architectural Consequence

PMS-OS virtual memory is a structured interpretation system.

The consequence is:

```text id="eeek8z"
A PMS-OS address space is a □-structured frame environment whose virtual
addresses resolve only through role-authorized, boundary-valid,
policy-permitted, resource-accounted mappings, with faults handled through
Φ and mapping changes integrated through Σ.
```

This gives PMS-OS a unified model for address spaces, segmentation, paging, COW, shared memory, file mappings, device mappings, page faults, context switching, and resource-accounted memory behavior.

### 10.28 Boundary Statement

The correct boundary for this chapter is:

```text id="gejb3i"
The PMS-OS virtual-memory model specifies OS-level address spaces, frame
sets, mappings, PTE-like descriptors, protection rules, user/kernel memory
separation, page faults, COW, shared memory, file-backed mappings,
device/MMIO mappings, demand paging, guard frames, context switching, and
memory-accounting integration through Δ–Ψ operator structure.

This is an OS-level virtual-memory and address-space architecture claim.

It does not claim a completed production memory manager, physical MMU
circuitry, physical page-table hardware, physical TLB behavior, physical
cache-coherence hardware, fabricated hardware substrate, external security
validation, or PMS Base validation.
```

---

## 11. Allocation and Reclamation

PMS-OS defines allocation and reclamation as structured transformations over frames.

Allocation is not merely pointer production. Reclamation is not merely freeing memory. Both are operator-typed state transitions involving request classification, frame selection, authority checks, boundary constraints, resource accounting, mutation, commit, policy, and fault behavior.

The central allocation claim is:

```text id="j9c2rx"
PMS-OS treats dynamic memory management as Δ-classified, □-scoped,
Ω-authorized, Χ-bounded, RAcc-governed, ∇-executed, Σ-committed,
Ψ-constrained, and Φ/Λ-aware frame transformation.
```

Claim type:

```text id="f0h0c7"
OS-level allocation and reclamation architecture claim
```

Boundary:

```text id="ti890l"
This section specifies PMS-OS allocation and reclamation architecture.

It does not claim a completed production allocator, production memory
manager, production garbage collector, physical memory-controller behavior,
fabricated hardware substrate, external security validation, or PMS Base
validation.
```

This section covers heaps, pools, slab allocators, reference counting, garbage collection, memory pressure, OOM handling, and concurrency safety at OS-specification level.

A concrete PMS-OS allocation execution produces:

```text id="lcezoo"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="elakwk"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible allocation/reclamation executions is:

```text id="mbo5bg"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="ify38h"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text id="fmt1be"
RAcc = ResourceAccount
```

`RF` must not be used for resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

### 11.1 Allocation Domains

Allocation occurs inside an allocation domain.

```text id="sxwt3g"
AllocationDomain = (FrameSet, RAcc, PolicySet, X_alloc, meta)
```

where:

| Component   | Meaning                                                    |
| ----------- | ---------------------------------------------------------- |
| `FrameSet`  | frames visible to the allocation domain                    |
| `RAcc`      | ResourceAccount governing quota and accounting state       |
| `PolicySet` | active allocation and reclamation policy                   |
| `X_alloc`   | OS-level isolation-domain value                            |
| `meta`      | lifecycle, fault, τ-derived accounting, and audit metadata |

`X_alloc` is an OS-level isolation-domain value.

It is not the PMS Base operator `Χ`.

It names the concrete boundary / reachability / namespace / allocation-domain value through which PMS Base Χ = Distance is projected at OS level.

Examples:

```text id="ocd94u"
process heap
kernel heap
driver pool
IPC buffer pool
filesystem cache
page cache
DMA region
shared-memory region
runtime-managed heap
```

Each allocation domain has:

```text id="z89naf"
owner
visible frames
allowed allocation classes
quota
policy
reclamation strategy
fault behavior
```

A domain is valid when:

```text id="hl0trs"
owner exists
∧ FrameSet valid
∧ RAcc active
∧ Ψ permits allocation behavior
∧ Χ boundary projection is coherent
```

### 11.2 Heap as Structured Frame

A heap is a frame.

```text id="x4luo7"
HeapFrame = (base, size, perms = {r, w}, type = HEAP, RAcc_ref, meta)
```

The heap contains subframes:

```text id="tim6b6"
HeapFrame (□)
 ├── BlockFrame_0
 ├── BlockFrame_1
 ├── ...
 └── BlockFrame_N
```

Each allocation block is:

```text id="qzcxwt"
BlockFrame = (addr, size, state, owner, RAcc_ref, meta)
```

where:

```text id="wriiii"
state ∈ {free, used, reserved, quarantined, reclaiming}
```

This means heap management is frame management at a finer granularity.

A pointer returned by allocation is valid only relative to:

```text id="z75pg4"
HeapFrame
BlockFrame
owner
bounds
permissions
policy state
resource-accounting state
```

### 11.3 Allocation Request

An allocation request is:

```text id="y77fuo"
AllocRequest = (size, alignment, class, flags, owner, policy, RAcc_ref, meta)
```

The allocation pipeline is:

```text id="ou0g3e"
Δ classify request
□ select allocation domain and candidate frame
Ω verify allocation authority
Ψ check quota and policy
Χ verify boundary constraints
∇ mutate allocator state
Σ commit allocation and RAcc update
Φ or Λ on failure
```

In compact form:

```text id="olwxyt"
Δ → □ → Ω → Ψ → Χ → ∇ → Σ
```

The returned pointer or handle is valid only after Σ commit.

### 11.4 Allocation Semantics

For:

```text id="sfvddk"
ptr = alloc(n)
```

the OS-level semantics are:

1. Δ — classify request.

```text id="qz9e4a"
size class
alignment
allocation domain
flags
shared/private mode
zeroed/uninitialized mode
RAcc impact
```

2. □ — select candidate frame.

```text id="bmlxhq"
free BlockFrame
slab frame
page frame
heap expansion candidate
pool frame
```

3. Ω — verify authority.

```text id="xqtz7n"
caller may allocate in this domain
caller may expand heap
caller may allocate shared memory
caller may allocate DMA memory
```

4. Ψ — check policy.

```text id="a9codf"
quota
W^X rules
sandbox constraints
driver limits
kernel reserve
fragmentation or pressure policy
```

5. Χ — verify boundary.

```text id="gekdgm"
allocation does not cross unauthorized OS isolation domain
shared allocation has explicit bridge
DMA allocation stays inside DMARegionFrame
```

6. ∇ — perform allocator mutation.

```text id="txu82d"
mark block used
split block if necessary
update free list/tree
create mapping if needed
zero memory if required
update accounting counters as staged state
```

7. Σ — commit allocation.

```text id="n291mg"
pointer becomes valid
RAcc update becomes visible
audit event may be committed
```

### 11.5 Free and Reclamation Semantics

For:

```text id="nktk8m"
free(ptr)
```

the OS-level semantics are:

1. Δ — validate pointer.

```text id="outzo0"
ptr belongs to known BlockFrame
ptr lies inside active HeapFrame
ptr is aligned
ptr state = used
```

2. Ω — verify authority.

```text id="q1wej9"
caller owns or may release this block
```

3. Ψ — check policy.

```text id="jku06p"
not kernel-only
not foreign frame
not already freed
not shared without release protocol
```

4. Χ — check boundary.

```text id="vesmac"
release does not cross an unauthorized allocation domain
foreign-domain free is denied unless explicit policy permits it
```

5. ∇ — mutate allocator state.

```text id="xup4p1"
BlockFrame.state := free
clear metadata if required
coalesce adjacent free blocks
remove references
stage accounting decrement
```

6. Σ — commit reclamation.

```text id="qzythb"
block becomes available for reuse
RAcc accounting is decremented
audit may be recorded
```

Invalid free paths:

```text id="xhmrn3"
unknown pointer      → Φ invalid-pointer fault
double free          → Φ memory-safety fault
foreign pointer      → Φ boundary fault
kernel/shared frame  → Ψ denial / Φ trap
```

### 11.6 Heap Expansion

If no existing block satisfies an allocation, the heap may expand.

Heap expansion flow:

```text id="giznbk"
Δ classify expansion need
Ω verify expansion authority
Ψ check memory quota
□ request new page/frame mapping
Χ ensure boundary remains valid
∇ extend HeapFrame or attach new BlockFrame region
Σ commit mapping and RAcc accounting
```

If expansion cannot occur:

```text id="ggw3h9"
Λ allocation-not-realized
```

or:

```text id="aet37h"
Φ OOM handler
```

depending on policy and syscall/runtime mode.

### 11.7 Pools and Slab Allocators

Pools and slabs are reusable allocation patterns.

A slab pattern is:

```text id="otwbvn"
Α_slab(size_class):
    SlabFrame
    ├── ObjectFrame_0
    ├── ObjectFrame_1
    └── ObjectFrame_N
```

A slab object is:

```text id="j9m5hd"
ObjectFrame = (addr, size_class, state, owner, RAcc_ref, meta)
```

Allocation from slab:

```text id="gyzkh1"
Δ classify size class
□ select SlabFrame
Ω verify use of pool
Ψ check pool policy and quota
∇ set ObjectFrame.state := used
Σ commit allocation and RAcc update
```

Free to slab:

```text id="dm76le"
Δ validate object
Ω verify release authority
∇ set ObjectFrame.state := free
Σ commit free and RAcc update
```

Slabs are suitable for:

```text id="is8205"
kernel objects
IPC messages
thread descriptors
file handles
page-table entries
driver descriptors
sync primitives
```

Shared or privileged slabs require stricter Ω/Ψ hooks.

### 11.8 Kernel Pools

Kernel memory pools are privileged allocation domains.

Examples:

```text id="uzlt3i"
process descriptor pool
thread descriptor pool
frame descriptor pool
IPC message pool
device request pool
driver work item pool
audit record pool
```

Kernel-pool allocation requires:

```text id="sxm0cx"
kernel role
valid subsystem authority
policy permission
resource reserve availability
```

Kernel-pool invariants:

```text id="wfrz5a"
kernel reserve cannot be exhausted by user allocation
driver allocations charged to DriverRAcc
IPC pool growth bounded by quota
audit pool preserves critical logging reserve
```

If a kernel pool is exhausted:

```text id="zlw0w3"
Λ kernel-pool-unavailable
Φ recovery / pressure path
Ψ critical policy response
```

### 11.9 Reference Counting

Reference counting is an allocation-lifecycle mechanism.

For object `o`:

```text id="cl4b7a"
refcount(o) ∈ state(o)
```

Retain:

```text id="fvrok0"
Δ identify object
Ω verify sharing/retain authority
Χ verify visibility relation
∇ refcount(o) := refcount(o) + 1
Σ commit retain
Ψ check overflow and sharing policy
```

Release:

```text id="wdc0fy"
Δ identify object
Ω verify release authority
∇ refcount(o) := refcount(o) - 1
if refcount(o) = 0:
    reclaim(o)
Σ commit release/reclaim
Ψ check underflow and lifecycle closure
```

Reference-counting invariants:

```text id="o9uu86"
refcount never underflows
refcount never overflows
zero refcount implies object not reachable
cross-domain retain requires policy permission
shared object lifetime is explicit
RAcc attribution remains coherent for shared objects
```

### 11.10 Garbage Collection

Garbage collection is modeled as Θ-ordered traversal and reclamation of frame graphs.

A GC-managed heap contains:

```text id="pwitfq"
objects as BlockFrames
references as Δ-distinguishable edges
roots as Role/Frame/Thread/Stack references
```

GC cycle:

```text id="n8f4ch"
Θ enter GC cycle
Δ identify roots
Δ traverse reachable objects
∇ mark reachable objects
Δ classify unmarked objects
∇ reclaim unmarked objects
Σ commit heap state and RAcc update
Ψ check memory policy
```

GC does not need to be mandatory for PMS-OS.

PMS-OS specifies how GC fits when a runtime or subsystem uses it.

A concrete runtime GC belongs to the runtime/language layer unless implemented as an OS subsystem.

### 11.11 Mark and Sweep

Mark phase:

```text id="qk67i8"
Θ begin mark
Δ identify roots
Δ inspect references
∇ mark reachable BlockFrames
Χ prevent invalid cross-domain traversal
```

Sweep phase:

```text id="q6xooq"
Θ begin sweep
Δ classify marked vs unmarked
∇ free unmarked blocks
Σ commit free state and RAcc update
Ψ post-check
```

Mark/sweep must respect:

```text id="um276y"
thread stacks
shared frames
IPC references
driver references
file-backed mappings
kernel roots
policy-protected objects
OS isolation-domain boundaries
```

### 11.12 Copying and Generational Collection

Copying GC uses Φ and □ to reframe heap state.

Copying cycle:

```text id="o6kye4"
Φ enter collection context
□ create to-space HeapFrame
Δ scan roots
∇ copy live objects
∇ update references
Σ commit new heap frame
Σ commit RAcc update where required
□ retire old heap frame
Φ resume execution
```

Generational GC adds:

```text id="irz6r3"
young generation frames
old generation frames
promotion policy
write barriers
```

Write barriers are policy/ordering hooks:

```text id="dz6q9m"
∇ write reference
Θ/Ψ record intergenerational edge
Σ commit barrier metadata
```

Χ ensures that no other thread observes inconsistent intermediate heap structure across an OS isolation-domain boundary.

### 11.13 Stop-the-World and Concurrent Collection

PMS-OS permits multiple GC scheduling profiles.

#### Stop-the-world

```text id="oe9vdu"
Θ suspend mutator threads
Σ save thread states
Φ enter GC context
perform GC
Σ commit heap state
Σ commit RAcc update where required
Θ resume mutators
```

#### Concurrent GC

```text id="x9861j"
Θ interleave collector and mutators
Ψ enforce barrier correctness
Χ isolate collector metadata
Σ commit incremental progress
```

Concurrent collection requires explicit policy over:

```text id="djl8c4"
write barriers
read barriers
object movement
visibility of forwarded pointers
thread synchronization
resource-account attribution
```

### 11.14 Memory Pressure

Memory pressure is a resource condition.

```text id="orc40k"
MemoryPressure(level) =
    RAcc.mem.used / RAcc.mem.max
    plus kernel reserve state
    plus reclaimable cache state
    plus allocation failure history
```

Pressure response:

```text id="ssrnnt"
Δ classify pressure level
Ψ choose pressure policy
Θ schedule reclaim
∇ reclaim caches/pages/objects
Σ commit reclaimed accounting
```

Possible pressure levels:

```text id="lx6idp"
NORMAL
ELEVATED
CRITICAL
OOM
```

The kernel may reclaim:

```text id="gisolz"
page cache
filesystem buffers
unused slabs
freeable heap regions
inactive pages
driver buffers if policy permits
```

Memory pressure policy is OS-level resource-control behavior.

It is not external performance validation.

### 11.15 Out-of-Memory Handling

OOM occurs when an allocation cannot be satisfied after permitted reclaim paths.

OOM path:

```text id="kb0x6j"
Λ allocation-not-realized
Φ enter OOM handler
Δ classify offender and criticality
Ψ choose response
Χ isolate or suspend if needed
Σ commit failure/audit/resource state
Φ return error or terminate
```

Possible OOM responses:

```text id="y1vx8t"
return allocation failure
block and retry
run reclaim
invoke GC
reduce priority
suspend process
kill selected process
protect critical process
enter low-memory mode
panic/halt if kernel invariant cannot be preserved
```

Policy may define:

```text id="gc5dxy"
kernel must not exhaust emergency reserve
critical services are non-killable
driver memory may be reclaimed before user memory
container may be killed before system process
```

OOM selection is kernel-internal resource and lifecycle policy.

It is not moral judgment, forensic attribution, or governance authority.

### 11.16 Allocation Failure as Λ

Not every allocation failure is a fault.

If allocation is optional or nonblocking:

```text id="y3nm61"
Λ allocation_absent
```

Examples:

```text id="x0rk1d"
try_alloc returns no block
nonblocking IPC buffer allocation fails
cache growth skipped
driver request deferred
```

Λ means:

```text id="pc02ml"
expected allocation event did not materialize
```

The caller may retry, block, degrade, or return a no-resource status.

### 11.17 Invalid Pointer and Safety Faults

Invalid memory operations are Φ events.

Examples:

```text id="jzalfu"
free unknown pointer
double free
use-after-free detected
write outside BlockFrame
access quarantined block
foreign-frame free
free kernel memory from user path
```

Fault path:

```text id="tvwkx9"
Δ classify violation
Φ enter memory-safety handler
Ψ choose response
Σ audit if enabled
```

Possible responses:

```text id="gdr29n"
return error
kill process
quarantine allocation domain
disable driver
rollback transaction
halt under critical policy
```

These are OS-level safety responses.

They do not constitute external security validation.

### 11.18 Quarantine of Memory Objects

A block, heap, or allocation domain may be quarantined.

```text id="p1cj9q"
Χ_quarantine(BlockFrame)
```

Quarantine effects:

```text id="sc0abo"
remove from ordinary free list
deny future allocation
preserve metadata for audit
block cross-domain visibility
trigger delayed reclamation
```

Quarantine is useful for:

* suspected memory corruption;
* driver misuse;
* use-after-free detection;
* policy investigation;
* delayed free to catch stale references.

This remains an OS-level isolation mechanism, not a forensic verdict.

Quarantine escalation is kernel-internal recontextualization and protection-state management.

It is not governance authority.

### 11.19 Concurrency Safety

Allocator concurrency is governed by Θ, Ω, Χ, Σ, and Ψ.

Concurrent allocation must define:

```text id="uv04uu"
lock ordering
atomic update points
per-thread caches
per-domain heaps
shared heap access
commit visibility
```

A concurrent allocation fast path:

```text id="xz5ktq"
Δ classify size
Ω verify local allocation authority
∇ update thread-local allocator state
Σ commit local allocation
```

A shared allocator path:

```text id="hzlerp"
Ω acquire allocator capability/lock
Δ inspect free structure
∇ mutate free structure
Σ commit
Ω release
```

Policies may enforce:

```text id="mhf6gk"
ABA prevention
bounded lock hold time
priority inheritance
no allocation in interrupt top-half context
no sleep in non-sleepable allocation path
```

No allocator fast path may bypass Ω, Χ, Ψ, or required `RAcc` quota checks.

### 11.20 Allocation in Interrupt and Driver Contexts

Some contexts restrict allocation.

Interrupt top-half context:

```text id="pjrzqo"
may not block
may not perform unbounded allocation
may use preallocated pool only
```

Driver bottom-half or workqueue context:

```text id="i2gty0"
may allocate if policy permits
charged to DriverRAcc or DeviceRAcc
subject to τ budget and memory limit
```

Kernel policy:

```text id="m9f1f9"
Ψ_no_unbounded_alloc_in_irq
Ψ_driver_mem_limit
Ψ_dma_region_bound
```

Violations produce Φ or driver quarantine depending on severity.

`τ` denotes time/accounting metadata, not a PMS Base operator.

Θ orders when τ-derived budget data is sampled, compared, or used.

### 11.21 DMA and Device Allocation

DMA allocations require explicit frames.

```text id="uu944u"
DMARegionFrame = (base, size, owner, device, perms, policy, RAcc_ref, meta)
```

DMA allocation flow:

```text id="x5zg5b"
Δ identify device and size
Ω verify DMA capability
Ψ check driver/device policy
□ create DMARegionFrame
Χ bind device reachability only to that frame
Σ commit allocation and accounting
```

DMA invariants:

```text id="d146t3"
device cannot write outside DMARegionFrame
DMA region belongs to authorized driver/device
user process cannot forge DMA mapping
DMA allocation charged to DriverRAcc or DeviceRAcc
```

This is an OS-level DMA allocation model.

It does not claim physical device-bus behavior or fabricated hardware substrate.

### 11.22 Reclamation Ordering

Reclamation may be ordered by policy.

Examples:

```text id="z25bde"
reclaim caches before process heaps
reclaim noncritical driver buffers before kernel emergency reserve
reclaim inactive pages before active pages
reclaim container memory before system memory
```

Reclamation order is Θ-governed:

```text id="r66ko3"
Θ_reclaim_select(ResourceSet) → ReclaimCandidate
```

Policy selects admissible candidates:

```text id="u213fd"
Ψ_reclaim(candidate) = true
```

Then:

```text id="fp0t5d"
∇ reclaim candidate
Σ commit reclamation
Σ commit RAcc update
```

### 11.23 Allocation and Resource Accounting

Every successful allocation updates accounting.

```text id="o6ls75"
Δ classify memory event
Ω verify account authority
Ψ quota precheck
∇ update memory counters
Σ commit RAcc
Ψ post-check
```

Every reclamation updates accounting:

```text id="waoa7i"
Δ classify free/reclaim event
∇ decrement usage
Σ commit RAcc
```

Accounting attribution must be explicit for:

```text id="q16k7x"
shared objects
kernel pools
driver buffers
DMA frames
IPC buffers
cache pages
file-backed pages
runtime heaps
```

Correct notation:

```text id="bri2y7"
RAcc.mem.used
RAcc.mem.max
ProcessRAcc
ContainerRAcc
DriverRAcc
DeviceRAcc
```

Incorrect notation:

```text id="sqw0by"
RF.mem.used
ProcessRF
ContainerRF
DriverRF
DeviceRF
```

This links Section 11 back to Section 9.

### 11.24 Allocation and Syscalls

Allocation and reclamation often occur through syscall paths.

Examples:

```text id="rvcvtm"
mmap
munmap
brk
clone
execve
sendmsg
recvmsg
open
driver buffer allocation
DMA region setup
```

Allocation-affecting syscalls follow the canonical PMS-OS syscall contract:

```text id="j46440"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded for allocation:

```text id="b7bupv"
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, namespace, endpoint, or allocation-domain boundary
→ Δ classify allocation request
→ Ψ policy and quota precheck
→ allocation / mapping / reclamation operation
→ Σ commit allocation, mapping, reclamation, and RAcc update where required
→ Ψ postcheck
→ Φ return
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

### 11.25 Allocation Trace and Audit

Allocation and reclamation may produce trace and audit records.

Examples:

```text id="ywmt9b"
heap allocation
free
double-free fault
foreign-frame free
heap expansion
slab allocation
GC cycle
OOM event
DMA allocation
driver pool allocation
quarantine
reclamation
RAcc update
```

An allocation audit record may be:

```text id="fw5gdi"
AllocationAuditRecord = (
    event_id,
    actor,
    role,
    frame,
    allocation_domain,
    resource_account,
    size,
    class,
    decision,
    commit_result,
    fault_result,
    timestamp_or_order,
    metadata
)
```

Audit flow:

```text id="ab95eg"
Δ prepare audit record
Σ commit audit record
Ψ enforce retention / integrity policy
```

Trace emission is an implementation/artifact choice.

Operator-labeled representability is the architecture invariant.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 11.26 Allocation Invariants

PMS-OS maintains the following allocation and reclamation invariants.

```text id="gj552k"
I1: every allocation belongs to a valid allocation domain

I2: every allocation request is Δ-classified before mutation

I3: allocation authority is Ω-checked

I4: quota and memory policy are Ψ-checked before commit

I5: allocated memory lies inside a valid frame

I6: returned pointers are valid only after Σ commit

I7: free validates pointer and ownership before mutation

I8: double free and foreign free produce Φ or Ψ response

I9: reclaimed memory is not visible as live memory

I10: shared objects have explicit reference/lifetime rules

I11: GC traversal respects frame and boundary constraints

I12: OOM behavior is policy-defined

I13: interrupt-context allocation obeys bounded allocation policy

I14: DMA allocation is bounded by explicit frames

I15: accounting is updated through RAcc for allocation and reclamation

I16: no allocator fast path bypasses Ω, Χ, Ψ, or required RAcc constraints

I17: RAcc / ResourceAccount is the resource-accounting notation

I18: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I19: X_alloc, X_p, X_user, X_global, and related X_* symbols are OS-level
     isolation-domain values, not PMS Base Χ

I20: PMS Base Χ = Distance

I21: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, device boundary, IPC visibility, filesystem view,
     sandbox/container boundary, DMA boundary, and reachability control

I22: τ denotes time/accounting metadata, not a PMS Base operator

I23: allocation traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile
```

### 11.27 Boundary to Runtime and Language Layers

This section defines OS-level allocation and reclamation.

It does not fully define:

* language-level ownership;
* PMSL allocation syntax;
* compiler escape analysis;
* runtime-specific garbage collectors;
* borrow checking or affine typing;
* application-level memory APIs.

Those belong in `05_pmsl_pms_ir.md`.

This section defines the kernel substrate on which those layers may rely.

Runtime-security hardening of allocator behavior belongs to `06_runtime_security.md` when it concerns adversarial hardening, exploit-class modeling, audit/evidence hardening, or deployment-facing security profiles.

### 11.28 Architectural Consequence

PMS-OS allocation and reclamation are frame lifecycle operations.

The consequence is:

```text id="kmjfar"
Allocation creates or activates bounded frame regions under authority,
policy, isolation, accounting, and commit constraints; reclamation closes
or returns those regions through checked, committed lifecycle transitions.
```

This gives PMS-OS a unified memory-management model for heaps, kernel pools, slab allocators, reference counting, garbage collection, memory pressure, OOM handling, DMA regions, and reclaim policy.

### 11.29 Boundary Statement

The correct boundary for this chapter is:

```text id="xwlf02"
The PMS-OS allocation and reclamation model specifies OS-level allocation
domains, heap frames, allocation requests, free/reclamation semantics, heap
expansion, pools, slabs, kernel pools, reference counting, garbage
collection profiles, memory pressure, OOM handling, DMA allocation,
concurrency safety, resource-accounting integration, syscall interaction,
and audit representability through Δ–Ψ operator structure.

This is an OS-level allocation and reclamation architecture claim.

It does not claim a completed production allocator, production memory
manager, production garbage collector, physical memory-controller behavior,
physical device-bus behavior, fabricated hardware substrate, external
security validation, runtime-language ownership semantics, or PMS Base
validation.
```

---

## 12. Filesystem Architecture

PMS-OS defines the filesystem as a frame-structured storage subsystem.

A filesystem is not treated as a collection of opaque paths and byte streams. In PMS-OS, files, directories, handles, mounts, namespaces, transactions, journals, quotas, permissions, recovery paths, and audit records are represented as operator-bearing frames governed by Δ, ∇, □, Ω, Χ, Θ, Λ, Φ, Σ, Α, and Ψ.

The central filesystem claim is:

```text id="e7jbch"
PMS-OS treats the filesystem as a □-structured namespace and persistence
system whose operations are Δ-classified, Ω-authorized, Χ-bounded,
RAcc-governed, Σ-committed, Φ-recoverable, and Ψ-constrained.
```

Claim type:

```text id="rpzk4b"
OS-level filesystem architecture claim
```

Boundary:

```text id="qod4mv"
This section defines the OS-level filesystem architecture.

It does not claim a completed production filesystem.

It does not claim block-device implementation, production storage driver
implementation, physical storage-controller behavior, fabricated hardware
substrate, external security validation, or PMS Base validation.
```

Block devices and storage drivers are defined in Section 13.

Cache and buffer management are defined in Section 14.

Device and driver lifecycle is defined in Section 16.

A concrete PMS-OS filesystem execution produces:

```text id="dtlioe"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="zv1hi8"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible filesystem executions is:

```text id="rgf5kr"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="ixdwva"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text id="s9mtzi"
RAcc = ResourceAccount
```

`RF` must not be used for filesystem resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

### 12.1 Filesystem as Frame Tree

The PMS filesystem is a frame tree or frame DAG.

```text id="f2oqm0"
FSRoot (□)
 ├── DirFrame("/etc")
 │    ├── FileFrame("config")
 │    └── FileFrame("policy")
 ├── DirFrame("/usr")
 └── DirFrame("/var")
      └── DirFrame("log")
```

Each filesystem object is a frame.

```text id="lmqvol"
FileFrame = (id, name, type, perms, owner, data, RAcc_ref, meta)
DirFrame  = (id, name, perms, owner, entries, RAcc_ref, meta)
```

where:

| Field      | Meaning                                                              |
| ---------- | -------------------------------------------------------------------- |
| `id`       | stable filesystem object identifier                                  |
| `name`     | local directory name                                                 |
| `type`     | file, directory, symlink, mount, device, pipe, socket, special       |
| `perms`    | Ω-governed permission set                                            |
| `owner`    | owning role, user, process, service, container, or kernel subsystem  |
| `data`     | file content, directory entries, or object-specific payload          |
| `entries`  | mapping from name to `FrameId` for directories                       |
| `RAcc_ref` | resource-accounting reference where storage/accounting applies       |
| `meta`     | τ metadata, policy hooks, journaling state, cache state, quota state |

The filesystem root is a frame.

Every subtree is a frame.

Every handle is a frame.

Every mount is a frame recontextualization.

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived metadata is sampled, compared, committed, or used.

### 12.2 Filesystem Object Types

PMS-OS may define the following filesystem frame types:

```text id="svzg87"
FSRootFrame
DirFrame
FileFrame
SymlinkFrame
HandleFrame
MountFrame
NamespaceFrame
JournalFrame
TransactionFrame
DeviceNodeFrame
PipeFrame
SocketFrame
CacheFrame
QuotaFrame
```

Each type provides a specific interpretation of the same underlying concept:

```text id="g4qrtp"
filesystem object = □ frame + Ω permissions + Χ visibility + RAcc accounting
                    + Ψ policy + Σ commit semantics
```

Frame type determines:

```text id="ad3sg2"
valid operations
resolution rules
permission model
commit behavior
recovery behavior
policy hooks
resource-accounting behavior
```

### 12.3 Directory Semantics

A directory is a distinction frame.

```text id="nj6lr3"
DirFrame = (id, name, perms, owner, entries, RAcc_ref, meta)
```

where:

```text id="jj6xbh"
entries : Name → FrameId
```

Directory lookup is Δ.

```text id="pn7rrh"
DirFrame --Δ(name)--> FrameId or Λ_missing
```

Lookup flow:

```text id="xo1hj6"
Δ classify name
Ω verify search/execute permission on directory
Χ verify namespace visibility
Ψ check filesystem policy
return entry or Λ/Φ
```

If the entry exists:

```text id="e7mzk7"
Δ(name) = FrameId
```

If the entry does not exist:

```text id="fnc4h3"
Λ_missing
```

If the absence is exceptional under the operation:

```text id="dk6nzh"
Φ not-found path
```

Directory lookup does not mutate persistent state unless policy requires audit, access-time update, or accounting-visible metadata update.

### 12.4 Path Resolution

A path is a sequence of directory distinctions.

```text id="ol7m98"
path = /a/b/c
```

Resolution:

```text id="zbwzhx"
Δ(root, "a")
→ Δ(DirFrame("a"), "b")
→ Δ(DirFrame("b"), "c")
```

At each step:

```text id="j7uu0h"
Ω search permission
Χ namespace boundary
Ψ policy constraint
```

Path resolution may encounter:

```text id="p8lo6p"
symlink
mount point
namespace boundary
permission boundary
missing component
cycle
stale handle
```

These are not ad hoc exceptions. They are operator-typed cases:

| Case               | Operator reading                   |
| ------------------ | ---------------------------------- |
| missing component  | Λ or Φ                             |
| symlink            | Φ recontextualization or Α pattern |
| mount point        | Φ + □                              |
| namespace boundary | Χ + Ψ                              |
| permission denial  | Ω / Ψ                              |
| cycle              | Δ / Ψ violation                    |
| stale handle       | Φ                                  |

Path resolution is always relative to an OS-level namespace/domain value.

Such values are not PMS Base Χ itself.

They are concrete PMS-OS projection domains through which PMS Base Χ = Distance appears as namespace visibility, filesystem view, and reachability control.

### 12.5 File Handles

Opening a file creates a handle frame.

```text id="jotpa4"
HandleFrame = (
    id,
    file_id,
    mode,
    offset,
    perms,
    owner,
    isolation,
    policy,
    RAcc_ref,
    meta
)
```

A process open-file table is a frame-indexed set of handle frames.

```text id="td8zqu"
OpenFileTable(p) = { fd_i → HandleFrame_i }
```

Open flow:

```text id="ovm5vw"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel and namespace boundary
→ Δ resolve path
→ Ω check requested mode
→ Ψ check filesystem policy
→ □ create HandleFrame
→ Σ commit handle into process table
→ Σ commit RAcc update where required
→ Ψ postcheck
→ Φ return fd
```

Compact form:

```text id="cb0apz"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; □ ; Σ? ; Ψ ; Φ
```

A handle permits future operations without repeating full path resolution, but Ψ may still enforce per-operation checks.

Handle validity:

```text id="jmxaj2"
file exists
∧ handle belongs to process or shared scope
∧ mode permits operation
∧ role/capability permits operation
∧ namespace boundary still permits access
∧ policy permits continued use
∧ RAcc state is coherent where accounting applies
```

### 12.6 Permissions and Roles

Filesystem permissions are Ω-governed.

A permission is a capability relation:

```text id="r0wa63"
Ω(role, action, FileFrame)
```

Typical filesystem capabilities:

```text id="d9q966"
read
write
execute
search
create
delete
rename
append
truncate
mount
unmount
sync
change_permission
change_owner
```

Permission check:

```text id="z1kxzd"
fs_access_ok(actor, action, object) iff
    Ω(role(actor), action, object)
    ∧ Χ permits namespace visibility
    ∧ Ψ permits action
```

Examples:

```text id="epap8f"
Ω(USER, read, own_file) = allowed
Ω(USER, write, system_policy_file) = denied
Ω(KERNEL, mount, MountFrame) = allowed
Ω(CONTAINER_ADMIN, mount, host_root) = denied unless policy permits
```

Ψ may impose constraints beyond Ω:

```text id="otyxhz"
append-only file
immutable file
read-only mount
no world-writable directory
no execute from writable directory
container cannot cross root namespace
```

### 12.7 File Read Semantics

A read is primarily Δ/Θ/∇-structured, with no required persistent commit on the data path.

Read flow:

```text id="c4f9pd"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, handle, and namespace boundary
→ Δ validate fd / HandleFrame
→ Ω check read permission
→ Ψ check read policy
→ Δ classify offset and length
→ ∇ copy bytes from file/cache/device into user buffer
→ Θ advance offset if sequential handle
→ Σ commit RAcc or audit update where required
→ Ψ postcheck
→ Φ return result
```

Canonical word:

```text id="ue7jof"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Δ ; ∇ ; Θ? ; Σ? ; Ψ ; Φ
```

Read may produce Λ when:

```text id="opvr20"
data not available
nonblocking pipe empty
device silent
network-backed storage unavailable
```

Read may produce Φ when:

```text id="ypzvdi"
handle invalid
permission denied
buffer invalid
storage error
policy violation
```

### 12.8 File Write Semantics

A write is primarily ∇/Σ-structured.

Write flow:

```text id="tx1p9b"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, handle, and namespace boundary
→ Δ validate fd / HandleFrame
→ Ω check write permission
→ Ψ check write policy and quota
→ Δ classify offset, size, and target blocks
→ ∇ modify file cache, page cache, or storage buffer
→ Σ commit or stage write according to consistency mode
→ Σ commit RAcc update where required
→ Ψ post-check filesystem invariants
→ Φ return result
```

Canonical word:

```text id="tjy8nn"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; ∇ ; Σ? ; Ψ ; Φ
```

Write commit modes include:

```text id="wddg5d"
write-through
write-back
journaled
transactional
deferred
log-structured
```

A write may complete before durable storage commit if the filesystem policy permits deferred Σ.

In that case, the staged state and pending commit must be explicit.

### 12.9 Create, Remove, Rename

Filesystem structural mutations are ∇ + Σ operations over directory frames.

#### Create

```text id="jbcbs5"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate namespace boundary
→ Δ resolve parent directory
→ Δ verify name absent
→ Ω check create permission
→ Ψ check directory and quota policy
→ □ create FileFrame or DirFrame
→ ∇ add entry to parent DirFrame
→ Σ commit directory update
→ Σ commit RAcc update where required
→ Ψ postcheck
→ Φ return
```

#### Remove

```text id="fqavqt"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate namespace boundary
→ Δ resolve object
→ Ω check delete permission
→ Ψ check removal constraints
→ ∇ unlink directory entry
→ Σ commit namespace update
→ Σ commit RAcc update where required
→ Σ or later reclamation of underlying storage
→ Ψ postcheck
→ Φ return
```

A removed file may remain live while handles exist.

```text id="ebewc2"
unlink namespace relation ≠ immediate data reclamation
```

#### Rename

Rename is a multi-frame transaction.

```text id="wmwjoh"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate source/target namespace boundaries
→ Δ resolve source and target
→ Ω check permissions on both directories
→ Ψ check cross-directory and namespace policy
→ ∇ remove source entry
→ ∇ create target entry
→ Σ commit atomically
→ Ψ postcheck
→ Φ return
```

Rename must not produce a transient globally visible inconsistent namespace.

### 12.10 Directories and Structural Invariants

Directories must preserve structure.

Core directory invariants:

```text id="o372qj"
I1: each directory entry maps to a valid FrameId

I2: names are unique inside a directory frame

I3: directory cycles are forbidden unless explicitly modeled

I4: remove of non-empty directory is policy-governed

I5: hardlink behavior is explicit

I6: mount and namespace boundaries are explicit

I7: directory mutations are Σ-committed

I8: directory updates that affect quota-visible state update RAcc where required
```

Policy may define:

```text id="b8jxjh"
case sensitivity
maximum name length
maximum directory size
allowed object types
immutable subtrees
append-only directories
```

### 12.11 Mounts and Namespaces

A mount is a frame recontextualization.

```text id="b4plyg"
MountFrame = (
    id,
    mount_point,
    source_frame,
    target_view,
    perms,
    owner,
    policy,
    RAcc_ref,
    meta
)
```

Mounting performs:

```text id="laeotq"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel and namespace boundary
→ Δ identify mount point and source
→ Ω verify mount authority
→ Ψ check mount policy
→ Φ rebind directory-frame pointer
→ Χ establish namespace boundary
→ Σ commit mount table update
→ Ψ postcheck
→ Φ return
```

Canonical word:

```text id="jxlrpr"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; Φ ; Χ ; Σ? ; Ψ ; Φ
```

Mounts support:

```text id="r49to5"
process namespaces
container roots
read-only views
overlay filesystems
per-role views
temporary filesystems
device-backed filesystems
network-backed filesystems
```

A mount may not silently cross isolation domains.

### 12.12 Filesystem Namespaces

A filesystem namespace is a frame view.

```text id="qs8pb8"
NamespaceFrame = (id, root, entries, owner, perms, policy, RAcc_ref, meta)
```

A process sees paths through its active namespace frame.

```text id="x3czc9"
resolve(path, NamespaceFrame(p))
```

Namespace isolation requires:

```text id="ne8mxw"
process p sees object o
iff o is reachable from NamespaceFrame(p)
∧ Ω permits access
∧ Χ permits visibility
∧ Ψ permits resolution
```

Namespace transitions require kernel mediation:

```text id="ldy0yb"
chroot-like transition
container entry
mount namespace switch
sandbox filesystem view
```

all follow the OS syscall contract:

```text id="z0tbip"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (□ | Χ | Φ) ; Σ? ; Ψ ; Φ
```

`X_p`, `X_user`, `X_global`, and namespace-domain symbols are OS-level isolation-domain values.

They are not PMS Base Χ.

PMS Base Χ = Distance; PMS-OS projects Χ as namespace separation, filesystem view, process isolation, and reachability control.

### 12.13 Symlinks and Recontextualized Resolution

A symlink is a frame whose payload redirects path interpretation.

```text id="d3nubc"
SymlinkFrame = (id, target_path, perms, owner, policy, meta)
```

Following a symlink is a Φ-like recontextualization of resolution state.

```text id="q9r1s3"
Δ identify symlink
Ψ check follow policy
Φ reframe path resolution to target
```

Policy may deny symlink traversal when:

```text id="ysptu6"
crossing namespace
crossing mount boundary
escaping sandbox root
following untrusted link
creating cycle
```

Symlink traversal is not an untyped string substitution.

It is an operator-typed resolution transition.

### 12.14 File-Backed Memory Mappings

A file may be mapped into memory.

```text id="ddlg67"
MappedFileFrame = (FileFrame, offset, length, perms, cache_state, policy, RAcc_ref)
```

Mapping flow:

```text id="nvf70i"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, filesystem, and address-space boundary
→ Δ resolve file
→ Ω check read/write/execute and map permission
→ Ψ check filesystem and VM policy
→ □ create mapped file frame
→ Χ attach to process address space
→ Σ commit mapping
→ Σ commit RAcc update where required
→ Ψ postcheck
→ Φ return
```

Write behavior may be:

```text id="tbgwlj"
private COW
shared write-back
write-through
journaled
deferred
```

This links filesystem state to Section 10 virtual memory and Section 14 cache/buffer management.

### 12.15 Journaling

PMS-OS treats journaling as a Σ-centric filesystem discipline.

A journal entry is:

```text id="dm6vgs"
JournalEntryFrame = (
    id,
    op_seq,
    affected_frames,
    state,
    τ_timestamp_or_order,
    policy,
    RAcc_ref,
    meta
)
```

Journal states may include:

```text id="fqbqqu"
STAGED
JOURNALED
APPLIED
COMMITTED
ABORTED
RECOVERED
```

Write-ahead logging flow:

```text id="r1v5yu"
Α expand operation into canonical sequence
Σ commit journal intent
Θ order journal entries
∇ apply filesystem updates
Σ commit final filesystem state
Σ commit RAcc update where required
Φ recover or rollback if failure occurs
```

Canonical transaction pattern:

```text id="a6j5li"
begin_tx:
    Α open transactional frame

mutate:
    ∇ modify buffers / directory entries / metadata

commit:
    Σ journal
    Σ apply changes
    Σ finalize
    Σ commit accounting update where required

abort:
    Φ rollback
    Σ commit rollback state
```

Journaling makes persistent state transitions explicit and recoverable.

This is an OS-level filesystem discipline.

It does not claim physical storage-controller behavior.

### 12.16 Filesystem Transactions

A filesystem transaction is:

```text id="rkjc3d"
FSTransaction = (id, op_seq, staged_state, affected_frames, policy, RAcc_delta, status)
```

Transaction validity:

```text id="qzgkk7"
all affected frames exist
∧ all permissions hold
∧ all quotas hold
∧ no isolation boundary is crossed illegally
∧ journal policy permits transaction
```

Commit:

```text id="gj76bd"
Σ_tx_commit
```

Rollback:

```text id="irg9dq"
Φ_recover
→ Σ_rollback
```

A transaction must not expose partially committed filesystem structure unless the selected filesystem policy explicitly permits staged visibility.

### 12.17 Crash Recovery

Crash recovery is Φ + Σ + Θ over journal state.

Recovery flow:

```text id="qifb44"
Θ order journal entries by committed order / τ metadata
Δ classify completed vs incomplete transactions
Φ recontextualize filesystem state
Σ apply valid committed updates
Σ rollback incomplete updates
Σ repair or correct RAcc state where required
Ψ validate filesystem invariants
```

Recovery may produce:

```text id="nmvp67"
clean filesystem state
repaired state
read-only recovery mode
quarantine of damaged subtree
halt if root invariants fail
```

Crash recovery is not external to PMS-OS.

It is part of the filesystem’s Φ recovery semantics.

### 12.18 Quotas and Filesystem Limits

Filesystem quotas are Ψ rules over Σ-committed storage accounting.

Quota scopes may include:

```text id="kxtgvo"
user
role
process
container
directory subtree
filesystem
device
project
```

Quota fields may include:

```text id="gs3izj"
RAcc.storage.blocks_used
RAcc.storage.blocks_max
RAcc.storage.inodes_used
RAcc.storage.inodes_max
RAcc.storage.bytes_written
RAcc.storage.journal_bytes
RAcc.storage.snapshots
RAcc.storage.pending_writes
```

Allocation flow with quota:

```text id="ehcgb0"
Δ resolve file/block/inode
Ω verify allocation permission
Ψ check quota
∇ allocate storage
Σ commit storage/accounting update
Ψ post-check filesystem consistency
```

Quota violation may produce:

```text id="gvb60b"
Λ no-space outcome
Φ transaction rollback
Ψ denial
Σ audit record
```

Correct notation:

```text id="c2jfpo"
RAcc.storage.blocks_used
RAcc.storage.blocks_max
```

Incorrect notation:

```text id="pvwfnv"
RF.storage.blocks_used
RF.storage.blocks_max
```

### 12.19 Filesystem Consistency Policies

Ψ defines filesystem consistency mode.

Examples:

```text id="erkftk"
Ψ_strong
Ψ_journaled
Ψ_eventual
Ψ_append_only
Ψ_read_only
Ψ_transactional
Ψ_container_isolated
```

A consistency policy defines:

```text id="zd8ifm"
when Σ must occur
which updates may be deferred
which ordering Θ must preserve
what recovery Φ must do
which invariants must hold after crash
which RAcc updates must be committed with filesystem state
```

Example strong policy:

```text id="oey6ey"
data and metadata visible only after Σ commit
no directory mutation visible before journal intent
no cross-namespace object exposure
accounting state coherent with committed filesystem state
```

Example eventual policy:

```text id="x0w7tl"
Σ may be deferred
Θ may batch independent writes
Ψ requires eventual flush before lifecycle closure
RAcc may track staged and committed usage separately
```

### 12.20 Filesystem and IPC/Events

Some filesystem objects are communication objects:

```text id="r5tv4r"
PipeFrame
SocketFrame
EventFrame
MessageFrame
```

These objects participate in filesystem namespaces but use IPC/event semantics for data behavior.

A named pipe, for example, is:

```text id="uyycbn"
filesystem path → FrameId
FrameId → IPC queue semantics
```

This allows PMS-OS to expose IPC endpoints through filesystem frames without conflating filesystem lookup with message delivery.

IPC-backed filesystem objects may affect:

```text id="bgcspo"
RAcc.ipc
RAcc.storage
RAcc.mem
```

depending on declared profile.

### 12.21 Filesystem and Devices

Device nodes are filesystem-visible references to device frames.

```text id="edn4yg"
DeviceNodeFrame = (path, DeviceFrame, perms, owner, policy, RAcc_ref)
```

Opening a device node requires:

```text id="du2pbu"
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel and device namespace boundary
→ Δ resolve device node
→ Ω verify device access capability
→ Ψ check driver/device policy
→ □ create HandleFrame
→ Σ commit open
→ Σ commit RAcc update where required
→ Ψ postcheck
→ Φ return
```

The actual device behavior belongs to Section 13 and Section 16.

This section defines filesystem visibility of devices.

It does not define production driver implementation or fabricated device hardware.

### 12.22 Filesystem Audit and Trace

Filesystem operations may emit audit records.

```text id="ott5ey"
FSAuditRecord = (
    event_id,
    actor,
    role,
    namespace,
    operation,
    path_or_frame,
    operator_class,
    decision,
    commit_result,
    resource_accounting_result,
    timestamp_or_order,
    metadata
)
```

Audit flow:

```text id="x4xe3c"
Δ prepare record
Σ commit audit record
Ψ enforce retention and integrity
```

Events worth auditing may include:

```text id="k8up5i"
permission denial
policy denial
mount/unmount
namespace crossing
journal commit
transaction rollback
quota violation
device node access
policy file mutation
root namespace change
```

A concrete filesystem trace is:

```text id="l4974j"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="b2tqaa"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The declared filesystem execution space is:

```text id="ak4g0q"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="f17sdd"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Trace emission is implementation-specific.

Operator-labeled representability is the architecture invariant.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 12.23 Filesystem Invariants

PMS-OS maintains the following filesystem invariants.

```text id="jmtv49"
I1: every filesystem object is represented as a valid frame

I2: every directory entry maps to a valid frame or defined absent state

I3: path resolution is Δ-structured and namespace-bound

I4: file handles are frame objects with explicit ownership and permissions

I5: mutating operations require Ω authority and Ψ permission

I6: namespace and mount crossings are Χ/Ψ-governed

I7: persistent mutations are Σ-committed or explicitly staged

I8: journaled operations preserve recovery paths

I9: incomplete transactions are Φ-recoverable

I10: quotas are checked before storage allocation commit

I11: filesystem mappings into memory are VM-policy-compatible

I12: device nodes do not bypass driver/device policy

I13: cache-visible filesystem state is consistent with Section 14 policy

I14: audit records, when enabled, are Σ-committed

I15: no filesystem fast path bypasses Ω, Χ, or Ψ constraints

I16: filesystem resource accounting uses RAcc / ResourceAccount notation

I17: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I18: filesystem namespace values, X_p, X_user, X_global, and related X_*
     symbols are OS-level isolation-domain values, not PMS Base Χ

I19: PMS Base Χ = Distance

I20: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, filesystem view, device boundary, IPC visibility,
     sandbox/container boundary, and reachability control

I21: τ denotes time/accounting metadata, not a PMS Base operator

I22: filesystem traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile
```

### 12.24 Boundary to Storage and Cache Layers

This section defines the filesystem namespace, object, handle, transaction, journaling, quota, audit, and policy model.

It does not fully define:

* block-device request scheduling;
* physical or virtual block geometry;
* driver lifecycle;
* device hotplug;
* buffer cache eviction;
* page cache coherency;
* write-back policy implementation;
* physical storage-controller behavior;
* fabricated storage hardware.

Those are defined or refined in:

```text id="cqju78"
13. Block Devices and Storage Drivers
14. Cache and Buffer Management
16. Device and Driver Lifecycle
```

This section also does not define distributed filesystem semantics.

Cross-node storage, remote consistency, cluster replication, distributed delivery guarantees, and distributed policy synchronization belong to `07_distributed_systems.md`.

### 12.25 Architectural Consequence

PMS-OS filesystems are operator-typed persistence structures.

The consequence is:

```text id="xjgd17"
A PMS-OS filesystem is a frame tree whose names, handles, mounts,
permissions, mappings, transactions, journals, quotas, recovery paths, and
audit records are governed by Δ distinction, Ω authority, Χ boundary
control, RAcc accounting, Σ commit, Φ recovery, and Ψ invariants.
```

This gives PMS-OS a unified storage namespace model compatible with virtual memory, syscalls, IPC, devices, drivers, cache management, resource accounting, and policy enforcement.

### 12.26 Boundary Statement

The correct boundary for this chapter is:

```text id="hnn79b"
The PMS-OS filesystem architecture specifies OS-level filesystem frames,
directory semantics, path resolution, handles, permissions, reads, writes,
create/remove/rename operations, mounts, namespaces, symlinks, file-backed
mappings, journaling, transactions, crash recovery, quotas, filesystem IPC
objects, device nodes, and audit representability through Δ–Ψ operator
structure.

This is an OS-level filesystem architecture claim.

It does not claim a completed production filesystem, block-device
implementation, production storage driver implementation, physical
storage-controller behavior, fabricated hardware substrate, external
security validation, distributed filesystem semantics, or PMS Base
validation.
```

---

## 13. Block Devices and Storage Drivers

PMS-OS defines block devices and storage drivers as frame-bound, role-governed I/O subsystems.

A block device is not treated as an opaque hardware endpoint. It is represented as a `DeviceFrame` whose block geometry, permissions, queues, caches, driver operations, isolation boundaries, commit behavior, resource-accounting state, and failure paths are typed by PMS operators.

The central block-device claim is:

```text id="l2vwd4"
PMS-OS treats block storage as a stack of □ device frames and driver
frames whose I/O requests are Δ-classified, Ω-authorized, Θ-dispatched,
∇-executed, RAcc-accounted, Σ-committed, Φ-recoverable, Χ-bounded, and
Ψ-constrained.
```

Claim type:

```text id="vuy728"
OS-level block-device and storage-driver architecture claim
```

Boundary:

```text id="uuwz9p"
This section defines OS-level block-device and storage-driver architecture.

It does not claim fabricated hardware.

It does not claim physical storage-controller implementation.

It does not claim a completed production storage driver framework.

It does not claim external driver certification or external security
validation.

It does not validate PMS Base.
```

This section defines the OS-level block-device and storage-driver architecture. General driver lifecycle is refined in Section 16.

A concrete PMS-OS block-device execution produces:

```text id="qupsnp"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="ldwxqx"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible block-device executions is:

```text id="szv7tx"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="c8yv24"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text id="d0bsfp"
RAcc = ResourceAccount
```

`RF` must not be used for block-device or driver resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

### 13.1 Block Devices as Frames

Every block device is represented as a device frame.

```text id="zvy4g0"
DeviceFrame = (
    id,
    type,
    blocksize,
    capacity,
    perms,
    owner,
    ops,
    state,
    policy,
    RAcc_ref,
    meta
)
```

where:

| Field       | Meaning                                                    |
| ----------- | ---------------------------------------------------------- |
| `id`        | device identifier                                          |
| `type`      | DISK, SSD, NVMe, RAMDISK, VDEV, LOOP, NET-BLOCK, etc.      |
| `blocksize` | logical block size                                         |
| `capacity`  | number of addressable blocks or bytes                      |
| `perms`     | Ω-governed access permissions                              |
| `owner`     | kernel, driver, VM, container, or subsystem                |
| `ops`       | driver-supported operation table                           |
| `state`     | queues, pending I/O, cache state, health state             |
| `policy`    | device policy constraints                                  |
| `RAcc_ref`  | resource-accounting reference for device use               |
| `meta`      | τ data, interrupt state, error counters, topology metadata |

A block device exposes the OS-level relation:

```text id="savmay"
blocks : BlockIndex → Byte[blocksize]
```

The device frame defines the interpretation of block indices.

This is an OS-level device model.

It does not claim physical disk, SSD, NVMe controller, firmware, bus, DMA engine, or storage-controller implementation.

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived metadata is sampled, compared, committed, or used.

### 13.2 Device Context

Accessing a device means entering its frame context.

```text id="zx983e"
FRM_ENTER DeviceFrame
```

At OS level, this corresponds to:

```text id="l4ru9r"
□ enter device context
Ω verify device capability
Χ enforce device isolation
Ψ enforce device policy
```

Device-frame validity requires:

```text id="bkq9m6"
device exists
∧ driver is bound or valid virtual backend exists
∧ block geometry is coherent
∧ permissions are defined
∧ queues are initialized
∧ policy is active
∧ OS isolation-domain value is coherent
∧ RAcc_ref is coherent where accounting applies
```

A block access outside device geometry is a Δ failure.

```text id="dgatmo"
block_index ≥ capacity ⇒ Φ bounds fault / I/O error
```

### 13.3 Driver Frame

A storage driver is a structured PMS submachine.

```text id="paxpq6"
DriverFrame = (
    id,
    device_id,
    role,
    capabilities,
    ops,
    queues,
    cache,
    state,
    policy,
    DriverRAcc,
    meta
)
```

Driver operations are operator-typed:

```text id="qi6xbl"
ops = {
    Δ_identify,
    Δ_check_bounds,
    Ω_permission_check,
    Θ_dispatch,
    ∇_read_blocks,
    ∇_write_blocks,
    Σ_commit,
    Φ_recover,
    Λ_timeout,
    Ψ_check
}
```

A driver is valid only when:

```text id="a0zly7"
driver role assigned
∧ capability set matches device
∧ device frame bound
∧ policy active
∧ isolation boundaries established
∧ queues and recovery paths defined
∧ DriverRAcc is coherent
```

This section specifies the OS-level storage-driver model.

It does not claim a production driver implementation.

### 13.4 Block I/O Request

A block I/O request is:

```text id="l6zg78"
BlockRequest = (
    id,
    op,
    device,
    block_index,
    block_count,
    buffer,
    flags,
    actor,
    policy,
    RAcc_delta,
    meta
)
```

where:

```text id="ofqevd"
op ∈ {READ, WRITE, FLUSH, DISCARD, BARRIER, IDENTIFY, CONTROL}
```

A request is valid when:

```text id="yy4cif"
device exists
∧ op supported by device/driver
∧ block range inside capacity
∧ buffer frame valid
∧ actor has capability
∧ boundary permits buffer/device relation
∧ policy permits request
∧ resource-accounting impact is permitted where relevant
```

### 13.5 I/O Request Pipeline

The canonical block I/O pipeline is:

```text id="zf65ti"
Δ → Ω → Ψ → Θ → ∇ → Σ → Φ?
```

Expanded:

```text id="x9ppg6"
Δ classify request
Ω verify capability
Ψ check device, driver, quota, and policy constraints
Θ enqueue and order request
∇ execute read/write/control operation
Σ commit completion / durability / RAcc state
Φ recover on error
```

This pipeline applies to:

```text id="omz6e4"
physical-device models
virtual devices
loop devices
RAM disks
encrypted volumes
RAID layers
network-backed block devices
```

The specification models these as OS-level device frames and driver frames.

It does not claim fabricated hardware.

### 13.6 Δ — Request Classification

The driver first distinguishes the request.

```text id="vzcv1d"
Δ(request):
    identify op
    identify device
    extract block_index
    extract block_count
    identify buffer frame
    check alignment
    check logical bounds
    classify RAcc impact
```

Classification failures include:

```text id="gtuxyv"
unknown operation
invalid device
misaligned block range
out-of-bounds block range
invalid buffer
unsupported flags
invalid resource-accounting context
```

Failure response:

```text id="w1ssus"
Δ failure → Φ I/O error or invalid-request return
```

### 13.7 Ω — Permission Check

The driver verifies that the actor has the authority to perform the request.

Capability examples:

```text id="jbpi6c"
Ω(actor, read, DeviceFrame)
Ω(actor, write, DeviceFrame)
Ω(actor, flush, DeviceFrame)
Ω(actor, discard, DeviceFrame)
Ω(actor, admin_control, DeviceFrame)
Ω(driver, dma_map, DMARegionFrame)
```

Permission failure:

```text id="v09huh"
Ω failure → Φ access-denied error
```

Policy may escalate repeated or suspicious failures.

Policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

### 13.8 Ψ — Device and Driver Policy

Device policy may constrain:

```text id="jbt6mz"
read/write permissions
flush requirements
journaling requirements
encryption requirements
driver trust level
device health state
rate limits
hotplug state
power state
quarantine state
filesystem consistency dependencies
RAcc limits
```

A request may be denied even if Ω permits it.

```text id="eercbc"
Ω permits write
∧ Ψ_device says device is read-only
⇒ request denied
```

Policy outcomes include:

```text id="cogmms"
ALLOW
DENY
DEFER
REWRITE
THROTTLE
REQUIRE_FLUSH
REQUIRE_JOURNAL
ISOLATE
FAIL_DEVICE
```

The policy engine constrains OS-level driver behavior.

It does not provide external security validation.

### 13.9 Θ — I/O Scheduling

Block requests are ordered by Θ.

The driver may use scheduling strategies such as:

```text id="m0b7bf"
FIFO
deadline
priority
elevator
C-LOOK
fair queue
per-container queue
per-role queue
real-time queue
```

Scheduler state:

```text id="rt2a90"
IOQueue = (pending, active, completed, policy, RAcc_refs, meta)
```

Dispatch:

```text id="cvw89e"
Θ_select(IOQueue) → BlockRequest
```

I/O scheduling must preserve:

```text id="mxygv2"
dependency order
barrier order
flush order
journal order
fairness policy
deadline policy
isolation-domain quota
resource-accounting policy
```

A request may remain pending if:

```text id="u0ff0u"
device busy
queue full
policy defers it
dependency not satisfied
quota window not yet available
```

This is represented through Θ and Λ.

### 13.10 ∇ — Read and Write Execution

Read execution:

```text id="r7l2bn"
∇_read_blocks(device, block_range, buffer)
```

Semantics:

```text id="plspgq"
device blocks → buffer frame
```

Write execution:

```text id="qxrybx"
∇_write_blocks(device, block_range, buffer)
```

Semantics:

```text id="yh7hxn"
buffer frame → device blocks
```

Execution requires:

```text id="z9xg7x"
buffer frame valid
∧ buffer access authorized
∧ device access authorized
∧ DMA boundary valid if used
∧ request still policy-valid at dispatch time
∧ RAcc impact remains permitted where relevant
```

The ∇ phase may update:

```text id="peb3ph"
driver internal state
request state
cache state
device queue state
error counters
temporary buffers
staged resource-accounting deltas
```

Durability is not guaranteed by ∇ alone.

Durability is governed by Σ.

### 13.11 Σ — Commit and Durability

Σ integrates I/O effects.

For reads, Σ may commit:

```text id="xmn8nq"
completion state
buffer visibility
accounting
wakeups
audit records
```

For writes, Σ may commit:

```text id="idxotn"
device write completion
write ordering
flush completion
journal dependency
request completion
filesystem-visible durability
RAcc update
```

Commit modes:

```text id="acbhsc"
write-through
write-back
flush-required
barrier-enforced
journal-dependent
deferred
transactional
```

A write is durable only when the selected policy’s Σ condition holds.

```text id="j6hdfm"
write executed ≠ write durably committed
```

Examples:

```text id="adr2fq"
Σ_device_flush
Σ_request_complete
Σ_journal_dependency
Σ_barrier_order
Σ_accounting_update
```

Durability here is a declared OS-level storage semantics property.

It does not claim physical device behavior beyond the declared profile.

### 13.12 Barriers and Flushes

Barriers constrain I/O ordering.

```text id="s5pfao"
BARRIER
FLUSH
FUA-like write
```

Barrier semantics:

```text id="ogrri5"
all prior dependent writes must commit before later writes become visible
```

Flush flow:

```text id="g8fogb"
Δ identify flush request
Ω verify flush authority
Ψ check policy
Θ order flush after prior writes
Σ commit device/cache state
Σ commit RAcc update where required
Φ return completion or error
```

Filesystems depend on this for journal and metadata correctness.

Flush and barrier semantics are OS-level ordering and commit claims.

They do not claim physical storage-controller implementation.

### 13.13 DMA and Buffer Boundaries

If DMA is supported, PMS-OS represents DMA memory as explicit frames.

```text id="sn2dpn"
DMARegionFrame = (
    id,
    base,
    size,
    owner,
    device,
    perms,
    policy,
    RAcc_ref,
    meta
)
```

DMA validity:

```text id="zb2yyl"
device has DMA capability
∧ buffer lies inside DMARegionFrame
∧ DMARegionFrame assigned to device/driver
∧ Χ prevents device access outside region
∧ Ψ permits DMA operation
∧ DriverRAcc or DeviceRAcc permits allocation/use
```

DMA mapping flow:

```text id="lko4i9"
Δ identify buffer and device
Ω verify DMA capability
Ψ check driver/device policy
□ create or select DMARegionFrame
Χ bind device reachability to DMARegionFrame
Σ commit DMA mapping
Σ commit DriverRAcc or DeviceRAcc update where required
```

This prevents arbitrary device writes into system memory.

This is an OS-level DMA boundary model.

It does not claim physical DMA engine implementation or fabricated hardware behavior.

### 13.14 Device Isolation

Each device frame has an associated boundary domain.

```text id="cbbar3"
X_device = (device_id, allowed_frames, allowed_ops, restrictions)
```

`X_device` is an OS-level isolation-domain value.

It is not the PMS Base operator `Χ`.

It names the concrete PMS-OS device boundary / reachability domain through which PMS Base Χ = Distance is projected at OS level.

At PMS-OS level, Χ projects PMS Base Distance into device reachability and device isolation.

Device isolation prevents:

```text id="f5ind0"
DMA outside approved regions
driver access to unassigned MMIO
user access to raw device frames
cross-device capability leakage
stale access after hotplug detach
filesystem bypass through device nodes
```

A device may interact only with frames explicitly exposed through Ω, Χ, and Ψ.

### 13.15 Storage Stack Composition

Storage systems compose frames.

```text id="mthtrt"
PhysicalDeviceFrame
    ↓
PartitionFrame
    ↓
VolumeFrame
    ↓
RAIDFrame / EncryptedFrame / CompressionFrame
    ↓
FilesystemRootFrame
```

These names denote OS-level storage-model frames.

They do not claim physical hardware fabrication.

Each layer is a PMS submachine:

```text id="rdkbp4"
Δ classify request
Ω check layer permission
Θ order request
∇ transform or forward request
Σ commit layer effect
Φ recover on failure
Ψ enforce policy
```

Layering is usually expressed through Α patterns.

### 13.16 RAID Pattern

RAID may be represented as an Α pattern over multiple device frames.

Example RAID-1 mirror write:

```text id="g8juof"
PATTERN RAID1_WRITE:
    Δ classify write
    Ω check both devices
    ∇ write block to devA
    ∇ write block to devB
    Σ commit if both writes succeed
    Φ recover if one write fails
```

Read selection:

```text id="h7kw6o"
Θ choose healthy device
∇ read from selected mirror
Σ commit completion
```

Policy may define:

```text id="ixjaz2"
degraded mode
rebuild behavior
quorum of mirrors
failure threshold
read preference
RAcc attribution for rebuild and redundancy work
```

RAID here is an OS-level storage composition pattern.

It does not claim completed RAID implementation or physical device behavior.

### 13.17 Encryption Layer

An encrypted storage layer is a frame transformation.

```text id="exvwry"
EncryptedFrame = (lower_device, key_policy, cipher_meta, state, RAcc_ref)
```

Read:

```text id="h575nn"
Δ classify block
∇ read encrypted block
Ω verify key capability
∇ decrypt block
Σ commit plaintext buffer visibility
Σ commit accounting where required
```

Write:

```text id="zzdbx3"
Δ classify block
Ω verify key/write capability
∇ encrypt block
∇ write encrypted block
Σ commit according to durability policy
Σ commit accounting where required
```

Key access is Ω-governed and Ψ-constrained.

This is an OS-level encrypted-storage architecture claim.

It does not claim implementation of a specific cryptographic library or external cryptographic validation.

### 13.18 Loop and Virtual Block Devices

A loop device maps a file frame into a block-device frame.

```text id="lu4x8b"
LoopDeviceFrame = (BackingFileFrame, blocksize, capacity, policy, RAcc_ref, state)
```

Request translation:

```text id="df7hoq"
BlockRequest(block_i)
→ Δ compute file offset
→ Ω check backing file access
→ ∇ read/write file frame
→ Σ commit via filesystem policy
→ Σ commit RAcc update where required
```

Virtual devices follow the same structure, with a synthetic or remote backing frame.

Distributed or remote block devices are mentioned here only as extension points.

Full distributed semantics belong in `07_distributed_systems.md`.

### 13.19 Interrupt Path for Block Devices

Block devices signal completion or error through interrupts.

Interrupt flow:

```text id="wo6wcb"
Φ interrupt entry
Δ identify device and cause
Ω verify driver interrupt capability
Θ schedule top-half/bottom-half handling
Σ commit completion metadata
Σ commit RAcc update where required
Λ if device becomes idle or expected event absent
Φ return or recover
```

Completion event:

```text id="j4nxkz"
request state := completed
wake waiting threads
commit accounting
notify filesystem/cache layer
```

Error event:

```text id="sifbtq"
Φ error handler
Ψ choose retry, fail, remap, quarantine, or degrade
```

This is an OS-level interrupt and completion model.

It does not define physical interrupt-controller hardware.

### 13.20 Timeouts and Absent Devices

A missing device response is a Λ condition.

```text id="za0x7p"
Λ_device_timeout :=
    τ.now ≥ request.deadline
    ∧ completion_absent
```

Timeout response may include:

```text id="lz2xv1"
Θ retry with backoff
Φ recover request
Ψ mark device degraded
Χ isolate device
Σ commit failure state
Σ commit RAcc/audit update where required
notify waiting process
```

Repeated Λ events may escalate to driver or device quarantine.

`τ` denotes time/accounting metadata.

It is not a PMS Base operator.

Θ orders when τ-derived deadline data is sampled, compared, and acted on.

### 13.21 Error Handling and Recovery

Drivers use Φ for recovery.

Recovery cases include:

```text id="nby3wm"
bad block
timeout
lost device
permission violation
DMA fault
controller reset
write failure
journal dependency failure
hotplug detach
driver crash
```

Recovery flow:

```text id="jojrtn"
Δ classify error
Φ enter recovery context
Ψ choose recovery policy
Θ order retry/backoff if applicable
∇ perform recovery action
Σ commit recovery state
Σ commit RAcc/audit update where required
Φ return or fail request
```

Possible recovery actions:

```text id="yu8c4e"
retry
remap bad block
mark device degraded
fail request
quarantine driver
detach device
switch to mirror
rollback staged write
panic/halt if root device invariant fails
```

Quarantine is an OS-level isolation response.

It is not moral judgment, forensic attribution, or governance authority.

### 13.22 Hotplug Interaction

Storage devices may appear or disappear dynamically.

Attach flow:

```text id="svg5xj"
Φ hotplug event
Δ identify device
Ψ check attach policy
□ create DeviceFrame
Ω assign driver capability
Σ initialize DeviceRAcc where required
Σ commit device registration
```

Detach flow:

```text id="fbp3vn"
Φ detach event
Ψ check pending I/O policy
Θ quiesce queues
Σ commit completed work
Χ isolate stale device frame
□ remove DeviceFrame visibility
Σ commit detach
Σ close or update DeviceRAcc where required
```

A storage device with pending writes may require:

```text id="qyux0v"
flush
rollback
read-only transition
forced detach
quarantine
```

according to policy.

Full lifecycle detail belongs in Section 16.

### 13.23 Driver-State Lifecycle for Storage

A storage driver may maintain lifecycle states:

```text id="e3s9gx"
UNBOUND
BOUND
ACTIVE
SUSPENDED
DEGRADED
QUIESCING
QUARANTINED
UNLOADED
```

Transitions are governed by:

```text id="dmg8di"
Δ identity
Ω capability
Χ isolation
Θ ordering
Φ recontextualization
Σ commit
Ψ policy
RAcc accounting
```

Storage-specific examples:

```text id="vk50fe"
ACTIVE → DEGRADED after repeated bad blocks
ACTIVE → QUIESCING before detach
QUIESCING → SUSPENDED after all I/O drains
DEGRADED → QUARANTINED after policy violation
```

The full PMS-OS device and driver lifecycle is specified in Section 16.

### 13.24 Interaction with Filesystem

The filesystem depends on block devices for persistence.

Filesystem request path:

```text id="igjksv"
File operation
→ filesystem frame mutation
→ cache/buffer stage
→ BlockRequest
→ driver execution
→ storage commit
→ filesystem Σ commit
```

Important separation:

```text id="f1q39x"
filesystem mutation ≠ block-device durability
```

The filesystem’s Σ semantics must coordinate with device-level Σ.

Examples:

```text id="fu3buo"
journal entry must reach device before metadata commit
fsync requires device flush under selected policy
write-back cache may defer block-level Σ
read-only mount may deny writes before BlockRequest is issued
```

Filesystem-level and device-level accounting must also remain coherent:

```text id="s3j2o1"
RAcc.storage.* at filesystem layer
RAcc.devices.* at device/driver layer
```

### 13.25 Interaction with Cache and Buffer Management

Block devices interact with caches through `CacheFrame` and `BufferFrame`.

Typical read:

```text id="eynoqk"
Δ cache lookup
Λ miss if absent
∇ issue block read
Σ commit buffer fill
```

Typical write-back:

```text id="fqpvk5"
∇ modify cache buffer
Θ schedule flush
∇ issue block write
Σ commit device write
Σ mark buffer clean
```

Cache policy is defined in Section 14.

The cache/buffer model is OS-level.

It does not claim physical CPU cache hardware or physical cache-coherence protocols.

### 13.26 Block Device Audit and Trace

Block I/O may emit audit records.

```text id="aaz7bw"
BlockAuditRecord = (
    event_id,
    actor,
    role,
    device,
    driver,
    operation,
    block_range,
    buffer_frame,
    decision,
    commit_result,
    resource_accounting_result,
    error_state,
    timestamp_or_order,
    metadata
)
```

Audit flow:

```text id="bi5wlb"
Δ prepare record
Σ commit audit record
Ψ enforce retention/integrity
```

Events worth auditing include:

```text id="b0e1mj"
raw device access
DMA mapping
write to privileged device
flush failure
bad block remap
driver quarantine
hotplug attach/detach
repeated timeouts
policy-denied device access
resource-accounting violation
```

A concrete block-device trace is:

```text id="nwll0w"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="bfuk6z"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The declared block-device execution space is:

```text id="rikn1k"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="n7xxsn"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Trace emission is implementation-specific.

Operator-labeled representability is the architecture invariant.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 13.27 Block Device Invariants

PMS-OS maintains the following block-device and storage-driver invariants.

```text id="rr713p"
I1: every block device is represented as a valid DeviceFrame

I2: every driver operates through an assigned DriverFrame

I3: every I/O request is Δ-classified before dispatch

I4: every protected I/O operation is Ω-authorized

I5: every request range lies within device capacity

I6: every buffer frame is valid and boundary-permitted

I7: every DMA operation is bounded by a DMARegionFrame

I8: every write durability claim is backed by Σ semantics

I9: barriers and flushes preserve required ordering

I10: driver queues are Θ-ordered under policy

I11: device errors enter Φ recovery paths

I12: repeated absence/timeouts are represented through Λ and policy

I13: hotplug detach invalidates or isolates stale device frames

I14: storage layering preserves frame and policy boundaries

I15: filesystem commits coordinate with device commit semantics

I16: no storage fast path bypasses Ω, Χ, or Ψ constraints

I17: DriverRAcc and DeviceRAcc account driver/device resource use where
     relevant

I18: RAcc / ResourceAccount is the resource-accounting notation

I19: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I20: X_device, X_p, X_user, X_global, and related X_* symbols are OS-level
     isolation-domain values, not PMS Base Χ

I21: PMS Base Χ = Distance

I22: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, device boundary, IPC visibility, filesystem view,
     sandbox/container boundary, DMA boundary, and reachability control

I23: τ denotes time/accounting metadata, not a PMS Base operator

I24: block-device traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile

I25: hardware-like names in this section denote OS-level device models unless
     a later implementation artifact explicitly realizes them
```

### 13.28 Boundary to Device Lifecycle and Distributed Storage

This section defines block devices and storage drivers at OS architecture level.

It does not fully define:

```text id="fl6dum"
general driver lifecycle
all device classes
network devices
GPU devices
USB topology
distributed block replication
cluster quorum
remote durability
cross-node recovery
production driver implementation
external driver certification
physical storage-controller behavior
fabricated storage hardware
```

Those belong in:

```text id="boi2t5"
16. Device and Driver Lifecycle
07_distributed_systems.md
```

Distributed or remote block devices are extension points in this section.

Cross-node messaging, distributed delivery guarantees, cluster events, remote consensus, distributed recovery, distributed block replication, remote durability, and distributed policy synchronization belong to `07_distributed_systems.md`.

### 13.29 Syscall Interaction

Block-device access may be reached through syscalls such as:

```text id="i9lv32"
open
read
write
ioctl
fsync
sync
mmap
mount
unmount
device_control
register_driver
```

Such syscalls follow the canonical PMS-OS syscall contract:

```text id="dvhkmg"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded for block-device access:

```text id="lx36rd"
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, device, namespace, or buffer boundary
→ Δ classify syscall, device, request, and buffer
→ Ψ check policy, quota, and device/driver constraints
→ block-device or driver operation
→ Σ commit request, durability, audit, or RAcc state where required
→ Ψ postcheck
→ Φ return
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

### 13.30 Architectural Consequence

PMS-OS block storage is a compositional operator-typed I/O system.

The consequence is:

```text id="xaowfm"
A PMS-OS block device is a frame-bound storage endpoint, and a storage
driver is a role-governed PMS submachine whose requests are classified,
authorized, ordered, executed, committed, resource-accounted, isolated,
recovered, and policy-checked through Δ–Ψ.
```

This gives PMS-OS a unified model for physical-device models, virtual block devices, loop devices, encrypted volumes, RAID layers, DMA regions, storage interrupts, device faults, hotplug, cache interaction, filesystem persistence, and storage-driver policy.

### 13.31 Boundary Statement

The correct boundary for this chapter is:

```text id="uvr345"
The PMS-OS block-device and storage-driver model specifies OS-level
DeviceFrames, DriverFrames, BlockRequests, request classification, device
authority, driver policy, I/O scheduling, read/write execution, durability
commit, barriers, flushes, DMA boundaries, storage-stack composition, RAID
patterns, encrypted layers, loop/virtual devices, interrupts, timeouts,
recovery, hotplug interaction, filesystem/cache interaction, syscall
interaction, resource accounting, and audit representability through Δ–Ψ
operator structure.

This is an OS-level block-device and storage-driver architecture claim.

It does not claim fabricated hardware, physical storage-controller
implementation, physical interrupt-controller behavior, physical DMA engine
implementation, a completed production storage-driver framework, external
driver certification, external security validation, distributed storage
semantics, or PMS Base validation.
```

---

## 14. Cache and Buffer Management

PMS-OS defines caches and buffers as operator-structured kernel frames.

Caching is not an implementation afterthought below the filesystem or device layer. In PMS-OS, caches, page-cache entries, filesystem buffers, journal buffers, block buffers, write-back queues, dirty states, eviction candidates, and flush policies are represented as frame-governed state structures with explicit ordering, isolation, commit, recovery, resource-accounting, and policy semantics.

The central cache-management claim is:

```text id="u76uqf"
PMS-OS treats cache and buffer management as □-framed, Χ-isolated,
Δ-classified, Ω-authorized, Θ-ordered, RAcc-accounted, ∇-mutated,
Σ-committed, Λ-aware, Φ-recoverable, Α-patterned, and Ψ-constrained
kernel state.
```

Claim type:

```text id="uo4utx"
OS-level cache and buffer-management architecture claim
```

Boundary:

```text id="llrm3q"
This section specifies OS-level cache frames, buffer lifecycles,
dirty-state handling, write-back policy, eviction, flush discipline,
resource accounting, recovery, and consistency constraints.

It does not claim physical CPU cache hardware.

It does not claim physical cache-coherence protocols.

It does not claim storage-controller implementation.

It does not claim a completed production cache subsystem.

It does not validate PMS Base.
```

This section defines the OS-level cache and buffer architecture used by virtual memory, filesystems, block devices, storage drivers, IPC buffers, and runtime-facing memory subsystems.

A concrete PMS-OS cache execution produces:

```text id="tnv8q9"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="l0bqhf"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible cache and buffer executions is:

```text id="fvcqfm"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="svvmbx"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text id="gjm6bw"
RAcc = ResourceAccount
```

`RF` must not be used for cache or buffer resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

### 14.1 Cache Frames

A cache is a frame.

```text id="a8zinr"
CacheFrame = (
    id,
    type,
    mapping,
    state,
    perms,
    owner,
    policy,
    RAcc_ref,
    meta
)
```

where:

| Field      | Meaning                                                      |
| ---------- | ------------------------------------------------------------ |
| `id`       | cache identifier                                             |
| `type`     | cache class                                                  |
| `mapping`  | relation from source object to cached buffer                 |
| `state`    | dirty/clean/flush/recovery metadata                          |
| `perms`    | Ω-governed access permissions                                |
| `owner`    | filesystem, VM subsystem, driver, process, kernel, or device |
| `policy`   | consistency, eviction, write-back, and isolation rules       |
| `RAcc_ref` | resource-accounting reference for cache usage                |
| `meta`     | τ metadata, LRU state, refcounts, ordering tags, error state |

Common cache types include:

```text id="ft1o0n"
PAGE_CACHE
BLOCK_CACHE
FS_BUFFER_CACHE
DIR_ENTRY_CACHE
INODE_CACHE
JOURNAL_CACHE
METADATA_CACHE
DEVICE_CACHE
IPC_BUFFER_CACHE
DRIVER_BUFFER_CACHE
```

A cache frame is entered implicitly by kernel subsystems or explicitly by storage and filesystem routines.

```text id="nz89s4"
FRM_ENTER CacheFrame
```

Within a cache frame, ∇ operates on cached buffers rather than directly on backing storage.

This is an OS-level cache frame model.

It does not claim physical CPU cache hardware, physical cache lines, physical cache hierarchy, or physical cache-coherence protocol.

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived metadata is sampled, compared, committed, or used.

### 14.2 Buffer Frames

A buffer is a cache-contained frame or subframe.

```text id="apwl01"
BufferFrame = (
    id,
    source,
    data,
    state,
    owner,
    refs,
    policy,
    RAcc_ref,
    meta
)
```

where:

| Field      | Meaning                                                                   |
| ---------- | ------------------------------------------------------------------------- |
| `source`   | block, page, file range, inode, journal entry, IPC payload, device region |
| `data`     | cached bytes or structured metadata                                       |
| `state`    | clean, dirty, flushing, recovery, dead, etc.                              |
| `owner`    | subsystem or process responsible for the buffer                           |
| `refs`     | references, pins, active users                                            |
| `policy`   | write-back, coherency, visibility, eviction rules                         |
| `RAcc_ref` | resource-accounting reference for buffer usage                            |
| `meta`     | ordering, τ data, dirty time, access time, checksum, fault metadata       |

Buffers are not untyped byte arrays.

They are lifecycle-controlled OS objects.

A buffer may represent:

```text id="cqxsyn"
file data
filesystem metadata
directory entry
inode record
journal intent
block-device sector
memory page
IPC message payload
DMA transfer region
driver request payload
```

### 14.3 Cache Lookup

Cache lookup is Δ.

Given a source object:

```text id="elbk00"
source = (device, block)
source = (file, offset, length)
source = (inode_id)
source = (page_id)
```

the kernel distinguishes whether a cached representation exists.

```text id="ng9s8z"
Δ(cache_lookup):
    if mapping.contains(source):
        hit
    else:
        miss
```

Cache-hit path:

```text id="l65z4m"
Δ hit
→ Ω check access
→ Χ verify visibility
→ Ψ check cache policy
→ return BufferFrame
```

Cache-miss path:

```text id="bculzm"
Δ miss
→ allocate or select BufferFrame
→ Ψ check quota and cache policy
→ ∇ load data from backing layer
→ Σ commit cache insertion
→ Σ commit RAcc update where required
```

A miss may produce Λ if the backing source is unavailable, delayed, or intentionally not loaded under current policy.

### 14.4 Cache Lifecycle

A typical cache access follows this operator sequence:

```text id="ei2hso"
Δ lookup
→ Ω permission check
→ Χ boundary check
→ Ψ policy and quota check
→ ∇ load or mutate buffer
→ Θ order access / flush / eviction
→ Σ commit if visibility or durability is required
→ Σ commit RAcc update where required
→ Λ or Φ if unavailable or failed
```

Expanded lifecycle:

1. Δ — lookup cached object.
2. Ω — check that caller/subsystem may access it.
3. Χ — ensure cache visibility does not cross isolation boundaries.
4. Ψ — enforce cache, quota, and consistency policy.
5. ∇ — load, modify, or update buffer state.
6. Θ — order concurrent access, flush, eviction, and write-back.
7. Σ — commit buffer state to cache, journal, filesystem, device, or resource account.
8. Λ — represent delayed or absent completion.
9. Φ — enter recovery if an error, fault, or inconsistency occurs.

This same lifecycle applies to page cache, buffer cache, journal cache, metadata cache, and block cache.

### 14.5 Buffer State Machine

Each buffer follows a defined lifecycle.

```text id="najmpc"
ABSENT
→ CLEAN
→ DIRTY
→ FLUSHING
→ CLEAN
```

Error and recovery states extend this:

```text id="oze1sm"
CLEAN -> DIRTY -> FLUSHING -> CLEAN
     ↘ Φ(error) -> RECOVERY -> CLEAN or DEAD
```

Additional states may include:

```text id="ec1wjk"
PINNED
LOCKED
STALE
INVALID
QUARANTINED
WRITEBACK_PENDING
JOURNAL_PENDING
DEAD
```

State transitions:

| Transition              | Operator structure         | Meaning                             |
| ----------------------- | -------------------------- | ----------------------------------- |
| `ABSENT → CLEAN`        | Δ miss + ∇ load + Σ insert | buffer filled from backing source   |
| `CLEAN → DIRTY`         | ∇ write                    | cached data modified                |
| `DIRTY → FLUSHING`      | Θ select + Σ begin         | write-back started                  |
| `FLUSHING → CLEAN`      | Σ complete                 | backing state synchronized          |
| `FLUSHING → RECOVERY`   | Φ error                    | flush failed                        |
| `RECOVERY → CLEAN`      | Φ recovery + Σ             | recovered and committed             |
| `RECOVERY → DEAD`       | Ψ fail policy              | unrecoverable buffer                |
| `CLEAN/DIRTY → INVALID` | Φ invalidate               | stale mapping or detach             |
| `any → QUARANTINED`     | Χ + Ψ                      | isolate suspicious or unsafe buffer |

A buffer state transition is valid only if the selected cache policy permits it.

### 14.6 Dirty Buffers

A dirty buffer contains changes that are visible in cache but not yet integrated into the selected backing layer.

```text id="c7h0e7"
dirty(BufferFrame) = true
```

Dirty state may apply to:

```text id="sn6iys"
file data
filesystem metadata
journal entries
page-cache data
block-cache data
driver buffers
device write queues
```

Dirty-buffer invariant:

```text id="n1zj27"
dirty buffer requires an explicit future Σ path
```

The future Σ path may be:

```text id="hztgvi"
write-through commit
write-back flush
journal commit
transaction commit
rollback
discard under policy
```

A dirty buffer cannot be silently forgotten if its changes are part of a visible or promised state transition.

Dirty state may also require resource accounting:

```text id="mzk0kr"
RAcc.cache.dirty_bytes
RAcc.cache.pinned_bytes
RAcc.cache.journal_bytes
```

### 14.7 Write Policies

PMS-OS represents classical write policies through operator sequences.

#### Write-Through

Write-through commits after every mutation.

```text id="a1fns0"
∇ write
→ Σ commit
```

Properties:

```text id="l5zi0h"
no long-lived dirty state
simple recovery
higher write latency
stronger immediate durability semantics
```

Write-through is appropriate for:

```text id="rvndsb"
critical metadata
synchronous files
journals
policy files
audit logs
small embedded systems
```

#### Write-Back

Write-back defers commit.

```text id="kx0bhh"
∇ write
→ mark dirty
→ Θ schedule later flush
→ Σ commit
```

Optional non-event handling:

```text id="bfejs0"
Θ selected flush
∧ device unavailable
⇒ Λ not-ready
```

Error handling:

```text id="kb7u7q"
Σ flush fails
⇒ Φ recovery
```

Write-back is appropriate when batching, throughput, or reduced device traffic is desired.

#### Write-Around

Write-around bypasses cache on write.

```text id="s537kf"
∇ direct write
→ Σ commit
```

Cache state is unchanged or invalidated.

```text id="o4nw5x"
cache entry exists
⇒ invalidate or mark stale
```

Write-around is useful for streaming writes or data unlikely to be reread.

#### Log-Structured Write

Log-structured cache behavior is an Α pattern.

```text id="k9twaw"
PATTERN LOG_APPEND:
    ∇ append to log buffer
    Θ batch when policy says ready
    Σ flush log buffer
```

This composes naturally with journaled filesystems and transactional storage.

### 14.8 Read Policies

Read behavior also has cache policy variants.

#### Read-Through

A cache miss loads from the backing layer.

```text id="w3jewy"
Δ miss
→ ∇ read backing source
→ Σ insert buffer into cache
→ Σ commit RAcc update where required
→ return data
```

#### Read-Ahead

Read-ahead is a Θ-ordered prediction pattern.

```text id="ku8nm1"
Δ detect sequential access
Α read-ahead pattern
Θ schedule future block/page loads
∇ load predicted buffers
Σ insert into cache
```

Read-ahead must remain policy-bound:

```text id="xwbgxg"
no cross-boundary prefetch
no forbidden namespace traversal
no user-invisible data exposure
no unaccounted cache growth
```

#### No-Cache Read

A policy may bypass cache.

```text id="q75rat"
Ψ_no_cache(source)
⇒ ∇ direct read
```

This may apply to:

```text id="hh9qpk"
security-sensitive data
device control regions
streaming workloads
explicit direct-I/O handles
```

### 14.9 Eviction

Eviction is Θ-governed candidate selection plus Σ/∇ lifecycle closure.

Eviction pipeline:

```text id="no4e09"
Δ identify candidate
Ω verify eviction authority
Ψ check eviction policy
Θ order eviction
Σ flush if dirty
∇ remove buffer from cache
Σ commit accounting and metadata
```

Eviction candidates may be selected by:

```text id="xaoywm"
LRU
LFU
CLOCK
priority
deadline
dirty age
memory pressure
role priority
container quota
driver budget
filesystem policy
```

A buffer may be non-evictable when:

```text id="hd1c0o"
pinned
locked
journal-critical
kernel-critical
DMA-active
referenced by in-flight I/O
protected by policy
```

Eviction must not break:

```text id="zt68u2"
filesystem consistency
journal ordering
device flush ordering
memory mapping validity
shared-buffer visibility
resource accounting
```

### 14.10 Dirty Eviction

If an eviction candidate is dirty, PMS-OS must resolve the dirty state before removal.

Options:

```text id="o5mkjt"
Σ write back
Φ rollback
Ψ deny eviction
Θ defer eviction
Χ quarantine buffer
```

Dirty eviction flow:

```text id="tu3gr2"
Δ candidate dirty?
if yes:
    Ψ choose resolution
    Σ flush or Φ rollback
    ∇ remove from cache after resolution
else:
    ∇ remove directly
Σ commit cache metadata update
Σ commit RAcc update where required
```

A dirty buffer cannot be evicted as if it were clean unless policy explicitly states that its changes are discardable.

### 14.11 Multi-Layer Caching

PMS-OS may maintain multiple cache layers.

Examples:

```text id="h2ml09"
PageCache
BlockCache
DirectoryEntryCache
InodeCache
MetadataCache
JournalCache
DeviceCache
DriverCache
```

Layering:

```text id="erq2dv"
File operation
→ PageCache
→ FSBufferCache
→ BlockCache
→ DeviceCache
→ DeviceFrame
```

Each layer is a CacheFrame.

```text id="zt5h9m"
FRM_ENTER PageCache
FRM_ENTER BlockCache
FRM_ENTER DeviceFrame
```

Layer coherence is defined by Α patterns and Ψ policies.

Example layered read:

```text id="pxbspb"
Δ page-cache lookup
if miss:
    Δ block-cache lookup
    if miss:
        ∇ read device
        Σ fill block cache
    Σ fill page cache
return page data
```

Example layered write:

```text id="vpld1a"
∇ modify page cache
mark page dirty
Θ schedule filesystem flush
Σ journal metadata if required
∇ write block cache
Σ device commit according to policy
```

Multi-layer caching is an OS-level cache architecture.

It does not claim physical cache hierarchy or physical cache-coherence protocols.

### 14.12 Cache Coherency

Cache coherency is a Ψ-governed relation among cache layers and backing objects.

Coherency condition:

```text id="hhzn2u"
Visible(cache_value, context)
⇒ value is valid under active consistency policy
```

Policies may define:

```text id="kv0g46"
strong coherency
journaled coherency
write-back coherency
eventual coherency
per-handle coherency
per-namespace coherency
per-device coherency
```

Examples:

#### Strong Coherency

```text id="ys0ri6"
write visible only after Σ
no reorder across Θ barriers
metadata and data visibility coupled
```

#### Journaled Coherency

```text id="zvlruf"
journal intent committed before metadata/data visibility
recovery path defined for incomplete transactions
```

#### Write-Back Coherency

```text id="m4up31"
cache may expose recent value before device durability
dirty state must remain explicit
flush policy must eventually resolve it
```

#### Eventual Coherency

```text id="uuyqu3"
Σ may be deferred
Θ may batch independent writes
Ψ requires eventual flush before lifecycle closure
```

These are OS-level coherency profiles.

They do not claim physical cache-coherence hardware.

### 14.13 Journaling and Cache Interaction

Journaling integrates tightly with buffer management.

Write sequence with intent logging:

```text id="mi7vx3"
∇ modify data buffer
∇ create or update journal buffer
Σ commit journal entry
Σ commit data buffer
Σ mark transaction complete
```

Failure path:

```text id="m0u0yo"
Φ crash/recovery
Δ classify journal entries
Σ apply committed entries
Σ rollback incomplete entries
Ψ check filesystem invariants
```

A journal buffer is itself a BufferFrame.

```text id="j1q5rl"
JournalBufferFrame = (
    transaction_id,
    affected_frames,
    state,
    data,
    policy,
    RAcc_ref,
    meta
)
```

Journal states may include:

```text id="dvtuik"
STAGED
JOURNALED
APPLIED
COMMITTED
ABORTED
RECOVERED
```

The cache manager must respect journal ordering:

```text id="vij9y5"
journal intent before metadata commit
metadata commit before visible namespace mutation
barrier before durability claim
```

### 14.14 Write-Back Scheduling

Write-back is Θ-governed.

Write-back scheduler state may include:

```text id="vkip6o"
dirty_list
flush_queue
deadline_queue
device_queue
journal_dependencies
priority_classes
policy_state
RAcc_refs
```

Selection:

```text id="f9vht4"
Θ_writeback_select(DirtySet) → BufferFrame
```

under policy:

```text id="ct5jse"
Ψ_writeback(BufferFrame) = true
```

Write-back may be triggered by:

```text id="zqcp8j"
dirty age
dirty byte threshold
memory pressure
fsync
sync
transaction commit
device idle window
policy requirement
process exit
unmount
shutdown
```

Write-back flow:

```text id="up4ugq"
Δ classify dirty buffer
Ω verify subsystem authority
Ψ check flush policy
Θ order flush
∇ issue write
Σ commit buffer clean
Σ commit RAcc update where required
Φ recover on failure
```

### 14.15 Cache Miss and Λ

A cache miss is Δ-classified absence.

```text id="rrzr95"
Δ cache_lookup(source) = miss
```

A miss is not necessarily an error.

If backing source can be loaded:

```text id="ifjceo"
∇ load source
Σ insert buffer
```

If backing source is delayed or unavailable:

```text id="uuyeaq"
Λ backing-not-ready
```

Possible responses:

```text id="uzgox5"
block caller
return WOULD_BLOCK
schedule I/O
retry later
enter Φ error path
```

A miss becomes Φ only when policy or operation semantics treat absence as exceptional.

### 14.16 Buffer Faults and Recovery

Buffer and cache failures are Φ events.

Examples:

```text id="m8a7u2"
flush failure
checksum mismatch
stale metadata
device timeout
journal dependency failure
dirty buffer lost
cache corruption
invalid buffer ownership
DMA boundary violation
resource-accounting inconsistency
```

Recovery flow:

```text id="f595pj"
Δ classify failure
Φ enter recovery context
Ψ choose recovery policy
Θ order retry or rollback
∇ repair, reload, discard, or reconstruct
Σ commit recovery state
Σ commit RAcc/audit update where required
Φ return or escalate
```

Possible recovery actions:

```text id="ghur2z"
retry write
reload from backing store
rollback transaction
invalidate buffer
quarantine buffer
mark device degraded
fail filesystem operation
switch to read-only mode
halt under critical policy
```

Quarantine is an OS-level isolation response.

It is not moral judgment, forensic attribution, or governance authority.

### 14.17 Cache Isolation

Caches must preserve isolation.

A cache may contain data from many processes, namespaces, containers, filesystems, or devices. PMS-OS prevents visibility leaks through Χ and Ψ.

Cache access rule:

```text id="dvvxjj"
CacheAccessAllowed(actor, BufferFrame, mode) iff
    Ω permits mode
    ∧ Χ permits visibility from actor domain to buffer domain
    ∧ Ψ permits access under cache policy
```

Cache isolation prevents:

```text id="w7xc6r"
process reading another process's cached file data
container seeing host metadata cache
driver observing unrelated DMA buffer
raw device cache bypassing filesystem policy
stale buffer visible after namespace change
```

Shared caches are allowed, but sharing must be explicit.

```text id="dxeuiq"
shared cache visibility requires Ω + Χ + Ψ
```

Concrete domain values such as `X_cache`, `X_p`, `X_user`, `X_global`, and `X_device` are OS-level isolation-domain values.

They are not PMS Base Χ.

PMS Base Χ = Distance.

PMS-OS projects Χ as process isolation, namespace separation, filesystem view, device boundary, IPC visibility, sandbox/container boundary, DMA boundary, and reachability control.

### 14.18 Cache Permissions

Cache access is Ω-governed.

Capabilities may include:

```text id="fh3mgg"
cache_read
cache_write
cache_insert
cache_evict
cache_flush
cache_pin
cache_unpin
cache_invalidate
cache_admin
```

Examples:

```text id="efbvbc"
filesystem may flush its own buffers
driver may flush device buffers
user process may not inspect global page cache
kernel may invalidate all buffers for detach
container may access only its namespace-visible cached objects
```

Permission checks must happen before cache mutation.

### 14.19 Pins, References, and Active I/O

A buffer may be pinned.

```text id="cb469j"
pin(BufferFrame)
```

Pinning prevents eviction or reuse while an operation depends on the buffer.

Pinned reasons include:

```text id="hf726g"
active I/O
DMA transfer
memory mapping
journal transaction
filesystem metadata update
IPC delivery
driver request
user page fault resolution
```

Pin flow:

```text id="d7wdfx"
Δ identify buffer
Ω verify pin authority
∇ increment pin/ref counter
Σ commit pin state
Σ commit RAcc update where required
```

Unpin flow:

```text id="kzgw6o"
Δ identify buffer
∇ decrement pin/ref counter
Σ commit unpin state
Σ commit RAcc update where required
Ψ check whether eviction/reclaim is now allowed
```

Pinned buffers must be accounted, because unbounded pins can exhaust memory.

### 14.20 Cache and Resource Accounting

Cache growth consumes resources.

Cache accounting fields may include:

```text id="wpxrmb"
RAcc.cache.bytes
RAcc.cache.dirty_bytes
RAcc.cache.clean_bytes
RAcc.cache.pinned_bytes
RAcc.cache.journal_bytes
RAcc.cache.metadata_bytes
RAcc.cache.per_owner_bytes
RAcc.cache.per_device_bytes
RAcc.cache.per_container_bytes
```

Accounting flow:

```text id="t79m5b"
Δ classify cache event
Ω verify owner/account relation
Ψ check quota
∇ update cache usage
Σ commit RAcc
Ψ post-check
```

Cache pressure may trigger:

```text id="dq1iuo"
Θ eviction
Σ write-back
Φ recovery
Χ isolation
Ψ throttle or deny
```

A cache may be charged to:

```text id="nr8k78"
process
container
filesystem
device
driver
system
shared account
```

Attribution rules must be explicit to prevent quota laundering.

Correct notation:

```text id="c2wobc"
RAcc.cache.bytes
RAcc.cache.dirty_bytes
ProcessRAcc
ContainerRAcc
DriverRAcc
DeviceRAcc
```

Incorrect notation:

```text id="ibbu4b"
RF.cache.bytes
ProcessRF
ContainerRF
DriverRF
DeviceRF
```

### 14.21 Cache Pressure

Cache pressure is a memory-pressure subtype.

```text id="qo1tql"
CachePressure(level) =
    RAcc.cache.bytes / RAcc.cache.limit
    plus dirty ratio
    plus pinned ratio
    plus reclaimability
```

Pressure levels may include:

```text id="p5m61u"
NORMAL
ELEVATED
WRITEBACK_REQUIRED
EVICTION_REQUIRED
CRITICAL
```

Pressure response:

```text id="osuw26"
Δ classify pressure
Ψ choose cache policy
Θ schedule write-back or eviction
Σ commit flushed buffers
∇ evict clean buffers
Σ commit RAcc update where required
Φ recover on failure
```

Critical pressure may cause:

```text id="wpf3ff"
deny cache insertions
bypass cache
force synchronous write-back
throttle writers
quarantine faulty driver buffers
invoke OOM policy
```

### 14.22 Concurrency and Synchronization

Concurrent cache access is Θ/Ω/Σ-governed.

A cache update must define:

```text id="njijex"
lock or capability acquisition
ordering of metadata updates
visibility point
commit point
recovery path
```

Atomic buffer update pattern:

```text id="f3h4b9"
Ω acquire buffer capability / lock
Δ inspect buffer state
∇ modify buffer
Σ commit update or dirty state
Ω release
```

Concurrent policies may enforce:

```text id="m0a3zf"
no dirty-state lost update
no eviction while pinned
no flush while ownership invalid
no metadata/data reorder across barrier
priority inheritance for cache locks
bounded lock hold time
```

Locking primitives themselves are defined in Section 15.

### 14.23 Cache Consistency and Memory Model

Cache behavior must be compatible with the PMS-CPU memory consistency model and PMS-OS virtual memory semantics.

Relevant constraints:

```text id="txypdd"
Θ defines ordering points
Σ defines visibility/commit points
Χ defines visibility domains
Ψ defines consistency policy
Φ handles invalidation and recovery
RAcc records resource-visible cache state
```

Examples:

```text id="v6njk9"
memory-mapped file write must update or invalidate page cache coherently
DMA write must invalidate or synchronize affected buffers
filesystem write-back must respect journal barriers
shared-memory cache entries must obey synchronization policy
```

No cache layer may make a visibility claim stronger than its Σ path supports.

This is an OS-level consistency discipline.

It does not claim physical cache-coherence hardware.

### 14.24 Cache Invalidation

Invalidation removes or marks cached state as no longer valid.

Invalidation triggers:

```text id="xu1zel"
file truncate
unmap memory
device detach
driver reset
namespace change
permission change
policy change
journal rollback
external modification
DMA completion
```

Invalidation flow:

```text id="awvwhe"
Δ identify affected buffers
Ω verify invalidation authority
Ψ check invalidation policy
Φ recontextualize dependent views
∇ mark invalid/stale
Σ commit invalidation state
Σ commit RAcc update where required
```

Invalidation may wake or fault waiters if they were depending on the old buffer state.

### 14.25 Buffer Barriers

Barriers constrain reorderings across cache operations.

Barrier examples:

```text id="avqdhn"
fsync
sync
journal barrier
device flush barrier
memory-mapped-file sync
metadata-before-data barrier
data-before-metadata barrier
```

Barrier flow:

```text id="h9rfpr"
Δ identify barrier scope
Ω verify authority
Ψ determine required ordering
Θ order prior operations before barrier
Σ commit all required prior buffers
Θ permit later operations
Φ recover if barrier fails
```

A barrier is valid only when every required prior commit has either completed or has a policy-defined failure path.

### 14.26 Cache Audit and Trace

Cache operations may emit audit records.

```text id="s4dk2h"
CacheAuditRecord = (
    event_id,
    actor,
    role,
    cache_id,
    buffer_id,
    source,
    operation,
    state_before,
    state_after,
    decision,
    commit_result,
    resource_accounting_result,
    timestamp_or_order,
    metadata
)
```

Auditable events include:

```text id="x7ftr1"
dirty buffer creation
flush
flush failure
journal buffer commit
eviction
forced invalidation
cache policy denial
DMA buffer synchronization
cross-domain cache access
quarantine
resource-accounting violation
```

Audit flow:

```text id="ocript"
Δ prepare record
Σ commit audit record
Ψ enforce retention/integrity policy
```

A concrete cache trace is:

```text id="bag8nj"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="xuhr4e"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The declared cache execution space is:

```text id="p9nb12"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="fbsi9j"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Trace emission is implementation-specific.

Operator-labeled representability is the architectural requirement.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 14.27 Cache and Filesystem Interaction

The filesystem uses cache and buffer management for:

```text id="z6a557"
file data
directory entries
metadata
journaling
mapped files
write-back
transaction staging
```

Filesystem write through cache:

```text id="dueihe"
Δ validate handle
∇ modify cache buffer
mark dirty
Σ journal if required
Θ schedule write-back
Σ device commit
Σ filesystem commit
Σ commit RAcc update where required
```

Filesystem read through cache:

```text id="dbjz85"
Δ lookup cache
if hit:
    return buffer
else:
    ∇ read via block layer
    Σ insert buffer
    Σ commit RAcc update where required
    return
```

Filesystem consistency depends on cache policy.

Section 12 defines filesystem semantics; this section defines cache behavior that those semantics rely on.

### 14.28 Cache and Block Device Interaction

The block layer uses cache frames to buffer device I/O.

Read miss path:

```text id="gljgr5"
Δ block-cache miss
Ω verify device access
∇ issue block read
Σ commit buffer fill
Σ commit RAcc update where required
```

Write-back path:

```text id="wbs90x"
∇ modify buffer
Θ schedule flush
∇ issue block write
Σ commit device write
Σ mark buffer clean
Σ commit RAcc update where required
```

Device failure path:

```text id="y6q6kp"
Φ device error
Ψ choose retry/degrade/fail/quarantine
Σ commit recovery or failure state
```

Section 13 defines block devices and drivers; this section defines the cache and buffer semantics above them.

### 14.29 Cache and Virtual Memory Interaction

The page cache connects virtual memory to file and block storage.

Examples:

```text id="qq72sy"
file-backed mmap
demand paging
page fault fill
shared library mapping
COW page
write-back page
```

Page-fault fill:

```text id="lw6fcc"
Δ classify fault
Φ enter page-fault handler
Δ lookup page cache
if miss:
    ∇ read backing file/device
    Σ insert page buffer
□ install mapping
Σ commit page presence
Σ commit RAcc update where required
Φ return
```

Memory-mapped write:

```text id="n33o7l"
∇ modify page
mark page dirty
Θ schedule write-back
Σ commit file/device state according to policy
Σ commit RAcc update where required
```

Page cache isolation must preserve process, namespace, and policy boundaries.

### 14.30 Cache and IPC Buffers

IPC may use cache-like buffer frames.

Examples:

```text id="iltp6r"
message buffer pool
shared ring buffer
channel buffer
event backlog
socket buffer
```

IPC buffer access follows:

```text id="a8imtv"
Δ identify endpoint and buffer
Ω verify send/receive capability
Χ verify endpoint visibility
Ψ check queue and quota policy
∇ enqueue/dequeue or mutate buffer
Σ commit delivery or buffer release
Σ commit RAcc update where required
```

Full IPC semantics belong in Section 15.

### 14.31 Cache and Syscalls

Cache and buffer operations may be reached through syscalls such as:

```text id="noy5bw"
read
write
mmap
msync
fsync
sync
sendmsg
recvmsg
ioctl
cache_control
```

Such syscalls follow the canonical PMS-OS syscall contract:

```text id="u5zr56"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded for cache and buffer access:

```text id="yjnha9"
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, file, endpoint, buffer, or device boundary
→ Δ classify syscall, cache object, and buffer
→ Ψ check policy, quota, and consistency constraints
→ cache / buffer operation
→ Σ commit buffer, audit, consistency, or RAcc state where required
→ Ψ postcheck
→ Φ return
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

### 14.32 Cache Policy Profiles

A PMS-OS profile may define named cache policies.

Examples:

#### Strong Synchronous Profile

```text id="gdcrsq"
writes commit before return
dirty buffers short-lived
fsync barrier strict
journal required for metadata
```

#### Throughput Write-Back Profile

```text id="nt5g6v"
dirty buffers allowed
Θ batches write-back
Σ occurs on dirty age, pressure, fsync, unmount, or shutdown
```

#### Embedded Deterministic Profile

```text id="jg30hk"
bounded cache size
predictable eviction
no unbounded write-back delay
explicit flush points
```

#### Secure Isolation Profile

```text id="dhp1p2"
no cross-domain cache sharing without explicit policy
cache invalidation on namespace or role change
aggressive zeroing on reuse
audit high-value buffers
```

#### Recovery-Oriented Profile

```text id="fbx67g"
journal every metadata mutation
flush barriers before visible namespace changes
quarantine buffers with failed integrity checks
```

Profiles are Ψ-level configuration of the same cache architecture.

### 14.33 Cache and Buffer Invariants

PMS-OS maintains the following cache and buffer invariants.

```text id="njcesp"
I1: every cache is represented as a valid CacheFrame

I2: every buffer belongs to a cache, device, filesystem, VM, IPC, or driver
    scope

I3: cache lookup is Δ-classified before use

I4: protected cache access is Ω-authorized

I5: cache visibility respects Χ isolation boundaries

I6: cache mutations occur through ∇ and produce explicit dirty/clean state

I7: dirty buffers have an explicit Σ, rollback, or discard path

I8: write-back is Θ-ordered under active policy

I9: flush and barrier semantics are backed by Σ

I10: eviction does not discard non-discardable dirty state

I11: pinned buffers are not evicted or reused

I12: journal buffers preserve required ordering dependencies

I13: invalidation is Φ/Σ-represented and policy-governed

I14: cache accounting is updated through RAcc for growth, flush, eviction,
     and reclaim

I15: cache failures enter Φ recovery paths

I16: no cache fast path bypasses Ω, Χ, Ψ, or required RAcc constraints

I17: RAcc / ResourceAccount is the resource-accounting notation

I18: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I19: X_cache, X_device, X_p, X_user, X_global, and related X_* symbols are
     OS-level isolation-domain values, not PMS Base Χ

I20: PMS Base Χ = Distance

I21: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, filesystem view, device boundary, IPC visibility,
     sandbox/container boundary, DMA boundary, cache visibility, and
     reachability control

I22: τ denotes time/accounting metadata, not a PMS Base operator

I23: cache traces remain operator-labeled and belong to L_PMS or
     L_PMS,Ψ_kernel under the declared OS profile

I24: cache-like names in this section denote OS-level cache and buffer
     models unless a later implementation artifact explicitly realizes them
```

### 14.34 Boundary to Adjacent Sections

This section defines cache and buffer management at OS architecture level.

It does not fully define:

| Topic                                         | Primary section             |
| --------------------------------------------- | --------------------------- |
| virtual memory mapping and page faults        | Section 10                  |
| allocation and reclamation                    | Section 11                  |
| filesystem namespace, handles, journaling     | Section 12                  |
| block devices and storage drivers             | Section 13                  |
| IPC queues, channels, sync primitives, events | Section 15                  |
| device lifecycle and hotplug                  | Section 16                  |
| runtime security and audit hardening          | `06_runtime_security.md`    |
| distributed cache coherence                   | `07_distributed_systems.md` |

Distributed cache coherence, cross-node write-back, remote buffer invalidation, cluster-wide durability, distributed cache invalidation, remote consistency, and distributed policy synchronization are not defined here.

Those belong to `07_distributed_systems.md`.

Runtime-security hardening of cache behavior belongs to `06_runtime_security.md` when it concerns adversarial hardening, exploit-class modeling, audit/evidence hardening, or deployment-facing security profiles.

Boundary:

```text id="j39lqx"
The PMS-OS cache and buffer model specifies OS-level CacheFrames,
BufferFrames, buffer lifecycles, dirty-state handling, write-back policy,
eviction, flush discipline, invalidation, barriers, recovery, resource
accounting, and consistency constraints.

It does not claim physical CPU cache hardware, physical cache-coherence
protocols, storage-controller implementation, distributed cache coherence,
or PMS Base validation.
```

### 14.35 Architectural Consequence

PMS-OS cache and buffer management makes intermediate state explicit.

The consequence is:

```text id="hnqwqk"
A PMS-OS cache is a frame-governed subsystem whose hits, misses, dirty
states, write-back paths, flushes, evictions, invalidations, barriers,
journals, resource-accounting updates, and recovery paths are represented
as operator-typed, policy-constrained transitions.
```

This gives PMS-OS a unified cache model for filesystems, virtual memory, block devices, page caches, buffer caches, IPC buffers, driver buffers, journal buffers, and write-back subsystems.

### 14.36 Boundary Statement

The correct boundary for this chapter is:

```text id="hy0x36"
The PMS-OS cache and buffer-management model specifies OS-level cache
frames, buffer frames, cache lookup, buffer lifecycle, dirty state,
write policies, read policies, eviction, dirty eviction, multi-layer
caching, coherency profiles, journaling interaction, write-back scheduling,
cache misses, buffer recovery, cache isolation, permissions, pins,
resource accounting, pressure handling, synchronization, invalidation,
barriers, syscall interaction, audit representability, and cache/buffer
invariants through Δ–Ψ operator structure.

This is an OS-level cache and buffer-management architecture claim.

It does not claim a completed production cache subsystem, physical CPU cache
hardware, physical cache-coherence protocols, physical storage-controller
implementation, fabricated hardware substrate, distributed cache coherence,
external performance validation, external security validation, or PMS Base
validation.
```

---

## 15. IPC, Synchronization, and Events

PMS-OS defines IPC, synchronization, and events as one operator-typed communication and coordination subsystem.

Message passing, queues, mailboxes, channels, locks, semaphores, futex-like primitives, timers, signals, notifications, pub-sub topics, and interrupt-to-process delivery are not separate ad hoc mechanisms. They are structured through frames, capabilities, ordering, absence, recontextualization, commit, isolation, resource accounting, and policy.

The central IPC/synchronization/event claim is:

```text
PMS-OS treats inter-process communication, synchronization, and event
delivery as □-framed, Δ-classified, Ω-authorized, Χ-bounded,
Θ-ordered, Λ-aware, RAcc-accounted, ∇-mutated, Σ-committed,
Φ-recontextualized, Α-patterned, and Ψ-constrained kernel structure.
```

Claim type:

```text
OS-level IPC, synchronization, and event architecture claim
```

Boundary:

```text
This section defines single-node PMS-OS IPC, synchronization, and event
architecture.

It does not claim distributed messaging semantics, cross-node delivery
guarantees, distributed locks, cluster-wide event ordering, remote
exactly-once delivery, physical interrupt-controller implementation,
external security validation, or PMS Base validation.
```

Distributed messaging, cross-node event delivery, cluster consistency, remote consensus, replicated event logs, distributed locks, and global policy synchronization belong in `07_distributed_systems.md`.

A concrete PMS-OS communication execution produces:

```text
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible IPC, synchronization, and event executions is:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text
RAcc = ResourceAccount
```

`RF` must not be used for IPC, synchronization, or event resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

### 15.1 Unified Communication Model

PMS-OS uses a common structural model for IPC, synchronization, and events.

The core objects are frames:

```text
MessageFrame
SyncFrame
EventFrame
TopicFrame
SignalFrame
TimerFrame
ChannelFrame
```

The common transition pattern is:

```text
Δ classify object / operation / state
Ω check authority
Χ check visibility and boundary
Ψ check policy
Θ order waiters, messages, events, or dispatch
Λ represent absence, timeout, or not-ready state
∇ mutate queue, lock, buffer, or event state
Σ commit delivery, wakeup, lock state, notification, or RAcc update
Φ recontextualize on trap, fault, signal, timeout, or invalid state
```

IPC and synchronization therefore share a single kernel substrate:

```text
framed object
+ capability gate
+ OS isolation-domain boundary
+ ordered state transition
+ absence semantics
+ resource-accounting state
+ commit semantics
+ policy constraints
```

At PMS Base level:

```text
Χ = Distance
```

At PMS-OS level, Χ projects as endpoint visibility, namespace boundary, process isolation, IPC reachability, event visibility, and synchronization-object sharing control.

This is a layer projection.

It does not redefine PMS Base Χ.

### 15.2 IPC Objects as Frames

All IPC endpoints are frames.

```text
MessageFrame = (
    id,
    type,
    queue,
    perms,
    owner,
    policy,
    RAcc_ref,
    meta
)
```

where:

| Field      | Meaning                                                               |
| ---------- | --------------------------------------------------------------------- |
| `id`       | endpoint identifier                                                   |
| `type`     | MAILBOX, QUEUE, CHANNEL, PIPE, PORT, SOCKET, TOPIC, SIGNAL, EVENT     |
| `queue`    | ordered buffer or delivery state                                      |
| `perms`    | Ω permissions for send, receive, inspect, close, bind                 |
| `owner`    | process, kernel subsystem, driver, service, or namespace              |
| `policy`   | delivery, quota, reliability, visibility, and ordering policy         |
| `RAcc_ref` | resource-accounting reference for queue, endpoint, or delivery cost   |
| `meta`     | Θ counters, Λ state, Φ errors, τ-derived timestamps, Σ delivery state |

Endpoint visibility is governed by Χ as an implementation-layer projection of PMS Base Distance.

```text
PMS Base 1.3:
    Χ = Distance

PMS-OS:
    Χ projects as endpoint visibility, namespace boundary,
    process isolation, communication reachability, and IPC-domain control.
```

Concrete IPC-domain values such as:

```text
X_endpoint
X_sender
X_receiver
X_topic
X_channel
X_event
```

are OS-level isolation-domain values.

They are not the PMS Base operator `Χ`.

They name concrete PMS-OS endpoint, namespace, communication, event, or process-domain values through which PMS Base Χ = Distance is projected at OS level.

A process may use an IPC endpoint only if:

```text
endpoint ∈ VisibleFrames(process)
∧ Ω permits requested operation
∧ Χ permits sender/receiver relation
∧ Ψ permits communication
∧ RAcc permits resource-visible operation where relevant
```

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived metadata is sampled, compared, committed, or used.

### 15.3 Message Structure

A message is a typed kernel object.

```text
Message = (
    id,
    kind,
    payload,
    sender,
    receiver,
    caps,
    policy,
    RAcc_delta,
    meta
)
```

where:

| Field        | Meaning                                                             |
| ------------ | ------------------------------------------------------------------- |
| `id`         | message identifier                                                  |
| `kind`       | REQUEST, RESPONSE, EVENT, SIGNAL, ERROR, CONTROL, TIMEOUT, DATA     |
| `payload`    | bytes or structured value                                           |
| `sender`     | sender process/thread/role                                          |
| `receiver`   | target process/thread/endpoint                                      |
| `caps`       | optional capability payload                                         |
| `policy`     | delivery and validation policy                                      |
| `RAcc_delta` | resource-accounting impact of enqueue, delivery, retry, or storage  |
| `meta`       | ordering, timestamp/order tag, retry count, hop count, commit state |

Message validity requires:

```text
sender exists
∧ receiver or endpoint exists
∧ payload matches endpoint schema
∧ attached capabilities are transferable
∧ sender has SEND authority
∧ receiver has RECEIVE visibility
∧ policy permits message relation
∧ resource-accounting impact is permitted where relevant
```

### 15.4 Message Passing Overview

Message passing has two primary paths:

```text
send
receive
```

Send mutates an endpoint queue or delivery structure.

Receive distinguishes availability and either dequeues a message or produces Λ absence.

Both operations are policy-checked and may require Σ delivery commit depending on reliability mode.

Canonical send word:

```text
Δ ; Ω ; Χ ; Ψ ; ∇ ; Θ ; Σ? ; Φ?
```

Canonical receive word:

```text
Δ ; Ω ; Χ ; Ψ ; (Λ | ∇) ; Σ? ; Φ?
```

When send or receive is entered from user context through the PMS-OS syscall ABI, the enclosing syscall contract is:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

The shorter IPC words describe the internal endpoint operation.

The full syscall word describes user-to-kernel entry, syscall-frame binding, boundary mediation, policy, operation, commit, postcheck, and return.

### 15.5 Send Semantics

Sending a message follows a structured operator sequence.

#### Step 1 — Δ classify message and endpoint

```text
Δ(message.kind)
Δ(endpoint.type)
Δ(payload schema)
Δ(RAcc impact)
```

The kernel determines:

```text
message type
target endpoint
delivery mode
payload size
attached capabilities
priority or ordering class
resource-accounting impact
```

#### Step 2 — Ω check send authority

The sender must have permission:

```text
Ω(sender, send, MessageFrame)
```

If the message carries capabilities:

```text
Ω(sender, transfer, capability)
```

must also hold.

#### Step 3 — Χ check visibility

The sender must be allowed to reach the endpoint.

```text
Χ permits sender_domain → endpoint_domain
```

No cross-domain message delivery occurs without explicit visibility or bridge relation.

The concrete `sender_domain` and `endpoint_domain` are OS-level isolation-domain values, not PMS Base Χ itself.

#### Step 4 — Ψ check policy

Policy may inspect:

```text
sender
receiver
endpoint
payload kind
payload size
capabilities
rate
queue depth
namespace
OS isolation-domain value
RAcc state
history
```

Policy may allow, deny, defer, rewrite, isolate, or audit the send.

Policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

#### Step 5 — ∇ enqueue or deliver

The message is placed into the endpoint state.

```text
ENQ MessageFrame.queue, Message
```

or for direct synchronous delivery:

```text
deliver Message to waiting receiver
```

The mutation may stage resource-accounting deltas.

#### Step 6 — Θ order dispatch

The kernel orders the message according to endpoint policy.

Ordering modes may include:

```text
FIFO
priority
deadline
fair queue
per-sender queue
per-role queue
topic order
transactional order
```

#### Step 7 — Σ commit delivery state

A committed send means the message is visible according to endpoint semantics.

```text
Σ commit_send(MessageFrame, Message)
Σ commit RAcc update where required
```

If Σ is deferred, the message remains staged or pending.

### 15.6 Receive Semantics

Receiving is the dual of sending.

#### Step 1 — Δ inspect endpoint state

```text
Δ queue_length
Δ message availability
Δ message kind
Δ resource-accounting impact
```

If no message exists:

```text
Λ no-message
```

#### Step 2 — Ω check receive authority

```text
Ω(receiver, receive, MessageFrame)
```

If the receiver lacks permission:

```text
Ω denial → Φ permission fault or error return
```

#### Step 3 — Χ check receiver visibility

The receiver must be able to observe the endpoint.

```text
Χ permits receiver_domain → endpoint_domain
```

The domain names are OS-level isolation-domain values.

They are not PMS Base Χ.

#### Step 4 — Ψ check delivery policy

Policy may deny delivery even when a message is present.

Examples:

```text
sender blocked by receiver policy
message type forbidden
capability transfer invalid
queue quarantined
receiver suspended
rate limit exceeded
RAcc quota exceeded
```

#### Step 5 — Λ or ∇

If no deliverable message exists:

```text
Λ no-message
```

If a message is present and deliverable:

```text
DEQ MessageFrame.queue → Message
```

#### Step 6 — Σ commit receive

If endpoint policy requires delivery commit:

```text
Σ commit_receive(Message)
Σ commit RAcc update where required
```

This may update:

```text
queue state
delivery acknowledgement
resource accounting
audit record
sender retry state
receiver state
```

### 15.7 Blocking Receive

A blocking receive waits when the expected message is absent.

```text
receive(endpoint, blocking = true)
```

If no message exists:

```text
Λ message_absent
Θ enqueue receiver in waiter queue
thread state := BLOCKED
```

Wait state:

```text
Wait = (
    endpoint,
    condition,
    receiver,
    deadline,
    policy,
    continuation,
    RAcc_ref
)
```

Wake-up:

```text
message arrives
→ Θ select waiter
→ move thread BLOCKED → READY
→ Φ resume syscall or continuation
```

Timeout:

```text
Λ_timeout :=
    τ.now ≥ deadline
    ∧ message_absent
```

Timeout response may be:

```text
return timeout
retry
defer
signal
recontextualize through Φ
terminate under policy
```

`τ` stores or represents timing/accounting data.

Θ orders when the kernel samples, compares, and acts on τ-derived data.

### 15.8 Nonblocking Receive

A nonblocking receive treats absence as a normal Λ outcome.

```text
receive(endpoint, blocking = false)
```

If no message exists:

```text
Λ no-message → return WOULD_BLOCK / NO_EVENT
```

This is not a fault.

It is a first-class OS result:

```text
expected communication event did not materialize in this step
```

### 15.9 Request/Response Pattern

Request/response is an Α pattern over message passing.

```text
Α_REQRESP(client, server)
```

Client send:

```text
Δ classify REQUEST
Ω check send rights
Χ check endpoint visibility
Ψ check request policy
∇ enqueue request
Σ commit request visibility
Σ commit RAcc update where required
```

Server receive and process:

```text
Δ inspect queue
Ω check receive rights
Χ verify visibility
∇ dequeue request
execute handler
```

Server response:

```text
Δ classify RESPONSE
Ω check reply capability
Χ check client reply endpoint
∇ enqueue response
Σ commit response
Σ commit RAcc update where required
```

Client receive:

```text
Δ inspect reply queue
Λ wait if absent
∇ dequeue response if present
Φ recontextualize if response changes control path
```

Canonical pattern:

```text
client: Δ Ω Χ Ψ ∇ Σ
server: Δ Ω Χ ∇ handler
server: Δ Ω Χ ∇ Σ
client: Δ (Λ | ∇) Φ?
```

This pattern supports:

```text
RPC
service calls
kernel/user request completion
driver requests
filesystem notifications
policy queries
```

For cross-node request/response, remote consensus, retry semantics across partitions, and replicated delivery state, see `07_distributed_systems.md`.

### 15.10 Mailboxes

A mailbox is a process- or service-owned `MessageFrame`.

```text
MailboxFrame = (
    owner,
    queue,
    perms,
    send_policy,
    receive_policy,
    RAcc_ref,
    meta
)
```

Typical permission structure:

```text
owner may receive
authorized peers may send
kernel may inspect or signal under policy
```

Mailbox isolation:

```text
Χ isolates mailbox contents to owner and authorized senders/receivers
```

Mailbox uses:

```text
signals
notifications
service requests
driver completions
asynchronous syscall completion
```

Mailbox queue growth must be accounted through `RAcc`.

### 15.11 Queues

A queue is a shared or multi-party `MessageFrame`.

```text
QueueFrame = (
    id,
    producers,
    consumers,
    queue,
    ordering_policy,
    quota,
    RAcc_ref,
    meta
)
```

Queue policies may define:

```text
FIFO
priority
fairness
maximum length
maximum bytes
backpressure
drop policy
blocking behavior
delivery guarantee
```

Queue operations:

```text
send/enqueue    → Δ Ω Χ Ψ ∇ Σ
receive/dequeue → Δ Ω Χ Ψ (Λ | ∇) Σ
```

A full queue may produce:

```text
Λ no-space
Θ block sender
Ψ deny send
Φ error path
```

depending on endpoint policy.

Queue resource accounting is expressed through:

```text
RAcc.ipc.queue_bytes
RAcc.ipc.max_queue_bytes
RAcc.ipc.message_count
RAcc.ipc.max_messages
```

### 15.12 Channels

A channel combines queue semantics with synchronization semantics.

```text
ChannelFrame = (
    id,
    buffer,
    capacity,
    closed,
    wait_send,
    wait_recv,
    perms,
    policy,
    RAcc_ref,
    meta
)
```

Channel send:

```text
Δ check closed/full state
Ω check SEND capability
Χ check visibility
Ψ check channel policy and quota
```

If buffer has capacity:

```text
∇ enqueue message
Σ commit_send
Σ commit RAcc update where required
Θ wake receiver if waiting
```

If buffer is full:

```text
blocking send     → Θ enqueue sender + Λ wait
nonblocking send  → Λ no-space
policy failure    → Φ / Ψ denial
```

Channel receive:

```text
Δ check closed/empty state
Ω check RECEIVE capability
Χ check visibility
Ψ check channel policy
```

If message exists:

```text
∇ dequeue message
Σ commit_receive
Σ commit RAcc update where required
Θ wake sender if waiting
```

If empty:

```text
blocking receive     → Θ enqueue receiver + Λ wait
nonblocking receive  → Λ no-message
```

Channel close:

```text
Δ classify channel open
Ω check CLOSE capability
Ψ check close policy
∇ set closed := true
Θ wake waiters
Σ commit close
Φ mark future invalid operations if needed
```

### 15.13 Capability Transfer

IPC may carry capabilities.

A capability transfer is Ω-sensitive and policy-bound.

Transfer validity:

```text
sender owns or may delegate capability
∧ receiver may receive capability
∧ capability scope permits transfer
∧ Χ permits sender/receiver relation
∧ Ψ permits delegation
```

Transfer flow:

```text
Δ identify capability
Ω verify delegation authority
Ψ check transfer policy
∇ attach capability to message
Σ commit transfer on delivery
```

Policy may require:

```text
copy capability
move capability
narrow capability
wrap capability
expire capability
audit transfer
deny transfer
```

Capability smuggling is invalid:

```text
payload contains undeclared authority
⇒ Ψ denial / Φ violation
```

Capability transfer is local OS authority transfer in this section.

Cross-node capability transfer, distributed delegation, and remote authority propagation belong to `07_distributed_systems.md`.

### 15.14 Delivery Guarantees

Delivery guarantees are Ψ + Σ policies over messages.

#### At-Most-Once

```text
message delivered zero or one time
```

Structure:

```text
Σ commit dequeue
Ψ forbid redelivery
```

#### At-Least-Once

```text
message retried until acknowledged or policy stops retry
```

Structure:

```text
sender retains staged copy
Λ timeout if no ack
Θ retry with backoff
Σ commit ack when received
```

#### Exactly-Once

Exactly-once requires stronger structure:

```text
message id
deduplication table
commit protocol
acknowledgement state
policy over duplicates
```

Structure:

```text
Δ identify message id
Σ commit delivery
Ψ reject duplicate delivery
Φ recover on ambiguity
```

Exactly-once delivery is an OS-level single-node policy profile, not an automatic property of all IPC.

Remote exactly-once delivery is not defined here.

It belongs to `07_distributed_systems.md`.

### 15.15 IPC Reliability and Failure

IPC failures are operator-typed.

| Failure                     | Operator reading |
| --------------------------- | ---------------- |
| endpoint missing            | Λ or Φ           |
| endpoint closed             | Δ / Φ            |
| no message                  | Λ                |
| queue full                  | Λ / Ψ            |
| permission denied           | Ω / Ψ            |
| boundary denied             | Χ / Ψ            |
| malformed message           | Δ / Φ            |
| delivery timeout            | Λ                |
| receiver dead               | Φ / Σ cleanup    |
| duplicate message           | Δ / Ψ            |
| capability transfer invalid | Ω / Ψ / Φ        |
| resource quota exceeded     | Ψ / RAcc / Φ     |

Recovery responses may include:

```text
return error
block
retry
drop
dead-letter queue
signal sender
terminate receiver relation
quarantine endpoint
commit audit event
```

Quarantine is an OS-level isolation response.

It is not moral judgment, forensic attribution, or governance authority.

### 15.16 Synchronization Primitives as Frames

Synchronization objects are frames.

```text
SyncFrame = (
    id,
    type,
    state,
    waiters,
    perms,
    policy,
    RAcc_ref,
    meta
)
```

where:

| Field      | Meaning                                                              |
| ---------- | -------------------------------------------------------------------- |
| `id`       | sync object identifier                                               |
| `type`     | MUTEX, SEMAPHORE, RWLOCK, FUTEX, CONDVAR, BARRIER, EVENTFD           |
| `state`    | primitive-specific state                                             |
| `waiters`  | Θ-ordered waiting threads                                            |
| `perms`    | Ω rights: lock, unlock, wait, signal, close                          |
| `policy`   | fairness, timeout, priority, deadlock, inheritance rules             |
| `RAcc_ref` | resource-accounting reference for waiters, object, or hold-time cost |
| `meta`     | τ wait data, owner, recursion, fault state, audit metadata           |

Χ isolates each `SyncFrame` unless explicitly shared.

A process can synchronize on an object only if it can see the `SyncFrame` and has the required capability.

### 15.17 Common Sync Operation Pattern

Every synchronization operation follows:

```text
Δ inspect primitive state
Ω check operation capability
Χ verify visibility
Ψ check synchronization policy
∇ mutate primitive state if possible
Σ commit mutation / wakeup / RAcc update
Λ wait or timeout if not possible
Φ handle invalid state or policy fault
```

Canonical success path:

```text
Δ ; Ω ; Χ ; Ψ ; ∇ ; Σ
```

Canonical blocking path:

```text
Δ ; Ω ; Χ ; Ψ ; Θ ; Λ ; Θ ; ∇ ; Σ
```

When entered through syscall, the operation is enclosed by the PMS-OS syscall ABI:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

### 15.18 Mutex

A mutex is a `SyncFrame` with:

```text
state = (
    locked ∈ {0,1},
    owner,
    recursion,
    waiters
)
```

#### Lock success

```text
Δ check locked = 0
Ω check LOCK capability
Χ check visibility
Ψ check policy
∇ locked := 1
∇ owner := current_tid
Σ commit lock
Σ commit RAcc update where required
```

Canonical word:

```text
Δ ; Ω ; Χ ; Ψ ; ∇ ; Σ
```

#### Lock blocking path

If locked:

```text
Δ locked = 1
Ω check WAIT capability
Θ enqueue current_tid in waiters
thread state := BLOCKED
Λ wait until unlock or timeout
```

Wake-up:

```text
unlock event
→ Θ select waiter
→ READY
→ retry lock or transfer ownership
```

#### Unlock

```text
Δ verify owner = current_tid
Ω check UNLOCK capability
Ψ check unlock policy
∇ locked := 0
∇ owner := null
Θ select next waiter if any
Σ commit unlock and wake
Σ commit RAcc update where required
```

Invalid unlock:

```text
not owner
unknown mutex
quarantined mutex
policy violation
```

produces Φ or Ψ denial.

### 15.19 Semaphore

A semaphore is a `SyncFrame` with:

```text
state = (
    count,
    max,
    waiters
)
```

#### Wait / down

```text
Δ compare count > 0
Ω check WAIT capability
Χ check visibility
Ψ check policy
```

If count is positive:

```text
∇ count := count - 1
Σ commit wait
```

If count is zero:

```text
Θ enqueue waiter
Λ wait or timeout
```

#### Signal / up

```text
Δ verify count < max
Ω check SIGNAL capability
Ψ check policy
∇ count := count + 1
Θ wake waiter if present
Σ commit signal
Σ commit RAcc update where required
```

Policy may enforce:

```text
FIFO order
bounded waiting
priority inheritance
maximum count
no signal without ownership
```

### 15.20 Reader/Writer Lock

An RW-lock is a `SyncFrame` with:

```text
state = (
    readers,
    writer_active,
    reader_waiters,
    writer_waiters,
    preference
)
```

Read-lock:

```text
Δ writer_active = false
Ω check READ_LOCK capability
Χ check visibility
Ψ check policy
∇ readers := readers + 1
Σ commit
```

Write-lock:

```text
Δ readers = 0 ∧ writer_active = false
Ω check WRITE_LOCK capability
Χ check visibility
Ψ check policy
∇ writer_active := true
Σ commit
```

If the lock cannot be acquired:

```text
Θ enqueue waiter
Λ wait / timeout
```

Policy may define:

```text
reader preference
writer preference
FIFO fairness
maximum read-hold time
priority inheritance
```

### 15.21 Futex-Like Primitives

A futex-like primitive splits synchronization into a user-space fast path and a kernel slow path.

Fast path:

```text
Δ compare memory word
Ω check access rights
Χ check address-space visibility
∇ atomic modification
Σ commit local synchronization state
```

Slow path:

```text
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel and futex-word boundary
→ Δ validate futex word and expected value
→ Ψ check policy
→ Θ enqueue waiter
→ Λ wait or timeout
→ Ψ postcheck
→ Φ return
```

Wake path:

```text
Φ syscall entry
→ Ω check caller authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel and futex-word boundary
→ Δ identify waiters
→ Ψ check wake policy
→ Θ move selected waiters to READY
→ Σ commit wake and RAcc update where required
→ Ψ postcheck
→ Φ return
```

Futex-like primitives are appropriate for userland threading because uncontended cases avoid kernel blocking while preserving OS-level structure for contended cases.

The syscall slow path follows the PMS-OS syscall ABI, not the ordinary PMS-CPU function calling convention.

### 15.22 Condition Variables

A condition variable is a `SyncFrame` with:

```text
state = (
    waiters
)
```

Wait operation:

```text
Δ verify associated mutex is held
Ω check WAIT capability
Ψ check policy
∇ release mutex
Θ enqueue thread on condition waiters
Λ wait until signal/broadcast/timeout
Θ resume
∇ reacquire mutex
Σ commit resumed state
Σ commit RAcc update where required
```

Signal:

```text
Δ inspect waiters
Ω check SIGNAL capability
Θ select one waiter
Σ commit wake
```

Broadcast:

```text
Δ inspect waiters
Ω check BROADCAST capability
Θ select all or policy-defined subset
Σ commit wake set
```

Φ handles:

```text
invalid mutex relation
owner death
timeout-as-exception
policy violation
invalid wakeup
```

### 15.23 Barriers and Event Counters

A barrier synchronizes multiple threads at a point.

```text
BarrierFrame = (
    threshold,
    arrived,
    waiters,
    generation,
    policy,
    RAcc_ref,
    meta
)
```

Arrive:

```text
Δ classify generation
Ω check ARRIVE capability
∇ arrived := arrived + 1
Σ commit RAcc update where required
```

If:

```text
arrived < threshold
```

then:

```text
Θ enqueue waiter
Λ wait
```

If:

```text
arrived = threshold
```

then:

```text
Θ wake waiters
Σ commit generation advance
```

Event counters provide lightweight readiness tracking.

```text
EventCounterFrame = (
    counter,
    waiters,
    policy,
    RAcc_ref,
    meta
)
```

Increment:

```text
∇ counter := counter + 1
Θ wake eligible waiters
Σ commit
```

Wait:

```text
Δ compare counter with expected
Λ wait if not advanced
```

### 15.24 Synchronization Policy

Ψ governs synchronization behavior.

Policies may enforce:

```text
FIFO lock acquisition
bounded waiting
maximum lock hold time
priority inheritance
deadlock detection
owner-death recovery
nonblocking-only domains
no sleeping in interrupt context
no blocking while holding specified locks
lock hierarchy ordering
cross-domain sync restrictions
RAcc limits for waiters, locks, or hold-time windows
```

Example policies:

```text
Ψ_no_thread_waiting_forever
Ψ_writer_priority
Ψ_fifo_semaphore
Ψ_no_block_in_irq
Ψ_lock_order(lock_a before lock_b)
Ψ_timeout_required_for_untrusted_wait
```

Policy violations may produce:

```text
denial
timeout
priority adjustment
Φ deadlock handler
process kill
lock quarantine
audit record
```

### 15.25 Deadlock and Stalled Synchronization

Deadlock is modeled as an invalid or policy-forbidden wait graph.

```text
WaitGraph = (Threads, SyncFrames, Edges)
```

Deadlock detection:

```text
Δ identify cycle in WaitGraph
Ψ classify cycle as forbidden
Φ enter deadlock handler
```

Responses:

```text
timeout one waiter
abort transaction
kill selected process
release quarantined lock under policy
escalate to kernel recovery
commit audit event
```

Stalled synchronization may instead be Λ:

```text
expected progress absent
```

Policy determines whether this remains a wait, becomes a timeout, or becomes a Φ event.

Deadlock recovery is an OS-level scheduler/synchronization response.

It is not moral judgment, forensic attribution, or governance authority.

### 15.26 Events as Transition Triggers

An event is a typed transition trigger.

```text
Event = (
    id,
    kind,
    payload,
    source,
    target,
    policy,
    RAcc_delta,
    meta
)
```

where:

| Field        | Meaning                                                            |
| ------------ | ------------------------------------------------------------------ |
| `id`         | event identifier                                                   |
| `kind`       | TIMER, SIGNAL, DEVICE, IPC, POLICY, PROCESS, DRIVER, FS, CUSTOM    |
| `payload`    | event-specific data                                                |
| `source`     | process, device, timer, kernel, driver, filesystem, policy engine  |
| `target`     | process, thread, endpoint, event frame, handler                    |
| `policy`     | routing, permission, masking, delivery policy                      |
| `RAcc_delta` | resource-accounting impact of enqueue, delivery, retry, or backlog |
| `meta`       | τ timestamp/order data, priority, retry, Λ flags, Φ state          |

Events do not mutate target state directly.

They request that a handler run an operator-typed sequence.

### 15.27 Event Frames

Events are stored and routed through `EventFrames`.

```text
EventFrame = (
    queue,
    routing,
    filters,
    perms,
    policy,
    RAcc_ref,
    meta
)
```

where:

| Field      | Meaning                                             |
| ---------- | --------------------------------------------------- |
| `queue`    | Θ-ordered event list                                |
| `routing`  | event kind → handler/endpoint                       |
| `filters`  | policy filters, masks, subscriptions                |
| `perms`    | Ω event send/receive rights                         |
| `policy`   | delivery, rate, masking, default-action policy      |
| `RAcc_ref` | resource-accounting reference for queue and backlog |
| `meta`     | τ data, error counters, ordering tags, last Φ state |

`EventFrame` visibility is Χ-governed.

A process receives events only from frames visible to its OS-level domain and permitted by Ω and Ψ.

### 15.28 Timer Events

Timers use τ-derived data and Θ ordering.

A timer is:

```text
Timer = (
    id,
    deadline,
    mode,
    callback,
    active,
    policy,
    RAcc_ref,
    meta
)
```

Timer registration:

```text
Δ classify timer parameters
Ω check create-timer capability
Ψ check timer policy
∇ install deadline in timer state
Σ commit registration
Σ commit RAcc update where required
```

Timer activation:

```text
Θ timer check point
Δ compare τ.now ≥ deadline
if true:
    Θ enqueue timer event
    Σ commit event visibility
```

Timer miss or lateness:

```text
Λ timer_missed
```

Possible responses:

```text
deliver late
reschedule
drop
escalate through Φ
audit
terminate under policy
```

Important distinction:

```text
τ stores or represents timing/accounting data.

Θ orders when the kernel samples, compares, and dispatches timer state.
```

### 15.29 Signals

Signals are asynchronous notifications.

```text
SignalFrame = (
    pending,
    handlers,
    perms,
    policy,
    RAcc_ref,
    meta
)
```

Sending a signal:

```text
Δ classify signal kind
Ω check SEND_SIGNAL capability
Χ check target visibility
Ψ check signal policy
Θ enqueue into target pending set
Σ commit signal enqueue
Σ commit RAcc update where required
```

Delivering a signal:

```text
Θ scheduling boundary
Δ pending ≠ ∅
Ω verify process may receive
Ψ check masks/default action
Θ dequeue selected signal
Φ enter signal-handler frame
execute handler
Σ return to main frame
```

Failed delivery:

```text
Λ signal_not_delivered
```

or:

```text
Φ redirect / default action / terminate
```

Signals are therefore not unstructured interrupts into user code.

They are Φ-mediated recontextualizations governed by event and policy state.

### 15.30 Pub-Sub Topics

A pub-sub topic is a `TopicFrame`.

```text
TopicFrame = (
    topic_id,
    subscribers,
    backlog,
    perms,
    policy,
    RAcc_ref,
    meta
)
```

Publish:

```text
Δ classify topic
Ω verify PUBLISH permission
Χ check topic visibility
Ψ check publish policy and quota
∇ append message to topic backlog
Σ commit publication
Σ commit RAcc update where required
Θ enqueue delivery events for subscribers
```

Subscribe:

```text
Δ identify topic
Ω verify SUBSCRIBE permission
Ψ check subscription policy
∇ add subscriber
Σ commit subscription
```

Delivery:

```text
Δ classify message
Θ schedule subscriber delivery
Ω verify RECEIVE permission
Χ verify subscriber visibility
∇ deliver into mailbox/channel/event frame
Σ commit delivery
```

Subscriber unavailable:

```text
Λ subscriber_unavailable
```

Policy may choose:

```text
drop
retry
buffer
reroute
dead-letter
signal
quarantine topic
```

`TopicFrames` may be isolated by namespace, container, role, trust zone, or policy class.

This section defines local OS pub-sub behavior.

Global pub-sub belongs in `07_distributed_systems.md`.

### 15.31 Event Router

The kernel event router coordinates event delivery.

```text
EventRouter = (
    routing_table,
    filters,
    perms,
    backlog,
    policy,
    RAcc_ref,
    meta
)
```

Processing loop:

```text
Θ advance routing cycle
Δ inspect event queues
Ω verify event authority
Χ verify route visibility
Ψ evaluate routing policy
Θ select destination
∇ enqueue or deliver event
Σ commit routing state
Σ commit RAcc update where required
Φ on invalid target or routing failure
```

The router handles:

```text
timers
signals
device events
driver completions
IPC notifications
policy events
filesystem events
process lifecycle events
resource quota events
```

### 15.32 Interrupt-to-Message Unification

Interrupts may be surfaced as events or messages in the OS model.

Path:

```text
Φ interrupt entry
Δ identify interrupt cause
Ω check driver/event authority
Θ schedule handler or bottom-half
∇ construct event/message
Σ commit into EventFrame or MessageFrame
Σ commit RAcc/audit update where required
Θ wake target thread
```

This unifies:

```text
hardware-origin events as modeled by OS interrupt entry
software signals
IPC messages
timer expirations
device completions
policy notifications
```

The kernel may deliver an interrupt-derived event through a mailbox, signal frame, event frame, or driver completion queue.

This is an OS-level interrupt-to-event model.

It does not claim physical interrupt-controller implementation or fabricated hardware behavior.

### 15.33 Event Delivery Guarantees

Events may use the same delivery policies as messages.

Delivery profiles:

```text
best effort
at-most-once
at-least-once
exactly-once within one node
coalesced
edge-triggered
level-triggered
persistent backlog
latest-value-only
```

Examples:

```text
timer tick may be coalesced
policy violation event should be committed and audited
device completion should be delivered once
filesystem watch event may be best-effort
signal may be pending/coalesced
```

Guarantees are Ψ policies over Θ ordering and Σ commit.

`Exactly-once within one node` is a single-node OS profile.

Remote exactly-once delivery belongs to `07_distributed_systems.md`.

### 15.34 Event Failure and Absence

Event absence is Λ.

Examples:

```text
timer did not fire before deadline
message did not arrive
device completion absent
subscriber unavailable
signal target dead
condition never became true
```

Λ outcome:

```text
expected event absent in current ordered interval
```

Policy chooses:

```text
continue waiting
timeout
retry
return no-event
escalate through Φ
isolate endpoint
terminate relation
audit
```

### 15.35 Policy over IPC, Sync, and Events

Ψ governs:

```text
who may communicate
which endpoints are visible
which capabilities may transfer
how queues are bounded
how waiters are ordered
which timeouts apply
which signals are masked
which events are delivered
which messages are audited
which locks may be held together
which topics are visible
which delivery guarantees apply
which RAcc constraints apply
```

Policy examples:

```text
process in sandbox cannot send to host topic
driver may publish only device-specific events
container cannot subscribe to host filesystem events
signal delivery denied across namespace boundary
IPC queue limited to N bytes per τ-window
mutex wait requires timeout in untrusted domain
no blocking in interrupt top-half context
```

Policy decisions may result in:

```text
ALLOW
DENY
DEFER
MODIFY
DROP
COALESCE
RETRY
ISOLATE
ESCALATE
HALT
AUDIT
```

Policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

### 15.36 Resource Accounting Integration

IPC, synchronization, and events consume resources.

Accounted resources include:

```text
message bytes
queue depth
endpoint count
waiter count
blocked-thread count
timer count
signal backlog
topic backlog
event backlog
sync object count
lock hold time
IPC rate per τ-window
event delivery rate
```

Accounting flow:

```text
Δ classify resource event
Ω verify accounting scope
Ψ check quota
∇ update RAcc
Σ commit accounting
Ψ post-check
```

Quota violations may produce:

```text
Λ no-buffer/no-space
Θ throttling
Ψ denial
Φ quota handler
Χ endpoint quarantine
Σ audit
```

Correct notation:

```text
RAcc.ipc.queue_bytes
RAcc.ipc.max_queue_bytes
RAcc.ipc.message_count
RAcc.ipc.max_messages
RAcc.events.backlog
RAcc.sync.waiters
```

Incorrect notation:

```text
RF.ipc.queue_bytes
RF.events.backlog
SystemRF
ProcessRF
ThreadRF
```

`RF` is reserved for PMS-CPU `RegisterFile`.

It must not denote resource accounting in PMS-OS.

### 15.37 Interaction with Scheduling

IPC and synchronization directly affect scheduling.

Examples:

```text
receive with no message     → BLOCKED via Λ/Θ
message arrival             → READY via Θ
mutex unavailable           → BLOCKED via Θ/Λ
unlock                      → wake waiter via Θ
timer expiration            → READY or signal handler via Θ/Φ
device completion event     → wake blocked thread
policy event                → suspend or recontextualize process
```

Scheduling relation:

```text
IPC/event state changes ReadySet
Sync state changes WaitGraph
Θ selects runnable consequences
```

A wakeup is valid only if:

```text
target thread exists
∧ wait condition resolved
∧ policy permits wake
∧ boundary permits delivery
∧ resource state permits execution
```

The resource-state check is expressed through `RAcc`, not `RF`.

### 15.38 Interaction with Syscalls

Most IPC, synchronization, and event operations are entered through syscalls.

Examples:

```text
sendmsg
recvmsg
poll
select-like wait
futex_wait
futex_wake
timer_create
timer_set
signal_send
event_subscribe
channel_create
channel_close
```

All such syscalls follow the canonical PMS-OS syscall contract defined in Section 8:

```text
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded for IPC, synchronization, and events:

```text
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, endpoint, sync-object, topic, signal, timer, or event boundary
→ Δ classify operation and endpoint/object/event
→ Ψ check policy, quota, and delivery/synchronization constraints
→ IPC/sync/event operation
→ Σ commit delivery, wakeup, object state, audit, or RAcc state where required
→ Ψ postcheck
→ Φ return
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

### 15.39 Interaction with Filesystem and Devices

Filesystem exposure:

```text
named pipe
socket node
event file
device node
watch handle
```

A filesystem path may resolve to an IPC or event frame.

```text
path → FrameId → MessageFrame / EventFrame / SyncFrame
```

Device exposure:

```text
driver completion queues
device event frames
interrupt-derived messages
hotplug events
```

Device events follow:

```text
Φ interrupt
→ Δ classify cause
→ Θ schedule handler
→ Σ commit event
→ IPC/Event delivery
```

This is local PMS-OS filesystem/device interaction.

Distributed device events and cross-node event routing belong to `07_distributed_systems.md`.

### 15.40 Audit and Trace

IPC, synchronization, and event operations may emit audit records.

```text
CommAuditRecord = (
    event_id,
    actor,
    role,
    source,
    target,
    object_frame,
    operation,
    operator_class,
    decision,
    state_before,
    state_after,
    commit_result,
    resource_accounting_result,
    timestamp_or_order,
    metadata
)
```

Auditable events include:

```text
message send/receive
capability transfer
policy-denied message
cross-domain IPC
queue overflow
sync object creation
lock timeout
deadlock detection
signal delivery
timer miss
event publish/subscribe
interrupt-derived event
endpoint quarantine
resource-accounting violation
```

Audit flow:

```text
Δ prepare audit record
Σ commit audit record
Ψ enforce retention and integrity
```

A concrete IPC/synchronization/event trace is:

```text
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The declared communication execution space is:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Trace emission is implementation-specific.

Operator-labeled representability is the architectural requirement.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 15.41 IPC, Sync, and Event Invariants

PMS-OS maintains the following communication and coordination invariants.

```text
I1: every IPC endpoint is represented as a valid frame

I2: every message send is Δ-classified before enqueue or delivery

I3: every protected send/receive is Ω-authorized

I4: every endpoint visibility relation is Χ-permitted

I5: every queue mutation is ∇-represented

I6: delivery guarantees are backed by explicit Σ semantics

I7: absence of a message, event, or resource is represented through Λ

I8: blocking operations create explicit wait state

I9: wakeups are Θ-ordered and policy-valid

I10: synchronization objects are valid SyncFrames

I11: lock, semaphore, and channel state changes are committed through Σ

I12: timeout behavior is based on τ-derived data and Θ ordering

I13: signals and exceptional notifications recontextualize through Φ

I14: capability transfer through messages is Ω/Ψ-governed

I15: cross-domain communication requires explicit Χ visibility

I16: policy-denied communication has a defined Ψ/Φ/Λ response

I17: resource accounting is updated through RAcc for queues, endpoints,
     waits, timers, signals, topics, sync objects, and events

I18: no IPC, sync, or event fast path bypasses Ω, Χ, Ψ, or required RAcc
     constraints

I19: RAcc / ResourceAccount is the resource-accounting notation

I20: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I21: X_endpoint, X_sender, X_receiver, X_topic, X_channel, X_event, X_p,
     X_user, X_global, and related X_* symbols are OS-level
     isolation-domain values, not PMS Base Χ

I22: PMS Base Χ = Distance

I23: PMS-OS projects Χ as process isolation, endpoint visibility,
     namespace boundary, communication reachability, IPC visibility,
     synchronization-object sharing, signal/event visibility,
     sandbox/container boundary, and reachability control

I24: τ denotes time/accounting metadata, not a PMS Base operator

I25: IPC, synchronization, and event traces remain operator-labeled and
     belong to L_PMS or L_PMS,Ψ_kernel under the declared OS profile

I26: delivery guarantees in this section are single-node PMS-OS guarantees
     unless explicitly lifted by 07_distributed_systems.md
```

### 15.42 Boundary to Distributed Systems

This section defines single-node PMS-OS IPC, synchronization, and event semantics.

It does not fully define:

```text
cross-node channels
distributed consensus
cluster-wide event ordering
remote exactly-once delivery
distributed locks
global pub-sub
distributed failure detectors
quorum-based Σ
network partitions
replicated event logs
remote capability transfer
distributed policy synchronization
distributed audit consensus
```

Those belong in `07_distributed_systems.md`.

This section provides the local OS substrate that distributed PMS systems may lift into cluster-level semantics.

Boundary:

```text
04_pms_os.md defines local PMS-OS communication, synchronization, and event
substrates.

07_distributed_systems.md defines cross-node messaging, distributed delivery
guarantees, cluster events, remote consensus, distributed locks, replicated
logs, distributed failure semantics, and distributed policy synchronization.
```

### 15.43 Architectural Consequence

PMS-OS communication and synchronization are structurally unified.

The consequence is:

```text
A PMS-OS communication object is a frame-governed coordination locus:
messages, locks, queues, channels, timers, signals, notifications, and
events all operate through explicit distinction, authority, boundary,
ordering, absence, resource accounting, mutation, commit,
recontextualization, and policy constraints.
```

This gives PMS-OS a unified model for IPC, synchronization, wait states, timers, signals, pub-sub, interrupt-to-process delivery, event routing, capability transfer, and communication policy.

### 15.44 Boundary Statement

The correct boundary for this chapter is:

```text
The PMS-OS IPC, synchronization, and event model specifies single-node
MessageFrames, SyncFrames, EventFrames, TopicFrames, SignalFrames,
TimerFrames, channels, queues, mailboxes, message delivery, capability
transfer, delivery guarantees, blocking and nonblocking receive,
synchronization primitives, wait graphs, timers, signals, pub-sub,
interrupt-to-message delivery, resource accounting, syscall interaction,
audit representability, and communication invariants through Δ–Ψ operator
structure.

This is an OS-level IPC, synchronization, and event architecture claim.

It does not claim distributed messaging semantics, cross-node delivery
guarantees, distributed locks, cluster-wide event ordering, remote
exactly-once delivery, replicated event logs, physical interrupt-controller
implementation, external security validation, governance authority,
forensic authority, moral judgment, or PMS Base validation.
```

---

## 16. Device and Driver Lifecycle

PMS-OS defines devices and drivers as governed, role-bearing, frame-bound kernel subsystems.

A device is represented as a frame. A driver is represented as a role-constrained execution locus with explicit capabilities, lifecycle state, interrupt paths, resource budgets, isolation boundaries, recovery paths, and policy attachments.

The central device/driver lifecycle claim is:

```text id="zx8n8d"
PMS-OS treats devices and drivers as □-framed, Ω-governed,
Χ-isolated, Θ-ordered, RAcc-accounted, Φ-recontextualized,
Σ-committed, Λ-aware, and Ψ-constrained kernel agents whose lifecycle
transitions are explicit operator-typed state changes.
```

Claim type:

```text id="kzjepi"
OS-level device and driver lifecycle architecture claim
```

Boundary:

```text id="zffj5f"
This section specifies PMS-OS device and driver lifecycle architecture.

It does not claim production driver implementation.

It does not claim fabricated hardware.

It does not claim a complete production device-driver framework.

It does not claim external driver certification.

It does not claim external security validation.

It does not validate PMS Base.
```

This section defines the general device and driver lifecycle. Block storage and storage-driver I/O were defined in Section 13. IPC/event delivery from devices was defined in Section 15. Runtime-security hardening is refined in `06_runtime_security.md`.

A concrete PMS-OS device/driver lifecycle execution produces:

```text id="w4jdlw"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="id0wj0"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible device/driver lifecycle executions is:

```text id="rck4dl"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="qfxys6"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text id="wtvhi1"
RAcc = ResourceAccount
```

`RF` must not be used for device or driver resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

### 16.1 Device and Driver Entities

PMS-OS distinguishes four primary entities.

```text id="ahvnge"
Device
Driver
Binding
DriverContext
```

A device is a kernel-visible endpoint:

```text id="ggbsak"
Device = (DeviceFrame, DeviceClass, Topology, State, Policy, DeviceRAcc)
```

A driver is a governed execution agent:

```text id="urczcp"
Driver = (DriverFrame, Role, Capabilities, Policy, Lifecycle, DriverRAcc, Meta)
```

A binding connects a driver to a device:

```text id="xz8uaf"
Binding = (DriverId, DeviceId, BindingState, Capabilities, Policy, RAccLinks, Meta)
```

A driver context is a runtime locus of execution:

```text id="hqu5kt"
DriverContext = (
    irq_handlers,
    bottom_halves,
    workqueues,
    control_paths,
    buffers,
    RAcc_refs,
    recovery_state
)
```

These entities are not opaque kernel records. They are operator-bearing structures.

### 16.2 Device Frames

Every device is represented as a frame.

```text id="dncsk9"
DeviceFrame = (
    id,
    class,
    type,
    address,
    resources,
    perms,
    owner,
    ops,
    state,
    policy,
    DeviceRAcc,
    meta
)
```

where:

| Field        | Meaning                                                           |
| ------------ | ----------------------------------------------------------------- |
| `id`         | stable device identifier                                          |
| `class`      | block, network, input, display, bus, sensor, virtual, etc.        |
| `type`       | concrete device type or protocol family                           |
| `address`    | bus address, virtual endpoint, port, path, or topology coordinate |
| `resources`  | MMIO ranges, IRQs, DMA regions, queues, buffers                   |
| `perms`      | Ω-governed access permissions                                     |
| `owner`      | kernel, driver, VM, container, service, or subsystem              |
| `ops`        | supported device operations                                       |
| `state`      | present, active, suspended, degraded, removed, etc.               |
| `policy`     | device-specific Ψ constraints                                     |
| `DeviceRAcc` | resource account for device-visible resource use                  |
| `meta`       | τ data, hotplug state, health counters, audit tags                |

Device-frame validity requires:

```text id="ptfh1r"
device identity distinguished
∧ topology relation valid
∧ resource descriptors coherent
∧ access permissions defined
∧ policy attached
∧ OS isolation-domain boundary established
∧ driver binding state explicit
∧ DeviceRAcc coherent where accounting applies
```

`τ` denotes time/accounting metadata.

It is not introduced here as an additional PMS Base operator.

Θ orders when τ-derived metadata is sampled, compared, committed, or used.

### 16.3 Driver Frames

A driver has a dedicated driver frame.

```text id="jz0edv"
DriverFrame = (
    id,
    module,
    class,
    supported_devices,
    role,
    capabilities,
    ops,
    queues,
    resources,
    lifecycle,
    policy,
    DriverRAcc,
    meta
)
```

where:

| Field               | Meaning                                                          |
| ------------------- | ---------------------------------------------------------------- |
| `id`                | driver identifier                                                |
| `module`            | code and metadata artifact                                       |
| `class`             | device class served by the driver                                |
| `supported_devices` | match table or probe profile                                     |
| `role`              | Ω role assigned to the driver                                    |
| `capabilities`      | permitted operations                                             |
| `ops`               | probe, bind, read, write, control, IRQ, suspend, resume, recover |
| `queues`            | request, workqueue, bottom-half, completion queues               |
| `resources`         | memory, IRQs, DMA regions, device mappings                       |
| `lifecycle`         | current lifecycle state                                          |
| `policy`            | driver-specific Ψ constraints                                    |
| `DriverRAcc`        | resource account for driver execution and resource use           |
| `meta`              | τ budgets, audit metadata, error counters, version, trust data   |

The driver frame defines the context in which driver logic is interpreted.

```text id="ev687u"
driver execution = execution inside DriverFrame under assigned Ω role
```

This is an OS-level driver model.

It does not claim a production driver implementation.

### 16.4 Drivers as Ω-Structured Roles

A driver is not arbitrary privileged code.

A driver is a role-bearing execution locus:

```text id="cdvwe0"
D = (f_D, r_D, C_D, P_D, DriverRAcc)
```

where:

| Component    | Meaning                   |
| ------------ | ------------------------- |
| `f_D`        | driver frame              |
| `r_D`        | driver role               |
| `C_D`        | driver capability set     |
| `P_D`        | driver policy constraints |
| `DriverRAcc` | driver resource account   |

Driver action is valid only if:

```text id="p5mazn"
Ω(r_D, action, target) = allowed
∧ Χ permits target reachability
∧ Ψ permits the transition
∧ DriverRAcc permits resource-visible action where relevant
```

Examples:

```text id="ddxgiz"
Ω(r_D, read, DeviceRegister)
Ω(r_D, write, MMIOFrame)
Ω(r_D, ack, IRQLine)
Ω(r_D, dma_map, DMARegionFrame)
Ω(r_D, schedule, WorkQueue)
Ω(r_D, publish, EventFrame)
```

A driver cannot operate outside its declared capability graph.

### 16.5 Driver Capability Families

Driver capabilities fall into structural Ω families.

#### Access Capabilities

Access capabilities control which device objects the driver may distinguish and mutate.

```text id="kmejva"
Ω(read, register)
Ω(write, register)
Ω(read, config-space)
Ω(write, MMIO-range)
Ω(read, block)
Ω(write, packet-ring)
```

These constrain ∇ actions over Δ-distinguished targets.

#### Ordering and Dispatch Capabilities

Ordering capabilities control driver participation in Θ-governed execution.

```text id="bw3nzy"
Ω(allow_interrupt_handler)
Ω(allow_deferred_work)
Ω(timer_arm)
Ω(timeout_register)
Ω(workqueue_schedule)
```

These determine which scheduling, timeout, interrupt, and dispatch transitions a driver may initiate.

#### Contextual Capabilities

Contextual capabilities govern frame operations.

```text id="p0jt3t"
Ω(enter_driver_frame)
Ω(map_device_frame)
Ω(switch_to_config_frame)
Ω(create_request_frame)
```

Without contextual capability, a driver cannot perform □ transitions that alter device or driver context.

#### Isolation Capabilities

Isolation capabilities govern Χ transitions.

```text id="ixgyy0"
Ω(spawn_io_sandbox)
Ω(access_ringbuffer_subset)
Ω(allow_dma_scope)
Ω(enter_device_domain)
Ω(exit_quarantine_context)
```

These define which boundary transformations are legal for the driver.

At PMS Base level:

```text id="fqp7bg"
Χ = Distance
```

At PMS-OS level, Χ projects as device boundary, DMA boundary, driver reachability, MMIO visibility, event visibility, and sandbox/container boundary.

Concrete driver/device symbols such as:

```text id="yfj259"
X_device
X_driver
X_dma
X_irq
X_bus
```

are OS-level isolation-domain values.

They are not PMS Base Χ.

#### Policy Capabilities

Policy capabilities govern limited policy interaction.

```text id="z5sxr3"
Ω(apply_power_policy)
Ω(change_error_policy)
Ω(register_policy_hook)
Ω(set_device_mode)
```

Policy capabilities never allow arbitrary weakening of kernel invariants.

### 16.6 Driver–Kernel Asymmetry

The kernel and drivers form an Ω asymmetry graph.

```text id="kkzmg4"
Ω(kernel) ⊇ Ω(driver) ⊇ Ω(device)
```

More explicitly:

```text id="oc4fhx"
r_K       = kernel role
r_D       = driver role
r_dev     = device-local role
C_K       = kernel capability set
C_D       = driver capability set
C_dev     = device-local capability set
```

Invariant:

```text id="fzbdwh"
C_dev ⊆ C_D ⊆ C_K
```

This does not mean every driver has the same authority. It means driver authority is a bounded subset of kernel authority and a structured superset of raw device operation.

Driver authority is real, but capability-scoped.

### 16.7 Driver Modules

A driver may be decomposed into modules.

```text id="clw377"
DriverModule = (ModuleFrame, ModuleRole, ModuleCaps, ModulePolicy, ModuleRAcc)
```

Typical modules:

```text id="v8azg5"
init module
probe module
IRQ top-half module
bottom-half module
data-path module
control-plane module
power-management module
recovery module
```

Each module may have a different capability subset.

Examples:

```text id="gicwy0"
IRQ top half:
    may ack IRQ
    may read status registers
    may enqueue bottom-half work
    may not block
    may not perform unbounded allocation

bottom half:
    may allocate within budget
    may perform I/O completion
    may wake waiters
    may publish events

control plane:
    may configure device
    may change modes
    may process privileged ioctl-like requests
```

This supports least-authority driver design without treating the driver as one undifferentiated privilege blob.

### 16.8 Device–Driver Binding

Binding attaches a driver to a device.

```text id="f4tggc"
Bind(D, Dev)
```

Binding is a kernel-mediated transition.

Canonical binding sequence:

```text id="vs1u0v"
Δ identify device
Δ identify driver
Ω verify driver may bind this device
Ψ evaluate device/driver policy
□ create or activate DriverFrame
□ map DeviceFrame resources
Χ establish device/driver isolation boundary
Σ initialize or link DriverRAcc / DeviceRAcc
Σ commit binding
```

Binding result:

```text id="e2q6rd"
Binding = (D, Dev, BOUND, C_D_for_Dev, Ψ_eff, RAccLinks, meta)
```

No driver may bind itself to a device without kernel mediation.

### 16.9 Effective Driver Policy

Driver execution is governed by an effective policy.

```text id="mq3d46"
Ψ_eff(D, Dev) =
    Ψ_kernel
    ∧ Ψ_device_class(Dev.class)
    ∧ Ψ_driver(D)
    ∧ Ψ_device(Dev)
    ∧ Ψ_binding(D, Dev)
```

Policy may constrain:

```text id="rns7vb"
trust level
driver signature or provenance
allowed device classes
allowed MMIO ranges
allowed DMA regions
IRQ budget
bottom-half budget
workqueue budget
memory budget
power policy
error policy
hotplug policy
audit level
quarantine mode
DriverRAcc limits
DeviceRAcc limits
```

A driver action is valid only when the effective policy permits it.

The policy engine constrains OS-level driver behavior.

It does not provide external security validation or driver certification.

### 16.10 Driver Lifecycle States

PMS-OS defines the following driver lifecycle states.

```text id="a5zpkg"
UNINSTALLED
INSTALLED
LOADED
PROBED
BOUND
ACTIVE
SUSPENDED
DEGRADED
QUIESCING
QUARANTINED
UNLOADING
UNLOADED
ERROR
```

State meanings:

| State         | Meaning                                                           |
| ------------- | ----------------------------------------------------------------- |
| `UNINSTALLED` | driver artifact absent from the OS                                |
| `INSTALLED`   | artifact known and registered but not mapped for execution        |
| `LOADED`      | code and metadata mapped into kernel/driver frames                |
| `PROBED`      | candidate devices have been inspected                             |
| `BOUND`       | driver is attached to at least one device                         |
| `ACTIVE`      | driver handles live requests, IRQs, events, or control operations |
| `SUSPENDED`   | driver/device quiesced, often for power or lifecycle reasons      |
| `DEGRADED`    | driver remains available with reduced capability or error mode    |
| `QUIESCING`   | driver is draining work before detach, suspend, or unload         |
| `QUARANTINED` | driver isolated; normal operation forbidden                       |
| `UNLOADING`   | teardown is in progress                                           |
| `UNLOADED`    | driver detached; code/resources reclaimed                         |
| `ERROR`       | invalid or failed lifecycle state requiring policy handling       |

Each state has valid incoming and outgoing transitions.

Lifecycle state is not advisory metadata; it constrains legal driver operations.

### 16.11 Install and Load

Installation registers a driver artifact.

```text id="wwov0e"
UNINSTALLED → INSTALLED
```

Install flow:

```text id="lb8qr3"
Δ identify driver artifact
Δ classify driver class, version, supported devices
Ω verify install authority
Ψ check install policy
Σ commit registry entry
```

Loading maps the driver into executable kernel/driver context.

```text id="xsmc9u"
INSTALLED → LOADED
```

Load flow:

```text id="m62qce"
Δ identify installed driver
Ψ check policy, trust, version, and compatibility
□ allocate and map driver code/data frames
Ω assign initial driver role
Σ initialize DriverRAcc
Σ commit DriverTable state
```

Load may fail if:

```text id="hrkg08"
artifact invalid
class denied
trust policy fails
resources unavailable
required capabilities impossible
policy rejects version
```

Failure response:

```text id="kz1kyt"
Λ unavailable resource
Φ load failure
Σ audit if enabled
```

This is an OS-level lifecycle specification.

It does not claim a completed production module loader or external driver certification.

### 16.12 Probe

Probe determines which devices the driver can handle.

```text id="tlpgo6"
LOADED → PROBED
```

Probe flow:

```text id="bm5w8z"
Δ enumerate candidate devices
Δ match device identity against driver profile
Ω verify bus/device access capability
Ψ check class and device policy
Θ order probe attempts
Λ timeout if probe response absent
Σ commit probe result
Σ commit DriverRAcc / DeviceRAcc update where required
```

Probe may read device descriptors, test protocol compatibility, or inspect bus topology.

Probe must be bounded by policy:

```text id="f3m7hi"
no unbounded probe loops
no unauthorized bus access
no probe outside driver class
probe timeout defined through τ-derived data and Θ ordering
```

### 16.13 Bind and Activate

Binding attaches the driver to a specific device.

```text id="u25yh1"
PROBED → BOUND
```

Bind flow:

```text id="m0dxp2"
Δ identify driver and device
Ω assign device-specific capabilities
□ create binding frame
□ map MMIO / I/O / config frames
Χ establish device isolation boundary
Ψ activate effective binding policy
Σ link DriverRAcc / DeviceRAcc
Σ commit binding
```

Activation starts live operation.

```text id="v2uzre"
BOUND → ACTIVE
```

Activation flow:

```text id="a8kc03"
Θ order activation sequence
Ω enable allowed interrupt and I/O capabilities
□ initialize request queues and buffers
Σ commit active state
Ψ check activation invariants
```

Activation may include:

```text id="dqmxkw"
register IRQ handlers
create workqueues
allocate DMA regions
publish device nodes
create event frames
register filesystem or network endpoints
```

### 16.14 Interrupt Handler Registration

A driver registers interrupt handling through kernel mediation.

```text id="a0mnaw"
register_irq_handler(irq, top_half, bottom_half, caps, policy)
```

Structural meaning:

```text id="mpngjv"
Δ identify IRQ and driver
Ω verify driver may handle IRQ
Ψ attach IRQ policy
□ bind handler into IRQ frame
Σ commit IRQ descriptor update
Σ commit DriverRAcc update where required
```

The resulting IRQ descriptor may include:

```text id="e8yq1o"
IRQDesc = (
    irq_id,
    priority,
    owner,
    top_half,
    bottom_half,
    policy,
    caps,
    RAcc_ref,
    meta
)
```

The driver may not receive interrupts until the IRQ descriptor is committed and policy-valid.

This is an OS-level IRQ registration model.

It does not claim physical interrupt-controller implementation.

### 16.15 Interrupt Path

Interrupts are Φ-driven recontextualizations.

General interrupt path:

```text id="sz5ijv"
device event
→ Δ classify IRQ
→ Φ CPU/kernel interrupt entry
→ Δ select IRQ descriptor
→ Ω verify driver capability
→ Ψ check IRQ policy
→ Θ order handler execution
→ top-half handler
→ Θ schedule bottom-half if required
→ Σ commit completion metadata
→ Σ commit RAcc/audit update where required
→ Φ return
```

The path is:

```text id="gi75d1"
Φ-centric
Θ-ordered
Ω-governed
Χ-isolated
Ψ-constrained
RAcc-accounted
Σ-integrated
```

Interrupts are not arbitrary asynchronous jumps.

They are typed context transitions at OS architecture level.

### 16.16 Top-Half Handler

A top-half handler runs in interrupt context.

Top-half constraints:

```text id="q9midr"
must be bounded
must not block
must not sleep
must not perform unbounded allocation
must use only IRQ-safe APIs
must stay within assigned capabilities
must stay within τ-derived execution budget
must return through defined interrupt path
```

Typical top-half structure:

```text id="njbmve"
Δ identify device status
Ω check register access
∇ acknowledge interrupt
∇ capture minimal status
Θ enqueue bottom-half work
Σ commit pending work item
Σ commit RAcc update where required
return
```

Top-half policy may enforce:

```text id="w6033y"
maximum τ-derived execution budget
maximum nesting level
allowed MMIO registers
no blocking syscalls
no pageable memory access
no unbounded allocation
```

Violation produces Φ recovery or driver quarantine.

Quarantine is an OS-level isolation response.

It is not moral judgment, forensic attribution, or governance authority.

### 16.17 Bottom-Half and Deferred Work

Heavy work is deferred to Θ-ordered contexts.

Deferred contexts include:

```text id="ie4v5n"
softirq-like context
kernel workqueue
driver worker thread
process-level completion path
```

Bottom-half flow:

```text id="mfo2cr"
Θ select deferred work item
Ω verify driver work capability
Ψ check work budget and policy
∇ process device state or request completion
Σ commit completion state
Σ commit RAcc update where required
Θ wake waiting threads
```

Bottom halves may perform work forbidden in top-half context if policy permits:

```text id="irt1pv"
allocation
blocking I/O
copy to user buffers
filesystem interaction
IPC notification
device recovery
```

### 16.18 Driver Workqueues

A workqueue is a scheduler-visible frame.

```text id="j4cjge"
WorkQueueFrame = (
    id,
    owner_driver,
    queue,
    worker_threads,
    policy,
    DriverRAcc,
    meta
)
```

Work item:

```text id="kayw71"
WorkItem = (
    id,
    handler,
    arg_frame,
    priority,
    deadline,
    policy,
    RAcc_delta,
    state
)
```

Workqueue dispatch:

```text id="cxh7ox"
Δ identify pending work
Ω verify work authority
Ψ check budget and state
Θ select work item
∇ execute handler
Σ commit result
Σ commit DriverRAcc update where required
```

Workqueue resources are charged to the driver/device resource account.

Correct notation:

```text id="sxopee"
DriverRAcc
DeviceRAcc
```

Incorrect notation:

```text id="xacjxd"
DriverRF
DeviceRF
```

### 16.19 Suspend and Resume

Drivers and devices may be suspended.

```text id="dn5mx6"
ACTIVE → SUSPENDED
SUSPENDED → ACTIVE
```

Suspend flow:

```text id="h1vkko"
Θ enter ordered suspend sequence
Ψ check suspend preconditions
Σ flush or complete outstanding work
Φ recontextualize device to suspended frame/state
Ω reduce active capabilities
Σ commit suspended state
Σ commit RAcc update where required
```

Suspend preconditions may include:

```text id="im7y0a"
no critical I/O pending
journal state stable
device queue drained or frozen
interrupts masked or redirected
DMA stopped
user-visible state consistent
```

Resume flow:

```text id="o1oun6"
Θ enter resume sequence
Ψ check resume policy
Φ recontextualize device to active state
Ω restore permitted capabilities
□ restore device/driver frames
Σ commit active state
Σ commit RAcc update where required
Θ wake waiters if needed
```

If resume fails:

```text id="j618jd"
SUSPENDED → DEGRADED
SUSPENDED → QUARANTINED
SUSPENDED → ERROR
```

depending on policy.

### 16.20 Quiescing

Quiescing drains driver activity before suspend, detach, reset, upgrade, or unload.

```text id="do1mp8"
ACTIVE → QUIESCING
```

Quiesce flow:

```text id="y0syr0"
Ψ decide quiesce requirement
Θ stop accepting new work
Θ drain existing queues
Σ commit completed requests
Σ commit RAcc update where required
Λ wait for outstanding events if needed
Φ handle stuck operations
```

Quiescing is complete when:

```text id="etpfyv"
no top-half active
∧ no bottom-half active
∧ no work item pending
∧ no DMA operation active
∧ no uncommitted critical state
∧ no unbounded external reference remains
```

### 16.21 Error and Degraded State

A driver enters degraded state when it remains usable under reduced assumptions.

```text id="aymfu1"
ACTIVE → DEGRADED
```

Causes:

```text id="f7w4cb"
repeated timeouts
partial device failure
capability violation
recoverable MMIO error
bad block or port failure
power-state error
driver budget exceeded
policy soft violation
```

Degraded transition:

```text id="yyzjh3"
Δ classify error
Ψ choose degraded mode
Φ recontextualize driver state
Χ strengthen isolation if required
Ω reduce capabilities if required
Σ commit degraded state
Σ commit RAcc/audit update where required
```

Degraded mode may allow:

```text id="bp1oeb"
read-only operation
reduced performance
single-path operation
safe-mode driver behavior
limited interrupt handling
diagnostic access
```

### 16.22 Quarantine

Quarantine is a stronger isolation state.

```text id="de6mnr"
DEGRADED → QUARANTINED
ACTIVE → QUARANTINED
ERROR → QUARANTINED
```

Quarantine flow:

```text id="zxpim5"
Ψ escalation policy triggers
Χ isolate driver and associated devices
Ω revoke or narrow capabilities
Θ stop scheduling ordinary work
Φ recontextualize pending requests to failure/recovery
Σ commit quarantine state
Σ audit if enabled
Σ commit RAcc update where required
```

Quarantined drivers may only perform explicitly permitted operations:

```text id="v3gagj"
introspection
controlled recovery
log extraction
policy-approved reset
unload
replacement
```

Quarantine is an OS-level isolation response.

It is not a forensic verdict.

It is not governance authority.

### 16.23 Unbind and Unload

Unbinding detaches a driver from a device.

```text id="lky6cw"
BOUND/ACTIVE/SUSPENDED/DEGRADED → UNBOUND relation
```

Unbind flow:

```text id="rv0xxl"
Θ quiesce driver/device activity
Ψ check unbind policy
Φ recontextualize device as unbound
Ω revoke device-specific capabilities
Χ remove device/driver reachability
Σ commit binding removal
Σ commit RAcc update where required
```

Unload removes the driver from execution context.

```text id="cl2mxn"
QUIESCING → UNLOADING → UNLOADED
```

Unload flow:

```text id="xdw23y"
Δ identify driver
Θ ensure no active contexts remain
Ψ check unload preconditions
Φ detach handlers and contexts
Χ remove isolation compartments
□ unmap driver code/data frames
Σ reclaim resources
Σ close or update DriverRAcc
Σ commit DriverTable update
Ψ post-check no dangling references
```

Unload is invalid if:

```text id="kf7p8g"
IRQ handler active
bottom-half pending
workqueue active
device binding live
DMA active
open references remain without policy-defined forced close
driver frame still reachable
```

### 16.24 Driver Upgrade and Replacement

Driver replacement is a Φ-mediated recontextualization.

```text id="er9hof"
D_old → D_new
```

Upgrade flow:

```text id="g1nrrc"
Δ identify old driver, new driver, and affected devices
Ψ check compatibility and trust policy
Θ quiesce old driver
Φ create migration context
□ map new driver frame
Ω assign new capabilities
∇ transform or transfer state if supported
Σ commit new binding
Σ initialize or migrate DriverRAcc where required
Χ isolate or unload old driver
Ψ post-check invariants
```

Possible outcomes:

```text id="tust98"
successful replacement
rollback to old driver
fallback driver bind
device quarantine
driver quarantine
policy denial
```

Replacement must preserve:

```text id="a9ri2h"
no lost in-flight I/O unless policy permits abort
no leaked capabilities
no dangling IRQ handlers
no stale DMA mappings
no uncommitted device state
resource-accounting state coherent
```

### 16.25 Hotplug Attach

Hotplug attach is a Φ-driven topology recontextualization.

Attach pipeline:

```text id="qysgem"
Φ external attach event
Δ identify bus and device
Ψ check hotplug policy
□ create DeviceFrame
Δ enumerate descriptors
Ω verify driver/bus authority
Ψ filter candidate drivers
Φ bind selected driver
Σ initialize DeviceRAcc where required
Σ commit device registration
Θ notify dependent subsystems
```

Detailed attach stages:

1. External event arrives.

```text id="n6124s"
Φ_ext_attach
```

2. Device is distinguished.

```text id="s9e3o8"
Δ_identify(Device)
```

3. Device frame is created.

```text id="xuqoi0"
□ create DeviceFrame
```

4. Policy checks attach permission.

```text id="ou0scb"
Ψ_hotplug(Device)
```

5. Candidate drivers are probed.

```text id="g6qjxf"
Δ_match(Driver, Device)
Ω_cap_check(Driver, Bus)
Ψ_driver_device(Driver, Device)
```

6. Binding is committed.

```text id="fm5647"
Σ_commit_binding
```

7. Device becomes visible.

```text id="cs3z7o"
Σ_system_namespace_update
```

Attach may be rejected and isolated if policy fails.

```text id="t8zcbr"
Ψ deny attach
→ Φ reject
→ Χ isolate device
→ Σ audit
```

This is OS-level hotplug architecture.

It does not claim physical bus behavior or fabricated hardware.

### 16.26 Hotplug Detach

Hotplug detach removes or invalidates a device.

Detach pipeline:

```text id="wyy2ki"
Φ external detach event
Λ detect absence if needed
Ψ check detach policy
Θ quiesce queues and handlers
Σ commit completed work
Φ unbind driver/device relation
Χ isolate stale frames
□ remove DeviceFrame visibility
Σ commit detach
Σ close or update DeviceRAcc where required
Ψ post-check no dangling references
```

Detach policy may distinguish:

```text id="liflrh"
clean detach
forced detach
surprise removal
unsafe detach
critical device loss
```

If pending work exists:

```text id="s8lybj"
flush
abort
rollback
fail requests
switch to degraded mode
quarantine driver/device
halt under critical policy
```

### 16.27 Topology Reconfiguration

Some devices alter topology rather than simply attach or detach.

Examples:

```text id="e6p4xs"
USB hub reset
PCIe bridge change
Thunderbolt chain reconfiguration
network link up/down
virtual device remapping
multi-function device mode switch
```

Topology change flow:

```text id="m85g2i"
Φ topology event
Δ classify changed topology
Ψ check topology policy
□ update device and bus frames
Ω adjust capabilities
Χ update reachability boundaries
Σ commit topology state
Σ commit RAcc update where required
Θ notify affected subsystems
```

Topology policy must prevent:

```text id="r1acgw"
device aliasing
unauthorized bus path
cross-domain exposure
stale capability reuse
driver access to removed resources
```

This is an OS-level topology model.

It does not claim physical bus implementation.

### 16.28 Virtual Devices

Virtual devices follow the same lifecycle as physical-device models.

```text id="gxy7oi"
VirtualDeviceFrame = (
    id,
    backend,
    class,
    resources,
    owner,
    policy,
    DeviceRAcc,
    state,
    meta
)
```

Examples:

```text id="i3xlbt"
RAM disk
loop device
virtual network interface
virtual console
guest device
synthetic timer
memory-backed block device
remote-backed device
```

Virtual-device lifecycle:

```text id="rom05u"
Δ identify backend
Ω authorize creation
Ψ check policy and resource budgets
□ create VirtualDeviceFrame
Χ bind backend reachability
Σ initialize DeviceRAcc where required
Σ commit device registration
```

Remote or cluster-backed devices are extension points for `07_distributed_systems.md`.

### 16.29 Device Nodes and Filesystem Exposure

Devices may be exposed through filesystem frames.

```text id="eohcmi"
DeviceNodeFrame = (
    path,
    DeviceFrame,
    perms,
    owner,
    policy,
    RAcc_ref,
    meta
)
```

Device-node open flow:

```text id="i4hh5d"
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, namespace, and device boundary
→ Δ resolve path
→ Ω verify device access
→ Ψ check device policy
→ □ create HandleFrame
→ Σ commit open
→ Σ commit RAcc update where required
→ Ψ postcheck
→ Φ return
```

This follows the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

A device node must not bypass the driver lifecycle.

If the device is detached, suspended, degraded, or quarantined, the device node must reflect that state through policy, fault, or absence behavior.

### 16.30 DMA and Device Memory

DMA requires explicit frame boundaries.

```text id="pu3pq2"
DMARegionFrame = (
    id,
    base,
    size,
    owner,
    device,
    perms,
    policy,
    RAcc_ref,
    state
)
```

DMA mapping flow:

```text id="njgc83"
Δ identify device and buffer
Ω verify DMA capability
Ψ check driver/device policy
□ create or select DMARegionFrame
Χ bind device reachability only to this frame
Σ commit DMA mapping
Σ commit DriverRAcc or DeviceRAcc update where required
```

DMA invariants:

```text id="zsfcgz"
device cannot write outside DMARegionFrame
DMARegionFrame belongs to authorized driver/device
user cannot forge DMA mapping
stale DMA mappings are removed on detach
DMA buffers are accounted to DriverRAcc or DeviceRAcc
```

This is an OS-level DMA boundary model.

It does not claim physical DMA engine implementation or fabricated hardware behavior.

### 16.31 Driver Resource Accounting

Driver activity consumes resources.

Driver resource account:

```text id="yl8pl5"
DriverRAcc = ResourceAccount(
    memory,
    DMA,
    IRQ_budget,
    workqueue_budget,
    queue_depth,
    device_bandwidth,
    error_budget,
    policy,
    meta
)
```

Accounting flow:

```text id="ue07di"
Δ classify driver resource event
Ω verify driver/account relation
Ψ check driver budget
∇ update usage
Σ commit RAcc
Ψ post-check budget
```

Resource violations may cause:

```text id="g8o05c"
Θ throttle workqueue
Ω reduce capability
Φ enter degraded mode
Χ quarantine driver
Σ audit event
Ψ unload or disable driver
```

Correct notation:

```text id="ro7n1h"
DriverRAcc
DeviceRAcc
RAcc.devices.*
RAcc.driver.*
```

Incorrect notation:

```text id="axjmsw"
DriverRF
DeviceRF
RF.devices.*
RF.driver.*
```

### 16.32 Driver Policy Attachments

A driver policy may include:

```text id="ns197f"
DriverPolicy = (
    trust_level,
    allowed_device_classes,
    caps,
    isolation_mode,
    irq_budget,
    work_budget,
    mem_limit,
    dma_policy,
    audit_level,
    recovery_mode,
    hotplug_policy,
    upgrade_policy,
    meta
)
```

Policy modes may include:

```text id="v21v27"
trusted core
signed vendor
third-party
experimental
sandboxed
quarantine-only
denylisted
```

The effective policy constrains every lifecycle transition.

Policy attachments are OS-level control structures.

They do not constitute supply-chain governance, external driver certification, or forensic authority.

### 16.33 Recovery Modes

PMS-OS supports policy-defined recovery modes.

```text id="gcc41c"
RECOVER_IN_PLACE
RESTART_DRIVER
RELOAD_DRIVER
FALLBACK_DRIVER
DEGRADE_DEVICE
QUIESCE_AND_RETRY
QUARANTINE_DRIVER
QUARANTINE_DEVICE
DISABLE_DEVICE
PANIC_OR_HALT
```

Recovery flow:

```text id="h8t23l"
Δ classify fault
Ψ choose recovery mode
Φ enter recovery context
Θ order retry/backoff if applicable
∇ perform recovery action
Σ commit recovery state
Σ commit RAcc/audit update where required
Ψ check post-state
```

A recovery mode must define:

```text id="fp3wm7"
allowed operations
resource budget
timeout behavior
audit requirement
return condition
failure escalation
```

### 16.34 Driver Faults

Driver faults include:

```text id="sgiq9i"
invalid MMIO access
unauthorized DMA
IRQ storm
top-half budget overrun
bottom-half timeout
unbounded allocation attempt
capability violation
policy violation
device protocol error
use-after-detach
stale frame access
crash in handler
```

Fault path:

```text id="udvi90"
Δ classify fault
Φ enter driver fault handler
Ψ choose response
Ω revoke/narrow capabilities if needed
Χ isolate if needed
Σ commit fault state
Σ commit RAcc/audit update where required
Θ reschedule or stop work
```

Responses may include:

```text id="dfnc5p"
return error
retry
degrade
reset
quarantine
unload
replace driver
disable device
halt under critical invariant
```

### 16.35 Nested Faults and Φ-of-Φ

Faults can occur while already handling an interrupt or driver error.

Nested fault path:

```text id="xewl3r"
Φ fault inside Φ context
Δ classify nested cause
Ψ evaluate nested-fault policy
Χ isolate driver or device if unsafe
Σ commit nested fault state
Φ return to safe context or halt
```

PMS-OS does not treat this as undefined behavior. It is a structured recontextualization under stricter policy.

### 16.36 Hotplug Failure Modes

Hotplug failures are typed outcomes.

| Failure                      | Operator reading |
| ---------------------------- | ---------------- |
| attach denied                | Ψ denial         |
| device absent during probe   | Λ                |
| descriptor invalid           | Δ / Φ            |
| driver not found             | Λ or Ψ           |
| bind fails midway            | Φ + Σ rollback   |
| unauthorized device          | Ψ + Χ            |
| detach with pending I/O      | Θ + Σ + Ψ        |
| stale reference after detach | Φ / Χ            |
| repeated attach instability  | Λ + Θ + Ψ        |
| unsafe topology              | Δ / Ψ            |

Responses include:

```text id="zljztw"
reject
retry
defer
rollback
quarantine
fallback driver
safe-mode attach
read-only attach
force detach
audit
```

### 16.37 Driver and Device Audit

Driver and device transitions may emit audit records.

```text id="i3odla"
DriverAuditRecord = (
    event_id,
    actor,
    driver,
    device,
    operation,
    lifecycle_before,
    lifecycle_after,
    operator_class,
    decision,
    commit_result,
    resource_accounting_result,
    fault_state,
    timestamp_or_order,
    metadata
)
```

Auditable events include:

```text id="j432l1"
install
load
probe
bind
activate
IRQ registration
interrupt fault
DMA mapping
capability grant/revoke
suspend/resume
degraded transition
quarantine
unbind
unload
hotplug attach/detach
topology change
driver upgrade
policy denial
resource budget violation
```

Audit flow:

```text id="j478ua"
Δ prepare audit record
Σ commit audit record
Ψ enforce retention/integrity
```

A concrete device/driver lifecycle trace is:

```text id="pov8x9"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="lox4cy"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The declared device/driver lifecycle execution space is:

```text id="wgpyf8"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="ch27b3"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Trace emission is implementation-specific.

Operator-labeled representability is the architectural requirement.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 16.38 Driver Lifecycle State Machine

A compact lifecycle graph:

```text id="qb0fhw"
UNINSTALLED
    → INSTALLED
    → LOADED
    → PROBED
    → BOUND
    → ACTIVE
```

Operational branches:

```text id="wtm5ph"
ACTIVE ↔ SUSPENDED
ACTIVE → DEGRADED
DEGRADED → ACTIVE
DEGRADED → QUARANTINED
ACTIVE → QUIESCING
QUIESCING → UNLOADING → UNLOADED
```

Hotplug and error branches:

```text id="c20bj3"
ACTIVE → QUIESCING → DETACHED
ACTIVE → ERROR → DEGRADED
ERROR → QUARANTINED
QUARANTINED → UNLOADING → UNLOADED
QUARANTINED → RECOVERY → ACTIVE
```

Upgrade branch:

```text id="f7xr8b"
ACTIVE(D_old)
→ QUIESCING(D_old)
→ MIGRATING
→ ACTIVE(D_new)
→ UNLOADED(D_old)
```

Every edge must be backed by an operator-typed transition and a Ψ policy decision.

### 16.39 Lifecycle Transition Template

Every driver lifecycle transition may be specified through one template.

```text id="eh0xai"
DriverTransition = (
    from_state,
    to_state,
    preconditions,
    operator_word,
    commit,
    postconditions,
    failure_path,
    audit
)
```

Template:

```text id="em00yj"
Pre:
    Δ identify driver/device/context
    Ω check authority
    Ψ check transition policy
    Χ check boundary state
    RAcc check resource-accounting state where relevant

Body:
    □ update frames
    ∇ mutate driver/device state
    Θ order queues/work/handlers
    Φ recontextualize if needed

Commit:
    Σ commit lifecycle state and resource accounting

Post:
    Ψ check invariants
    Φ return or remain in kernel recovery context
```

This allows driver lifecycle transitions to be specified or checked independently of a specific implementation language.

It does not claim external validation.

### 16.40 Driver and Device Syscall Interaction

Device and driver lifecycle operations may be reached through syscalls such as:

```text id="zn6uq5"
open
close
read
write
ioctl
mmap
poll
fsync
register_driver
bind_driver
unbind_driver
device_control
driver_upgrade
```

Such syscalls follow the canonical PMS-OS syscall contract:

```text id="hzhkod"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Expanded for device/driver operations:

```text id="qu49z7"
Φ syscall entry
→ Ω check / install authority
→ □ bind syscall/kernel frame
→ Χ mediate user/kernel, device, driver, buffer, namespace, or DMA boundary
→ Δ classify syscall, device, driver, request, buffer, or lifecycle transition
→ Ψ check policy, lifecycle state, quota, and driver/device constraints
→ device/driver operation
→ Σ commit lifecycle, request, audit, or RAcc state where required
→ Ψ postcheck
→ Φ return
```

This is the PMS-OS syscall ABI.

It is built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

### 16.41 Driver Lifecycle Invariants

PMS-OS maintains the following driver and device lifecycle invariants.

```text id="qhzlh9"
I1: every device is represented as a valid DeviceFrame

I2: every loaded driver is represented as a valid DriverFrame

I3: every driver action is Ω-authorized

I4: every driver/device binding is kernel-mediated

I5: every binding has an active effective Ψ policy

I6: every MMIO access targets an assigned frame

I7: every DMA operation is bounded by a DMARegionFrame

I8: every IRQ handler is registered through the kernel IRQ frame

I9: top-half handlers do not block or perform unbounded allocation

I10: bottom-half and workqueue execution is Θ-ordered and budgeted

I11: suspend/resume transitions preserve pending work and device state

I12: quiescing drains or resolves active work before detach/unload

I13: hotplug attach/detach is Φ-mediated and Σ-committed

I14: stale device frames are isolated or invalidated after detach

I15: driver faults enter defined Φ recovery paths

I16: quarantine revokes or narrows ordinary driver capabilities

I17: driver resource use is accounted through DriverRAcc / DeviceRAcc and
     policy-checked

I18: unload leaves no live IRQ handlers, DMA mappings, or frame references

I19: driver replacement preserves or explicitly closes in-flight state

I20: no device or driver fast path bypasses Ω, Χ, Ψ, or required RAcc
     constraints

I21: RAcc / ResourceAccount is the resource-accounting notation

I22: RF is reserved for PMS-CPU RegisterFile and must not denote
     ResourceAccount, ResourceFrame, or quota state in PMS-OS

I23: X_device, X_driver, X_dma, X_irq, X_bus, X_p, X_user, X_global, and
     related X_* symbols are OS-level isolation-domain values, not PMS Base Χ

I24: PMS Base Χ = Distance

I25: PMS-OS projects Χ as process isolation, address-space boundary,
     namespace separation, device boundary, driver boundary, DMA boundary,
     IPC visibility, filesystem view, sandbox/container boundary, and
     reachability control

I26: τ denotes time/accounting metadata, not a PMS Base operator

I27: device and driver lifecycle traces remain operator-labeled and belong
     to L_PMS or L_PMS,Ψ_kernel under the declared OS profile

I28: hardware-like names in this section denote OS-level device models unless
     a later implementation artifact explicitly realizes them
```

### 16.42 Boundary to Runtime Security and Distributed Systems

This section defines OS-level device and driver lifecycle architecture.

It does not fully define:

```text id="dcso23"
adversarial driver threat modeling
supply-chain trust governance
formal driver verification
remote attestation
distributed device ownership
cross-node hotplug
cluster failover
global device quorum
network partition behavior
production driver implementation
complete production driver framework
external driver certification
fabricated hardware
```

Those belong in or are bounded by:

```text id="vyy4ly"
06_runtime_security.md
07_distributed_systems.md
```

Boundary:

```text id="e2asjh"
04_pms_os.md defines local PMS-OS device and driver lifecycle substrate.

06_runtime_security.md defines runtime-security architecture, adversarial
hardening, audit/evidence hardening, and deployment-facing security profiles.

07_distributed_systems.md defines cross-node device ownership, distributed
failure semantics, cluster failover, distributed policy synchronization, and
network-partition behavior.
```

This section defines the local OS substrate on which those layers can build.

It does not make PMS-OS a governance oracle, forensic authority, or external certification system.

### 16.43 Architectural Consequence

PMS-OS drivers are governed kernel agents, not opaque privileged blobs.

The consequence is:

```text id="vge7lu"
A PMS-OS driver is a role-bearing, frame-bound, policy-constrained,
resource-accounted PMS submachine whose installation, loading, probing,
binding, activation, interrupt handling, deferred work, suspension,
recovery, hotplug, quarantine, replacement, and unloading are explicit
Δ–Ψ transitions.
```

This gives PMS-OS a unified lifecycle model for physical-device models, virtual devices, drivers, interrupt handlers, DMA regions, hotplug events, driver upgrades, degraded modes, recovery paths, and device-policy enforcement.

### 16.44 Boundary Statement

The correct boundary for this chapter is:

```text id="x5di8t"
The PMS-OS device and driver lifecycle model specifies OS-level
DeviceFrames, DriverFrames, driver roles, capability families,
driver-kernel asymmetry, module decomposition, device-driver binding,
effective driver policy, lifecycle states, installation, loading, probing,
binding, activation, IRQ registration, interrupt paths, top-half and
bottom-half execution, workqueues, suspend/resume, quiescing, degraded
state, quarantine, unbind/unload, driver replacement, hotplug attach/detach,
topology reconfiguration, virtual devices, device-node exposure, DMA
boundaries, resource accounting, policy attachments, recovery modes, driver
faults, nested faults, syscall interaction, audit representability, and
driver lifecycle invariants through Δ–Ψ operator structure.

This is an OS-level device and driver lifecycle architecture claim.

It does not claim production driver implementation, fabricated hardware,
a complete production device-driver framework, physical interrupt-controller
implementation, physical DMA engine implementation, physical bus behavior,
external driver certification, external security validation, distributed
device ownership, cross-node hotplug, global device quorum, governance
authority, forensic authority, moral judgment, or PMS Base validation.
```

---

## 17. OS-Level Invariants

PMS-OS is defined by the invariants it preserves across kernel execution.

The preceding sections specify kernel structure, process/thread state, scheduling, isolation, policy, syscalls, resources, virtual memory, allocation, filesystems, storage, cache, IPC, events, devices, and drivers. This section consolidates their shared invariant discipline.

The central OS-invariant claim is:

```text id="a7xvdr"
PMS-OS is valid when every kernel-visible transition preserves the
operator-typed invariants governing identity, frame context, authority,
boundary, ordering, absence, mutation, recontextualization, commit,
resource accounting, and policy.
```

Claim type:

```text id="p38scp"
implementation-layer OS invariant architecture claim
```

Boundary:

```text id="xar6tt"
This section specifies the OS-level invariant set of PMS-OS.

It does not claim a completed production kernel.

It does not claim a completed production OS.

It does not claim fabricated hardware substrate.

It does not claim external security validation.

It does not validate PMS Base.
```

These invariants are OS architecture constraints. They define what a PMS-conformant OS layer must preserve.

They strengthen the PMS-STACK operating-system architecture claim.

They do not validate PMS Base.

A concrete PMS-OS execution produces:

```text id="of9hd8"
trace_os(K, π_os, s₀) ∈ L_PMS
```

Under active kernel policy:

```text id="u2n453"
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
```

The set of possible PMS-OS executions is:

```text id="df6j3a"
Trace_os(K, π_os, s₀) ⊆ L_PMS
```

and under policy:

```text id="vcp7k3"
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Canonical resource notation:

```text id="dvtudi"
RAcc = ResourceAccount
```

`RF` must not be used for resource accounting in PMS-OS.

`RF` is reserved for `RegisterFile` in PMS-CPU.

At PMS Base level:

```text id="rrt4pd"
Χ = Distance
```

At PMS-OS level, Χ projects as process isolation, address-space boundary, namespace separation, user/kernel boundary, device boundary, driver boundary, DMA boundary, IPC visibility, filesystem view, sandbox/container boundary, cache visibility, and reachability control.

Concrete `X_*` symbols are OS-level isolation-domain values.

They are not PMS Base Χ.

### 17.1 Invariant Form

An OS-level invariant has the form:

```text id="um76sc"
Invariant = (
    id,
    scope,
    operator_basis,
    predicate,
    enforcement_point,
    failure_response
)
```

where:

| Field               | Meaning                                                                  |
| ------------------- | ------------------------------------------------------------------------ |
| `id`                | invariant identifier                                                     |
| `scope`             | kernel-global, process, frame, syscall, memory, filesystem, device, etc. |
| `operator_basis`    | primary Δ–Ψ operators involved                                           |
| `predicate`         | condition that must hold                                                 |
| `enforcement_point` | where the kernel checks or preserves it                                  |
| `failure_response`  | Ψ/Φ/Λ/Χ/Σ response when violated                                         |

The generic preservation rule is:

```text id="q5f6e1"
Ψ_OS(s_before) ∧ valid_transition(s_before → s_after)
⇒ Ψ_OS(s_after)
```

or, for transitions that intentionally enter recovery:

```text id="b70rld"
violation_detected
⇒ Φ_recovery
⇒ Σ_commit_recovery_state
⇒ Ψ_OS(recovered_state)
```

The kernel may deny, defer, isolate, recover, roll back, terminate, quarantine, or halt under policy.

It may not silently violate the invariant set.

### 17.2 Global Kernel Invariants

The kernel is privileged, but invariant-bound.

#### K1 — Kernel Authority Is Structured

Kernel authority exists through Ω, □, Χ, Φ, Θ, Σ, RAcc, and Ψ.

```text id="dnrctg"
kernel_action_valid(a) iff
    Ω authorizes a
    ∧ frame context is valid
    ∧ boundary context is valid
    ∧ RAcc constraints hold where resource-visible state changes
    ∧ Ψ permits a
```

The kernel may create frames, assign roles, handle traps, manage boundaries, schedule execution, update resource accounts, and commit global state only through operator-typed transitions.

#### K2 — Kernel Invariants Are Preserved

For every kernel transition:

```text id="a72usn"
Ψ_kernel(s_before) ⇒ Ψ_kernel(s_after)
```

If the direct transition cannot preserve invariants, the kernel must enter a defined Φ recovery, rollback, quarantine, or halt path.

#### K3 — User/Kernel Crossing Is Φ-Mediated

```text id="iqwq62"
USER → KERNEL only via Φ_trap/syscall/interrupt/fault
KERNEL → USER only via Φ_return
```

No process, thread, driver, or device may silently acquire kernel context.

#### K4 — Kernel Frames Are Protected

```text id="xocis5"
user frame cannot directly write, map, or execute kernel frame
```

Kernel frame access requires kernel-governed role, frame, boundary, and policy conditions.

#### K5 — Policy Mutation Is Kernel-Governed

```text id="fnu18d"
Ψ_update allowed iff Ω authorizes policy mutation in a kernel-governed frame
```

No user process, driver, device, namespace, or runtime may rewrite the policy constraints that bind it.

#### K6 — OS Isolation-Domain Values Are Not PMS Base Χ

Symbols such as:

```text id="cw4o1v"
X_user
X_global
X_p
X_device
X_driver
X_dma
X_endpoint
X_cache
X_alloc
X_domain
```

are OS-level isolation-domain values.

They are not PMS Base Χ.

They name concrete PMS-OS boundary, reachability, namespace, process, device, IPC, filesystem, cache, sandbox/container, DMA, or driver domains through which PMS Base Χ = Distance is projected at OS level.

### 17.3 Process and Thread Invariants

Processes and threads form the execution hierarchy of PMS-OS.

#### P1 — Every Live Thread Has One Parent Process

```text id="bmojjf"
∀ t ∈ LiveThreads:
    ∃! p ∈ LiveProcesses such that parent(t) = p
```

A thread cannot exist outside a process context.

#### P2 — Every Live Process Has a Valid Frame Set

```text id="cq8m98"
∀ p ∈ LiveProcesses:
    FrameSet(p) is valid
```

The frame set must contain coherent code, data, stack, heap, IPC, shared, and kernel-gateway relations according to the process profile.

#### P3 — Thread Authority Does Not Exceed Process Authority

```text id="f3m5a3"
CapSet(thread) ⊆ CapSet(process)
```

Thread-local capabilities may refine process authority, but they may not silently exceed it.

#### P4 — Thread State Has a Cause

Every non-running state must have an operator-readable cause.

```text id="q20n21"
BLOCKED    ⇒ Λ or Φ cause exists
SUSPENDED  ⇒ Χ, Ω, or Ψ cause exists
ZOMBIE     ⇒ Σ cleanup pending
TERMINATED ⇒ Σ cleanup complete ∧ Ψ lifecycle closed
```

#### P5 — Process Termination Is Σ/Ψ Closure

```text id="r8zawp"
TERMINATED(p) iff
    all threads terminated
    ∧ resources reclaimed or reassigned
    ∧ RAcc state committed
    ∧ policies closed
    ∧ no runnable continuation remains
```

A process is not structurally terminated until lifecycle closure is committed.

### 17.4 Scheduling Invariants

Scheduling is Θ ordering under policy.

#### S1 — Only READY Threads May Be Dispatched

```text id="pnqgkf"
Θ_select(t) valid ⇒ state(t) = READY
```

A blocked, suspended, zombie, terminated, quarantined, or policy-denied thread is not dispatchable.

#### S2 — Dispatch Installs Coherent Context

A context switch is valid only if:

```text id="vvv7xe"
Σ saves outgoing state
∧ □ installs incoming frame context
∧ Ω installs incoming role/capability state
∧ Χ installs incoming boundary state
∧ RAcc state is coherent where scheduling quota applies
∧ Ψ permits dispatch
```

#### S3 — Scheduler Policy Constrains Selection

```text id="v9h8gk"
Θ_select(t) valid ⇒ Ψ_sched(SchedulerState, t) = true
```

The scheduler may use round-robin, priority, fairness, deadline, or hierarchical scheduling, but selection remains policy-bound.

#### S4 — Blocking and Wakeups Are Explicit

```text id="zeyj6i"
BLOCKED(t) ⇒ wait condition or trap continuation exists
READY(t) after wake ⇒ wait condition resolved or timeout policy applied
```

Wakeups must be Θ-ordered and policy-valid.

#### S5 — Resource State Can Affect Scheduling

```text id="gfsvue"
RAcc.cpu.used ≥ RAcc.cpu.max
⇒ Ψ may deny Θ_select(t)
```

A thread may be READY but unselectable under resource policy.

### 17.5 Isolation and Protection Invariants

Isolation is the OS-level projection of PMS Base Χ as Distance into boundary, reachability, and access separation.

#### X1 — Cross-Boundary Access Requires an Explicit Relation

```text id="r9vrf8"
access(domain_i, object_j) valid only if
    Χ permits reachability
    ∧ Ω permits action
    ∧ Ψ permits relation
```

There is no spontaneous cross-domain visibility.

#### X2 — Shared Frames Require Explicit Commit

```text id="p0rcy2"
shared_frame_visible(p, q)
⇒ Ω authorizes sharing
∧ Χ bridge exists
∧ Ψ permits sharing
∧ Σ committed sharing relation
```

#### X3 — Namespace Crossings Are Policy-Governed

```text id="kj4qow"
resolve_across_namespace_boundary
⇒ Ω authority ∧ Χ visibility ∧ Ψ namespace policy
```

#### X4 — Quarantine Removes Ordinary Reachability

```text id="m6g42w"
Χ_quarantine(subject)
⇒ ordinary access paths denied unless Ψ_quarantine permits them
```

Quarantine may apply to processes, drivers, devices, endpoints, frames, caches, buffers, allocation domains, or filesystem subtrees.

Quarantine is an OS-level isolation response.

It is not moral judgment, forensic attribution, or governance authority.

#### X5 — Protection Failure Has Defined Response

Every protection violation must enter a typed response:

```text id="fbhj7w"
Ω failure → denial or Φ
Χ failure → boundary fault / isolation response
Ψ failure → policy denial / Φ / halt
```

No protection failure is undefined behavior.

### 17.6 Kernel Policy Engine Invariants

The Kernel Policy Engine is the OS-level Ψ mechanism.

#### PSI1 — Critical Transitions Have Policy Hooks

```text id="pjvfwe"
critical_transition(op) ⇒ hook_exists(op)
```

Critical transitions include syscalls, role changes, frame switches, memory mappings, IPC delivery, filesystem mutation, cache flush, device access, driver lifecycle transitions, resource-accounting mutation, and commits.

#### PSI2 — Local Policy Cannot Weaken Kernel Policy

```text id="jc4vao"
P_effective = Combine(P_kernel, P_role, P_process, P_frame, P_object, ...)
```

and:

```text id="di4wa6"
P_local may restrict;
P_local may not weaken P_kernel.
```

#### PSI3 — Policy Decisions Resolve Explicitly

Multiple policy results must be resolved by declared composition or priority rules.

```text id="upn9lk"
Resolve(results) → final_decision
```

No hidden conflict resolution is permitted.

#### PSI4 — Enforcement Actions Are Operator-Typed

```text id="uy5860"
DENY      → Ψ denial / Φ return
DEFER     → Θ delay / Λ wait
ISOLATE   → Χ restrict + Σ commit
ESCALATE  → Φ handler
LOG       → Δ prepare + Σ commit audit
HALT      → Ψ critical halt
```

Policy enforcement must preserve the same operator discipline it applies.

#### PSI5 — Policy Fast Paths Preserve Semantics

A cached or fast-path decision is valid only when:

```text id="dfyfla"
policy_epoch unchanged
∧ actor authority unchanged
∧ target frame/boundary unchanged
∧ relevant RAcc and τ constraints unchanged
```

No fast path may bypass active Ψ constraints.

Policy escalation is kernel-internal recontextualization.

It is not moral judgment, forensic attribution, or governance authority.

### 17.7 Syscall Invariants

Syscalls are Φ-mediated kernel contracts.

Canonical PMS-OS syscall contract:

```text id="erc9um"
Φ ; Ω ; □ ; Χ ; Δ ; Ψ ; (∇ | □ | Χ | Θ | Σ | Φ | Ψ) ; Σ? ; Ψ ; Φ
```

Meaning:

```text id="h2q804"
Φ  kernel entry / trap
Ω  kernel role and caller authority
□  kernel syscall frame
Χ  user/kernel boundary mediation
Δ  syscall and argument distinction
Ψ  precheck
(...) syscall body
Σ? commit where required
Ψ  postcheck
Φ  return / close / recontextualize
```

The PMS-OS syscall convention is a dedicated OS-level syscall ABI built on the PMS-CPU trap mechanism.

It does not redefine the ordinary PMS-CPU calling convention.

It does not replace the PMS-CPU trap/syscall control-transfer model.

#### SY1 — Syscall Entry Is Controlled

```text id="pvytv0"
user syscall ⇒ Φ_syscall_entry
```

The kernel must save user continuation, frame, role, boundary, and return metadata.

#### SY2 — Syscall Dispatch Is Δ-Classified

```text id="j7zvsc"
syscall_id must be distinguished before handler execution
```

Invalid IDs produce Δ failure and a defined Φ/Ψ response.

#### SY3 — Arguments Are Checked Before Use

```text id="vywqwu"
argument use valid only after:
    Δ type/range/pointer classification
    ∧ □ frame validation
    ∧ Ω authority
    ∧ Χ boundary check
    ∧ Ψ policy check
```

User pointers are never trusted merely because they are syntactically present.

#### SY4 — Mutating Syscalls Commit Effects

A syscall that produces visible or durable effects must use Σ.

```text id="fxgofx"
∇ produced effect
∧ effect globally visible
⇒ Σ committed effect
```

#### SY5 — Syscall Return Restores Valid User Context

```text id="ghx6tw"
Φ_return valid iff
    user frame valid
    ∧ user role restored
    ∧ user boundary restored
    ∧ return address executable
    ∧ pending commit state resolved
    ∧ Ψ permits return
```

No syscall may return with kernel-only role, frame, or boundary state leaked.

#### SY6 — Resource-Affecting Syscalls Update RAcc

```text id="g5y02h"
resource-affecting syscall
⇒ Δ classify resource impact
⇒ Ψ check RAcc policy
⇒ Σ commit RAcc update where required
```

### 17.8 Resource Accounting Invariants

Resources are quota-governed kernel state.

#### R1 — Accounted Resources Have Owners

```text id="edmjsj"
∀ resource_event:
    owner or system scope exists
```

Owner may be process, thread, user, role, container, driver, device, filesystem, cache, IPC endpoint, or system.

#### R2 — Resource Mutations Are Accounted

```text id="ec9woj"
resource mutation
⇒ Δ classify
⇒ ∇ update usage
⇒ Σ commit accounting
```

#### R3 — Quotas Are Checked Before Commit

```text id="j9e0bo"
RAcc.x.used + delta > RAcc.x.max
⇒ Ψ denies, defers, throttles, isolates, or recontextualizes
```

#### R4 — Hierarchical Quotas Propagate

```text id="auu6g2"
∀ RAcc ∈ Ancestors(local_RAcc):
    RAcc.x.used += delta
```

A child cannot bypass a parent quota.

#### R5 — Shared Resource Attribution Is Explicit

Shared memory, shared buffers, shared IPC, shared files, shared cache entries, and shared devices must define attribution rules.

```text id="ndwvlu"
shared_resource ⇒ accounting_policy_defined
```

#### R6 — Resource Exhaustion Has Typed Outcomes

```text id="tgo9t0"
no resource available ⇒ Λ no-resource
critical failure       ⇒ Φ recovery / Ψ halt
quota denial           ⇒ Ψ denial
```

#### R7 — RF Is Not Resource Accounting

```text id="qt70j2"
RAcc / ResourceAccount is the PMS-OS resource-accounting notation.
RF is reserved for PMS-CPU RegisterFile.
```

The following are invalid in PMS-OS resource accounting:

```text id="pwzr4z"
RF.mem.used
RF.cpu.used
SystemRF
ProcessRF
ThreadRF
DriverRF
DeviceRF
```

The correct forms are:

```text id="myc6b1"
RAcc.mem.used
RAcc.cpu.used
SystemRAcc
ProcessRAcc
ThreadRAcc
DriverRAcc
DeviceRAcc
```

### 17.9 Virtual Memory Invariants

Virtual memory is frame-based address interpretation.

#### VM1 — Every Valid Address Resolves Through an Address Space

```text id="cc8ypw"
valid_access(p, VA, mode)
⇒ Resolve(p, VA) succeeds
```

#### VM2 — Every Mapping Selects a Valid Frame

```text id="xo42zj"
Map_p(VA) = FrameId ⇒ Frame(FrameId) exists
```

#### VM3 — Access Is Bounds-Checked

```text id="pe07jq"
offset(VA) < size(FrameId)
```

#### VM4 — Memory Access Is Authorized and Boundary-Valid

```text id="n4qkux"
AccessAllowed(p, VA, mode) iff
    mapping exists
    ∧ mode ∈ perms
    ∧ Ω permits mode
    ∧ Χ permits reachability
    ∧ Ψ permits access
```

#### VM5 — User Code Cannot Directly Map Kernel Frames

```text id="ydkklk"
user_mapping(kernel_frame) invalid unless explicitly kernel-mediated and policy-defined
```

#### VM6 — Page Faults Are Φ Events

```text id="vpnriy"
invalid or missing mapping ⇒ Φ_pagefault / Φ_protection_fault
```

Fault handling must either resolve, deny, signal, terminate, quarantine, or halt under policy.

#### VM7 — Mapping Changes Are Σ-Committed

```text id="ujxvtb"
map / unmap / protect / remap
⇒ Σ commit mapping state before global visibility
```

#### VM8 — PTE Is an OS-Level Mapping Descriptor

`PTE` in PMS-OS denotes an OS-level mapping descriptor.

It does not claim physical page-table hardware, physical TLB behavior, or fabricated MMU circuitry.

### 17.10 Allocation and Reclamation Invariants

Allocation and reclamation are frame lifecycle operations.

#### A1 — Every Allocation Belongs to a Domain

```text id="twk031"
allocation ⇒ AllocationDomain exists
```

#### A2 — Returned Pointers Are Valid Only After Commit

```text id="q0t5zp"
ptr returned valid iff Σ allocation commit completed
```

#### A3 — Free Checks Pointer and Ownership

```text id="wlmk9j"
free(ptr) valid iff
    ptr belongs to known BlockFrame
    ∧ state(ptr) = used
    ∧ caller may release it
    ∧ Ψ permits release
```

#### A4 — Invalid Free Is Φ/Ψ-Handled

```text id="k2v3f1"
unknown pointer
∨ double free
∨ foreign pointer
∨ kernel/shared frame violation
⇒ Φ memory-safety path or Ψ denial
```

#### A5 — Reclaimed Memory Is Not Live

```text id="qpu4pi"
reclaimed(block) ⇒ block not reachable as live object
```

#### A6 — GC and RC Respect Boundaries

```text id="qf6drw"
GC traversal / refcount sharing
⇒ Ω authority ∧ Χ visibility ∧ Ψ policy
```

#### A7 — OOM Behavior Is Policy-Defined

```text id="nn8btk"
allocation not realized
⇒ Λ allocation_absent or Φ OOM handler
```

#### A8 — Allocation Accounting Uses RAcc

```text id="eygtx1"
allocation or reclamation
⇒ RAcc update according to allocation-domain policy
```

### 17.11 Filesystem Invariants

The filesystem is a frame tree or DAG with Σ-governed persistence.

#### FS1 — Every Filesystem Object Is a Frame

```text id="nlbt2j"
file, directory, handle, mount, namespace, journal, device node
⇒ valid Frame
```

#### FS2 — Path Resolution Is Δ-Structured and Namespace-Bound

```text id="af21zm"
path resolution = sequence of Δ over directory frames
```

At each step:

```text id="z56jei"
Ω search permission
∧ Χ namespace visibility
∧ Ψ path policy
```

#### FS3 — Handles Are Explicit Frame Objects

```text id="od86uk"
open(path) ⇒ HandleFrame committed into process table
```

#### FS4 — Mutations Require Authority, Policy, and Commit

```text id="kxmlq6"
filesystem mutation
⇒ Ω authority
∧ Ψ permission
∧ ∇ mutation
∧ Σ commit or explicit staged state
```

#### FS5 — Journaled Operations Preserve Recovery

```text id="iv54qu"
journaled mutation
⇒ Σ journal intent
∧ Φ recovery path
∧ Ψ consistency invariant
```

#### FS6 — Namespace and Mount Crossings Are Χ/Ψ-Governed

```text id="irvzom"
mount / namespace crossing
⇒ Φ recontextualization
∧ Χ boundary update
∧ Ψ policy
∧ Σ commit
```

#### FS7 — Filesystem Quotas Use RAcc

```text id="obit3v"
filesystem quota-visible mutation
⇒ RAcc.storage.* update under declared policy
```

### 17.12 Block Device and Storage Invariants

Block storage is frame-bound I/O.

#### B1 — Every Device Is a DeviceFrame

```text id="b2cvq1"
block device ⇒ valid DeviceFrame
```

#### B2 — Every I/O Request Is Δ-Classified

```text id="bp8e9x"
BlockRequest valid ⇒ op, device, range, buffer classified
```

#### B3 — I/O Requires Authority and Boundary Validity

```text id="msnw8n"
I/O valid iff
    Ω permits action
    ∧ buffer frame valid
    ∧ Χ permits buffer/device relation
    ∧ Ψ permits request
```

#### B4 — Durability Claims Require Σ

```text id="qvab2a"
write executed ≠ write durably committed
```

A durability claim is valid only with the relevant Σ condition.

#### B5 — DMA Is Frame-Bounded

```text id="kf9d7c"
DMA valid iff
    DMARegionFrame exists
    ∧ device may access only that frame
    ∧ Ψ permits DMA operation
```

#### B6 — Device Errors Enter Φ Recovery

```text id="y7pmzb"
timeout / bad block / lost device / driver fault
⇒ Φ recovery path
```

#### B7 — Hardware-Like Names Are OS-Level Models

Physical-device, block-device, DMA, bus, interrupt, storage-controller, and cache-like names in PMS-OS denote OS-level device models unless a later implementation artifact explicitly realizes them.

They do not claim fabricated hardware.

### 17.13 Cache and Buffer Invariants

Caches are intermediate state made explicit.

#### C1 — Every Cache Is a CacheFrame

```text id="q0q1a3"
cache subsystem ⇒ valid CacheFrame
```

#### C2 — Every Buffer Has a Lifecycle State

```text id="utx5g4"
BufferFrame.state ∈ {
    CLEAN, DIRTY, FLUSHING, RECOVERY, DEAD,
    PINNED, STALE, INVALID, QUARANTINED, ...
}
```

#### C3 — Dirty Buffers Have a Resolution Path

```text id="f8tevj"
dirty(buffer) ⇒ future Σ flush ∨ Φ rollback ∨ Ψ discard policy
```

#### C4 — Pinned Buffers Are Not Evicted

```text id="lkh92s"
pinned(buffer) ⇒ eviction invalid
```

#### C5 — Flush and Barrier Semantics Are Backed by Σ

```text id="ghebx7"
barrier complete ⇒ all required prior commits complete or policy-failed
```

#### C6 — Cache Visibility Respects Boundaries

```text id="oq1nix"
CacheAccessAllowed(actor, buffer, mode)
⇒ Ω permits mode
∧ Χ permits visibility
∧ Ψ permits cache access
```

#### C7 — Cache Accounting Uses RAcc

```text id="yrvst1"
cache growth / flush / eviction / reclaim
⇒ RAcc.cache.* update where policy requires it
```

This is an OS-level cache and buffer model.

It does not claim physical CPU cache hardware or physical cache-coherence protocols.

### 17.14 IPC, Synchronization, and Event Invariants

Communication and coordination are frame-governed.

#### I1 — Every Endpoint Is a Frame

```text id="t6t7qd"
MessageFrame / ChannelFrame / EventFrame / SyncFrame exists for endpoint
```

#### I2 — Send and Receive Are Authorized

```text id="uy7ps1"
send valid ⇒ Ω(sender, send, endpoint)
receive valid ⇒ Ω(receiver, receive, endpoint)
```

#### I3 — Cross-Domain Communication Requires Visibility

```text id="d6fklc"
communication(domain_i, domain_j)
⇒ Χ permits relation
∧ Ψ permits communication
```

#### I4 — Absence Is Represented Through Λ

```text id="uy3fwi"
no message / no event / no resource / timeout
⇒ Λ outcome
```

#### I5 — Blocking Creates Explicit Wait State

```text id="wexhlx"
blocking operation ⇒ Wait(object, condition, deadline, policy, continuation)
```

#### I6 — Wakeups Are Θ-Ordered

```text id="xu7ixo"
wake(thread) ⇒ Θ orders transition BLOCKED → READY
```

#### I7 — Delivery Guarantees Require Σ Semantics

```text id="ywfsvf"
at-most-once / at-least-once / exactly-once
⇒ explicit Σ and Ψ policy
```

#### I8 — Synchronization State Changes Commit

```text id="pqg6l1"
lock / unlock / wait / signal / close
⇒ Σ commit state or defined failure path
```

#### I9 — Communication Accounting Uses RAcc

```text id="lacdyq"
IPC / sync / event resource effect
⇒ RAcc.ipc.* or RAcc.sync/events.* update under policy
```

These are single-node PMS-OS guarantees.

Cross-node messaging, distributed delivery guarantees, distributed locks, replicated logs, and distributed policy synchronization belong to `07_distributed_systems.md`.

### 17.15 Device and Driver Lifecycle Invariants

Devices and drivers are governed kernel agents.

#### D1 — Every Device Has a DeviceFrame

```text id="c1t9jk"
device visible to kernel ⇒ DeviceFrame exists
```

#### D2 — Every Loaded Driver Has a DriverFrame

```text id="fbu13n"
driver loaded ⇒ DriverFrame exists
```

#### D3 — Driver Actions Are Capability-Governed

```text id="uy51x2"
driver action valid ⇒ Ω(r_D, action, target)
```

#### D4 — Binding Is Kernel-Mediated

```text id="bfakug"
Bind(D, Dev)
⇒ Δ identify
∧ Ω authorize
∧ Ψ policy
∧ □ frame setup
∧ Χ boundary setup
∧ Σ commit
```

#### D5 — IRQ Handlers Are Registered Through Kernel Frames

```text id="mo6gut"
driver handles IRQ ⇒ IRQDesc committed and policy-valid
```

#### D6 — Top Halves Are Bounded

```text id="r48a4d"
IRQ top half
⇒ no blocking
∧ no unbounded allocation
∧ IRQ-safe API set
∧ τ-derived budget policy
```

#### D7 — DMA Is Explicitly Framed

```text id="v784iu"
driver DMA ⇒ DMARegionFrame
```

#### D8 — Hotplug Is Φ/Σ-Mediated

```text id="toqvyy"
attach/detach/topology change
⇒ Φ recontextualization
∧ Σ commit global state
```

#### D9 — Quarantine Revokes Ordinary Reachability

```text id="sgtyr1"
driver/device quarantined
⇒ ordinary capabilities revoked or narrowed
∧ scheduler/resource/device visibility updated
```

#### D10 — Unload Leaves No Dangling References

```text id="a3cc8a"
UNLOADED(driver)
⇒ no IRQ handler
∧ no active work item
∧ no DMA mapping
∧ no live binding
∧ no reachable driver frame reference
```

#### D11 — Driver and Device Resource Use Is Accounted

```text id="i0g9qr"
driver/device resource use
⇒ DriverRAcc or DeviceRAcc updated and policy-checked
```

### 17.16 Cross-Subsystem Invariants

PMS-OS subsystems compose through shared operator discipline.

#### CS1 — Frame Coherence Across Subsystems

A frame referenced by one subsystem must remain coherent when referenced by another.

```text id="wc9xr3"
FrameId used in VM / FS / IPC / Device / Cache
⇒ same lifecycle and boundary state is respected
```

#### CS2 — Commit Order Is Preserved Across Layers

Example:

```text id="g7fpq7"
filesystem journal intent
→ block-device write
→ device flush
→ filesystem metadata visible
```

A higher layer may not claim committed state before its lower-layer Σ requirements are satisfied.

#### CS3 — Policy Applies Across Homomorphic Boundaries

A syscall, VM operation, filesystem action, block request, cache flush, IPC send, or driver action may cross subsystem boundaries, but it remains Ψ-constrained.

```text id="q6jbdm"
valid_cross_layer_transition
⇒ Ψ effective policy holds at every relevant layer
```

#### CS4 — Resource Accounting Follows Effects

If a transition consumes, releases, stages, flushes, maps, pins, delivers, or allocates resources, the accounting state must reflect it.

```text id="uoic8v"
resource_effect ⇒ RAcc update ⇒ Σ commit
```

#### CS5 — Faults Preserve Recoverability

A subsystem fault must either:

```text id="oql0m4"
resolve
deny
rollback
quarantine
terminate
halt under policy
```

It may not leave half-typed state without policy-defined interpretation.

### 17.17 Trace and Audit Representability

PMS-OS transitions should be representable as operator-labeled events.

A generic OS trace event may contain:

```text id="o4uhsx"
TraceEvent = (
    event_id,
    actor,
    role,
    frame,
    boundary,
    subsystem,
    operation,
    operator_class,
    policy_decision,
    commit_state,
    resource_accounting_state,
    result,
    timestamp_or_order,
    metadata
)
```

Trace notation:

```text id="s65ck3"
trace_os(K, π_os, s₀) ∈ L_PMS
trace_os(K, π_os, s₀) ∈ L_PMS,Ψ_kernel
Trace_os(K, π_os, s₀) ⊆ L_PMS
Trace_os(K, π_os, s₀) ⊆ L_PMS,Ψ_kernel
```

Traceable events include:

```text id="xqc6b7"
syscall entry/return
context switch
policy decision
frame mapping
resource update
allocation/free
page fault
filesystem mutation
journal commit
block I/O
cache flush
IPC delivery
lock wait/wake
signal delivery
driver bind/unbind
IRQ handling
hotplug attach/detach
quarantine
halt
```

Architectural requirement:

```text id="ertw1t"
operator-labeled representability
```

Implementation choice:

```text id="sz9n4s"
whether, where, and how much trace is emitted
```

Thus PMS-OS requires structural accountability without mandating one logging format in this document.

Trace and audit evidence strengthen bounded implementation-artifact claims.

They do not validate PMS Base.

### 17.18 Invariant Enforcement Points

Invariants may be enforced at multiple points.

| Enforcement point  | Examples                                                            |
| ------------------ | ------------------------------------------------------------------- |
| boot               | mandatory policies, driver registry, filesystem root, kernel frames |
| syscall entry      | argument checking, authority, policy                                |
| scheduler dispatch | READY state, resource eligibility, frame/role/boundary coherence    |
| page fault         | VM resolution, COW, demand paging                                   |
| commit boundary    | filesystem, IPC, accounting, cache, device write                    |
| policy update      | invariant preservation, policy epoch                                |
| driver lifecycle   | bind, activate, suspend, quarantine, unload                         |
| resource pressure  | reclaim, throttle, OOM, quota responses                             |
| trap/interrupt     | safe recontextualization                                            |
| shutdown/unmount   | flush, closure, no dangling references                              |

The kernel may check invariants eagerly, lazily, at commit points, at policy hooks, or through conformance checks, as long as the selected profile preserves the architectural conditions.

### 17.19 Failure Response Matrix

Invariant failure responses are operator-typed.

| Failure type               | Primary response                                  |
| -------------------------- | ------------------------------------------------- |
| invalid distinction        | Δ failure → Φ/error path                          |
| unauthorized action        | Ω denial → Φ/error or Ψ denial                    |
| invalid frame              | □ failure → Φ trap/recovery                       |
| absence/non-event          | Λ outcome                                         |
| invalid ordering           | Θ policy response                                 |
| invalid boundary           | Χ denial/quarantine                               |
| invalid mutation           | Φ rollback or Ψ denial                            |
| invalid commit             | Σ failure → Φ recovery                            |
| invalid resource state     | RAcc/Ψ denial, throttle, isolation, or Φ recovery |
| policy violation           | Ψ denial/escalation/halt                          |
| critical invariant failure | Ψ halt or panic path                              |

The response must be defined by the relevant subsystem policy.

### 17.20 Implementation Profiles

A PMS-OS implementation profile may choose different concrete mechanisms.

Examples:

```text id="jkivai"
segmentation-style or paging-style VM
monolithic or microkernel-like structure
synchronous or asynchronous IPC
write-through or write-back filesystem policy
minimal or rich driver model
simple round-robin or hierarchical scheduler
interpreted, simulated, or native kernel artifact
```

The profile may vary mechanisms, but it must preserve invariant meaning.

```text id="f5m1xk"
implementation_profile valid iff
    all required OS-level invariants are preserved
```

This allows PMS-OS to be specified independently of one concrete implementation strategy.

A profile can be checked for conformance to these invariants.

Such checking does not constitute PMS Base validation.

### 17.21 Boundary of the OS Invariant Set

This section defines PMS-OS invariants.

It does not define:

```text id="osv8vy"
PMS Base validation
completed production kernel
completed production OS
complete runtime-security governance
distributed consensus
cross-node policy synchronization
language-level ownership rules
compiler verification
hardware proof
formal machine-checked theorem set
external security validation
external driver certification
fabricated hardware substrate
```

Those belong to other PMS-STACK documents or future artifacts.

The positive boundary is:

```text id="fsihhe"
This strengthens the PMS-STACK operating-system architecture claim by
defining the invariant set that a PMS-conformant OS layer must preserve.
```

The invariant set is an implementation-layer architecture claim.

It does not prove PMS Base.

It does not imply that all PMS-OS subsystems have already been implemented.

It defines the PMS-OS closure condition.

### 17.22 Final Architectural Consequence

The PMS-OS invariant set gives the operating-system layer its closure condition.

The consequence is:

```text id="kmellw"
PMS-OS is a kernel-governed, multi-process, policy-constrained,
frame-isolated, resource-accounted operating-system architecture whose
processes, threads, syscalls, memory, allocation, filesystems, storage,
caches, IPC, events, devices, drivers, resources, and recovery paths remain
valid only while their Δ–Ψ invariants are preserved across every
kernel-visible transition.
```

This completes `04_pms_os.md` as an OS architecture specification: strong enough to define a complete PMS-conformant operating-system layer, bounded as an implementation-layer architecture claim, and aligned with PMS Base without treating the OS artifact as PMS Base validation.

### 17.23 Final Boundary Statement

The correct boundary for `04_pms_os.md` is:

```text id="nc4vo2"
PMS-OS specifies the operating-system architecture layer of PMS-STACK: a
kernel-governed system of processes, threads, frames, roles, capabilities,
syscalls, virtual memory, scheduling, resource accounting, storage,
filesystems, caches, IPC, synchronization, events, devices, drivers,
policy, recovery, and invariants derived from Δ–Ψ.

This is an implementation-layer OS architecture claim.

It does not claim a completed kernel artifact, production OS, fabricated
hardware substrate, external security validation, external driver
certification, distributed-system completion, runtime-security completion,
or PMS Base validation.
```
