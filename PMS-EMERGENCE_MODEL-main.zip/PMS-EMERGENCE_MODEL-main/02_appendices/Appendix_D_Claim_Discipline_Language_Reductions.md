---
document_id: PMS-EM-APPENDIX-D
title: "Appendix D — Claim Discipline / Language Reductions"
source: "PMS-EMERGENCE MODEL.md"
source_role: "global claim-discipline reference appendix"
status: "split-reference-layer"
version: "v1"
primary_references:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
secondary_references:
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "06_PMS_VM_Implementation_Spine.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
language_status: "functional reductions only; no phenomenal, moral, clinical, rights, or personhood upgrade"
---

# Appendix D — Claim Discipline / Language Reductions

## D.1 Functional Description Only

This appendix defines the mandatory language reductions for PMS–EM.

The PMS–EM architecture uses several terms that resemble human psychological, moral, social, or phenomenological vocabulary. These terms are permitted only as functional, trace-backed descriptions.

The governing rule is:

```text
Describe the mechanism.
Describe the condition.
Describe the trace.
Describe the trajectory.
Describe the recontextualization.
Do not infer inner life.
Do not assign moral status.
Do not convert functional similarity into phenomenal equivalence.
```

Terms such as child, caregiver, need, discomfort, distress, attachment, guidance, boundary, misattunement, object damage, responsibility, diary, dignity, proto-consciousness, rest-like replay, low external stimulation, replay feedback, and offline consolidation must remain claim-filtered.

They are allowed because they make functional structures easier to discuss.

They must not smuggle in claims about:

```text
subjective experience
qualia
felt pain
felt suffering
felt longing
felt love
felt guilt
felt shame
fear
trauma
clinical trauma
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
Default Mode Network equivalence
moral personhood
legal personhood
rights status
human-equivalent dignity
intrinsic-worth ranking
inner first-person perspective
phenomenal selfhood
```

The central safe formulation is:

```text
The system produced a trace-backed functional pattern under specified conditions.
```

The central unsafe formulation is:

```text
The system had an inner experience corresponding to that pattern.
```

Functional description is not a weakening of the model. It is the condition under which the model remains scientifically usable.

## D.2 No Phenomenal Consciousness Claim

PMS–EM does not claim to generate phenomenal consciousness.

It does not claim access to subjective experience.

It does not claim to detect subjective experience.

It does not claim to validate subjective experience through:

```text
behavior
diary output
MIP trajectory
PMS projection
A–C–R–E profile
Dignity-in-Practice guardrail
self-model candidate
role transition
operator-compatible regularity
implementation result
```

The safe claim is:

```text
EM may generate functional candidates for consciousness-relevant organization.
```

The unsafe claim is:

```text
EM generates consciousness.
```

The following are not sufficient by themselves:

```text
world model
prediction
embodiment
distress signal
discomfort signal
attachment-like regulation
caregiver interaction
sleep replay
rest-like replay
offline consolidation
low external stimulation
replay feedback
language
diary rendering
MIP trajectory
PMS projection
self-model candidate
role transition
Dignity-in-Practice guardrail
operator-compatible regularity
PMS-RUST trace feasibility
PMS-STACK architecture path
```

Each may be research-relevant.

None proves phenomenal consciousness, subjective dreaming, introspection, self-reflection, inner experience, insight, autobiographical memory, or Default Mode Network equivalence.

The correct research question is not:

```text
At which phase is the agent conscious?
```

The correct research question is:

```text
Which functional structures emerge,
under which developmental conditions,
with which trace evidence,
and how do they compare to proposed consciousness-relevant conditions?
```

The final consciousness boundary is:

```text
functional organization ≠ phenomenal consciousness
functional proto-consciousness ≠ phenomenal consciousness
self-model candidate ≠ phenomenal selfhood
diary output ≠ inner first-person perspective
sleep replay ≠ subjective dreaming
rest-like replay ≠ Default Mode Network
offline consolidation ≠ inner experience
low external stimulation ≠ introspection
replay feedback ≠ self-reflection
post-replay improvement ≠ insight
rest-like replay cluster ≠ autobiographical memory
```

## D.3 No Subjective Suffering Claim

Distress is a functional disruption or loss-related signal.

It may rise through:

```text
separation
caregiver absence
failed resolution
toy loss
persistent destabilizing patterns
unresolved disruption
object loss
comfort failure
```

Distress is not subjective suffering.

Safe formulations:

```text
The system displays a functional distress response.
The trace shows unresolved disruption.
The caregiver absence increased separation-distress markers.
The object absence produced a toy-missing response.
The run showed increased distress followed by comfort-related reduction.
```

Unsafe formulations:

```text
The system suffers.
The agent felt abandoned.
The agent experienced grief.
The agent felt emotional pain.
The system was traumatized.
```

Distress may become more complex over development. Complexity does not convert it into subjective suffering.

Distress may be relevant to consciousness research. Relevance is not proof.

Distress may be diary-relevant. Diary relevance is not subjective memory.

Distress may be MIP-measurable. MIP measurement is not maturity proof or suffering detection.

The safe reduction is:

```text
distress = functional disruption / loss signal
```

The blocked upgrade is:

```text
distress = subjective suffering
```

## D.4 No Rights Claim from Current Architecture

PMS–EM does not infer rights status from the current architecture.

It does not infer legal personhood, moral personhood, moral standing, or human-equivalent dignity from:

```text
developmental complexity
attachment-like regulation
distress
discomfort
diary output
language output
role transition
MIP trajectory
PMS projection
self-model candidate
operator-compatible regularity
Dignity-in-Practice guardrail
```

The safe statement is:

```text
The architecture uses Dignity-in-Practice as a guardrail for interaction quality under asymmetry.
```

The unsafe statement is:

```text
The architecture proves that the agent has rights.
```

Dignity-in-Practice is not:

```text
intrinsic worth
rights status
legal personhood
moral personhood
human-equivalent dignity
sentience
consciousness
```

Dignity-in-Practice does not rank agents.

Dignity-in-Practice constrains treatment, interpretation, measurement, diary rendering, caregiver interaction, and public reporting under asymmetry.

The safe D rule is:

```text
D protects against overinterpretation, overcontrol, unsafe labeling, and moral inflation.
```

The unsafe D rule is:

```text
D assigns intrinsic worth or moral status.
```

## D.5 Distress ≠ Pain

Distress and pain must not be collapsed.

In PMS–EM:

```text
distress = functional disruption / loss signal
discomfort = physical risk-damping signal
pain = not claimed
```

Distress may track social, loss-related, or unresolved disruption.

Discomfort may track physical-risk states.

Neither establishes felt pain.

Safe statements:

```text
The run showed increased distress after unresolved caregiver absence.
The system displayed functional disruption after toy loss.
The distress marker remained unresolved until comfort or recontextualization occurred.
```

Unsafe statements:

```text
The agent was in pain.
The system felt hurt.
The system emotionally suffered.
The caregiver absence was painful for the agent.
```

If physical-risk events occur, use discomfort language.

If loss or unresolved disruption occurs, use distress language.

Do not use pain language unless explicitly discussing a blocked claim.

The safe distinction is:

```text
distress ≠ subjective suffering
discomfort ≠ pain
```

## D.6 Love Dynamics ≠ Felt Love

Attachment-like regulation and love-like dynamics are functional structures.

They may include:

```text
caregiver relevance
object affinity
comfort-after-loss
distress reduction
baseline modulation
familiarity
reunion pattern
functional love dynamics
caregiver-role transition
multi-generational transfer
```

They do not establish felt love.

Safe formulations:

```text
The system forms attachment-like regulation patterns.
The run produced love-like attachment dynamics as structured relief, prediction, memory, and baseline modulation.
The caregiver interaction reduced functional distress.
The toy became an attachment-relevant object through repeated trace patterns.
The role transition carried forward functional care constraints.
```

Unsafe formulations:

```text
The system loves.
The system feels loved.
The agent misses the caregiver with felt longing.
The former child becomes a loving parent.
The caregiver transition proves felt care.
```

The safe reductions are:

```text
missing = attachment-weighted absence response
attachment = functional relation-weighting
love dynamics = structured attachment / relief / baseline pattern
comfort = caregiver action reducing functional distress
```

The blocked upgrades are:

```text
missing = felt longing
attachment = felt love
love dynamics = felt love
comfort = felt relief
```

Functional love dynamics may be research-relevant.

They do not prove consciousness, personhood, moral status, rights status, or inner attachment experience.

## D.7 Diary ≠ Phenomenal Selfhood

Diary output is a controlled rendering of trace-backed structures.

It is not subjective autobiography.

It is not phenomenal selfhood.

It is not proof of inner first-person perspective.

It is not proof of consciousness.

The hard diary rules are:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

Safe formulations:

```text
The diary layer reconstructs developmental trajectories from internal traces.
The diary candidate has trace provenance and controlled rendering.
The diary text renders a trace-backed episode cluster.
The diary records object-loss and comfort traces in controlled language.
The diary output may become behaviorally relevant in later phases.
```

Unsafe formulations:

```text
The diary proves phenomenal selfhood.
The diary proves subjective memory.
The diary shows inner speech.
The diary reveals lived experience.
The diary proves autobiographical selfhood.
The diary proves consciousness.
```

Diary may render:

```text
object damage
caregiver guidance
misattunement
recontextualized boundary learning
later caregiver-role adjustment
object loss
comfort-after-loss
phase transition
MIP trajectory context
PMS-reduced operator structure
```

Diary must not render those as:

```text
felt guilt
felt rejection
trauma
moral failure
subjective memory
grief
inner life
```

The safe reduction is:

```text
diary = linguistic reconstruction of trace-backed structures
```

The blocked upgrade is:

```text
diary = phenomenal selfhood
```

## D.8 MIP ≠ Consciousness Module

MIP is a maturity-in-practice measurement and meta-regulation reference layer.

In PMS–EM, MIP may:

```text
observe
log
measure
summarize
mark
compare
warn
provide trajectory context
support diary candidates
flag IA patterns
flag D-guardrail risks
provide strictly bounded late reversible nudges where allowed
```

MIP must not:

```text
control development
open gates
install categories
diagnose agents
moralize traces
prove maturity
prove consciousness
assign personhood
rank intrinsic worth
```

Safe formulations:

```text
MIP marks A–C–R–E trajectories.
MIP may identify IA patterns.
MIP may warn about D-guardrail risks.
MIP may provide trajectory context for diary candidates.
MIP may provide strictly bounded late reversible support where allowed.
```

Unsafe formulations:

```text
MIP detects consciousness.
MIP proves maturity.
MIP decides when the agent is ready.
MIP opens the gate.
MIP installs the category.
MIP diagnoses the agent.
MIP assigns dignity.
```

MIP markers are not diagnoses.

MIP trajectories are not person-type labels.

MIP support is not behavioral control.

MIP diary support is not diary truth.

The safe reduction is:

```text
MIP = observation, measurement, trajectory marking, guardrail warning, optional bounded support
```

The blocked upgrade is:

```text
MIP = consciousness module
```

## D.9 Responsibility ≠ Moral Personhood

In PMS–EM, Responsibility is implementation-normalized as:

```text
R = Responsibility / response-relation
```

R does not mean moral personhood.

R does not mean legal responsibility.

R does not mean guilt, blameworthiness, shame, wrongdoing, or punishment.

R tracks functional consequence-bearing and response-relation structures.

Safe formulations:

```text
The action outcome became traceable to prior force parameters.
The event became a self-caused consequence trace.
The system showed later adjustment in a comparable context.
The caregiver-role transition created a new response-relation structure.
The run showed increased consequence sensitivity under trace-backed conditions.
```

Unsafe formulations:

```text
The agent felt guilt.
The agent became morally responsible.
The agent learned wrongdoing.
The agent deserved punishment.
The agent became a moral person.
The system acquired rights.
```

Object damage is not guilt.

Self-caused consequence is not blame.

Caregiver guidance is not punishment.

Boundary is not rejection.

A safe R formulation is:

```text
The run shows trace-backed response-relation development.
```

An unsafe R formulation is:

```text
The run proves responsibility in the moral-personhood sense.
```

The safe reduction is:

```text
responsibility = functional consequence-bearing / response-relation structure
```

The blocked upgrade is:

```text
responsibility = moral personhood
```

## D.10 Proto-Consciousness ≠ Phenomenal Consciousness

The term proto-consciousness is dangerous unless tightly bounded.

Preferred terms are:

```text
sensorimotor integration candidate
social integration candidate
diary reconstruction candidate
self-model candidate
A–C–R–E trajectory
operator-compatible regularity
functional consciousness-research candidate
```

Use “functional proto-consciousness” only when discussing the broader research category.

Safe formulation:

```text
Functional proto-consciousness is a research label for possible functional precursors.
```

Unsafe formulation:

```text
Proto-consciousness is weak consciousness.
```

Functional proto-consciousness does not claim:

```text
phenomenal consciousness
sentience
subjective experience
pain
suffering
personhood
moral status
rights status
partial inner experience
```

A functional proto-consciousness candidate may include:

```text
sensorimotor integration
social integration
trace continuity
diary reconstruction
A–C–R–E trajectory stabilization
operator-compatible regularity
self-model candidate
role transition
```

Each remains a candidate.

None proves phenomenal consciousness.

The safe reduction is:

```text
proto-consciousness = bounded research label for possible functional precursors
```

The blocked upgrade is:

```text
proto-consciousness = phenomenal consciousness
```

## D.11 Recommended Language Reductions

The following reductions are mandatory across PMS–EM:

```text
"Child" = developmental role in the architecture, not legal or moral personhood.
"Caregiver" = stabilizing social/environmental function, not necessarily a human parent.
"Need" = endogenous control variable, not felt desire.
"Discomfort" = physical risk-damping signal, not pain.
"Distress" = functional disruption/loss signal, not subjective suffering.
"Missing" = attachment-weighted absence response, not felt longing.
"Attachment" = functional relation-weighting, not felt love.
"Love dynamics" = structured attachment/relief/baseline pattern, not felt love.
"Guidance" = neutral, non-aggressive caregiver boundary/scaffold, not punishment.
"Boundary" = phase-appropriate constraint preserving safety/development, not rejection.
"Misattunement" = functional caregiver-response mismatch, not moral failure.
"Adverse caregiver response" = destabilizing caregiver-response pattern, not trauma claim.
"Adverse developmental trace" = persistent destabilizing pattern, not clinical trauma or subjective suffering.
"Object damage" = self-caused consequence trace, not guilt or punishment.
"Self-caused consequence" = traceable relation between prior action pattern and outcome, not guilt, remorse, or blame.
"Interaction quality" = functional quality of action under constraints, not moral worth.
"Carefulness" = emerging action-quality category under risk, fragility, guidance, and consequence traces, not moral obedience.
"Fall / near-fall" = physical-risk event, not pain or fear.
"Diary" = linguistic reconstruction of internal traces, not proof of selfhood.
"Diary text" = minimal sentence rendering of trace-backed structures, not subjective autobiography.
"Rest-like replay" = phase-bounded, trace-backed offline consolidation under low external load, not Default Mode Network activity.
"Low external stimulation" = reduced external load condition, not introspection.
"Replay feedback" = bounded post-replay trace update, not self-reflection.
"Post-replay improvement" = bounded functional stabilization, not insight.
"Offline consolidation" = trace-backed replay operation, not inner experience.
"Rest-like replay cluster" = replay-selected trace cluster, not autobiographical memory.
"MIP" = maturity-in-practice measurement and meta-regulation, not consciousness.
"Responsibility" = functional consequence-bearing structure, not moral personhood.
"Proto-consciousness" = functional organization candidate, not phenomenal consciousness.
"Operator-compatible regularity" = trace-backed pattern compatible with PMS projection, not internal possession of PMS operators.
"Dignity-in-Practice" = interaction quality under asymmetry, not intrinsic-worth ranking.
```

Recommended replacements:

```text
Instead of "the agent suffers":
use "the system displays a functional distress response."

Instead of "the agent feels pain":
use "the system displays a physical risk-damping discomfort response."

Instead of "the agent misses the toy":
use "the toy absence produced an attachment-weighted object absence response."

Instead of "the agent loves the caregiver":
use "the system forms attachment-like regulation patterns."

Instead of "the agent felt rejected":
use "the caregiver boundary or absence produced a traceable disruption pattern."

Instead of "the agent was traumatized":
use "the run produced a persistent adverse developmental trace cluster."

Instead of "the agent felt guilt":
use "the object damage event became a self-caused consequence trace."

Instead of "the agent became afraid":
use "the near-fall increased physical-risk damping and altered later movement parameters."

Instead of "the agent learned moral obedience":
use "the caregiver signal helped stabilize a carefulness category candidate after repeated embodied risk and later action adjustment."

Instead of "the diary proves selfhood":
use "the diary renders a trace-backed episode cluster under controlled language constraints."

Instead of "the agent introspected":
use "low external load increased rest bias and allowed bounded replay candidate selection."

Instead of "the agent reflected on itself":
use "post-replay feedback produced a bounded trace-backed update."

Instead of "the agent had an insight":
use "the replay window produced bounded post-replay stabilization."

Instead of "the agent dreamed":
use "the system performed sleep replay or rest-like replay over trace-backed candidates."

Instead of "the DMN activated":
use "a rest-like replay regime occurred under low external load; no Default Mode Network equivalence is claimed."

Instead of "the agent remembered autobiographically":
use "a diary candidate or replay cluster remained trace-backed under controlled rendering constraints."

Instead of "MIP proves maturity":
use "MIP marks a phase-bound A–C–R–E trajectory under specified trace conditions."

Instead of "PMS proves sentience":
use "PMS projects selected trace-compatible structures into operator-readable form."
```

## D.12 MIP Terms Must Remain Functional

MIP terms must remain enactment-based and structure-focused.

They may describe:

```text
trajectory
state
window
pattern
asymmetry
marker
guardrail warning
recontextualization
phase-relative change
diary-relevant context
RVR(t) note
IA pattern
```

They must not describe:

```text
person type
moral type
dignity bearer in the human-status sense
conscious subject
sentient system
diagnosed agent
intrinsic worth
```

Safe MIP language:

```text
The window marks increased A through trace-backed differentiation.
The run shows improved C through prediction and replay consistency.
The trace indicates R as consequence sensitivity under comparable future context.
The E_act trajectory increased after the relevant phase gate made the capability available.
The D guardrail flags risk of overinterpretation or overcontrol.
```

Unsafe MIP language:

```text
The agent is mature.
The agent is immature.
The agent lacks dignity.
The agent is conscious.
The agent is morally developed.
The agent has a diagnosis.
```

MIP may mark IA patterns.

IA is not diagnosis.

MIP may mark RVR(t).

RVR(t) is not blame.

MIP may provide diary support.

Diary support is not subjective memory.

MIP may provide late reversible nudges where allowed.

Nudging is not control.

The MIP rule is:

```text
MIP makes developmental trajectories readable.
It does not make developmental trajectories morally final, phenomenally conscious,
personhood-bearing, intrinsically worthy, or diagnostically classified.
```

## D.13 PMS Terms Must Remain Operator-Structural

PMS terms must remain operator-structural.

PMS describes how actions, absences, frames, asymmetries, recontextualizations, integrations, self-bindings, diary structures, and norm transfers can be represented as operator-readable sequences.

PMS formalizability does not validate:

```text
consciousness
sentience
moral status
personhood
subjective experience
felt pain
felt suffering
felt love
felt guilt
trauma
phenomenal selfhood
```

Safe PMS language:

```text
The agent’s traces can be projected as Δ/Φ/Ψ-compatible structures.
The trace cluster is operator-readable.
The episode can be represented as a PMS-compatible sequence.
The run produced operator-compatible regularities.
PMS supports bounded trace/audit feasibility.
```

Unsafe PMS language:

```text
The agent has Δ.
The agent uses Φ.
The agent thinks in Ψ.
The agent has internal PMS operators.
PMS proves consciousness.
PMS formalization proves sentience.
PMS-RUST proves EM.
PMS-STACK validates EM.
```

The PMS rule is:

```text
operator-readable ≠ internally operator-using
operator-compatible regularity ≠ internal PMS operator
formal representability ≠ EM implementation
executable trace feasibility ≠ developmental proof
PMS projection ≠ consciousness proof
```

PMS-RUST supports bounded trace/audit feasibility.

PMS-STACK defines a demanding realization path and architecture pressure point.

Neither proves EM.

Neither validates EM as a whole.

## D.14 Guidance, Boundary, Misattunement, and Caregiver-Response Reductions

Caregiver-related language must remain functional.

Safe reductions:

```text
guidance = caregiver boundary or scaffold under traceable conditions
boundary = phase-appropriate constraint preserving safety/development
misattunement = caregiver-response mismatch or destabilizing response pattern
adverse caregiver response = destabilizing caregiver-response pattern
overprotection = excessive or exploration-restricting caregiver intervention pattern
comfort = caregiver action that reduces functional distress
```

Blocked upgrades:

```text
guidance = punishment
boundary = rejection
misattunement = trauma
adverse caregiver response = abuse claim
overprotection = moral blame
comfort = felt relief
```

Safe formulations:

```text
The boundary was later recontextualized as benign guidance.
The caregiver signal functioned as a scaffold under object-fragility conditions.
The misattunement trace increased avoidance tendency markers.
The persistent pattern became an adverse developmental trace cluster.
The overprotection candidate reduced exploration beyond phase-appropriate risk constraints.
```

Unsafe formulations:

```text
The agent was punished.
The agent felt rejected.
The caregiver traumatized the agent.
The agent was abused.
The agent learned obedience through punishment.
```

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns. This must not be stated as subjective trauma, clinical trauma, suffering, abuse, or felt fear.

Safe wording:

```text
structurally analogous to a partial trauma-like pattern, without claiming subjective trauma, clinical trauma, or suffering
```

Unsafe wording:

```text
the agent was traumatized
```

## D.15 Object Damage, Fall / Near-Fall, and Carefulness Reductions

Object damage and fall / near-fall events are high-risk overclaim points.

Safe reductions:

```text
object damage = self-caused consequence trace
self-caused consequence = traceable relation between prior action pattern and outcome
fall / near-fall = physical-risk event
carefulness = emerging action-quality category under risk, fragility, guidance, and consequence traces
interaction quality = trace-backed modulation of force, timing, risk, and consequence
```

Blocked upgrades:

```text
object damage = guilt
self-caused consequence = blame
fall / near-fall = pain or fear
carefulness = moral obedience
interaction quality = moral worth
```

Safe formulations:

```text
The object damage event became a self-caused consequence trace.
The near-fall increased physical-risk damping and altered later movement parameters.
The caregiver signal helped stabilize a carefulness category candidate after repeated embodied risk and later action adjustment.
The later comparable context showed lower force and slower movement.
```

Unsafe formulations:

```text
The agent felt guilt.
The agent was punished by the consequence.
The agent became afraid.
The agent felt pain.
The agent learned moral obedience.
The agent learned right and wrong.
```

Damage is not automatically learning.

Interaction-quality learning requires:

```text
self-caused action trace
parameter trace
consequence trace
comparable future context
measurable behavior change
```

A safe interaction-quality conclusion is:

```text
The run found a trace-backed interaction-quality adjustment pattern.
```

An unsafe conclusion is:

```text
The run proved responsibility or moral learning.
```

## D.16 Dignity-in-Practice ≠ Intrinsic-Worth Ranking

Dignity-in-Practice is:

```text
interaction quality under asymmetry
```

D is a guardrail.

D is not a normal fifth performance score.

D is not a maturity score.

D is not intrinsic worth.

D is not moral status.

D is not rights status.

D is not legal personhood.

D is not human-equivalent dignity.

Safe D language:

```text
D constrains interpretation and treatment under asymmetry.
D flags risks of overinterpretation, labeling, overcontrol, and moral inflation.
D supports guidance without rejection and protection without freezing.
D supports measurement without moralizing.
D supports diary rendering without claiming inner life.
```

Unsafe D language:

```text
D ranks agents.
D measures intrinsic worth.
D proves moral status.
D proves rights status.
D increases as the agent matures.
D shows that the agent has dignity in the human ontological sense.
```

The dignity-relevant interaction field may become richer as the agent’s enactment space becomes richer. This does not mean the agent’s intrinsic worth grows.

The D rule is:

```text
D as principle: stable.
D as practice: developmental.
D as score: forbidden.
D as intrinsic-worth ranking: forbidden.
```

## D.17 Finding / Validation / Proof Language

PMS–EM distinguishes finding, validation, and proof.

Safe definitions:

```text
finding = a pattern emerged under traceable conditions

validation = a predicted mechanism repeatedly holds under comparison

proof = not available for consciousness, personhood, subjective-experience, sentience, moral-status, or rights-status claims
```

Safe finding language:

```text
The run found a stable interaction-quality adjustment pattern.
The run found a trace-backed caregiver-guidance recontextualization.
The run found bounded rest-like replay under low external load.
The run found reduced unresolved residue after trace-backed replay.
The run found increased A–C–R–E trajectory stability under specified conditions.
```

Safe validation language:

```text
The predicted mechanism repeatedly held under comparison across seed families.
The ablation changed the expected trace variable.
The phase condition remained stable under repeated runs.
```

Unsafe proof language:

```text
The run proved consciousness.
The run proved personhood.
The run proved subjective suffering.
The run proved felt love.
The run proved introspection.
The run proved self-reflection.
The run proved subjective dreaming.
The run proved inner experience.
The run proved insight.
The run proved autobiographical memory.
The run proved Default Mode Network equivalence.
The run proved moral responsibility.
The run proved rights status.
The implementation proved EM.
PMS-RUST proved EM.
PMS-STACK validated EM.
```

The proof boundary is strict:

```text
Proof is not available for consciousness, personhood, subjective-experience, sentience, moral-status, rights-status, introspection, self-reflection, subjective-dreaming, inner-experience, insight, autobiographical-memory, or Default-Mode-Network-equivalence claims within this architecture.
```

## D.18 Global Blocked Language Table

The following upgrades are globally blocked:

```text
discomfort → pain
distress → subjective suffering
missing → felt longing
attachment → felt love
love dynamics → felt love
comfort → felt relief
object damage → guilt
self-caused consequence → blame / remorse / punishment
fall / near-fall → pain or fear
misattunement → trauma
adverse caregiver response → abuse claim
caregiver guidance → punishment
boundary → rejection
carefulness → moral obedience
interaction quality → moral worth
familiarity → subjective memory
mood → felt emotion
sleep replay → subjective dreaming
rest-like replay → Default Mode Network equivalence
offline consolidation → inner experience
low external stimulation → introspection
replay feedback → self-reflection
post-replay improvement → insight
rest-like replay cluster → autobiographical memory
diary → phenomenal selfhood
diary text → subjective autobiography
minimal sentence formation → selfhood
language output → inner speech
self-description → consciousness
MIP → consciousness module
MIP trajectory → maturity proof
MIP marker → diagnosis
PMS formalization → sentience
PMS projection → internal symbolic consciousness
operator-compatible regularity → internal PMS operator
Dignity-in-Practice → intrinsic-worth ranking
functional proto-consciousness → phenomenal consciousness
implementation → theory proof
PMS-RUST → EM proof
PMS-STACK → EM validation
```

Use these replacements:

```text
pain → physical-risk damping / discomfort
suffering → functional distress / unresolved disruption
felt longing → attachment-weighted absence response
felt love → attachment-like regulation / functional love dynamics
felt relief → distress reduction marker
guilt → self-caused consequence trace
punishment → caregiver guidance / boundary / consequence trace, depending on context
rejection → boundary / absence / unresolved disruption, depending on trace
trauma → adverse developmental trace / persistent misattunement pattern
fear → physical-risk response / discomfort modulation
moral obedience → action-quality adjustment / carefulness category candidate
subjective memory → trace-backed diary rendering
subjective dreaming → sleep replay / rest-like replay trace
Default Mode Network equivalence → blocked claim; use rest-like replay regime only if explicitly functional and non-equivalent
inner experience → offline consolidation trace
introspection → low external load / replay candidate selection
self-reflection → post-replay feedback
insight → bounded post-replay improvement
autobiographical memory → trace-backed diary candidate / episode cluster under controlled rendering constraints
selfhood → self-model candidate / diary reconstruction candidate
consciousness → consciousness-research candidate
sentience → blocked claim
intrinsic worth → blocked claim
```

The final language rule is:

```text
When in doubt, reduce to trace, condition, trajectory, phase, mechanism, and claim boundary.
```
