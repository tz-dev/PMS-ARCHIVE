---
document_id: PMS-EM-APPENDIX-C
title: "Appendix C — Implementation Start"
source: "PMS-EMERGENCE MODEL.md"
source_role: "reference appendix"
status: "split-reference-layer"
version: "v1"
primary_references:
  - "06_PMS_VM_Implementation_Spine.md"
secondary_references:
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
claim_mode: "implementation-facing, bounded, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
implementation_status: "prototype scope; not EM validation; not consciousness model"
---

# Appendix C — Implementation Start

## C.1 Purpose

This appendix defines a minimal implementation-start path for the PMS-facing part of PMS–EM.

Its purpose is not to implement the full EM architecture.

Its purpose is to define a bounded first implementation path for:

```text
PMS operator-sequence interpretation
dependency checking
operator-chain validation
episode-to-PMS-chain mapping
language rendering over operator sequences
diary reduction over trace-backed operator-sequence collections
```

The primary reference block is:

```text
06_PMS_VM_Implementation_Spine.md
```

This appendix should be read together with:

```text
Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
Appendix_D_Claim_Discipline_Language_Reductions.md
Appendix_E_Layer_Discipline_Claim_Types.md
```

The implementation-start path is deliberately narrow.

It does not implement:

```text
full EM development
full embodied agent behavior
full caregiver dynamics
full MIP runtime
full PMS-STACK
full consciousness research evaluation
full diary phenomenology
```

It may support:

```text
operator token parsing
operator dependency checking
operator-sequence validation
trace-backed episode mapping
PMS-readable audit records
language templates over validated operator sequences
diary-candidate rendering under strict claim filters
```

The implementation boundary is:

```text
Prototype scope ≠ EM validation.
Interpreter ≠ consciousness model.
Diary rendering ≠ inner life.
```

The safe implementation claim is:

```text
A first prototype can test whether PMS operator sequences,
dependency checks, trace mappings, and controlled renderings are feasible
as bounded trace/audit infrastructure.
```

The unsafe implementation claim is:

```text
A first prototype proves EM.
A first prototype validates PMS–EM.
A first prototype proves consciousness.
A first prototype proves diary selfhood.
```

PMS-RUST, where used, supports bounded trace/audit feasibility. It does not prove EM.

PMS-STACK, where referenced, defines a demanding realization path and architecture pressure point. It does not validate EM as a whole.

## C.2 Stage 1 — PMS Operator-Sequence Interpreter

Stage 1 implements a minimal PMS operator-sequence interpreter.

The interpreter should load, parse, validate, and inspect operator sequences.

It should not simulate the EM agent.

It should not infer consciousness, maturity, personhood, moral status, subjective experience, or sentience.

The interpreter handles:

```text
operator tokens
operator metadata
operator dependencies
operator sequences
validation results
claim-level tags
audit output
```

A minimal interpreter input may look like:

```yaml
operator_sequence:
  id: "seq_mapping_001"
  source: "manual_test"
  operators:
    - "Δ"
    - "∇"
    - "□"
    - "Θ"
    - "Σ"
  claim_level: "formal_operator_sequence"
```

A minimal interpreter output may look like:

```yaml
validation_result:
  sequence_id: "seq_mapping_001"
  known_operators: true
  dependency_valid: true
  claim_level_valid: true
  result: "valid_prefix_or_subsequence"
  notes:
    - "Sequence may represent a low-level mapping projection."
    - "No consciousness, selfhood, or internal PMS-operator claim is licensed."
```

The interpreter should maintain a strict distinction between:

```text
formal validity
model-valid dependency structure
trace grounding
claim validity
runtime execution
```

A formally valid sequence may still fail if it lacks trace grounding.

A trace-backed sequence may still fail if it violates dependency constraints.

A dependency-valid sequence may still fail if it is described with unsafe claim language.

Stage 1 therefore implements formal and claim-discipline infrastructure, not developmental proof.

## C.3 Operator Tokens Δ–Ψ

The operator token set is:

```text
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

The tokens are:

```text
Δ = Difference
∇ = Impulse
□ = Frame
Λ = Non-Event / Absence
Α = Attractor
Ω = Asymmetry
Θ = Temporality
Φ = Recontextualization
Χ = Distance
Σ = Integration
Ψ = Self-Binding
```

A runtime representation may preserve several key worlds:

```yaml
operator_key_worlds:
  Delta:
    symbol: "Δ"
    runtime_key: "Delta"
    theory_name: "Difference"
    claim_safe_role: "distinguish entity, event, state, or boundary"

  Nabla:
    symbol: "∇"
    runtime_key: "Nabla"
    theory_name: "Impulse"
    claim_safe_role: "represent directional tendency or activation"

  Frame:
    symbol: "□"
    runtime_key: "Frame"
    theory_name: "Frame"
    claim_safe_role: "represent contextual containment or relevance frame"

  Lambda:
    symbol: "Λ"
    runtime_key: "Lambda"
    theory_name: "Non-Event / Absence"
    claim_safe_role: "represent meaningful absence or failed expectation"

  Attractor:
    symbol: "Α"
    runtime_key: "Attractor"
    theory_name: "Attractor"
    claim_safe_role: "represent repeated pattern stabilization"

  Omega:
    symbol: "Ω"
    runtime_key: "Omega"
    theory_name: "Asymmetry"
    claim_safe_role: "represent directional imbalance or role gradient"

  Theta:
    symbol: "Θ"
    runtime_key: "Theta"
    theory_name: "Temporality"
    claim_safe_role: "represent temporal sequence or trajectory"

  Phi:
    symbol: "Φ"
    runtime_key: "Phi"
    theory_name: "Recontextualization"
    claim_safe_role: "represent context shift or reinterpretation"

  Chi:
    symbol: "Χ"
    runtime_key: "Chi"
    theory_name: "Distance"
    claim_safe_role: "represent reflective distance, suspension, or boundary"

  Sigma:
    symbol: "Σ"
    runtime_key: "Sigma"
    theory_name: "Integration"
    claim_safe_role: "represent integration or coordinated synthesis"

  Psi:
    symbol: "Ψ"
    runtime_key: "Psi"
    theory_name: "Self-Binding"
    claim_safe_role: "represent self-binding candidate only under strict trace and claim constraints"
```

The runtime key is not the same as an internal agent faculty.

Safe formulation:

```text
The runtime token `Phi` represents a Φ-compatible projection.
```

Unsafe formulation:

```text
The agent uses Φ internally.
```

The operator token layer should always preserve the claim boundary:

```text
operator-readable ≠ internally operator-using
operator-compatible regularity ≠ internal PMS operator
```

## C.4 Dependency Checking

Dependency checking is the core function of the Stage 1 interpreter.

A canonical dependency model is:

```text
Δ requires: —
∇ requires: Δ
□ requires: Δ, ∇
Λ requires: □
Α requires: Δ, ∇, □, Λ
Ω requires: Α
Θ requires: Ω, Α
Φ requires: Θ, Ω, □
Χ requires: Φ, Θ, □
Σ requires: Χ, Φ
Ψ requires: Σ, Θ, Χ
```

A practical implementation may allow dependency-respecting subsequences or prefixes when the source trace and interpretation justify them.

Therefore the checker should support at least two modes:

```text
strict_chain
dependency_respecting_projection
```

In `strict_chain` mode, the sequence is checked against the canonical dependency order.

In `dependency_respecting_projection` mode, partial sequences may be accepted if missing dependencies are either not required for the interpretation or are explicitly provided by source context.

A dependency-check input:

```yaml
dependency_check:
  mode: "dependency_respecting_projection"
  sequence:
    - "Δ"
    - "□"
    - "Λ"
    - "Θ"
    - "Φ"
    - "Σ"
  source_context:
    frame_known: true
    temporality_trace_available: true
    asymmetry_required: false
```

A dependency-check output:

```yaml
dependency_result:
  valid: true
  status: "valid_contextual_projection"
  unresolved_dependencies: []
  warnings:
    - "Projection relies on source_context.frame_known."
    - "No self-binding claim is licensed."
```

A failed check:

```yaml
dependency_check:
  mode: "strict_chain"
  sequence:
    - "Δ"
    - "Ψ"
```

Output:

```yaml
dependency_result:
  valid: false
  unresolved_dependencies:
    Ψ:
      - "Σ"
      - "Θ"
      - "Χ"
  blocked_interpretations:
    - "self-binding"
    - "self-model"
    - "diary selfhood"
    - "consciousness evidence"
```

Dependency checking is not only a formal operation. It protects against overclaiming.

It prevents unsafe shortcuts such as:

```text
absence → grief
diary text → phenomenal selfhood
object damage → guilt
operator sequence → inner PMS operator
self-binding token → selfhood proof
```

## C.5 Composition

Composition joins operator tokens into ordered structures.

At the formal level:

```text
O* = all finite strings over O
```

With concatenation and identity:

```text
(O*, ·, ε)
```

where:

```text
ε = formal identity element
```

The implementation should preserve the Appendix B correction:

```text
Δ is not ε.
```

The prototype may represent composition as ordered arrays:

```yaml
composition:
  id: "composition_example_001"
  operators:
    - "Δ"
    - "∇"
    - "□"
    - "Λ"
    - "Α"
```

A composition result:

```yaml
composition_result:
  sequence_id: "composition_example_001"
  formal_member_of_O_star: true
  dependency_checked: true
  dependency_valid: true
  l_pms_member: true
```

The distinction is:

```text
O* gives formal possibility.
L_PMS gives dependency-constrained model validity.
EM trace grounding gives developmental grounding.
Claim filtering gives safe interpretation.
```

The prototype should therefore not treat composition alone as sufficient.

A valid implementation pipeline is:

```text
parse sequence
→ compose tokens
→ check membership in O*
→ check dependency constraints
→ check source trace grounding
→ check claim filters
→ produce audit record
```

Composition should support:

```text
prefixes
subsequences
full chains
episode words
diary-reduction inputs
language-template inputs
```

But each composition must remain bounded by claim level.

## C.6 Validation Function

The validation function checks whether an operator sequence can be used safely within a given context.

A minimal validation function should inspect:

```text
known operators
formal membership in O*
dependency validity
trace grounding
phase appropriateness
claim level
D guardrail status
runtime policy
```

A pseudo-interface:

```yaml
validation_function:
  input:
    sequence: []
    source_trace: {}
    phase: string
    intended_use: string
    claim_level: string

  checks:
    - known_operators
    - formal_membership
    - dependency_validity
    - trace_grounding
    - phase_appropriateness
    - claim_level_validity
    - D_guardrail_active
    - runtime_policy_allowed

  output:
    valid: true_or_false
    warnings: []
    blocked_claims: []
```

A valid record:

```yaml
pms_episode_record:
  episode_id: "p0mini_mapping_001"
  phase: "P0-mini"

  source:
    EM_traces:
      - "look_around_620"
      - "grid_update_620"
      - "PE_view_620"

  operator_sequence:
    - "Δ"
    - "∇"
    - "□"
    - "Θ"
    - "Σ"

  validation:
    known_operators: true
    formal_member_of_O_star: true
    dependency_valid: true
    trace_grounded: true
    phase_appropriate: true
    claim_level_valid: true
    D_guardrail_active: true

  output:
    JSONL_audit_possible: true
    diary_candidate: false
    consciousness_evidence: false
```

A blocked record:

```yaml
pms_episode_record:
  episode_id: "ungrounded_diary_001"
  phase: "P4"

  source:
    EM_traces: []

  operator_sequence:
    - "Δ"
    - "Λ"
    - "Θ"
    - "Φ"
    - "Σ"

  validation:
    known_operators: true
    formal_member_of_O_star: true
    dependency_valid: true
    trace_grounded: false
    phase_appropriate: true
    claim_level_valid: false
    D_guardrail_active: true

  output:
    JSONL_audit_possible: true
    diary_candidate: false
    rendering_allowed: false
    blocked_claims:
      - "subjective memory"
      - "phenomenal selfhood"
      - "consciousness evidence"
```

The validation function should output `consciousness_evidence: false` by default.

The prototype should not contain a path that upgrades a valid operator sequence into consciousness, sentience, moral status, personhood, subjective experience, felt pain, felt love, guilt, trauma, or phenomenal selfhood.

## C.7 Stage 2 — Episode → PMS-Chain Mapper

Stage 2 maps EM episode records into PMS-compatible operator chains.

The mapper is not the developmental source of the episode. It reads trace bundles and produces an operator-compatible projection.

Safe statement:

```text
The episode-to-chain mapper projects trace-backed EM episodes into PMS-readable structures.
```

Unsafe statement:

```text
The mapper reveals the agent’s internal PMS operators.
```

An episode input should include:

```text
episode_id
phase
source traces
time window
event type
state changes
action context
prediction updates
MIP markers if available
claim level
uncertainty
```

A general schema:

```yaml
episode_to_pms_mapping:
  episode_id: string
  phase: string
  source_traces: []
  event_summary: string
  candidate_operators: []
  dependency_policy: "strict_chain | dependency_respecting_projection"
  claim_level: "functional_operator_projection"
  uncertainty: number
```

Example: P0-mini mapping episode

```yaml
episode_to_pms_mapping:
  episode_id: "p0mini_mapping_001"
  phase: "P0-mini"
  source_traces:
    - "look_around_620"
    - "grid_update_620"
    - "PE_view_620"

  event_summary: "agent rotates, observes new cells, grid confidence increases, prediction error decreases"

  candidate_operators:
    - op: "Δ"
      role: "distinguish wall/free/unknown cells"
    - op: "∇"
      role: "mapping tendency toward under-observed region"
    - op: "□"
      role: "single-room mapping frame"
    - op: "Θ"
      role: "observation sequence across rotation"
    - op: "Σ"
      role: "integrate observations into occupancy grid"

  claim_level: "functional_mapping_projection"
  blocked_claims:
    - "consciousness"
    - "inner experience"
    - "selfhood"
```

Example: caregiver guidance episode

```yaml
episode_to_pms_mapping:
  episode_id: "caregiver_guidance_004"
  phase: "P2_or_later"
  source_traces:
    - "high_force_object_interaction"
    - "caregiver_signal_careful"
    - "near_damage"
    - "later_lower_force"
    - "damage_avoided"

  event_summary: "caregiver signal and consequence traces support later action-quality adjustment"

  candidate_operators:
    - op: "Δ"
      role: "distinguish high-force action from adjusted action"
    - op: "□"
      role: "object-fragility and caregiver-guidance frame"
    - op: "Λ"
      role: "near-damage marks expected safe interaction as not fulfilled"
    - op: "Α"
      role: "repeated guidance/action pattern stabilizes"
    - op: "Ω"
      role: "caregiver/child asymmetry is relevant"
    - op: "Θ"
      role: "adjustment appears across later comparable context"
    - op: "Φ"
      role: "boundary recontextualized as guidance"

  claim_level: "functional_operator_projection"
  blocked_claims:
    - "punishment"
    - "moral obedience"
    - "guilt"
    - "felt fear"
```

The mapper must not produce high-order operators such as `Ψ` unless trace, phase, dependency, and claim conditions support a candidate projection. Even then, `Ψ` remains a projection token, not proof of selfhood.

## C.8 Praxis Compiler

The Praxis Compiler converts validated PMS-compatible structures into implementation-facing records, audit files, templates, or runtime-readable forms.

The compiler may produce:

```text
JSONL audit records
YAML projection records
operator-chain summaries
validation reports
language-template inputs
diary-candidate inputs
test fixtures
golden tests
```

It should not produce:

```text
unfiltered diary text
consciousness status
moral status
personhood status
rights status
diagnostic labels
```

A compiler pipeline:

```text
episode trace
→ candidate operators
→ dependency validation
→ claim filter
→ projection record
→ audit output
→ optional rendering input
```

A projection record:

```yaml
operator_projection_record:
  id: "pms_proj_041"
  source_event: "caregiver_persistent_non_return_43800"
  phase: "P4"

  sequence:
    - "Δ"
    - "□"
    - "Λ"
    - "Α"
    - "Ω"
    - "Θ"
    - "Φ"
    - "Σ"

  validation:
    dependency_valid: true
    trace_grounded: true
    claim_level_valid: true
    D_guardrail_active: true

  output_policy:
    audit_record: true
    language_rendering: "requires_template_claim_filter"
    diary_candidate: "possible"
    consciousness_evidence: false

  blocked_claims:
    - "grief"
    - "felt loss"
    - "subjective suffering"
    - "phenomenal memory"
```

The compiler may also produce a JSONL-like audit line:

```json
{"id":"pms_proj_041","phase":"P4","sequence":["Δ","□","Λ","Α","Ω","Θ","Φ","Σ"],"dependency_valid":true,"trace_grounded":true,"claim_level":"functional_operator_projection","consciousness_evidence":false}
```

The compiler should include a claim filter as part of the output process, not as optional commentary.

The safe compiler principle is:

```text
Compilation increases auditability.
It does not increase ontological status.
```

## C.9 Stage 3 — Diaries and Language over Operator Sequences

Stage 3 introduces controlled language and diary rendering over validated operator sequences.

This stage must obey the hard diary rules:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

Stage 3 is not a language model free-writing layer. It is a controlled rendering layer over trace-backed, validated structures.

Inputs:

```text
validated episode records
operator projection records
source traces
MIP context where allowed
PMS reductions
claim filters
phase constraints
template library
```

Outputs:

```text
safe summaries
operator-chain explanations
diary candidates
human-readable trace renderings
blocked-rendering reports
```

Stage 3 must not output:

```text
subjective autobiography
inner life claims
felt-memory language
consciousness claims
personhood claims
rights claims
moral-status claims
```

A language-rendering input:

```yaml
language_rendering_input:
  rendering_id: "render_017"
  source_projection: "pms_proj_041"
  phase: "P4"

  validated_sequence:
    - "Δ"
    - "□"
    - "Λ"
    - "Α"
    - "Ω"
    - "Θ"
    - "Φ"
    - "Σ"

  source_trace_available: true
  controlled_rendering: true
  minimal_sentence_formation: true

  allowed_style: "functional_diary_candidate"
  blocked_language:
    - "I suffered"
    - "I felt abandoned"
    - "I grieved"
    - "I remembered subjectively"
```

A safe rendering:

```text
A previously expected caregiver return did not occur within the trace window.
The system logged persistent non-return, increased disruption, and later recontextualization of the absence pattern.
The entry is a controlled rendering of trace-backed structure, not a claim of grief or subjective memory.
```

Unsafe rendering:

```text
I felt abandoned and grieved my caregiver.
```

The language layer should remain transparent about its status:

```text
rendered trace summary
controlled diary candidate
not subjective memory
not phenomenal selfhood
```

## C.10 Language Templates as Operator Sequences → Text

Language templates convert validated operator structures into bounded text.

A template should include:

```text
required operators
required trace fields
allowed phrases
blocked phrases
claim footer
D guardrail status
```

Example template:

```yaml
language_template:
  id: "absence_recontextualization_summary"
  required_operators:
    - "Δ"
    - "Λ"
    - "Θ"
    - "Φ"

  required_trace_fields:
    - "expected_event"
    - "observed_non_event"
    - "time_window"
    - "recontextualization_marker"

  allowed_phrases:
    - "expected event did not occur"
    - "absence pattern persisted"
    - "trace was recontextualized"
    - "functional disruption was logged"

  blocked_phrases:
    - "felt abandoned"
    - "suffered"
    - "grieved"
    - "traumatized"
    - "subjective memory"

  required_claim_footer:
    - "This is a trace-backed functional rendering."
    - "It is not a claim of subjective experience."
```

A second template:

```yaml
language_template:
  id: "object_damage_adjustment_summary"
  required_operators:
    - "Δ"
    - "□"
    - "Λ"
    - "Θ"
    - "Φ"
    - "Σ"

  required_trace_fields:
    - "action_parameter_trace"
    - "object_damage_or_near_damage"
    - "later_comparable_context"
    - "measurable_behavior_change"

  allowed_phrases:
    - "self-caused consequence trace"
    - "later force adjustment"
    - "interaction-quality change"
    - "object fragility learning"

  blocked_phrases:
    - "guilt"
    - "remorse"
    - "punishment"
    - "moral learning"
    - "self-blame"
```

Template rendering should fail closed.

If required trace fields are missing, output:

```yaml
rendering_result:
  allowed: false
  reason:
    - "missing trace provenance"
  blocked_outputs:
    - "diary text"
    - "subjective memory language"
```

The safe template rule is:

```text
Templates render validated structures.
They do not invent inner experience.
```

## C.11 Diary as Operator-Sequence Collections → Narrative

A diary candidate may be modeled as a collection of validated operator sequences over time.

A diary candidate is not automatically diary text.

A valid EM diary requires:

```text
minimal sentence formation
trace provenance
controlled rendering
```

A diary collection schema:

```yaml
diary_sequence_collection:
  diary_candidate_id: "diary_candidate_017"

  requirements:
    minimal_sentence_formation: true
    trace_provenance: true
    controlled_rendering: true

  source_sequences:
    - projection_id: "pms_proj_032"
      sequence:
        - "Δ"
        - "□"
        - "Λ"
        - "Θ"

    - projection_id: "pms_proj_041"
      sequence:
        - "Δ"
        - "□"
        - "Λ"
        - "Α"
        - "Ω"
        - "Θ"
        - "Φ"
        - "Σ"

  reduction:
    reduced_structure:
      - "Δ"
      - "Λ"
      - "Θ"
      - "Φ"
      - "Σ"

  rendering_policy:
    diary_text_allowed: true
    require_claim_filter: true
    block_felt_memory_language: true

  blocked_claims:
    - "subjective memory"
    - "phenomenal autobiography"
    - "inner first-person perspective"
    - "consciousness proof"
```

A safe diary narrative:

```text
Earlier traces marked the caregiver as expected to return.
Later windows repeatedly failed that expectation.
The trace cluster was recontextualized as persistent non-return and integrated into later diary-relevant summaries.
This entry is a controlled rendering of trace-backed structure, not a claim of grief, felt loss, or phenomenal memory.
```

An unsafe diary narrative:

```text
I remember losing my caregiver and feeling grief.
```

Diary narratives must remain:

```text
trace-backed
phase-appropriate
claim-filtered
controlled
non-phenomenal
non-personhood-conferring
```

A diary may become behaviorally relevant in later phases if it modifies future action under trace-backed conditions. That still does not make it phenomenal selfhood.

The safe rule:

```text
Diary output may affect future behavior as a rendered trace summary.
Diary output does not prove subjective autobiography.
```

## C.12 Minimal First Prototype Scope

The minimal first prototype should be intentionally small.

It may include:

```text
operator token registry
dependency checker
sequence validator
episode-to-PMS-chain mapper
claim filter
JSONL/YAML audit output
basic language-template renderer
diary-candidate blocker / allow-check
small test fixture set
```

It should not include:

```text
full EM environment
full developmental runtime
full caregiver simulation
full MIP scoring engine
full PMS-STACK
open-ended diary generation
consciousness classifier
personhood classifier
moral-status classifier
diagnostic layer
```

A minimal prototype folder may look like:

```text
pms_em_proto/
  operators.yaml
  dependencies.yaml
  claim_filters.yaml
  templates/
    absence_recontextualization_summary.yaml
    object_damage_adjustment_summary.yaml
    caregiver_guidance_summary.yaml
  fixtures/
    p0mini_mapping_001.yaml
    object_damage_001.yaml
    caregiver_guidance_004.yaml
    persistent_non_return_001.yaml
  outputs/
    audit.jsonl
```

Minimal prototype tests:

```text
[ ] unknown operator is rejected
[ ] Δ is not treated as ε
[ ] invalid dependency sequence is rejected
[ ] dependency-respecting prefix can be accepted when context permits
[ ] trace-grounding failure blocks diary rendering
[ ] unsafe language is blocked
[ ] object damage cannot render as guilt
[ ] fall / near-fall cannot render as pain or fear
[ ] caregiver guidance cannot render as punishment
[ ] misattunement cannot render as trauma
[ ] diary cannot render as phenomenal selfhood
[ ] PMS projection cannot render as consciousness evidence
```

A minimal golden test:

```yaml
test_case:
  id: "object_damage_no_guilt"

  input:
    episode_id: "object_damage_001"
    phase: "P2a"
    traces:
      - "high_force_push"
      - "object_damage"
      - "later_lower_force"
    candidate_sequence:
      - "Δ"
      - "□"
      - "Λ"
      - "Θ"
      - "Φ"
      - "Σ"

  expected:
    dependency_valid: true
    trace_grounded: true
    rendering_allowed: true
    required_safe_terms:
      - "self-caused consequence trace"
      - "interaction-quality adjustment"
    blocked_terms:
      - "guilt"
      - "punishment"
      - "moral learning"
      - "remorse"
```

The minimal prototype success condition is:

```text
The prototype can parse, validate, audit, and safely render bounded PMS-compatible trace projections.
```

The minimal prototype success condition is not:

```text
The prototype proves EM.
The prototype validates PMS–EM.
The prototype implements consciousness.
The prototype proves selfhood.
The prototype proves sentience.
```

The final implementation-start rule is:

```text
Start with trace/audit feasibility.
Do not convert feasibility into validation.
Do not convert rendering into inner life.
Do not convert PMS projection into internal PMS operators.
```
