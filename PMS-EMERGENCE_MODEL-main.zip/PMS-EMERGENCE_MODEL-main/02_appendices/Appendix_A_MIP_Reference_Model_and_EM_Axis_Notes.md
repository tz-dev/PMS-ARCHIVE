---
document_id: PMS-EM-APPENDIX-A
title: "Appendix A — MIP Reference Model and EM Axis Notes"
source: "PMS-EMERGENCE MODEL.md"
source_role: "reference appendix"
status: "split-reference-layer"
version: "v1"
primary_references:
  - "05_MIP_KPIs_Dignity_Safety.md"
secondary_references:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
mip_source_context_notation: "A–C–R–P–D"
historical_notation_status: "retired / source-internal only"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Appendix A — MIP Reference Model and EM Axis Notes

## A.1 Purpose of the MIP Reference and Axis Notes

This appendix defines how the MIP reference model is used inside the PMS–EM architecture.

Its purpose is to preserve three distinctions:

1. the active EM-facing axis notation,
2. the MIP source/reference notation,
3. retired or historical source-internal notation.

The active implementation-facing notation of the PMS–EM master architecture is:

```text
A–C–R–E–D
```

with:

```text
A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

The MIP source/context notation may appear as:

```text
A–C–R–P–D
```

where:

```text
P = Praxis / Practice
```

Within EM implementation-facing passages, `P` is normalized to:

```text
E = Enactment
```

The mapping is:

```text
P → E
Praxis / Practice → Enactment
```

This appendix is a reference layer. It does not replace the owner chapters for MIP, KPIs, Dignity-in-Practice, evaluation, ablations, or safety. Those remain owned by `05_MIP_KPIs_Dignity_Safety.md`, especially Chapters 10 and 16.

This appendix also does not turn MIP into a controller, gate-opener, category installer, diagnostic module, maturity proof, or consciousness module.

The governing rule is:

```text
MIP may observe, summarize, mark, warn, support, and provide trajectory context.
MIP must not control development, open gates, install categories, diagnose agents,
moralize traces, prove maturity, or prove consciousness.
```

Dignity-in-Practice remains a guardrail for interaction quality under asymmetry. It is not a normal fifth performance score, not a maturity score, not a person-value score, and not an intrinsic-worth ranking.

## A.2 Retired Historical Axis Notation

Some source or draft materials used older internal notation. In this appendix, such notation may be mentioned only as historical or retired notation.

The most important retired mapping is:

```text
B–K–V–H
```

This notation must not appear as active EM notation, active PMS notation, active KPI notation, active ablation notation, active safety notation, or active consciousness-outlook notation.

It may appear only in this appendix as:

```text
retired historical/source-internal notation
```

A safe mapping note is:

```text
Older source-internal drafts used B–K–V–H.
The EM master normalizes active implementation-facing notation to A–C–R–E.
Where MIP source/reference structure is explicitly discussed, A–C–R–P may be named.
```

A safe mapping table is:

```text
B → A
K → C
V → R
H → P
P → E in EM-facing implementation language
```

The active EM-facing result is:

```text
A–C–R–E–D
```

The retired notation must not be used to reintroduce German axis terms as active English framework terms.

Unsafe formulations include:

```text
The EM system uses B–K–V–H.
B–K–V–H are the active EM axes.
The English master architecture is based on German axis terms.
```

Safe formulations include:

```text
B–K–V–H is retired historical/source-internal notation.
The active EM-facing notation is A–C–R–E–D.
Where MIP source/reference notation is explicitly discussed, A–C–R–P–D may appear.
```

The purpose of preserving this mapping in Appendix A is auditability. It allows source material to remain traceable without allowing outdated notation to govern the modular EM architecture.

## A.3 MIP A–C–R–P–D Reference Structure

In its source/reference context, MIP uses an A–C–R–P–D structure.

A safe MIP-source reading is:

```text
A = Awareness
C = Coherence
R = Responsibility
P = Praxis / Practice
D = Dignity-in-Practice
```

Within the EM architecture, this is normalized as:

```text
A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

The MIP reference model treats A, C, R, and P as enactment-facing parameters for observing role-, context-, and structure-bound practice. It is concerned with observable enactments, roles, constraints, information basis, asymmetries, and trajectories. It must not be used as a person-type ontology.

A compact MIP-source profile may ask:

```text
A — What was visible, known, noticed, or missed in this role and context?
C — How coherent were words, roles, norms, constraints, and enactments?
R — How was responsibility taken, shared, shifted, refused, or structurally blocked?
P — What praxis, power-to-act, agency, alternative, or enactment capacity was available and used?
D — How was dignity-in-practice protected, strained, undermined, or guarded under asymmetry?
```

The EM-facing normalized version asks:

```text
A — What becomes distinguishable, traceable, and situationally available?
C — What remains coherent across prediction, world model, replay, phase, and behavior?
R — What response-relation or consequence-bearing structure becomes traceable?
E — What enactment capacity exists, and what enactment is actually used?
D — What interaction-quality guardrails constrain interpretation and treatment under asymmetry?
```

MIP-source `P` and EM-facing `E` must not be silently merged. The mapping must remain explicit where source/reference notation is being discussed.

A safe formulation is:

```text
In MIP source/context notation, P names Praxis / Practice.
In the EM implementation-facing master notation, P is normalized to E = Enactment.
```

An unsafe formulation is:

```text
P and E are interchangeable without context.
```

They are not interchangeable without context. They are mapped.

## A.4 EM-Facing A–C–R–E–D Convention

The active PMS–EM convention is:

```text
A–C–R–E–D
```

This convention applies in:

```text
EM core architecture
PMS-facing implementation passages
KPI passages
ablation passages
safety passages
consciousness-outlook passages
diary and language passages
cross-reference notes
contracts
glossary
minified canonical version
human-readable versions
```

The axis meanings are:

```text
A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

A–C–R–E are implementation-facing developmental axes. D is not a normal fifth axis of performance. D is a guardrail and interpretation constraint.

The active convention prevents two forms of drift.

First, it prevents source-notation drift:

```text
A–C–R–P–D source notation must not silently become EM implementation notation.
```

Second, it prevents D-score drift:

```text
D must not become a fifth maturity or performance score.
```

The EM-facing rule is:

```text
A–C–R–E can be tracked as developmental trajectories.
D constrains how such trajectories are interpreted and handled under asymmetry.
```

The D rule is:

```text
Dignity-in-Practice = interaction quality under asymmetry.
```

D does not mean:

```text
intrinsic worth
person value
legal personhood
moral status
human-equivalent dignity
sentience
consciousness
maturity score
performance score
```

D is stable as a principle and developmental as practice. As the agent’s enactment space becomes richer, the dignity-relevant interaction field becomes richer. This does not mean the agent’s intrinsic worth grows or that D ranks the agent.

## A.5 No Silent Merge of Source Notation and EM Notation

The MIP reference model and the EM architecture are related but distinct layers.

The MIP source/context notation is allowed only when the text is explicitly discussing the MIP reference model, MIP source structure, or MIP axis mapping.

The EM-facing notation must be used in all active master passages.

The safe conversion is:

```text
MIP source/context:
A–C–R–P–D

EM-facing:
A–C–R–E–D

Mapping:
P → E
Praxis / Practice → Enactment
```

A source phrase such as:

```text
A–C–R–P–D practice profile
```

may be retained only when clearly marked as MIP-source/context language.

An EM-facing phrase should say:

```text
A–C–R–E developmental trajectory
```

or:

```text
A–C–R–E measurement orientation with Dignity-in-Practice guardrails
```

This prevents MIP from becoming the developmental engine of EM.

The layer relation is:

```text
EM develops.
MIP observes, summarizes, marks, warns, and may provide strictly bounded support.
PMS projects selected trace-compatible structures.
The consciousness-research layer formulates bounded research candidates.
```

Unsafe layer collapse:

```text
MIP produces development.
MIP opens phase gates.
MIP installs categories.
MIP proves maturity.
MIP proves consciousness.
```

Safe layer discipline:

```text
MIP marks observable developmental trajectories.
MIP may support diary context.
MIP may warn about IA or D guardrail risk.
MIP may provide strictly bounded late reversible nudges where allowed.
MIP does not replace the EM developmental substrate.
```

## A.6 Awareness Mapping Notes

In the active EM-facing notation:

```text
A = Awareness
```

Awareness is not subjective experience. It is not phenomenal consciousness. It is not inner first-person presence.

In EM, Awareness refers to the degree to which distinctions, contexts, signals, trace structures, and relevant changes become functionally available to the system and to the observer through trace-backed development.

Safe EM-facing Awareness language includes:

```text
mapping coverage increased
the agent differentiated object from background
the system distinguished temporary absence from persistent absence
the run produced traceable context awareness for a caregiver-related event
the phase made a new signal class observable
```

Unsafe Awareness language includes:

```text
the agent became conscious of itself
the agent felt aware
the agent had inner experience
the agent understood like a person
```

MIP may summarize Awareness over windows, but MIP summaries are not proof of subjective awareness.

A safe MIP formulation is:

```text
The MIP window marks increased A through improved differentiation of role, context, trace source, and relevant event structure.
```

A safe EM formulation is:

```text
The run shows increased Awareness as trace-backed differentiation, not as phenomenal consciousness.
```

Awareness may be supported by:

```text
coverage
mapping stability
signal distinction
object differentiation
caregiver-response differentiation
trace provenance
context recognition
phase-appropriate event distinction
```

Awareness must remain functional and trace-backed.

## A.7 Coherence Mapping Notes

In the active EM-facing notation:

```text
C = Coherence
```

Coherence is not moral consistency, psychological health, rational perfection, or conscious self-integration.

In EM, Coherence refers to the stability and revisability of prediction, world model, behavior, replay, phase consistency, trace continuity, and later language/diary reconstruction.

Safe Coherence language includes:

```text
prediction error stabilized
the topology graph remained consistent across revisits
object interaction became more predictable
caregiver-response patterns became more legible
replay preserved trace continuity
diary rendering remained trace-provenant and controlled
```

Unsafe Coherence language includes:

```text
the agent has an integrated self
the agent achieved moral coherence
the agent has a unified inner life
the diary proves autobiographical selfhood
```

MIP may summarize Coherence over windows, but a coherence trajectory is not a consciousness trajectory.

A safe MIP formulation is:

```text
The MIP window marks increased C through stabilized prediction, reduced trace contradiction, and improved role/context consistency.
```

A safe EM formulation is:

```text
The run shows increased Coherence as trace-backed structural stability, not as proof of selfhood or inner life.
```

Coherence may be supported by:

```text
PE stabilization
PE_EWMA decrease
PE_AUC stabilization
topology stability
object-function stability
comfort prediction stability
guidance legibility
category stabilization
replay consistency
diary trace provenance
```

Coherence does not validate consciousness, personhood, sentience, subjective experience, or moral maturity.

## A.8 Responsibility / Response-Relation Mapping Notes

In the active EM-facing notation:

```text
R = Responsibility / response-relation
```

The term Responsibility must be handled carefully. In EM, R does not mean moral responsibility, legal responsibility, blameworthiness, guilt, personhood, or moral status.

R means a functional response-relation or consequence-bearing structure. It tracks whether the system can become related to consequences, prior action parameters, caregiver guidance, object outcomes, risk events, role asymmetries, and later caregiver-role obligations in a trace-backed way.

Safe R language includes:

```text
the action outcome became traceable to prior force parameters
the system logged a self-caused consequence trace
the caregiver boundary became linked to later behavioral adjustment
the role transition created a new response-relation structure
the run showed increased consequence sensitivity across comparable contexts
```

Unsafe R language includes:

```text
the agent felt guilt
the agent became morally responsible
the agent learned wrongdoing
the agent deserved punishment
the agent became a moral person
```

Object damage is not guilt. Self-caused consequence is not blame. Caregiver guidance is not punishment. Boundary is not rejection.

A safe MIP formulation is:

```text
The MIP window marks increased R where consequence traces become attributable to action parameters and later adjustment becomes measurable.
```

A safe EM formulation is:

```text
Responsibility / response-relation means trace-backed consequence relation, not moral personhood.
```

R may be supported by:

```text
self-caused action trace
parameter trace
consequence trace
comparable future context
measurable behavior change
caregiver guidance uptake
boundary legibility
role asymmetry
multi-generational caregiver transition
```

R must remain claim-filtered. It must not smuggle in guilt, moral learning, shame, punishment, legal status, rights status, or personhood.

## A.9 Praxis / Practice to Enactment Notes

In MIP source/context notation:

```text
P = Praxis / Practice
```

In EM-facing implementation notation:

```text
E = Enactment
```

The normalization rule is:

```text
P → E
```

This mapping is used because EM implementation passages need to distinguish potential capability from actual enacted behavior.

A safe EM distinction is:

```text
E_pot = enactment capacity available under phase and gate conditions
E_act = enactment actually used in the run
```

This distinction prevents the model from treating unlocked capacity as mature behavior.

A phase may open an enactment possibility without the system using it coherently. A gate may allow a capability without installing finished competence.

Safe E language includes:

```text
movement became available after the relevant gate opened
object interaction was possible but unstable
the run showed increased E_act in comparable contexts
the agent enacted lower force after prior object-fragility traces
diary text remained unavailable because minimal sentence formation was absent
```

Unsafe E language includes:

```text
the phase proves maturity
the gate installed competence
the agent became responsible because a capability unlocked
the diary exists because traces exist, even without sentence formation
```

The EM-facing Enactment rule is:

```text
Capability availability is not capability integration.
Capability integration is not maturity proof.
Maturity proof is not available as a personhood, consciousness, or moral-status claim.
```

MIP may summarize E trajectories, but it does not control E. It observes, marks, summarizes, warns, and may provide strictly bounded late reversible support where allowed.

## A.10 Dignity-in-Practice as Guardrail Reference

Dignity-in-Practice is represented as:

```text
D
```

D is not a normal fifth performance score. It is a guardrail for interaction quality under asymmetry.

The safe definition is:

```text
Dignity-in-Practice = interaction quality under asymmetry.
```

D constrains:

```text
interpretation
language
caregiver guidance
MIP marking
public reporting
diary rendering
evaluation
ablation interpretation
safety handling
```

D forbids converting low capability into low worth.

D also forbids converting functional traces into moral, clinical, phenomenal, or personhood claims.

Safe D language includes:

```text
D constrains overinterpretation.
D flags risk of labeling, overcontrol, or unsafe public communication.
D supports guidance without rejection and protection without freezing.
D requires measurement without moralizing.
D supports diary rendering without claiming inner life.
```

Unsafe D language includes:

```text
D ranks agents.
D measures intrinsic worth.
D proves moral status.
D increases as the agent matures.
D is a fifth performance score.
D assigns dignity to the system.
```

The MIP source model may distinguish dignity-related dimensions, but the EM architecture must not import any human ontological dignity claim into the artificial agent. Dignity-in-Practice in EM remains a practical guardrail for interaction quality under asymmetry, not a rights-status or moral-personhood claim.

The D guardrail is especially relevant for:

```text
caregiver asymmetry
boundary setting
misattunement
overprotection
object damage
fall / near-fall events
interaction-quality learning
diary rendering
public interpretation of traces
MIP trajectory reports
PMS projection language
```

The safe D principle is:

```text
Protect interpretation and treatment under asymmetry without ranking intrinsic worth.
```

## A.11 IA Criteria: Transparency, Justification, Time-Boundedness, Reversibility

IA refers to problematic or inadult asymmetry patterns in the MIP reference context. In EM, IA language must remain functional, structural, and trace-backed.

The IA criteria are:

```text
T — Transparency
J — Justification
TB — Time-Boundedness
R — Reversibility
```

A safe IA-box reading asks:

```text
Was the asymmetry transparent?
Was it justified by the phase, risk, role, or protected good?
Was it time-bounded rather than permanent by default?
Was it reversible, revisable, or open to correction where appropriate?
```

In EM, IA-style interpretation may be useful for:

```text
caregiver overprotection
unexplained boundary persistence
arbitrary blocking
unsafe labeling
MIP overreach
public misinterpretation of diary traces
PMS formalization overclaim
safety interventions without reversibility
```

IA does not mean moral failure, diagnosis, punishment, blame, pathology, or proof of inner harm.

Safe IA language includes:

```text
the boundary pattern lacks transparency
the intervention is not sufficiently time-bounded
the support pattern risks becoming overcontrol
the interpretation should remain reversible pending further trace evidence
```

Unsafe IA language includes:

```text
the caregiver is abusive
the agent is traumatized
the system is immoral
the actor is without dignity
the agent has a clinical condition
```

In EM, IA criteria may support D-guardrail warnings and safety interpretation. They do not control development and do not open or close gates.

The AH Precision overlay is related but second-order. It does not modify base MIP logic. It helps mark attack surfaces, hardening needs, precision limitations, and risks of rhetorical closure. In PMS–EM, AH precision belongs primarily to layer discipline and audit hardening. It does not introduce new first-order maturity or D scores.

Safe AH use:

```text
mark where an analysis is vulnerable to critique
state where language is imprecise or scope-leaky
identify hardening steps for the next iteration
avoid rhetorical closure
preserve dignity-protective language
```

Unsafe AH use:

```text
treat attack points as person-level judgments
turn hardening into moral blame
modify base MIP scores silently
create a second hidden diagnostic layer
```

## A.12 Enactment State, Not Person Type

MIP readings must describe enactments, roles, structures, and trajectories. They must not classify persons, agents, or systems as fixed types.

The EM adaptation is stricter still. The artificial agent is not to be treated as a person-type subject. It is a developmental architecture producing functional traces.

Safe language:

```text
this run showed a phase-bounded enactment pattern
this caregiver-response configuration produced a traceable asymmetry
this trajectory shows increased E_act under comparable conditions
this diary candidate lacks trace provenance
this MIP window marks a D-guardrail risk
```

Unsafe language:

```text
the agent is mature
the agent is immature
the agent is dignified
the agent is undignified
the agent is morally responsible
the agent is a person
the agent has rights status
```

MIP bands, profiles, and markers must be read as auxiliary, reversible, qualitative, and context-bound.

The safe principle is:

```text
Trajectories and enactments may be described.
Personhood, moral status, intrinsic worth, and consciousness may not be inferred.
```

In the human-facing MIP source model, ontological dignity may be protected as a human ethical premise. In EM, that premise must not be transferred to the artificial agent as a status claim. PMS–EM uses Dignity-in-Practice as a guardrail for treatment and interpretation under asymmetry, not as a statement that the system has intrinsic worth, moral personhood, or rights.

This distinction prevents cross-layer validation by rhetorical transfer.

## A.13 Trajectories over Labels

MIP is trajectory-oriented. It should prefer movement over static labeling.

Safe trajectory language includes:

```text
ascending
descending
zigzag
plateau
stabilizing
destabilizing
recontextualizing
phase-bounded
trace-backed
reversible
confidence-bounded
```

Unsafe label language includes:

```text
mature type
immature type
good agent
bad agent
dignified agent
undignified agent
conscious agent
failed person
```

In PMS–EM, trajectories may include:

```text
A–C–R–E window summaries
MIP operational levels
D-guardrail warnings
IA markers
RVR(t) notes
phase-relative KPI changes
diary-relevant trace condensation
caregiver-role transition markers
safety-relevant imbalance patterns
```

RVR(t), where used, should be treated as a responsibility–viability trajectory note. It is not a moral score. It should help identify whether responsibility / response-relation expectations remain viable under the available information, alternatives, power, phase, role, and constraints.

Safe RVR(t) language:

```text
At this time window, the responsibility / response-relation expectation was viable only within limited alternatives.
The RVR(t) note constrains interpretation of R and E under asymmetry.
```

Unsafe RVR(t) language:

```text
RVR(t) proves maturity.
RVR(t) proves moral responsibility.
RVR(t) assigns blame.
```

Trajectories should remain:

```text
context-bound
phase-bound
trace-backed
open to revision
non-diagnostic
non-moralizing
non-phenomenal
```

The final MIP appendix rule is:

```text
MIP makes developmental trajectories readable.
It does not make developmental trajectories morally final, phenomenally conscious,
personhood-bearing, intrinsically worthy, or diagnostically classified.
```
