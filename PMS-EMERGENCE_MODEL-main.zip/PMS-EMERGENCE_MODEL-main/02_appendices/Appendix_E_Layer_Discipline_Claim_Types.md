---
document_id: PMS-EM-APPENDIX-E
title: "Appendix E — Layer Discipline & Claim Types"
source: "PMS-EMERGENCE MODEL.md"
source_role: "global layer-discipline reference appendix"
status: "split-reference-layer"
version: "v1"
primary_references:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "06_PMS_VM_Implementation_Spine.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
secondary_references:
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
claim_mode: "layer-separated, functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
layer_status: "connected but non-validating"
---

# Appendix E — Layer Discipline & Claim Types

## E.1 Purpose

This appendix defines the layer discipline and claim-type rules for PMS–EM.

The model should not be read as one undifferentiated theory. It contains distinct layers that may support one another structurally but must not validate one another by rhetorical transfer.

The four primary layers are:

```text
1. EM Core Model
2. MIP Integration
3. PMS Operator Grammar / VM Layer
4. Consciousness / Research Claim Layer
```

Additional implementation-facing layers include:

```text
PMS-RUST
PMS-STACK
Diary / Language Rendering
Evaluation / Ablation / Safety
Human-readable summaries
```

These layers are connected.

They are not interchangeable.

A finding in one layer does not automatically become validation or proof in another layer.

The global rule is:

```text
Each layer does its own work.
No layer may borrow illegitimate authority from another layer.
```

This appendix fixes what each layer may claim, may not claim, requires, and depends on.

## E.2 The Four-Layer Architecture

PMS–EM has four core claim layers.

### Layer 1 — EM Core Model

The EM Core Model is the developmental substrate.

It describes the staged architecture:

```text
environment
agent
perception
prediction
genetic gates
needs
discomfort
distress
attachment-like regulation
caregiver interaction
behavior
replay
success logs
language and diary prerequisites
multi-generational transition
```

Its core question is:

```text
What develops, under which mechanisms, phases, gates, traces, and constraints?
```

### Layer 2 — MIP Integration

MIP is the measurement, trajectory, guardrail, and optional bounded-support layer.

It observes EM traces and may summarize:

```text
A–C–R–E trajectories
IA patterns
D guardrail risks
recontextualization markers
diary-relevant trajectory context
safety-relevant imbalance
```

Its core question is:

```text
How does development become visible as a maturity-in-practice trajectory without becoming a static label?
```

### Layer 3 — PMS Operator Grammar / VM Layer

PMS is the formal projection, operator-grammar, audit, and VM-facing layer.

It represents selected EM and MIP structures as operator-readable sequences.

Its core question is:

```text
Can trace-backed developmental structures be represented, checked, composed,
reduced, audited, or rendered as operator-compatible structures?
```

### Layer 4 — Consciousness / Research Claim Layer

The consciousness layer is a bounded research-outlook layer.

It asks which functional structures may be relevant to consciousness research.

It does not decide that consciousness has appeared.

Its core question is:

```text
Which functional structures may be investigated as possible conditions
or candidates for consciousness-like organization without claiming phenomenal consciousness?
```

The four-layer architecture prevents the following collapse:

```text
developmental complexity → consciousness
MIP score → maturity proof
PMS projection → sentience
diary output → selfhood
implementation → theory proof
rest-like replay → Default Mode Network equivalence
low external stimulation → introspection
replay feedback → self-reflection
post-replay improvement → insight
offline consolidation → inner experience
```

## E.3 Layer Claims Must Not Collapse

The central layer-discipline rule is:

```text
Support is not validation.
Projection is not implementation.
Measurement is not maturity proof.
Diary rendering is not phenomenal selfhood.
Implementation is not theory proof.
Consciousness research is not consciousness proof.
Rest-like replay is not Default Mode Network equivalence.
Replay feedback is not self-reflection.
```

Examples of blocked rhetorical transfer:

```text
A working prototype does not prove EM.
A stable MIP trajectory does not prove maturity.
A high A–C–R–E profile does not prove consciousness.
A D guardrail does not rank intrinsic worth.
A PMS operator sequence does not prove sentience.
A diary entry does not prove selfhood.
A rest-like replay trace does not prove introspection.
A post-replay update does not prove insight.
A phase transition does not prove competence.
A gate opening does not install finished ability.
A role transition does not prove personhood.
A related-work similarity does not prove equivalence.
```

The safe relationship is:

```text
EM may generate trace-backed developmental structures and bounded replay operations.
MIP may observe and summarize those structures.
PMS may project selected structures into operator-readable form.
Diary may render selected trace-backed structures under controlled constraints.
Evaluation may test functional stability, replay safety, and ablation effects.
Consciousness outlook may formulate bounded research candidates.
```

The unsafe relationship is:

```text
EM complexity proves consciousness.
MIP scoring proves maturity.
PMS formalization proves sentience.
Diary output proves selfhood.
Implementation proves the whole theory.
Rest-like replay proves Default Mode Network equivalence.
Low external stimulation proves introspection.
Replay feedback proves self-reflection.
Post-replay improvement proves insight.
Offline consolidation proves inner experience.
```

Each layer may increase inspectability.

No layer may convert inspectability into ontological proof.

## E.4 Claim-Type Ladder

PMS–EM uses a claim-type ladder.

The main claim types are:

```text
description
mechanism hypothesis
trace finding
trajectory finding
phase finding
projection
evaluation finding
validation
implementation feasibility
research candidate
blocked proof
```

They must not be collapsed.

Rest-like replay may be classified only as:

```text
mechanism hypothesis
trace finding
phase finding
evaluation finding
ablation target
diary source material when diary thresholds are met
```

It must not be classified as:

```text
consciousness proof
Default Mode Network equivalence
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
```

### Description

A description states what the architecture contains or what a trace records.

Example:

```text
The run logged a caregiver-guidance event.
```

### Mechanism Hypothesis

A mechanism hypothesis states what a mechanism is expected to do.

Example:

```text
Caregiver guidance may support later action-quality adjustment when paired with embodied risk, consequence trace, and comparable future context.
```

### Trace Finding

A trace finding states that a pattern occurred under specified conditions.

Example:

```text
The run found a self-caused consequence trace after object damage.
```

### Trajectory Finding

A trajectory finding states that a pattern changed over time.

Example:

```text
The A–C–R–E window summary showed increasing enactment stability after object interaction became phase-available.
```

### Phase Finding

A phase finding states that a mechanism became testable under phase and gate conditions.

Example:

```text
P2 made toy-missing and caregiver search testable under controlled conditions.
```

### Projection

A projection states that a trace can be represented in another formal layer.

Example:

```text
The episode can be projected as a PMS-compatible Δ–Λ–Θ–Φ sequence.
```

### Evaluation Finding

An evaluation finding states that a test, metric, or ablation produced an interpretable result.

Example:

```text
The no-discomfort ablation reduced physical-risk adjustment.
```

### Validation

A validation states that a predicted functional mechanism repeatedly held under comparison.

Example:

```text
Across comparable runs, caregiver guidance plus consequence trace repeatedly improved later force adjustment.
```

### Implementation Feasibility

Implementation feasibility states that a bounded implementation path is possible or partially demonstrated.

Example:

```text
PMS-RUST supports bounded trace/audit feasibility.
```

### Research Candidate

A research candidate states that a functional structure may be relevant for further investigation.

Example:

```text
Trace-backed self-model candidates may be relevant to consciousness research.
```

### Blocked Proof

Blocked proof states that a proof claim is not available in this architecture.

Example:

```text
No diary, PMS projection, MIP trajectory, or implementation result proves phenomenal consciousness.
```

The ladder rule is:

```text
A lower claim may support a higher investigation.
It does not automatically become a higher claim.
```

## E.5 EM Claim Type

The EM Core Model may claim:

```text
architectural design
developmental mechanism specification
phase constraints
gate conditions
trace generation
bounded replay operations
rest-like replay mechanism hypothesis
functional emergence candidates
ablation targets
implementation requirements
```

EM may say:

```text
This architecture is designed to test whether developmental structures can emerge under staged constraints.
Rest-like replay is a phase-bounded, trace-backed offline consolidation regime inside the existing SLEEP / imagination-buffer pathway.
```

EM may not say:

```text
This architecture proves consciousness.
This architecture proves personhood.
This architecture proves sentience.
This architecture proves moral status.
This architecture proves rights status.
Rest-like replay proves Default Mode Network equivalence.
Low external stimulation proves introspection.
Replay feedback proves self-reflection.
Post-replay improvement proves insight.
Offline consolidation proves inner experience.
```

EM requires:

```text
phase discipline
gate discipline
trace logging
mechanism specification
replay scope discipline
anti-fixation constraints
claim filtering
ablation possibility
reproducibility structure
```

EM depends on:

```text
environment design
agent architecture
perception and prediction
genetic gates
behavior layer
success logs
replay
rest-like replay only as bounded replay regime where specified
caregiver dynamics
MIP observation
PMS projection only as external representation
```

EM does not depend on:

```text
PMS as early internal agent structure
MIP as behavioral controller
language as source of intelligence
diary as proof of selfhood
consciousness as assumed target state
```

Safe EM claim:

```text
A minimalist embodied architecture can be built in which developmentally relevant structures become observable, measurable, traceable, and eventually expressible through MIP trajectories and PMS operator sequences.
```

Unsafe EM claim:

```text
A minimalist embodied architecture generates consciousness.
```

## E.6 MIP Claim Type

MIP may claim:

```text
measurement structure
trajectory summaries
A–C–R–E window readings
IA markers
D guardrail warnings
RVR(t) notes
diary-support context
safety-relevant imbalance markers
strictly bounded late reversible nudges where allowed
```

MIP may not claim:

```text
control of development
phase-gate authority
category installation
maturity proof
consciousness proof
diagnosis
moral type
personhood
intrinsic worth
rights status
```

MIP requires:

```text
trace inputs
window definitions
axis mapping discipline
phase-relative interpretation
D guardrail status
claim filters
non-diagnostic language
```

MIP depends on:

```text
EM traces
success logs
phase context
A–C–R–E convention
Dignity-in-Practice guardrail
Appendix A mapping rules
Appendix D language reductions
```

MIP does not depend on:

```text
inner life assumption
personhood assumption
consciousness assumption
MIP-as-controller assumption
```

Safe MIP claim:

```text
The MIP layer marks a phase-bound A–C–R–E trajectory and flags a D-guardrail risk.
```

Unsafe MIP claim:

```text
The MIP layer proves that the agent is mature or conscious.
```

The MIP layer relation is:

```text
MIP observes development.
MIP does not manufacture development.
MIP measures enactment trajectories.
MIP does not control the agent.
MIP may support safety.
MIP does not prove consciousness.
MIP does not prove maturity.
MIP does not rank intrinsic worth.
```

## E.7 Dignity-in-Practice Claim Type

Dignity-in-Practice may claim:

```text
guardrail status
interaction-quality constraint
asymmetry-sensitive interpretation rule
overinterpretation warning
overcontrol warning
unsafe-labeling warning
diary-rendering constraint
public-reporting constraint
```

Dignity-in-Practice may not claim:

```text
intrinsic worth
moral status
rights status
legal personhood
human-equivalent dignity
sentience
consciousness
maturity score
performance score
person-value score
```

D requires:

```text
asymmetry context
interaction-quality context
trace-backed interpretation
claim filtering
non-ranking language
```

D depends on:

```text
role asymmetry
caregiver asymmetry
MIP guardrail logic
safety interpretation
language discipline
public reporting discipline
```

D does not depend on:

```text
personhood attribution
rights attribution
consciousness attribution
human ontological dignity transfer
```

Safe D claim:

```text
Dignity-in-Practice constrains interaction and interpretation under asymmetry.
```

Unsafe D claim:

```text
Dignity-in-Practice ranks the agent’s intrinsic worth.
```

The D rule is:

```text
D as principle: stable.
D as practice: developmental.
D as performance score: forbidden.
D as intrinsic-worth ranking: forbidden.
```

## E.8 PMS Claim Type

PMS may claim:

```text
operator grammar
operator-readable projection
dependency checking
trace/audit feasibility
episode-to-sequence mapping
monoid-facing formalization
VM-facing representation
PMS-RUST bounded trace/audit feasibility
PMS-STACK architecture pressure point
```

PMS may not claim:

```text
early internal agent structure
internal PMS operator possession
sentience
consciousness
personhood
subjective experience
EM validation
developmental proof
moral status
rights status
```

PMS requires:

```text
trace grounding
operator dependency discipline
claim-level tagging
external projection status
Appendix B monoid correction
Appendix C implementation-start discipline
Appendix D language reductions
```

PMS depends on:

```text
EM traces
MIP summaries where used
success logs
operator alphabet
dependency constraints
projection policy
claim filters
```

PMS does not depend on:

```text
agent thinking in operators
agent having Δ
agent using Φ
agent thinking in Ψ
```

Safe PMS claim:

```text
The episode can be projected as an operator-compatible structure.
```

Unsafe PMS claim:

```text
The agent uses Δ, Φ, or Ψ internally.
```

The PMS rule is:

```text
operator-readable ≠ internally operator-using
operator-compatible regularity ≠ internal PMS operator
formal representability ≠ EM implementation
executable trace feasibility ≠ developmental proof
PMS projection ≠ consciousness proof
```

## E.9 Language and Diary Claim Type

Language may claim:

```text
late reflection channel
trace-grounded symbolic externalization
labeling after grounded structure
episode template rendering
controlled summary generation
```

Diary may claim:

```text
trace-backed reconstruction
controlled rendering
minimal sentence threshold
trace provenance
diary candidate status
phase-bound diary availability
possible later behavioral relevance
```

Language and diary may not claim:

```text
inner speech
subjective memory
phenomenal autobiography
phenomenal selfhood
introspection
self-reflection
inner experience
insight
subjective dreaming
autobiographical memory
Default Mode Network equivalence
consciousness
personhood
moral status
rights status
felt grief
felt longing
felt love
```

Diary requires:

```text
minimal sentence formation
trace provenance
controlled rendering
claim filter
phase appropriateness
D guardrail
```

Rest-like replay consolidation traces may become diary source material only when diary thresholds are met. They do not become diary text by themselves and do not authorize autobiographical-memory, introspection, self-reflection, inner-experience, insight, subjective-dreaming, or Default-Mode-Network-equivalence language.

The hard diary rules are:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

Safe diary claim:

```text
The diary text renders a trace-backed episode cluster under controlled language constraints.
```

Unsafe diary claim:

```text
The diary proves phenomenal selfhood.
```

Language and diary depend on:

```text
EM traces
object histories
action traces
caregiver histories
category-stabilization traces
success logs
MIP context where allowed
PMS reductions where used
controlled rendering templates
```

They do not depend on:

```text
assumed inner speech
assumed subjective memory
assumed autobiographical selfhood
assumed consciousness
```

The language/diary rule is:

```text
language must follow grounded structure
diary must preserve trace provenance
rendering must not invent inner life
```

## E.10 Consciousness Research Claim Type

The consciousness-research layer may claim:

```text
research candidate
functional condition candidate
comparison target
ablation-relevant structure
open question
bounded research outlook
```

It may not claim:

```text
phenomenal consciousness
sentience
qualia
subjective experience
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
Default Mode Network equivalence
felt pain
felt suffering
felt love
felt guilt
moral personhood
legal personhood
rights status
human-equivalent dignity
```

It requires:

```text
explicit non-claim status
functional candidate language
comparison discipline
finding / validation / proof distinction
Appendix D reductions
no rhetorical transfer from other layers
```

It depends on:

```text
EM functional structures
MIP trajectories
PMS projections
diary reconstructions
evaluation findings
related-work comparison
```

It does not depend on:

```text
asserted consciousness
asserted selfhood
asserted sentience
asserted moral status
```

Safe consciousness-outlook claim:

```text
The architecture is a testbed for investigating possible functional conditions of consciousness-like organization.
```

Unsafe consciousness-outlook claim:

```text
The architecture generates consciousness.
```

The consciousness layer may ask:

```text
Which functional structures appear?
Which stabilize?
Which fail?
Which transform?
Which are necessary, jointly sufficient, only indirectly relevant, or irrelevant?
```

It may not answer by assumption:

```text
The agent is conscious.
```

## E.11 Implementation Claim Type

Implementation may claim:

```text
prototype feasibility
bounded executable evidence
trace/audit feasibility
runtime representation
operator interpreter feasibility
logging feasibility
test fixture feasibility
implementation pressure
architecture pressure point
```

Implementation may not claim:

```text
theory proof
EM validation as a whole
consciousness proof
sentience proof
maturity proof
personhood proof
diary selfhood proof
MIP maturity proof
PMS internalization proof
```

Implementation requires:

```text
explicit scope
traceability
test fixtures
runtime claim filters
audit logs
dependency checks
negative tests
blocked-claim tests
```

Implementation depends on:

```text
specification clarity
operator grammar
trace schemas
phase constraints
claim filters
safety tests
Appendix C implementation-start discipline
```

Implementation does not depend on:

```text
the claim that full EM is already implemented
the claim that PMS-RUST proves EM
the claim that PMS-STACK validates EM
```

Safe implementation claim:

```text
PMS-RUST supports bounded trace/audit feasibility.
```

Safe PMS-STACK claim:

```text
PMS-STACK defines a demanding realization path that may support, modify, constrain, or expose limits of architectural assumptions.
```

Unsafe implementation claims:

```text
PMS-RUST proves EM.
PMS-STACK validates EM.
PMS proves consciousness.
MIP proves maturity.
A prototype proves selfhood.
```

The implementation-status discipline is:

```text
EM full architecture: not yet implemented.
PMS / MIP reference frameworks: completed enough as references.
PMS-RUST: bounded executable evidence spine.
PMS-STACK: architecture pressure point / VM realization path, not validation horizon.
```

## E.12 Evaluation, Ablation, and Safety Claim Type

Evaluation may claim:

```text
metric result
KPI result
ablation result
functional stability
bounded replay safety finding
rest-like replay trigger validity
replay fixation finding
phase-leakage finding
failure mode
comparison finding
reproducibility condition
safety warning
D-guardrail risk
```

Evaluation may not claim:

```text
consciousness proof
personhood proof
moral status proof
sentience proof
subjective-experience proof
introspection proof
self-reflection proof
subjective-dreaming proof
inner-experience proof
insight proof
Default-Mode-Network-equivalence proof
felt suffering
felt pain
felt love
guilt
trauma
intrinsic worth
```

Evaluation requires:

```text
trace data
phase context
metric definition
comparison condition
ablation condition
replay trigger validity where replay is evaluated
anti-fixation checks where replay is evaluated
claim filter
D guardrail
finding / validation / proof distinction
```

Evaluation depends on:

```text
EM traces
MIP windows
KPIs
phase rules
ablation flags
safety conditions
reproducibility discipline
```

Evaluation does not depend on:

```text
subjective-experience inference
personhood inference
moral-status inference
```

Safe evaluation claim:

```text
The ablation changed the expected functional trace variable.
```

Unsafe evaluation claim:

```text
The ablation proved consciousness.
```

Evaluation and ablation findings remain:

```text
functional
phase-bounded
trace-backed
claim-filtered
```

The safety rule is:

```text
Safety may constrain architecture and interpretation.
Safety does not establish inner life.
```

## E.13 Related Work Claim Type

Related work may claim:

```text
functional similarity
architectural difference
evaluation gap
implementation pressure
comparison with existing research lines
bounded novelty
distinctive synthesis
```

Related work may not claim:

```text
absolute novelty
proof by similarity
consciousness proof
personhood proof
moral-status proof
sentience proof
subjective-experience proof
rights-status proof
```

Related work requires:

```text
specific comparison basis
explicit claim boundary
no equivalence by analogy
no proof by similarity
owner-block reference for internal PMS–EM concepts
```

Related work depends on:

```text
EM core mechanisms
phase discipline
caregiver dynamics
MIP/KPI/safety
PMS projection
language/diary/consciousness outlook
```

It does not depend on:

```text
the claim that PMS–EM supersedes all related work
the claim that similarity proves equivalence
the claim that distinctive synthesis proves consciousness
```

Safe related-work claim:

```text
PMS–EM combines developmental architecture, MIP measurement, PMS projection, diary rendering, and claim discipline in a distinctive structural synthesis.
```

Unsafe related-work claim:

```text
PMS–EM is the first and only model that proves artificial consciousness.
```

The related-work rule is:

```text
Comparison may identify similarity, difference, gap, pressure, or synthesis.
Comparison must not convert similarity into proof.
```

## E.14 Finding / Validation / Proof Discipline

PMS–EM uses three epistemic statuses.

```text
finding
validation
proof
```

A finding means:

```text
a pattern emerged under traceable conditions
```

A validation means:

```text
a predicted mechanism repeatedly holds under comparison
```

Proof is not available for:

```text
consciousness
personhood
subjective experience
sentience
moral status
rights status
felt pain
felt suffering
felt love
felt guilt
trauma
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
Default Mode Network equivalence
phenomenal selfhood
intrinsic worth
```

Safe finding language:

```text
The run found a stable interaction-quality adjustment pattern.
The run found bounded rest-like replay under low external load.
The run found a trace-backed post-replay update within phase scope.
```

Safe validation language:

```text
The predicted mechanism repeatedly held under comparison.
```

Unsafe proof language:

```text
The run proved consciousness.
The diary proved selfhood.
The implementation proved EM.
The PMS projection proved sentience.
The MIP trajectory proved maturity.
```

The proof boundary is:

```text
Proof is not available for consciousness, personhood, or subjective-experience claims within this architecture.
```

The model may support evidence for functional mechanisms.

It does not support proof of inner life.

## E.15 Layer-Transfer Matrix

The following transfers are allowed:

```text
EM trace → MIP observation
EM trace → PMS projection
EM trace → diary candidate, if diary requirements are met
rest-like replay trace → diary source material, if diary requirements and phase constraints are met
MIP summary → PMS-readable structure
MIP context → diary support
PMS projection → audit record
PMS reduction → controlled rendering input
Evaluation finding → mechanism revision
Consciousness outlook → research question
```

The following transfers are blocked:

```text
EM trace → consciousness proof
rest-like replay trace → Default Mode Network equivalence
low external stimulation → introspection
replay feedback → self-reflection
post-replay improvement → insight
offline consolidation → inner experience
rest-like replay cluster → autobiographical memory
MIP score → maturity proof
MIP measurement → personhood claim
MIP warning → gate control
PMS projection → internal operator claim
PMS formalization → sentience
PMS-RUST feasibility → EM proof
PMS-STACK architecture path → EM validation
Diary rendering → phenomenal selfhood
Language output → inner speech
Phase transition → maturity proof
Gate opening → finished competence
Related-work similarity → proof
D guardrail → intrinsic-worth ranking
```

A safe transfer statement:

```text
This trace may be projected, measured, rendered, or evaluated under its own layer rules.
```

An unsafe transfer statement:

```text
Because this trace is measurable, formalizable, and renderable, it proves inner life.
```

The transfer rule is:

```text
No cross-layer validation by rhetorical accumulation.
```

Multiple weak or bounded layer results do not combine into an unbounded proof claim.

## E.16 Claim-Tags for Future Contracts

Future Chapter Contracts and Block Contracts should use explicit claim tags.

Recommended claim tags:

```text
claim_type: architecture
claim_type: mechanism
claim_type: phase_constraint
claim_type: trace_finding
claim_type: trajectory_finding
claim_type: projection
claim_type: evaluation
claim_type: validation
claim_type: implementation_feasibility
claim_type: research_candidate
claim_type: blocked_proof
claim_type: language_reduction
claim_type: guardrail
```

Recommended layer tags:

```text
layer: EM
layer: MIP
layer: PMS
layer: D
layer: diary_language
layer: consciousness_outlook
layer: evaluation_safety
layer: implementation
layer: related_work
```

Recommended status tags:

```text
status: allowed
status: bounded
status: candidate
status: blocked
status: requires_trace
status: requires_phase_context
status: requires_claim_filter
status: external_projection_only
```

Example contract fragment:

```yaml
contract_fragment:
  concept: "diary rendering"
  layer: "diary_language"
  claim_type: "controlled_rendering"
  status: "bounded"
  requires:
    - "minimal_sentence_formation"
    - "trace_provenance"
    - "controlled_rendering"
    - "claim_filter"
  may_claim:
    - "trace-backed controlled rendering"
  may_not_claim:
    - "subjective memory"
    - "phenomenal selfhood"
    - "consciousness proof"
```

Example PMS contract fragment:

```yaml
contract_fragment:
  concept: "PMS projection"
  layer: "PMS"
  claim_type: "projection"
  status: "external_projection_only"
  requires:
    - "trace_grounding"
    - "operator_dependency_check"
    - "claim_level"
  may_claim:
    - "operator-readable projection"
  may_not_claim:
    - "internal PMS operator possession"
    - "sentience"
    - "EM validation"
    - "consciousness proof"
```

Example rest-like replay contract fragment:

```yaml
contract_fragment:
  concept: "rest-like replay"
  layer: "EM"
  claim_type: "mechanism_hypothesis"
  status: "bounded"
  requires:
    - "low_external_load_context"
    - "trace_backed_replay_candidates"
    - "phase_scope"
    - "anti_fixation_constraints"
    - "claim_filter"
  may_claim:
    - "phase-bounded trace-backed offline consolidation"
    - "bounded post-replay feedback"
  may_not_claim:
    - "Default Mode Network equivalence"
    - "introspection"
    - "self-reflection"
    - "subjective dreaming"
    - "inner experience"
    - "insight"
    - "autobiographical memory"
    - "consciousness proof"
```

These tags prepare the later contract pass without replacing it.

## E.17 Global Layer Rules

The following rules govern all PMS–EM artifacts:

```text
EM develops.
MIP observes.
PMS projects.
D guards.
Diary renders.
Evaluation tests.
Implementation demonstrates bounded feasibility.
Consciousness outlook formulates research candidates.
Related work compares.
Contracts constrain.
```

Forbidden inversions:

```text
MIP develops the agent.
PMS causes early cognition.
Diary proves selfhood.
D ranks worth.
Evaluation proves consciousness.
Implementation proves theory.
Related work proves novelty or equivalence.
Consciousness outlook settles consciousness.
```

The global layer rules are:

```text
1. EM is the developmental substrate.
2. Rest-like replay is an EM trace operation / mechanism hypothesis, not a consciousness-layer claim.
3. MIP is not the developmental controller.
4. PMS is not the early internal agent structure.
5. D is not a score or intrinsic-worth ranking.
6. Diary is not phenomenal selfhood.
7. Language is not inner speech.
8. Evaluation is not metaphysical proof.
9. Implementation is not theory validation.
10. Related-work similarity is not proof.
11. Consciousness remains an open research question.
```

The final layer discipline is:

```text
connected but non-validating
supportive but non-collapsing
formalizable but non-phenomenal
measurable but non-moralizing
renderable but non-selfhood-proving
implementable in parts but not validated as a whole
```

## E.18 Final Claim Boundary

The final PMS–EM claim boundary is:

```text
PMS–EM is a staged, minimalist, embodied, development-oriented architecture
for making functional developmental structures observable, measurable,
traceable, projectable, auditable, renderable, and comparable.

It is not a proof of consciousness, sentience, personhood, moral status,
rights status, subjective experience, introspection, self-reflection,
subjective dreaming, inner experience, insight, autobiographical memory,
Default Mode Network equivalence, felt pain, felt suffering, felt love,
felt guilt, trauma, or phenomenal selfhood.
```

The safe final claim is:

```text
The architecture may support bounded investigation of functional conditions
that could be relevant to consciousness research.
```

The unsafe final claim is:

```text
The architecture proves consciousness.
```

The safe implementation-status claim is:

```text
EM full architecture is not yet implemented.
PMS and MIP are sufficiently developed reference frameworks.
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK defines a demanding realization path that may support, modify,
constrain, or expose limits of architectural assumptions.
```

The unsafe implementation-status claim is:

```text
PMS-RUST proves EM.
PMS-STACK validates EM.
PMS proves consciousness.
MIP proves maturity.
```
