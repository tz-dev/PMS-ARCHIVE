# PMS–EM Split Specification v1

## Working Specification for Modularizing the PMS–EM Monolith

### 0. Purpose

This split specification defines how the completed PMS–EM monolith is maintained as a modular document system.

The master source is:

```text
00_source/PMS-EMERGENCE MODEL.md
```

The target document system is:

```text
PMS-EMERGENCE MODEL.md = Source of Truth / Master Specification
↓
7 modular full-version blocks
↓
Appendices / Reference Layer
↓
Contracts
↓
Minified canonical version
↓
Derivative publications
```

The split must not be treated as a content rewrite.

It is first and foremost:

```text
extraction
structuring
owner assignment
minimal cross-linking
claim-discipline preservation
reference-layer construction
contract preparation
```

No split artifact may weaken, expand, or silently reinterpret the claim boundaries of the master specification.

---

# 1. Source-of-Truth Rule

## 1.1 Primary Source

```text
00_source/PMS-EMERGENCE MODEL.md
```

is the master specification and remains the source of truth.

All split files are derived from it.

The split specification itself is procedural guidance. It does not override the monolith’s architecture, claim discipline, layer discipline, or implementation-status discipline.

## 1.2 The Monolith Remains Preserved

The monolith remains the complete reference.

```text
Do not silently overwrite or rewrite PMS-EMERGENCE MODEL.md during modularization.
```

The monolith may be read, searched, cited, and used as the source for verification.

It must not be modified unless the user explicitly requests a master-source revision.

## 1.3 No Silent Content Change

During extraction and modularization:

```text
chapter text remains chapter text
no silent paraphrase
no claim expansion
no claim weakening
no deletion from full-version owner blocks
no new theory claims inside chapter bodies
```

Allowed additions in split artifacts:

```text
frontmatter
block orientation
cross-reference notes
appendix references
technical file names
minor heading normalization preserving chapter identity
reference-layer summaries
contract metadata
```

Forbidden unless explicitly requested:

```text
silent content rewrite
claim expansion
claim weakening
full foreign-chapter duplication
new proof claims
layer collapse
implementation-as-validation language
phenomenal, moral, clinical, rights, or personhood upgrades
```

---

# 2. Hard Split Rule

Each chapter has exactly one owner block.

Cross-links may summarize, orient, and route the reader.

Cross-links must not duplicate full chapters.

Global rules belong in:

```text
Appendices
Glossary
Audit Checklist
Cross Reference Map
Contracts
```

The target is:

```text
no mini-monolith per block
no repeated full chapters
no diverging variants
no silent claim shifts
no rhetorical transfer across layers
```

---

# 3. Target Directory Tree

The expected PMS–EM directory structure is:

```text
PMS-EM/
  00_source/
    PMS-EMERGENCE MODEL.md
    PMS-EM_Split_Specification_v1.md

  01_blocks/
    01_Theory_Scope_Claim_Discipline.md
    02_EM_Core_Developmental_Architecture.md
    03_Developmental_Phases_Gate_Logic.md
    04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
    05_MIP_KPIs_Dignity_Safety.md
    06_PMS_VM_Implementation_Spine.md
    07_Language_Diary_Consciousness_Related_Work.md

  02_appendices/
    Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
    Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
    Appendix_C_Implementation_Start.md
    Appendix_D_Claim_Discipline_Language_Reductions.md
    Appendix_E_Layer_Discipline_Claim_Types.md
    Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md

  03_reference/
    Glossary.md
    Reader_Pathways.md
    Audit_Checklist.md
    Cross_Reference_Map.md

  04_minified/
    Chapter_Contracts.md
    Block_Contracts.md
    PMS_EM_Minified_Canonical.md

  05_derivative_publications/
    PMS_EM_Compact_Overview.md
    PMS_EM_Technical_Whitepaper.md
```

Notes:

```text
PMS-EMERGENCE MODEL.md remains the master source.
PMS-EM_Split_Specification_v1.md defines modularization procedure.
The seven block files are the modular full version.
Appendices are reference layers.
Appendix F defines the PMS ecosystem and Meta-Developmental Legibility reference layer.
Reference files support navigation, glossary discipline, audit, and contracts.
Contracts must precede the minified canonical version.
The minified canonical version must precede derivative publications unless explicitly requested otherwise.
```

---

# 4. Block Owner Assignment

## 4.1 Block 01 — Theory, Scope & Claim Discipline

File:

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
```

Owner chapters:

```text
Chapters 0, 1, 2, 18
```

Primary scope:

```text
master overview
scope
design principles
axis discipline
layer discipline
claim boundaries
implementation status
epistemic status
final synthesis
```

Required appendix references:

```text
Appendix D — Claim Discipline / Language Reductions
Appendix E — Layer Discipline & Claim Types
```

May reference:

```text
Block 02 for EM core architecture
Block 03 for phases and gates
Block 04 for caregiver and multi-generational dynamics
Block 05 for MIP, KPIs, Dignity-in-Practice, evaluation, and safety
Block 06 for PMS, VM, PMS-RUST, PMS-STACK, and implementation spine
Block 07 for language, diary, consciousness outlook, and related work
```

Must not duplicate:

```text
full EM core details
full MIP details
full PMS operator grammar
full safety ablations
full diary mechanics
full related-work comparison
```

Key claim boundaries:

```text
The model is an experimental architecture, not a proof of consciousness.
Implementation does not prove theory.
MIP scoring does not prove consciousness.
MIP measurement does not prove maturity.
PMS formalization does not prove sentience.
PMS-RUST does not prove EM.
PMS-STACK does not validate EM.
Diary output does not prove selfhood.
Dignity-in-Practice does not rank intrinsic worth.
```

---

## 4.2 Block 02 — EM Core Developmental Architecture

File:

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
```

Owner chapters:

```text
Chapters 3, 4, 5, 6, 8, 9
```

Primary scope:

```text
environment
entities
agent architecture
perception
world model
prediction
genetic system
behavior layer
object interaction
fall / near-fall
object damage
imagination buffer
replay
success logs
basic developmental machinery
```

Cross-link references:

```text
caregiver material → Block 04
phase and gate material → Block 03
MIP / KPI / safety material → Block 05
PMS projection material → Block 06
diary / language implications → Block 07
claim discipline → Appendices D and E
```

Must not duplicate:

```text
Chapter 7
Chapter 10
Chapter 11
Chapter 12
Chapter 13
Chapter 14
Chapter 15
Chapter 16
Chapter 17
```

Key claim boundaries:

```text
perception ≠ phenomenal perception
world model ≠ lived world
prediction error ≠ felt surprise
replay ≠ subjective dreaming
trace consolidation ≠ felt memory
object damage ≠ guilt
fall / near-fall ≠ pain or fear
caregiver guidance ≠ punishment
category replay ≠ concept insertion
diary preparation ≠ phenomenal selfhood
```

---

## 4.3 Block 03 — Developmental Phases & Gate Logic

File:

```text
01_blocks/03_Developmental_Phases_Gate_Logic.md
```

Owner chapter:

```text
Chapter 11
```

Primary scope:

```text
phase overview
P0-mini
P0
P1
P2
P3+
P4+
P5
gate logic
phase success criteria
exit criteria
failure modes
developmental prerequisites
learned categories
recontextualization thresholds
premature-unlock risks
```

Cross-link references:

```text
EM core mechanisms → Block 02
caregiver-role transition → Block 04
MIP phase observation and safety → Block 05
PMS implementation constraints → Block 06
diary thresholds → Block 07
claim discipline → Appendices D and E
implementation start → Appendix C
```

Must not duplicate:

```text
full EM core chapters
full caregiver theory
full MIP KPIs
full PMS formalism
full language/diary chapter
full related-work chapter
```

Key claim boundaries:

```text
phases open possibility spaces
phases do not prove maturity
phases do not prove consciousness
gates constrain capability availability
gates do not install finished competence
phase transition ≠ maturity proof
gate opening ≠ finished competence
P5 caregiver transition ≠ proof of inner life
```

---

## 4.4 Block 04 — Caregiver, Attachment, Interaction Quality & Multi-Generation

File:

```text
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
```

Owner chapters:

```text
Chapter 7
Chapter 12
```

Primary scope:

```text
needs
comfort
discomfort
distress
attachment-like regulation
caregiver response
caregiver guidance
boundary learning
misattunement
adverse caregiver response
overprotection
category stabilization
carefulness
interaction quality
object damage as self-caused consequence trace
fall / near-fall risk learning
functional love dynamics
multi-generation transition
Caregiver 1 → Child → Caregiver 2
role transition
norm transfer
Dignity-in-Practice under asymmetry
```

Allowed cross-link summaries:

```text
selected summary from Chapters 8–9
selected summary from Chapter 11
selected summary from Chapter 16
selected summary from Chapter 14 where norm transfer is projected into PMS
selected summary from Chapter 13 where diary reconstruction depends on caregiver traces
```

Cross-link summaries must not replace owner chapters.

Recommended maximum length per cross-link summary:

```text
300–700 words
```

Required appendix references:

```text
Appendix D — Claim Discipline / Language Reductions
Appendix E — Layer Discipline & Claim Types
```

Must not duplicate:

```text
full Chapter 8
full Chapter 9
full Chapter 10
full Chapter 11
full Chapter 13
full Chapter 14
full Chapter 16
full Chapter 17
```

Key claim boundaries:

```text
discomfort ≠ pain
distress ≠ subjective suffering
missing ≠ felt longing
attachment ≠ felt love
functional love dynamics ≠ felt love
comfort ≠ felt relief
caregiver guidance ≠ punishment
boundary ≠ rejection
misattunement ≠ trauma
adverse caregiver response ≠ abuse claim
overprotection ≠ moral blame
object damage ≠ guilt
fall / near-fall ≠ pain or fear
carefulness ≠ moral obedience
role / caregiver transition ≠ proof of inner life
norm transfer ≠ moral essence transfer
```

---

## 4.5 Block 05 — MIP, KPIs, Dignity & Safety

File:

```text
01_blocks/05_MIP_KPIs_Dignity_Safety.md
```

Owner chapters:

```text
Chapter 10
Chapter 16
```

Primary scope:

```text
MIP layer
A–C–R–E measurement orientation
A–C–R–P–D source/context handling
Dignity-in-Practice guardrails
IA markers
T–J–TB–R
RVR(t)
AH Precision as second-order hardening where relevant
optional MIP operational levels
KPIs
evaluation
ablations
safety principles
reproducibility
finding / validation / proof distinction
trajectories instead of labels
```

Required appendix references:

```text
Appendix A — MIP Reference Model and EM Axis Notes
Appendix D — Claim Discipline / Language Reductions
Appendix E — Layer Discipline & Claim Types
```

May reference:

```text
Block 02 for mechanisms measured by MIP/KPIs
Block 03 for phase and gate context
Block 04 for caregiver, attachment-like regulation, interaction quality, and multigeneration
Block 06 for PMS projection and implementation feasibility boundaries
Block 07 for diary, language, and consciousness-outlook boundaries
```

Must not duplicate:

```text
full EM core chapters
full caregiver chapters
full PMS formalism
full diary chapter
full related work
```

Key claim boundaries:

```text
MIP observes; it does not control.
MIP does not open gates.
MIP does not install categories.
MIP does not prove maturity.
MIP does not prove consciousness.
MIP does not diagnose agents.
MIP does not moralize traces.
D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.
D is not a performance score.
D is not intrinsic-worth ranking.
KPIs do not prove consciousness, personhood, moral status, sentience, subjective experience, pain, suffering, love, guilt, trauma, or phenomenal selfhood.
Evaluation and ablation findings remain functional, phase-bounded, trace-backed, and claim-filtered.
```

---

## 4.6 Block 06 — PMS, VM & Implementation Spine

File:

```text
01_blocks/06_PMS_VM_Implementation_Spine.md
```

Owner chapter:

```text
Chapter 14
```

Primary scope:

```text
PMS as operator grammar
PMS as external projection / audit / VM layer
operator-readable traces
operator-compatible regularities
Δ–Ψ operator alphabet
ε identity distinction
O*
L_PMS
dependency checking
episode-to-sequence mapping
Success Log trace layer
MIP-to-PMS projection
IA pattern matching
diary reduction
language rendering
norm transfer as morphism
self-model candidate projection
PMS-RUST as bounded executable evidence spine
PMS-STACK as architecture pressure point
DSL / VM framing
Meta-Developmental Legibility as external trace-weighting / domain-profile mapping reference
temporary domain-profile weighting boundaries
implementation boundaries
```

Required appendix references:

```text
Appendix B — PMS Operator Grammar and Monoid Notes
Appendix C — Implementation Start
Appendix D — Claim Discipline / Language Reductions
Appendix E — Layer Discipline & Claim Types
Appendix F — PMS Ecosystem and Meta-Legibility Notes
```

May reference:

```text
Block 02 for developmental mechanisms whose traces may become operator-compatible
Block 03 for phase and gate context
Block 04 for caregiver, interaction-quality, and norm-transfer content
Block 05 for MIP/KPI/safety content
Block 07 for diary/language/consciousness boundaries
```

Must not allow:

```text
PMS proves EM
PMS proves consciousness
PMS proves sentience
PMS-RUST proves EM
PMS-STACK validates EM
agent has Δ
agent uses Φ
agent thinks in Ψ
internalized PMS operators
operator-compatible regularity = internal PMS operator
PMS domain profiles become internal agent modules
temporary domain-profile weighting opens gates
temporary domain-profile weighting installs categories
Meta-Developmental Legibility Strand controls development
PMS projection = consciousness proof
```

Preferred language:

```text
operator-readable trace
operator-compatible regularity
Δ/Φ/Ψ-compatible projection
the agent’s traces can be projected as PMS-compatible structures
temporary domain-profile weighting overlay
external PMS domain-profile lens
projection-readiness note
bounded trace/audit feasibility
architecture pressure point
VM-facing representation
```

Key claim boundaries:

```text
PMS is an external operator / projection / audit / VM layer.
PMS is not early internal agent structure.
Formal representability is not EM implementation.
Executable trace feasibility is not developmental proof.
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK defines a demanding realization path and architecture pressure point.
PMS-STACK does not validate EM as a whole.
```

---

## 4.7 Block 07 — Language, Diary, Consciousness Outlook & Related Work

File:

```text
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

Owner chapters:

```text
Chapter 13
Chapter 15
Chapter 17
```

Primary scope:

```text
language as late reflection channel
labels to narratives
minimal sentence threshold
trace provenance
controlled rendering
diary candidate status
diary rendering
diary ≠ phenomenal selfhood
consciousness research outlook
functional candidates
functional proto-consciousness as bounded research label
self-model candidate boundaries
related work comparison
neutralized uniqueness claims
comparison without proof by similarity
```

Required appendix references:

```text
Appendix D — Claim Discipline / Language Reductions
Appendix E — Layer Discipline & Claim Types
```

May reference:

```text
Block 02 for traces underlying diary/language
Block 03 for phase placement and thresholds
Block 04 for caregiver/object/comfort/multigeneration traces used by diary
Block 05 for MIP trajectory context and safety
Block 06 for PMS diary reduction and operator-readable structure
Appendix F for PMS ecosystem, Meta-Developmental Legibility, and domain-profile weighting boundaries
```

Must not allow:

```text
diary proves consciousness
diary proves subjective memory
diary proves phenomenal selfhood
minimal sentence formation proves selfhood
language output proves inner speech
self-description proves consciousness
functional proto-consciousness = phenomenal consciousness
related-work similarity = proof
```

Key claim boundaries:

```text
language is a late reflection channel
language is not the source of developmental architecture
diary requires minimal sentence formation, trace provenance, and controlled rendering
no minimal sentence formation → no diary text
no trace provenance → no valid EM diary
no controlled rendering → no safe diary output
consciousness remains an open research question
```

---

# 5. Appendix Instructions

## 5.1 General Appendix Rule

Appendices are reference layers.

They are not fully copied into the seven blocks.

Blocks refer to appendices.

Appendices may clarify, normalize, constrain, and harden the specification.

Appendices must not expand chapter claims.

Appendices must not introduce proof claims.

Appendices must preserve the master claim boundaries.

---

## 5.2 Appendix A — MIP Reference Model and EM Axis Notes

File:

```text
02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
```

Primary reference:

```text
Block 05
```

Secondary references:

```text
Block 01
Block 03
Block 07
```

Purpose:

```text
MIP reference model
A–C–R–P–D source/context notation
P → E mapping
active A–C–R–E–D convention
retired historical notation
Dignity-in-Practice guardrail discipline
IA criteria
trajectory-over-label discipline
```

Critical correction:

```text
B–K–V–H must not appear as active EM notation or active master notation.
```

If historical axes are mentioned, they must be marked as:

```text
retired historical/source-internal notation
not active in the English master architecture
```

Recommended headings:

```text
A.1 Purpose of the MIP Reference and Axis Notes
A.2 Retired Historical Axis Notation
A.3 MIP A–C–R–P–D Reference Structure
A.4 EM-Facing A–C–R–E–D Convention
A.5 No Silent Merge of Source Notation and EM Notation
A.6 Awareness Mapping Notes
A.7 Coherence Mapping Notes
A.8 Responsibility / Response-Relation Mapping Notes
A.9 Praxis / Practice to Enactment Notes
A.10 Dignity-in-Practice as Guardrail Reference
A.11 IA Criteria: Transparency, Justification, Time-Boundedness, Reversibility
A.12 Enactment State, Not Person Type
A.13 Trajectories over Labels
```

Do not use as an active heading:

```text
EM-Internal B–K–V–H Axes
```

Use instead:

```text
Retired Historical Axis Notation
```

Key boundaries:

```text
MIP does not control development.
MIP does not open gates.
MIP does not install categories.
MIP does not diagnose agents.
MIP does not prove maturity.
MIP does not prove consciousness.
D is not a performance score.
D is not intrinsic-worth ranking.
```

---

## 5.3 Appendix B — PMS Operator Grammar and Monoid Notes

File:

```text
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
```

Primary reference:

```text
Block 06
```

Purpose:

```text
PMS operator grammar
operator alphabet Δ–Ψ
optional monoid reconstruction
formal identity ε
semantic role of Δ
dependency-constrained language L_PMS
operator composition
well-formedness and dependency checking
episodes as words
diaries as monoid reductions
IA detection as pattern matching
norm transfer as morphism
self-model as operator-composition candidate
Δ is not ε correction
```

Recommended headings:

```text
B.1 Purpose of the Operator Grammar and Monoid Appendix
B.2 Operator Alphabet Δ–Ψ
B.3 Optional Monoid Reconstruction over Operator Sequences
B.4 Formal Identity ε
B.5 Semantic Role of Δ
B.6 Dependency-Constrained Language L_PMS
B.7 Operator Composition
B.8 Well-Formedness and Dependency Checking
B.9 Episodes as Words
B.10 Diaries as Monoid Reductions
B.11 IA Detection as Pattern Matching
B.12 Norm Transfer as Morphism
B.13 Self-Model as Operator-Composition Candidate
B.14 Mathematical Vulnerability Avoided: Δ Is Not ε
```

Critical boundaries:

```text
operator-readable ≠ internally operator-using
operator-compatible regularity ≠ internal PMS operator
formal representability ≠ EM implementation
PMS formalization ≠ sentience
PMS projection ≠ consciousness proof
Ψ ≠ phenomenal selfhood
```

---

## 5.4 Appendix C — Implementation Start

File:

```text
02_appendices/Appendix_C_Implementation_Start.md
```

Primary reference:

```text
Block 06
```

Purpose:

```text
minimal implementation-start path
PMS operator-sequence interpreter
operator token registry
dependency checking
composition
validation function
episode-to-PMS-chain mapper
Praxis Compiler
language templates
diary rendering over operator sequences
minimal first prototype scope
```

Recommended headings:

```text
C.1 Purpose
C.2 Stage 1 — PMS Operator-Sequence Interpreter
C.3 Operator Tokens Δ–Ψ
C.4 Dependency Checking
C.5 Composition
C.6 Validation Function
C.7 Stage 2 — Episode → PMS-Chain Mapper
C.8 Praxis Compiler
C.9 Stage 3 — Diaries and Language over Operator Sequences
C.10 Language Templates as Operator Sequences → Text
C.11 Diary as Operator-Sequence Collections → Narrative
C.12 Minimal First Prototype Scope
```

Critical boundaries:

```text
Prototype scope ≠ EM validation.
Interpreter ≠ consciousness model.
Diary rendering ≠ inner life.
PMS-RUST supports bounded trace/audit feasibility.
PMS-RUST does not prove EM.
PMS-STACK defines an architecture pressure point.
PMS-STACK does not validate EM.
```

---

## 5.5 Appendix D — Claim Discipline / Language Reductions

File:

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
```

Global reference.

Strongly referenced by:

```text
Block 01
Block 04
Block 05
Block 07
```

Purpose:

```text
mandatory language reductions
blocked claim upgrades
functional-description discipline
no phenomenal upgrade
no moral upgrade
no clinical upgrade
no rights or personhood upgrade
```

Recommended headings:

```text
D.1 Functional Description Only
D.2 No Phenomenal Consciousness Claim
D.3 No Subjective Suffering Claim
D.4 No Rights Claim from Current Architecture
D.5 Distress ≠ Pain
D.6 Love Dynamics ≠ Felt Love
D.7 Diary ≠ Phenomenal Selfhood
D.8 MIP ≠ Consciousness Module
D.9 Responsibility ≠ Moral Personhood
D.10 Proto-Consciousness ≠ Phenomenal Consciousness
D.11 Recommended Language Reductions
D.12 MIP Terms Must Remain Functional
D.13 PMS Terms Must Remain Operator-Structural
D.14 Guidance, Boundary, Misattunement, and Caregiver-Response Reductions
D.15 Object Damage, Fall / Near-Fall, and Carefulness Reductions
D.16 Dignity-in-Practice ≠ Intrinsic-Worth Ranking
D.17 Finding / Validation / Proof Language
D.18 Global Blocked Language Table
```

Must include:

```text
discomfort ≠ pain
distress ≠ subjective suffering
missing ≠ felt longing
attachment ≠ felt love
love dynamics ≠ felt love
comfort ≠ felt relief
guidance ≠ punishment
boundary ≠ rejection
misattunement ≠ trauma
adverse caregiver response ≠ abuse claim
object damage ≠ guilt
self-caused consequence ≠ blame / remorse / punishment
fall / near-fall ≠ pain or fear
carefulness ≠ moral obedience
role / caregiver transition ≠ proof of inner life
norm transfer ≠ moral essence transfer
self-model candidate ≠ phenomenal selfhood
Dignity-in-Practice ≠ intrinsic-worth ranking
```

---

## 5.6 Appendix E — Layer Discipline & Claim Types

File:

```text
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

Global reference.

Strongly referenced by:

```text
Block 01
Block 05
Block 06
Block 07
```

Purpose:

```text
layer discipline
claim-type ladder
finding / validation / proof distinction
allowed and blocked layer transfers
implementation-status boundaries
contract-preparation claim tags
```

Recommended headings:

```text
E.1 Purpose
E.2 The Four-Layer Architecture
E.3 Layer Claims Must Not Collapse
E.4 Claim-Type Ladder
E.5 EM Claim Type
E.6 MIP Claim Type
E.7 Dignity-in-Practice Claim Type
E.8 PMS Claim Type
E.9 Language and Diary Claim Type
E.10 Consciousness Research Claim Type
E.11 Implementation Claim Type
E.12 Evaluation, Ablation, and Safety Claim Type
E.13 Related Work Claim Type
E.14 Finding / Validation / Proof Discipline
E.15 Layer-Transfer Matrix
E.16 Claim-Tags for Future Contracts
E.17 Global Layer Rules
E.18 Final Claim Boundary
```

Must clarify:

```text
EM developmental claim ≠ MIP validation claim
MIP marker ≠ diagnosis
PMS implementation claim ≠ consciousness claim
artifact behavior ≠ theoretical proof
formalization ≠ sentience
implementation feasibility ≠ validation
diary rendering ≠ phenomenal selfhood
related-work similarity ≠ proof
```

---

## 5.7 Appendix F — PMS Ecosystem and Meta-Legibility Notes

File:

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

Primary references:

```text
Block 06
Block 05
Block 07
```

Secondary references:

```text
Block 01
Block 02
Block 03
Block 04
```

Purpose:

```text
PMS ecosystem framing
PMS Base / PMS Repository / PMS domain-profile distinction
domain profiles as external operator-strict overlays
MIP / IA as downstream governance and artifact responsibility
PMS–QC as specialized structural bridge
Meta-Developmental Legibility Strand
temporary domain-profile weighting
profile activation conditions
T–J–TB–R requirements for activation
Core / Extended / Research Ecosystem framing
```

Recommended headings:

```text
F.1 Purpose
F.2 PMS Base, PMS Repository, and PMS Domain Profiles
F.3 Domain Profiles as External Operator-Strict Overlays
F.4 MIP / IA as Downstream Governance and Artifact Responsibility
F.5 PMS–QC as Specialized Structural Bridge
F.6 Meta-Developmental Legibility Strand
F.7 Temporary Domain-Profile Weighting
F.8 Profile Activation Conditions
F.9 Initial Domain Profiles
F.10 T–J–TB–R Requirements for Profile Activation
F.11 Integration Boundary for PMS–EM
F.12 What Must Not Be Internalized
F.13 Core / Extended / Research Ecosystem Framing
F.14 Appendix F Quality Gate
```

Must include:

```text
Meta-Developmental Legibility Strand = temporary, reversible, time-bounded trace-weighting and legibility overlay
Genetic Strand = developmental availability
Meta-Developmental Legibility Strand = temporary legibility / weighting / audit sensitivity
temporary domain-profile weighting may affect trace interpretation, support sensitivity, MIP / IA review, PMS projection focus, diary rendering constraints, safety audit attention, and implementation-facing inspection
domain profiles are external PMS lenses, not agent modules
profile activation requires Transparency, Justification, Time-Boundedness, and Reversibility
the meta strand may change what the system watches more carefully
the meta strand must not change what the agent is allowed to become
```

Must block:

```text
meta strand as second genetic system
meta strand as controller
meta strand as gate opener
meta strand as category installer
meta strand as internal PMS operator system
domain profiles as internal agent modules
domain-profile activation as consciousness evidence
domain-profile activation as diagnosis
domain-profile activation as moral judgment
domain-profile activation as personhood claim
domain-profile activation as rights-status claim
domain-profile activation as sexualization of the EM agent
```

---

# 6. Reference Files

## 6.1 Glossary.md

Path:

```text
03_reference/Glossary.md
```

Purpose:

```text
controlled terminology
stable definitions
owner routing
may mean / must not mean distinctions
retired / forbidden terms
claim-safe definitions
mandatory reductions
blocked upgrade shortlist
```

Must include:

```text
EM
PMS–EM
MIP
PMS
PMS-RUST
PMS-STACK
Implementation Status
A–C–R–E–D
A–C–R–P–D
P → E
B–K–V–H as retired historical notation
Dignity-in-Practice
RVR(t)
IA
T–J–TB–R
AH Precision
caregiver guidance
boundary
misattunement
adverse caregiver response
overprotection
interaction quality
carefulness
role / caregiver transition
norm transfer / core norm transfer
trace provenance
controlled rendering
diary
operator-compatible regularity
PMS projection
self-model candidate
asymmetry drift
Meta-Developmental Legibility Strand
PMS domain profile
temporary domain-profile weighting
domain-profile activation
Core / Extended / Research Ecosystem
finding
validation
proof
```

Must preserve:

```text
controlled definitions only
no new theory claims
no active historical notation
no phenomenal, moral, clinical, rights, or personhood upgrades
```

---

## 6.2 Reader_Pathways.md

Path:

```text
03_reference/Reader_Pathways.md
```

Purpose:

```text
human-readable entry paths
owner-preserving reading routes
audience-specific navigation
contract preparation route
minified preparation route
derivative-publication preparation route
```

Recommended pathways:

```text
First-contact reader
Full architecture reader
Technical EM architecture reader
Developmental phases and gate logic reader
Caregiver / attachment / multigeneration reader
MIP / KPI / Dignity / safety reader
PMS / VM / implementation reader
Diary / language / consciousness-outlook reader
Claim-discipline / audit reader
Implementation starter reader
Contract preparation reader
Minified canonical preparation reader
Derivative-publication preparation reader
Related-work / comparison reader
Reviewer / skeptic reader
```

Must not:

```text
replace owner blocks
weaken claim boundaries
convert reading route into proof route
summarize in a way that changes claim status
```

---

## 6.3 Audit_Checklist.md

Path:

```text
03_reference/Audit_Checklist.md
```

Purpose:

```text
global consistency checklist
file-level audit
block-level audit
chapter-level audit
axis discipline audit
layer discipline audit
claim-boundary audit
contract-readiness audit
minified-readiness audit
human-version readiness audit
editing-residue audit
```

Must check:

```text
A–C–R–E–D correct
A–C–R–P–D restricted to explicit MIP source/context
B–K–V–H restricted to Appendix A or historical audit context
D not as performance score
Dignity-in-Practice not as intrinsic-worth ranking
MIP not as controller
MIP not as gate opener
MIP not as category installer
PMS not as early internal agent structure
operator-compatible regularity ≠ internal PMS operator
Diary not as selfhood
Misattunement not as trauma
Damage not as guilt
Fall / near-fall not as pain/fear
Carefulness not as obedience
Role / caregiver transition not as proof of inner life
Norm transfer not as moral essence transfer
No cross-layer validation
No consciousness proof
No personhood proof
No sentience proof
No rights-status proof
```

---

## 6.4 Cross_Reference_Map.md

Path:

```text
03_reference/Cross_Reference_Map.md
```

Purpose:

```text
chapter → owner block
block → owner chapters
appendix → reference purpose
concept → owner location
concept → secondary references
do-not-duplicate zones
claim-boundary routing
contract-preparation map
```

Example structure:

```yaml
carefulness:
  owner_block: 04
  secondary_blocks:
    - 02
    - 03
    - 05
    - 07
  appendices:
    - D
    - E

RVR(t):
  owner_block: 05
  secondary_blocks:
    - 03
    - 04
  appendices:
    - A
    - E

PMS_projection:
  owner_block: 06
  secondary_blocks:
    - 05
    - 07
  appendices:
    - B
    - C
    - E
```

Must preserve:

```text
one owner per chapter
no full foreign-chapter duplication
appendices as reference layers
reference files as navigation/audit layers
```

---

# 7. Frontmatter Standard

Each split file receives YAML frontmatter at the beginning.

## 7.1 Block Frontmatter Template

```yaml
---
document_id: PMS-EM-BLOCK-XX
title: ""
source: "PMS-EMERGENCE MODEL.md"
source_role: "derived full-block extraction"
status: "split-full-version"
version: "v1"
owner_chapters: []
secondary_references: []
appendix_references: []
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---
```

## 7.2 Example Block 05 Frontmatter

```yaml
---
document_id: PMS-EM-BLOCK-05
title: "MIP, KPIs, Dignity & Safety"
source: "PMS-EMERGENCE MODEL.md"
source_role: "derived full-block extraction"
status: "split-full-version"
version: "v1"
owner_chapters: [10, 16]
secondary_references: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 17, 18]
appendix_references: ["Appendix A", "Appendix D", "Appendix E"]
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---
```

## 7.3 Appendix Frontmatter Requirements

Appendices should include:

```text
document_id
title
source
source_role
status
version
primary_references
secondary_references
related_appendices
claim_mode
active_axis_notation
d_status
mip_status
pms_status
```

## 7.4 Reference File Frontmatter Requirements

Reference files should include:

```text
document_id
title
source
source_role
status
version
related_blocks
related_appendices
claim_mode
active_axis_notation
d_status
mip_status
pms_status
```

Reference files may also include:

```text
related_reference_files
mip_source_context_notation
language_status
layer_status
```

---

# 8. Block Orientation Standard

After the frontmatter, each block receives a short orientation.

Template:

```markdown
# <Block Title>

## Block Orientation

This block contains the owner chapters for <scope>.

It should be read together with:

- <Appendix references>
- <Relevant block references>

This block preserves the claim discipline of the master specification:

- A–C–R–E are the active implementation-facing axes.
- D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.
- D is not a normal performance score and does not rank intrinsic worth.
- MIP observes, summarizes, marks, warns, and may support; it does not control development.
- PMS is an external operator, projection, audit, and VM-facing layer; it is not assumed to be an early internal agent structure.
- Functional traces must not be upgraded into phenomenal, moral, clinical, rights, or personhood claims.
```

Then the extracted owner chapter text begins.

Block orientation may route readers to other blocks or appendices.

It must not become a new chapter.

It must not rewrite the theory.

---

# 9. Cross-Link Rules

## 9.1 Allowed Cross-Link Summary

A cross-link summary may:

```text
refer to another owner block
orient a concept briefly
repeat a claim boundary
name the owner
name the relevant appendix
```

It must not:

```text
duplicate full chapters
introduce new claims
reactivate retired notation
copy full YAML schemas that belong to an owner location
weaken claim boundaries
convert a dependency into validation
```

## 9.2 Cross-Link Format

Recommended format:

```markdown
> Cross-reference:
> For the full treatment of <concept>, see `<block-file>`, especially Chapter <x>.
> This block uses the concept only as a dependency / orientation point / claim-boundary context / implementation boundary.
```

Example:

```markdown
> Cross-reference:
> For the full treatment of caregiver guidance, misattunement, interaction quality, and multi-generational transfer, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapters 7 and 12.
> This block uses these concepts only as dependencies for phase interpretation.
```

## 9.3 Cross-Link Audit Rule

Every cross-link should be checked for:

```text
correct owner block
correct chapter reference
no full foreign-chapter duplication
no claim expansion
no claim weakening
no layer collapse
no proof transfer
```

---

# 10. Work Order

## Pass 1 — Secure Source and Extract Seven Full Blocks

Input:

```text
00_source/PMS-EMERGENCE MODEL.md
```

Output:

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/03_Developmental_Phases_Gate_Logic.md
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

Extraction must preserve:

```text
original chapter headings
original chapter identity
original claim boundaries
original core content
```

Extraction may remove:

```text
chat context
editing notes
old to-do comments
duplicate accidental residue
```

## Pass 2 — Verify Owner-Chapter Completeness

Verify:

```text
[ ] all owner chapters are present
[ ] no chapter is missing
[ ] no chapter appears as full content in more than one block
[ ] chapter identity is preserved
[ ] owner mapping is correct
```

Special check:

```text
Chapter 9 must be present in Block 02.
```

## Pass 3 — Add Frontmatter and Block Orientation

Add:

```text
YAML frontmatter
Block Orientation
appendix references
claim-discipline bullets
```

Do not rewrite owner chapters.

## Pass 4 — Normalize Block Headings

Normalize:

```text
block title
chapter heading preservation
minor numbering consistency
markdown structure
```

Do not renumber original chapters into block-local numbering.

## Pass 5 — Add Minimal Cross-Links

Add:

```text
owner-preserving cross-reference notes
appendix routing
claim-boundary routing
```

Do not add full foreign content.

Do not create mini-monoliths.

## Pass 6 — Create Appendices A–F

Output:

```text
02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

Appendices are reference layers.

They do not replace owner chapters.

Appendix F is the PMS ecosystem and Meta-Developmental Legibility reference layer.
It must not introduce a new EM core chapter, a second genetic system, an internal PMS domain-module system, or a consciousness/personhood/sentience proof claim.

## Pass 7 — Create Reference Files

Output:

```text
03_reference/Cross_Reference_Map.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
03_reference/Reader_Pathways.md
```

Recommended order:

```text
1. Cross_Reference_Map.md
2. Glossary.md
3. Audit_Checklist.md
4. Reader_Pathways.md
```

Reference files may summarize more strongly than block cross-links, but must remain claim-conformant.

## Pass 8 — Create Contracts

Output:

```text
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
```

Contracts are audit artifacts.

They must include:

```text
may claim
may not claim
requires
depends on
owner concepts
blocked language
related appendices
```

Chapter contracts must include:

```text
chapter number
chapter title
owner block
may claim
may not claim
requires
depends on
owner concepts
blocked language
related appendices
```

Block contracts must include:

```text
block file
owner chapters
scope
may claim
may not claim
requires
depends on
owner concepts
foreign concepts
cross-reference obligations
appendix obligations
blocked language
```

Contracts must not introduce new theory.

Contracts must constrain future reductions.

## Pass 9 — Create Minified Canonical Version

Output:

```text
04_minified/PMS_EM_Minified_Canonical.md
```

Inputs:

```text
seven block summaries
Chapter_Contracts.md
Block_Contracts.md
Glossary.md
Audit_Checklist.md
Cross_Reference_Map.md
Appendices A–F
```

Do not create the minified canonical version directly from the monolith without contracts unless explicitly requested.

## Pass 10 — Create Compact Overview

Output:

```text
05_derivative_publications/PMS_EM_Compact_Overview.md
```

Inputs:

```text
PMS_EM_Minified_Canonical.md
Reader_Pathways.md
Glossary.md
Audit_Checklist.md
Appendix D
Appendix E
```

Goal:

```text
10–15 pages
first-contact overview
minimal YAML
strong claim boundaries
human-readable
```

## Pass 11 — Create Technical Whitepaper

Output:

```text
05_derivative_publications/PMS_EM_Technical_Whitepaper.md
```

Inputs:

```text
PMS_EM_Minified_Canonical.md
Block_Contracts.md
Chapter_Contracts.md
selected schemas
selected examples
Appendix D
Appendix E
Glossary.md
Audit_Checklist.md
```

Goal:

```text
50–80 pages
technical but readable
selected schemas
architecture + safety + implementation + diary/consciousness outlook
less dense than the full block version
```

---

# 11. Quality Gates per Split File

Before completing any file, check:

```text
[ ] correct file path
[ ] correct file role
[ ] correct frontmatter
[ ] correct owner chapters if applicable
[ ] block orientation present if applicable
[ ] no full foreign chapters duplicated
[ ] A–C–R–E–D correct
[ ] A–C–R–P–D restricted to explicit MIP source/context
[ ] B–K–V–H restricted to Appendix A or explicit historical audit context
[ ] D not treated as performance score
[ ] Dignity-in-Practice not treated as intrinsic-worth ranking
[ ] MIP not treated as controller
[ ] MIP not treated as gate opener
[ ] MIP not treated as category installer
[ ] PMS not treated as early internal structure of the agent
[ ] operator-compatible regularities used where appropriate
[ ] no internalized PMS operator claim
[ ] no “agent has Δ”
[ ] no “agent uses Φ”
[ ] no “agent thinks in Ψ”
[ ] no PMS proves EM
[ ] no PMS-RUST proves EM
[ ] no PMS-STACK validates EM
[ ] no MIP proves maturity
[ ] no consciousness proof
[ ] no personhood proof
[ ] no sentience proof
[ ] no moral-status proof
[ ] no rights-status proof
[ ] diary ≠ phenomenal selfhood
[ ] distress ≠ subjective suffering
[ ] discomfort ≠ pain
[ ] missing ≠ felt longing
[ ] attachment ≠ felt love
[ ] love dynamics ≠ felt love
[ ] object damage ≠ guilt
[ ] fall / near-fall ≠ pain or fear
[ ] misattunement ≠ trauma
[ ] adverse caregiver response ≠ abuse claim
[ ] guidance ≠ punishment
[ ] boundary ≠ rejection
[ ] carefulness ≠ moral obedience
[ ] role / caregiver transition ≠ proof of inner life
[ ] norm transfer ≠ moral essence transfer
[ ] self-model candidate ≠ phenomenal selfhood
[ ] no cross-layer validation by rhetorical transfer
[ ] no editing residue in the document body
```

Editing residue includes:

```text
to-do
previous version
patch
update
chat-style comments
German editing notes inside English artifacts
accidental assistant commentary
malformed markdown fences
duplicate headings caused by failed patch
orphaned code-fence markers
placeholder markers
```

Allowed in audit/reference artifacts:

```text
explicit checklist labels
blocked-language lists
source-role labels in frontmatter
```

---

# 12. Global Claim Discipline for All Outputs

All split files must preserve the following boundaries:

```text
discomfort ≠ pain
distress ≠ subjective suffering
missing ≠ felt longing
attachment ≠ felt love
love dynamics ≠ felt love
comfort ≠ felt relief
object damage ≠ guilt
self-caused consequence ≠ blame / remorse / punishment
fall / near-fall ≠ pain or fear
misattunement ≠ trauma
adverse caregiver response ≠ abuse claim
caregiver guidance ≠ punishment
boundary ≠ rejection
carefulness ≠ moral obedience
interaction quality ≠ moral worth
role / caregiver transition ≠ proof of inner life
norm transfer ≠ moral essence transfer
self-model candidate ≠ phenomenal selfhood
diary ≠ phenomenal selfhood
diary text ≠ subjective autobiography
language output ≠ inner speech
self-description ≠ consciousness
MIP ≠ consciousness module
MIP trajectory ≠ maturity proof
MIP marker ≠ diagnosis
PMS formalization ≠ sentience
PMS projection ≠ internal symbolic consciousness
operator-compatible regularity ≠ internal PMS operator
Dignity-in-Practice ≠ intrinsic-worth ranking
functional proto-consciousness ≠ phenomenal consciousness
implementation ≠ theory proof
PMS-RUST ≠ EM proof
PMS-STACK ≠ EM validation
related-work similarity ≠ proof
```

Use functional, trace-backed language only.

Do not introduce:

```text
consciousness proof
personhood proof
moral-status proof
rights-status proof
sentience proof
subjective suffering
felt pain
felt love
felt guilt
felt fear
trauma claim
punishment claim
moral obedience claim
phenomenal selfhood claim
```

---

# 13. Active Axis Rule

In all EM, PMS, KPI, ablation, consciousness-outlook, safety, diary, and reference texts, the active EM-facing notation is:

```text
A–C–R–E–D
```

with:

```text
A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

D is:

```text
guardrail
interaction quality under asymmetry
not a normal performance score
not a maturity score
not intrinsic worth
not rights status
not moral status
not personhood
not consciousness
not sentience
```

MIP source/context notation:

```text
A–C–R–P–D
```

may appear only in explicit MIP reference passages.

Historical/source-internal notation may appear only in Appendix A or explicit historical audit context as retired notation.

It must not appear as active master notation.

The retired historical notation:

```text
B–K–V–H
```

must be marked as:

```text
retired historical/source-internal notation
not active in the English master architecture
```

---

# 14. Minified Canonical Version Rule

The minified canonical version may shorten the text, but it must not loosen the boundaries.

It must preserve:

```text
all central definitions
all axis rules
all D rules
all implementation-status rules
all forbidden claim upgrades
all owner concepts
all cross-layer boundaries
all diary threshold rules
all MIP boundaries
all PMS boundaries
finding / validation / proof distinction
```

It may reduce:

```text
long examples
repeated YAML variants
detail paths
extended repetitions
long related-work comparisons
some implementation fixture detail
```

It must not reduce:

```text
claim boundaries
Dignity-in-Practice rule
MIP not controller
MIP not consciousness module
PMS external/operator-compatible regularity boundary
PMS not early internal agent structure
Diary threshold
Finding / validation / proof distinction
Implementation status
No cross-layer validation rule
```

Before creating the minified canonical version, verify:

```text
Chapter_Contracts.md exists.
Block_Contracts.md exists.
Cross_Reference_Map.md exists.
Glossary.md exists.
Audit_Checklist.md exists.
Reader_Pathways.md exists.
Appendices A–E exist.
```

---

# 15. Derivative Publications

## 15.1 Compact Overview

Output:

```text
05_derivative_publications/PMS_EM_Compact_Overview.md
```

Goal:

```text
10–15 pages target length
first-contact overview
clear
human-readable
minimal YAML
strong claim boundaries
Core / Extended / Research Ecosystem framing
```

Must answer:

```text
What is PMS–EM?
What does it claim?
What does it not claim?
Why is it interesting?
What layers does it have?
Which claims are forbidden?
How should the reader continue?
```

Must preserve:

```text
no consciousness proof
no sentience proof
no personhood proof
no subjective suffering claim
no felt love/guilt/pain/trauma claim
Dignity-in-Practice as guardrail
MIP not controller
PMS not early internal agent structure
diary not phenomenal selfhood
implementation status discipline
```

## 15.2 Technical Whitepaper

Output:

```text
05_derivative_publications/PMS_EM_Technical_Whitepaper.md
```

Goal:

```text
50–80 pages
technical whitepaper
readable for expert readers
selected schemas
claim discipline
less dense than the full block version
```

Must include:

```text
architecture overview
developmental phases
caregiver / interaction quality
MIP / safety
PMS / implementation
language / diary
consciousness outlook
related work
PMS ecosystem and Meta-Developmental Legibility
Core / Extended / Research Ecosystem framing
claim boundaries
implementation status
```

Must not become:

```text
full monolith repetition
claim-weakened popularization
consciousness proof narrative
sentience proof narrative
personhood narrative
```

---

# 16. Completion Definition

The modularization is considered complete when the following files exist and pass audit:

```text
00_source/PMS-EMERGENCE MODEL.md
00_source/PMS-EM_Split_Specification_v1.md

01_blocks/01_Theory_Scope_Claim_Discipline.md
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/03_Developmental_Phases_Gate_Logic.md
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md

02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md

03_reference/Glossary.md
03_reference/Reader_Pathways.md
03_reference/Audit_Checklist.md
03_reference/Cross_Reference_Map.md

04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
04_minified/PMS_EM_Minified_Canonical.md

05_derivative_publications/PMS_EM_Compact_Overview.md
05_derivative_publications/PMS_EM_Technical_Whitepaper.md
```

Final completion statement:

```text
The monolith remains the source of truth.
The seven blocks are the modular full version.
The appendices are the reference layer.
Appendix F is the PMS ecosystem and Meta-Developmental Legibility reference layer.
The reference files are navigation and audit layers.
The contracts constrain reductions and derived versions.
The minified version is the canonical compact specification.
The compact overview and technical whitepaper are derivative publication documents.
No split artifact may weaken the claim boundaries of the master specification.
No derivative publication may turn external PMS domain profiles into internal EM modules.
```
