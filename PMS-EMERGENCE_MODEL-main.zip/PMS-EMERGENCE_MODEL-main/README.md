# PMS–EM: Emergence Model

## Purpose

**PMS–EM** is a corpus-form emergence / developmental-architecture repository for reading trace-backed regularity, measurement, projection, diary discipline, auditability, and meta-developmental legibility.

It does not claim developmental law, inevitability, diagnosis, consciousness, personhood, moral status, rights status, or proof that an observed process is emergence in any metaphysical sense.

Compact boundary:

```text
emergence readability ≠ emergence proof
trace-backed regularity ≠ developmental law
projection ≠ inevitability
diary discipline ≠ consciousness evidence
reader navigation ≠ authority
```

---

## Ecosystem Position

PMS–EM belongs to the PMS corpus-form repository family. It is adjacent to PMS as a developmental-architecture corpus.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies compatible praxis and operator grammar, but does not validate EM claims. |
| MIP | Neighboring praxeological anthropology corpus; MIP does not become an EM diagnostic model. |
| PMS-STRATA | Can inspect composition, decomposition, projection, and level movement in developmental architecture. |
| PMS-DISCIPLINE | Provides application restraint and stop logic where EM materials become person-near or decision-adjacent. |
| PMS — UNDER LOAD | Critiques emergence overclaim, projection drift, reader/corpus authority, and self-application pressure. |

PMS–EM should be read as a disciplined corpus for emergent regularity and development-facing structure, not as a universal theory of emergence.

---

## Repository Form

This is a **corpus-form emergence / developmental-architecture repository**.

| Material | Function |
| --- | --- |
| `00_source/` | Canonical source text and long-form material. |
| `01_blocks/` | Modular owner blocks and theory sections. |
| `02_appendices/` | Appendices and additional support material. |
| `03_reference/` | Reference maps, paths, checks, and boundary materials. |
| `04_minified/` | Compact summaries and controls. |
| `05_derivative_publications/` | Derivative or publication-facing materials where present. |
| `06_PMS-EM Reader/` | Optional local reader for corpus navigation. |

The repository form makes the corpus inspectable. It does not turn the corpus into a proof system.

---

## PMS–EM Reader

![PMS–EM Reader screenshot](06_PMS-EM%20Reader/screenshot.png)

The repository includes an optional local reader tool in:

```text
06_PMS-EM Reader/
```

The reader is a single-file Python / Tkinter desktop application for browsing the PMS–EM Markdown corpus locally.

It supports:

```text
canonical PMS–EM file navigation
document-level heading navigation
corpus-wide text search
search-result jumps
light / dark mode
fullscreen toggle
font-size controls
large-document rendering
Markdown-light rendering
```

Run from the repository root:

```bash
python "06_PMS-EM Reader/pms_em_reader.py"
```

Or run with an explicit folder or ZIP path:

```bash
python "06_PMS-EM Reader/pms_em_reader.py" /path/to/PMS-EM
python "06_PMS-EM Reader/pms_em_reader.py" /path/to/PMS-EM.zip
```

Reader boundary:

```text
reader navigation ≠ theory evidence
large-document rendering ≠ corpus authority
search result ≠ claim validation
```

The reader does not replace canonical Markdown files, modify the specification, or constitute evidence for PMS–EM theory, implementation status, consciousness, sentience, personhood, moral status, or rights status.

---

## Core Layer Discipline

PMS–EM keeps several layers separate.

```text
source observation
≠
trace-backed regularity
≠
measurement
≠
projection
≠
developmental architecture
≠
normative conclusion
```

The project may show how regularities become legible across time, practice, trace, and projection. It does not treat regularity as inevitability or projection as prophecy.

---

## Active Axis Notation

PMS–EM uses active axis notation to keep observed process, trace, measurement, projection, and reflection distinct.

The axis notation should be read as a navigation discipline:

```text
what is observed
what is reconstructed
what is measured
what is projected
what remains open
```

It is not a law of development, consciousness scale, maturity score, or rights-status classifier.

---

## Operational Layer Discipline

PMS–EM should preserve these distinctions in use:

| Distinction | Boundary |
| --- | --- |
| emergence readability | not proof of emergence |
| trace-backed regularity | not inevitability |
| measurement | not final ontology |
| projection | not prediction authority |
| diary discipline | not personhood evidence |
| corpus navigation | not validation |

Where PMS–EM materials are used with AI systems or in sensitive applied settings, route the use through PMS-DISCIPLINE or another explicit application boundary. Do not treat the corpus as a direct decision tool.

---

## Implementation Status

PMS–EM is corpus-implemented rather than software-complete.

It currently provides:

```text
canonical source material
owner blocks
appendices
reference layers
minified layers
derivative-publication space
reader tooling
```

Implementation status does not mean the project is experimentally validated, externally replicated, or suitable for automated classification.

---

## How to Read the Project

Recommended path:

```text
README
→ 00_source
→ 01_blocks
→ 02_appendices
→ 03_reference
→ 04_minified
→ optional Reader
```

For a quick orientation, start with the core source material and then use the reader for local navigation, search, and heading traversal.

For modification or contribution, first identify whether the change affects a source claim, block formulation, appendix support, reference pathway, minified control, derivative text, or reader behavior.

---

## Contribution and Modification Rule

Contributions should preserve:

```text
source traceability
layer separation
projection limits
non-diagnostic status
non-personhood status
non-rights-status status
reader non-authority
```

Do not add material that converts PMS–EM into:

```text
developmental law
consciousness detector
sentience test
personhood classifier
moral-status calculator
rights-status instrument
inevitability model
```

---

## Relation to the PMS Ecosystem

PMS–EM participates in the broader PMS ecosystem as a corpus-form project concerned with emergence and developmental architecture.

It can dock with PMS Base, MIP, STRATA, DISCIPLINE, ORCHESTRATOR, and UNDER LOAD only under declared claim boundaries.

Strong reduction:

```text
developmental legibility ≠ developmental authority
```

---

## Status

PMS–EM exists as a corpus-form emergence / developmental-architecture project with source, block, appendix, reference, minified, derivative, and reader layers.

Its current status is:

```text
corpus-form
developmental-architecture oriented
trace-aware
projection-bounded
reader-supported
non-diagnostic
non-validating
```

---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS–EM DOI | [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.21071650.svg)](https://doi.org/10.5281/zenodo.21071650) |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing PMS–EM, cite the repository release and DOI corresponding to the version used. Do not cite PMS–EM as if it proves emergence, predicts development, diagnoses a subject, or establishes moral/personhood/rights status.

---

## License

Unless otherwise noted, textual theory, papers, documentation, case materials, examples, prompts, diagrams, and non-executable corpus materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, reader applications, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
