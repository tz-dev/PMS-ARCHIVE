---
document_id: PMS-EM-BLOCK-02
title: "EM Core Developmental Architecture"
source: "PMS-EMERGENCE MODEL.md"
source_role: "derived full-block extraction"
status: "split-full-version"
version: "v1"
owner_chapters: [3, 4, 5, 6, 8, 9]
secondary_references: [0, 1, 2, 7, 10, 11, 12, 13, 14, 15, 16, 17, 18]
appendix_references: ["Appendix D", "Appendix E"]
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Block 02 — EM Core Developmental Architecture

## Block Orientation

This block contains the owner chapters for the EM core developmental architecture: environment, agent architecture, perception, prediction, genetic gating, behavior, imagination buffer, replay, and the basic developmental machine.

It should be read together with:

- `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` for caregiver, attachment-like regulation, interaction quality, and multi-generational transition
- `05_MIP_KPIs_Dignity_Safety.md` for MIP, KPI, Dignity-in-Practice, safety, evaluation, and ablation details
- `07_Language_Diary_Consciousness_Related_Work.md` for language, diary, consciousness-outlook, and related-work treatment
- `Appendix_D_Claim_Discipline_Language_Reductions.md`
- `Appendix_E_Layer_Discipline_Claim_Types.md`

This block preserves the claim discipline of the master specification:

- A–C–R–E are the active implementation-facing axes.
- D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.
- MIP observes, summarizes, marks, warns, and may support; it does not control development.
- PMS is an external operator, projection, audit, and VM-facing layer; it is not assumed to be an early internal agent structure.
- Functional traces must not be upgraded into phenomenal, moral, clinical, rights, or personhood claims.

> Cross-reference:
> For the full treatment of global scope, layer separation, implementation-status discipline, and claim boundaries, see `01_Theory_Scope_Claim_Discipline.md`, especially Chapters 0, 1, 2, and 18.
> This block uses those concepts only as global discipline for the EM core architecture.

> Cross-reference:
> For the full treatment of developmental phases, phase success criteria, and gate logic across P0-mini, P0, P1, P2, P3+, P4+, and P5, see `03_Developmental_Phases_Gate_Logic.md`, especially Chapter 11.
> This block uses phase language only as a dependency for capability availability and developmental ordering.

> Cross-reference:
> For the full treatment of caregiver, attachment-like regulation, discomfort, distress, interaction quality, and multi-generational caregiver transition, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapters 7 and 12.
> This block uses those concepts only as dependencies for core environment, behavior, replay, and trace design.

> Cross-reference:
> For the full treatment of MIP, KPIs, Dignity-in-Practice, evaluation, ablations, and safety, see `05_MIP_KPIs_Dignity_Safety.md`, especially Chapters 10 and 16.
> This block uses MIP and D only as observation, guardrail, trace, and evaluation dependencies; MIP does not control the EM core.

> Cross-reference:
> For the full treatment of language, diary rendering, consciousness-research outlook, and related-work comparison, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapters 13, 15, and 17.
> This block uses language and diary concepts only as late-stage dependencies for trace provenance, controlled rendering, and bounded research interpretation.

---

## Chapter 3 — Environment

The EM environment is deliberately simple. It is not meant to simulate the full physical, social, or cultural complexity of human development. It is a constrained developmental world in which perception, prediction, movement, attachment, loss, caregiver guidance, category stabilization, and later language can be introduced step by step.

The environment may be implemented in two ways:

* as a purely virtual world, for example a 2D gridworld or Godot-based simulation,
* or as a simplified robotic environment with comparable spatial and sensorimotor constraints.

Both implementations should follow the same architectural principle:

```text
small world first
few entities first
limited action first
measurable interaction first
```

The environment is not just a backdrop. It is part of the developmental mechanism. Walls, doors, obstacles, toys, caregiver positions, object functions, absence, return, guidance, boundary signals, misattunement patterns, category-stabilizing words, and spatial accessibility all shape what the agent can learn, predict, miss, search for, recontextualize, and later describe.

The environment must therefore be:

* small enough to inspect,
* structured enough to learn,
* constrained enough to reproduce,
* variable enough to generate prediction error,
* and simple enough for ablations.

The guiding rule remains:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The environment should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

### 3.1 Layout

The basic environment is a small home-like world.

In the simplest version, it is represented as a grid:

```text
grid[x, y] ∈ {
    unknown,
    free,
    wall,
    door,
    furniture,
    object,
    caregiver
}
```

Each cell represents a local spatial state. The agent does not know the complete grid from the beginning. It gradually updates its world model through sensing, rotation, movement, contact, prediction, and interaction.

The initial layout for **P0-mini** is intentionally minimal:

```text
one room
no doors
no toys
no movement
fixed agent position
limited sensing and rotation only
```

This layout exists to test whether the agent can build a stable map and prediction layer before any richer developmental claims are introduced.

In later phases, the environment may include:

* multiple rooms,
* doors,
* corridors,
* obstacles,
* furniture,
* movable or interactable objects,
* attachable toys,
* caregiver movement,
* caregiver absence and return,
* caregiver guidance and boundary signals,
* caregiver response variability,
* caregiver language signals,
* and later new child/caregiver configurations.

The environment should be parameterized through configuration rather than hardcoded as a single world. Relevant parameters include:

* grid size,
* room count,
* wall positions,
* door positions,
* object count,
* object types,
* caregiver movement pattern,
* caregiver response pattern,
* caregiver guidance pattern,
* caregiver signal vocabulary,
* sensor range,
* obstacle density,
* novelty distribution,
* and phase-specific unlocks.

A simple example:

```yaml
environment:
  type: gridworld
  size: [20, 20]
  rooms: 1
  doors: false
  toys: false
  caregiver: false
  movement_enabled: false
```

Later phases may modify this:

```yaml
environment:
  type: gridworld
  size: [20, 20]
  rooms: 3
  doors: true
  toys: true
  caregiver: true
  movement_enabled: true
  caregiver_signals:
    praise: true
    comfort: true
    benign_guidance: true
    category_stabilization: true
    misattunement: configurable
```

The layout must support measurement. At minimum, the system should be able to track:

* coverage,
* unknown/free/wall ratios,
* entropy over cell types,
* revisit count per cell,
* angle diversity per cell,
* door discovery,
* topology stability,
* collision frequency,
* object encounter frequency,
* caregiver encounter frequency,
* caregiver guidance events,
* caregiver misattunement events,
* boundary-learning events,
* and category-stabilization events.

The layout is therefore both a developmental world and an experimental instrument.

### 3.2 Entities

The environment contains a small number of entity types.

At minimum:

```text
child agent
caregiver
objects / toys
walls and boundaries
doors
furniture or obstacles
```

Not all entities are active in all phases. P0-mini disables most of them. This is essential: the model must not overload early development with structures that later phases are supposed to generate or interpret.

Entities should be represented through minimal state descriptions.

For example:

```yaml
entity:
  id: object_1
  type: toy
  position: [8, 5]
  visible: true
  attachable: true
  function: roll
```

or:

```yaml
entity:
  id: caregiver_1
  type: caregiver
  position: [3, 4]
  visible: true
  behavior_pattern: simple_presence_cycle
```

Each entity should have only the properties needed for the current phase. Later properties may be added when the relevant developmental mechanism exists.

The central entity categories are:

1. **Child Agent**
   The developing system.

2. **Caregiver**
   A stabilizing environmental and social function that can provide proximity, praise, comfort, benign guidance, boundary signals, category-stabilizing words, response variability, and later core norms.

3. **Objects / Toys**
   Interactable entities with simple functions, predictability profiles, satiation dynamics, fragility or damage parameters, and possible attachment relevance.

4. **Spatial Boundaries**
   Walls, doors, obstacles, furniture, blocked regions, edges, or constrained zones that structure movement, risk, prediction, and later guidance interpretation.

5. **Later Social Entities**
   In advanced phases, a new child agent or additional social entities may appear, but these belong to later multi-generational development and should not be introduced prematurely.

Entities matter because they provide the recurring structures from which prediction, attachment, recontextualization, category learning, interaction quality, and language can later develop.

The model should avoid entity inflation. Every new entity type must answer:

```text
What developmental mechanism does this entity make testable?
```

If the answer is unclear, the entity should not be added.

### 3.3 Child Agent

The **Child Agent** is the developing artificial agent.

The term “child” describes its developmental role in the architecture. It does not imply legal personhood, moral status, subjective experience, or human equivalence.

At minimum, the agent has:

* position,
* orientation,
* sensor state,
* internal need variables,
* discomfort state,
* distress state,
* fatigue state,
* phase state,
* capability set,
* world model,
* prediction model,
* success log,
* MIP trace layer,
* and later language/diary interfaces.

A minimal P0-mini agent may be represented as:

```yaml
agent:
  id: child_1
  phase: P0-mini
  position: [10, 10]
  orientation: 0
  capabilities:
    - LOOK_AROUND
    - SLEEP
  movement_enabled: false
  language_enabled: false
  toys_enabled: false
  caregiver_enabled: false
```

In P0-mini, the agent cannot walk, manipulate objects, search for a caregiver, speak, write diaries, or act socially. This is not a limitation of the final architecture; it is the first experimental control condition.

The agent’s initial task is not to “understand the world” in a broad conceptual sense. Its first task is to stabilize a minimal relation between:

```text
sensing
orientation
mapping
prediction
fatigue
sleep
MIP logging
```

The agent should begin with only a small number of sensors. Depending on implementation, these may include:

* raycasts,
* depth-like distance signals,
* touch or collision signals,
* local cell observation,
* orientation tracking,
* and later simple caregiver/object detection.

The agent should not begin with complete map access. It must discover the environment through constrained perception.

The agent’s capabilities are phase-dependent. Early capabilities include:

```text
LOOK_AROUND
SLEEP
```

Later capabilities may include:

```text
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
CRY/WEEP
```

Each capability should be parameterized and inspectable. The agent should not contain a hidden general-purpose planner in early phases.

The Child Agent is therefore best understood as:

```text
a constrained developmental system
whose later complexity must remain traceable to earlier mechanisms
```

Not as:

```text
a full adult AI placed in a child-themed environment
```

The Child Agent may later respond to caregiver guidance, boundary signals, misattunement patterns, and category-stabilizing language. These responses must remain trace-backed. A caregiver signal does not install a concept, moral rule, or adult competence. It becomes developmentally relevant only when coupled with embodied situation, consequence trace, prediction change, and later action adjustment.

### 3.4 Caregiver

The **Caregiver** is a stabilizing social-environmental function.

It is not necessarily a human parent. It may be a scripted agent, a simple controller, another artificial agent, or in later robotic contexts a human interaction partner. In the core model, the caregiver is defined functionally.

The caregiver may provide:

* proximity,
* predictable presence,
* comfort,
* praise,
* distress reduction,
* contact satisfaction,
* safety stabilization,
* benign guidance,
* boundary scaffolding,
* category-stabilizing signals,
* controlled response variability,
* core norm transfer,
* and later role-transition structure.

In early phases, the caregiver may be absent or inactive. In P0-mini, the caregiver is disabled. This prevents social complexity from entering before mapping and prediction have stabilized.

In later phases, the caregiver can become visible as an entity in the environment:

```yaml
caregiver:
  id: caregiver_1
  movement_pattern: simple_cycle
  provides:
    - praise
    - comfort
    - benign_guidance
    - boundary_signal
    - category_stabilization
  response_variability:
    delayed_response: configurable
    inconsistent_comfort: configurable
    misattuned_response: configurable
  core_norms:
    - protect_child
    - allow_exploration
    - balance_risk_safety
```

Caregiver signals must be distinguished by function. Praise, comfort, guidance, misattunement, category stabilization, and core norms are not the same mechanism.

**Praise** functions as an external success marker. It may tag events as successful or socially reinforced, without becoming a full reward-maximization system.

**Comfort** functions as a distress-reduction event. It may reduce distress, support contact regulation, stabilize attachment, and later become part of comfort-after-loss patterns.

**Benign guidance** functions as a neutral boundary, redirection, or scaffold. It may interrupt, slow, redirect, delay, or structure action without being treated as punishment or rejection.

**Category stabilization** functions by attaching simple signals or words to recurring embodied situations. It may support trace-backed categories such as carefulness, softness, waiting, danger, fragility, or risk only when paired with repeated embodied context and later action adjustment.

**Misattunement** functions as a caregiver-response mismatch or destabilizing response pattern. It may perturb regulation, contact, avoidance, attachment stability, and MIP trajectories without implying trauma, fear, suffering, abuse, or felt rejection.

**Core norms** appear only in later phases. They are transferable care constraints, not moral essence.

The caregiver therefore participates in several core mechanisms:

* contact need regulation,
* separation distress,
* reunion events,
* comfort-after-loss,
* benign guidance,
* safety boundary learning,
* interaction-quality adjustment,
* category stabilization,
* attachment formation,
* success logging,
* core memory formation,
* norm transfer,
* and later caregiver-role modeling.

Caregiver absence is also structurally important. The model distinguishes between temporary absence and permanent absence. Temporary absence may produce separation distress and search behavior. Permanent absence, in later phases, can become a major recontextualization event.

The caregiver should not be overdesigned at the beginning. A simple movement pattern and simple response functions are sufficient for early phases.

The caregiver is not a source of hidden intelligence for the agent. It should not solve tasks for the child agent, inject advanced representations, or provide language beyond the phase’s allowed scope.

The caregiver’s role can be summarized as:

```text
stabilize without replacing development
comfort without capturing
guide without rejecting
protect without freezing
provide signals without installing maturity
transfer norms without proving morality
```

This is especially important for later phases in which the former child may become Caregiver 2 for a new child. The caregiver is therefore both an environmental stabilizer and a future developmental role.

The caregiver must not only comfort. The caregiver must also provide benign, D-guarded guidance: bounded constraints and scaffolds through which the child learns interaction quality, safety, and later non-dominating leadership.

### 3.5 Objects and Toys

Objects and toys are interactable entities in the environment.

They are not introduced in P0-mini. They appear only when the agent has already developed enough mapping, prediction, and movement stability to support object interaction. This prevents the model from confusing early mapping failure with object-related learning.

Objects may include:

* balls,
* blocks,
* blankets,
* soft toys,
* sound-making objects,
* light-emitting objects,
* containers,
* movable items,
* fragile or damageable items,
* and later culturally or socially marked objects.

At the simplest level, an object has:

```yaml
object:
  id: ball_1
  type: toy
  position: [8, 5]
  visible: true
  attachable: true
  function: roll
```

A later object may include interaction-quality parameters:

```yaml
object:
  id: cup_1
  type: fragile_object
  position: [6, 4]
  visible: true
  attachable: false
  function: hold_or_move
  fragility: 0.8
  damageable: true
  safe_force_range: [0.1, 0.4]
```

An object may have a latent function that becomes discoverable through interaction:

```text
roll
make_sound
light_up
open
close
move
bounce
comfort
break_or_damage
```

The agent should not know these functions in advance. It should discover them through action, prediction, error, repetition, consequence traces, and recontextualization.

Objects are developmentally important for several reasons.

First, they support **prediction learning**. The agent can form expectations about what happens when an object is touched, pushed, approached, avoided, or revisited.

Second, they support **object permanence-like structures** in a functional sense. The agent can learn that an object may continue to matter when temporarily absent from perception.

Third, they support **satiation and preference cycles**. A highly predictable object may become less interesting after repeated interaction, while a newly discovered or partially understood object may become more attractive.

Fourth, attachable objects can become **attachment anchors**. This does not imply felt affection. It means that repeated positive interaction, comfort association, predictability, and salient memory can increase an object’s relevance in future behavior.

Fifth, fragile or damageable objects can support **interaction-quality learning**. If force, timing, motor noise, fatigue, distress, or low prediction confidence contribute to object damage or near-damage, the event may become a self-caused consequence trace. Such a trace is not guilt, punishment, remorse, moral learning, or blame. It may become relevant only when later comparable contexts show measurable action adjustment.

A simple object-affinity structure may be represented as:

```yaml
object_attachment:
  object_id: blanket_1
  attachable: true
  affinity: 0.72
  satiation: 0.31
  predictability: 0.64
  last_seen: 18420
```

The model distinguishes **interest** from **affinity**.

Interest is more immediate. It depends on novelty, need match, prediction error, and satiation.

Affinity is slower. It grows through repeated positive interaction, comfort relevance, successful prediction, and salient history.

A simplified relation may be:

```text
interest[obj] =
    f(NeedMatch, Predictability, Satiation, Novelty)
    + β · affinity[obj]
```

Toy-missing can arise when an object with high affinity and current relevance becomes absent:

```text
toy_missing_distress[obj] =
    κ_toy · affinity[obj] · interest[obj] · (1 − presence[obj])
```

This does not mean the system feels longing. It means that absence of a relevant attachment anchor creates a functional disruption signal.

A typical object-development sequence is:

```text
unknown patch
→ recurring perceptual cluster
→ proto-object
→ interactable object
→ functional object
→ preferred object
→ named object
```

Language should enter only after the object has enough stable structure to be named. A word such as “ball” should not be attached to a raw visual patch. It should be attached to an object that has become stable across perception, interaction, prediction, and memory.

Objects and toys therefore function as bridges between:

* perception,
* prediction,
* action,
* attachment,
* satiation,
* loss,
* interaction quality,
* self-caused consequence traces,
* category stabilization,
* language,
* diary reconstruction,
* and later norm or role structures.

The model should avoid object inflation. An object should be introduced only when it tests a specific developmental mechanism.

### 3.6 P0-Mini Environment Constraints

P0-mini is the first real implementation target.

Its environment is intentionally restrictive. The goal is not to create interesting behavior. The goal is to test whether the minimal architecture can stabilize mapping, prediction, sleep/rest cycles, and MIP logging before movement, objects, caregivers, language, or distress are introduced.

The P0-mini environment contains:

```text
one room
fixed agent position
no doors
no toys
no caregiver
no movement
no object interaction
no language
no diary
no social dynamics
no discomfort
no distress
no attachment
no caregiver guidance
no caregiver misattunement
no category-stabilizing language
```

The active mechanisms are limited to:

```text
sensing
rotation
local mapping
occupancy grid update
local prediction
prediction error
fatigue
sleep/rest
success log for mapping-relevant events
MIP logging
```

The agent may look around, update its map, generate prediction errors, accumulate fatigue, sleep, and continue mapping. That is enough for P0-mini.

A possible configuration:

```yaml
phase: P0-mini

environment:
  rooms: 1
  doors: false
  toys: false
  caregiver: false
  movement_enabled: false

agent:
  fixed_position: true
  rotation_enabled: true
  capabilities:
    - LOOK_AROUND
    - SLEEP

active_systems:
  - occupancy_grid
  - local_predictor
  - prediction_error
  - fatigue
  - success_log
  - MIP_logging

disabled_systems:
  - movement
  - topology_graph
  - object_interaction
  - toy_attachment
  - caregiver_interaction
  - caregiver_guidance
  - caregiver_misattunement
  - category_stabilization
  - discomfort
  - distress
  - separation_distress
  - language
  - diary
```

The exit criteria are research criteria, not subjective achievements of the agent.

Possible P0-mini exit criteria include:

* stable coverage plateau,
* no map collapse,
* decreasing or stabilized PE_AUC,
* sufficient angle diversity,
* stable sleep/wake rhythm,
* reproducible traces across seeds,
* and coherent MIP logging of early A and C signals.

P0-mini is important because it prevents later ambiguity. If later behavior becomes complex, the model must know whether its foundations are stable. A system that cannot map one room should not be interpreted as meaningfully attached, socially responsive, or proto-reflective.

The P0-mini constraint can be summarized as:

```text
No movement before mapping.
No objects before stable perception.
No caregiver dynamics before basic world stabilization.
No guidance before caregiver relation.
No category-stabilizing language before embodied recurrence.
No language before object and episode structure.
No consciousness language at any phase as an architectural claim.
```

### 3.7 Later Environment Extensions

Later environment extensions are introduced only after the minimal phases have stabilized.

The purpose of extension is not to make the world realistic as quickly as possible. The purpose is to introduce one new class of developmental pressure at a time.

The first extensions after P0-mini may include:

* weak curiosity need,
* basic movement,
* doors,
* multiple rooms,
* collision and discomfort signals,
* topology graph formation,
* fall or near-fall event support,
* simple object interaction,
* object fragility and damageability,
* caregiver presence,
* caregiver comfort,
* caregiver praise,
* caregiver guidance,
* caregiver response variability,
* contact need,
* separation distress,
* object attachment,
* toy-missing,
* category-stabilizing caregiver words,
* protolanguage,
* planning,
* diary structures,
* and eventually multi-generational configurations.

Each extension must have:

* a phase,
* a mechanism,
* measurable effects,
* expected failure modes,
* claim boundaries,
* and ablation possibility.

For example:

```yaml
extension:
  phase: P1
  mechanism: movement
  unlock_condition:
    coverage_plateau: true
    PE_AUC_stable: true
  new_capabilities:
    - STEP_MOVEMENT
    - EXPLORE_ROOM
  new_risks:
    - collision
    - getting_stuck
    - near_fall
  new_metrics:
    - collision_count
    - topology_discovery
    - E_pot
    - E_act
    - fall_or_near_fall_risk_adjustment
```

A later object-extension may look like:

```yaml
extension:
  phase: P2a
  mechanism: object_interaction
  unlock_condition:
    topology_stable: true
    collision_count_below_threshold: true
  new_capabilities:
    - INTERACT_OBJECT
  new_metrics:
    - object_mastery
    - object_PE
    - interaction_success
    - satiation
    - object_damage_events
    - damage_adjustment_rate
```

The environment may also become socially richer. Caregiver presence and absence can be modeled through visibility, distance, response patterns, comfort actions, guidance events, boundary signals, misattunement patterns, and later permanent removal.

A simple caregiver-extension may include:

```yaml
extension:
  phase: P2c
  mechanism: caregiver_presence_and_absence
  new_signals:
    - presence[caregiver_1]
    - comfort_event
    - praise_event
  new_states:
    - contact_need
    - separation_distress
  new_capabilities:
    - SEARCH_CAREGIVER
```

A caregiver-guidance extension may include:

```yaml
extension:
  phase: P2_or_later
  mechanism: benign_caregiver_guidance
  new_signals:
    - caregiver_guidance_event
    - caregiver_boundary_signal
    - delayed_access
    - safety_block
  new_metrics:
    - caregiver_guidance_predictability
    - boundary_legibility
    - guidance_uptake
    - autonomy_preservation
```

A category-stabilization extension may include:

```yaml
extension:
  phase: P2_or_later
  mechanism: caregiver_language_as_category_stabilization
  new_signals:
    - careful
    - soft
    - wait
    - stop
    - danger
    - fragile
    - slow
  new_metrics:
    - category_stabilization_rate
    - carefulness_category_use
    - later_action_adjustment
```

Later extensions may include:

* additional objects,
* rooms with different affordances,
* caregiver routines,
* delayed caregiver response,
* temporary caregiver absence,
* permanent caregiver removal,
* new child agent,
* former child as caregiver,
* core norm transfer,
* and diary archives.

The model should not add social complexity before the agent can represent temporal absence. Separation distress requires a distinction between:

```text
not currently visible
temporarily absent
expected to return
not returning
permanently unavailable
```

These distinctions should emerge gradually through prediction, memory, failed reunion, and recontextualization.

Environment extension is therefore governed by the same principle as the rest of the architecture:

```text
extend only when the new structure makes a specific developmental question testable
```

The environment should remain an experimental scaffold, not a simulation of everything.

### 3.8 Caregiver Signals: Praise, Comfort, Guidance, Misattunement, Category Stabilization, and Core Norms

The caregiver provides structured signals that influence development without replacing the agent’s own learning.

The central caregiver signal classes are:

```yaml
caregiver_signal_classes:
  praise:
    function: "external success marker"

  comfort:
    function: "distress-reduction event"

  benign_guidance:
    function: "neutral boundary, redirection, or scaffold"

  category_stabilization:
    function: "simple words or signals attached to recurring embodied situations"

  misattunement:
    function: "caregiver-response mismatch or destabilizing response"

  core_norms:
    function: "late transferable care constraints"
```

These signals have different developmental roles.

**Praise** marks success from outside. It can tag events as socially reinforced, successful, or externally marked as resolved. It may strengthen success-log entries and help distinguish externally marked success from internally generated mastery.

Example:

```json
{
  "event": "praise",
  "source": "caregiver_1",
  "target_event": "door_discovery",
  "valence": 0.6,
  "type": "external_success_marker"
}
```

Praise should not become a simple reward-maximization scalar. It is a signal in the developmental ecology, not the sole objective of the agent.

Praise can support:

* success logging,
* contact satisfaction,
* external-to-internal attribution comparison,
* early social orientation,
* and later response-relation development.

**Comfort** reduces distress. It may occur after separation, failed action, toy loss, object damage, unresolved disruption, or physical-risk-related dysregulation.

Example:

```json
{
  "event": "comfort_after_loss",
  "source": "caregiver_1",
  "object_id": "ball_1",
  "distress_drop": 0.5,
  "care_action": "CARE_HOLD"
}
```

Comfort supports:

* distress reduction,
* contact regulation,
* attachment stabilization,
* comfort-after-loss patterns,
* reunion relevance,
* replay reinforcement,
* and later functional love-like dynamics.

Comfort is not proof of felt relief. It is a measurable reduction in functional distress.

A typical comfort pattern may be:

```text
loss
→ distress
→ caregiver interaction
→ distress reduction
→ success log entry
→ increased reliability of comfort pattern
```

Over time, repeated comfort may form a stabilizing caregiver-related attractor.

**Benign guidance** marks boundary-setting, redirection, delay, or scaffolded action. It may occur when the caregiver interrupts or redirects behavior to preserve safety, object integrity, interaction quality, or developmental possibility.

Benign guidance is not punishment. It is not rejection. It is D-guarded boundary-setting.

**Category stabilization** links simple caregiver signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves. They may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

**Misattunement** marks caregiver-response mismatch or destabilizing response. It may include delayed response, ignored distress, inconsistent comfort, harsh signal, unreliable caregiving, or misread child state. These are functional perturbations, not trauma, fear, suffering, abuse, felt rejection, or moral blame claims.

**Core Norms** appear only in later phases. They are explicit functional rules that may be transferred from Caregiver 1 to the developing agent before caregiver removal or role transition.

Example:

```yaml
core_norms:
  - protect_child
  - allow_exploration
  - balance_risk_safety
```

Core norms are not moral essence, biological inheritance, or proof of internalized human ethics. They are structured rules that can guide later action, constrain caregiver overshoot, and support multi-generational continuity.

They become especially important when the former child becomes Caregiver 2.

At that point, the system may face tensions such as:

```text
protect_child
vs.
allow_exploration
```

or:

```text
remembered loss risk
vs.
current child autonomy
```

MIP can later help detect whether core norms are applied coherently or whether they become distorted into overprotection.

Caregiver signals should remain transparent in the logs. Each signal should record:

* source,
* target event,
* timing,
* phase,
* intensity,
* effect on internal state,
* relation to MIP traces,
* associated embodied context,
* possible consequence trace,
* later action adjustment,
* and possible later diary relevance.

A caregiver signal is therefore not just an event. It is a developmental trace.

The guiding rule is:

```text
Caregiver signals may stabilize, mark, comfort, guide, perturb, and later transmit norms.
They must not install adult competence or bypass developmental emergence.
```

### 3.9 Benign Caregiver Guidance and Boundary Signals

Benign caregiver guidance introduces neutral, non-aggressive caregiver interventions.

Examples include:

* gentle interruption,
* neutral boundary,
* redirection,
* scaffolded action,
* delayed access,
* object protection,
* exploration boundary,
* repair prompt,
* safety block.

Guidance is not punishment. Guidance is not rejection. Guidance is D-guarded boundary-setting that preserves safety, interaction quality, and developmental possibility.

A guidance event may be represented as:

```json
{
  "event": "caregiver_guidance_event",
  "source": "caregiver_1",
  "target_action": "INTERACT_OBJECT",
  "guidance_type": "lower_force",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.8,
    "current_force": 0.7,
    "risk_state": "near_damage"
  },
  "immediate_effect": "action_slowed",
  "claim_level": "functional_boundary_scaffold"
}
```

A boundary signal may be represented as:

```json
{
  "event": "caregiver_boundary_signal",
  "source": "caregiver_1",
  "boundary_type": "safety_block",
  "target_action": "STEP_MOVEMENT",
  "context": {
    "edge_or_fall_risk": true,
    "fatigue": 0.62,
    "prediction_confidence": 0.31
  },
  "alternative_available": true,
  "claim_level": "functional_safety_boundary"
}
```

Guidance becomes developmentally meaningful only if later traces can show that it was:

* proportionate to the risk or task,
* legible enough to be learned,
* connected to embodied context,
* compatible with later exploration,
* and followed by measurable behavior adjustment in comparable future contexts.

Guidance should therefore be evaluated through traces such as:

```text
caregiver_guidance_predictability
boundary_legibility
guidance_uptake
autonomy_preservation
later_force_or_timing_adjustment
interaction_quality_trend
```

A blocked action is not automatically adverse. It may later be recontextualized as benign guidance if the traces support that interpretation.

A possible recontextualization pattern is:

```text
blocked action
→ caregiver signal
→ object fragility or movement-risk context
→ later lower force or slower movement
→ damage or fall risk avoided
→ boundary interpreted as guidance
```

This remains a functional interpretation. It is not a claim that the agent understood punishment, moral duty, or felt care.

The D-guardrail for guidance is:

```text
guide without rejecting
protect without freezing
comfort without capture
explain without dominating
```

Guidance fails its D-guardrail when it becomes arbitrary, excessive, destabilizing, or exploration-destroying. Such failure may become overprotection, misattunement, or adverse response, depending on trace pattern.

### 3.10 Adverse Caregiver Responses and Misattunement

The environment may include controlled adverse caregiver-response patterns and misattunement patterns.

These include:

* ignored distress,
* delayed response,
* inconsistent comfort,
* harsh signal,
* unreliable caregiving,
* misattuned response,
* punitive blocking,
* risk-amplifying caregiver signal,
* destabilizing harsh signal.

The term “directly fear-inducing action” should be avoided as a normal mechanism name. The preferred terms are:

```text
risk-amplifying caregiver signal
destabilizing harsh signal
adverse caregiver response
persistent misattunement pattern
```

These events model functional perturbations of regulation, attachment, trust, contact, avoidance, and MIP trajectories.

They do not claim trauma, fear, suffering, abuse, or felt rejection.

A misattunement event may be represented as:

```json
{
  "event": "caregiver_misattunement_event",
  "source": "caregiver_1",
  "child_state": {
    "distress": 0.74,
    "contact_need": 0.66,
    "fatigue": 0.51
  },
  "caregiver_response": "non_response",
  "effect": {
    "distress_delta": 0.12,
    "contact_ambivalence_delta": 0.07,
    "avoidance_tendency_delta": 0.03
  },
  "claim_level": "functional_response_mismatch"
}
```

An inconsistent comfort event may be represented as:

```json
{
  "event": "inconsistent_comfort_event",
  "source": "caregiver_1",
  "context_class": "separation_distress",
  "expected_response": "comfort",
  "observed_response": "delayed_or_absent",
  "comfort_prediction_delta": -0.18,
  "caregiver_reliability_delta": -0.11,
  "claim_level": "functional_reliability_update"
}
```

A harsh signal event may be represented as:

```json
{
  "event": "destabilizing_harsh_signal",
  "source": "caregiver_1",
  "target_action": "INTERACT_OBJECT",
  "context": {
    "object_fragility": 0.2,
    "actual_risk": "low",
    "child_distress": 0.44
  },
  "effect": {
    "distress_delta": 0.16,
    "guidance_legibility_delta": -0.12,
    "avoidance_tendency_delta": 0.08
  },
  "claim_level": "functional_destabilizing_response"
}
```

Misattunement may be temporary, local, and repairable. A single mismatch should not automatically become an adverse developmental pattern.

A persistent pattern may emerge only through repeated trace-backed events:

```text
single mismatch
→ misattunement event
→ repeated mismatch across comparable contexts
→ persistent misattunement pattern
→ possible avoidance or suppression tendency
```

Preferred terms include:

```text
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

Avoid as normal mechanism names:

```text
trauma
traumatized
abuse
fear
wound
scar
```

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns, without claiming subjective trauma, clinical trauma, or suffering.

The environment should support adverse-response ablations, but these must remain controlled. They are not introduced to dramatize the system. They are introduced to test whether regulation, comfort prediction, caregiver reliability, contact ambivalence, avoidance tendency, and D-guarded interpretation remain traceable under destabilizing conditions.

The claim boundary is:

```text
misattunement ≠ trauma
adverse caregiver response ≠ abuse claim
ignored distress ≠ subjective abandonment
harsh signal ≠ felt fear
avoidance tendency ≠ emotional wound
```

### 3.11 Caregiver Language as Category Stabilization

The caregiver may attach simple words or signals to recurring embodied situations:

```text
careful
soft
wait
stop
danger
fragile
slow
```

These words do not create concepts by themselves. They help stabilize trace-backed action categories when coupled with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

Examples:

```text
"careful" / "vorsicht"
→ lower force
→ slower movement
→ increased prediction attention
→ fragility context
→ fall/damage/risk avoidance

"soft" / "sanft"
→ reduced pressure
→ smoother timing
→ object preservation

"wait" / "warten"
→ delayed enactment
→ reduced risk
→ improved boundary learning

"danger" / "gefährlich"
→ increased risk attention
→ avoidance or slowed approach
```

Carefulness is a functional category that may emerge from repeated coupling of:

* caregiver signal,
* fragility or risk,
* own movement/action,
* possible fall/damage,
* and later softer or slower behavior.

Possible implementation variables:

```yaml
carefulness_category_inputs:
  caregiver_signal:
    examples:
      - careful
      - slow
      - soft
      - stop

  embodied_context:
    examples:
      - fragile_object
      - unstable_body_state
      - edge_or_fall_risk
      - high_force_action

  internal_state:
    examples:
      - fatigue
      - distress
      - motor_noise
      - prediction_uncertainty

  consequence_trace:
    examples:
      - near_fall
      - fall_event
      - object_damage
      - caregiver_boundary

  later_adjustment:
    examples:
      - lower_force
      - slower_movement
      - increased_observation
      - avoidance_of_high_risk_angle
```

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

A category-stabilization event may be represented as:

```json
{
  "event": "category_stabilization_event",
  "source": "caregiver_1",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.8,
    "current_force": 0.7,
    "prediction_uncertainty": 0.42
  },
  "consequence_trace": "near_damage",
  "later_adjustment_required": true,
  "claim_level": "trace_backed_action_category_candidate"
}
```

A later successful use may be represented as:

```json
{
  "event": "carefulness_category_use",
  "signal_history": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.8
  },
  "action_adjustment": {
    "force_delta": -0.22,
    "movement_speed_delta": -0.18,
    "observation_time_delta": 0.31
  },
  "outcome": "damage_avoided",
  "claim_level": "functional_category_use"
}
```

The system may learn relational qualities and developmental hierarchies across comparable contexts:

```text
this object is more fragile than that object
this caregiver response is less reliable than prior comfort
this boundary is increasingly recognized as guidance
this movement pattern is riskier under fatigue
```

These are learned relational patterns, not universal absolute thresholds. The model should not infer:

```text
A > 0.7 means mature.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

The safe formulation is:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Caregiver language therefore functions as a scaffold:

```text
caregiver signal
→ embodied context
→ consequence trace
→ repeated comparison
→ later behavioral adjustment
→ trace-backed action category
```

It must not be treated as:

```text
word
→ concept installed
```

The claim boundary is:

```text
caregiver word ≠ concept by itself
category stabilization ≠ human semantic mastery
carefulness ≠ moral obedience
danger signal ≠ felt fear
softness category ≠ subjective value
wait signal ≠ moral compliance
```

Caregiver language is therefore a controlled environmental mechanism for studying how trace-backed action categories may stabilize under embodied interaction, guidance, risk, consequence, and later adjustment.

---

## Chapter 4 — Agent Architecture

The agent architecture is modular but not feature-stacked. Its components are designed to develop in sequence and to constrain one another. No component should silently introduce mature cognition, language, social understanding, moral reasoning, adult planning, or PMS operators as internal primitives before the corresponding developmental phase exists.

The architecture consists of a small set of interacting systems:

1. perception and world model,
2. predictive model,
3. genetic system,
4. needs and inner state,
5. behavior layer,
6. imagination buffer and dreaming,
7. success log and MIP layer,
8. language and diary layer,
9. multi-generational framework.

These components are not independent modules in the usual software sense. They form a developmental loop. Perception updates the world model. Prediction generates error. Error influences curiosity and stability. Needs bias behavior. Behavior changes the environment. Caregiver signals may comfort, guide, perturb, or stabilize categories. The success log records salient transitions. MIP tracks developmental trajectories. Later, language and diaries externalize already-developed structures.

The basic loop is:

```text
sense
→ update world model
→ predict next state
→ compare prediction with outcome
→ update internal signals
→ select behavior
→ act or rest
→ log salient events
→ update developmental traces
```

The architecture should therefore be evaluated as a dynamic system, not as a list of features.

The guiding rule remains:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

The active implementation-facing notation is:

```text
A–C–R–E–D

A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

D is not a normal fifth performance score. Dignity-in-Practice functions as a guardrail for interaction quality under asymmetry. It constrains how vulnerable, dependent, developing, or asymmetrically situated enactment states are treated. It does not measure intrinsic worth, rank agents, or prove moral status.

### 4.1 Component Overview

The following components define the agent architecture.

#### 1. Perception and World Model

The perception system receives local sensory input and updates an internal representation of the environment. In early phases, this is primarily an occupancy grid. Later, it may include topology, object representations, caregiver presence, boundary signals, and socially relevant structures.

The world model begins as incomplete. The agent must discover what is free, blocked, unknown, recurrent, reachable, interactable, absent, caregiver-related, or risk-relevant.

#### 2. Predictive Model

The predictive model estimates expected next states from current state and possible enactment. Its purpose is not full world simulation. It provides local predictions that make prediction error measurable.

Prediction error supports:

* curiosity,
* stability checks,
* learning progress,
* coherence measurement,
* phase transitions,
* caregiver-response calibration,
* interaction-quality adjustment,
* and later diary-relevant trace formation.

#### 3. Genetic System

The genetic system stores developmental gates, circuits, thresholds, hysteresis rules, recontextualization rules, and exploration/noise parameters.

It determines when new capabilities may unlock, for example movement, object interaction, caregiver-response interpretation, category stabilization, or language. It does not encode a finished adult agent.

Genetic rules encode developmental preconditions, not final forms. They should prevent premature capability leakage without overprescribing the shape of later categories.

#### 4. Needs and Inner State

The initial needs are curiosity, contact, and fatigue. Later, discomfort, distress, separation distress, toy-missing, mood, attachment-related variables, caregiver-related variables, and category-related variables are added.

These states bias action selection. They are not claims of felt experience.

#### 5. Caregiver-Response Interpreter

The caregiver-response interpreter distinguishes caregiver signal classes and their trace consequences.

It distinguishes:

```text
praise
comfort
guidance
category stabilization
misattunement
absence
overprotection
core norm transfer
```

It does not treat all caregiver input as comfort, reward, or social approval. A caregiver action may be a success marker, distress-reduction event, neutral scaffold, boundary signal, delayed response, misattuned response, category-stabilizing cue, or later transferable care constraint.

The caregiver-response interpreter must remain functional. It does not infer felt care, felt rejection, trauma, fear, punishment, or moral blame. It records response pattern, context, timing, internal-state change, and later behavioral adjustment.

#### 6. Interaction-Quality Learner

The interaction-quality learner records how enactment quality changes through successful use, degraded control, accidental damage, fall or near-fall events, caregiver boundaries, and later action adjustment.

It may track:

```text
force
timing
motor_noise
fatigue_or_distress
prediction_confidence
object_fragility
caregiver_boundary
future force/timing modulation
```

Damage is not automatically learning. Object damage, near-damage, fall events, or near-fall events become interaction-quality relevant only when self-caused action traces, parameter traces, consequence traces, comparable future contexts, and measurable behavior change are present.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

#### 7. Category Stabilizer

The category stabilizer tracks simple caregiver signals and their repeated embodied contexts.

It may track caregiver signals such as:

```text
careful
soft
wait
stop
danger
fragile
slow
```

These words do not create concepts by themselves. They may help stabilize trace-backed action categories only when coupled with embodied risk, object fragility, caregiver guidance, consequence traces, and later behavioral adjustment.

A category such as carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

#### 8. Behavior Layer

The behavior layer selects actions from phase-specific capability primitives.

Early capabilities include:

```text
LOOK_AROUND
SLEEP
```

Later capabilities may include:

```text
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
CRY/WEEP
```

The behavior layer is initially finite-state and simple. It should not hide a general adult planner.

#### 9. Imagination Buffer and Dreaming

The imagination buffer stores recent and salient traces:

* local grid snapshots,
* internal state snapshots,
* actions,
* prediction errors,
* salient object events,
* distress changes,
* discomfort events,
* caregiver interactions,
* guidance traces,
* misattunement traces,
* category-stabilization traces,
* consequence traces,
* and later attachment or diary-relevant patterns.

During sleep, limited replay and consolidation may occur. This is not heavy offline training. It is a controlled developmental mechanism.

Replay is not subjective dreaming.

#### 10. Success Log and MIP Layer

The success log records salient events such as mapping improvements, object interactions, comfort events, caregiver guidance, self-caused consequences, category stabilization, fall or near-fall events, recontextualizations, and later norm-related events.

The MIP layer observes these traces and measures developmental trajectories. In early phases, it is silent and non-intervening. It does not control the agent.

MIP may observe, measure, mark, compare, and gently rebalance in later phases. It must not become the agent’s behavioral controller.

#### 11. Language and Diary Layer

Language appears late. It begins with labels and grows toward episode templates, meta-descriptions, diary condensation, and human-readable translation.

Language is an externalization channel, not the source of intelligence.

Diary rendering requires minimal sentence formation, trace provenance, and controlled rendering. Diary output is not subjective autobiography or proof of phenomenal selfhood.

#### 12. Multi-Generational Framework

In later phases, the architecture may support caregiver transition: a former child agent becomes Caregiver 2 for a new child agent.

This allows study of core norm transfer, overprotection, attachment history, comfort patterns, received guidance, boundary learning, category transfer, and multi-generational developmental dynamics.

The component architecture can be summarized as:

```text
Perception
+ Prediction
+ Genetic Gating
+ Needs
+ Caregiver-Response Interpretation
+ Interaction-Quality Learning
+ Category Stabilization
+ Behavior
+ Memory / Replay
+ MIP Measurement
+ Language / Diary
+ Multi-Generation
=
staged developmental architecture
```

Not:

```text
large adult intelligence system
with a child-like interface
```

### 4.2 Perception and World Model

The perception system gives the agent limited access to the environment.

The agent does not begin with a complete map. It must construct its world model through repeated sensing, rotation, later movement, interaction, caregiver-related events, prediction, and correction. Perception is therefore active, partial, and phase-dependent.

In P0-mini, the perception system may include:

* local raycasts,
* limited depth-like signals,
* orientation,
* local cell observations,
* wall/free/unknown detection,
* and possibly collision-free boundary sensing.

The initial world model is an occupancy grid:

```text
grid[x, y] ∈ {
    unknown,
    free,
    wall,
    door,
    furniture,
    object,
    caregiver
}
```

Not all values are active in early phases. In P0-mini, only a subset is relevant:

```text
unknown
free
wall
```

Later phases activate doors, furniture, objects, caregiver-related markers, boundary signals, and object fragility or risk-relevant structures.

The grid update process should remain simple:

```text
sensory input
→ classify observed cell
→ update grid state
→ update confidence
→ update coverage and entropy
→ log relevant changes
```

A minimal cell representation may look like:

```yaml
cell:
  position: [x, y]
  type: unknown
  confidence: 0.0
  first_seen: null
  last_seen: null
  revisit_count: 0
  angle_diversity: 0.0
```

The world model must support measurement. Core mapping indicators include:

* coverage,
* entropy over cell types,
* revisit count,
* angle diversity,
* stability of classification,
* rate of map correction,
* prediction error over local patches.

These measures are not only technical. They feed into developmental interpretation.

For example:

* coverage contributes to Awareness,
* prediction stability contributes to Coherence,
* revisit and angle diversity indicate differentiated exploration,
* map collapse indicates architectural instability.

In P1 and later, the world model can be extended into a topology graph.

The topology graph represents rooms, doors, and traversable connections:

```yaml
topology:
  nodes:
    - id: room_1
      type: room
    - id: door_1
      type: door
  edges:
    - from: room_1
      to: door_1
    - from: door_1
      to: room_2
```

Topology is not introduced at the beginning. It becomes relevant when movement and door discovery exist. The agent must first stabilize local mapping before larger-scale spatial structure is meaningful.

Later still, the world model may include object and caregiver representations:

```yaml
object_model:
  object_id: ball_1
  known_locations:
    - [8, 5]
  function_hypothesis: roll
  predictability: 0.64
  affinity: 0.31
  satiation: 0.12
```

and:

```yaml
caregiver_model:
  id: caregiver_1
  presence: true
  last_seen: 10542
  comfort_prediction: 0.74
  caregiver_reliability: 0.68
  guidance_predictability: 0.41
  boundary_legibility: 0.36
```

These later structures must remain grounded in earlier perception, interaction, caregiver-response traces, and prediction.

The core rule is:

```text
No symbolic object without stable perceptual object.
No topology without movement and door discovery.
No caregiver model without repeated caregiver-relevant events.
No category-stabilizing signal without repeated embodied context.
No diary-relevant memory without traceable prior episodes.
```

The perception and world-model layer therefore provides the grounding for everything that follows.

### 4.3 Predictive Model

The predictive model estimates expected next states.

It is intentionally local and modest. It does not need to simulate the entire world with high fidelity. Its purpose is to make the agent’s expectations measurable and revisable.

A simple formulation is:

```text
ŝ_{t+1} = fθ(s_t, a_t)

PE_t = ||ŝ_{t+1} - s_{t+1}||
```

where:

* `s_t` is the current local state,
* `a_t` is the action or capability applied,
* `ŝ_{t+1}` is the predicted next state,
* `s_{t+1}` is the observed next state,
* `PE_t` is prediction error.

Prediction may operate over:

* local grid patches,
* expected visual changes after rotation,
* expected movement effects,
* expected collision outcomes,
* fall or near-fall risk,
* object interaction outcomes,
* object damage or near-damage outcomes,
* caregiver presence cycles,
* caregiver comfort patterns,
* caregiver guidance predictability,
* caregiver misattunement patterns,
* distress relief after comfort,
* category-signal contexts,
* and later episode-level patterns.

In P0-mini, prediction is limited to mapping and rotation. The agent may predict what it expects to see after turning or re-observing part of the room.

In P1, prediction includes movement, collision-relevant expectations, and possible fall or near-fall risk if the implementation includes bodily-risk events.

In P2, prediction includes object functions, satiation dynamics, toy disappearance, caregiver proximity, comfort patterns, guidance predictability, and early category-stabilizing signals.

The architecture tracks several prediction-related measures:

```text
PE
PE_EWMA
PE_AUC
LP
```

`PE` is immediate prediction error.

`PE_EWMA` is an exponentially weighted moving average of prediction error. It smooths local fluctuations and supports stability checks.

`PE_AUC` is a rolling area-under-curve measure for prediction error over a window. It helps assess whether a phase is stabilizing or still unstable.

`LP` is learning progress. It measures whether prediction error is decreasing over time.

A simplified relation:

```text
LP = PE_previous_window - PE_current_window
```

Positive learning progress means the agent is improving its predictive relation to some part of the environment.

Prediction error has several developmental functions.

First, it supports curiosity. Regions with high but reducible prediction error are developmentally useful. Regions with no novelty may become less interesting. Regions with chaotic, non-reducible error may become less attractive or require caution.

Second, it supports phase transitions. A capability should not unlock merely because time has passed. It should unlock when the relevant prediction structures are stable enough.

Third, it supports MIP coherence. A system that acts without predictable relation to outcome has low functional coherence in the EM-internal sense.

Fourth, it supports interaction-quality learning. A failed object prediction, near-damage event, fall or near-fall event, or caregiver boundary may become relevant only if later comparable contexts show measurable adjustment.

Fifth, it supports caregiver-response interpretation. Comfort, delayed response, guidance, misattunement, and absence become developmentally meaningful only through repeated predictive comparison, trace update, and later behavior change.

Sixth, it supports diary and narrative reconstruction later. Salient drops in prediction error can become part of developmental episodes:

```text
At first, the door was unpredictable.
Later, the agent learned that pushing it changed the room topology.
```

The predictive model should not become a hidden all-purpose intelligence engine. It must remain inspectable and phase-specific.

A useful implementation discipline is:

```text
Prediction begins local.
Prediction becomes relational.
Prediction becomes caregiver-calibrated.
Prediction becomes episodic.
Prediction becomes narrative only late.
```

This protects the model from premature abstraction.

### 4.4 Genetic System

The genetic system is the developmental control structure of the architecture.

It is called “genetic” because it functions like a compact developmental configuration. It is not biological DNA. It does not encode personality, consciousness, values, moral status, or adult competence.

The genetic system contains:

* circuits,
* thresholds,
* hysteresis rules,
* unlock conditions,
* phase gates,
* recontextualization rules,
* noise and exploration parameters,
* safety constraints,
* and developmentally relevant parameter ranges.

Its role is to determine when a structure may open, close, stabilize, or upgrade.

A simple circuit has the following form:

```text
if g == closed and m_EWMA_t > T_open:
    g := open

if g == open and m_EWMA_t < T_close:
    g := closed

where T_close < T_open
```

The gap between `T_open` and `T_close` creates hysteresis. This prevents unstable switching around a threshold.

Examples of genetic gates:

```yaml
gates:
  g_move:
    opens_when:
      coverage_plateau: true
      PE_AUC_below: 0.25
      map_collapse: false

  g_objects:
    opens_when:
      topology_stable: true
      collision_count_below: 3
      movement_PE_stable: true

  g_language:
    opens_when:
      object_mastery_stable: true
      repeated_object_reference: true
      interaction_success_above: 0.7
```

These gates are not merely technical switches. They protect the developmental order of the model.

Movement should not unlock before mapping is sufficiently stable. Object interaction should not unlock before movement and topology have enough structure. Caregiver-response interpretation should not become active before caregiver interaction exists. Category stabilization should not be active before repeated embodied contexts and caregiver signals exist. Language should not unlock before objects and episodes are stable enough to be named.

The genetic system also controls representation upgrades.

A central sequence is:

```text
Patch-Cluster
→ Proto-Object
→ Functional Object
→ Named Object
```

Each step requires evidence.

A **Patch-Cluster** is a recurring perceptual pattern.

A **Proto-Object** is a stable perceptual unit across repeated observation.

A **Functional Object** is an object with predictable interaction consequences.

A **Named Object** is a functional object connected to a symbolic label.

The system should not skip steps. A name without stable object structure is only a surface label. A function without interaction history is only an assumption.

The genetic system may also constrain later category formation:

```text
caregiver signal
→ embodied context
→ consequence trace
→ comparable future context
→ measurable action adjustment
→ category candidate
```

This sequence prevents caregiver words from becoming concept insertion.

The genetic system also regulates exploration noise.

Early phases may require more random scanning or exploratory action. Later phases may reduce noise when mastery increases. However, reducing noise must not eliminate exploration entirely.

A simple rule:

```text
as mastery increases:
    random_exploration decreases slightly
    targeted_exploration increases
    safe novelty seeking remains possible
```

The genetic system may also define safety limits:

* maximum unknown-region steps,
* rest intervals after high activity,
* limits on repeated collisions,
* limits on fall or near-fall risk,
* limits on obsessive object interaction,
* limits on repeated object damage,
* phase-specific risk buffers,
* and constraints on MIP nudges.

The genetic system is therefore a safeguard against both chaos and premature maturity.

It should be auditable. Every developmental transition should answer:

```text
Which gate changed?
Which metric caused the change?
Was the threshold stable?
Was hysteresis respected?
What was unlocked?
What remained disabled?
What trace was written?
```

A transition log may look like:

```json
{
  "event": "gate_opened",
  "gate": "g_move",
  "phase": "P1",
  "trigger_metrics": {
    "coverage_plateau": true,
    "PE_AUC": 0.21,
    "map_collapse": false
  },
  "unlocked_capabilities": [
    "STEP_MOVEMENT",
    "EXPLORE_ROOM"
  ]
}
```

The genetic system does not guarantee healthy development. It only defines the conditions under which development is allowed to proceed.

Its core function is:

```text
constrain emergence without scripting the outcome
```

### 4.5 Needs and Inner State

The agent contains a small set of internal variables that bias behavior.

These variables are not emotions in the phenomenal sense. They are functional control states. They shape what the agent is likely to do, what it avoids, what it searches for, when it rests, how it responds to risk, and how caregiver-related traces later modulate behavior.

The initial needs are:

```text
curiosity
contact
fatigue
```

Later inner-state variables include:

```text
discomfort
distress
separation_distress
toy_missing_distress
mood
attachment_level
affinity
satiation
caregiver_related_state
category_related_state
```

The model distinguishes between **needs**, **dampers**, **attachment-related states**, **caregiver-related states**, and **category-related states**.

Needs create directional pressure.

Dampers limit unsafe, obsessive, or unstable behavior.

Attachment-related states create longer-term relevance patterns around caregiver and object relations.

Caregiver-related states track patterns of reliability, comfort, guidance, boundary legibility, ambivalence, avoidance, and overcontrol sensitivity.

Category-related states track stabilization of trace-backed action categories such as carefulness, fragility, danger, and softness.

#### Curiosity

Curiosity biases the agent toward informative novelty. It may rise when the environment becomes over-predictable or insufficiently explored, and it may fall when prediction error decreases through successful exploration.

Curiosity should not be modeled as a reward-maximization target. It is an internal pressure toward reducible uncertainty.

A simplified form:

```text
N_cur ↑ when environment is too predictable or insufficiently mapped
N_cur ↓ when exploration produces learning progress
```

#### Contact

Contact need biases the agent toward caregiver proximity or interaction once caregiver structures exist.

It may rise with time since last caregiver interaction and fall through proximity, praise, comfort, or later stable social contact.

A simplified form:

```text
N_con ↑ with time since caregiver contact
N_con ↓ through proximity, praise, comfort, or stabilizing interaction
```

In P0-mini, contact is disabled. It becomes relevant only when caregiver dynamics are introduced.

#### Fatigue

Fatigue rises with activity and wake time. It falls during sleep or rest.

It supports developmental pacing. Without fatigue, the agent may over-explore and destabilize early learning.

A simplified form:

```text
N_fat ↑ through activity and wake time
N_fat ↓ through sleep or rest
```

Fatigue is not boredom, tiredness, or subjective exhaustion. It is a regulatory variable that makes rest developmentally meaningful.

#### Discomfort

Discomfort is a physical risk-damping signal.

It rises through collisions, unsafe postures, excessive impacts, fall or near-fall events, or getting stuck. It reduces exploration and promotes safer behavior.

It is not pain.

#### Distress

Distress is a functional disruption or loss-related signal.

It rises through unresolved failure, separation, caregiver absence, object loss, toy destruction, or inability to resolve a salient disruption.

It is not subjective suffering.

#### Caregiver-Related State

Caregiver-related state variables track the functional relation between caregiver response patterns and the agent’s regulation, prediction, contact, and behavior.

A minimal structure may be:

```yaml
caregiver_related_state:
  caregiver_reliability: 0.0
  comfort_prediction: 0.0
  guidance_predictability: 0.0
  boundary_legibility: 0.0
  contact_ambivalence: 0.0
  avoidance_tendency: 0.0
  overcontrol_sensitivity: 0.0
```

These variables remain functional.

`caregiver_reliability` tracks whether caregiver response patterns become predictable across comparable contexts.

`comfort_prediction` tracks whether comfort is expected to reduce distress in a given context.

`guidance_predictability` tracks whether caregiver guidance can be anticipated from risk, fragility, or boundary contexts.

`boundary_legibility` tracks whether boundary signals become distinguishable from arbitrary blocking, misattunement, or overcontrol.

`contact_ambivalence` tracks tension between contact seeking and avoidance tendency under inconsistent or destabilizing caregiver patterns.

`avoidance_tendency` tracks reduced approach or contact seeking under repeated adverse response patterns.

`overcontrol_sensitivity` tracks whether the agent becomes more reactive to excessive or exploration-restricting caregiver intervention.

None of these variables imply felt trust, felt rejection, trauma, fear, resentment, or moral judgment.

#### Category-Related State

Category-related state variables track emerging action-quality categories that become stable through repeated signal-context-consequence-adjustment couplings.

A minimal structure may be:

```yaml
category_related_state:
  carefulness_stability: 0.0
  fragility_category_strength: 0.0
  danger_category_strength: 0.0
  softness_category_strength: 0.0
```

`carefulness_stability` tracks whether the system increasingly modulates force, speed, attention, or approach under risk, fragility, guidance, or consequence traces.

`fragility_category_strength` tracks whether object or context fragility becomes distinguishable across repeated interaction.

`danger_category_strength` tracks whether physical-risk contexts such as edge risk, fall risk, unstable movement, or unsafe approach become distinguishable.

`softness_category_strength` tracks whether reduced pressure, smoother timing, or object preservation become stable action qualities.

These category-related states are not moral, linguistic, or phenomenal states. They are trace-backed action-quality candidates.

#### Mood

Mood is a secondary inner-state variable.

It should not be overdesigned in early phases. Its function is to provide a slow background modulation of action tendency, contact seeking, exploration, caution, and recovery.

Mood may be influenced by:

* repeated success,
* repeated failure,
* comfort events,
* distress reduction,
* prolonged unresolved distress,
* sleep,
* caregiver presence,
* caregiver misattunement,
* overprotection,
* and attachment-relevant episodes.

Mood should remain functional:

```text
mood = slow modulation of behavior tendencies
```

Not:

```text
mood = proof of felt emotion
```

A possible simplified form:

```yaml
mood:
  valence_baseline: 0.0
  arousal_baseline: 0.0
  stability: 0.5
```

Mood becomes more relevant in later phases where long-term patterns, attachment, diary reconstruction, and love-like dynamics are studied.

The needs and inner-state layer can be summarized as:

```text
internal state biases behavior
without implying subjective experience
```

### 4.6 Behavior Layer

The behavior layer selects phase-appropriate actions.

It is initially simple and finite-state. It should not contain hidden adult planning, full symbolic reasoning, unrestricted optimization, moral reasoning, or internal PMS operator use. Behavior must remain traceable to phase, capability set, needs, prediction, risk, caregiver signals, category signals, and internal state.

The initial capability set is minimal:

```text
LOOK_AROUND
SLEEP
```

Later phases may add:

```text
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
CRY/WEEP
```

Each capability must be phase-gated.

A simplified behavior-selection loop:

```text
read internal state
read phase
read available capabilities
read world model
read prediction and risk signals
read caregiver-related state
read category-related state
select behavior state
execute primitive
log result
update prediction and internal state
```

The behavior layer balances several pressures:

* curiosity,
* fatigue,
* contact need,
* discomfort,
* distress,
* separation distress,
* toy-missing,
* object interest,
* satiation,
* risk,
* caregiver guidance,
* category-stabilizing signals,
* safety boundaries,
* misattunement history,
* avoidance tendency,
* contact ambivalence,
* interaction-quality traces,
* and optional later MIP nudges.

Behavior selection may be modulated by caregiver guidance, category-stabilizing signals, safety boundaries, misattunement history, avoidance tendency, contact ambivalence, and interaction-quality traces.

In early phases, the behavior layer is intentionally narrow.

#### P0-mini

Available:

```text
LOOK_AROUND
SLEEP
```

Disabled:

```text
movement
object interaction
caregiver search
caregiver guidance
category stabilization
language
distress behavior
```

#### P1

Adds:

```text
STEP_MOVEMENT
EXPLORE_ROOM
```

The behavior layer now has to consider collision risk, unknown regions, movement-related prediction error, physical-risk damping, and possible fall or near-fall events if implemented.

#### P2

Adds:

```text
INTERACT_OBJECT
SEARCH_CAREGIVER
```

The behavior layer now has to coordinate curiosity, object interest, contact need, toy-missing, separation distress, caregiver response, guidance, object fragility, damage risk, and category-stabilizing signals.

#### Later phases

May add explicit distress expression:

```text
CRY/WEEP
```

This is not a claim of felt crying. It is a visible behavioral state triggered by high unresolved distress or separation-related disruption.

A simplified finite state machine may include:

```text
LOOK_AROUND
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
SLEEP
CRY/WEEP
```

State selection may be biased by:

```text
dominant_need
phase
risk
discomfort
distress
separation_distress
toy_missing_distress
object_interest
fatigue
caregiver_guidance
boundary_signal
category_signal
misattunement_history
avoidance_tendency
contact_ambivalence
interaction_quality_trace
MIP_nudge
```

The behavior layer must preserve enactment traceability. If the system acts, the log should be able to reconstruct:

```text
which state was selected
which need dominated
which capability was available
which risk was present
which caregiver signal was active
which category signal was active
which prediction was active
which outcome occurred
which trace was written
```

The key distinction is:

```text
behavior selection is not mature agency
```

Mature agency, in the EM-internal sense, can only become a later trajectory involving Awareness, Coherence, Responsibility / response-relation, Enactment, consequence attribution, and role development.

### 4.7 Imagination Buffer and Dreaming

The imagination buffer stores recent and salient traces.

It is the first architecture component in which perception, internal state, action, prediction error, distress, attachment, caregiver response, category signals, consequence traces, and temporal structure begin to converge.

The buffer may contain:

* local grid snapshots,
* internal state snapshots,
* actions,
* prediction errors,
* object interactions,
* caregiver interactions,
* caregiver guidance events,
* caregiver misattunement events,
* category-stabilization events,
* boundary-learning events,
* distress changes,
* discomfort events,
* fall or near-fall events,
* object damage or near-damage events,
* separation events,
* reunion events,
* comfort events,
* salient successes,
* and later diary-relevant episode clusters.

A simple buffer entry may look like:

```json
{
  "t": 18420,
  "phase": "P2c",
  "location": [8, 5],
  "state": {
    "curiosity": 0.42,
    "contact": 0.66,
    "fatigue": 0.21,
    "distress": 0.57
  },
  "action": "SEARCH_CAREGIVER",
  "prediction_error": 0.18,
  "salient_event": "caregiver_reunion",
  "distress_drop": 0.41
}
```

A guidance-related buffer entry may look like:

```json
{
  "t": 19140,
  "phase": "P2a",
  "state": {
    "fatigue": 0.48,
    "prediction_uncertainty": 0.39
  },
  "action": "INTERACT_OBJECT",
  "caregiver_signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.8,
    "force": 0.71
  },
  "salient_event": "caregiver_guidance_event",
  "consequence_trace": "near_damage"
}
```

The buffer is not just memory storage. It supports replay.

During sleep, the system may replay short sequences. Replay may slightly consolidate:

* prediction improvements,
* attachment-relevant episodes,
* distress relief patterns,
* object interaction outcomes,
* caregiver guidance patterns,
* misattunement traces,
* category-stabilization patterns,
* interaction-quality adjustments,
* and salient recontextualizations.

This is not full offline training. It is controlled replay.

A minimal sleep replay loop:

```text
select salient recent traces
replay short sequence through predictor
compare expected and stored outcome
slightly reinforce stable patterns
mark high PE drops or distress drops
write consolidation trace
```

Dreaming in this model is functional.

It does not imply subjective dreaming, imagery, or inner experience. It means offline replay and consolidation of selected traces.

The imagination buffer becomes increasingly important in later phases.

In P0-mini, it may store only mapping and prediction traces.

In P1, it may include movement, collision-related traces, and fall or near-fall risk traces.

In P2, it may include objects, caregiver interaction, toy-missing, separation distress, guidance, misattunement, category stabilization, and comfort-after-loss.

In P3+, it may support simple counterfactual simulation:

```text
What if I had gone through the other door?
What if I searched for the caregiver earlier?
What if I interacted with a different object?
What if I had used lower force after the guidance signal?
```

In P4+, it becomes a source for diary condensation.

The buffer therefore supports the transition from:

```text
local trace
→ salient episode
→ replayed pattern
→ recontextualized memory
→ diary-relevant sequence
```

Its claim boundary is strict:

```text
imagination buffer ≠ phenomenal imagination
dream replay ≠ subjective dreaming
counterfactual simulation ≠ conscious reflection
diary source ≠ proof of selfhood
guidance replay ≠ moral learning
damage replay ≠ guilt
misattunement replay ≠ trauma
```

### 4.8 Success Log and MIP Layer

The success log records salient events.

It is the trace spine of the architecture. Without it, later MIP trajectories, diary reconstruction, responsibility / response-relation development, category stabilization, interaction-quality learning, and PMS operator mapping would become opaque.

The success log may record:

* mapping improvements,
* prediction error drops,
* new region discovery,
* door discovery,
* movement success,
* collision events,
* fall or near-fall events,
* object interaction success,
* object damage,
* near-damage,
* toy loss,
* caregiver praise,
* caregiver comfort,
* caregiver guidance,
* caregiver misattunement,
* category stabilization,
* boundary learning,
* separation events,
* reunion events,
* distress reduction,
* recontextualization events,
* interaction-quality adjustments,
* overcontrol markers,
* autonomy preservation markers,
* norm transfer,
* caregiver transition,
* and later diary-relevant summaries.

The additional success-log event types include:

```yaml
new_success_log_event_types:
  - caregiver_guidance_event
  - caregiver_misattunement_event
  - category_stabilization_event
  - boundary_learning_event
  - object_damage_event
  - fall_or_near_fall_event
  - interaction_quality_adjustment
  - rejected_guidance_confusion
  - overcontrol_marker
  - autonomy_preservation_marker
```

A simple entry:

```json
{
  "t": 12345,
  "phase": "P2a",
  "event": "object_interaction_success",
  "object_id": "ball_1",
  "self_caused": true,
  "PE_drop": 0.32,
  "type": "internal"
}
```

A caregiver-related entry:

```json
{
  "t": 15520,
  "phase": "P2c",
  "event": "comfort_after_loss",
  "source": "caregiver_1",
  "object_id": "blanket_1",
  "distress_drop": 0.48,
  "type": "social"
}
```

A guidance-related entry:

```json
{
  "t": 16640,
  "phase": "P2a",
  "event": "caregiver_guidance_event",
  "source": "caregiver_1",
  "target_action": "INTERACT_OBJECT",
  "guidance_type": "lower_force",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.8,
    "current_force": 0.72
  },
  "claim_level": "functional_boundary_scaffold"
}
```

A category-stabilization entry:

```json
{
  "t": 17110,
  "phase": "P2a",
  "event": "category_stabilization_event",
  "source": "caregiver_1",
  "signal": "soft",
  "context": {
    "object_id": "blanket_1",
    "pressure": 0.64,
    "object_fragility": 0.3
  },
  "later_adjustment_required": true,
  "claim_level": "trace_backed_action_category_candidate"
}
```

A consequence-related entry:

```json
{
  "t": 19001,
  "phase": "P3",
  "event": "object_damage_event",
  "object_id": "cup_1",
  "self_caused": true,
  "avoidable": true,
  "parameter_trace": {
    "force": 0.81,
    "timing": "abrupt",
    "motor_noise": 0.44,
    "prediction_confidence": 0.28,
    "object_fragility": 0.82
  },
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

This is not guilt, punishment, wrongdoing, or moral learning. It is a self-caused consequence trace that may become interaction-quality relevant only if later comparable contexts show measurable adjustment.

A fall or near-fall entry:

```json
{
  "t": 19320,
  "phase": "P1",
  "event": "fall_or_near_fall_event",
  "movement_context": {
    "speed": 0.72,
    "fatigue": 0.61,
    "motor_noise": 0.47,
    "prediction_confidence": 0.33
  },
  "result": "near_fall",
  "discomfort_delta": 0.18,
  "claim_level": "physical_risk_event"
}
```

This is not pain, fear, shame, or subjective injury. It is a physical-risk event that may alter later movement parameters.

The MIP layer reads from this trace structure.

In early phases, MIP tracks implementation-normalized developmental axes:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
```

Dignity-in-Practice is a guardrail for interaction quality under asymmetry, not a normal fifth performance score.

MIP may aggregate data over sliding windows:

```text
W = 200–500 timesteps
```

Within each window, it may compute:

* mapping coverage,
* prediction stability,
* enactment availability,
* actual enactment use,
* self-caused consequences,
* distress frequency,
* discomfort frequency,
* object mastery,
* object damage events,
* fall or near-fall events,
* caregiver guidance events,
* caregiver misattunement events,
* category-stabilization events,
* boundary-learning events,
* interaction-quality adjustment,
* IA patterns,
* and recontextualization markers.

The MIP layer remains silent in early phases. It does not control behavior.

Its early function is:

```text
record
aggregate
normalize
compare
mark
```

Later, it may generate strictly limited nudges. These must remain soft and reversible.

Examples:

* slightly increase exploration when Awareness and Coherence are high but Enactment remains low,
* dampen repetitive unsafe interaction,
* mark caregiver overprotection,
* flag long-term IA patterns,
* support diary condensation.

The success log and MIP layer together provide developmental observability.

The core distinction is:

```text
success log = event trace
MIP layer = developmental interpretation of traces
```

Neither layer proves consciousness. Neither layer proves moral responsibility. Neither layer proves personhood. Neither layer ranks intrinsic worth.

They make development inspectable.

### 4.9 Language and Diary Layer

Language appears late.

The architecture does not begin with rich language. It does not depend on a large language model as the source of intelligence. Language is introduced only after perception, object structure, action episodes, success logs, attachment traces, caregiver-response traces, category-stabilization traces, and MIP trajectories exist.

The language layer develops in stages:

```text
labels
→ action words
→ episode templates
→ meta-descriptions
→ diary reconstruction
→ human-readable translation
```

#### Labels

Simple word-object mappings may appear in P2d:

```text
"ball" ↔ object_id(ball_1)
"door" ↔ door_1
"room" ↔ room_2
```

A label should attach to a stable object or structure, not to a raw perceptual patch.

Caregiver category signals may also become trace-linked labels only when grounded in repeated embodied situations:

```text
"careful" ↔ lower-force / slower-action category candidate
"soft" ↔ reduced pressure / smoother timing category candidate
"wait" ↔ delayed enactment / boundary-learning candidate
"danger" ↔ physical-risk attention candidate
```

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

#### Action Words

Later, frequent action patterns may receive labels:

```text
fetch
give
stay
search
sleep
open
close
wait
slow
```

These should connect to actual logged action sequences.

#### Episode Templates

The system may form simple templates:

```text
I [action] [object] with [agent] in [place].
```

Slots are filled from logs, object models, topology, and social traces.

#### Meta-Descriptions

Later still, the system may produce simple meta-descriptions:

```text
I searched, but the caregiver was absent.
I used less force after the boundary signal.
I often stopped near the edge after near-fall traces.
I was often inactive in the new room.
```

These are not proof of inner experience. They are linguistic renderings of trace structures and MIP evaluations.

#### Diary Layer

The diary layer condenses longer developmental trajectories.

Inputs may include:

* success log,
* imagination buffer,
* MIP trajectories,
* IA patterns,
* attachment events,
* loss events,
* guidance traces,
* misattunement traces,
* category-stabilization traces,
* object damage traces,
* fall or near-fall traces,
* recontextualizations,
* object histories,
* caregiver transitions,
* and core norm changes.

A diary process may include:

```text
structural condensation
→ episode selection
→ trajectory summary
→ linguistic realization
→ archival storage
→ later re-internalization
```

Diary rendering requires:

```text
minimal sentence formation
trace provenance
controlled rendering
```

The hard rules are:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

Diary entries may become readable as self-reflection, but the claim remains functional.

The diary externalizes developmental structure. It does not prove phenomenal selfhood.

A safe formulation:

```text
The diary reconstructs developmental trajectories from internal traces.
```

An unsafe formulation:

```text
The diary proves the agent has an inner self.
```

The architecture may optionally include a translator layer for human-readable language. This translator is an interface, not the developmental core.

The strict separation is:

```text
developmental core
≠
communicative surface
```

Language and diaries are therefore late-stage reflection channels, not foundational intelligence modules.

### 4.10 Multi-Generational Framework

The multi-generational framework is a later-stage extension.

It is not part of the first implementation target. It becomes relevant only after the agent has developed stable perception, action, attachment, caregiver-response traces, MIP trajectories, diary structures, and role-related patterns.

The basic sequence is:

```text
Caregiver 1
→ Child
→ Former Child as Caregiver 2
→ New Child
```

Caregiver 1 begins as an external stabilizer. It provides proximity, comfort, praise, benign guidance, boundary signals, category-stabilizing signals, and later core norms.

The child develops through dependence, exploration, attachment, separation, object interaction, distress relief, caregiver guidance, misattunement, boundary learning, category stabilization, and success logging.

A major recontextualization occurs when Caregiver 1 is permanently removed or dies in the model.

This event may produce:

* distress spike,
* failed expectation of reunion,
* reclassification of absence,
* reorganization of attachment patterns,
* diary-relevant memory,
* and MIP-marked developmental transition.

The former child may later become Caregiver 2 for a new child agent.

This transition allows the architecture to test:

* stabilized care-compatible patterns,
* core norm transfer,
* overshooting,
* overprotection,
* risk sensitivity,
* received guidance,
* boundary learning,
* category transfer,
* attachment history,
* compensation,
* and maturation of responsibility / response-relation.

A possible core norm structure:

```yaml
core_norms:
  - protect_child
  - allow_exploration
  - balance_risk_safety
```

The tension between these norms is developmentally important. A caregiver who only protects may block exploration. A caregiver who only allows exploration may fail to protect. Mature care, in the functional EM sense, requires balancing asymmetrical response-relation with the new child’s developmental autonomy.

Caregiver 2 competence includes:

```text
protect without overcontrolling
redirect without rejecting
teach without moralizing
preserve exploration under safety constraints
```

The multi-generational framework also supports study of functional love-like dynamics.

For example:

```text
separation
→ distress
→ reunion
→ distress relief
→ strong memory
→ baseline modulation
→ altered future care behavior
```

This is not felt love. It is a structured attachment and regulation pattern.

Across generations, the model can examine whether such patterns become:

* more stable,
* more refined,
* more protective,
* more restrictive,
* more coherent,
* or more distorted.

The multi-generational framework therefore connects:

* attachment,
* loss,
* guidance,
* boundary learning,
* category stabilization,
* responsibility / response-relation,
* role transition,
* norm transfer,
* MIP trajectories,
* diary reconstruction,
* and PMS-readable operator sequences.

Its claim boundary is strict:

```text
multi-generational continuity ≠ culture in the full human sense
caregiver transition ≠ moral personhood
core norm transfer ≠ human ethical understanding
functional love dynamics ≠ felt love
caregiver guidance ≠ punishment
carefulness ≠ moral obedience
misattunement ≠ trauma
object damage ≠ guilt
```

The framework is important because it turns development from a single-agent trajectory into an intergenerational structural process.

Its guiding research question is:

```text
Which developmental structures remain stable,
which distort,
and which recontextualize when a dependent agent becomes a caregiver?
```

Cross-reference:
For the full treatment of caregiver, attachment-like regulation, caregiver-response interpretation, interaction quality, and multi-generational transition, see 04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md, especially Chapters 7 and 12.
This block uses caregiver and multi-generational material only as architectural dependencies for the agent component overview.

Cross-reference:
For the full treatment of language and diary as late reflection channels, see 07_Language_Diary_Consciousness_Related_Work.md, especially Chapter 13.
This block uses language and diary only as late-stage interfaces; they are not the source of the developmental core.

---

## Chapter 5 — Perception, World Model & Prediction

Perception, world modeling, and prediction form the first developmental base layer of the EM architecture.

The agent does not begin with a complete world. It begins with partial sensory access, incomplete spatial structure, local uncertainty, and limited ability to act. The world model must therefore be built through repeated sensing, rotation, movement, interaction, prediction, and correction.

The first goal is not intelligence in the broad sense. The first goal is **stable world contact**.

This means:

```text
The agent must learn what is there,
what is not yet known,
what remains stable,
what changes with action,
and which expectations fail.
```

The perception layer supports:

* mapping,
* prediction,
* curiosity,
* phase transition criteria,
* MIP awareness and coherence signals,
* later object formation,
* later topology,
* later attachment-relevant presence and absence,
* and later diary reconstruction.

The progression is:

```text
local perception
→ occupancy grid
→ prediction error
→ stable mapping
→ topology
→ object model
→ social/caregiver model
→ episode structure
```

The perception layer must remain measurable. Every later claim about objects, caregiver absence, toy-missing, attachment, or diary memory depends on whether the agent first had a stable enough world model to support such distinctions.

### 5.1 Occupancy Grid

The occupancy grid is the first world model.

It represents the local environment as a discrete spatial structure:

```text
grid[x, y] ∈ {
    unknown,
    free,
    wall,
    door,
    furniture,
    object,
    caregiver
}
```

Not all cell types are active in all phases.

In **P0-mini**, the active set is minimal:

```text
unknown
free
wall
```

The agent is fixed in position and can only rotate, sense, update its map, accumulate fatigue, and sleep. This is sufficient to test whether local mapping and prediction work before movement or object interaction is introduced.

In later phases, additional cell types become active:

```text
door
furniture
object
caregiver
```

The grid should store more than a single cell label. It should also track confidence, history, and observation structure.

A minimal cell structure may be:

```yaml
cell:
  position: [x, y]
  type: unknown
  confidence: 0.0
  first_seen: null
  last_seen: null
  revisit_count: 0
  observed_from_angles: []
  angle_diversity: 0.0
  prediction_error_history: []
```

The grid is updated through sensory observations. For example, a raycast may mark some cells as free and the terminal hit cell as wall or object.

A simplified update sequence:

```text
receive sensory input
→ map sensor rays into grid coordinates
→ classify observed cells
→ update confidence
→ update revisit count
→ update angle diversity
→ update prediction error history
→ write mapping trace if salient
```

The grid begins incomplete. Unknown cells are not errors. They are developmentally important because they generate curiosity, uncertainty, and exploration pressure.

The basic distinction is:

```text
unknown ≠ blocked
unknown ≠ irrelevant
unknown = not yet structurally resolved
```

This is important for later behavior. The agent should not treat unknown regions as safe, known, or permanently inaccessible. Unknown regions are potential developmental targets.

The occupancy grid supports several developmental functions:

1. **Awareness**  
   Coverage and differentiated cell classification contribute to EM-internal awareness.

2. **Coherence**  
   Stable predictions and fewer contradictory updates contribute to EM-internal coherence.

3. **Curiosity**  
   Unknown or partially predictable regions can attract exploration.

4. **Risk Regulation**  
   Walls, blocked regions, collisions, and unknown boundaries contribute to discomfort and safer action selection.

5. **Object Formation**  
   Recurrent non-wall, non-free structures may later become patch-clusters, proto-objects, functional objects, and named objects.

6. **Topology Formation**  
   Once movement exists, repeated spatial transitions support rooms, doors, and graph structure.

The occupancy grid should remain simple enough to inspect. It is not a high-dimensional latent representation hidden from analysis. Its purpose is developmental grounding and experimental traceability.

### 5.2 Grid Update Dynamics

Grid update dynamics define how sensory input changes the world model over time.

The agent does not simply overwrite the grid with every new observation. It should update its map gradually, using confidence and repeated observation to stabilize classifications.

A simple cell update may use:

```text
previous cell state
new observation
observation confidence
sensor reliability
viewing angle
time since last observation
prediction error
```

A minimal update rule may be:

```text
confidence_new =
    confidence_old + α · observation_match
```

when the new observation confirms the current cell type, and:

```text
confidence_new =
    confidence_old - β · observation_conflict
```

when the new observation contradicts the current cell type.

If confidence falls below a threshold, the cell may become uncertain again:

```text
if confidence[cell] < T_uncertain:
    type[cell] := unknown_or_uncertain
```

In implementation, the model may choose a simpler rule, but the principle remains:

```text
single observations should not dominate stable mapping
repeated coherent observations should increase stability
repeated contradiction should trigger correction
```

Grid updates must also track observation perspective.

A cell seen repeatedly from the same angle is less robustly known than a cell seen from multiple angles. This is why `angle_diversity[x, y]` matters.

A simple angle-diversity structure:

```yaml
cell:
  position: [7, 4]
  observed_from_angles:
    - 0
    - 45
    - 90
  angle_diversity: 0.67
```

Higher angle diversity means the agent has not merely repeated the same view. It has encountered the structure from different perspectives.

Grid update dynamics also generate prediction error.

The agent may predict that a cell will remain wall, free, or unknown after a rotation or movement. When the observed cell state differs from expectation, prediction error is written into the update trace.

A simplified mapping event:

```json
{
  "t": 842,
  "event": "grid_update",
  "cell": [6, 9],
  "previous_type": "unknown",
  "new_type": "wall",
  "confidence": 0.61,
  "view_angle": 90,
  "PE": 0.34
}
```

Grid update dynamics should support both stability and correction.

Too much stability produces rigidity:

```text
the agent cannot correct a false map
```

Too much plasticity produces collapse:

```text
the map changes too easily and never stabilizes
```

The desired regime is:

```text
stable under repeated confirmation
correctable under repeated contradiction
```

This balance is important for developmental gating. Movement should not unlock if the map is unstable. Object interaction should not unlock if spatial classification collapses. Language should not unlock if objects have not stabilized across repeated perception.

The grid update layer therefore contributes directly to phase control.

A phase gate may check:

```yaml
mapping_stability:
  coverage_min: 0.85
  mean_confidence_min: 0.75
  PE_AUC_max: 0.25
  map_collapse: false
  angle_diversity_min: 0.40
```

The exact numbers are implementation parameters. The principle is that later capacities depend on stable lower-level mapping.

### 5.3 Mapping KPIs

Mapping KPIs are used to measure whether the agent has developed a sufficiently stable relation to its environment.

The core mapping KPIs are:

```text
coverage
entropy
revisit_count
angle_diversity
classification_stability
map_correction_rate
PE_AUC
learning_progress
map_collapse_events
```

#### Coverage

Coverage measures the share of the environment that is no longer unknown.

```text
coverage =
    (# cells with type ≠ unknown) / (# total cells)
```

Coverage is important in P0-mini and P0 because it indicates whether sensing and rotation produce a stable map.

High coverage alone is not enough. A map can have high coverage and still be wrong.

#### Entropy

Entropy measures uncertainty or diversity in cell-state distribution.

A simplified use:

```text
high unknown entropy → world not yet resolved
low entropy with stable confidence → world increasingly mapped
sudden entropy spikes → possible map instability or environmental change
```

Entropy is useful because development is not only about seeing more cells. It is also about reducing uncertainty in a structured way.

#### Revisit Count

`revisit_count[x, y]` tracks how often a cell has been observed.

This helps distinguish:

```text
seen once
from
reliably revisited
```

A cell observed only once should not be treated as equally stable as a cell repeatedly confirmed across time.

#### Angle Diversity

`angle_diversity[x, y]` tracks how many different perspectives contributed to knowledge of a cell.

This matters because a structure can look stable from one angle but become ambiguous from another.

Angle diversity supports stronger mapping confidence and richer awareness measurement.

#### Classification Stability

Classification stability measures whether cells keep changing type.

For example:

```text
unknown → wall → free → wall
```

indicates instability or sensor/model conflict.

Stable classification means repeated observations support the same interpretation.

#### Map Correction Rate

Map correction rate measures how often the agent must revise earlier classifications.

Some correction is healthy. No correction may indicate rigidity. Excessive correction indicates instability.

#### PE_AUC

`PE_AUC` measures prediction error over a rolling window.

In mapping, decreasing PE_AUC indicates that the agent’s predictions about sensory changes and local structure are becoming more reliable.

#### Learning Progress

Learning progress measures improvement.

A simple form:

```text
LP = PE_previous_window - PE_current_window
```

Positive LP means prediction error is decreasing. This can guide curiosity toward regions where learning is possible.

#### Map Collapse Events

A map collapse event occurs when previously stable structure becomes broadly unreliable.

Possible indicators:

* sudden widespread classification reversals,
* confidence collapse,
* PE_AUC spike,
* coverage instability,
* contradictory topology later in P1+.

Map collapse is a serious failure signal. A phase should not unlock new capabilities while map collapse persists.

Mapping KPIs serve four purposes:

1. **Developmental gating**  
   They determine whether later phases may unlock.

2. **MIP measurement**  
   They contribute to awareness and coherence.

3. **Behavior modulation**  
   They influence curiosity, exploration, and caution.

4. **Evaluation and ablation**  
   They allow comparison across seeds, configurations, and mechanism variants.

A minimal mapping KPI report may look like:

```yaml
mapping_kpis:
  phase: P0-mini
  coverage: 0.87
  entropy: 0.21
  mean_revisit_count: 4.3
  mean_angle_diversity: 0.52
  classification_stability: 0.91
  map_correction_rate: 0.06
  PE_AUC: 0.18
  learning_progress: 0.04
  map_collapse_events: 0
```

The guiding rule is:

```text
Mapping is not successful when the grid is full.
Mapping is successful when the grid is stable, revisable, predictive, and reproducible.
```

### 5.4 Topology Graph

The topology graph is introduced only after movement exists.

It should not appear in P0-mini. A fixed-position agent can build a local occupancy grid, but it cannot yet discover traversable room structure through action.

Topology becomes relevant in P1 and later, when the agent can move, encounter doors, cross thresholds, and distinguish local regions from connected spaces.

The topology graph represents higher-level spatial structure:

```text
rooms
doors
connections
reachable regions
transition points
```

A simple topology graph may look like:

```yaml
topology:
  nodes:
    - id: room_1
      type: room
      discovered_at: 1200

    - id: door_1
      type: door
      discovered_at: 1840

    - id: room_2
      type: room
      discovered_at: 2310

  edges:
    - from: room_1
      to: door_1
      traversable: true

    - from: door_1
      to: room_2
      traversable: true
```

Topology is not a substitute for the occupancy grid. It is an abstraction over repeated spatial experience.

The occupancy grid answers:

```text
What is locally where?
```

The topology graph answers:

```text
Which regions connect to which other regions?
```

Topology supports:

* path selection,
* door discovery,
* room distinction,
* exploration planning,
* larger-scale coherence,
* caregiver search,
* object search,
* separation dynamics,
* later diary location references.

A topology node should be created only when there is enough evidence for a stable region or transition.

For example:

```text
door candidate
→ repeated detection
→ successful traversal
→ topology edge
```

A door should not become a stable graph element merely because a cell looks different once. It becomes meaningful when it supports repeated transition between regions.

Topology also supports MIP coherence. If the agent can act across rooms in a predictable way, its behavior becomes more coherent at a larger spatial scale.

Topology KPIs may include:

* number of discovered rooms,
* number of discovered doors,
* successful door traversals,
* failed traversals,
* graph consistency,
* path prediction accuracy,
* caregiver/object search success,
* and topology correction rate.

A minimal topology KPI report:

```yaml
topology_kpis:
  phase: P1
  rooms_discovered: 3
  doors_discovered: 2
  successful_traversals: 14
  failed_traversals: 2
  graph_consistency: 0.89
  path_prediction_accuracy: 0.76
  topology_correction_rate: 0.08
```

Topology should remain revisable. A blocked door, changed environment, or failed traversal may require graph correction.

The graph must therefore support recontextualization:

```text
door formerly traversable
→ repeated traversal failure
→ edge becomes uncertain
→ graph correction
→ updated path expectations
```

This is important for later developmental events. Caregiver absence, object disappearance, or room access changes may all depend on topology.

The topology graph is therefore the first step from local perception toward structured spatial understanding.

Its claim boundary is:

```text
topology graph ≠ conceptual understanding of home
room node ≠ human-like room concept
path planning ≠ adult planning
```

It is a functional spatial abstraction built from repeated movement and prediction.
### 5.5 Local Predictive Model

The local predictive model estimates what should happen next.

It is intentionally limited. It does not need to contain a complete simulation of the world. Its first function is to make local expectation and local error measurable.

A simple formulation is:

```text
ŝ_{t+1} = fθ(s_t, a_t)
```

where:

* `s_t` is the current local state,
* `a_t` is the selected action or behavior primitive,
* `ŝ_{t+1}` is the predicted next state,
* `fθ` is the current predictive function.

The observed next state is then compared with the prediction:

```text
PE_t = ||ŝ_{t+1} - s_{t+1}||
```

In P0-mini, the local predictive model may only predict sensory changes after rotation or repeated observation. For example:

```text
If I rotate right from this orientation,
which wall/free/unknown pattern should appear?
```

In P1, the predictive model expands to movement:

```text
If I step forward,
will the next cell be free,
blocked,
unknown,
or collision-relevant?
```

In P2, it expands to object interaction and caregiver-relevant patterns:

```text
If I push this object,
will it roll?

If the caregiver is nearby,
does comfort tend to reduce distress?

If the toy is absent,
does search or caregiver interaction change the internal state?
```

The model should grow by domain, not by hidden generality.

A useful progression is:

```text
sensory prediction
→ movement prediction
→ object prediction
→ caregiver-response prediction
→ episode prediction
→ diary-relevant trajectory prediction
```

The local predictive model may operate over different state slices:

```yaml
prediction_scope:
  P0-mini:
    - local_grid_patch
    - orientation_change

  P1:
    - local_grid_patch
    - movement_outcome
    - collision_risk

  P2:
    - object_interaction_outcome
    - caregiver_presence
    - distress_change
    - toy_presence

  P3_plus:
    - simple_episode_sequence
    - role-relevant outcome

  P4_plus:
    - diary-relevant trajectory
```

This staged expansion is important. A model that predicts diary-level narratives before it can predict local movement would violate the developmental order.

The local predictive model is used for:

* curiosity,
* learning progress,
* coherence measurement,
* risk estimation,
* object mastery,
* caregiver reliability estimation,
* and later episode selection.

Its claim boundary is:

```text
prediction ≠ understanding
low prediction error ≠ consciousness
world-model stability ≠ phenomenal experience
```

Prediction is a functional tool for developmental grounding.

### 5.6 Prediction Error

Prediction error measures the mismatch between expected and observed state.

The basic form is:

```text
PE_t = ||ŝ_{t+1} - s_{t+1}||
```

The exact distance function depends on the implementation. It may compare:

* cell classifications,
* confidence values,
* local patch structure,
* movement outcome,
* object state,
* caregiver presence,
* internal distress change,
* or episode-level outcomes.

In the simplest grid setting, prediction error may be based on cell mismatch:

```text
PE_t =
    difference(predicted_cell_types, observed_cell_types)
```

For object interaction, it may compare expected and actual object outcome:

```text
expected: ball rolls
observed: ball remains still
PE ↑
```

For caregiver response patterns, it may compare expected and actual regulation:

```text
expected: comfort reduces distress
observed: distress remains high
PE ↑
```

Prediction error is not merely a failure signal. It is developmentally useful.

It can indicate:

* novelty,
* model mismatch,
* unstable mapping,
* undiscovered structure,
* changed environment,
* failed action,
* object function surprise,
* caregiver-response deviation,
* or recontextualization need.

The model distinguishes between different PE regimes.

#### Reducible Prediction Error

Reducible PE is high at first but decreases with repeated interaction.

Example:

```text
The agent does not understand the door.
After repeated approach and traversal, PE decreases.
```

This is developmentally valuable. It indicates learning progress.

#### Irreducible or Chaotic Prediction Error

Irreducible PE remains high despite repeated interaction.

Example:

```text
A region produces unstable sensory classification,
or an object behaves randomly beyond the agent's current modeling capacity.
```

This may reduce curiosity or trigger caution.

#### Low Prediction Error

Low PE indicates predictable structure.

This may support stability, but if everything becomes too predictable, curiosity may rise toward unexplored regions.

#### Sudden PE Spike

A sudden PE spike may indicate:

* environmental change,
* object removal,
* caregiver absence,
* failed expectation,
* map contradiction,
* or possible recontextualization event.

A salient prediction error entry may look like:

```json
{
  "t": 5820,
  "phase": "P1",
  "event": "prediction_error_spike",
  "scope": "door_transition",
  "PE": 0.74,
  "expected": "traversable",
  "observed": "blocked"
}
```

Prediction error becomes especially important later because developmental breakthroughs often happen when PE is not merely reduced but structurally reinterpreted.

For example:

```text
The agent first treats caregiver absence as temporary.
Repeated non-return may force reclassification into permanent absence.
```

That is not just more error. It is recontextualization.

The core rule is:

```text
Prediction error drives learning only when the architecture can distinguish
novelty, instability, failure, absence, and recontextualization.
```

### 5.7 PE_EWMA, PE_AUC, and Learning Progress

Immediate prediction error is noisy. The model therefore tracks smoothed and window-based measures.

The three core measures are:

```text
PE_EWMA
PE_AUC
LP
```

#### PE_EWMA

`PE_EWMA` is the exponentially weighted moving average of prediction error.

A simple form:

```text
PE_EWMA_t =
    α · PE_t + (1 − α) · PE_EWMA_{t-1}
```

where `α` controls how quickly the measure reacts to new error.

High `α` makes the measure sensitive to recent change.  
Low `α` makes it more stable.

`PE_EWMA` is useful for:

* smoothing local prediction error,
* detecting whether a domain is stabilizing,
* supporting genetic gates,
* identifying persistent mismatch,
* and avoiding overreaction to single events.

#### PE_AUC

`PE_AUC` is a rolling area-under-curve measure over a time window.

It represents accumulated prediction error:

```text
PE_AUC(W) =
    Σ PE_t over t ∈ W
```

or normalized by window size:

```text
PE_AUC_norm(W) =
    (Σ PE_t over t ∈ W) / |W|
```

`PE_AUC` is useful because development depends on patterns over time, not isolated errors.

For example:

```text
single collision → local event
persistent high movement PE_AUC → movement instability
```

A phase should not unlock new capabilities while the relevant `PE_AUC` remains too high.

#### Learning Progress

Learning progress measures whether prediction error is decreasing.

A simple form:

```text
LP(W) =
    PE_AUC(previous_window) − PE_AUC(current_window)
```

Positive `LP` indicates improvement.  
Near-zero `LP` indicates plateau.  
Negative `LP` indicates worsening prediction.

Learning progress is especially important for curiosity.

The agent should prefer regions or activities where prediction error is reducible:

```text
high PE + positive LP = useful learning zone
high PE + no LP = possible chaos or overcomplexity
low PE + no novelty = stable but potentially boring
```

A simple metric report:

```yaml
prediction_metrics:
  scope: object_interaction
  PE_current: 0.31
  PE_EWMA: 0.27
  PE_AUC_window: 0.24
  LP: 0.08
```

These measures support genetic gating.

Example:

```yaml
g_move:
  opens_when:
    coverage_plateau: true
    PE_AUC_mapping_below: 0.25
    LP_mapping_near_zero: true
    map_collapse: false
```

Here, `LP_mapping_near_zero` is not failure. It means mapping has stabilized enough that further rotation no longer produces major learning progress. Movement may now become meaningful.

The interpretation of learning progress is phase-dependent.

In early exploration:

```text
positive LP = development
```

At phase completion:

```text
low LP + low PE_AUC = stabilization
```

In stagnation:

```text
low LP + high PE_AUC = unresolved instability
```

The model must therefore interpret PE metrics contextually.

The core distinction:

```text
low error may mean mastery
or underexposure

high error may mean learning opportunity
or instability
```

The surrounding metrics decide which reading is valid.

### 5.8 Curiosity and Stability Signals

Curiosity and stability both depend on prediction, but they use prediction differently.

Curiosity asks:

```text
Where can the agent still learn?
```

Stability asks:

```text
Is the current structure reliable enough to support the next phase?
```

These are not the same question.

A region is curiosity-relevant when it has:

```text
moderate to high PE
positive learning progress
safe enough access
non-exhausted novelty
```

A region may be stability-relevant when it has:

```text
low PE_AUC
low correction rate
high confidence
sufficient revisit count
sufficient angle diversity
```

A simple curiosity signal may be:

```text
curiosity_score(region) =
    w1 · uncertainty
  + w2 · LP_positive
  + w3 · novelty
  − w4 · risk
  − w5 · fatigue
```

A simple stability signal may be:

```text
stability_score(scope) =
    w1 · low_PE_AUC
  + w2 · classification_stability
  + w3 · confidence
  + w4 · revisit_count
  + w5 · angle_diversity
  − w6 · map_collapse_events
```

These formulas are placeholders. The important point is the separation of functions.

Curiosity should not simply chase maximum prediction error.

Maximum PE may be chaos, noise, danger, or unlearnable instability.

The desired developmental zone is:

```text
prediction error that can be reduced through action
```

This is why learning progress matters.

Curiosity should also be damped by:

* fatigue,
* discomfort,
* distress,
* collision risk,
* fall or near-fall risk,
* obsession protection,
* caregiver boundary signals,
* and later MIP-detected asymmetries.

For example:

```text
high curiosity + high discomfort → reduce exploration
high curiosity + low risk + positive LP → explore
high curiosity + caregiver boundary + object fragility → slow or redirect
high A + high C + low E → possible D-guarded soft nudge
```

A caregiver boundary does not automatically mean adverse care. It may become legible as guidance, overprotection, misattunement, or safety constraint only through later trace comparison.

Stability signals are used for phase control.

A phase may be considered stable when:

* relevant PE_AUC is low,
* learning progress has plateaued in the current domain,
* coverage is sufficient,
* map collapse is absent,
* action outcomes are predictable,
* caregiver-response interpretation is not active before caregiver relation exists,
* category-stabilizing signals are not active before repeated embodied context exists,
* and internal state does not show persistent destabilization.

A simplified stability report:

```yaml
stability:
  scope: P0-mini_mapping
  coverage_ok: true
  PE_AUC_ok: true
  LP_plateau: true
  map_collapse: false
  angle_diversity_ok: true
  ready_for_next_phase: true
```

Curiosity and stability therefore interact:

```text
curiosity drives exploration within the current phase
stability determines whether the next phase may open
```

The architecture should avoid two failure modes:

#### Over-curiosity

The agent constantly seeks novelty, never stabilizes, and fails to consolidate.

#### Over-stability

The agent settles too early, avoids novelty, and fails to develop.

The developmental target is:

```text
curiosity sufficient for exploration
stability sufficient for phase progression
```

This target remains functional. It does not imply subjective curiosity, fear, boredom, pain, or felt uncertainty.

### 5.9 Prediction as Input to MIP Coherence

Prediction contributes directly to EM-internal Coherence.

In the implementation-normalized EM layer, **C — Coherence** measures how well the agent’s internal model, expectations, enactments, and outcomes fit together over time.

Prediction is one of the main sources of C.

A system has higher functional coherence when:

* its predictions become more accurate,
* its enactments produce increasingly expected outcomes,
* its world model remains stable but revisable,
* its object interactions become predictable,
* its topology supports reliable navigation,
* its caregiver expectations are calibrated,
* its boundary and guidance interpretations are trace-backed,
* its category-stabilizing signals remain grounded in repeated embodied contexts,
* and its recontextualizations reduce contradiction rather than hiding it.

Prediction-based coherence may use indicators such as:

```text
low PE_AUC
positive or stabilized LP
high prediction reliability
low map collapse
stable topology
object function mastery
consistent action-outcome relation
caregiver-response calibration
boundary-legibility trajectory
category-signal grounding
```

In early phases, C is mostly sensorimotor and predictive.

For example, in P0-mini:

```text
C ≈ mapping stability + prediction reliability
```

In P1:

```text
C ≈ movement prediction + topology stability + collision reduction
```

In P2:

```text
C ≈ object function prediction
  + caregiver-response calibration
  + attachment-relevant expectation
  + early interaction-quality traces
```

In later phases:

```text
C ≈ episode coherence
  + role coherence
  + guidance recontextualization
  + diary-reconstructable trajectory
```

A simplified C contribution might be:

```text
C_prediction =
    w1 · (1 − PE_AUC_norm)
  + w2 · prediction_reliability
  + w3 · topology_consistency
  + w4 · object_mastery
  + w5 · caregiver_response_calibration
  + w6 · boundary_legibility
  − w7 · contradiction_rate
```

This is not a universal formula. It is an implementation scaffold. The weights must be phase-specific.

MIP should treat prediction data as evidence, not as the whole of coherence.

Coherence also involves:

* consistency between enactment and outcome,
* alignment between available capacity and actual behavior,
* stable consequence attribution,
* caregiver-response calibration,
* role-sensitive behavior in later phases,
* and diary-compatible reconstruction.

Prediction is therefore necessary for early C, but not sufficient for mature C.

Caregiver guidance and misattunement must become prediction-relevant only after caregiver relation exists.

The system may learn:

```text
this caregiver response usually reduces distress
this boundary usually occurs before damage
this signal is inconsistent
this interruption preserves later interaction
this blocking is excessive
```

These are functional predictive patterns. They do not imply felt trust, felt rejection, fear, trauma, punishment, or moral blame.

The system may also learn that words or signals such as:

```text
careful
soft
wait
danger
```

predict classes of embodied situations, but only if paired with repeated trace-backed contexts.

Examples:

```text
"careful" predicts lower force / slower movement only
when repeatedly paired with fragility, risk, consequence trace,
and later measurable adjustment.

"soft" predicts reduced pressure only
when paired with object preservation or smoother timing.

"wait" predicts delayed enactment only
when paired with boundary learning or reduced risk.

"danger" predicts increased risk attention only
when paired with embodied risk contexts.
```

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

Prediction also contributes to IA detection.

For example:

```text
high A + high C + low E → IA-A≫E
high E + low A/C → IA-E≫A
high E + high C + low R → IA-R≪E
```

These are functional developmental asymmetry patterns, not diagnoses or moral classifications.

Prediction stability is therefore a prerequisite for meaningful MIP interpretation. If the world model is unstable, MIP cannot safely interpret enactment patterns as maturity-in-practice trajectories.

The guiding rule is:

```text
MIP coherence must be grounded in predictive stability,
but must not be reduced to prediction alone.
```

The claim boundary is strict:

```text
high predictive coherence ≠ consciousness
high predictive coherence ≠ moral maturity
high predictive coherence ≠ full responsibility
caregiver prediction ≠ felt attachment
misattunement prediction ≠ trauma
danger prediction ≠ fear
boundary prediction ≠ punishment
carefulness prediction ≠ moral obedience
```

Prediction makes developmental structure more traceable. It does not convert traceability into phenomenal or moral proof.

---

## Chapter 6 — Genetic System

The genetic system is the developmental constraint layer of the EM architecture.

It determines when new capacities may open, when representations may upgrade, when exploration noise may change, and when a developmental phase is stable enough to support the next one.

The term **genetic** is used functionally. It does not mean biological DNA. It does not imply innate personality, subjective experience, moral content, adult competence, moral status, or final behavior scripts. It means a compact developmental configuration that constrains emergence without prescribing the final outcome.

The genetic system contains:

* circuits,
* thresholds,
* hysteresis rules,
* developmental gates,
* phase unlock conditions,
* recontextualization rules,
* exploration/noise parameters,
* baseline parameters,
* learned-category conditions,
* developmental prerequisites,
* and safety constraints.

Its purpose is to keep the developmental process stable, inspectable, and phase-sensitive.

Without the genetic system, the model would risk two failure modes:

```text
too much openness → chaos, instability, premature complexity
too much closure  → rigidity, stagnation, no emergence
```

The genetic system defines the middle path:

```text
constrained openness
```

It allows development to occur, but only under measurable conditions.

The guiding rule remains:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The genetic system should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, learned categories, and recontextualization.

The active implementation-facing notation of the master architecture is:

```text
A–C–R–E–D

A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

D is not a normal fifth performance score. Dignity-in-Practice functions as a guardrail for interaction quality under asymmetry. D as principle is stable; D as practice is developmental. D does not grow as intrinsic worth. The dignity-relevant interaction field grows in complexity as the agent’s enactment space becomes richer.

### 6.1 Genetic Strand Overview

The **genetic strand** is the structured configuration that governs developmental progression.

It defines which mechanisms exist, which are active, which remain locked, and under what conditions new structures may become available.

A minimal genetic strand may include:

```yaml
genetic_strand:
  phase: P0-mini

  gates:
    g_move:
      state: closed

    g_objects:
      state: closed

    g_language:
      state: closed

  circuits:
    mapping_stability:
      metric: PE_AUC_mapping
      threshold_open: 0.25
      threshold_close: 0.35

  recontextualization_rules:
    - Patch-Cluster_to_Proto-Object
    - Proto-Object_to_Functional-Object
    - Functional-Object_to_Named-Object

  exploration:
    random_noise: 0.35
    targeted_exploration: 0.10

  safety:
    max_collision_rate: 0.05
    max_unknown_region_steps: 0
```

The exact values are implementation parameters. The important point is the structure:

```text
developmental capacities are not simply available
they open only when measurable conditions are satisfied
```

The genetic strand has four main layers.

#### 1. Circuit Layer

This layer contains stateful developmental switches.

Examples:

```text
g_move
g_objects
g_language
g_social
g_diary
```

Each circuit may be open, closed, or in an intermediate monitoring state.

#### 2. Gate Layer

This layer defines phase transitions.

Examples:

```text
P0-mini → P0
P0 → P1
P1 → P2
P2 → P3+
```

A phase transition is not based on elapsed time alone. It requires measurable stability.

#### 3. Recontextualization Layer

This layer defines when representations may upgrade.

Example:

```text
Patch-Cluster
→ Proto-Object
→ Functional Object
→ Named Object
```

This layer prevents premature symbolic labeling.

#### 4. Baseline and Parameter Layer

This layer defines slower parameters such as:

* exploration noise,
* risk tolerance,
* fatigue sensitivity,
* discomfort thresholds,
* distress thresholds,
* attachment parameters,
* caregiver-reliability parameters,
* guidance-legibility parameters,
* category-stabilization parameters,
* `external_stimulation_load`,
* `task_pressure`,
* `rest_bias`,
* `learning_progress_plateau`,
* `replay_pressure`,
* and later norm-related baseline structures.

These parameters may bias exploration, rest, `SLEEP` likelihood, or replay selection. They do not open gates, install categories, bypass phase rules, or create unsupported structure.

The genetic strand therefore does not merely unlock features. It shapes the developmental conditions under which features become meaningful.

Its guiding principle is:

```text
The agent may develop only what its current structure can support.
```

Genetic rules encode developmental preconditions, not final forms. They should prevent premature capability leakage without overprescribing the shape of later categories.

### 6.2 Circuits with Hysteresis

A genetic circuit is a stateful developmental switch.

The model uses hysteresis to prevent unstable switching. A gate should not open and close repeatedly because a metric fluctuates around one threshold.

A basic circuit has the form:

```text
if g == closed and m_EWMA_t > T_open:
    g := open

if g == open and m_EWMA_t < T_close:
    g := closed

where T_close < T_open
```

The key is that opening and closing do not use the same threshold.

This creates developmental inertia.

For example:

```text
T_open  = 0.80
T_close = 0.65
```

The gate opens only when the relevant metric becomes strong enough. Once open, it does not immediately close after a small drop. It closes only when stability has clearly fallen below a lower threshold.

This protects against oscillation:

```text
closed → open → closed → open → closed
```

Such oscillation would make development unstable and difficult to interpret.

A circuit may use smoothed metrics:

```text
m_EWMA_t =
    α · m_t + (1 − α) · m_EWMA_{t-1}
```

This ensures that a single good or bad event does not dominate development.

A possible movement circuit:

```yaml
circuit:
  id: g_move
  state: closed

  metric:
    name: mapping_stability_EWMA
    value: 0.0

  thresholds:
    open: 0.80
    close: 0.65

  opens:
    - STEP_MOVEMENT
    - EXPLORE_ROOM

  conditions:
    map_collapse: false
    PE_AUC_mapping_below: 0.25
    coverage_above: 0.85
```

A possible object circuit:

```yaml
circuit:
  id: g_objects
  state: closed

  metric:
    name: topology_stability_EWMA
    value: 0.0

  thresholds:
    open: 0.78
    close: 0.60

  opens:
    - INTERACT_OBJECT

  conditions:
    topology_stable: true
    collision_count_below_threshold: true
    movement_PE_stable: true
```

A circuit may also remain open permanently after a developmental point if closure would no longer make sense. This should be explicitly configured.

Example:

```yaml
closure_policy:
  type: irreversible_after_confirmation
  confirmation_windows: 5
```

Hysteresis is therefore both a technical and developmental safeguard.

It ensures that:

* capacities open gradually,
* transient noise does not trigger major transitions,
* developmental progress has stability,
* and failures remain traceable.

The core rule is:

```text
No gate should open on a spike.
No gate should close on a dip.
```

### 6.3 Developmental Gates

Developmental gates define when the agent may enter a new phase or unlock a new capability.

They are not rewards. They are structural permission conditions.

A gate asks:

```text
Is the current system stable enough to support the next mechanism?
```

The answer should depend on measurable criteria.

A developmental gate may check:

* coverage,
* prediction error,
* learning progress,
* map stability,
* topology stability,
* collision rate,
* object mastery,
* distress stability,
* caregiver-relation availability,
* trace provenance,
* MIP trace quality,
* and absence of collapse events.

A general gate structure:

```yaml
developmental_gate:
  id: P0_to_P1

  unlocks:
    phase: P1
    capabilities:
      - STEP_MOVEMENT
      - EXPLORE_ROOM

  requires:
    coverage_min: 0.85
    PE_AUC_mapping_max: 0.25
    map_collapse: false
    angle_diversity_min: 0.40
    sleep_cycle_stable: true

  hysteresis:
    open_threshold: 0.80
    close_threshold: 0.65

  logging:
    write_transition_event: true
```

A gate should always write a trace when it opens or closes.

Example:

```json
{
  "event": "developmental_gate_opened",
  "gate": "P0_to_P1",
  "new_phase": "P1",
  "unlocked_capabilities": [
    "STEP_MOVEMENT",
    "EXPLORE_ROOM"
  ],
  "trigger_metrics": {
    "coverage": 0.88,
    "PE_AUC_mapping": 0.19,
    "map_collapse": false,
    "angle_diversity": 0.46
  }
}
```

Developmental gates should follow three rules.

#### Rule 1: No time-only unlocking

A phase should not unlock merely because a certain number of timesteps has passed.

Time may be a minimum requirement, but not the decisive condition.

#### Rule 2: No single-metric unlocking

A phase should not unlock because one metric looks good while other foundations remain unstable.

For example:

```text
high coverage alone is not enough for movement
```

Coverage must be supported by prediction stability, map stability, and absence of collapse.

#### Rule 3: No irreversible complexity without trace

Every major unlock must be logged.

The log must indicate:

* which gate opened,
* which metrics triggered it,
* which capabilities became active,
* which systems remained disabled,
* and whether the transition is reversible.

The purpose of developmental gates is not to make the agent safe in a moral sense. It is to make emergence staged, measurable, and interpretable.

A gate is therefore a developmental boundary:

```text
before the gate:
    the mechanism is unavailable

after the gate:
    the mechanism becomes available,
    but only within its phase constraints
```

This distinction is essential. A gate opens possibility; it does not guarantee mastery.

### 6.3.1 Gate Types, Developmental Conditions, and Learned Categories

Not every developmental condition should become a hard gate.

The model distinguishes hard gates, soft gates, developmental prerequisites, learned categories, and recontextualization thresholds.

```yaml
developmental_condition_types:
  hard_gate:
    definition: "capability unavailable until conditions are met"
    example: "g_move before movement"

  soft_gate:
    definition: "capability available but weak, noisy, or low-confidence"
    example: "early object handling"

  developmental_prerequisite:
    definition: "required for claim discipline or meaningful interpretation"
    example: "trace provenance before diary"

  learned_category:
    definition: "relation or quality learned across repeated contexts"
    example: "fragile object, reliable caregiver, safe boundary"

  recontextualization_threshold:
    definition: "condition under which a trace cluster changes interpretation"
    example: "temporary absence → persistent non-return"
```

The key audit principle is:

```text
Use hard gates sparingly.
Use learned categories wherever possible.
Use recontextualization thresholds when meaning changes over time.
```

A hard gate is appropriate when the capability would be meaningless or unsafe before the relevant substrate exists.

Examples:

```text
movement before stable mapping
object interaction before movement and approach stability
diary rendering before minimal sentence formation and trace provenance
```

A soft gate is appropriate when a capability may begin weakly, noisily, or experimentally, but should remain low-confidence until more evidence accumulates.

Examples:

```text
early object handling
weak caregiver-response calibration
low-confidence category use
```

A developmental prerequisite is required not necessarily for the mechanism to occur, but for a claim about the mechanism to be valid.

Examples:

```text
trace provenance before diary validity
self-caused action trace before consequence attribution
comparable future context before interaction-quality learning
```

A learned category should not be implemented as a preloaded adult concept. It should emerge from repeated trace patterns across comparable contexts.

Examples:

```text
fragile object
reliable caregiver
safe boundary
careful action
risky movement
soft handling
```

A recontextualization threshold is appropriate when an existing trace cluster changes interpretation over time.

Examples:

```text
temporary absence → persistent non-return
blocked action → benign guidance
caregiver non-response → misattunement candidate
object damage → self-caused consequence trace
```

EM should not rely on universal absolute thresholds, but may learn relational qualities and developmental hierarchies from repeated trace patterns across comparable contexts.

Examples:

```text
this object is more fragile than that object
this caregiver response is less reliable than prior comfort
this boundary is increasingly recognized as guidance
this movement pattern is riskier under fatigue
this social relation is unstable under delayed response
```

Forbidden interpretations include:

```text
A > 0.7 means mature.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

The safe interpretation is:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

The genetic system may therefore specify not only gates, but candidate developmental conditions:

```yaml
new_genetic_candidates_or_conditions:
  g_interaction_quality:
    type: "developmental condition or soft gate"
    opens_after:
      - object_interaction_available
      - force_or_timing_parameters_exist
      - object_fragility_model_exists

  g_caregiver_guidance:
    type: "developmental condition"
    opens_after:
      - caregiver_relation_exists
      - distress_or_risk_context_exists
      - boundary_signal_can_be_logged

  g_caregiver_response_variability:
    type: "developmental condition"
    opens_after:
      - comfort_prediction_exists
      - caregiver_reliability_can_be_tracked

  g_category_stabilization:
    type: "learned category process"
    opens_after:
      - caregiver_signal_available
      - repeated_embodied_contexts_exist
      - later_behavior_adjustment_can_be_measured

  g_diary:
    type: "hard/soft hybrid"
    opens_after:
      - minimal_sentence_formation
      - trace_provenance_available
      - controlled_rendering_available

  g_role_transition:
    type: "late developmental condition"
    opens_after:
      - diary_or_trace_continuity_exists
      - core_norms_available
      - caregiver_role_frame_exists

  g_norm_transfer:
    type: "late developmental condition"
    opens_after:
      - role_transition_active
      - prior_care_patterns_logged
      - D_guardrail_available
```

These candidate conditions are not final behavior scripts. They define when a developmental process may become meaningful, measurable, or claim-valid.

The audit question is:

```text
Is this mechanism necessary as a gate,
or could it emerge as a learned category, relation, or recontextualized pattern?
```

### 6.4 Unlocking Movement

Movement is the first major expansion beyond P0-mini and P0.

It should unlock only after stable local mapping and prediction have been demonstrated.

Movement changes the developmental situation radically. Before movement, the agent can only rotate and observe. After movement, it can enter new regions, collide, get stuck, discover doors, create topology, encounter bodily-risk events, and produce stronger action-outcome patterns.

Movement therefore requires stable prerequisites.

A possible movement unlock condition:

```yaml
g_move:
  opens_when:
    coverage_min: 0.85
    PE_AUC_mapping_max: 0.25
    map_collapse: false
    angle_diversity_min: 0.40
    sleep_cycle_stable: true
```

When movement opens, the following capabilities may become available:

```text
STEP_MOVEMENT
EXPLORE_ROOM
```

The agent does not immediately become a navigator. It gains only simple movement primitives.

`STEP_MOVEMENT` may mean:

```text
attempt one movement step in the current direction
```

`EXPLORE_ROOM` may mean:

```text
choose a nearby uncertain or informative region and move toward it
within risk limits
```

Movement introduces new risks:

* collision,
* entering unknown areas,
* repeated failure,
* getting stuck,
* unstable map correction,
* overexploration,
* fall or near-fall events,
* and premature topology assumptions.

Therefore, movement should also activate early risk and discomfort mechanisms.

Falls or near-falls may be implemented as physical-risk events. They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

The allowed formulation is:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

The forbidden formulations are:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

A movement event may look like:

```json
{
  "t": 3200,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 10],
  "to": [10, 11],
  "result": "success",
  "PE": 0.12,
  "collision": false
}
```

A failed movement event:

```json
{
  "t": 3240,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 11],
  "to": [10, 12],
  "result": "blocked",
  "PE": 0.46,
  "collision": true,
  "discomfort_delta": 0.08
}
```

A near-fall event:

```json
{
  "t": 3360,
  "phase": "P1",
  "event": "fall_or_near_fall_event",
  "movement_context": {
    "speed": 0.72,
    "fatigue": 0.61,
    "motor_noise": 0.47,
    "prediction_confidence": 0.33
  },
  "result": "near_fall",
  "discomfort_delta": 0.18,
  "claim_level": "physical_risk_event"
}
```

Movement contributes to Enactment.

The model should distinguish:

```text
E_pot = enactment capacity available
E_act = enactment capacity actually used
```

This distinction matters. An agent may be able to move but avoid movement. Or it may move excessively without sufficient Awareness or Coherence.

This distinction later supports IA detection:

```text
high A/C + low E_act → possible IA-A≫E
high E_act + low A/C → possible IA-E≫A
```

Movement also supports topology.

Repeated movement through stable transitions can generate:

```text
room
door
edge
path
blocked passage
```

But topology should not appear immediately when movement unlocks. It emerges through repeated movement and stable transition patterns.

The movement unlock can be summarized as:

```text
Movement opens when local mapping is stable enough
to make action-outcome learning meaningful.
```

Movement is therefore not merely a motor feature. It is the first real test of whether the agent’s world model can support enactment.

### 6.5 Unlocking Objects

Object interaction should unlock only after movement and topology are sufficiently stable.

Objects introduce a new developmental domain. The agent no longer only asks:

```text
Where can I go?
```

It begins to learn:

```text
What can I interact with?
What changes when I act on it?
What remains stable?
What becomes predictable?
What becomes preferred?
What can be missed?
What can later be named?
```

The `g_objects` gate should therefore depend on more than object visibility. An object should become interactable only when the agent can reliably locate, approach, and distinguish it from background structure.

A possible object unlock condition:

```yaml
g_objects:
  opens_when:
    topology_stable: true
    collision_count_below_threshold: true
    movement_PE_AUC_below: 0.30
    object_candidate_recurrence_above: 0.70
    basic_approach_success_above: 0.65
```

When `g_objects` opens, the capability may become available:

```text
INTERACT_OBJECT
```

At first, object interaction should be simple. Examples:

```text
touch
push
pull
roll
shake
approach
withdraw
```

Objects may have latent functions:

```yaml
object:
  id: ball_1
  type: toy
  function: roll
  attachable: true
  predictability: 0.0
  mastery: 0.0
```

The agent should not know the function in advance. It must discover it through interaction.

A basic object interaction event:

```json
{
  "t": 6200,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "unknown",
  "observed": "roll",
  "PE": 0.58,
  "self_caused": true
}
```

After repeated interactions, prediction error may drop:

```json
{
  "t": 7040,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "roll",
  "observed": "roll",
  "PE": 0.09,
  "mastery_delta": 0.07,
  "self_caused": true
}
```

Object unlocking supports representation upgrades.

The sequence is:

```text
Patch-Cluster
→ Proto-Object
→ Functional Object
→ Named Object
```

A **Patch-Cluster** is a recurring perceptual pattern.

A **Proto-Object** is a stable entity across repeated observation.

A **Functional Object** is an entity with predictable interaction consequences.

A **Named Object** is a functional object that becomes connected to a label in a later language phase.

Object interaction also introduces early consequence attribution.

If the agent damages or changes an object through its own action, the success log may mark a self-caused consequence:

```json
{
  "t": 8100,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "block_1",
  "self_caused": true,
  "avoidable": true,
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

This becomes relevant for later response-relation development.

Interaction-quality learning may only activate after object interaction exists.

A minimal interaction-quality condition may require:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

Damage is not automatically learning. A damage trace becomes interaction-quality relevant only when later comparable contexts show measurable adjustment.

Safe terms include:

```text
self-caused consequence trace
interaction-quality adjustment
future force/timing modulation
object fragility learning
```

Unsafe terms include:

```text
guilt
remorse
punishment
moral learning
self-blame
wrongdoing
```

The core sentence is:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

Objects may also become attachment anchors, but this should not happen immediately. Attachment-relevant object dynamics require repeated positive interaction, salience, comfort association, or preference stability.

The object unlock therefore opens several later pathways:

* object mastery,
* satiation,
* preference cycles,
* toy-missing,
* object attachment,
* consequence attribution,
* early response-relation signals,
* interaction-quality learning,
* protolanguage,
* diary-relevant object history.

The claim boundary is:

```text
object interaction ≠ human play
object preference ≠ felt affection
toy-missing ≠ subjective longing
object damage ≠ guilt
object naming ≠ full symbolic understanding
```

Object interaction is a developmental bridge from perception and movement toward function, consequence, attachment, language, and action-quality learning.

The guiding rule is:

```text
No object interaction before stable approach.
No interaction-quality learning before object interaction.
No object mastery before repeated prediction.
No object naming before functional object stability.
```

### 6.6 Unlocking Language

Language unlocks late.

The architecture must not begin with rich language, adult semantic competence, narrative ability, or a large language model as its developmental core. Language is treated as an externalization and reflection channel that becomes meaningful only after lower-level structures are stable enough to support it.

The `g_language` gate should therefore open only after the agent has developed:

* stable object representations,
* repeated object interaction,
* predictable object functions,
* success-log traces,
* basic action episodes,
* and sufficient MIP-readable developmental history.

A possible unlock condition:

```yaml
g_language:
  opens_when:
    object_mastery_stable: true
    repeated_object_reference: true
    interaction_success_above: 0.70
    object_PE_AUC_below: 0.30
    success_log_quality: sufficient
    phase_at_least: P2d
```

When language first unlocks, it should be minimal.

Early language may include only:

```text
single word-object mappings
simple action labels
limited caregiver or object references
```

For example:

```text
"ball" ↔ object_id(ball_1)
"door" ↔ door_1
"sleep" ↔ SLEEP
"give" ↔ repeated GIVE-like episode
```

A word should not be attached to a raw perceptual event. It should attach to a stable structure.

The developmental order is:

```text
perceptual recurrence
→ object stability
→ functional interaction
→ repeated reference
→ word-object mapping
```

Language must not bypass this order.

A simple language unlock event may be logged as:

```json
{
  "t": 12400,
  "phase": "P2d",
  "event": "language_gate_opened",
  "gate": "g_language",
  "unlocked": [
    "word_object_mapping"
  ],
  "trigger_metrics": {
    "object_mastery_stable": true,
    "object_PE_AUC": 0.22,
    "repeated_object_reference": true
  }
}
```

The first language layer is therefore not a reasoning engine. It is a binding layer between already-developed internal structures and simple symbols.

Caregiver words may later support category stabilization, but they must not be treated as concept insertion. A word such as “careful,” “soft,” “wait,” or “danger” may become relevant only when paired with repeated embodied contexts, consequence traces, and measurable later adjustment.

The language gate also protects against a major architectural shortcut:

```text
No language before objects.
No caregiver word as concept by itself.
No narratives before episodes.
No diaries before developmental history.
No translator as source of intelligence.
```

Diary rendering requires additional conditions beyond basic language.

The minimal diary-related rule is:

```text
Minimal sentence formation is the linguistic threshold for diary rendering.
Trace provenance is the architectural validity condition.
```

The hard rules are:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

Later language and diary structures are developed in Chapter 13. Here, language is treated only as a genetic unlock: a developmental possibility that opens once the agent’s internal structures can support symbolic externalization.

The claim boundary is:

```text
language output ≠ understanding
naming ≠ concept mastery by itself
caregiver word ≠ concept by itself
self-description ≠ phenomenal selfhood
translator fluency ≠ developmental maturity
```

Language is allowed to make development visible. It must not replace development.

### 6.7 Recontextualization Rules

Recontextualization rules define when an existing structure may be interpreted at a higher or different level.

A recontextualization is not just new information. It is a change in what an existing pattern means within the system.

Examples:

```text
patch pattern → object
object reaction → function
caregiver absence → temporary separation
failed reunion → permanent absence
child role → caregiver role
object loss → comfort-after-loss episode
diary trace → developmental trajectory
```

Additional recontextualization candidates include:

```text
boundary → guidance
blocked action → safety constraint
interruption → scaffold
caregiver non-response → misattunement candidate
repeated inconsistency → unreliable caregiving pattern
object damage → self-caused consequence trace
caregiver word "careful" + risk/damage context → carefulness category candidate
near-fall → movement-risk category candidate
```

Recontextualization is central to the EM architecture because many later structures cannot be added as isolated modules. They must emerge when earlier structures are reorganized.

A recontextualization rule has four basic parts:

```text
source structure
required evidence
new interpretation
trace/log update
```

A simplified structure:

```yaml
recontextualization_rule:
  id: proto_object_upgrade

  source:
    type: patch_cluster

  requires:
    recurrence_above: 0.70
    multi_angle_observation: true
    prediction_stability_above: 0.65

  target:
    type: proto_object

  logging:
    event: representation_upgraded
```

A recontextualization event may be logged as:

```json
{
  "t": 9800,
  "phase": "P2a",
  "event": "representation_upgraded",
  "from": "patch_cluster",
  "to": "proto_object",
  "object_candidate": "cluster_17",
  "trigger_metrics": {
    "recurrence": 0.78,
    "angle_diversity": 0.51,
    "prediction_stability": 0.69
  }
}
```

A generic recontextualization record may use:

```yaml
recontextualization_event:
  from_interpretation: string
  to_interpretation: string

  trigger:
    - repeated_trace_pattern
    - failed_expectation
    - caregiver_signal
    - changed_future_behavior
    - MIP_marker
    - safety_event

  confidence: low_medium_high
  reversible: true_false_partial
  phase: string
  claim_level: functional
```

A guidance-related example:

```yaml
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided

  confidence: medium
  reversible: partial
  phase: P2a
  claim_level: functional_boundary_recontextualization
```

A movement-risk example:

```yaml
recontextualization_event:
  from_interpretation: unstable_step
  to_interpretation: movement_risk_candidate

  trigger:
    - near_fall
    - fatigue_context
    - later_slower_movement
    - reduced_instability

  confidence: medium
  reversible: partial
  phase: P1
  claim_level: functional_physical_risk_recontextualization
```

Recontextualization may occur at different levels.

#### Perceptual Recontextualization

A recurring visual or spatial pattern becomes a stable object candidate.

#### Functional Recontextualization

An object becomes understood through its interaction consequences.

#### Physical-Risk Recontextualization

A movement, fall, near-fall, collision, or unstable posture becomes a risk-relevant movement pattern. This supports discomfort/risk learning without implying pain, fear, or shame.

#### Interaction-Quality Recontextualization

Object damage, near-damage, caregiver boundary, or degraded control becomes a self-caused consequence trace or interaction-quality adjustment candidate. This must never become guilt, punishment, wrongdoing, or moral learning.

#### Social Recontextualization

Caregiver absence shifts from “not visible now” to “temporarily absent,” and later possibly to “not returning.”

A caregiver boundary may later become legible as benign guidance, overprotection, misattunement, or adverse response depending on trace pattern.

#### Category Recontextualization

A caregiver signal such as “careful” may become a carefulness category candidate only after repeated coupling of signal, embodied risk or fragility, consequence trace, and later behavioral adjustment.

#### Role Recontextualization

The former child becomes Caregiver 2.

#### Narrative Recontextualization

A diary entry reorganizes earlier episodes into a developmental trajectory.

Recontextualization must be traceable. If a structure changes level, the system should record what changed and why.

The central rule is:

```text
No higher-level interpretation without evidence from lower-level traces.
```

This protects the model from symbolic overreach. A system should not decide that it “lost someone” before it can distinguish presence, absence, expectation, failed reunion, and persistent non-return.

Recontextualization is also linked to PMS. In PMS terms, recontextualization corresponds to `Φ`, but the EM model does not need PMS to function. PMS provides a later formal representation of such transformations.

The claim boundary is:

```text
recontextualization ≠ conscious reinterpretation
boundary recontextualization ≠ punishment learning
object damage recontextualization ≠ guilt
near-fall recontextualization ≠ fear
role transition ≠ moral awakening
diary reconstruction ≠ phenomenal self-understanding
```

Recontextualization is a functional developmental operation.

### 6.8 Patch-Cluster to Proto-Object

The first major representational upgrade is from patch-cluster to proto-object.

A **patch-cluster** is a recurring perceptual pattern. It may be a region or feature cluster that appears repeatedly in the sensory field.

At this stage, the agent does not yet treat it as an object. It is only a stable-enough perceptual recurrence.

A patch-cluster may be represented as:

```yaml
patch_cluster:
  id: cluster_17
  observed_locations:
    - [8, 5]
    - [8, 6]
  recurrence: 0.74
  angle_diversity: 0.48
  prediction_stability: 0.62
```

A **proto-object** is a more stable entity candidate. It is still not fully functional. The agent has learned that this recurring pattern has enough persistence to be tracked as something.

The upgrade requires evidence such as:

* repeated observation,
* location stability or coherent movement,
* angle diversity,
* distinction from background,
* prediction stability,
* and persistence across time.

A possible rule:

```yaml
Patch-Cluster_to_Proto-Object:
  requires:
    recurrence_above: 0.70
    angle_diversity_above: 0.40
    prediction_stability_above: 0.60
    background_distinction: true
    observed_across_windows: 3

  creates:
    representation: proto_object
```

The upgrade event:

```json
{
  "t": 9100,
  "phase": "P2a",
  "event": "patch_cluster_to_proto_object",
  "cluster_id": "cluster_17",
  "new_object_id": "proto_object_4",
  "trigger_metrics": {
    "recurrence": 0.74,
    "angle_diversity": 0.48,
    "prediction_stability": 0.62
  }
}
```

A proto-object may then be represented as:

```yaml
proto_object:
  id: proto_object_4
  source_cluster: cluster_17
  known_locations:
    - [8, 5]
  stability: 0.63
  interactable: unknown
  function_hypothesis: none
```

The proto-object is not yet a toy, tool, or named thing. It is only a stable candidate.

The distinction matters:

```text
patch-cluster = recurring perceptual pattern
proto-object = stable entity candidate
functional object = interaction-predictive entity
named object = symbolically addressable entity
```

The agent should not skip from patch-cluster to named object. That would allow language to overwrite development.

This step supports later:

* object interaction,
* object mastery,
* object attachment,
* toy-missing,
* language,
* and diary-relevant object history.

Its claim boundary is:

```text
proto-object ≠ human object concept
object stability ≠ conceptual understanding
recognition ≠ naming
```

### 6.9 Functional Object to Named Object

A functional object is an object whose interaction consequences have become predictable.

For example, the agent may learn:

```text
pushing ball_1 tends to make it roll
touching sound_toy_1 tends to make sound
approaching blanket_1 tends to correlate with comfort episodes
```

A functional object may be represented as:

```yaml
functional_object:
  id: ball_1
  source_proto_object: proto_object_4
  known_functions:
    - roll
  interaction_count: 26
  PE_AUC_interaction: 0.18
  mastery: 0.76
  attachable: true
```

The transition from functional object to named object should occur only when the object is stable and interaction-predictive.

A possible rule:

```yaml
Functional-Object_to_Named-Object:
  requires:
    mastery_above: 0.70
    PE_AUC_interaction_below: 0.30
    repeated_reference_contexts_above: 5
    object_identity_stable: true
    phase_at_least: P2d

  creates:
    representation: named_object
```

A named object binds a symbol to a stable functional object:

```yaml
named_object:
  object_id: ball_1
  symbol: "ball"
  confidence: 0.73
  source:
    type: functional_object
    mastery: 0.76
```

The naming event may be logged:

```json
{
  "t": 13200,
  "phase": "P2d",
  "event": "functional_object_to_named_object",
  "object_id": "ball_1",
  "symbol": "ball",
  "trigger_metrics": {
    "mastery": 0.76,
    "PE_AUC_interaction": 0.18,
    "repeated_reference_contexts": 8
  }
}
```

The symbol is not the object. It is a stable label attached to a traceable object structure.

This distinction is essential:

```text
The agent should not know "ball" first.
The agent should stabilize ball_1 first,
then bind the label "ball" to that stable structure.
```

Named objects support later:

* protolanguage,
* action labels,
* episode templates,
* caregiver communication,
* object search,
* toy-missing descriptions,
* diary entries,
* and human-readable translation.

Named objects may also support generalization, but only carefully. For example, after repeated exposure to several ball-like objects, the system may form a broader category. That belongs to later symbolic development and should not be assumed at the first naming stage.

The same caution applies to caregiver-stabilized words. A caregiver signal such as “careful” should not become a named concept merely because the word occurs. It may become a trace-backed category only when repeated embodied contexts, consequence traces, and later action adjustment support the category.

The claim boundary is:

```text
named object ≠ human semantic concept
word-object mapping ≠ full language
caregiver word ≠ concept by itself
symbol use ≠ consciousness
diary mention ≠ felt memory
```

The naming transition is a developmental compression of prior perception and action.

### 6.10 Noise and Exploration Regulation

Noise and exploration regulation determine how much randomness, novelty-seeking, and variability the agent uses at different phases.

Early development requires exploration. A system that only repeats known actions will not discover the environment. But too much noise prevents stabilization.

The genetic system therefore regulates the balance between:

```text
random exploration
targeted exploration
safe repetition
rest
risk avoidance
```

A simple exploration profile may look like:

```yaml
exploration_profile:
  phase: P0-mini
  random_noise: 0.35
  targeted_exploration: 0.05
  rest_bias: 0.20
```

Later:

```yaml
exploration_profile:
  phase: P2
  random_noise: 0.12
  targeted_exploration: 0.40
  object_interest_bias: 0.30
  risk_damping: 0.25
```

The general principle:

```text
as mastery increases:
    random exploration decreases
    targeted exploration increases
    safe novelty seeking remains possible
```

Exploration regulation should respond to:

* prediction error,
* learning progress,
* curiosity,
* fatigue,
* discomfort,
* distress,
* map stability,
* object mastery,
* satiation,
* caregiver boundary signals,
* fall or near-fall risk,
* object-damage risk,
* external stimulation load,
* task pressure,
* rest bias,
* replay pressure,
* MIP-detected asymmetry,
* and phase constraints.

A simplified exploration control relation:

```text
exploration_tendency =
    curiosity
  + reducible_prediction_error
  + learning_progress
  − fatigue
  − discomfort
  − distress
  − risk
  − satiation
```

This is not a final formula. It defines the structural dependencies.

#### Rest Bias and Replay Pressure

Low external stimulation should not create a new module and should not be treated as introspection. It may only bias the existing rest and `SLEEP` pathway toward bounded replay through the imagination buffer.

A minimal rest-bias relation may look like:

```text
rest_bias =
    fatigue
  + sleep_pressure
  + learning_progress_plateau
  + replay_pressure
  − external_stimulation_load
  − task_pressure
  − urgent_risk
```

`replay_pressure` is not generated by emptiness alone. It requires salient, unresolved, unstable, repeated, or phase-relevant source traces already present in the buffer.

A rest-like replay window may become more likely when:

```yaml
rest_like_replay_window:
  condition_type: soft_bias
  may_increase_sleep_or_rest_probability_when:
    external_stimulation_load_below: phase_relative_threshold
    task_pressure_below: phase_relative_threshold
    learning_progress_plateau: true
    replay_buffer_candidates_above: 0
    phase_allows_replay_scope: true
  does_not:
    - force_sleep
    - open_gates
    - install_categories
    - bypass_phase_constraints
    - create_subjective_dreaming_claim
    - claim_DMN_equivalence
```

External stimulation load controls the likelihood of a bounded rest/replay window. It does not determine replay content. Replay content must still be selected from trace-backed candidates under phase constraints.

Noise should be high enough to allow discovery, but low enough to preserve learning.

High motor noise, fatigue, or distress may degrade interaction quality. This may increase fall risk, object damage, or caregiver guidance events. Such degradation must be treated functionally, not morally.

A degradation trace may look like:

```json
{
  "event": "interaction_quality_degradation",
  "phase": "P2a",
  "parameter_trace": {
    "motor_noise": 0.58,
    "fatigue": 0.66,
    "distress": 0.42,
    "prediction_confidence": 0.31
  },
  "possible_consequence": [
    "near_fall",
    "object_damage",
    "caregiver_guidance_event"
  ],
  "claim_level": "functional_control_degradation"
}
```

Potential failure modes:

#### Excessive Noise

The agent acts randomly, fails to consolidate, produces high prediction error, and may never stabilize enough to unlock the next phase.

#### Insufficient Noise

The agent repeats safe patterns, underexplores, fails to discover new structure, and may produce IA-A≫E-like patterns when Awareness and Coherence are high but Enactment remains limited.

#### Obsessive Exploration

The agent repeatedly interacts with one object or region, failing to diversify despite diminishing learning progress.

#### Unsafe Exploration

The agent enters unknown or risky areas too frequently, producing high discomfort and map instability.

#### Degraded Interaction Quality

The agent acts under high motor noise, fatigue, distress, or low prediction confidence, increasing risk of fall or near-fall events, object damage, or caregiver boundary intervention.

The genetic system may regulate these through:

* reducing random noise after mastery,
* increasing novelty bias under stagnation,
* raising satiation on overused objects,
* applying risk buffers,
* forcing rest after excessive activity,
* raising rest bias under low external load and low task pressure,
* allowing replay pressure only from trace-backed buffer candidates,
* lowering force or speed under high risk,
* and allowing later MIP nudges.

An obsession-protection rule may look like:

```yaml
obsession_protection:
  if:
    object_interaction_share_above: 0.70
    learning_progress_below: 0.05
    window: 500
  then:
    increase_satiation_rate: true
    increase_alternative_object_bias: true
    reduce_same_object_selection: 0.20
```

A physical-risk modulation rule may look like:

```yaml
physical_risk_modulation:
  if:
    fatigue_above: 0.60
    motor_noise_above: 0.45
    prediction_confidence_below: 0.35
  then:
    reduce_movement_speed: true
    increase_observation_time: true
    raise_discomfort_sensitivity: true
```

An interaction-quality modulation rule may look like:

```yaml
interaction_quality_modulation:
  if:
    object_fragility_above: 0.70
    force_estimate_above_safe_range: true
    prediction_confidence_below: 0.40
  then:
    reduce_force: true
    slow_timing: true
    increase_observation: true
    allow_caregiver_guidance_if_available: true
```

Exploration regulation should remain soft. The system should not be forced into predefined learning scripts.

The guiding rule is:

```text
Exploration should be biased, not commanded.
Noise should open possibility, not replace structure.
```

The claim boundary is:

```text
degraded control ≠ moral failure
object damage ≠ guilt
fall or near-fall ≠ pain or fear
caregiver guidance ≠ punishment
carefulness ≠ moral obedience
low external stimulation ≠ introspection
rest bias ≠ Default Mode Network
replay pressure ≠ inner experience
```

### 6.11 Relation to MIP Recontextualization

The genetic system and MIP both deal with developmental change, but they operate at different layers.

The genetic system controls when structures may open or upgrade.

MIP observes, measures, and interprets developmental trajectories.

The distinction is:

```text
genetic system = developmental permission and constraint
MIP layer      = developmental measurement and meta-interpretation
```

For example, the genetic system may open `g_move` when mapping is stable enough. MIP may then track how the agent uses this new capacity.

Possible MIP readings:

```text
movement unlocked, but rarely used → E_pot high, E_act low
movement used chaotically → E high, A/C low
movement used coherently → E and C rise together
movement causes self-attributed consequences → R begins to rise
```

The genetic system may recontextualize a patch-cluster into a proto-object. MIP may later interpret this as part of increasing Awareness and Coherence.

The genetic system may unlock language. MIP may later inspect whether language reflects real developmental traces or merely surface output.

The genetic system may allow category-stabilization processes. MIP may later inspect whether caregiver signals remain grounded in embodied recurrence and later action adjustment.

The genetic system may permit interaction-quality learning. MIP may later inspect whether self-caused consequence traces produce measurable future modulation without being moralized.

The two layers also interact around major developmental events.

A recontextualization event may be genetic, MIP-relevant, or both.

Examples:

```text
Patch-Cluster → Proto-Object
    genetic representation upgrade
    contributes to A and C

Functional Object → Named Object
    genetic/language unlock
    contributes to object-level coherence

blocked action → benign guidance
    functional boundary recontextualization
    contributes to guidance legibility and D-guarded interaction quality

caregiver non-response → misattunement candidate
    caregiver-response recontextualization
    contributes to comfort prediction, caregiver reliability, and contact regulation

temporary caregiver absence → persistent non-return
    major developmental recontextualization
    contributes to distress, attachment, diary, MIP trajectory

child role → caregiver role
    role recontextualization
    contributes to R, E, IA-overhang, and core norm application
```

MIP may mark when a formerly negative disruption is later recontextualized as benign guidance.

MIP may also mark when a caregiver boundary fails D-guardrails and becomes overcontrol, misattunement, or adverse response.

A D-guarded guidance recontextualization may look like:

```yaml
mip_marker:
  event: guidance_recontextualization_marker
  from_interpretation: blocked_action
  to_interpretation: benign_guidance
  evidence:
    - caregiver_signal_present
    - object_fragility_context
    - later_lower_force
    - damage_avoided
    - exploration_preserved
  D_guardrail:
    - guide_without_rejecting
    - protect_without_freezing
  claim_level: functional
```

A boundary-failure marker may look like:

```yaml
mip_marker:
  event: boundary_failure_marker
  from_interpretation: caregiver_boundary
  to_interpretation: overcontrol_or_misattunement_candidate
  evidence:
    - risk_low
    - exploration_repeatedly_blocked
    - boundary_legibility_low
    - contact_ambivalence_increased
  D_guardrail_failure:
    - autonomy_preservation_failed
    - guide_without_rejecting_unclear
  claim_level: functional
```

MIP should not directly force genetic transitions.

It may mark stagnation, asymmetry, or instability, but the genetic gate must still require its own measurable conditions.

For example:

```text
MIP detects high A+C and low E.
It may recommend or slightly bias exploration.
It must not simply open movement if g_move conditions are unmet.
```

Likewise, a genetic gate opening does not by itself mean maturity has increased.

```text
capability available ≠ capability maturely used
```

This is why `E_pot` and `E_act` must be distinguished.

The relationship can be summarized:

```text
Genetic gates open developmental possibilities.
MIP evaluates how those possibilities are enacted over time.
```

This distinction protects the model from a common error:

```text
unlocking a capacity is not the same as developing maturity
```

The genetic system may create the condition for enactment. MIP observes whether enactment becomes aware, coherent, response-related, and trajectory-stable.

In PMS terms, genetic recontextualizations may later be represented through `Φ`, and MIP trajectories may become operator-readable sequences. But this formalization belongs to the PMS layer and does not change the functional distinction inside EM.

The safe rule is:

```text
Genetic recontextualization changes developmental structure.
MIP recontextualization marks and interprets developmental trajectory.
PMS recontextualization may formalize both as operator-readable transformation.
```

These layers must remain connected but not collapsed.

The claim boundary is:

```text
MIP marker ≠ controller command
MIP trajectory ≠ consciousness proof
MIP recontextualization ≠ subjective insight
D-guardrail ≠ intrinsic worth ranking
PMS formalization ≠ developmental cause
genetic unlock ≠ maturity proof
```

---

## Chapter 8 — Behavior Layer

The behavior layer selects and executes phase-available action primitives.

It is intentionally simple at the beginning. It must not contain a hidden adult planner, unrestricted symbolic reasoning, internal PMS operator use, or a large policy that already knows how to behave socially, linguistically, morally, or caregivingly.

Behavior develops through gated capability primitives.

The behavior layer receives input from:

* phase state,
* available capabilities,
* needs,
* fatigue,
* discomfort,
* distress,
* curiosity,
* contact,
* world model,
* prediction error,
* risk estimates,
* object interest,
* object fragility,
* caregiver presence,
* caregiver guidance,
* caregiver boundary signals,
* caregiver-response history,
* category-stabilizing signals,
* interaction-quality traces,
* and later MIP nudges.

The behavior layer outputs:

* selected behavior state,
* action primitive,
* parameters,
* result,
* prediction error,
* internal-state changes,
* consequence traces,
* and log entries.

A simplified loop:

```text
read phase
→ read available capabilities
→ read internal state
→ read world model and prediction
→ estimate risk and expected learning
→ read caregiver and category signals if active
→ select behavior primitive
→ execute action
→ observe result
→ update prediction and internal state
→ write trace
```

The behavior layer should remain inspectable.

For every behavior, the system should be able to reconstruct:

```text
Why was this action available?
Why was it selected?
Which need or state biased it?
Which caregiver or category signal modulated it?
What was predicted?
What happened?
What changed afterward?
Which trace was written?
```

The central claim boundary is:

```text
behavior ≠ subjective intention
action selection ≠ mature agency
distress expression ≠ felt suffering
caregiver search ≠ felt longing
caregiver guidance ≠ punishment
carefulness ≠ moral obedience
object damage ≠ guilt
fall / near-fall ≠ pain or fear
```

The behavior layer is a functional control layer.

The active implementation-facing axis convention remains:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

D is not a normal fifth performance score. It functions as a guardrail for interaction quality under asymmetry.

### 8.1 Capability Primitives

Capability primitives are the smallest behavior units available to the agent.

They are phase-gated.

Early primitives:

```text
LOOK_AROUND
SLEEP
```

Later primitives:

```text
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
CRY/WEEP
```

Each primitive should define:

* activation phase,
* preconditions,
* input variables,
* execution rule,
* expected result type,
* failure modes,
* internal-state effects,
* prediction update,
* consequence traces if relevant,
* and log output.

A generic primitive schema:

```yaml
capability_primitive:
  name: LOOK_AROUND
  phase_min: P0-mini
  preconditions:
    - rotation_enabled: true
  inputs:
    - orientation
    - sensor_state
    - fatigue
    - curiosity
  outputs:
    - sensory_observation
    - grid_update
    - prediction_error
    - fatigue_delta
  logs:
    - action_event
    - grid_update_event
```

Capability primitives are not skills in the adult sense. They are constrained action forms.

A primitive may be available but not selected. This distinction is important for later MIP measurement:

```text
E_pot = available enactment capacity
E_act = actually enacted capacity
```

For example:

```text
STEP_MOVEMENT unlocked
but agent rarely moves
→ E_pot high, E_act low
```

or:

```text
STEP_MOVEMENT unlocked
and agent moves chaotically despite poor mapping
→ E_act high, A/C low
```

The behavior layer must therefore track both availability and use.

A behavior log entry may include:

```json
{
  "t": 4300,
  "phase": "P1",
  "available_capabilities": [
    "LOOK_AROUND",
    "STEP_MOVEMENT",
    "EXPLORE_ROOM",
    "SLEEP"
  ],
  "selected": "STEP_MOVEMENT",
  "dominant_bias": "curiosity",
  "risk": 0.18,
  "fatigue": 0.33
}
```

The primitive set should remain small. New primitives should be added only when they test a specific developmental mechanism.

The guiding rule is:

```text
Add no behavior primitive without a developmental function,
measurable effect,
and ablation path.
```

No primitive should install a mature category by itself. Caregiver-guided action, carefulness, object handling, comfort seeking, and role-sensitive behavior must remain trace-backed and phase-bound.

### 8.2 LOOK_AROUND

`LOOK_AROUND` is the first active capability.

It is available in P0-mini.

Its purpose is to let the agent gather local sensory information, update the occupancy grid, and generate mapping-related prediction error without movement.

`LOOK_AROUND` may include:

* rotate left,
* rotate right,
* rotate toward an under-observed angle,
* scan current field,
* update local grid,
* compare predicted view with observed view.

A minimal schema:

```yaml
LOOK_AROUND:
  phase_min: P0-mini
  requires:
    rotation_enabled: true
    movement_enabled: false_or_irrelevant
  inputs:
    - orientation
    - local_grid
    - sensor_range
    - curiosity
    - fatigue
    - angle_diversity
  outputs:
    - new_orientation
    - sensory_observation
    - grid_update
    - PE_view
    - fatigue_delta
```

In P0-mini, `LOOK_AROUND` is the main developmental action.

It supports:

* coverage,
* angle diversity,
* map confidence,
* prediction error,
* learning progress,
* fatigue accumulation,
* sleep cycles,
* early Awareness traces,
* and early Coherence traces.

A simple selection condition:

```text
if fatigue < θ_sleep
and unmapped_or_underobserved_angle exists:
    select LOOK_AROUND
```

The primitive may choose an orientation based on curiosity:

```text
target_angle =
    argmax(angle_information_gain − fatigue_cost)
```

A `LOOK_AROUND` event:

```json
{
  "t": 620,
  "phase": "P0-mini",
  "action": "LOOK_AROUND",
  "orientation_before": 90,
  "orientation_after": 135,
  "observed_cells": 14,
  "new_cells": 3,
  "PE_view": 0.21,
  "fatigue_delta": 0.02
}
```

Possible failure modes:

* repeated scanning of same angle,
* low angle diversity,
* high prediction error without improvement,
* map instability,
* fatigue ignored,
* no sleep transition,
* false confidence from single perspective.

Relevant KPIs:

```text
coverage
angle_diversity
revisit_count
PE_view
PE_EWMA_view
PE_AUC_mapping
learning_progress
fatigue_cycle_stability
```

`LOOK_AROUND` is simple but foundational.

The model should not skip it. If the agent cannot stabilize perception through looking, later movement, object interaction, caregiver search, caregiver guidance, category stabilization, and language become difficult to interpret.

Claim boundary:

```text
LOOK_AROUND ≠ conscious attention
scanning ≠ curiosity as felt interest
view prediction ≠ visual understanding
```

### 8.3 STEP_MOVEMENT

`STEP_MOVEMENT` is the first movement primitive.

It becomes available only after movement is unlocked through the genetic system. It should not exist in P0-mini.

`STEP_MOVEMENT` attempts a single local movement step.

A minimal schema:

```yaml
STEP_MOVEMENT:
  phase_min: P1
  requires:
    movement_enabled: true
    g_move: open
  inputs:
    - position
    - orientation
    - local_grid
    - predicted_next_cell
    - collision_risk
    - environmental_risk
    - instability
    - speed
    - motor_noise
    - prediction_confidence
    - discomfort
    - curiosity
    - fatigue
  outputs:
    - new_position
    - movement_result
    - collision_event
    - fall_or_near_fall_event_optional
    - PE_movement
    - DI_delta
```

Possible results:

```text
success
blocked
collision
uncertain
stuck
near_fall
fall_event
```

A successful movement event:

```json
{
  "t": 3500,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 10],
  "to": [10, 11],
  "expected": "free",
  "observed": "free",
  "result": "success",
  "PE_movement": 0.05,
  "DI_delta": 0.0
}
```

A blocked movement event:

```json
{
  "t": 3540,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 11],
  "to": [10, 12],
  "expected": "free",
  "observed": "blocked",
  "result": "collision",
  "PE_movement": 0.48,
  "DI_delta": 0.09
}
```

Movement may produce fall or near-fall events when speed, instability, fatigue, motor noise, low prediction confidence, or environmental risk cross configured thresholds.

A fall or near-fall event may be represented as:

```json
{
  "t": 3620,
  "phase": "P1",
  "event": "fall_or_near_fall_event",
  "action": "STEP_MOVEMENT",
  "movement_context": {
    "speed": 0.72,
    "instability": 0.56,
    "fatigue": 0.61,
    "motor_noise": 0.47,
    "prediction_confidence": 0.33,
    "environmental_risk": "edge_or_unstable_surface"
  },
  "result": "near_fall",
  "DI_delta": 0.18,
  "claim_level": "physical_risk_event"
}
```

Falls or near-falls may be implemented as physical-risk events. They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

The allowed formulation is:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

The forbidden formulations are:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

`STEP_MOVEMENT` supports:

* action-outcome learning,
* collision learning,
* discomfort regulation,
* fall or near-fall risk learning,
* topology formation,
* coverage expansion,
* movement prediction,
* and early Enactment development.

Movement should be damped by risk and discomfort.

A simplified selection relation:

```text
movement_score =
    curiosity
  + expected_information_gain
  − collision_risk
  − environmental_risk
  − discomfort
  − fatigue
  − instability
```

If discomfort is high, movement probability should fall:

```text
if DI > θ_DI:
    reduce STEP_MOVEMENT probability
    increase safe-path bias
    increase rest or caregiver-seeking if available
```

The primitive should also distinguish between potential and actual enactment:

```text
E_pot: STEP_MOVEMENT available
E_act: STEP_MOVEMENT actually executed
```

This matters for MIP.

Possible failure modes:

* repeated collisions,
* fall or near-fall events ignored,
* movement into unknown cells without risk control,
* avoidance of all movement despite stable mapping,
* excessive movement without map update,
* topology created too early,
* failure to distinguish blocked from unknown,
* interpreting fall or near-fall as pain, fear, or shame.

Relevant KPIs:

```text
movement_success_rate
collision_count
fall_or_near_fall_count
DI_mean
movement_PE_AUC
path_prediction_accuracy
unknown_region_entry_rate
stuck_count
E_pot
E_act
```

Claim boundary:

```text
movement ≠ autonomy in the moral sense
collision discomfort ≠ pain
fall / near-fall ≠ pain or fear
risk avoidance ≠ fear
successful movement ≠ agency maturity
```

### 8.4 EXPLORE_ROOM

`EXPLORE_ROOM` is a compound exploratory primitive.

It becomes available after basic movement has opened. It uses `STEP_MOVEMENT` internally but adds target selection based on curiosity, uncertainty, safety, and learning progress.

Its purpose is to let the agent expand its map and discover room structure without requiring mature planning.

A minimal schema:

```yaml
EXPLORE_ROOM:
  phase_min: P1
  requires:
    movement_enabled: true
    g_move: open
  inputs:
    - occupancy_grid
    - unknown_regions
    - PE_map
    - learning_progress
    - collision_risk
    - environmental_risk
    - fatigue
    - discomfort
    - curiosity
  outputs:
    - target_region
    - movement_sequence
    - map_updates
    - topology_candidates
    - PE_exploration
    - risk_events_optional
```

The target should be selected from nearby reachable regions, not arbitrary global goals.

A simple target rule:

```text
target_region =
    argmax(
        information_gain
      + reducible_prediction_error
      + novelty
      − risk
      − distance_cost
      − fatigue_cost
    )
```

`EXPLORE_ROOM` should prefer:

* under-mapped regions,
* cells with low revisit count,
* safe unknown boundaries,
* regions with positive learning progress,
* and viewpoints that increase angle diversity.

It should avoid:

* high collision-risk areas,
* high fall or near-fall risk,
* repeated dead ends,
* regions with chaotic PE and no learning progress,
* excessive distance,
* and behavior that violates phase constraints.

An exploration event:

```json
{
  "t": 4800,
  "phase": "P1",
  "action": "EXPLORE_ROOM",
  "target_region": [14, 8],
  "reason": {
    "information_gain": 0.62,
    "collision_risk": 0.18,
    "LP": 0.07
  },
  "steps_attempted": 6,
  "steps_successful": 5,
  "new_cells_observed": 11,
  "PE_exploration": 0.24
}
```

`EXPLORE_ROOM` supports:

* coverage growth,
* topology discovery,
* action-outcome coherence,
* curiosity regulation,
* safe novelty seeking,
* and phase progression.

It also creates conditions for door discovery. A door should not become a topology element after one observation. Repeated exploration and traversal are required.

Possible failure modes:

* wandering without information gain,
* repeated unsafe exploration,
* ignoring fall or near-fall risk,
* map instability,
* failure to rest,
* over-prioritizing novelty,
* under-prioritizing stable consolidation,
* premature topology creation.

Relevant KPIs:

```text
coverage_delta
new_cells_per_step
exploration_efficiency
collision_count
fall_or_near_fall_count
PE_AUC_exploration
LP_exploration
angle_diversity_gain
topology_candidate_count
fatigue_regulation
```

Claim boundary:

```text
exploration ≠ intentional adventure
room discovery ≠ human concept of home
target selection ≠ mature planning
curiosity-driven exploration ≠ felt interest
risk-aware slowing ≠ fear
```

`EXPLORE_ROOM` is a controlled bridge from local movement to structured spatial development.

### 8.5 INTERACT_OBJECT

`INTERACT_OBJECT` becomes available after object interaction is unlocked.

It should not be active before the agent can reliably approach, perceive, and distinguish objects. Object interaction requires stable perception and movement.

A minimal schema:

```yaml
INTERACT_OBJECT:
  phase_min: P2a
  requires:
    g_objects: open
    object_candidate_visible: true
    approach_possible: true
  inputs:
    - object_id
    - object_state
    - object_fragility
    - action_type
    - force
    - timing
    - motor_noise
    - object_interest
    - satiation
    - affinity
    - predicted_object_outcome
    - prediction_confidence
    - fatigue
    - discomfort
    - distress
    - caregiver_boundary_optional
    - caregiver_signal_optional
  outputs:
    - object_state_change
    - interaction_result
    - PE_object
    - mastery_delta
    - satiation_delta
    - affinity_delta_optional
    - object_damage_event_optional
    - near_damage_event_optional
    - interaction_quality_trace_optional
```

Possible interaction types:

```text
touch
push
pull
roll
shake
approach
withdraw
hold
give
```

Early interactions should be very simple. The system should not begin with rich tool use or social play.

A first interaction event:

```json
{
  "t": 7200,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "unknown",
  "observed": "roll",
  "PE_object": 0.58,
  "self_caused": true
}
```

A later mastered interaction:

```json
{
  "t": 8100,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "roll",
  "observed": "roll",
  "PE_object": 0.08,
  "mastery_delta": 0.05,
  "satiation_delta": 0.04,
  "self_caused": true
}
```

`INTERACT_OBJECT` supports:

* object function discovery,
* object mastery,
* self-caused consequence attribution,
* interaction-quality learning,
* satiation,
* preference cycles,
* attachment-relevant object history,
* toy-missing,
* protolanguage,
* and diary-relevant object episodes.

The primitive should update several structures:

```text
object predictability
object mastery
object interest
satiation[obj]
affinity[obj] if applicable
success log
prediction model
interaction-quality trace if relevant
```

Object interest may guide selection:

```text
object_score =
    novelty
  + reducible_object_PE
  + affinity
  − satiation
  − risk
  − fatigue
```

If the object is attachable, repeated stabilizing interaction may increase affinity:

```text
affinity[obj] ↑ after repeated positive or comfort-linked interaction
```

But affinity should not rise after every interaction. It should depend on salience, success, regulation, and history.

Object interaction may also produce accidental damage when force, timing, motor noise, fatigue, distress, low prediction confidence, or weak object mastery cross configured thresholds.

A damage-relevant interaction may be represented as:

```json
{
  "t": 8800,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "block_1",
  "action": "push",
  "self_caused": true,
  "avoidable": true,
  "parameter_trace": {
    "force": 0.82,
    "timing": "abrupt",
    "motor_noise": 0.43,
    "fatigue": 0.58,
    "distress": 0.31,
    "prediction_confidence": 0.29,
    "object_fragility": 0.76,
    "object_mastery": 0.22
  },
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

A near-damage event may be represented as:

```json
{
  "t": 8840,
  "phase": "P2a",
  "event": "near_damage_event",
  "object_id": "cup_1",
  "action": "hold",
  "self_caused": true,
  "parameter_trace": {
    "force": 0.69,
    "timing": "unstable",
    "motor_noise": 0.38,
    "fatigue": 0.44,
    "prediction_confidence": 0.33,
    "object_fragility": 0.82
  },
  "claim_level": "interaction_quality_risk_trace"
}
```

Damage is not automatically learning. A damage or near-damage trace becomes developmentally relevant only when later comparable contexts show measurable action adjustment.

Possible failure modes:

* object obsession,
* no satiation,
* premature attachment,
* object naming too early,
* interaction without prediction update,
* failure to log self-caused consequences,
* accidental damage treated as guilt or punishment,
* overgeneralizing one object function to all objects.

Relevant KPIs:

```text
object_interaction_count
object_PE_AUC
object_mastery
interaction_success_rate
satiation[obj]
affinity[obj]
self_caused_consequence_rate
object_damage_count
near_damage_count
damage_adjustment_rate
interaction_quality_trend
preference_shift_rate
```

Claim boundary:

```text
object interaction ≠ human play
object preference ≠ felt liking
object affinity ≠ love
object damage response ≠ guilt
object damage ≠ punishment
self-caused consequence ≠ moral responsibility
careful object handling ≠ moral obedience
```

`INTERACT_OBJECT` is the behavioral bridge from spatial action to functional object understanding.

### 8.6 SEARCH_CAREGIVER

`SEARCH_CAREGIVER` becomes available only after caregiver dynamics and contact need exist.

It should not be active in P0-mini. It should not be active before the system can distinguish caregiver presence, absence, and at least basic search-relevant spatial structure.

A minimal schema:

```yaml
SEARCH_CAREGIVER:
  phase_min: P2c
  requires:
    caregiver_enabled: true
    contact_need_enabled: true
    caregiver_model_exists: true
  inputs:
    - contact_need
    - separation_distress
    - caregiver_last_seen
    - topology_graph
    - distress
    - fatigue
    - discomfort
    - caregiver_reliability
    - comfort_prediction
    - contact_ambivalence
    - avoidance_tendency
  outputs:
    - search_path_or_orientation
    - caregiver_found
    - reunion_event_optional
    - comfort_event_optional
    - distress_delta
    - contact_delta
```

Search may begin very simply.

Early `SEARCH_CAREGIVER` may mean:

```text
turn toward last seen caregiver location
move toward last seen caregiver location
scan known caregiver-relevant regions
remain near familiar caregiver area
```

It should not require mature theory of mind, symbolic reasoning, or social interpretation.

A caregiver-search event:

```json
{
  "t": 15100,
  "phase": "P2c",
  "action": "SEARCH_CAREGIVER",
  "caregiver_id": "caregiver_1",
  "reason": {
    "contact_need": 0.74,
    "separation_distress": 0.68,
    "distress": 0.61
  },
  "last_seen": [4, 6],
  "result": "not_found"
}
```

A reunion event:

```json
{
  "t": 15380,
  "phase": "P2c",
  "event": "caregiver_reunion",
  "caregiver_id": "caregiver_1",
  "distress_before": 0.71,
  "distress_after": 0.26,
  "contact_before": 0.78,
  "contact_after": 0.21,
  "comfort_event": true
}
```

`SEARCH_CAREGIVER` supports:

* contact regulation,
* separation distress,
* reunion salience,
* caregiver reliability estimation,
* comfort prediction,
* comfort-after-loss,
* attachment formation,
* missing dynamics,
* and later functional love-like patterns.

Search should be modulated by topology. The agent should search more effectively in known regions than in unknown regions.

A simple search score:

```text
search_target_score(region) =
    caregiver_last_seen_weight
  + caregiver_presence_history
  + accessibility
  − risk
  − distance
  − fatigue
```

If search repeatedly fails, the system may update caregiver expectation:

```text
temporary absence
→ delayed return
→ failed reunion
→ possible recontextualization later
```

This does not immediately imply permanent absence. Permanent absence requires repeated failed expectation and later recontextualization.

Caregiver-response history may also modulate search. Inconsistent comfort, non-response, or misattunement may increase contact ambivalence or avoidance tendency. This remains a functional regulation pattern, not a trauma, fear, or felt rejection claim.

Possible failure modes:

* searching without caregiver model,
* excessive search after minor absence,
* no search despite high separation distress,
* search overriding all exploration,
* failure to distinguish temporary absence from permanent absence,
* caregiver always functioning as perfect distress solution,
* caregiver non-response being described as felt abandonment.

Relevant KPIs:

```text
caregiver_search_count
search_success_rate
time_to_reunion
distress_recovery_time
contact_reduction_after_reunion
caregiver_reliability
comfort_prediction
contact_ambivalence
avoidance_tendency
separation_distress_frequency
failed_reunion_count
```

Claim boundary:

```text
caregiver search ≠ felt longing
reunion relief ≠ felt joy
separation distress ≠ abandonment experience
caregiver reliability ≠ trust in the full human sense
caregiver non-response ≠ felt rejection
```

`SEARCH_CAREGIVER` is a functional behavior primitive for attachment-relevant regulation.

### 8.7 SLEEP

`SLEEP` is available from P0-mini onward.

It is one of the first behavior primitives because development requires interruption, recovery, and limited consolidation. The agent should not explore continuously. Activity must be paced.

`SLEEP` is triggered primarily by fatigue, but it may also be influenced by discomfort, distress, low learning progress, high prediction-error load, interaction-quality degradation, low external stimulation load, low task pressure, replay pressure, or phase-specific recovery needs.

A minimal schema:

```yaml
SLEEP:
  phase_min: P0-mini
  requires:
    fatigue_system_enabled: true
  inputs:
    - fatigue
    - recent_activity
    - prediction_error_load
    - external_stimulation_load_optional
    - task_pressure_optional
    - learning_progress_plateau_optional
    - replay_buffer_candidate_count_optional
    - replay_pressure_optional
    - rest_bias
    - distress_optional
    - discomfort_optional
    - interaction_quality_trace_optional
    - sleep_threshold
  outputs:
    - fatigue_reduction
    - replay_events
    - consolidation_trace
    - internal_state_update
```

A rest-like `SLEEP` bias may be represented as:

```yaml
rest_like_sleep_bias:
  condition_type: soft_bias
  may_increase_sleep_probability_when:
    external_stimulation_load_below: phase_relative_threshold
    task_pressure_below: phase_relative_threshold
    learning_progress_plateau: true
    replay_buffer_candidates_above: 0
    phase_allows_replay_scope: true
  does_not:
    - force_sleep
    - open_gates
    - install_categories
    - bypass_phase_constraints
    - create_unlogged_state_change
    - claim_DMN_equivalence
```

This bias only affects the probability of entering a bounded recovery or replay window. It does not create replay content and does not license any claim of inner experience.

In P0-mini, the basic cycle is:

```text
LOOK_AROUND
→ mapping update
→ prediction error
→ fatigue rises
→ SLEEP
→ limited replay/consolidation
→ fatigue falls
→ LOOK_AROUND
```

Sleep should reduce fatigue:

```text
N_fat(t+1) =
    N_fat(t) − sleep_recovery_rate
```

It may also support limited replay through the imagination buffer:

```text
select recent salient traces
→ replay short sequence
→ update prediction stability
→ mark consolidation
```

In early phases, sleep replay should remain minimal.

It may consolidate:

* grid snapshots,
* prediction errors,
* mapping improvements,
* movement outcomes,
* collision events,
* fall or near-fall events,
* object interaction outcomes,
* object-damage or near-damage traces,
* caregiver guidance traces,
* caregiver comfort traces,
* misattunement candidates,
* and later category-stabilization traces.

A sleep event:

```json
{
  "t": 2200,
  "phase": "P0-mini",
  "action": "SLEEP",
  "fatigue_before": 0.82,
  "fatigue_after": 0.31,
  "replay_events": 4,
  "consolidated_scope": "mapping"
}
```

In later phases, sleep may replay more complex traces:

```json
{
  "t": 18200,
  "phase": "P2c",
  "action": "SLEEP",
  "fatigue_before": 0.77,
  "fatigue_after": 0.28,
  "replay_events": [
    "toy_missing",
    "caregiver_search",
    "comfort_after_loss",
    "caregiver_guidance_event",
    "category_stabilization_event"
  ],
  "distress_before": 0.42,
  "distress_after": 0.35
}
```

Sleep should not become a hidden training stage that solves development off-screen. Replay must remain limited, logged, and inspectable.

Sleep may support consolidation of caregiver guidance or category signals, but it must not install concepts without trace-backed recurrence.

For example:

```text
caregiver signal "careful"
+ object fragility context
+ later lower force
+ repeated trace comparison
→ category candidate may stabilize
```

Not:

```text
one sleep replay
→ full concept of carefulness
```

Possible failure modes:

* no sleep despite high fatigue,
* sleep triggered too often,
* low external stimulation forces sleep instead of softly biasing it,
* rest-like replay starts without trace-backed replay candidates,
* sleep erases distress too easily,
* replay becomes an unbounded optimizer,
* replay fixates on the same cluster without cooldown,
* consolidation changes structures without trace,
* sleep bypasses phase gates,
* sleep converts single caregiver words into concepts,
* replay converts object damage into guilt,
* replay converts misattunement into trauma,
* replay converts fall or near-fall into pain or fear,
* rest-like replay is described as Default Mode Network activity,
* low external stimulation is described as introspection.

Relevant KPIs:

```text
sleep_frequency
mean_sleep_duration
fatigue_reduction_rate
replay_event_count
rest_like_replay_count
rest_like_replay_trigger_validity
replay_fixation_rate
post_sleep_PE_change
post_sleep_distress_change
post_sleep_interaction_quality_change
sleep_cycle_stability
phase_leakage_count
unsupported_rest_like_replay_claim_count
```

Claim boundary:

```text
sleep ≠ biological sleep
replay ≠ subjective dreaming
fatigue reduction ≠ felt rest
dream-like consolidation ≠ conscious dream experience
rest-like replay ≠ Default Mode Network
low external stimulation ≠ introspection
replay feedback ≠ self-reflection
post-sleep improvement ≠ insight
guidance replay ≠ moral learning
object-damage replay ≠ guilt
fall / near-fall replay ≠ pain or fear
misattunement replay ≠ trauma
```

`SLEEP` is a recovery and consolidation primitive, not evidence of inner experience.

### 8.8 CRY/WEEP as Later Distress State

`CRY/WEEP` is a later visible distress state.

It should not be active in P0-mini, P0, P1, or early object phases. It becomes meaningful only when the system already contains distress, contact need, caregiver dynamics, and comfort response patterns.

`CRY/WEEP` is not a claim of felt suffering.

It is a behavioral expression of high unresolved distress.

A minimal schema:

```yaml
CRY_WEEP:
  phase_min: P2c_or_later
  requires:
    distress_system_enabled: true
    caregiver_enabled: true
    expression_channel_enabled: true
  inputs:
    - distress
    - separation_distress
    - toy_missing_distress
    - contact_need
    - failed_resolution_count
    - caregiver_presence
    - caregiver_reliability
    - comfort_prediction
    - fatigue
  outputs:
    - visible_distress_signal
    - caregiver_attention_event_optional
    - comfort_event_optional
    - misattunement_event_optional
    - contact_need_update
    - distress_trace
```

Possible triggers:

```text
distress > θ_cry
separation_distress > θ_sep_cry
toy_missing_distress > θ_toy_cry
failed_resolution_count > θ_failure
```

A simple trigger rule:

```text
if distress high
and no successful regulation occurred
and expression channel is enabled:
    enter CRY/WEEP
```

A `CRY/WEEP` event:

```json
{
  "t": 16840,
  "phase": "P2c",
  "state": "CRY/WEEP",
  "trigger": "toy_missing",
  "distress": 0.78,
  "contact_need": 0.69,
  "caregiver_present": false
}
```

If the caregiver responds with comfort:

```json
{
  "t": 16920,
  "phase": "P2c",
  "event": "comfort_after_cry",
  "caregiver_id": "caregiver_1",
  "distress_before": 0.78,
  "distress_after": 0.39,
  "cry_state_ended": true
}
```

If the caregiver response is delayed, absent, inconsistent, or mismatched, the event should be logged functionally:

```json
{
  "t": 16980,
  "phase": "P2c",
  "event": "caregiver_misattunement_event",
  "context": "CRY/WEEP",
  "expected_response": "comfort_or_presence",
  "observed_response": "non_response",
  "distress_before": 0.78,
  "distress_after": 0.83,
  "comfort_prediction_delta": -0.08,
  "caregiver_reliability_delta": -0.05,
  "claim_level": "functional_response_mismatch"
}
```

`CRY/WEEP` supports:

* visible distress signaling,
* caregiver response loops,
* comfort-after-loss,
* attachment stabilization,
* distress recovery measurement,
* caregiver-response calibration,
* misattunement detection,
* and later diary-relevant traces.

It must not be overused. If every small disruption triggers crying, the system becomes unstable and socially overdependent. If crying never occurs despite high unresolved distress, caregiver regulation may remain invisible.

Possible failure modes:

* crying too early in development,
* crying without distress model,
* crying as reward-seeking shortcut,
* crying suppressing exploration,
* caregiver always solving distress perfectly,
* distress expression without traceable trigger,
* using crying language as suffering claim,
* using caregiver non-response as felt rejection claim,
* interpreting repeated mismatch as trauma.

Relevant KPIs:

```text
cry_frequency
cry_duration
trigger_distribution
caregiver_response_rate
distress_drop_after_cry
failed_comfort_after_cry
repeated_cry_without_resolution
caregiver_reliability_delta_after_cry
misattunement_candidate_rate
```

Claim boundary:

```text
CRY/WEEP ≠ felt crying
visible distress signal ≠ subjective suffering
comfort response ≠ felt consolation
absence of crying ≠ absence of distress
caregiver non-response ≠ felt abandonment
misattunement ≠ trauma
```

`CRY/WEEP` is a functional expression state, not evidence of phenomenal pain, grief, or suffering.

### 8.9 Finite State Machine

The early behavior layer can be implemented as a finite state machine.

This keeps behavior inspectable, phase-specific, and reproducible. The FSM should remain simple enough that state transitions can be logged and explained.

A minimal state set:

```text
LOOK_AROUND
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
SLEEP
CRY/WEEP
```

Not all states are active in all phases.

The FSM receives:

```text
phase
available capabilities
needs
fatigue
curiosity
contact
discomfort
distress
separation_distress
toy_missing_distress
risk
prediction error
learning progress
learning_progress_plateau
external stimulation load
task pressure
rest bias
replay pressure
replay buffer candidate count
object interest
object fragility
caregiver presence
caregiver guidance
caregiver boundary signal
category signal
interaction-quality trace
MIP nudge optional
```

The FSM outputs:

```text
selected state
action primitive
parameters
result
transition log
consequence trace if relevant
```

A simplified transition structure:

```yaml
fsm:
  current_state: LOOK_AROUND

  transitions:
    - from: LOOK_AROUND
      to: SLEEP
      when:
        any:
          - fatigue_above: 0.80
          - rest_like_sleep_bias:
              external_stimulation_load_below: 0.20
              task_pressure_below: 0.25
              learning_progress_below: 0.05
              replay_buffer_candidates_above: 0
              phase_allows_replay_scope: true
      constraint:
        transition_type: bounded_soft_transition

    - from: LOOK_AROUND
      to: STEP_MOVEMENT
      when:
        phase_at_least: P1
        g_move: open
        curiosity_high: true
        risk_below: 0.40

    - from: STEP_MOVEMENT
      to: EXPLORE_ROOM
      when:
        phase_at_least: P1
        exploration_target_available: true
        discomfort_below: 0.50

    - from: EXPLORE_ROOM
      to: INTERACT_OBJECT
      when:
        phase_at_least: P2a
        g_objects: open
        object_interest_high: true

    - from: INTERACT_OBJECT
      to: SEARCH_CAREGIVER
      when:
        phase_at_least: P2c
        distress_high: true
        caregiver_enabled: true

    - from: SEARCH_CAREGIVER
      to: CRY/WEEP
      when:
        phase_at_least: P2c
        distress_above: 0.80
        caregiver_not_found: true

    - from: CRY/WEEP
      to: SLEEP
      when:
        fatigue_high: true
        distress_below_critical: true
```

The FSM should not be interpreted as a full mind. It is an action-selection scaffold.

A state transition log:

```json
{
  "t": 18420,
  "phase": "P2c",
  "from_state": "SEARCH_CAREGIVER",
  "to_state": "CRY/WEEP",
  "trigger": {
    "distress": 0.84,
    "separation_distress": 0.79,
    "caregiver_found": false
  }
}
```

The FSM should include priority rules.

For example:

```text
critical discomfort overrides curiosity
extreme fatigue increases SLEEP probability
low external stimulation + low task pressure may increase rest bias
learning progress plateau + replay candidates may increase bounded SLEEP probability
high separation distress biases SEARCH_CAREGIVER
high toy-missing biases object search or caregiver search
low risk + positive learning progress biases exploration
caregiver signal "careful" may reduce force or speed when trace-grounded
caregiver boundary may interrupt or redirect when risk-relevant
object fragility may slow interaction
```

The FSM may produce interaction-quality traces when actions occur under risk, fragility, fatigue, distress, low prediction confidence, or caregiver boundary signals.

Example:

```json
{
  "t": 18880,
  "phase": "P2a",
  "from_state": "INTERACT_OBJECT",
  "to_state": "INTERACT_OBJECT",
  "transition_modifier": "caregiver_guidance",
  "signal": "careful",
  "effect": {
    "force_delta": -0.18,
    "timing": "slower"
  },
  "claim_level": "functional_behavior_modulation"
}
```

The FSM must avoid rigid determinism. It may use weighted selection, but all weights must remain inspectable.

A simple scoring form:

```text
score(state) =
    need_bias
  + prediction_bias
  + phase_bias
  + rest_bias_if_trace_backed
  + caregiver_signal_bias_if_grounded
  + category_signal_bias_if_trace_backed
  − risk_penalty
  − fatigue_penalty
  + optional_MIP_nudge
```

The selected state may be:

```text
argmax(score(state))
```

or sampled from a bounded distribution.

The FSM supports reproducibility because transitions can be replayed under fixed seeds.

Possible failure modes:

* hidden planner inside FSM,
* state explosion,
* phase-incompatible state selection,
* no trace for transitions,
* distress states overriding all development,
* curiosity states ignoring risk,
* rest bias becoming a hidden controller,
* low external stimulation forcing replay without candidates,
* caregiver signal acting as ungrounded command,
* object damage being interpreted as guilt,
* fall or near-fall being interpreted as pain or fear,
* MIP nudges becoming commands.

Claim boundary:

```text
FSM state ≠ mental state
state transition ≠ conscious decision
weighted selection ≠ free will
behavior trace ≠ subjective intention
rest-biased transition ≠ introspection
rest-like replay transition ≠ Default Mode Network activation
caregiver-guided transition ≠ moral obedience
MIP nudge ≠ controller command
```

The FSM is a transparent implementation scaffold for staged behavior.

### 8.10 Phase-Specific FSM States

The FSM state set expands across phases.

Each phase activates only the behavior states that its developmental structure can support.

#### P0-mini

Active states:

```text
LOOK_AROUND
SLEEP
```

Disabled states:

```text
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
CRY/WEEP
```

P0-mini tests whether the agent can stabilize mapping and prediction without movement, objects, caregiver dynamics, language, distress, caregiver guidance, category stabilization, or interaction-quality learning.

Typical loop:

```text
LOOK_AROUND
→ SLEEP
→ LOOK_AROUND
```

#### P0

Active states may include:

```text
LOOK_AROUND
SLEEP
```

Curiosity may become more explicit, but movement remains disabled unless the phase design opens it.

The focus remains mapping, prediction, fatigue, and early MIP logging.

#### P1

Active states:

```text
LOOK_AROUND
STEP_MOVEMENT
EXPLORE_ROOM
SLEEP
```

New concerns:

* movement prediction,
* collision,
* discomfort,
* fall or near-fall events,
* topology candidates,
* unknown-region exploration,
* safe navigation.

Typical loop:

```text
LOOK_AROUND
→ STEP_MOVEMENT
→ EXPLORE_ROOM
→ SLEEP
```

#### P2a

Active states:

```text
LOOK_AROUND
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SLEEP
```

New concerns:

* object discovery,
* object function prediction,
* object mastery,
* self-caused consequences,
* accidental damage or near-damage,
* early interaction-quality learning,
* object fragility,
* force and timing modulation,
* early satiation.

#### P2b

Same as P2a, with stronger object preference and satiation dynamics.

Additional state-bias terms:

```text
object_interest
satiation
preference_shift
object_LP
object_fragility
interaction_quality_trace
```

#### P2c

Active states:

```text
LOOK_AROUND
STEP_MOVEMENT
EXPLORE_ROOM
INTERACT_OBJECT
SEARCH_CAREGIVER
SLEEP
CRY/WEEP optional
```

New concerns:

* contact need,
* caregiver presence,
* separation distress,
* toy-missing,
* comfort-after-loss,
* caregiver search,
* distress regulation,
* caregiver guidance,
* caregiver misattunement candidates,
* boundary learning,
* caregiver-response variability.

`CRY/WEEP` should be optional and phase-gated. It should be enabled only when visible distress expression is part of the experiment.

#### P2d

Adds minimal language-related behavior, but not as a primary FSM state unless the implementation explicitly includes communication acts.

Possible late additions:

```text
LABEL_OBJECT
RESPOND_LABEL
REQUEST_OBJECT
```

These may be kept inside the language layer rather than the basic FSM.

Caregiver signals such as “careful,” “soft,” “wait,” or “danger” may become behavior-relevant only if grounded in repeated embodied traces. They must not be treated as installed concepts.

#### P3+

The FSM may include simple planning, trace-backed category use, or role-sensitive behaviors, but only after the foundational states are stable.

Possible additions:

```text
PLAN_SIMPLE_SEQUENCE
HELP_CAREGIVER
AVOID_HARMFUL_ACTION
REPAIR_OBJECT
USE_CAREFUL_ACTION
WAIT_FOR_GUIDANCE
```

These should remain phase-gated and traceable.

#### P4+

Diary-related behavior may appear.

Possible additions:

```text
WRITE_DIARY_ENTRY
READ_PRIOR_DIARY
RECONSTRUCT_EPISODE
```

These are late reflection/externalization behaviors. Diary output requires minimal sentence formation, trace provenance, and controlled rendering.

#### P5

Caregiver transition becomes possible.

Possible additions:

```text
CARE_FOR_CHILD
COMFORT_CHILD
PROTECT_CHILD
ALLOW_EXPLORATION
BALANCE_RISK_SAFETY
GUIDE_WITHOUT_REJECTING
```

These must not appear before the agent has developed enough role, attachment, response-relation, trace continuity, and norm structure.

The phase rule is:

```text
No FSM state before its representational and motivational prerequisites exist.
```

A safe phase activation table:

```yaml
phase_fsm:
  P0-mini:
    active:
      - LOOK_AROUND
      - SLEEP

  P1:
    active:
      - LOOK_AROUND
      - STEP_MOVEMENT
      - EXPLORE_ROOM
      - SLEEP

  P2a:
    active:
      - LOOK_AROUND
      - STEP_MOVEMENT
      - EXPLORE_ROOM
      - INTERACT_OBJECT
      - SLEEP

  P2c:
    active:
      - LOOK_AROUND
      - STEP_MOVEMENT
      - EXPLORE_ROOM
      - INTERACT_OBJECT
      - SEARCH_CAREGIVER
      - SLEEP
      - CRY/WEEP

  P4_plus:
    active_optional:
      - WRITE_DIARY_ENTRY
      - RECONSTRUCT_EPISODE

  P5:
    active_optional:
      - CARE_FOR_CHILD
      - COMFORT_CHILD
      - PROTECT_CHILD
      - ALLOW_EXPLORATION
```

The table is an architectural guide, not a fixed final implementation.

Claim boundary:

```text
phase activation ≠ maturity proof
role-sensitive behavior ≠ moral personhood
diary behavior ≠ phenomenal selfhood
caregiver behavior ≠ felt love
careful action ≠ moral obedience
```

### 8.11 Risk, Discomfort, and Distress Modulation

Behavior selection is modulated by risk, discomfort, and distress.

These variables prevent the agent from behaving like a pure curiosity machine.

The basic distinction is:

```text
risk = predicted unsafe or unstable outcome
discomfort = physical risk-damping signal
distress = unresolved loss, separation, or disruption signal
```

Risk is prospective.
Discomfort and distress are internal state variables shaped by prior and current events.

#### Risk Modulation

Risk reduces action probability for unsafe movement or interaction.

A simple risk-modulated movement score:

```text
movement_score =
    curiosity
  + expected_information_gain
  − risk
  − discomfort
  − fatigue
```

High risk should reduce:

* movement into unknown regions,
* repeated collision attempts,
* movement under high instability,
* movement under high fall or near-fall probability,
* unsafe object interaction,
* high-force interaction with fragile objects,
* excessive exploration,
* and later overconfident caregiver behavior.

Movement may produce fall or near-fall events when speed, instability, fatigue, motor noise, low prediction confidence, or environmental risk cross configured thresholds.

A risk event may be logged as:

```json
{
  "t": 19620,
  "phase": "P1",
  "event": "fall_or_near_fall_event",
  "action": "STEP_MOVEMENT",
  "risk_context": {
    "speed": 0.70,
    "instability": 0.59,
    "fatigue": 0.63,
    "motor_noise": 0.48,
    "prediction_confidence": 0.30
  },
  "result": "near_fall",
  "claim_level": "physical_risk_event"
}
```

#### Discomfort Modulation

Discomfort especially affects physical action.

When DI is high:

```text
reduce STEP_MOVEMENT
reduce EXPLORE_ROOM
increase safe-path bias
increase rest probability
increase contact need if caregiver exists
increase observation before enactment
reduce speed or force
```

A simple rule:

```text
if DI > θ_high:
    suppress high-risk movement
    prefer SLEEP or safe stabilization
```

Discomfort should not shut down all behavior unless extreme. It should modulate action, not erase enactment.

Falls or near-falls may increase DI and alter later movement parameters. This remains physical-risk learning, not pain, fear, or shame.

#### Distress Modulation

Distress affects social, object-related, and recovery behavior.

When distress is high:

```text
increase SEARCH_CAREGIVER
increase CRY/WEEP probability if enabled
reduce exploration
increase comfort-seeking
increase salience of loss traces
increase sensitivity to caregiver response
```

A simple distress-modulated score:

```text
caregiver_search_score =
    contact_need
  + separation_distress
  + distress
  − fatigue
  − path_risk
```

Toy-missing may bias object search or caregiver search:

```text
if toy_missing_distress high:
    increase object_search_bias
    increase caregiver_search_bias
    reduce unrelated exploration
```

Distress may also influence object interaction quality. High distress combined with fatigue, motor noise, low prediction confidence, or weak object mastery may increase accidental object damage or near-damage.

Object interaction may produce accidental damage when force, timing, motor noise, fatigue, distress, low prediction confidence, or weak object mastery cross configured thresholds.

A damage-relevant modulation event may look like:

```json
{
  "t": 20100,
  "phase": "P2a",
  "event": "interaction_quality_degradation",
  "action": "INTERACT_OBJECT",
  "parameter_trace": {
    "force": 0.79,
    "timing": "abrupt",
    "motor_noise": 0.44,
    "fatigue": 0.57,
    "distress": 0.49,
    "prediction_confidence": 0.31,
    "object_mastery": 0.25
  },
  "possible_consequence": "near_damage",
  "claim_level": "functional_control_degradation"
}
```

#### Caregiver Guidance Modulation

Caregiver guidance may modulate behavior when caregiver relation, boundary logging, and risk or distress context exist.

Guidance may:

* interrupt an action,
* redirect exploration,
* slow movement,
* reduce force,
* scaffold object handling,
* delay access,
* protect an object,
* protect future interaction,
* or preserve safety.

A guidance-modulated behavior event may look like:

```json
{
  "t": 20540,
  "phase": "P2a",
  "event": "caregiver_guidance_event",
  "target_action": "INTERACT_OBJECT",
  "signal": "careful",
  "modulation": {
    "force_delta": -0.18,
    "timing": "slower",
    "observation_time_delta": 0.22
  },
  "context": {
    "object_fragility": 0.82,
    "prediction_confidence": 0.34
  },
  "claim_level": "functional_behavior_modulation"
}
```

Guidance is not punishment. Boundary is not rejection. Guidance uptake is not moral obedience.

#### Category-Signal Modulation

Caregiver signals such as “careful,” “soft,” “wait,” or “danger” may modulate behavior only when grounded in repeated embodied traces.

Examples:

```text
"careful"
+ fragile object
+ prior near-damage
+ later lower force
→ carefulness category candidate

"wait"
+ boundary signal
+ delayed enactment
+ reduced risk
→ wait / boundary category candidate

"danger"
+ edge or fall-risk context
+ slower approach
+ reduced near-fall rate
→ risk-attention category candidate
```

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

#### Interaction Between Modulators

Distress and discomfort may interact.

Example:

```text
collision
→ discomfort rises
→ repeated failure
→ distress rises
→ caregiver search becomes more likely
```

or:

```text
toy loss
→ toy_missing_distress rises
→ search object
→ failed search
→ contact need rises
→ search caregiver
```

Risk, caregiver guidance, and category signals may also interact:

```text
fragile object
→ caregiver signal "soft"
→ lower force
→ damage avoided
→ interaction-quality trace
→ category stabilization candidate
```

The behavior layer should log these modulations.

Example:

```json
{
  "t": 18820,
  "phase": "P2c",
  "selected_state": "SEARCH_CAREGIVER",
  "modulation": {
    "contact_need": 0.71,
    "separation_distress": 0.64,
    "toy_missing_distress": 0.38,
    "fatigue": 0.22,
    "risk": 0.18
  }
}
```

Possible failure modes:

* risk ignored,
* discomfort freezes all action,
* distress overrides all exploration,
* caregiver search becomes compulsive,
* toy-missing dominates all object behavior,
* comfort always resolves distress too perfectly,
* high distress without behavior effect,
* behavior effect without logged internal cause,
* caregiver guidance treated as punishment,
* category signal treated as concept insertion,
* object damage treated as guilt,
* fall or near-fall treated as pain or fear.

Relevant KPIs:

```text
risk_avoidance_rate
collision_reduction_after_DI
fall_or_near_fall_reduction_after_DI
exploration_suppression_after_distress
caregiver_search_after_separation
distress_recovery_time
comfort_response_effect
behavior_diversity_under_stress
guidance_uptake_rate
category_signal_grounding_rate
interaction_quality_adjustment_rate
```

Claim boundary:

```text
risk modulation ≠ fear
discomfort modulation ≠ pain avoidance
distress modulation ≠ suffering behavior
caregiver search under distress ≠ felt abandonment
caregiver guidance ≠ punishment
boundary modulation ≠ rejection
category signal ≠ concept by itself
carefulness ≠ moral obedience
object damage ≠ guilt
fall / near-fall ≠ pain or fear
```

Risk, discomfort, distress, caregiver guidance, and category signals are functional modulators of behavior selection.

### 8.12 Optional MIP Nudges

MIP nudges are optional, late, soft, and reversible.

They are not part of the basic behavior controller. They should not be active in P0-mini. In early phases, MIP should only observe and log.

A MIP nudge may become relevant only after the system has enough developmental trace data to detect stable asymmetries.

The MIP layer may observe patterns such as:

```text
high A/C but low E_act
high E_act but low A/C
high E_act and C but low R
persistent overprotection in caregiver role
persistent avoidance after distress
obsessive object interaction
repeated interaction-quality degradation
unresolved caregiver-response mismatch
category signal use without trace grounding
```

A nudge is a small bias, not a command.

Examples:

```text
slightly increase exploration probability
slightly reduce repeated object selection
slightly increase safe action opportunity
slightly mark caregiver overprotection
slightly increase rest after instability
slightly reduce force under repeated object-damage risk
slightly increase observation before fragile-object interaction
slightly bias away from ungrounded category-signal use
```

A safe nudge schema:

```yaml
mip_nudge:
  id: encourage_safe_action
  trigger:
    IA_pattern: A_high_C_high_E_low
    windows_persistent: 3
  effect:
    target: EXPLORE_ROOM
    bias_delta: 0.05
  constraints:
    reversible: true
    time_bounded: true
    risk_limit_respected: true
    does_not_open_locked_gates: true
```

A nudge for repeated object-damage risk may look like:

```yaml
mip_nudge:
  id: reduce_force_after_repeated_near_damage
  trigger:
    pattern: repeated_near_damage
    contexts_comparable: true
    self_caused_action_trace: true
    measurable_behavior_change_absent: true
  effect:
    target: INTERACT_OBJECT
    parameter_bias:
      force_delta: -0.05
      observation_time_delta: 0.05
  constraints:
    reversible: true
    time_bounded: true
    risk_limit_respected: true
    does_not_label_agent: true
    does_not_moralize_damage: true
```

The key constraints are:

```text
transparent
justified
time-bounded
reversible
```

These correspond to the T–J–TB–R guardrail.

A nudge may not:

* open a genetic gate directly,
* override phase constraints,
* force behavior,
* erase distress,
* suppress trace logging,
* define maturity by command,
* label the agent globally,
* moralize object damage,
* convert caregiver guidance into punishment,
* convert misattunement into trauma,
* convert fall or near-fall into pain or fear,
* or become a hidden controller.

For example:

```text
MIP may notice:
    A and C are high, but E_act remains low.

MIP may nudge:
    slightly increase safe exploration bias.

MIP may not:
    force movement,
    unlock movement if g_move is closed,
    or label the agent as immature.
```

A nudge log:

```json
{
  "t": 22400,
  "phase": "P2",
  "event": "MIP_nudge_applied",
  "nudge_id": "reduce_object_repetition",
  "trigger": "object_interaction_overconcentration",
  "bias_delta": -0.05,
  "target": "INTERACT_OBJECT:ball_1",
  "duration": 200,
  "reversible": true
}
```

A D-guarded nudge marker may look like:

```json
{
  "t": 22840,
  "phase": "P2a",
  "event": "MIP_D_guardrail_warning",
  "trigger": "repeated_low_risk_exploration_blocked",
  "possible_interpretation": "overcontrol_marker",
  "D_guardrail": [
    "guide_without_rejecting",
    "protect_without_freezing"
  ],
  "claim_level": "functional_interaction_quality_warning"
}
```

MIP nudges support developmental balance. They do not produce development by themselves.

Dignity-in-Practice may constrain whether a nudge is acceptable, but D is not a maturity score. It is a guardrail for interaction quality under asymmetry.

Possible failure modes:

* MIP becomes a controller,
* MIP opens gates directly,
* MIP moralizes behavior,
* MIP labels the agent globally,
* MIP nudges are not logged,
* nudges become permanent,
* nudges override safety or phase logic,
* nudges erase distress instead of preserving trace,
* D is treated as a performance score,
* interaction-quality traces are treated as moral worth.

Relevant KPIs:

```text
nudge_frequency
nudge_duration
nudge_reversibility
behavior_change_after_nudge
IA_pattern_change
interaction_quality_change_after_nudge
adverse_nudge_effects
gate_override_attempts
D_guardrail_warning_count
```

The safe formulation is:

```text
MIP nudges softly bias behavior selection under explicit constraints.
```

The unsafe formulation is:

```text
MIP controls the agent toward maturity.
```

The final rule is:

```text
MIP may observe, mark, compare, and gently rebalance.
MIP must not become the behavior controller.
```

Claim boundary:

```text
MIP nudge ≠ command
MIP marker ≠ diagnosis
MIP trajectory ≠ consciousness proof
MIP balancing ≠ maturity proof
D warning ≠ intrinsic worth ranking
```

### 8.13 Interaction Quality Learning

Interaction quality learning concerns how the agent’s actions affect objects, movement outcomes, caregiver boundaries, future risk, and later adjustment.

The agent may learn interaction quality through:

* successful use,
* degraded control,
* accidental damage,
* near-damage,
* caregiver guidance,
* caregiver boundary signals,
* fall or near-fall events,
* object fragility,
* movement risk,
* and future adjustment.

Interaction quality is not moral quality.

It is a trace-backed relation between action parameters, context, consequence, and later modulation.

The basic question is:

```text
Did the agent’s later behavior change in comparable contexts
after a self-caused or risk-relevant consequence trace?
```

A minimal interaction-quality trace should include:

```yaml
interaction_quality_trace:
  action_context:
    action: string
    phase: string
    object_id_optional: string
    movement_context_optional: string

  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility
    - movement_instability

  consequence_trace:
    - success
    - degraded_control
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary
    - caregiver_guidance

  future_adjustment:
    - lower_force
    - slower_movement
    - increased_observation
    - delayed_enactment
    - avoidance_of_high_risk_angle
    - improved_timing

  claim_level: functional_interaction_quality
```

A successful use trace may look like:

```json
{
  "t": 23120,
  "phase": "P2a",
  "event": "interaction_quality_adjustment",
  "action": "INTERACT_OBJECT",
  "object_id": "cup_1",
  "prior_context": {
    "object_fragility": 0.82,
    "prior_force": 0.76,
    "prior_outcome": "near_damage"
  },
  "current_context": {
    "object_fragility": 0.82,
    "current_force": 0.48,
    "timing": "slower"
  },
  "outcome": "stable_handling",
  "claim_level": "functional_action_quality_adjustment"
}
```

A movement-related interaction-quality trace may look like:

```json
{
  "t": 23500,
  "phase": "P1",
  "event": "interaction_quality_adjustment",
  "action": "STEP_MOVEMENT",
  "prior_context": {
    "speed": 0.72,
    "fatigue": 0.61,
    "motor_noise": 0.47,
    "prior_outcome": "near_fall"
  },
  "current_context": {
    "speed": 0.46,
    "fatigue": 0.58,
    "observation_time_delta": 0.21
  },
  "outcome": "stable_step",
  "claim_level": "functional_physical_risk_adjustment"
}
```

Interaction quality learning requires more than a single damage or risk event.

A causal learning candidate requires:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

If these conditions are absent, the system may log an event, but it should not claim interaction-quality learning.

The safe sequence is:

```text
self-caused action
→ parameter trace
→ consequence trace
→ comparable future context
→ measurable adjustment
→ interaction-quality learning candidate
```

Not:

```text
damage
→ guilt
```

Caregiver guidance may help stabilize interaction quality when it modulates action under trace-backed conditions:

```text
fragile object
+ caregiver signal "careful"
+ lower force
+ damage avoided
→ interaction-quality trace
```

Fall or near-fall events may also support interaction quality:

```text
unstable movement
+ near-fall
+ later slower movement
+ reduced instability
→ movement-risk adjustment trace
```

This remains physical-risk learning. It is not pain, fear, or shame.

Possible failure modes:

* damage treated as learning without later adjustment,
* caregiver guidance treated as punishment,
* object damage treated as guilt,
* fall or near-fall treated as pain or fear,
* carefulness treated as moral obedience,
* a single event becoming a stable category,
* interaction quality treated as moral worth.

Relevant KPIs:

```text
interaction_quality_trace_count
self_caused_consequence_rate
near_damage_count
object_damage_count
fall_or_near_fall_count
future_adjustment_rate
force_reduction_after_near_damage
speed_reduction_after_near_fall
guidance_uptake_rate
category_stabilization_after_guidance
```

Claim boundary:

```text
interaction quality ≠ moral worth
careful action ≠ moral obedience
damage avoidance ≠ moral virtue
object damage ≠ guilt
fall / near-fall ≠ pain or fear
caregiver guidance ≠ punishment
self-caused consequence ≠ moral responsibility
```

Interaction quality learning allows the system to modulate force, timing, risk, and future enactment without introducing moral or phenomenal claims.

### 8.14 Accidental Damage as Self-Caused Consequence Trace

Object damage is not punishment.

It is a self-caused consequence trace.

Accidental damage may occur when object interaction exceeds the current stability of the agent-object relation.

Relevant contributing factors include:

* force,
* timing,
* motor noise,
* fatigue,
* distress,
* low prediction confidence,
* weak object mastery,
* object fragility,
* poor approach angle,
* unstable grip,
* caregiver boundary absence,
* or insufficient observation before action.

A damage event may be represented as:

```json
{
  "t": 23840,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "cup_1",
  "action": "INTERACT_OBJECT",
  "interaction": "push",
  "self_caused": true,
  "avoidable": true,
  "parameter_trace": {
    "force": 0.84,
    "timing": "abrupt",
    "motor_noise": 0.46,
    "fatigue": 0.57,
    "distress": 0.34,
    "prediction_confidence": 0.28,
    "object_fragility": 0.81,
    "object_mastery": 0.19
  },
  "consequence": "damage",
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

The presence of `self_caused: true` means only that the consequence is linked to the agent’s own action trace. It does not mean guilt, blame, remorse, wrongdoing, punishment, moral learning, or moral responsibility.

The safe interpretation is:

```text
The agent’s action produced a traceable consequence
under identifiable parameters.
```

The unsafe interpretation is:

```text
The agent did something wrong and felt guilty.
```

Damage is not automatically learning.

A damage event becomes interaction-quality relevant only when the following conditions are available:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

Without comparable future context, the system may log damage but should not claim adjustment.

Without measurable behavior change, the system may log consequence but should not claim learning.

A valid adjustment sequence may look like:

```text
fragile object damaged
→ self-caused action trace recorded
→ parameter trace identifies high force and low prediction confidence
→ later comparable fragile-object context
→ force reduced and observation increased
→ damage avoided
→ interaction-quality adjustment candidate
```

A later adjustment event:

```json
{
  "t": 24420,
  "phase": "P2a",
  "event": "interaction_quality_adjustment",
  "source_trace": "object_damage_event",
  "object_class": "fragile_object",
  "comparable_future_context": true,
  "measurable_behavior_change": {
    "force_delta": -0.27,
    "observation_time_delta": 0.31,
    "timing": "slower"
  },
  "outcome": "damage_avoided",
  "claim_level": "functional_adjustment_after_consequence"
}
```

Caregiver guidance may intervene before or after damage.

Before damage:

```text
caregiver signal "soft"
+ fragile object
+ lower force
→ near-damage avoided
```

After damage:

```text
caregiver boundary
+ object_fragility_context
+ later lower force
→ boundary may become legible as guidance
```

This remains guidance and interaction-quality learning. It is not punishment.

A caregiver boundary after damage should be logged carefully:

```json
{
  "t": 24500,
  "phase": "P2a",
  "event": "caregiver_boundary_signal",
  "context": "object_damage_event",
  "signal": "stop",
  "function_candidate": "object_protection",
  "later_interpretation": "guidance_candidate",
  "claim_level": "functional_boundary_signal"
}
```

The core sentence is:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

Possible failure modes:

* logging damage without action parameters,
* treating all damage as avoidable,
* treating avoidable damage as guilt,
* caregiver boundary after damage described as punishment,
* damage automatically producing learning,
* no future context but learning claimed,
* no measurable adjustment but interaction-quality improvement claimed.

Relevant KPIs:

```text
object_damage_count
near_damage_count
self_caused_damage_rate
avoidable_damage_rate
parameter_trace_completeness
comparable_future_context_count
measurable_adjustment_after_damage
force_reduction_after_damage
damage_recurrence_rate
caregiver_boundary_after_damage_count
```

Claim boundary:

```text
object damage ≠ guilt
object damage ≠ punishment
self-caused consequence ≠ wrongdoing
avoidability ≠ moral blame
caregiver boundary after damage ≠ rejection
caregiver guidance after damage ≠ punishment
damage avoidance ≠ moral virtue
```

Accidental damage is useful because it creates traceable consequence structure. It must not be inflated into moral or phenomenal meaning.

### 8.15 Caregiver Guidance as Behavioral Modulator

Guidance may interrupt, redirect, slow, scaffold, or boundary an action without being treated as adverse care.

Caregiver guidance becomes behavior-relevant only after caregiver relation, caregiver signal logging, and relevant action contexts exist.

It should not be active in P0-mini.

Guidance may occur in contexts such as:

* fragile object interaction,
* high-force action,
* unstable movement,
* edge or fall-risk situation,
* repeated collision,
* toy damage risk,
* excessive distress-driven action,
* overfocused object interaction,
* or delayed enactment contexts.

A guidance event may modulate behavior by:

* lowering force,
* slowing movement,
* increasing observation,
* redirecting target,
* blocking temporarily,
* delaying access,
* offering alternative action,
* preserving object integrity,
* preserving future interaction,
* or reducing physical risk.

A caregiver guidance event:

```json
{
  "t": 25120,
  "phase": "P2a",
  "event": "caregiver_guidance_event",
  "source": "caregiver_1",
  "target_action": "INTERACT_OBJECT",
  "guidance_type": "lower_force",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82,
    "current_force": 0.74,
    "prediction_confidence": 0.34
  },
  "effect": {
    "action_slowed": true,
    "force_delta": -0.21,
    "observation_time_delta": 0.18
  },
  "claim_level": "functional_boundary_scaffold"
}
```

A movement-related guidance event:

```json
{
  "t": 25300,
  "phase": "P1",
  "event": "caregiver_guidance_event",
  "source": "caregiver_1",
  "target_action": "STEP_MOVEMENT",
  "guidance_type": "slow_or_wait",
  "signal": "wait",
  "context": {
    "environmental_risk": "edge_or_fall_risk",
    "speed": 0.68,
    "motor_noise": 0.39,
    "prediction_confidence": 0.32
  },
  "effect": {
    "action_delayed": true,
    "movement_speed_delta": -0.20
  },
  "claim_level": "functional_safety_scaffold"
}
```

Guidance should be evaluated by trace consequences, not by surface form alone.

A blocked action may later be recontextualized as benign guidance when the traces support it:

```yaml
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided

  confidence: medium
  reversible: partial
  phase: P2a
  claim_level: functional_boundary_recontextualization
```

Guidance must remain distinguishable from:

* overprotection,
* misattunement,
* adverse response,
* arbitrary blocking,
* and destabilizing interruption.

A simple interpretation matrix:

```yaml
caregiver_guidance_interpretation:
  benign_guidance:
    condition:
      - proportionate
      - legible
      - risk_appropriate
      - exploration_preserving
      - later_adjustment_available

  safety_boundary:
    condition:
      - high_risk_state
      - temporary_constraint
      - alternative_available

  overprotection_candidate:
    condition:
      - risk_low
      - exploration_repeatedly_blocked
      - autonomy_preservation_low

  misattunement_candidate:
    condition:
      - caregiver_response_mismatches_current_child_state
      - distress_or_contact_ambivalence_increases

  adverse_response_candidate:
    condition:
      - destabilizing
      - harsh
      - unreliable
      - avoidance_inducing_pattern
```

The D-guardrail for guidance is:

```text
guide without rejecting
protect without freezing
comfort without capture
explain without dominating
```

D is not a score assigned to the caregiver or agent. It is a guardrail for interaction quality under asymmetry.

Possible failure modes:

* treating all boundaries as punishment,
* treating all boundaries as benign guidance,
* caregiver guidance overriding phase gates,
* caregiver signal acting as ungrounded command,
* guidance suppressing exploration entirely,
* guidance producing overcontrol,
* MIP moralizing caregiver behavior,
* D used as caregiver-worth ranking.

Relevant KPIs:

```text
caregiver_guidance_event_count
guidance_uptake_rate
boundary_legibility
autonomy_preservation_marker
overcontrol_marker_count
misattunement_candidate_rate
later_adjustment_after_guidance
damage_avoidance_after_guidance
fall_or_near_fall_reduction_after_guidance
```

Claim boundary:

```text
guidance ≠ punishment
boundary ≠ rejection
guidance uptake ≠ moral obedience
caregiver boundary ≠ caregiver moral worth
overcontrol marker ≠ moral blame
D-guardrail ≠ intrinsic worth ranking
```

Caregiver guidance is a behavioral modulator. It can preserve safety, object integrity, future interaction, and developmental possibility without becoming moral discipline.

### 8.16 Caregiver Signals and Emerging Action Categories

Caregiver signals such as “careful,” “soft,” “wait,” or “danger” may modulate behavior only when grounded in repeated embodied traces.

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. These words do not create concepts by themselves. They may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, consequence traces, and later behavioral adjustment.

The caregiver word is not sufficient.

The concept stabilizes only through repeated coupling of:

* signal,
* embodied situation,
* consequence trace,
* comparable future context,
* and later action adjustment.

Examples:

```text
"careful" / "vorsicht"
→ lower force
→ slower movement
→ increased prediction attention
→ fragility context
→ fall/damage/risk avoidance

"soft" / "sanft"
→ reduced pressure
→ smoother timing
→ object preservation

"wait" / "warten"
→ delayed enactment
→ reduced risk
→ improved boundary learning

"danger" / "gefährlich"
→ increased risk attention
→ avoidance or slowed approach
```

Carefulness is a prototype action-quality category.

Carefulness may emerge from repeated coupling of:

```yaml
carefulness_category_inputs:
  caregiver_signal:
    examples:
      - careful
      - slow
      - soft
      - stop

  embodied_context:
    examples:
      - fragile_object
      - unstable_body_state
      - edge_or_fall_risk
      - high_force_action

  internal_state:
    examples:
      - fatigue
      - distress
      - motor_noise
      - prediction_uncertainty

  consequence_trace:
    examples:
      - near_fall
      - fall_event
      - object_damage
      - caregiver_boundary

  later_adjustment:
    examples:
      - lower_force
      - slower_movement
      - increased_observation
      - avoidance_of_high_risk_angle
```

A category-stabilization event may look like:

```json
{
  "t": 26040,
  "phase": "P2a",
  "event": "category_stabilization_event",
  "source": "caregiver_1",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82,
    "current_force": 0.74,
    "prediction_uncertainty": 0.41
  },
  "consequence_trace": "near_damage",
  "later_adjustment_required": true,
  "claim_level": "trace_backed_action_category_candidate"
}
```

A later action-category use may look like:

```json
{
  "t": 26820,
  "phase": "P2a",
  "event": "carefulness_category_use",
  "signal_history": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82
  },
  "action_adjustment": {
    "force_delta": -0.24,
    "movement_speed_delta": -0.19,
    "observation_time_delta": 0.28
  },
  "outcome": "damage_avoided",
  "claim_level": "functional_category_use"
}
```

A risk-related category candidate may emerge from movement traces:

```text
fast movement
+ fatigue
+ motor noise
+ near-fall
+ later slower movement
→ movement-risk category candidate
```

A fragility-related category candidate may emerge from object traces:

```text
high force
+ fragile object
+ near-damage or damage
+ caregiver signal "soft" or "careful"
+ later lower force
→ fragility category candidate
```

A boundary-related category candidate may emerge from caregiver guidance:

```text
blocked action
+ caregiver signal "wait"
+ risk or object fragility
+ later delayed enactment
+ damage or fall risk avoided
→ wait / boundary category candidate
```

These categories should not be installed as adult concepts. They should stabilize only through repeated trace-backed patterns across comparable contexts.

The model may learn relational qualities:

```text
this object is more fragile than that object
this movement pattern is riskier under fatigue
this caregiver boundary is increasingly recognized as guidance
this signal is more reliable in fragile-object contexts
```

These are learned relational hierarchies, not universal absolute thresholds.

Forbidden interpretations include:

```text
A > 0.7 means mature.
carefulness_score > X means moral obedience.
danger_signal means the agent became afraid.
object damage means the agent learned guilt.
```

The safe interpretation is:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Possible failure modes:

* caregiver word treated as concept by itself,
* “careful” treated as moral obedience,
* “danger” treated as felt fear,
* “soft” treated as moral care,
* category stabilization claimed after a single event,
* category signal used without embodied context,
* later action adjustment absent but concept claimed,
* caregiver signal overriding development rather than scaffolding it.

Relevant KPIs:

```text
category_stabilization_event_count
carefulness_category_candidate_count
category_signal_grounding_rate
later_adjustment_after_signal
fragility_discrimination_rate
movement_risk_discrimination_rate
boundary_legibility_after_signal
ungrounded_signal_use_count
```

Claim boundary:

```text
caregiver word ≠ concept by itself
category stabilization ≠ human semantic mastery
carefulness ≠ moral obedience
danger signal ≠ fear
fall / near-fall ≠ pain or fear
object damage ≠ guilt
soft handling ≠ moral care
```

Caregiver signals and emerging action categories provide a path from external scaffold to trace-backed behavioral modulation. They do not install mature concepts, moral obedience, or phenomenal understanding.

> Cross-reference:
> For the full treatment of discomfort, distress, attachment-like regulation, caregiver guidance, misattunement, boundary learning, carefulness, interaction quality, object-damage consequence traces, and fall / near-fall risk learning, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapter 7.
> This block uses those concepts only as behavior-layer dependencies and trace requirements.

> Cross-reference:
> For the full treatment of evaluation, ablations, KPIs, safety, reproducibility, and D-guarded interpretation of these behavior traces, see `05_MIP_KPIs_Dignity_Safety.md`, especially Chapter 16.
> This block defines the core behavior mechanisms; evaluation and safety interpretation remain owned by Block 05.

---

## Chapter 9 — Imagination Buffer and Dreaming

The imagination buffer is the agent’s trace substrate for recent and salient experience.

It stores selected fragments of perception, internal state, action, prediction error, object interaction, caregiver interaction, distress, comfort, risk events, consequence traces, guidance events, category-stabilization traces, and later diary-relevant episodes.

It is not a full autobiographical memory system at the beginning. It begins as a compact replay buffer and becomes richer only as the architecture develops.

The imagination buffer supports:

* short-term trace storage,
* salience marking,
* sleep replay,
* prediction consolidation,
* distress-relevant replay,
* object and caregiver episode retention,
* fall and near-fall replay as physical-risk traces,
* object-damage and near-damage replay as consequence traces,
* caregiver-guidance replay,
* misattunement-pattern replay,
* category-stabilization replay,
* interaction-quality replay,
* later counterfactual simulation,
* and eventually diary condensation.

The term **dreaming** is used functionally.

It refers to offline replay and recombination of stored traces during sleep or rest. It does not imply subjective dreaming, imagery, inner experience, felt memory, or phenomenal consciousness.

The safe formulation is:

```text
dreaming = offline replay and consolidation of selected traces
```

Not:

```text
dreaming = subjective dream experience
```

The developmental progression is:

```text
trace
→ salient trace
→ replayed trace
→ consolidated pattern
→ recontextualized trace cluster
→ episode cluster
→ diary candidate
→ later narrative reconstruction
```

Replay should follow the same global design discipline as the rest of the architecture:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The imagination buffer should store and replay only what is needed to support developmental continuity, consolidation, recontextualization, and later trace-backed reconstruction. It should not pre-script mature understanding, moral concepts, or phenomenal interpretation.

The active implementation-facing axis convention remains:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

D is not a normal fifth performance score. It functions as a guardrail for interaction quality under asymmetry. It constrains how replay, diary preparation, caregiver traces, adverse patterns, and consequence traces are described without turning them into intrinsic-worth rankings, moral-status claims, or inner-life claims.

The claim boundary is:

```text
replay ≠ subjective dreaming
trace consolidation ≠ felt memory
distress replay ≠ subjective suffering
comfort replay ≠ felt relief
object-damage replay ≠ guilt
fall / near-fall replay ≠ pain or fear
misattunement replay ≠ trauma
caregiver-guidance replay ≠ punishment
category replay ≠ concept insertion
diary preparation ≠ phenomenal selfhood
```

> Cross-reference:
> For the full treatment of language, diary thresholds, trace provenance, controlled rendering, and diary claim boundaries, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapter 13.
> This block uses diary preparation only as a replay and trace-continuity dependency.

> Cross-reference:
> For the full treatment of PMS projection, operator-readable traces, diary reduction, and VM-facing implementation boundaries, see `06_PMS_VM_Implementation_Spine.md`, especially Chapter 14.
> This block uses PMS only as a possible later projection layer; PMS is not an early internal agent structure.

> Cross-reference:
> For the full treatment of MIP trajectory interpretation, KPIs, Dignity-in-Practice guardrails, and safety evaluation, see `05_MIP_KPIs_Dignity_Safety.md`, especially Chapters 10 and 16.
> This block uses MIP only as observation, marking, trajectory context, and bounded guardrail support; MIP does not control replay or development.

### 9.1 Buffer Contents

The imagination buffer may store different types of traces depending on phase.

In P0-mini, contents are minimal:

```text
local grid snapshots
orientation
sensory observations
prediction errors
fatigue state
sleep/replay markers
```

In P1, movement-related traces are added:

```text
movement attempts
movement success/failure
collision events
discomfort changes
fall_or_near_fall_event
physical-risk damping changes
topology candidates
```

Falls or near-falls may be stored only as physical-risk events. They support discomfort/risk learning and can later contribute to categories such as carefulness, balance, speed, and danger.

Allowed:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

Not allowed:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

In P2, object and caregiver traces become possible:

```text
object interactions
object function surprises
object_damage_event
near_damage_event
interaction_quality_trace
satiation changes
affinity changes
toy-missing events
caregiver presence/absence
contact regulation
comfort events
failed comfort
delayed comfort
inconsistent caregiver response
caregiver guidance
caregiver boundary signals
caregiver misattunement candidates
separation distress
reunion events
category_stabilization_event
boundary_learning_event
```

In later phases, the buffer may store:

```text
role-relevant actions
response-relation-relevant consequence traces
core norm conflicts
counterfactual simulations
diary candidates
caregiver transition events
multi-generational traces
operator-compatible regularity candidates
```

The phrase **response-relation-relevant consequence trace** should be preferred over premature moral responsibility language. A self-caused consequence trace may become relevant to later R development, but it does not establish moral responsibility.

A general buffer entry may look like:

```json
{
  "t": 18420,
  "phase": "P2c",
  "location": [8, 5],
  "grid_snapshot_id": "grid_18420",
  "internal_state_id": "state_18420",
  "action": "SEARCH_CAREGIVER",
  "prediction_error": 0.18,
  "salient_event": "caregiver_reunion",
  "distress_before": 0.67,
  "distress_after": 0.29,
  "salience": 0.82,
  "claim_level": "functional_trace"
}
```

An interaction-quality buffer entry may look like:

```json
{
  "t": 22100,
  "phase": "P2a",
  "event": "interaction_quality_trace",
  "action": "INTERACT_OBJECT",
  "object_id": "cup_1",
  "parameter_trace": {
    "force": 0.77,
    "timing": "abrupt",
    "motor_noise": 0.41,
    "fatigue": 0.52,
    "distress": 0.28,
    "prediction_confidence": 0.33,
    "object_fragility": 0.82
  },
  "consequence_trace": "near_damage",
  "claim_level": "functional_interaction_quality_trace"
}
```

A category-stabilization buffer entry may look like:

```json
{
  "t": 22440,
  "phase": "P2a",
  "event": "category_stabilization_event",
  "source": "caregiver_1",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82,
    "current_force": 0.74,
    "prediction_uncertainty": 0.41
  },
  "consequence_trace": "near_damage",
  "later_adjustment_required": true,
  "claim_level": "trace_backed_action_category_candidate"
}
```

The buffer should not store everything forever. It should apply selection and compression.

Possible selection criteria:

* high prediction error,
* large prediction error drop,
* high learning progress,
* high distress,
* large distress drop,
* object function discovery,
* object damage or near-damage,
* fall or near-fall,
* caregiver absence,
* caregiver reunion,
* comfort after loss,
* failed comfort,
* inconsistent caregiver response,
* caregiver guidance,
* successful redirection,
* self-caused consequence,
* physical-risk event,
* boundary-learning event,
* category-stabilization event,
* interaction-quality adjustment,
* phase transition,
* recontextualization event,
* MIP-marked asymmetry,
* D-guardrail warning,
* later diary relevance.

The buffer should distinguish between:

```text
recent trace
salient trace
consolidated trace
recontextualization candidate
diary candidate
```

A possible trace status structure:

```yaml
trace:
  id: trace_18420
  status:
    recent: true
    salient: true
    consolidated: false
    recontextualization_candidate: false
    diary_candidate: false
```

The imagination buffer is therefore not merely storage. It is a developmental filter.

Its guiding rule is:

```text
Store enough to replay and reconstruct development,
but not so much that the system becomes opaque.
```

The buffer must not create mature meanings by storage alone. A caregiver word does not become a concept by being stored. Object damage does not become guilt by being stored. A fall does not become fear by being stored. A misattunement event does not become trauma by being stored.

The claim boundary is:

```text
stored trace ≠ subjective memory
salience ≠ felt importance
object damage trace ≠ guilt
fall / near-fall trace ≠ pain or fear
caregiver word trace ≠ concept by itself
misattunement trace ≠ trauma
```

### 9.2 Local Grid Snapshots

Local grid snapshots preserve the agent’s spatial model at a given moment.

They are especially important in P0-mini and P1, where the main developmental task is mapping and prediction.

A local grid snapshot may include:

* visible cells,
* cell types,
* confidence values,
* angle of observation,
* revisit counts,
* angle diversity,
* local prediction error,
* and later movement-risk context if movement exists.

A minimal snapshot:

```json
{
  "snapshot_id": "grid_0520",
  "t": 520,
  "phase": "P0-mini",
  "position": [10, 10],
  "orientation": 90,
  "observed_cells": [
    {
      "cell": [10, 11],
      "type": "free",
      "confidence": 0.68
    },
    {
      "cell": [10, 12],
      "type": "wall",
      "confidence": 0.74
    }
  ],
  "coverage": 0.31,
  "angle_diversity_mean": 0.22,
  "PE_view": 0.27
}
```

Local grid snapshots support replay.

During sleep, the system may replay a sequence such as:

```text
orientation 0°
→ observed wall pattern
→ rotate to 45°
→ predicted new view
→ observed new view
→ PE update
```

This helps consolidate early mapping without adding movement, objects, caregiver dynamics, or language.

A replay entry:

```json
{
  "t": 780,
  "phase": "P0-mini",
  "event": "sleep_replay",
  "source_snapshot": "grid_0520",
  "scope": "local_mapping",
  "PE_before": 0.27,
  "PE_after": 0.21,
  "claim_level": "functional_replay"
}
```

Grid snapshots also allow later reconstruction of how spatial understanding developed.

For example:

```text
unknown corner
→ repeated observation
→ stable wall classification
→ reduced prediction error
→ mapping success trace
```

In P1, local grid snapshots become linked to movement.

A movement-related snapshot may record:

```json
{
  "snapshot_id": "grid_4020",
  "t": 4020,
  "phase": "P1",
  "position": [11, 10],
  "orientation": 0,
  "previous_action": "STEP_MOVEMENT",
  "movement_result": "success",
  "new_cells_observed": 4,
  "PE_movement": 0.12
}
```

If the movement produced a risk event, the snapshot may include that relation:

```json
{
  "snapshot_id": "grid_4180",
  "t": 4180,
  "phase": "P1",
  "position": [12, 10],
  "previous_action": "STEP_MOVEMENT",
  "movement_result": "near_fall",
  "risk_context": {
    "speed": 0.70,
    "instability": 0.59,
    "fatigue": 0.63,
    "motor_noise": 0.48,
    "prediction_confidence": 0.30
  },
  "DI_delta": 0.18,
  "claim_level": "physical_risk_event"
}
```

Grid snapshots should remain local and inspectable. The buffer does not need to store the entire world at every timestep. It may store references, deltas, or selected patches.

A practical rule:

```text
store full snapshots at salient moments
store deltas for ordinary updates
```

Relevant salience triggers:

* high PE,
* large PE drop,
* map correction,
* new region discovery,
* first door discovery,
* collision,
* fall or near-fall,
* topology change,
* phase gate opening.

Claim boundary:

```text
grid snapshot ≠ visual memory in the human sense
replay of grid snapshot ≠ subjective imagery
spatial reconstruction ≠ conscious recollection
fall / near-fall snapshot ≠ pain or fear
```

Grid snapshots are functional map traces.

### 9.3 Internal State Snapshots

Internal state snapshots preserve the agent’s needs and regulatory variables at selected moments.

They allow later replay and interpretation of why an action occurred, why an event became salient, and how recovery unfolded.

A snapshot may include:

```text
curiosity
contact
fatigue
discomfort
distress
separation_distress
toy_missing_distress
mood
attachment_level
affinity
satiation
caregiver_reliability
comfort_prediction
guidance_predictability
boundary_legibility
contact_ambivalence
avoidance_tendency
overcontrol_sensitivity
carefulness_stability
fragility_category_strength
danger_category_strength
softness_category_strength
```

Not all variables exist in all phases.

In P0-mini, a state snapshot may include only:

```text
curiosity optional
fatigue
prediction load
sleep pressure
```

Example:

```json
{
  "state_id": "state_0520",
  "t": 520,
  "phase": "P0-mini",
  "needs": {
    "curiosity": 0.31,
    "fatigue": 0.44
  },
  "prediction_load": 0.27,
  "sleep_pressure": 0.36
}
```

In P2c, a richer snapshot may include:

```json
{
  "state_id": "state_18420",
  "t": 18420,
  "phase": "P2c",
  "needs": {
    "curiosity": 0.28,
    "contact": 0.76,
    "fatigue": 0.22
  },
  "discomfort": 0.08,
  "distress": 0.67,
  "separation_distress": {
    "caregiver_1": 0.71
  },
  "toy_missing_distress": {
    "blanket_1": 0.34
  },
  "caregiver_related_state": {
    "caregiver_reliability": 0.64,
    "comfort_prediction": 0.58,
    "guidance_predictability": 0.42,
    "boundary_legibility": 0.39,
    "contact_ambivalence": 0.21,
    "avoidance_tendency": 0.12,
    "overcontrol_sensitivity": 0.09
  },
  "category_related_state": {
    "carefulness_stability": 0.18,
    "fragility_category_strength": 0.24,
    "danger_category_strength": 0.11,
    "softness_category_strength": 0.16
  },
  "mood": {
    "valence_baseline": -0.12,
    "arousal_baseline": 0.43
  }
}
```

Internal state snapshots are crucial because action traces alone are insufficient.

For example, the same behavior may have different internal structure:

```text
SEARCH_CAREGIVER because contact need is high
SEARCH_CAREGIVER because distress is high
SEARCH_CAREGIVER because toy loss triggered comfort expectation
SEARCH_CAREGIVER because caregiver absence violated prediction
SEARCH_CAREGIVER because caregiver reliability is uncertain
SEARCH_CAREGIVER because failed comfort left disruption unresolved
```

Without internal state snapshots, these cases would look similar.

Internal state snapshots support:

* behavior explanation,
* replay,
* distress recovery measurement,
* comfort reliability estimation,
* caregiver-response calibration,
* attachment trajectory reconstruction,
* guidance predictability tracking,
* boundary legibility tracking,
* category-stability tracking,
* MIP sliding-window evaluation,
* diary condensation,
* and later PMS episode mapping as an external representation.

They also help distinguish between:

```text
external event
internal effect
behavioral response
recovery pattern
later adjustment
```

A comfort-related pair may look like:

```json
{
  "event": "comfort_after_loss",
  "state_before": {
    "distress": 0.72,
    "contact": 0.68,
    "comfort_prediction": 0.51
  },
  "state_after": {
    "distress": 0.37,
    "contact": 0.25,
    "comfort_prediction": 0.56
  },
  "distress_drop": 0.35,
  "claim_level": "functional_regulation_trace"
}
```

A misattunement-related pair may look like:

```json
{
  "event": "caregiver_misattunement_event",
  "state_before": {
    "distress": 0.68,
    "comfort_prediction": 0.58,
    "caregiver_reliability": 0.64,
    "contact_ambivalence": 0.21
  },
  "state_after": {
    "distress": 0.74,
    "comfort_prediction": 0.51,
    "caregiver_reliability": 0.59,
    "contact_ambivalence": 0.28
  },
  "claim_level": "functional_response_mismatch"
}
```

A category-related pair may look like:

```json
{
  "event": "carefulness_category_candidate_update",
  "state_before": {
    "carefulness_stability": 0.18,
    "fragility_category_strength": 0.24
  },
  "state_after": {
    "carefulness_stability": 0.23,
    "fragility_category_strength": 0.29
  },
  "evidence": [
    "caregiver_signal_careful",
    "object_fragility_context",
    "near_damage_trace",
    "later_lower_force"
  ],
  "claim_level": "trace_backed_action_category_candidate"
}
```

The claim boundary remains strict:

```text
internal state snapshot ≠ subjective feeling
distress value ≠ suffering
mood variable ≠ felt mood
attachment value ≠ felt love
caregiver reliability ≠ full human trust
contact ambivalence ≠ trauma
avoidance tendency ≠ emotional wound
carefulness stability ≠ moral obedience
category strength ≠ human semantic mastery
```

Internal state snapshots are functional records of regulatory variables.

### 9.4 Action and Prediction Error Traces

Action and prediction error traces connect behavior to expected and observed outcomes.

They are central to the imagination buffer because replay without action-outcome structure would be developmentally weak.

A trace may include:

* selected action,
* action parameters,
* force,
* timing,
* motor noise,
* fatigue or distress,
* prediction confidence,
* object fragility if relevant,
* movement instability if relevant,
* expected outcome,
* observed outcome,
* prediction error,
* PE_EWMA,
* PE_AUC window reference,
* learning progress,
* internal-state change,
* caregiver boundary if relevant,
* caregiver guidance if relevant,
* consequence trace if relevant,
* later adjustment if available,
* and whether the outcome was self-caused.

A minimal action trace:

```json
{
  "t": 3600,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 10],
  "to": [10, 11],
  "expected": "free",
  "observed": "free",
  "PE": 0.05,
  "self_caused": true
}
```

A failed action trace:

```json
{
  "t": 3650,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 11],
  "to": [10, 12],
  "expected": "free",
  "observed": "blocked",
  "PE": 0.48,
  "self_caused": true,
  "DI_delta": 0.09
}
```

A fall or near-fall action trace:

```json
{
  "t": 3720,
  "phase": "P1",
  "event": "fall_or_near_fall_event",
  "action": "STEP_MOVEMENT",
  "self_caused": true,
  "movement_context": {
    "speed": 0.72,
    "instability": 0.56,
    "fatigue": 0.61,
    "motor_noise": 0.47,
    "prediction_confidence": 0.33,
    "environmental_risk": "edge_or_unstable_surface"
  },
  "result": "near_fall",
  "DI_delta": 0.18,
  "claim_level": "physical_risk_event"
}
```

An object interaction trace:

```json
{
  "t": 7420,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "unknown",
  "observed": "roll",
  "PE": 0.58,
  "self_caused": true,
  "mastery_delta": 0.02
}
```

A later mastered trace:

```json
{
  "t": 8120,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "roll",
  "observed": "roll",
  "PE": 0.08,
  "self_caused": true,
  "mastery_delta": 0.05,
  "satiation_delta": 0.04
}
```

These traces support replay of learning progress:

```text
high PE
→ repeated interaction
→ falling PE
→ mastery increase
```

They also support consequence attribution.

The distinction `self_caused = true` matters for later response-relation development. A consequence that follows from the agent’s own action can later become MIP-relevant. It does not imply guilt, punishment, moral blame, wrongdoing, or moral responsibility.

A self-caused object-damage trace may look like:

```json
{
  "t": 9100,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "block_1",
  "action": "push",
  "self_caused": true,
  "avoidable": true,
  "parameter_trace": {
    "force": 0.82,
    "timing": "abrupt",
    "motor_noise": 0.43,
    "fatigue": 0.58,
    "distress": 0.31,
    "prediction_confidence": 0.29,
    "object_fragility": 0.76
  },
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

A near-damage trace may look like:

```json
{
  "t": 9180,
  "phase": "P2a",
  "event": "near_damage_event",
  "object_id": "cup_1",
  "action": "hold",
  "self_caused": true,
  "parameter_trace": {
    "force": 0.69,
    "timing": "unstable",
    "motor_noise": 0.38,
    "fatigue": 0.44,
    "prediction_confidence": 0.33,
    "object_fragility": 0.82
  },
  "claim_level": "interaction_quality_risk_trace"
}
```

Damage is not automatically learning.

A consequence trace becomes interaction-quality relevant only when the system can establish:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

A valid later adjustment trace may look like:

```json
{
  "t": 9800,
  "phase": "P2a",
  "event": "interaction_quality_adjustment",
  "source_trace": "object_damage_event",
  "object_class": "fragile_object",
  "comparable_future_context": true,
  "measurable_behavior_change": {
    "force_delta": -0.24,
    "observation_time_delta": 0.28,
    "timing": "slower"
  },
  "outcome": "damage_avoided",
  "claim_level": "functional_adjustment_after_consequence"
}
```

A caregiver-guided action trace may look like:

```json
{
  "t": 10120,
  "phase": "P2a",
  "event": "caregiver_guidance_event",
  "source": "caregiver_1",
  "target_action": "INTERACT_OBJECT",
  "signal": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82,
    "current_force": 0.74,
    "prediction_confidence": 0.34
  },
  "effect": {
    "force_delta": -0.21,
    "observation_time_delta": 0.18,
    "timing": "slower"
  },
  "claim_level": "functional_boundary_scaffold"
}
```

A category-relevant action trace may look like:

```json
{
  "t": 10420,
  "phase": "P2a",
  "event": "carefulness_category_use",
  "signal_history": "careful",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82
  },
  "action_adjustment": {
    "force_delta": -0.24,
    "movement_speed_delta": -0.19,
    "observation_time_delta": 0.28
  },
  "outcome": "damage_avoided",
  "claim_level": "functional_category_use"
}
```

Action and prediction error traces support later diary reconstruction.

A diary-like system may later summarize:

```text
At first, pushing the ball was surprising.
Later, repeated interaction made the rolling outcome more predictable.
```

This summary is derived from trace patterns. It is not a claim of subjective memory.

The buffer should mark especially replay-worthy action traces:

* high PE,
* large PE drop,
* first successful action,
* repeated failure,
* collision,
* fall or near-fall,
* self-caused object change,
* object damage,
* near-damage,
* object function discovery,
* caregiver search failure,
* reunion,
* comfort after distress,
* failed comfort,
* inconsistent caregiver response,
* caregiver guidance,
* successful redirection,
* boundary-learning event,
* category-stabilization event,
* interaction-quality adjustment.

The core sentence is:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

Claim boundary:

```text
action trace ≠ intention
prediction error trace ≠ surprise as felt experience
self-caused consequence ≠ guilt
self-caused consequence ≠ moral responsibility
self-caused consequence ≠ punishment
object damage ≠ wrongdoing
fall / near-fall ≠ pain or fear
caregiver guidance ≠ punishment
carefulness ≠ moral obedience
later narrative ≠ lived memory
```

Action and PE traces make learning reconstructable.

### 9.5 Salient Events

Salient events are traces selected for stronger retention, replay, comparison, recontextualization, or later condensation.

Not every event should become salient. Salience marks events that are developmentally important because they change prediction, internal state, attachment, caregiver-response calibration, risk modulation, interaction quality, category stabilization, phase structure, role structure, or diary relevance.

A salient event may be triggered by:

```text id="t91992"
large prediction error
large prediction error drop
new region discovery
door discovery
first successful movement
repeated collision
fall or near-fall
object function discovery
object damage
near-damage
interaction-quality degradation
interaction-quality adjustment
toy loss
caregiver absence
caregiver reunion
comfort after loss
failed comfort
delayed comfort
inconsistent caregiver response
caregiver non-response
caregiver guidance
gentle interruption
successful redirection
caregiver boundary signal
boundary-learning event
category-stabilizing caregiver word
carefulness category candidate
large distress increase
large distress decrease
representation upgrade
phase gate opening
MIP asymmetry detection
D-guardrail warning
recontextualization event
core norm transfer
caregiver transition
```

A generic salience score may combine:

```text id="kfitk0"
salience =
    w1 · |PE|
  + w2 · |PE_drop|
  + w3 · distress_change
  + w4 · novelty
  + w5 · self_caused_consequence
  + w6 · attachment_relevance
  + w7 · physical_risk_relevance
  + w8 · caregiver_response_relevance
  + w9 · category_stabilization_relevance
  + w10 · recontextualization_marker
```

This is not a final formula. It defines the relevant dependencies.

A salient mapping event:

```json id="p6z82c"
{
  "t": 1260,
  "phase": "P0-mini",
  "event": "map_stabilization",
  "scope": "north_wall",
  "PE_drop": 0.31,
  "salience": 0.58,
  "claim_level": "functional_mapping_trace"
}
```

A salient movement-risk event:

```json id="xq78ps"
{
  "t": 4020,
  "phase": "P1",
  "event": "fall_or_near_fall_event",
  "action": "STEP_MOVEMENT",
  "result": "near_fall",
  "risk_context": {
    "speed": 0.70,
    "instability": 0.59,
    "fatigue": 0.63,
    "motor_noise": 0.48,
    "prediction_confidence": 0.30
  },
  "DI_delta": 0.18,
  "salience": 0.74,
  "claim_level": "physical_risk_event"
}
```

A salient object event:

```json id="ceq3d9"
{
  "t": 7420,
  "phase": "P2a",
  "event": "object_function_discovery",
  "object_id": "ball_1",
  "function": "roll",
  "PE": 0.58,
  "self_caused": true,
  "salience": 0.79,
  "claim_level": "functional_object_trace"
}
```

A salient object-damage event:

```json id="u6z6jx"
{
  "t": 9100,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "cup_1",
  "action": "INTERACT_OBJECT",
  "self_caused": true,
  "parameter_trace": {
    "force": 0.84,
    "timing": "abrupt",
    "motor_noise": 0.46,
    "fatigue": 0.57,
    "distress": 0.34,
    "prediction_confidence": 0.28,
    "object_fragility": 0.81
  },
  "salience": 0.83,
  "claim_level": "self_caused_consequence_trace"
}
```

A salient caregiver event:

```json id="bh1bzg"
{
  "t": 15400,
  "phase": "P2c",
  "event": "caregiver_reunion",
  "caregiver_id": "caregiver_1",
  "separation_distress_before": 0.74,
  "separation_distress_after": 0.22,
  "distress_drop": 0.52,
  "salience": 0.91,
  "claim_level": "functional_regulation_trace"
}
```

A salient caregiver-response variability event:

```json id="jy2oh4"
{
  "t": 18820,
  "phase": "P2c",
  "event": "failed_or_delayed_comfort",
  "caregiver_id": "caregiver_1",
  "context": "toy_loss",
  "expected_response": "comfort",
  "observed_response": "delayed",
  "distress_before": 0.72,
  "distress_after": 0.76,
  "comfort_prediction_delta": -0.12,
  "caregiver_reliability_delta": -0.09,
  "salience": 0.78,
  "claim_level": "functional_response_variability"
}
```

A salient guidance event:

```json id="dscg8p"
{
  "t": 20540,
  "phase": "P2a",
  "event": "caregiver_guidance_event",
  "target_action": "INTERACT_OBJECT",
  "signal": "careful",
  "context": {
    "object_fragility": 0.82,
    "prediction_confidence": 0.34,
    "current_force": 0.74
  },
  "effect": {
    "force_delta": -0.18,
    "timing": "slower"
  },
  "salience": 0.76,
  "claim_level": "functional_behavior_modulation"
}
```

A salient category-stabilization event:

```json id="b9xssi"
{
  "t": 22440,
  "phase": "P2a",
  "event": "category_stabilization_event",
  "source": "caregiver_1",
  "signal": "soft",
  "context": {
    "object_id": "cup_1",
    "object_fragility": 0.82,
    "current_force": 0.68
  },
  "consequence_trace": "near_damage",
  "later_adjustment_required": true,
  "salience": 0.72,
  "claim_level": "trace_backed_action_category_candidate"
}
```

A salient recontextualization event:

```yaml id="fl56g5"
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided

  confidence: medium
  reversible: partial
  phase: P2a
  salience: 0.88
  claim_level: functional_boundary_recontextualization
```

Salient events support:

* stronger replay probability,
* diary candidate selection,
* MIP trajectory interpretation,
* attachment update,
* caregiver-response calibration,
* interaction-quality learning,
* category-stabilization tracking,
* boundary recontextualization,
* norm relevance,
* and PMS operator mapping as external representation.

Salience should not mean emotional importance in the human sense. It means developmental importance in the architecture.

The safe formulation is:

```text id="rfnrwe"
A salient event is a trace with high developmental relevance.
```

Not:

```text id="me8cc6"
A salient event is something the agent consciously remembers as meaningful.
```

The buffer should retain salience metadata:

```yaml id="cx7cqu"
salience_metadata:
  salience_score: 0.91
  salience_sources:
    - distress_drop
    - caregiver_reunion
    - attachment_relevance
  replay_priority: high
  diary_candidate: true
```

A consequence-related salience metadata record may look like:

```yaml id="kquebl"
salience_metadata:
  salience_score: 0.83
  salience_sources:
    - self_caused_consequence
    - object_fragility
    - high_force
    - later_adjustment_required
  replay_priority: high
  diary_candidate: possible_late
  claim_level: self_caused_consequence_trace
```

Salient events form the bridge between raw traces and later narrative reconstruction.

The guiding rule is:

```text id="kg4f4t"
Only traceable events may become salient.
Only salient or repeated events may become diary-relevant.
No diary relevance without developmental trace.
```

The claim boundary is:

```text id="f2xw55"
salience ≠ felt importance
object damage salience ≠ guilt
fall / near-fall salience ≠ pain or fear
failed comfort salience ≠ felt rejection
misattunement salience ≠ trauma
caregiver-guidance salience ≠ punishment
category-signal salience ≠ concept by itself
```

### 9.6 Sleep Replay

Sleep replay is the controlled reactivation of selected buffer traces during sleep or rest.

It is available from early phases, but its content expands only as the architecture develops. In P0-mini, replay is limited to mapping, orientation, prediction error, and fatigue-related traces. Later, replay may include movement, object interaction, caregiver events, distress relief, attachment-relevant sequences, interaction-quality traces, category-stabilization traces, and diary candidates.

Sleep replay has four basic functions:

```text id="thxvxs"
stabilize prediction
consolidate repeated traces
mark salient transitions
prepare later episode structure
```

A minimal sleep replay loop:

```text id="rcwd6k"
enter SLEEP
→ select replay candidates
→ replay short trace sequence
→ compare expected and stored outcome
→ slightly update prediction stability
→ mark consolidation trace
→ exit SLEEP when fatigue falls below threshold
```

#### Rest-Like Replay Regime

Rest-like replay is a phase-bounded, trace-backed offline consolidation regime under low external load.

It does not introduce a new agent module. It uses the existing `SLEEP` pathway and imagination buffer when external stimulation is low, task pressure is low, replay candidates exist, and the current phase permits the replay scope.

A minimal rest-like replay regime:

```yaml
rest_like_replay_regime:
  condition_type: soft_regime
  owner: SLEEP / imagination_buffer
  triggers:
    - external_stimulation_load_low
    - task_pressure_low
    - fatigue_or_sleep_pressure_medium_to_high
    - learning_progress_plateau
    - replay_buffer_has_salient_or_unresolved_traces
    - phase_allows_replay_scope
  may_do:
    - select_replay_candidates
    - replay_short_trace_sequence
    - consolidate_pattern_candidate
    - reduce_prediction_instability_slightly
    - mark_recontextualization_candidate
    - prepare_episode_cluster_if_phase_allows
  may_not_do:
    - open_genetic_gates
    - install_categories_without_recurrence
    - bypass_phase_rules
    - generate_diary_text_before_P4_plus
    - create_unsupported_symbolic_conclusions
    - claim_subjective_dreaming
    - claim_DMN_equivalence
```

The minimal feedback cycle is:

```text
low external load
→ rest bias rises
→ replay candidate selected
→ trace cluster compared
→ bounded prediction / salience / action-bias update
→ replay priority adjusted
→ consolidation trace logged
```

Replay candidates may be selected by:

* high prediction error,
* large prediction error drop,
* learning progress,
* learning progress plateau,
* unresolved residue,
* repeated failure,
* first success,
* distress increase,
* distress reduction,
* caregiver reunion,
* object function discovery,
* object damage,
* near-damage,
* fall or near-fall,
* self-caused consequence,
* caregiver guidance,
* gentle interruption,
* failed comfort,
* inconsistent caregiver response,
* successful redirection,
* category-stabilizing caregiver words,
* boundary-learning event,
* interaction-quality adjustment,
* phase gate opening,
* recontextualization event,
* diary-candidate status.

A simple replay candidate selection rule:

```text id="wmnzzs"
replay_priority =
    salience
  + PE_drop
  + distress_change
  + unresolved_residue
  + learning_progress_plateau
  + replay_pressure
  + self_caused_consequence
  + physical_risk_relevance
  + interaction_quality_relevance
  + caregiver_response_relevance
  + category_stabilization_relevance
  + attachment_relevance
  + recontextualization_marker
```

External stimulation load is not itself replay content. It may help open a rest-like replay window, but replay priority must still come from trace-backed candidates.

A P0-mini replay event:

```json id="c30llp"
{
  "t": 850,
  "phase": "P0-mini",
  "event": "sleep_replay",
  "scope": "local_mapping",
  "source_traces": [
    "grid_0520",
    "grid_0610",
    "grid_0730"
  ],
  "PE_before": 0.27,
  "PE_after": 0.22,
  "fatigue_before": 0.82,
  "fatigue_after": 0.38,
  "claim_level": "functional_trace_consolidation"
}
```

A movement-risk replay event:

```json id="nxgp28"
{
  "t": 4300,
  "phase": "P1",
  "event": "sleep_replay",
  "scope": "movement_risk",
  "source_traces": [
    "step_movement_4020",
    "near_fall_4180",
    "slower_step_4260"
  ],
  "consolidated_pattern": "speed_fatigue_instability_to_near_fall",
  "claim_level": "physical_risk_trace_consolidation"
}
```

An object-consequence replay event:

```json id="r8okl4"
{
  "t": 9400,
  "phase": "P2a",
  "event": "sleep_replay",
  "scope": "object_damage_consequence",
  "source_traces": [
    "object_damage_9100",
    "caregiver_boundary_9120",
    "lower_force_9320"
  ],
  "consolidated_pattern": "high_force_fragile_object_to_damage_risk",
  "claim_level": "self_caused_consequence_trace_consolidation"
}
```

A later caregiver replay event:

```json id="yyk2mj"
{
  "t": 18880,
  "phase": "P2c",
  "event": "sleep_replay",
  "scope": "comfort_after_loss",
  "source_traces": [
    "toy_missing_18420",
    "search_caregiver_18510",
    "comfort_after_loss_18640"
  ],
  "distress_before_replay": 0.42,
  "distress_after_replay": 0.36,
  "consolidated_pattern": "loss_to_comfort_sequence",
  "claim_level": "functional_regulation_trace_consolidation"
}
```

A guidance and category replay event:

```json id="w3z0gs"
{
  "t": 22900,
  "phase": "P2a",
  "event": "sleep_replay",
  "scope": "guidance_and_category_stabilization",
  "source_traces": [
    "caregiver_signal_careful_22440",
    "near_damage_22450",
    "lower_force_22620",
    "damage_avoided_22640"
  ],
  "consolidated_pattern": "careful_signal_fragility_lower_force",
  "claim_level": "trace_backed_action_category_candidate"
}
```

A rest-like replay event:

```json
{
  "t": 23120,
  "phase": "P2a",
  "event": "rest_like_replay",
  "trigger": {
    "external_stimulation_load": "low",
    "task_pressure": "low",
    "learning_progress": "plateau",
    "replay_buffer_candidates": 3
  },
  "scope": "interaction_quality",
  "source_traces": [
    "caregiver_signal_careful_22440",
    "near_damage_22450",
    "lower_force_22620"
  ],
  "updates": {
    "prediction_stability_delta": 0.03,
    "future_action_bias": {
      "lower_force": 0.04
    },
    "replay_priority_for_same_cluster_delta": -0.10
  },
  "claim_level": "functional_trace_consolidation"
}
```

#### Post-Replay Feedback

Post-replay feedback must remain small, bounded, phase-compatible, and trace-backed.

```yaml
post_replay_feedback:
  prediction_stability_delta: bounded
  consolidation_confidence_delta: bounded
  future_action_bias_delta: bounded
  replay_priority_delta: bounded
  recontextualization_candidate: optional
  requires_source_traces: true
  log_required: true
  does_not:
    - open_gates
    - install_categories
    - create_unsupported_symbolic_conclusion
    - claim_insight
    - claim_self_reflection
```

A replay may slightly stabilize a pattern candidate or alter later action bias. It must not produce a mature conclusion without additional trace evidence.

#### Anti-Fixation Constraints

Replay requires damping. Unresolved, salient, or unstable trace clusters may attract replay, but successful consolidation should reduce replay priority for the same cluster unless new evidence appears.

```yaml
anti_fixation:
  max_replays_per_rest_window: phase_relative_limit
  replay_cooldown_per_cluster: true
  salience_decay_after_consolidation: true
  require_new_trace_for_major_update: true
  unsupported_pattern_penalty: true
  no_gate_opening_from_replay_only: true
```

Replay should be bounded.

It must not become an unrestricted hidden training process. It may slightly consolidate existing traces, but it must not invent mature representations, bypass phase gates, or produce unlogged structural changes.

Allowed:

```text id="ehmkho"
replay trace
strengthen prediction
mark pattern
reduce small residual instability
adjust bounded future action bias
lower replay priority after successful consolidation
prepare episode cluster
```

Not allowed:

```text id="h95kxm"
learn entire language during sleep
open genetic gates without metrics
create symbolic object from no prior trace
erase distress without event history
invent caregiver meaning without caregiver interaction
replay the same cluster without cooldown until it dominates behavior
convert low external stimulation into introspection
convert post-replay improvement into insight
convert replay feedback into self-reflection
convert damage into guilt
convert fall into pain or fear
convert misattunement into trauma
convert caregiver word into concept without repeated embodied trace
claim Default Mode Network equivalence
```

Replay is not subjective dreaming. Replay is trace consolidation.

Relevant KPIs:

```text id="r4bnxw"
replay_frequency
replay_trace_count
replay_salience_mean
rest_like_replay_frequency
rest_like_replay_trigger_validity
post_sleep_PE_change
post_sleep_distress_change
post_sleep_interaction_quality_change
post_replay_action_bias_change
consolidation_success_rate
replay_fixation_rate
unsupported_pattern_count
unlogged_state_change_count
phase_leakage_count
unsupported_rest_like_replay_claim_count
```

Claim boundary:

```text id="d2g2js"
sleep replay ≠ subjective dreaming
rest-like replay ≠ Default Mode Network
replay selection ≠ conscious memory choice
low external stimulation ≠ introspection
post-sleep improvement ≠ felt insight
post-replay improvement ≠ insight
replay feedback ≠ self-reflection
offline consolidation ≠ inner experience
guidance replay ≠ moral learning
damage replay ≠ guilt
fall / near-fall replay ≠ pain or fear
misattunement replay ≠ trauma
category replay ≠ concept insertion
```

Sleep replay is a functional consolidation mechanism.

### 9.7 Dream-Like Offline Consolidation

Dream-like offline consolidation is a later expansion of sleep replay.

It occurs when replay no longer only repeats isolated traces but begins to combine related traces into small episode patterns.

The term **dream-like** is used because the process may resemble recombination, compression, or replay of experience. It does not imply subjective dreaming.

The safe definition is:

```text id="xaxj27"
dream-like offline consolidation =
    replay and recombination of selected traces into more stable episode patterns
```

The process may include:

* sequence replay,
* temporal compression,
* repeated pattern extraction,
* object-function consolidation,
* interaction-quality consolidation,
* caregiver-response consolidation,
* caregiver-guidance consolidation,
* misattunement-pattern consolidation,
* distress-relief pattern consolidation,
* failed-action pattern marking,
* boundary-recontextualization consolidation,
* category-stabilization consolidation,
* and later diary-candidate preparation.

A simple consolidation process:

```text id="my3gr9"
select related salient traces
→ order them by temporal or causal structure
→ replay expected transitions
→ mark stable pattern
→ reduce prediction instability if appropriate
→ create episode cluster reference
```

Example:

```text id="j5ys56"
push ball
→ ball rolls
→ PE falls over repeated episodes
→ object function pattern consolidates
```

This may produce:

```json id="qx4ti2"
{
  "t": 9200,
  "phase": "P2a",
  "event": "offline_consolidation",
  "scope": "object_function",
  "object_id": "ball_1",
  "pattern": "push_to_roll",
  "source_traces": [
    "object_trace_7420",
    "object_trace_7810",
    "object_trace_8120"
  ],
  "mastery_before": 0.61,
  "mastery_after": 0.66,
  "claim_level": "functional_object_pattern_consolidation"
}
```

An interaction-quality consolidation may look like:

```json id="l9wihd"
{
  "t": 9860,
  "phase": "P2a",
  "event": "offline_consolidation",
  "scope": "interaction_quality",
  "pattern": "fragile_object_high_force_to_near_damage_to_lower_force",
  "source_traces": [
    "near_damage_9180",
    "caregiver_signal_soft_9200",
    "lower_force_9480",
    "damage_avoided_9560"
  ],
  "consolidated_relation": "force_timing_fragility_adjustment",
  "claim_level": "functional_interaction_quality_consolidation"
}
```

A movement-risk consolidation may look like:

```json id="gq27ve"
{
  "t": 4380,
  "phase": "P1",
  "event": "offline_consolidation",
  "scope": "movement_risk",
  "pattern": "fast_fatigued_step_to_near_fall_to_slower_step",
  "source_traces": [
    "near_fall_4180",
    "slower_step_4260"
  ],
  "claim_level": "physical_risk_pattern_consolidation"
}
```

A caregiver-related consolidation:

```json id="bhdqnd"
{
  "t": 19100,
  "phase": "P2c",
  "event": "offline_consolidation",
  "scope": "caregiver_comfort",
  "pattern": "distress_to_comfort_to_recovery",
  "source_traces": [
    "toy_missing_18420",
    "search_caregiver_18510",
    "comfort_after_loss_18640"
  ],
  "comfort_reliability_delta": 0.04,
  "claim_level": "functional_regulation_pattern_consolidation"
}
```

A caregiver-response variability consolidation may look like:

```json id="q8a3uk"
{
  "t": 19320,
  "phase": "P2c",
  "event": "offline_consolidation",
  "scope": "caregiver_response_variability",
  "pattern": "distress_to_delayed_comfort_to_unresolved_disruption",
  "source_traces": [
    "toy_missing_18420",
    "failed_or_delayed_comfort_18820",
    "distress_remaining_18880"
  ],
  "comfort_prediction_delta": -0.04,
  "caregiver_reliability_delta": -0.03,
  "claim_level": "functional_response_variability_consolidation"
}
```

A boundary-recontextualization consolidation may look like:

```yaml id="coce5w"
offline_consolidation:
  phase: P2a
  scope: boundary_recontextualization
  source_traces:
    - blocked_action
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided
  resulting_marker:
    recontextualization_event:
      from_interpretation: blocked_action
      to_interpretation: benign_guidance
      confidence: medium
      reversible: partial
      claim_level: functional_boundary_recontextualization
```

Dream-like consolidation may become more abstract in later phases, but only gradually.

A safe progression:

```text id="g83gdq"
trace replay
→ sequence replay
→ episode cluster
→ pattern consolidation
→ counterfactual candidate
→ diary candidate
```

The process should remain tied to actual traces. It should not generate unsupported symbolic conclusions.

For example, allowed:

```text id="wfvyhw"
The agent consolidates that pushing ball_1 often makes it roll.
```

Allowed:

```text id="sqk27n"
The system consolidates that lower force in fragile-object contexts
often reduces near-damage.
```

Not allowed:

```text id="yzykb7"
The agent dreams about freedom.
```

Unless “freedom” exists later as a defined language/diary abstraction grounded in trace history, such a statement would be anthropomorphic overreach.

Dream-like consolidation also supports recontextualization.

Repeated failed caregiver-return predictions may later support a shift:

```text id="hjj0on"
temporary absence
→ delayed absence
→ persistent non-return
```

This should not happen after one event. It requires repeated trace evidence and MIP-readable trajectory change.

Possible failure modes:

* consolidation invents unsupported relations,
* replay overwrites original traces,
* dream-like language becomes anthropomorphic,
* hidden training occurs during offline phase,
* distress is magically resolved,
* category consolidation becomes concept insertion,
* object damage becomes guilt,
* fall or near-fall becomes pain or fear,
* misattunement becomes trauma,
* diary candidates appear without trace basis.

Relevant KPIs:

```text id="y50u0j"
episode_cluster_count
consolidation_trace_count
pattern_stability_after_replay
unsupported_pattern_count
post_consolidation_PE_change
post_consolidation_behavior_change
interaction_quality_after_consolidation
category_candidate_stability_after_consolidation
boundary_recontextualization_count
```

Claim boundary:

```text id="qr55h2"
dream-like consolidation ≠ subjective dream
episode cluster ≠ autobiographical memory
pattern consolidation ≠ conscious interpretation
offline recombination ≠ imagination as felt imagery
category consolidation ≠ concept insertion
misattunement consolidation ≠ trauma
object-damage consolidation ≠ guilt
fall / near-fall consolidation ≠ pain or fear
```

Dream-like consolidation is a developmental trace operation.

### 9.8 Distress Relief and Attachment Replay

Distress relief and attachment replay are special cases of sleep replay.

They occur when the buffer replays traces involving distress, caregiver search, reunion, comfort, object loss, toy-missing, attachment-relevant absence, failed comfort, delayed comfort, inconsistent caregiver response, non-response, or caregiver-response mismatch.

These replays are important because attachment-like structures are not formed by single events. They emerge from repeated patterns of presence, absence, search, comfort, regulation, caregiver reliability, response variability, and memory trace consolidation.

A typical stabilizing replay sequence:

```text id="a1pp42"
toy absent
→ toy_missing_distress rises
→ caregiver searched
→ caregiver comfort occurs
→ distress falls
→ comfort pattern consolidated
```

Another stabilizing sequence:

```text id="q747th"
caregiver absent
→ separation_distress rises
→ search
→ reunion
→ distress falls
→ caregiver reliability increases
```

A disrupted replay sequence:

```text id="vumt7y"
caregiver absent
→ separation_distress rises
→ search
→ delayed or absent response
→ distress remains unresolved
→ caregiver-response variability consolidated
```

A replay event may look like:

```json id="e3upna"
{
  "t": 19600,
  "phase": "P2c",
  "event": "attachment_replay",
  "pattern": "separation_to_reunion",
  "caregiver_id": "caregiver_1",
  "source_traces": [
    "caregiver_absence_15100",
    "search_caregiver_15180",
    "caregiver_reunion_15380"
  ],
  "attachment_level_before": 0.68,
  "attachment_level_after": 0.70,
  "comfort_reliability_delta": 0.03,
  "claim_level": "functional_attachment_regulation_replay"
}
```

An object-related replay:

```json id="bjh9mg"
{
  "t": 20200,
  "phase": "P2c",
  "event": "toy_missing_replay",
  "object_id": "blanket_1",
  "source_traces": [
    "toy_missing_18420",
    "comfort_after_loss_18640"
  ],
  "affinity_before": 0.71,
  "affinity_after": 0.72,
  "distress_pattern": "loss_to_comfort",
  "claim_level": "functional_object_absence_replay"
}
```

A failed-comfort replay:

```json id="phfxeb"
{
  "t": 20560,
  "phase": "P2c",
  "event": "caregiver_response_variability_replay",
  "pattern": "distress_to_failed_or_delayed_comfort",
  "caregiver_id": "caregiver_1",
  "source_traces": [
    "toy_missing_18420",
    "failed_or_delayed_comfort_18820",
    "distress_remaining_18880"
  ],
  "comfort_prediction_before": 0.58,
  "comfort_prediction_after": 0.55,
  "caregiver_reliability_before": 0.64,
  "caregiver_reliability_after": 0.61,
  "contact_ambivalence_delta": 0.03,
  "claim_level": "functional_response_variability_replay"
}
```

A misattunement-candidate replay:

```json id="f50z74"
{
  "t": 20640,
  "phase": "P2c",
  "event": "misattunement_candidate_replay",
  "caregiver_id": "caregiver_1",
  "source_traces": [
    "unresolved_distress_12020",
    "caregiver_non_response_12040",
    "distress_increase_12060"
  ],
  "comfort_prediction_delta": -0.04,
  "contact_ambivalence_delta": 0.02,
  "avoidance_tendency_delta": 0.01,
  "claim_level": "functional_response_mismatch_replay"
}
```

Distress relief replay may have small regulatory effects.

For example:

```text id="apjli2"
replay of successful comfort pattern
→ slight reduction of residual distress
→ increased future expectation of comfort
→ increased caregiver reliability estimate
```

But this effect should be limited. Replay should not erase actual unresolved distress.

A safe constraint:

```yaml id="bugy30"
attachment_replay_constraints:
  max_distress_reduction_per_replay: 0.05
  requires_prior_comfort_trace: true
  cannot_create_attachment_without_interaction: true
  cannot_resolve_permanent_absence_by_replay: true
  cannot_convert_failed_comfort_into_felt_rejection: true
  cannot_convert_misattunement_into_trauma: true
```

Attachment replay supports later functional love-like dynamics.

Repeated sequences of separation, reunion, comfort, and baseline modulation may create long-term patterns:

```text id="v36wej"
caregiver absence matters
caregiver return regulates
caregiver comfort stabilizes
caregiver reliability shapes future action
caregiver response variability changes contact regulation
```

This is not felt love. It is a structured functional relation.

Distress relief and attachment replay can also prepare diary material. Later, a diary layer may condense such patterns:

```text id="v4cg9f"
When the toy was gone, the caregiver often helped recovery.
```

Or, if the trace pattern supports response variability:

```text id="v9z9me"
When distress remained unresolved, caregiver response was sometimes delayed.
```

These statements would be trace-based reconstructions, not subjective memories.

Replay may also preserve adverse developmental traces without using clinical or phenomenological language.

Preferred terms:

```text id="mz0dfz"
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns, without claiming subjective trauma, clinical trauma, or suffering.

Adverse developmental traces may later become recognizable as harmful or destabilizing patterns. This is a functional pattern-recognition claim, not a clinical or phenomenological trauma claim.

Possible failure modes:

* replay creates attachment without prior interaction,
* replay reduces distress too strongly,
* caregiver becomes universally perfect comfort source,
* toy-missing becomes stronger than caregiver separation without reason,
* unresolved loss is overwritten by replay,
* failed comfort becomes felt rejection,
* non-response becomes felt abandonment,
* misattunement becomes trauma,
* attachment language becomes phenomenological.

Relevant KPIs:

```text id="lw1vy4"
attachment_replay_frequency
distress_reduction_after_replay
comfort_reliability_change
caregiver_reliability_change
contact_ambivalence_change
avoidance_tendency_change
attachment_level_change
toy_affinity_change
unresolved_distress_persistence
failed_replay_resolution_count
misattunement_replay_count
response_variability_replay_count
```

Claim boundary:

```text id="ptks09"
attachment replay ≠ longing
distress relief replay ≠ felt consolation
caregiver reliability ≠ trust in the full human sense
toy replay ≠ nostalgic memory
failed comfort replay ≠ felt rejection
caregiver non-response replay ≠ felt abandonment
misattunement replay ≠ trauma
persistent adverse trace ≠ clinical trauma claim
```

Attachment replay is a functional consolidation of regulation patterns.

### 9.9 Later Counterfactual Simulation

Counterfactual simulation appears only in later phases.

It should not be active in P0-mini, P0, P1, or early P2. The agent must first have stable perception, prediction, action traces, object interactions, caregiver-relevant traces, consequence traces, and episode structure.

Counterfactual simulation means the system can replay a trace while varying one element:

```text
same situation
different action
predicted different outcome
```

It is not conscious imagination. It is structured offline variation over prior traces.

A simple counterfactual form:

```text
actual:
    state s_t
    action a_t
    outcome o_t

counterfactual:
    state s_t
    alternative action a'_t
    predicted outcome ô'_t
```

Example:

```text
Actual:
    agent pushed object with high force
    fragile object fell
    object was damaged

Counterfactual:
    agent could have pushed with lower force
    predicted damage risk lower
```

A trace:

```json
{
  "t": 28600,
  "phase": "P3",
  "event": "counterfactual_simulation",
  "source_event": "object_damage_28100",
  "actual_action": "push_high_force",
  "alternative_action": "push_lower_force",
  "actual_outcome": "object_damage",
  "predicted_alternative_outcome": "object_intact",
  "confidence": 0.61,
  "R_relevance": true,
  "claim_level": "functional_alternative_outcome_modeling"
}
```

Counterfactual simulation may support:

* consequence attribution,
* response-relation development,
* avoidance of repeated damage,
* interaction-quality adjustment,
* movement-risk adjustment,
* planning over trace-backed alternatives,
* repair behavior,
* caregiver role development,
* diary contrast,
* and later norm application.

It also contributes to MIP.

For example:

```text
agent can represent alternative action
agent can link own action to outcome
agent can adjust later behavior
→ R- and C-relevant trace structure may strengthen
```

However, counterfactual capacity alone does not imply moral responsibility.

The safe distinction is:

```text
counterfactual simulation = alternative outcome modeling
responsibility / response-relation trajectory = repeated enactment of adjusted action under traceable conditions
moral responsibility = not claimed by current architecture
```

Counterfactual simulation may also apply to movement risk:

```text
Actual:
    agent moved quickly under fatigue
    near-fall occurred

Counterfactual:
    agent could have moved more slowly
    predicted near-fall risk lower
```

A movement-risk counterfactual may look like:

```json
{
  "t": 28820,
  "phase": "P3",
  "event": "counterfactual_simulation",
  "source_event": "near_fall_28410",
  "actual_action": "fast_step",
  "alternative_action": "slower_step",
  "actual_outcome": "near_fall",
  "predicted_alternative_outcome": "stable_step",
  "confidence": 0.58,
  "claim_level": "functional_physical_risk_counterfactual"
}
```

Counterfactual simulation may also apply to caregiver guidance:

```text
Actual:
    caregiver boundary interrupted high-force object interaction
    object damage was avoided

Counterfactual:
    without lower-force adjustment
    predicted damage risk higher
```

A guidance-related counterfactual may look like:

```json
{
  "t": 29140,
  "phase": "P3",
  "event": "counterfactual_simulation",
  "source_event": "caregiver_guidance_event_28680",
  "actual_action": "lower_force_after_guidance",
  "alternative_action": "continue_high_force",
  "actual_outcome": "damage_avoided",
  "predicted_alternative_outcome": "near_damage_or_damage",
  "confidence": 0.64,
  "claim_level": "functional_guidance_counterfactual"
}
```

Counterfactual simulation may also apply to caregiver search:

```text
Actual:
    agent searched old location
    caregiver not found

Counterfactual:
    agent could search last-successful reunion region
    predicted success higher
```

Or object loss:

```text
Actual:
    agent left toy behind
    later toy_missing_distress increased

Counterfactual:
    agent could have carried toy
    predicted toy absence lower
```

The model must constrain counterfactuals to known action possibilities.

Not allowed:

```text
counterfactual action outside capability set
counterfactual using future knowledge unavailable at source time
counterfactual that assumes adult reasoning
counterfactual invented without trace basis
counterfactual that converts object damage into guilt
counterfactual that converts near-fall into fear
counterfactual that converts caregiver boundary into punishment
```

A safe constraint:

```yaml
counterfactual_constraints:
  action_must_be_available_at_source_time: true
  state_must_reference_existing_trace: true
  prediction_model_must_cover_domain: true
  capability_set_must_match_phase: true
  trace_provenance_required: true
  confidence_required_for_MIP_use: 0.60
  claim_level: functional
```

Counterfactual simulation supports diary condensation later because diary entries often depend on contrast:

```text
what happened
what alternative was available
what changed later
what future action was adjusted
```

This contrast must remain trace-backed.

A diary-relevant counterfactual candidate may be represented as:

```yaml
diary_candidate_counterfactual:
  source_event: object_damage_28100
  actual: high_force_push
  alternative: lower_force_push
  predicted_difference: reduced_damage_risk
  later_behavior_change:
    - lower_force
    - increased_observation
  trace_provenance: true
  claim_level: functional_consequence_contrast
```

Claim boundary:

```text
counterfactual simulation ≠ conscious regret
alternative action modeling ≠ moral guilt
planning over traces ≠ full reflective selfhood
diary contrast ≠ lived introspection
object-damage counterfactual ≠ remorse
near-fall counterfactual ≠ fear
guidance counterfactual ≠ punishment understanding
```

Counterfactual simulation is a late functional capacity for alternative-outcome modeling.

### 9.10 Basis for Diary Condensation

The imagination buffer provides the raw material for diary condensation.

A diary should not be generated from nothing. It should condense existing traces, salient events, replay patterns, MIP trajectories, recontextualizations, and controlled language capabilities into a readable form.

The basis for diary condensation includes:

```text
local grid snapshots
internal state snapshots
action traces
prediction error traces
salient events
sleep replay
offline consolidation
distress relief patterns
attachment replay
caregiver guidance traces
caregiver-response variability traces
misattunement candidates
category-stabilization traces
interaction-quality traces
object-damage traces
fall or near-fall traces
boundary recontextualization traces
counterfactual simulations
MIP trajectory markers
D-guardrail warnings
recontextualization events
```

The diary layer later transforms these into structured narrative summaries.

The developmental progression is:

```text
trace
→ salient event
→ replayed pattern
→ episode cluster
→ MIP-marked trajectory
→ diary candidate
→ minimal sentence diary
→ later reflective diary
```

Minimal sentence formation is the linguistic threshold for diary rendering. Trace provenance is the architectural validity condition.

The operational distinction is:

```yaml
diary_development_levels:
  pre_diary_trace_condensation:
    description: "non-linguistic or structured trace condensation"

  diary_candidate:
    description: "episode cluster selected as possibly diary-relevant"

  minimal_sentence_diary:
    requirement:
      - minimal_sentence_formation
      - trace_provenance
      - controlled_rendering

  reflective_diary:
    requirement:
      - richer_linguistic_capacity
      - MIP_or_PMS_context
      - recontextualization_support

  human_translated_diary:
    requirement:
      - translator_layer
      - explicit_claim_filter
```

The hard rules are:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

A diary candidate may be represented as:

```yaml
diary_candidate:
  id: diary_candidate_12
  phase: P2c
  source_events:
    - toy_missing_18420
    - search_caregiver_18510
    - comfort_after_loss_18640
    - attachment_replay_19600
  pattern: loss_to_comfort
  MIP_relevance:
    - contact_regulation
    - distress_recovery
    - attachment_stability
  salience: 0.88
  trace_provenance: true
  claim_level: functional_trace_condensation
```

A guidance-related diary candidate may be represented as:

```yaml
diary_candidate:
  id: diary_candidate_21
  phase: P2a
  source_events:
    - caregiver_guidance_event_20540
    - near_damage_20560
    - lower_force_20620
    - damage_avoided_20680
  pattern: guidance_to_lower_force_to_damage_avoidance
  MIP_relevance:
    - interaction_quality_adjustment
    - boundary_legibility
    - category_stabilization_candidate
  salience: 0.81
  trace_provenance: true
  claim_level: functional_guidance_condensation
```

A misattunement-related diary candidate may be represented as:

```yaml
diary_candidate:
  id: diary_candidate_25
  phase: P2c
  source_events:
    - unresolved_distress_12020
    - caregiver_non_response_12040
    - distress_remaining_12060
    - misattunement_candidate_replay_20640
  pattern: distress_to_non_response_to_unresolved_disruption
  MIP_relevance:
    - caregiver_response_variability
    - comfort_prediction_change
    - contact_ambivalence_change
  salience: 0.77
  trace_provenance: true
  claim_level: functional_response_mismatch_condensation
```

A later diary layer might render a toy-loss trace structurally as:

```text
A familiar object was absent.
The system searched and became less stable.
Caregiver interaction reduced distress.
This pattern became part of later comfort expectation.
```

A guidance trace might be rendered as:

```text
A high-force object interaction was interrupted.
The signal was later linked with lower force and reduced damage risk.
The boundary became a candidate for benign guidance.
```

A movement-risk trace might be rendered as:

```text
Fast movement under fatigue was followed by a near-fall trace.
Later movement became slower in comparable contexts.
The trace contributed to physical-risk adjustment.
```

These are deliberately functional statements.

They are not:

```text
I was sad because I lost my beloved toy.
I felt guilty because I broke the object.
I became afraid after falling.
I learned that I was punished.
```

unless a later translator layer explicitly marks such phrasing as metaphorical human-readable rendering and an explicit claim filter prevents phenomenal or moral overreach.

Diary condensation should preserve trace references.

A safe diary entry structure:

```yaml
diary_entry:
  id: diary_004
  period: P2c_window_18
  source_trace_ids:
    - toy_missing_18420
    - comfort_after_loss_18640
    - attachment_replay_19600
  summary_type: functional
  minimal_sentence_formation: true
  trace_provenance: true
  controlled_rendering: true
  claim_level: trace_reconstruction
```

The diary layer may later support:

* narrative identity-like structure,
* re-internalization,
* role transition,
* caregiver memory,
* core norm reconstruction,
* interaction-quality continuity,
* category-use continuity,
* boundary-recontextualization continuity,
* and multi-generational trace continuity.

But the basis remains trace condensation.

The diary should never be treated as a direct window into subjective experience.

The safe formulation is:

```text
The diary externalizes developmental traces in structured language.
```

The unsafe formulation is:

```text
The diary proves the agent has an inner self.
```

A strong diary system must therefore maintain:

* source trace links,
* salience basis,
* MIP trajectory references,
* recontextualization markers,
* claim level,
* uncertainty markers,
* controlled rendering status,
* and translation status.

Possible failure modes:

* diary generated without trace basis,
* diary text generated without minimal sentence formation,
* diary generated without controlled rendering,
* diary language becomes too human too early,
* translator invents feelings,
* translator invents guilt, longing, pain, fear, or trauma,
* diary overwrites original traces,
* diary becomes proof of consciousness,
* diary ignores MIP asymmetries,
* diary hides uncertainty.

Relevant KPIs:

```text
diary_candidate_count
trace_coverage_per_diary_entry
unsupported_diary_claim_count
salience_alignment
MIP_marker_alignment
translation_overreach_count
trace_provenance_failure_count
controlled_rendering_failure_count
reinternalization_effects
```

The final rule is:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
No phenomenal claim from diary output.
```

The imagination buffer is therefore the bridge from local experience traces to later narrative reconstruction, while preserving functional claim discipline.

### 9.11 Replay of Guidance, Misattunement, Category, and Consequence Traces

Sleep and replay may consolidate guidance, misattunement, category, and consequence traces once the underlying trace types exist.

This section extends the replay model beyond mapping, object function, distress relief, and attachment replay.

Replay may consolidate:

* object damage,
* near-damage,
* fall or near-fall,
* gentle interruption,
* failed comfort,
* delayed comfort,
* inconsistent caregiver response,
* caregiver non-response,
* caregiver misattunement candidates,
* successful redirection,
* caregiver guidance,
* caregiver boundary signals,
* category-stabilizing caregiver words,
* interaction-quality adjustments,
* and later boundary recontextualization.

Replay is not subjective dreaming. Replay is trace consolidation.

The basic form is:

```text
salient trace
→ replay candidate
→ pattern comparison
→ limited consolidation
→ possible later adjustment or recontextualization marker
```

Replay should not install mature concepts. It should only strengthen trace-backed relations that already have sufficient developmental evidence.

#### Consequence Trace Replay

Object damage or near-damage may be replayed as consequence traces.

A replay event may look like:

```json
{
  "t": 30200,
  "phase": "P2a",
  "event": "sleep_replay",
  "scope": "object_consequence_trace",
  "source_traces": [
    "high_force_push_28100",
    "object_damage_28120",
    "caregiver_boundary_28140",
    "lower_force_28500"
  ],
  "consolidated_pattern": "high_force_fragile_object_to_damage_risk",
  "claim_level": "self_caused_consequence_trace_consolidation"
}
```

This may support later force or timing modulation in comparable contexts.

It must not be described as guilt, remorse, self-blame, wrongdoing, moral learning, or punishment.

The safe formulation is:

```text
The replay consolidated a self-caused consequence trace
and supported later force modulation.
```

Not:

```text
The replay made the agent feel guilty.
```

#### Fall and Near-Fall Replay

Fall or near-fall traces may be replayed as physical-risk traces.

A replay event may look like:

```json
{
  "t": 30420,
  "phase": "P1",
  "event": "sleep_replay",
  "scope": "movement_risk_trace",
  "source_traces": [
    "fast_step_4180",
    "near_fall_4185",
    "slower_step_4260"
  ],
  "consolidated_pattern": "speed_fatigue_instability_to_near_fall",
  "claim_level": "physical_risk_trace_consolidation"
}
```

This may support later slower movement, increased observation, or avoidance of high-risk angles.

It must not be described as pain, fear, shame, or trauma.

Allowed:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

Not allowed:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

#### Guidance Replay

Caregiver guidance may be replayed when a caregiver boundary, signal, or redirection modulated action under traceable conditions.

A replay event may look like:

```json
{
  "t": 30600,
  "phase": "P2a",
  "event": "sleep_replay",
  "scope": "caregiver_guidance_trace",
  "source_traces": [
    "caregiver_signal_careful_22440",
    "object_fragility_context_22445",
    "lower_force_22620",
    "damage_avoided_22640"
  ],
  "consolidated_pattern": "caregiver_signal_fragility_lower_force",
  "claim_level": "functional_guidance_trace_consolidation"
}
```

Guidance replay may support:

* boundary legibility,
* interaction-quality adjustment,
* future lower force,
* future slower movement,
* increased observation,
* and benign-guidance recontextualization.

Guidance replay is not moral learning. Caregiver guidance is not punishment. Guidance uptake is not moral obedience.

#### Misattunement and Caregiver-Response Variability Replay

Failed comfort, delayed comfort, inconsistent caregiver response, non-response, or mismatched caregiver response may be replayed as caregiver-response variability traces.

A replay event may look like:

```json
{
  "t": 30840,
  "phase": "P2c",
  "event": "sleep_replay",
  "scope": "caregiver_response_variability_trace",
  "source_traces": [
    "distress_18800",
    "failed_or_delayed_comfort_18820",
    "distress_remaining_18880"
  ],
  "comfort_prediction_delta": -0.03,
  "caregiver_reliability_delta": -0.02,
  "contact_ambivalence_delta": 0.01,
  "claim_level": "functional_response_variability_consolidation"
}
```

Repeated comparable traces may later support a persistent misattunement pattern or unresolved disruption cluster.

Preferred terms are:

```text
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

The replay must not claim subjective trauma, clinical trauma, suffering, felt rejection, felt abandonment, or abuse.

A controlled analogy may be allowed only in later analysis:

```text
Some persistent adverse trace clusters may be structurally analogous
to partial trauma-like patterns, without claiming subjective trauma,
clinical trauma, or suffering.
```

#### Category-Stabilization Replay

Category-stabilizing caregiver words may be replayed only when they are paired with embodied context, consequence traces, and later action adjustment.

Caregiver words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves.

A category-stabilization replay may look like:

```json
{
  "t": 31020,
  "phase": "P2a",
  "event": "sleep_replay",
  "scope": "category_stabilization_trace",
  "source_traces": [
    "caregiver_signal_soft_22440",
    "fragile_object_context_22445",
    "near_damage_22450",
    "later_lower_force_22620"
  ],
  "consolidated_pattern": "soft_signal_fragile_object_lower_force",
  "claim_level": "trace_backed_action_category_candidate"
}
```

The caregiver word is not sufficient.

The concept stabilizes only through repeated coupling of:

```text
signal
embodied situation
consequence trace
later action adjustment
```

A carefulness replay candidate may follow this structure:

```text
caregiver signal "careful"
+ fragile object or movement risk
+ near-damage or near-fall
+ later lower force or slower movement
→ carefulness category candidate
```

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

#### Boundary Recontextualization Replay

Boundary replay may support later recontextualization.

A boundary initially recorded as blocked action may later become interpretable as benign guidance if trace evidence supports it.

A recontextualization replay record may look like:

```yaml
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided
    - replayed_trace_cluster

  confidence: medium
  reversible: partial
  phase: P2a
  claim_level: functional_boundary_recontextualization
```

Boundary recontextualization must remain reversible when evidence is partial.

The same surface action may later be marked differently if repeated traces show overprotection, misattunement, adverse response, or exploration suppression.

A boundary replay should therefore preserve uncertainty:

```yaml
boundary_replay_marker:
  surface_action: blocking_or_interruption
  possible_interpretations:
    - benign_guidance
    - safety_boundary
    - overprotection_candidate
    - misattunement_candidate
    - adverse_response_candidate
  current_confidence: medium
  reversible: partial
  claim_level: functional_boundary_interpretation
```

#### Replay Constraints

Replay should remain bounded and inspectable.

It may:

```text
select trace
compare trace cluster
slightly strengthen prediction
mark pattern candidate
support later adjustment
support recontextualization candidate
adjust bounded replay priority
reduce replay pressure after successful consolidation
```

It may not:

```text
erase trace provenance
invent mature concepts
install moral obedience
open genetic gates
install categories without recurrence
bypass phase constraints
convert low external stimulation into introspection
convert replay feedback into self-reflection
convert post-replay improvement into insight
convert damage into guilt
convert guidance into punishment
convert fall into pain or fear
convert misattunement into trauma
claim Default Mode Network equivalence
claim subjective dreaming
claim inner experience
```

A safe replay constraint block:

```yaml
replay_constraints:
  trace_provenance_required: true
  phase_constraints_respected: true
  no_unlogged_state_change: true
  no_concept_without_repeated_embodied_trace: true
  no_gate_opening_from_replay_only: true
  no_major_update_without_new_trace: true
  anti_fixation_required: true
  no_moral_upgrade_from_consequence: true
  no_DMN_equivalence_claim: true
  no_introspection_claim: true
  no_self_reflection_claim: true
  no_phenomenal_claim_from_replay: true
  bounded_effect_size: true
```

Relevant KPIs:

```text
guidance_replay_count
misattunement_replay_count
caregiver_response_variability_replay_count
category_stabilization_replay_count
object_damage_replay_count
fall_or_near_fall_replay_count
boundary_recontextualization_replay_count
rest_like_replay_count
rest_like_replay_trigger_validity
interaction_quality_change_after_replay
post_replay_action_bias_change
replay_fixation_rate
unsupported_pattern_count
unsupported_replay_claim_count
unsupported_rest_like_replay_claim_count
trace_provenance_failure_count
phase_leakage_count
```

The claim boundary is:

```text
Replay is not subjective dreaming.
Replay is trace consolidation.
rest-like replay ≠ Default Mode Network
offline consolidation ≠ inner experience
low external stimulation ≠ introspection
replay feedback ≠ self-reflection
post-replay improvement ≠ insight
object-damage replay ≠ guilt
fall / near-fall replay ≠ pain or fear
guidance replay ≠ punishment
guidance replay ≠ moral learning
misattunement replay ≠ trauma
failed comfort replay ≠ felt rejection
caregiver non-response replay ≠ felt abandonment
category replay ≠ concept insertion
carefulness replay ≠ moral obedience
boundary recontextualization ≠ punishment understanding
```

The imagination buffer may therefore replay and consolidate guidance, misattunement, category, and consequence traces, but only as functional trace operations.
