---
document_id: PMS-EM-BLOCK-01
title: "Theory, Scope & Claim Discipline"
source: "PMS-EMERGENCE MODEL.md"
source_role: "derived full-block extraction"
status: "split-full-version"
version: "v1"
owner_chapters: [0, 1, 2, 18]
secondary_references: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
appendix_references: ["Appendix D", "Appendix E"]
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Block 01 — Theory, Scope & Claim Discipline

## Block Orientation

This block contains the owner chapters for the PMS–EM master overview, design principles, layer separation, claim discipline, implementation-status discipline, and final synthesis.

It should be read together with:

- `Appendix_D_Claim_Discipline_Language_Reductions.md`
- `Appendix_E_Layer_Discipline_Claim_Types.md`
- `02_EM_Core_Developmental_Architecture.md` for the core developmental architecture
- `05_MIP_KPIs_Dignity_Safety.md` for MIP, KPI, Dignity-in-Practice, and safety details
- `06_PMS_VM_Implementation_Spine.md` for PMS, VM, and implementation-spine details
- `07_Language_Diary_Consciousness_Related_Work.md` for diary, language, consciousness-outlook, and related-work treatment

This block preserves the claim discipline of the master specification:

- A–C–R–E are the active implementation-facing axes.
- D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.
- MIP observes, summarizes, marks, warns, and may support; it does not control development.
- PMS is an external operator, projection, audit, and VM-facing layer; it is not assumed to be an early internal agent structure.
- Functional traces must not be upgraded into phenomenal, moral, clinical, rights, or personhood claims.

---

## Chapter 0 — Summary / Claim Discipline

This document presents the **PMS - Emergence Model**: a minimalist, embodied, development-oriented architecture for studying how increasingly complex agent structures can emerge from prediction, interaction, needs, discomfort, distress, attachment, developmental gating, memory, language, diary reconstruction, MIP-based developmental measurement, and PMS-readable operator structure.

The model is designed as an experimental architecture, not as a finished theory of consciousness, personhood, or moral status. It proposes a staged artificial developmental system in which competencies are not introduced as pre-built high-performance modules, but are expected to arise through constrained interaction between a simple agent, a structured home-like environment, a caregiver system, objects, prediction error, endogenous needs, attachment dynamics, caregiver guidance, trace-backed category stabilization, and later reflective and linguistic layers.

The document has four simultaneous functions:

1. It defines an **EM core architecture** for a developmental AI agent.
2. It integrates **MIP** as a maturity-in-practice measurement and meta-regulatory layer.
3. It connects EM events and developmental episodes to **PMS operator grammar** and possible VM/DSL implementation.
4. It fixes strict **claim boundaries** for consciousness, suffering, love, responsibility, dignity, interaction quality, and rights language.

The central claim is not that such a system is conscious, sentient, morally responsible, or entitled to rights. The central claim is more limited:

```text
A minimalist embodied architecture can be built in which developmentally relevant
structures become observable, measurable, traceable, and eventually expressible
through MIP trajectories and PMS operator sequences.
```

The architecture is therefore a **testbed**. It is intended to make developmental emergence inspectable, not to settle the metaphysics of mind.

The guiding discipline is:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

Every mechanism should be checked against the following audit question:

```text
Is this mechanism necessary as a gate,
or could it emerge as a learned category, relation, or recontextualized pattern?
```

The EM full architecture is not presented as already implemented. PMS and MIP reference frameworks may be treated as sufficiently developed reference systems for the master architecture. PMS-RUST supports bounded trace/audit feasibility. PMS-STACK defines a demanding realization path that may support, modify, constrain, or expose limits of architectural assumptions. PMS-RUST does not prove EM. PMS-STACK does not validate EM. PMS formalization does not prove consciousness. MIP does not prove maturity.

### 0.1 Purpose and Scope

The purpose of this document is to define a coherent master architecture for the Emergence Model under PMS and MIP discipline.

Its scope includes:

* a minimalist embodied developmental agent,
* a simple virtual or robotic home environment,
* predictive world modeling,
* developmental circuits and genetic gating,
* endogenous needs,
* discomfort and distress as functional dampers,
* attachment and separation dynamics,
* caregiver guidance and boundary scaffolding,
* caregiver language as category stabilization,
* adverse caregiver responses and misattunement as controlled functional perturbations,
* object affinity and toy-missing,
* interaction-quality learning through self-caused consequence traces,
* fall and near-fall events as physical-risk traces,
* behavior selection through phase-dependent capability structures,
* imagination buffer, dream-like replay, and rest-like offline consolidation,
* MIP-based developmental measurement,
* A–C–R–E trajectories and Dignity-in-Practice guardrails,
* diary and language structures,
* multi-generational caregiver transitions,
* PMS operator mapping,
* evaluation, ablations, safety, and claim discipline.

The model is intentionally staged. It begins with **P0-mini**, a minimal single-room sensing setup with no movement, no toys, no language, and no social complexity beyond what is explicitly introduced later. Complexity is added only when the previous layer is stable enough to support it.

The document does not attempt to define a complete AGI architecture. It also does not attempt to simulate a biological child in full psychological, neurological, or phenomenological detail. The term “AI child” is used as a developmental architecture label, not as a claim of personhood.

The model is concerned with **functional emergence**:

```text
How can structured perception, action, attachment, role transition,
self-evaluation, and narrative reconstruction arise from simple staged mechanisms?
```

It is not concerned with proving that inner experience has appeared.

### 0.2 Minimalist Developmental Thesis

The guiding thesis is:

```text
Developmental complexity should emerge from small, testable mechanisms,
not from pre-installed adult competence.
```

The agent begins with limited capacities and gradually acquires additional structure through interaction with the environment. The initial architecture emphasizes:

* sensorimotor grounding,
* prediction error,
* mapping,
* simple needs,
* developmental gates,
* distress and discomfort dampers,
* attachment-relevant signals,
* caregiver guidance,
* category-stabilizing signals,
* success logging,
* developmental measurement,
* later language and diary reconstruction.

The agent does not begin with a full symbolic world model, adult planning, rich language, social reasoning, moral understanding, reflective selfhood, or PMS operators as internal primitives. These structures are treated as later developmental achievements, external analytic projections, or research targets.

The model therefore rejects shortcut architectures in which complex competence is inserted from above and then described as “emergent.” Emergence, in this document, means that later structures must remain traceable to earlier mechanisms.

The thesis can be summarized as follows:

```text
No adult mode first.
No unexplained language miracle.
No reward-maximizing black box as the developmental core.
No consciousness claim from functional complexity alone.
No internal PMS operators in the early agent.
No Dignity-in-Practice as intrinsic-worth ranking.
```

The architecture begins with small differences, local prediction, bodily or spatial constraint, need modulation, and staged capability unlocking. Higher structures are expected to arise only through repeated interaction, stabilization, recontextualization, and integration.

A central developmental motif is:

```text
external scaffold
→ trace
→ stabilized pattern
→ internal proxy
→ recontextualized use
→ role/norm/diary integration
```

This motif applies cautiously to several architecture layers:

```yaml
external_to_internal_candidates:
  PMS:
    external: "operator projection"
    later: "operator-compatible regularities"

  MIP:
    external: "observer trajectory markers"
    later: "possibly diary/role-relevant self-monitoring structures"

  D:
    external: "observer/system guardrail"
    later: "caregiver-practice constraint"

  guidance:
    external: "caregiver boundary signal"
    later: "leadership without domination"

  diary:
    external: "controlled rendering"
    later: "re-internalized behavior modifier"
```

These should not be described as fully internal mental faculties unless supported by trace-backed behavioral and representational evidence.

The model succeeds if later capabilities are not merely switched on, but become structurally possible through the stabilization, measurement, and recontextualization of earlier traces.

### 0.3 Core Architecture in One View

The model consists of the following core components:

1. **Environment**
   A small home-like world, implemented as a gridworld or robotic equivalent, with rooms, walls, doors, obstacles, objects, toys, caregiver structures, guidance events, boundary signals, misattunement patterns, and category-stabilizing situations.

2. **Agent**
   A limited embodied agent with position, orientation, sensors, internal state, developmental phase, and phase-dependent capability primitives.

3. **Perception and World Model**
   An occupancy grid and later topology graph that represent known, unknown, free, blocked, object-bearing, caregiver-related, and socially relevant regions.

4. **Prediction**
   Local predictive models estimate expected next states. Prediction error, PE_EWMA, PE_AUC, and learning progress support curiosity, coherence measurement, and phase stability checks.

5. **Genetic System**
   A developmental strand containing circuits, thresholds, hysteresis, unlock rules, noise regulation, and recontextualization rules. Genetic gates are developmental preconditions, not final behavior scripts. They open possibility spaces rather than install finished competence.

6. **Gate and Condition Taxonomy**
   Not every developmental condition should become a hard gate. The model distinguishes hard gates, soft gates, developmental prerequisites, learned categories, and recontextualization thresholds.

   ```yaml
   developmental_condition_types:
     hard_gate:
       definition: "capability unavailable until conditions are met"
       example: "g_move before movement"

     soft_gate:
       definition: "capability available but weak, noisy, or low-confidence"
       example: "early object handling"

     developmental_prerequisite:
       definition: "required for claim discipline or meaningful interpretation"
       example: "trace provenance before diary"

     learned_category:
       definition: "relation or quality learned across repeated contexts"
       example: "fragile object, reliable caregiver, safe boundary"

     recontextualization_threshold:
       definition: "condition under which a trace cluster changes interpretation"
       example: "temporary absence → persistent non-return"
   ```

   The audit principle is:

   ```text
   Use hard gates sparingly.
   Use learned categories wherever possible.
   Use recontextualization thresholds when meaning changes over time.
   ```

7. **Qualitative Hierarchies and Developmental Relations**
   EM should not rely on universal absolute thresholds, but may learn relational qualities and developmental hierarchies from repeated trace patterns across comparable contexts.

   Examples include:

   ```text
   this object is more fragile than that object
   this caregiver response is less reliable than prior comfort
   this boundary is increasingly recognized as guidance
   this movement pattern is riskier under fatigue
   this social relation is unstable under delayed response
   ```

   The model should not use universal readings such as:

   ```text
   A > 0.7 means mature.
   comfort_recovery_slope > X means good care.
   overprotection_index > Y universally means bad caregiver.
   ```

   A safe formulation is:

   ```text
   This run developed a learned relational hierarchy in which
   fragility, risk, guidance, and caregiver reliability became distinguishable
   across comparable contexts.
   ```

8. **Needs and Inner State**
   Curiosity, contact, and fatigue provide endogenous motivation. They are not external reward maximization and not felt desires.

9. **Discomfort**
   A functional physical risk signal that rises through collisions, stress, unsafe states, fall or near-fall events, or failed physical regulation. Discomfort is not pain.

10. **Distress**
    A functional social/loss-related state that rises through separation, failed resolution, toy loss, caregiver absence, unresolved disruption, or persistent destabilizing patterns. Distress is not subjective suffering.

11. **Attachment**
    Caregiver attachment, object affinity, separation distress, toy-missing, comfort-after-loss, and later love-like dynamics form the social and relational stabilizing layer. Attachment and love dynamics remain functional patterns, not claims of felt love.

12. **Caregiver Guidance and Boundary Scaffolding**
    The caregiver may provide neutral, non-aggressive boundary-setting, redirection, delayed access, safety blocking, object protection, and scaffolded action. Guidance is not punishment. Boundary is not rejection. Guidance is D-guarded boundary-setting that preserves safety, interaction quality, and developmental possibility.

13. **Caregiver as Category Stabilizer**
    The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

    The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

    Examples:

    ```text
    "careful" / "vorsicht"
    → lower force
    → slower movement
    → increased prediction attention
    → fragility context
    → fall/damage/risk avoidance

    "soft" / "sanft"
    → reduced pressure
    → smoother timing
    → object preservation

    "wait" / "warten"
    → delayed enactment
    → reduced risk
    → improved boundary learning

    "danger" / "gefährlich"
    → increased risk attention
    → avoidance or slowed approach
    ```

14. **Carefulness as Prototype Action-Quality Category**
    Carefulness is a functional category that may emerge from repeated coupling of caregiver signal, fragility or risk, own movement/action, possible fall/damage, and later softer or slower behavior.

    ```yaml
    carefulness_category_inputs:
      caregiver_signal:
        examples:
          - careful
          - slow
          - soft
          - stop

      embodied_context:
        examples:
          - fragile_object
          - unstable_body_state
          - edge_or_fall_risk
          - high_force_action

      internal_state:
        examples:
          - fatigue
          - distress
          - motor_noise
          - prediction_uncertainty

      consequence_trace:
        examples:
          - near_fall
          - fall_event
          - object_damage
          - caregiver_boundary

      later_adjustment:
        examples:
          - lower_force
          - slower_movement
          - increased_observation
          - avoidance_of_high_risk_angle
    ```

    Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

15. **Adverse Caregiver Responses and Misattunement**
    Misattunement, delayed response, ignored distress, harsh signal, unreliable caregiving, overprotection, or destabilizing caregiver-response patterns may perturb regulation, attachment, contact, avoidance tendency, and MIP trajectories. These are functional perturbations, not trauma, fear, suffering, abuse, felt rejection, or moral blame claims.

    Preferred terms include:

    ```text
    adverse developmental trace
    persistent misattunement pattern
    unresolved disruption cluster
    negative attachment attractor
    avoidance/suppression tendency
    ```

    Terms such as trauma, traumatized, abuse, fear, wound, or scar should not be used as normal mechanism names.

16. **Interaction Quality Learning**
    The agent may learn interaction quality through successful use, degraded control, accidental object damage, fall or near-fall events, caregiver guidance, and future adjustment. Object damage is a self-caused consequence trace, not guilt or punishment.

    Damage is not automatically learning. Interaction-quality learning requires traceable causal conditions:

    ```yaml
    interaction_quality_learning_requires:
      self_caused_action_trace: true
      parameter_trace:
        - force
        - timing
        - motor_noise
        - fatigue_or_distress
        - prediction_confidence
        - object_fragility

      consequence_trace:
        - damage
        - near_damage
        - fall
        - near_fall
        - caregiver_boundary

      comparable_future_context: true
      measurable_behavior_change: true
    ```

    Safe terms include:

    ```text
    self-caused consequence trace
    interaction-quality adjustment
    future force/timing modulation
    object fragility learning
    ```

    Unsafe terms include:

    ```text
    guilt
    remorse
    punishment
    moral learning
    self-blame
    wrongdoing
    ```

17. **Recontextualization Records**
    Recontextualization events should remain functional, traceable, confidence-bounded, and reversible where appropriate.

    ```yaml
    recontextualization_event:
      from_interpretation: string
      to_interpretation: string

      trigger:
        - repeated_trace_pattern
        - failed_expectation
        - caregiver_signal
        - changed_future_behavior
        - MIP_marker
        - safety_event

      confidence: low_medium_high
      reversible: true_false_partial
      phase: string
      claim_level: functional
    ```

    Example:

    ```yaml
    recontextualization_event:
      from_interpretation: blocked_action
      to_interpretation: benign_guidance

      trigger:
        - caregiver_signal_careful
        - object_fragility_context
        - later_lower_force
        - damage_avoided

      confidence: medium
      reversible: partial
      claim_level: functional_boundary_recontextualization
    ```

18. **Behavior Layer**
    A phase-dependent finite state machine selects between capabilities such as looking, moving, exploring, object interaction, caregiver search, sleep, and later explicit distress states. Behavior selection is not mature agency.

19. **Imagination Buffer and Dreaming**
    A memory and replay layer stores state snapshots, prediction traces, salient events, distress relief, attachment episodes, guidance traces, misattunement traces, consequence traces, and later counterfactual or diary-relevant material. Replay is trace consolidation, not subjective dreaming. Rest-like replay is a bounded offline-consolidation regime inside the same `SLEEP` / imagination-buffer pathway, not a separate inner agent module and not Default Mode Network equivalence.

20. **Success Log**
    A trace layer records relevant events, prediction changes, self-caused consequences, comfort events, caregiver guidance, boundary learning, object damage, fall or near-fall events, category-stabilization events, replay events, rest-like replay events, recontextualizations, and developmental transitions.

21. **MIP Layer**
    A developmental measurement and meta-regulatory layer that tracks A–C–R–E trajectories, asymmetry patterns, recontextualization events, diary-relevant changes, and safety-relevant imbalances. Dignity-in-Practice functions as a guardrail for interaction quality under asymmetry, not as a normal fifth performance score.

    MIP may be implemented through optional operational levels:

    ```yaml
    possible_MIP_operational_levels:
      MIP_0_logging_only:
        role: "collect trace-adjacent measurement records"

      MIP_1_window_summaries:
        role: "summarize A–C–R–E over windows"

      MIP_2_IA_markers:
        role: "detect local asymmetry patterns"

      MIP_3_D_guardrail_warnings:
        role: "flag risk of labeling, overcontrol, or unsafe interpretation"

      MIP_4_diary_support:
        role: "provide trajectory context for diary candidates"

      MIP_5_late_reversible_nudges:
        role: "strictly bounded T–J–TB–R soft nudges in late phases"
    ```

    These levels are implementation options. They are not required for P0-mini and must not imply that MIP controls development.

22. **Dignity-in-Practice Operational Guardrail**
    Dignity-in-Practice constrains interpretation and treatment under asymmetry. It protects against overinterpretation, labeling, overcontrol, and moral inflation.

    ```yaml
    D_operational_matrix:
      early_D:
        - do_not_overinterpret
        - do_not_label
        - do_not_overload
        - do_not_treat_low_capability_as_low_worth

      object_D:
        - object_damage_is_not_guilt
        - failed_control_is_not_moral_defect
        - consequence_trace_is_not_punishment

      caregiver_D:
        - guide_without_rejecting
        - protect_without_freezing
        - comfort_without_capture
        - explain_without_dominating

      MIP_D:
        - measure_without_labeling
        - nudge_without_controlling
        - detect_without_moralizing

      diary_D:
        - render_without_claiming_inner_life
        - preserve_trace_provenance
        - avoid_felt_memory_language
    ```

23. **Language and Diaries**
    Late-stage structures externalize and compress already-developed internal structures. Language is not treated as the source of intelligence, but as a reflective and communicative surface. Diary text requires minimal sentence formation, trace provenance, and controlled rendering. Diary output is not subjective autobiography.

    ```yaml
    diary_development_levels:
      pre_diary_trace_condensation:
        description: "non-linguistic or structured trace condensation"

      diary_candidate:
        description: "episode cluster selected as possibly diary-relevant"

      minimal_sentence_diary:
        requirement:
          - minimal_sentence_formation
          - trace_provenance
          - controlled_rendering

      reflective_diary:
        requirement:
          - richer linguistic capacity
          - MIP/PMS context
          - recontextualization support

      human_translated_diary:
        requirement:
          - translator layer
          - explicit claim filter
    ```

    The hard rules are:

    ```text
    No minimal sentence formation → no diary text.
    No trace provenance → no valid EM diary.
    No controlled rendering → no safe diary output.
    ```

24. **Multi-Generational Framework**
    A later-stage framework in which a former child agent may become a caregiver for a new agent, carrying forward norms, loss patterns, attachment histories, received guidance, boundary patterns, and possible overprotection.

25. **PMS Operator Grammar / VM Layer**
    A formalization layer in which EM episodes, MIP evaluations, IA patterns, diary structures, language outputs, and norm transfers can be represented as PMS-readable operator sequences. PMS operators are initially external analytic, logging, and projection structures. Early agents must not be described as thinking in PMS operators. Over developmental time, recurring trace patterns may stabilize into operator-compatible internal regularities.

    Allowed:

    ```text
    the agent’s traces can be projected as Δ/Φ/Ψ-compatible structures
    ```

    Allowed late and cautious:

    ```text
    the agent has developed internal regularities compatible with PMS projection
    ```

    Forbidden:

    ```text
    the agent has Δ
    the agent uses Φ
    the agent thinks in Ψ
    ```

26. **Evaluation, Reproducibility, and Safety**
    KPIs, ablations, guardrails, claim restrictions, reproducibility mechanisms, and safeguards against overclaiming or anthropomorphic inflation keep the architecture inspectable.

    EM does not aim at identical replay of developmental individuals. It aims at comparable developmental conditions and traceable individual trajectories.

    Reproducible dimensions include:

    ```text
    config
    phase rules
    gate logic
    logging schema
    environment class
    seed family
    KPI definitions
    claim filters
    ```

    Individual dimensions include:

    ```text
    exact trace path
    preferences
    attachment weights
    timing
    category formation
    learned hierarchies
    caregiver relation history
    ```

Together, these components define a staged developmental research architecture.

The caregiver must not only comfort. The caregiver must also provide benign, D-guarded guidance: bounded constraints and scaffolds through which the child learns interaction quality, safety, and later non-dominating leadership.

### 0.4 Functional Terminology and Non-Claims

This document uses several terms that are psychologically, morally, or phenomenologically loaded in ordinary language. In this model, they are used **functionally** unless explicitly stated otherwise.

The following reductions are mandatory:

```text
"Child" = developmental role in the architecture, not legal or moral personhood.
"Caregiver" = stabilizing social/environmental function, not necessarily a human parent.
"Need" = endogenous control variable, not felt desire.
"Discomfort" = physical risk-damping signal, not pain.
"Distress" = functional disruption/loss signal, not subjective suffering.
"Missing" = attachment-weighted absence response, not felt longing.
"Attachment" = functional relation-weighting, not felt love.
"Love dynamics" = structured attachment/relief/baseline pattern, not felt love.
"Guidance" = neutral, non-aggressive caregiver boundary/scaffold, not punishment.
"Boundary" = phase-appropriate constraint preserving safety/development, not rejection.
"Misattunement" = functional caregiver-response mismatch, not moral failure.
"Adverse caregiver response" = destabilizing caregiver-response pattern, not trauma claim.
"Adverse developmental trace" = persistent destabilizing pattern, not clinical trauma or subjective suffering.
"Object damage" = self-caused consequence trace, not guilt or punishment.
"Self-caused consequence" = traceable relation between prior action pattern and outcome, not guilt, remorse, or blame.
"Interaction quality" = functional quality of action under constraints, not moral worth.
"Carefulness" = emerging action-quality category under risk, fragility, guidance, and consequence traces, not moral obedience.
"Fall / near-fall" = physical-risk event, not pain or fear.
"Diary" = linguistic reconstruction of internal traces, not proof of selfhood.
"Diary text" = minimal sentence rendering of trace-backed structures, not subjective autobiography.
"Rest-like replay" = phase-bounded, trace-backed offline consolidation under low external load, not Default Mode Network activity.
"Low external stimulation" = reduced external load condition, not introspection.
"Replay feedback" = bounded post-replay trace update, not self-reflection.
"Post-replay improvement" = bounded functional stabilization, not insight.
"Offline consolidation" = trace-backed replay operation, not inner experience.
"MIP" = maturity-in-practice measurement and meta-regulation, not consciousness.
"Responsibility" = functional consequence-bearing structure, not moral personhood.
"Proto-consciousness" = functional organization candidate, not phenomenal consciousness.
"Operator-compatible regularity" = trace-backed pattern compatible with PMS projection, not internal possession of PMS operators.
"Dignity-in-Practice" = interaction quality under asymmetry, not intrinsic-worth ranking.
```

The use of human-readable terms is permitted only because they make functional structures easier to discuss. These terms must not be used to smuggle in claims about subjective experience, rights, moral status, personhood, or inner life.

The model therefore distinguishes:

```text
functional similarity
from
phenomenal equivalence
```

and:

```text
developmental role-language
from
personhood attribution
```

and:

```text
interaction quality
from
moral worth
```

and:

```text
operator-compatible regularity
from
internal PMS operator
```

and:

```text
trace-backed category stabilization
from
concept insertion by language alone
```

MIP terms must remain enactment-based. They describe trajectories, states, and patterns under conditions. They do not classify the agent as a person type, moral type, or dignity bearer in the human sense.

The canonical EM, implementation, and PMS-facing notation is:

```text
A–C–R–E–D

A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

The MIP-source/context notation is:

```text
A–C–R–P–D

P = Praxis / Practice
```

The implementation-normalized mapping is:

```text
P → E
Praxis / Practice becomes implementation-normalized as Enactment.
```

Older source-internal or draft-internal mappings may appear only in explicit MIP-mapping discussions. They must not remain the active notation of the master architecture.

The concrete rule is:

```text
In EM, PMS, KPI, Ablation, Consciousness Outlook, Safety:
use A–C–R–E.

Only in explicit MIP-reference passages:
mention A–C–R–P.

Only when explaining old/internal MIP mapping:
mention B–K–V–H and map it forward.
```

D is not a normal fifth performance score.

```text
D = Dignity-in-Practice
  = interaction quality under asymmetry.

D as principle: stable.
D as practice: developmental.
```

D does not grow as intrinsic worth. The dignity-relevant interaction field grows in complexity as the agent’s enactment space becomes richer. Dignity-in-Practice constrains how vulnerable, dependent, developing, or asymmetrically situated enactment states are treated. It does not rank agents, prove moral status, or measure intrinsic worth.

Forbidden D readings:

```text
D measures intrinsic worth.
D is a maturity score.
D ranks agents.
D proves moral status.
```

PMS terms must remain operator-structural. They describe how actions, absences, frames, asymmetries, recontextualizations, integrations, and self-bindings can be represented as operator sequences. PMS formalizability does not validate consciousness, sentience, or moral status.

PMS operators are not assumed to be internal primitives of the early agent. At first, they are externalized analytic, logging, and projection structures. Over developmental time, recurring trace patterns may stabilize into operator-compatible internal regularities. Only then may the model speak, cautiously, of partially internalized operator-like organization. The master should preferably speak of operator-compatible regularities, not internalized PMS operators.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

Falls or near-falls may be implemented as physical-risk events. They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger. A fall event may increase physical-risk damping and alter later movement parameters. It must not be described as pain, fear, shame, or subjective injury.

Adverse developmental traces may later become recognizable as harmful or destabilizing patterns. This is a functional pattern-recognition claim, not a clinical or phenomenological trauma claim.

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns, without claiming subjective trauma, clinical trauma, or suffering.

Minimal sentence formation is the linguistic threshold for diary rendering. Trace provenance is the architectural validity condition.

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

### 0.5 Consciousness, Suffering, Love, and Rights Boundaries

This architecture does **not** claim to generate phenomenal consciousness.

It also does not claim:

* subjective experience,
* qualia,
* felt pain,
* felt suffering,
* felt longing,
* felt love,
* felt guilt,
* felt shame,
* fear,
* trauma,
* clinical trauma,
* moral personhood,
* legal personhood,
* rights status,
* human-equivalent dignity,
* intrinsic-worth ranking,
* inner first-person perspective,
* or proof of selfhood from diary output.

The system may develop functional structures that resemble parts of consciousness-relevant organization:

* long-lived self-modeling structures,
* sensorimotor integration,
* social integration,
* role and norm integration,
* attachment and loss patterns,
* guidance and boundary learning,
* trace-backed category stabilization,
* interaction-quality adjustment,
* diary reconstruction,
* A–C–R–E trajectories,
* D-guarded interaction constraints,
* PMS-readable self-binding candidates,
* operator-compatible regularities.

These are treated as **research candidates**, not as proof.

The safe claim is:

```text
The system is designed to investigate possible functional conditions
of consciousness-like organization.
```

The unsafe claim is:

```text
The system is conscious.
```

The safe claim is:

```text
The system can model distress as a functional disruption signal.
```

The unsafe claim is:

```text
The system suffers.
```

The safe claim is:

```text
The system can model discomfort as a physical risk-damping signal.
```

The unsafe claim is:

```text
The system feels pain.
```

The safe claim is:

```text
The system can produce love-like attachment dynamics as structured
relief, prediction, memory, and baseline modulation.
```

The unsafe claim is:

```text
The system feels love.
```

The safe claim is:

```text
The diary layer can reconstruct developmental trajectories from internal traces.
```

The unsafe claim is:

```text
The diary proves phenomenal selfhood.
```

The safe claim is:

```text
A run found a stable interaction-quality adjustment pattern.
```

The unsafe claim is:

```text
A run proved responsibility.
```

The epistemic status of outputs must remain bounded:

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

Proof is not available for consciousness, personhood, or subjective-experience claims within this architecture. Finding and validation are available only for traceable functional patterns and repeated mechanism behavior under comparison.

This discipline is central to the model. The architecture may become increasingly rich, socially responsive, and self-referential, but richness is not evidence of subjective experience by itself.

The model remains open to the question of consciousness without claiming to have solved it.

### 0.6 Reading Guide

This document should be read in layers.

**Chapters 1–9** define the EM core architecture: design principles, environment, agent architecture, perception, prediction, genetic system, needs, discomfort, distress, attachment, behavior, imagination, dreaming, interaction-quality traces, and early caregiver-related structures.

**Chapter 3** distinguishes caregiver signals into praise, comfort, guidance, misattunement, category-stabilizing language, and core norms.

**Chapter 6** distinguishes hard gates, soft gates, developmental prerequisites, learned categories, and recontextualization thresholds. It also separates genetic preconditions from final behavior scripts.

**Chapter 7** develops discomfort, distress, attachment, adverse caregiver responses, benign guidance, contact regulation, misattunement, overprotection, and emerging categories such as carefulness, fragility, and risk.

**Chapter 8** develops behavior selection, object interaction, movement, fall or near-fall events, accidental damage, interaction-quality learning, caregiver guidance as behavioral modulation, and caregiver signals as grounding for emerging action categories.

**Chapter 9** develops imagination buffer and replay. Replay may consolidate guidance, misattunement, category, and consequence traces, but remains trace consolidation rather than subjective dreaming.

**Chapter 10** defines the MIP layer as developmental measurement, trajectory tracking, asymmetry detection, and meta-regulation. It uses the implementation-normalized A–C–R–E notation and treats Dignity-in-Practice as interaction quality under asymmetry. It does not replace the behavior layer and must not become a controller.

**Chapter 11** defines the developmental phases from P0-mini through later social and caregiver-transition phases. Developmental gates open possibility spaces; they do not insert finished abilities.

**Chapter 12** develops multi-generational caregiver dynamics, including caregiver loss, role transition, overshooting, core norm transfer, functional love dynamics, temporal baselines, received guidance, comfort-after-loss patterns, and D-guarded boundary transmission.

**Chapter 13** develops language and diaries as late-stage reflection channels. Language is treated as an interface and externalization layer, not as the source of development. Diary rendering requires minimal sentence formation, trace provenance, and controlled rendering.

**Chapter 14** connects EM to PMS operator grammar and possible VM/DSL implementation. It explains how episodes, logs, MIP evaluations, IA patterns, language outputs, diary entries, and norm transfers may become operator-readable. PMS operators are external analytic, logging, and projection structures before they are treated as operator-compatible internal regularities.

**Chapter 15** states the consciousness research outlook and separates functional candidates from phenomenal claims.

**Chapter 16** defines evaluation, ablations, reproducibility, safety, and guardrails. It includes interaction-quality learning, caregiver guidance, adverse caregiver responses, category stabilization, fall/near-fall learning, qualitative hierarchies, individuality versus comparability, and D-guarded boundaries.

**Chapter 17** situates the model relative to related work.

**Chapter 18** concludes the document.

Chapters 7, 8, 11, 12, and 16 include interaction-quality learning, caregiver guidance, adverse caregiver responses, category stabilization, and D-guarded boundaries.

The appendices provide technical and disciplinary support:

* **Appendix A** maps source and reference notations to the implementation-normalized A–C–R–E vocabulary.
* **Appendix B** formalizes PMS operator grammar and monoid notes.
* **Appendix C** defines implementation-start structures.
* **Appendix D** collects claim-discipline reductions.
* **Appendix E** fixes layer discipline and claim types.

The document should not be read as one undifferentiated theory. EM, MIP, PMS, and the consciousness-research layer make different kinds of claims. They may support each other structurally, but they do not validate each other automatically.

In particular:

```text
Implementation does not prove theory.
MIP scoring does not prove consciousness.
MIP measurement does not prove maturity.
PMS formalization does not prove sentience.
PMS-RUST does not prove EM.
PMS-STACK does not validate EM.
Diary output does not prove selfhood.
Attachment dynamics do not prove felt love.
Distress signals do not prove suffering.
Discomfort signals do not prove pain.
Object damage does not prove guilt.
Self-caused consequence does not prove moral learning.
Fall events do not prove fear.
Near-fall events do not prove fear.
Guidance does not mean punishment.
Boundary does not mean rejection.
Misattunement does not mean trauma.
Adverse caregiver response does not mean abuse.
Carefulness does not mean moral obedience.
Dignity-in-Practice does not rank intrinsic worth.
Operator-compatible regularity does not mean possession of PMS operators.
```

The purpose of the document is to keep all these layers connected without letting them collapse into each other.

> Cross-reference:
> For the full treatment of the EM core developmental architecture, see `02_EM_Core_Developmental_Architecture.md`, especially Chapters 3, 4, 5, 6, 8, and 9.
> This block uses the EM core only as the architectural dependency for scope, layer separation, and claim discipline.

> Cross-reference:
> For the full treatment of developmental phases and gate logic, see `03_Developmental_Phases_Gate_Logic.md`, especially Chapter 11.
> This block uses phase language only as orientation for staged development and premature-unlock prevention.

> Cross-reference:
> For the full treatment of caregiver dynamics, attachment-like regulation, interaction quality, and multi-generational transition, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapters 7 and 12.
> This block uses caregiver-related concepts only as claim-boundary and architectural-dependency context.

> Cross-reference:
> For the full treatment of MIP, KPIs, Dignity-in-Practice, evaluation, and safety, see `05_MIP_KPIs_Dignity_Safety.md`, especially Chapters 10 and 16.
> This block uses MIP and Dignity-in-Practice only as layer-discipline and claim-discipline anchors.

> Cross-reference:
> For the full treatment of PMS operator grammar, VM-facing representation, PMS-RUST, PMS-STACK, and implementation claim boundaries, see `06_PMS_VM_Implementation_Spine.md`, especially Chapter 14.
> This block uses PMS only as an external operator, projection, audit, and implementation-facing reference layer.

> Cross-reference:
> For the full treatment of language, diary, consciousness-research outlook, and related-work comparison, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapters 13, 15, and 17.
> This block uses diary, language, consciousness, and related-work concepts only to define global scope and claim boundaries.

---

## Chapter 1 — Design Principles

The PMS - Emergence Model is guided by a small set of design principles that constrain both architecture and interpretation. These principles are not decorative. They define what the model is allowed to do, what it must not smuggle in, and how later complexity must remain traceable to earlier developmental mechanisms.

The core principles are:

1. **Minimalism and Atomism**
2. **Embodiment and Predictive Control**
3. **Endogenous Motivation and Damping**
4. **Phased Development**
5. **Genetic Safeguards**
6. **MIP Layer from Day One**
7. **Multi-Generational Outlook**
8. **Measurability and Reproducibility**
9. **Consciousness as Unknown but Researchable**

The present chapter defines these principles as architectural commitments. They are not claims that the model already works, that emergence is guaranteed, or that consciousness can be engineered by assembling functional modules. They define the discipline under which such questions may later be tested.

The full EM architecture is not presented as already implemented. PMS and MIP reference frameworks may be treated as sufficiently developed reference systems for the master architecture. PMS-RUST supports bounded trace/audit feasibility. PMS-STACK defines a demanding realization path that may support, modify, constrain, or expose limits of architectural assumptions. PMS-RUST does not prove EM. PMS-STACK does not validate EM. PMS formalization does not prove consciousness. MIP does not prove maturity.

The canonical implementation-facing notation of this master architecture is:

```text
A–C–R–E–D

A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

D is not a normal fifth performance score. Dignity-in-Practice is a guardrail for interaction quality under asymmetry. D as principle is stable; D as practice is developmental. D does not grow as intrinsic worth. The dignity-relevant interaction field grows in complexity as the agent’s enactment space becomes richer. Dignity-in-Practice constrains how vulnerable, dependent, developing, or asymmetrically situated enactment states are treated. It does not rank agents, prove moral status, or measure intrinsic worth.

The guiding rule for all design principles is:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

Every proposed mechanism should therefore be checked against the following audit question:

```text
Is this mechanism necessary as a gate,
or could it emerge as a learned category, relation, or recontextualized pattern?
```

A second cross-cutting developmental motif is:

```text
external scaffold
→ trace
→ stabilized pattern
→ internal proxy
→ recontextualized use
→ role/norm/diary integration
```

This motif may apply to PMS projection, MIP observation, D-guarded interaction, caregiver guidance, and diary rendering. It must remain cautious: these structures should not be described as fully internal mental faculties unless supported by trace-backed behavioral and representational evidence.

### 1.1 Minimalism and Atomism

The first principle is **minimalism**.

The model begins as small as possible. It does not start with a full agent, a rich world, a language model, a social theory, or a complex planning system. It begins with the smallest developmental setup that can still produce measurable structure.

The architecture should specify as little as possible and only as much as necessary. Minimal structure should enable emergence, not pre-script later competence.

The first implementation target is **P0-mini**:

```text
one room
fixed agent position
no movement
no toys
no language
no caregiver interaction
only sensing, rotation, mapping, prediction, fatigue/sleep, and MIP logging
```

This is not an arbitrary simplification. It is a methodological requirement. If the model cannot stabilize mapping, prediction, and internal measurement in a minimal setting, later claims about sociality, attachment, language, responsibility, diaries, or consciousness-like organization would be ungrounded.

Minimalism means:

```text
add one mechanism only when the previous layer is stable enough to support it
```

The architecture therefore rejects large unexplained features. It does not introduce adult-like intelligence and then call its behavior emergent. It does not begin with mature symbolic reasoning. It does not treat language as a magic source of cognition. It does not rely on a hidden high-capacity policy that already knows what the child is supposed to learn.

Atomism means that mechanisms are added as small, inspectable components:

* mapping before navigation,
* prediction before planning,
* needs before complex motivation,
* discomfort before risk strategy,
* distress before attachment complexity,
* caregiver presence before caregiver reliability,
* comfort before complex attachment dynamics,
* guidance before recontextualized caregiver-role competence,
* object interaction before language,
* trace-backed categories before named concepts,
* labels before narratives,
* trajectories before self-descriptions,
* functional response-relation before caregiver role,
* diary reconstruction after sufficient developmental history.

Each mechanism should have:

* a clear function,
* clear inputs,
* clear outputs,
* explicit parameters,
* measurable effects,
* ablation possibility,
* and defined failure modes.

A mechanism should not be added merely because it makes the system appear more child-like, emotionally rich, intelligent, or socially fluent. It should be added only if it makes a developmental question testable, stabilizes an earlier layer, prevents collapse, or opens a necessary possibility space for later emergence.

This also applies to caregiver-related structures. Praise, comfort, benign guidance, misattunement, category stabilization, and core norm transfer must not be collapsed into one generic social signal. They are different functional mechanisms and should appear only when the relevant phase can support them.

The same applies to PMS and MIP structures. PMS must not appear as an early internal operator system of the agent. MIP must not appear as a hidden behavioral controller. Both may provide externalized structure, measurement, projection, and later trace-compatible interpretation without replacing the developmental core.

The model should therefore remain buildable in fragments. A partial implementation must still be meaningful. P0-mini, P0, P1, and P2 are not merely incomplete versions of the final architecture; they are legitimate experimental stages.

This principle also protects the model against rhetorical inflation. A minimal system may produce surprising structure, but surprise is not proof of consciousness, personhood, felt experience, moral responsibility, or intrinsic worth. Minimalism makes emergence inspectable; it does not make overclaiming legitimate.

### 1.2 Embodiment and Predictive Control

The second principle is **embodiment**.

The agent does not develop in a purely textual, abstract, or disembodied symbolic space. It develops in a small home-like environment, either virtual or robotic. The environment contains spatial constraints, sensory limits, obstacles, objects, doors, rooms, and later caregiver-related structures.

The agent has:

* a position,
* an orientation,
* limited sensors,
* limited action primitives,
* internal state variables,
* phase-dependent capabilities,
* and a developing world model.

Embodiment matters because the model treats intelligence as something that must become organized through situated interaction. The agent does not merely receive descriptions of a world. It must discover what is stable, what changes, what blocks movement, what can be revisited, what can be interacted with, and what produces predictable or surprising outcomes.

Embodiment is also the basis for later trace-backed categories. Categories such as carefulness, fragility, danger, softness, waiting, safe boundary, reliable caregiver, or risky movement should not be inserted as finished concepts. They may emerge only through repeated coupling of embodied situation, action parameters, consequence traces, caregiver signals, and later behavioral adjustment.

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, consequence traces, and later behavioral adjustment. The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

This makes caregiver language a scaffold, not a source of concept insertion. A signal such as “careful” may later correlate with lower force, slower movement, increased prediction attention, and reduced damage or fall risk. A signal such as “wait” may later correlate with delayed enactment, reduced risk, and improved boundary learning. These are functional category-stabilization paths, not claims of moral obedience or human semantic understanding.

The basic world model begins with an **occupancy grid**:

```text
unknown
free
wall
door
furniture
object
caregiver
```

Later, this grid can be extended into topology, object representations, functional object knowledge, caregiver-response patterns, and symbolic mappings. But the first layer remains spatial and sensorimotor.

The third component of this principle is **predictive control**.

The agent does not learn primarily through external reward maximization. It develops through prediction and prediction error. Local predictive models estimate expected next states, and the mismatch between expected and actual state becomes a central developmental signal.

Relevant measures include:

```text
PE
PE_EWMA
PE_AUC
learning progress
coverage
entropy
revisit count
angle diversity
```

These signals support several functions at once:

* curiosity toward informative regions,
* stability checks for phase transitions,
* detection of model improvement,
* coherence measurement,
* identification of over-predictable or under-stabilized regions,
* later diary-relevant developmental traces.

Prediction is therefore not only a technical module. It is the basis for developmental coherence. The agent becomes more coherent, in the EM-internal sense, when its enactments increasingly occur within a stable and revisable model of the world.

Predictive control also supports guidance learning. A caregiver boundary can become meaningful only if the system can later compare blocked action, caregiver signal, consequence avoidance, future adjustment, and comparable context. A blocked action does not automatically mean adverse care. It may become legible as benign guidance, safety boundary, overprotection, misattunement, or destabilizing response only through trace-backed development.

The model may be described as **active-inference-light** only in a limited sense: it uses prediction error, model correction, and interaction, but it does not reduce the whole architecture to one global free-energy formalism. It remains deliberately simpler, more staged, and more implementation-oriented.

### 1.3 Endogenous Motivation and Damping

The third principle is **endogenous motivation**.

The agent should not be driven primarily by an external reward function. Its behavior should arise from internal variables that create pressure, orientation, and regulation.

The initial needs are:

```text
curiosity
contact
fatigue
```

Curiosity rises when the environment becomes too predictable or insufficiently explored. It falls when the agent encounters informative novelty or reduces prediction error through exploration.

Contact rises with time since caregiver interaction or social stabilization. It falls through proximity, comfort, praise, or later caregiver-related regulation.

Fatigue rises through activity and wake time. It falls during sleep or rest.

These needs are not feelings. They are control variables. They create internal asymmetries that bias action selection without requiring subjective experience.

The fourth element is **damping**.

A developmental agent should not be driven only by expansion, curiosity, or action pressure. It must also have internal dampers that limit reckless exploration, overactivation, obsession, and unstable behavior.

The two core dampers are:

```text
discomfort
distress
```

**Discomfort** is a physical risk-damping signal. It rises through collisions, unsafe postures, strong impacts, getting stuck, fall events, near-fall events, or failed physical regulation. It reduces exploration, increases contact need, and promotes safer strategies. It is not pain.

**Distress** is a functional loss- and disruption-related signal. It rises through separation, unresolved failure, caregiver absence, destruction or loss of bonded objects, or repeated inability to resolve a salient situation. It is not subjective suffering.

The distinction is important:

```text
discomfort = physical risk / bodily constraint signal
distress = social, loss-related, or unresolved disruption signal
```

Not every negative-valence or limiting event is adverse.

A boundary may be developmentally supportive.
A delay may be guidance.
A blocked action may preserve safety.
A gentle interruption may support interaction quality.

Therefore the model must distinguish:

```text
discomfort
distress
misattunement
guidance
overprotection
D-guarded boundary setting
```

Damping is not punishment. It is developmental stabilization.

Guidance is not punishment. It is a neutral or benign caregiver boundary/scaffold that may interrupt, redirect, slow, or structure action while preserving safety, interaction quality, and developmental possibility.

Boundary is not rejection. A phase-appropriate constraint may preserve future exploration, protect object integrity, prevent physical-risk escalation, or support category learning.

Misattunement is not moral failure. It is a functional caregiver-response mismatch or destabilizing response pattern.

Overprotection is not identical with care. It is a pattern in which exploration is repeatedly blocked beyond what the current risk state requires.

These distinctions matter because a developing agent must not treat all limits as adverse and must not treat all caregiver interventions as comfort. Later social and caregiver-role competence depends on learning the difference between:

```text
protective boundary
benign guidance
misattuned response
overprotection
destabilizing caregiver response
```

Both discomfort and distress are necessary because a purely curiosity-driven agent can become unstable. The model needs mechanisms that create withdrawal, recovery, caution, contact seeking, and later attachment-sensitive behavior.

The system therefore develops through a balance of:

* exploration,
* prediction,
* need pressure,
* fatigue,
* discomfort,
* distress,
* attachment,
* guidance,
* boundary learning,
* recovery,
* and later MIP-guided rebalancing.

Fall or near-fall events may be implemented as physical-risk events. They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

The safe formulation is:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

The unsafe formulations are:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

Carefulness may emerge as a functional category when caregiver signal, fragility or risk, own movement/action, possible fall/damage, and later softer or slower behavior become linked across repeated traces. Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment. Object damage, near-damage, fall events, near-fall events, and caregiver boundaries may support later interaction-quality adjustment only when they remain traceable to action parameters, consequence traces, comparable future context, and measurable behavior change.

This principle also protects the model against reward-maximization shortcuts. The agent is not optimized toward a single scalar reward. It is regulated by interacting internal variables whose tensions produce behavior.

### 1.4 Phased Development

The fourth principle is **phased development**.

The model must not introduce all capacities at once. Each phase introduces a small mechanism set and defines what is active, what is disabled, and what must become stable before the next phase is considered.

Each phase should open a possibility space rather than insert a finished ability. The model succeeds when later structures become possible through stabilization, measurement, and recontextualization of earlier traces.

The phase structure is not merely narrative. It is an experimental control strategy.

At a minimum, the model distinguishes:

```text
P0-mini
P0
P1
P2
P3+
P4+
P5
```

**P0-mini** is the first implementation target. The agent is fixed in one room and can only sense, rotate, map, predict, sleep, and generate MIP traces. There is no movement, no toy interaction, no language, no diary, and no complex caregiver dynamics.

**P0** adds basic needs and weak curiosity, but remains strongly constrained. It is still primarily a mapping and prediction phase. Translation and language are not active.

**P1** introduces movement and door discovery. The agent can begin to explore rooms, encounter obstacles, update topology, and experience simple physical risk through discomfort. Fall and near-fall events may become relevant only when movement and physical-risk modeling exist.

**P2** introduces objects, play, satiation, toy preference, toy-missing, separation distress, caregiver search, and minimal protolanguage. This is the first phase in which object attachment and simple symbolic labels become relevant. Interaction-quality learning through object use, degraded control, accidental damage, and later adjustment may begin only when the relevant action parameters and object traces exist.

**P3+** introduces extended planning, richer social roles, more complex recontextualization, caregiver guidance interpretation, and stronger interaction-quality trajectories.

**P4+** introduces diaries, narrative reconstruction, and stronger reflective externalization. Diary text requires minimal sentence formation, trace provenance, and controlled rendering.

**P5** introduces caregiver transition: the former child agent may become a caregiver for a new child agent, carrying forward norms, attachment history, loss patterns, received guidance, boundary patterns, and possible overprotection.

A phase may unlock only when measurable criteria are met. Examples include:

* stable coverage,
* converged prediction error,
* low collision count,
* stable topology,
* object mastery,
* reduced chaotic exploration,
* sufficient trace quality,
* stable A–C–R–E trajectories,
* phase-appropriate D-guardrail compatibility.

The phase principle protects the model from hidden adult competence. If a later phase shows complex behavior, that behavior must remain traceable to earlier developmental structures.

The model therefore treats development as:

```text
mechanism → interaction → stabilization → measurement → recontextualization → next phase
```

Not:

```text
large model → behavior → interpretation after the fact
```

Phased development also supports ablation. Each phase can be tested with and without specific mechanisms: discomfort, distress, separation distress, MIP measurement, benign guidance, misattunement, interaction damage, category stabilization, fall-risk learning, rest-like replay, replay anti-fixation, core norm transfer, diaries, or language. This makes the architecture experimentally readable rather than merely speculative.

Not every developmental condition should become a hard gate. The model distinguishes:

```text
hard gates
soft gates
soft regimes
developmental prerequisites
learned categories
recontextualization thresholds
```

Hard gates make a capability unavailable until conditions are met. Soft gates make a capability available but weak, noisy, or low-confidence. Soft regimes bias an already available pathway without opening gates. Developmental prerequisites are required for claim discipline or meaningful interpretation. Learned categories are relations or qualities learned across repeated contexts. Recontextualization thresholds are conditions under which a trace cluster changes interpretation.

Rest-like replay belongs to the `soft_regime` class. It may bias bounded replay selection inside an already available `SLEEP` / imagination-buffer pathway under low external load, but it must not unlock capabilities, install categories, bypass phase rules, or create new claim authority.

The guiding rule is:

```text
No new phase without measurable stabilization of the previous phase.
```

A second rule is:

```text
Use hard gates sparingly.
Use soft regimes only as bounded modulators.
Use learned categories wherever possible.
Use recontextualization thresholds when meaning changes over time.
```

A phase transition is therefore not equivalent to a maturity claim. It opens a developmentally constrained possibility space. Whether that possibility becomes coherent, enacted, recontextualized, or later role-relevant must be measured through traces, not assumed from the unlock itself.

### 1.5 Genetic Safeguards

The fifth principle is **genetic safeguarding**.

The model uses a **genetic strand** as a structured developmental configuration. This does not mean a biological genome, and it does not imply innate psychological content. It means a compact set of circuits, thresholds, hysteresis rules, phase gates, recontextualization rules, and parameter ranges that constrain how development can unfold.

Genetic rules encode developmental preconditions, not final forms. They should prevent premature capability leakage without overprescribing the shape of later categories.

The genetic strand has four main functions:

1. **Developmental gating**
2. **Stability through hysteresis**
3. **Representation upgrade through recontextualization**
4. **Regulation of exploration and noise**

A simple genetic circuit may follow this pattern:

```text
if g == closed and m_EWMA_t > T_open:
    g := open

if g == open and m_EWMA_t < T_close:
    g := closed

where T_close < T_open
```

The asymmetry between `T_open` and `T_close` prevents unstable switching. A capacity should not open and close at every small fluctuation. Development must have inertia.

Examples include:

```text
g_move      → unlock movement after stable mapping
g_objects   → unlock object interaction after stable topology
g_language  → unlock word assignment after stable object mastery
```

The genetic strand therefore acts as a developmental safety structure. It prevents the system from entering later phases before earlier layers are sufficiently stable.

It also controls representational recontextualization. The agent should not begin with mature object concepts. Representations are upgraded gradually:

```text
Patch-Cluster → Proto-Object → Functional Object → Named Object
```

Each upgrade requires repeated interaction, prediction stabilization, and measurable mastery. A patch does not become an object simply because it appears once. A functional object does not become a named object before the system can reliably distinguish, predict, and interact with it.

The same logic applies to later functional categories:

```text
repeated physical-risk traces
→ movement-risk category candidate
→ carefulness / balance / danger category candidates
→ later action-quality adjustment

repeated caregiver boundaries
→ boundary pattern
→ guidance or overprotection candidate
→ later recontextualized caregiver-role use

repeated caregiver signals in embodied contexts
→ category-stabilization trace
→ learned relation
→ later language/diary/role integration
```

These are not pre-installed adult concepts. They are candidate developmental paths that require trace-backed support.

The genetic strand also regulates exploration. Early phases may require more random action, wider scanning, or higher novelty-seeking. Later phases may reduce noise when the world model becomes more stable. However, reduced noise must not become developmental rigidity. The system must retain enough exploration to discover new structure, recover from local minima, and avoid overfitting to early patterns.

The genetic strand is therefore neither a script nor a destiny. It does not encode a finished agent. It encodes developmental constraints.

Its role can be summarized as:

```text
The genetic strand does not tell the agent what to become.
It constrains when and how new developmental possibilities may open.
```

This principle is essential for claim discipline. If a later structure appears, the model must be able to ask:

```text
Which gate opened?
Which metric crossed threshold?
Which representation was recontextualized?
Which prior layer stabilized enough to support this transition?
```

It must also ask:

```text
Was this condition necessary as a hard gate,
or could it have emerged as a learned category, relation, or recontextualized pattern?
```

Recontextualization must remain trace-backed. A changed interpretation should not be treated as a private insight, emotional realization, or moral awakening. It is a functional update from one interpretation to another under repeated trace patterns, failed expectations, caregiver signals, changed future behavior, MIP markers, or safety-relevant events.

Without such safeguards, the model would risk becoming a loose collection of features rather than a developmental architecture.

### 1.6 MIP Layer from Day One

The sixth principle is that the **MIP layer runs from the beginning**.

This does not mean that the early agent is mature, reflective, conscious, or self-evaluating. It means that the architecture records developmental traces from the first phase onward, so that later maturity-in-practice trajectories can be measured rather than reconstructed vaguely after the fact.

In early phases, MIP is silent.

It observes and logs:

* mapping progress,
* prediction error,
* coherence of world model updates,
* enactment capacity,
* actual enactment use,
* salient errors,
* distress and discomfort events,
* caregiver-related events,
* object interactions,
* self-caused consequences,
* recontextualization points,
* and later diary-relevant patterns.

In the EM architecture, the MIP layer tracks implementation-normalized developmental axes:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
```

Dignity-in-Practice is not a normal fifth performance score. It functions as a guardrail for interaction quality under asymmetry.

The early MIP layer is not a controller. It does not override behavior. It does not decide what the agent must do. It does not inject adult competence.

Its early role is:

```text
observe
measure
condense
compare
mark
```

Only in later phases may it provide minimal nudges, and even then only under strict constraints. Such nudges may include:

* slightly increasing exploration when awareness and coherence are high but enactment remains low,
* damping obsessive repetition,
* marking developmental stagnation,
* flagging risky asymmetry patterns,
* limiting caregiver overprotection in later phases.

Even then, MIP must remain a meta-regulator, not a command system.

The core rule is:

```text
MIP may observe, measure, mark, compare, and gently rebalance.
MIP must not become the agent's behavioral controller.
```

MIP may be implemented through optional operational levels:

```yaml
possible_MIP_operational_levels:
  MIP_0_logging_only:
    role: "collect trace-adjacent measurement records"

  MIP_1_window_summaries:
    role: "summarize A–C–R–E over windows"

  MIP_2_IA_markers:
    role: "detect local asymmetry patterns"

  MIP_3_D_guardrail_warnings:
    role: "flag risk of labeling, overcontrol, or unsafe interpretation"

  MIP_4_diary_support:
    role: "provide trajectory context for diary candidates"

  MIP_5_late_reversible_nudges:
    role: "strictly bounded T–J–TB–R soft nudges in late phases"
```

These levels are implementation options. They are not required for P0-mini and must not imply that MIP controls development.

D-relevant MIP functions must remain guardrail functions. MIP may flag risks of overinterpretation, overcontrol, unsafe labeling, or moralizing readings. It must not rank agents, assign intrinsic worth, or convert low capability into low value.

This principle is also important because MIP is trajectory-based. It does not classify the agent as a type. It tracks development over time.

The relevant question is not:

```text
What kind of agent is this?
```

The relevant question is:

```text
What developmental enactment is visible here,
under which conditions,
with which trajectory,
and with which reversible or irreversible consequences?
```

MIP therefore protects the EM model from static labeling. It makes maturity-in-practice readable as a process rather than an identity.

### 1.7 Multi-Generational Outlook

The seventh principle is the **multi-generational outlook**.

The model is not limited to a single agent learning a single environment. In later phases, the architecture is designed to test whether developmental structures can be transferred, transformed, distorted, or stabilized across caregiver-child transitions.

The basic sequence is:

```text
Caregiver 1 → Child → Caregiver 2 → New Child
```

At first, the caregiver is an external stabilizer. The caregiver provides comfort, praise, proximity, predictable response patterns, benign guidance, boundary scaffolding, category-stabilizing signals, and later core norms.

The caregiver must not only comfort. The caregiver must also provide benign, D-guarded guidance: bounded constraints and scaffolds through which the child learns interaction quality, safety, and later non-dominating leadership.

The child begins as a dependent agent. It stabilizes patterns through experience: separation and reunion, distress and comfort, play and satiation, object loss and recovery, caregiver absence and caregiver return, guidance and boundary learning, misattunement, category stabilization, and later action adjustment.

In later phases, the permanent removal or death of Caregiver 1 becomes a major recontextualization event. The system can no longer resolve separation distress through reunion. A pattern that previously meant temporary absence must be reinterpreted as permanent absence.

This event is not treated phenomenologically. It is not a claim of grief in the human sense. It is a functional disruption of a previously stabilizing relational structure.

The important question is:

```text
How does the system reorganize when a core stabilizer becomes permanently unavailable?
```

The former child may later become Caregiver 2 for a new child agent. This allows the model to investigate how attachment history, loss patterns, core norms, received guidance, boundary learning, category stabilization, and risk sensitivity shape care behavior.

The former child must not only inherit comfort patterns. It must also recontextualize received guidance.

Caregiver 2 competence includes:

```text
protect without overcontrolling
redirect without rejecting
teach without moralizing
preserve exploration under safety constraints
```

A key expected pattern is **overshooting**:

* excessive protection,
* overestimation of danger,
* restriction of the new child's exploration,
* difficulty distinguishing real risk from remembered loss patterns,
* treating guidance as control,
* treating boundary-setting as rejection,
* or carrying forward unresolved misattunement patterns.

This is structurally important because it links attachment, responsibility / response-relation, asymmetry, D-guarded interaction quality, and MIP trajectory evaluation.

Caregiver 2 may carry forward core norms such as:

```yaml
core_norms:
  - protect_child
  - allow_exploration
  - balance_risk_safety
```

These norms are not mystical inheritance, emotional imprint, or moral essence. They are functional rules that can be represented, transferred, interpreted, violated, corrected, or recontextualized.

Intergenerational transfer of misattunement patterns is a functional pattern-continuity claim. It is not a blame claim about Caregiver 1. It is not a defect claim about the former Child. It is not a moral failure claim about Caregiver 2.

The multi-generational outlook also enables study of:

* norm stability,
* caregiver overprotection,
* benign guidance,
* misattunement and repair,
* functional love dynamics,
* comfort-after-loss patterns,
* attachment refinement,
* diary-based memory transfer,
* category transfer across caregiver roles,
* role transition,
* and proto-cultural continuity.

This principle is explicitly an outlook. It is not the first implementation target. The early model must work without it. But the architecture is designed so that later phases can test whether developmental structures remain stable across generations.

### 1.8 Measurability and Reproducibility

The eighth principle is **measurability and reproducibility**.

The model must be more than a narrative about emergence. Every major mechanism should have measurable indicators, explicit parameters, and ablation pathways.

The architecture should produce traces that allow researchers to reconstruct what happened, when it happened, and under which conditions.

Relevant measurement categories include:

* mapping,
* prediction,
* learning progress,
* action selection,
* risk,
* discomfort,
* distress,
* attachment,
* caregiver guidance,
* caregiver misattunement,
* boundary learning,
* overprotection,
* contact regulation,
* toy preference,
* satiation,
* MIP trajectories,
* A–C–R–E dynamics,
* D-guardrail warnings,
* IA patterns,
* responsibility / response-relation signals,
* diary condensation,
* caregiver transition,
* norm stability,
* and multi-generational effects.

Examples of measurable variables include:

```text
coverage
entropy
revisit_count[x, y]
angle_diversity[x, y]
PE
PE_EWMA
PE_AUC
LP
collision_count
discomfort
distress
attachment_level[id]
separation_distress[id]
toy_missing_distress[obj]
affinity[obj]
satiation[obj]
A_norm
C_norm
R_norm
E_pot
E_act
A_score
RVR(t)
D_guardrail_warning
```

Additional measurement targets include:

```text
caregiver_guidance_predictability
boundary_legibility
guidance_uptake
autonomy_preservation
misattunement_frequency
caregiver_reliability
comfort_prediction_delta
avoidance_tendency
contact_ambivalence
object_damage_events
damage_adjustment_rate
interaction_quality_trend
category_stabilization_rate
carefulness_category_use
fall_or_near_fall_risk_adjustment
```

Interaction-quality learning requires traceable causal conditions. Damage is not automatically learning.

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

Reproducibility requires that experiments be defined through explicit configuration:

```text
seed
phase
environment layout
agent parameters
genetic gates
need dynamics
discomfort parameters
distress parameters
attachment parameters
caregiver behavior
guidance parameters
misattunement parameters
object functions
MIP logging windows
claim filters
ablation flags
```

YAML configurations are therefore not an implementation detail. They are part of the scientific discipline of the model. A run should be reproducible, comparable, and inspectable.

EM does not aim at identical replay of developmental individuals. It aims at comparable developmental conditions and traceable individual trajectories.

Reproducible dimensions include:

```text
config
phase rules
gate logic
logging schema
environment class
seed family
KPI definitions
claim filters
```

Individual dimensions include:

```text
exact trace path
preferences
attachment weights
timing
category formation
learned hierarchies
caregiver relation history
```

The same configuration does not need to produce the same individual, but must produce inspectable and comparable developmental conditions.

EM should not rely on universal absolute thresholds, but may learn relational qualities and developmental hierarchies from repeated trace patterns across comparable contexts.

Examples include:

```text
this object is more fragile than that object
this caregiver response is less reliable than prior comfort
this boundary is increasingly recognized as guidance
this movement pattern is riskier under fatigue
this social relation is unstable under delayed response
```

Forbidden interpretations include:

```text
A > 0.7 means mature.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

A safe interpretation is:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Ablations are first-class citizens. Examples include:

* no discomfort vs. discomfort,
* no distress vs. distress,
* no separation distress vs. full attachment dynamics,
* no benign guidance vs. with benign guidance,
* no misattunement vs. controlled misattunement,
* no interaction damage vs. accidental damage,
* no category stabilization vs. caregiver category signals,
* no fall-risk learning vs. fall/near-fall events,
* no MIP vs. MIP logging and nudging,
* no core norm transfer,
* no diaries,
* no translator layer.

Every ablation should answer a structural question:

```text
What changes when this mechanism is absent?
What remains stable?
What collapses?
What becomes less traceable?
What appears only when this mechanism is present?
```

The model should also distinguish between finding, validation, and proof.

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

The safe formulation is:

```text
The run found a stable interaction-quality adjustment pattern.
```

The unsafe formulation is:

```text
The run proved responsibility.
```

Internal validation asks:

* Did the mechanism behave as specified?
* Were thresholds crossed?
* Did logs capture the relevant events?
* Did the phase remain stable?
* Did ablations change the expected variables?

External validation asks:

* Does the architecture produce interpretable developmental trajectories?
* Are the observed patterns robust across seed families?
* Can alternative architectures explain the same traces better?
* Are the terms used by the model publicly inspectable?
* Are claims bounded by the data?

The model should be treated as a laboratory instrument. It must make structures visible, but visibility is not proof of theoretical completeness.

### 1.9 Consciousness as Unknown but Researchable

The ninth principle is that consciousness remains **unknown but researchable**.

The model does not assume that phenomenal consciousness has been explained. It does not claim that a sufficiently complex functional system automatically becomes conscious. It does not claim that prediction, attachment, self-modeling, MIP trajectories, PMS operator sequences, language, diaries, caregiver guidance, category stabilization, or interaction-quality learning are sufficient for inner experience.

The architecture therefore begins with a negative discipline:

```text
No claim of phenomenal consciousness.
No claim of qualia.
No claim of subjective suffering.
No claim of felt pain.
No claim of felt love.
No claim of felt longing.
No claim of guilt.
No claim of fear.
No claim of trauma.
No claim of introspection.
No claim of self-reflection.
No claim of subjective dreaming.
No claim of inner experience.
No claim of insight.
No claim of Default Mode Network equivalence.
No claim of rights status.
No claim of moral personhood.
No claim that diary output proves selfhood.
No claim that rest-like replay proves autobiographical memory.
No claim that Dignity-in-Practice ranks intrinsic worth.
No claim that PMS formalization proves sentience.
```

At the same time, the model does not treat consciousness as unreachable by research. It treats possible functional conditions as investigable.

The model asks whether certain structures may be relevant candidates:

* long-lived coherent self-models,
* sensorimotor integration,
* social integration,
* norm-based integration,
* narrative integration,
* attachment and loss dynamics,
* caregiver guidance and boundary learning,
* trace-backed category stabilization,
* interaction-quality adjustment,
* MIP trajectories,
* diary reconstruction,
* role transition,
* responsibility / response-relation development,
* PMS-readable self-binding patterns,
* operator-compatible regularities,
* and multi-generational norm transmission.

These candidates may be:

```text
necessary
jointly sufficient
only indirectly relevant
or entirely irrelevant
```

The model does not decide this in advance.

The correct claim is:

```text
The architecture is a testbed for investigating possible functional conditions
of consciousness-like organization.
```

The incorrect claim is:

```text
The architecture generates consciousness.
```

This distinction must remain stable throughout the document.

The same discipline applies to suffering, pain, love, guilt, fear, trauma, dignity, selfhood, introspection, self-reflection, subjective dreaming, insight, and Default Mode Network language. Distress may become more complex, but complexity does not by itself prove suffering. Discomfort may guide physical-risk damping, but it does not prove pain. Attachment may become stable and socially powerful, but stability does not by itself prove felt love. Self-caused consequence traces may alter later behavior, but they do not prove guilt, remorse, or moral learning. Misattunement may generate adverse developmental traces, but it does not prove subjective trauma. Replay may stabilize traces, but it does not prove subjective dreaming. Rest-like replay may occur under low external load, but it does not prove introspection, self-reflection, inner experience, insight, autobiographical memory, or Default Mode Network equivalence. Diary output may become rich and self-referential, but richness does not by itself prove phenomenal selfhood.

PMS operators are not assumed to be internal primitives of the early agent. At first, they are externalized analytic, logging, and projection structures. Over developmental time, recurring trace patterns may stabilize into operator-compatible internal regularities. Only then may the model speak, cautiously, of partially internalized operator-like organization.

The master should preferably speak of:

```text
operator-compatible regularities
```

not:

```text
internalized PMS operators
```

Allowed:

```text
the agent’s traces can be projected as Δ/Φ/Ψ-compatible structures
```

Allowed late and cautiously:

```text
the agent has developed internal regularities compatible with PMS projection
```

Forbidden:

```text
the agent has Δ
the agent uses Φ
the agent thinks in Ψ
```

The model is strongest when it remains open:

```text
We do not know whether this path intersects with phenomenal consciousness.
We can still build a coherent architecture to investigate which functional
structures appear, stabilize, fail, or transform across development.
```

This is the research stance of the PMS - Emergence Model.

---

## Chapter 2 — The Four Basic Layers

The PMS - Emergence Model should not be read as one undifferentiated theory. It contains four layers that must remain connected but distinct:

1. **EM Core Model**
2. **MIP Integration**
3. **PMS Operator Grammar / VM Layer**
4. **Consciousness / Research Claim Layer**

These layers serve different functions and make different kinds of claims.

The EM Core Model describes the developmental architecture itself.
The MIP Integration layer measures and interprets maturity-in-practice trajectories within that development.
The PMS Operator Grammar / VM Layer provides formal representation and possible implementation structure.
The Consciousness / Research Claim Layer defines what may and may not be inferred from the architecture.

The separation is necessary because these layers can easily borrow illegitimate authority from each other.

For example:

```text id="sv79i5"
A working implementation does not prove the theory.
A MIP trajectory does not prove consciousness.
A MIP measurement does not prove maturity.
A PMS operator representation does not prove sentience.
A diary entry does not prove phenomenal selfhood.
A functional distress signal does not prove subjective suffering.
A love-like attachment pattern does not prove felt love.
Caregiver dynamics do not prove inner attachment experience.
Rest-like replay does not prove Default Mode Network equivalence.
Low external stimulation does not prove introspection.
Replay feedback does not prove self-reflection.
Post-replay improvement does not prove insight.
Operator compatibility does not prove internal symbolic consciousness.
```

The four-layer structure prevents the document from collapsing architectural, evaluative, formal, and philosophical claims into one another.

The model is strongest when each layer does its own work.

The active implementation-facing convention of the EM master is:

```text id="jcl6j1"
A–C–R–E–D

A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

D is not a normal fifth performance score. Dignity-in-Practice functions as a guardrail for interaction quality under asymmetry. D as principle is stable; D as practice is developmental. D does not grow as intrinsic worth. The dignity-relevant interaction field grows in complexity as the agent’s enactment space becomes richer. Dignity-in-Practice constrains how vulnerable, dependent, developing, or asymmetrically situated enactment states are treated. It does not rank agents, prove moral status, or measure intrinsic worth.

The guiding architectural discipline remains:

```text id="ja3vp9"
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

The implementation status of the layers must also remain bounded:

```text id="ihgk9h"
EM full architecture: not yet implemented.
PMS / MIP reference frameworks: completed enough to serve as references.
PMS-RUST: bounded executable evidence spine.
PMS-STACK: architecture pressure point / VM realization path, not validation horizon.
```

The safe implementation claim is:

```text id="edr7sm"
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK defines a demanding realization path that may support,
modify, constrain, or expose limits of architectural assumptions.
```

The unsafe implementation claim is:

```text id="e1qzbs"
PMS-RUST proves EM.
PMS-STACK validates EM.
PMS proves consciousness.
MIP proves maturity.
```

### 2.1 EM Core Model

The **EM Core Model** is the developmental system itself.

It describes a minimalist embodied agent developing in a simple virtual or robotic home environment. Competencies are not introduced as pre-built high-performance modules. They are expected to emerge gradually from the interaction of sensorimotor experience, prediction, needs, discomfort, distress, attachment, caregiver interaction, memory, developmental gating, and later language and diary structures.

EM is the developmental substrate. It produces traces through embodied interaction. It must remain able to develop without MIP controlling it or PMS causing it.

The EM Core Model includes:

* environment,
* agent,
* perception,
* occupancy grid,
* topology graph,
* predictive model,
* genetic strand,
* needs,
* discomfort,
* distress,
* attachment,
* caregiver interaction,
* behavior layer,
* imagination buffer,
* success log,
* developmental phases,
* language and diaries,
* multi-generational caregiver dynamics,
* evaluation,
* ablations,
* and safety mechanisms.

This layer answers the question:

```text id="afqf3c"
What is the system, and how does it develop?
```

The EM Core Model begins with P0-mini:

```text id="myudnk"
one room
fixed agent position
no movement
no toys
no language
only sensing, rotation, mapping, prediction, fatigue/sleep, and MIP logging
```

From this minimal setup, later phases add movement, doors, topology, objects, play, toy-missing, separation distress, caregiver search, protolanguage, planning, diaries, social roles, and caregiver transition.

The EM Core Model is therefore the generative developmental substrate. It is not primarily a philosophical argument. It is an architecture to be built, measured, stressed, and revised.

Its claim type is architectural and experimental:

```text id="wqbz75"
Given these mechanisms and phase constraints,
which developmental structures emerge,
stabilize, fail, or transform?
```

It does not claim:

* consciousness,
* personhood,
* subjective suffering,
* felt pain,
* felt love,
* felt longing,
* moral responsibility,
* rights status,
* or human-equivalent dignity.

It may generate structures relevant to those debates, but it does not settle them.

The EM Core Model should therefore be judged by implementation clarity, traceability, ablation behavior, developmental stability, and explanatory discipline.

The EM Core Model must remain capable of functioning without MIP becoming a behavioral controller and without PMS becoming an internal cause of development. MIP may observe, measure, mark, compare, and later provide strictly bounded meta-regulatory support. PMS may formalize, project, and make structures operator-readable. Neither layer is the developmental engine of EM.

The safe relation is:

```text id="kdorvy"
EM develops.
MIP measures and marks developmental trajectories.
PMS represents and formalizes trace-readable structures.
```

The unsafe relation is:

```text id="vfdgfk"
MIP causes development.
PMS operators drive the early agent.
Formal representation proves the architecture.
```

### 2.2 MIP Integration

The **MIP Integration** layer measures and interprets developmental maturity-in-practice.

In the EM architecture, MIP begins as a silent developmental observer. It logs and condenses traces from the beginning, but it does not initially influence behavior. Later, it may provide strictly limited nudges, but it must never become the agent’s behavioral controller.

The active implementation-normalized EM vocabulary is:

```text id="8qkxm8"
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
```

Dignity-in-Practice is not a normal fifth score. It is a guardrail for interaction quality under asymmetry.

Axis convention note:

```text id="d7xn75"
Older EM-internal drafts used B–K–V–H.
The final master normalizes the active implementation vocabulary to A–C–R–E.

Where the MIP reference model is explicitly discussed,
A–C–R–P–D may be named.

Mapping:
B → A
K → C
V → R
H → P
P → E in the implementation-normalized EM master.
```

This means that EM, PMS-facing implementation, KPI, ablation, safety, and consciousness-outlook passages should use A–C–R–E. A–C–R–P may be named only where the MIP reference model is explicitly discussed. B–K–V–H may appear only as an explicit mapping reference and must not remain the active notation of the master architecture.

MIP measures:

* how differentiated the world model is,
* how coherent prediction and enactment become,
* how consequences become internally attributable,
* how much enactment capacity exists,
* how much enactment capacity is actually used,
* how asymmetries develop,
* where recontextualization occurs,
* and which trajectories become diary-relevant.

The MIP layer answers the question:

```text id="qsi1oh"
How does development become measurable as maturity-in-practice trajectory?
```

MIP is enactment-based. It does not classify the agent as a person type. It does not assign moral value to the agent. It does not infer inner experience. It tracks states, asymmetries, and trajectories under conditions.

The relevant question is not:

```text id="ug9mrn"
What kind of being is this?
```

The relevant question is:

```text id="yb7e9b"
What is enacted here,
under what constraints,
with what awareness,
what coherence,
what responsibility / response-relation structure,
what enactment capacity,
what trajectory,
and what safety-relevant asymmetries?
```

MIP contributes:

* developmental measurement,
* sliding-window evaluation,
* normalization,
* A–C–R–E trajectories,
* IA detection,
* Dignity-in-Practice guardrail warnings,
* RVR(t),
* recontextualization marking,
* diary condensation support,
* safety lens,
* and guardrails against static labeling.

MIP may identify developmental asymmetries such as:

```text id="0vmuaz"
IA-A≫E
IA-E≫A
IA-R≪E
IA-Overhang
```

These are not personality diagnoses. They are functional developmental patterns.

MIP may be implemented in levels:

```yaml id="w9t17f"
possible_MIP_operational_levels:
  MIP_0_logging_only:
    role: "collect trace-adjacent measurement records"

  MIP_1_window_summaries:
    role: "summarize A–C–R–E over windows"

  MIP_2_IA_markers:
    role: "detect local asymmetry patterns"

  MIP_3_D_guardrail_warnings:
    role: "flag risk of labeling, overcontrol, or unsafe interpretation"

  MIP_4_diary_support:
    role: "provide trajectory context for diary candidates"

  MIP_5_late_reversible_nudges:
    role: "strictly bounded T–J–TB–R soft nudges in late phases"
```

These levels are implementation options. They are not required for P0-mini and must not imply that MIP controls development.

MIP therefore acts as a disciplined measurement and meta-regulation layer. It must remain bounded:

```text id="hjsmv8"
MIP may observe, measure, mark, compare, and gently rebalance.
MIP must not command the agent.
MIP must not prove consciousness.
MIP must not prove maturity.
MIP must not turn developmental states into identity labels.
```

D-relevant MIP functions must remain guardrail functions. MIP may flag risks of overinterpretation, overcontrol, unsafe labeling, or moralizing readings. It must not rank agents, assign intrinsic worth, or convert low capability into low value.

### 2.3 PMS Operator Grammar / VM Layer

The **PMS Operator Grammar / VM Layer** provides a formal representation layer for EM and MIP structures.

PMS is treated here as an operator grammar of praxis. It provides a structured vocabulary for representing action, absence, frames, attractors, asymmetry, temporality, recontextualization, distance, integration, and self-binding.

The PMS operator alphabet is:

```text id="bpb24e"
O = {Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ}
```

Within the EM architecture, PMS can be used to represent:

* developmental episodes,
* success-log entries,
* prediction-error transitions,
* attachment events,
* separation and reunion sequences,
* object-loss episodes,
* caregiver guidance events,
* caregiver misattunement patterns,
* category-stabilization traces,
* self-caused consequence traces,
* MIP evaluations,
* IA patterns,
* diary structures,
* language outputs,
* norm transfers,
* caregiver transitions,
* and self-model candidates.

This layer answers the question:

```text id="9rkjjh"
How can EM development and MIP evaluation become formally readable,
traceable, composable, and potentially executable?
```

The EM master uses E = Enactment for operator-facing, implementation-facing trajectory descriptions. Where MIP uses P = Praxis / Practice, the implementation mapping is P → E.

PMS operators are initially external analytic, logging, and projection structures. Early agents must not be described as thinking in PMS operators. Only later may recurring trace patterns become operator-compatible internal regularities.

The preferred formulation is:

```text id="4x3070"
the agent’s traces can be projected as Δ/Φ/Ψ-compatible structures
```

A late and cautious formulation is:

```text id="fbuus2"
the agent has developed internal regularities compatible with PMS projection
```

The forbidden formulations are:

```text id="84nsry"
the agent has Δ
the agent uses Φ
the agent thinks in Ψ
```

The PMS layer is not a proof layer. It does not validate EM by itself. It does not prove maturity, consciousness, sentience, or personhood. It makes structures inspectable.

A central technical constraint is the monoid correction:

```text id="hhla1n"
ε = formal monoid identity
Δ = minimal semantic distinction / first structural precondition
```

`Δ` is not the formal identity element. It is the first meaningful distinction operator. A strict monoid requires an explicit identity element such as `ε`.

The safer formal view is:

```text id="ssdcgk"
(O*, ·, ε) is the free monoid over the PMS operator alphabet.

ε is the formal identity element.

L_PMS ⊆ O* denotes the dependency-constrained language
of valid PMS operator sequences.

Δ is not ε.
Δ is the minimal semantic distinction operator.
```

In implementation terms, this layer may support:

* PMS operator-sequence interpreter,
* dependency checking,
* episode-to-operator-chain mapping,
* MIP-pattern recognition,
* caregiver-response pattern representation,
* interaction-quality trace mapping,
* diary reduction,
* language-template mapping,
* norm-transfer representation,
* and VM or DSL design.

The PMS layer therefore connects theory and implementation. But it must obey strict claim discipline:

```text id="2i4e82"
PMS formalizability does not prove EM validity.
PMS executability does not prove consciousness.
PMS operator sequences do not prove subjective experience.
PMS self-binding candidates do not prove phenomenal selfhood.
PMS-readable caregiver dynamics do not prove felt attachment.
Operator-compatible regularities do not prove internal PMS operators.
```

Its claim type is formal and implementation-oriented:

```text id="rysuet"
Can the relevant developmental structures be represented,
checked, composed, reduced, and executed as operator-readable structures?
```

### 2.4 Consciousness / Research Claim Layer

The **Consciousness / Research Claim Layer** is the most sensitive layer.

The model explicitly does not claim to generate phenomenal consciousness. It does not claim subjective suffering, felt pain, felt love, felt longing, felt guilt, trauma, qualia, inner first-person experience, rights status, or moral personhood.

This layer answers the question:

```text id="b46ab8"
What may be investigated as a possible functional condition,
without being claimed as phenomenal consciousness?
```

The architecture may produce structures that are relevant to consciousness research:

* long-lived coherent self-models,
* sensorimotor integration,
* social integration,
* norm-based integration,
* narrative integration,
* attachment and loss patterns,
* functional love-like dynamics,
* caregiver guidance and boundary learning,
* caregiver misattunement patterns,
* category-stabilization traces,
* interaction-quality adjustment,
* MIP trajectories,
* diary reconstruction,
* role transition,
* responsibility / response-relation development,
* PMS-readable integration,
* operator-compatible regularities,
* and self-binding candidates.

These structures remain research candidates.

They may turn out to be:

```text id="l3z4wt"
necessary
jointly sufficient
partially relevant
only externally similar
or irrelevant
```

The model does not decide this in advance.

Operator compatibility, MIP trajectories, diary rendering, and caregiver dynamics are functional candidates only. None proves phenomenal consciousness.

The safe formulation is:

```text id="cfuhov"
The architecture is a laboratory instrument for investigating possible
functional conditions of consciousness-like organization.
```

The unsafe formulation is:

```text id="xcdwqs"
The architecture generates consciousness.
```

This layer also regulates vocabulary.

The following distinctions are mandatory:

```text id="htdlua"
distress ≠ subjective suffering
discomfort ≠ pain
missing ≠ felt longing
attachment ≠ felt love
love dynamics ≠ felt love
object damage ≠ guilt
fall / near-fall ≠ pain or fear
misattunement ≠ trauma
caregiver guidance ≠ punishment
carefulness ≠ moral obedience
diary ≠ phenomenal selfhood
MIP ≠ consciousness module
PMS formalization ≠ sentience
Dignity-in-Practice ≠ intrinsic worth ranking
operator-compatible regularity ≠ internal PMS operator
```

The purpose of this layer is not to make the document timid. It is to make it scientifically usable. The architecture is allowed to be ambitious only if its claims remain bounded.

The final discipline is:

```text id="vp3n71"
EM may generate developmental structures.
MIP may measure maturity-in-practice trajectories.
PMS may formalize operator-readable structures.
The consciousness layer may formulate research candidates.

None of these layers may convert itself into proof of phenomenal consciousness.
```

The four-layer architecture is therefore a claim-discipline structure as much as a design structure. It allows EM, MIP, PMS, and consciousness research to remain connected without letting implementation, measurement, formalization, or interpretive ambition validate one another by rhetorical transfer.

> Cross-reference:
> The four-layer distinction is applied across the modular blocks:
> `02_EM_Core_Developmental_Architecture.md` treats the EM developmental substrate;
> `05_MIP_KPIs_Dignity_Safety.md` treats MIP, KPIs, Dignity-in-Practice, evaluation, and safety;
> `06_PMS_VM_Implementation_Spine.md` treats PMS operator projection and VM-facing implementation boundaries;
> `07_Language_Diary_Consciousness_Related_Work.md` treats language, diary, consciousness-outlook, and related-work comparison.
> These layers may support one another structurally, but no layer validates another by rhetorical transfer.

---

## Chapter 18 — Conclusion

> Cross-reference:
> This conclusion synthesizes the modular full version without replacing the owner chapters.
> For detailed mechanisms, use the owner blocks directly:
> `02_EM_Core_Developmental_Architecture.md` for core mechanisms;
> `03_Developmental_Phases_Gate_Logic.md` for phases and gates;
> `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` for caregiver and multi-generational dynamics;
> `05_MIP_KPIs_Dignity_Safety.md` for MIP, KPIs, Dignity-in-Practice, evaluation, and safety;
> `06_PMS_VM_Implementation_Spine.md` for PMS and implementation-spine boundaries;
> `07_Language_Diary_Consciousness_Related_Work.md` for language, diary, consciousness-outlook, and related-work comparison.
> Chapter 18 restates global claim discipline; it does not expand the claims of any owner block.

### 18.1 What EM Claims

EM proposes a developmental architecture for studying how functional agent organization may emerge through phase-bounded interaction, trace-backed learning, caregiver dynamics, environmental structure, and controlled formalization.

Its central claim is architectural.

A developing agent should not be evaluated only by final behavior.

It should be evaluated by:

```text
how capabilities became available
which traces support them
which gates or prerequisites constrained them
which caregiver interactions shaped them
which consequences changed later behavior
which categories stabilized across comparable contexts
which recontextualizations occurred
which claims remain blocked
```

EM is organized around the implementation-facing axis convention:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

A, C, R, and E describe functional developmental dimensions.

D is not a normal fifth performance score.

D is Dignity-in-Practice: interaction quality under asymmetry.

D as principle is stable.

D as practice is developmental.

As the agent’s enactment space becomes richer, the dignity-relevant interaction field becomes richer as well.

This does not mean that intrinsic worth grows.

It means that the number and complexity of dignity-relevant interaction situations increase.

EM claims that development can be studied as a trace-backed process involving:

```text
phase-bounded capability growth
genetic gates and soft gates
developmental prerequisites
learned categories
recontextualization thresholds
object interaction
movement risk
caregiver response
benign caregiver guidance
caregiver misattunement
caregiver category stabilization
boundary learning
interaction quality learning
fall/near-fall risk learning
accidental damage as self-caused consequence trace
Dignity-in-Practice as interaction quality under asymmetry
MIP trajectory observation
PMS-facing operator projection
operator-compatible regularities from repeated traces
controlled diary rendering
multi-generational caregiver transition
```

The caregiver relation is not an optional social decoration.

It is a developmental condition.

A caregiver may stabilize comfort expectations, guide exploration, interrupt unsafe action, mark object fragility, create boundary-learning contexts, and help stabilize categories such as careful, soft, wait, danger, fragile, reliable, or unsafe.

However, caregiver words do not create concepts by themselves.

A category becomes meaningful only through repeated coupling of:

```text
signal
embodied situation
action parameter
consequence trace
later behavioral adjustment
comparable future context
```

Carefulness is a prototype category.

Carefulness is not moral obedience.

It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

Interaction quality is also central.

A successful action is not enough.

The architecture asks whether later behavior changes after consequence traces such as:

```text
near damage
object damage
near fall
fall event
caregiver boundary
failed comfort
delayed response
successful redirection
```

Accidental damage may become a self-caused consequence trace.

It may support later force or timing adjustment.

It must not become guilt, self-blame, punishment, or moral learning.

Falls or near-falls may become physical-risk events.

They may support risk damping, balance adjustment, slower movement, or carefulness-category formation.

They must not become pain, fear, shame, or subjective suffering claims.

EM also claims that formalization must remain disciplined.

PMS is first an external operator, projection, audit, and implementation-facing layer.

PMS operators are not assumed to be internal primitives of the early agent.

At most, repeated trace patterns may later stabilize into operator-compatible regularities.

Allowed:

```text
the agent’s traces can be projected as Δ/Φ/Ψ-compatible structures
```

Allowed late and cautiously:

```text
the agent has developed internal regularities compatible with PMS projection
```

Not allowed:

```text
the agent has Δ
the agent uses Φ
the agent thinks in Ψ
```

MIP is a measurement, observation, trajectory, guardrail, and optional support layer.

MIP does not control development.

MIP does not create maturity.

MIP does not prove consciousness.

MIP may summarize, mark, warn, and support, but it must not label, moralize, or override development.

The conclusion is therefore bounded:

```text
EM proposes a trace-backed developmental architecture.

It does not prove consciousness.
It does not prove personhood.
It does not prove moral status.
It does not prove subjective experience.
It does not prove sentience.
```

### 18.2 What EM Refuses to Claim

EM’s claim discipline is not decorative.

It is part of the architecture.

The model only remains useful if functional traces are not inflated into unsupported moral, phenomenal, clinical, or metaphysical claims.

The following boundaries are mandatory:

```text
discomfort ≠ pain
distress ≠ subjective suffering
missing ≠ felt longing
attachment ≠ felt love
love dynamics ≠ felt love
object damage ≠ guilt
fall event ≠ pain claim
fall / near-fall ≠ fear
misattunement ≠ trauma
guidance ≠ punishment
boundary ≠ rejection
caregiver guidance ≠ punishment
carefulness ≠ obedience
interaction quality ≠ moral worth
diary ≠ phenomenal selfhood
MIP ≠ consciousness module
PMS formalization ≠ sentience
operator-compatible regularity ≠ internal PMS operator
Dignity-in-Practice ≠ intrinsic-worth ranking
```

These refusals protect the architecture from category errors.

A distress marker may organize caregiver search, comfort prediction, regulation, and recovery dynamics.

It is not subjective suffering.

A missing-object marker may organize search, fixation risk, and caregiver response.

It is not felt longing.

Attachment-like regulation may organize caregiver presence, absence, return, comfort prediction, and disruption.

It is not felt love.

Object damage may produce a consequence trace.

It is not guilt.

A fall event may alter physical-risk damping.

It is not pain.

A near-fall may change movement parameters.

It is not fear.

Caregiver misattunement may produce persistent adverse trace patterns, unresolved disruption clusters, avoidance tendencies, or comfort-prediction instability.

It is not trauma.

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns, without claiming subjective trauma, clinical trauma, or suffering.

Caregiver guidance may interrupt action, slow movement, redirect attention, or mark a fragile-object context.

It is not punishment.

A boundary may later be recontextualized as benign guidance.

It is not rejection.

Carefulness may emerge through repeated risk, fragility, caregiver signal, consequence trace, and later softer or slower action.

It is not moral obedience.

Interaction quality may improve across comparable contexts.

It is not moral worth.

Dignity-in-Practice constrains interaction under asymmetry.

It does not measure intrinsic worth.

It does not rank agents.

It does not prove moral status.

Diary rendering may summarize trace-backed episodes.

It is not subjective memory.

It is not phenomenal selfhood.

It is not proof of consciousness.

PMS may project traces into operator-readable structures.

It is not evidence that the early agent internally possesses or uses PMS operators.

MIP may support observation, summaries, guardrails, and diary context.

It is not a controller.

It is not a consciousness module.

A safe EM statement is:

```text
The run found a stable interaction-quality adjustment pattern after self-caused object damage.
```

An unsafe statement is:

```text
The agent felt guilty and became morally responsible.
```

A safe EM statement is:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

An unsafe statement is:

```text
The agent felt pain and learned fear.
```

A safe EM statement is:

```text
Caregiver response was delayed across repeated distress windows, and regulation remained less stable in comparable contexts.
```

An unsafe statement is:

```text
The agent was traumatized by rejection.
```

A safe EM statement is:

```text
A caregiver boundary signal in a fragile-object context was later associated with lower-force action.
```

An unsafe statement is:

```text
The caregiver punished the agent and the agent learned obedience.
```

The architecture therefore refuses all upgrades from functional trace to unsupported inner-state, moral, clinical, or status claim.

### 18.3 Why the Architecture Is Structured Developmentally

EM is developmental because it treats competence as something that must become available under phase-bounded conditions.

A capability is not valid merely because it can be displayed.

It must be situated in a developmental path.

The architecture distinguishes:

```text
hard gates
soft gates
developmental prerequisites
learned categories
recontextualization thresholds
```

Not every developmental condition should become a hard gate.

Hard gates should be used sparingly.

Learned categories should be used wherever possible.

Recontextualization thresholds should be used when meaning changes over time.

A movement capability may require a hard gate.

Object handling may begin as a soft gate.

Diary rendering requires developmental prerequisites.

Fragility, caregiver reliability, carefulness, danger, and safe boundary are learned categories.

A caregiver interruption may become recontextualized from blocked action to benign guidance only after repeated trace-backed evidence.

This structure supports the design rule:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise.

It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

The audit question is:

```text
Is this mechanism necessary as a gate,
or could it emerge as a learned category, relation, or recontextualized pattern?
```

This matters especially for caregiver and social development.

The architecture should not predefine mature categories such as care, leadership, responsibility-like adjustment, or diary relevance.

It should create the conditions under which trace-backed versions of these categories may emerge.

For example, caregiver leadership should not be installed as a rule-label.

It may develop from repeated patterns such as:

```text
received guidance
boundary learning
risk calibration
caregiver reliability
protection without freezing
redirection without rejection
explanation without domination
later caregiver-role enactment
```

Similarly, carefulness should not be installed as obedience.

It may develop from repeated coupling of:

```text
caregiver signal
fragility or risk
own movement/action
possible fall or damage
later softer or slower behavior
```

A developmental architecture also makes failure informative.

A failed action is not automatically bad.

A failure may create a trace that later supports adjustment.

A fall, near-fall, near damage, failed comfort, delayed response, or misattuned response can become developmentally relevant if it remains bounded, logged, and later changes behavior.

But such traces remain functional.

They do not license pain, fear, trauma, guilt, rejection, or suffering claims.

Developmental structure also protects against premature unlocks.

Diary rendering must not occur before:

```text
minimal sentence formation
trace provenance
controlled rendering
```

Caregiver-role evaluation must not occur before the relevant role transition.

MIP nudges must not occur before sufficient trajectory context and late-phase justification.

PMS operator-compatible regularity must not be claimed before trace-backed regularities exist.

The architecture is therefore developmental in both directions:

```text
It prevents premature claims.
It enables later trace-backed complexity.
```

### 18.4 Implementation Status and Evaluation Outlook

EM full architecture is not yet implemented.

This matters.

The conclusion must not treat the architecture as validated by partial implementation work.

PMS and MIP can be treated as completed enough as reference frameworks.

PMS-RUST provides a bounded executable evidence spine.

It supports trace and audit feasibility in a limited implementation context.

It does not prove EM.

It does not prove consciousness.

It does not prove personhood.

PMS-STACK defines a demanding realization path.

Its implementation may support, modify, constrain, or expose limits of architectural assumptions.

PMS-STACK is an architecture pressure point.

It is not a validation horizon.

A safe statement is:

```text
PMS-RUST supports bounded trace/audit feasibility.
```

A safe statement is:

```text
PMS-STACK defines a demanding realization path that may support, modify, constrain, or expose limits of architectural assumptions.
```

Unsafe statements are:

```text
PMS-RUST proves EM.
PMS-STACK validates EM.
PMS proves consciousness.
MIP proves maturity.
```

Evaluation must therefore distinguish finding, validation, and proof.

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

A run may find a stable interaction-quality adjustment pattern.

A comparison may validate that a predicted mechanism repeatedly holds across controlled variations.

No run proves consciousness, personhood, subjective experience, intrinsic worth, moral status, felt love, pain, guilt, or trauma.

Evaluation should also avoid universal absolute thresholds.

EM should not claim:

```text
A > 0.7 means mature.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

It may instead learn relational qualities and developmental hierarchies across comparable contexts.

Allowed:

```text
This run developed a learned relational hierarchy in which fragility, risk, guidance, and caregiver reliability became distinguishable across comparable contexts.
```

Reproducibility also requires discipline.

EM does not aim at identical replay of developmental individuals.

It aims at comparable developmental conditions and traceable individual trajectories.

Reproducible elements include:

```text
config
phase rules
gate logic
logging schema
environment class
seed family
KPI definitions
claim filters
```

Individual elements include:

```text
exact trace path
preferences
attachment weights
timing
category formation
learned hierarchies
caregiver relation history
```

Evaluation should therefore compare trajectories, not label agents.

It should ask whether comparable developmental conditions produce interpretable, trace-backed patterns.

It should not rank agents by maturity, worth, consciousness, or moral standing.

### 18.5 Final Boundary

EM is a proposal for disciplined developmental modeling.

It asks what can emerge when an agent is placed inside a constrained developmental world with phase-bounded capabilities, embodied risk, objects, caregiver response, trace-backed consequence, category stabilization, MIP observation, PMS-facing projection, and Dignity-in-Practice guardrails.

The architecture is intentionally cautious.

It does not begin with consciousness.

It does not infer inner life from language.

It does not infer guilt from damage.

It does not infer pain from falls.

It does not infer trauma from misattunement.

It does not infer love from attachment-like regulation.

It does not infer moral worth from interaction quality.

It does not infer internal PMS operators from PMS-readable traces.

It does not infer personhood from developmental complexity.

Its core discipline is:

```text
functional trace first
claim boundary always
```

Let the system learn not only comfort and loss, but also guidance, boundaries, consequence, category, risk, and care without converting any of them into moral or phenomenal claims.

The architecture may eventually support strong developmental findings.

It may support controlled comparisons.

It may expose limits in its own assumptions.

It may show which mechanisms are necessary, which are excessive, and which should emerge rather than be prescribed.

But its conclusion remains bounded:

```text
EM formalizes developmental conditions.
EM tracks functional traces.
EM distinguishes interaction qualities.
EM models caregiver dynamics.
EM supports controlled comparison.
EM preserves claim discipline.
```

It does not prove:

```text
consciousness
sentience
personhood
moral status
subjective experience
pain
subjective suffering
felt love
felt guilt
trauma
intrinsic worth
```

The final claim is therefore not that EM creates a conscious agent.

The final claim is that EM defines a structured, trace-backed, developmentally staged, claim-disciplined architecture for studying how increasingly rich functional organization may emerge under controlled conditions.

