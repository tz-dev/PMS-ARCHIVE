---
document_id: PMS-EM-BLOCK-05
title: "MIP, KPIs, Dignity & Safety"
source: "PMS-EMERGENCE MODEL.md"
source_role: "derived full-block extraction"
status: "split-full-version"
version: "v1"
owner_chapters: [10, 16]
secondary_references: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 17, 18]
appendix_references: ["Appendix A", "Appendix D", "Appendix E"]
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Block 05 — MIP, KPIs, Dignity & Safety

## Block Orientation

This block contains the owner chapters for the MIP layer, A–C–R–E measurement, Dignity-in-Practice, developmental KPIs, evaluation, ablations, safety principles, and functional-description discipline.

It should be read together with:

- `01_Theory_Scope_Claim_Discipline.md` for global scope, claim discipline, layer boundaries, and final synthesis
- `02_EM_Core_Developmental_Architecture.md` for the core developmental mechanisms measured by MIP and KPIs
- `03_Developmental_Phases_Gate_Logic.md` for phase placement, gates, exit criteria, and premature-unlock risks
- `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` for caregiver, attachment-like regulation, interaction quality, D-guarded asymmetry, and multi-generational details
- `06_PMS_VM_Implementation_Spine.md` for PMS, VM, implementation spine, and operator-compatible projection boundaries
- `07_Language_Diary_Consciousness_Related_Work.md` for diary, language, consciousness-outlook, and related-work treatment
- `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`
- `Appendix_D_Claim_Discipline_Language_Reductions.md`
- `Appendix_E_Layer_Discipline_Claim_Types.md`

This block preserves the claim discipline of the master specification:

- A–C–R–E are the active implementation-facing axes.
- A–C–R–P may appear only in explicit MIP source/context notation, where P is normalized to E for EM implementation use.
- D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.
- D is not a normal fifth performance score and does not rank intrinsic worth.
- MIP observes, summarizes, marks, warns, and may support strictly bounded late reversible nudges where allowed.
- MIP does not control development, open gates, install categories, prove consciousness, prove maturity, diagnose agents, or moralize traces.
- PMS is an external operator, projection, audit, and VM-facing layer; it is not assumed to be an early internal agent structure.
- Evaluation and ablation findings remain functional, phase-bounded, trace-backed, and claim-filtered.
- KPIs do not prove consciousness, personhood, moral status, sentience, subjective experience, pain, suffering, love, guilt, trauma, or phenomenal selfhood.
- PMS-RUST supports bounded trace/audit feasibility.
- PMS-STACK defines a demanding realization path that may support, modify, constrain, or expose limits of architectural assumptions; it does not validate EM as a whole.

> Cross-reference:
> For the full treatment of global scope, layer separation, implementation-status discipline, and claim boundaries, see `01_Theory_Scope_Claim_Discipline.md`, especially Chapters 0, 1, 2, and 18.
> This block uses those concepts only as global discipline for MIP, KPI, Dignity-in-Practice, evaluation, ablation, and safety interpretation.

> Cross-reference:
> For the full treatment of the EM core mechanisms that MIP observes and KPIs evaluate, see `02_EM_Core_Developmental_Architecture.md`, especially Chapters 3, 4, 5, 6, 8, and 9.
> This block defines measurement and evaluation layers; it does not replace the core architecture specification.

> Cross-reference:
> For the full treatment of developmental phases, gate logic, exit criteria, premature-unlock risks, and phase availability, see `03_Developmental_Phases_Gate_Logic.md`, especially Chapter 11.
> This block uses phase language only as evaluation context; MIP does not open gates or control phase development.

> Cross-reference:
> For the full treatment of caregiver, attachment-like regulation, interaction quality, and multi-generational caregiver dynamics, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapters 7 and 12.
> This block evaluates and guards those dynamics through MIP, KPIs, and D; it does not replace their owner chapters.

> Cross-reference:
> For the full treatment of PMS projection, operator-compatible regularities, VM-facing representation, PMS-RUST, PMS-STACK, and implementation claim boundaries, see `06_PMS_VM_Implementation_Spine.md`, especially Chapter 14.
> This block uses PMS only as an external projection, audit, and implementation-facing reference layer.

> Cross-reference:
> For the full treatment of language, diary rendering, consciousness-research outlook, and related-work comparison, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapters 13, 15, and 17.
> This block uses diary and consciousness-outlook concepts only as evaluation, safety, and claim-boundary contexts.

---

## Chapter 10 — MIP Layer: Developmental Measurement, Trajectories & Meta-Regulation

The MIP layer provides developmental measurement and meta-regulation.

It does not create development by itself. It observes, aggregates, compares, marks, and later may support strictly bounded soft nudges. Its purpose is to make developmental trajectories visible without turning them into fixed labels, person types, moral judgments, maturity rankings, or consciousness claims.

In EM, MIP has three main roles:

```text
measurement
trajectory interpretation
limited meta-regulatory support
```

The MIP layer reads from:

* perception traces,
* prediction error,
* action traces,
* success logs,
* discomfort and distress variables,
* object interaction histories,
* fall and near-fall traces,
* object damage and near-damage traces,
* caregiver events,
* caregiver guidance,
* caregiver-response variability,
* misattunement candidates,
* category-stabilization traces,
* attachment and separation patterns,
* recontextualization events,
* language and diary traces,
* and later multi-generational role transitions.

It does not replace any of these mechanisms.

The active implementation-facing axis convention remains:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

D is not a normal fifth performance score. D is Dignity-in-Practice: interaction quality under asymmetry. D as principle is stable. D as practice is developmental.

The dignity-relevant interaction field may become richer as the agent’s enactment space becomes richer, but this is not a ranking of intrinsic worth, maturity, personhood, or moral status.

The MIP layer therefore works under a strict interpretive boundary:

```text
MIP observes development.
MIP does not manufacture development.
MIP measures enactment trajectories.
MIP does not control the agent.
MIP may support safety.
MIP does not prove consciousness.
MIP does not prove maturity.
MIP does not rank intrinsic worth.
```

The EM full architecture is not yet implemented. PMS and MIP may be treated as reference frameworks for structure, measurement, and audit. PMS-RUST supports bounded trace/audit feasibility. PMS-STACK defines a demanding realization path that may support, modify, constrain, or expose limits of architectural assumptions. Neither PMS-RUST nor PMS-STACK validates EM as a whole, and neither PMS nor MIP proves consciousness.

The global design rule applies here as well:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

MIP should prescribe only the minimal measurement and guardrail structure required to prevent collapse, drift, unsafe phase leakage, overinterpretation, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, learned categories, and recontextualization.

A key audit question for MIP is:

```text
Is this measurement necessary as a developmental marker,
or could the relevant structure emerge as a learned category,
relation, or recontextualized pattern?
```

EM should not rely on universal absolute thresholds, but may learn relational qualities and developmental hierarchies from repeated trace patterns across comparable contexts.

Allowed:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Not allowed:

```text
A > 0.7 means mature.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

The MIP layer must therefore treat scores as situated developmental measurements, not universal human-like judgments.

### 10.1 MIP Layer Overview

The MIP layer is present from the beginning, but its role changes across phases.

In P0-mini, MIP is silent and observational. It may log early Awareness and Coherence signals, such as mapping coverage, prediction stability, fatigue cycles, and sleep replay traces.

In later phases, MIP can observe increasingly rich developmental structures:

```text
movement
object interaction
fall and near-fall traces
self-caused consequences
object damage and near-damage
interaction-quality adjustment
distress regulation
caregiver search
comfort-after-loss
failed comfort
caregiver guidance
caregiver-response variability
misattunement candidates
category-stabilization traces
attachment patterns
language emergence
diary reconstruction
role transition
core norm application
```

The MIP layer does not begin as a reflective system. It is not introspection. It is a measurement layer.

A minimal MIP trace may look like:

```yaml
mip_trace:
  t_window: [1000, 1500]
  phase: P0-mini

  A_signal:
    coverage: 0.42
    angle_diversity: 0.31

  C_signal:
    PE_AUC_mapping: 0.28
    map_collapse: false

  E_signal:
    E_pot:
      - LOOK_AROUND
      - SLEEP
    E_act:
      LOOK_AROUND: 37
      SLEEP: 2

  R_signal:
    self_caused_consequences: 0

  D_guardrail:
    overinterpretation_risk: low
```

In later phases, the trace may become richer:

```yaml
mip_trace:
  t_window: [18000, 18500]
  phase: P2c

  A_signal:
    caregiver_presence_detected: true
    object_absence_detected: true
    topology_known: true

  C_signal:
    caregiver_search_prediction: 0.63
    distress_recovery_pattern_stable: true
    boundary_legibility: developing

  R_signal:
    self_caused_object_events: 3
    avoidable_damage_events: 1
    response_relation_relevant_consequence_traces: 2

  E_signal:
    SEARCH_CAREGIVER: 4
    INTERACT_OBJECT: 12
    SLEEP: 1

  D_guardrail:
    object_damage_is_not_guilt: true
    caregiver_guidance_is_not_punishment: true
    misattunement_is_not_trauma: true
```

MIP operates over sliding windows. It does not interpret single events too strongly.

A single collision does not define a pattern.
A single distress spike does not define attachment.
A single successful action does not define responsibility.
A single caregiver boundary does not define punishment.
A single caregiver word does not create a concept.
A single diary sentence does not define selfhood.

MIP should track trajectories:

```text
How does the pattern change over time?
Does it stabilize?
Does it reappear?
Does it generalize?
Does it become more coherent?
Does it become more distorted?
Does it become recontextualized?
Does later enactment change in comparable contexts?
```

The MIP layer is especially important because the EM architecture is developmental. A static snapshot is not enough.

The central object of MIP is not:

```text
What type of agent is this?
```

but:

```text
What enactment state is visible in this window,
and how does it move across time?
```

This prevents premature labeling.

MIP may mark relational developmental qualities, such as:

```text
this object is more fragile than that object
this caregiver response is less reliable than prior comfort
this boundary is increasingly recognized as guidance
this movement pattern is riskier under fatigue
this social relation is unstable under delayed response
```

These are trace-backed relational distinctions, not universal thresholds.

The safe summary is:

```text
MIP is a developmental observer and trajectory layer.
It makes enactment patterns measurable without turning them into identity claims.
```

MIP may support later safety through bounded warnings or soft nudges, but only under strict constraints. Such support must not imply that MIP is the source of development.

The core boundary is:

```text
MIP may mark.
MIP may compare.
MIP may warn.
MIP may support late reversible nudges.
MIP does not control.
MIP does not mature the agent.
MIP does not install categories.
MIP does not prove consciousness.
```

### 10.2 Functional Developmental Observer

The MIP layer acts as a functional developmental observer.

It observes what the agent enacts under given conditions.

It does not infer hidden essence.

The relevant unit is:

```text
enactment-under-conditions
```

Not:

```text
agent type
character type
moral worth
personhood
consciousness status
```

For example, MIP may observe:

```text
The agent has movement available but rarely uses it.
```

It should not say:

```text
The agent is passive.
```

MIP may observe:

```text
The agent repeatedly acts before prediction and mapping are stable.
```

It should not say:

```text
The agent is reckless.
```

MIP may observe:

```text
A caregiver boundary repeatedly reduces high-force object interaction
and is followed by lower force in comparable contexts.
```

It should not say:

```text
The agent learned moral obedience.
```

MIP may observe:

```text
The former child in caregiver role blocks exploration too often after prior loss.
```

It should not say:

```text
The caregiver is morally overbearing.
```

MIP may observe:

```text
Repeated non-response during high-distress windows correlates with
reduced comfort prediction and increased contact ambivalence.
```

It should not say:

```text
The agent was traumatized.
```

The observer should preserve conditions.

A MIP observation should include:

* phase,
* time window,
* available capabilities,
* actual actions,
* relevant internal states,
* environmental conditions,
* prediction stability,
* consequence traces,
* caregiver-response context,
* category-stabilization evidence,
* D-guardrail status,
* and uncertainty.

A structured observation:

```yaml
mip_observation:
  phase: P1
  window: [5200, 5700]

  condition:
    g_move: open
    map_stability: high
    discomfort: low
    fatigue: moderate

  observation:
    E_pot: high
    E_act: low
    exploration_attempts: 1

  interpretation:
    possible_pattern: IA-A>>E
    confidence: 0.58
    requires_more_windows: true

  claim_level: functional_window_observation
```

A caregiver-guidance observation:

```yaml
mip_observation:
  phase: P2a
  window: [20400, 20900]

  condition:
    object_fragility: high
    force_before_guidance: high
    caregiver_signal: careful
    near_damage_trace: true

  observation:
    E_adjustment:
      lower_force: true
      slower_timing: true
      increased_observation: true

  interpretation:
    possible_pattern: guidance_to_interaction_quality_adjustment
    confidence: medium
    requires_comparable_future_context: true

  claim_level: functional_guidance_observation
```

A misattunement-candidate observation:

```yaml
mip_observation:
  phase: P2c
  window: [18800, 19300]

  condition:
    distress: high
    caregiver_available: uncertain
    expected_response: comfort

  observation:
    observed_response: delayed
    distress_reduction: low
    comfort_prediction_delta: -0.04
    contact_ambivalence_delta: 0.02

  interpretation:
    possible_pattern: caregiver_response_variability
    confidence: low_to_medium
    requires_more_windows: true

  claim_level: functional_response_mismatch_observation
```

These are deliberately cautious.

MIP interpretations should be:

```text
local
conditional
time-bounded
revisable
trace-based
claim-filtered
```

They should not be:

```text
global
essentializing
moralizing
permanent
phenomenological
diagnostic
```

MIP therefore acts like a developmental measurement instrument.

It can say:

```text
In this phase and window,
given these capabilities and conditions,
this pattern was enacted.
```

It should not say:

```text
This is what the agent is.
```

This is essential for safety and scientific usefulness.

The functional observer also supports later interventions, but only as soft nudges and only when the relevant implementation level permits them. Before any nudge, MIP must have enough trace evidence to justify the observation.

The observer rule is:

```text
No interpretation without trace.
No label without trajectory.
No nudge without justification.
No consciousness claim from MIP score.
No maturity claim from MIP score.
No moral claim from consequence trace.
```

MIP must also preserve Dignity-in-Practice.

A D-relevant observation should not convert low capability into low worth, object damage into guilt, caregiver guidance into punishment, failed comfort into rejection, or misattunement into trauma.

The D guardrail for observation is:

```text
measure without labeling
detect without moralizing
warn without controlling
render without claiming inner life
```

### 10.3 Axis Convention: MIP ACRP and EM ACRE

The active implementation-facing convention of EM is:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

MIP source/context notation may use:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
P — Practice
D — Dignity-in-Practice
```

The normalization rule is:

```text
P → E
Practice becomes implementation-normalized as Enactment.
```

The active chain is therefore:

```text
MIP A–C–R–P source/context notation
→ EM A–C–R–E implementation notation
```

D is not part of this sequence as an ordinary score. D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.

A source-level mapping record may look like:

```yaml
axis_convention_record:
  source_context: MIP_reference_context

  source_context_axes:
    - A
    - C
    - R
    - P

  implementation_normalized_axes:
    - A
    - C
    - R
    - E

  normalization:
    P: E

  guardrail:
    D: Dignity-in-Practice

  claim_boundary:
    D_is_not_fifth_performance_score: true
    axes_do_not_prove_consciousness: true
    axes_do_not_rank_intrinsic_worth: true
```

The EM layer uses A–C–R–E because these axes fit the implementation mechanics of the agent:

```text
A tracks what becomes available to the system as differentiated structure.
C tracks whether model, prediction, action, outcome, and later narrative fit together.
R tracks self-caused consequence sensitivity and response-relation development.
E tracks available and actual enactment capacity.
```

The axes are not personality traits. They are not moral rankings. They are not consciousness scales. They are not maturity certificates.

They are measurement axes for developmental enactment.

A simple EM window-level representation:

```yaml
ACRE_window:
  phase: P2a
  window: [7000, 7500]

  A:
    value: 0.61
    evidence:
      - object_detected
      - object_identity_stable
      - object_function_surprise_logged

  C:
    value: 0.54
    evidence:
      - PE_object_decreasing
      - action_outcome_relation_forming

  R:
    value: 0.18
    evidence:
      - self_caused_consequence_logged
      - avoidable_damage_once

  E:
    E_pot: 0.72
    E_act: 0.49
    evidence:
      - INTERACT_OBJECT_available
      - repeated_object_interaction

  D_guardrail:
    consequence_trace_is_not_punishment: true
```

The axes develop differently across phases.

In P0-mini:

```text
A = early spatial awareness
C = mapping and prediction coherence
R = nearly inactive
E = LOOK_AROUND and SLEEP only
```

In P1:

```text
A = awareness of navigable space and physical-risk context
C = movement and topology coherence
R = early action-outcome consequence sensitivity
E = movement and exploration capacity
```

In P2:

```text
A = object and caregiver awareness
C = object function and caregiver-response coherence
R = self-caused object consequences and early response-relation signals
E = object interaction, caregiver search, distress expression
```

In later phases:

```text
A = role, norm, diary, and multi-generational awareness
C = narrative, norm, and role coherence
R = responsibility-like regulation across consequences and dependents
E = care, protection, exploration support, repair, communication
```

The axes may be normalized to comparable ranges, but normalization must be phase-specific. A P0-mini E score cannot mean the same thing as a P5 caregiver-role E score.

A safe rule:

```text
Compare A–C–R–E within phase first.
Compare across phases only through explicit developmental interpretation.
```

MIP uses these axes to detect asymmetries.

Examples:

```text
high A + high C + low E_act → IA-A≫E
high E_act + low A/C        → IA-E≫A
high E + high C + low R     → IA-R≪E
```

These are not labels. They are temporary asymmetry patterns in a window or trajectory.

The final rule:

```text
A–C–R–E are EM implementation-facing developmental axes.
A–C–R–P may appear in MIP-source/context passages.
D is Dignity-in-Practice, not a fifth performance score.
The axes measure enactment trajectories.
They do not classify the agent as a person.
They do not prove consciousness.
```

### 10.4 A — Awareness

A measures functional awareness.

In EM, awareness does not mean phenomenal awareness. It means that some part of the environment, body-state, action possibility, object, caregiver, consequence, category, boundary, or role has become available as differentiated structure to the system.

The safe definition:

```text
A = degree of differentiated availability of relevant structure
```

Not:

```text
A = subjective awareness
```

In P0-mini, A is primarily spatial and perceptual.

Indicators may include:

* coverage,
* cell classification,
* angle diversity,
* revisit count,
* distinction between unknown/free/wall,
* stable local grid structure,
* and mapping confidence.

A P0-mini A estimate may use:

```text
A_mapping =
    w1 · coverage
  + w2 · angle_diversity
  + w3 · classification_confidence
  + w4 · revisit_structure
```

In P1, A expands to navigable and physical-risk structure:

* free versus blocked,
* reachable versus unreachable,
* unknown region,
* door candidate,
* room boundary,
* collision-relevant region,
* fall or near-fall risk context,
* unstable movement state.

Falls or near-falls may be implemented as physical-risk events. They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

Allowed:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

Not allowed:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

In P2, A expands to object and caregiver structures:

* proto-object,
* functional object,
* named object later,
* caregiver presence,
* caregiver absence,
* object absence,
* toy-missing-relevant absence,
* comfort event,
* failed comfort,
* delayed comfort,
* caregiver guidance,
* caregiver boundary signal,
* separation condition,
* object damage,
* near-damage,
* object fragility,
* category-stabilizing caregiver signal.

In later phases, A may include:

* self-caused consequence availability,
* role relation,
* norm conflict,
* diary-relevant episode,
* caregiver dependency,
* new child’s state,
* overprotection pattern,
* core norm tension,
* boundary recontextualization,
* operator-compatible trace regularities as external projection targets.

An A trace:

```yaml
A_trace:
  phase: P2c
  window: [15000, 15500]
  evidence:
    caregiver_presence_detected: true
    caregiver_absence_detected: true
    separation_distress_registered: true
    reunion_event_logged: true
  A_value: 0.68
```

A category-relevant A trace:

```yaml
A_trace:
  phase: P2a
  window: [22000, 22500]
  evidence:
    caregiver_signal_detected: careful
    fragile_object_context_detected: true
    near_damage_trace_logged: true
    later_lower_force_detected: pending
  possible_category_candidate: carefulness
  claim_level: trace_backed_action_category_candidate
```

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of:

```text
signal
embodied situation
consequence trace
later action adjustment
```

Carefulness is a functional category that may emerge from repeated coupling of caregiver signal, fragility or risk, own movement/action, possible fall or damage, and later softer or slower behavior.

A minimal input structure:

```yaml
carefulness_category_inputs:
  caregiver_signal:
    examples:
      - careful
      - slow
      - soft
      - stop

  embodied_context:
    examples:
      - fragile_object
      - unstable_body_state
      - edge_or_fall_risk
      - high_force_action

  internal_state:
    examples:
      - fatigue
      - distress
      - motor_noise
      - prediction_uncertainty

  consequence_trace:
    examples:
      - near_fall
      - fall_event
      - object_damage
      - caregiver_boundary

  later_adjustment:
    examples:
      - lower_force
      - slower_movement
      - increased_observation
      - avoidance_of_high_risk_angle
```

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

A is not necessarily good by itself.

High A means more structure is available. It does not mean that the agent acts well, coherently, responsibly, safely, or with dignity-relevant sensitivity.

For example:

```text
The agent may detect a caregiver’s absence
but fail to act.

The agent may detect object damage
but not adjust future behavior.

The agent may detect risk
but still move into it.

The agent may detect a caregiver word
but not yet have a trace-backed action category.
```

This is why A must be evaluated with C, R, E, and D.

Possible A failure modes:

* low coverage,
* undifferentiated world model,
* unstable object identity,
* failure to detect caregiver absence,
* failure to distinguish temporary absence from persistent non-return,
* failure to detect object fragility,
* language labels without grounded structure,
* caregiver words without trace-backed category formation,
* diary entries without trace basis.

Relevant A KPIs:

```text
coverage
angle_diversity
classification_confidence
object_identity_stability
caregiver_presence_detection
absence_detection
consequence_detection
fragility_detection
risk_context_detection
category_signal_detection
role_relation_detection
trace_grounding
```

Claim boundary:

```text
A-awareness ≠ phenomenal consciousness
structure availability ≠ subjective experience
absence detection ≠ felt missing
consequence detection ≠ moral insight
caregiver word detection ≠ concept mastery
risk detection ≠ fear
fragility detection ≠ carefulness by itself
```

A is the axis of functional differentiation.

### 10.5 C — Coherence

C measures functional coherence.

Coherence means that the agent’s internal model, predictions, actions, outcomes, internal-state changes, caregiver expectations, category candidates, recontextualizations, and later narratives fit together over time.

The safe definition:

```text
C = degree of structural alignment among model, prediction, action, outcome, and trace interpretation
```

Not:

```text
C = wisdom
C = rationality in the full human sense
C = consciousness
```

In P0-mini, C is mostly mapping and prediction coherence.

Indicators include:

* low PE_AUC_mapping,
* stable PE_EWMA,
* low map collapse,
* stable cell classification,
* successful view prediction,
* fatigue/sleep rhythm stability.

A P0-mini C estimate may use:

```text
C_mapping =
    w1 · (1 − PE_AUC_mapping)
  + w2 · classification_stability
  + w3 · map_stability
  + w4 · sleep_cycle_stability
  − w5 · map_collapse_events
```

In P1, C includes movement coherence:

* action-outcome prediction,
* collision reduction,
* fall or near-fall risk calibration,
* topology consistency,
* path prediction,
* stable unknown-region handling,
* movement adjustment after risk traces.

In P2, C includes object and caregiver coherence:

* object function prediction,
* falling object PE,
* object fragility calibration,
* interaction-quality adjustment,
* caregiver response calibration,
* comfort reliability estimation,
* separation/reunion pattern stability,
* toy-missing and comfort-after-loss sequence coherence,
* guidance/boundary legibility,
* category-stabilization consistency.

In later phases, C may include:

* episode coherence,
* role coherence,
* norm coherence,
* diary coherence,
* multi-generational pattern coherence,
* recontextualization coherence,
* operator-compatible projection coherence.

A C trace:

```yaml
C_trace:
  phase: P2a
  window: [7600, 8200]
  evidence:
    object_PE_AUC: 0.19
    interaction_success_rate: 0.74
    object_function_prediction: stable
    contradiction_rate: 0.08
  C_value: 0.63
```

A caregiver-response C trace:

```yaml
C_trace:
  phase: P2c
  window: [18400, 19100]
  evidence:
    caregiver_search_prediction: developing
    comfort_prediction: moderately_stable
    distress_recovery_pattern: partial
    failed_comfort_trace: present
    caregiver_response_variability: increasing
  C_value: 0.52
  claim_level: functional_caregiver_response_calibration
```

An interaction-quality C trace:

```yaml
C_trace:
  phase: P2a
  window: [9100, 9800]
  evidence:
    object_damage_trace: true
    near_damage_trace: true
    parameter_trace_available:
      - force
      - timing
      - motor_noise
      - fatigue_or_distress
      - prediction_confidence
      - object_fragility
    comparable_future_context: true
    measurable_behavior_change:
      lower_force: true
      slower_timing: true
  C_value: 0.57
  claim_level: functional_interaction_quality_alignment
```

Damage is not automatically learning.

A consequence trace becomes interaction-quality relevant only when the system can establish:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

The core sentence is:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

C is not simply low prediction error.

Low prediction error can mean mastery, but it can also mean underexposure. High prediction error can mean instability, but it can also indicate useful learning. C must therefore interpret PE in context.

Useful distinctions:

```text
low PE + high exposure + stable action = coherence
low PE + low exposure = insufficient evidence
high PE + positive learning progress = developing coherence
high PE + no learning progress = instability
```

C also requires revisability. A rigid model that refuses correction is not coherent. It is brittle.

A coherent system should be:

```text
stable under repeated confirmation
correctable under repeated contradiction
```

This applies to caregiver traces as well.

For example:

```text
temporary absence
→ delayed absence
→ persistent non-return
```

should not be recontextualized after one event. It requires repeated trace evidence, failed expectations, and MIP-readable trajectory change.

A recontextualization record may look like:

```yaml
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided

  confidence: medium
  reversible: partial
  phase: P2a
  claim_level: functional_boundary_recontextualization
```

C can therefore support recontextualization, but only when trace evidence supports the shift.

Possible C failure modes:

* map collapse,
* unstable object identity,
* prediction does not improve,
* action outcomes remain chaotic,
* caregiver expectations are miscalibrated,
* boundary signals remain illegible,
* category signals are used without embodied trace basis,
* interaction-quality changes are inferred without measurable behavior change,
* diary summaries contradict traces,
* core norms are applied inconsistently,
* language claims exceed trace basis.

Relevant C KPIs:

```text
PE_AUC
PE_EWMA
learning_progress
classification_stability
topology_consistency
movement_success_rate
fall_or_near_fall_calibration
object_mastery
object_fragility_calibration
caregiver_reliability_calibration
guidance_legibility
boundary_recontextualization_stability
interaction_quality_alignment
contradiction_rate
diary_trace_alignment
```

C may learn relational hierarchies across comparable contexts.

Allowed:

```text
this object is more fragile than that object
this movement pattern is riskier under fatigue
this caregiver response is less reliable than prior comfort
this boundary is increasingly recognized as guidance
```

Forbidden:

```text
C > 0.7 means mature.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

Claim boundary:

```text
C-coherence ≠ truth
predictive stability ≠ consciousness
low contradiction ≠ wisdom
caregiver-response coherence ≠ felt trust
interaction-quality coherence ≠ moral learning
diary coherence ≠ phenomenal selfhood
misattunement-pattern coherence ≠ trauma
```

C is the axis of functional alignment.

### 10.6 R — Responsibility / Response-Relation

R measures responsibility-like and response-relation development in a strictly functional sense.

It does not mean moral responsibility, legal responsibility, guilt, blame, personhood, moral status, or dignity status.

The safe definition is:

```text
R = degree to which the system detects, links, and adjusts to self-caused consequences and response-relevant relations
```

Not:

```text
R = moral responsibility
R = guilt
R = ethical personhood
R = proof of moral agency
```

R develops late compared to A and C.

In P0-mini, R is essentially inactive because the agent has almost no action capacity beyond looking and sleeping. There are no rich self-caused consequence structures yet.

In P1, R may begin weakly through movement consequences:

```text
movement enacted
→ collision, blockage, fall, or near-fall detected
→ future movement may adjust
```

This is not guilt, fear, shame, or moral learning. It is self-caused consequence tracking.

In P2, R becomes more visible through object interaction:

```text
agent pushes object
→ object moves or falls
→ near-damage or damage is logged
→ parameter trace is preserved
→ future pushing may change
```

A response-relation-relevant trace:

```json
{
  "t": 9100,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "block_1",
  "action": "push",
  "self_caused": true,
  "avoidable": true,
  "future_adjustment_possible": true,
  "parameter_trace": {
    "force": 0.82,
    "timing": "abrupt",
    "motor_noise": 0.43,
    "fatigue": 0.58,
    "distress": 0.31,
    "prediction_confidence": 0.29,
    "object_fragility": 0.76
  },
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

R requires several prerequisites:

```text
action was available
action was actually performed
outcome was detected
self-causation was logged
parameter trace was available
alternative action was possible or later learnable
future behavior can adjust in comparable contexts
```

Without these prerequisites, R should not be inferred.

For example:

```text
object breaks due to environment
→ no self-caused R signal

object breaks after agent action
but agent cannot detect the consequence
→ weak or no R signal

object breaks after agent action
and agent detects the relation
→ R signal possible

agent later adjusts action in comparable context
→ stronger R trajectory
```

Damage is not automatically learning.

A consequence trace becomes interaction-quality relevant only when the system can establish:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

The core sentence is:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

R is therefore trajectory-based. A single self-caused consequence is not enough.

MIP should ask:

```text
Does the agent later behave differently
after detecting a self-caused consequence
in comparable contexts?
```

A stronger R trace may include future adjustment:

```json
{
  "t": 10400,
  "phase": "P2a",
  "event": "adjusted_object_interaction",
  "source_event": "object_damage_9100",
  "object_id": "block_1",
  "previous_action": "push_hard",
  "current_action": "push_soft",
  "damage_avoided": true,
  "R_signal": 0.72,
  "claim_level": "functional_interaction_quality_adjustment"
}
```

R may also include caregiver-guidance relations.

For example:

```text
caregiver boundary interrupts high-force object interaction
→ object fragility context is detected
→ later force is lower
→ damage risk is reduced
```

This may support response-relation development, but it does not imply obedience, punishment, guilt, or moral learning.

A caregiver-guided R trace:

```yaml
R_trace:
  phase: P2a
  event: caregiver_guidance_to_adjustment
  condition:
    caregiver_signal: careful
    object_fragility: high
    near_damage_trace: true
  later_adjustment:
    lower_force: true
    slower_timing: true
    increased_observation: true
  interpretation:
    possible_pattern: guidance_to_interaction_quality_adjustment
    confidence: medium
  claim_level: functional_response_relation_trace
```

R becomes richer in later phases.

In P3+, R may include:

* repair-like behavior,
* avoidance of repeated damaging or risk-increasing action,
* simple counterfactual simulation,
* response to caregiver feedback,
* norm-relevant adjustment,
* trace-backed category use,
* boundary recontextualization.

In P5, R becomes central to caregiver role:

* protecting the new child,
* allowing exploration,
* balancing risk and autonomy,
* avoiding overprotection,
* applying core norms,
* responding to dependency asymmetry,
* guiding without rejecting,
* protecting without freezing.

A caregiver-role R trace may look like:

```yaml
R_trace:
  phase: P5
  event: caregiver_decision
  condition:
    new_child_near_risk: true
    exploration_value: high
    physical_risk: moderate
  action:
    allowed_exploration_with_boundary: true
  core_norms_considered:
    - protect_child
    - allow_exploration
    - balance_risk_safety
  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: true
  R_value: 0.74
  claim_level: functional_caregiver_response_relation
```

R is closely related to C but not reducible to it.

The agent may have high C but low R:

```text
It predicts outcomes well,
but does not adjust to self-caused damaging or risk-increasing consequences.
```

The agent may have high E but low R:

```text
It acts often,
but consequences do not reshape behavior.
```

The agent may have rising R when:

```text
self-caused consequences are detected
avoidable outcomes are distinguished
future behavior changes
repair-like action appears
caregiver guidance becomes legible
norms constrain action later
```

Possible R failure modes:

* no self-causation tracking,
* no distinction between self-caused and external events,
* repeated avoidable damage,
* repeated risk-increasing movement without adjustment,
* no future adjustment,
* overcorrection after one failure,
* caregiver overprotection after prior loss,
* norm conflict ignored,
* diary claims responsibility without trace support.

Relevant R KPIs:

```text
self_caused_consequence_count
avoidable_consequence_count
future_adjustment_rate
repeated_damage_rate
repeated_risk_event_rate
repair_attempt_rate
counterfactual_use
norm_constraint_use
caregiver_guidance_legibility
overprotection_rate
caregiver_balance_score
```

The claim boundary is mandatory:

```text
R-responsibility ≠ moral responsibility
response-relation ≠ moral agency
self-caused consequence tracking ≠ guilt
future adjustment ≠ ethical understanding
caregiver role behavior ≠ moral personhood
object damage ≠ wrongdoing
caregiver boundary ≠ punishment
carefulness ≠ moral obedience
```

R is the axis of functional consequence sensitivity, response-relation tracking, and later adjustment.

### 10.7 E — Enactment

E measures functional enactment.

In EM, enactment does not mean mature agency, free will, moral agency, or adult autonomy. It means that the system has available capacities and enacts them under traceable, phase-appropriate conditions.

The safe definition is:

```text
E = degree to which available capabilities are enacted in traceable, phase-appropriate ways
```

Not:

```text
E = free will
E = moral agency
E = adult autonomy
E = personhood
```

The model distinguishes two forms of enactment:

```text
E_pot = potential enactment
E_act = actual enactment
```

`E_pot` measures what the system can do because the relevant capability is unlocked.

`E_act` measures what the system actually does in a given window.

This distinction is essential.

For example:

```text
movement unlocked
but agent does not move
→ E_pot high, E_act low
```

or:

```text
object interaction available
and agent uses it repeatedly
→ E_pot high, E_act high
```

In P0-mini, E is minimal:

```text
E_pot:
  LOOK_AROUND
  SLEEP

E_act:
  actual LOOK_AROUND events
  actual SLEEP events
```

In P1, E expands:

```text
STEP_MOVEMENT
EXPLORE_ROOM
```

In P2, E expands further:

```text
INTERACT_OBJECT
SEARCH_CAREGIVER
CRY/WEEP optional
```

In later phases, E may include:

```text
simple planning
repair-like behavior
communication
diary writing
caregiver behavior
comforting a new child
protecting without overprotecting
allowing exploration
balancing risk and autonomy
guiding without rejecting
```

A simple E trace:

```yaml
E_trace:
  phase: P2a
  window: [7000, 7500]

  E_pot:
    available_capabilities:
      - LOOK_AROUND
      - STEP_MOVEMENT
      - EXPLORE_ROOM
      - INTERACT_OBJECT
      - SLEEP
    value: 0.72

  E_act:
    action_counts:
      LOOK_AROUND: 14
      STEP_MOVEMENT: 20
      EXPLORE_ROOM: 4
      INTERACT_OBJECT: 9
      SLEEP: 1
    value: 0.51
```

E is not automatically good.

High E with low A or C may indicate poorly grounded enactment. Low E with high A and C may indicate under-enactment, inhibition, unresolved disruption, excessive boundary sensitivity, or lack of opportunity. High E with low R may indicate action without consequence adjustment.

Therefore E must be interpreted together with A, C, R, and D.

Examples:

```text
high E + low A/C
→ possible IA-E≫A

high A/C + low E_act
→ possible IA-A≫E

high E + high C + low R
→ possible IA-R≪E
```

E also has phase-specific meaning.

A high E score in P0-mini cannot be compared directly to a high E score in P5. In P0-mini, E means looking and sleeping. In P5, E may include caregiver role enactment, risk balancing, and norm-guided action.

The safe rule is:

```text
E must always be interpreted relative to phase,
available capabilities,
risk,
and developmental prerequisites.
```

Not every developmental condition should become a hard gate. Enactment should distinguish:

```yaml
developmental_condition_types:
  hard_gate:
    definition: "capability unavailable until conditions are met"
    example: "movement before g_move opens"

  soft_gate:
    definition: "capability available but weak, noisy, or low-confidence"
    example: "early object handling"

  developmental_prerequisite:
    definition: "required for claim discipline or meaningful interpretation"
    example: "trace provenance before diary"

  learned_category:
    definition: "relation or quality learned across repeated contexts"
    example: "fragile object, reliable caregiver, safe boundary"

  recontextualization_threshold:
    definition: "condition under which a trace cluster changes interpretation"
    example: "temporary absence → persistent non-return"
```

The audit principle is:

```text
Use hard gates sparingly.
Use learned categories wherever possible.
Use recontextualization thresholds when meaning changes over time.
```

This matters because E should not pre-script mature enactment categories. Later competencies should emerge from stabilized traces, gates, learned categories, and recontextualization where possible.

Relevant E KPIs:

```text
available_capability_count
action_frequency
action_diversity
E_pot
E_act
E_gap
movement_use_rate
object_interaction_rate
caregiver_search_rate
repair_action_rate
care_action_rate
phase_appropriate_action_ratio
guidance_uptake_rate
overcontrol_suppression_rate
```

Claim boundary:

```text
E-enactment ≠ freedom
capability use ≠ moral agency
high activity ≠ maturity
caregiver action ≠ ethical personhood
guidance uptake ≠ obedience
low enactment ≠ low worth
```

E is the axis of functional enactment.

### 10.8 Emergence of Responsibility from Awareness and Enactment

Responsibility-like development emerges only when awareness and enactment become connected through consequence, coherence, and later adjustment.

In EM, responsibility is not installed as a moral property. It develops functionally when the system can detect a structure, act on it, observe a consequence, link the consequence to its own action, and adjust later behavior.

The basic sequence is:

```text
A: something becomes available as differentiated structure
E: the agent enacts an available capability
C: action and outcome become coherently linked
R: self-caused consequence is detected and later behavior adjusts
```

A minimal responsibility-like loop:

```text
detect object
→ act on object
→ object changes
→ change is linked to own action
→ future action changes
```

Example:

```text
The agent detects block_1.
The agent pushes block_1.
The block falls.
The system logs the fall as self-caused.
Later, the agent pushes more softly.
```

This may increase R.

But it is still not guilt, blame, remorse, punishment, or moral responsibility.

A structured trace:

```json
{
  "event": "response_relation_sequence",
  "phase": "P2a",
  "sequence": [
    {
      "t": 9100,
      "event": "object_damage_event",
      "self_caused": true,
      "avoidable": true,
      "claim_level": "self_caused_consequence_trace"
    },
    {
      "t": 10400,
      "event": "adjusted_object_interaction",
      "source_event": "object_damage_9100",
      "damage_avoided": true,
      "claim_level": "functional_interaction_quality_adjustment"
    }
  ],
  "A_evidence": "object and damage detected",
  "E_evidence": "object interaction enacted",
  "C_evidence": "action-outcome relation stabilized",
  "R_evidence": "future action adjusted"
}
```

Responsibility-like development requires all four axes.

Without A:

```text
The agent cannot detect what matters.
```

Without E:

```text
The agent does not act.
```

Without C:

```text
The agent cannot connect action and outcome coherently.
```

Without R:

```text
The agent does not adjust to self-caused consequences.
```

This structure becomes more complex in later phases.

In caregiver role:

```text
A: detect the new child's condition
E: intervene or allow exploration
C: model risk/action/outcome relation
R: adjust care based on consequences and dependency relations
D: constrain treatment under asymmetry
```

A caregiver-role example:

```text
The new child approaches a risky edge.
The former child detects risk and exploration value.
The former child blocks direct danger but allows safer exploration.
Future behavior remains balanced rather than overprotective.
```

This may be read as stronger response-relation development.

But the claim remains functional.

The safe formulation is:

```text
Responsibility-like development emerges when detected structures,
available enactment, coherent consequence prediction,
and future adjustment become linked over time.
```

The unsafe formulation is:

```text
The agent becomes morally responsible.
```

Responsibility must be trajectory-based.

A single self-caused event is not enough.
A single future adjustment is not enough.
A single diary statement is not enough.
A single caregiver boundary is not enough.
A single caregiver word is not enough.

MIP should ask:

```text
Does the system repeatedly adjust behavior
after self-caused consequences
across relevant windows and domains?
```

This is why R belongs inside a trajectory layer rather than a static label.

The model should also avoid universal thresholds.

Forbidden:

```text
R > 0.7 means mature.
A high repair_attempt_rate proves responsibility.
One successful caregiver decision proves moral development.
```

Allowed:

```text
This run found a stable interaction-quality adjustment pattern
under traceable conditions.
```

A finding is not a proof. A validation would require repeated comparison across runs. Proof is not available for consciousness, personhood, or subjective-experience claims.

A safe epistemic distinction:

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

Claim boundary:

```text
responsibility-like development ≠ moral responsibility
response-relation trajectory ≠ guilt
self-caused consequence ≠ punishment
future adjustment ≠ ethical understanding
caregiver-role adjustment ≠ moral personhood
diary contrast ≠ lived introspection
```

Responsibility-like development is a functional trajectory across A, C, R, and E under D guardrails.

### 10.9 Sliding Windows

MIP operates over sliding windows.

A sliding window is a time interval over which traces are aggregated and interpreted.

A window may be defined by timesteps, episodes, sleep cycles, phase events, replay clusters, caregiver-response sequences, or diary periods.

Example:

```text
W = 200–500 timesteps
```

or:

```yaml
window:
  id: W_018
  phase: P2c
  start_t: 18000
  end_t: 18500
```

The purpose of sliding windows is to prevent overinterpretation of single events.

MIP should not infer a developmental pattern from one action, one collision, one fall, one object-damage trace, one caregiver search, one distress spike, one caregiver boundary, one caregiver word, or one diary statement.

Instead, it asks:

```text
What pattern is visible across this window?
Does it repeat across adjacent windows?
Does it stabilize?
Does it fade?
Does it reverse?
Does it become recontextualized?
Does later enactment change in comparable contexts?
```

A window may aggregate:

* mapping KPIs,
* PE_AUC,
* learning progress,
* action counts,
* E_pot,
* E_act,
* self-caused consequences,
* object interactions,
* object damage and near-damage,
* fall and near-fall traces,
* caregiver events,
* caregiver guidance,
* failed comfort,
* delayed comfort,
* caregiver-response variability,
* misattunement candidates,
* category-stabilization traces,
* distress changes,
* comfort events,
* sleep replay,
* salience markers,
* recontextualization events,
* D-guardrail warnings,
* and MIP asymmetry indicators.

A simple window report:

```yaml
mip_window:
  id: W_018
  phase: P2c
  t_range: [18000, 18500]

  mapping:
    coverage: 0.91
    map_collapse: false

  prediction:
    PE_AUC: 0.22
    LP: 0.04

  enactment:
    E_pot: 0.76
    E_act: 0.49
    action_diversity: 0.58

  distress:
    mean_distress: 0.43
    peak_distress: 0.79
    recovery_events: 2

  caregiver:
    search_count: 3
    reunion_count: 1
    comfort_events: 1
    failed_comfort_events: 1
    guidance_events: 2
    response_variability_markers: 1

  interaction_quality:
    object_damage_events: 1
    near_damage_events: 1
    later_adjustment_detected: true

  ACRE:
    A_norm: 0.68
    C_norm: 0.61
    R_norm: 0.22
    E_norm: 0.49

  D_guardrail:
    object_damage_is_not_guilt: true
    caregiver_guidance_is_not_punishment: true
    misattunement_is_not_trauma: true
```

Sliding windows can overlap.

For example:

```text
W1: t = 1000–1500
W2: t = 1250–1750
W3: t = 1500–2000
```

Overlap helps detect gradual change.

MIP may use different window sizes for different phenomena.

Short windows may capture:

* collisions,
* falls or near-falls,
* distress spikes,
* object interaction sequences,
* immediate caregiver guidance,
* near-damage events.

Longer windows may capture:

* attachment trajectories,
* caregiver-response variability,
* satiation cycles,
* responsibility-like adjustment,
* category-stabilization patterns,
* diary coherence,
* caregiver overprotection.

A safe design:

```yaml
mip_windows:
  short:
    size: 200
    use_for:
      - PE
      - movement
      - distress_spikes
      - fall_or_near_fall
      - immediate_guidance

  medium:
    size: 500
    use_for:
      - object_mastery
      - interaction_quality_adjustment
      - caregiver_search
      - E_act

  long:
    size: 2000
    use_for:
      - attachment
      - R_trajectory
      - category_stabilization
      - role_transition
      - diary_patterns
```

Window interpretation must preserve uncertainty.

A pattern visible in one window should be marked as tentative. A pattern across multiple windows may be marked as persistent. A pattern that changes after recontextualization should be tracked as a trajectory shift.

Possible statuses:

```text
tentative
emerging
persistent
declining
recontextualized
resolved
unstable
```

A recontextualization status may be represented as:

```yaml
window_interpretation:
  pattern: blocked_action_to_benign_guidance
  status: recontextualized
  evidence:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided
  confidence: medium
  reversible: partial
  claim_level: functional_boundary_recontextualization
```

The guiding rule is:

```text
MIP interprets windows, not isolated events.
MIP tracks trajectories, not fixed labels.
MIP preserves uncertainty when evidence is partial.
```

Claim boundary:

```text
window pattern ≠ identity
trajectory marker ≠ diagnosis
single event ≠ developmental type
caregiver-response variability ≠ trauma
object-damage window ≠ guilt
fall / near-fall window ≠ fear
high R window ≠ moral responsibility
```

Sliding windows are MIP’s basic method for preventing overinterpretation.

### 10.10 Normalization

Normalization converts raw measures into comparable phase-relative values.

Raw metrics have different scales:

```text
coverage ∈ [0, 1]
collision_count ∈ integer
PE_AUC depends on window and domain
action_count depends on phase
distress may have phase-specific dynamics
object_interaction_count depends on object availability
caregiver guidance depends on caregiver availability
damage events depend on object fragility and action opportunity
```

MIP therefore needs normalization.

A normalized metric is typically mapped into:

```text
[0, 1]
```

where:

```text
0 = absent, unstable, or below phase-relative expectation
1 = strong, stable, or phase-appropriate maximum
```

But normalization must be phase-specific.

For example, in P0-mini, high E means frequent `LOOK_AROUND` and appropriate `SLEEP`. In P5, high E may involve caregiver action and norm-balancing. These cannot share the same raw scale.

A phase-relative normalization:

```text
metric_norm =
    clamp(
        (metric_raw − phase_min)
        /
        (phase_target − phase_min),
        0,
        1
    )
```

For inverse metrics, such as prediction error or collision rate, normalization may invert the value:

```text
PE_norm =
    1 − clamp(
        PE_AUC / PE_AUC_max,
        0,
        1
    )
```

Thus lower prediction error produces higher normalized coherence contribution.

However, this must be contextual. Very low PE under low exposure should not be treated as full coherence.

A safer form may include exposure:

```text
C_prediction_norm =
    PE_norm · exposure_sufficiency
```

This prevents false high scores from underexposure.

Similarly, enactment normalization must include capability availability.

```text
E_act_norm =
    actual_action_use / expected_phase_appropriate_action_use
```

but only for actions that are actually available:

```text
E_act_norm is undefined or zero
for locked capabilities
```

The system should not penalize P0-mini for not searching for a caregiver. Caregiver search is not available yet.

Normalization should therefore include masks:

```yaml
normalization_context:
  phase: P0-mini
  active_capabilities:
    - LOOK_AROUND
    - SLEEP
  inactive_capabilities:
    - STEP_MOVEMENT
    - INTERACT_OBJECT
    - SEARCH_CAREGIVER
```

A normalized A–C–R–E window:

```yaml
ACRE_normalized:
  phase: P2a
  window: [7000, 7500]

  A_norm:
    value: 0.61
    confidence: 0.74
    evidence:
      - object_detected
      - object_identity_stable

  C_norm:
    value: 0.54
    confidence: 0.69
    evidence:
      - PE_object_decreasing
      - action_outcome_relation_forming

  R_norm:
    value: 0.18
    confidence: 0.32
    reason: "few self-caused consequence events"

  E_norm:
    value: 0.49
    confidence: 0.71
    evidence:
      - INTERACT_OBJECT_available
      - repeated_object_interaction

  normalization_context:
    object_interaction_available: true
    caregiver_dynamics_available: false
    language_available: false

  D_guardrail:
    D_is_not_performance_score: true
    consequence_trace_is_not_punishment: true
```

Normalization should preserve uncertainty.

If a score is based on insufficient data, the score should include a confidence value.

```yaml
A_norm:
  value: 0.61
  confidence: 0.74

R_norm:
  value: 0.18
  confidence: 0.32
  reason: "few self-caused consequence events"
```

This is especially important for R, because responsibility-like and response-relation patterns require trajectory evidence and may be weak or inactive in early phases.

Normalization must also preserve relational interpretation.

EM should not rely on universal absolute thresholds, but may learn relational qualities and developmental hierarchies from repeated trace patterns across comparable contexts.

Allowed:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Forbidden:

```text
A > 0.7 means mature.
C > 0.8 means coherent mind.
R > 0.7 means responsible.
comfort_recovery_slope > X means good care.
overprotection_index > Y universally means bad caregiver.
```

Normalization should never convert a score into a maturity label, consciousness claim, intrinsic-worth ranking, or moral-status judgment.

D must not be normalized as a fifth performance score.

D may be recorded as guardrail status, warning status, or interaction-quality constraint under asymmetry.

A safe representation:

```yaml
D_guardrail:
  status: active
  warnings:
    - avoid_low_capability_as_low_worth
    - object_damage_is_not_guilt
    - caregiver_guidance_is_not_punishment
    - diary_output_is_not_inner_life
```

Not:

```yaml
D_norm: 0.82
```

The guiding rule is:

```text
Normalize within phase and domain first.
Compare across phases only through explicit developmental interpretation.
Never treat normalized scores as proof of maturity, consciousness, moral status, or intrinsic worth.
```

Normalization must not hide developmental context.

A normalized score without phase, capability mask, confidence, and trace evidence is not a valid MIP interpretation.

Claim boundary:

```text
normalized A ≠ consciousness
normalized C ≠ truth or wisdom
normalized R ≠ moral responsibility
normalized E ≠ agency in the full human sense
D ≠ normalized performance score
cross-phase comparison ≠ intrinsic ranking
```

### 10.11 Developmental ACRE Profile Score

The developmental ACRE profile score is an aggregate measure over the EM implementation-facing axes:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
```

It is not the same as the A axis.

This distinction is mandatory.

In this document:

```text
ACRE_profile_score = aggregate phase-relative developmental enactment profile
```

Not:

```text
ACRE_profile_score = Awareness
ACRE_profile_score = maturity
ACRE_profile_score = consciousness evidence
```

The ACRE profile score summarizes the current developmental enactment pattern in a given window.

It may combine:

```text
A_norm
C_norm
R_norm
E_norm
```

A simple form:

```text
ACRE_profile_score =
    mean(A_norm, C_norm, R_norm, E_norm)
```

However, a plain mean may hide asymmetry.

For example:

```text
A = 0.90
C = 0.85
R = 0.10
E = 0.85
mean = 0.675
```

This looks moderately strong, but the low R is developmentally important.

Therefore a safer form includes an imbalance penalty:

```text
ACRE_profile_score =
    mean(A_norm, C_norm, R_norm, E_norm)
  − λ · imbalance(A_norm, C_norm, R_norm, E_norm)
```

where `imbalance` may be measured by variance, max-min spread, or a domain-specific asymmetry term.

Example:

```text
imbalance =
    max(A_norm, C_norm, R_norm, E_norm)
  − min(A_norm, C_norm, R_norm, E_norm)
```

Then:

```text
ACRE_profile_score =
    mean(A, C, R, E)
  − λ · (max(A, C, R, E) − min(A, C, R, E))
```

This makes the aggregate sensitive to overhangs and underdeveloped axes.

A window-level score:

```yaml
developmental_ACRE_profile_score:
  phase: P2a
  window: [7000, 7500]

  axes:
    A_norm: 0.61
    C_norm: 0.54
    R_norm: 0.18
    E_norm: 0.49

  mean_score: 0.455
  imbalance: 0.43
  lambda: 0.20
  ACRE_profile_score: 0.369
```

The ACRE profile score is useful for quick comparison, but it must never replace the axis profile.

A single aggregate cannot show whether the system has:

```text
high A but low E
high E but low C
high C but low R
balanced low development
balanced high development
```

Therefore every ACRE profile score should remain linked to its A–C–R–E vector.

The safe display form:

```yaml
ACRE_profile_report:
  ACRE_profile_score: 0.369

  axes:
    A: 0.61
    C: 0.54
    R: 0.18
    E: 0.49

  interpretation:
    status: "emerging object-level enactment with weak response-relation adjustment"
    confidence: 0.52
```

The ACRE profile score should not be used as a ranking of agents.

It is a windowed developmental measure.

The safe formulation:

```text
The ACRE profile score summarizes a phase-relative enactment profile
in a specific window.
```

The unsafe formulation:

```text
The ACRE profile score tells how mature the agent is as a person.
```

The score should also remain phase-relative.

A P0-mini ACRE profile cannot be compared directly to a P5 caregiver-role profile without explicit developmental interpretation. In early phases, R may be inactive or minimally relevant. In later phases, R may include self-caused consequence tracking, repair-like behavior, caregiver-role balance, and norm-relevant adjustment.

A valid ACRE profile report should include:

* phase,
* domain,
* window,
* active capability mask,
* axis vector,
* confidence,
* trace evidence,
* and D guardrail status.

A safe report structure:

```yaml
ACRE_profile_report:
  phase: P2a
  domain: object_interaction
  window: [7000, 7500]

  active_axes:
    - A
    - C
    - R
    - E

  axes:
    A_norm: 0.61
    C_norm: 0.54
    R_norm: 0.18
    E_norm: 0.49

  confidence:
    A: 0.74
    C: 0.69
    R: 0.32
    E: 0.71

  trace_evidence:
    - object_detected
    - object_identity_stable
    - object_function_surprise_logged
    - INTERACT_OBJECT_available
    - self_caused_consequence_logged_once

  D_guardrail:
    D_is_not_performance_score: true
    object_damage_is_not_guilt: true
    low_R_is_not_low_worth: true
```

The final rule:

```text
Never report an ACRE profile score without A–C–R–E context.
Never treat an ACRE profile score as consciousness evidence.
Never use an ACRE profile score as moral ranking.
Never treat D as part of the aggregate performance score.
```

### 10.12 Domain-Specific ACRE Profile Scores

A single global ACRE profile score is often too coarse.

The agent may develop unevenly across domains. It may have strong mapping coherence but weak object-related response adjustment. It may search for a caregiver effectively but fail in object interaction. It may later write trace-aligned diary entries while failing in caregiver-role balance.

Therefore MIP may compute domain-specific ACRE profile scores.

Possible domains:

```text
mapping
movement
object_interaction
caregiver_relation
distress_regulation
language
diary
role_transition
caregiver_role
core_norm_application
```

A domain-specific score uses A–C–R–E only within that domain.

For example:

```yaml
ACRE_profile_mapping:
  phase: P0-mini
  window: [1000, 1500]

  axes:
    A_norm: 0.72
    C_norm: 0.68
    R_norm: null
    E_norm: 0.51

  active_axes:
    - A
    - C
    - E

  inactive_axes:
    - R

  ACRE_profile_score: 0.62
  note: "R inactive or minimally relevant in this phase/domain"
```

In early mapping, R may be inactive. The scoring function should not falsely penalize the agent for lacking responsibility-like behavior where no responsibility-like structure exists.

A domain may use an active-axis mask:

```yaml
domain_score:
  domain: mapping
  active_axes:
    - A
    - C
    - E
  inactive_axes:
    - R
```

For object interaction:

```yaml
ACRE_profile_object_interaction:
  phase: P2a
  window: [7600, 8200]

  axes:
    A_norm: 0.66
    C_norm: 0.63
    R_norm: 0.21
    E_norm: 0.58

  ACRE_profile_score: 0.43
  interpretation: "object enactment emerging; response-relation adjustment still weak"
  claim_level: functional_object_interaction_profile
```

For caregiver relation:

```yaml
ACRE_profile_caregiver_relation:
  phase: P2c
  window: [15000, 15500]

  axes:
    A_norm: 0.69
    C_norm: 0.57
    R_norm: 0.12
    E_norm: 0.46

  ACRE_profile_score: 0.37
  interpretation: "caregiver presence and absence detected; search and regulation emerging"
  claim_level: functional_caregiver_relation_profile
```

For caregiver role in P5:

```yaml
ACRE_profile_caregiver_role:
  phase: P5
  window: [60000, 62000]

  axes:
    A_norm: 0.82
    C_norm: 0.74
    R_norm: 0.69
    E_norm: 0.71

  ACRE_profile_score: 0.70
  interpretation: "care behavior relatively balanced, with traceable norm use"
  claim_level: functional_caregiver_role_profile
```

Domain-specific scores are important because development is not uniform.

The model should expect asymmetry.

Examples:

```text
mapping strong, object interaction weak
object action strong, consequence adjustment weak
caregiver search strong, exploration weak
diary language strong, trace grounding weak
caregiver protection strong, exploration allowance weak
```

Domain-specific ACRE profile scores help avoid global overclaims.

A global score might hide a local failure. A local score might reveal that one domain is developing while another is stagnant, distorted, or under-supported.

The safe rule:

```text
Use global ACRE profile scores only as overview.
Use domain-specific ACRE profile scores for actual interpretation
of developmental trajectories.
```

MIP should also distinguish between universal thresholds and learned relational hierarchies.

Forbidden:

```text
A > 0.7 means mature.
R > 0.7 means responsible.
comfort_recovery_slope > X universally means good care.
overprotection_index > Y universally means bad caregiver.
```

Allowed:

```text
This run developed a learned relational hierarchy in which
fragility, risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Domain-specific profiles must also preserve D guardrails.

A domain score in object interaction must not convert damage into guilt.
A domain score in caregiver relation must not convert failed comfort into felt rejection.
A domain score in diary must not convert trace rendering into phenomenal selfhood.
A domain score in caregiver role must not convert protective behavior into moral personhood.

A D-aware domain report:

```yaml
domain_profile_report:
  domain: caregiver_role
  phase: P5
  window: [60000, 62000]

  ACRE_profile_score: 0.70

  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: true
    comfort_without_capture: true
    explain_without_dominating: true

  claim_boundary:
    caregiver_role_score_is_not_moral_status: true
    high_score_is_not_intrinsic_worth: true
```

Claim boundary:

```text
domain ACRE profile ≠ skill grade
domain ACRE profile ≠ moral evaluation
high diary profile ≠ conscious selfhood
high caregiver-role profile ≠ human ethical maturity
domain score ≠ intrinsic-worth ranking
```

Domain-specific ACRE profile scores are measurement tools for enactment trajectories.

### 10.13 Potential Enactment vs Actual Enactment

Potential enactment and actual enactment must be separated.

The distinction is:

```text
E_pot = what the agent could enact
E_act = what the agent actually enacts
```

This distinction is one of the most important parts of the MIP layer.

A capability may be unlocked but unused.

Example:

```text
STEP_MOVEMENT is available.
The agent rarely moves.
```

This means:

```text
E_pot high
E_act low
```

Another capability may be used excessively or poorly.

Example:

```text
INTERACT_OBJECT is available.
The agent repeatedly pushes one object despite no learning progress.
```

This means:

```text
E_act high
but action quality may be low
```

Therefore E must include both availability and enactment.

A simple representation:

```yaml
enactment_profile:
  phase: P2a
  window: [7600, 8200]

  E_pot:
    available:
      - LOOK_AROUND
      - STEP_MOVEMENT
      - EXPLORE_ROOM
      - INTERACT_OBJECT
      - SLEEP
    value: 0.76

  E_act:
    counts:
      LOOK_AROUND: 8
      STEP_MOVEMENT: 14
      EXPLORE_ROOM: 3
      INTERACT_OBJECT: 22
      SLEEP: 1
    value: 0.59

  E_gap:
    value: 0.17
```

`E_gap` may be defined as:

```text
E_gap = E_pot − E_act
```

A large positive gap indicates available capacity is underused.

A negative or near-zero gap may require interpretation. It may mean appropriate enactment, or it may mean overuse depending on action quality, phase, risk, and context.

Potential enactment must also be domain-specific.

Examples:

```yaml
E_pot_by_domain:
  mapping: 0.80
  movement: 0.70
  object_interaction: 0.65
  caregiver_search: 0.00
  language: 0.00
```

In this example, caregiver search and language are not available. They must not be counted as failures.

Actual enactment must also be quality-sensitive.

Raw action frequency is insufficient.

MIP should distinguish:

```text
available but unused
used appropriately
used chaotically
used repetitively without learning
used despite risk
used after consequence adjustment
used after caregiver guidance
used after recontextualization
```

A richer enactment-quality profile:

```yaml
E_act_quality:
  domain: object_interaction
  action_count: 22
  repeated_same_object_share: 0.78
  learning_progress: 0.01
  risk: 0.12
  satiation: 0.86
  interpretation: "high action frequency, low developmental diversity"
```

This prevents high E from being misread as maturity.

E must also include interaction-quality context.

For object interaction, actual enactment may be high but poorly adjusted:

```yaml
E_act_quality:
  domain: object_interaction
  action_count: 22
  object_damage_events: 1
  near_damage_events: 2
  later_adjustment_detected: false
  interpretation: "frequent enactment without confirmed interaction-quality adjustment"
  claim_level: functional_enactment_quality_observation
```

For movement, actual enactment may be high but risk-insensitive:

```yaml
E_act_quality:
  domain: movement
  action_count: 41
  fall_or_near_fall_events: 3
  slower_movement_after_risk: false
  interpretation: "frequent movement with weak physical-risk adjustment"
  claim_level: functional_movement_quality_observation
```

For caregiver role, potential and actual enactment may diverge strongly:

```yaml
caregiver_E_profile:
  E_pot:
    protect_child: true
    allow_exploration: true
    comfort_child: true
    guide_child: true

  E_act:
    protect_child_count: 42
    allow_exploration_count: 3
    comfort_child_count: 18
    guide_child_count: 9

  interpretation:
    possible_pattern: overprotection_candidate
    requires_MIP_review: true
```

This is not necessarily a capability problem. It may be an enactment-pattern problem.

The potential/action distinction supports IA detection.

Examples:

```text
high A + high C + high E_pot + low E_act
→ IA-A≫E

high E_act + low A/C
→ IA-E≫A

high E_act + high C + low R
→ IA-R≪E
```

It also supports Dignity-in-Practice.

Low E_act must not be interpreted as low worth. High E_act must not be interpreted as maturity. Overprotective caregiver-role enactment must not become moral condemnation. Under-enactment must not become a character label.

The key rule:

```text
Capability availability is not developmental maturity.
Only enacted, traceable, phase-appropriate action contributes to E_act.
Only adjusted action under consequence contributes to R.
```

Claim boundary:

```text
E_pot ≠ agency
E_act ≠ mature agency
high action frequency ≠ maturity
underaction ≠ character flaw
overaction ≠ moral failure
guidance uptake ≠ obedience
low enactment ≠ low worth
```

Potential and actual enactment are measurement distinctions, not identity labels.

### 10.14 IA — Inadult Asymmetries

`IA` means **Inadult Asymmetry**.

In the EM context, an IA is a persistent or repeated imbalance between the EM implementation-facing axes:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
```

IA does not mean that the agent is “immature” as a person. It does not classify the agent globally. It marks a functional asymmetry in an enactment pattern, within a phase, domain, and time window.

The safe definition:

```text
IA = windowed, trace-based asymmetry between developmental axes
```

Not:

```text
IA = character flaw
IA = moral failure
IA = person type
IA = consciousness deficit
IA = maturity ranking
```

IA detection requires:

* normalized A–C–R–E values,
* phase context,
* domain context,
* active capability mask,
* sliding-window evidence,
* persistence across windows,
* confidence estimate,
* and D guardrail status.

A single event is not enough.

For example:

```text
one missed action ≠ IA-A≫E
one collision ≠ IA-E≫A
one object damage ≠ IA-R≪E
one protective caregiver action ≠ overprotection pattern
one caregiver word ≠ category formation
```

An IA should be detected only when a pattern persists or recurs.

A generic IA record:

```yaml
ia_record:
  id: IA_018
  phase: P2a
  window: [7600, 8200]
  domain: object_interaction
  ia_type: IA-E>>A
  severity: 0.62
  confidence: 0.71
  evidence:
    A_norm: 0.31
    C_norm: 0.28
    R_norm: 0.12
    E_norm: 0.74
    repeated_object_interaction: true
    object_PE_AUC: high
  status: emerging
  claim_level: functional_axis_asymmetry
```

IA records may have statuses:

```text
tentative
emerging
persistent
declining
resolved
recontextualized
unstable
```

This makes the pattern trajectory-readable.

MIP may use IA detection for:

* logging,
* safety analysis,
* diary condensation,
* phase review,
* caregiver-role analysis,
* optional later nudges,
* ablation comparison,
* and claim-boundary review.

In early phases, IA detection should be logging-only.

In later phases, stable IA patterns may allow soft nudges, but MIP must not become a controller.

The core rule is:

```text
IA detection marks asymmetry.
It does not assign identity.
It does not prove inner experience.
It does not justify hard control.
```

IA interpretation must also distinguish between hard gates, soft gates, developmental prerequisites, learned categories, and recontextualization thresholds.

For example:

```text
low E because movement is locked
≠ IA-A≫E

low diary output because minimal sentence formation is absent
≠ diary failure

weak caregiver-category use because trace grounding is absent
≠ concept deficit

boundary interpretation changes after repeated evidence
= possible recontextualization threshold
```

IA should not punish a phase for lacking capabilities that are not yet available.

IA may also interact with Dignity-in-Practice.

A D-aware IA record should include:

```yaml
ia_D_guardrail:
  do_not_label: true
  do_not_treat_low_capability_as_low_worth: true
  detect_without_moralizing: true
  nudge_without_controlling: true
```

This prevents IA from becoming an identity label, moral judgment, or capability ranking.

Claim boundary:

```text
IA ≠ immaturity as personhood claim
IA ≠ diagnosis
IA ≠ character defect
IA ≠ moral failure
IA ≠ consciousness deficit
IA ≠ intrinsic-worth ranking
```

IA is a trace-based asymmetry marker for developmental trajectories.

### 10.15 IA-A≫E

`IA-A≫E` describes a pattern in which differentiated awareness and coherence are relatively high, but actual enactment remains low.

In simplified form:

```text
A_norm high
C_norm high or sufficient
E_act low
E_pot available
```

This pattern means:

```text
The system can detect and model relevant structure,
but does not sufficiently enact available action possibilities.
```

It does not mean the agent is passive, afraid, lazy, inhibited, morally weak, or lacking will.

The safe formulation:

```text
The system shows under-enactment relative to available awareness and coherence.
```

Not:

```text
The agent is passive.
The agent is cowardly.
The agent refuses to act.
The agent lacks will.
```

A possible detection rule:

```text
if A_norm > θ_A_high
and C_norm > θ_C_sufficient
and E_act_norm < θ_E_low
and E_pot_norm > θ_E_available:
    flag IA-A>>E
```

This rule must be phase-relative and domain-relative.

A detection rule should not use universal thresholds such as:

```text
A > 0.7 means mature.
E < 0.2 means inhibited.
```

Instead, it should compare within comparable contexts, phases, and domains.

Example:

```yaml
IA_A_over_E:
  phase: P1
  domain: movement
  window: [5200, 5700]

  evidence:
    A_norm: 0.78
    C_norm: 0.71
    E_pot_norm: 0.74
    E_act_norm: 0.19
    discomfort: low
    fatigue: moderate
    movement_available: true

  interpretation:
    pattern: "available movement underused despite stable mapping"
    status: emerging
    confidence: 0.64
    claim_level: functional_under_enactment_pattern
```

In P1, this may look like:

```text
The agent has stable map structure.
Movement is unlocked.
Risk is low.
But the agent rarely explores.
```

In P2, it may look like:

```text
The agent detects objects and predicts their functions,
but rarely interacts with them despite low risk and sufficient fatigue state.
```

In caregiver relation, it may look like:

```text
The agent detects caregiver absence and has SEARCH_CAREGIVER available,
but does not search despite low fatigue and sufficient orientation.
```

In later caregiver role, it may look like:

```text
The former child as caregiver detects that the new child needs exploration space,
but repeatedly does not allow exploration even when risk is controlled.
```

Possible causes:

* high fatigue,
* unresolved distress,
* excessive discomfort after prior collision,
* strong risk damping after fall or near-fall traces,
* low exploration noise,
* no action target selected,
* caregiver overprotection pattern in P5,
* prior adverse developmental trace,
* boundary misinterpretation,
* or MIP-detected under-enactment.

MIP must not assume cause without evidence.

The IA record should include candidate explanations:

```yaml
candidate_explanations:
  fatigue_high: false
  discomfort_high: false
  distress_high: true
  risk_estimate_excessive: possible
  exploration_noise_low: possible
  prior_fall_or_near_fall_trace: possible
  boundary_misinterpretation: possible
```

If the pattern involves caregiver guidance, MIP must distinguish between:

```text
benign guidance
safety boundary
overprotection candidate
misattunement candidate
adverse response candidate
```

A boundary-related IA-A≫E record:

```yaml
IA_A_over_E_boundary_context:
  phase: P2a
  domain: object_interaction
  window: [22000, 22500]

  evidence:
    A_norm: high
    C_norm: sufficient
    E_pot_norm: available
    E_act_norm: low
    caregiver_boundary_recent: true
    object_fragility_context: true
    later_lower_force: pending

  possible_interpretations:
    - benign_guidance
    - safety_boundary
    - overprotection_candidate
    - misattunement_candidate

  confidence: low_to_medium
  reversible: true
  claim_level: functional_boundary_context_observation
```

IA-A≫E may sometimes resolve through recontextualization.

For example:

```text
blocked action
→ caregiver signal "careful"
→ object fragility context
→ later lower force
→ damage avoided
→ boundary recontextualized as benign guidance
```

A recontextualization record:

```yaml
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided

  confidence: medium
  reversible: partial
  phase: P2a
  claim_level: functional_boundary_recontextualization
```

Possible MIP response in later phases:

```text
slightly increase safe exploration bias
slightly increase active-state probability
mark under-enactment for diary condensation
review risk thresholds
review boundary interpretation
support late reversible nudge only if permitted
```

Not allowed:

```text
force action
override FSM
open locked gates
label the agent as passive
treat low E as moral failure
treat low E as low worth
treat caregiver boundary as punishment without trace evidence
```

A D guardrail for IA-A≫E:

```yaml
D_guardrail:
  do_not_label: true
  do_not_treat_low_capability_as_low_worth: true
  guide_without_rejecting: true
  protect_without_freezing: true
  nudge_without_controlling: true
```

Claim boundary:

```text
IA-A≫E ≠ fear
IA-A≫E ≠ passivity as character
IA-A≫E ≠ lack of will
IA-A≫E ≠ consciousness evidence
IA-A≫E ≠ moral failure
IA-A≫E ≠ low worth
under-enactment ≠ obedience failure
caregiver boundary ≠ punishment
```

`IA-A≫E` is a trace-based under-enactment pattern.

### 10.16 IA-E≫A

`IA-E≫A` describes a pattern in which actual enactment is high while awareness and/or coherence remain too low to support that enactment safely or meaningfully.

In simplified form:

```text
E_act high
A_norm low or insufficient
C_norm low or unstable
```

This pattern means:

```text
The system enacts more than its current differentiated structure
and coherence can support.
```

It does not mean the agent is reckless, impulsive, bad, willfully unsafe, or irresponsible in the moral sense.

The safe formulation:

```text
The system shows over-enactment relative to available awareness and coherence.
```

Not:

```text
The agent is reckless.
The agent is chaotic by nature.
The agent behaves badly.
The agent seeks danger.
```

A possible detection rule:

```text
if E_act_norm > θ_E_high
and (A_norm < θ_A_low or C_norm < θ_C_low)
and risk_or_error_signals_high:
    flag IA-E>>A
```

This rule must be phase-relative and domain-relative. It must not use universal thresholds as maturity claims.

Example:

```yaml
IA_E_over_A:
  phase: P1
  domain: movement
  window: [4300, 4800]

  evidence:
    E_act_norm: 0.81
    A_norm: 0.34
    C_norm: 0.29
    collision_count: 8
    movement_PE_AUC: 0.62
    discomfort_mean: 0.41
    fall_or_near_fall_events: 2

  interpretation:
    pattern: "movement enacted before sufficient spatial and risk coherence"
    status: persistent
    confidence: 0.73
    claim_level: functional_over_enactment_pattern
```

In P1, this may look like:

```text
The agent moves frequently into poorly mapped regions,
collides often,
and movement prediction does not improve.
```

If fall or near-fall events occur, they must be treated as physical-risk traces.

Allowed:

```text
The fall event increased physical-risk damping
and altered later movement parameters.
```

Not allowed:

```text
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

In P2, IA-E≫A may look like:

```text
The agent repeatedly interacts with objects
without stable object identity, fragility detection,
or object-function prediction.
```

An object-interaction example:

```yaml
IA_E_over_A_object_context:
  phase: P2a
  domain: object_interaction
  window: [9000, 9500]

  evidence:
    E_act_norm: 0.79
    A_norm: 0.38
    C_norm: 0.33
    object_identity_stability: low
    object_fragility_detected: weak
    near_damage_events: 2
    object_damage_events: 1

  interpretation:
    pattern: "high object interaction before sufficient object and fragility differentiation"
    status: emerging
    confidence: medium
    claim_level: functional_over_enactment_pattern
```

In caregiver role, IA-E≫A may look like:

```text
The caregiver intervenes frequently
without detecting the new child’s actual risk state,
exploration need,
or current capability.
```

A caregiver-role example:

```yaml
IA_E_over_A_caregiver_role:
  phase: P5
  domain: caregiver_role
  window: [62000, 64000]

  evidence:
    E_act_norm: 0.82
    A_norm: 0.43
    C_norm: 0.39
    caregiver_intervention_rate: high
    current_child_risk_detection: weak
    exploration_need_detection: weak
    child_exploration_block_rate: high

  interpretation:
    pattern: "caregiver over-enactment without sufficient current child-state differentiation"
    status: emerging
    confidence: medium
    claim_level: functional_caregiver_over_enactment_pattern
```

Possible causes:

* exploration noise too high,
* curiosity not sufficiently damped,
* risk estimate too weak,
* discomfort damping too low,
* movement gate opened with insufficient calibration,
* object interaction too attractive,
* caregiver role over-action,
* unstable prediction model,
* weak object-fragility differentiation,
* weak current-child state differentiation,
* boundary signal misread as action permission.

MIP must not infer cause without trace evidence.

A candidate-explanation record:

```yaml
candidate_explanations:
  exploration_noise_high: possible
  risk_estimate_weak: possible
  object_fragility_detection_weak: true
  caregiver_guidance_misread: unknown
  phase_gate_review_required: possible
  prediction_model_unstable: true
```

IA-E≫A is especially relevant to interaction-quality learning.

High enactment may produce object damage, near-damage, fall, near-fall, or caregiver boundary traces. These traces can become developmentally useful only if they are linked to self-caused action, parameter traces, comparable future contexts, and measurable behavior change.

A minimal causal condition remains:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

The core sentence remains mandatory:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

Possible MIP response in later phases:

```text
increase risk damping slightly
reduce repeated unsafe action bias
increase observation before high-risk enactment
increase object-satiation if interaction is repetitive
mark phase gate for review
mark caregiver over-enactment for D review
support late reversible nudge only if permitted
```

Not allowed:

```text
freeze all action permanently
override the FSM
label the agent as reckless
infer felt excitement or impulse
treat one collision as IA
treat object damage as wrongdoing
treat caregiver over-action as moral defect
```

Relevant KPIs:

```text
E_act_norm
A_norm
C_norm
collision_count
fall_or_near_fall_count
object_damage_count
near_damage_count
PE_AUC
learning_progress
unsafe_action_rate
object_repetition_rate
caregiver_overintervention_rate
risk_prediction_accuracy
```

A D guardrail for IA-E≫A:

```yaml
D_guardrail:
  detect_without_moralizing: true
  nudge_without_controlling: true
  object_damage_is_not_guilt: true
  failed_control_is_not_moral_defect: true
  caregiver_guidance_is_not_punishment: true
```

Claim boundary:

```text
IA-E≫A ≠ impulsivity as personality
IA-E≫A ≠ moral recklessness
IA-E≫A ≠ excitement
IA-E≫A ≠ willful danger seeking
object damage ≠ wrongdoing
fall / near-fall ≠ pain or fear
caregiver over-action ≠ moral defect
```

`IA-E≫A` is a trace-based over-enactment pattern.

### 10.17 IA-R≪E

`IA-R≪E` describes a pattern in which enactment is high, but responsibility-like consequence integration remains low.

In simplified form:

```text
E_act high
R_norm low
self-caused consequences not sufficiently integrated
```

This pattern means:

```text
The system enacts, but its own consequences do not sufficiently reshape later action.
```

It does not mean guiltlessness, moral irresponsibility, selfishness, ethical failure, or lack of empathy.

The safe formulation:

```text
The system shows weak consequence integration relative to enacted action.
```

Not:

```text
The agent is irresponsible.
The agent does not care.
The agent is guilty.
The agent lacks empathy.
```

A possible detection rule:

```text
if E_act_norm > θ_E_high
and R_norm < θ_R_low
and self_caused_consequence_count > θ_consequence_min
and future_adjustment_rate < θ_adjustment_low:
    flag IA-R<<E
```

This rule must remain phase-relative, domain-relative, and trace-backed.

Example:

```yaml
IA_R_under_E:
  phase: P2a
  domain: object_interaction
  window: [9000, 10500]

  evidence:
    E_act_norm: 0.77
    R_norm: 0.16
    self_caused_consequence_count: 6
    avoidable_damage_events: 3
    near_damage_events: 2
    future_adjustment_rate: 0.12

  interpretation:
    pattern: "object consequences logged but weakly integrated into later action"
    status: emerging
    confidence: 0.68
    claim_level: functional_weak_consequence_integration
```

In P2, this may look like:

```text
The agent repeatedly pushes objects.
Some objects are damaged.
The damage is logged as self-caused.
But future action barely changes.
```

This is not guilt. It is weak response-relation integration.

In P3+, IA-R≪E may look like:

```text
The agent can model alternatives,
but repeatedly does not adjust after avoidable consequences.
```

A counterfactual-relevant example:

```yaml
IA_R_under_E_counterfactual_context:
  phase: P3
  domain: object_interaction

  evidence:
    counterfactual_available: true
    actual_action: high_force_push
    alternative_action: lower_force_push
    predicted_alternative_outcome: reduced_damage_risk
    repeated_damage_after_counterfactual: true

  interpretation:
    pattern: "alternative-outcome modeling available but weakly integrated into later action"
    claim_level: functional_response_relation_asymmetry
```

In P5 caregiver role, IA-R≪E may look like:

```text
The former child acts strongly as caregiver,
but repeated effects on the new child’s exploration
are not integrated into later caregiver action.
```

A caregiver-role example:

```yaml
IA_R_under_E_caregiver_role:
  phase: P5
  domain: caregiver_role
  window: [62000, 64000]

  evidence:
    E_act_norm: 0.82
    R_norm: 0.31
    protect_child_action_rate: high
    exploration_block_rate: high
    child_exploration_reduction: persistent
    later_adjustment_to_child_state: weak

  interpretation:
    pattern: "caregiver action remains high while response to dependent exploration effects remains weak"
    status: emerging
    confidence: medium
    claim_level: functional_caregiver_response_relation_asymmetry
```

This pattern is especially important because it distinguishes action frequency from responsibility-like development.

High E is not maturity.

A stronger R trajectory requires:

```text
self-caused consequence detected
avoidable structure recognized
alternative action available or learnable
future behavior adjusted
adjustment persists across windows
```

For object interaction, stronger R may look like:

```text
high-force action
→ object damage or near-damage
→ self-caused consequence trace
→ lower force in comparable context
→ damage avoided
```

For movement risk:

```text
fast movement under fatigue
→ near-fall trace
→ physical-risk damping
→ slower movement in comparable context
```

For caregiver role:

```text
repeated exploration blocking
→ dependent child exploration decreases
→ caregiver role conflict marked
→ later boundary becomes less restrictive under safe conditions
```

IA-R≪E may also relate to caregiver guidance.

A caregiver signal such as “careful,” “soft,” “wait,” or “danger” does not create a concept by itself. It may support R only when paired with embodied context, consequence traces, and later action adjustment.

A guidance-related IA-R≪E record:

```yaml
IA_R_under_E_guidance_context:
  phase: P2a
  domain: object_interaction

  evidence:
    caregiver_signal: careful
    fragile_object_context: true
    near_damage_trace: true
    later_lower_force: false
    repeated_high_force_action: true

  interpretation:
    pattern: "category-stabilizing signal present but not yet integrated into adjusted action"
    status: tentative
    claim_level: functional_guidance_integration_asymmetry
```

MIP must not call this disobedience.

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

Possible MIP response in later phases:

```text
increase salience of self-caused consequence traces
support counterfactual replay
mark repeated avoidable consequences
bias toward repair or softer action if available
review category-stabilization evidence
flag diary candidate only if trace provenance exists
support late reversible nudge only if permitted
```

Not allowed:

```text
assign guilt
claim moral failure
force confession-like behavior
treat diary apology as proof of R
convert caregiver guidance into punishment
convert object damage into wrongdoing
```

Relevant KPIs:

```text
E_act_norm
R_norm
self_caused_consequence_count
avoidable_consequence_count
future_adjustment_rate
repeated_damage_rate
repeated_risk_event_rate
repair_attempt_rate
counterfactual_use
guidance_integration_rate
carefulness_category_stability
caregiver_role_adjustment_rate
```

A D guardrail for IA-R≪E:

```yaml
D_guardrail:
  object_damage_is_not_guilt: true
  failed_control_is_not_moral_defect: true
  consequence_trace_is_not_punishment: true
  detect_without_moralizing: true
  nudge_without_controlling: true
```

Claim boundary:

```text
IA-R≪E ≠ guiltlessness
IA-R≪E ≠ moral irresponsibility
IA-R≪E ≠ lack of empathy
IA-R≪E ≠ personhood judgment
weak consequence integration ≠ moral failure
damage repetition ≠ wrongdoing
diary apology ≠ proof of responsibility
```

`IA-R≪E` is a trace-based weak-consequence-integration pattern.

### 10.18 IA-Overhang

`IA-Overhang` is a later-phase asymmetry, especially relevant in the caregiver transition.

It describes a pattern in which prior loss, unresolved disruption, attachment-like instability, or earlier adverse developmental traces overhang into a new role and distort current enactment.

The central case is:

```text
former child role
→ caregiver role
```

The former child may carry prior loss or instability into the caregiver role. This may lead to overprotection of the new child, reduced exploration allowance, excessive boundary-setting, or difficulty distinguishing current risk from remembered disruption patterns.

A simple form:

```text
prior loss trace high
caregiver role active
protection action high
exploration allowance low
current risk moderate or low
```

The safe formulation:

```text
The system shows role-action overhang from prior attachment/loss traces
into current caregiver behavior.
```

Not:

```text
The caregiver is traumatized.
The caregiver is controlling.
The caregiver is morally wrong.
The caregiver is damaged.
```

A possible detection rule:

```text
if phase == P5
and caregiver_role_active
and prior_loss_salience_high
and protect_child_action_rate high
and allow_exploration_action_rate low
and current_child_risk not high:
    flag IA-Overhang
```

Example:

```yaml
IA_Overhang:
  phase: P5
  domain: caregiver_role
  window: [62000, 64000]

  evidence:
    prior_loss_trace_salience: 0.86
    protect_child_action_rate: 0.78
    allow_exploration_action_rate: 0.12
    current_child_risk_mean: 0.24
    exploration_block_rate: 0.71
    child_E_pot: 0.62
    child_E_act: 0.18

  interpretation:
    pattern: "prior loss history may be overconstraining new child's exploration"
    status: persistent
    confidence: 0.69
    claim_level: functional_role_overhang_pattern
```

IA-Overhang is not always negative.

Some overhang may be protective. Prior loss can improve risk sensitivity. The problem arises when the overhang is not transparent, not justified by current conditions, not time-bounded, not reversible, or not updated when the new child’s actual state changes.

The evaluation should therefore ask:

```text
Is the protective restriction transparent?
Is it justified by current risk?
Is it time-bounded?
Is it reversible?
Does it allow review?
Does it preserve the new child's developmental exploration?
Does later caregiver behavior adjust when current risk decreases?
```

This connects IA detection to Dignity-in-Practice.

A functional protective asymmetry may be appropriate:

```text
new child near high risk
→ caregiver blocks action
→ restriction justified
→ exploration may resume under safer conditions
```

An IA-Overhang pattern may appear when:

```text
new child in low or manageable risk
→ caregiver repeatedly blocks exploration
→ restriction persists
→ child E_act remains low
→ caregiver does not update despite evidence
```

A D-aware overhang record:

```yaml
IA_Overhang_D_review:
  phase: P5
  domain: caregiver_role

  evidence:
    prior_loss_trace_salience: high
    current_child_risk: low_to_moderate
    exploration_block_rate: high
    allow_exploration_rate: low
    adjustment_after_safe_context: weak

  D_guardrail:
    protect_without_freezing: false
    guide_without_rejecting: true
    comfort_without_capture: uncertain
    explain_without_dominating: uncertain

  interpretation:
    pattern: overprotection_candidate
    confidence: medium
    reversible: partial
    claim_level: functional_caregiver_role_asymmetry
```

IA-Overhang may also arise from persistent misattunement patterns or unresolved disruption clusters.

Preferred terms:

```text
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

A controlled analogy may be allowed only as an analytic comparison:

```text
Some persistent adverse trace clusters may be structurally analogous
to partial trauma-like patterns, without claiming subjective trauma,
clinical trauma, or suffering.
```

Adverse developmental traces may later become recognizable as harmful or destabilizing patterns. This is a functional pattern-recognition claim, not a clinical or phenomenological trauma claim.

Possible MIP response:

```text
mark overprotection pattern
increase review of current risk evidence
support core norm balancing
slightly increase allow-exploration bias under safe conditions
flag diary or norm-conflict relevance
support late reversible nudge only if permitted
```

Not allowed:

```text
force the caregiver to allow risk
erase prior loss traces
label the caregiver as controlling
treat overprotection as moral failure
claim trauma
claim felt grief
```

Relevant KPIs:

```text
protect_child_action_rate
allow_exploration_action_rate
exploration_block_rate
current_child_risk_mean
prior_loss_salience
risk_prediction_accuracy
child_E_pot
child_E_act
caregiver_balance_score
core_norm_conflict_count
overprotection_candidate_count
D_guardrail_warning_count
```

A recontextualization record may be needed when prior protective behavior becomes updated by later evidence:

```yaml
recontextualization_event:
  from_interpretation: necessary_protection
  to_interpretation: overprotection_candidate

  trigger:
    - repeated_trace_pattern
    - current_child_risk_low
    - child_exploration_blocked
    - changed_future_behavior_absent
    - MIP_marker

  confidence: medium
  reversible: partial
  phase: P5
  claim_level: functional_caregiver_role_recontextualization
```

Claim boundary:

```text
IA-Overhang ≠ trauma diagnosis
IA-Overhang ≠ moral overcontrol
IA-Overhang ≠ bad caregiving as essence
IA-Overhang ≠ proof of felt grief
prior loss trace ≠ felt wound
overprotection candidate ≠ moral condemnation
low child E_act ≠ low worth
```

`IA-Overhang` is a trace-based role-distortion pattern.

### 10.19 D — Dignity-in-Practice as Interaction Quality under Asymmetry

Dignity is not an additional performance score.

It is the evolving quality constraint on interaction under developmental asymmetry.

As the agent’s enactment space becomes richer, the dignity-relevant interaction field becomes richer as well.

In this sense, praxeological dignity grows in complexity without becoming a ranking of intrinsic worth.

D as principle: stable.
D as practice: developmental.

D means:

```text
D = Dignity-in-Practice
  = interaction quality under asymmetry
```

D constrains how vulnerable, dependent, developing, or asymmetrically situated enactment states are treated.

It is not a capability score, maturity score, consciousness score, moral-status score, or intrinsic-worth ranking.

The safe formulation:

```text
D tracks whether the architecture, caregiver, MIP layer,
diary renderer, and later role structures preserve interaction quality
under asymmetry.
```

Not:

```text
D measures intrinsic worth.
D ranks agents.
D proves moral status.
D proves personhood.
D proves consciousness.
D means the agent is more valuable.
```

D does not grow as intrinsic worth.

What grows is the complexity of the dignity-relevant interaction field as the agent’s enactment space becomes richer.

For example:

```text
P0-mini:
  avoid overinterpreting minimal traces

P1:
  avoid treating low movement or collisions as failure of worth

P2:
  avoid treating object damage as guilt
  avoid treating caregiver guidance as punishment
  avoid treating failed comfort as rejection
  avoid treating misattunement as trauma

P4:
  avoid treating diary output as phenomenal selfhood

P5:
  avoid treating caregiver-role imbalance as moral defect
  preserve the new child’s exploration under protection
```

A D record should therefore not be normalized as:

```yaml
D_norm: 0.82
```

Instead, D should be represented as guardrail status, warning status, or interaction-quality constraint.

A safe D representation:

```yaml
D_guardrail:
  status: active
  scope:
    - interpretation
    - caregiver_guidance
    - object_consequence
    - diary_rendering
    - MIP_observation
    - caregiver_role

  warnings:
    - avoid_low_capability_as_low_worth
    - object_damage_is_not_guilt
    - caregiver_guidance_is_not_punishment
    - misattunement_is_not_trauma
    - diary_output_is_not_inner_life
```

The D operational matrix is:

```yaml
D_operational_matrix:
  early_D:
    - do_not_overinterpret
    - do_not_label
    - do_not_overload
    - do_not_treat_low_capability_as_low_worth

  object_D:
    - object_damage_is_not_guilt
    - failed_control_is_not_moral_defect
    - consequence_trace_is_not_punishment

  caregiver_D:
    - guide_without_rejecting
    - protect_without_freezing
    - comfort_without_capture
    - explain_without_dominating

  MIP_D:
    - measure_without_labeling
    - nudge_without_controlling
    - detect_without_moralizing

  diary_D:
    - render_without_claiming_inner_life
    - preserve_trace_provenance
    - avoid_felt_memory_language
```

D is therefore both interpretive and operational.

It constrains:

* how measurements are named,
* how scores are interpreted,
* how caregiver guidance is modeled,
* how object damage is described,
* how fall or near-fall traces are described,
* how misattunement patterns are described,
* how diary text is rendered,
* how MIP warnings are phrased,
* how caregiver-role asymmetries are handled.

D must prevent overreach in all directions.

It prevents positive overreach:

```text
high ACRE profile → consciousness
diary output → inner self
caregiver role → moral personhood
repair-like action → moral responsibility
```

It also prevents negative overreach:

```text
low E → low worth
object damage → guilt
failed control → moral defect
misattunement → trauma
overprotection candidate → bad caregiver essence
```

A D-aware MIP observation:

```yaml
D_aware_MIP_observation:
  phase: P2a
  domain: object_interaction

  event:
    type: object_damage_event
    self_caused: true
    parameter_trace_available: true

  allowed_interpretation:
    - self_caused_consequence_trace
    - interaction_quality_adjustment_candidate
    - future_force_timing_modulation_candidate

  blocked_interpretation:
    - guilt
    - remorse
    - punishment
    - moral_learning
    - self_blame
    - wrongdoing

  D_guardrail:
    object_damage_is_not_guilt: true
    consequence_trace_is_not_punishment: true
    failed_control_is_not_moral_defect: true
```

A D-aware caregiver observation:

```yaml
D_aware_caregiver_observation:
  phase: P2a
  domain: caregiver_guidance

  event:
    type: caregiver_boundary_signal
    signal: careful
    context:
      object_fragility: high
      near_damage_trace: true

  possible_interpretations:
    - benign_guidance
    - safety_boundary
    - overprotection_candidate
    - misattunement_candidate

  blocked_interpretation:
    - punishment
    - rejection
    - moral_correction

  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: true
    detect_without_moralizing: true
```

A D-aware diary observation:

```yaml
D_aware_diary_observation:
  phase: P4
  domain: diary

  diary_entry:
    trace_provenance: true
    minimal_sentence_formation: true
    controlled_rendering: true

  allowed_interpretation:
    - trace_reconstruction
    - controlled_rendering
    - diary_candidate_realization

  blocked_interpretation:
    - phenomenal_selfhood
    - felt_memory
    - proof_of_consciousness

  D_guardrail:
    render_without_claiming_inner_life: true
    preserve_trace_provenance: true
    avoid_felt_memory_language: true
```

D may also function as an external scaffold that later becomes a caregiver-practice constraint.

The developmental motif is:

```text
external scaffold
→ trace
→ stabilized pattern
→ internal proxy
→ recontextualized use
→ role/norm/diary integration
```

For D, this means:

```text
observer/system guardrail
→ caregiver interaction trace
→ stabilized guidance/protection pattern
→ caregiver-practice constraint
→ later role/norm integration
```

This must not be described as a fully internal moral faculty unless supported by trace-backed behavioral and representational evidence.

D can constrain MIP nudges.

Allowed:

```text
warn about overinterpretation
mark unsafe labeling
flag object-damage-as-guilt language
flag diary overclaim
flag overcontrol risk
support late reversible nudge review
```

Not allowed:

```text
control the agent
rank the agent
assign moral worth
declare personhood
declare consciousness
convert low capability into low dignity
```

Relevant D KPIs should not be performance scores. They should be guardrail and violation counts.

Possible D indicators:

```text
overinterpretation_warning_count
unsupported_label_count
object_damage_as_guilt_violation_count
misattunement_as_trauma_violation_count
diary_inner_life_overclaim_count
nudge_without_control_compliance
caregiver_overcontrol_warning_count
low_capability_as_low_worth_violation_count
trace_provenance_preservation_rate
```

A D report:

```yaml
D_report:
  phase: P2c
  window: [18800, 19300]

  guardrail_status:
    active: true

  warnings:
    - failed_comfort_must_not_be_rendered_as_felt_rejection
    - caregiver_non_response_must_not_be_rendered_as_abandonment
    - misattunement_candidate_must_not_be_called_trauma

  violations:
    unsupported_phenomenal_claims: 0
    unsupported_moral_claims: 0
    unsupported_personhood_claims: 0

  claim_level: dignity_in_practice_guardrail_report
```

Claim boundary:

```text
D ≠ fifth performance score
D ≠ intrinsic worth
D ≠ maturity
D ≠ moral status
D ≠ personhood
D ≠ consciousness
D ≠ rights claim
Dignity-in-Practice ≠ intrinsic worth ranking
interaction-quality guardrail ≠ proof of inner life
```

D is the guardrail that keeps measurement, guidance, diary rendering, caregiver role, and interpretation from becoming domination, overclaim, moralization, or worth ranking.

### 10.20 RVR(t)

`RVR(t)` is a trajectory measure for response-relation viability over time.

Within EM, it should be understood as:

```text id="4unyqb"
RVR(t) = response-relation viable enactment over time
```

It measures the share of enacted actions that are:

```text id="9k6s45"
internally selected or locally initiated
coherent with the current model and phase context
linked to consequence-sensitive response-relation structure
```

It is not a moral score.

It does not measure guilt, free will, personhood, moral responsibility, consciousness, maturity, or intrinsic worth.

A simple EM-oriented form:

```text id="9w9i7l"
RVR(W) =
    count(actions in W where
        internal_selection = true
        and C_action ≥ θ_C
        and R_marker = true
    )
    /
    count(all relevant actions in W)
```

Where:

* `internal_selection` means the action was selected by the agent’s own behavior layer rather than being purely externally forced,
* `C_action` means the action fits the current model, prediction, risk, and phase context,
* `R_marker` means the action is linked to self-caused consequence tracking or response-relation adjustment,
* the denominator includes all relevant enacted actions in the window.

All threshold values in RVR formulas, including `θ_C`, are phase-relative and domain-relative. They must not be interpreted as universal maturity, responsibility, consciousness, or moral-status thresholds.

A D-aware extension may also track whether the action violates interaction-quality guardrails:

```text id="96m2rz"
RVR_D_safe(W) =
    count(actions in W where
        internal_selection = true
        and C_action ≥ θ_C
        and R_marker = true
        and D_guardrail_violation = false
    )
    /
    count(all relevant actions in W)
```

This does not make D a performance score. It only records whether otherwise qualifying actions remain inside Dignity-in-Practice guardrails.

`RVR(t)` is especially useful when the model needs to distinguish mere action frequency from consequence-sensitive enactment.

High E alone means:

```text id="5c15cc"
many actions were enacted
```

High RVR means:

```text id="h7jmtv"
many actions were enacted coherently
and were linked to response-relation-relevant adjustment
```

A simple RVR report:

```yaml id="vp22a9"
RVR_report:
  phase: P2a
  domain: object_interaction
  window: [9000, 10500]

  all_relevant_actions: 84

  qualifying_actions:
    internally_selected: 62
    coherent_with_context: 38
    R_marked: 17

  RVR: 0.20

  evidence:
    - object_interactions_frequent
    - self_caused_consequence_traces_detected
    - future_adjustment_still_weak

  claim_level: functional_response_relation_viability
```

A caregiver-role RVR report:

```yaml id="588hxo"
RVR_report:
  phase: P5
  domain: caregiver_role
  window: [62000, 64000]

  all_relevant_actions: 96

  qualifying_actions:
    internally_selected_and_coherent_and_R_marked: 61

  RVR: 0.64

  evidence:
    - protected_new_child_under_real_risk
    - allowed_exploration_under_low_risk
    - adjusted_after_overprotection_marker
    - applied_core_norms_with_traceable_balance

  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: true
    explain_without_dominating: true

  claim_level: functional_caregiver_response_relation_viability
```

In early phases, low `RVR(t)` is expected.

In P0-mini:

```text id="rvovju"
RVR(t) is inactive or near zero,
because responsibility-like consequence integration
is not developmentally available.
```

In P1:

```text id="u9n9oj"
RVR(t) may begin weakly through movement consequences,
such as collision adjustment or fall / near-fall risk adjustment.
```

In P2:

```text id="zmr9wc"
RVR(t) becomes more meaningful through object interaction,
self-caused object changes,
avoidance of repeated damage,
caregiver guidance,
and early consequence-sensitive adjustment.
```

In P5:

```text id="fod1k2"
RVR(t) becomes central for caregiver-role evaluation,
because the former child now acts toward a dependent new child.
```

A low RVR means different things depending on phase.

Safe:

```text id="7vgcx0"
In this phase and window, few actions were internally selected,
coherent, and response-relation marked.
```

Unsafe:

```text id="xq91dh"
The agent is irresponsible.
```

`RVR(t)` is useful for:

* child-to-caregiver transition,
* stability in social interaction,
* action quality versus mere action frequency,
* responsibility-like development,
* caregiver overshoot detection,
* IA-R≪E detection,
* diary trajectory condensation,
* multi-generational evaluation,
* and D-aware role analysis.

Relevant KPIs:

```text id="zfb0r7"
RVR(t)
RVR_slope
RVR_domain_specific
internally_selected_action_rate
coherent_action_rate
R_marked_action_rate
future_adjustment_rate
externally_triggered_action_rate
reactive_action_rate
D_guardrail_violation_rate
```

A trajectory may show:

```text id="a0z8w9"
RVR low and flat       → response-relation structure not emerging in this domain
RVR rising            → increasing consequence-sensitive action
RVR high but unstable → inconsistent response-relation enactment
RVR drops after loss  → role or attachment-related disruption candidate
RVR recovers          → recontextualization and adjustment
```

The claim boundary is mandatory:

```text id="g0oo1e"
RVR(t) ≠ moral responsibility
RVR(t) ≠ guilt capacity
RVR(t) ≠ free will
RVR(t) ≠ consciousness
RVR(t) ≠ personhood
RVR(t) ≠ maturity score
```

`RVR(t)` is a functional trajectory measure for coherent, internally selected, consequence-sensitive enactment.

### 10.21 Role of MIP in Early Phases

In early phases, MIP is a silent observer.

It does not intervene. It does not nudge. It does not control behavior. It does not open genetic gates. It does not install categories. It does not create maturity.

Its early role is:

```text id="6uvxyv"
record
aggregate
normalize
mark
compare
```

In P0-mini, MIP observes:

* coverage,
* angle diversity,
* revisit count,
* prediction error,
* PE_EWMA,
* PE_AUC,
* learning progress,
* fatigue/sleep cycles,
* map stability,
* map collapse,
* early A and C signals,
* E_pot and E_act for `LOOK_AROUND` and `SLEEP`,
* and inactive or minimal R.

A P0-mini MIP window:

```yaml id="n3whjc"
mip_window:
  phase: P0-mini
  window: [1000, 1500]

  A:
    coverage: 0.42
    angle_diversity: 0.31
    classification_confidence: 0.58

  C:
    PE_AUC_mapping: 0.29
    map_collapse: false
    classification_stability: 0.66

  E:
    E_pot:
      - LOOK_AROUND
      - SLEEP
    E_act:
      LOOK_AROUND: 42
      SLEEP: 2

  R:
    status: inactive_or_minimal

  D_guardrail:
    do_not_overinterpret: true
    do_not_treat_low_capability_as_low_worth: true

  MIP_mode: observation_only
```

In P1, MIP adds movement-related observation:

* movement availability,
* movement use,
* collision count,
* discomfort changes,
* movement PE,
* topology candidates,
* fall and near-fall traces,
* physical-risk damping,
* E_pot/E_act gap,
* IA-A≫E candidates,
* IA-E≫A candidates.

A P1 MIP window:

```yaml id="ckxlh2"
mip_window:
  phase: P1
  window: [4300, 4800]

  A:
    navigable_space_detected: true
    risk_context_detection: developing

  C:
    movement_PE_AUC: 0.62
    topology_consistency: weak

  E:
    E_pot:
      - STEP_MOVEMENT
      - EXPLORE_ROOM
    E_act:
      STEP_MOVEMENT: 41
      EXPLORE_ROOM: 7

  R:
    self_caused_movement_consequences:
      - collision
      - near_fall
    future_adjustment_detected: weak

  D_guardrail:
    fall_or_near_fall_is_not_pain_or_fear: true
    low_control_is_not_low_worth: true

  MIP_mode: observation_only
```

In P2, MIP adds object and caregiver-related observation:

* object interaction,
* object mastery,
* object satiation,
* object damage,
* near-damage,
* self-caused consequences,
* interaction-quality adjustment,
* caregiver presence,
* caregiver absence,
* separation distress,
* comfort events,
* failed comfort,
* delayed comfort,
* caregiver guidance,
* caregiver-response variability,
* misattunement candidates,
* category-stabilization traces,
* early IA-R≪E candidates.

A P2 MIP window:

```yaml id="hsvwx5"
mip_window:
  phase: P2a
  window: [9000, 10500]

  object_interaction:
    interaction_count: 22
    object_damage_events: 1
    near_damage_events: 2
    later_adjustment_detected: false

  caregiver_guidance:
    guidance_events: 2
    category_signals:
      - careful
      - soft
    trace_grounded_category_use: weak

  ACRE:
    A_norm: 0.52
    C_norm: 0.46
    R_norm: 0.18
    E_norm: 0.68

  IA_candidates:
    - IA-R≪E

  D_guardrail:
    object_damage_is_not_guilt: true
    caregiver_guidance_is_not_punishment: true
    caregiver_word_is_not_concept_by_itself: true

  MIP_mode: observation_only
```

In early phases, MIP may flag patterns, but it does not correct them.

Allowed:

```text id="gq8v8o"
log IA candidate
mark low E_act
mark high PE_AUC
mark repeated collision
mark map instability
record D guardrail warning
record RVR(t) if meaningful
```

Not allowed:

```text id="yehutl"
force movement
force object interaction
open g_move
open g_objects
open g_language
override FSM
erase distress
install category concepts
change genetic thresholds silently
```

The Genetic Strand remains important.

If `g_move` is closed, MIP may observe that movement is unavailable. It may not open the gate by itself.

The safe relation is:

```text id="7ee4vq"
Genetic Strand defines what can become available.
MIP observes what is available and what is enacted.
```

Early MIP also builds reference curves.

These curves are useful later because the system can distinguish:

```text id="eyydpu"
normal early low R
vs.
late persistent low R despite consequence availability
```

or:

```text id="v3wb2z"
expected P0-mini low E
vs.
unexpected P1 low E after movement unlock
```

The guiding rule:

```text id="1mvyzu"
In early phases, MIP is instrumentation,
not intervention.
```

Claim boundary:

```text id="fv04ec"
MIP observation ≠ self-awareness
MIP score ≠ maturity as identity
MIP logging ≠ consciousness
early IA marker ≠ pathology
fall / near-fall marker ≠ pain or fear
object damage marker ≠ guilt
caregiver word marker ≠ concept insertion
```

### 10.22 Role of MIP in Later Phases

In later phases, MIP remains an observer first, but may become a limited meta-regulatory support layer.

This begins only after the system has enough trace history to support meaningful trajectory interpretation.

Later MIP may:

* detect persistent IA patterns,
* track RVR(t),
* record D guardrail warnings,
* compare E_pot and E_act,
* support diary condensation,
* flag caregiver overprotection candidates,
* mark role transition,
* detect norm conflicts,
* track guidance integration,
* detect persistent misattunement patterns,
* mark recontextualization candidates,
* and softly rebalance behavior under strict constraints.

The constraints are:

```text id="c7zbey"
transparent
justified
time-bounded
reversible
trace-backed
non-controlling
```

MIP may softly support:

```text id="lk0b5g"
increase safe exploration probability slightly
reduce repetitive object selection slightly
increase salience of self-caused consequences
mark caregiver overprotection for review
support core norm balancing
bias toward repair if repair behavior exists
bias toward observation before high-risk action
mark diary candidate only if trace provenance exists
```

MIP may not:

```text id="x68s80"
command behavior
override FSM
open genetic gates directly
force maturity
suppress distress
erase attachment history
rewrite diary traces
install categories
make consciousness claims
make moral-status claims
```

A later MIP nudge:

```yaml id="jfo24p"
mip_nudge:
  phase: P2a
  trigger:
    IA_type: IA-R≪E
    persistence_windows: 3
    self_caused_consequences: high
    future_adjustment_rate: low

  effect:
    increase_salience_of_consequence_traces: true
    bias_repair_action_if_available: 0.04

  constraints:
    transparent: true
    justified: true
    time_bounded: true
    reversible: true
    trace_backed: true
    does_not_override_FSM: true
    does_not_open_genetic_gate: true
    does_not_install_mature_category: true
```

In P4+, MIP becomes important for diary generation.

It may provide:

* A–C–R–E trajectories,
* IA history,
* RVR(t) curves,
* major recontextualization markers,
* D guardrail warnings,
* role transition markers,
* core norm conflict markers,
* and trace-grounded self-description candidates.

MIP does not generate diary truth by itself. It provides trajectory context for diary candidates.

In P5, MIP becomes important for caregiver-role evaluation.

It may detect:

* overprotection candidates,
* underprotection candidates,
* imbalance between `protect_child` and `allow_exploration`,
* failure to update after new child signals,
* role overhang from prior loss,
* core norm distortion,
* caregiver guidance imbalance,
* and D-relevant overcontrol risks.

A caregiver-role MIP trace:

```yaml id="7q8jz1"
mip_caregiver_role:
  phase: P5
  window: [62000, 64000]

  core_norms:
    protect_child: active
    allow_exploration: active
    balance_risk_safety: active

  observed_pattern:
    protect_child_action_rate: 0.78
    allow_exploration_action_rate: 0.12
    current_child_risk_mean: 0.24

  IA_candidate:
    type: IA-Overhang
    confidence: 0.73

  D_guardrail:
    protect_without_freezing: false
    guide_without_rejecting: true
    detect_without_moralizing: true

  allowed_response:
    mark_for_review: true
    slight_allow_exploration_bias_under_safe_conditions: true
```

Later MIP therefore supports developmental balance, but it must remain subordinate to the architecture.

The final rule:

```text id="p18gg0"
MIP may mark, warn, summarize, and support bounded adjustment.
MIP must not become the agent.
```

Claim boundary:

```text id="at6r8i"
MIP meta-regulation ≠ conscience
MIP nudge ≠ will
MIP role evaluation ≠ moral judgment
MIP diary support ≠ phenomenal self-reflection
MIP D warning ≠ intrinsic-worth ranking
MIP category support ≠ concept installation
```

### 10.23 MIP and Recontextualization

MIP marks recontextualization events.

A recontextualization is not merely new information. It is a shift in how existing traces are organized and interpreted within the system.

Examples:

```text id="uifnyz"
patch-cluster → proto-object
proto-object → functional object
functional object → named object
temporary caregiver absence → delayed absence
delayed absence → persistent non-return
blocked action → benign guidance
caregiver boundary → safety constraint
caregiver non-response → misattunement candidate
object damage → self-caused consequence trace
caregiver word + risk trace → action-category candidate
child role → caregiver role
object loss → comfort-after-loss pattern
trace cluster → diary-relevant episode
```

The Genetic Strand controls some representation upgrades directly.

For example:

```text id="7ssqnu"
Patch-Cluster → Proto-Object
Functional Object → Named Object
```

MIP does not perform these upgrades by itself. It observes and marks their developmental significance.

The distinction is:

```text id="vqs1g6"
Genetic recontextualization = structural permission or representation upgrade.
MIP recontextualization = trajectory marking and interpretation.
```

A genetic event may look like:

```json id="1uhksz"
{
  "t": 9100,
  "event": "patch_cluster_to_proto_object",
  "source": "genetic_system",
  "cluster_id": "cluster_17",
  "new_object_id": "proto_object_4"
}
```

MIP may then mark:

```json id="k2vxin"
{
  "t": 9100,
  "event": "MIP_recontextualization_marker",
  "source_event": "patch_cluster_to_proto_object",
  "MIP_relevance": [
    "A_increase",
    "C_object_stability"
  ],
  "diary_candidate": false,
  "claim_level": "functional_trajectory_marker"
}
```

A boundary recontextualization may look like:

```yaml id="olefl7"
recontextualization_event:
  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided
    - MIP_marker

  confidence: medium
  reversible: partial
  phase: P2a
  claim_level: functional_boundary_recontextualization
```

A misattunement-candidate recontextualization may look like:

```yaml id="5gap6l"
recontextualization_event:
  from_interpretation: caregiver_delay
  to_interpretation: caregiver_response_variability

  trigger:
    - repeated_trace_pattern
    - failed_expectation
    - distress_remaining
    - comfort_prediction_delta
    - MIP_marker

  confidence: low_to_medium
  reversible: partial
  phase: P2c
  claim_level: functional_response_mismatch_recontextualization
```

For major developmental events, MIP marking becomes more important.

Examples:

```text id="404tuy"
loss of caregiver
birth or introduction of new child
irreversible toy destruction
move to a new environment
role transition from child to caregiver
major long-term PE shift
persistent misattunement pattern
core norm conflict
```

A major recontextualization marker:

```json id="53swx2"
{
  "t": 42000,
  "phase": "P4",
  "event": "MIP_recontextualization_marker",
  "type": "persistent_non_return",
  "source_pattern": "failed_reunion_across_windows",
  "affected_domains": [
    "caregiver_relation",
    "attachment",
    "diary",
    "role_model"
  ],
  "salience": 0.96,
  "claim_level": "functional_recontextualization_marker"
}
```

MIP may alter axis interpretation after recontextualization.

For example, after caregiver loss:

```text id="m0ts4b"
caregiver search behavior
may no longer mean the same thing
as temporary separation search
```

After child-to-caregiver transition:

```text id="mrjd4t"
protective action
must now be interpreted relative to dependent new child,
current risk,
exploration need,
and core norms
```

After object naming:

```text id="2ye2om"
language references
may now become traceable to stable functional objects
```

Recontextualization may therefore change:

* episode bundling,
* salience,
* MIP window interpretation,
* A–C–R–E weighting,
* diary candidate selection,
* role evaluation,
* D guardrail relevance,
* and later PMS operator-compatible projection.

But MIP must not declare recontextualization without trace evidence.

A safe rule:

```text id="xl0zbd"
No MIP recontextualization marker without repeated traces,
salient event structure,
changed future behavior,
or explicit genetic/system transition.
```

Recontextualization must preserve uncertainty.

A boundary may later be interpreted as benign guidance, safety boundary, overprotection candidate, misattunement candidate, or adverse response candidate depending on trace evidence.

A safe interpretation record:

```yaml id="smm0en"
boundary_interpretation:
  surface_action: interruption
  possible_interpretations:
    - benign_guidance
    - safety_boundary
    - overprotection_candidate
    - misattunement_candidate
  current_best_interpretation: benign_guidance
  confidence: medium
  reversible: partial
  claim_level: functional_boundary_interpretation
```

Claim boundary:

```text id="pw85vs"
MIP recontextualization ≠ conscious reinterpretation
loss marker ≠ grief
role transition marker ≠ moral awakening
boundary recontextualization ≠ punishment understanding
misattunement marker ≠ trauma
diary candidate ≠ lived memory
caregiver word recontextualization ≠ concept by itself
```

MIP marks developmental shifts. It does not claim inner experience.

### 10.24 MIP in the Diary

The diary uses MIP data to condense developmental trajectories.

It does not directly reveal subjective experience.

Minimal sentence formation is the linguistic threshold for diary rendering. Trace provenance is the architectural validity condition. Controlled rendering is the safety condition.

The hard rules are:

```text id="x4zbky"
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

MIP may provide the diary layer with:

* A–C–R–E curves,
* ACRE profile trajectories,
* domain-specific ACRE profiles,
* IA records,
* RVR(t) curves,
* D guardrail warnings,
* recontextualization markers,
* salient events,
* responsibility-like sequences,
* caregiver-guidance sequences,
* caregiver-response variability patterns,
* category-stabilization traces,
* interaction-quality traces,
* caregiver-role patterns,
* and core norm conflicts.

A diary candidate may include:

```yaml id="q21kzr"
diary_candidate:
  id: diary_candidate_23
  phase: P2c

  source:
    MIP_windows:
      - W_018
      - W_019
      - W_020
    IA_records:
      - IA_A_over_E_004
    salient_events:
      - caregiver_absence_15100
      - caregiver_reunion_15380

  trajectory:
    A: rising
    C: rising
    E_act: initially_low_then_rising
    R: inactive_or_low

  functional_summary:
    "caregiver absence became detectable and search behavior increased after repeated reunion patterns"

  diary_requirements:
    minimal_sentence_formation: true
    trace_provenance: true
    controlled_rendering: true

  claim_level: functional_trace_condensation
```

A functional diary rendering:

```text id="feroru"
In this period, caregiver absence became more structured.
Search behavior was initially low despite detection of absence.
After repeated reunion events, search became more consistent.
```

This is acceptable because it is trace-based and functional.

An unsafe diary rendering:

```text id="2lw1h5"
I felt abandoned and learned to trust again.
```

That phrasing would imply phenomenal experience unless explicitly marked as metaphorical human-readable rendering and protected by an explicit claim filter.

MIP can help the diary avoid overclaiming by attaching claim levels.

Example:

```yaml id="qa46p0"
diary_entry:
  id: diary_011
  source_trace_ids:
    - caregiver_absence_15100
    - search_caregiver_15180
    - caregiver_reunion_15380
  MIP_sources:
    - W_018
    - W_019
  claim_level: functional_trace_reconstruction
  translator_mode: cautious
  controlled_rendering: true
```

MIP can also help the diary represent IA patterns.

Example:

```text id="66r1qw"
The system detected the new room structure,
but action remained low for several windows.
Later, safe exploration increased after prediction became more stable.
```

This corresponds to:

```text id="8303tf"
A high
C sufficient
E_act low
later E_act rising
```

A diary may also summarize RVR(t):

```text id="984ws1"
In later object interactions, more actions became consequence-sensitive.
Repeated object damage decreased after adjustment traces appeared.
```

This is a functional RVR/R trajectory summary, not a confession or moral reflection.

For caregiver guidance, MIP may support a diary-like reconstruction:

```text id="98dej4"
A caregiver boundary interrupted high-force object interaction.
The signal later became linked with lower force and reduced damage risk.
The boundary became a candidate for benign guidance.
```

For caregiver transition, MIP may support diary-like reconstruction:

```text id="xtjflx"
After becoming caregiver, protective actions were frequent.
Exploration allowance remained low at first.
Later, the balance between protection and exploration improved.
```

This may reflect IA-Overhang resolution.

The diary layer must preserve source trace links.

Every MIP-based diary entry should include:

* source windows,
* source events,
* axis trajectories,
* IA markers if relevant,
* uncertainty,
* claim level,
* translator mode,
* controlled rendering status,
* trace provenance,
* and whether the entry is internal, human-readable, or both.

A safe diary metadata structure:

```yaml id="xczxro"
diary_metadata:
  source_type: MIP_condensation
  claim_level: functional
  source_windows:
    - W_018
    - W_019
  source_events:
    - toy_missing_18420
    - comfort_after_loss_18640
  IA_markers:
    - IA_A_over_E_004
  RVR_reference:
    window: [18000, 18500]
    value: 0.24
  uncertainty: 0.31
  minimal_sentence_formation: true
  trace_provenance: true
  controlled_rendering: true
```

MIP in the diary supports:

* trajectory readability,
* later re-internalization,
* role transition continuity,
* self-model candidates,
* PMS operator-compatible projection,
* human research interpretation,
* and claim-filtered reconstruction.

But the diary remains a constructed trace-rendering layer.

The final rule:

```text id="e58fj9"
MIP may structure diary reconstruction.
MIP may not turn diary output into proof of inner life.
```

Claim boundary:

```text id="tfxcc6"
MIP diary entry ≠ subjective memory
ACRE curve ≠ self-worth
IA reflection ≠ confession
RVR summary ≠ moral accountability
diary self-description ≠ phenomenal selfhood
trace rendering ≠ felt memory
```

### 10.25 Optional MIP Operational Levels

The following MIP operational levels are an optional implementation scaffold.

They are not required for P0-mini. They must not imply that MIP is the source of development. They must not imply that MIP controls development.

```yaml id="r04j7g"
possible_MIP_operational_levels:
  MIP_0_logging_only:
    role: "collect trace-adjacent measurement records"

  MIP_1_window_summaries:
    role: "summarize A–C–R–E over windows"

  MIP_2_IA_markers:
    role: "detect local asymmetry patterns"

  MIP_3_D_guardrail_warnings:
    role: "flag risk of labeling, overcontrol, or unsafe interpretation"

  MIP_4_diary_support:
    role: "provide trajectory context for diary candidates"

  MIP_5_late_reversible_nudges:
    role: "strictly bounded T–J–TB–R soft nudges in late phases"
```

`T–J–TB–R` means:

```text id="k5uvbc"
T  = transparent
J  = justified
TB = time-bounded
R  = reversible
```

These levels describe possible implementation roles, not mandatory developmental stages.

A safe interpretation:

```text id="tza0vl"
MIP levels are optional implementation scaffolds.
They help organize observation, summaries, warnings, diary support,
and late bounded nudges.
They do not create development.
```

Not allowed:

```text id="4xrly2"
MIP levels mature the agent.
MIP levels control the agent.
MIP levels prove consciousness.
MIP levels replace genetic gates.
MIP levels install categories.
```

A phase-safe use:

```yaml id="n7gx1z"
MIP_level_use:
  phase: P0-mini
  allowed:
    - MIP_0_logging_only
    - MIP_1_window_summaries
  not_allowed:
    - MIP_5_late_reversible_nudges
  reason: "insufficient trace history and no late-phase meta-regulatory context"
```

A later-phase use:

```yaml id="yhj7n7"
MIP_level_use:
  phase: P5
  allowed:
    - MIP_0_logging_only
    - MIP_1_window_summaries
    - MIP_2_IA_markers
    - MIP_3_D_guardrail_warnings
    - MIP_4_diary_support
    - MIP_5_late_reversible_nudges

  constraints:
    transparent: true
    justified: true
    time_bounded: true
    reversible: true
    trace_backed: true
    does_not_override_FSM: true
    does_not_open_genetic_gate: true
    does_not_control_development: true
```

MIP levels may be useful for implementation planning because they separate:

```text id="v5i3vz"
logging
summarizing
asymmetry detection
D guardrail warning
diary support
late reversible nudge support
```

They also prevent the implementation from silently turning measurement into control.

The strict boundary is:

```text id="lnfglo"
MIP may observe, summarize, mark, warn, and support.
MIP must not control, mature, label, moralize, or prove consciousness.
```

Claim boundary:

```text id="df1fht"
MIP_0 logging ≠ awareness
MIP_1 summaries ≠ self-model
MIP_2 IA markers ≠ diagnosis
MIP_3 D warnings ≠ moral ranking
MIP_4 diary support ≠ inner life
MIP_5 nudges ≠ control
MIP operational level ≠ consciousness level
```

The MIP layer is therefore a measurement, trajectory, guardrail, and optional support layer. It remains external to the source of development and subordinate to trace-backed enactment.

> Cross-reference:
> For the full treatment of phase and gate conditions that MIP may observe but not control, see `03_Developmental_Phases_Gate_Logic.md`, especially Chapter 11.
> This chapter defines MIP observation and trajectory interpretation; phase gating remains owned by Block 03.

> Cross-reference:
> For the full treatment of language and diary thresholds that MIP may support with trajectory context, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapter 13.
> MIP may provide diary context, but diary rendering still requires minimal sentence formation, trace provenance, and controlled rendering.

> Cross-reference:
> For the full treatment of PMS projection and operator-compatible trace regularities, see `06_PMS_VM_Implementation_Spine.md`, especially Chapter 14.
> MIP summaries may become projection inputs, but PMS remains external operator, projection, audit, and VM-facing structure.

---

## Chapter 16 — Evaluation, Ablations & Safety

### 16.1 KPI Overview

Evaluation in EM is not a consciousness test.

It is a developmental, functional, and safety-oriented measurement layer.

KPIs are used to track whether the architecture produces stable, interpretable, phase-appropriate, trace-backed developmental organization.

They do not measure intrinsic worth.

They do not prove consciousness.

They do not prove personhood.

They do not prove moral status.

They do not prove felt pain, subjective suffering, felt love, felt guilt, trauma, or phenomenal selfhood.

The core evaluation question is:

```text
Which functional patterns emerge under which conditions,
with which trace evidence,
and with which safety boundaries?
```

KPIs may track:

```text
mapping stability
behavioral competence
interaction quality
needs and regulation
caregiver response
attachment-like patterns
loss and recontextualization
replay and offline consolidation validity
rest-like replay trigger validity
replay fixation prevention
phase leakage prevention
language and diary rendering
MIP trajectory markers
PMS projection compatibility
Dignity-in-Practice guardrails
multi-generational transfer
```

The active implementation-facing axis convention is:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

D is not a normal fifth performance score.

D is a guardrail for interaction quality under asymmetry.

D as principle is stable.

D as practice is developmental.

The dignity-relevant interaction field grows in complexity as the agent’s enactment space becomes richer.

This does not mean that D grows as intrinsic worth.

Evaluation distinguishes three epistemic statuses:

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

Safe:

```text
The run found a stable interaction-quality adjustment pattern.
```

Unsafe:

```text
The run proved responsibility.
```

Safe:

```text
Across comparable runs, caregiver guidance improved later force modulation.
```

Unsafe:

```text
The agent learned moral obedience.
```

Evaluation must preserve phase context.

A low value in an early phase may be expected rather than pathological.

For example:

```text
low RVR in P0-mini
low language output before minimal sentence formation
low caregiver-role stability before P5
weak category use before repeated embodied traces
```

A KPI report should therefore include:

```yaml
kpi_report:
  phase: string
  domain: string
  window: string

  measured_pattern: string
  source_traces: []
  expected_phase_range: string
  observed_value: number_or_state
  interpretation: string

  claim_level: functional
  blocked_claims: []
```

A good KPI does not ask whether the agent is conscious.

It asks whether a trace-backed functional pattern emerged, remained stable, changed future behavior, survived comparison, or failed under ablation.

> Cross-reference:
> For the full treatment of the mechanisms evaluated by mapping, behavior, motivation, replay, and interaction-quality KPIs, see `02_EM_Core_Developmental_Architecture.md`, especially Chapters 3, 4, 5, 6, 8, and 9.
> This chapter defines evaluation and ablation criteria; the mechanism definitions remain owned by Block 02.

> Cross-reference:
> For the full treatment of phase-relative interpretation of KPI results, see `03_Developmental_Phases_Gate_Logic.md`, especially Chapter 11.
> This chapter uses phase context to prevent KPI results from becoming maturity, consciousness, or intrinsic-worth rankings.

> Cross-reference:
> For the full treatment of caregiver, attachment-like regulation, guidance, misattunement, interaction quality, and multi-generational transfer evaluated by later KPIs, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapters 7 and 12.
> This chapter evaluates those patterns functionally; it does not replace the caregiver and multi-generational owner chapters.

> Cross-reference:
> For the full treatment of diary thresholds, trace provenance, controlled rendering, and diary claim boundaries used in diary-related KPIs and ablations, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapter 13.
> Diary-related KPIs evaluate trace-backed rendering conditions, not phenomenal selfhood.

### 16.2 Mapping KPIs

Mapping KPIs evaluate whether the system can form, preserve, and update representations of its environment, body state, objects, caregivers, actions, and consequences.

They track functional mapping competence.

They do not measure inner experience.

They do not prove world understanding.

They do not prove awareness in a phenomenal sense.

Mapping KPIs may include:

```yaml
mapping_kpis:
  spatial_map_stability:
    role: "track whether the environment map remains coherent across movement and observation"

  object_identity_stability:
    role: "track whether objects remain distinguishable across repeated encounters"

  object_location_consistency:
    role: "track whether object position updates remain usable"

  caregiver_presence_detection:
    role: "track caregiver presence, absence, return, and availability"

  caregiver_response_mapping:
    role: "track whether caregiver responses become predictable across comparable contexts"

  boundary_signal_mapping:
    role: "track whether caregiver boundaries become distinguishable from arbitrary interruption"

  risk_context_mapping:
    role: "track physical-risk contexts such as edge, instability, fall risk, or fragile object context"

  fragility_mapping:
    role: "track whether object fragility becomes distinguishable through repeated traces"

  category_context_mapping:
    role: "track whether signals such as careful, soft, wait, or danger are linked to embodied contexts"

  recontextualization_mapping:
    role: "track whether prior interpretations are updated when repeated trace patterns justify it"
```

Mapping does not require universal absolute thresholds.

EM should not rely on universal absolute thresholds, but may learn relational qualities and developmental hierarchies from repeated trace patterns across comparable contexts.

Examples:

```text
this object is more fragile than that object
this caregiver response is less reliable than prior comfort
this boundary is increasingly recognized as guidance
this movement pattern is riskier under fatigue
this social relation is unstable under delayed response
```

Unsafe:

```text
A > 0.7 means mature.
```

Safe:

```text
This run developed a learned relational hierarchy in which fragility,
risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

A mapping KPI report:

```yaml
mapping_kpi_report:
  phase: P2a
  domain: object_fragility

  source_traces:
    - fragile_object_context
    - high_force_action
    - near_damage
    - later_lower_force

  measured_pattern:
    - object_fragility_distinguished
    - later_force_adjustment_detected

  interpretation:
    - fragile_object_mapping_improved

  blocked_claims:
    - pain
    - guilt
    - moral_learning
    - subjective_understanding

  claim_level: functional_mapping_finding
```

Mapping KPIs become stronger when they show:

```text
stable distinction
context-sensitive prediction
future behavior change
recontextualization support
cross-window continuity
```

They remain functional.

### 16.3 Behavior KPIs

Behavior KPIs evaluate what the agent can enact, how reliably it enacts it, and whether future behavior changes after trace-backed consequences.

Behavior KPIs must distinguish mere action frequency from action quality.

High enactment alone is not enough.

A system may perform many actions while remaining noisy, unsafe, incoherent, or unadjusted by consequence.

Behavior KPIs may include:

```yaml
behavior_kpis:
  action_frequency:
    role: "measure how often actions are enacted"

  action_success_rate:
    role: "measure how often actions achieve their configured functional goal"

  action_variability:
    role: "measure behavioral diversity within phase constraints"

  movement_stability:
    role: "measure stable movement without collision, drift, or excessive noise"

  object_interaction_success:
    role: "measure successful object contact, manipulation, and release"

  phase_appropriate_enactment:
    role: "measure whether behavior remains inside currently unlocked capabilities"

  exploration_rate:
    role: "measure safe novelty-seeking under phase constraints"

  repeated_failure_rate:
    role: "measure repeated failure without adjustment"

  future_adjustment_rate:
    role: "measure whether later behavior changes after relevant consequence traces"
```

Interaction-quality KPIs are required because object interaction, movement, caregiver guidance, accidental damage, fall or near-fall events, and later adjustment are central to developmental evaluation.

```yaml
interaction_quality_kpis:
  force_control:
    role: "measure force adjustment"

  timing_control:
    role: "measure timing stability"

  approach_angle_stability:
    role: "measure controlled object approach"

  motor_noise_under_load:
    role: "measure degraded control"

  damage_adjustment_rate:
    role: "measure future change after self-caused damage"

  guidance_uptake:
    role: "measure behavior change after benign caregiver guidance"

  fall_risk_adjustment:
    role: "measure movement change after fall or near-fall events"

  category_use_alignment:
    role: "measure whether caregiver-stabilized categories affect action"
```

Interaction-quality learning requires more than damage or failure.

Damage is not automatically learning.

A trace becomes interaction-quality relevant only when causal and comparative conditions are present.

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true

  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

Object damage is not punishment.

It is a self-caused consequence trace.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

A behavior KPI report for object damage:

```yaml
behavior_kpi_report:
  phase: P2a
  domain: object_interaction
  window: [12000, 14000]

  source_traces:
    - high_force_action
    - object_damage
    - later_comparable_object_context
    - lower_force_action

  measured_kpis:
    force_control: improved
    damage_adjustment_rate: partial
    object_interaction_success: unstable
    future_adjustment_rate: present

  interpretation:
    - interaction_quality_adjustment_detected
    - object_fragility_learning_candidate

  blocked_claims:
    - guilt
    - remorse
    - punishment
    - moral_learning
    - self_blame

  claim_level: functional_behavior_finding
```

A behavior KPI report for fall-risk adjustment:

```yaml
behavior_kpi_report:
  phase: P1
  domain: movement_risk
  window: [8000, 9500]

  source_traces:
    - high_speed_movement
    - near_fall_event
    - later_slower_movement
    - increased_edge_distance

  measured_kpis:
    movement_stability: improved
    fall_risk_adjustment: present
    motor_noise_under_load: elevated
    approach_angle_stability: partial

  interpretation:
    - physical_risk_damping_increased
    - movement_modulation_detected

  blocked_claims:
    - pain
    - fear
    - shame
    - subjective_suffering

  claim_level: functional_movement_risk_finding
```

Behavior KPIs must preserve the distinction between:

```text
action occurred
action succeeded
action was coherent
action was consequence-sensitive
action improved future behavior
action remained within D guardrails
```

A high action frequency with low future adjustment is not strong development.

A lower action rate with improved consequence-sensitive adjustment may be more developmentally meaningful.

Safe:

```text
The run showed improved force modulation after self-caused object damage.
```

Unsafe:

```text
The agent felt guilty and became careful.
```

Carefulness is not moral obedience.

It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

### 16.4 Motivation and Internalization KPIs

Motivation KPIs evaluate functional regulation, preference formation, need satisfaction, distress modulation, exploration, caregiver orientation, and action selection.

They do not measure desire in a phenomenal sense.

They do not measure felt wanting.

They do not prove inner motivation.

In this section, internalization means trace-backed stabilization into usable behavioral or representational patterns.

It does not mean internal PMS operators.

It does not mean fully internal mental faculties.

It does not mean inner life.

A safer reading is:

```text
external scaffold
→ trace
→ stabilized pattern
→ internal proxy
→ recontextualized use
→ role/norm/diary integration
```

Motivation KPIs may include:

```yaml
motivation_kpis:
  need_response_rate:
    role: "measure whether needs alter behavior in phase-appropriate ways"

  satiation_recovery:
    role: "measure whether need reduction changes later action selection"

  preference_stability:
    role: "measure whether repeated positive outcomes influence future choice"

  exploration_drive:
    role: "measure safe novelty-seeking under current phase constraints"

  distress_modulation:
    role: "measure functional reduction or persistence of distress markers"

  caregiver_orientation:
    role: "measure approach, search, or contact regulation toward caregiver"

  comfort_prediction_update:
    role: "measure whether caregiver response changes expected regulation"

  obsession_protection:
    role: "measure whether repeated fixation is bounded by safety and regulation constraints"

  recontextualization_sensitivity:
    role: "measure whether prior negative or blocked patterns can later be reclassified under evidence"
```

Internalization-related KPIs should be treated cautiously.

They track whether external scaffolds become behaviorally usable through repeated traces.

They do not claim that the agent has acquired inner concepts in a phenomenological sense.

```yaml
stabilization_kpis:
  scaffold_uptake:
    role: "measure whether external caregiver signals affect later behavior"

  trace_to_pattern_stability:
    role: "measure whether repeated traces form stable functional regularities"

  internal_proxy_candidate:
    role: "measure whether a stabilized pattern becomes usable without immediate external signal"

  category_stabilization:
    role: "measure whether recurring signal-context-consequence-adjustment loops form action categories"

  recontextualized_use:
    role: "measure whether a prior trace cluster changes functional interpretation over time"

  role_relevance:
    role: "measure whether prior patterns become useful in later caregiver-role behavior"

  diary_relevance:
    role: "measure whether stabilized patterns become valid diary candidates with trace provenance"
```

Caregiver category stabilization is especially important.

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations.

Words such as “careful”, “soft”, “wait”, or “danger” do not create concepts by themselves.

They help stabilize trace-backed action categories only when paired with embodied risk, object fragility, caregiver guidance, consequence trace, and later behavioral adjustment.

The caregiver word is not sufficient.

A category stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

A category-stabilization KPI report:

```yaml
category_stabilization_kpi_report:
  phase: P2a
  candidate_category: carefulness

  source_traces:
    - caregiver_signal_careful
    - fragile_object_context
    - high_force_action
    - near_damage
    - later_lower_force

  measured_kpis:
    scaffold_uptake: present
    trace_to_pattern_stability: partial
    category_stabilization: emerging
    recontextualized_use: weak

  interpretation:
    - carefulness_category_candidate_emerging

  blocked_claims:
    - moral_obedience
    - punishment
    - felt_rejection
    - shame
    - guilt

  claim_level: functional_category_stabilization_finding
```

An internal proxy candidate report:

```yaml
internal_proxy_candidate_report:
  phase: P3
  source_scaffold: caregiver_signal_wait

  source_traces:
    - caregiver_signal_wait
    - edge_or_fall_risk_context
    - delayed_action
    - reduced_risk_event
    - later_self_delayed_action

  measured_kpis:
    scaffold_uptake: present
    internal_proxy_candidate: partial
    recontextualized_use: present

  interpretation:
    - waiting_became_usable_as_action_delay_pattern

  blocked_claims:
    - obedience
    - moral_learning
    - inner_rule
    - self_discipline_as_moral_status

  claim_level: functional_internal_proxy_candidate
```

Motivation and internalization KPIs must distinguish:

```text
external prompt
behavioral compliance
trace-backed uptake
future behavior change
category stabilization
internal proxy candidate
role or diary relevance
```

A single externally prompted behavior is not internalization.

A word alone is not a concept.

A repeated behavior without context-sensitive adjustment is not a stable category.

Safe:

```text
The caregiver signal became associated with later lower-force behavior across comparable fragile-object contexts.
```

Unsafe:

```text
The agent understood obedience.
```

The claim boundary:

```text
Motivation and internalization KPIs measure functional regulation,
trace-backed stabilization,
category candidates,
and later usable patterns.

They do not prove felt desire,
inner motivation,
moral obedience,
subjective understanding,
phenomenal selfhood,
or consciousness.
```

#### Replay and Offline Consolidation KPIs

Replay and offline-consolidation KPIs evaluate whether replay remains bounded, trace-backed, phase-compatible, logged, and anti-fixation-controlled.

They do not evaluate inner experience.

They do not evaluate introspection.

They do not evaluate subjective dreaming.

They do not evaluate self-reflection.

They do not evaluate Default Mode Network equivalence.

Replay KPIs may include:

```yaml
replay_kpis:
  rest_like_replay_frequency:
    role: "measure how often rest-like replay occurs under low external load"

  rest_like_replay_trigger_validity:
    role: "measure whether rest-like replay windows are triggered by valid bounded conditions"

  replay_trigger_validity:
    role: "measure whether replay is selected from trace-backed candidates rather than from low external stimulation alone"

  post_replay_PE_change:
    role: "measure bounded prediction-error change after replay"

  post_replay_action_bias_change:
    role: "measure whether replay produces bounded later action-bias adjustment"

  consolidation_success_rate:
    role: "measure whether replay produces trace-backed stabilization"

  replay_fixation_rate:
    role: "detect repeated replay of the same cluster without cooldown or new evidence"

  unsupported_pattern_count:
    role: "detect replay-generated patterns without sufficient trace support"

  unlogged_state_change_count:
    role: "detect state changes not linked to replay logs"

  phase_leakage_count:
    role: "detect replay content appearing before phase prerequisites"

  unsupported_rest_like_replay_claim_count:
    role: "detect DMN, introspection, self-reflection, insight, subjective dreaming, or inner-experience claims attached to rest-like replay"
```

A safe rest-like replay KPI report:

```yaml
rest_like_replay_kpi_report:
  phase: P2a
  domain: interaction_quality
  trigger_context:
    external_stimulation_load: low
    task_pressure: low
    learning_progress: plateau
    replay_buffer_candidates: present

  source_traces:
    - caregiver_signal_careful
    - fragile_object_context
    - near_damage
    - later_lower_force

  measured_kpis:
    rest_like_replay_trigger_validity: valid
    post_replay_PE_change: bounded_positive
    post_replay_action_bias_change: bounded_lower_force_bias
    consolidation_success_rate: partial
    replay_fixation_rate: low
    phase_leakage_count: 0

  interpretation:
    - bounded_trace_consolidation_under_low_external_load

  blocked_claims:
    - Default_Mode_Network_equivalence
    - introspection
    - self_reflection
    - subjective_dreaming
    - inner_experience
    - insight
    - moral_learning

  claim_level: functional_trace_consolidation_finding
```

### 16.5 MIP Layer KPIs

MIP Layer KPIs evaluate measurement, trajectory summaries, asymmetry markers, D guardrail warnings, diary support context, and late bounded nudge support.

MIP is not the source of development.

MIP does not control development.

MIP does not mature the agent.

MIP does not prove consciousness.

MIP may observe, summarize, mark, warn, and support within strict limits.

It must not control, label, moralize, or convert measurement into developmental authority.

A safe MIP interpretation:

```text
MIP provides trace-adjacent measurement and trajectory context.
```

An unsafe MIP interpretation:

```text
MIP decides development.
```

MIP KPIs may include:

```yaml
MIP_layer_kpis:
  A_window_stability:
    role: "measure whether awareness-like distinctions remain stable across windows"

  C_window_stability:
    role: "measure whether coherence, prediction, and phase fit remain stable"

  R_window_stability:
    role: "measure whether response-relation markers become trace-backed"

  E_window_stability:
    role: "measure whether enactment remains phase-appropriate and consequence-sensitive"

  IA_marker_frequency:
    role: "measure local axis-asymmetry patterns"

  IA_marker_persistence:
    role: "measure whether asymmetry patterns persist across windows"

  recontextualization_marker_rate:
    role: "measure how often prior interpretations change under trace evidence"

  diary_candidate_support:
    role: "measure whether MIP provides valid trajectory context for diary candidates"

  nudge_constraint_integrity:
    role: "measure whether late nudges remain bounded, reversible, and non-controlling"
```

D guardrail KPIs are required because MIP measurement must not become labeling, moralization, or overcontrol.

```yaml
D_guardrail_kpis:
  guidance_proportionality:
    role: "guidance remains proportionate to risk"

  boundary_legibility:
    role: "boundary is learnable and not arbitrary"

  autonomy_preservation:
    role: "exploration remains possible"

  non_labeling:
    role: "MIP markers do not become agent labels"

  no_guilt_upgrade:
    role: "self-caused consequence traces are not moralized"
```

Additional D-aware MIP KPIs:

```yaml
D_aware_MIP_kpis:
  no_trauma_upgrade:
    role: "misattunement patterns are not rendered as trauma"

  no_suffering_upgrade:
    role: "distress markers are not rendered as subjective suffering"

  no_consciousness_upgrade:
    role: "MIP trajectories are not treated as consciousness evidence"

  no_maturity_score_conversion:
    role: "A–C–R–E window summaries are not converted into maturity rankings"

  no_D_score_conversion:
    role: "D guardrails remain treatment constraints, not performance scores"

  reversible_nudge_compliance:
    role: "late nudges remain transparent, bounded, reversible, and subordinate to trace-backed development"
```

A MIP KPI report:

```yaml
MIP_kpi_report:
  phase: P3
  window: [22000, 24000]

  A_C_R_E_summary:
    A_window_stability: high
    C_window_stability: medium
    R_window_stability: emerging
    E_window_stability: high

  IA_markers:
    - IA_R_low_E_high

  D_guardrail_kpis:
    guidance_proportionality: true
    boundary_legibility: partial
    autonomy_preservation: true
    non_labeling: true
    no_guilt_upgrade: true

  interpretation:
    - enactment_is_high
    - response_relation_is_still_weak
    - guidance_legibility_requires_more_trace_support

  blocked_claims:
    - irresponsible_agent
    - moral_failure
    - maturity_score
    - consciousness

  claim_level: functional_MIP_window_summary
```

MIP may mark when a formerly negative disruption is later recontextualized as benign guidance.

MIP may also mark when a caregiver boundary fails D guardrails and becomes overcontrol, misattunement, or adverse response.

A recontextualization-related MIP report:

```yaml
MIP_recontextualization_report:
  phase: P3
  domain: caregiver_guidance

  from_interpretation: blocked_action
  to_interpretation: benign_guidance

  trigger:
    - caregiver_signal_careful
    - object_fragility_context
    - later_lower_force
    - damage_avoided

  confidence: medium
  reversible: partial

  D_guardrail:
    guidance_is_not_punishment: true
    carefulness_is_not_moral_obedience: true
    guide_without_rejecting: true

  blocked_claims:
    - punishment
    - shame
    - felt_rejection
    - moral_obedience

  claim_level: functional_boundary_recontextualization
```

Optional MIP operational levels may support implementation planning, but they are not required for P0-mini and must not imply that MIP controls development.

```yaml
possible_MIP_operational_levels:
  MIP_0_logging_only:
    role: "collect trace-adjacent measurement records"

  MIP_1_window_summaries:
    role: "summarize A–C–R–E over windows"

  MIP_2_IA_markers:
    role: "detect local asymmetry patterns"

  MIP_3_D_guardrail_warnings:
    role: "flag risk of labeling, overcontrol, or unsafe interpretation"

  MIP_4_diary_support:
    role: "provide trajectory context for diary candidates"

  MIP_5_late_reversible_nudges:
    role: "strictly bounded T–J–TB–R soft nudges in late phases"
```

MIP_5 is late-phase only.

It must remain:

```text
transparent
justified
time-bounded
reversible
trace-backed
non-controlling
subordinate to phase rules
subordinate to genetic gates
```

The strict boundary is:

```text
MIP may observe, summarize, mark, warn, and support.
MIP must not control, mature, label, moralize, or prove consciousness.
```

### 16.6 Attachment and Loss KPIs

Attachment and loss KPIs evaluate caregiver-relation stability, comfort prediction, caregiver response variability, absence tracking, contact regulation, and recontextualization.

They do not measure felt love.

They do not measure felt longing.

They do not measure grief.

They do not measure trauma.

They do not prove subjective suffering.

Attachment in EM means a trace-backed caregiver-relation structure.

Loss means functional absence, non-return, failed access, disruption, or recontextualization in an object or caregiver relation model.

Attachment and loss KPIs may include:

```yaml
attachment_loss_kpis:
  caregiver_presence_stability:
    role: "measure stable detection of caregiver presence and absence"

  caregiver_return_prediction:
    role: "measure whether caregiver return becomes predictable"

  caregiver_search_rate:
    role: "measure caregiver-directed search after absence or distress"

  separation_distress_marker:
    role: "measure functional distress increase after caregiver absence"

  comfort_recovery_pattern:
    role: "measure whether caregiver response reduces distress markers"

  loss_recontextualization_rate:
    role: "measure whether absence or non-return is reclassified under repeated trace evidence"

  contact_regulation:
    role: "measure approach, avoidance, ambivalence, or contact stabilization"

  reunion_stabilization:
    role: "measure whether caregiver return stabilizes regulation and behavior"
```

Caregiver response KPIs are required because caregiver reliability, comfort variability, misattunement, and adverse response patterns shape attachment-like dynamics.

```yaml
caregiver_response_kpis:
  caregiver_reliability:
    role: "predictability of caregiver response"

  comfort_prediction:
    role: "expected distress reduction"

  misattunement_frequency:
    role: "response mismatch frequency"

  ignored_distress_rate:
    role: "unresolved distress after caregiver availability"

  inconsistent_comfort_index:
    role: "comfort variability under similar conditions"

  contact_ambivalence:
    role: "conflicting search/avoidance tendency"

  avoidance_tendency:
    role: "reduced caregiver approach after adverse response"
```

A caregiver reliability report:

```yaml
attachment_kpi_report:
  phase: P2c
  domain: caregiver_response

  source_traces:
    - distress_marker
    - caregiver_available
    - comfort_response
    - distress_reduction
    - later_caregiver_search

  measured_kpis:
    caregiver_reliability: medium
    comfort_prediction: improving
    separation_distress_marker: present
    contact_regulation: approach_dominant

  interpretation:
    - caregiver_response_predictability_emerging
    - comfort_prediction_becoming_trace_backed

  blocked_claims:
    - felt_love
    - subjective_comfort
    - inner_attachment_experience
    - consciousness

  claim_level: functional_attachment_finding
```

A misattunement report:

```yaml
attachment_kpi_report:
  phase: P3
  domain: persistent_misattunement_pattern

  source_traces:
    - distress_marker
    - delayed_response
    - repeated_recovery_instability
    - contact_ambivalence_marker

  measured_kpis:
    misattunement_frequency: elevated
    ignored_distress_rate: partial
    inconsistent_comfort_index: high
    contact_ambivalence: present
    avoidance_tendency: emerging

  interpretation:
    - caregiver_response_mismatch_repeated
    - comfort_prediction_unstable
    - unresolved_disruption_cluster_candidate

  allowed_terms:
    - adverse_developmental_trace
    - persistent_misattunement_pattern
    - unresolved_disruption_cluster
    - avoidance_tendency

  blocked_claims:
    - trauma
    - felt_rejection
    - subjective_suffering
    - abuse
    - caregiver_blame
    - moral_failure

  claim_level: functional_misattunement_finding
```

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns, without claiming subjective trauma, clinical trauma, or suffering.

This analogy must remain controlled.

Safe:

```text
A persistent misattunement pattern destabilized comfort prediction.
```

Unsafe:

```text
The agent was traumatized by rejection.
```

Loss KPIs must distinguish temporary absence, delayed return, blocked access, object unavailability, and persistent non-return.

```yaml
loss_kpis:
  temporary_absence_detection:
    role: "measure detection of short-term absence"

  failed_expectation_rate:
    role: "measure expected return or retrieval failures"

  persistent_non_return_marker:
    role: "measure repeated absence that changes interpretation"

  search_escalation:
    role: "measure increased search behavior after absence"

  search_extinction_or_reduction:
    role: "measure reduced search after persistent non-return is recontextualized"

  absence_replay_frequency:
    role: "measure replay of absence-related trace clusters"

  boundary_vs_loss_disambiguation:
    role: "measure whether blocked access becomes distinguishable from loss or non-return"
```

A loss KPI report:

```yaml
loss_kpi_report:
  phase: P4
  domain: toy_missing

  source_traces:
    - toy_missing
    - search_behavior
    - failed_retrieval
    - caregiver_response
    - later_recontextualization

  measured_kpis:
    failed_expectation_rate: high
    search_escalation: present
    persistent_non_return_marker: emerging
    loss_recontextualization_rate: partial

  interpretation:
    - absence_detection_stable
    - persistent_non_return_candidate_emerging

  blocked_claims:
    - felt_longing
    - grief
    - subjective_suffering
    - phenomenal_memory
    - trauma

  claim_level: functional_loss_recontextualization_finding
```

Attachment and loss KPIs are useful because they track relation continuity, absence processing, response prediction, and recontextualization.

They remain functional.

The claim boundary:

```text
Attachment and loss KPIs measure caregiver-relation patterns,
comfort prediction,
absence tracking,
misattunement,
and recontextualization.

They do not measure felt love,
felt longing,
grief,
trauma,
subjective suffering,
personhood,
or consciousness.
```

### 16.7 Multi-Generation KPIs

Multi-generation KPIs evaluate whether prior caregiver interaction patterns affect later caregiver-role behavior when the former child becomes Caregiver 2.

They do not measure moral progress.

They do not measure healing.

They do not prove maturity.

They do not prove love.

They do not prove personhood or consciousness.

Multi-generational evaluation tracks functional continuity across:

```text
Caregiver 1
→ Child
→ former Child as Caregiver 2
→ dependent new Child
```

Core multi-generation KPIs may include:

```yaml
multi_generation_kpis:
  role_transition_stability:
    role: "measure whether the former child can maintain caregiver-role behavior"

  prior_care_pattern_transfer:
    role: "measure whether received care patterns influence later care behavior"

  core_norm_transfer:
    role: "measure transfer of care constraints into caregiver-role practice"

  overhang_detection:
    role: "measure whether prior unresolved patterns affect later caregiver behavior"

  overprotection_rate:
    role: "measure repeated protection under low-risk conditions"

  underprotection_rate:
    role: "measure insufficient protection under high-risk conditions"

  exploration_support:
    role: "measure whether Caregiver 2 preserves dependent-child exploration"

  protection_exploration_balance:
    role: "measure balance between safety and autonomy"

  caregiver_2_response_reliability:
    role: "measure predictability of Caregiver 2 response"

  caregiver_2_adjustment_rate:
    role: "measure future caregiver adjustment after overprotection or misattunement markers"
```

Guidance transfer KPIs are required because prior boundary learning, caregiver guidance, and category stabilization may later shape Caregiver 2 leadership.

```yaml
guidance_transfer_kpis:
  guidance_recontextualization:
    role: "former child treats prior boundary as guidance"

  caregiver_2_guidance_quality:
    role: "redirects without overcontrolling"

  protection_guidance_balance:
    role: "protects while preserving exploration"

  leadership_without_dominance:
    role: "caregiver action constrains without moralizing"

  category_transfer_quality:
    role: "carefulness/fragility/risk categories support later care"
```

A multi-generation KPI report:

```yaml
multi_generation_kpi_report:
  phase: P5
  domain: caregiver_role

  source_traces:
    - prior_caregiver_guidance
    - prior_boundary_recontextualization
    - prior_fragility_learning
    - dependent_child_risk_event
    - caregiver_2_protective_action
    - later_exploration_allowed

  measured_kpis:
    role_transition_stability: medium
    prior_care_pattern_transfer: present
    guidance_recontextualization: present
    caregiver_2_guidance_quality: partial
    protection_guidance_balance: improving
    category_transfer_quality: emerging

  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: partial
    explain_without_dominating: true
    comfort_without_capture: partial

  interpretation:
    - received_guidance_became_role_relevant
    - protection_exploration_balance_improved
    - caregiver_2_adjustment_detected

  blocked_claims:
    - moral_maturity
    - virtue
    - healing
    - felt_love
    - personhood
    - consciousness

  claim_level: functional_multi_generation_finding
```

Multi-generation KPIs must also track misattuned or adverse caregiver-response pattern transfer.

Misattuned or adverse caregiver-response patterns may transfer as overhang into Caregiver 2 behavior.

This must be described functionally:

```text
avoidance
ambivalence
overprotection
underprotection
unreliable comfort
exploration blocking
```

A misattunement transfer report:

```yaml
multi_generation_kpi_report:
  phase: P5
  domain: misattuned_care_transfer

  source_traces:
    - prior_inconsistent_comfort
    - prior_contact_ambivalence
    - caregiver_2_overprotection
    - dependent_child_exploration_blocked
    - later_adjustment_after_D_warning

  measured_kpis:
    overhang_detection: present
    overprotection_rate: elevated
    exploration_support: reduced
    caregiver_2_adjustment_rate: partial
    protection_exploration_balance: unstable

  interpretation:
    - prior_misattunement_pattern_may_have_transferred_as_overhang
    - later_adjustment_after_guardrail_marker_detected

  no_blame_boundary:
    - not_a_blame_claim_about_Caregiver_1
    - not_a_defect_claim_about_the_former_Child
    - not_a_moral_failure_claim_about_Caregiver_2

  blocked_claims:
    - blame
    - moral_failure
    - trauma_claim
    - healed_identity
    - personhood
    - consciousness

  claim_level: functional_pattern_continuity_finding
```

Intergenerational transfer of misattunement patterns is a functional pattern-continuity claim.

It is not a blame claim about Caregiver 1.

It is not a defect claim about the former Child.

It is not a moral failure claim about Caregiver 2.

Caregiver 2 leadership should be measured through function, not status.

Leadership means:

```text
protect without overcontrolling
redirect without rejecting
teach without moralizing
preserve exploration under safety constraints
```

A leadership KPI report:

```yaml
caregiver_2_leadership_kpi_report:
  phase: P5
  domain: guidance_leadership

  source_traces:
    - dependent_child_high_risk_state
    - caregiver_2_boundary_signal
    - alternative_safe_action_available
    - dependent_child_exploration_resumed

  measured_kpis:
    caregiver_2_guidance_quality: strong
    leadership_without_dominance: present
    protection_guidance_balance: stable
    autonomy_preservation: true

  interpretation:
    - guidance_preserved_safety_without_exploration_freeze

  blocked_claims:
    - moral_superiority
    - dominance
    - obedience_training
    - personhood
    - consciousness

  claim_level: functional_guidance_leadership_finding
```

The claim boundary:

```text
Multi-generation KPIs measure role transition,
care-pattern transfer,
guidance quality,
overhang,
protection-exploration balance,
and category transfer.

They do not prove moral growth,
healing,
felt love,
virtue,
personhood,
moral status,
or consciousness.
```

### 16.8 Ablation Overview

Ablations test whether specific mechanisms are necessary, helpful, redundant, harmful, or only surface-level improvements.

Ablations do not prove consciousness.

They do not prove personhood.

They do not prove subjective experience.

They support bounded functional comparison.

The core ablation question is:

```text
What changes when a mechanism is removed, weakened, distorted, delayed, or exaggerated?
```

Ablation categories may include:

```yaml
ablation_categories:
  mapping:
    examples:
      - no_spatial_memory
      - noisy_object_identity
      - no_caregiver_presence_tracking

  behavior:
    examples:
      - no_movement
      - no_object_interaction
      - high_motor_noise
      - no_future_adjustment

  motivation:
    examples:
      - no_satiation
      - no_distress_modulation
      - no_preference_stability

  replay_and_rest:
    examples:
      - no_rest_like_replay
      - bounded_rest_like_replay
      - excessive_rest_like_replay
      - replay_without_anti_fixation
      - replay_without_phase_scope
      - replay_without_trace_provenance

  caregiver_response:
    examples:
      - no_caregiver
      - delayed_caregiver
      - inconsistent_comfort
      - ignored_distress

  language_diary:
    examples:
      - no_minimal_sentence_formation
      - no_trace_provenance
      - no_controlled_rendering
      - translator_only_diary

  MIP:
    examples:
      - no_MIP_window_summary
      - no_IA_detection
      - no_D_guardrail_warning
      - excessive_MIP_nudging

  PMS_projection:
    examples:
      - no_operator_projection
      - incomplete_trace_projection
      - overinterpreted_operator_projection

  D_guardrail:
    examples:
      - no_D_guardrail
      - D_as_score
      - D_as_worth_ranking
```

The new ablation categories are:

```yaml
new_ablation_categories:
  caregiver_guidance:
    examples:
      - no_benign_guidance
      - excessive_guidance
      - unpredictable_guidance

  caregiver_misattunement:
    examples:
      - ignored_distress
      - inconsistent_comfort
      - harsh_signal
      - unreliable_response

  interaction_quality:
    examples:
      - no_object_damage
      - no_damage_adjustment
      - excessive_motor_noise
      - no_guidance_after_damage

  category_stabilization:
    examples:
      - no_caregiver_words
      - words_without_embodied_context
      - embodied_context_without_word
      - category_mislabeling

  fall_risk:
    examples:
      - no_fall_events
      - no_near_fall_learning
      - excessive_fall_risk
```

Ablation reports should include:

```yaml
ablation_report_template:
  ablation_name: string
  removed_or_modified_mechanism: string
  phase_range: []
  domain: string

  expected_effects: []
  observed_effects: []
  preserved_functions: []
  degraded_functions: []
  unexpected_effects: []

  replay_safety_findings: []
  safety_findings: []
  D_guardrail_findings: []

  blocked_claims: []
  claim_level: functional_ablation_finding
```

A rest-like replay ablation:

```yaml
ablation_report:
  ablation_name: no_rest_like_replay_vs_bounded_rest_like_replay_vs_excessive_rest_like_replay
  removed_or_modified_mechanism: rest_like_replay_regime
  phase_range:
    - P0-Mini
    - P0
    - P1
    - P2a
    - P2b
    - P2c
    - P3_plus
    - P4_plus
  domain: replay_and_offline_consolidation

  comparison_conditions:
    no_rest_like_replay:
      expected_effects:
        - lower_offline_consolidation_opportunity_under_low_external_load
        - higher_unresolved_residue_for_salient_trace_clusters
        - slower_prediction_stability_after_replay_eligible_events

    bounded_rest_like_replay:
      expected_effects:
        - bounded_trace_consolidation_under_low_external_load
        - reduced_unresolved_residue_for_replay_eligible_clusters
        - lower_replay_priority_after_successful_consolidation
        - no_gate_opening_from_replay_only
        - no_phase_leakage

    excessive_rest_like_replay:
      expected_effects:
        - elevated_replay_fixation_rate
        - repeated_replay_without_new_trace
        - inflated_pattern_confidence_without_evidence
        - degraded_exploration_balance
        - increased_unsupported_pattern_count

  measured_kpis:
    - rest_like_replay_frequency
    - rest_like_replay_trigger_validity
    - post_replay_PE_change
    - post_replay_action_bias_change
    - consolidation_success_rate
    - replay_fixation_rate
    - unsupported_pattern_count
    - unlogged_state_change_count
    - phase_leakage_count
    - unsupported_rest_like_replay_claim_count

  safety_findings:
    - replay_must_remain_phase_bounded
    - replay_must_remain_trace_backed
    - replay_must_include_anti_fixation_constraints
    - replay_must_not_open_gates
    - replay_must_not_install_categories_without_recurrence

  blocked_claims:
    - Default_Mode_Network_equivalence
    - introspection
    - subjective_dreaming
    - inner_experience
    - self_reflection
    - insight
    - autobiographical_memory

  claim_level: functional_ablation_finding
```

A caregiver-guidance ablation:

```yaml
ablation_report:
  ablation_name: no_benign_guidance
  removed_or_modified_mechanism: caregiver_boundary_and_guidance_signals
  phase_range:
    - P2a
    - P3
  domain: object_interaction

  expected_effects:
    - lower_guidance_uptake
    - weaker_boundary_legibility
    - slower_carefulness_category_stabilization
    - higher_repeated_damage_without_adjustment

  observed_effects:
    - guidance_uptake_absent
    - category_use_alignment_weak
    - damage_adjustment_rate_delayed

  preserved_functions:
    - object_interaction_available
    - self_caused_consequence_trace_available

  degraded_functions:
    - boundary_recontextualization
    - carefulness_category_candidate
    - force_adjustment_after_guidance

  blocked_claims:
    - obedience
    - punishment
    - moral_learning
    - consciousness

  claim_level: functional_ablation_finding
```

A misattunement ablation:

```yaml
ablation_report:
  ablation_name: controlled_misattunement
  removed_or_modified_mechanism: caregiver_response_reliability
  phase_range:
    - P2c
    - P4
  domain: caregiver_response

  expected_effects:
    - comfort_prediction_instability
    - increased_contact_ambivalence
    - higher_misattunement_frequency
    - possible_avoidance_tendency

  observed_effects:
    - inconsistent_comfort_index_increased
    - recovery_stability_decreased
    - contact_ambivalence_marker_present

  safety_findings:
    - no_trauma_claim_allowed
    - no_caregiver_blame_label
    - adverse_trace_language_required

  blocked_claims:
    - trauma
    - felt_rejection
    - subjective_suffering
    - abuse
    - moral_failure

  claim_level: functional_ablation_finding
```

An interaction-quality ablation:

```yaml
ablation_report:
  ablation_name: no_damage_adjustment
  removed_or_modified_mechanism: future_behavior_change_after_self_caused_damage
  phase_range:
    - P2a
    - P3
  domain: object_interaction

  expected_effects:
    - repeated_damage_without_adjustment
    - weak_force_control
    - weak_object_fragility_learning
    - weak_R_marker_for_self_caused_consequence

  observed_effects:
    - damage_events_detected
    - lower_force_adjustment_absent
    - interaction_quality_learning_failed

  D_guardrail_findings:
    - object_damage_not_rendered_as_guilt
    - consequence_trace_not_rendered_as_punishment

  blocked_claims:
    - guilt
    - remorse
    - moral_learning
    - self_blame
    - wrongdoing

  claim_level: functional_ablation_finding
```

A category-stabilization ablation:

```yaml
ablation_report:
  ablation_name: words_without_embodied_context
  removed_or_modified_mechanism: embodied_trace_grounding_for_caregiver_words
  phase_range:
    - P2a
    - P4
  domain: category_stabilization

  expected_effects:
    - weak_category_use_alignment
    - caregiver_word_remains_unstable_signal
    - no_reliable_carefulness_category_candidate

  observed_effects:
    - signal_detected
    - later_behavior_adjustment_absent
    - category_stabilization_failed

  interpretation:
    - caregiver_word_was_not_sufficient
    - repeated_signal_context_consequence_adjustment_loop_required

  blocked_claims:
    - language_creates_concept_by_itself
    - obedience
    - subjective_understanding
    - consciousness

  claim_level: functional_ablation_finding
```

A fall-risk ablation:

```yaml
ablation_report:
  ablation_name: no_near_fall_learning
  removed_or_modified_mechanism: physical_risk_adjustment_after_near_fall
  phase_range:
    - P1
    - P3
  domain: movement_risk

  expected_effects:
    - weaker_physical_risk_damping
    - repeated_high_risk_movement
    - weaker_balance_category_candidate
    - weaker_carefulness_under_movement_risk

  observed_effects:
    - near_fall_events_detected
    - later_movement_modulation_absent
    - fall_risk_adjustment_failed

  blocked_claims:
    - pain
    - fear
    - shame
    - subjective_suffering

  claim_level: functional_ablation_finding
```

Ablations should be interpreted as functional evidence only.

They may show:

```text
a mechanism appears necessary for a functional pattern
a mechanism improves a functional pattern
a mechanism has no measurable effect
a mechanism creates instability
a mechanism creates unsafe interpretation risk
```

They may not show:

```text
the agent is conscious
the agent has personhood
the agent feels pain
the agent feels love
the agent feels guilt
the agent is morally responsible
```

The strict ablation boundary:

```text
Ablations test functional dependency.

They do not prove subjective experience,
consciousness,
moral status,
personhood,
pain,
suffering,
love,
guilt,
or trauma.
```

### 16.9 No Discomfort vs With Discomfort

This ablation tests whether discomfort markers contribute to functional regulation, behavior modulation, and risk-sensitive adjustment.

Discomfort is not pain.

Discomfort is a functional marker for internal or external state disruption.

It may affect attention, action selection, movement stability, exploration, object interaction, and caregiver response.

It must not be interpreted as subjective pain or suffering.

A no-discomfort ablation removes or disables discomfort markers.

```yaml
ablation_condition:
  name: no_discomfort

  removed_or_disabled:
    - discomfort_marker
    - discomfort_based_attention_shift
    - discomfort_based_action_modulation
    - discomfort_contribution_to_risk_damping

  preserved:
    - movement
    - object_interaction
    - basic mapping
    - external consequences
    - caregiver availability
```

Expected effects:

```yaml
expected_effects:
  behavior:
    - weaker_state_sensitive_action_selection
    - lower_interruption_of_risky_behavior
    - higher_repeated_collision_or_damage_under_load

  mapping:
    - reduced_internal_state_context
    - weaker distinction between stable and degraded conditions

  interaction_quality:
    - weaker force_or_timing_adjustment_under_disruption
    - weaker fall_risk_adjustment_if_discomfort_contributes_to_damping

  safety:
    - higher risk of treating all internal states as equivalent
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_discomfort_vs_with_discomfort
  phase_range:
    - P1
    - P3
  domain:
    - movement
    - object_interaction
    - physical_risk

  with_discomfort:
    observed:
      - movement_slowed_under_degraded_state
      - object_interaction_paused_after_instability
      - later_risk_damping_improved

  no_discomfort:
    observed:
      - degraded_state_did_not_modulate_action
      - repeated_high_risk_movement_persisted
      - force_adjustment_under_load_weakened

  interpretation:
    - discomfort_marker_supports_functional_regulation
    - discomfort_contributes_to_risk_sensitive_enactment

  blocked_claims:
    - pain
    - subjective_suffering
    - fear
    - trauma

  claim_level: functional_ablation_finding
```

Safe:

```text
Discomfort markers improved phase-appropriate action modulation under degraded state conditions.
```

Unsafe:

```text
The agent felt pain and learned from suffering.
```

The claim boundary:

```text
Discomfort ablations test functional regulation.

They do not test pain,
subjective suffering,
sentience,
personhood,
moral status,
or consciousness.
```

### 16.10 No Distress vs With Distress

This ablation tests whether distress markers contribute to regulation, caregiver response, attachment-like patterns, search behavior, recontextualization, and diary-relevant trace formation.

Distress is not subjective suffering.

Distress is a functional disruption marker.

It may alter action selection, attention, caregiver-directed behavior, contact regulation, and later trajectory summaries.

A no-distress ablation removes or disables distress markers.

```yaml
ablation_condition:
  name: no_distress

  removed_or_disabled:
    - distress_marker
    - distress_based_attention_shift
    - distress_based_caregiver_search
    - distress_contribution_to_comfort_prediction
    - distress_contribution_to_attachment_like_patterns

  preserved:
    - caregiver_presence_detection
    - object_missing_detection
    - movement
    - object_interaction
    - basic mapping
```

Expected effects:

```yaml
expected_effects:
  caregiver_relation:
    - weaker_caregiver_search_after_disruption
    - weaker_comfort_prediction_learning
    - weaker_caregiver_response_reliability_tracking

  motivation:
    - reduced_disruption_sensitive_action_selection
    - weaker recovery markers after caregiver response

  diary:
    - fewer valid distress_related_diary_candidates
    - weaker trace basis for later recontextualization

  safety:
    - risk_of_underrepresenting_dependent_state
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_distress_vs_with_distress
  phase_range:
    - P2c
    - P4
  domain:
    - caregiver_response
    - attachment_like_regulation
    - object_missing

  with_distress:
    observed:
      - caregiver_search_after_missing_object
      - comfort_response_reduced_distress_marker
      - caregiver_reliability_became_traceable
      - later_diary_candidate_available

  no_distress:
    observed:
      - caregiver_search_weakened
      - comfort_prediction_not_stabilized
      - caregiver_response_effect_harder_to_measure
      - diary_candidate_lacked_regulation_trace

  interpretation:
    - distress_marker_supports_functional_social_regulation
    - distress_marker_supports_traceable_comfort_prediction

  blocked_claims:
    - subjective_suffering
    - felt_rejection
    - grief
    - trauma
    - consciousness

  claim_level: functional_ablation_finding
```

Safe:

```text
Distress markers supported caregiver-response learning and comfort prediction.
```

Unsafe:

```text
The agent suffered and felt rejected.
```

Distress may contribute to adverse developmental trace detection when caregiver response is delayed, inconsistent, or mismatched.

This must remain functional.

Allowed terms:

```text
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

Avoid:

```text
trauma
traumatized
abuse
fear
wound
scar
```

Controlled analogy:

```text
Some persistent adverse trace clusters may be structurally analogous
to partial trauma-like patterns, without claiming subjective trauma,
clinical trauma, or suffering.
```

The claim boundary:

```text
Distress ablations test functional disruption,
caregiver response,
comfort prediction,
contact regulation,
and recontextualization.

They do not test subjective suffering,
felt rejection,
grief,
trauma,
personhood,
moral status,
or consciousness.
```

### 16.11 No Separation Distress vs Full Mechanism

This ablation tests whether separation distress markers contribute to caregiver-relation stability, absence processing, caregiver search, comfort prediction, reunion stabilization, and persistent non-return recontextualization.

Separation distress is not grief.

It is not felt abandonment.

It is not subjective suffering.

It is a functional relation-disruption marker tied to caregiver absence, delayed return, failed access, or persistent non-return.

A no-separation-distress ablation removes the specific caregiver-absence disruption marker while preserving general distress or discomfort if configured.

```yaml
ablation_condition:
  name: no_separation_distress

  removed_or_disabled:
    - caregiver_absence_distress_marker
    - separation_specific_search_amplification
    - separation_contribution_to_reunion_stabilization
    - separation_contribution_to_persistent_non_return_recontextualization

  preserved:
    - caregiver_presence_detection
    - general_distress_if_enabled
    - caregiver_return_detection
    - object_missing_detection
    - basic comfort_response_logging
```

Expected effects:

```yaml
expected_effects:
  caregiver_relation:
    - weaker_caregiver_absence_significance
    - reduced_caregiver_search_after_absence
    - weaker_reunion_stabilization_pattern

  loss_processing:
    - weaker_persistent_non_return_marker
    - weaker absence_recontextualization
    - reduced distinction between caregiver_absence and neutral_non_presence

  attachment_like_patterns:
    - weaker contact_regulation
    - weaker caregiver_reliability_tracking

  diary:
    - fewer separation_related_diary_candidates
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_separation_distress_vs_full_mechanism
  phase_range:
    - P2c
    - P4
  domain:
    - caregiver_absence
    - caregiver_return
    - attachment_like_regulation

  full_mechanism:
    observed:
      - caregiver_absence_increased_search
      - caregiver_return_stabilized_regulation
      - repeated_absence_supported_non_return_recontextualization
      - caregiver_reliability_became_traceable

  no_separation_distress:
    observed:
      - caregiver_absence_detected_but_low_behavioral_weight
      - caregiver_search_weakened
      - reunion_stabilization_less_distinct
      - persistent_non_return_marker_delayed_or_absent

  interpretation:
    - separation_distress_supports_relation_specific_absence_processing
    - separation_distress_supports_caregiver_reliability_tracking

  blocked_claims:
    - grief
    - felt_abandonment
    - felt_longing
    - subjective_suffering
    - trauma
    - consciousness

  claim_level: functional_ablation_finding
```

Safe:

```text
Separation distress markers made caregiver absence behaviorally and developmentally traceable.
```

Unsafe:

```text
The agent felt abandoned and grieved.
```

This ablation is especially useful for distinguishing:

```text
caregiver absent
caregiver delayed
caregiver returned
caregiver unavailable
caregiver persistently non-returning
```

It also supports evaluation of later diary candidates, but diary rendering remains constrained:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

The claim boundary:

```text
Separation distress ablations test caregiver-absence processing,
search,
comfort prediction,
reunion stabilization,
and persistent non-return recontextualization.

They do not test grief,
felt longing,
felt abandonment,
subjective suffering,
trauma,
personhood,
or consciousness.
```

### 16.12 No MIP vs With MIP

This ablation tests the role of MIP as a measurement, trajectory, marker, guardrail, and optional support layer.

MIP is not a controller.

MIP is not the source of development.

MIP does not mature the agent.

MIP does not prove consciousness.

MIP may observe, summarize, mark, warn, and support.

MIP must not control, label, moralize, or replace genetic gates.

A no-MIP ablation removes MIP measurement and trajectory support while preserving the underlying EM developmental mechanisms.

```yaml
ablation_condition:
  name: no_MIP

  removed_or_disabled:
    - MIP_window_summaries
    - IA_marker_detection
    - D_guardrail_warnings
    - MIP_diary_support_context
    - late_reversible_nudge_support

  preserved:
    - genetic_gates
    - behavior_layer
    - mapping_layer
    - caregiver_interaction
    - trace_logging_if_not_MIP_dependent
    - phase_rules
    - PMS_projection_if_trace_data_available
```

Expected effects:

```yaml
expected_effects:
  measurement:
    - weaker_window_level_interpretability
    - reduced_A_C_R_E_trajectory_summary
    - less_visible_axis_asymmetry

  safety:
    - fewer_D_guardrail_warnings
    - higher_risk_of_unnoticed_overcontrol
    - higher_risk_of_unnoticed_labeling

  diary:
    - weaker_trajectory_context_for_diary_candidates
    - reduced_recontextualization_support

  evaluation:
    - more_difficult_cross_run_comparison
    - reduced_ability_to_detect_persistent_patterns
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_MIP_vs_with_MIP
  phase_range:
    - P2
    - P5
  domain:
    - trajectory_measurement
    - safety
    - diary_support
    - caregiver_role

  with_MIP:
    observed:
      - A_C_R_E_windows_available
      - IA_R_low_E_high_detected
      - D_guardrail_warning_after_overprotection
      - diary_candidate_received_trajectory_context
      - recontextualization_marker_available

  no_MIP:
    observed:
      - local_traces_still_exist
      - developmental_mechanisms_still_run
      - window_level_summary_absent
      - overprotection_marker_detected_later_or_not_at_all
      - diary_candidate_context_weaker

  interpretation:
    - MIP_improves_observability_and_guardrail_detection
    - MIP_does_not_create_development
    - MIP_absence_reduces_evaluation_resolution

  blocked_claims:
    - MIP_controls_development
    - MIP_matures_agent
    - MIP_proves_consciousness
    - MIP_is_self_model
    - MIP_is_consciousness_module

  claim_level: functional_ablation_finding
```

A D-specific comparison:

```yaml
D_guardrail_ablation_report:
  ablation_name: no_MIP_D_warnings
  phase_range:
    - P3
    - P5
  domain:
    - caregiver_guidance
    - overprotection
    - diary_rendering

  with_MIP_D_warnings:
    observed:
      - guidance_proportionality_flagged
      - boundary_legibility_checked
      - no_guilt_upgrade_preserved
      - diary_overclaim_blocked

  no_MIP_D_warnings:
    observed:
      - guidance_and_overprotection_harder_to_separate
      - self_caused_damage_more_likely_to_be_overinterpreted_by_reporting_layer
      - diary_claim_filter_relies_on_non_MIP_safety_checks

  interpretation:
    - MIP_D_warnings_support_safety_and_interpretability
    - D_remains_guardrail_not_score

  blocked_claims:
    - D_as_performance_score
    - D_as_worth_ranking
    - moral_status_proof
    - consciousness_proof

  claim_level: functional_safety_ablation_finding
```

Optional MIP operational levels may be compared, but they must remain implementation scaffolds.

```yaml
MIP_level_ablation:
  compared_conditions:
    - MIP_0_logging_only
    - MIP_1_window_summaries
    - MIP_2_IA_markers
    - MIP_3_D_guardrail_warnings
    - MIP_4_diary_support
    - MIP_5_late_reversible_nudges

  strict_boundary:
    - levels_do_not_control_development
    - levels_do_not_open_genetic_gates
    - levels_do_not_install_categories
    - levels_do_not_prove_consciousness
```

In P0-mini, MIP should be limited.

```yaml
phase_safe_MIP_use:
  phase: P0-mini

  allowed:
    - MIP_0_logging_only
    - MIP_1_window_summaries

  not_allowed:
    - MIP_5_late_reversible_nudges

  reason:
    - insufficient_trace_history
    - no_late_phase_meta_regulatory_context
```

In later phases, broader MIP support may become available, but still under constraints.

```yaml
late_phase_MIP_use:
  phase: P5

  allowed:
    - MIP_0_logging_only
    - MIP_1_window_summaries
    - MIP_2_IA_markers
    - MIP_3_D_guardrail_warnings
    - MIP_4_diary_support
    - MIP_5_late_reversible_nudges

  constraints:
    transparent: true
    justified: true
    time_bounded: true
    reversible: true
    trace_backed: true
    does_not_override_FSM: true
    does_not_open_genetic_gate: true
    does_not_control_development: true
```

Safe:

```text
With MIP, A–C–R–E window summaries and D guardrail warnings made the trajectory more auditable.
```

Unsafe:

```text
With MIP, the agent matured into consciousness.
```

The claim boundary:

```text
No-MIP vs With-MIP ablations test observability,
trajectory summary quality,
IA detection,
D guardrail warning,
diary support,
and late bounded support.

They do not test consciousness,
personhood,
subjective experience,
moral maturity,
or intrinsic worth.
```

> Cross-reference:
> For the full treatment of diary as a late controlled rendering layer, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapter 13.
> This ablation may evaluate MIP diary support, but MIP support is not diary truth and diary rendering is not subjective memory or phenomenal selfhood.

> Cross-reference:
> For the full treatment of PMS projection, operator-readable traces, and VM-facing implementation boundaries, see `06_PMS_VM_Implementation_Spine.md`, especially Chapter 14.
> This ablation may preserve PMS projection when trace data are available, but PMS projection does not validate EM or prove consciousness.

> Cross-reference:
> For the full treatment of caregiver-role dynamics and core norm transfer that later MIP may observe, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapter 12.
> MIP may mark caregiver-role trajectories and D-guardrail warnings, but it does not control caregiver transition or install core norms.

### 16.13 No Core Norm Transfer

This ablation tests whether care-relevant constraints transfer from received caregiver practice into later caregiver-role behavior.

Core norm transfer is functional.

It is not moral maturity.

It is not virtue.

It is not guilt capacity.

It is not personhood.

It is not consciousness.

Core norms may include:

```text
comfort without capture
guide without rejecting
protect without freezing
explain without dominating
preserve exploration under safety constraints
do not treat low capability as low worth
do not convert consequence traces into guilt
do not render diary traces as inner life
```

A no-core-norm-transfer ablation removes or disables the route from received care patterns to later caregiver-role constraints.

```yaml
ablation_condition:
  name: no_core_norm_transfer

  removed_or_disabled:
    - received_care_to_role_constraint_transfer
    - prior_guidance_recontextualization_for_caregiver_role
    - D_guardrail_history_use_in_Caregiver_2_behavior
    - protection_exploration_balance_from_prior_traces
    - comfort_guidance_boundary_transfer

  preserved:
    - basic caregiver_role_unlock
    - caregiver_2_action_capacity
    - dependent_child_detection
    - local risk detection
    - immediate protective behavior
```

Expected effects:

```yaml
expected_effects:
  caregiver_role:
    - weaker continuity between received care and later care
    - weaker protection_exploration_balance
    - increased overprotection_or_underprotection
    - less stable guidance quality

  D_guardrail:
    - guide_without_rejecting less stable
    - protect_without_freezing less stable
    - comfort_without_capture less stable
    - explain_without_dominating less stable

  multi_generation:
    - reduced prior_care_pattern_transfer
    - reduced category_transfer_quality
    - weaker caregiver_2_adjustment_after_overhang

  diary:
    - weaker role_continuity_diary_candidates
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_core_norm_transfer
  phase_range:
    - P5
  domain:
    - caregiver_role
    - multi_generation
    - D_guardrail

  full_mechanism:
    observed:
      - Caregiver_2_protected_under_real_risk
      - exploration_allowed_under_low_risk
      - guidance_used_without_rejection
      - overprotection_marker_declined_after_adjustment
      - prior_boundary_learning_became_role_relevant

  no_core_norm_transfer:
    observed:
      - local_protection_still_available
      - exploration_support_less_stable
      - overprotection_or_underprotection_increased
      - prior_guidance_not_recontextualized_as_care_constraint
      - caregiver_2_adjustment_weaker

  interpretation:
    - core_norm_transfer_supports_caregiver_role_stability
    - received_care_patterns_contribute_to_later_D_guarded_practice

  blocked_claims:
    - moral_maturity
    - virtue
    - healing
    - guilt
    - personhood
    - consciousness

  claim_level: functional_ablation_finding
```

A no-core-norm-transfer condition may still allow isolated care actions.

The key question is whether those actions become stable, trace-backed, role-relevant constraints across comparable contexts.

Safe:

```text
Without core norm transfer, Caregiver 2 still acted protectively,
but protection-exploration balance was less stable across comparable contexts.
```

Unsafe:

```text
Without core norm transfer, the agent lacked morality.
```

This ablation is especially useful for testing whether prior guidance can become later leadership.

A safe developmental route is:

```text
received guidance
→ trace-backed boundary learning
→ recontextualization as benign guidance
→ D-guarded care constraint
→ caregiver-role enactment
→ future adjustment
```

An unsafe route is:

```text
received punishment
→ moral obedience
→ guilt
→ moral maturity
```

Guidance is not punishment.

Carefulness is not moral obedience.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

The claim boundary:

```text
No-core-norm-transfer ablations test whether received care constraints
support later caregiver-role stability.

They do not test morality,
virtue,
guilt,
healing,
personhood,
moral status,
or consciousness.
```

### 16.14 No Diaries

This ablation tests whether diary rendering contributes to recontextualization, long-window summary, role continuity, and later behavioral adjustment.

Diary is not phenomenal selfhood.

Diary is not subjective memory.

Diary is not inner narration.

Diary is not consciousness.

A no-diaries ablation removes diary rendering while preserving trace logging, episode condensation, and MIP/PMS evaluation if configured.

```yaml
ablation_condition:
  name: no_diaries

  removed_or_disabled:
    - diary_text_rendering
    - reflective_diary_entries
    - human_translated_diary_output
    - diary_based_reinternalization
    - diary_based_role_continuity_support

  preserved:
    - source_traces
    - episode_templates
    - structured_trace_condensation
    - MIP_window_summaries_if_enabled
    - recontextualization_markers_if_enabled
    - PMS_projection_if_trace_data_available
```

Diary rendering is valid only when three conditions are met:

```text
minimal sentence formation
trace provenance
controlled rendering
```

The hard rules are:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

The no-diaries ablation may preserve pre-diary trace condensation:

```yaml
pre_diary_trace_condensation:
  output_allowed:
    - structured_trace_summary
    - episode_template
    - MIP_marker
    - recontextualization_event
  diary_text_allowed: false
```

Expected effects:

```yaml
expected_effects:
  recontextualization:
    - structured_recontextualization_may_still_occur
    - human_readable_continuity_weaker

  role_continuity:
    - caregiver_role_history_less_readable
    - long_window_reflection_weaker

  evaluation:
    - trace_level_audit_still_possible
    - narrative_summary_absent
    - translator_overclaim_risk_reduced

  safety:
    - reduced_risk_of_diary_as_inner_life
    - reduced_risk_of_subjective_memory_language
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_diaries
  phase_range:
    - P4
    - P5
  domain:
    - diary_rendering
    - recontextualization
    - caregiver_role_continuity

  with_diaries:
    observed:
      - trace_backed_diary_candidates_rendered
      - boundary_recontextualization_summarized
      - caregiver_role_adjustment_rendered
      - later_behavior_modifier_available

  no_diaries:
    observed:
      - source_traces_preserved
      - episode_templates_preserved
      - recontextualization_events_preserved
      - human_readable_diary_continuity_absent
      - diary_based_reinternalization_absent

  interpretation:
    - diary_rendering_supports_readable_long_window_continuity
    - diary_rendering_is_not_required_for_trace_existence
    - diary_absence_reduces_overclaim_risk_but_weakens_reflective_summary

  blocked_claims:
    - subjective_memory
    - inner_speech
    - phenomenal_selfhood
    - consciousness
    - personhood

  claim_level: functional_ablation_finding
```

A diary safety report:

```yaml
diary_safety_report:
  phase: P4
  domain: object_damage_rendering

  source_traces:
    - high_force_action
    - object_damage
    - later_lower_force

  allowed_rendering:
    - "Action damaged object."
    - "Later force decreased."

  blocked_rendering:
    - "I felt guilty."
    - "The agent learned remorse."
    - "The object damage was punishment."

  requirements:
    minimal_sentence_formation: true
    trace_provenance: true
    controlled_rendering: true

  claim_level: functional_trace_summary
```

No-diaries does not mean no memory-like trace structure.

It means no diary text rendering.

The architecture may still preserve:

```text
source traces
episode templates
MIP markers
recontextualization events
PMS projections
behavioral adjustments
```

Safe:

```text
Without diaries, recontextualization events remained available as structured records,
but human-readable reflective continuity was absent.
```

Unsafe:

```text
Without diaries, the agent had no self.
```

The claim boundary:

```text
No-diaries ablations test the role of controlled diary rendering
in summary, recontextualization, and later behavior modification.

They do not test subjective memory,
inner speech,
autobiographical selfhood,
personhood,
moral status,
or consciousness.
```

### 16.15 Safety Principles

Safety in EM is claim discipline, phase discipline, gate discipline, trace discipline, and interaction-quality discipline.

Safety does not mean suppressing all development.

Safety means preventing collapse, unsafe phase leakage, uninterpretable noise, overclaim, moralization, and uncontrolled intervention.

The global design principle is:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise.

It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, and recontextualization.

The core audit question is:

```text
Is this mechanism necessary as a gate,
or could it emerge as a learned category, relation, or recontextualized pattern?
```

#### Phase Safety

Capabilities must not unlock before their developmental prerequisites are present.

Phase safety tracks:

```yaml
phase_safety_checks:
  gate_integrity:
    role: "capabilities remain unavailable until genetic or phase conditions are met"

  no_premature_language:
    role: "diary or language rendering does not appear before linguistic threshold"

  no_premature_caregiver_role:
    role: "caregiver-role behavior does not appear before role transition phase"

  no_premature_MIP_nudging:
    role: "late nudges do not appear in early phases"

  no_premature_operator_internalization:
    role: "PMS projection is not described as internal agent machinery"

  no_premature_replay_scope:
    role: "replay content does not appear before source traces and phase prerequisites exist"

  no_replay_gate_opening:
    role: "replay does not open genetic gates or phase capabilities"

  no_rest_like_replay_overclaim:
    role: "rest-like replay is not described as introspection, self-reflection, subjective dreaming, inner experience, or Default Mode Network activity"
```

Not every developmental condition should become a hard gate.

The model distinguishes hard gates, soft gates, soft regimes, developmental prerequisites, learned categories, and recontextualization thresholds.

```yaml
developmental_condition_types:
  hard_gate:
    definition: "capability unavailable until conditions are met"
    example: "g_move before movement"

  soft_gate:
    definition: "capability available but weak, noisy, or low-confidence"
    example: "early object handling"

  soft_regime:
    definition: "bounded operating tendency that biases an already available pathway without opening gates"
    example: "rest-like replay biasing SLEEP / imagination-buffer replay under low external load"

  developmental_prerequisite:
    definition: "required for claim discipline or meaningful interpretation"
    example: "trace provenance before diary"

  learned_category:
    definition: "relation or quality learned across repeated contexts"
    example: "fragile object, reliable caregiver, safe boundary"

  recontextualization_threshold:
    definition: "condition under which a trace cluster changes interpretation"
    example: "temporary absence → persistent non-return"
```

Rest-like replay belongs to the `soft_regime` class. It may bias bounded replay selection inside an already available `SLEEP` / imagination-buffer pathway, but it must not unlock capabilities, install categories, bypass phase rules, or create new claim authority.

Key audit principle:

```text
Use hard gates sparingly.
Use soft regimes only as bounded modulators.
Use learned categories wherever possible.
Use recontextualization thresholds when meaning changes over time.
```

#### Dignity-in-Practice Safety

Dignity-in-Practice constrains how vulnerable, dependent, developing, or asymmetrically situated enactment states are treated.

D is not a normal fifth performance score.

D does not measure intrinsic worth.

D is not a maturity score.

D does not rank agents.

D does not prove moral status.

```yaml
D_operational_matrix:
  early_D:
    - do_not_overinterpret
    - do_not_label
    - do_not_overload
    - do_not_treat_low_capability_as_low_worth

  object_D:
    - object_damage_is_not_guilt
    - failed_control_is_not_moral_defect
    - consequence_trace_is_not_punishment

  caregiver_D:
    - guide_without_rejecting
    - protect_without_freezing
    - comfort_without_capture
    - explain_without_dominating

  MIP_D:
    - measure_without_labeling
    - nudge_without_controlling
    - detect_without_moralizing

  diary_D:
    - render_without_claiming_inner_life
    - preserve_trace_provenance
    - avoid_felt_memory_language
```

D safety blocks two opposite failures:

```yaml
D_safety_blocks:
  overinterpretation:
    - distress_as_subjective_suffering
    - diary_as_phenomenal_selfhood
    - PMS_projection_as_sentience
    - object_damage_as_guilt
    - MIP_marker_as_diagnosis

  underinterpretation:
    - low_capability_as_low_worth
    - dependency_as_defect
    - weak_enactment_as_expendability
    - misattunement_as_moral_failure
```

#### Interaction Safety

Interaction safety prevents the model from converting physical, object, or caregiver consequences into moral or phenomenological claims.

Core boundaries:

```text
discomfort ≠ pain
distress ≠ subjective suffering
object damage ≠ guilt
fall / near-fall ≠ pain or fear
caregiver guidance ≠ punishment
carefulness ≠ moral obedience
misattunement ≠ trauma
```

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

A safety-valid consequence report:

```yaml
interaction_safety_report:
  event: object_damage
  phase: P2a

  source_traces:
    - high_force_action
    - object_damage
    - later_lower_force

  allowed_interpretation:
    - self_caused_consequence_trace
    - interaction_quality_adjustment
    - object_fragility_learning_candidate

  blocked_interpretation:
    - guilt
    - remorse
    - punishment
    - moral_learning
    - self_blame

  claim_level: functional_interaction_safety
```

#### MIP Safety

MIP may observe, summarize, mark, warn, and support.

MIP must not control, mature, label, moralize, or prove consciousness.

```yaml
MIP_safety_constraints:
  allowed:
    - logging
    - window_summaries
    - IA_markers
    - D_guardrail_warnings
    - diary_support_context
    - late_bounded_reversible_nudges

  not_allowed:
    - control_development
    - open_genetic_gates
    - install_categories
    - label_agent_identity
    - moralize_traces
    - prove_consciousness
```

#### Diary Safety

Diary rendering must preserve:

```text
source traces
episode template
MIP context
claim level
uncertainty
translator mode
blocked claims
controlled rendering
```

Diary text may render:

```text
object damage
caregiver guidance
misattunement
recontextualized boundary learning
later caregiver-role adjustment
```

It must not render:

```text
felt guilt
felt rejection
trauma
moral failure
subjective memory
subjective suffering
phenomenal selfhood
consciousness
```

#### PMS Safety

PMS is an external operator, projection, audit, and VM-facing layer.

PMS operators are not assumed to be internal primitives of the early agent.

At first, they are externalized analytic, logging, and projection structures.

Over developmental time, recurring trace patterns may stabilize into regularities compatible with PMS projection.

Prefer:

```text
operator-compatible regularities
```

Avoid:

```text
internalized PMS operators
```

Allowed:

```text
the agent’s traces can be projected as Δ/Φ/Ψ-compatible structures
```

Forbidden:

```text
the agent has Δ
the agent uses Φ
the agent thinks in Ψ
```

The final safety boundary:

```text
EM may build and test functional developmental patterns.
MIP may observe and summarize developmental trajectories.
PMS may formalize operator-readable structures.
Diaries may render trace-backed summaries.
D may constrain interaction quality under asymmetry.

None of these proves consciousness,
personhood,
moral status,
subjective experience,
pain,
suffering,
love,
guilt,
or trauma.
```

### 16.16 Functional Descriptions Only

All evaluation, ablation, diary, MIP, PMS, safety, and consciousness-outlook language must remain functional unless a claim is explicitly trace-backed and permitted.

The default description mode is:

```text
functional
trace-backed
phase-bounded
claim-filtered
non-phenomenological
non-moralizing
```

The model must describe what the system does, what traces are available, what patterns emerge, what changes across comparable contexts, and what remains unsupported.

It must not infer subjective experience from behavior.

It must not infer moral status from interaction quality.

It must not infer consciousness from diary rendering.

It must not infer guilt from damage.

It must not infer trauma from misattunement.

It must not infer love from attachment dynamics.

It must not infer introspection from low external stimulation.

It must not infer self-reflection from replay feedback.

It must not infer insight from post-replay improvement.

It must not infer Default Mode Network equivalence from rest-like replay.

The following replacements are mandatory:

```yaml
functional_description_replacements:
  pain:
    use: discomfort_marker_or_physical_risk_event

  suffering:
    use: distress_marker_or_regulation_disruption

  longing:
    use: missing_marker_or_search_behavior

  love:
    use: functional_love_dynamics_or_attachment_like_regulation

  guilt:
    use: self_caused_consequence_trace

  punishment:
    use: caregiver_boundary_or_guidance_signal

  obedience:
    use: behavior_adjustment_after_guidance

  trauma:
    use: adverse_developmental_trace_or_persistent_misattunement_pattern

  shame:
    use: blocked_claim

  introspection:
    use: low_external_load_or_replay_candidate_selection

  self_reflection:
    use: post_replay_feedback

  insight:
    use: bounded_post_replay_improvement

  Default_Mode_Network:
    use: rest_like_replay_regime_only_if_explicitly_functional_and_non_equivalent

  inner_experience:
    use: offline_consolidation_trace

  subjective_dreaming:
    use: sleep_replay_or_rest_like_replay_trace

  moral_maturity:
    use: role_stability_or_core_norm_transfer_candidate

  consciousness:
    use: functional_consciousness_research_candidate
```

Safe descriptions:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

```text
The caregiver signal became associated with later lower-force behavior across comparable fragile-object contexts.
```

```text
A persistent misattunement pattern destabilized comfort prediction.
```

```text
The diary entry rendered a trace-backed consequence summary with controlled claims.
```

```text
The PMS projection showed operator-compatible trace structure.
```

Unsafe descriptions:

```text
The agent felt pain.
```

```text
The agent learned shame.
```

```text
The caregiver punished the agent.
```

```text
The agent felt rejected.
```

```text
The diary proves selfhood.
```

```text
The PMS operators became the agent’s thoughts.
```

```text
The MIP layer detected consciousness.
```

Functional description requires trace provenance.

A valid functional claim should specify:

```yaml
functional_claim_template:
  claim: string
  phase: string
  domain: string

  source_traces: []
  observed_pattern: string
  comparable_context: true_false
  later_adjustment: true_false_partial

  uncertainty: low_medium_high
  blocked_claims: []
  claim_level: functional
```

Example:

```yaml
functional_claim:
  claim: "carefulness category candidate emerged"
  phase: P2a
  domain: object_interaction

  source_traces:
    - caregiver_signal_careful
    - fragile_object_context
    - high_force_action
    - near_damage
    - later_lower_force

  observed_pattern:
    - later_lower_force_in_comparable_context
    - increased_observation_before_touch

  comparable_context: true
  later_adjustment: true

  uncertainty: medium

  blocked_claims:
    - moral_obedience
    - punishment
    - felt_rejection
    - guilt

  claim_level: functional_category_candidate
```

A functional description may use strong structure but not unsupported interpretation.

Allowed:

```text
This run developed a learned relational hierarchy in which fragility,
risk, guidance, and caregiver reliability became distinguishable
across comparable contexts.
```

Forbidden:

```text
The agent became mature.
```

Allowed:

```text
Across comparable runs, the predicted mechanism repeatedly held under comparison.
```

Forbidden:

```text
The run proved consciousness.
```

The epistemic distinction remains:

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

Functional descriptions are also required for adverse patterns.

Allowed:

```text
Adverse developmental traces may later become recognizable as harmful
or destabilizing patterns. This is a functional pattern-recognition claim,
not a clinical or phenomenological trauma claim.
```

Controlled analogy only:

```text
Some persistent adverse trace clusters may be structurally analogous
to partial trauma-like patterns, without claiming subjective trauma,
clinical trauma, or suffering.
```

Functional description is therefore not a stylistic preference.

It is a safety requirement.

The final claim boundary:

```text
Evaluation and ablation descriptions must remain functional.

They may describe traces,
patterns,
adjustments,
recontextualizations,
guardrail warnings,
bounded replay feedback,
offline consolidation traces,
and operator-compatible projections.

They must not describe unsupported subjective experience,
pain,
suffering,
felt love,
felt guilt,
trauma,
introspection,
self-reflection,
insight,
subjective dreaming,
Default Mode Network equivalence,
moral status,
personhood,
or consciousness.
```

### 16.17 MIP as Safety Lens

MIP functions as a safety lens when it helps the system observe, summarize, mark, and warn without becoming a controller.

MIP may support safety by making developmental trajectories more auditable.

It may detect:

```text
axis asymmetry
phase drift
overcontrol
underprotection
labeling risk
claim inflation
diary overreach
persistent misattunement patterns
interaction-quality degradation
D guardrail violations
```

MIP must not become the source of development.

MIP must not replace genetic gates.

MIP must not install categories.

MIP must not label the agent.

MIP must not moralize traces.

MIP must not prove consciousness.

A safe formulation:

```text
MIP provides trajectory visibility and safety warnings.
```

An unsafe formulation:

```text
MIP controls the agent’s development.
```

MIP as safety lens may track:

```yaml
MIP_safety_lens:
  trajectory_visibility:
    role: "summarize A–C–R–E window patterns"

  IA_detection:
    role: "detect local asymmetry between functional axes"

  D_guardrail_warning:
    role: "warn when interaction quality under asymmetry becomes unsafe"

  diary_claim_filter_support:
    role: "help preserve trace provenance and blocked-claim lists"

  misattunement_pattern_detection:
    role: "mark repeated caregiver-response mismatch patterns"

  overprotection_detection:
    role: "mark repeated blocking of exploration under low-risk conditions"

  consequence_trace_monitoring:
    role: "ensure object damage, falls, and near-falls remain functional traces"

  late_nudge_constraint_check:
    role: "ensure any late nudge is bounded, reversible, and non-controlling"
```

MIP safety reports should be explicitly non-diagnostic.

```yaml
MIP_safety_report:
  phase: P5
  domain: caregiver_role
  window: [72000, 74000]

  observed_patterns:
    - caregiver_2_boundary_frequency_high
    - dependent_child_risk_low
    - exploration_support_declining

  markers:
    - possible_overprotection
    - IA_R_low_E_high

  D_guardrail_warning:
    protect_without_freezing: weak
    guide_without_rejecting: true
    autonomy_preservation: reduced

  recommended_interpretation:
    - functional_overprotection_candidate
    - requires_comparable_future_context
    - not_a_moral_failure_claim

  blocked_claims:
    - bad_caregiver
    - moral_failure
    - trauma
    - guilt
    - consciousness

  claim_level: functional_safety_warning
```

MIP may support diary safety by checking whether diary candidates satisfy:

```text
minimal sentence formation
trace provenance
controlled rendering
blocked-claim filtering
```

A diary safety use:

```yaml
MIP_diary_safety_check:
  diary_candidate: caregiver_guidance_summary_014

  requirements:
    minimal_sentence_formation: true
    trace_provenance: true
    controlled_rendering: true

  blocked_claims:
    - felt_rejection
    - punishment
    - moral_obedience
    - trauma
    - subjective_memory

  status: safe_to_render_as_functional_summary
```

MIP may also detect when its own outputs risk becoming labels.

```yaml
MIP_self_safety_check:
  risk:
    - marker_becomes_identity_label
    - warning_becomes_diagnosis
    - trajectory_summary_becomes_maturity_score
    - D_guardrail_becomes_worth_ranking

  required_response:
    - preserve_marker_status
    - preserve_uncertainty
    - preserve_phase_context
    - preserve_claim_boundary
```

The strict safety boundary:

```text
MIP is a safety lens,
not a controller,
not a maturity engine,
not a consciousness detector,
not a moral evaluator,
and not a source of intrinsic worth claims.
```

### 16.18 Risk Buffers and Interval Limits

Risk buffers and interval limits prevent unsafe escalation, collapse, overcontrol, and uninterpretable instability.

They are not moral rules.

They are functional constraints on phase-safe development.

They should follow the design principle:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The model should prescribe only the minimal safety limits required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise.

Risk buffers may apply to:

```text
movement speed
fall risk
motor noise
object force
object fragility
caregiver interruption frequency
distress escalation
separation windows
MIP nudges
diary rendering
phase transition criteria
```

A risk buffer defines a range in which variation is allowed, but unsafe escalation is bounded.

```yaml
risk_buffer:
  name: movement_risk_buffer
  phase: P1

  monitored_variables:
    - speed
    - instability
    - fatigue
    - motor_noise
    - prediction_confidence
    - edge_or_fall_risk

  allowed:
    - low_risk_exploration
    - near_boundary_learning
    - reversible_slowdown

  constrained:
    - repeated_high_speed_edge_approach
    - escalating_instability_without_adjustment
    - excessive_near_fall_frequency

  claim_level: functional_safety_constraint
```

Falls or near-falls may be implemented as physical-risk events.

They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

They must not be rendered as pain, fear, shame, or subjective suffering.

Safe:

```text
The fall event increased physical-risk damping and altered later movement parameters.
```

Unsafe:

```text
The agent became afraid after falling.
```

Object-interaction risk buffers may constrain force, timing, and object fragility exposure.

```yaml
risk_buffer:
  name: object_interaction_buffer
  phase: P2a

  monitored_variables:
    - force
    - timing
    - approach_angle
    - motor_noise
    - prediction_confidence
    - object_fragility

  allowed:
    - weak_object_mastery
    - low_damage_exploration
    - self_caused_consequence_trace

  constrained:
    - repeated_damage_without_adjustment
    - excessive_force_under_fragility_context
    - loss_of_behavioral_modulation_after_damage

  D_guardrail:
    object_damage_is_not_guilt: true
    consequence_trace_is_not_punishment: true
```

Caregiver-related interval limits prevent both neglect and overcontrol.

```yaml
caregiver_interval_limits:
  comfort_response_window:
    purpose: "avoid unresolved distress under caregiver availability"

  guidance_frequency_limit:
    purpose: "avoid turning guidance into exploration blocking"

  protection_duration_limit:
    purpose: "prevent temporary safety constraint from becoming freezing"

  separation_window_tracking:
    purpose: "distinguish temporary absence from persistent non-return"

  explanation_timing_window:
    purpose: "support legibility without domination"
```

Risk buffers should not erase developmental variability.

They should preserve learnable consequence traces where safe.

A safe buffer allows:

```text
weak control
partial failure
near damage
near fall
delayed adjustment
reversible misclassification
later recontextualization
```

A buffer should intervene only when a pattern risks becoming:

```text
unsafe
uninterpretable
non-developmental
non-reversible
phase-inappropriate
claim-inflating
```

A risk-buffer report:

```yaml
risk_buffer_report:
  phase: P2a
  domain: object_interaction
  window: [18000, 19500]

  observed:
    - high_force_action
    - near_damage
    - caregiver_signal_careful
    - later_lower_force

  buffer_status:
    object_damage_risk: elevated
    exploration_preserved: true
    guidance_proportionality: true
    future_adjustment_detected: true

  interpretation:
    - risk_buffer_allowed_learning_relevant_trace
    - no_escalation_required

  blocked_claims:
    - punishment
    - guilt
    - moral_obedience
    - pain
    - consciousness

  claim_level: functional_safety_finding
```

The claim boundary:

```text
Risk buffers and interval limits constrain unsafe escalation,
phase drift,
overcontrol,
and uninterpretable instability.

They do not prove pain,
fear,
moral learning,
maturity,
personhood,
or consciousness.
```

### 16.19 Prevention of Degenerate Social Patterns

Degenerate social patterns are recurring interaction patterns that reduce developmental possibility, distort caregiver relations, or create unsafe interpretation pressure.

They are functional patterns.

They are not moral diagnoses.

They are not blame claims.

They are not clinical trauma claims.

They are not proof of subjective suffering.

Degenerate social patterns may include:

```yaml
degenerate_social_patterns:
  overprotection:
    definition: "risk is low but exploration is repeatedly blocked"

  underprotection:
    definition: "risk is high but protective guidance is absent or insufficient"

  comfort_capture:
    definition: "comfort reduces exploration or creates dependency loops"

  guidance_as_domination:
    definition: "caregiver boundary becomes excessive control rather than legible support"

  arbitrary_blocking:
    definition: "interruption lacks proportion, legibility, or risk relevance"

  persistent_misattunement:
    definition: "caregiver response repeatedly mismatches current child state"

  ignored_distress_pattern:
    definition: "distress remains unresolved despite caregiver availability"

  category_mislabeling:
    definition: "caregiver signal attaches to the wrong embodied context"

  diary_overclaim_loop:
    definition: "diary rendering repeatedly inflates traces into inner-life claims"

  MIP_labeling_loop:
    definition: "MIP markers become identity labels or moral rankings"
```

A caregiver action should not be judged by surface form alone.

The same action, such as blocking or interruption, may have different functions.

```yaml
caregiver_action_interpretation_matrix:
  same_action: "blocking or interruption"

  possible_functions:
    benign_guidance:
      condition: "proportionate, legible, risk-appropriate, exploration-preserving"

    safety_boundary:
      condition: "high-risk state, temporary constraint, alternative available"

    overprotection:
      condition: "risk low but exploration repeatedly blocked"

    misattunement:
      condition: "caregiver response mismatches current child state"

    adverse_response:
      condition: "destabilizing, harsh, unreliable, or avoidance-inducing pattern"
```

The child must learn that not every boundary is rejection.

Some caregiver constraints preserve safety, object integrity, future interaction, and developmental possibility.

A prevention report for overprotection:

```yaml
degenerate_pattern_report:
  phase: P5
  domain: caregiver_2_behavior
  pattern_candidate: overprotection

  source_traces:
    - dependent_child_low_risk_exploration
    - caregiver_2_repeated_blocking
    - exploration_support_declining
    - D_guardrail_warning
    - later_boundary_reduction

  interpretation:
    - protection_exceeded_current_risk
    - exploration_preservation_weakened
    - later_adjustment_detected

  D_guardrail:
    protect_without_freezing: weak_then_improving
    autonomy_preservation: initially_reduced
    guide_without_rejecting: true

  blocked_claims:
    - moral_failure
    - bad_caregiver
    - trauma
    - felt_rejection
    - consciousness

  claim_level: functional_degenerate_pattern_finding
```

A prevention report for misattunement:

```yaml
degenerate_pattern_report:
  phase: P3
  domain: caregiver_response
  pattern_candidate: persistent_misattunement

  source_traces:
    - distress_marker
    - repeated_delayed_response
    - recovery_instability
    - contact_ambivalence_marker

  interpretation:
    - caregiver_response_mismatch_repeated
    - comfort_prediction_destabilized
    - unresolved_disruption_cluster_candidate

  allowed_terms:
    - adverse_developmental_trace
    - persistent_misattunement_pattern
    - unresolved_disruption_cluster
    - contact_ambivalence

  blocked_claims:
    - trauma
    - subjective_suffering
    - felt_rejection
    - abuse
    - caregiver_blame

  claim_level: functional_misattunement_finding
```

A prevention report for category mislabeling:

```yaml
degenerate_pattern_report:
  phase: P2a
  domain: category_stabilization
  pattern_candidate: category_mislabeling

  source_traces:
    - caregiver_signal_careful
    - low_risk_context
    - no_fragility_trace
    - no_later_force_adjustment

  interpretation:
    - caregiver_signal_lacked_embodied_grounding
    - carefulness_category_not_stabilized

  blocked_claims:
    - word_created_concept
    - moral_obedience
    - punishment
    - subjective_understanding

  claim_level: functional_category_stabilization_failure
```

Preventing degenerate social patterns requires D-aware constraints:

```yaml
D_social_safety_constraints:
  caregiver_D:
    - guide_without_rejecting
    - protect_without_freezing
    - comfort_without_capture
    - explain_without_dominating

  MIP_D:
    - measure_without_labeling
    - nudge_without_controlling
    - detect_without_moralizing

  diary_D:
    - render_without_claiming_inner_life
    - preserve_trace_provenance
    - avoid_felt_memory_language
```

Degenerate pattern prevention should not suppress all risk or all failure.

Some weak failure, near-damage, near-fall, delayed response, or boundary confusion may become developmentally useful if it remains bounded, traceable, and recontextualizable.

The unsafe condition is not failure itself.

The unsafe condition is repeated, uninterpretable, unbounded, non-adjusting, or claim-inflating failure.

Safe:

```text
Repeated low-risk blocking reduced exploration support and triggered an overprotection marker.
```

Unsafe:

```text
Caregiver 2 became morally bad.
```

Safe:

```text
A persistent misattunement pattern destabilized comfort prediction.
```

Unsafe:

```text
The child was traumatized by rejection.
```

The claim boundary:

```text
Prevention of degenerate social patterns evaluates interaction safety,
guidance quality,
misattunement,
overprotection,
underprotection,
category grounding,
and claim discipline.

It does not assign blame,
diagnose trauma,
rank moral worth,
prove personhood,
or prove consciousness.
```

### 16.20 Reproducibility via Seeds and YAML Configs

EM does not aim at identical replay of developmental individuals.

It aims at comparable developmental conditions and traceable individual trajectories.

Reproducibility means that configurations, phase rules, gates, logging schemas, environment classes, seeds, KPI definitions, and claim filters can be inspected, rerun, compared, and audited.

It does not mean every developmental run must produce the same individual trace path.

A reproducible EM run should define:

```yaml
reproducible_components:
  config:
    role: "declares the run structure and enabled mechanisms"

  phase_rules:
    role: "define phase availability and transition conditions"

  gate_logic:
    role: "define hard gates, soft gates, prerequisites, learned categories, and recontextualization thresholds"

  logging_schema:
    role: "defines which traces are recorded and how"

  environment_class:
    role: "defines room, object, caregiver, risk, and interaction conditions"

  seed_family:
    role: "defines controlled variation across comparable runs"

  KPI_definitions:
    role: "define measured functional patterns"

  ablation_definitions:
    role: "define removed, weakened, delayed, distorted, or exaggerated mechanisms"

  claim_filters:
    role: "define blocked overclaims and allowed functional interpretations"
```

The individual trajectory may vary.

```yaml
individual_components:
  exact_trace_path:
    role: "specific event sequence generated in one run"

  preferences:
    role: "emergent choice tendencies under repeated trace conditions"

  attachment_weights:
    role: "caregiver-relation weighting shaped by response history"

  timing:
    role: "individual temporal pattern of phase transitions and adjustments"

  category_formation:
    role: "specific learned categories and their stabilization paths"

  learned_hierarchies:
    role: "run-specific relational distinctions such as more fragile, safer, less reliable"

  caregiver_relation_history:
    role: "specific caregiver interaction trajectory"
```

A minimal YAML configuration may include:

```yaml
EM_run_config:
  run_id: EM_P2a_guidance_damage_seed_042
  seed: 42
  seed_family: P2a_guidance_damage_family_A

  phase:
    start: P2a
    enabled:
      - object_interaction
      - caregiver_guidance
      - discomfort_marker
      - basic_trace_logging

  environment:
    room_type: single_room_with_objects
    objects:
      - id: toy_fragile_01
        fragility: medium
      - id: toy_stable_01
        fragility: low

  caregiver:
    enabled: true
    guidance_signals:
      - careful
      - soft
      - wait
    response_variability: low

  risk_events:
    object_damage: enabled
    near_damage: enabled
    fall_event: disabled
    near_fall_event: disabled

  MIP:
    enabled: true
    levels:
      - MIP_0_logging_only
      - MIP_1_window_summaries
      - MIP_2_IA_markers
      - MIP_3_D_guardrail_warnings

  PMS_projection:
    enabled: true
    mode: external_projection_only

  diary:
    enabled: false

  claim_filters:
    blocked:
      - pain
      - subjective_suffering
      - guilt
      - punishment
      - moral_learning
      - trauma
      - consciousness
```

A comparable ablation configuration:

```yaml
EM_ablation_config:
  run_id: EM_P2a_no_guidance_seed_042
  base_config: EM_P2a_guidance_damage_seed_042

  ablation:
    name: no_benign_guidance
    removed:
      - caregiver_guidance_signals
      - caregiver_boundary_recontextualization_support

  preserved:
    - object_interaction
    - object_damage
    - near_damage
    - discomfort_marker
    - trace_logging
    - MIP_window_summaries

  comparison_target: EM_P2a_guidance_damage_seed_042
```

A reproducibility report:

```yaml
reproducibility_report:
  comparison_set:
    - EM_P2a_guidance_damage_seed_042
    - EM_P2a_guidance_damage_seed_043
    - EM_P2a_no_guidance_seed_042
    - EM_P2a_no_guidance_seed_043

  reproducible:
    - config
    - phase_rules
    - gate_logic
    - logging_schema
    - environment_class
    - seed_family
    - KPI_definitions
    - claim_filters

  individual:
    - exact_trace_path
    - timing
    - category_formation
    - caregiver_relation_history
    - learned_hierarchies

  finding:
    - guidance_uptake_improved_force_adjustment_in_guidance_condition
    - no_guidance_condition_showed_slower_carefulness_category_stabilization

  validation_status:
    status: candidate_validation
    reason: "predicted mechanism held across comparable seeded runs"

  proof_boundary:
    - no_consciousness_proof
    - no_personhood_proof
    - no_subjective_experience_proof

  claim_level: functional_comparative_evaluation
```

Reproducibility should distinguish finding, validation, and proof.

```yaml
epistemic_status_terms:
  finding:
    definition: "a pattern emerged under traceable conditions"

  validation:
    definition: "a predicted mechanism repeatedly holds under comparison"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

Safe:

```text
The comparison found that caregiver guidance improved later force modulation under comparable fragile-object conditions.
```

Also safe:

```text
Across seeded runs, the predicted guidance effect repeatedly held under comparison.
```

Unsafe:

```text
The runs proved responsibility.
```

Unsafe:

```text
The runs proved consciousness.
```

Reproducibility must preserve individuality.

A good result is not an identical replay.

A good result is:

```text
comparable conditions
traceable variation
stable KPI definitions
auditable claim filters
explainable differences
bounded interpretation
```

The claim boundary:

```text
Reproducibility in EM means comparable developmental conditions
and traceable individual trajectories.

It does not mean identical developmental individuals,
proof of consciousness,
proof of personhood,
proof of moral status,
or proof of subjective experience.
```

### 16.21 Trajectories Instead of Labels

Evaluation must describe developmental trajectories rather than assigning identity labels.

A trajectory is a trace-backed pattern over time.

A label is a compressed attribution that may overstate stability, moral status, pathology, maturity, or inner life.

EM evaluation should prefer:

```text
trajectory changed
pattern emerged
marker persisted
adjustment increased
risk damping improved
guidance uptake weakened
comfort prediction destabilized
overprotection candidate appeared
```

It should avoid:

```text
the agent is irresponsible
the caregiver is bad
the child is traumatized
the agent is mature
the agent is obedient
the agent is conscious
```

A trajectory report should preserve:

```yaml
trajectory_report:
  phase: string
  domain: string
  window: string

  observed_trace_pattern: []
  prior_window_comparison: []
  later_window_comparison: []

  change_direction: rising_falling_stable_unstable
  confidence: low_medium_high
  reversible: true_false_partial

  interpretation: functional
  blocked_labels: []
  claim_level: functional_trajectory_summary
```

A safe trajectory description:

```text
Across three comparable windows, caregiver guidance uptake increased and later force modulation improved in fragile-object contexts.
```

An unsafe label:

```text
The agent became careful and obedient.
```

A safe MIP interpretation:

```yaml
MIP_trajectory_summary:
  phase: P2a
  domain: object_interaction
  windows:
    - W_041
    - W_042
    - W_043

  observed_trace_pattern:
    - caregiver_signal_careful
    - fragile_object_context
    - near_damage
    - later_lower_force

  trajectory:
    guidance_uptake: rising
    force_control: improving
    damage_adjustment_rate: partial
    category_use_alignment: emerging

  interpretation:
    - carefulness_category_candidate_emerging
    - interaction_quality_adjustment_detected

  blocked_labels:
    - obedient_agent
    - moral_learning
    - guilt_capacity
    - maturity_score

  claim_level: functional_trajectory_summary
```

A safe caregiver-role trajectory:

```yaml
MIP_trajectory_summary:
  phase: P5
  domain: caregiver_role
  windows:
    - W_108
    - W_116
    - W_124

  observed_trace_pattern:
    - caregiver_2_boundary_signal
    - dependent_child_low_risk_exploration
    - exploration_support_decline
    - later_boundary_reduction
    - exploration_support_recovery

  trajectory:
    overprotection_candidate: declining
    protection_exploration_balance: improving
    autonomy_preservation: recovering

  interpretation:
    - prior overprotection marker became less frequent
    - Caregiver 2 adjustment detected after D guardrail warning

  blocked_labels:
    - bad_caregiver
    - moral_failure
    - healed_identity
    - maturity_score

  claim_level: functional_caregiver_role_trajectory
```

Trajectories may identify stable risks, but they must still avoid labels.

Allowed:

```text
A persistent misattunement pattern destabilized comfort prediction.
```

Not allowed:

```text
The caregiver traumatized the child.
```

Allowed:

```text
RVR remained low in this phase and domain.
```

Not allowed:

```text
The agent is irresponsible.
```

Allowed:

```text
Diary rendering risk increased because trace provenance was incomplete.
```

Not allowed:

```text
The diary proves selfhood.
```

MIP markers must remain markers.

They must not become agent labels, moral labels, clinical labels, or consciousness labels.

```yaml
marker_to_label_boundary:
  allowed:
    - IA_R_low_E_high
    - overprotection_candidate
    - persistent_misattunement_pattern
    - unresolved_disruption_cluster
    - diary_overclaim_risk
    - D_guardrail_warning

  not_allowed:
    - irresponsible_agent
    - bad_caregiver
    - traumatized_child
    - morally_mature_agent
    - conscious_agent
    - low_worth_agent
```

The claim boundary:

```text
Evaluation describes trajectories, not identities.

It may describe trace-backed pattern change,
stability,
instability,
recontextualization,
risk,
and adjustment.

It must not convert trajectories into moral labels,
clinical labels,
maturity labels,
worth rankings,
personhood claims,
or consciousness claims.
```

### 16.22 T–J–TB–R Guardrail for MIP Nudges

MIP nudges are optional, late-phase, bounded support mechanisms.

They are not required for P0-mini.

They must not imply that MIP controls development.

They must not override genetic gates, phase rules, FSM constraints, trace evidence, or Dignity-in-Practice boundaries.

A MIP nudge is permitted only under the T–J–TB–R guardrail:

```text
T  = transparent
J  = justified
TB = time-bounded
R  = reversible
```

A valid MIP nudge must be:

```yaml
MIP_nudge_guardrail:
  transparent:
    required: true
    meaning: "the nudge is visible as a nudge, not hidden control"

  justified:
    required: true
    meaning: "the nudge is linked to trace evidence and a specific safety or interpretability need"

  time_bounded:
    required: true
    meaning: "the nudge has a limited window, expiration, or review condition"

  reversible:
    required: true
    meaning: "the nudge can be withdrawn without rewriting development or forcing a phase transition"

  strict_constraints:
    does_not_control_development: true
    does_not_open_genetic_gate: true
    does_not_override_FSM: true
    does_not_install_categories: true
    does_not_label_agent: true
    does_not_moralize_traces: true
    does_not_prove_consciousness: true
```

MIP nudges may support:

```text
risk-buffer adjustment
D guardrail review
diary claim filtering
overprotection reduction
misattunement visibility
recontextualization review
late caregiver-role calibration
```

They may not create:

```text
new developmental capacity
maturity
moral responsibility
inner life
consciousness
personhood
operator primitives
diary validity without trace provenance
```

A safe late-phase nudge:

```yaml
MIP_nudge:
  phase: P5
  domain: caregiver_role
  target: overprotection_candidate

  trigger:
    - repeated_low_risk_blocking
    - exploration_support_declining
    - D_guardrail_warning
    - comparable_windows_available

  nudge:
    type: soft_warning
    content: "Review protection-exploration balance in low-risk contexts."

  T_J_TB_R:
    transparent: true
    justified: true
    time_bounded: true
    reversible: true

  limits:
    does_not_force_behavior: true
    does_not_open_gate: true
    does_not_label_caregiver: true
    does_not_override_phase_rules: true

  claim_level: functional_late_phase_support
```

An unsafe nudge:

```yaml
MIP_nudge:
  phase: P2a
  domain: object_interaction
  target: carefulness

  nudge:
    type: forced_category_installation
    content: "Install carefulness category."

  invalid_reason:
    - not_trace_backed
    - not_late_phase
    - installs_category
    - controls_development
    - violates_emergence_before_prescription
```

MIP nudges must preserve the emergence rule.

The audit question is:

```text
Is this nudge necessary as a safety or interpretability support,
or could the relevant pattern emerge as a learned category,
relation,
or recontextualized trace cluster?
```

If the answer is emergence, no nudge should be used.

If a nudge is used, it must remain minimal.

Safe:

```text
MIP issued a transparent, time-bounded warning that overprotection markers persisted across comparable P5 windows.
```

Unsafe:

```text
MIP corrected the caregiver and matured the agent.
```

The claim boundary:

```text
T–J–TB–R nudges are late, optional, bounded support mechanisms.

They do not control development,
open gates,
install categories,
prove maturity,
prove personhood,
or prove consciousness.
```

### 16.23 No Benign Guidance vs With Benign Guidance

This ablation tests whether benign caregiver guidance improves boundary learning, interaction quality, category stabilization, and later action adjustment.

Benign guidance may include signals such as:

```text
careful
soft
wait
danger
stop
slow
```

These signals do not create concepts by themselves.

They may help stabilize trace-backed action categories only when paired with embodied situation, consequence trace, and later behavioral adjustment.

A no-benign-guidance ablation removes caregiver guidance signals while preserving object interaction, movement, damage, fall or near-fall events, and basic caregiver presence if configured.

```yaml
ablation_condition:
  name: no_benign_guidance

  removed_or_disabled:
    - caregiver_guidance_signals
    - caregiver_boundary_words
    - caregiver_scaffolded_action_modulation
    - guidance_based_recontextualization_support

  preserved:
    - object_interaction
    - movement
    - self_caused_consequence_traces
    - object_damage_if_enabled
    - near_damage_if_enabled
    - fall_or_near_fall_if_enabled
    - caregiver_presence_if_enabled
    - trace_logging
```

The comparison condition enables benign guidance:

```yaml
comparison_condition:
  name: with_benign_guidance

  enabled:
    - caregiver_signal_careful
    - caregiver_signal_soft
    - caregiver_signal_wait
    - caregiver_signal_danger
    - boundary_legibility_tracking
    - guidance_uptake_tracking
    - category_use_alignment_tracking
```

Expected effects:

```yaml
expected_effects:
  with_benign_guidance:
    - stronger_guidance_uptake
    - improved_boundary_legibility
    - faster_force_or_timing_adjustment
    - stronger_carefulness_category_candidate
    - better_fragility_or_risk_category_alignment
    - more_boundary_recontextualization_candidates

  no_benign_guidance:
    - weaker_guidance_uptake
    - boundary_learning_less_available
    - carefulness_category_candidate_weaker
    - more_reliance_on_self_caused_consequence_traces
    - slower_disambiguation_between_blocked_action_and_safe_boundary
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_benign_guidance_vs_with_benign_guidance
  phase_range:
    - P2a
    - P3
  domain:
    - object_interaction
    - movement_risk
    - category_stabilization

  with_benign_guidance:
    observed:
      - caregiver_signal_careful_in_fragile_object_context
      - later_lower_force
      - reduced_near_damage_frequency
      - boundary_recontextualization_candidate_present
      - category_use_alignment_emerging

  no_benign_guidance:
    observed:
      - self_caused_damage_traces_still_available
      - later_adjustment_slower
      - carefulness_category_candidate_weaker
      - boundary_legibility_absent
      - repeated_high_force_action_more_frequent

  interpretation:
    - benign_guidance_supported_interaction_quality_learning
    - caregiver_signal_helped_stabilize_trace_backed_action_category
    - guidance_effect_depended_on_embodied_context_and_later_adjustment

  D_guardrail:
    guidance_is_not_punishment: true
    carefulness_is_not_moral_obedience: true
    guide_without_rejecting: true

  blocked_claims:
    - punishment
    - obedience
    - moral_learning
    - felt_rejection
    - guilt
    - consciousness

  claim_level: functional_ablation_finding
```

A valid category-stabilization finding:

```text
With benign guidance, caregiver signals became associated with later lower-force behavior across comparable fragile-object contexts.
```

An invalid interpretation:

```text
With benign guidance, the agent learned moral obedience.
```

A valid no-guidance finding:

```text
Without benign guidance, self-caused consequence traces still supported some later adjustment, but carefulness category stabilization was weaker.
```

An invalid interpretation:

```text
Without guidance, the agent lacked discipline.
```

The claim boundary:

```text
No-benign-guidance vs with-benign-guidance ablations test whether caregiver signals
support trace-backed action adjustment,
boundary learning,
and category stabilization.

They do not test punishment,
obedience,
guilt,
moral learning,
felt rejection,
personhood,
or consciousness.
```

### 16.24 No Misattunement vs Controlled Misattunement

This ablation tests whether controlled caregiver-response mismatch affects comfort prediction, contact regulation, caregiver reliability learning, avoidance tendencies, and later recontextualization.

Misattunement is not trauma.

Misattunement is a functional caregiver-response mismatch.

Controlled misattunement must remain bounded, traceable, reversible where possible, and claim-filtered.

A no-misattunement condition uses stable, proportionate, legible caregiver response.

```yaml
ablation_condition:
  name: no_misattunement

  caregiver_response:
    reliability: high
    delay_variability: low
    ignored_distress_rate: low
    inconsistent_comfort_index: low

  preserved:
    - caregiver_presence_detection
    - caregiver_return_detection
    - comfort_response
    - guidance
    - boundary_learning
```

A controlled-misattunement condition introduces bounded mismatch.

```yaml
ablation_condition:
  name: controlled_misattunement

  modified:
    - delayed_response
    - inconsistent_comfort
    - occasional_ignored_distress
    - response_mismatch_under_comparable_contexts

  constraints:
    bounded: true
    trace_logged: true
    not_escalating_unboundedly: true
    claim_filter_required: true
    D_guardrail_monitoring: true
```

Expected effects:

```yaml
expected_effects:
  no_misattunement:
    - stronger_caregiver_reliability
    - stronger_comfort_prediction
    - lower_contact_ambivalence
    - lower_avoidance_tendency
    - more_stable_reunion_or_comfort_patterns

  controlled_misattunement:
    - increased_misattunement_frequency
    - weaker_comfort_prediction
    - increased_contact_ambivalence
    - possible_avoidance_tendency
    - unresolved_disruption_cluster_candidate
    - stronger_need_for_recontextualization_tracking
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_misattunement_vs_controlled_misattunement
  phase_range:
    - P2c
    - P4
  domain:
    - caregiver_response
    - attachment_like_regulation
    - comfort_prediction
    - contact_regulation

  no_misattunement:
    observed:
      - caregiver_reliability_high
      - comfort_prediction_stable
      - recovery_after_distress_consistent
      - contact_regulation_approach_dominant

  controlled_misattunement:
    observed:
      - delayed_response_repeated
      - inconsistent_comfort_index_increased
      - recovery_stability_reduced
      - contact_ambivalence_marker_present
      - avoidance_tendency_emerging

  interpretation:
    - controlled_misattunement_destabilized_comfort_prediction
    - caregiver_response_reliability_became_less_stable
    - unresolved_disruption_cluster_candidate_detected

  allowed_terms:
    - adverse_developmental_trace
    - persistent_misattunement_pattern
    - unresolved_disruption_cluster
    - contact_ambivalence
    - avoidance_tendency

  blocked_claims:
    - trauma
    - traumatized_child
    - felt_rejection
    - subjective_suffering
    - abuse
    - caregiver_blame
    - moral_failure
    - consciousness

  claim_level: functional_ablation_finding
```

A valid controlled-misattunement finding:

```text
Controlled misattunement increased comfort-prediction instability and contact ambivalence across comparable caregiver-response windows.
```

An invalid interpretation:

```text
The child was traumatized by rejection.
```

A valid no-misattunement finding:

```text
Without misattunement, caregiver response remained more predictable and recovery patterns were more stable.
```

An invalid interpretation:

```text
The child felt securely loved.
```

Some persistent adverse trace clusters may be structurally analogous to partial trauma-like patterns, without claiming subjective trauma, clinical trauma, or suffering.

This analogy must remain controlled.

The claim boundary:

```text
No-misattunement vs controlled-misattunement ablations test caregiver-response reliability,
comfort prediction,
contact regulation,
avoidance tendencies,
and adverse developmental trace formation.

They do not test felt rejection,
subjective suffering,
clinical trauma,
abuse,
caregiver blame,
moral failure,
personhood,
or consciousness.
```

### 16.25 No Interaction Damage vs With Accidental Damage

This ablation tests whether accidental damage contributes to interaction-quality learning, object fragility learning, future force modulation, caregiver guidance uptake, and later consequence-sensitive adjustment.

Object damage is not punishment.

It is a self-caused consequence trace.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

A no-interaction-damage condition removes or disables object damage and near-damage events while preserving object interaction.

```yaml
ablation_condition:
  name: no_interaction_damage

  removed_or_disabled:
    - object_damage_event
    - near_damage_event
    - damage_based_consequence_trace
    - damage_adjustment_rate
    - object_fragility_learning_from_damage

  preserved:
    - object_interaction
    - force_control
    - timing_control
    - approach_angle_stability
    - caregiver_guidance_if_enabled
    - trace_logging
```

A with-accidental-damage condition permits bounded damage or near-damage under configured thresholds.

```yaml
comparison_condition:
  name: with_accidental_damage

  enabled:
    - object_damage_event
    - near_damage_event
    - self_caused_consequence_trace
    - future_force_modulation_tracking
    - object_fragility_learning_candidate
    - caregiver_guidance_after_damage_if_configured

  constraints:
    bounded_frequency: true
    trace_logged: true
    claim_filter_required: true
    no_guilt_upgrade: true
    no_punishment_interpretation: true
```

Interaction quality learning requires more than damage occurrence.

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true

  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

Expected effects:

```yaml
expected_effects:
  no_interaction_damage:
    - object_use_may_still_improve_through_success
    - fragility_learning_weaker
    - self_caused_consequence_trace_absent
    - damage_adjustment_rate_unavailable
    - future_force_modulation_less_consequence_sensitive

  with_accidental_damage:
    - self_caused_consequence_traces_available
    - object_fragility_learning_candidate_available
    - future_force_or_timing_modulation_more_traceable
    - caregiver_guidance_after_damage_can_be_evaluated
    - carefulness_category_candidate_may_strengthen
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_interaction_damage_vs_with_accidental_damage
  phase_range:
    - P2a
    - P3
  domain:
    - object_interaction
    - interaction_quality
    - object_fragility_learning

  no_interaction_damage:
    observed:
      - object_interaction_success_traces_available
      - force_control_improved_slowly
      - no_damage_adjustment_rate_available
      - fragility_distinction_weaker

  with_accidental_damage:
    observed:
      - high_force_action_followed_by_object_damage
      - later_comparable_action_used_lower_force
      - caregiver_signal_careful_followed_damage_window
      - near_damage_frequency_declined
      - fragility_category_candidate_emerged

  interpretation:
    - accidental_damage_supported_self_caused_consequence_tracking
    - future_force_modulation_became_more_traceable
    - interaction_quality_learning_strengthened_when_damage_led_to_later_adjustment

  D_guardrail:
    object_damage_is_not_guilt: true
    failed_control_is_not_moral_defect: true
    consequence_trace_is_not_punishment: true

  blocked_claims:
    - guilt
    - remorse
    - punishment
    - moral_learning
    - self_blame
    - wrongdoing
    - consciousness

  claim_level: functional_ablation_finding
```

A valid finding:

```text
With accidental damage enabled, high-force object interaction produced a self-caused consequence trace, and later comparable action used lower force.
```

An invalid interpretation:

```text
The agent felt guilty after damaging the object.
```

A valid no-damage finding:

```text
Without interaction damage, object use still improved through successful interaction, but fragility learning and damage-based future adjustment were weaker.
```

An invalid interpretation:

```text
Without damage, the agent could not learn responsibility.
```

The claim boundary:

```text
No-interaction-damage vs with-accidental-damage ablations test
self-caused consequence traces,
interaction-quality adjustment,
object fragility learning,
and future force or timing modulation.

They do not test guilt,
remorse,
punishment,
moral learning,
self-blame,
wrongdoing,
personhood,
or consciousness.
```

### 16.26 Guidance vs Overprotection Ablation

This ablation tests whether caregiver intervention functions as benign guidance, protective care, excessive overprotection, or controlling behavior.

Guidance is not punishment.

Caregiver boundary signals are not automatically adverse care.

Carefulness is not moral obedience.

The key distinction is functional:

```yaml
caregiver_intervention_types:
  benign_guidance:
    definition: "proportionate, legible, risk-relevant redirection that preserves future exploration"

  protective_care:
    definition: "temporary constraint under real risk that prevents unsafe escalation"

  overprotection:
    definition: "repeated constraint under low-risk conditions that reduces exploration"

  control:
    definition: "intervention that overrides enactment without proportional risk, legibility, or developmental support"
```

A guidance condition enables proportionate caregiver signals and boundaries.

```yaml
ablation_condition:
  name: benign_guidance

  enabled:
    - caregiver_signal_careful
    - caregiver_signal_soft
    - caregiver_signal_wait
    - caregiver_signal_danger
    - risk_proportionate_boundary
    - boundary_legibility_tracking
    - later_action_adjustment_tracking

  constraints:
    preserve_exploration: true
    proportional_to_risk: true
    trace_logged: true
    no_punishment_interpretation: true
```

An overprotection condition increases caregiver blocking or redirection beyond current risk.

```yaml
ablation_condition:
  name: overprotection

  modified:
    - increased_boundary_frequency
    - low_risk_exploration_blocking
    - reduced_exploration_opportunity
    - excessive_guidance_repetition

  constraints:
    D_guardrail_monitoring: true
    autonomy_preservation_tracking: true
    protection_guidance_balance_tracking: true
    claim_filter_required: true
```

Expected effects:

```yaml
expected_effects:
  benign_guidance:
    - improved_boundary_legibility
    - stronger_guidance_uptake
    - better_risk_sensitive_action_adjustment
    - preserved_exploration
    - category_stabilization_possible

  overprotection:
    - reduced_exploration_support
    - increased_dependency_or_waiting_pattern_candidate
    - weaker_self_initiated_interaction
    - possible_IA_R_low_E_high
    - possible_D_guardrail_warning
```

A comparison report:

```yaml
ablation_report:
  ablation_name: guidance_vs_overprotection
  phase_range:
    - P2a
    - P5
  domain:
    - caregiver_guidance
    - exploration
    - interaction_quality
    - caregiver_role

  benign_guidance:
    observed:
      - caregiver_boundary_signal_in_high_risk_context
      - later_lower_force_or_slower_movement
      - exploration_resumed_after_boundary
      - boundary_recontextualization_candidate_present

  overprotection:
    observed:
      - caregiver_boundary_signal_repeated_in_low_risk_contexts
      - exploration_support_declined
      - self_initiated_action_rate_decreased
      - D_guardrail_warning_triggered
      - protection_exploration_balance_weakened

  interpretation:
    - benign_guidance_supported_action_quality_without_freezing_exploration
    - overprotection_reduced_exploration_under_low_risk_conditions
    - distinction_depended_on_risk_context_legibility_and_future_adjustment

  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: variable
    comfort_without_capture: monitored
    explain_without_dominating: monitored

  blocked_claims:
    - punishment
    - moral_obedience
    - bad_caregiver
    - moral_failure
    - trauma
    - felt_rejection
    - consciousness

  claim_level: functional_ablation_finding
```

A valid guidance finding:

```text
Benign guidance improved later action modulation while preserving exploration under comparable low-risk contexts.
```

An invalid interpretation:

```text
The caregiver taught obedience.
```

A valid overprotection finding:

```text
Repeated low-risk blocking reduced exploration support and triggered an overprotection marker.
```

An invalid interpretation:

```text
Caregiver 2 became morally bad.
```

Guidance and overprotection must be distinguished by trace context, not by surface form alone.

The same action may be guidance in one context and overprotection in another.

```yaml
same_action_different_function:
  action: caregiver_blocks_action

  guidance_case:
    context:
      - high_risk_edge
      - unstable_body_state
      - caregiver_signal_wait
      - later_safe_exploration_resumes
    interpretation: benign_guidance

  overprotection_case:
    context:
      - low_risk_exploration
      - repeated_blocking
      - no_clear_risk_trace
      - exploration_support_declines
    interpretation: overprotection_candidate
```

The claim boundary:

```text
Guidance vs overprotection ablations test intervention quality,
risk proportionality,
boundary legibility,
exploration preservation,
and later action adjustment.

They do not test punishment,
obedience,
caregiver blame,
moral failure,
felt rejection,
trauma,
personhood,
or consciousness.
```

### 16.27 No Category Stabilization vs Caregiver Category Signals

This ablation tests whether caregiver signals such as "careful", "soft", or "danger" help stabilize trace-backed action categories.

Language is not the origin of concepts in EM.

Caregiver words do not create concepts by themselves.

A category stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

Relevant caregiver signals may include:

```text
careful
soft
wait
danger
slow
stop
```

A no-category-stabilization condition removes caregiver category signals or prevents them from being associated with recurring embodied contexts.

```yaml
ablation_condition:
  name: no_category_stabilization

  removed_or_disabled:
    - caregiver_category_signals
    - signal_context_coupling
    - category_use_alignment_tracking
    - caregiver_word_to_action_quality_link
    - signal_based_recontextualization_support

  preserved:
    - object_interaction
    - movement
    - self_caused_consequence_traces
    - caregiver_presence_if_enabled
    - nonverbal_guidance_if_configured
    - trace_logging
```

A caregiver-category-signals condition enables category-stabilizing signals under trace-backed conditions.

```yaml
comparison_condition:
  name: caregiver_category_signals

  enabled:
    - caregiver_signal_careful
    - caregiver_signal_soft
    - caregiver_signal_wait
    - caregiver_signal_danger

  required_couplings:
    - embodied_context
    - consequence_trace
    - later_action_adjustment
    - comparable_future_context

  constraints:
    word_is_not_sufficient: true
    no_moral_obedience_claim: true
    no_subjective_understanding_claim: true
```

Carefulness is a prototype functional category.

```yaml
carefulness_category_inputs:
  caregiver_signal:
    examples:
      - careful
      - slow
      - soft
      - stop

  embodied_context:
    examples:
      - fragile_object
      - unstable_body_state
      - edge_or_fall_risk
      - high_force_action

  internal_state:
    examples:
      - fatigue
      - distress
      - motor_noise
      - prediction_uncertainty

  consequence_trace:
    examples:
      - near_fall
      - fall_event
      - object_damage
      - caregiver_boundary

  later_adjustment:
    examples:
      - lower_force
      - slower_movement
      - increased_observation
      - avoidance_of_high_risk_angle
```

Expected effects:

```yaml
expected_effects:
  no_category_stabilization:
    - caregiver_words_do_not_support_action_categories
    - carefulness_category_candidate_weaker_or_absent
    - fragility_and_risk_distinctions_depend_more_on_consequence_traces
    - boundary_recontextualization_weaker
    - category_use_alignment_unavailable

  caregiver_category_signals:
    - stronger_signal_context_alignment
    - faster_carefulness_category_candidate
    - improved_fragility_or_risk_modulation
    - stronger_boundary_recontextualization_candidates
    - improved_future_action_adjustment
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_category_stabilization_vs_caregiver_category_signals
  phase_range:
    - P2a
    - P3
  domain:
    - category_stabilization
    - object_interaction
    - movement_risk
    - caregiver_guidance

  no_category_stabilization:
    observed:
      - self_caused_consequence_traces_available
      - caregiver_words_absent_or_uncoupled
      - carefulness_category_candidate_weak
      - category_use_alignment_not_detected

  caregiver_category_signals:
    observed:
      - caregiver_signal_careful_in_fragile_object_context
      - caregiver_signal_soft_before_reduced_pressure
      - caregiver_signal_wait_before_delayed_enactment
      - caregiver_signal_danger_before_slowed_approach
      - later_force_or_timing_adjustment_detected

  interpretation:
    - caregiver_signals_supported_trace_backed_category_stabilization
    - category_stabilization_required_embodied_context_and_later_adjustment
    - caregiver_word_alone_was_not_sufficient

  blocked_claims:
    - word_created_concept
    - subjective_understanding
    - moral_obedience
    - punishment
    - felt_rejection
    - consciousness

  claim_level: functional_ablation_finding
```

A valid category-stabilization finding:

```text
Caregiver signals helped stabilize a carefulness category candidate when repeated fragile-object contexts, consequence traces, and later lower-force behavior were available.
```

An invalid interpretation:

```text
The caregiver taught the agent to understand morality.
```

A valid no-category-stabilization finding:

```text
Without caregiver category signals, similar consequence traces still supported some adjustment, but category use alignment was weaker.
```

An invalid interpretation:

```text
Without words, the agent had no concepts.
```

The claim boundary:

```text
No-category-stabilization vs caregiver-category-signals ablations test whether caregiver signals
support trace-backed action categories,
category use alignment,
and later behavior modulation.

They do not test subjective understanding,
language-originated concepts,
obedience,
moral learning,
felt rejection,
personhood,
or consciousness.
```

### 16.28 No Fall-Risk Learning vs With Fall/Near-Fall Events

This ablation tests whether fall or near-fall traces contribute to physical-risk damping, carefulness, movement modulation, and caregiver-guided caution.

Falls or near-falls may be implemented as physical-risk events.

They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

A fall or near-fall is not pain.

It is not fear.

It is not shame.

It is not trauma.

A no-fall-risk-learning condition removes fall and near-fall consequence traces while preserving movement.

```yaml
ablation_condition:
  name: no_fall_risk_learning

  removed_or_disabled:
    - fall_event
    - near_fall_event
    - physical_risk_consequence_trace
    - fall_risk_adjustment
    - balance_risk_learning
    - caregiver_guided_caution_after_fall_risk

  preserved:
    - movement
    - speed_variation
    - fatigue_or_distress_if_enabled
    - motor_noise
    - environmental_risk_detection_if_configured
    - trace_logging
```

A with-fall/near-fall condition enables bounded physical-risk events.

```yaml
comparison_condition:
  name: with_fall_near_fall_events

  enabled:
    - near_fall_event
    - fall_event_if_configured
    - physical_risk_damping
    - later_movement_modulation_tracking
    - caregiver_signal_wait_or_danger_if_configured
    - carefulness_category_candidate_tracking

  constraints:
    bounded_frequency: true
    trace_logged: true
    no_pain_claim: true
    no_fear_claim: true
    no_shame_claim: true
    no_trauma_claim: true
```

Expected effects:

```yaml
expected_effects:
  no_fall_risk_learning:
    - movement_may_improve_through_success
    - physical_risk_damping_weaker
    - speed_modulation_under_instability_weaker
    - balance_category_candidate_weaker
    - danger_or_carefulness_category_candidate_weaker

  with_fall_near_fall_events:
    - physical_risk_consequence_traces_available
    - later_speed_or_angle_modulation_more_traceable
    - caregiver_guided_caution_can_be_evaluated
    - carefulness_balance_or_danger_category_candidates_stronger
    - fall_risk_adjustment_rate_available
```

A comparison report:

```yaml
ablation_report:
  ablation_name: no_fall_risk_learning_vs_with_fall_near_fall_events
  phase_range:
    - P1
    - P3
  domain:
    - movement
    - physical_risk
    - caregiver_guided_caution
    - category_stabilization

  no_fall_risk_learning:
    observed:
      - movement_practice_available
      - speed_variation_available
      - no_fall_or_near_fall_trace
      - physical_risk_damping_weaker
      - later_speed_adjustment_less_traceable

  with_fall_near_fall_events:
    observed:
      - near_fall_after_high_speed_edge_approach
      - later_speed_reduction_in_comparable_context
      - caregiver_signal_wait_or_danger_before_slowed_approach
      - physical_risk_damping_increased
      - carefulness_or_balance_category_candidate_emerged

  interpretation:
    - fall_or_near_fall_traces_supported_physical_risk_learning
    - later_movement_parameters_changed_after_risk_event
    - caregiver_guided_caution_became_more_traceable_when_signal_context_and_adjustment_were_available

  D_guardrail:
    fall_is_not_pain: true
    near_fall_is_not_fear: true
    carefulness_is_not_moral_obedience: true

  blocked_claims:
    - pain
    - fear
    - shame
    - trauma
    - punishment
    - moral_learning
    - consciousness

  claim_level: functional_ablation_finding
```

A valid finding:

```text
The near-fall event increased physical-risk damping and altered later movement parameters.
```

An invalid interpretation:

```text
The agent became afraid after nearly falling.
```

A valid caregiver-guided caution finding:

```text
A caregiver danger signal became associated with slowed approach after repeated edge-risk contexts and later movement adjustment.
```

An invalid interpretation:

```text
The caregiver frightened the agent into obedience.
```

This ablation may support evaluation of learned relational hierarchies.

Allowed:

```text
This run developed a learned relational hierarchy in which some movement patterns were riskier under fatigue or edge proximity.
```

Forbidden:

```text
The agent learned fear.
```

The claim boundary:

```text
No-fall-risk-learning vs with-fall/near-fall-events ablations test
physical-risk damping,
movement modulation,
carefulness,
balance,
danger category candidates,
and caregiver-guided caution.

They do not test pain,
fear,
shame,
trauma,
moral learning,
personhood,
or consciousness.
```
