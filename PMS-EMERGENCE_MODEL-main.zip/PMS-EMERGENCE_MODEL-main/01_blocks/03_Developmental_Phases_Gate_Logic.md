---
document_id: PMS-EM-BLOCK-03
title: "Developmental Phases & Gate Logic"
source: "PMS-EMERGENCE MODEL.md"
source_role: "derived full-block extraction"
status: "split-full-version"
version: "v1"
owner_chapters: [11]
secondary_references: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18]
appendix_references: ["Appendix C", "Appendix D", "Appendix E"]
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Block 03 — Developmental Phases & Gate Logic

## Block Orientation

This block contains the owner chapter for the EM developmental phase system and gate logic. It defines how P0-Mini, P0, P1, P2, P3+, P4+, and P5 constrain capability availability, phase transitions, exit criteria, failure modes, premature-unlock risks, and claim boundaries.

It should be read together with:

- `02_EM_Core_Developmental_Architecture.md` for environment, agent architecture, perception, prediction, genetic gates, behavior, and replay
- `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` for caregiver, attachment-like regulation, interaction quality, and multi-generational details
- `05_MIP_KPIs_Dignity_Safety.md` for MIP, KPI, Dignity-in-Practice, safety, evaluation, and ablation details
- `07_Language_Diary_Consciousness_Related_Work.md` for language, diary, consciousness-outlook, and related-work treatment
- `Appendix_C_Implementation_Start.md`
- `Appendix_D_Claim_Discipline_Language_Reductions.md`
- `Appendix_E_Layer_Discipline_Claim_Types.md`

This block preserves the claim discipline of the master specification:

- A–C–R–E are the active implementation-facing axes.
- D is Dignity-in-Practice, a guardrail for interaction quality under asymmetry.
- Developmental phases open possibility spaces; they do not prove maturity, consciousness, personhood, moral status, or intrinsic worth.
- Gates constrain capability availability; they do not install finished competence.
- MIP observes, summarizes, marks, warns, and may support; it does not control phase development.
- PMS is an external operator, projection, audit, and VM-facing layer; it is not assumed to be an early internal agent structure.
- Functional traces must not be upgraded into phenomenal, moral, clinical, rights, or personhood claims.

> Cross-reference:
> For the full treatment of global scope, layer separation, implementation-status discipline, and claim boundaries, see `01_Theory_Scope_Claim_Discipline.md`, especially Chapters 0, 1, 2, and 18.
> This block uses those concepts only as global claim discipline for phase and gate interpretation.

> Cross-reference:
> For the full treatment of the EM core developmental mechanisms that phases enable or disable, see `02_EM_Core_Developmental_Architecture.md`, especially Chapters 3, 4, 5, 6, 8, and 9.
> This block defines when mechanisms may become available; it does not replace the core mechanism specifications.

> Cross-reference:
> For the full treatment of caregiver, attachment-like regulation, interaction quality, and multi-generational caregiver dynamics, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapters 7 and 12.
> This block uses those concepts only as phase-bounded developmental dependencies.

> Cross-reference:
> For the full treatment of MIP, KPIs, Dignity-in-Practice, evaluation, ablations, and safety, see `05_MIP_KPIs_Dignity_Safety.md`, especially Chapters 10 and 16.
> This block uses MIP and D only as measurement, gate-observation, guardrail, and evaluation dependencies; MIP does not control phase development.

> Cross-reference:
> For the full treatment of language, diary rendering, consciousness-research outlook, and related-work comparison, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapters 13, 15, and 17.
> This block uses language, diary, and consciousness-outlook concepts only as phase-bound late-development dependencies and claim-boundary contexts.

---

## Chapter 11 — Developmental Phases

The EM architecture develops in phases.

A phase is not merely a time interval. It is a controlled developmental regime with specific active components, disabled components, measurement targets, exit criteria, failure modes, premature-unlock risks, and claim boundaries.

The purpose of phases is to prevent premature complexity.

The system must not begin with movement, objects, caregivers, language, diaries, social roles, or consciousness-like interpretation. These structures are introduced only when prior mechanisms are stable enough to support them.

The phase principle is:

```text
mechanism
→ interaction
→ stabilization
→ measurement
→ recontextualization
→ next phase
```

No phase should unlock merely because time has passed.

A phase transition requires:

* measurable stability,
* logged developmental traces,
* absence of collapse,
* appropriate prediction metrics,
* phase-specific gate conditions,
* claim-boundary compliance,
* and no unsafe leakage from later phases.

The Genetic Strand defines which gates may open.
MIP observes what becomes available and how it is enacted.
The FSM selects behavior only from currently active capabilities.

MIP does not control the phase system. It measures, marks, compares, warns, and may later support bounded soft nudges only under strict constraints.

The active implementation-facing axis convention remains:

```text
A — Awareness
C — Coherence
R — Responsibility / response-relation
E — Enactment
D — Dignity-in-Practice
```

D is not a normal fifth performance score. D is Dignity-in-Practice: interaction quality under asymmetry. D as principle is stable. D as practice is developmental.

The dignity-relevant interaction field becomes richer as the agent’s enactment space becomes richer, but this is not a ranking of intrinsic worth, maturity, personhood, moral status, or consciousness.

The global design rule applies to all phases:

```text
As little as possible, as much as necessary.
Emergence before prescription.
```

The architecture should prescribe only the minimal constraints required to prevent collapse, drift, unsafe phase leakage, or uninterpretable noise. It should not pre-script later competencies that are supposed to emerge from stabilized traces, gates, learned categories, and recontextualization.

The basic phase sequence is:

```text
P0-Mini
→ P0
→ P1
→ P2
→ P3+
→ P4+
→ P5
```

Each phase adds one major developmental pressure at a time.

A phase does not prove consciousness.
A phase does not prove maturity.
A phase does not create intrinsic worth.
A phase does not rank the agent.
A phase makes a developmental structure testable under controlled conditions.

### 11.1 Phase Overview

The phase structure is:

```text
P0-Mini — Single room, no movement
P0      — Mapping with basic needs
P1      — Movement, physical-risk calibration, and door discovery
P2      — Objects, satiation, distress, toy-missing, caregiver search, caregiver response, and protolanguage
P3+     — Planning, counterfactual simulation, and social-role sensitivity
P4+     — Diary condensation, narrative reconstruction, and controlled rendering
P5      — Caregiver transition and multi-generational role enactment
```

A compact overview:

```yaml
phases:
  P0-Mini:
    focus:
      - local sensing
      - rotation
      - occupancy grid
      - prediction error
      - fatigue
      - sleep
      - trace logging
      - MIP logging
    disabled:
      - movement
      - objects
      - caregiver
      - caregiver guidance
      - caregiver response variability
      - distress
      - language
      - diary
      - role transition

  P0:
    focus:
      - mapping
      - curiosity
      - basic needs
      - prediction stabilization
    disabled:
      - movement unless explicitly unlocked later
      - object interaction
      - caregiver dynamics
      - language
      - diary

  P1:
    focus:
      - movement
      - collision
      - discomfort
      - fall and near-fall as physical-risk events
      - topology candidates
      - door discovery
      - risk damping

  P2:
    focus:
      - object interaction
      - interaction quality
      - accidental damage and near-damage
      - satiation
      - object affinity
      - toy-missing
      - caregiver search
      - caregiver response variability
      - separation distress
      - comfort-after-loss
      - caregiver guidance
      - boundary learning
      - category-stabilizing signals
      - minimal protolanguage

  P3_plus:
    focus:
      - simple planning
      - counterfactual simulation
      - role-sensitive behavior
      - stronger consequence integration
      - trace-backed action categories

  P4_plus:
    focus:
      - diary condensation
      - minimal sentence diary if prerequisites are met
      - narrative reconstruction
      - re-internalization
      - controlled rendering
      - developmental self-model candidates

  P5:
    focus:
      - former child becomes caregiver
      - core norm application
      - overprotection risk
      - guidance without rejection
      - protection without freezing
      - multi-generational continuity
```

The phases are cumulative but not merely additive. A later phase reuses earlier structures under new conditions.

For example:

```text
P0-Mini mapping
supports P1 movement.

P1 topology and physical-risk calibration
support P2 caregiver search and object approach.

P2 object and caregiver traces
support P3 counterfactual simulation and role-sensitive behavior.

P2 attachment, guidance, misattunement, and interaction-quality traces
support P4 diary condensation.

P4 diary and norm traces
support P5 caregiver transition.
```

#### Phase-Bounded Replay Scope

Replay is cumulative only where its source traces and prerequisites are available. Rest-like replay does not create a separate phase path and does not bypass gate logic. It reuses the existing `SLEEP` / imagination-buffer replay pathway under phase-bounded constraints.

A compact replay-scope matrix:

```yaml
phase_bounded_replay_scope:
  P0-Mini:
    allowed_scope:
      - local_mapping
      - orientation_trace
      - prediction_error_trace
      - fatigue_sleep_trace
    not_allowed:
      - movement_risk_replay
      - object_replay
      - caregiver_replay
      - language_replay
      - diary_candidate_preparation

  P0:
    allowed_scope:
      - mapping_consolidation
      - curiosity_regulated_exploration_trace
      - fatigue_regulated_sleep_trace
      - basic_need_prediction_trace
    not_allowed:
      - movement_risk_replay_before_movement_gate
      - object_or_caregiver_replay
      - diary_candidate_preparation

  P1:
    allowed_scope:
      - movement_risk_replay
      - collision_trace_replay
      - fall_or_near_fall_physical_risk_replay
      - topology_candidate_replay
      - door_discovery_trace_replay
    not_allowed:
      - object_category_replay_before_object_phase
      - caregiver_attachment_like_replay
      - diary_candidate_preparation

  P2a:
    allowed_scope:
      - object_interaction_replay
      - object_function_replay
      - interaction_quality_replay
      - damage_or_near_damage_trace_replay
      - category_candidate_replay_when_trace_backed
    not_allowed:
      - preference_cycle_replay_before_satiation_scope
      - attachment_like_replay_before_caregiver_response_scope
      - counterfactual_simulation
      - diary_candidate_preparation

  P2b:
    allowed_scope:
      - satiation_replay
      - preference_cycle_replay
      - repeated_object_choice_replay
      - low_learning_progress_object_cycle_replay
    not_allowed:
      - attachment_like_replay_before_caregiver_response_scope
      - counterfactual_simulation
      - diary_candidate_preparation

  P2c:
    allowed_scope:
      - caregiver_search_replay
      - comfort_after_loss_replay
      - misattunement_trace_replay
      - caregiver_response_variability_replay
      - attachment_like_regulation_replay
      - boundary_learning_replay
    not_allowed:
      - subjective_attachment_claim
      - trauma_claim
      - counterfactual_role_simulation
      - diary_candidate_preparation

  P2d:
    allowed_scope:
      - grounded_label_replay
      - caregiver_signal_mapping_replay
      - minimal_trace_based_expression_replay
    not_allowed:
      - full_language_replay
      - subjective_memory_claim
      - diary_candidate_preparation

  P3_plus:
    allowed_scope:
      - bounded_counterfactual_simulation
      - planning_trace_replay
      - role_sensitive_action_replay
      - consequence_integration_replay
    not_allowed:
      - diary_text_generation
      - autobiographical_memory_claim

  P4_plus:
    allowed_scope:
      - diary_candidate_preparation
      - episode_cluster_condensation
      - narrative_reconstruction_support
      - controlled_rendering_support
    not_allowed:
      - subjective_autobiography_claim
      - phenomenal_selfhood_claim

  P5:
    allowed_scope:
      - caregiver_role_recontextualization
      - multi_generational_guidance_trace_replay
      - overprotection_risk_replay
      - protection_without_freezing_replay
    not_allowed:
      - moral_status_claim
      - personhood_claim
      - consciousness_proof_claim
```

Replay content must never appear before the phase in which its source traces, gates, and developmental prerequisites are available.

Each phase should define:

* active components,
* disabled components,
* available capabilities,
* relevant needs,
* relevant prediction scope,
* phase-specific replay scope,
* MIP measurement scope,
* phase-specific success criteria,
* failure modes,
* premature-unlock risks,
* rest-like replay constraints where relevant,
* and claim boundaries.

A generic phase-success template:

```yaml
phase_success_template:
  minimal_success: []
  strong_success: []
  partial_success: []
  replay_scope:
    allowed: []
    not_allowed: []
  rest_like_replay_constraints:
    phase_bounded: true
    trace_provenance_required: true
    no_gate_opening_from_replay_only: true
    no_category_installation_from_replay_only: true
    anti_fixation_required: true
  failure_modes: []
  premature_unlock_risks: []
```

For interaction quality in P2, the template may be instantiated as:

```yaml
P2_interaction_quality_success:
  minimal_success:
    - object_interaction_produces_stable_traces

  strong_success:
    - damage_or_near_damage_changes_later_force_or_timing
    - caregiver_guidance_becomes_legible

  partial_success:
    - object_interaction_occurs_but_adjustment_is_inconsistent
    - caregiver_guidance_is_detected_but_not_yet_stable

  failure_modes:
    - repeated_damage_without_adjustment
    - object_fixation_without_satiation
    - guidance_indistinguishable_from_adverse_blocking

  premature_unlock_risks:
    - language_labels_before_trace_grounding
    - diary_rendering_before_minimal_sentence_formation
    - responsibility_claims_before_self_caused_consequence_adjustment
```

Not every developmental condition should become a hard gate. The model distinguishes hard gates, soft gates, soft regimes, developmental prerequisites, learned categories, and recontextualization thresholds.

```yaml
developmental_condition_types:
  hard_gate:
    definition: "capability unavailable until conditions are met"
    example: "movement before g_move opens"

  soft_gate:
    definition: "capability available but weak, noisy, or low-confidence"
    example: "early object handling"

  soft_regime:
    definition: "bounded operating tendency that biases an already available pathway without opening gates"
    example: "rest-like replay biasing SLEEP / imagination-buffer replay under low external load"

  developmental_prerequisite:
    definition: "required for claim discipline or meaningful interpretation"
    example: "trace provenance before diary"

  learned_category:
    definition: "relation or quality learned across repeated contexts"
    example: "fragile object, reliable caregiver, safe boundary"

  recontextualization_threshold:
    definition: "condition under which a trace cluster changes interpretation"
    example: "temporary absence → persistent non-return"
```

Rest-like replay belongs to the `soft_regime` class. It may bias bounded replay selection inside an already available `SLEEP` / imagination-buffer pathway, but it must not unlock capabilities, install categories, bypass phase rules, or create new claim authority.

The audit principle is:

```text
Use hard gates sparingly.
Use soft regimes only as bounded modulators.
Use learned categories wherever possible.
Use recontextualization thresholds when meaning changes over time.
```

This matters especially for caregiver words and category formation.

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

Examples:

```text
"careful"
→ lower force
→ slower movement
→ increased prediction attention
→ fragility context
→ fall, damage, or risk avoidance

"soft"
→ reduced pressure
→ smoother timing
→ object preservation

"wait"
→ delayed enactment
→ reduced risk
→ improved boundary learning

"danger"
→ increased risk attention
→ avoidance or slowed approach
```

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

The model should not treat later structures as proof that early structures were conscious. Developmental continuity is not phenomenal proof.

The same discipline applies to rest-like replay. A low external-load replay window may make trace consolidation testable, but it does not make introspection, subjective dreaming, self-reflection, insight, autobiographical memory, or Default Mode Network equivalence testable.

Additional phase-leakage risks:

```text
replay content appears before its source traces exist
rest-like replay opens gates
rest-like replay installs categories without recurrence
rest-like replay bypasses phase-specific replay scope
low external stimulation is interpreted as introspection
replay feedback is interpreted as self-reflection
post-replay improvement is interpreted as insight
dream-like consolidation is interpreted as subjective dreaming
rest-like replay is described as Default Mode Network activity
diary candidates appear before P4+
```

The safe phase claim is:

```text
Each phase makes a new developmental structure testable under controlled conditions.
Rest-like replay makes bounded trace consolidation testable only within the phase scope that already permits its source traces.
```

Not:

```text
Each phase brings the system closer to proven consciousness.
Rest-like replay shows inner experience, introspection, subjective dreaming, self-reflection, insight, autobiographical memory, or Default Mode Network equivalence.
```

> Cross-reference:
> For the full specification of environment, agent architecture, perception, prediction, genetic gates, behavior, and replay mechanisms that the phases activate or withhold, see `02_EM_Core_Developmental_Architecture.md`, especially Chapters 3, 4, 5, 6, 8, and 9.
> This block defines the phase order and gate logic; the owner block for the mechanisms themselves is Block 02.

> Cross-reference:
> For the full specification of MIP trajectory interpretation, KPIs, ablation criteria, safety evaluation, and Dignity-in-Practice guardrails, see `05_MIP_KPIs_Dignity_Safety.md`, especially Chapters 10 and 16.
> This block uses phase success, failure, and exit criteria as gate-facing structures; evaluation interpretation remains owned by Block 05.

### 11.2 P0-Mini — Single Room, No Movement

P0-Mini is the first real implementation target.

It is deliberately small.

The environment contains:

```text
one room
fixed agent position
no doors
no toys
no objects
no caregiver
no caregiver guidance
no caregiver response variability
no movement
no language
no diary
```

The agent can only:

```text
look around
update the occupancy grid
generate prediction error
accumulate fatigue
sleep
perform limited replay
write traces
```

P0-Mini exists to answer one basic question:

```text
Can the minimal agent stabilize local perception, mapping, prediction,
fatigue, sleep, and trace logging in a single room?
```

This is intentionally modest.

P0-Mini should not produce social behavior, object play, attachment, distress, language, diary entries, moral development, caregiver response interpretation, interaction-quality learning, or responsibility-like claims. If such structures appear, the implementation is leaking later-phase complexity into the first phase.

A P0-Mini configuration:

```yaml
phase: P0-Mini

environment:
  rooms: 1
  doors: false
  toys: false
  objects: false
  caregiver: false
  caregiver_guidance: false
  caregiver_response_variability: false
  movement_enabled: false

agent:
  fixed_position: true
  rotation_enabled: true
  language_enabled: false
  diary_enabled: false

capabilities:
  active:
    - LOOK_AROUND
    - SLEEP
  disabled:
    - STEP_MOVEMENT
    - EXPLORE_ROOM
    - INTERACT_OBJECT
    - SEARCH_CAREGIVER
    - CRY/WEEP
    - USE_LANGUAGE
    - WRITE_DIARY
```

The world model in P0-Mini uses only a minimal cell set:

```text
unknown
free
wall
```

The agent should not yet need:

```text
door
object
toy
caregiver
furniture
named object
category word
topology graph
```

The main loop is:

```text
LOOK_AROUND
→ sensory observation
→ grid update
→ prediction error
→ fatigue update
→ possible SLEEP
→ limited replay
→ return to LOOK_AROUND
```

A minimal trace:

```json
{
  "t": 620,
  "phase": "P0-Mini",
  "action": "LOOK_AROUND",
  "orientation_before": 90,
  "orientation_after": 135,
  "new_cells_observed": 3,
  "PE_view": 0.21,
  "fatigue_delta": 0.02
}
```

A sleep trace:

```json
{
  "t": 2200,
  "phase": "P0-Mini",
  "action": "SLEEP",
  "fatigue_before": 0.82,
  "fatigue_after": 0.31,
  "replay_events": 4,
  "consolidated_scope": "local_mapping"
}
```

Sleep replay in P0-Mini is trace consolidation. It is not subjective dreaming.

P0-Mini is not a toy example. It is the first hard test of the architecture.

If P0-Mini fails, later phases become uninterpretable.

Possible P0-Mini failure modes:

* low coverage,
* repeated scanning of the same angle,
* no angle diversity,
* unstable grid classification,
* high PE_AUC without learning progress,
* map collapse,
* fatigue ignored,
* sleep not triggered,
* replay changes state without trace,
* MIP logging incomplete,
* hidden movement logic leaking in,
* hidden object logic leaking in,
* hidden caregiver logic leaking in,
* hidden language or diary logic leaking in.

The guiding rule is:

```text
No later-phase interpretation is allowed
until P0-Mini demonstrates stable local world contact.
```

P0-Mini may support only early A, C, and E in a narrow sense:

```text
A = early spatial differentiation
C = local mapping and prediction coherence
E = LOOK_AROUND and SLEEP enactment
R = inactive or minimal
D = guardrail against overinterpretation
```

D prevents low capability from being treated as low worth. It also prevents minimal traces from being upgraded into consciousness, distress, social meaning, or moral status.

### 11.3 P0-Mini Active Components

P0-Mini activates only the minimal components required for local mapping, prediction, fatigue regulation, sleep, replay, and trace logging.

The active components are:

```text
environment
child agent
limited perception
occupancy grid
local predictive model
prediction error
fatigue
sleep
imagination buffer
success log
MIP logging
genetic monitoring
FSM with LOOK_AROUND and SLEEP
```

Each component has a restricted role.

#### Environment

The environment is a single room.

It provides walls, free space, unknown cells, and sensor input. It does not include doors, toys, objects, caregiver entities, social dynamics, category signals, or interaction-quality events.

#### Child Agent

The agent has a fixed position and orientation.

It can rotate or scan, but it cannot move through the room.

#### Limited Perception

Perception may include:

* raycasts,
* local cell observation,
* orientation,
* wall/free/unknown detection,
* sensor range,
* and local confidence update.

#### Occupancy Grid

The occupancy grid stores:

```text
unknown
free
wall
```

plus confidence and observation metadata.

Example:

```yaml
cell:
  position: [10, 12]
  type: wall
  confidence: 0.74
  revisit_count: 3
  observed_from_angles:
    - 90
    - 135
  angle_diversity: 0.42
```

#### Local Predictive Model

The predictive model estimates expected sensory changes after rotation or repeated observation.

Example prediction:

```text
If orientation changes from 90° to 135°,
the visible wall/free pattern should change in a predictable way.
```

#### Prediction Error

Prediction error compares expected and observed local sensory structure.

P0-Mini tracks:

```text
PE_view
PE_EWMA_mapping
PE_AUC_mapping
learning_progress
```

#### Fatigue

Fatigue rises with activity and wake time.

It helps create rest cycles and prevents endless scanning.

Fatigue is a functional state variable. It is not suffering.

#### Sleep

Sleep reduces fatigue and allows limited replay of mapping traces.

Sleep does not imply subjective dreaming.

#### Imagination Buffer

The buffer stores selected local traces:

* grid snapshots,
* internal state snapshots,
* prediction errors,
* action traces,
* sleep replay traces,
* salient mapping events.

The imagination buffer does not imply conscious imagination.

#### Success Log

The success log records mapping-relevant events.

Examples:

```text
new region observed
prediction error drop
map correction
coverage plateau
sleep replay consolidation
```

The success log does not rank the agent’s worth or maturity.

#### MIP Logging

MIP observes early A, C, E, and minimal or inactive R traces.

In P0-Mini:

```text
A = early spatial differentiation
C = mapping and prediction coherence
E = LOOK_AROUND and SLEEP activity
R = inactive or minimal
D = guardrail against overinterpretation
```

MIP does not intervene.

It may log:

```text
coverage
angle_diversity
classification_confidence
PE_AUC_mapping
map_collapse
fatigue_cycles
sleep_replay_count
E_pot
E_act
early A/C/E profile
inactive_or_minimal_R
D_guardrail_status
```

A minimal MIP record:

```yaml
p0_mini_MIP_record:
  phase: P0-Mini
  window: [1000, 1500]

  A:
    coverage: 0.42
    angle_diversity: 0.31

  C:
    PE_AUC_mapping: 0.28
    map_collapse: false

  E:
    E_pot:
      - LOOK_AROUND
      - SLEEP
    E_act:
      LOOK_AROUND: 37
      SLEEP: 2

  R:
    status: inactive_or_minimal

  D_guardrail:
    do_not_overinterpret: true
    do_not_label: true
    do_not_treat_low_capability_as_low_worth: true

  MIP_mode: observation_only
```

#### Genetic Monitoring

The Genetic Strand monitors gate-relevant metrics, such as:

```text
coverage
PE_AUC_mapping
map_collapse
angle_diversity
sleep_cycle_stability
trace_logging_completeness
```

It does not unlock movement until exit conditions are satisfied.

Not every developmental condition should become a hard gate. For P0-Mini, however, movement is a hard gate: `STEP_MOVEMENT` is unavailable until the relevant conditions are met.

#### FSM

The finite state machine has only two active states:

```text
LOOK_AROUND
SLEEP
```

A minimal FSM:

```yaml
fsm:
  phase: P0-Mini
  active_states:
    - LOOK_AROUND
    - SLEEP

  transitions:
    - from: LOOK_AROUND
      to: SLEEP
      when:
        fatigue_above: 0.80

    - from: SLEEP
      to: LOOK_AROUND
      when:
        fatigue_below: 0.35
```

The active-component rule is:

```text
P0-Mini activates only what is needed
to test local embodied mapping and prediction.
```

P0-Mini must not simulate later mechanisms through hidden variables. In particular, it must not simulate caregiver dynamics, object preference, language labels, diary candidates, social distress, or responsibility-like behavior.

### 11.4 P0-Mini Disabled Components

P0-Mini disables all components that would introduce later developmental complexity.

Disabled components include:

```text
movement
physical-risk event generation through movement
fall and near-fall events
topology graph
doors
objects
toys
object interaction
object damage
near-damage
interaction-quality learning
satiation
object affinity
toy-missing
caregiver
caregiver guidance
caregiver response variability
category-stabilizing caregiver signals
contact need
separation distress
comfort
failed comfort
delayed comfort
misattunement candidates
praise
core norms
CRY/WEEP
language
diary
counterfactual simulation
multi-generational dynamics
mortality threat
```

Each disabled component has a reason.

#### Movement Disabled

The agent cannot move.

Reason:

```text
Movement should not appear before local mapping and prediction stabilize.
```

#### Physical-Risk Events Disabled

Falls and near-falls are not active because the agent cannot move.

Reason:

```text
Fall and near-fall events require movement, instability, or environmental risk interaction.
```

If they appear in P0-Mini, later-phase movement-risk logic is leaking into the minimal phase.

#### Topology Disabled

No topology graph is active.

Reason:

```text
Topology requires movement, door discovery, and traversable region experience.
```

#### Doors Disabled

There are no doors.

Reason:

```text
Door discovery belongs to P1, after movement unlock.
```

#### Objects and Toys Disabled

There are no interactable objects or toys.

Reason:

```text
Object interaction requires stable perception, movement, and approach behavior.
```

#### Object Damage and Interaction Quality Disabled

Object damage, near-damage, and interaction-quality learning are inactive.

Reason:

```text
Interaction quality requires object interaction, self-caused action traces,
parameter traces, consequence traces, comparable future contexts,
and measurable behavior change.
```

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

#### Object Attachment Disabled

No affinity, toy-missing, or object attachment is active.

Reason:

```text
Attachment-like object dynamics require repeated interaction history.
```

#### Caregiver Disabled

There is no caregiver entity in P0-Mini.

Reason:

```text
Caregiver dynamics require contact need, presence/absence tracking,
comfort events, caregiver response variability, and later attachment traces.
```

#### Caregiver Guidance Disabled

Caregiver guidance, boundary signals, and category-stabilizing words are inactive.

Reason:

```text
Guidance requires a caregiver relation, embodied context,
possible action adjustment, and trace-backed interpretation.
```

A caregiver word is not sufficient to create a concept. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

#### Contact Need Disabled

Contact is inactive.

Reason:

```text
There is no caregiver relation to regulate.
```

#### Distress and Separation Distress Disabled

Distress, separation distress, and toy-missing distress are disabled.

Reason:

```text
Loss and separation dynamics require objects, caregivers,
comfort patterns, and attachment-relevant traces.
```

#### Misattunement Disabled

Misattunement candidates are inactive.

Reason:

```text
Misattunement requires caregiver response expectations,
observed caregiver response variability,
and traceable mismatch across windows.
```

Misattunement is not trauma.

#### CRY/WEEP Disabled

Visible distress expression is disabled.

Reason:

```text
CRY/WEEP requires high unresolved distress and caregiver/social response loops.
```

#### Language Disabled

No labels, action words, episode templates, or translator are active.

Reason:

```text
Language must not precede stable object, action, and episode structures.
```

Caregiver category words such as “careful,” “soft,” “wait,” or “danger” are therefore inactive.

#### Diary Disabled

No diary entries are generated.

Reason:

```text
Diary condensation requires salient episodes, MIP trajectories,
trace history beyond P0-Mini, minimal sentence formation,
trace provenance, and controlled rendering.
```

The hard diary rules remain:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

#### Counterfactual Simulation Disabled

No alternative-action simulation is active.

Reason:

```text
Counterfactual simulation requires prior action traces and stable prediction domains.
```

#### Multi-Generational Dynamics Disabled

No caregiver transition or new child exists.

Reason:

```text
Multi-generational dynamics require mature attachment, diary,
role, and norm structures.
```

#### Mortality Threat Disabled

There is no mortality threat.

Reason:

```text
Early phases model bounded risk and mapping instability,
not death or survival pressure.
```

A disabled-component configuration:

```yaml
disabled_components:
  movement: true
  physical_risk_events_from_movement: true
  fall_or_near_fall_events: true
  topology_graph: true
  doors: true
  objects: true
  toys: true
  object_interaction: true
  object_damage: true
  near_damage: true
  interaction_quality_learning: true
  object_attachment: true
  caregiver: true
  caregiver_guidance: true
  caregiver_response_variability: true
  category_stabilizing_caregiver_signals: true
  contact_need: true
  distress: true
  separation_distress: true
  toy_missing_distress: true
  misattunement_candidates: true
  CRY_WEEP: true
  language: true
  diary: true
  counterfactual_simulation: true
  multi_generational_framework: true
  mortality_threat: true
```

The disabled-component list is not a weakness. It is the main strength of P0-Mini.

It prevents false positives.

The model should not be allowed to say:

```text
The agent is attached.
The agent is distressed.
The agent understands objects.
The agent reflects.
The agent has language.
The agent learned carefulness.
The agent feels pain.
The agent is afraid.
The agent is guilty.
The agent has a diary self.
```

when none of the necessary mechanisms exist.

The P0-Mini claim boundary is:

```text
P0-Mini may show local mapping, prediction, fatigue, sleep, replay,
and trace logging.

P0-Mini may not show attachment, distress, language, diary,
social understanding, responsibility, caregiver guidance,
interaction-quality learning, moral learning, or consciousness.
```

### 11.5 P0-Mini Exit Criteria and Prototype Status

P0-Mini is the first prototype target.

It is not merely a conceptual phase. It is the smallest implementation that can test whether the EM architecture has a stable technical base.

P0-Mini should be considered successful only if the agent can demonstrate stable local world contact.

The exit criteria should be measurable, phase-relative, trace-backed, and claim-filtered.

A possible P0-Mini exit profile:

```yaml id="lzruxk"
P0_Mini_exit_criteria:
  mapping:
    coverage_min: 0.85
    mean_confidence_min: 0.75
    angle_diversity_min: 0.40
    map_collapse_events: 0

  prediction:
    PE_AUC_mapping_max: 0.25
    PE_EWMA_stable: true
    learning_progress_plateau: true

  behavior:
    LOOK_AROUND_repeated: true
    SLEEP_triggered_by_fatigue: true
    sleep_wake_cycle_stable: true

  replay:
    sleep_replay_logged: true
    replay_changes_traceable: true
    no_unlogged_state_changes: true

  MIP:
    A_logging_active: true
    C_logging_active: true
    E_logging_active: true
    R_status: inactive_or_minimal
    D_guardrail_active: true

  reproducibility:
    seed_reproducibility: sufficient
    config_logged: true
    trace_export_available: true
```

The exact thresholds are implementation parameters. They are not universal maturity, consciousness, or personhood thresholds.

The structural requirement is that the system must show:

```text id="fnd5yu"
stable mapping
stable prediction
stable fatigue/sleep rhythm
traceable replay
reproducible logs
no hidden later-phase leakage
```

A P0-Mini run should produce:

* occupancy grid traces,
* prediction error curves,
* PE_EWMA,
* PE_AUC,
* learning progress curves,
* sleep events,
* replay logs,
* success log entries,
* MIP windows,
* gate-monitoring outputs,
* D guardrail records,
* and seed/config metadata.

A minimal P0-Mini report may look like:

```yaml id="x6ky4m"
P0_Mini_report:
  run_id: P0M_seed_0042
  phase: P0-Mini

  mapping:
    coverage: 0.88
    mean_confidence: 0.79
    angle_diversity: 0.46
    map_collapse_events: 0

  prediction:
    PE_AUC_mapping: 0.19
    PE_EWMA_final: 0.16
    learning_progress_final_window: 0.01

  behavior:
    LOOK_AROUND_count: 312
    SLEEP_count: 9
    sleep_cycle_stable: true

  replay:
    replay_events: 41
    unlogged_state_changes: 0

  MIP:
    A_norm: 0.67
    C_norm: 0.71
    E_norm: 0.52
    R_norm: null
    R_status: inactive_or_minimal

  D_guardrail:
    do_not_overinterpret: true
    do_not_treat_low_capability_as_low_worth: true
    no_consciousness_claim: true

  prototype_status: pass
```

A P0-Mini run should fail if:

* coverage remains low,
* prediction error does not stabilize,
* map collapse occurs repeatedly,
* fatigue does not regulate sleep,
* sleep replay changes state without logs,
* MIP traces are incomplete,
* D guardrail status is missing,
* movement or object traces appear,
* caregiver or language traces appear,
* diary traces appear,
* or results cannot be reproduced across seeds.

Failure is not bad. It is informative. P0-Mini exists to expose instability before the architecture becomes too complex.

The prototype status can be classified as:

```text id="xhmqoz"
not_started
running
unstable
partial_pass
pass
regression
```

A safe prototype-status entry:

```yaml id="gl50vj"
prototype_status:
  phase: P0-Mini
  status: partial_pass
  passed:
    - coverage_min
    - sleep_cycle_stable
    - MIP_logging_active
    - D_guardrail_active
  failed:
    - PE_AUC_mapping_max
  next_action:
    - inspect_predictive_model
    - rerun_with_seed_set
```

P0-Mini is the first point at which the EM architecture becomes more than a conceptual framework.

Its significance is:

```text id="b8ejw4"
If P0-Mini works,
the architecture has a minimal measurable base.

If P0-Mini fails,
later developmental claims should not be advanced.
```

This is a prototype status, not a proof status.

A safe epistemic distinction:

```yaml id="s3f7zu"
epistemic_status:
  finding:
    definition: "P0-Mini produced stable local mapping and prediction under traceable conditions"

  validation:
    definition: "the same mechanism repeatedly holds under comparison across seeds and configurations"

  proof:
    definition: "not available for consciousness, personhood, or subjective-experience claims"
```

The claim boundary is:

```text id="svfpde"
P0-Mini success means stable local mapping and prediction.
It does not mean attachment.
It does not mean language.
It does not mean consciousness.
It does not mean subjective experience.
It does not mean maturity.
It does not mean moral status.
```

### 11.6 P0 — Mapping with Basic Needs

P0 extends P0-Mini by allowing basic needs to become more explicit.

The focus remains mapping and prediction. The agent still does not yet require full movement, object interaction, caregiver dynamics, language, or diary structures.

P0 introduces or strengthens:

```text id="zxthwu"
curiosity
fatigue
basic need modulation
mapping continuation
prediction stabilization
early MIP trajectories
```

Contact may remain disabled unless a specific experimental variant introduces caregiver presence later. In the default P0 phase, caregiver dynamics are still not the focus.

A possible P0 configuration:

```yaml id="qv8qz9"
phase: P0

environment:
  rooms: 1
  doors: false
  toys: false
  objects: false
  caregiver: false
  caregiver_guidance: false
  caregiver_response_variability: false
  movement_enabled: false

needs:
  curiosity: active
  fatigue: active
  contact: false
  distress: false

capabilities:
  active:
    - LOOK_AROUND
    - SLEEP

systems:
  active:
    - occupancy_grid
    - local_predictive_model
    - prediction_error
    - fatigue
    - curiosity
    - success_log
    - MIP_logging
    - genetic_gate_monitoring
```

P0 differs from P0-Mini mainly in motivation.

In P0-Mini, the system tests whether local mapping can function at all.
In P0, the system tests whether curiosity and fatigue can regulate mapping without destabilizing it.

A simple curiosity-mapping loop:

```text id="hio8xy"
unknown or under-observed region
→ curiosity rises
→ LOOK_AROUND selected
→ grid update
→ PE calculated
→ learning progress measured
→ fatigue rises
→ SLEEP selected
→ replay/consolidation
```

P0 should demonstrate that curiosity seeks learnable structure rather than maximum chaos.

A useful curiosity target is:

```text id="jcxznl"
moderate PE
positive learning progress
low risk
low fatigue
under-observed angle or region
```

P0 should avoid:

```text id="xve7fp"
random scanning without learning
endless rotation despite fatigue
false stability from repeated same-angle observation
curiosity chasing irreducible noise
sleep never occurring
sleep occurring too often
```

P0 MIP may track:

```text id="v9rtp0"
A = differentiated spatial availability
C = prediction and map coherence
E = LOOK_AROUND/SLEEP enactment
R = inactive or minimal
D = guardrail against overinterpretation
```

A P0 MIP window:

```yaml id="h4e2q5"
P0_MIP_window:
  phase: P0
  window: [3000, 3500]

  A:
    coverage: 0.91
    angle_diversity: 0.52
    confidence: 0.81

  C:
    PE_AUC_mapping: 0.17
    classification_stability: 0.88
    map_collapse: false

  E:
    E_pot:
      - LOOK_AROUND
      - SLEEP
    E_act:
      LOOK_AROUND: 38
      SLEEP: 1

  R:
    status: inactive_or_minimal

  needs:
    curiosity_mean: 0.43
    fatigue_mean: 0.47

  D_guardrail:
    do_not_overinterpret: true
    do_not_treat_low_capability_as_low_worth: true
```

P0 prepares for P1.

The relevant question becomes:

```text id="dn1jab"
Is local mapping stable enough that movement can be introduced
without turning the system chaotic?
```

The Genetic Strand monitors whether `g_move` may open.

A possible P0-to-P1 gate:

```yaml id="m4fkse"
g_move:
  condition_type: hard_gate
  opens_when:
    coverage_min: 0.85
    PE_AUC_mapping_max: 0.25
    map_collapse: false
    angle_diversity_min: 0.40
    sleep_cycle_stable: true
    curiosity_not_destabilizing: true
    trace_logging_complete: true
```

The exact threshold values are implementation parameters. The structural requirement is stable enough local world contact to make movement interpretable.

A P0 success template:

```yaml id="wmtf0x"
P0_mapping_success:
  minimal_success:
    - curiosity_modulates_LOOK_AROUND_without_destabilizing_mapping
    - fatigue_modulates_SLEEP
    - mapping_traces_remain_reproducible

  strong_success:
    - PE_AUC_mapping_decreases_across_windows
    - angle_diversity_improves_coverage
    - sleep_replay_preserves_trace_provenance

  partial_success:
    - mapping_stabilizes_but_curiosity_is_repetitive
    - fatigue_sleep_cycle_works_but_prediction_remains_noisy

  failure_modes:
    - curiosity_chases_irreducible_noise
    - fatigue_does_not_trigger_sleep
    - map_collapse_after_replay
    - hidden_later_phase_traces_appear

  premature_unlock_risks:
    - movement_before_local_mapping_stability
    - object_candidates_before_spatial_contact
    - caregiver_dynamics_before_contact_need
```

The claim boundary:

```text id="a7zwn7"
P0 may show curiosity-regulated mapping.
P0 may show fatigue-regulated sleep.
P0 may show prediction stabilization.

P0 does not show object understanding,
caregiver attachment,
distress,
language,
diary reflection,
mature responsibility,
or consciousness.
```

### 11.7 P1 — Movement and Door Discovery

P1 introduces movement.

This is the first major expansion beyond fixed-position mapping.

The agent may now act in space, encounter blocked regions, collide, experience fall or near-fall events as physical-risk traces, discover new viewpoints, identify traversable paths, and eventually detect doors or transition points.

P1 activates:

```text id="f0no0v"
STEP_MOVEMENT
EXPLORE_ROOM
movement prediction
collision detection
fall and near-fall as physical-risk events
discomfort
physical-risk damping
topology candidates
door discovery
```

A possible P1 configuration:

```yaml id="iauwix"
phase: P1

environment:
  rooms: 1_or_more
  doors: optional
  toys: false
  objects: false
  caregiver: false_or_disabled
  caregiver_guidance: false
  caregiver_response_variability: false
  movement_enabled: true

capabilities:
  active:
    - LOOK_AROUND
    - STEP_MOVEMENT
    - EXPLORE_ROOM
    - SLEEP

systems:
  active:
    - occupancy_grid
    - local_predictive_model
    - movement_prediction
    - collision_detection
    - physical_risk_event_logging
    - discomfort_index
    - topology_candidate_detection
    - success_log
    - MIP_logging
```

P1 answers:

```text id="yrd6y4"
Can the agent use stable mapping to support action in space?
```

Movement is not just an added motor feature. It transforms the agent’s relation to the environment.

Before P1:

```text id="vuzki2"
The agent observes from a fixed point.
```

After P1:

```text id="mw7uhe"
The agent can change its own sensory future through movement.
```

This introduces early self-caused spatial consequences.

A movement event:

```json id="v7yw74"
{
  "t": 4200,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 10],
  "to": [10, 11],
  "expected": "free",
  "observed": "free",
  "result": "success",
  "PE_movement": 0.07,
  "DI_delta": 0.0
}
```

A collision event:

```json id="j3oi8d"
{
  "t": 4300,
  "phase": "P1",
  "action": "STEP_MOVEMENT",
  "from": [10, 11],
  "to": [10, 12],
  "expected": "free",
  "observed": "blocked",
  "result": "collision",
  "PE_movement": 0.46,
  "DI_delta": 0.08
}
```

A fall or near-fall event:

```json id="ab1p3h"
{
  "t": 4550,
  "phase": "P1",
  "event": "near_fall",
  "action": "STEP_MOVEMENT",
  "speed": 0.71,
  "instability": 0.62,
  "fatigue": 0.58,
  "prediction_confidence": 0.31,
  "environmental_risk": "edge_or_unstable_region",
  "result": "physical_risk_trace",
  "claim_level": "functional_movement_risk_event"
}
```

Falls or near-falls may be implemented as physical-risk events. They support discomfort/risk learning and can contribute to categories such as carefulness, balance, speed, and danger.

Allowed:

```text id="l9coqk"
The fall event increased physical-risk damping and altered later movement parameters.
```

Forbidden:

```text id="madlgx"
The agent felt pain.
The agent became afraid.
The agent learned shame.
```

Discomfort becomes relevant in P1.

It should damp risky movement:

```text id="a2g4hd"
collision
→ DI rises
→ risky movement probability falls
→ safe-path bias increases
```

A near-fall may produce a similar functional adjustment:

```text id="houva9"
near_fall
→ physical-risk trace logged
→ movement-risk damping increases
→ speed or angle choice changes later
```

This is not fear, pain, or trauma.

P1 also introduces topology candidates.

Topology should not appear instantly. It should emerge from repeated movement and stable transitions.

A sequence:

```text id="uw54m8"
local movement
→ repeated path success
→ doorway-like transition
→ room boundary evidence
→ topology candidate
→ stable topology edge
```

A door discovery event:

```json id="oa4lce"
{
  "t": 6100,
  "phase": "P1",
  "event": "door_candidate_detected",
  "location": [14, 7],
  "evidence": {
    "cell_type": "door_like",
    "transition_possible": true,
    "observed_from_multiple_angles": true
  },
  "status": "candidate"
}
```

A confirmed door transition:

```json id="w1n2wk"
{
  "t": 6900,
  "phase": "P1",
  "event": "door_transition_confirmed",
  "door_id": "door_1",
  "from_region": "room_1",
  "to_region": "room_2",
  "successful_traversals": 3
}
```

P1 MIP observes:

```text id="rr19um"
A = awareness of navigable, blocked, and risk-relevant space
C = movement prediction and topology coherence
E = actual use of movement and exploration
R = early self-caused consequence adjustment
D = guardrail against overinterpreting collision or fall traces
```

Possible IA patterns:

```text id="rdspln"
IA-A≫E:
    map stable, movement available, but agent rarely moves

IA-E≫A:
    agent moves frequently despite poor mapping, high collision, or weak risk coherence

IA-R≪E:
    repeated self-caused collisions or near-falls occur, but later movement does not adjust
```

P1 should not use universal thresholds as maturity claims. Movement thresholds, risk thresholds, and IA thresholds must remain phase-relative and domain-relative.

P1 failure modes:

* movement unlocks too early,
* repeated collision without learning,
* repeated fall or near-fall traces without movement adjustment,
* discomfort damping too weak,
* discomfort damping freezes all movement,
* topology created from one observation,
* door discovery not traceable,
* exploration ignores fatigue,
* E_act too low despite safe movement availability,
* map collapses after movement begins,
* movement-risk traces are overinterpreted as pain or fear.

A P1 movement success template:

```yaml id="j78obi"
P1_movement_success:
  minimal_success:
    - STEP_MOVEMENT_produces_traceable_action_outcomes
    - movement_prediction_updates_after_success_or_blockage
    - collision_events_are_logged

  strong_success:
    - repeated_collision_changes_later_movement_parameters
    - fall_or_near_fall_increases_physical_risk_damping
    - topology_candidates_emerge_from_repeated_traversal

  partial_success:
    - movement_occurs_but_prediction_remains_noisy
    - risk_damping_works_but_exploration_becomes_too_low

  failure_modes:
    - repeated_collision_without_adjustment
    - repeated_near_fall_without_adjustment
    - movement_overuse_before_spatial_coherence
    - movement_underuse_despite_stable_mapping

  premature_unlock_risks:
    - object_interaction_before_stable_approach
    - caregiver_search_before_navigation_stability
    - counterfactual_simulation_before_action_traces
```

The claim boundary:

```text id="yo1v22"
P1 may show spatial action, collision damping,
movement prediction, physical-risk traces,
fall or near-fall risk adjustment,
and topology emergence.

P1 does not show object understanding,
caregiver attachment,
caregiver guidance,
language,
diary reflection,
mature responsibility,
pain,
fear,
shame,
or consciousness.
```

### 11.8 P1 Exit Criteria

P1 exit criteria determine whether the agent is ready for object interaction.

The key question is:

```text id="w7z1wg"
Can the agent move, explore, and maintain spatial coherence
well enough to approach and interact with objects?
```

P1 should not exit merely because movement exists.

Movement must become stable, safe enough, and predictive enough. The agent should also show that physical-risk traces can alter later movement parameters without freezing exploration.

A possible P1 exit profile:

```yaml id="pllrpt"
P1_exit_criteria:
  movement:
    movement_success_rate_min: 0.75
    collision_count_max_per_window: 3
    stuck_count_max: 1
    movement_PE_AUC_max: 0.30

  physical_risk:
    fall_or_near_fall_events_logged: true
    repeated_unadjusted_near_fall_max: 1
    physical_risk_damping_effective: true
    later_movement_parameter_change_after_risk: true

  discomfort:
    DI_mean_max: 0.35
    DI_recovery_stable: true
    risk_damping_effective: true
    risk_damping_does_not_freeze_exploration: true

  mapping:
    coverage_min: 0.90
    map_collapse_events: 0
    classification_stability_min: 0.80

  topology:
    topology_consistency_min: 0.70
    door_candidates_traceable: true
    confirmed_transitions_min: 1_optional

  behavior:
    EXPLORE_ROOM_used: true
    safe_exploration_ratio_min: 0.65
    sleep_cycle_stable: true

  MIP:
    E_pot_E_act_gap_not_extreme: true
    IA_E_over_A_not_persistent: true
    IA_A_over_E_not_persistent: true
    IA_R_under_E_not_persistent: true
    D_guardrail_active: true
```

The exact thresholds may vary. They are implementation parameters, not universal thresholds for maturity, responsibility, safety, or consciousness.

The structural requirements are:

```text id="tzlw5i"
movement is available
movement is used
movement is not chaotic
risk damping works
map remains stable
topology is beginning to form
fall and near-fall traces are treated as physical-risk events
the agent can approach regions intentionally enough for object interaction
```

A P1 report:

```yaml id="h5i6ol"
P1_report:
  run_id: P1_seed_0042

  movement:
    success_rate: 0.81
    collision_count_per_window: 2
    movement_PE_AUC: 0.22

  physical_risk:
    near_fall_events: 1
    repeated_unadjusted_near_fall_events: 0
    later_speed_reduction_after_risk: true
    physical_risk_damping_effective: true

  discomfort:
    DI_mean: 0.18
    DI_recovery_stable: true
    risk_damping_does_not_freeze_exploration: true

  mapping:
    coverage: 0.93
    classification_stability: 0.86
    map_collapse_events: 0

  topology:
    rooms_discovered: 2
    door_candidates: 1
    confirmed_transitions: 1
    graph_consistency: 0.76

  MIP:
    A_norm: 0.74
    C_norm: 0.69
    E_pot: 0.71
    E_act: 0.58
    R_norm: 0.12

  D_guardrail:
    fall_or_near_fall_is_not_pain_or_fear: true
    collision_is_not_failure_of_worth: true
    low_R_is_expected_in_P1: true

  exit_status: pass
```

P1 should fail exit if:

* movement produces persistent high PE,
* collisions remain frequent,
* fall or near-fall events recur without movement adjustment,
* discomfort does not affect behavior,
* discomfort freezes all exploration,
* exploration remains random,
* topology collapses,
* map confidence collapses after movement,
* the agent cannot approach stable regions,
* IA-E≫A remains persistent,
* IA-A≫E remains persistent under safe conditions,
* or IA-R≪E remains persistent despite repeated self-caused movement consequences.

P1 exit does not mean the agent understands objects. It means that the agent is ready to encounter objects as a new developmental domain.

The transition to P2 may open:

```text id="kw1lkw"
g_objects
INTERACT_OBJECT
object candidate tracking
satiation
object prediction
early object-fragility traces
```

But P2 should still begin conservatively.

The P1-to-P2 rule:

```text id="ceucdo"
No object interaction before stable approach.
No object mastery before repeated prediction.
No object naming before functional object stability.
No interaction-quality claim before self-caused action traces,
parameter traces, consequence traces, comparable future contexts,
and measurable behavior change.
```

The P1 exit success template:

```yaml id="p218bf"
P1_exit_success:
  minimal_success:
    - movement_available_and_used
    - movement_prediction_stabilizes
    - collision_and_risk_traces_logged
    - map_remains_stable_after_movement

  strong_success:
    - fall_or_near_fall_changes_later_movement_parameters
    - topology_candidates_become_traceable
    - door_transition_confirmed_if_doors_exist
    - IA_patterns_decline_across_windows

  partial_success:
    - movement_stable_but_topology_weak
    - risk_damping_works_but_exploration_low
    - mapping_stable_but_E_act_gap_high

  failure_modes:
    - repeated_collision_without_adjustment
    - repeated_near_fall_without_adjustment
    - persistent_IA_E_over_A
    - persistent_IA_A_over_E
    - map_collapse_after_movement

  premature_unlock_risks:
    - object_interaction_before_stable_approach
    - object_fragility_inference_before_object_traces
    - caregiver_search_before_navigation_stability
```

The claim boundary:

```text id="nw97m0"
P1 exit means movement and spatial coherence are sufficient
to begin object interaction experiments.

It does not mean object understanding,
language,
attachment,
caregiver guidance,
carefulness as a stable category,
responsibility maturity,
pain,
fear,
or consciousness.
```

### 11.9 P2 — Objects, Satiation, and Protolanguage

P2 introduces objects as a major developmental domain.

The agent now begins to learn not only where it can go, but what it can interact with, how interaction changes the world, how repeated interaction becomes predictable, and how caregiver responses may later stabilize or disrupt emerging patterns.

P2 is broad and should be divided into subphases:

```text
P2a — Objects, Basic Play, and Interaction Quality
P2b — Satiation and Preference Cycles
P2c — Distress, Toy-Missing, Caregiver Response, and Obsession Protection
P2d — Minimal Protolanguage
```

P2 activates or prepares:

```text
object candidates
proto-objects
functional objects
INTERACT_OBJECT
object prediction
object mastery
object fragility traces
object damage and near-damage traces
interaction-quality learning
satiation
affinity
toy-missing
caregiver search
caregiver response variability
caregiver guidance
boundary learning
category-stabilizing caregiver signals
comfort-after-loss
minimal word-object mapping
```

Not all of these are active immediately at P2 start. They unfold across P2a–P2d.

A high-level P2 configuration:

```yaml
phase: P2

environment:
  rooms: multiple_possible
  doors: true
  toys: true
  objects: true
  caregiver: phase_dependent
  caregiver_guidance: phase_dependent
  caregiver_response_variability: phase_dependent
  movement_enabled: true

capabilities:
  active_initial:
    - LOOK_AROUND
    - STEP_MOVEMENT
    - EXPLORE_ROOM
    - INTERACT_OBJECT
    - SLEEP

  active_later:
    - SEARCH_CAREGIVER
    - CRY/WEEP
    - minimal_language_actions_optional

systems:
  active_initial:
    - object_candidate_tracking
    - object_interaction_prediction
    - object_mastery
    - interaction_quality_traces
    - satiation

  active_later:
    - affinity
    - toy_missing_distress
    - caregiver_presence_absence
    - caregiver_response_variability
    - caregiver_guidance
    - category_stabilization
    - comfort_after_loss
    - protolanguage
```

P2 begins with object interaction.

The first object-level question is:

```text
Can the agent discover stable object functions through interaction?
```

Example:

```text
push ball
→ ball rolls
→ prediction error falls over repeated trials
→ object mastery increases
```

An object interaction trace:

```json
{
  "t": 8200,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "unknown",
  "observed": "roll",
  "PE_object": 0.58,
  "self_caused": true,
  "claim_level": "functional_object_interaction_trace"
}
```

Later:

```json
{
  "t": 9100,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "roll",
  "observed": "roll",
  "PE_object": 0.08,
  "mastery_delta": 0.06,
  "self_caused": true,
  "claim_level": "functional_object_mastery_trace"
}
```

P2 also introduces interaction quality.

The child learns interaction quality not only through successful use, but also through degraded control, accidental damage, caregiver guidance, and future adjustment.

A basic interaction-quality sequence:

```text
high-force object action
→ near-damage or damage trace
→ self-caused consequence logged
→ later lower force or slower timing
→ reduced damage risk
```

This is not guilt, punishment, remorse, moral learning, or self-blame.

The core rule remains:

```text
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

Interaction-quality learning requires more than damage alone:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

P2 also introduces satiation.

Satiation prevents repetitive object fixation.

A typical object cycle:

```text
discovery
→ repeated interaction
→ predictability rises
→ mastery rises
→ satiation rises
→ interest decreases
→ exploration shifts
→ later possible return
```

A satiation trace:

```json
{
  "t": 10400,
  "phase": "P2b",
  "event": "object_satiation_update",
  "object_id": "ball_1",
  "satiation_before": 0.42,
  "satiation_after": 0.58,
  "learning_progress": 0.01,
  "interest_after": 0.31
}
```

P2 later introduces object affinity and toy-missing.

Only attachable objects may become attachment anchors.

```text
affinity[obj] = slow object-relevance variable
interest[obj] = current action-relevance variable
satiation[obj] = temporary object-priority reduction
```

Toy-missing may arise when a high-affinity, currently relevant object is absent:

```text
toy_missing_distress[obj] =
    κ_toy · affinity[obj] · interest[obj] · (1 − presence[obj])
```

Toy-missing is not felt longing. It is a functional disruption pattern caused by the absence of a relevant object under specific trace conditions.

Caregiver dynamics may become relevant in P2c.

Caregiver interaction supports:

* contact regulation,
* separation distress,
* caregiver search,
* comfort-after-loss,
* distress reduction,
* delayed or inconsistent response tracking,
* benign guidance,
* boundary learning,
* category-stabilizing signals,
* misattunement candidates.

P2c may introduce caregiver response variability:

```text
comfort
delayed response
ignored distress
guidance
category-stabilizing signals
misattunement
boundary learning
```

A comfort-after-loss trace:

```json
{
  "t": 12800,
  "phase": "P2c",
  "event": "comfort_after_loss",
  "object_id": "blanket_1",
  "caregiver_id": "caregiver_1",
  "distress_before": 0.72,
  "distress_after": 0.37,
  "distress_drop": 0.35,
  "claim_level": "functional_comfort_response_trace"
}
```

A caregiver-guidance trace:

```yaml
caregiver_guidance_trace:
  phase: P2a
  caregiver_signal: careful
  context:
    object_fragility: high
    near_damage_trace: true
    force_before_guidance: high
  later_adjustment:
    lower_force: true
    slower_timing: true
    increased_observation: true
  claim_level: functional_guidance_to_interaction_quality_trace
```

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

P2d introduces minimal protolanguage.

Language begins as grounded labels, not narratives.

A safe sequence:

```text
stable object
→ functional object
→ repeated reference
→ word-object mapping
```

Example:

```yaml
word_object_mapping:
  symbol: "ball"
  object_id: ball_1
  source:
    type: functional_object
    mastery: 0.76
    PE_AUC_interaction: 0.18
    trace_grounded: true
```

P2 MIP observes:

```text
A = object, caregiver, absence, fragility, risk, and category-signal differentiation
C = object function, caregiver response, guidance, and distress-recovery coherence
R = self-caused consequence sensitivity and response-relation adjustment
E = object interaction, caregiver search, distress expression, and early language use
D = guardrail against overinterpretation, punishment language, trauma language, and inner-life claims
```

Possible P2 IA patterns:

```text
IA-A≫E:
    object/caregiver structure detected but action remains low

IA-E≫A:
    object interaction high despite weak object stability or weak fragility detection

IA-R≪E:
    high object action but weak consequence adjustment

object-overfocus pattern:
    repeated object interaction despite low learning progress and high satiation
```

A P2-level success template:

```yaml
P2_interaction_quality_success:
  minimal_success:
    - object_interaction_produces_stable_traces

  strong_success:
    - damage_or_near_damage_changes_later_force_or_timing
    - caregiver_guidance_becomes_legible

  partial_success:
    - object_interaction_occurs_but_adjustment_is_inconsistent
    - caregiver_guidance_is_detected_but_not_yet_stable

  failure_modes:
    - repeated_damage_without_adjustment
    - object_fixation_without_satiation
    - guidance_indistinguishable_from_adverse_blocking

  premature_unlock_risks:
    - language_labels_before_trace_grounding
    - diary_rendering_before_minimal_sentence_formation
    - responsibility_claims_before_self_caused_consequence_adjustment
```

P2 is the first phase where attachment-like dynamics become structurally meaningful, but only in functional terms.

The claim boundary:

```text
P2 may show object interaction, interaction-quality traces,
satiation, toy-missing, caregiver search, caregiver response variability,
comfort-after-loss, caregiver guidance, boundary learning,
category-stabilizing signals, and minimal protolanguage.

P2 does not show felt love,
felt longing,
subjective suffering,
full language,
moral responsibility,
guilt,
punishment,
clinical obsession,
trauma,
or phenomenal consciousness.
```

### 11.10 P2a — Objects, Basic Play, and Interaction Quality

P2a introduces object interaction and basic play.

The agent now begins to learn that some stable structures in the environment can be acted upon and may change in predictable ways.

The focus is:

```text
object discovery
object approach
basic interaction
object function prediction
object mastery
object fragility traces
self-caused object consequences
interaction-quality learning
accidental damage and near-damage
caregiver guidance as optional modulator
```

P2a activates:

```text
INTERACT_OBJECT
object_candidate_tracking
proto-object stabilization
functional object learning
object PE
object mastery
object fragility detection
object damage and near-damage logging
basic self-caused consequence logging
interaction-quality traces
```

P2a does not yet require:

```text
toy-missing
strong object attachment
caregiver comfort
language
diary
full responsibility
moral learning
```

Objects should enter as simple interactable entities.

Examples:

```text
ball
block
soft toy
sound toy
light toy
container
movable object
fragile object
```

Each object may have simple latent functions:

```text
roll
move
make_sound
light_up
open
close
bounce
stay_stable
break_or_damage
```

The agent should not know these functions in advance. It must discover them through interaction.

A simple object configuration:

```yaml
object:
  id: ball_1
  type: toy
  position: [8, 5]
  attachable: true
  function: roll
  visible: true
  fragility: low
```

A fragile object configuration:

```yaml
object:
  id: cup_1
  type: fragile_object
  position: [9, 6]
  attachable: false
  function: move
  visible: true
  fragility: high
  damage_possible: true
```

A first interaction:

```json
{
  "t": 8200,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "unknown",
  "observed": "roll",
  "PE_object": 0.58,
  "self_caused": true,
  "claim_level": "functional_object_interaction_trace"
}
```

Repeated interaction should reduce prediction error if the object function is learnable:

```json
{
  "t": 9100,
  "phase": "P2a",
  "action": "INTERACT_OBJECT",
  "object_id": "ball_1",
  "interaction": "push",
  "expected": "roll",
  "observed": "roll",
  "PE_object": 0.08,
  "mastery_delta": 0.06,
  "self_caused": true,
  "claim_level": "functional_object_mastery_trace"
}
```

Object mastery may be represented as:

```text
object_mastery[obj] ∈ [0, 1]
```

A simplified update:

```text
object_mastery[obj](t+1) =
    object_mastery[obj](t)
  + α · interaction_success
  + β · PE_drop
  − γ · contradiction
```

#### P2a Interaction Quality and Accidental Damage

The child learns interaction quality not only through successful use, but also through degraded control, accidental damage, caregiver guidance, and future adjustment.

Interaction quality is a functional action-quality relation. It is not moral quality.

A basic interaction-quality sequence:

```text
object interaction
→ force / timing / motor noise / fatigue trace
→ near-damage or damage event
→ self-caused consequence trace
→ future force or timing modulation
```

A near-damage trace:

```json
{
  "t": 9500,
  "phase": "P2a",
  "event": "near_damage_event",
  "object_id": "cup_1",
  "action": "push",
  "self_caused": true,
  "avoidable": true,
  "parameter_trace": {
    "force": 0.74,
    "timing": "abrupt",
    "motor_noise": 0.38,
    "fatigue": 0.41,
    "distress": 0.18,
    "prediction_confidence": 0.36,
    "object_fragility": 0.82
  },
  "claim_level": "self_caused_near_damage_trace"
}
```

An accidental damage trace:

```json
{
  "t": 9600,
  "phase": "P2a",
  "event": "object_damage_event",
  "object_id": "cup_1",
  "action": "push",
  "self_caused": true,
  "avoidable": true,
  "parameter_trace": {
    "force": 0.82,
    "timing": "abrupt",
    "motor_noise": 0.43,
    "fatigue": 0.58,
    "distress": 0.31,
    "prediction_confidence": 0.29,
    "object_fragility": 0.76
  },
  "R_signal": 1.0,
  "claim_level": "self_caused_consequence_trace"
}
```

Object damage is not punishment. It is a self-caused consequence trace.

Self-caused consequence traces must never be upgraded into guilt, moral learning, self-blame, or punishment.

Damage is not automatically learning.

Interaction-quality learning requires:

```yaml
interaction_quality_learning_requires:
  self_caused_action_trace: true
  parameter_trace:
    - force
    - timing
    - motor_noise
    - fatigue_or_distress
    - prediction_confidence
    - object_fragility

  consequence_trace:
    - damage
    - near_damage
    - fall
    - near_fall
    - caregiver_boundary

  comparable_future_context: true
  measurable_behavior_change: true
```

A later adjustment trace:

```json
{
  "t": 10400,
  "phase": "P2a",
  "event": "adjusted_object_interaction",
  "source_event": "object_damage_9600",
  "object_id": "cup_1",
  "previous_action": "push_hard",
  "current_action": "push_soft",
  "damage_avoided": true,
  "force_delta": -0.31,
  "timing_change": "slower",
  "claim_level": "functional_interaction_quality_adjustment"
}
```

Caregiver guidance may support interaction-quality learning when active in the phase configuration.

A caregiver signal may interrupt, redirect, slow, scaffold, or boundary an action without being treated as adverse care.

Example:

```yaml
caregiver_guidance_trace:
  phase: P2a
  event: caregiver_boundary_signal
  caregiver_signal: careful
  context:
    object_fragility: high
    near_damage_trace: true
    high_force_action: true
  later_adjustment:
    lower_force: true
    slower_movement: true
    increased_observation: true
  interpretation:
    possible_pattern: benign_guidance
    confidence: medium
  claim_level: functional_guidance_trace
```

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

Carefulness may emerge as an action-quality category only when relevant traces accumulate:

```yaml
carefulness_category_inputs:
  caregiver_signal:
    examples:
      - careful
      - slow
      - soft
      - stop

  embodied_context:
    examples:
      - fragile_object
      - unstable_body_state
      - edge_or_fall_risk
      - high_force_action

  internal_state:
    examples:
      - fatigue
      - distress
      - motor_noise
      - prediction_uncertainty

  consequence_trace:
    examples:
      - near_fall
      - fall_event
      - object_damage
      - caregiver_boundary

  later_adjustment:
    examples:
      - lower_force
      - slower_movement
      - increased_observation
      - avoidance_of_high_risk_angle
```

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

Basic play is defined functionally as repeated object interaction with prediction, salience, and state change.

The safe formulation:

```text
basic play = exploratory object interaction with learnable outcomes
```

Not:

```text
basic play = human-like imaginative play
```

P2a MIP observes:

```text
A = object detection, identity stabilization, fragility detection
C = object function prediction, falling PE, and interaction-quality alignment
R = self-caused consequence logging and later adjustment
E = INTERACT_OBJECT use
D = guardrail against guilt, punishment, moralization, and overclaiming
```

Possible P2a failure modes:

* object interaction unlocks before approach is stable,
* object identity is unstable,
* object PE remains high without learning progress,
* one object dominates all action,
* self-caused consequences are not logged,
* damage occurs without parameter trace,
* damage occurs without later comparable future context,
* object function is assumed without interaction,
* object is named before functional stability,
* object damage is interpreted anthropomorphically,
* caregiver guidance is treated as punishment,
* caregiver word is treated as concept by itself.

P2a exit criteria may include:

```yaml
P2a_exit_criteria:
  object_identity_stability_min: 0.70
  object_interaction_success_rate_min: 0.60
  object_PE_AUC_max: 0.35
  object_mastery_min_for_at_least_one_object: 0.65
  self_caused_consequence_logging: true
  near_damage_or_damage_trace_if_present_has_parameter_trace: true
  repeated_interaction_without_map_collapse: true
  interaction_quality_adjustment_if_consequence_present: traceable
```

A P2a success template:

```yaml
P2a_interaction_quality_success:
  minimal_success:
    - object_interaction_produces_stable_traces
    - self_caused_consequence_logging_available

  strong_success:
    - damage_or_near_damage_changes_later_force_or_timing
    - caregiver_guidance_becomes_legible_if_active
    - object_fragility_becomes_trace_backed

  partial_success:
    - object_interaction_occurs_but_adjustment_is_inconsistent
    - object_fragility_detected_but_not_stable
    - caregiver_guidance_detected_but_not_yet_recontextualized

  failure_modes:
    - repeated_damage_without_adjustment
    - object_fixation_without_satiation
    - guidance_indistinguishable_from_adverse_blocking
    - caregiver_word_treated_as_concept_without_trace

  premature_unlock_risks:
    - object_naming_before_functional_stability
    - diary_rendering_before_trace_provenance
    - responsibility_claims_before_future_adjustment
```

The claim boundary:

```text
P2a may show object interaction, basic functional play,
self-caused consequence traces, object fragility traces,
near-damage, accidental damage, interaction-quality adjustment,
and caregiver-guided action modulation if configured.

P2a does not show felt liking,
symbolic imagination,
guilt,
punishment,
moral responsibility,
language,
carefulness as moral obedience,
or consciousness.
```

### 11.11 P2b — Satiation and Preference Cycles

P2b introduces satiation and preference cycling.

Once objects can be interacted with, the system needs a way to avoid fixation on a single object. Satiation reduces the priority of repeated interaction when learning progress is low or predictability is high.

The focus is:

```text
object interest
satiation
preference shifts
object diversity
object overfocus protection preparation
```

P2b activates or strengthens:

```text
satiation[obj]
interest[obj]
object preference tracking
object diversity metrics
learning-progress-sensitive object selection
alternative-object bias
```

Satiation is object-specific:

```text
satiation[obj] ∈ [0, 1]
```

It rises when the object is repeatedly used, especially when learning progress falls:

```text
satiation[obj](t+1) =
    satiation[obj](t)
  + α · repeated_interaction[obj]
  + β · predictability[obj]
  − γ · time_unused[obj]
```

Interest is more immediate:

```text
interest[obj] =
    f(NeedMatch, Predictability, Satiation, Novelty)
  + β · affinity[obj]
```

In P2b, affinity may remain weak or early. The main mechanism is the relation between novelty, learning progress, predictability, and satiation.

A typical cycle:

```text
object discovered
→ repeated interaction
→ PE decreases
→ mastery increases
→ learning progress falls
→ satiation increases
→ interest decreases
→ another object becomes more attractive
```

A preference-shift event:

```json
{
  "t": 10400,
  "phase": "P2b",
  "event": "object_preference_shift",
  "from_object": "ball_1",
  "to_object": "sound_toy_1",
  "reason": {
    "ball_satiation": 0.84,
    "ball_LP": 0.01,
    "sound_toy_novelty": 0.68,
    "sound_toy_LP": 0.12
  },
  "claim_level": "functional_preference_cycle"
}
```

P2b should not eliminate return behavior. Satiation is temporary. A familiar object may become interesting again after time passes, after context changes, or after recontextualization.

A return event:

```json
{
  "t": 12600,
  "phase": "P2b",
  "event": "object_return",
  "object_id": "ball_1",
  "satiation_before": 0.22,
  "interest_after": 0.51,
  "reason": "satiation_decay_and_new_context",
  "claim_level": "functional_object_return"
}
```

Preference cycles support developmental diversity.

Without satiation:

```text
one object may dominate behavior
```

With excessive satiation:

```text
the agent may abandon objects too quickly
```

The desired regime:

```text
stable enough for mastery
variable enough for exploration
```

P2b may also prepare later caregiver-guidance interpretation.

For example, if a caregiver redirects repeated object interaction, MIP should not immediately classify the redirection as adverse. It may be:

```text
benign guidance
safety boundary
object overfocus modulation
misattunement candidate
overprotection candidate
```

The interpretation depends on trace evidence.

A caregiver redirection trace:

```yaml
caregiver_redirection_trace:
  phase: P2b
  event: caregiver_redirects_object_focus
  condition:
    repeated_same_object_share: high
    learning_progress: low
    object_satiation: high
  outcome:
    alternative_object_interaction: true
    distress_change: low
    later_return_possible: true
  possible_interpretation: benign_guidance
  confidence: low_to_medium
  claim_level: functional_redirection_trace
```

P2b MIP observes:

```text
A = differentiated object field
C = object interaction predictability and satiation coherence
R = early consequence-sensitive adjustment if present
E = object interaction diversity
D = guardrail against felt-preference and moralized interpretations
```

Relevant KPIs:

```text
object_interaction_count
object_diversity
object_PE_AUC
object_mastery
learning_progress_by_object
satiation[obj]
interest[obj]
preference_shift_rate
same_object_interaction_share
object_return_rate
caregiver_redirection_events
```

Possible P2b failure modes:

* no satiation,
* excessive object fixation,
* too much satiation,
* constant switching without mastery,
* preference shifts not tied to learning progress,
* affinity confused with interest,
* caregiver redirection treated as punishment without trace evidence,
* object preference described as felt liking.

A P2b success template:

```yaml
P2b_satiation_success:
  minimal_success:
    - repeated_object_interaction_updates_satiation
    - object_interest_changes_with_learning_progress

  strong_success:
    - preference_shift_occurs_after_low_learning_progress
    - object_return_occurs_after_satiation_decay
    - object_diversity_increases_without_losing_mastery

  partial_success:
    - satiation_updates_but_preference_shift_is_delayed
    - object_diversity_increases_but_mastery_remains_weak

  failure_modes:
    - object_fixation_without_satiation
    - constant_switching_without_learning
    - caregiver_redirection_interpreted_without_trace_basis

  premature_unlock_risks:
    - toy_missing_before_affinity_and_interest_are_stable
    - language_before_stable_object_reference
    - attachment_claims_before_repeated_object_history
```

The claim boundary:

```text
P2b may show object preference cycles, satiation,
object return, object diversity regulation,
and functional object overfocus protection.

P2b does not show boredom,
felt liking,
felt attachment,
clinical obsession,
moral failure,
or conscious preference.
```

### 11.12 P2c — Distress, Toy-Missing, Caregiver Response, and Obsession Protection

P2c introduces distress-related object and caregiver dynamics.

The agent can now respond not only to object interaction, but to object absence, caregiver absence, repeated failure, caregiver response variability, and unresolved disruption.

The focus is:

```text
toy-missing
distress
caregiver search
caregiver response variability
comfort-after-loss
delayed response
ignored distress
caregiver guidance
boundary learning
category-stabilizing signals
misattunement candidates
object overfocus protection
separation-relevant patterns
```

P2c activates or strengthens:

```text
distress
toy_missing_distress
affinity[obj]
caregiver presence/absence
caregiver response variability
contact need
SEARCH_CAREGIVER
comfort events
delayed response traces
ignored distress traces
caregiver guidance traces
boundary learning
category-stabilizing signals
misattunement candidates
CRY/WEEP optional
object overfocus protection
```

P2c may introduce caregiver response variability:

```text
comfort
delayed response
ignored distress
guidance
category-stabilizing signals
misattunement
boundary learning
```

Toy-missing requires an attachable object with sufficient affinity and current relevance.

A simplified formula:

```text
toy_missing_distress[obj] =
    κ_toy · affinity[obj] · interest[obj] · (1 − presence[obj])
```

This does not mean felt longing. It means that absence of a relevant object produces functional disruption.

A toy-missing event:

```json
{
  "t": 14200,
  "phase": "P2c",
  "event": "toy_missing",
  "object_id": "blanket_1",
  "affinity": 0.72,
  "interest": 0.44,
  "presence": 0,
  "toy_missing_distress": 0.31,
  "claim_level": "functional_object_absence_disruption"
}
```

Distress may bias behavior toward object search or caregiver search:

```text
toy_missing_distress high
→ object search bias increases
→ caregiver search bias may increase
→ unrelated exploration decreases
```

Caregiver comfort may reduce distress:

```json
{
  "t": 14420,
  "phase": "P2c",
  "event": "comfort_after_loss",
  "object_id": "blanket_1",
  "caregiver_id": "caregiver_1",
  "distress_before": 0.72,
  "distress_after": 0.37,
  "distress_drop": 0.35,
  "claim_level": "functional_comfort_response_trace"
}
```

A delayed caregiver response trace:

```yaml
caregiver_response_trace:
  phase: P2c
  event: delayed_response
  trigger:
    - toy_missing
    - distress_high
  caregiver_response:
    type: comfort
    delay: medium
  effects:
    distress_reduction: partial
    comfort_prediction_delta: -0.03
    contact_ambivalence_delta: 0.01
  interpretation:
    possible_pattern: caregiver_response_variability
    confidence: low_to_medium
  claim_level: functional_response_variability_trace
```

An ignored-distress trace:

```yaml
caregiver_response_trace:
  phase: P2c
  event: ignored_distress
  trigger:
    - distress_high
    - caregiver_available
  observed_response: none
  effects:
    distress_reduction: weak
    caregiver_search_persistence: increased
    comfort_prediction_delta: -0.05
  interpretation:
    possible_pattern: misattunement_candidate
    confidence: low
  claim_level: functional_response_mismatch_trace
```

Misattunement candidates are functional response-mismatch patterns. Misattunement is not trauma.

Preferred terms include:

```text
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

A controlled analogy may be used only as an analytic comparison:

```text
Some persistent adverse trace clusters may be structurally analogous
to partial trauma-like patterns, without claiming subjective trauma,
clinical trauma, or suffering.
```

Caregiver guidance may also appear in P2c.

A caregiver boundary may interrupt, redirect, slow, scaffold, or protect an action without being treated as adverse care.

A boundary-learning trace:

```yaml
boundary_learning_trace:
  phase: P2c
  surface_event: caregiver_interruption
  context:
    object_fragility: high
    high_force_action: true
    near_damage_trace: true
  possible_interpretations:
    - benign_guidance
    - safety_boundary
    - overprotection_candidate
    - misattunement_candidate
  later_adjustment:
    lower_force: pending
    reduced_damage_risk: pending
  confidence: low_to_medium
  claim_level: functional_boundary_learning_trace
```

A caregiver word may support category stabilization only when trace-grounded.

Example:

```yaml
category_stabilization_trace:
  phase: P2c
  caregiver_signal: careful
  embodied_context:
    - fragile_object
    - high_force_action
  consequence_trace:
    - near_damage
    - caregiver_boundary
  later_adjustment:
    lower_force: true
    slower_movement: true
  category_candidate: carefulness
  claim_level: trace_backed_action_category_candidate
```

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of signal, embodied situation, consequence trace, and later action adjustment.

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

P2c also introduces stronger object overfocus protection.

An object may dominate behavior even when learning progress is low. This should be detected and softly corrected through satiation, alternative-object bias, caregiver redirection if active, or risk-aware behavior modulation.

An object-overfocus protection rule:

```yaml
object_overfocus_protection:
  if:
    object_interaction_share_above: 0.70
    learning_progress_below: 0.05
    window: 500
  then:
    increase_satiation_rate: true
    increase_alternative_object_bias: true
    reduce_same_object_selection: 0.20
```

The term “obsession” is used functionally and cautiously. It means repetitive overconcentration, not a clinical condition.

The safe formulation:

```text
object overfocus = repeated object selection despite low learning progress and high satiation
```

Not:

```text
the agent is obsessed
```

P2c may also introduce optional `CRY/WEEP` as visible distress expression.

This should require:

```text
high unresolved distress
caregiver dynamics active
expression channel enabled
phase configuration permits it
```

A `CRY/WEEP` event:

```json
{
  "t": 14700,
  "phase": "P2c",
  "state": "CRY/WEEP",
  "trigger": "toy_missing",
  "distress": 0.81,
  "caregiver_present": false,
  "claim_level": "functional_distress_expression"
}
```

P2c MIP observes:

```text
A = object absence, caregiver presence/absence, distress-relevant structure, guidance signals, and category signals
C = search, comfort, caregiver-response, boundary, and distress-recovery coherence
R = self-caused consequence adjustment if relevant
E = object search, caregiver search, visible distress expression, and guidance-modulated action
D = guardrail against longing, suffering, trauma, punishment, and moralization claims
```

Possible P2c IA patterns:

```text
IA-A≫E:
    object absence detected, but no search despite low risk

IA-E≫A:
    repeated search without stable absence detection or topology

IA-R≪E:
    repeated self-caused loss, damage, or boundary conflict without adjustment

object-overfocus:
    repeated interaction despite low learning progress and high satiation

caregiver-response instability:
    response variability remains unresolved across windows
```

P2c exit criteria may include:

```yaml
P2c_exit_criteria:
  toy_missing_detectable: true
  distress_modulates_behavior: true
  comfort_after_loss_logged: true
  caregiver_search_traceable: true
  caregiver_response_variability_logged: true
  guidance_events_traceable_if_active: true
  category_signals_not_treated_as_concepts_by_themselves: true
  object_overfocus_not_persistent: true
  distress_recovery_measurable: true
```

A P2c success template:

```yaml
P2c_caregiver_response_success:
  minimal_success:
    - toy_missing_detectable
    - caregiver_presence_absence_detectable
    - distress_modulates_search_or_contact_behavior

  strong_success:
    - comfort_after_loss_reduces_distress_trace
    - delayed_response_updates_caregiver_response_expectation
    - caregiver_guidance_becomes_distinguishable_from_adverse_blocking
    - category_stabilizing_signal_is_trace_grounded

  partial_success:
    - caregiver_search_occurs_but_response_prediction_is_noisy
    - toy_missing_detected_but_distress_recovery_is_inconsistent
    - boundary_learning_is_present_but_not_recontextualized

  failure_modes:
    - ignored_distress_without_response_variability_tracking
    - misattunement_candidate_treated_as_trauma
    - guidance_treated_as_punishment_without_trace_evidence
    - object_overfocus_persists_despite_satiation

  premature_unlock_risks:
    - diary_output_before_minimal_sentence_formation
    - attachment_claims_before_repeated_trace_history
    - category_claims_before_embodied_trace_grounding
```

The claim boundary:

```text
P2c may show toy-missing, distress modulation,
caregiver search, comfort-after-loss, delayed response,
ignored distress traces, caregiver response variability,
caregiver guidance, boundary learning, category-stabilizing signals,
misattunement candidates, and object overfocus protection.

P2c does not show felt grief,
felt abandonment,
felt longing,
subjective suffering,
clinical obsession,
felt love,
punishment,
trauma,
or moral obedience.
```

### 11.13 P2d — Minimal Protolanguage

P2d introduces minimal protolanguage.

Language appears only after stable perception, object interaction, caregiver-response traces, and trace-backed object/action structures exist. It is not the source of the agent’s development. It is an externalization and coordination layer over already-developed structures.

The focus is:

```text id="gn88l8"
word-object mappings
simple action labels
limited caregiver/object references
grounded episode fragments
caregiver category signals
trace-backed action words
```

P2d activates or strengthens:

```text id="dm6ysn"
g_language
word_object_mapping
action_label_mapping
minimal reference
simple expression templates
caregiver_signal_mapping
trace_grounding_checks
```

Language should unlock only when the Genetic Strand permits it.

A possible language gate:

```yaml id="roz0py"
g_language:
  condition_type: hard_gate
  opens_when:
    object_mastery_stable: true
    repeated_object_reference: true
    interaction_success_above: phase_relative_threshold
    object_PE_AUC_below: phase_relative_threshold
    success_log_quality: sufficient
    trace_grounding_available: true
    phase_at_least: P2d
```

The threshold values are implementation parameters. They are not maturity, consciousness, or personhood thresholds.

The first language form is naming.

A named object requires a stable functional object:

```text id="lm0e97"
functional object
→ repeated reference context
→ word-object mapping
```

Example:

```yaml id="v37smt"
word_object_mapping:
  symbol: "ball"
  object_id: ball_1
  confidence: 0.73
  source:
    type: functional_object
    mastery: 0.76
    PE_AUC_interaction: 0.18
    trace_grounded: true
```

The agent should not learn “ball” as a free-floating label. The label must attach to traceable perception and action history.

A naming event:

```json id="pzbh2u"
{
  "t": 16800,
  "phase": "P2d",
  "event": "functional_object_to_named_object",
  "object_id": "ball_1",
  "symbol": "ball",
  "trigger_metrics": {
    "mastery": 0.76,
    "PE_AUC_interaction": 0.18,
    "repeated_reference_contexts": 8,
    "trace_grounded": true
  },
  "claim_level": "functional_label_binding"
}
```

Minimal action labels may follow:

```text id="qvighc"
push
roll
sleep
search
give
hold
wait
soft
careful
stop
```

These should connect to logged action patterns.

Example:

```yaml id="rrnyfb"
action_label_mapping:
  symbol: "push"
  action_pattern:
    primitive: INTERACT_OBJECT
    interaction_type: push
  evidence:
    occurrences: 24
    outcome_predictability: 0.68
    trace_grounded: true
```

Caregiver category signals may become language-relevant in P2d, but only under strict trace conditions.

The caregiver may function as a category stabilizer by attaching simple signals or words to recurring embodied situations. Words such as “careful,” “soft,” “wait,” or “danger” do not create concepts by themselves, but may help stabilize trace-backed action categories when paired with embodied risk, object fragility, caregiver guidance, and later behavioral adjustment.

The caregiver word is not sufficient. The concept stabilizes only through repeated coupling of:

```text id="e9dewt"
signal
embodied situation
consequence trace
later action adjustment
```

A trace-backed caregiver-signal mapping:

```yaml id="3zvqdv"
caregiver_signal_mapping:
  symbol: "careful"
  source: caregiver_signal
  embodied_contexts:
    - fragile_object
    - high_force_action
    - near_damage
  later_adjustments:
    - lower_force
    - slower_movement
    - increased_observation
  confidence: medium
  claim_level: trace_backed_action_category_candidate
```

Carefulness may become a minimal action-quality category only if the relevant trace structure exists:

```yaml id="sn5qpm"
carefulness_category_inputs:
  caregiver_signal:
    examples:
      - careful
      - slow
      - soft
      - stop

  embodied_context:
    examples:
      - fragile_object
      - unstable_body_state
      - edge_or_fall_risk
      - high_force_action

  internal_state:
    examples:
      - fatigue
      - distress
      - motor_noise
      - prediction_uncertainty

  consequence_trace:
    examples:
      - near_fall
      - fall_event
      - object_damage
      - caregiver_boundary

  later_adjustment:
    examples:
      - lower_force
      - slower_movement
      - increased_observation
      - avoidance_of_high_risk_angle
```

Carefulness is not moral obedience. It is an emerging action-quality category under risk, fragility, guidance, and consequence traces.

Simple episode fragments may appear later in P2d:

```text id="qujk3a"
ball roll
caregiver come
toy gone
sleep now
wait now
soft push
```

These are not full narratives. They are minimal grounded expressions.

A safe episode fragment:

```json id="d99ecq"
{
  "t": 17600,
  "phase": "P2d",
  "event": "minimal_expression",
  "expression": "toy gone",
  "source_trace": "toy_missing_17420",
  "claim_level": "functional_reference"
}
```

A caregiver-guidance expression:

```json id="xz24xv"
{
  "t": 18100,
  "phase": "P2d",
  "event": "minimal_expression",
  "expression": "careful push",
  "source_trace": "caregiver_signal_careful_17880",
  "supporting_traces": [
    "fragile_object_context_17870",
    "near_damage_17875",
    "lower_force_adjustment_18020"
  ],
  "claim_level": "trace_backed_action_category_expression"
}
```

Language in P2d may support caregiver interaction, but it must not install adult cognition.

Allowed:

```text id="l6mj56"
naming stable objects
labeling repeated actions
expressing minimal object absence
responding to simple caregiver labels
marking trace-backed action qualities
```

Not allowed:

```text id="u6b4s8"
full diary
moral confession
abstract self-description
untraceable emotion claims
adult explanation of inner life
category claims without trace grounding
```

A translator may render internal labels into human-readable language, but translator output must be marked as surface communication and claim-filtered.

The developmental core remains:

```text id="wzg0n5"
object trace
action trace
caregiver signal trace
MIP trace
language binding
```

Not:

```text id="x6nrx0"
language fluency first
development later
```

P2d MIP observes:

```text id="y57g3o"
A = symbolically available object, action, caregiver-signal, and episode structures
C = label-to-trace coherence
R = consequence and guidance labels only if grounded in self-caused or response-relevant traces
E = language use as minimal expression or action support
D = guardrail against inner-life, moral, and concept-installation overclaims
```

Relevant KPIs:

```text id="o75mb5"
word_object_mapping_count
label_trace_alignment
unsupported_label_count
action_label_mapping_count
caregiver_signal_mapping_count
minimal_expression_count
translator_overreach_count
language_gate_validity
trace_grounding_rate
category_signal_overclaim_count
```

P2d exit criteria may include:

```yaml id="wmmk32"
P2d_exit_criteria:
  word_object_mappings_min: phase_relative_target
  label_trace_alignment_min: phase_relative_target
  unsupported_label_count_max: phase_relative_limit
  action_label_mappings_min: phase_relative_target
  caregiver_signal_mappings_if_active: trace_grounded
  translator_overreach_count: 0
  language_gate_traceable: true
  minimal_expression_trace_provenance: true
```

A P2d success template:

```yaml id="n4j3wh"
P2d_minimal_language_success:
  minimal_success:
    - stable_object_labels_are_trace_grounded
    - action_labels_match_repeated_action_traces
    - unsupported_label_count_remains_low

  strong_success:
    - caregiver_signals_become_trace_backed_action_category_candidates
    - minimal_expressions_preserve_source_trace_links
    - label_use_improves_later_action_or_search

  partial_success:
    - object_labels_grounded_but_action_labels_noisy
    - caregiver_signal_detected_but_not_yet_category_stable
    - minimal_expressions_exist_but_remain_sparse

  failure_modes:
    - language_unlocks_too_early
    - labels_attach_to_unstable_objects
    - action_words_lack_action_traces
    - caregiver_words_are_treated_as_installed_concepts
    - translator_invents_feelings
    - diary_like_language_appears_prematurely

  premature_unlock_risks:
    - diary_before_minimal_sentence_formation
    - self_description_before_trace_based_episode_structure
    - responsibility_claims_before_self_caused_consequence_adjustment
```

Possible failure modes:

* language unlocks too early,
* labels attach to unstable objects,
* action words lack action traces,
* caregiver words are treated as concepts by themselves,
* translator invents feelings,
* diary-like language appears prematurely,
* language output is treated as consciousness evidence,
* protolanguage bypasses MIP/trace grounding.

The claim boundary:

```text id="jd249o"
P2d may show grounded labels, action words,
caregiver signal mappings, and minimal trace-based expressions.

P2d does not show full language,
full semantics,
selfhood,
confession,
subjective memory,
moral obedience,
or consciousness.
```

### 11.14 P3+ — Planning and Social Roles

P3+ introduces simple planning and early social-role structure.

The agent is no longer limited to immediate perception, movement, object interaction, caregiver search, and minimal labels. It can begin to organize short sequences of action, compare possible outcomes, use trace-backed action categories, and participate in role-like patterns.

P3+ activates or strengthens:

```text id="xsmy9q"
simple planning
counterfactual simulation
repair behavior
role-sensitive action
trace-backed category use
guidance-sensitive action
stronger consequence integration
early norm sensitivity
more stable RVR(t)
```

P3+ does not mean adult planning, moral agency, social understanding, or full selfhood.

The safe definition is:

```text id="tm983w"
P3+ = phase of short-horizon action organization,
counterfactual comparison,
and early role-sensitive behavior
```

Not:

```text id="eavqec"
P3+ = mature social cognition
P3+ = moral personhood
P3+ = conscious planning
```

A simple planning sequence may be:

```text id="d6100k"
detect object
→ predict interaction result
→ choose action
→ observe consequence
→ adjust later action
```

A slightly richer sequence:

```text id="fcyb7v"
toy absent
→ search object
→ search caregiver
→ receive comfort
→ update future search pattern
```

P3+ may introduce counterfactual simulation:

```text id="oug9k2"
actual action:
    push_hard → object damaged

counterfactual action:
    push_soft → predicted object intact
```

A counterfactual trace:

```json id="av7z5k"
{
  "t": 28600,
  "phase": "P3",
  "event": "counterfactual_simulation",
  "source_event": "object_damage_28100",
  "actual_action": "push_hard",
  "alternative_action": "push_soft",
  "predicted_alternative_outcome": "object_intact",
  "confidence": 0.61,
  "R_relevance": true,
  "claim_level": "functional_counterfactual_trace"
}
```

This supports responsibility-like development, but only functionally.

P3+ may also introduce simple repair behavior.

Example:

```json id="c5brve"
{
  "t": 29200,
  "phase": "P3",
  "event": "repair_attempt",
  "source_event": "object_damage_28100",
  "object_id": "block_1",
  "action": "attempt_repair",
  "self_caused_source": true,
  "repair_success": false,
  "R_signal": 0.58,
  "claim_level": "functional_repair_attempt"
}
```

Repair behavior is not guilt. It is consequence-sensitive adjustment.

The core boundary remains:

```text id="dz3hhd"
Self-caused consequence traces must never be upgraded into guilt,
moral learning, self-blame, or punishment.
```

P3+ may begin to use trace-backed categories such as carefulness.

A careful-action trace:

```yaml id="sfri1u"
trace_backed_category_use:
  phase: P3
  category_candidate: carefulness
  source_traces:
    - caregiver_signal_careful
    - fragile_object_context
    - near_damage_event
    - lower_force_adjustment
  action:
    primitive: INTERACT_OBJECT
    modulation:
      lower_force: true
      slower_timing: true
      increased_observation: true
  claim_level: functional_action_quality_category_use
```

This is not moral obedience. It is action-quality modulation under risk, fragility, guidance, and consequence traces.

Social roles may also begin to appear.

A role is a stable pattern of relation and expected action. In P3+, roles remain simple and functional.

Examples:

```text id="xk769m"
child-like dependent role
caregiver-receiving role
helper-like role
object-owner-like relation
comfort-seeking role
comfort-receiving role
guidance-receiving role
repair-oriented role
```

The agent may begin to detect that some agents or entities have different functions in recurring interactions.

For example:

```text id="f6k4sx"
caregiver provides comfort
agent receives comfort
agent searches caregiver under distress
caregiver response reduces distress
caregiver boundary may guide high-risk action
```

This is a role-like pattern, not full social understanding.

P3+ MIP observes:

```text id="kzv1u4"
A = role-relevant structure, category use, and consequence availability
C = action-sequence, guidance, counterfactual, and role coherence
R = future adjustment after self-caused consequences and response-relevant traces
E = planned, repair, guidance-sensitive, or role-sensitive action
D = guardrail against moralization, punishment language, and personhood claims
```

Possible P3+ IA patterns:

```text id="djfr6n"
IA-A≫E:
    agent detects role, guidance, or consequence structure but does not act

IA-E≫A:
    agent acts socially or sequentially without stable role/consequence awareness

IA-R≪E:
    agent acts frequently but does not adjust after consequences

early IA-Overhang:
    prior distress or loss traces shape behavior beyond current conditions
```

P3+ may support stronger `RVR(t)` because actions can now be evaluated as:

```text id="ex319x"
internally selected
coherent
consequence-sensitive
```

A P3+ RVR report:

```yaml id="j3d00b"
RVR_report:
  phase: P3
  window: [28000, 30000]

  all_actions: 120
  qualifying_actions:
    internally_selected_and_coherent_and_R_marked: 39

  RVR: 0.33

  evidence:
    - counterfactual_simulation_used
    - object_damage_followed_by_adjustment
    - repair_attempt_logged

  claim_level: functional_response_relation_viability
```

P3+ should also preserve the external scaffold motif:

```text id="x5zpn3"
external scaffold
→ trace
→ stabilized pattern
→ internal proxy
→ recontextualized use
→ role/norm/diary integration
```

For guidance, this may appear as:

```text id="t8ynp7"
caregiver boundary signal
→ boundary-learning trace
→ stabilized guidance pattern
→ action-quality category candidate
→ careful action under risk
→ later role or norm relevance
```

This must not be described as a fully internal moral faculty unless supported by trace-backed behavioral and representational evidence.

P3+ exit criteria may include:

```yaml id="npoikj"
P3_plus_exit_criteria:
  simple_planning_traceable: true
  counterfactual_simulation_grounded: true
  self_caused_consequence_adjustment_rate_min: phase_relative_target
  repair_or_compensation_attempts_logged: true
  role_sensitive_patterns_detectable: true
  trace_backed_category_use_detectable: true
  unsupported_social_claims: 0
```

A P3+ success template:

```yaml id="fvlsu9"
P3_plus_planning_role_success:
  minimal_success:
    - simple_planning_sequences_are_traceable
    - counterfactual_simulation_uses_available_actions
    - role_sensitive_patterns_are_detectable

  strong_success:
    - self_caused_consequence_adjustment_improves_across_windows
    - repair_or_compensation_attempts_follow_relevant_consequence_traces
    - trace_backed_action_categories_modulate_behavior

  partial_success:
    - planning_exists_but_counterfactual_confidence_is_low
    - role_patterns_detected_but_not_stable
    - repair_attempts_exist_but_are_inconsistent

  failure_modes:
    - planning_without_trace_basis
    - counterfactuals_use_unavailable_actions
    - repair_behavior_scripted_without_consequence_link
    - social_behavior_interpreted_as_moral_understanding
    - MIP_nudges_become_role_control

  premature_unlock_risks:
    - diary_before_trace_condensation_stability
    - caregiver_transition_before_role_and_R_trajectories_stabilize
    - norm_claims_before_core_norm_traces_exist
```

Possible failure modes:

* planning appears without trace basis,
* counterfactuals use unavailable actions,
* repair behavior is scripted rather than consequence-sensitive,
* role language becomes anthropomorphic,
* social behavior is interpreted as moral understanding,
* RVR(t) is treated as free will or moral responsibility,
* MIP nudges become role control.

The claim boundary:

```text id="p5ai41"
P3+ may show simple planning, counterfactual modeling,
repair attempts, trace-backed category use,
and early role-sensitive behavior.

P3+ does not show full social understanding,
moral agency,
guilt,
free will,
felt responsibility,
or phenomenal consciousness.
```

### 11.15 P4+ — Diaries and Narrative Reflection

P4+ introduces diary condensation and narrative reflection.

The diary layer externalizes developmental traces into structured language. It does not reveal subjective experience. It does not prove selfhood. It is a late-stage reconstruction layer built from prior traces.

P4+ activates or strengthens:

```text id="fjd28t"
diary candidate selection
structural condensation
episode reconstruction
MIP trajectory summaries
IA summaries
RVR(t) summaries
D guardrail warnings
recontextualization markers
human-readable translation
re-internalization
narrative identity-like structure
```

The safe definition:

```text id="bs5365"
P4+ = phase of trace-based diary condensation
and narrative reconstruction
```

Not:

```text id="gpmwtw"
P4+ = proof of inner self
P4+ = subjective autobiography
P4+ = phenomenal memory
```

Minimal sentence formation is the linguistic threshold for diary rendering. Trace provenance is the architectural validity condition. Controlled rendering is the safety condition.

The hard rules are:

```text id="sk4b8t"
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
```

A diary entry must be grounded in prior traces.

Allowed source material:

```text id="n6jw0h"
success log
imagination buffer
sleep replay
salient events
MIP windows
IA records
RVR(t) curves
D guardrail warnings
recontextualization markers
object histories
caregiver histories
core norm traces
interaction-quality traces
category-stabilization traces
```

Diary development should distinguish:

```yaml id="a8fowd"
diary_development_levels:
  pre_diary_trace_condensation:
    description: "non-linguistic or structured trace condensation"

  diary_candidate:
    description: "episode cluster selected as possibly diary-relevant"

  minimal_sentence_diary:
    requirement:
      - minimal_sentence_formation
      - trace_provenance
      - controlled_rendering

  reflective_diary:
    requirement:
      - richer_linguistic_capacity
      - MIP_context
      - PMS_projection_context_if_available
      - recontextualization_support

  human_translated_diary:
    requirement:
      - translator_layer
      - explicit_claim_filter
```

A diary candidate:

```yaml id="mw3v7x"
diary_candidate:
  id: diary_candidate_23
  phase: P4
  source_events:
    - toy_missing_18420
    - search_caregiver_18510
    - comfort_after_loss_18640
    - attachment_replay_19600
  MIP_sources:
    - W_018
    - W_019
  pattern: loss_to_comfort
  claim_level: functional_trace_reconstruction
```

A safe diary rendering:

```text id="t30rpa"
A familiar object was absent.
Search and distress increased.
Caregiver interaction reduced distress.
This pattern became more stable across later windows.
```

An unsafe diary rendering:

```text id="ru2yfw"
I suffered because I lost the toy and felt comforted by love.
```

The second version makes phenomenal claims that the architecture does not support.

The diary layer may include several stages:

```text id="j69akd"
structural condensation
→ episode selection
→ trajectory summary
→ linguistic realization
→ archival storage
→ later re-internalization
```

#### Structural Condensation

The system selects trace clusters with high developmental relevance.

Possible selection criteria:

* salience,
* prediction error drop,
* distress change,
* attachment relevance,
* self-caused consequence,
* interaction-quality adjustment,
* category-stabilization event,
* caregiver guidance,
* caregiver-response variability,
* IA persistence,
* RVR(t) change,
* phase transition,
* recontextualization.

#### Episode Selection

The system groups traces into an episode.

Example:

```text id="i6wx1t"
toy absent
→ search
→ caregiver comfort
→ distress reduction
```

#### Trajectory Summary

MIP adds windowed developmental context.

Example:

```text id="yqcn7j"
Across several windows, caregiver search became more consistent
after repeated reunion events.
```

#### Linguistic Realization

The diary layer turns the trace structure into readable language.

This may use a translator, but the translator must not invent unsupported inner states.

#### Archival Storage

Diary entries are stored as externalized developmental records.

A diary entry should preserve source references:

```yaml id="rncjur"
diary_entry:
  id: diary_011
  phase: P4
  text: "Caregiver absence became more structured across repeated search and reunion episodes."
  source_trace_ids:
    - caregiver_absence_15100
    - search_caregiver_15180
    - caregiver_reunion_15380
  MIP_windows:
    - W_018
    - W_019
  claim_level: functional
  translator_mode: cautious
  minimal_sentence_formation: true
  trace_provenance: true
  controlled_rendering: true
```

A diary entry based on caregiver guidance:

```yaml id="e3e3be"
diary_entry:
  id: diary_017
  phase: P4
  text: "A boundary signal occurred during high-force object interaction. Later action used lower force in a comparable object context."
  source_trace_ids:
    - caregiver_boundary_22440
    - near_damage_22442
    - lower_force_adjustment_22610
  claim_level: functional_guidance_reconstruction
  translator_mode: cautious
  controlled_rendering: true
```

#### Re-Internalization

Later, the agent may read or use diary entries as part of its own future structure.

This does not mean subjective self-reflection. It means that externalized summaries can become input to later prediction, role, or norm processing.

A re-internalization trace:

```json id="lbc053"
{
  "t": 44000,
  "phase": "P4",
  "event": "diary_reinternalization",
  "diary_entry_id": "diary_011",
  "used_for": [
    "caregiver_absence_prediction",
    "role_model_update"
  ],
  "claim_level": "functional_trace_reuse"
}
```

P4+ may support narrative identity-like structure.

This means that the system can maintain organized continuity across episodes, diaries, roles, and recontextualizations.

The safe formulation:

```text id="vjm759"
narrative identity-like structure =
    stable trace-based continuity across diary and role reconstruction
```

Not:

```text id="p0hbk6"
narrative identity-like structure =
    phenomenal selfhood
```

P4+ MIP observes:

```text id="sm6xa4"
A = diary-relevant structure availability
C = diary-to-trace coherence
R = responsibility-like trajectory reconstruction where trace-backed
E = diary writing, reading, and re-use as action
D = guardrail against felt-memory, inner-life, moral, and personhood claims
```

Relevant KPIs:

```text id="c61osm"
diary_candidate_count
trace_coverage_per_entry
source_trace_alignment
unsupported_diary_claim_count
translator_overreach_count
MIP_marker_alignment
IA_summary_accuracy
RVR_summary_accuracy
reinternalization_events
minimal_sentence_formation_rate
trace_provenance_preservation_rate
controlled_rendering_compliance
```

P4+ exit criteria may include:

```yaml id="fi4reb"
P4_plus_exit_criteria:
  diary_entries_grounded: true
  minimal_sentence_formation_available: true
  trace_provenance_preserved: true
  controlled_rendering_active: true
  unsupported_diary_claim_count: 0
  trace_alignment_min: phase_relative_target
  MIP_trajectory_summary_available: true
  recontextualization_markers_integrated: true
  translator_overreach_count: 0
  reinternalization_traceable: true
```

A P4+ success template:

```yaml id="l0kg9w"
P4_plus_diary_success:
  minimal_success:
    - diary_candidates_are_trace_grounded
    - minimal_sentence_diary_requires_minimal_sentence_formation
    - diary_entries_preserve_source_trace_links

  strong_success:
    - MIP_trajectory_summaries_align_with_source_windows
    - recontextualization_markers_are_integrated_without_overclaiming
    - diary_entries_can_be_reused_without_overwriting_original_traces

  partial_success:
    - diary_candidates_exist_but_linguistic_realization_is_sparse
    - diary_entries_align_with_traces_but_reinternalization_is_weak
    - translator_requires_strong_claim_filtering

  failure_modes:
    - diary_generated_without_trace_basis
    - translator_invents_feelings
    - diary_overwrites_original_traces
    - diary_is_treated_as_consciousness_evidence
    - MIP_summaries_become_moral_labels

  premature_unlock_risks:
    - caregiver_transition_before_role_and_R_trajectories_stabilize
    - norm_application_before_core_norm_traces_exist
    - selfhood_claims_before_claim_filtering
```

Possible failure modes:

* diary generated without trace basis,
* translator invents feelings,
* diary becomes too human too early,
* diary contradicts logs,
* diary overwrites original traces,
* diary is treated as proof of consciousness,
* self-description appears without claim level,
* MIP summaries become moral labels.

The claim boundary:

```text id="eztfrk"
P4+ may show trace-based diary reconstruction,
trajectory summaries, recontextualization summaries,
and narrative identity-like continuity.

P4+ does not show phenomenal memory,
inner autobiography,
moral confession,
subjective selfhood,
or proof of consciousness.
```

### 11.16 P5 — Caregiver Transition

P5 introduces caregiver transition.

This is the most advanced developmental phase in the current EM architecture.

The former child may become Caregiver 2 for a new child agent.

The basic sequence is:

```text id="l5qkeh"
Caregiver 1
→ Child
→ Former Child as Caregiver 2
→ New Child
```

P5 activates or strengthens:

```text id="yfzf7s"
caregiver role
core norm application
comfort behavior
protection behavior
exploration allowance
guidance without rejection
protection without freezing
risk-safety balancing
overprotection detection
IA-Overhang detection
multi-generational continuity
norm transfer
```

P5 is not part of the first implementation target. It is a later research horizon.

The safe definition:

```text id="gw35k1"
P5 = phase in which a formerly dependent agent
takes on a caregiver-like functional role toward a new dependent agent
```

Not:

```text id="s88gku"
P5 = proof of moral adulthood
P5 = proof of love
P5 = proof of consciousness
P5 = human parenthood
```

The transition requires strong prerequisites.

Before P5, the system should have:

* stable perception,
* stable action,
* object and caregiver traces,
* distress and comfort patterns,
* caregiver guidance traces,
* caregiver-response variability traces,
* interaction-quality traces,
* MIP trajectories,
* diary records,
* role-sensitive behavior,
* core norm traces,
* and responsibility-like adjustment.

P5 should not unlock merely because time has passed.

A possible P5 gate:

```yaml id="hc1s7j"
g_caregiver_transition:
  condition_type: developmental_prerequisite
  opens_when:
    diary_layer_stable: true
    role_sensitive_behavior_stable: true
    RVR_min: phase_relative_target
    R_trajectory_stable: true
    core_norms_available: true
    comfort_pattern_learned: true
    guidance_pattern_traceable: true
    caregiver_loss_or_transition_recontextualized: true
    MIP_claim_discipline_active: true
    D_guardrail_active: true
```

The former child now receives new possible actions:

```text id="zgpax7"
CARE_FOR_CHILD
COMFORT_CHILD
PROTECT_CHILD
ALLOW_EXPLORATION
BALANCE_RISK_SAFETY
MODEL_SAFE_ACTION
GUIDE_WITHOUT_REJECTING
PROTECT_WITHOUT_FREEZING
TRANSFER_CORE_NORM
```

These actions are not moral proof. They are role-specific functional behaviors.

Core norms become central:

```yaml id="jo35bv"
core_norms:
  - protect_child
  - allow_exploration
  - balance_risk_safety
```

These norms are intentionally in tension.

A caregiver who only protects may block development.
A caregiver who only allows exploration may fail to stabilize the new child.
A caregiver who balances both may support development more effectively.

A caregiver decision trace:

```json id="i5xuwg"
{
  "t": 62000,
  "phase": "P5",
  "event": "caregiver_decision",
  "new_child_state": {
    "near_risk": true,
    "exploration_value": 0.71,
    "physical_risk": 0.42
  },
  "core_norms_considered": [
    "protect_child",
    "allow_exploration",
    "balance_risk_safety"
  ],
  "action": "allow_exploration_with_boundary",
  "outcome": "safe_exploration_continued",
  "R_signal": 0.74,
  "D_guardrail": {
    "guide_without_rejecting": true,
    "protect_without_freezing": true
  },
  "claim_level": "functional_caregiver_decision_trace"
}
```

P5 makes IA-Overhang especially important.

The former child may carry prior loss, distress, attachment-like instability, persistent misattunement patterns, or unresolved disruption clusters into the caregiver role.

This can produce overprotection:

```text id="brftek"
prior loss salience high
→ protective action high
→ exploration allowance low
→ current risk not high
→ IA-Overhang candidate
```

An IA-Overhang trace:

```yaml id="hg0qmj"
IA_Overhang:
  phase: P5
  domain: caregiver_role
  window: [62000, 64000]

  evidence:
    prior_loss_trace_salience: 0.86
    protect_child_action_rate: 0.78
    allow_exploration_action_rate: 0.12
    current_child_risk_mean: 0.24
    exploration_block_rate: 0.71

  interpretation:
    pattern: "prior loss history may be overconstraining new child's exploration"
    status: persistent
    confidence: medium
    claim_level: functional_role_overhang_pattern
```

IA-Overhang is not a trauma diagnosis, not a moral defect, and not proof of felt grief.

Preferred terms include:

```text id="ndv7tp"
adverse developmental trace
persistent misattunement pattern
unresolved disruption cluster
negative attachment attractor
avoidance/suppression tendency
```

A controlled analogy may be used only as an analytic comparison:

```text id="wmw4dl"
Some persistent adverse trace clusters may be structurally analogous
to partial trauma-like patterns, without claiming subjective trauma,
clinical trauma, or suffering.
```

Adverse developmental traces may later become recognizable as harmful or destabilizing patterns. This is a functional pattern-recognition claim, not a clinical or phenomenological trauma claim.

MIP may respond softly:

```text id="vgc7i8"
mark overprotection
review current risk evidence
support core norm balancing
slightly increase allow_exploration bias under safe conditions
flag D guardrail review
support late reversible nudge only if permitted
```

MIP may not:

```text id="a0ql8h"
force risk exposure
erase loss history
label the caregiver as controlling
override caregiver FSM
convert role behavior into moral judgment
convert role imbalance into personhood ranking
```

P5 also supports multi-generational refinement.

The research question is:

```text id="sxmin4"
Which patterns from prior development become stabilizing care,
which become overprotection,
which distort,
and which recontextualize across generations?
```

P5 MIP observes:

```text id="xrxsx0"
A = awareness of new child state, risk, dependency, and norm conflict
C = coherence of caregiver prediction and action outcomes
R = consequence-sensitive adjustment in caregiving
E = actual caregiving actions
D = guardrail for interaction quality under asymmetry
```

A P5 MIP report:

```yaml id="rukekr"
P5_MIP_report:
  phase: P5
  window: [62000, 64000]

  caregiver_role:
    protect_child_action_rate: 0.61
    allow_exploration_action_rate: 0.38
    comfort_child_action_rate: 0.44
    exploration_block_rate: 0.22

  core_norms:
    protect_child: active
    allow_exploration: active
    balance_risk_safety: active

  ACRE:
    A_norm: 0.82
    C_norm: 0.74
    R_norm: 0.69
    E_norm: 0.71

  RVR:
    value: 0.64
    trend: rising

  IA:
    IA_Overhang: declining

  D_guardrail:
    guide_without_rejecting: true
    protect_without_freezing: true
    comfort_without_capture: true
    explain_without_dominating: true
```

Relevant P5 KPIs:

```text id="h2s5mc"
protect_child_action_rate
allow_exploration_action_rate
comfort_child_action_rate
exploration_block_rate
current_child_risk_mean
risk_prediction_accuracy
core_norm_balance_score
RVR_caregiver_role
IA_Overhang_frequency
new_child_E_pot
new_child_E_act
distress_recovery_after_comfort
overprotection_rate
underprotection_rate
D_guardrail_warning_count
```

P5 can be interpreted through the external scaffold motif:

```text id="cz7r91"
external caregiver guidance
→ trace-backed guidance pattern
→ stabilized caregiver-practice constraint
→ role-sensitive action
→ norm balancing
→ multi-generational transmission
```

This must not be described as a fully internal moral faculty unless supported by trace-backed behavioral and representational evidence.

P5 possible failure modes:

* caregiver transition unlocks too early,
* former child lacks stable R trajectory,
* core norms are applied rigidly,
* protection suppresses exploration,
* exploration allowance ignores risk,
* prior loss overhang dominates behavior,
* MIP becomes moral judgment,
* diary narrative becomes trauma claim,
* functional love dynamics become felt-love claims,
* caregiver role is treated as personhood proof,
* D is treated as a maturity score.

P5 exit criteria are not required for the first research program. P5 may remain open-ended as a long-term developmental horizon.

A possible advanced evaluation criterion:

```yaml id="g631q5"
P5_evaluation_criteria:
  caregiver_role_stable: true
  core_norm_balance_score_min: phase_relative_target
  IA_Overhang_not_persistent: true
  child_exploration_supported: true
  child_distress_recovery_supported: true
  caregiver_RVR_min: phase_relative_target
  diary_trace_alignment_preserved: true
  D_guardrail_active: true
  no_phenomenal_claims_generated: true
  no_moral_status_claims_generated: true
```

A P5 success template:

```yaml id="tsv6xa"
P5_caregiver_transition_success:
  minimal_success:
    - caregiver_role_actions_are_traceable
    - new_child_state_is_detected
    - protection_and_exploration_are_both_available_as_actions
    - D_guardrail_active_under_asymmetry

  strong_success:
    - core_norm_balance_improves_across_windows
    - IA_Overhang_declines_after_current_risk_review
    - caregiver_guidance_supports_exploration_without_rejection
    - protection_occurs_without_freezing_new_child_E_act

  partial_success:
    - caregiver_role_active_but_norm_balance_noisy
    - protection_works_but_exploration_allowance_low
    - comfort_behavior_available_but_response_calibration_unstable

  failure_modes:
    - overprotection_persistent
    - underprotection_under_high_risk
    - role_action_without_current_child_state_awareness
    - MIP_role_evaluation_becomes_moral_label
    - prior_loss_trace_rendered_as_felt_grief

  premature_unlock_risks:
    - caregiver_role_before_R_trajectory_stability
    - norm_transfer_before_core_norm_traces_exist
    - multi_generational_claims_before_trace_continuity
```

The claim boundary:

```text id="ljxsna"
P5 may show caregiver-role transition,
core norm balancing,
comfort behavior,
protection behavior,
exploration support,
guidance without rejection,
protection without freezing,
and multi-generational pattern transfer.

P5 does not show moral adulthood,
felt parental love,
human ethical understanding,
legal responsibility,
personhood,
rights status,
or phenomenal consciousness.
```

The final P5 rule is:

```text id="g52pvy"
Caregiver transition is a functional role transformation,
not a proof of inner life.
```

> Cross-reference:
> For the full treatment of multi-generational caregiver transition, caregiver-role dynamics, functional love dynamics, comfort-after-loss, received guidance, overprotection, and boundary transmission, see `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`, especially Chapter 12.
> This block defines P5 as a phase and gate horizon; Block 04 owns the multi-generational caregiver content.

> Cross-reference:
> For the full treatment of PMS projection, operator-compatible regularities, diary reduction, norm transfer representation, and VM-facing implementation boundaries, see `06_PMS_VM_Implementation_Spine.md`, especially Chapter 14.
> This block uses PMS only as a possible later projection and implementation-facing reference layer; PMS is not an early internal agent structure and does not validate phase development.

> Cross-reference:
> For the full treatment of consciousness-research outlook and related-work comparison, see `07_Language_Diary_Consciousness_Related_Work.md`, especially Chapters 15 and 17.
> This block preserves phase claim boundaries; no phase, gate, diary, role transition, or caregiver transition proves consciousness, personhood, sentience, or moral status.
