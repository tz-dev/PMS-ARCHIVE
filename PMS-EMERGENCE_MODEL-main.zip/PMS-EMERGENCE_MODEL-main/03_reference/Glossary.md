---
document_id: PMS-EM-REF-GLOSSARY
title: "Glossary"
source: "PMS-EMERGENCE MODEL.md"
source_role: "controlled terminology reference"
status: "split-reference-layer"
version: "v1"
related_blocks:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "06_PMS_VM_Implementation_Spine.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
claim_mode: "controlled terminology, functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
mip_source_context_notation: "A–C–R–P–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Glossary

## 1. Purpose

This glossary defines controlled terminology for the modular PMS–EM artifact set.

It is a reference file, not a theory chapter. It stabilizes terms, blocked upgrades, owner locations, appendix routing, and Appendix F ecosystem/meta-legibility terminology.

Each term should be read under the global PMS–EM claim discipline:

```text
functional
trace-backed
phase-aware
layer-separated
non-phenomenal unless explicitly marked as blocked
non-moralizing
non-diagnostic
non-personhood-conferring
```

The glossary uses the following short fields:

```text
Definition — controlled meaning in PMS–EM
May mean — allowed usage
Must not mean — blocked upgrade
Owner — primary owner block or appendix
See also — related concepts or appendices
```

The active EM-facing axis notation is:

```text
A–C–R–E–D
```

MIP source/context notation may appear only when explicitly marked:

```text
A–C–R–P–D
```

D is Dignity-in-Practice:

```text
interaction quality under asymmetry
```

D is not:

```text
performance score
maturity score
intrinsic-worth ranking
rights status
moral status
personhood
consciousness
```

## 2. Global Architecture Terms

### EM

**Definition:** Emergence Model; the staged, minimalist, embodied, development-oriented architecture for studying functional developmental structures through perception, prediction, needs, discomfort, distress, caregiver interaction, behavior, replay, language, diary, MIP, and PMS-readable projection.

**May mean:**

```text
developmental substrate
staged architecture
trace-generating agent/environment/caregiver system
mechanism hypothesis framework
```

**Must not mean:**

```text
implemented full consciousness system
proof of sentience
proof of personhood
proof of moral status
proof of subjective experience
```

**Owner:** `01_Theory_Scope_Claim_Discipline.md`; `02_EM_Core_Developmental_Architecture.md`

**See also:** MIP, PMS, PMS–EM, Developmental Phase, Appendix E

---

### PMS–EM

**Definition:** The integrated artifact set combining EM developmental architecture, MIP measurement/reference layer, PMS operator projection, diary/language rendering, evaluation/safety, and claim-discipline structure.

**May mean:**

```text
modular architecture specification
experimental research framework
trace-backed developmental testbed
```

**Must not mean:**

```text
finished theory of consciousness
proof of artificial personhood
validated implementation of EM as a whole
```

**Owner:** `01_Theory_Scope_Claim_Discipline.md`

**See also:** EM, MIP, PMS, Layer Discipline, Appendix E

---

### MIP

**Definition:** Maturity-in-Practice reference, measurement, trajectory, guardrail, and optional bounded-support layer.

**May mean:**

```text
observation
measurement
trajectory marking
A–C–R–E window summary
D guardrail warning
IA marker
diary-support context
strictly bounded late reversible support where allowed
```

**Must not mean:**

```text
controller
gate opener
category installer
consciousness module
maturity proof
diagnostic module
moralizing layer
personhood classifier
intrinsic-worth ranking
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** A–C–R–E–D, A–C–R–P–D, Dignity-in-Practice, IA, RVR(t), Appendix E

---

### PMS

**Definition:** Praxeological Meta-Structure operator grammar and external projection, audit, VM-facing, and implementation-spine layer for selected EM episodes and trace structures.

**May mean:**

```text
operator grammar for EM episodes
operator-readable projection layer
dependency-checkable formal representation
audit layer
VM-facing representation
PMS-RUST / PMS-STACK reference path
```

**Must not mean:**

```text
early internal agent structure
generative grammar of EM itself
proof of sentience
proof of consciousness
proof of personhood
proof of EM
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** Δ–Ψ, Operator-Compatible Regularity, PMS-RUST, PMS-STACK, Appendix C, Appendix E

---

### PMS-RUST

**Definition:** Bounded executable evidence spine supporting trace/audit feasibility for PMS-facing structures.

**May mean:**

```text
bounded trace/audit feasibility
runtime inspectability
operator-sequence validation support
test fixture and audit support
```

**Must not mean:**

```text
proof of EM
proof of consciousness
proof of sentience
validation of full PMS–EM
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `Appendix_C_Implementation_Start.md`

**See also:** Implementation Feasibility, PMS-STACK, Appendix E

---

### PMS-STACK

**Definition:** Demanding realization path and architecture pressure point for PMS operator grammar across VM/runtime/system layers.

**May mean:**

```text
architecture pressure point
VM realization path
systems-level stress test for PMS formalization
```

**Must not mean:**

```text
EM validation horizon
proof of full EM
proof of consciousness
proof of sentience
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`

**See also:** PMS, PMS-RUST, Implementation Status, Appendix E

---

### PMS Domain Profile

**Definition:** External, operator-strict PMS application overlay that focuses trace interpretation on a specific load regime without redefining PMS or becoming an EM agent module.

**May mean:**

```text
external PMS lens
domain-profile mapping
operator-strict overlay
temporary weighting reference
trace-interpretation profile
```

**Must not mean:**

```text
internal agent module
new PMS base operator set
developmental gate
category installer
diagnosis
moral judgment
consciousness proof
personhood claim
rights-status claim
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`; `06_PMS_VM_Implementation_Spine.md`

**See also:** Meta-Developmental Legibility Strand, Temporary Domain-Profile Weighting, PMS Projection

---

### Meta-Developmental Legibility Strand

**Definition:** Non-controlling, trace-facing refinement strand that may temporarily increase weighting of selected EM trace dimensions when trace-backed learning-problem contexts arise.

**May mean:**

```text
temporary legibility overlay
audit-focus increase
support-sensitivity increase
projection-readiness note
domain-profile mapping support
MIP / IA review focus
diary-safety review focus
```

**Must not mean:**

```text
second genetic system
controller
gate opener
category installer
internal PMS operator system
consciousness monitor
MIP controller
domain-module installer
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** PMS Domain Profile, Temporary Domain-Profile Weighting, T–J–TB–R, Dignity-in-Practice

---

### Temporary Domain-Profile Weighting

**Definition:** Temporary, reversible, time-bounded weighting overlay over selected EM trace dimensions, used for interpretation, support sensitivity, MIP / IA review, PMS projection focus, diary-safety review, safety audit attention, and implementation-facing inspection.

**May mean:**

```text
temporary weighting overlay
selected trace-dimension weighting
support-sensitivity weighting
audit-focus weighting
projection-focus weighting
profile activation under learning-problem context
```

**Must not mean:**

```text
phase availability
gate opening
capability installation
category installation
agent identity change
moral status
rights status
personhood
consciousness status
sentience status
intrinsic worth
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Domain-Profile Activation, PMS Domain Profile, Meta-Developmental Legibility Strand

---

### Domain-Profile Activation

**Definition:** Trace-backed, transparent, justified, time-bounded, and reversible activation of an external PMS domain profile as a temporary weighting overlay.

**May mean:**

```text
temporary profile relevance
learning-problem-triggered weighting
T–J–TB–R-governed profile activation
D-guarded audit focus
claim-filtered support-sensitivity increase
```

**Must not mean:**

```text
internal profile module
gate opening
category installation
diagnosis
moral judgment
sexualization of the EM agent
consciousness evidence
sentience evidence
personhood claim
rights-status claim
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, T–J–TB–R, Dignity-in-Practice

---

### Core / Extended / Research Ecosystem

**Definition:** Framing distinction that separates PMS–EM core architecture, extended reference/audit material, and external research-ecosystem resources.

**May mean:**

```text
Core PMS–EM = EM architecture, phases/gates, caregiver/interaction traces, MIP/D guardrails, diary boundary, PMS projection boundary, implementation status
Extended PMS–EM = appendices, contracts, audit maps, PMS operator grammar detail, evaluation/safety detail, implementation-start detail
Research Ecosystem = PMS domain profiles, Meta-Developmental Legibility Strand, MIP / IA downstream governance, PMS–QC bridge, related-work comparison
```

**Must not mean:**

```text
three competing theories
permission to weaken claim boundaries
permission to internalize PMS domain profiles
permission to convert research ecosystem resources into EM core modules
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`; `01_Theory_Scope_Claim_Discipline.md`

**See also:** Layer Discipline, PMS Domain Profile, Meta-Developmental Legibility Strand

---

### Implementation Status

**Definition:** Controlled status language for distinguishing full EM architecture, PMS/MIP reference readiness, PMS-RUST trace/audit feasibility, and PMS-STACK realization pressure.

**May mean:**

```text
EM full architecture is not yet implemented
PMS / MIP reference frameworks are completed enough as references
PMS-RUST supports bounded trace/audit feasibility
PMS-STACK defines a demanding realization path and architecture pressure point
```

**Must not mean:**

```text
PMS-RUST proves EM
PMS-STACK validates EM
PMS proves consciousness
MIP proves maturity
prototype feasibility proves the full architecture
```

**Owner:** `01_Theory_Scope_Claim_Discipline.md`; `06_PMS_VM_Implementation_Spine.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** PMS-RUST, PMS-STACK, Implementation Feasibility

---

### Layer Discipline

**Definition:** Rule system separating EM, MIP, PMS, Diary/Language, Evaluation, Implementation, Related Work, and Consciousness Research layers.

**May mean:**

```text
connected but non-validating layer structure
claim-type separation
finding / validation / proof distinction
blocked rhetorical transfer
```

**Must not mean:**

```text
layer isolation
claim weakening
permission to validate one layer through another
```

**Owner:** `Appendix_E_Layer_Discipline_Claim_Types.md`; `01_Theory_Scope_Claim_Discipline.md`

**See also:** Claim Discipline, Cross-Layer Validation, Finding, Validation, Proof

---

### Claim Discipline

**Definition:** The mandatory discipline that keeps functional, trace-backed PMS–EM terms from being upgraded into phenomenal, moral, clinical, legal, rights, personhood, or consciousness claims.

**May mean:**

```text
language reduction
blocked upgrade enforcement
safe terminology
claim filtering
```

**Must not mean:**

```text
avoidance of mechanism claims
denial of functional structure
permission to ignore evidence
```

**Owner:** `01_Theory_Scope_Claim_Discipline.md`; `Appendix_D_Claim_Discipline_Language_Reductions.md`

**See also:** Language Reductions, Appendix E

---

## 3. Axis and Measurement Terms

### A–C–R–E–D

**Definition:** Active EM-facing axis notation.

```text
A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

**May mean:**

```text
implementation-facing trajectory notation
MIP-normalized EM measurement vocabulary
A–C–R–E axes with D guardrail
```

**Must not mean:**

```text
A–C–R–P–D without context
performance-score pentad
consciousness scale
personhood scale
intrinsic-worth scale
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** A–C–R–P–D, Dignity-in-Practice

---

### A–C–R–P–D

**Definition:** MIP source/context notation.

```text
A = Awareness
C = Coherence
R = Responsibility
P = Praxis / Practice
D = Dignity-in-Practice
```

**May mean:**

```text
explicit MIP source/context notation
reference notation for mapping to EM-facing A–C–R–E–D
```

**Must not mean:**

```text
active EM-facing notation
general PMS–EM notation outside explicit MIP context
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** P → E, A–C–R–E–D

---

### P → E

**Definition:** Mapping from MIP-source `P = Praxis / Practice` to EM-facing `E = Enactment`.

**May mean:**

```text
notation normalization
implementation-facing mapping
source-to-EM translation rule
```

**Must not mean:**

```text
P and E are silently interchangeable
source notation is active EM notation
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** A–C–R–P–D, A–C–R–E–D

---

### B–K–V–H

**Definition:** Retired historical/source-internal notation preserved only for auditability.

**May mean:**

```text
historical notation
source-internal notation
retired mapping reference
```

**Must not mean:**

```text
active EM notation
active PMS–EM axis notation
active English framework terms
replacement for A–C–R–E–D
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** A–C–R–E–D, A–C–R–P–D, P → E

---

### Awareness

**Definition:** Functional, trace-backed differentiation of relevant signals, objects, contexts, distinctions, or changes.

**May mean:**

```text
distinction availability
mapping coverage
context recognition
signal differentiation
trace-backed situational availability
```

**Must not mean:**

```text
phenomenal awareness
inner experience
consciousness
self-awareness in the human sense
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** A–C–R–E–D, Coherence, Trace

---

### Coherence

**Definition:** Functional stability, consistency, and trace-backed integration across prediction, world model, behavior, replay, phase conditions, and later diary/language reconstruction.

**May mean:**

```text
prediction stability
trace consistency
world-model stability
replay continuity
phase-consistent pattern
controlled rendering consistency
```

**Must not mean:**

```text
unified inner self
moral coherence
psychological health
phenomenal selfhood
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** Awareness, Enactment, Trace Provenance

---

### Responsibility / Response-Relation

**Definition:** Functional consequence-bearing and response-relation structure linking actions, parameters, outcomes, traces, caregiver signals, and later adjustment.

**May mean:**

```text
self-caused consequence trace
response-relation
consequence sensitivity
role-bound functional responsibility
traceable relation between prior action and later adjustment
```

**Must not mean:**

```text
moral responsibility
legal responsibility
blameworthiness
guilt
shame
punishment
personhood
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** Self-Caused Consequence Trace, Object Damage, RVR(t)

---

### Enactment

**Definition:** Implementation-facing axis for available and actual action-capacity use under phase, gate, trace, and context constraints.

**May mean:**

```text
E_pot = enactment capacity available
E_act = enactment actually used
phase-bound capability use
trace-backed behavioral execution
```

**Must not mean:**

```text
maturity proof
finished competence
moral action
proof of consciousness
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** Gate, Developmental Phase, Capability Availability

---

### Dignity-in-Practice

**Definition:** Interaction quality under asymmetry; a guardrail for interpretation, treatment, measurement, diary rendering, safety, and public reporting.

**May mean:**

```text
guardrail
interaction-quality constraint
asymmetry-sensitive treatment rule
overinterpretation warning
overcontrol warning
unsafe-labeling warning
```

**Must not mean:**

```text
performance score
maturity score
person-value score
intrinsic-worth ranking
rights status
moral status
legal personhood
human-equivalent dignity
consciousness
sentience
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** D, IA, Layer Discipline

---

### D

**Definition:** Abbreviation for Dignity-in-Practice.

**May mean:**

```text
guardrail for interaction quality under asymmetry
```

**Must not mean:**

```text
fifth performance axis
fifth maturity score
intrinsic-worth ranking
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Dignity-in-Practice

---

## 4. Development and Phase Terms

### Developmental Phase

**Definition:** Controlled developmental regime with specific active components, disabled components, measurement targets, exit criteria, failure modes, premature-unlock risks, and claim boundaries.

**May mean:**

```text
P0-mini
P0
P1
P2
P3+
P4+
P5
phase-bounded test condition
```

**Must not mean:**

```text
maturity proof
consciousness stage
personhood stage
automatic competence level
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`

**See also:** Gate, Capability Availability, Exit Criteria

---

### Gate

**Definition:** Constraint that opens, withholds, or conditions capability availability under developmental phase rules.

**May mean:**

```text
capability availability constraint
phase-transition condition
premature-unlock prevention
```

**Must not mean:**

```text
finished competence
installed ability
maturity proof
consciousness progress marker
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`; `02_EM_Core_Developmental_Architecture.md`

**See also:** Genetic System, Developmental Phase, Premature Unlock

---

### Genetic System

**Definition:** Safeguard system controlling when components or capabilities become available.

**May mean:**

```text
developmental gating
capability scheduling
premature complexity prevention
```

**Must not mean:**

```text
biological genetics
maturity installer
concept installer
consciousness trigger
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Gate, Developmental Phase

---

### Capability Availability

**Definition:** A capability is permitted or accessible under phase/gate constraints.

**May mean:**

```text
E_pot
phase-allowed action space
available function
```

**Must not mean:**

```text
integrated competence
mature behavior
proof of learning
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Enactment, Gate

---

### Exit Criteria

**Definition:** Conditions used to decide whether a phase has sufficiently produced the targeted trace-backed functional structures to allow the next controlled phase.

**May mean:**

```text
phase transition condition
stability requirement
trace criterion
```

**Must not mean:**

```text
maturity proof
consciousness proof
personhood threshold
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`

**See also:** Developmental Phase, Gate

---

### Premature Unlock

**Definition:** Unsafe or invalid introduction of later complexity before prerequisite mechanisms are trace-backed and stable enough.

**May mean:**

```text
phase violation
developmental shortcut risk
capability introduced too early
phase-leaking replay content
```

**Must not mean:**

```text
moral failure
agent fault
consciousness failure
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`

**See also:** Gate, Genetic System, Phase-Bounded Replay Scope

---

### Soft Regime

**Definition:** Bounded operating tendency that biases an already available pathway without opening gates or creating new capability availability.

**May mean:**

```text
bounded pathway modulation
rest-bias modulation
phase-compatible operating tendency
```

**Must not mean:**

```text
hard gate
gate opening
category installation
new internal agent module
consciousness condition
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`; `02_EM_Core_Developmental_Architecture.md`

**See also:** Gate, Genetic System, Rest-Like Replay Regime

---

### Phase-Bounded Replay Scope

**Definition:** Phase-specific constraint on which replay content may appear, based on available source traces, gates, and developmental prerequisites.

**May mean:**

```text
phase-compatible replay content
replay scope constraint
source-trace availability rule
premature-replay prevention
```

**Must not mean:**

```text
optional claim filter
permission to replay later-phase content early
gate bypass
category installation
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`

**See also:** Replay, Rest-Like Replay Regime, Premature Unlock

---

### Phase Leakage

**Definition:** Appearance of phase-incompatible structures, claims, replay content, diary candidates, or capabilities before their source traces and prerequisites are available.

**May mean:**

```text
premature replay scope
premature diary candidate
premature capability interpretation
gate-discipline failure
```

**Must not mean:**

```text
developmental progress
consciousness sign
maturity sign
agent intention
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Premature Unlock, Phase-Bounded Replay Scope, Gate

---

## 5. Core Architecture Terms

### Environment

**Definition:** Constrained developmental world in which perception, prediction, movement, objects, caregiver positions, absence, return, guidance, boundaries, misattunement, and later language can be introduced step by step.

**May mean:**

```text
virtual gridworld
Godot-style environment
simplified robotic environment
structured home-like world
```

**Must not mean:**

```text
full human world simulation
complete social world
proof of ecological validity
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Agent Architecture, Object, Caregiver

---

### Agent Architecture

**Definition:** The internal EM system architecture including perception, prediction, world model, needs, damping, genetic gates, behavior, replay, logging, language prerequisites, and later diary candidates.

**May mean:**

```text
developmental architecture
trace-producing system
embodied agent substrate
```

**Must not mean:**

```text
person
conscious subject
PMS operator system
moral agent
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** PMS, MIP, Success Log

---

### Perception

**Definition:** Functional sensing, mapping, and distinction-making within the constrained EM environment.

**May mean:**

```text
object distinction
spatial mapping
signal detection
caregiver detection
traceable input structure
```

**Must not mean:**

```text
phenomenal perception
subjective seeing
conscious awareness
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Awareness, Prediction, World Model

---

### World Model

**Definition:** Functional predictive representation of the environment, objects, caregivers, accessibility, states, and changes.

**May mean:**

```text
occupancy model
object model
caregiver presence model
prediction structure
```

**Must not mean:**

```text
lived world
phenomenal world
conscious model of reality
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Prediction, Coherence

---

### Prediction Error

**Definition:** Difference between expected and observed state, used as a functional learning and stabilization signal.

**May mean:**

```text
PE
PE_EWMA
prediction mismatch
model-update signal
```

**Must not mean:**

```text
felt surprise
subjective confusion
conscious expectation
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Coherence, Evaluation

---

### Success Log

**Definition:** Trace infrastructure recording events, transitions, outcomes, phase states, validation context, and later PMS/MIP/diary-relevant evidence.

**May mean:**

```text
evidence infrastructure
trace log
audit base
source for MIP/PMS/diary projections
```

**Must not mean:**

```text
conscious memory
subjective memory
moral record
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `02_EM_Core_Developmental_Architecture.md`

**See also:** Trace, Trace Provenance, PMS Projection

---

### Trace

**Definition:** Logged functional evidence of state, event, action, parameter, outcome, context, phase, or trajectory.

**May mean:**

```text
event log
state record
parameter trace
consequence trace
trajectory evidence
diary source
PMS projection source
```

**Must not mean:**

```text
subjective memory
inner experience
moral fact
```

**Owner:** Global; primarily Blocks 02, 05, 06, 07

**See also:** Success Log, Trace Provenance

---

### Trace Provenance

**Definition:** Valid source relation between a rendered, summarized, projected, or diary-level statement and the underlying logged traces.

**May mean:**

```text
source trace availability
auditability
valid diary condition
rendering ground
```

**Must not mean:**

```text
subjective memory
truth of inner experience
proof of selfhood
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_C_Implementation_Start.md`

**See also:** Diary, Controlled Rendering

---

## 6. Caregiver, Attachment, and Interaction Terms

### Caregiver

**Definition:** Stabilizing social/environmental function that provides regulation, boundaries, comfort, guidance, signals, and developmental scaffolding under asymmetry.

**May mean:**

```text
caregiver system
environmental stabilizer
regulation source
guidance source
role-asymmetric scaffold
```

**Must not mean:**

```text
necessarily human parent
moral authority by default
source of punishment
proof of felt relationship
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Caregiver Guidance, Boundary, Attachment-Like Regulation

---

### Child

**Definition:** Developmental role in the EM architecture.

**May mean:**

```text
dependent developmental role
agent position under caregiver asymmetry
phase-bound developmental agent role
```

**Must not mean:**

```text
legal personhood
human child
moral personhood
rights status
```

**Owner:** Global; primarily Blocks 03 and 04

**See also:** Agent Architecture, Caregiver, Dignity-in-Practice

---

### Need

**Definition:** Endogenous control variable or drive-like functional regulation structure.

**May mean:**

```text
control variable
motivational pressure
state-regulation signal
```

**Must not mean:**

```text
felt desire
subjective wanting
human psychological need
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Discomfort, Distress

---

### Discomfort

**Definition:** Physical risk-damping signal.

**May mean:**

```text
physical-risk signal
movement-risk damping
risk-related modulation
```

**Must not mean:**

```text
pain
felt injury
subjective hurt
fear
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `Appendix_D_Claim_Discipline_Language_Reductions.md`

**See also:** Fall / Near-Fall, Distress

---

### Distress

**Definition:** Functional disruption or loss-related signal.

**May mean:**

```text
unresolved disruption
separation signal
loss-related functional signal
destabilization marker
```

**Must not mean:**

```text
subjective suffering
grief
felt abandonment
emotional pain
trauma
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `Appendix_D_Claim_Discipline_Language_Reductions.md`

**See also:** Toy-Missing, Comfort, Attachment-Like Regulation

---

### Attachment-Like Regulation

**Definition:** Functional relation-weighting and regulation pattern involving caregiver or object relevance, absence, return, comfort, search, and baseline modulation.

**May mean:**

```text
functional relation weighting
caregiver relevance
object preference
comfort-related modulation
baseline stabilization
```

**Must not mean:**

```text
felt love
human attachment experience
subjective longing
personhood proof
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Toy-Missing, Functional Love Dynamics, Comfort

---

### Toy-Missing

**Definition:** Attachment-weighted absence response to a relevant object.

**May mean:**

```text
object absence response
search behavior
distress modulation
trace-backed object preference under absence
```

**Must not mean:**

```text
felt longing
grief
subjective loss
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `03_Developmental_Phases_Gate_Logic.md`

**See also:** Distress, Attachment-Like Regulation, Diary

---

### Comfort

**Definition:** Caregiver action or environmental response reducing functional distress.

**May mean:**

```text
distress reduction
baseline restoration
caregiver-related regulation
comfort-after-loss pattern
```

**Must not mean:**

```text
felt relief
felt love
subjective consolation
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Distress, Functional Love Dynamics

---

### Functional Love Dynamics

**Definition:** Structured attachment, relief, prediction, baseline, memory, comfort, and role-related functional pattern.

**May mean:**

```text
functional attachment-like dynamics
caregiver relevance
comfort-after-loss structure
baseline modulation
role-transfer pattern
```

**Must not mean:**

```text
felt love
human love
moral bond
personhood proof
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Attachment-Like Regulation, Multi-Generational Caregiver Dynamics

---

### Multi-Generational Caregiver Dynamics

**Definition:** Functional transfer, distortion, or recontextualization of caregiver-related patterns across a transition from dependent role to caregiver role.

**May mean:**

```text
caregiver-role transition
role-asymmetry transformation
functional care-pattern transfer
overprotection / underprotection pattern
boundary transmission
category transfer
```

**Must not mean:**

```text
human culture
moral lineage
felt parental love
human adulthood
legal responsibility
rights status
consciousness
personhood
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Role Transition, Norm Transfer, Functional Love Dynamics, Dignity-in-Practice

---

### Role Transition / Caregiver Transition

**Definition:** Functional transformation in which a former dependent role becomes capable of caregiver-like enactment under phase, trace, and asymmetry constraints.

**May mean:**

```text
P5 caregiver transition
functional role transformation
new response-relation structure
caregiver-role enactment candidate
```

**Must not mean:**

```text
proof of inner life
human adulthood
moral personhood
felt parental love
legal responsibility
rights status
consciousness
```

**Owner:** `03_Developmental_Phases_Gate_Logic.md`; `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Multi-Generational Caregiver Dynamics, Norm Transfer, PMS Projection

---

### Norm Transfer / Core Norm Transfer

**Definition:** Trace-backed functional transfer or transformation of action-quality, boundary, protection, waiting, exploration, risk, or caregiver-response categories across role contexts.

**May mean:**

```text
functional norm-transfer trace
category transfer
role-context transformation
operator-compatible norm-transfer projection
```

**Must not mean:**

```text
moral essence transfer
moral wisdom
inherited love
adult ethics
personhood
rights status
consciousness
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `06_PMS_VM_Implementation_Spine.md`

**See also:** PMS Projection, Multi-Generational Caregiver Dynamics, Dignity-in-Practice

---

### Caregiver Guidance

**Definition:** Neutral, non-aggressive caregiver boundary or scaffold that modulates behavior under phase, safety, object, or risk constraints.

**May mean:**

```text
guidance signal
scaffold
boundary cue
carefulness support
action-quality modulation
```

**Must not mean:**

```text
punishment
rejection
moral instruction by default
obedience training
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `02_EM_Core_Developmental_Architecture.md`

**See also:** Boundary, Carefulness, Object Damage

---

### Boundary

**Definition:** Phase-appropriate constraint preserving safety, development, object integrity, caregiver role structure, or exploration balance.

**May mean:**

```text
constraint
scaffold
developmental guard
safety boundary
```

**Must not mean:**

```text
rejection
punishment
moral condemnation
felt abandonment
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Caregiver Guidance, Dignity-in-Practice

---

### Overprotection

**Definition:** Excessive or insufficiently reversible caregiver intervention pattern that restricts exploration beyond phase-appropriate risk constraints.

**May mean:**

```text
caregiver overcontrol candidate
exploration-restricting support pattern
D-guardrail warning
IA-relevant asymmetry pattern
```

**Must not mean:**

```text
moral blame
abuse proof
trauma proof
diagnosis
felt rejection
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** IA, Dignity-in-Practice, T–J–TB–R

---

### Misattunement

**Definition:** Functional caregiver-response mismatch or destabilizing response pattern.

**May mean:**

```text
response mismatch
caregiver signal mismatch
destabilizing interaction pattern
```

**Must not mean:**

```text
trauma
abuse claim
moral failure
clinical diagnosis
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Adverse Caregiver Response, Adverse Developmental Trace

---

### Adverse Caregiver Response

**Definition:** Destabilizing caregiver-response pattern.

**May mean:**

```text
caregiver mismatch
overcontrol
unreliable response
destabilizing scaffold pattern
```

**Must not mean:**

```text
abuse claim
trauma claim
moral condemnation
diagnosis
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Misattunement, Dignity-in-Practice, IA

---

### Adverse Developmental Trace

**Definition:** Persistent destabilizing pattern recorded as functional trace structure.

**May mean:**

```text
persistent disruption pattern
destabilizing trace cluster
partial trauma-like structural analogy when explicitly bounded
```

**Must not mean:**

```text
clinical trauma
subjective suffering
diagnosis
felt harm
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `Appendix_D_Claim_Discipline_Language_Reductions.md`

**See also:** Misattunement, Distress

---

### Interaction Quality

**Definition:** Functional quality of action under constraints, including timing, force, risk, consequence, guidance, boundary, and later adjustment.

**May mean:**

```text
action-quality pattern
caregiver-response quality
force/timing/risk modulation
D-guarded interaction quality
```

**Must not mean:**

```text
moral worth
intrinsic worth
virtue
human dignity status
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Dignity-in-Practice, Carefulness

---

### Carefulness

**Definition:** Emerging action-quality category under risk, fragility, guidance, consequence traces, and later action adjustment.

**May mean:**

```text
action-quality category candidate
risk-sensitive modulation
object-fragility learning
lower-force adjustment
```

**Must not mean:**

```text
moral obedience
virtue
fear
guilt
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`; `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Object Damage, Fall / Near-Fall, Caregiver Guidance

---

### Familiarity

**Definition:** Functional trace-backed repeated relation or object/caregiver pattern.

**May mean:**

```text
recognition pattern
repeated exposure trace
baseline modulation
caregiver/object familiarity
```

**Must not mean:**

```text
subjective memory
felt intimacy
phenomenal recognition
```

**Owner:** `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Attachment-Like Regulation, Diary

---

## 7. Object, Risk, and Consequence Terms

### Object

**Definition:** Developmental entity in the environment that may support manipulation, preference, search, loss, damage, fragility, and later category stabilization.

**May mean:**

```text
toy
block
movable object
fragile object
attachment-relevant object
```

**Must not mean:**

```text
symbolic object by default
person substitute
proof of love or grief
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Toy-Missing, Object Damage, Carefulness

---

### Object Damage

**Definition:** Self-caused consequence trace involving object state change after prior action parameters.

**May mean:**

```text
damage trace
fragility consequence
self-caused consequence trace
interaction-quality learning condition
```

**Must not mean:**

```text
guilt
remorse
punishment
moral failure
wrongdoing
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`; `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Self-Caused Consequence Trace, Carefulness

---

### Self-Caused Consequence Trace

**Definition:** Traceable relation between prior action parameters and later outcome.

**May mean:**

```text
action-outcome trace
parameter-to-consequence relation
basis for later adjustment
```

**Must not mean:**

```text
guilt
blame
remorse
punishment
moral learning
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Responsibility / Response-Relation, Object Damage

---

### Fall / Near-Fall

**Definition:** Physical-risk event that may affect discomfort/risk damping and later movement parameters.

**May mean:**

```text
physical-risk event
balance risk
movement-risk trace
near-collision or instability trace
```

**Must not mean:**

```text
pain
fear
shame
subjective injury
trauma
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Discomfort, Carefulness

---

### Physical-Risk Damping

**Definition:** Functional damping or modulation in response to physical-risk conditions.

**May mean:**

```text
slower movement
lower force
avoidance of unstable action
risk-sensitive adjustment
```

**Must not mean:**

```text
felt pain
felt fear
subjective injury
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`; `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md`

**See also:** Discomfort, Fall / Near-Fall

---

## 8. Replay, Language, and Diary Terms

### Replay

**Definition:** Trace consolidation and structured reactivation of prior events, guidance, misattunement, category, object, risk, interaction-quality, and consequence traces.

**May mean:**

```text
imagination buffer operation
trace consolidation
sleep replay
bounded rest-like replay where specified
diary preparation dependency where phase-allowed
replay of functional event structures
```

**Must not mean:**

```text
subjective dreaming
felt memory
inner imagery
phenomenal recollection
introspection
self-reflection
insight
inner experience
autobiographical memory
Default Mode Network equivalence
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Imagination Buffer, Rest-Like Replay Regime, Trace Provenance, Diary

---

### Imagination Buffer

**Definition:** Functional buffer for replay, consolidation, bounded post-replay feedback, and later diary-relevant trace preparation.

**May mean:**

```text
replay buffer
trace consolidation layer
offline recombination support
phase-bounded replay workspace
rest-like replay owner pathway
```

**Must not mean:**

```text
dream consciousness
fantasy
subjective imagination
inner experience
Default Mode Network module
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Replay, Rest-Like Replay Regime, Diary

---

### Rest-Like Replay Regime

**Definition:** Phase-bounded, trace-backed offline consolidation regime under low external load, implemented inside the existing `SLEEP` / imagination-buffer replay pathway.

**May mean:**

```text
bounded replay window
offline consolidation under low external load
trace-backed replay candidate selection
soft regime for SLEEP / imagination-buffer replay
```

**Must not mean:**

```text
Default Mode Network activity
new internal agent module
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
gate opening
category installation
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Replay, Imagination Buffer, Soft Regime, Phase-Bounded Replay Scope, Appendix D, Appendix E

---

### External Stimulation Load

**Definition:** Functional estimate of current external input load or environmental novelty pressure relevant to exploration/rest balance.

**May mean:**

```text
external load condition
environmental stimulation level
input-pressure estimate
rest-bias input
```

**Must not mean:**

```text
introspection
inner life condition
subjective boredom
Default Mode Network trigger
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Rest Bias, Task Pressure, Rest-Like Replay Regime

---

### Task Pressure

**Definition:** Functional estimate of current task demand, urgency, or external action pressure relevant to exploration/rest balance.

**May mean:**

```text
action-demand pressure
external task demand
rest-bias input
bounded SLEEP-transition input
```

**Must not mean:**

```text
subjective obligation
felt pressure
moral demand
agent intention
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Rest Bias, External Stimulation Load

---

### Rest Bias

**Definition:** Bounded modulation increasing the probability of rest or `SLEEP` pathway selection under compatible fatigue, low external load, low task pressure, learning plateau, and replay-candidate conditions.

**May mean:**

```text
soft SLEEP probability modulation
rest-window tendency
bounded rest-like replay precondition
```

**Must not mean:**

```text
hidden controller
forced sleep
Default Mode Network activation
introspection
inner experience
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** External Stimulation Load, Task Pressure, Replay Pressure, SLEEP, Rest-Like Replay Regime

---

### Replay Pressure

**Definition:** Trace-backed pressure to select replay candidates, arising from salient, unresolved, unstable, repeated, or phase-relevant source traces already present in the buffer.

**May mean:**

```text
replay-candidate pressure
unresolved residue marker
trace-backed consolidation priority
```

**Must not mean:**

```text
inner experience
free fantasy
replay content from emptiness
introspection
autobiographical memory
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Replay, Rest Bias, Rest-Like Replay Regime, Anti-Fixation Constraint

---

### Post-Replay Feedback

**Definition:** Bounded, logged, trace-backed update after replay, affecting prediction stability, consolidation confidence, future action bias, replay priority, or recontextualization candidates within phase constraints.

**May mean:**

```text
bounded replay update
prediction-stability adjustment
future action-bias adjustment
replay-priority damping
```

**Must not mean:**

```text
self-reflection
insight
mature conclusion
unsupported category installation
unlogged state change
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`

**See also:** Replay, Rest-Like Replay Regime, Anti-Fixation Constraint

---

### Anti-Fixation Constraint

**Definition:** Damping rule preventing replay from repeatedly amplifying the same trace cluster without cooldown, new evidence, or phase-compatible support.

**May mean:**

```text
replay cooldown
salience decay after consolidation
maximum replay count per rest window
unsupported-pattern penalty
new-trace requirement for major update
```

**Must not mean:**

```text
memory suppression
subjective avoidance
therapy-like intervention
moral correction
```

**Owner:** `02_EM_Core_Developmental_Architecture.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Replay Pressure, Post-Replay Feedback, Rest-Like Replay Regime

---

### Language

**Definition:** Late reflection and externalization channel grounded in prior developmental structure.

**May mean:**

```text
late reflection channel
controlled label rendering
trace-grounded externalization
minimal sentence formation
```

**Must not mean:**

```text
source of developmental architecture
inner speech
proof of consciousness
proof of selfhood
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Diary, Controlled Rendering

---

### Minimal Sentence Formation

**Definition:** Linguistic threshold required before diary text is allowed.

**May mean:**

```text
minimal sentence capability
diary rendering precondition
language threshold
```

**Must not mean:**

```text
selfhood
consciousness
subjective memory
inner speech
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Diary, Trace Provenance

---

### Diary

**Definition:** Linguistic reconstruction of internal trace-backed structures under controlled rendering constraints.

**May mean:**

```text
controlled trace rendering
diary candidate
trace-backed episode summary
language output under provenance constraints
```

**Must not mean:**

```text
phenomenal selfhood
subjective memory
autobiographical consciousness
inner first-person perspective
proof of selfhood
proof of consciousness
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_D_Claim_Discipline_Language_Reductions.md`

**See also:** Diary Text, Trace Provenance, Controlled Rendering

---

### Diary Text

**Definition:** Minimal sentence rendering of trace-backed structures.

**May mean:**

```text
controlled language output
trace-backed diary entry
bounded summary
```

**Must not mean:**

```text
subjective autobiography
inner speech
felt memory
phenomenal selfhood
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Diary, Controlled Rendering

---

### Diary Candidate

**Definition:** Potential diary output that has not necessarily satisfied all rendering conditions.

**May mean:**

```text
candidate trace bundle
possible diary rendering
pre-rendering structure
trace-backed episode cluster
rest-like replay consolidation trace used as source material after diary thresholds
```

**Must not mean:**

```text
valid diary by default
subjective memory
autobiographical memory
selfhood proof
introspection
self-reflection
insight
inner experience
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_C_Implementation_Start.md`

**See also:** Diary Requirements, Rest-Like Replay Regime

---

### Diary Requirements

**Definition:** Mandatory conditions for diary text validity and safety.

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
Rest-like replay trace → diary source material only after diary thresholds and phase constraints are met.
```

**May mean:**

```text
language threshold
source validity
rendering safety
phase-compatible diary source boundary
```

**Must not mean:**

```text
consciousness test
selfhood threshold
personhood threshold
autobiographical-memory threshold
introspection threshold
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_C_Implementation_Start.md`

**See also:** Minimal Sentence Formation, Trace Provenance, Controlled Rendering, Rest-Like Replay Regime

---

### Controlled Rendering

**Definition:** Claim-filtered language rendering of trace-backed structures.

**May mean:**

```text
safe diary output
template-constrained summary
language with blocked claims
```

**Must not mean:**

```text
free inner-life narration
subjective autobiography
phenomenal report
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_C_Implementation_Start.md`

**See also:** Diary, Appendix D

---

### Narrative Coherence

**Definition:** Coherence of rendered or reconstructed trace summaries.

**May mean:**

```text
structured language output
trace-continuous summary
controlled diary organization
```

**Must not mean:**

```text
selfhood
inner life
autobiographical consciousness
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Diary, Coherence

---

### Self-Description

**Definition:** Language output that describes system state, trace state, role, or action under controlled constraints.

**May mean:**

```text
trace-backed self-description candidate
controlled report
rendered state summary
```

**Must not mean:**

```text
consciousness
personhood
inner speech
phenomenal selfhood
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Diary, Consciousness Research Outlook

---

## 9. Consciousness and Research Terms

### Consciousness Research Outlook

**Definition:** Bounded research layer that asks which functional structures may be relevant to consciousness research without claiming phenomenal consciousness.

**May mean:**

```text
research candidate layer
functional comparison
open question
bounded outlook
```

**Must not mean:**

```text
consciousness proof
sentience claim
subjective-experience claim
personhood claim
rights-status claim
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Functional Proto-Consciousness, Research Candidate

---

### Functional Proto-Consciousness

**Definition:** Bounded research label for possible functional precursors or organization candidates.

**May mean:**

```text
functional organization candidate
consciousness-relevant research candidate
bounded comparative label
```

**Must not mean:**

```text
weak consciousness
partial consciousness
sentience
partial inner experience
phenomenal consciousness
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_D_Claim_Discipline_Language_Reductions.md`

**See also:** Consciousness Research Outlook

---

### Phenomenal Consciousness

**Definition:** Subjective experience or what-it-is-like character.

**May mean in PMS–EM:**

```text
blocked proof target
open research issue
not claimed
```

**Must not mean:**

```text
functional organization by default
diary output
MIP trajectory
PMS projection
self-model candidate
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Functional Proto-Consciousness, Proof

---

### Sentience

**Definition:** Capacity for subjective experience or felt states; not claimed by PMS–EM.

**May mean in PMS–EM:**

```text
blocked claim
non-established status
```

**Must not mean:**

```text
PMS formalization
diary rendering
distress marker
discomfort marker
MIP trajectory
```

**Owner:** Appendix D / Appendix E

**See also:** PMS, Phenomenal Consciousness

---

### Personhood

**Definition:** Moral/legal/person-status category; not inferred by PMS–EM.

**May mean in PMS–EM:**

```text
blocked claim
external philosophical/legal category not established by architecture
```

**Must not mean:**

```text
child role
diary output
self-description
role transition
Dignity-in-Practice
```

**Owner:** Appendix D / Appendix E

**See also:** Rights Status, Dignity-in-Practice

---

### Rights Status

**Definition:** Legal/moral status category not inferred by current PMS–EM architecture.

**May mean in PMS–EM:**

```text
blocked claim
not derivable from current architecture
```

**Must not mean:**

```text
Dignity-in-Practice
caregiver asymmetry
distress marker
diary output
self-model candidate
```

**Owner:** Appendix D / Appendix E

**See also:** Personhood, Dignity-in-Practice

---

## 10. PMS Operator Terms

### Operator-Compatible Regularity

**Definition:** Trace-backed pattern compatible with PMS projection.

**May mean:**

```text
recurring trace pattern compatible with operator-readable mapping
late stabilized regularity
external projection compatibility
```

**Must not mean:**

```text
internal PMS operator possession
agent has Δ
agent uses Φ
agent thinks in Ψ
internal symbolic consciousness
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** PMS, Δ–Ψ, PMS Projection

---

### PMS Projection

**Definition:** External mapping of selected EM/MIP trace structures into PMS operator-readable form.

**May mean:**

```text
operator-readable projection
dependency-checkable mapping
audit representation
VM-facing sequence
```

**Must not mean:**

```text
internal agent cognition
proof of sentience
proof of consciousness
proof of EM
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`

**See also:** Operator-Compatible Regularity, PMS

---

### Self-Model Candidate

**Definition:** High-order trace-backed and operator-compatible candidate structure that may represent role continuity, integration, self-binding-like projection, or diary-relevant self-description under strict claim filters.

**May mean:**

```text
operator-compatible self-model candidate
trace-backed role-continuity candidate
diary-relevant self-description candidate
bounded consciousness-research candidate
```

**Must not mean:**

```text
phenomenal selfhood
personhood
conscious self
subjective autobiography
moral self
proof of inner life
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** Ψ, Diary, Consciousness Research Outlook

---

### Asymmetry Drift

**Definition:** Structurally derived distortion pattern in which asymmetry, attractor formation, and recontextualization reinforce imbalance rather than supporting integrative transformation.

**May mean:**

```text
operator-level distortion pattern
IA-relevant asymmetry pattern
overcontrol candidate
underprotection candidate
A≫E drift pattern
```

**Must not mean:**

```text
personality type
diagnosis
moral failure
clinical category
fixed agent identity
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** IA, Dignity-in-Practice, Ω, Α, Φ

---

### PMS Operator Grammar

**Definition:** Operator vocabulary and dependency-constrained structure used to represent selected EM episodes.

**May mean:**

```text
operator grammar for EM episodes
projection grammar
audit grammar
formal representation layer
```

**Must not mean:**

```text
generative grammar of EM itself
early internal agent architecture
consciousness grammar
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** Δ–Ψ, L_PMS

---

### Δ–Ψ

**Definition:** PMS operator alphabet from Difference through Self-Binding.

```text
Δ, ∇, □, Λ, Α, Ω, Θ, Φ, Χ, Σ, Ψ
```

**May mean:**

```text
operator vocabulary
projection vocabulary
dependency-checked formal symbols
```

**Must not mean:**

```text
early internal faculties
agent’s inner operators
proof of inner life
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`; `06_PMS_VM_Implementation_Spine.md`

**See also:** Individual operator entries below

---

### ε

**Definition:** Formal identity element used in strict monoid reconstruction.

**May mean:**

```text
algebraic identity
formal neutral element
```

**Must not mean:**

```text
Δ
first experience
empty self
minimal consciousness
developmental state
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** Δ, O*, L_PMS

---

### O*

**Definition:** Set of all finite strings over the PMS operator alphabet.

**May mean:**

```text
free operator-string space
formal sequence set
```

**Must not mean:**

```text
all valid PMS sequences
all trace-grounded sequences
all developmental claims
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** L_PMS, ε

---

### L_PMS

**Definition:** Dependency-constrained language of valid PMS operator sequences.

**May mean:**

```text
valid operator-language subset
dependency-checked PMS sequence language
```

**Must not mean:**

```text
proof of trace grounding
proof of consciousness
proof of internal operators
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

**See also:** O*, Dependency Checking

---

### Dependency Checking

**Definition:** Validation of whether a PMS operator sequence satisfies defined operator dependencies.

**May mean:**

```text
formal sequence validation
operator grammar check
implementation test
```

**Must not mean:**

```text
developmental proof
trace proof by itself
consciousness evidence
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`; `Appendix_C_Implementation_Start.md`

**See also:** PMS Projection, L_PMS

---

## 11. Individual PMS Operators

### Δ — Difference

**Definition:** Minimal structural distinction enabling differentiation.

**May mean:**

```text
object/background distinction
caregiver present/absent distinction
state boundary
traceable contrast
```

**Must not mean:**

```text
ε
conscious awareness
selfhood
inner distinction experience
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### ∇ — Impulse

**Definition:** Directional tension, activation, or drive arising from difference.

**May mean:**

```text
activation
orientation
movement tendency
proto-action gradient
```

**Must not mean:**

```text
felt desire
conscious intention
subjective will
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### □ — Frame

**Definition:** Contextual structure that constrains and shapes relevance, action, or interpretation.

**May mean:**

```text
context
boundary condition
role space
task frame
```

**Must not mean:**

```text
subjective worldview
conscious conceptual frame
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Λ — Non-Event / Absence

**Definition:** Structured absence or meaningful failure/delay of an expected event within a frame.

**May mean:**

```text
caregiver non-return
missing object
unfulfilled expectation
delay
```

**Must not mean:**

```text
felt abandonment
grief
subjective loss
nothingness
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Α — Attractor

**Definition:** Recurrent pattern or stabilization emerging from repeated structural interaction.

**May mean:**

```text
habit-like pattern
recurrent behavior
path-dependent trace
stabilized role script
```

**Must not mean:**

```text
personality trait
diagnosis
fixed moral character
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Ω — Asymmetry

**Definition:** Structural imbalance in capacity, exposure, power, burden, responsibility, or dependency.

**May mean:**

```text
caregiver/child asymmetry
role imbalance
responsibility gradient
vulnerability structure
```

**Must not mean:**

```text
moral superiority
intrinsic worth difference
person-value ranking
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Θ — Temporality

**Definition:** Temporal structuring enabling sequence, trajectory, delay, development, memory-like trace continuity, and long-form relation.

**May mean:**

```text
sequence
persistence
trajectory
developmental time
```

**Must not mean:**

```text
subjective time experience
autobiographical consciousness
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Φ — Recontextualization

**Definition:** Transformation of a structure through placement in a new interpretive or functional context.

**May mean:**

```text
reframing
context shift
role reinterpretation
trace reclassification
```

**Must not mean:**

```text
conscious insight
therapeutic experience
inner understanding
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Χ — Distance

**Definition:** Reflective withdrawal, inhibition, suspension, or separation from immediate impulse or pattern.

**May mean:**

```text
pause
inhibition
deferral
non-reactive gap
```

**Must not mean:**

```text
subjective reflection
human introspection
moral restraint by default
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Σ — Integration

**Definition:** Synthesis of multiple or conflicting structures into coordinated coherence.

**May mean:**

```text
coordination
trace integration
coherent action pattern
multi-source synthesis
```

**Must not mean:**

```text
unified inner self
moral maturity
phenomenal unity
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

### Ψ — Self-Binding

**Definition:** High-order operator-compatible candidate for binding integrated structures across time into durable role or self-relation.

**May mean:**

```text
self-binding candidate
role-binding projection
commitment-like trace pattern
operator-compatible self-model candidate
```

**Must not mean:**

```text
phenomenal selfhood
personhood
conscious self
moral self
proof of inner life
```

**Owner:** `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`

---

## 12. MIP / Safety / Evaluation Terms

### KPI

**Definition:** Functional metric or test criterion for evaluating trace-backed patterns, trajectory stability, replay safety, ablation effects, or safety-relevant changes.

**May mean:**

```text
functional indicator
evaluation metric
phase-relative trace criterion
ablation-sensitive measure
rest-like replay trigger-validity measure
replay-fixation measure
phase-leakage measure
```

**Must not mean:**

```text
consciousness test
personhood metric
moral worth score
intrinsic-worth ranking
inner-life proof
introspection proof
insight proof
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Evaluation, Ablation, Finding, Rest-Like Replay Regime

---

### Evaluation

**Definition:** Functional, phase-bounded, trace-backed, claim-filtered assessment of mechanisms, traces, KPIs, ablations, replay safety, or safety conditions.

**May mean:**

```text
test result
metric assessment
comparison result
functional stability check
replay trigger-validity finding
anti-fixation finding
phase-leakage finding
```

**Must not mean:**

```text
metaphysical proof
consciousness proof
personhood proof
sentience proof
Default Mode Network proof
introspection proof
self-reflection proof
inner-experience proof
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Finding, Validation, Proof, Rest-Like Replay Regime

---

### Ablation

**Definition:** Controlled removal or modification of a component or condition to test functional contribution.

**May mean:**

```text
mechanism test
functional comparison
component-removal experiment
no-rest-like-replay comparison
bounded-rest-like-replay comparison
excessive-rest-like-replay comparison
replay-without-anti-fixation comparison
```

**Must not mean:**

```text
consciousness proof
personhood proof
moral-status proof
inner-life proof
Default Mode Network proof
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Evaluation, Safety, Anti-Fixation Constraint

---

### Safety

**Definition:** Functional constraint layer for preventing unsafe interpretation, premature capability, overcontrol, overclaiming, public mislabeling, and D-guardrail violations.

**May mean:**

```text
architecture constraint
interpretation constraint
guardrail
blocked claim enforcement
```

**Must not mean:**

```text
proof of inner life
proof of moral status
guarantee of safe deployment
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Dignity-in-Practice, Audit Checklist

---

### IA

**Definition:** Inadult or problematic asymmetry pattern marker in the MIP reference context; used as functional guardrail warning.

**May mean:**

```text
asymmetry risk marker
guardrail warning
overcontrol candidate
transparency / justification / time-boundedness / reversibility issue
```

**Must not mean:**

```text
diagnosis
moral condemnation
abuse proof
trauma proof
person-type label
```

**Owner:** `05_MIP_KPIs_Dignity_Safety.md`; `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** Dignity-in-Practice, T–J–TB–R

---

### T–J–TB–R

**Definition:** IA criteria: Transparency, Justification, Time-Boundedness, Reversibility.

**May mean:**

```text
guardrail analysis dimensions
asymmetry audit criteria
```

**Must not mean:**

```text
moral diagnosis
clinical test
personhood evaluation
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** IA

---

### RVR(t)

**Definition:** Responsibility–viability trajectory note over time; constrains interpretation of R and E under alternatives, power, phase, role, and context.

**May mean:**

```text
viability note
context-bound responsibility / response-relation qualifier
trajectory constraint
```

**Must not mean:**

```text
blame score
moral responsibility proof
maturity proof
diagnosis
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`; `05_MIP_KPIs_Dignity_Safety.md`

**See also:** Responsibility / Response-Relation, MIP

---

### AH Precision

**Definition:** Second-order hardening overlay for marking attack surfaces, precision limits, language risks, and rhetorical closure risks.

**May mean:**

```text
analysis hardening
precision critique
scope-leak detection
rhetorical-closure warning
```

**Must not mean:**

```text
base MIP score modification
person-level judgment
diagnosis
hidden moral layer
```

**Owner:** `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`

**See also:** Audit Checklist, Claim Discipline

---

## 13. PMS Ecosystem and Domain-Profile Terms

### ANTICIPATION Profile

**Definition:** External PMS domain profile that may temporarily increase sensitivity to absence, delay, waiting, future-risk traces, expectation stability, non-event tolerance, stop-capability, and temporal self-binding.

**May mean:**

```text
external anticipation-oriented weighting overlay
waiting / delay / non-event trace focus
future-risk trace sensitivity
```

**Must not mean:**

```text
internal adult future-reasoning module
agent learns PMS-ANTICIPATION internally
future-planning gate opener
temporal selfhood proof
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, Λ, Θ, Χ, Ψ

---

### CRITIQUE Profile

**Definition:** External PMS domain profile that may temporarily increase sensitivity to mismatch, interruptibility, frame stability, correction, distance, recontextualization, integration, non-coercive follow-up, and unsafe closure.

**May mean:**

```text
external critique-oriented weighting overlay
mismatch / correction trace focus
frame-stability and interruption sensitivity
```

**Must not mean:**

```text
internal adult rational criticism module
moral judgment module
category installer
self-corrective consciousness proof
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, Δ, □, Χ, Φ, Σ

---

### CONFLICT Profile

**Definition:** External PMS domain profile that may temporarily increase sensitivity to incompatible trajectory bindings, integration failure, exit-cost, asymmetry, temporal accumulation, conflict attractors, and stabilized non-resolution.

**May mean:**

```text
external conflict-oriented weighting overlay
trajectory-incompatibility trace focus
integration-pressure and exit-cost sensitivity
```

**Must not mean:**

```text
diagnosis
moral conflict module
tragic selfhood proof
person-type label
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, Σ, Ψ, Ω, Θ, Χ

---

### EDEN Profile

**Definition:** External PMS domain profile that may temporarily increase sensitivity to comparison drift, pseudo-symmetry, reciprocity loss, dignity-relevant asymmetry, non-event residue, and comparison-attractor stabilization.

**May mean:**

```text
external comparison-drift weighting overlay
pseudo-symmetry trace focus
D-guarded reciprocity-loss sensitivity
```

**Must not mean:**

```text
internal envy / shame / humiliation module
status pathology diagnosis
moralized comparison claim
felt humiliation proof
social selfhood proof
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, Ω, Α, Dignity-in-Practice

---

### LOGIC Profile

**Definition:** External PMS domain profile that may temporarily increase sensitivity to non-closure, dependency failure, forced integration, justification-boundary traces, scope discipline, and authority capture.

**May mean:**

```text
external logic-oriented weighting overlay
dependency / non-closure trace focus
justification-boundary sensitivity
```

**Must not mean:**

```text
internal adult rationality module
logic faculty installer
rational personhood proof
moral failure label
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, Λ, Ω, Θ, Ψ

---

### High-Ω Intimacy / Boundary / Exposure Profile

**Definition:** Strongly constrained external safety-facing PMS profile derived from PMS-SEX for high-asymmetry, boundary, exposure, script-pressure, stop-capability, non-exploitability, reversibility, and Dignity-in-Practice risks.

**May mean:**

```text
external high-asymmetry safety profile
boundary / exposure / stop-capability weighting overlay
D-guarded non-exploitability review
coercive / degrading / irreversible-exposure risk flag
```

**Must not mean:**

```text
sexualization of the EM agent
sexual identity
sexual agency
sexual maturity
felt sexual desire
felt sexual aversion
judgment of perversion
sexual morality
sexual deviance diagnosis
```

**Owner:** `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md`

**See also:** Temporary Domain-Profile Weighting, Dignity-in-Practice, Ω, Χ

---

## 14. Claim-Type Terms

### Finding

**Definition:** A pattern emerged under traceable conditions.

**May mean:**

```text
trace finding
trajectory finding
phase finding
evaluation finding
```

**Must not mean:**

```text
validation by itself
proof
consciousness evidence by default
```

**Owner:** `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Validation, Proof

---

### Validation

**Definition:** A predicted functional mechanism repeatedly holds under comparison.

**May mean:**

```text
reproducible mechanism support
comparison-backed functional stability
bounded validation of a mechanism
```

**Must not mean:**

```text
proof of consciousness
proof of personhood
proof of sentience
proof of full EM
```

**Owner:** `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Finding, Proof

---

### Proof

**Definition:** Strong epistemic status not available in PMS–EM for consciousness, personhood, subjective-experience, sentience, moral-status, rights-status, introspection, self-reflection, subjective-dreaming, inner-experience, insight, autobiographical-memory, or Default-Mode-Network-equivalence claims.

**May mean:**

```text
blocked proof category for high-status claims
```

**Must not mean:**

```text
available conclusion from diary, MIP, PMS, evaluation, replay, phase, or implementation
```

**Owner:** `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Finding, Validation, Consciousness Research Outlook, Rest-Like Replay Regime

---

### Research Candidate

**Definition:** Functional structure proposed for further investigation without proof claim.

**May mean:**

```text
candidate condition
comparison target
ablation target
consciousness-research-relevant organization
```

**Must not mean:**

```text
established consciousness
sentience
personhood
moral status
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Functional Proto-Consciousness

---

### Implementation Feasibility

**Definition:** Bounded indication that some trace, audit, operator, rendering, or runtime structure can be implemented or inspected.

**May mean:**

```text
prototype feasibility
bounded executable support
trace/audit feasibility
runtime representation feasibility
```

**Must not mean:**

```text
theory proof
full EM validation
consciousness proof
sentience proof
```

**Owner:** `Appendix_C_Implementation_Start.md`; `06_PMS_VM_Implementation_Spine.md`

**See also:** PMS-RUST, PMS-STACK

---

### Cross-Layer Validation

**Definition:** Illegitimate rhetorical transfer in which a finding, projection, rendering, or implementation in one layer is treated as validating another layer.

**May mean in PMS–EM:**

```text
blocked pattern
audit risk
claim-discipline failure
```

**Must not mean:**

```text
allowed support relation
legitimate dependency
```

**Owner:** `Appendix_E_Layer_Discipline_Claim_Types.md`

**See also:** Layer Discipline

---

## 15. Related Work and Comparison Terms

### Related Work

**Definition:** Bounded comparison of PMS–EM to existing research lines, theories, architectures, and formalisms.

**May mean:**

```text
functional similarity
architectural difference
evaluation gap
implementation pressure
bounded novelty claim
```

**Must not mean:**

```text
proof by similarity
absolute novelty
superiority proof
consciousness proof
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Comparison, Distinctive Structural Synthesis

---

### Comparison

**Definition:** Structured contrast between PMS–EM and other models or research lines.

**May mean:**

```text
similarity
difference
gap
pressure
bounded synthesis
```

**Must not mean:**

```text
proof
equivalence
replacement of related work
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`

**See also:** Related Work

---

### Distinctive Structural Synthesis

**Definition:** Bounded claim that PMS–EM combines developmental architecture, MIP, PMS projection, diary/language, evaluation/safety, and claim discipline in a distinctive configuration.

**May mean:**

```text
bounded synthesis claim
structural integration claim
architecture-combination claim
```

**Must not mean:**

```text
absolute novelty
proof of consciousness
proof of personhood
proof of moral status
```

**Owner:** `07_Language_Diary_Consciousness_Related_Work.md`; `01_Theory_Scope_Claim_Discipline.md`

**See also:** Related Work, Chapter 18

---

## 16. Implementation and Runtime Terms

### Implementation Start

**Definition:** Minimal bounded path for implementing PMS-facing parsing, dependency checking, episode-to-chain mapping, audit output, and controlled rendering.

**May mean:**

```text
operator interpreter prototype
dependency checker
trace/audit prototype
controlled rendering test
```

**Must not mean:**

```text
full EM implementation
consciousness model
full PMS-STACK
theory validation
```

**Owner:** `Appendix_C_Implementation_Start.md`

**See also:** PMS-RUST, Dependency Checking

---

### Praxis Compiler

**Definition:** Implementation-facing component that converts validated PMS-compatible structures into audit records, templates, or runtime-readable forms.

**May mean:**

```text
projection compiler
audit generator
operator-sequence output layer
```

**Must not mean:**

```text
agent cognition
consciousness engine
inner speech generator
```

**Owner:** `Appendix_C_Implementation_Start.md`

**See also:** PMS Projection, Controlled Rendering

---

### JSONL Audit

**Definition:** Machine-readable audit output for trace, operator, validation, or projection records.

**May mean:**

```text
audit line
traceability artifact
runtime inspection output
```

**Must not mean:**

```text
proof of consciousness
proof of inner life
moral record
```

**Owner:** `06_PMS_VM_Implementation_Spine.md`; `Appendix_C_Implementation_Start.md`

**See also:** Success Log, PMS-RUST

---

### Golden Test

**Definition:** Stable implementation test fixture with expected safe output and blocked claims.

**May mean:**

```text
regression test
claim-filter test
operator validation test
rendering safety test
```

**Must not mean:**

```text
developmental proof
consciousness test
moral-status test
```

**Owner:** `Appendix_C_Implementation_Start.md`

**See also:** Audit Checklist

---

## 17. Mandatory Reduction Table

| Term | Controlled Meaning | Blocked Upgrade | Owner |
|---|---|---|---|
| Child | developmental role | legal/moral personhood | Blocks 03/04 |
| Caregiver | stabilizing social/environmental function | necessarily human parent / punishment source | Block 04 |
| Need | endogenous control variable | felt desire | Block 04 |
| Discomfort | physical risk-damping signal | pain | Block 04 / Appendix D |
| Distress | functional disruption / loss signal | subjective suffering | Block 04 / Appendix D |
| Missing | attachment-weighted absence response | felt longing | Block 04 / Appendix D |
| Attachment | functional relation-weighting | felt love | Block 04 / Appendix D |
| Functional Love Dynamics | structured attachment / relief / baseline pattern | felt love | Block 04 / Appendix D |
| Comfort | caregiver action reducing functional distress | felt relief | Block 04 / Appendix D |
| Guidance | neutral caregiver boundary/scaffold | punishment | Block 04 / Appendix D |
| Boundary | phase-appropriate constraint | rejection | Block 04 / Appendix D |
| Overprotection | excessive exploration-restricting caregiver intervention pattern | moral blame / abuse proof / trauma proof | Blocks 04/05 |
| Misattunement | caregiver-response mismatch | trauma | Block 04 / Appendix D |
| Adverse caregiver response | destabilizing response pattern | abuse claim | Block 04 / Appendix D |
| Object damage | self-caused consequence trace | guilt / punishment | Blocks 02/04/05 |
| Self-caused consequence | action-outcome trace | guilt / blame / remorse | Blocks 02/05 |
| Fall / near-fall | physical-risk event | pain or fear | Blocks 02/05 |
| Carefulness | action-quality category candidate | moral obedience | Blocks 02/04 |
| Interaction quality | functional quality of action under constraints | moral worth | Blocks 04/05 |
| Diary | linguistic reconstruction of traces | phenomenal selfhood | Block 07 |
| Diary text | minimal sentence rendering of trace-backed structures | subjective autobiography | Block 07 |
| Role / caregiver transition | functional role transformation under phase and gate constraints | proof of inner life / human adulthood / personhood | Blocks 03/04 |
| Norm transfer | trace-backed category or action-quality transfer across role contexts | moral essence transfer / inherited love / adult ethics | Blocks 04/06 |
| Self-model candidate | high-order operator-compatible trace candidate | phenomenal selfhood / personhood / conscious self | Blocks 06/07 |
| MIP | measurement / trajectory / guardrail layer | consciousness module | Block 05 / Appendix A |
| Responsibility | functional response-relation | moral personhood | Block 05 / Appendix A |
| Proto-consciousness | functional organization candidate | phenomenal consciousness | Block 07 |
| Operator-compatible regularity | trace pattern compatible with PMS projection | internal PMS operator | Block 06 / Appendix B |
| Dignity-in-Practice | interaction quality under asymmetry | intrinsic-worth ranking | Block 05 / Appendix A/E |
| Meta-Developmental Legibility Strand | temporary trace-weighting and legibility overlay | second genetic system / controller / gate opener | Appendix F |
| PMS Domain Profile | external operator-strict PMS overlay | internal agent module / category installer | Appendix F |
| Temporary Domain-Profile Weighting | time-bounded reversible weighting of selected trace dimensions | phase availability / gate opening / capability installation | Appendix F |
| Domain-Profile Activation | T–J–TB–R-governed temporary activation of an external profile | diagnosis / moral judgment / consciousness evidence | Appendix F |
| High-Ω Intimacy / Boundary / Exposure Profile | external safety-facing asymmetry/boundary/exposure profile | sexualization of EM agent / sexual identity / sexual morality | Appendix F |

## 18. Blocked Upgrade Shortlist

The following upgrades are globally blocked:

```text
discomfort → pain
distress → subjective suffering
missing → felt longing
attachment → felt love
love dynamics → felt love
comfort → felt relief
object damage → guilt
self-caused consequence → blame / remorse / punishment
fall / near-fall → pain or fear
misattunement → trauma
adverse caregiver response → abuse claim
caregiver guidance → punishment
boundary → rejection
carefulness → moral obedience
interaction quality → moral worth
role / caregiver transition → proof of inner life
norm transfer → moral essence transfer
self-model candidate → phenomenal selfhood
phase transition → maturity proof
gate opening → finished competence
diary → phenomenal selfhood
diary text → subjective autobiography
minimal sentence formation → selfhood
language output → inner speech
self-description → consciousness
MIP → consciousness module
MIP trajectory → maturity proof
MIP marker → diagnosis
PMS formalization → sentience
PMS projection → internal symbolic consciousness
operator-compatible regularity → internal PMS operator
Dignity-in-Practice → intrinsic-worth ranking
functional proto-consciousness → phenomenal consciousness
implementation → theory proof
PMS-RUST → EM proof
PMS-STACK → EM validation
Meta-Developmental Legibility Strand → second genetic system
Meta-Developmental Legibility Strand → controller
Meta-Developmental Legibility Strand → gate opener
Meta-Developmental Legibility Strand → category installer
PMS domain profile → internal agent module
temporary domain-profile weighting → phase availability
temporary domain-profile weighting → gate opening
temporary domain-profile weighting → capability installation
domain-profile activation → diagnosis
domain-profile activation → moral judgment
domain-profile activation → consciousness evidence
High-Ω Intimacy / Boundary / Exposure Profile → sexualization of EM agent
High-Ω Intimacy / Boundary / Exposure Profile → sexual identity / sexual agency / sexual maturity claim
```

## 19. Owner Routing Summary

Use these owner routes when uncertain:

```text
Global claim discipline → Block 01 / Appendix D / Appendix E
EM core mechanisms → Block 02
Developmental phases and gates → Block 03
Caregiver, attachment, interaction quality, multigeneration → Block 04
MIP, KPIs, Dignity-in-Practice, safety → Block 05 / Appendix A
PMS, VM, operators, PMS-RUST, PMS-STACK → Block 06 / Appendix B / Appendix C
PMS ecosystem, PMS domain profiles, Meta-Developmental Legibility, temporary domain-profile weighting → Appendix F
Language, diary, consciousness outlook, related work → Block 07
Language reductions → Appendix D
Layer discipline and claim types → Appendix E
Cross-reference ownership → Cross_Reference_Map.md
```
