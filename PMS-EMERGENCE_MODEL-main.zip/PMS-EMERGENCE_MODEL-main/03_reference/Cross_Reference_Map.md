---
document_id: PMS-EM-REF-CROSS-REFERENCE-MAP
title: "Cross Reference Map"
source: "PMS-EMERGENCE MODEL.md"
source_role: "reference navigation and ownership map"
status: "split-reference-layer"
version: "v1"
related_blocks:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "06_PMS_VM_Implementation_Spine.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
claim_mode: "navigation-only, ownership-preserving, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
---

# Cross Reference Map

## 1. Purpose

This file maps the modular PMS–EM artifact structure.

It defines:

```text
chapter ownership
block ownership
appendix ownership
concept ownership
allowed cross-reference paths
do-not-duplicate zones
claim-discipline anchors
contract-preparation anchors
PMS ecosystem and Meta-Developmental Legibility routing
```

This file is a navigation and audit artifact. It is not a theory chapter and does not introduce new claims.

The governing rule is:

```text
Each chapter has one owner block.
Each appendix has one reference purpose.
Cross-links may orient.
Cross-links must not duplicate full foreign chapters.
```

The active axis notation is:

```text
A–C–R–E–D
```

MIP source/context notation may appear only where explicitly marked:

```text
A–C–R–P–D
```

Historical or source-internal notation appears only in Appendix A as retired/historical notation.

## 2. Top-Level Artifact Structure

```text
PMS-EM/
  00_source/
    PMS-EMERGENCE MODEL.md
    PMS-EM_Split_Specification_v1.md

  01_blocks/
    01_Theory_Scope_Claim_Discipline.md
    02_EM_Core_Developmental_Architecture.md
    03_Developmental_Phases_Gate_Logic.md
    04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
    05_MIP_KPIs_Dignity_Safety.md
    06_PMS_VM_Implementation_Spine.md
    07_Language_Diary_Consciousness_Related_Work.md

  02_appendices/
    Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
    Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
    Appendix_C_Implementation_Start.md
    Appendix_D_Claim_Discipline_Language_Reductions.md
    Appendix_E_Layer_Discipline_Claim_Types.md
    Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md

  03_reference/
    Glossary.md
    Reader_Pathways.md
    Audit_Checklist.md
    Cross_Reference_Map.md

  04_minified/
    Chapter_Contracts.md
    Block_Contracts.md
    PMS_EM_Minified_Canonical.md

  05_derivative_publications/
    PMS_EM_Compact_Overview.md
    PMS_EM_Technical_Whitepaper.md
```

`PMS-EMERGENCE MODEL.md` remains the master source of truth.

`PMS-EM_Split_Specification_v1.md` defines split and modularization requirements.

The seven block files are the modular full version.

The appendices are reference layers.

Appendix F is the PMS ecosystem and Meta-Developmental Legibility reference layer.

The reference files provide navigation, glossary discipline, audit discipline, and reading paths.

Contracts are audit artifacts and must be created before the minified canonical version.

## 3. Owner Block Map

| Block File                                                       |   Owner Chapters | Primary Scope                                                                                |
| ---------------------------------------------------------------- | ---------------: | -------------------------------------------------------------------------------------------- |
| `01_Theory_Scope_Claim_Discipline.md`                            |      0, 1, 2, 18 | Summary, design principles, layer separation, claim discipline, rest-like replay claim boundary, conclusion |
| `02_EM_Core_Developmental_Architecture.md`                       | 3, 4, 5, 6, 8, 9 | Environment, agent architecture, perception, prediction, genetic gates, behavior, replay, rest-like replay |
| `03_Developmental_Phases_Gate_Logic.md`                          |               11 | Developmental phases, gates, exit criteria, phase-bounded replay scope, failure modes, premature-unlock risks |
| `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` |            7, 12 | Needs, discomfort, distress, attachment-like regulation, caregiver dynamics, multigeneration |
| `05_MIP_KPIs_Dignity_Safety.md`                                  |           10, 16 | MIP, A–C–R–E, Dignity-in-Practice, KPIs, replay KPIs, evaluation, ablations, safety |
| `06_PMS_VM_Implementation_Spine.md`                              |               14 | PMS operator grammar, VM, PMS-RUST, PMS-STACK, implementation spine |
| `07_Language_Diary_Consciousness_Related_Work.md`                |       13, 15, 17 | Language, diary, rest-like replay as diary source material after thresholds, consciousness research outlook, related work |

The owner-block rule is strict:

```text
A chapter may be summarized or referenced outside its owner block.
A chapter must not be fully duplicated outside its owner block.
```

## 4. Chapter Ownership Map

| Chapter | Title / Topic                            | Owner Block                                                      | Primary Reference Appendices |
| ------: | ---------------------------------------- | ---------------------------------------------------------------- | ---------------------------- |
|       0 | Summary / Claim Discipline               | `01_Theory_Scope_Claim_Discipline.md`                            | D, E                         |
|       1 | Design Principles                        | `01_Theory_Scope_Claim_Discipline.md`                            | D, E                         |
|       2 | The Four Basic Layers                    | `01_Theory_Scope_Claim_Discipline.md`                            | D, E                         |
|       3 | Environment                              | `02_EM_Core_Developmental_Architecture.md`                       | D, E                         |
|       4 | Agent Architecture                       | `02_EM_Core_Developmental_Architecture.md`                       | D, E                         |
|       5 | Perception, World Model & Prediction     | `02_EM_Core_Developmental_Architecture.md`                       | D, E                         |
|       6 | Genetic System                           | `02_EM_Core_Developmental_Architecture.md`                       | C, D, E                      |
|       7 | Needs, Discomfort, Distress & Attachment | `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` | D, E                         |
|       8 | Behavior Layer                           | `02_EM_Core_Developmental_Architecture.md`                       | D, E                         |
|       9 | Imagination Buffer and Dreaming          | `02_EM_Core_Developmental_Architecture.md`                       | D, E                         |
|      10 | MIP Layer                                | `05_MIP_KPIs_Dignity_Safety.md`                                  | A, D, E                      |
|      11 | Developmental Phases                     | `03_Developmental_Phases_Gate_Logic.md`                          | C, D, E                      |
|      12 | Multi-Generational Caregiver Dynamics    | `04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md` | D, E                         |
|      13 | Language & Diaries                       | `07_Language_Diary_Consciousness_Related_Work.md`                | D, E                         |
|      14 | PMS-VM Implementation Spine              | `06_PMS_VM_Implementation_Spine.md`                              | B, C, D, E, F                |
|      15 | Consciousness Research Outlook           | `07_Language_Diary_Consciousness_Related_Work.md`                | D, E                         |
|      16 | Evaluation, Ablations & Safety           | `05_MIP_KPIs_Dignity_Safety.md`                                  | A, D, E                      |
|      17 | Related Work / Comparison                | `07_Language_Diary_Consciousness_Related_Work.md`                | D, E                         |
|      18 | Conclusion                               | `01_Theory_Scope_Claim_Discipline.md`                            | D, E                         |

## 5. Appendix Map

| Appendix   | File                                                    | Purpose                                                                                                      | Must Not Do                                                                                                                                               |
| ---------- | ------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Appendix A | `Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md`   | MIP reference model, axis mapping, retired notation, A–C–R–P–D to A–C–R–E–D discipline                       | Must not make MIP a controller, gate-opener, maturity proof, or consciousness module                                                                      |
| Appendix B | `Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md`   | PMS operator grammar, Δ–Ψ alphabet, monoid notes, ε identity, dependency language                            | Must not treat PMS operators as early internal faculties or PMS formalization as sentience                                                                |
| Appendix C | `Appendix_C_Implementation_Start.md`                    | Minimal implementation-start path, operator interpreter, dependency checking, diary rendering guardrails     | Must not treat prototype feasibility as EM validation or consciousness proof                                                                              |
| Appendix D | `Appendix_D_Claim_Discipline_Language_Reductions.md`    | Mandatory language reductions and blocked upgrades                                                           | Must not weaken claim boundaries                                                                                                                          |
| Appendix E | `Appendix_E_Layer_Discipline_Claim_Types.md`            | Layer discipline, claim-type ladder, transfer rules, finding/validation/proof discipline                     | Must not allow cross-layer validation by rhetorical transfer                                                                                              |
| Appendix F | `Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md` | PMS ecosystem framing, PMS domain profiles, Meta-Developmental Legibility, temporary domain-profile weighting | Must not treat domain profiles as internal agent modules, a second genetic system, gate openers, category installers, diagnosis, moral judgment, or consciousness evidence |

## 6. Block-to-Appendix Dependency Map

| Block    | Required Appendix References | Reason                                                                                                             |
| -------- | ---------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| Block 01 | D, E                         | Global claim and layer discipline, including rest-like replay claim boundaries                                     |
| Block 02 | D, E                         | Functional language and layer boundaries for core mechanisms, replay, rest bias, replay pressure, and rest-like replay |
| Block 03 | C, D, E                      | Phase/gate implementation relevance, phase-bounded replay scope, claim filtering, layer boundaries                 |
| Block 04 | D, E                         | Caregiver/attachment/multigeneration language reductions                                                           |
| Block 05 | A, D, E                      | MIP axis discipline, replay KPIs, language reductions, layer discipline                                            |
| Block 06 | B, C, D, E, F                | PMS operator grammar, implementation start, language reductions, layer discipline, PMS ecosystem / meta-legibility boundaries |
| Block 07 | D, E, F                      | Diary/consciousness/related-work claim discipline, rest-like replay source-material boundary, PMS ecosystem / meta-legibility boundary where domain-profile references occur |

Appendix A is primarily required by Block 05 and later contracts involving MIP notation.

Appendix B is primarily required by Block 06 and later contracts involving PMS operator grammar.

Appendix C is primarily required by Block 06 and implementation-facing phase/gate references.

Appendices D and E are global and apply to all blocks.

Appendix F applies where PMS ecosystem, PMS domain profiles, Meta-Developmental Legibility, temporary domain-profile weighting, domain-profile activation, or Research Ecosystem framing are referenced.

## 7. Concept Ownership Map

| Concept                                       | Primary Owner                             | Secondary / Reference Locations              | Cross-Reference Rule                                                               |
| --------------------------------------------- | ----------------------------------------- | -------------------------------------------- | ---------------------------------------------------------------------------------- |
| Global claim discipline                       | Block 01                                  | Appendices D, E                              | May be referenced by all blocks                                                    |
| Four-layer architecture                       | Block 01                                  | Appendix E                                   | Do not redefine layer rules outside Block 01 / Appendix E                          |
| EM core architecture                          | Block 02                                  | Blocks 01, 03, 05, 06, 07                    | Mechanism details remain in Block 02                                               |
| Environment                                   | Block 02, Chapter 3                       | Block 03 for phase availability              | Do not duplicate environment specification in phase or safety blocks               |
| Agent architecture                            | Block 02, Chapter 4                       | Blocks 03, 06                                | Do not treat PMS as early internal agent architecture                              |
| Perception / prediction                       | Block 02, Chapter 5                       | Blocks 03, 05, 06                            | Keep as EM mechanism, not consciousness proof                                      |
| Genetic gates                                 | Block 02, Chapter 6                       | Block 03, Appendix C                         | Gates constrain availability; they do not install finished competence              |
| Soft regimes                                  | Block 03, Chapter 11; Block 02, Chapter 6 | Appendix E                                   | Soft regimes bias available pathways; they do not open gates                       |
| External stimulation load                     | Block 02, Chapter 6                       | Blocks 03, 05; Appendix D                    | Reduced external load may bias rest; it is not introspection                       |
| Task pressure                                 | Block 02, Chapter 6                       | Blocks 03, 05                                | Task pressure is functional demand context, not felt obligation                    |
| Rest bias                                     | Block 02, Chapters 6, 8                   | Block 03, Appendix E                         | Rest bias modulates SLEEP/rest likelihood; it is not a hidden controller           |
| Replay pressure                               | Block 02, Chapters 6, 9                   | Block 05                                     | Replay pressure requires trace-backed candidates; it is not inner experience       |
| Needs                                         | Block 04, Chapter 7                       | Block 02                                     | Needs are control variables, not felt desires                                      |
| Discomfort                                    | Block 04, Chapter 7                       | Appendix D                                   | Discomfort is physical risk-damping signal, not pain                               |
| Distress                                      | Block 04, Chapter 7                       | Appendix D                                   | Distress is functional disruption / loss signal, not subjective suffering          |
| Attachment-like regulation                    | Block 04, Chapter 7                       | Appendix D                                   | Attachment is functional relation-weighting, not felt love                         |
| Toy-missing                                   | Block 04, Chapter 7                       | Blocks 03, 07                                | Missing is attachment-weighted absence response, not felt longing                  |
| Comfort-after-loss                            | Block 04, Chapters 7, 12                  | Blocks 02, 07                                | Comfort reduces functional distress; it is not felt relief                         |
| Caregiver guidance                            | Block 04, Chapter 7                       | Blocks 02, 03, 05                            | Guidance is scaffold/boundary, not punishment                                      |
| Boundary                                      | Block 04, Chapter 7                       | Appendix D                                   | Boundary is constraint/scaffold, not rejection                                     |
| Misattunement                                 | Block 04, Chapter 7                       | Appendix D                                   | Misattunement is caregiver-response mismatch, not trauma                           |
| Object damage                                 | Block 02, Chapter 8; Block 04, Chapter 7  | Block 05, Appendix D                         | Object damage is self-caused consequence trace, not guilt                          |
| Fall / near-fall                              | Block 02, Chapter 8; Block 05, Chapter 16 | Appendix D                                   | Fall / near-fall is physical-risk event, not pain or fear                          |
| Carefulness                                   | Block 02, Chapter 8; Block 04, Chapter 7  | Appendix D                                   | Carefulness is action-quality category candidate, not moral obedience              |
| Behavior layer                                | Block 02, Chapter 8                       | Blocks 04, 05                                | Behavior mechanisms remain EM core                                                 |
| Replay / imagination buffer                   | Block 02, Chapter 9                       | Blocks 05, 07                                | Replay is trace consolidation, not subjective dreaming                             |
| Rest-like replay regime                       | Block 02, Chapters 6, 8, 9                | Blocks 03, 05, 07; Appendices D, E           | Phase-bounded, trace-backed offline consolidation under low external load; not DMN |
| Phase-bounded replay scope                    | Block 03, Chapter 11                      | Blocks 02, 05, 07; Appendix E                | Replay content must not appear before source traces and phase prerequisites exist  |
| Post-replay feedback                          | Block 02, Chapter 9                       | Block 05; Appendices D, E                    | Bounded trace update, not self-reflection or insight                               |
| Anti-fixation constraints                     | Block 02, Chapter 9; Block 05, Chapter 16 | Block 03; Appendix E                         | Damping and cooldown prevent unsupported replay fixation                           |
| Rest-like replay as diary source material     | Block 07, Chapter 13                      | Block 02, Chapter 9; Appendix E              | Allowed only after diary thresholds; not autobiographical memory                   |
| MIP                                           | Block 05, Chapter 10                      | Appendix A, Appendix E                       | MIP observes; it does not control development                                      |
| A–C–R–E–D                                     | Block 05, Appendix A                      | Blocks 01, 03, 04, 06, 07                    | Active EM notation only                                                            |
| A–C–R–P–D                                     | Appendix A                                | Block 05 only as explicit MIP source/context | Source/context only; P maps to E                                                   |
| Dignity-in-Practice                           | Block 05, Chapter 10; Appendix A          | Appendices D, E                              | D is guardrail, not performance score or intrinsic-worth ranking                   |
| IA markers                                    | Block 05, Chapter 10                      | Appendix A, Appendix E                       | Functional guardrail markers, not diagnosis                                        |
| RVR(t)                                        | Appendix A / Block 05 context             | Appendix E                                   | Viability/context note, not blame or moral score                                   |
| Developmental phases                          | Block 03, Chapter 11                      | Appendix E                                   | Phases open possibility spaces; they do not prove maturity                         |
| Gate logic                                    | Block 03, Chapter 11                      | Block 02, Appendix C                         | Gates constrain capability availability; they do not install competence            |
| Multi-generational caregiver transition       | Block 04, Chapter 12                      | Blocks 03, 06, 07                            | Role transition is functional transformation, not proof of inner life              |
| Functional love dynamics                      | Block 04, Chapter 12                      | Appendix D                                   | Functional love dynamics are not felt love                                         |
| Language                                      | Block 07, Chapter 13                      | Blocks 03, 06                                | Language is late reflection channel, not source of architecture                    |
| Diary                                         | Block 07, Chapter 13                      | Blocks 05, 06; Appendix D                    | Diary is controlled trace rendering, not phenomenal selfhood                       |
| Trace provenance                              | Block 07, Chapter 13                      | Appendices C, D                              | Required for valid EM diary                                                        |
| Controlled rendering                          | Block 07, Chapter 13                      | Appendices C, D                              | Required for safe diary output                                                     |
| Consciousness research outlook                | Block 07, Chapter 15                      | Appendix E                                   | Research candidate layer only                                                      |
| Functional proto-consciousness                | Block 07, Chapter 15                      | Appendix D                                   | Bounded research label, not weak consciousness                                     |
| PMS operator grammar                          | Block 06, Chapter 14                      | Appendix B                                   | External projection/audit/VM layer                                                 |
| Δ–Ψ operators                                 | Block 06, Chapter 14                      | Appendix B                                   | Projection vocabulary, not early internal faculties                                |
| Operator-compatible regularity                | Block 06, Chapter 14                      | Appendices B, D, E                           | Preferred over internalized PMS operators                                          |
| PMS-RUST                                      | Block 06, Chapter 14                      | Appendix C, Appendix E                       | Bounded trace/audit feasibility, not EM proof                                      |
| PMS-STACK                                     | Block 06, Chapter 14                      | Appendix C, Appendix E                       | Architecture pressure point, not validation horizon                                |
| PMS ecosystem                                 | Appendix F                                | Block 06, Block 07                           | External ecosystem framing, not EM core architecture                               |
| PMS domain profile                            | Appendix F                                | Block 06, Block 07                           | External operator-strict overlay, not internal agent module                        |
| Meta-Developmental Legibility Strand          | Appendix F                                | Blocks 05, 06, 07                            | Temporary trace-weighting / legibility overlay, not second genetic system          |
| Temporary domain-profile weighting            | Appendix F                                | Blocks 05, 06, 07                            | Reversible weighting of selected trace dimensions, not gate opening                |
| Domain-profile activation                     | Appendix F                                | Blocks 05, 06, 07                            | T–J–TB–R-governed activation, not diagnosis or moral judgment                      |
| High-Ω Intimacy / Boundary / Exposure Profile | Appendix F                                | Blocks 05, 06, 07                            | External safety-facing high-asymmetry profile, not sexualization of EM agent       |
| Evaluation / ablation                         | Block 05, Chapter 16                      | Appendix E                                   | Functional, phase-bounded, trace-backed, claim-filtered                            |
| Replay KPIs / replay ablations                | Block 05, Chapter 16                      | Blocks 02, 03; Appendix E                    | Test replay trigger validity, anti-fixation, phase leakage, and bounded effects    |
| Safety                                        | Block 05, Chapter 16                      | Appendix E                                   | Constrains architecture and interpretation; does not prove inner life              |
| Related work                                  | Block 07, Chapter 17                      | Appendix E, Appendix F                       | Comparison without proof by similarity or profile internalization                  |
| Conclusion / synthesis                        | Block 01, Chapter 18                      | Appendix E                                   | Synthesizes; does not expand owner-block claims                                    |

## 8. Chapter-to-Concept Map

### Chapter 0 — Summary / Claim Discipline

Owner:

```text
01_Theory_Scope_Claim_Discipline.md
```

Owns:

```text
global summary
experimental architecture framing
central claim boundary
testbed status
functional trace-backed discipline
```

References:

```text
all blocks
Appendix D
Appendix E
```

Must not claim:

```text
consciousness
sentience
personhood
moral status
rights status
subjective experience
```

### Chapter 1 — Design Principles

Owner:

```text
01_Theory_Scope_Claim_Discipline.md
```

Owns:

```text
minimalism
embodiment
phased development
genetic safeguards
MIP from day one
multi-generational outlook
measurability and reproducibility
consciousness as unknown but researchable
implementation-status discipline
```

References:

```text
Appendix E for layer discipline
Appendix D for language reductions
```

Must not claim:

```text
full EM already implemented
PMS-RUST proves EM
PMS-STACK validates EM
MIP proves maturity
PMS formalization proves consciousness
```

### Chapter 2 — The Four Basic Layers

Owner:

```text
01_Theory_Scope_Claim_Discipline.md
```

Owns:

```text
EM layer
MIP layer
PMS layer
consciousness research layer
layer separation
no cross-layer validation
```

References:

```text
Appendix E
```

Must not claim:

```text
one layer validates another by rhetorical transfer
```

### Chapters 3–6, 8–9 — EM Core Developmental Architecture

Owner:

```text
02_EM_Core_Developmental_Architecture.md
```

Owns:

```text
environment
agent architecture
perception
world model
prediction
genetic gates
soft regimes where specified
external stimulation load
task pressure
rest bias
replay pressure
behavior layer
SLEEP / rest-biased transition conditions
object interaction
fall / near-fall events
object damage
caregiver signals as behavior modulation
replay / imagination buffer
rest-like replay regime
post-replay feedback
anti-fixation constraints
```

References:

```text
03_Developmental_Phases_Gate_Logic.md
04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
05_MIP_KPIs_Dignity_Safety.md
07_Language_Diary_Consciousness_Related_Work.md
Appendix D
Appendix E
```

Must not claim:

```text
replay = subjective dreaming
rest-like replay = Default Mode Network activity
low external stimulation = introspection
replay feedback = self-reflection
post-replay improvement = insight
offline consolidation = inner experience
rest-like replay cluster = autobiographical memory
rest-like replay opens gates
rest-like replay installs categories without recurrence
object damage = guilt
fall / near-fall = pain or fear
caregiver guidance = punishment
category replay = concept insertion
diary preparation = phenomenal selfhood
```

### Chapter 7 — Needs, Discomfort, Distress & Attachment

Owner:

```text
04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
```

Owns:

```text
needs
discomfort
distress
attachment-like regulation
toy-missing
comfort-after-loss
caregiver guidance
boundary
misattunement
interaction quality
carefulness
functional familiarity
claim boundaries for attachment-related terms
```

References:

```text
02_EM_Core_Developmental_Architecture.md
03_Developmental_Phases_Gate_Logic.md
05_MIP_KPIs_Dignity_Safety.md
07_Language_Diary_Consciousness_Related_Work.md
Appendix D
Appendix E
```

Must not claim:

```text
discomfort = pain
distress = subjective suffering
missing = felt longing
attachment = felt love
caregiver guidance = punishment
boundary = rejection
misattunement = trauma
object damage = guilt
fall / near-fall = pain or fear
carefulness = moral obedience
```

### Chapter 10 — MIP Layer

Owner:

```text
05_MIP_KPIs_Dignity_Safety.md
```

Owns:

```text
MIP
A–C–R–E measurement
Dignity-in-Practice
trajectory marking
IA patterns
D guardrail warnings
optional bounded support
MIP status boundaries
```

References:

```text
Appendix A
Appendix D
Appendix E
```

Must not claim:

```text
MIP controls development
MIP opens gates
MIP installs categories
MIP proves maturity
MIP proves consciousness
MIP diagnoses agents
MIP moralizes traces
D ranks intrinsic worth
```

### Chapter 11 — Developmental Phases

Owner:

```text
03_Developmental_Phases_Gate_Logic.md
```

Owns:

```text
P0-mini
P0
P1
P2
P3+
P4+
P5
phase conditions
gate logic
soft-regime class
phase-bounded replay scope
exit criteria
failure modes
premature-unlock risks
```

References:

```text
02_EM_Core_Developmental_Architecture.md
04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
05_MIP_KPIs_Dignity_Safety.md
07_Language_Diary_Consciousness_Related_Work.md
Appendix C
Appendix D
Appendix E
```

Must not claim:

```text
phase = maturity proof
gate = finished competence
phase transition = consciousness progress
rest-like replay opens gates
rest-like replay installs categories
rest-like replay bypasses phase-specific replay scope
replay content appears before source traces and phase prerequisites exist
low external stimulation = introspection
replay feedback = self-reflection
post-replay improvement = insight
P5 caregiver transition = proof of inner life
```

### Chapter 12 — Multi-Generational Caregiver Dynamics

Owner:

```text
04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
```

Owns:

```text
caregiver transition
caregiver loss
role transition
overshooting
core norm transfer
functional love dynamics
received guidance
comfort-after-loss
boundary transmission
category transfer
```

References:

```text
03_Developmental_Phases_Gate_Logic.md
05_MIP_KPIs_Dignity_Safety.md
06_PMS_VM_Implementation_Spine.md
07_Language_Diary_Consciousness_Related_Work.md
Appendix D
Appendix E
```

Must not claim:

```text
human culture
moral lineage
felt parental love
human adulthood
legal responsibility
rights status
consciousness
personhood
```

### Chapter 13 — Language & Diaries

Owner:

```text
07_Language_Diary_Consciousness_Related_Work.md
```

Owns:

```text
language as late reflection channel
minimal sentence threshold
trace provenance
controlled rendering
diary candidate status
rest-like replay source-material boundary
diary claim boundaries
```

References:

```text
02_EM_Core_Developmental_Architecture.md
03_Developmental_Phases_Gate_Logic.md
05_MIP_KPIs_Dignity_Safety.md
06_PMS_VM_Implementation_Spine.md
Appendix D
Appendix E
```

Must not claim:

```text
language output = inner speech
diary = subjective memory
diary = phenomenal autobiography
diary = phenomenal selfhood
rest-like replay trace = diary text
rest-like replay cluster = autobiographical memory
low external stimulation = introspection
replay feedback = self-reflection
post-replay improvement = insight
offline consolidation = inner experience
rest-like replay = Default Mode Network equivalence
self-description = consciousness
```

### Chapter 14 — PMS-VM Implementation Spine

Owner:

```text
06_PMS_VM_Implementation_Spine.md
```

Owns:

```text
PMS operator layer
operator alphabet
episode sequences
monoid notes
Success Log trace layer
MIP-to-PMS projection
IA pattern matching
diary reduction
language rendering
norm transfer
PMS as DSL / VM
PMS-RUST
PMS-STACK
operator-compatible regularities
external domain-profile mapping boundaries
Meta-Developmental Legibility reference boundary
```

References:

```text
Appendix B
Appendix C
Appendix D
Appendix E
Appendix F
```

Must not claim:

```text
PMS is early internal agent structure
agent has Δ
agent uses Φ
agent thinks in Ψ
PMS formalization proves sentience
PMS-RUST proves EM
PMS-STACK validates EM
PMS projection proves consciousness
PMS domain profiles become internal agent modules
temporary domain-profile weighting opens gates
temporary domain-profile weighting installs categories
Meta-Developmental Legibility Strand controls development
```

### Chapter 15 — Consciousness Research Outlook

Owner:

```text
07_Language_Diary_Consciousness_Related_Work.md
```

Owns:

```text
bounded consciousness research outlook
functional candidates
bounded replay findings as research-relevant but non-proving structures
non-claim discipline
functional proto-consciousness boundary
```

References:

```text
01_Theory_Scope_Claim_Discipline.md
02_EM_Core_Developmental_Architecture.md
05_MIP_KPIs_Dignity_Safety.md
06_PMS_VM_Implementation_Spine.md
Appendix D
Appendix E
```

Must not claim:

```text
phenomenal consciousness
sentience
subjective experience
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
Default Mode Network equivalence
moral status
personhood
rights status
partial inner experience
```

### Chapter 16 — Evaluation, Ablations & Safety

Owner:

```text
05_MIP_KPIs_Dignity_Safety.md
```

Owns:

```text
KPIs
replay KPIs
rest-like replay trigger validity
offline consolidation safety
replay fixation prevention
phase leakage prevention
evaluation
ablation design
rest-like replay ablations
reproducibility
safety
D guardrails
finding / validation / proof distinctions
interaction-quality evaluation
caregiver-response evaluation
diary-related evaluation
PMS-related implementation feasibility boundaries
```

References:

```text
02_EM_Core_Developmental_Architecture.md
03_Developmental_Phases_Gate_Logic.md
Appendix A
Appendix D
Appendix E
```

Must not claim:

```text
KPI = consciousness proof
replay KPI = inner life proof
rest-like replay trigger validity = introspection proof
post-replay update = insight
ablation = personhood proof
replay ablation = inner life proof
safety result = moral status proof
diary KPI = phenomenal selfhood proof
PMS feasibility = EM proof
```

### Chapter 17 — Related Work / Comparison

Owner:

```text
07_Language_Diary_Consciousness_Related_Work.md
```

Owns:

```text
related work comparison
developmental robotics comparison
active inference comparison
world model comparison
attachment AI comparison
consciousness theory comparison
PMS comparison
bounded uniqueness claim
comparison table as claim-discipline tool
Core / Extended / Research Ecosystem framing where relevant
PMS ecosystem comparison without profile internalization
```

References:

```text
all owner blocks
Appendix D
Appendix E
Appendix F
```

Must not claim:

```text
absolute novelty
proof by similarity
consciousness proof by comparison
personhood proof by comparison
moral-status proof by comparison
sentience proof by comparison
PMS domain profiles become EM core modules by comparison
research ecosystem framing becomes claim expansion
```

### Chapter 18 — Conclusion

Owner:

```text
01_Theory_Scope_Claim_Discipline.md
```

Owns:

```text
global synthesis
safe final claims
implementation-status discipline
final claim boundary
```

References:

```text
all owner blocks
Appendix D
Appendix E
```

Must not claim:

```text
any owner-block claim expansion
full EM implementation
PMS-RUST proof of EM
PMS-STACK validation of EM
consciousness proof
personhood proof
sentience proof
```

## 9. Allowed Cross-Reference Patterns

Allowed pattern:

```markdown
> Cross-reference:
> For the full treatment of <topic>, see `<owner-file>`, especially Chapter <x>.
> This block uses the concept only as <dependency / orientation / claim-boundary context / implementation boundary>.
```

Allowed uses:

```text
orientation
dependency marking
claim-boundary clarification
appendix routing
owner-block routing
contract preparation
```

Blocked uses:

```text
full foreign-chapter duplication
silent rewrite of owner claims
claim expansion
claim weakening
foreign concepts treated as owner concepts
layer collapse
```

## 10. Do-Not-Duplicate Zones

The following material must not be duplicated outside its owner location.

| Material                              | Owner                              | May Be Referenced By      | Must Not Be Duplicated In                                    |
| ------------------------------------- | ---------------------------------- | ------------------------- | ------------------------------------------------------------ |
| Global claim discipline               | Block 01 / Appendix D / Appendix E | all blocks                | full restatement in every chapter except concise orientation |
| EM core mechanisms                    | Block 02                           | Blocks 03–07              | Appendix or contracts as full chapter content                |
| Phase/gate logic                      | Block 03                           | Blocks 02, 04, 05, 07     | Core, caregiver, MIP, diary chapters                         |
| Caregiver / attachment full treatment | Block 04                           | Blocks 02, 03, 05, 06, 07 | Core, MIP, PMS, diary chapters                               |
| MIP / KPI / D full treatment          | Block 05 / Appendix A              | all blocks                | Core, caregiver, PMS, diary chapters                         |
| PMS / VM full treatment               | Block 06 / Appendix B / Appendix C | Blocks 01, 05, 07         | Core, MIP, diary chapters                                    |
| Language / diary full treatment       | Block 07                           | Blocks 03, 05, 06         | Core, caregiver, PMS chapters                                |
| Consciousness outlook                 | Block 07 / Appendix E              | all blocks                | MIP, PMS, implementation, core chapters                      |
| Related work                          | Block 07                           | Block 01                  | other blocks                                                 |
| Claim reductions                      | Appendix D                         | all files                 | should be referenced, not rewritten as new theory            |
| Layer discipline                      | Appendix E                         | all files                 | should be referenced, not contradicted                       |
| PMS ecosystem / meta-legibility       | Appendix F                         | Blocks 05, 06, 07         | should be referenced as external profile / weighting boundary, not imported as EM core module |

## 11. Concept-to-Appendix Routing

| If the issue concerns...                                                                                         | Use Appendix |
| ---------------------------------------------------------------------------------------------------------------- | ------------ |
| MIP source/context notation, A–C–R–P–D, retired notation, P → E mapping                                          | Appendix A   |
| PMS operators, Δ–Ψ, monoid, ε, dependency language                                                               | Appendix B   |
| Minimal implementation path, PMS interpreter, dependency checker, controlled rendering prototype                 | Appendix C   |
| Blocked language, safe reductions, no phenomenal/moral/clinical upgrade                                          | Appendix D   |
| Layer separation, claim types, finding/validation/proof, transfer rules                                          | Appendix E   |
| PMS ecosystem, PMS domain profiles, Meta-Developmental Legibility, temporary domain-profile weighting, activation | Appendix F   |

## 12. Claim-Boundary Routing

| Boundary                                                                       | Owner / Reference                               |
| ------------------------------------------------------------------------------ | ----------------------------------------------- |
| discomfort ≠ pain                                                              | Block 04, Appendix D                            |
| distress ≠ subjective suffering                                                | Block 04, Appendix D                            |
| missing ≠ felt longing                                                         | Block 04, Appendix D                            |
| attachment ≠ felt love                                                         | Block 04, Appendix D                            |
| love dynamics ≠ felt love                                                      | Block 04, Appendix D                            |
| comfort ≠ felt relief                                                          | Block 04, Appendix D                            |
| object damage ≠ guilt                                                          | Block 02 / Block 04 / Appendix D                |
| self-caused consequence ≠ blame / remorse / punishment                         | Block 02 / Block 05 / Appendix D                |
| fall / near-fall ≠ pain or fear                                                | Block 02 / Block 05 / Appendix D                |
| caregiver guidance ≠ punishment                                                | Block 04 / Appendix D                           |
| boundary ≠ rejection                                                           | Block 04 / Appendix D                           |
| misattunement ≠ trauma                                                         | Block 04 / Appendix D                           |
| adverse caregiver response ≠ abuse claim                                       | Block 04 / Appendix D                           |
03_reference/Reader_Pathways.md
| MIP ≠ consciousness module                                                     | Block 05 / Appendix E                           |
| MIP ≠ maturity proof                                                           | Block 05 / Appendix E                           |
| PMS formalization ≠ sentience                                                  | Block 06 / Appendix E                           |
| operator-compatible regularity ≠ internal PMS operator                         | Block 06 / Appendix B / Appendix E              |
| Dignity-in-Practice ≠ intrinsic-worth ranking                                  | Block 05 / Appendix A / Appendix D / Appendix E |
| functional proto-consciousness ≠ phenomenal consciousness                      | Block 07 / Appendix D                           |
| implementation ≠ theory proof                                                  | Block 01 / Appendix E                           |
| PMS-RUST ≠ EM proof                                                            | Block 06 / Appendix E                           |
| PMS-STACK ≠ EM validation                                                      | Block 06 / Appendix E                           |
| Meta-Developmental Legibility Strand ≠ second genetic system                   | Appendix F                                      |
| Meta-Developmental Legibility Strand ≠ controller / gate opener / category installer | Appendix F                               |
| PMS domain profile ≠ internal agent module                                     | Appendix F                                      |
| Temporary domain-profile weighting ≠ phase availability / gate opening / capability installation | Appendix F                       |
| Domain-profile activation ≠ diagnosis / moral judgment / consciousness evidence | Appendix F                                     |
| High-Ω Intimacy / Boundary / Exposure Profile ≠ sexualization of EM agent      | Appendix F                                      |

## 13. Layer-Transfer Map

Allowed transfers:

```text
EM trace → MIP observation
EM trace → PMS projection
EM trace → diary candidate, if diary requirements are met
MIP summary → PMS-readable structure
MIP context → diary support
PMS projection → audit record
PMS reduction → controlled rendering input
Evaluation finding → mechanism revision
Consciousness outlook → research question
Related-work comparison → bounded similarity / difference / gap / pressure
Learning-problem trace → temporary domain-profile weighting, if T–J–TB–R conditions are met
Domain-profile weighting → MIP / IA review focus
Domain-profile weighting → PMS projection focus
Domain-profile weighting → diary-safety review
Domain-profile weighting → safety audit attention
```

Blocked transfers:

```text
EM trace → consciousness proof
MIP score → maturity proof
MIP measurement → personhood claim
MIP warning → gate control
PMS projection → internal operator claim
PMS formalization → sentience
PMS-RUST feasibility → EM proof
PMS-STACK architecture path → EM validation
Diary rendering → phenomenal selfhood
Language output → inner speech
Phase transition → maturity proof
Gate opening → finished competence
Related-work similarity → proof
D guardrail → intrinsic-worth ranking
Domain-profile activation → internal PMS module
Domain-profile activation → gate opening
Domain-profile activation → category installation
Domain-profile activation → consciousness evidence
Domain-profile activation → diagnosis
Domain-profile activation → moral judgment
High-Ω profile activation → sexualization of EM agent
```

Global rule:

```text
No cross-layer validation by rhetorical accumulation.
```

## 14. Contract Preparation Map

Pass 8 will create:

```text
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
```

This cross-reference map prepares those contracts as follows.

### Chapter Contracts Must Use

```text
chapter number
chapter title
owner block
may claim
may not claim
requires
depends on
owner concepts
blocked language
related appendices
```

### Block Contracts Must Use

```text
block file
owner chapters
scope
may claim
may not claim
requires
depends on
owner concepts
foreign concepts
cross-reference obligations
appendix obligations
blocked language
```

### Contract Dependency Sources

| Contract Need                              | Source File              |
| ------------------------------------------ | ------------------------ |
| Owner chapter mapping                      | `Cross_Reference_Map.md` |
| Controlled definitions                     | `Glossary.md`            |
| Mandatory audit gates                      | `Audit_Checklist.md`     |
| Reading order / audience pathways          | `Reader_Pathways.md`     |
| Claim reductions                           | Appendix D               |
| Layer discipline                           | Appendix E               |
| MIP notation discipline                    | Appendix A               |
| PMS formal discipline                      | Appendix B               |
| Implementation-start discipline            | Appendix C               |
| PMS ecosystem / meta-legibility discipline | Appendix F               |

## 15. Maintenance Rules

When a block changes:

```text
1. Check whether owner chapters changed.
2. Check whether cross-links still point to correct owner files.
3. Check whether appendix references remain correct.
4. Check whether no full foreign chapter was imported.
5. Check whether claim boundaries remain intact.
6. Update this map only if ownership, routing, or dependency changed.
```

When an appendix changes:

```text
1. Check whether its purpose remains reference-layer only.
2. Check whether it duplicates block content.
3. Check whether it changes claim boundaries.
4. Check whether affected blocks or contracts need reference updates.
5. If Appendix F changes, check that PMS domain profiles remain external overlays and do not become internal EM modules.
6. If Appendix F changes, check that temporary domain-profile weighting remains non-gating, non-controlling, time-bounded, and reversible.
```

When contracts are created:

```text
1. Use this map for owner and dependency references.
2. Use Appendix D for blocked language.
3. Use Appendix E for layer and claim type.
4. Use Appendix A for MIP notation.
5. Use Appendix B for PMS operator grammar.
6. Use Appendix C for implementation-start status.
7. Use Appendix F for PMS ecosystem, PMS domain-profile, Meta-Developmental Legibility, and temporary domain-profile weighting boundaries.
```

## 16. Final Cross-Reference Rule

The modular PMS–EM structure is valid only if:

```text
Monolith remains source of truth.
Seven block files preserve owner chapters.
Appendices remain reference layers.
Reference files remain navigation and audit layers.
Contracts constrain future reductions.
Minified and derivative publications do not weaken claim boundaries.
Appendix F remains an external PMS ecosystem / Meta-Developmental Legibility reference layer.
PMS domain profiles do not become internal EM modules.
```

The final rule is:

```text
Reference, do not duplicate.
Orient, do not rewrite.
Map, do not expand.
Connect, do not validate by transfer.
```