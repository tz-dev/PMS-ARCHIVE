---
document_id: PMS-EM-REF-READER-PATHWAYS
title: "Reader Pathways"
source: "PMS-EMERGENCE MODEL.md"
source_role: "reference navigation and reader-orientation file"
status: "split-reference-layer"
version: "v1"
related_blocks:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "06_PMS_VM_Implementation_Spine.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
related_reference_files:
  - "Cross_Reference_Map.md"
  - "Glossary.md"
  - "Audit_Checklist.md"
claim_mode: "navigation-only, owner-preserving, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
mip_source_context_notation: "A–C–R–P–D only in explicit MIP source/context"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
meta_legibility_status: "Appendix F reference layer; temporary, reversible, time-bounded trace-weighting; not controller; not gate opener; not internal PMS module"
---

# Reader Pathways

## 1. Purpose

This file provides recommended reading paths through the modular PMS–EM artifact set.

It is a navigation file, not a theory chapter.

It does not replace:

```text
the seven owner block files
the six appendices
the glossary
the audit checklist
the cross-reference map
contracts
the minified canonical version
```

The governing rule is:

```text
Use pathways to enter the artifact set.
Use owner blocks for full chapter content.
Use appendices for reference discipline.
Use glossary and audit files for terminology and claim checks.
Use Appendix F for PMS ecosystem and Meta-Developmental Legibility boundaries.
```

No pathway may weaken claim boundaries.

No pathway may convert a summary route into proof of consciousness, personhood, sentience, subjective experience, moral status, rights status, felt pain, felt suffering, felt love, guilt, trauma, or phenomenal selfhood.

No pathway may convert PMS domain profiles into internal EM modules.

No pathway may treat temporary domain-profile weighting as gate opening, category installation, capability installation, diagnosis, moral judgment, or consciousness evidence.

## 2. Global Reading Rules

Before using any pathway, keep these rules active:

```text
A–C–R–E–D is the active EM-facing notation.
A–C–R–P–D is allowed only in explicit MIP source/context.
B–K–V–H is retired historical/source-internal notation only.
Dignity-in-Practice is a guardrail, not a performance score.
MIP observes, summarizes, marks, warns, and may support; it does not control development.
PMS is external operator / projection / audit / VM layer; it is not early internal agent structure.
PMS domain profiles are external operator-strict overlays; they are not internal EM modules.
Meta-Developmental Legibility is temporary trace-weighting / legibility support; it is not a second genetic system.
Temporary domain-profile weighting is transparent, justified, time-bounded, reversible, non-gating, and claim-filtered.
Rest-like replay is phase-bounded, trace-backed offline consolidation under low external load, not Default Mode Network activity.
Low external stimulation is not introspection.
Replay feedback is not self-reflection.
Post-replay improvement is not insight.
Offline consolidation is not inner experience.
Rest-like replay clusters are not autobiographical memory.
Diary rendering is trace-backed controlled rendering, not phenomenal selfhood.
Rest-like replay consolidation traces may become diary source material only when diary thresholds and phase constraints are met.
Consciousness remains an open research question.
Implementation feasibility is not theory proof.
```

Use these global reference files while reading:

```text
Cross_Reference_Map.md
Glossary.md
Audit_Checklist.md
```

Use these appendices for discipline:

```text
Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
Appendix_C_Implementation_Start.md
Appendix_D_Claim_Discipline_Language_Reductions.md
Appendix_E_Layer_Discipline_Claim_Types.md
Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

## 3. Pathway Index

Recommended pathways:

```text
1. First-Contact Reader
2. Full Architecture Reader
3. Technical EM Architecture Reader
4. Developmental Phases and Gate Logic Reader
5. Caregiver / Attachment / Multigeneration Reader
6. MIP / KPI / Dignity / Safety Reader
7. PMS / VM / Implementation Reader
8. PMS Ecosystem / Meta-Legibility Reader
9. Diary / Language / Consciousness-Outlook Reader
10. Claim-Discipline / Audit Reader
11. Implementation Starter Reader
12. Contract Preparation Reader
13. Minified Canonical Preparation Reader
14. Derivative-Publication Preparation Reader
15. Related-Work / Comparison Reader
16. Reviewer / Skeptic Reader
17. Rest-Like Replay / Offline Consolidation Reader
```

Each pathway lists:

```text
Read first
Then read
Use as reference
Skip initially
Claim warnings
Output readiness
```

## 4. Pathway 1 — First-Contact Reader

### Goal

Understand what PMS–EM is without getting lost in implementation, PMS formalization, MIP details, diary/consciousness debates, or PMS ecosystem extension points.

### Read first

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
  Chapter 0 — Summary / Claim Discipline
  Chapter 1 — Design Principles
  Chapter 2 — The Four Basic Layers
  Chapter 18 — Conclusion
```

### Then read

```text
03_reference/Glossary.md
  Sections 1–3
  Mandatory Reduction Table
  Blocked Upgrade Shortlist

02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
  D.1 Functional Description Only
  D.2 No Phenomenal Consciousness Claim
  Global Blocked Language Table

02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
  E.1 Purpose
  Four-Layer Architecture
  Final Claim Boundary
```

### Use as reference

```text
03_reference/Cross_Reference_Map.md
03_reference/Audit_Checklist.md
```

### Skip initially

```text
Full Chapter 14 PMS-VM details
Full Appendix F PMS ecosystem / meta-legibility details
Full Chapter 16 ablation details
Full operator monoid notes
Full related-work comparison
```

### Claim warnings

```text
Do not read EM as consciousness proof.
Do not read MIP as maturity proof.
Do not read PMS as sentience proof.
Do not read diary as phenomenal selfhood.
Do not read Dignity-in-Practice as intrinsic-worth ranking.
Do not read PMS domain profiles as internal EM modules.
Do not read temporary domain-profile weighting as gate opening or category installation.
```

### Output readiness

After this pathway, the reader should be able to explain:

```text
PMS–EM is a staged developmental architecture.
MIP is an observation/measurement/guardrail layer.
PMS is an external projection/audit/VM-facing layer.
Diary is controlled trace rendering.
Consciousness remains an open research question.
PMS ecosystem resources remain external reference/profile layers.
```

## 5. Pathway 2 — Full Architecture Reader

### Goal

Read the modular full version in a stable order.

### Read first

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
```

### Then read the owner blocks

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/03_Developmental_Phases_Gate_Logic.md
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

### Then read appendices

```text
02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read reference files

```text
03_reference/Cross_Reference_Map.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
03_reference/Reader_Pathways.md
```

### Claim warnings

```text
Do not treat later blocks as validating earlier blocks.
Do not treat implementation as proof.
Do not treat evaluation as metaphysical proof.
Do not treat related-work similarity as proof.
Do not treat Appendix F as a new EM core layer.
Do not treat PMS domain profiles as internal developmental faculties.
```

### Output readiness

After this pathway, the reader should be prepared to:

```text
review contracts
audit owner mappings
review Appendix F boundaries
create or audit minified canonical version
create derivative publications
```

## 6. Pathway 3 — Technical EM Architecture Reader

### Goal

Understand the developmental machinery before MIP, PMS, diary, consciousness outlook, and PMS ecosystem extensions.

### Read first

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
  Chapter 0
  Chapter 1
  Chapter 2

01_blocks/02_EM_Core_Developmental_Architecture.md
  Chapter 3 — Environment
  Chapter 4 — Agent Architecture
  Chapter 5 — Perception, World Model & Prediction
  Chapter 6 — Genetic System
  Chapter 8 — Behavior Layer
  Chapter 9 — Imagination Buffer and Dreaming
```

### Then read

```text
01_blocks/03_Developmental_Phases_Gate_Logic.md
  Chapter 11 — Developmental Phases

01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
  Chapter 7 — Needs, Discomfort, Distress & Attachment

01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 16 — Evaluation, Ablations & Safety
```

### Use as reference

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
03_reference/Glossary.md
```

### Skip initially

```text
Appendix B monoid details
Appendix F PMS ecosystem / meta-legibility details
PMS-RUST / PMS-STACK details
Related work
Consciousness outlook
```

### Claim warnings

```text
Perception is not phenomenal perception.
Prediction error is not felt surprise.
Replay is not subjective dreaming.
Rest-like replay is not Default Mode Network activity.
Low external stimulation is not introspection.
Replay feedback is not self-reflection.
Post-replay improvement is not insight.
Offline consolidation is not inner experience.
Rest-like replay cluster is not autobiographical memory.
Rest-like replay does not open gates or install categories.
Object damage is not guilt.
Fall / near-fall is not pain or fear.
Behavioral adjustment is not moral obedience.
Temporary domain-profile weighting does not change phase availability.
```

### Output readiness

After this pathway, the reader should be able to describe:

```text
the EM environment
agent architecture
world model / prediction loop
genetic gates
soft regimes
rest bias and replay pressure
behavior layer
SLEEP / rest-biased transition conditions
replay
rest-like replay as bounded offline consolidation where specified
anti-fixation constraints
trace requirements
phase dependence
```

without importing consciousness, personhood, subjective-experience, introspection, self-reflection, insight, Default-Mode-Network, or PMS-domain internalization claims.

## 7. Pathway 4 — Developmental Phases and Gate Logic Reader

### Goal

Understand how phases constrain capability availability and claim scope.

### Read first

```text
01_blocks/03_Developmental_Phases_Gate_Logic.md
  Chapter 11 — Developmental Phases
```

### Then read

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
  Chapters 3, 4, 5, 6, 8, 9

01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
  Chapters 7, 12

01_blocks/07_Language_Diary_Consciousness_Related_Work.md
  Chapter 13 — Language & Diaries
```

### Use as reference

```text
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
03_reference/Audit_Checklist.md
```

### Skip initially

```text
Full PMS monoid details
Full Appendix F domain-profile activation details
Full related-work comparison
Full MIP source-notation appendix unless axis mapping is at issue
```

### Claim warnings

```text
Phase transition is not maturity proof.
Gate opening is not finished competence.
Soft regimes are not gate openings.
Rest-like replay does not open gates.
Rest-like replay does not install categories without recurrence.
Replay content must not appear before source traces and phase prerequisites exist.
P5 caregiver transition is not proof of inner life.
Phase progression is not progress toward proven consciousness.
Low external stimulation is not introspection.
Replay feedback is not self-reflection.
Post-replay improvement is not insight.
Temporary domain-profile weighting does not open gates.
Meta-Developmental Legibility does not override the Genetic Strand.
```

### Output readiness

After this pathway, the reader should be able to identify:

```text
which structures are available in each phase
which structures are withheld
which replay scopes are phase-allowed
which replay scopes remain blocked
which premature-unlock risks matter
which claims remain blocked at each phase
why rest-like replay cannot replace gate discipline
why profile weighting cannot replace gate discipline
```

## 8. Pathway 5 — Caregiver / Attachment / Multigeneration Reader

### Goal

Understand caregiver dynamics, attachment-like regulation, discomfort, distress, interaction quality, and multi-generational transition.

### Read first

```text
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
  Chapter 7 — Needs, Discomfort, Distress & Attachment
  Chapter 12 — Multi-Generational Caregiver Dynamics
```

### Then read

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
  Chapter 8 — Behavior Layer
  Chapter 9 — Imagination Buffer and Dreaming

01_blocks/03_Developmental_Phases_Gate_Logic.md
  Chapter 11 — Developmental Phases

01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 10 — MIP Layer
  Chapter 16 — Evaluation, Ablations & Safety
```

### Use as reference

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
```

### Skip initially

```text
Full PMS operator grammar
Full implementation start
Full Appendix F domain-profile ecosystem
Full related work
```

### Claim warnings

```text
Discomfort is not pain.
Distress is not subjective suffering.
Missing is not felt longing.
Attachment is not felt love.
Functional love dynamics are not felt love.
Caregiver guidance is not punishment.
Boundary is not rejection.
Misattunement is not trauma.
Object damage is not guilt.
Fall / near-fall is not pain or fear.
Carefulness is not moral obedience.
Role / caregiver transition is not proof of inner life.
Norm transfer is not moral essence transfer.
High-Ω profile language must never sexualize the EM agent.
```

### Output readiness

After this pathway, the reader should be able to explain:

```text
caregiver as functional scaffold
attachment-like regulation
comfort-after-loss
interaction quality
overprotection
multi-generational transition
functional love dynamics
norm transfer
```

without using felt-love, trauma, guilt, punishment, sexuality, or personhood language.

## 9. Pathway 6 — MIP / KPI / Dignity / Safety Reader

### Goal

Understand MIP, A–C–R–E–D, Dignity-in-Practice, KPIs, ablations, safety, and meta-legibility review boundaries.

### Read first

```text
01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 10 — MIP Layer
  Chapter 16 — Evaluation, Ablations & Safety
```

### Then read

```text
02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

### Then read where profile activation or ecosystem routing is at issue

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read

```text
01_blocks/03_Developmental_Phases_Gate_Logic.md
  Chapter 11 — Developmental Phases

01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
  Chapter 7
  Chapter 12
```

### Use as reference

```text
03_reference/Glossary.md
03_reference/Audit_Checklist.md
03_reference/Cross_Reference_Map.md
```

### Skip initially

```text
Full PMS-RUST / PMS-STACK details unless implementation feasibility is the focus
Full related-work comparison
```

### Claim warnings

```text
MIP observes; it does not control.
MIP does not open gates.
MIP does not install categories.
MIP does not prove maturity.
MIP does not prove consciousness.
MIP does not diagnose agents.
D is guardrail, not score.
D is not intrinsic-worth ranking.
KPIs do not prove consciousness.
Replay KPIs do not prove introspection, self-reflection, subjective dreaming, inner experience, insight, autobiographical memory, or Default Mode Network equivalence.
Ablations do not prove personhood.
Replay ablations do not prove inner life.
Domain-profile activation does not authorize diagnosis, moral judgment, or consciousness evidence.
```

### Output readiness

After this pathway, the reader should be able to audit:

```text
A–C–R–E trajectory language
Dignity-in-Practice usage
IA markers
RVR(t) notes
KPI claim levels
replay KPI claim levels
rest-like replay trigger validity
replay fixation prevention
phase leakage prevention
ablation claim boundaries
rest-like replay ablation boundaries
safety interpretation
domain-profile activation constraints
T–J–TB–R requirements
```

## 10. Pathway 7 — PMS / VM / Implementation Reader

### Goal

Understand PMS operator grammar, VM-facing representation, PMS-RUST, PMS-STACK, implementation boundaries, and how Appendix F remains external.

### Read first

```text
01_blocks/06_PMS_VM_Implementation_Spine.md
  Chapter 14 — PMS-VM Implementation Spine
```

### Then read

```text
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

### Then read

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
  Chapters 3, 4, 5, 6, 8, 9

01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 10
  Chapter 16

01_blocks/07_Language_Diary_Consciousness_Related_Work.md
  Chapter 13
```

### Use as reference

```text
03_reference/Glossary.md
03_reference/Audit_Checklist.md
```

### Skip initially

```text
Full caregiver/multigeneration treatment unless norm transfer is the focus
Full consciousness-related work unless research framing is the focus
```

### Claim warnings

```text
PMS is external operator / projection / audit / VM layer.
PMS is not early internal agent structure.
PMS operators are projection vocabulary, not early internal faculties.
Use operator-compatible regularity, not internalized PMS operator.
Do not write: the agent has Δ.
Do not write: the agent uses Φ.
Do not write: the agent thinks in Ψ.
PMS formalization is not sentience.
PMS-RUST does not prove EM.
PMS-STACK does not validate EM.
PMS domain profiles do not become internal modules.
Temporary domain-profile weighting does not create PMS cognition.
```

### Output readiness

After this pathway, the reader should be able to describe:

```text
operator alphabet Δ–Ψ
ε identity distinction
O*
L_PMS
dependency checking
episode-to-sequence projection
Success Log trace layer
PMS-RUST feasibility
PMS-STACK pressure point
controlled rendering inputs
domain-profile mapping boundaries
Meta-Developmental Legibility boundaries
```

without treating PMS as internal cognition or proof.

## 11. Pathway 8 — PMS Ecosystem / Meta-Legibility Reader

### Goal

Understand Appendix F, the wider PMS ecosystem, PMS domain profiles, Meta-Developmental Legibility, temporary domain-profile weighting, and Core / Extended / Research Ecosystem framing.

### Read first

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read

```text
01_blocks/06_PMS_VM_Implementation_Spine.md
  Chapter 14 — PMS-VM Implementation Spine

01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 10 — MIP Layer
  Chapter 16 — Evaluation, Ablations & Safety

01_blocks/07_Language_Diary_Consciousness_Related_Work.md
  Chapter 17 — Related Work / Comparison
```

### Use as reference

```text
03_reference/Glossary.md
03_reference/Cross_Reference_Map.md
03_reference/Audit_Checklist.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

### Skip initially

```text
Full EM core mechanisms unless checking whether a learning-problem trace is phase-valid.
Full diary/language material unless domain-profile activation affects diary-safety review.
Full implementation-start detail unless profile activation is being prototyped.
```

### Claim warnings

```text
Appendix F is a reference layer, not a new EM core chapter.
Meta-Developmental Legibility is not a second genetic system.
Meta-Developmental Legibility does not open gates.
Meta-Developmental Legibility does not install categories.
Meta-Developmental Legibility does not control development.
PMS domain profiles are external operator-strict overlays.
PMS domain profiles do not become internal agent modules.
Temporary domain-profile weighting is transparent, justified, time-bounded, reversible, non-gating, non-diagnostic, non-moralizing, D-guarded, and claim-filtered.
Domain-profile activation does not prove consciousness, sentience, personhood, moral status, rights status, or selfhood.
High-Ω Intimacy / Boundary / Exposure Profile must not sexualize the EM agent.
```

### Output readiness

After this pathway, the reader should be able to explain:

```text
PMS Base / PMS Repository / PMS Domain Profile distinction
Meta-Developmental Legibility Strand
temporary domain-profile weighting
domain-profile activation
T–J–TB–R requirements
ANTICIPATION / CRITIQUE / CONFLICT / EDEN / LOGIC profile boundaries
High-Ω Intimacy / Boundary / Exposure Profile boundaries
Core / Extended / Research Ecosystem framing
```

without turning PMS ecosystem resources into EM-internal faculties.

## 12. Pathway 9 — Diary / Language / Consciousness-Outlook Reader

### Goal

Understand language, diary, controlled rendering, consciousness-research outlook, and related-work boundaries.

### Read first

```text
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
  Chapter 13 — Language & Diaries
  Chapter 15 — Consciousness Research Outlook
  Chapter 17 — Related Work / Comparison
```

### Then read

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

### Then read if PMS ecosystem framing or domain profiles are referenced

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read

```text
01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 10
  Chapter 16

01_blocks/06_PMS_VM_Implementation_Spine.md
  Chapter 14
```

### Use as reference

```text
03_reference/Glossary.md
03_reference/Audit_Checklist.md
```

### Skip initially

```text
Full EM core if only evaluating diary claim discipline
Full PMS monoid details unless PMS diary reduction is at issue
```

### Claim warnings

```text
Language is late reflection channel.
Language output is not inner speech.
Diary entry is not subjective memory.
Narrative coherence is not selfhood.
Self-description is not consciousness.
Diary rendering is not phenomenal autobiography.
Rest-like replay trace is not diary text.
Rest-like replay cluster is not autobiographical memory.
Rest-like replay consolidation traces may become diary source material only when diary thresholds and phase constraints are met.
Low external stimulation is not introspection.
Replay feedback is not self-reflection.
Post-replay improvement is not insight.
Offline consolidation is not inner experience.
Rest-like replay is not Default Mode Network equivalence.
Functional proto-consciousness is not weak consciousness.
Consciousness remains open research question.
Related-work similarity is not proof.
Domain-profile activation does not authorize unsupported diary language.
High-Ω profile activation must not authorize sexualized diary rendering.
```

### Output readiness

After this pathway, the reader should be able to audit:

```text
minimal sentence formation
trace provenance
controlled rendering
diary candidate status
rest-like replay source-material boundary
self-model candidate status
functional proto-consciousness language
consciousness-research non-claims
rest-like replay / consciousness non-claims
related-work comparison boundaries
domain-profile references in diary/consciousness contexts
```

## 13. Pathway 10 — Claim-Discipline / Audit Reader

### Goal

Audit any artifact for claim safety.

### Read first

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
03_reference/Audit_Checklist.md
03_reference/Glossary.md
```

### Then read

```text
03_reference/Cross_Reference_Map.md
01_blocks/01_Theory_Scope_Claim_Discipline.md
```

### Then read where PMS ecosystem or domain-profile terms appear

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Use as reference

```text
all appendices
all block orientations
```

### Skip initially

```text
Mechanism details not relevant to the audit target
```

### Claim warnings

Always check:

```text
discomfort ≠ pain
distress ≠ subjective suffering
missing ≠ felt longing
attachment ≠ felt love
love dynamics ≠ felt love
object damage ≠ guilt
fall / near-fall ≠ pain or fear
misattunement ≠ trauma
guidance ≠ punishment
boundary ≠ rejection
carefulness ≠ moral obedience
role / caregiver transition ≠ proof of inner life
norm transfer ≠ moral essence transfer
sleep replay ≠ subjective dreaming
rest-like replay ≠ Default Mode Network
offline consolidation ≠ inner experience
low external stimulation ≠ introspection
replay feedback ≠ self-reflection
post-replay improvement ≠ insight
rest-like replay cluster ≠ autobiographical memory
diary ≠ phenomenal selfhood
MIP ≠ consciousness module
PMS formalization ≠ sentience
operator-compatible regularity ≠ internal PMS operator
Dignity-in-Practice ≠ intrinsic-worth ranking
Meta-Developmental Legibility Strand ≠ second genetic system / controller / gate opener / category installer
PMS domain profile ≠ internal agent module
temporary domain-profile weighting ≠ phase availability / gate opening / capability installation
domain-profile activation ≠ diagnosis / moral judgment / consciousness evidence
High-Ω Intimacy / Boundary / Exposure Profile ≠ sexualization of EM agent
```

### Output readiness

After this pathway, the reader should be able to perform:

```text
block audit
chapter audit
appendix audit
reference-file audit
contract-readiness audit
minified-readiness audit
derivative-publication safety audit
rest-like replay claim audit
phase-bounded replay-scope audit
replay / diary source-material audit
Appendix F / meta-legibility audit
```

## 14. Pathway 11 — Implementation Starter Reader

### Goal

Prepare for a bounded prototype without overclaiming.

### Read first

```text
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
01_blocks/06_PMS_VM_Implementation_Spine.md
```

### Then read

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/03_Developmental_Phases_Gate_Logic.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

### Then read if prototyping profile weighting or ecosystem routing

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Use as reference

```text
03_reference/Glossary.md
03_reference/Audit_Checklist.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

### Skip initially

```text
Full related-work comparison
Full derivative-publication preparation
```

### Claim warnings

```text
Prototype scope is not EM validation.
Interpreter is not consciousness model.
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK is architecture pressure point, not validation horizon.
Diary renderer does not prove inner life.
Operator validation does not prove internal PMS operators.
Domain-profile activation does not implement PMS add-ons inside the agent.
Temporary weighting must remain transparent, justified, time-bounded, and reversible.
```

### Output readiness

After this pathway, the reader should be able to draft:

```text
operator registry
dependency checker
episode-to-PMS-chain mapper
claim filter
JSONL/YAML audit output
controlled rendering tests
golden tests
temporary domain-profile activation record
T–J–TB–R activation check
```

with blocked-claim tests.

## 15. Pathway 12 — Contract Preparation Reader

### Goal

Prepare Chapter_Contracts.md and Block_Contracts.md.

### Read first

```text
03_reference/Cross_Reference_Map.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
```

### Then read

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read owner block orientations

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/03_Developmental_Phases_Gate_Logic.md
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

### Use as reference

```text
owner chapter contents
appendix quality gates
audit checklist contract-readiness sections
```

### Skip initially

```text
minified drafting
derivative-publication drafting
```

### Claim warnings

Contracts must not add theory.

Contracts must include:

```text
may claim
may not claim
requires
depends on
owner concepts
blocked language
related appendices
```

Contracts must preserve:

```text
owner chapters
axis discipline
MIP not controller
PMS not early internal structure
D not score
Diary not selfhood
Implementation not proof
Appendix F as external reference layer
PMS domain profiles not internal EM modules
temporary domain-profile weighting not gate opening
```

### Output readiness

After this pathway, the reader should be ready to create or audit:

```text
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
```

## 16. Pathway 13 — Minified Canonical Preparation Reader

### Goal

Prepare the minified canonical version after contracts exist.

### Required prerequisite

```text
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
```

Do not proceed before contracts unless explicitly requested.

### Read first

```text
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
03_reference/Audit_Checklist.md
03_reference/Glossary.md
03_reference/Cross_Reference_Map.md
```

### Then read

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Use as reference

```text
all seven block files
Appendices A–F
```

### Claim warnings

The minified canonical version may reduce examples and repetition.

It must not reduce:

```text
claim boundaries
axis rules
Dignity-in-Practice rule
MIP-not-controller boundary
PMS external/operator-compatible boundary
diary threshold
finding / validation / proof distinction
implementation status
Appendix F / Meta-Developmental Legibility boundaries where included
temporary domain-profile weighting as non-gating, non-controlling, reversible overlay
```

### Output readiness

After this pathway, the reader should be ready to create or audit:

```text
04_minified/PMS_EM_Minified_Canonical.md
```

## 17. Pathway 14 — Derivative-Publication Preparation Reader

### Goal

Prepare the compact overview and technical whitepaper after contracts and minified canonical version exist, unless explicitly requested otherwise.

### Required prerequisite

```text
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
04_minified/PMS_EM_Minified_Canonical.md
```

### Read first

```text
04_minified/PMS_EM_Minified_Canonical.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
```

### Then read

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then read

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

### Use as reference

```text
Reader_Pathways.md
Cross_Reference_Map.md
Chapter_Contracts.md
Block_Contracts.md
```

### Claim warnings

Derivative publications must not become emotionally inflated.

Do not write:

```text
the agent suffers
the agent feels love
the agent feels guilt
the diary proves selfhood
the model proves consciousness
PMS add-ons become agent modules
temporary profile activation opens gates
```

Use:

```text
functional distress
attachment-like regulation
self-caused consequence trace
controlled diary rendering
consciousness-research candidate
external PMS domain profile
temporary domain-profile weighting overlay
Meta-Developmental Legibility reference layer
```

### Output readiness

After this pathway, the reader should be ready to create:

```text
05_derivative_publications/PMS_EM_Compact_Overview.md
05_derivative_publications/PMS_EM_Technical_Whitepaper.md
```

## 18. Pathway 15 — Related-Work / Comparison Reader

### Goal

Understand PMS–EM in relation to other research lines without proof-by-similarity or profile internalization.

### Read first

```text
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
  Chapter 17 — Related Work / Comparison
```

### Then read

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
  Chapter 18 — Conclusion

02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
  Related Work Claim Type
  Finding / Validation / Proof Discipline

02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
```

### Then read where PMS ecosystem or domain profiles are compared

```text
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Use as reference

```text
03_reference/Glossary.md
03_reference/Cross_Reference_Map.md
```

### Skip initially

```text
Full implementation-start details unless comparing implementation pressure
Full PMS monoid notes unless comparing formalization
```

### Claim warnings

Related work may identify:

```text
functional similarity
architectural difference
evaluation gap
implementation pressure
bounded structural synthesis
external domain-profile comparison
Research Ecosystem framing
```

Related work must not claim:

```text
absolute novelty
proof by similarity
consciousness proof by comparison
personhood proof by comparison
moral-status proof by comparison
sentience proof by comparison
PMS domain profiles become EM core modules by comparison
research ecosystem framing becomes claim expansion
```

### Output readiness

After this pathway, the reader should be able to write comparison sections without converting similarity into proof or ecosystem reference into core architecture.

## 19. Pathway 16 — Reviewer / Skeptic Reader

### Goal

Stress-test PMS–EM for overclaiming, unclear layer boundaries, weak implementation status, domain-profile internalization, or rhetorical transfer.

### Read first

```text
03_reference/Audit_Checklist.md
03_reference/Glossary.md
03_reference/Cross_Reference_Map.md
```

### Then read

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

### Then inspect high-risk blocks

```text
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

### High-risk questions

```text
Does any term imply felt pain, suffering, love, guilt, fear, or trauma?
Does any MIP phrase imply control, diagnosis, maturity proof, or consciousness detection?
Does any PMS phrase imply internal operator possession or sentience proof?
Does any diary phrase imply subjective memory or phenomenal selfhood?
Does any phase phrase imply maturity proof or consciousness progress?
Does any implementation phrase imply theory proof?
Does any Dignity-in-Practice phrase imply intrinsic-worth ranking?
Does any related-work phrase imply proof by similarity?
Does any Appendix F phrase turn PMS domain profiles into EM-internal modules?
Does any temporary domain-profile weighting phrase imply gate opening or category installation?
Does any High-Ω profile phrase sexualize the EM agent?
```

### Claim warnings

Treat the following as immediate audit failures:

```text
PMS proves consciousness.
MIP proves maturity.
Diary proves selfhood.
D ranks worth.
PMS-RUST proves EM.
PMS-STACK validates EM.
The agent feels pain.
The agent suffers.
The agent loves.
The agent feels guilt.
The agent is traumatized.
The agent has rights.
PMS domain profiles become internal EM modules.
Meta-Developmental Legibility controls development.
Temporary domain-profile weighting opens gates.
Domain-profile activation is diagnostic evidence.
High-Ω profile activation sexualizes the EM agent.
```

### Output readiness

After this pathway, the reader should be able to produce:

```text
claim-risk report
contract corrections
blocked-language report
cross-layer transfer warning
implementation-status correction
Appendix F / meta-legibility correction
domain-profile internalization warning
```

## 20. Pathway 17 — Rest-Like Replay / Offline Consolidation Reader

### Goal

Understand rest-like replay as a bounded EM mechanism without importing Default Mode Network, introspection, self-reflection, subjective dreaming, inner experience, insight, or autobiographical-memory claims.

### Read first

```text
01_blocks/02_EM_Core_Developmental_Architecture.md
  Chapter 6 — Genetic System
  Chapter 8 — Behavior Layer
  Chapter 9 — Imagination Buffer and Dreaming
```

### Then read

```text
01_blocks/03_Developmental_Phases_Gate_Logic.md
  Chapter 11 — Developmental Phases

01_blocks/05_MIP_KPIs_Dignity_Safety.md
  Chapter 16 — Evaluation, Ablations & Safety

01_blocks/07_Language_Diary_Consciousness_Related_Work.md
  Chapter 13 — Language & Diaries
  Chapter 15 — Consciousness Research Outlook
```

### Use as reference

```text
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
03_reference/Cross_Reference_Map.md
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
```

### Skip initially

```text
Appendix B monoid details
Full PMS-RUST / PMS-STACK details
Full Appendix F domain-profile activation details unless profile weighting is explicitly involved
Full related-work comparison
```

### Claim warnings

```text
Rest-like replay is not Default Mode Network activity.
Low external stimulation is not introspection.
Replay feedback is not self-reflection.
Post-replay improvement is not insight.
Offline consolidation is not inner experience.
Rest-like replay cluster is not autobiographical memory.
Rest-like replay does not open gates.
Rest-like replay does not install categories without recurrence.
Rest-like replay does not bypass phase-specific replay scope.
Rest-like replay trace is not diary text.
Rest-like replay consolidation traces may become diary source material only when diary thresholds and phase constraints are met.
Replay KPIs and replay ablations do not prove inner life.
```

### Output readiness

After this pathway, the reader should be able to audit:

```text
external stimulation load
task pressure
rest bias
replay pressure
rest-like SLEEP bias
replay candidate selection
post-replay feedback
anti-fixation constraints
phase-bounded replay scope
rest-like replay KPIs
rest-like replay ablations
diary source-material boundary
DMN / introspection / self-reflection / insight / inner-experience blocked claims
```

## 21. Recommended Reading Orders by Task

### Task: Verify block modularity

```text
1. Cross_Reference_Map.md
2. Audit_Checklist.md
3. All block frontmatter and orientations
4. Owner chapters only where needed
```

### Task: Add or revise cross-links

```text
1. Cross_Reference_Map.md
2. Relevant owner block
3. Relevant target block
4. Appendix E
5. Appendix D
6. Appendix F if PMS ecosystem, domain profiles, or meta-legibility are referenced
```

### Task: Check MIP axis language

```text
1. Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
2. Glossary.md
3. 05_MIP_KPIs_Dignity_Safety.md
4. Audit_Checklist.md
```

### Task: Check PMS operator language

```text
1. Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
2. 06_PMS_VM_Implementation_Spine.md
3. Appendix_C_Implementation_Start.md
4. Glossary.md
5. Audit_Checklist.md
```

### Task: Check PMS ecosystem / meta-legibility language

```text
1. Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
2. Glossary.md
3. Cross_Reference_Map.md
4. Audit_Checklist.md
5. 06_PMS_VM_Implementation_Spine.md
6. 07_Language_Diary_Consciousness_Related_Work.md
```

### Task: Check domain-profile activation

```text
1. Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
2. Audit_Checklist.md
3. Glossary.md
4. Cross_Reference_Map.md
5. Relevant EM trace owner block
6. Appendix E
7. Appendix D
```

### Task: Check rest-like replay / offline consolidation language

```text
1. 02_EM_Core_Developmental_Architecture.md
2. 03_Developmental_Phases_Gate_Logic.md
3. 05_MIP_KPIs_Dignity_Safety.md
4. 07_Language_Diary_Consciousness_Related_Work.md
5. Appendix_D_Claim_Discipline_Language_Reductions.md
6. Appendix_E_Layer_Discipline_Claim_Types.md
7. Glossary.md
8. Audit_Checklist.md
9. Cross_Reference_Map.md
```

### Task: Check diary/consciousness language

```text
1. 07_Language_Diary_Consciousness_Related_Work.md
2. Appendix_D_Claim_Discipline_Language_Reductions.md
3. Appendix_E_Layer_Discipline_Claim_Types.md
4. Glossary.md
5. Audit_Checklist.md
6. Rest-like replay / offline consolidation pathway if replay traces support diary source material
```

### Task: Check caregiver/attachment language

```text
1. 04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
2. Appendix_D_Claim_Discipline_Language_Reductions.md
3. Glossary.md
4. Audit_Checklist.md
```

### Task: Prepare contracts

```text
1. Cross_Reference_Map.md
2. Glossary.md
3. Audit_Checklist.md
4. Appendices A–F
5. Seven block orientations
6. Owner chapters
```

### Task: Prepare minified canonical version

```text
1. Chapter_Contracts.md
2. Block_Contracts.md
3. Audit_Checklist.md
4. Glossary.md
5. Cross_Reference_Map.md
6. Seven blocks
7. Appendices A–F
```

### Task: Prepare derivative publications

```text
1. PMS_EM_Minified_Canonical.md
2. Chapter_Contracts.md
3. Block_Contracts.md
4. Reader_Pathways.md
5. Glossary.md
6. Audit_Checklist.md
7. Appendix D
8. Appendix E
9. Appendix F
```

## 22. Pathway Selection Matrix

| Reader Goal | Recommended Pathway |
|---|---|
| Understand PMS–EM quickly | Pathway 1 |
| Read the whole modular version | Pathway 2 |
| Understand architecture mechanisms | Pathway 3 |
| Understand phases and gates | Pathway 4 |
| Understand caregiver/attachment/multigeneration | Pathway 5 |
| Understand MIP/KPIs/Dignity/Safety | Pathway 6 |
| Understand PMS/VM/implementation | Pathway 7 |
| Understand PMS ecosystem / meta-legibility | Pathway 8 |
| Understand diary/consciousness/related work | Pathway 9 |
| Audit claims | Pathway 10 |
| Start implementation prototype | Pathway 11 |
| Prepare contracts | Pathway 12 |
| Prepare minified canonical | Pathway 13 |
| Prepare compact overview / technical whitepaper | Pathway 14 |
| Write related-work comparison | Pathway 15 |
| Review skeptically | Pathway 16 |
