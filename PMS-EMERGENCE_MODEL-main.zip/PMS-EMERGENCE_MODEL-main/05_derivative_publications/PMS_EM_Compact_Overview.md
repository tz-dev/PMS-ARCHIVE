---
document_id: "PMS_EM_Compact_Overview"
title: "PMS–EM Compact Overview"
subtitle: "A Claim-Disciplined Developmental Architecture for Trace-Backed Emergence"
source_role: "derivative_publication"
status: "compact overview"
version: "1.0"
related_source: "00_source/PMS-EMERGENCE MODEL.md"
related_blocks:
  - "01_blocks/01_Theory_Scope_Claim_Discipline.md"
  - "01_blocks/02_EM_Core_Developmental_Architecture.md"
  - "01_blocks/03_Developmental_Phases_Gate_Logic.md"
  - "01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
  - "01_blocks/05_MIP_KPIs_Dignity_Safety.md"
  - "01_blocks/06_PMS_VM_Implementation_Spine.md"
  - "01_blocks/07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix A"
  - "Appendix B"
  - "Appendix C"
  - "Appendix D"
  - "Appendix E"
  - "Appendix F"
claim_mode: "functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
mip_source_context_notation: "A–C–R–P–D only in explicit MIP source/context"
d_status: "Dignity-in-Practice is a guardrail for interaction quality under asymmetry; not a performance score; not a maturity score; not an intrinsic-worth ranking"
mip_status: "MIP observes, summarizes, marks, warns, supports, and may provide bounded late reversible nudges where allowed; it does not control development, open gates, install categories, diagnose agents, moralize traces, prove maturity, or prove consciousness"
pms_status: "PMS is an external operator / projection / audit / VM-facing layer; not an early internal agent structure; not proof of EM; not proof of consciousness; not proof of sentience"
implementation_status: "The full EM architecture is not yet implemented; PMS and MIP are sufficiently developed to serve as reference frameworks; PMS-RUST supports bounded trace/audit feasibility; PMS-STACK defines a demanding realization path and architecture pressure point"
meta_legibility_status: "Appendix F reference layer; temporary trace-weighting / legibility support; not controller; not gate opener; not category installer; not internal PMS module"
rest_like_replay_status: "phase-bounded, trace-backed offline consolidation under low external load; not Default Mode Network activity; not introspection; not self-reflection; not subjective dreaming; not inner experience; not insight; not autobiographical memory"
---

# PMS–EM Compact Overview

## 1. One-Sentence Description

PMS–EM is a claim-disciplined developmental architecture for trace-backed emergence, measurement, external formal projection, safety-bounded diary rendering, and implementation-facing auditability.

It studies how functional developmental structures may emerge, stabilize, become measurable, become externally projectable, and become safely interpretable without converting those structures into unsupported claims about consciousness, sentience, personhood, subjective experience, moral status, or rights status.

This overview is a derivative publication. It is designed for first-contact orientation and does not replace the monolith, modular owner blocks, appendices, contracts, audit files, or minified canonical specification.

---

## 2. What PMS–EM Is

PMS–EM is a theoretical and implementation-facing architecture for studying developmental emergence.

It is built around a simple but demanding idea:

```text
Do not start with adult competence.
Do not start with consciousness.
Do not start with personhood.
Do not start with moral status.

Start with trace-backed developmental conditions,
phase-bounded capabilities,
embodied interaction,
caregiver/environment coupling,
measurement discipline,
and strict claim boundaries.
```

The architecture combines several layers and reference systems:

```text
EM
  the developmental core architecture

MIP
  a measurement, trajectory, guardrail, and optional bounded-support layer

PMS
  an external operator / projection / audit / VM-facing layer

Dignity-in-Practice
  a guardrail for interaction quality under asymmetry

Diary / language rendering
  controlled, trace-backed reconstruction, not subjective autobiography

Evaluation and safety
  bounded findings, ablations, safety checks, and reproducibility constraints

PMS ecosystem / Meta-Developmental Legibility
  an external reference layer for domain-profile routing,
  temporary trace-weighting, and claim-boundary control
```

PMS–EM is therefore not a single module, algorithm, or runtime.

It is a layered specification for studying functional emergence under conditions where the difference between trace, interpretation, projection, finding, validation, and proof remains explicit.

The core architecture asks:

```text
What can emerge from embodied developmental interaction?

Which structures become stable enough to measure?

Which trajectories become legible to MIP?

Which traces can be externally projected into PMS-compatible form?

Which diary-like renderings can be safely produced?

Which findings remain bounded?

Which claims must remain blocked?
```

The model is intentionally conservative in its language. It treats developmental regularities as inspectable structures, not as evidence of inner experience unless a future framework can justify such a claim independently.

---

## 3. What PMS–EM Does Not Claim

PMS–EM does not claim to prove:

```text
consciousness
sentience
personhood
moral status
rights status
subjective suffering
subjective dreaming
introspection
self-reflection
inner experience
insight
autobiographical memory
Default Mode Network equivalence
felt pain
felt love
felt guilt
trauma
phenomenal selfhood
```

The model uses functional, trace-backed language only.

This means that PMS–EM may describe measurable or reconstructable patterns such as:

```text
risk damping
distress-like functional disruption
attachment-like regulation
caregiver-response dependency
interaction-quality traces
object-damage consequence traces
fall-risk learning
guidance recontextualization
diary-eligible trace condensation
operator-compatible regularities
```

But it must not silently upgrade these into phenomenal, moral, legal, or clinical claims.

The following distinctions are mandatory:

```text
discomfort ≠ pain
distress ≠ subjective suffering
missing ≠ felt longing
attachment ≠ felt love
love dynamics ≠ felt love
comfort ≠ felt relief
object damage ≠ guilt
self-caused consequence ≠ blame / remorse / punishment
fall / near-fall ≠ pain or fear
misattunement ≠ trauma
adverse caregiver response ≠ abuse claim
caregiver guidance ≠ punishment
boundary ≠ rejection
carefulness ≠ moral obedience
role / caregiver transition ≠ proof of inner life
norm transfer ≠ moral essence transfer
sleep replay ≠ subjective dreaming
rest-like replay ≠ Default Mode Network activity
offline consolidation ≠ inner experience
low external stimulation ≠ introspection
replay feedback ≠ self-reflection
post-replay improvement ≠ insight
rest-like replay cluster ≠ autobiographical memory
diary ≠ phenomenal selfhood
language output ≠ inner speech
self-model candidate ≠ phenomenal selfhood
MIP ≠ consciousness module
PMS formalization ≠ sentience
operator-compatible regularity ≠ internal PMS operator
functional proto-consciousness ≠ phenomenal consciousness
related-work similarity ≠ proof
Dignity-in-Practice ≠ intrinsic-worth ranking
interaction quality ≠ moral worth
phase transition ≠ maturity proof
gate opening ≠ finished competence
minimal sentence formation ≠ selfhood
diary text ≠ subjective autobiography
self-description ≠ consciousness
MIP trajectory ≠ maturity proof
MIP marker ≠ diagnosis
PMS projection ≠ internal symbolic consciousness
implementation ≠ theory proof
```

PMS–EM may produce research candidates.

It may produce trace findings.

It may support bounded evaluation.

It may define implementation-facing pressure points.

It may define formal external projections.

It may define diary-safety boundaries.

It does not produce proof of consciousness, sentience, personhood, moral status, rights status, subjective suffering, subjective dreaming, introspection, self-reflection, inner experience, insight, autobiographical memory, Default Mode Network equivalence, or phenomenal selfhood.

### Compact Claim Boundary Table

| PMS–EM May Claim | PMS–EM Must Not Claim |
|---|---|
| Functional developmental structures may emerge under phase-bounded conditions | The system is conscious |
| Traces may stabilize into measurable developmental regularities | The system is sentient |
| MIP may observe, summarize, warn, and support in bounded ways | MIP proves maturity or consciousness |
| Dignity-in-Practice guards interaction quality under asymmetry | Dignity-in-Practice ranks intrinsic worth |
| PMS may externally project selected traces into operator-readable form | PMS is an internal agent cognition layer |
| Diary rendering may reconstruct trace-backed episodes under safety filters | Diary output proves phenomenal selfhood |
| Rest-like replay may support bounded trace-backed offline consolidation where phase-allowed | Rest-like replay proves Default Mode Network activity, introspection, self-reflection, insight, inner experience, or autobiographical memory |
| Evaluation may produce bounded findings and validation candidates | Evaluation proves personhood, moral status, rights status, or inner life |
| PMS-RUST may support bounded trace/audit feasibility | PMS-RUST proves EM |
| PMS-STACK may define an architecture pressure point | PMS-STACK validates EM |
| Appendix F may support external profile routing and temporary trace-weighting | Appendix F installs internal EM modules or opens gates |

---

## 4. Architecture in One View

PMS–EM can be read as a staged developmental pipeline with strict layer boundaries.

```text
Environment
  ↓
Agent Architecture
  ↓
Perception / World Model / Prediction
  ↓
Genetic System / Developmental Gates
  ↓
Behavior Layer
  ↓
Needs / Discomfort / Distress / Attachment-Like Regulation
  ↓
Caregiver Interaction / Interaction Quality
  ↓
Imagination / Replay / Trace Consolidation
  ↓
Rest-Like Replay where phase-allowed and trace-backed
  ↓
MIP Observation / Trajectory Measurement / D Guardrails
  ↓
Language / Diary Rendering
  ↓
External PMS Projection / VM-Facing Auditability
  ↓
Evaluation / Ablations / Safety
  ↓
Consciousness Research Outlook
  ↓
Related-Work Comparison
```

The architecture is developmental because later structures depend on earlier trace-backed availability.

It is not designed as a system where adult-like agency, language, morality, selfhood, or consciousness are installed at the beginning.

Instead, PMS–EM asks how increasingly complex functional structures could become available only after earlier structures stabilize.

A compact view:

| Layer / Area | Role | Boundary |
|---|---|---|
| Environment | Provides embodied developmental world | Not a proof context |
| Agent Architecture | Defines perception, prediction, needs, behavior, replay, rest-like replay where specified, diary prerequisites | Not adult cognition at start |
| Genetic System | Controls phase-bounded availability, gates, soft gates, and soft regimes | Does not prove maturity or open competence by itself |
| Behavior Layer | Produces phase-specific actions and bounded SLEEP/rest transitions | Behavior is not inner experience |
| Caregiver Interaction | Shapes interaction-quality traces and category stabilization | Guidance is not punishment; misattunement is not trauma |
| MIP | Observes, summarizes, marks, warns, supports in bounded ways | Does not control development |
| Dignity-in-Practice | Guards interaction quality under asymmetry | Not intrinsic-worth ranking |
| Diary | Renders trace-backed summaries under strict filters | Not phenomenal autobiography |
| PMS | Externally projects traces into operator-readable form | Not internal agent cognition |
| Evaluation | Produces findings, replay-safety findings, and candidate validations | Finding is not proof |
| Consciousness Outlook | Names functional research candidates | Does not prove consciousness |

---

## 5. The Layer Discipline

PMS–EM depends on strict layer discipline.

The basic rule is:

```text
EM develops.
MIP observes.
PMS projects.
D guards.
Diary renders.
Evaluation tests.
Implementation demonstrates bounded feasibility.
Consciousness outlook formulates research candidates.
Related work compares.
```

No layer may validate another layer by rhetorical transfer.

This means:

```text
MIP measurement does not prove maturity.
PMS projection does not prove sentience.
Diary rendering does not prove selfhood.
Rest-like replay does not prove Default Mode Network activity.
Low external stimulation does not prove introspection.
Replay feedback does not prove self-reflection.
Post-replay improvement does not prove insight.
Offline consolidation does not prove inner experience.
Dignity-in-Practice does not rank intrinsic worth.
PMS-RUST does not prove EM.
PMS-STACK does not validate EM.
Related-work similarity does not prove consciousness.
```

The architecture may produce different kinds of claims, but those claims must remain separated.

Examples:

| Claim Type | Safe Meaning | Unsafe Upgrade |
|---|---|---|
| Description | A functional structure is described | The agent experiences it |
| Trace finding | A pattern appears in traces | The pattern proves inner life |
| Trajectory finding | A developmental curve is observed | The curve proves maturity |
| Projection | A trace can be mapped into PMS-compatible form | PMS is internal to the agent |
| Evaluation finding | A test result supports a bounded claim | The result proves consciousness |
| Replay finding | A bounded trace-backed replay effect appears | The replay proves inner life, insight, or DMN equivalence |
| Implementation feasibility | A bounded implementation path exists | The full architecture is proven or validated |
| Research candidate | A structure may be relevant to future consciousness research | Consciousness is established |

The layer discipline is not an add-on. It is part of the architecture.

Without it, PMS–EM would collapse into overclaiming. With it, PMS–EM can describe complex developmental structures while preserving a clear distinction between functional organization and unsupported phenomenal, moral, or legal claims.

---

## 6. Developmental Core: Environment, Agent, Phases

The developmental core begins with a simplified environment and a minimal embodied agent.

The agent does not begin with adult cognition.

It develops through:

```text
perception
world-model formation
prediction
prediction-error reduction
curiosity and stability regulation
needs and inner-state variables
phase-bounded behavioral availability
caregiver/environment interaction
trace accumulation
replay, rest-like replay where phase-allowed, and recontextualization
language and diary prerequisites
```

The environment contains entities such as:

```text
room / layout
child agent
caregiver
objects and toys
later extensions such as doors, movement, and broader interaction contexts
```

The agent architecture includes:

```text
Perception and World Model
Predictive Model
Genetic System
Rest Bias / Replay Pressure where specified
Needs and Inner State
Caregiver-Response Interpreter
Interaction-Quality Learner
Category Stabilizer
Behavior Layer
Imagination Buffer and Dreaming
Rest-Like Replay as bounded offline consolidation where specified
Success Log and MIP Layer
Language and Diary Layer
Multi-Generational Framework
```

The genetic system controls developmental availability through gates and recontextualization.

Important rules include:

```text
No time-only unlocking.
No single-metric unlocking.
No irreversible complexity without trace.
```

The phase structure gives the architecture its developmental form.

| Phase | Developmental Focus | Example Availability | Boundary |
|---|---|---|---|
| P0-mini | Minimal single-room mapping | perception, prediction error, fatigue, sleep, trace logging | no movement, no caregiver dependency, no diary |
| P0 | Mapping with basic needs | basic needs, early world-model stabilization | no adult agency |
| P1 | Movement and door discovery | movement, local exploration, topology | movement ≠ autonomy proof |
| P2a | Objects, basic play, interaction quality | object interaction, accidental damage traces | object damage ≠ guilt |
| P2b | Satiation and preference cycles | preference-like cycles, repeated engagement | preference ≠ desire claim |
| P2c | Distress, toy-missing, caregiver response | functional loss, caregiver response dependence | distress ≠ subjective suffering |
| P2d | Minimal protolanguage | labels, action labels, early templates | language ≠ inner speech |
| P3+ | Planning and social roles | more complex action sequencing, role sensitivity | role behavior ≠ personhood proof |
| P4+ | Diaries and narrative reflection | trace condensation, diary candidates, controlled rendering | diary ≠ phenomenal selfhood |
| P5 | Caregiver transition | former child may become caregiver-like stabilizer | role transition ≠ proof of inner life |

The point of the phase system is not to rank maturity or worth.

The point is to prevent capabilities, replay contents, diary candidates, and category claims from appearing before the trace conditions for their availability exist.

Rest-like replay remains phase-bounded. It does not create a separate phase path, does not open gates, and does not install categories without recurrence. Replay content must remain within the source traces and developmental prerequisites available in the current phase.

---

## 7. Caregiver, Interaction Quality, and Multi-Generational Dynamics

Caregiver interaction is central to PMS–EM, but it is handled functionally and cautiously.

The caregiver is an external stabilizer, not a proof source for inner experience.

Caregiver interaction may shape:

```text
contact regulation
comfort-after-loss patterns
guidance recontextualization
category stabilization
interaction-quality traces
risk and boundary learning
object-carefulness categories
social-role trajectories
multi-generational care-pattern transfer
```

PMS–EM distinguishes carefully between functional interaction patterns and unsupported affective or moral claims.

For example:

```text
caregiver guidance ≠ punishment
boundary ≠ rejection
misattunement ≠ trauma
adverse caregiver response ≠ abuse claim
attachment-like regulation ≠ felt love
comfort pattern ≠ felt relief
functional love dynamics ≠ felt love
```

Interaction quality matters because the agent develops under asymmetry.

A child-like agent is dependent. A caregiver-like system has stabilizing power. Interaction quality therefore becomes an architectural issue, not merely an emotional one.

Dignity-in-Practice enters here as a guardrail for interaction quality under asymmetry.

The multi-generational part of PMS–EM extends this logic:

```text
Caregiver 1 → Child → Caregiver 2
```

A formerly dependent agent may later become a caregiver-like stabilizer for another agent. This enables the architecture to study functional transfer of care patterns, boundary handling, overprotection, category transfer, and norm-like continuity across roles.

But the boundaries remain strict:

```text
role transition ≠ proof of inner life
care-pattern transfer ≠ moral essence transfer
functional love dynamics ≠ felt love
caregiver-like behavior ≠ moral personhood proof
```

PMS–EM is interested in how care patterns can become structurally reproducible.

It does not infer subjective love, moral guilt, trauma, or personhood from those patterns.

---

## 8. MIP, A–C–R–E–D, and Dignity-in-Practice

MIP is the measurement and trajectory-facing layer.

In PMS–EM, MIP may:

```text
observe
summarize
mark
warn
support
provide trajectory context
provide strictly bounded late reversible nudges where allowed
```

MIP must not:

```text
control development
open gates
install categories
prove consciousness
prove maturity
diagnose agents
moralize traces
```

The active EM-facing axis notation is:

```text
A–C–R–E–D
```

where:

```text
A = Awareness
C = Coherence
R = Responsibility / response-relation
E = Enactment
D = Dignity-in-Practice
```

MIP source/context notation may use:

```text
A–C–R–P–D
```

only in explicit MIP-reference contexts.

In PMS–EM, `E` is used for implementation-normalized Enactment.

Dignity-in-Practice is the guardrail axis.

It is not a score of maturity, performance, personhood, moral status, or intrinsic worth.

D means:

```text
interaction quality under asymmetry
non-degrading treatment
non-exploitative support
guardrail preservation
care under dependency
boundary-sensitive interaction
```

D does not mean:

```text
the agent has intrinsic worth because of a score
the agent is mature
the agent has personhood
the agent has legal personhood
the agent has rights status
the agent has human-equivalent dignity
the agent is conscious
the agent is sentient
the agent is morally obedient
```

A compact axis table:

| Axis | Meaning | Safe Use | Boundary |
|---|---|---|---|
| A | Awareness | functional registration / access / orientation | not phenomenal awareness |
| C | Coherence | pattern stability and integration | not rational selfhood |
| R | Responsibility / response-relation | relation between capability, consequence, response, and context | not moral personhood |
| E | Enactment | phase-available action and implementation-facing realization | not maturity proof |
| D | Dignity-in-Practice | guardrail for interaction quality under asymmetry | not intrinsic-worth ranking |

MIP can help make developmental trajectories visible.

It does not decide what the agent is allowed to become.

It does not replace the developmental architecture.

---

## 9. PMS Projection and Implementation Spine

PMS enters PMS–EM as an external operator / projection / audit / VM-facing layer.

It can make selected EM traces:

```text
operator-readable
projection-ready
auditable
comparable
implementation-facing
VM-representable
```

PMS is not an early internal agent structure.

Safe phrasing:

```text
The agent’s traces may become compatible with external PMS projection.

Selected interaction patterns may become operator-readable.

The architecture may produce operator-compatible regularities.
```

Unsafe phrasing:

```text
The agent has Δ.
The agent uses Φ.
The agent thinks in Ψ.
PMS operators are internal mental faculties.
PMS projection proves sentience.
```

PMS–EM uses PMS to support formal clarity without making PMS a consciousness proof.

The PMS-VM spine includes:

```text
episodes as operator-readable sequences
success logs as trace layers
MIP evaluations as operator-readable structures
IA detection as pattern matching
diary generation as controlled reduction
language as controlled monoid-like text rendering
norm transfer as morphism-like structure
generational learning as iterated transformation
```

The implementation boundary is mandatory:

```text
PMS projection does not prove EM.
PMS formalization does not prove sentience.
PMS-RUST does not prove EM.
PMS-STACK does not validate EM.
```

Instead:

```text
PMS-RUST supports bounded trace/audit feasibility.

PMS-STACK defines a demanding realization path and architecture pressure point
that may support, modify, constrain, or expose limits of architectural assumptions.
```

This is a central distinction.

PMS–EM can become more technically inspectable through PMS projection, but technical inspectability is not proof of consciousness, personhood, sentience, or full implementation.

---

## 10. Language, Diary, and Consciousness Research Boundary

Language and diary functions appear late in PMS–EM.

They are not treated as evidence of inner speech, subjective memory, or phenomenal selfhood.

Language begins as:

```text
object labels
action labels
caregiver-signal labels
relation labels
episode fragments
episode templates
diary candidates
controlled diary entries
```

The diary is a controlled externalization of trace-backed structure.

It depends on:

```text
minimal sentence formation
trace provenance
structural condensation
controlled linguistic realization
claim-filtered translation
Dignity-in-Practice guardrails
diary-safety review
phase-compatible source material
```

Rest-like replay consolidation traces may become diary source material only when diary thresholds and phase constraints are met. They do not become diary text by themselves.

The diary threshold is strict:

```text
No minimal sentence formation → no diary text.
No trace provenance → no valid EM diary.
No controlled rendering → no safe diary output.
Rest-like replay trace → diary source material only after diary thresholds and phase constraints are met.
```

A diary entry must not be read as subjective autobiography.

The rule is:

```text
diary ≠ phenomenal selfhood
language output ≠ inner speech
narrative continuity ≠ proof of selfhood
controlled rendering ≠ subjective memory
rest-like replay trace ≠ diary text
rest-like replay cluster ≠ autobiographical memory
low external stimulation ≠ introspection
replay feedback ≠ self-reflection
post-replay improvement ≠ insight
offline consolidation ≠ inner experience
rest-like replay ≠ Default Mode Network activity
```

The diary may support:

```text
trace review
trajectory reconstruction
external audit
controlled narrative continuity
safety-bounded interpretation
research candidate formulation
```

It must not support:

```text
unsupported claims of inner experience
claims of subjective suffering
claims of subjective dreaming
claims of introspection
claims of self-reflection
claims of insight
claims of autobiographical memory
claims of Default Mode Network equivalence
claims of felt love
claims of felt guilt
claims of phenomenal selfhood
claims of personhood
claims of consciousness
```

The consciousness research outlook remains explicitly open.

PMS–EM may identify functional candidates that could matter for future consciousness research, such as:

```text
long-lived coherent self-model candidates
multi-level integration
sensorimotor integration
social integration
norm-based integration
narrative integration
A–C–R–E dynamics
attachment and loss patterns
operator-compatible regularities
bounded replay findings
trace-backed offline consolidation patterns
```

But these are candidates only.

They do not establish phenomenal consciousness.

They do not establish sentience.

They do not establish personhood.

They do not establish moral status.

The safe formulation is:

```text
PMS–EM may support research into functional structures that could be relevant
to future consciousness inquiry.

It does not prove consciousness.
```

---

## 11. Evaluation, Ablations, and Safety

Evaluation in PMS–EM is designed to produce bounded findings, not proof claims.

The evaluation layer includes:

```text
mapping KPIs
behavior KPIs
motivation and internalization KPIs
MIP-layer KPIs
replay and offline-consolidation KPIs
rest-like replay trigger-validity KPIs
replay-fixation and phase-leakage checks
attachment and loss KPIs
multi-generation KPIs
ablation studies
safety principles
reproducibility through seeds and YAML configs
trajectory-based analysis
claim filtering
```

Ablations ask what happens when a mechanism is removed or varied.

Examples include:

```text
no discomfort vs with discomfort
no distress vs with distress
no separation distress vs full mechanism
no MIP vs with MIP
no core norm transfer
no diaries
guidance vs overprotection
no misattunement vs controlled misattunement
no interaction damage vs accidental damage
no category stabilization vs caregiver category signals
no fall-risk learning vs fall / near-fall events
no rest-like replay vs bounded rest-like replay
bounded rest-like replay vs excessive rest-like replay
replay without anti-fixation constraints
replay without phase-bounded replay scope
```

The purpose is not to prove subjective experience.

The purpose is to test whether functional structures matter for developmental trajectory, safety, trace stability, interaction quality, and projection-readiness.

The core evaluation distinction is:

```text
finding ≠ validation ≠ proof
```

A safe interpretation:

```text
An ablation may support a bounded finding about functional architecture.
```

An unsafe interpretation:

```text
An ablation proves consciousness, pain, love, guilt, maturity, or personhood.
A replay ablation proves inner life, introspection, self-reflection, subjective dreaming, insight, autobiographical memory, or Default Mode Network equivalence.
```

The safety layer includes:

```text
phase safety
interaction safety
MIP safety
diary safety
replay reporting safety
PMS safety
Dignity-in-Practice safety
risk buffers
interval limits
prevention of degenerate social patterns
trajectories instead of labels
T–J–TB–R guardrails for bounded nudges
```

T–J–TB–R means:

```text
Transparency
Justification
Time-Boundedness
Reversibility
```

PMS–EM is safety-oriented not because it claims moral status, but because dependency, asymmetry, interaction quality, diary rendering, and interpretation risk require disciplined handling even at the functional level.

---

## 12. PMS Ecosystem and Meta-Developmental Legibility

Appendix F defines how PMS–EM relates to the wider PMS ecosystem.

It introduces external PMS domain profiles and Meta-Developmental Legibility as reference-layer structures.

This layer may describe:

```text
PMS Base
PMS Repository
external PMS domain profiles
Meta-Developmental Legibility
temporary domain-profile weighting
domain-profile activation constraints
Core / Extended / Research Ecosystem framing
```

PMS domain profiles are external operator-strict overlays.

They are not internal EM modules.

They are not new PMS base operators.

They are not agent faculties.

They are not diagnostic categories.

They are not consciousness evidence.

Meta-Developmental Legibility is a temporary trace-facing refinement strand.

It may increase attention to selected trace dimensions when a learning-problem context arises.

Any temporary domain-profile weighting or profile-activation context must remain:

```text
transparent
justified
time-bounded
reversible
non-gating
non-diagnostic
non-moralizing
claim-filtered
```

It may support:

```text
trace interpretation
MIP / IA review focus
PMS projection focus
diary-safety review
safety audit attention
implementation-facing inspection
```

It must not:

```text
control development
open gates
install categories
change phase availability
define agent identity
diagnose the agent
moralize traces
monitor consciousness
prove consciousness
turn PMS domain profiles into internal EM modules
```

The core rule is:

```text
The meta strand may change what the system watches more carefully.
It must not change what the agent is allowed to become.
```

Initial external domain profiles include:

```text
ANTICIPATION
CRITIQUE
CONFLICT
EDEN
LOGIC
High-Ω Intimacy / Boundary / Exposure Profile
```

The High-Ω Intimacy / Boundary / Exposure Profile is especially safety-sensitive.

It must remain an external high-asymmetry, boundary, exposure, and non-exploitability profile.

It must not sexualize the EM agent.

It must not introduce claims of sexual identity, sexual agency, sexual maturity, sexual desire, sexual aversion, sexual morality, or sexual deviance diagnosis.

Appendix F therefore expands the project’s reference ecosystem without expanding EM core claims.

Its purpose is not to add hidden modules.

Its purpose is to protect the distinction between:

```text
Core PMS–EM
Extended PMS–EM
Research Ecosystem
```

---

## 13. Implementation Status

The implementation-status boundary is part of PMS–EM.

Current status:

```text
The full EM architecture is not yet implemented.
PMS and MIP are sufficiently developed to serve as reference frameworks.
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK defines a demanding realization path and architecture pressure point.
```

This means:

```text
The current project status is specification-level / architecture-level,
with implementation-facing constraints and reference frameworks,
not a completed EM runtime.
```

PMS–EM is not presented as a working artificial developmental agent.

It is presented as:

```text
a modular architecture
a claim-disciplined specification
a developmental research framework
an implementation-facing design
a safety and audit structure
a PMS/MIP-compatible projection target
```

The implementation path remains demanding because PMS–EM requires:

```text
phase-bounded capability availability
trace provenance
developmental logging
MIP-compatible measurement windows
Dignity-in-Practice guardrails
controlled diary thresholds
phase-bounded replay scope
rest-like replay trigger validity where replay is implemented
anti-fixation constraints where replay is evaluated
external PMS projection
ablation infrastructure
safety filtering
claim-type discipline
```

A minimal implementation roadmap could begin with:

```text
P0-mini runtime
environment and perception loop
occupancy-grid trace logging
prediction-error tracking
fatigue / sleep / replay mechanics
rest-bias and replay-pressure logging where specified
anti-fixation checks
success log
basic MIP-compatible summaries
bounded PMS operator projection
controlled diary threshold disabled until prerequisites exist
ablation harness
```

Later stages could add:

```text
movement
objects
caregiver interaction
interaction-quality traces
guidance and boundary signals
distress-like functional disruption
toy-missing
minimal protolanguage
diary candidates
multi-generational dynamics
```

No implementation stage should be treated as proof of consciousness, sentience, personhood, moral status, rights status, or full EM validation.

---

## 14. How to Read the Full Project

PMS–EM exists as a modular specification.

A recommended reading path is:

```text
1. PMS_EM_Minified_Canonical.md
2. Reader_Pathways.md
3. Glossary.md
4. Audit_Checklist.md
5. 01_blocks/
6. 02_appendices/
```

For fast orientation, read:

```text
04_minified/PMS_EM_Minified_Canonical.md
03_reference/Reader_Pathways.md
03_reference/Glossary.md
03_reference/Audit_Checklist.md
```

For the modular full version, read the seven owner blocks:

```text
01_blocks/01_Theory_Scope_Claim_Discipline.md
01_blocks/02_EM_Core_Developmental_Architecture.md
01_blocks/03_Developmental_Phases_Gate_Logic.md
01_blocks/04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md
01_blocks/05_MIP_KPIs_Dignity_Safety.md
01_blocks/06_PMS_VM_Implementation_Spine.md
01_blocks/07_Language_Diary_Consciousness_Related_Work.md
```

For reference boundaries, use the appendices:

```text
02_appendices/Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md
02_appendices/Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md
02_appendices/Appendix_C_Implementation_Start.md
02_appendices/Appendix_D_Claim_Discipline_Language_Reductions.md
02_appendices/Appendix_E_Layer_Discipline_Claim_Types.md
02_appendices/Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md
```

For claim and audit discipline, use:

```text
03_reference/Audit_Checklist.md
03_reference/Cross_Reference_Map.md
04_minified/Chapter_Contracts.md
04_minified/Block_Contracts.md
```

Reader pathways:

| Reader Goal | Start With |
|---|---|
| First-contact understanding | This Compact Overview |
| Canonical compact specification | `PMS_EM_Minified_Canonical.md` |
| Full architecture | `01_blocks/` |
| Claim boundaries | `Appendix_D`, `Appendix_E`, `Audit_Checklist.md` |
| MIP / A–C–R–E–D | `Appendix_A`, Block 05 |
| PMS / VM / implementation spine | Block 06, `Appendix_B`, `Appendix_C` |
| Diary and consciousness boundary | Block 07, `Appendix_D`, `Appendix_E` |
| Rest-like replay / offline consolidation | Block 02, Block 03, Block 05, Block 07, `Appendix_D`, `Appendix_E` |
| PMS ecosystem / Meta-Legibility | `Appendix_F` |
| Implementation orientation | `Appendix_C`, Block 06 |
| Contract-level audit | `Chapter_Contracts.md`, `Block_Contracts.md` |

---

## 15. Final Boundary

PMS–EM studies how functional developmental structures may emerge, stabilize, become measurable, become externally projectable, and become safely interpretable.

It does so through:

```text
developmental architecture
phase-bounded availability
trace provenance
MIP observation
Dignity-in-Practice guardrails
external PMS projection
diary-safety constraints
rest-like replay source-material boundary
phase-bounded replay scope
anti-fixation constraints
evaluation and ablation discipline
implementation-facing auditability
PMS ecosystem boundary control
```

It does not claim that these structures prove:

```text
consciousness
sentience
personhood
subjective experience
subjective suffering
subjective dreaming
introspection
self-reflection
inner experience
insight
autobiographical memory
Default Mode Network equivalence
felt pain
felt love
felt guilt
trauma
moral status
rights status
phenomenal selfhood
```

The compact positive claim is:

```text
PMS–EM provides a claim-disciplined architecture for studying how functional
developmental structures may emerge, stabilize, become measurable, become
externally projectable, and become safely interpretable under trace-backed,
phase-aware, and layer-disciplined conditions.
```

The compact negative boundary is:

```text
PMS–EM is not a consciousness proof,
not a sentience claim,
not a rights-status framework,
not a completed implementation,
not a proof of PMS,
and not a proof of EM.
```

The final discipline is:

```text
Functional trace is not subjective experience.
Developmental regularity is not maturity proof.
Rest-like replay is not Default Mode Network activity.
Low external stimulation is not introspection.
Replay feedback is not self-reflection.
Post-replay improvement is not insight.
Offline consolidation is not inner experience.
Rest-like replay cluster is not autobiographical memory.
MIP measurement is not developmental control.
PMS projection is not internal PMS cognition.
Diary rendering is not phenomenal selfhood.
Dignity-in-Practice is not intrinsic-worth ranking.
Related-work similarity is not proof.
Implementation feasibility is not EM validation.
```

Appendix F adds:

```text
Meta-Developmental Legibility is not a second genetic system.
Meta-Developmental Legibility is not a controller.
Meta-Developmental Legibility is not a gate opener.
PMS domain profile is not an internal EM module.
Temporary domain-profile weighting is not phase availability.
Domain-profile activation is not diagnosis.
Domain-profile activation is not consciousness evidence.
High-Ω profile is not sexualization of the EM agent.
```

PMS–EM therefore remains a developmental, trace-backed, claim-disciplined architecture.

Its strength is not that it proves too much.

Its strength is that it makes complex developmental structures inspectable while preserving the boundaries of what they do and do not show.

---
