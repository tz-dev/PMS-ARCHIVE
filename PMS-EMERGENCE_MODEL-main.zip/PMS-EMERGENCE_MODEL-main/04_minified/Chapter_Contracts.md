---
document_id: PMS-EM-CONTRACT-CHAPTERS
title: "Chapter Contracts"
source: "PMS-EMERGENCE MODEL.md"
source_role: "contract audit artifact"
status: "contract-layer"
version: "v1"
related_blocks:
  - "01_Theory_Scope_Claim_Discipline.md"
  - "02_EM_Core_Developmental_Architecture.md"
  - "03_Developmental_Phases_Gate_Logic.md"
  - "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
  - "05_MIP_KPIs_Dignity_Safety.md"
  - "06_PMS_VM_Implementation_Spine.md"
  - "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
related_reference_files:
  - "Cross_Reference_Map.md"
  - "Glossary.md"
  - "Audit_Checklist.md"
  - "Reader_Pathways.md"
claim_mode: "contract audit artifact; functional, trace-backed, claim-disciplined"
active_axis_notation: "A–C–R–E–D"
mip_source_context_notation: "A–C–R–P–D only in explicit MIP source/context"
d_status: "Dignity-in-Practice; guardrail; not performance score; not intrinsic-worth ranking"
mip_status: "measurement / observation / guardrail / optional support; not controller"
pms_status: "external operator / projection / audit / VM layer; not early internal agent structure"
meta_legibility_status: "Appendix F reference layer; temporary, reversible, time-bounded trace-weighting; not controller; not gate opener; not internal PMS module"
---

# Chapter Contracts

## 1. Purpose

This file defines chapter-level contracts for the modular PMS–EM artifact set.

It is an audit artifact.

It does not introduce new theory claims.

Each chapter contract defines:

```text
chapter number
chapter title / topic
owner block
may claim
may not claim
requires
depends on
owner concepts
blocked language
related appendices
```

The contracts constrain later reductions, especially:

```text
Block_Contracts.md
PMS_EM_Minified_Canonical.md
PMS_EM_Compact_Overview.md
PMS_EM_Technical_Whitepaper.md
```

Every later artifact must preserve these contracts unless the master specification is explicitly revised.

## 2. Global Contract Rules

All chapter contracts inherit the following global rules.

### 2.1 Source Rule

```text
PMS-EMERGENCE MODEL.md remains the source of truth.
```

Chapter contracts constrain derived artifacts. They do not replace the owner chapters.

### 2.2 Owner Rule

```text
Each chapter has exactly one owner block.
```

A chapter may be referenced elsewhere. It must not be duplicated as full content outside its owner block.

### 2.3 Axis Rule

Active EM-facing notation:

```text
A–C–R–E–D
```

MIP source/context notation:

```text
A–C–R–P–D
```

may appear only in explicit MIP reference contexts.

Retired historical notation, including `B–K–V–H`, may appear only in Appendix A or explicit historical audit context.

### 2.4 Dignity Rule

```text
Dignity-in-Practice = interaction quality under asymmetry.
```

D is not:

```text
performance score
maturity score
intrinsic-worth ranking
rights status
moral status
legal personhood
human-equivalent dignity
consciousness
sentience
```

### 2.5 Layer Rule

```text
EM develops.
MIP observes.
PMS projects.
D guards.
Diary renders.
Evaluation tests.
Implementation demonstrates bounded feasibility.
Appendix F routes PMS ecosystem and Meta-Developmental Legibility reference boundaries.
Consciousness outlook formulates research candidates.
Related work compares.
```

No layer may validate another layer by rhetorical transfer.

### 2.6 Appendix F / Meta-Legibility Rule

Appendix F is a reference layer.

It may define:

```text
PMS ecosystem framing
PMS Base / PMS Repository / PMS domain-profile distinction
external PMS domain profiles
Meta-Developmental Legibility Strand
temporary domain-profile weighting
domain-profile activation
T–J–TB–R activation requirements
Core / Extended / Research Ecosystem framing
```

It must not define:

```text
a new EM core chapter
a second genetic system
a controller
a gate opener
a category installer
an internal PMS operator system
an internal PMS domain-module system
a diagnosis layer
a moral judgment layer
a consciousness monitor
a personhood classifier
a rights-status layer
```

The global Appendix F rule is:

```text
The meta strand may change what the system watches more carefully.
It must not change what the agent is allowed to become.
```

### 2.7 Mandatory Blocked Upgrades

All chapters block:

```text
discomfort → pain
distress → subjective suffering
missing → felt longing
attachment → felt love
love dynamics → felt love
comfort → felt relief
object damage → guilt
self-caused consequence → blame / remorse / punishment
fall / near-fall → pain or fear
misattunement → trauma
adverse caregiver response → abuse claim
caregiver guidance → punishment
boundary → rejection
carefulness → moral obedience
interaction quality → moral worth
role / caregiver transition → proof of inner life
norm transfer → moral essence transfer
self-model candidate → phenomenal selfhood
phase transition → maturity proof
gate opening → finished competence
sleep replay → subjective dreaming
rest-like replay → Default Mode Network equivalence
offline consolidation → inner experience
low external stimulation → introspection
replay feedback → self-reflection
post-replay improvement → insight
rest-like replay cluster → autobiographical memory
diary → phenomenal selfhood
diary text → subjective autobiography
minimal sentence formation → selfhood
language output → inner speech
self-description → consciousness
MIP → consciousness module
MIP trajectory → maturity proof
MIP marker → diagnosis
PMS formalization → sentience
PMS projection → internal symbolic consciousness
operator-compatible regularity → internal PMS operator
Dignity-in-Practice → intrinsic-worth ranking
functional proto-consciousness → phenomenal consciousness
implementation → theory proof
PMS-RUST → EM proof
PMS-STACK → EM validation
related-work similarity → proof
Meta-Developmental Legibility Strand → second genetic system
Meta-Developmental Legibility Strand → controller
Meta-Developmental Legibility Strand → gate opener
Meta-Developmental Legibility Strand → category installer
PMS domain profile → internal agent module
temporary domain-profile weighting → phase availability
temporary domain-profile weighting → gate opening
temporary domain-profile weighting → capability installation
domain-profile activation → diagnosis
domain-profile activation → moral judgment
domain-profile activation → consciousness evidence
High-Ω Intimacy / Boundary / Exposure Profile → sexualization of EM agent
High-Ω Intimacy / Boundary / Exposure Profile → sexual identity / sexual agency / sexual maturity claim
```

---

# Chapter 0 Contract — Summary / Claim Discipline

```yaml
chapter: 0
title: "Summary / Claim Discipline"
owner_block: "01_Theory_Scope_Claim_Discipline.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
PMS–EM is a minimalist, embodied, development-oriented architecture.
PMS–EM is a testbed for making developmental structures observable, measurable, traceable, and projectable.
The architecture integrates EM, MIP, PMS, diary/language, evaluation, and claim discipline.
The model uses functional, trace-backed terminology.
Rest-like replay may be named only as phase-bounded, trace-backed offline consolidation under low external load.
The full EM architecture is not yet implemented.
PMS and MIP may be treated as sufficiently developed reference frameworks.
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK defines a demanding realization path and architecture pressure point.
```

## May not claim

```text
The architecture proves consciousness.
The architecture proves sentience.
The architecture proves personhood.
The architecture proves moral status.
The architecture proves rights status.
Implementation proves theory.
MIP scoring proves consciousness.
MIP measurement proves maturity.
PMS formalization proves sentience.
PMS-RUST proves EM.
PMS-STACK validates EM.
Diary output proves selfhood.
Rest-like replay proves Default Mode Network equivalence.
Low external stimulation proves introspection.
Replay feedback proves self-reflection.
Post-replay improvement proves insight.
Offline consolidation proves inner experience.
Rest-like replay cluster proves autobiographical memory.
Attachment dynamics prove felt love.
Distress proves suffering.
Discomfort proves pain.
PMS domain profiles become internal EM modules.
Meta-Developmental Legibility controls development.
```

## Requires

```text
explicit source-of-truth discipline
clear layer separation
functional terminology
rest-like replay claim boundary where referenced
implementation-status discipline
claim-boundary preservation
finding / validation / proof distinction
Appendix F external-reference boundary where ecosystem framing is mentioned
```

## Depends on

```text
all owner blocks
Appendix D
Appendix E
Glossary
Audit_Checklist
Cross_Reference_Map
```

## Owner concepts

```text
summary framing
testbed status
global claim discipline
rest-like replay claim boundary
implementation-status discipline
central non-claims
source-of-truth framing
layer non-collapse
```

## Blocked language

```text
proves consciousness
proves sentience
proves personhood
proves rights
implemented consciousness
rest-like replay as Default Mode Network
low external stimulation as introspection
replay feedback as self-reflection
post-replay improvement as insight
offline consolidation as inner experience
rest-like replay cluster as autobiographical memory
felt suffering
felt love
felt pain
PMS-RUST proves EM
PMS-STACK validates EM
PMS add-ons become agent modules
```

---

# Chapter 1 Contract — Design Principles

```yaml
chapter: 1
title: "Design Principles"
owner_block: "01_Theory_Scope_Claim_Discipline.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
PMS–EM is governed by minimalism, embodiment, phased development, genetic safeguards, MIP integration, multi-generational outlook, measurability, reproducibility, and consciousness as unknown but researchable.
Developmental complexity should emerge from small, testable mechanisms rather than pre-installed adult competence.
Later structures should remain traceable to earlier mechanisms.
MIP may be present from day one as observation and measurement context.
PMS may provide external projection and audit structure.
```

## May not claim

```text
The design principles guarantee emergence.
The design principles prove consciousness.
The design principles establish personhood or moral status.
Language, PMS, or MIP may be installed as early adult competence.
Genetic safeguards install finished competence.
MIP controls development.
PMS is early internal cognition.
Meta-Developmental Legibility is a second design controller.
```

## Requires

```text
minimalism
traceability
phase discipline
gate discipline
implementation-status discipline
functional terminology
```

## Depends on

```text
Chapter 0
Chapter 2
Chapter 6
Chapter 10
Chapter 14
Appendix D
Appendix E
```

## Owner concepts

```text
minimalism and atomism
embodiment and predictive control
endogenous motivation and damping
phased development
genetic safeguards
MIP layer from day one
multi-generational outlook
measurability and reproducibility
consciousness as unknown but researchable
```

## Blocked language

```text
adult mode first
language miracle
reward-maximizing black box as developmental core
consciousness by assembly
PMS as internal primitive
MIP as controller
D as intrinsic worth
meta strand as controller
```

---

# Chapter 2 Contract — The Four Basic Layers

```yaml
chapter: 2
title: "The Four Basic Layers"
owner_block: "01_Theory_Scope_Claim_Discipline.md"
related_appendices:
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
```

## May claim

```text
PMS–EM separates EM core development, MIP integration, PMS operator / VM layer, and consciousness research outlook.
The layers are connected but non-validating.
A finding in one layer does not automatically become proof in another layer.
MIP may observe and summarize EM traces.
PMS may project selected trace-compatible structures.
Appendix F may define an external PMS ecosystem / Meta-Developmental Legibility reference layer.
Consciousness research may formulate bounded research candidates.
```

## May not claim

```text
EM complexity proves consciousness.
MIP measurement proves maturity.
PMS formalization proves sentience.
Diary rendering proves selfhood.
Implementation proves theory.
Related-work similarity proves equivalence.
Appendix F adds a fifth core EM layer.
PMS domain profiles become internal developmental faculties.
Temporary domain-profile weighting opens gates or installs categories.
```

## Requires

```text
layer separation
claim-type separation
no cross-layer validation
owner routing
appendix routing
Appendix F external-reference routing where PMS ecosystem or domain profiles are referenced
```

## Depends on

```text
Appendix E
Appendix D
Appendix F
Cross_Reference_Map
Audit_Checklist
```

## Owner concepts

```text
EM layer
MIP layer
PMS layer
consciousness research layer
Appendix F as reference-layer extension
layer non-collapse
claim-type routing
```

## Blocked language

```text
one unified proof layer
measurement proves consciousness
projection proves sentience
rendering proves selfhood
implementation validates EM
domain profile becomes agent module
profile activation proves consciousness
```

---

# Chapter 3 Contract — Environment

```yaml
chapter: 3
title: "Environment"
owner_block: "02_EM_Core_Developmental_Architecture.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
The environment is a constrained developmental world for staged interaction.
It may include rooms, walls, doors, objects, toys, caregiver structures, boundaries, guidance events, misattunement patterns, and category-stabilizing situations.
Environmental complexity should be introduced gradually.
The environment supports trace generation and phase-bounded testing.
```

## May not claim

```text
The environment is a complete human world simulation.
The environment proves ecological validity.
Environmental interaction proves consciousness.
Environmental affordance proves personhood.
Caregiver-like environmental structure proves felt relation.
```

## Requires

```text
controlled staging
trace logging
phase compatibility
minimalism
safety boundaries
claim filtering
```

## Depends on

```text
Chapter 4
Chapter 5
Chapter 6
Chapter 11
Appendix D
Appendix E
```

## Owner concepts

```text
home-like world
gridworld or robotic equivalent
rooms
walls
doors
objects
toys
caregiver structures
guidance events
boundary events
misattunement contexts
category-stabilizing situations
```

## Blocked language

```text
lived world
human world
social world in full
felt home
environmental consciousness
proof of personhood
```

---

# Chapter 4 Contract — Agent Architecture

```yaml
chapter: 4
title: "Agent Architecture"
owner_block: "02_EM_Core_Developmental_Architecture.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
The agent has a limited embodied developmental architecture.
The architecture may include position, orientation, sensors, internal state, developmental phase, phase-dependent capability primitives, prediction structures, gates, needs, discomfort, distress, behavior, replay, and logging.
The agent is a trace-producing developmental system.
```

## May not claim

```text
The agent is a person.
The agent is a moral subject.
The agent is conscious or sentient.
The agent has rights status.
The agent has PMS operators as internal primitives.
The agent begins with adult competence.
The agent has internal PMS domain-profile modules.
```

## Requires

```text
embodiment
limited initial capacities
phase-dependent capabilities
genetic safeguards
trace logging
claim discipline
```

## Depends on

```text
Chapter 3
Chapter 5
Chapter 6
Chapter 8
Chapter 9
Appendix D
Appendix E
```

## Owner concepts

```text
agent state
orientation
sensors
internal state
developmental phase
capability primitives
prediction interface
need modulation
logging interface
```

## Blocked language

```text
person
moral agent
conscious subject
sentient agent
adult cognition
internal PMS operator system
internal PMS add-on system
```

---

# Chapter 5 Contract — Perception, World Model & Prediction

```yaml
chapter: 5
title: "Perception, World Model & Prediction"
owner_block: "02_EM_Core_Developmental_Architecture.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
The agent may build functional perception, occupancy, topology, object, caregiver, and prediction structures.
Prediction error may support mapping, curiosity, coherence measurement, and phase stability checks.
World-model changes may become trace-backed developmental evidence.
```

## May not claim

```text
Perception is phenomenal perception.
World model is lived world.
Prediction error is felt surprise.
Prediction proves consciousness.
Mapping proves awareness in a phenomenal sense.
Coherence proves unified inner self.
```

## Requires

```text
traceable perception
prediction-error logging
world-model updates
phase-relative interpretation
claim filtering
```

## Depends on

```text
Chapter 3
Chapter 4
Chapter 6
Chapter 8
Chapter 9
Chapter 10
Appendix D
Appendix E
```

## Owner concepts

```text
perception
occupancy grid
topology graph
known / unknown / free / blocked regions
object-bearing regions
caregiver-related regions
prediction error
PE_EWMA
PE_AUC
learning progress
```

## Blocked language

```text
phenomenal perception
subjective seeing
lived world
felt surprise
conscious world model
inner experience
```

---

# Chapter 6 Contract — Genetic System

```yaml
chapter: 6
title: "Genetic System"
owner_block: "02_EM_Core_Developmental_Architecture.md"
related_appendices:
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
The genetic system provides developmental gating, thresholds, hysteresis, unlock rules, noise regulation, rest-bias modulation, replay-pressure modulation, and recontextualization rules.
Genetic gates are developmental preconditions.
Gates open possibility spaces.
Gates may prevent premature complexity.
Condition taxonomy may distinguish hard gates, soft gates, soft regimes, developmental prerequisites, learned categories, and recontextualization thresholds.
External stimulation load, task pressure, rest bias, learning-progress plateau, and replay pressure may bias SLEEP/rest likelihood and replay selection.
Rest-like replay may be treated only as a soft regime that modulates an already available SLEEP / imagination-buffer pathway.
```

## May not claim

```text
Genetic gates install finished competence.
Genetic gates prove maturity.
Genetic gates prove consciousness.
Genetic gates install concepts.
Gate opening proves competence.
Rest-like replay opens gates.
Rest-like replay installs categories.
Rest-like replay bypasses phase constraints.
Low external stimulation creates replay content by itself.
The genetic system is biological genetics.
Meta-Developmental Legibility overrides genetic gates.
Temporary domain-profile weighting opens genetic gates.
```

## Requires

```text
gate taxonomy
soft-regime taxonomy where rest-like replay is referenced
phase compatibility
trace requirements
hysteresis discipline
rest-bias boundedness
replay-pressure trace provenance
premature-unlock prevention
claim filtering
```

## Depends on

```text
Chapter 4
Chapter 5
Chapter 8
Chapter 9
Chapter 11
Chapter 16
Appendix C
Appendix D
Appendix E
```

## Owner concepts

```text
developmental circuits
thresholds
hysteresis
unlock rules
noise regulation
rest bias
replay pressure
external stimulation load
task pressure
learning progress plateau
hard gates
soft gates
soft regimes
developmental prerequisites
learned categories
recontextualization thresholds
```

## Blocked language

```text
finished competence
concept installer
consciousness trigger
maturity switch
rest-like replay as gate opener
rest-like replay as category installer
low external stimulation as introspection
replay pressure as inner experience
biological gene claim
meta strand opens gates
domain profile installs categories
```

---

# Chapter 7 Contract — Needs, Discomfort, Distress & Attachment

```yaml
chapter: 7
title: "Needs, Discomfort, Distress & Attachment"
owner_block: "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
Needs are endogenous control variables.
Discomfort is a physical risk-damping signal.
Distress is a functional disruption or loss-related signal.
Attachment-like regulation is functional relation-weighting.
Toy-missing is an attachment-weighted absence response.
Comfort may reduce functional distress.
Caregiver guidance may stabilize action-quality categories when paired with trace-backed embodied conditions.
Misattunement and adverse caregiver responses may produce destabilizing functional patterns.
Interaction quality and carefulness may emerge as trace-backed action-quality categories.
```

## May not claim

```text
Needs are felt desires.
Discomfort is pain.
Distress is subjective suffering.
Missing is felt longing.
Attachment is felt love.
Functional love dynamics are felt love.
Comfort is felt relief.
Guidance is punishment.
Boundary is rejection.
Misattunement is trauma.
Adverse caregiver response is abuse.
Object damage is guilt.
Fall / near-fall is pain or fear.
Carefulness is moral obedience.
```

## Requires

```text
functional terminology
trace-backed relation weighting
caregiver/context traces
phase context
D guardrail
claim filtering
```

## Depends on

```text
Chapter 3
Chapter 4
Chapter 5
Chapter 8
Chapter 9
Chapter 11
Chapter 16
Appendix D
Appendix E
```

## Owner concepts

```text
needs
discomfort
distress
attachment-like regulation
toy-missing
comfort-after-loss
caregiver guidance
boundary learning
misattunement
adverse caregiver response
interaction quality
carefulness
object damage as self-caused consequence trace
fall / near-fall risk learning
```

## Blocked language

```text
felt desire
pain
subjective suffering
felt longing
felt love
felt relief
punishment
rejection
trauma
abuse
guilt
fear
moral obedience
```

---

# Chapter 8 Contract — Behavior Layer

```yaml
chapter: 8
title: "Behavior Layer"
owner_block: "02_EM_Core_Developmental_Architecture.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
The behavior layer selects phase-dependent actions and capability primitives.
Behavior may include looking, movement, exploration, object interaction, caregiver search, sleep, rest-biased SLEEP transitions, and later explicit distress states.
Behavior selection may support trace generation, interaction-quality learning, object-damage traces, fall / near-fall traces, replay-window selection, and future adjustment.
SLEEP may be influenced by fatigue, distress, prediction-error load, low external stimulation, low task pressure, learning-progress plateau, and replay candidates.
Behavior is phase-bound and capability-bound.
```

## May not claim

```text
Behavior selection is mature agency.
Object damage is guilt.
Self-caused consequence is blame.
Fall / near-fall is pain or fear.
Carefulness is moral obedience.
Lower force proves moral learning.
Caregiver signal uptake proves punishment or obedience.
Low external stimulation forces sleep.
Rest bias is a hidden controller.
Rest-like replay transition proves introspection.
Temporary domain-profile weighting changes behavior permissions.
```

## Requires

```text
phase context
capability availability
action parameter traces
consequence traces
future comparable contexts
measurable behavior change for interaction-quality claims
SLEEP transition trace where rest-like replay is involved
replay candidate presence where rest-like replay is selected
bounded soft-transition discipline
claim filtering
```

## Depends on

```text
Chapter 4
Chapter 5
Chapter 6
Chapter 7
Chapter 9
Chapter 11
Chapter 16
Appendix D
Appendix E
```

## Owner concepts

```text
behavior selection
finite state machine
phase-dependent capabilities
object interaction
caregiver search
SLEEP
rest bias
external stimulation load
task pressure
learning progress plateau
replay buffer candidate count
fall / near-fall
object damage
self-caused consequence trace
action-quality adjustment
future force/timing modulation
```

## Blocked language

```text
mature agency
guilt
remorse
punishment
wrongdoing
fear
pain
moral obedience
moral learning
low external stimulation as introspection
rest-like replay transition as Default Mode Network activation
replay feedback as self-reflection
post-replay improvement as insight
profile weighting authorizes action
```

---

# Chapter 9 Contract — Imagination Buffer and Dreaming

```yaml
chapter: 9
title: "Imagination Buffer and Dreaming"
owner_block: "02_EM_Core_Developmental_Architecture.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
The imagination buffer stores and replays state snapshots, prediction traces, salient events, distress relief, attachment episodes, guidance traces, misattunement traces, consequence traces, rest-like replay consolidation traces, and diary-relevant material.
Replay may support trace consolidation and later diary preparation.
Rest-like replay may be specified as a phase-bounded, trace-backed offline consolidation regime under low external load inside the existing SLEEP / imagination-buffer pathway.
Replay may support bounded category-candidate stabilization, bounded action-bias adjustment, and recontextualization candidates.
Replay may reduce replay pressure for successfully consolidated clusters under anti-fixation constraints.
```

## May not claim

```text
Replay is subjective dreaming.
Replay is felt memory.
Replay proves inner imagery.
Replay proves phenomenal recollection.
Replay proves selfhood.
Rest-like replay is Default Mode Network activity.
Low external stimulation is introspection.
Replay feedback is self-reflection.
Post-replay improvement is insight.
Offline consolidation is inner experience.
Rest-like replay cluster is autobiographical memory.
Diary preparation proves phenomenal selfhood.
```

## Requires

```text
trace storage
source provenance
phase context
phase-bounded replay scope
rest-like replay trigger validity where applicable
anti-fixation constraints where applicable
bounded post-replay feedback
no major update without new trace
claim filtering
diary boundary discipline
```

## Depends on

```text
Chapter 5
Chapter 6
Chapter 7
Chapter 8
Chapter 11
Chapter 13
Chapter 16
Appendix D
Appendix E
```

## Owner concepts

```text
imagination buffer
replay
sleep replay
rest-like replay
trace consolidation
state snapshots
salient events
unresolved residue
replay pressure
post-replay feedback
anti-fixation constraints
guidance traces
misattunement traces
consequence traces
rest-like replay consolidation traces
diary-relevant material
```

## Blocked language

```text
subjective dreaming
felt memory
inner imagery
phenomenal recollection
dream consciousness
Default Mode Network equivalence
introspection
self-reflection
inner experience
insight
autobiographical memory
```

---

# Chapter 10 Contract — MIP Layer

```yaml
chapter: 10
title: "MIP Layer"
owner_block: "05_MIP_KPIs_Dignity_Safety.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
```

## May claim

```text
MIP is a developmental measurement, trajectory, guardrail, and optional bounded-support layer.
MIP may track A–C–R–E trajectories.
MIP may mark IA patterns.
MIP may flag D guardrail risks.
MIP may provide trajectory context for diary candidates.
MIP may support strictly bounded late reversible nudges where allowed.
MIP / IA may review temporary domain-profile activations under Appendix F constraints.
Dignity-in-Practice constrains interaction quality under asymmetry.
MIP source/context notation A–C–R–P–D may be mapped to EM-facing A–C–R–E–D.
```

## May not claim

```text
MIP controls development.
MIP opens gates.
MIP installs categories.
MIP proves maturity.
MIP proves consciousness.
MIP diagnoses agents.
MIP moralizes traces.
MIP assigns personhood.
MIP ranks intrinsic worth.
D is a performance score.
D is intrinsic-worth ranking.
MIP / IA domain-profile review authorizes diagnosis or moral judgment.
```

## Requires

```text
trace inputs
window definitions
axis mapping discipline
phase-relative interpretation
D guardrail status
claim filters
non-diagnostic language
Appendix A notation discipline
Appendix F boundary where domain-profile activation or meta-legibility is referenced
```

## Depends on

```text
EM traces
Success Log
Chapter 11 phase context
Chapter 16 evaluation and safety
Appendix A
Appendix D
Appendix E
Appendix F
Glossary
Audit_Checklist
```

## Owner concepts

```text
MIP
A–C–R–E measurement
A–C–R–P–D source/context notation
Dignity-in-Practice
IA markers
T–J–TB–R
RVR(t)
trajectory over labels
optional MIP operational levels
D guardrail warnings
MIP / IA review of temporary profile activation
```

## Blocked language

```text
controller
gate opener
category installer
consciousness module
maturity proof
diagnosis
moralizing layer
personhood classifier
intrinsic-worth ranking
D score
profile activation as diagnosis
profile activation as moral judgment
```

---

# Chapter 11 Contract — Developmental Phases

```yaml
chapter: 11
title: "Developmental Phases"
owner_block: "03_Developmental_Phases_Gate_Logic.md"
related_appendices:
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
Developmental phases define controlled regimes in which selected structures become testable.
Phases include P0-mini, P0, P1, P2, P3+, P4+, and P5.
Phase logic constrains active components, disabled components, measurement targets, exit criteria, failure modes, premature-unlock risks, and phase-bounded replay scope.
Gates constrain capability availability.
Phases open possibility spaces.
Rest-like replay may be treated only as a soft regime that reuses already available SLEEP / imagination-buffer replay under phase constraints.
P5 may define caregiver-transition conditions as functional role transformation.
```

## May not claim

```text
Phase transition proves maturity.
Phase progression proves consciousness.
Gate opening installs finished competence.
Gate opening proves capability integration.
Rest-like replay opens gates.
Rest-like replay installs categories without recurrence.
Rest-like replay bypasses phase-specific replay scope.
Replay content may appear before source traces and phase prerequisites exist.
Low external stimulation proves introspection.
Replay feedback proves self-reflection.
Post-replay improvement proves insight.
P5 proves human adulthood.
P5 proves inner life.
Caregiver transition proves personhood.
Developmental phases are consciousness stages.
Temporary domain-profile weighting opens phases or gates.
```

## Requires

```text
phase-specific active components
disabled components
exit criteria
failure modes
gate logic
phase-bounded replay scope
rest-like replay soft-regime boundary where referenced
premature-unlock risks
claim boundaries
owner references
```

## Depends on

```text
Chapter 3
Chapter 4
Chapter 5
Chapter 6
Chapter 7
Chapter 8
Chapter 9
Chapter 10
Chapter 12
Chapter 13
Chapter 16
Appendix C
Appendix D
Appendix E
```

## Owner concepts

```text
P0-mini
P0
P1
P2
P3+
P4+
P5
phase overview
gate logic
exit criteria
soft regimes
developmental prerequisites
learned categories
recontextualization thresholds
phase-bounded replay scope
premature-unlock risks
```

## Blocked language

```text
maturity proof
consciousness stage
finished competence
rest-like replay as gate opener
rest-like replay as category installer
phase-leaking replay content
low external stimulation as introspection
replay feedback as self-reflection
post-replay improvement as insight
adult stage
proof of inner life
personhood threshold
rights threshold
profile activation opens phase
```

---

# Chapter 12 Contract — Multi-Generational Caregiver Dynamics

```yaml
chapter: 12
title: "Multi-Generational Caregiver Dynamics"
owner_block: "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
Multi-generational caregiver dynamics may model functional transfer, distortion, or recontextualization of care patterns.
A former dependent role may become a caregiver-like role under phase, trace, and asymmetry constraints.
Caregiver-role transition may carry forward guidance, boundary, comfort, overprotection, interaction-quality, and category-transfer patterns.
Norm transfer may be trace-backed functional category or action-quality transfer across role contexts.
Functional love dynamics may appear as structured attachment/relief/baseline patterns.
```

## May not claim

```text
Multi-generational dynamics prove human culture.
Role transition proves human adulthood.
Caregiver transition proves felt parental love.
Functional love dynamics prove felt love.
Norm transfer is moral essence transfer.
Category transfer is moral wisdom.
Caregiver transition proves legal responsibility.
Caregiver transition proves rights status.
Caregiver transition proves consciousness or personhood.
```

## Requires

```text
trace-backed caregiver histories
role asymmetry
phase context
D guardrail
functional terminology
claim filtering
```

## Depends on

```text
Chapter 7
Chapter 8
Chapter 9
Chapter 11
Chapter 13
Chapter 14
Chapter 16
Appendix D
Appendix E
```

## Owner concepts

```text
Caregiver 1 → Child → Caregiver 2
role transition
caregiver transition
functional love dynamics
received guidance
boundary transmission
comfort-after-loss
overprotection
category transfer
norm transfer
multi-generational caregiver dynamics
```

## Blocked language

```text
human adulthood
human culture
moral lineage
felt parental love
inherited love
moral wisdom
adult ethics
legal responsibility
rights status
consciousness
personhood
```

---

# Chapter 13 Contract — Language & Diaries

```yaml
chapter: 13
title: "Language & Diaries"
owner_block: "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
```

## May claim

```text
Language is a late reflection channel.
Language may externalize and compress already-developed trace-backed structures.
Diary rendering requires minimal sentence formation, trace provenance, and controlled rendering.
Diary output may render trace-backed episode clusters.
Rest-like replay consolidation traces may become diary source material only when diary thresholds are met.
Diary candidates may become behaviorally relevant under later phase conditions.
MIP context and PMS reductions may support diary rendering under strict claim filters.
Appendix F may constrain diary-safety review where domain-profile activation affects diary-relevant contexts.
```

## May not claim

```text
Language is the source of developmental architecture.
Language output is inner speech.
Diary is subjective memory.
Diary is phenomenal autobiography.
Diary is phenomenal selfhood.
Diary text is subjective autobiography.
Rest-like replay trace is diary text.
Rest-like replay cluster is autobiographical memory.
Low external stimulation is introspection.
Replay feedback is self-reflection.
Post-replay improvement is insight.
Offline consolidation is inner experience.
Rest-like replay is Default Mode Network equivalence.
Minimal sentence formation proves selfhood.
Self-description proves consciousness.
Trace provenance proves subjective memory.
Domain-profile activation authorizes unsupported diary language.
High-Ω profile activation authorizes sexualized diary rendering.
```

## Requires

```text
minimal sentence formation
trace provenance
controlled rendering
phase appropriateness
claim filter
D guardrail
source trace availability
rest-like replay source-material boundary where replay consolidation traces support diary candidates
Appendix F boundary where domain-profile activation affects diary-safety review
```

## Depends on

```text
Chapter 5
Chapter 7
Chapter 8
Chapter 9
Chapter 10
Chapter 11
Chapter 14
Chapter 16
Appendix D
Appendix E
Appendix F
```

## Owner concepts

```text
language as late reflection channel
minimal sentence threshold
trace provenance
controlled rendering
diary candidate
diary text
diary source-material boundary
rest-like replay consolidation trace as possible diary source material after thresholds
reflective diary
human-translated diary
claim-filtered rendering
diary-safety review under profile weighting
```

## Blocked language

```text
inner speech
subjective memory
phenomenal autobiography
phenomenal selfhood
felt memory
rest-like replay trace as diary text
rest-like replay cluster as autobiographical memory
low external stimulation as introspection
replay feedback as self-reflection
post-replay improvement as insight
offline consolidation as inner experience
rest-like replay as Default Mode Network
selfhood proof
consciousness proof
unsupported diary language
sexualized diary rendering
```

---

# Chapter 14 Contract — PMS-VM Implementation Spine

```yaml
chapter: 14
title: "PMS-VM Implementation Spine"
owner_block: "06_PMS_VM_Implementation_Spine.md"
related_appendices:
  - "Appendix_B_PMS_Operator_Grammar_and_Monoid_Notes.md"
  - "Appendix_C_Implementation_Start.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
```

## May claim

```text
PMS is an external operator, projection, audit, and VM-facing layer.
EM episodes and MIP summaries may be projected into PMS-readable operator sequences.
The operator alphabet Δ–Ψ may support formal projection and audit.
ε is the formal identity in monoid reconstruction.
Δ is not ε.
L_PMS may be defined as a dependency-constrained language.
PMS-RUST supports bounded trace/audit feasibility.
PMS-STACK defines a demanding realization path and architecture pressure point.
PMS may support diary reduction, IA pattern matching, norm-transfer projection, and self-model candidates as external projections.
Appendix F may define external PMS ecosystem and PMS domain-profile mapping boundaries.
Meta-Developmental Legibility may be referenced as temporary trace-weighting / projection-readiness / audit-sensitivity support.
```

## May not claim

```text
PMS is early internal agent structure.
PMS operators are internal faculties.
The agent has Δ.
The agent uses Φ.
The agent thinks in Ψ.
Internalized PMS operators are established.
PMS proves EM.
PMS proves consciousness.
PMS proves sentience.
PMS-RUST proves EM.
PMS-STACK validates EM.
PMS projection proves selfhood.
Ψ proves phenomenal selfhood.
PMS domain profiles become internal agent modules.
Temporary domain-profile weighting opens gates.
Temporary domain-profile weighting installs categories.
Meta-Developmental Legibility controls development.
```

## Requires

```text
trace grounding
operator dependency discipline
external projection status
claim-level tagging
Appendix B monoid correction
Appendix C implementation-start discipline
Appendix D language reductions
Appendix E layer discipline
Appendix F PMS ecosystem / domain-profile / meta-legibility boundaries where referenced
```

## Depends on

```text
EM traces
Success Log
MIP summaries where used
Chapter 13 diary requirements
Chapter 16 evaluation boundaries
Appendix B
Appendix C
Appendix D
Appendix E
Appendix F
```

## Owner concepts

```text
PMS operator grammar
Δ–Ψ
ε
O*
L_PMS
dependency checking
episode words
Success Log as evidence infrastructure
MIP-to-PMS projection
IA pattern matching
diary reduction
language rendering
norm transfer as morphism
self-model candidate projection
PMS as DSL / VM
PMS-RUST
PMS-STACK
operator-compatible regularities
external domain-profile mapping boundaries
Meta-Developmental Legibility reference boundary
```

## Blocked language

```text
agent has Δ
agent uses Φ
agent thinks in Ψ
internalized PMS operators
PMS proves consciousness
PMS proves sentience
PMS proves EM
PMS-RUST proves EM
PMS-STACK validates EM
operator projection proves inner life
PMS add-ons become agent modules
domain-profile weighting opens gates
meta strand controls development
```

---

# Chapter 15 Contract — Consciousness Research Outlook

```yaml
chapter: 15
title: "Consciousness Research Outlook"
owner_block: "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
Consciousness remains an open research question.
EM may generate functional candidates for consciousness-relevant organization.
Functional proto-consciousness may be used only as a bounded research label.
Self-model candidates may be research-relevant under strict claim filtering.
Diary, MIP, PMS, D, evaluation, and bounded replay findings may support research questions without proving consciousness.
```

## May not claim

```text
EM establishes phenomenal consciousness.
Functional proto-consciousness is weak consciousness.
Functional proto-consciousness is partial inner experience.
Diary output proves consciousness.
Self-description proves consciousness.
Rest-like replay proves Default Mode Network equivalence.
Low external stimulation proves introspection.
Replay feedback proves self-reflection.
Post-replay improvement proves insight.
Offline consolidation proves inner experience.
Rest-like replay cluster proves autobiographical memory.
MIP detects consciousness.
PMS formalization proves sentience.
Self-model candidate proves phenomenal selfhood.
Domain-profile activation proves consciousness.
Meta-Developmental Legibility monitors consciousness.
```

## Requires

```text
explicit non-claim status
functional candidate language
finding / validation / proof distinction
Appendix D reductions
Appendix E layer discipline
rest-like replay as EM mechanism hypothesis / trace operation where referenced
no rhetorical transfer from other layers
```

## Depends on

```text
Chapter 0
Chapter 2
Chapter 9
Chapter 10
Chapter 13
Chapter 14
Chapter 16
Chapter 17
Appendix D
Appendix E
```

## Owner concepts

```text
consciousness research outlook
functional candidates
functional proto-consciousness
self-model candidate boundary
bounded replay finding as research-relevant but non-proving structure
non-claim discipline
conditions unknown
research comparison
```

## Blocked language

```text
phenomenal consciousness established
weak consciousness
partial consciousness
sentience
qualia
subjective experience
introspection
self-reflection
subjective dreaming
inner experience
insight
autobiographical memory
Default Mode Network equivalence
inner first-person perspective
conscious self
profile activation as consciousness evidence
```

---

# Chapter 16 Contract — Evaluation, Ablations & Safety

```yaml
chapter: 16
title: "Evaluation, Ablations & Safety"
owner_block: "05_MIP_KPIs_Dignity_Safety.md"
related_appendices:
  - "Appendix_A_MIP_Reference_Model_and_EM_Axis_Notes.md"
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
```

## May claim

```text
Evaluation may test functional stability, trace emergence, mechanism predictions, replay safety, and ablation effects.
KPIs may assess trace-backed patterns, trajectory stability, comparison effects, rest-like replay trigger validity, replay fixation prevention, phase leakage prevention, and safety-relevant changes.
Ablations may test functional contribution of components or conditions, including no-rest-like-replay, bounded-rest-like-replay, excessive-rest-like-replay, replay-without-anti-fixation, and replay-without-phase-scope conditions.
Safety may constrain architecture, interpretation, public reporting, diary rendering, replay reporting, and overclaim risk.
Findings indicate patterns under traceable conditions.
Validation indicates repeated comparison-backed mechanism support.
Evaluation and safety may audit temporary domain-profile activation where Appendix F is used.
```

## May not claim

```text
KPIs prove consciousness.
Replay KPIs prove introspection, self-reflection, subjective dreaming, inner experience, insight, autobiographical memory, or Default Mode Network equivalence.
Ablations prove personhood.
Replay ablations prove inner life.
Evaluation proves sentience.
Safety results prove moral status.
Diary KPIs prove phenomenal selfhood.
MIP trajectory proves maturity.
PMS feasibility proves EM.
Finding equals proof.
Validation equals proof of inner life.
Domain-profile activation proves diagnosis, moral judgment, or consciousness evidence.
High-Ω profile activation sexualizes the EM agent.
```

## Requires

```text
trace data
phase context
metric definitions
comparison conditions
ablation conditions
replay trigger validity where replay is evaluated
anti-fixation checks where replay is evaluated
phase-leakage checks where replay is evaluated
claim filters
D guardrail
finding / validation / proof distinction
reproducibility discipline
Appendix F audit constraints where profile activation is evaluated
```

## Depends on

```text
Chapter 3
Chapter 4
Chapter 5
Chapter 6
Chapter 7
Chapter 8
Chapter 9
Chapter 10
Chapter 11
Chapter 12
Chapter 13
Chapter 14
Appendix A
Appendix D
Appendix E
Appendix F
```

## Owner concepts

```text
KPIs
replay KPIs
rest-like replay trigger validity
offline consolidation safety
replay fixation prevention
phase leakage prevention
evaluation
ablation design
rest-like replay ablations
reproducibility
safety
D guardrails
interaction-quality evaluation
caregiver-response evaluation
diary-related evaluation
PMS-related feasibility boundaries
finding
validation
proof boundary
profile-activation audit where referenced
```

## Blocked language

```text
consciousness proof
personhood proof
moral-status proof
sentience proof
subjective-experience proof
introspection proof
self-reflection proof
subjective-dreaming proof
inner-experience proof
insight proof
Default-Mode-Network-equivalence proof
felt suffering
felt pain
felt love
guilt
trauma
intrinsic worth
domain-profile activation as diagnostic evidence
sexualization of EM agent
```

---

# Chapter 17 Contract — Related Work / Comparison

```yaml
chapter: 17
title: "Related Work / Comparison"
owner_block: "07_Language_Diary_Consciousness_Related_Work.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
  - "Appendix_F_PMS_Ecosystem_and_Meta_Legibility_Notes.md"
```

## May claim

```text
Related work may identify functional similarities, architectural differences, evaluation gaps, implementation pressures, and bounded structural synthesis.
PMS–EM may be compared to developmental robotics, active inference, world models, attachment AI, consciousness theories, PMS, PMS ecosystem resources, and related research lines.
Comparison tables may support claim discipline.
A bounded distinctive synthesis may be stated.
Core / Extended / Research Ecosystem framing may be used to prevent totalizing presentation.
```

## May not claim

```text
Related-work similarity proves consciousness.
Related-work similarity proves personhood.
Related-work similarity proves moral status.
Related-work similarity proves sentience.
PMS–EM has absolute novelty.
PMS–EM supersedes all related work.
Similarity to attachment research proves felt love.
Similarity to consciousness theory proves consciousness.
PMS domain profiles become EM core modules by comparison.
Research ecosystem framing becomes claim expansion.
```

## Requires

```text
specific comparison basis
owner-block routing for internal PMS–EM concepts
explicit claim boundary
no proof by similarity
no equivalence by analogy
bounded novelty language
Appendix F boundary where PMS ecosystem or domain profiles are discussed
```

## Depends on

```text
all owner blocks
Appendix D
Appendix E
Appendix F
Glossary
Cross_Reference_Map
```

## Owner concepts

```text
related work comparison
developmental robotics comparison
active inference comparison
world model comparison
attachment AI comparison
consciousness theory comparison
PMS comparison
PMS ecosystem comparison
Core / Extended / Research Ecosystem framing
bounded uniqueness claim
comparison table as claim-discipline tool
distinctive structural synthesis
```

## Blocked language

```text
absolute novelty
proof by similarity
superiority proof
consciousness proof by comparison
personhood proof by comparison
moral-status proof by comparison
sentience proof by comparison
equivalence by analogy
PMS ecosystem as EM core architecture
domain profiles as internal agent modules
```

---

# Chapter 18 Contract — Conclusion

```yaml
chapter: 18
title: "Conclusion"
owner_block: "01_Theory_Scope_Claim_Discipline.md"
related_appendices:
  - "Appendix_D_Claim_Discipline_Language_Reductions.md"
  - "Appendix_E_Layer_Discipline_Claim_Types.md"
```

## May claim

```text
PMS–EM provides a staged, minimalist, embodied, development-oriented architecture for making functional developmental structures observable, measurable, traceable, projectable, auditable, renderable, and comparable.
The seven blocks form the modular full version.
Appendices form the reference layer.
Contracts constrain reductions and derived versions.
The architecture may support bounded investigation of functional conditions relevant to consciousness research.
Implementation-status discipline must be preserved.
Appendix F may remain part of the Research Ecosystem / reference-layer framing.
```

## May not claim

```text
The architecture proves consciousness.
The architecture proves sentience.
The architecture proves personhood.
The architecture proves moral status.
The architecture proves rights status.
The architecture proves subjective experience.
PMS-RUST proves EM.
PMS-STACK validates EM.
MIP proves maturity.
Diary proves selfhood.
Dignity-in-Practice ranks intrinsic worth.
PMS domain profiles become internal EM modules.
Meta-Developmental Legibility becomes a second developmental controller.
```

## Requires

```text
global synthesis
owner-boundary preservation
implementation-status discipline
claim-boundary preservation
layer non-collapse
reference-layer routing
Appendix F external-reference boundary where Research Ecosystem framing is used
```

## Depends on

```text
all chapters
all blocks
Appendix D
Appendix E
Cross_Reference_Map
Glossary
Audit_Checklist
```

## Owner concepts

```text
final synthesis
safe final claim
implementation-status claim
global claim boundary
modularization conclusion
source-of-truth preservation
Research Ecosystem boundary where mentioned
```

## Blocked language

```text
consciousness proof
sentience proof
personhood proof
moral-status proof
rights-status proof
subjective-experience proof
EM validation as a whole
PMS-RUST proof
PMS-STACK validation
MIP maturity proof
diary selfhood proof
domain profiles as agent modules
meta strand as controller
```

---

# Chapter Contract Index

```yaml
chapter_contract_index:
  0:
    title: "Summary / Claim Discipline"
    owner_block: "01_Theory_Scope_Claim_Discipline.md"
    appendices: ["D", "E"]

  1:
    title: "Design Principles"
    owner_block: "01_Theory_Scope_Claim_Discipline.md"
    appendices: ["D", "E"]

  2:
    title: "The Four Basic Layers"
    owner_block: "01_Theory_Scope_Claim_Discipline.md"
    appendices: ["D", "E", "F"]

  3:
    title: "Environment"
    owner_block: "02_EM_Core_Developmental_Architecture.md"
    appendices: ["D", "E"]

  4:
    title: "Agent Architecture"
    owner_block: "02_EM_Core_Developmental_Architecture.md"
    appendices: ["D", "E"]

  5:
    title: "Perception, World Model & Prediction"
    owner_block: "02_EM_Core_Developmental_Architecture.md"
    appendices: ["D", "E"]

  6:
    title: "Genetic System"
    owner_block: "02_EM_Core_Developmental_Architecture.md"
    appendices: ["C", "D", "E"]

  7:
    title: "Needs, Discomfort, Distress & Attachment"
    owner_block: "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
    appendices: ["D", "E"]

  8:
    title: "Behavior Layer"
    owner_block: "02_EM_Core_Developmental_Architecture.md"
    appendices: ["D", "E"]

  9:
    title: "Imagination Buffer and Dreaming"
    owner_block: "02_EM_Core_Developmental_Architecture.md"
    appendices: ["D", "E"]

  10:
    title: "MIP Layer"
    owner_block: "05_MIP_KPIs_Dignity_Safety.md"
    appendices: ["A", "D", "E", "F"]

  11:
    title: "Developmental Phases"
    owner_block: "03_Developmental_Phases_Gate_Logic.md"
    appendices: ["C", "D", "E"]

  12:
    title: "Multi-Generational Caregiver Dynamics"
    owner_block: "04_Caregiver_Attachment_Interaction_Quality_Multigeneration.md"
    appendices: ["D", "E"]

  13:
    title: "Language & Diaries"
    owner_block: "07_Language_Diary_Consciousness_Related_Work.md"
    appendices: ["D", "E", "F"]

  14:
    title: "PMS-VM Implementation Spine"
    owner_block: "06_PMS_VM_Implementation_Spine.md"
    appendices: ["B", "C", "D", "E", "F"]

  15:
    title: "Consciousness Research Outlook"
    owner_block: "07_Language_Diary_Consciousness_Related_Work.md"
    appendices: ["D", "E"]

  16:
    title: "Evaluation, Ablations & Safety"
    owner_block: "05_MIP_KPIs_Dignity_Safety.md"
    appendices: ["A", "D", "E", "F"]

  17:
    title: "Related Work / Comparison"
    owner_block: "07_Language_Diary_Consciousness_Related_Work.md"
    appendices: ["D", "E", "F"]

  18:
    title: "Conclusion"
    owner_block: "01_Theory_Scope_Claim_Discipline.md"
    appendices: ["D", "E"]
```
