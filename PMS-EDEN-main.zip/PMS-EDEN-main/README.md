# PMS–EDEN

## Purpose

**PMS–EDEN** is a paper-form PMS lens for Adult Reciprocity and its loss through false-coordinated real asymmetry.

It reads how real Ω can be misframed as reciprocity, equality, comparison, recognition, or harmless play, thereby shifting Ψ-load and stabilizing responsibility displacement.

Compact boundary:

```text
Adult Reciprocity ≠ symmetry fiction
Reciprocity Loss ≠ person verdict
Eden scene ≠ theology
Ω readability ≠ blame automation
```

---

## Ecosystem Position

PMS–EDEN belongs to the PMS paper-form lens family.

| Neighboring layer | Relation |
| --- | --- |
| PMS Base | Supplies the Δ–Ψ operator grammar. |
| PMS-CONFLICT | Neighboring lens for terminal incompatibility under cost, time, and binding. |
| PMS-SEX | Neighboring high-asymmetry application profile with body, boundary, and sexual cost topology. |
| MIP | Possible downstream docking only when maturity/person-near language appears; not internal to EDEN. |
| PMS-STRATA | Later discipline for reading Eden's composition/projection moves without retro-validating them. |
| PMS-DISCIPLINE | Required for application, public transmission, person-near use, or case-record production. |

---

## Repository Form

This is a **paper-form PMS lens repository**.

| Material | Function |
| --- | --- |
| Main paper | Adult Reciprocity, real Ω, EDEN-MAP, boundary conditions, and case logic. |
| `model/PMS-EDEN.yaml` | Machine-readable EDEN overlay/profile. |
| `model/Model Specification.*` | Human-readable model specification. |
| `examples/` | Case YAML files and optional human-readable renderings. |

---

## Core Thesis

Adult Reciprocity is truthful coordination of real Ω. Reciprocity Loss begins when real asymmetry is falsely coordinated as mutuality, comparison, recognition, equality, play, or harmlessness.

EDEN does not ask who is better, worse, guilty, mature, immature, adult, childlike, innocent, or corrupt. It asks when a praxis frame cannot carry the asymmetry it pretends to coordinate.

---

## Validity Gate

Application use requires:

| Gate | Requirement |
| --- | --- |
| Χ / Distance | Maintained meta-position; no fusion into verdict, exposure, ideology, role authority, or accusation. |
| Reversibility | Scene-bound, revisable claims; no global person labels or fixed moral identity. |
| Dignity-in-Practice | No shaming, ranking, humiliation, adultness verdict, gender truth, or ontological person evaluation. |

The gate applies to EDEN use. It does not restrict criticism of EDEN.

---

## Methodological Restraint

PMS–EDEN is not theology, anthropology of origin, gender metaphysics, adultness test, maturity scale, legal framework, clinical diagnosis, or moral verdict engine.

It can use the Eden scene as a test scene because the scene is structurally useful for reading exposure, asymmetry, comparison, responsibility displacement, and non-binding. It does not make theological or historical claims about the scene.

---

## Key Contributions

| Contribution | Short orientation | Where to read |
| --- | --- | --- |
| Adult Reciprocity | Reciprocity means coordinated real Ω, not equality fantasy. | Core thesis / EDEN-MAP. |
| False-coordinated real asymmetry | Real asymmetry becomes unstable when framed as symmetry. | Main paper and model profile. |
| Responsibility principle | Responsibility may exist without malicious intent or total capacity. | Responsibility sections. |
| No passive praxis | Passivity can still be structurally active under a frame. | Structural contributions. |
| Ψ-load shift | Binding burden can be shifted without being made legitimate. | Ψ-load sections. |
| False comparison / switch family | Comparison can erase the very asymmetry that makes it invalid. | EDEN-MAP and examples. |
| Immunization / overexposure / AEP | Defensive structures can stabilize false coordination. | Drift sections. |
| Pseudo-Augenhöhe | Recognition can occur without accepting responsibility. | Recognition sections. |
| PFO | Downstream regime stabilization after reciprocity loss. | PFO sections. |
| Eden as test scene | A structural scene, not theological proof. | Methodological sections. |
| Reciprocity Loss | A tragedy of coordination, not a person diagnosis. | Final argument. |
| Boundary conditions | Falsifiers and minimal use discipline prevent overreach. | Boundary/Falsifier sections. |

---

## EDEN-MAP and Falsifiers

EDEN-MAP should be used as a structural map for asymmetry, comparison, responsibility, exposure, recognition, and loss of reciprocity.

Falsifier discipline matters. EDEN weakens or fails when:

```text
real Ω is not present
asymmetry is already truthfully coordinated
responsibility is asserted without capacity or alternative
comparison is not load-bearing
publicness is not structurally relevant
the reading depends on person typing
```

Boundary:

```text
EDEN-MAP ≠ verdict map
falsifier ≠ acquittal
responsibility readability ≠ blame proof
```

---

## Safety and Minimal Use Discipline

PMS–EDEN must be kept away from:

```text
adultness verdicts
gender truth claims
person ranking
maturity diagnosis
public accusation
legal conclusion
therapeutic diagnosis
moralized exposure
```

Minimal use rule:

```text
Use EDEN only when the claim can remain structural,
scene-bound, reversible, dignity-preserving, and source-limited.
```

---

## Model and Examples

The model layer contains `model/PMS-EDEN.yaml` and human-readable model specifications.

The example suite contains scene-bound stress tests. Examples should illustrate structural drift, not adjudicate persons.

Use cases should preserve:

```text
scene packet boundary
evidence limits
temporal boundary
role-position distinction
Dignity-in-Practice
no person-level labels
```

---

## Reading Path

Recommended path:

```text
README
→ main paper
→ validity gate
→ EDEN-MAP
→ boundary conditions and falsifiers
→ model/PMS-EDEN.yaml
→ examples/
```

---

## Status

PMS–EDEN is a bounded paper-form PMS lens.

Its current status is:

```text
Adult Reciprocity lens
false-coordination analysis
asymmetry-focused
application-gated
non-theological
non-diagnostic
non-validating
```


---

## Archive / DOI

| Resource | Description |
| --- | --- |
| PMS–EDEN DOI | [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20853589.svg)](https://doi.org/10.5281/zenodo.20853589) |

---

## Links and Resources

### PMS Core and Orientation

| Resource | Description |
| --- | --- |
| [PMS Theory / Repository](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory) | Core PMS grammar, theory text, model files, examples, and orientation documents. |
| [PMS — Short Introduction](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/PMS%20-%20Short%20Introduction.md) | Concise orientation to PMS, its scientific status, spectrum, limits, use areas, and claim boundaries. |
| [Overview of the PMS Ecosystem](https://github.com/tz-dev/Praxeological-Meta-Structure-Theory/blob/main/doc/Overview%20of%20the%20PMS%20Ecosystem.md) | Ecosystem map covering repository forms, layer boundaries, claim types, and relations between PMS projects. |

### PMS Paper-Form Lenses and Bridge Layers

| Resource | Description |
| --- | --- |
| [PMS-ANTICIPATION](https://github.com/tz-dev/PMS-ANTICIPATION) | Future-oriented praxis under uncertainty, non-events, restraint, anticipation, and post-confirmation drift. |
| [PMS-CONFLICT](https://github.com/tz-dev/PMS-CONFLICT) | Conflict as stabilized incompatibility under cost geometry, asymmetry, continuity load, endpoint pressure, and binding. |
| [PMS-CRITIQUE](https://github.com/tz-dev/PMS-CRITIQUE) | Critique as interruption, recontextualization, distance, correction, and drift from irritation into judgment or exposure. |
| [PMS-EDEN](https://github.com/tz-dev/PMS-EDEN) | Adult Reciprocity, false-coordinated real Ω, responsibility displacement, Reciprocity Loss, and blocked Σ/Ψ. |
| [PMS-LOGIC](https://github.com/tz-dev/PMS-LOGIC) | Pre-moral foundations, logical limits, responsibility, non-closure, and post-moral effects. |
| [PMS-SEX](https://github.com/tz-dev/PMS-SEX) | High-asymmetry sexual-praxeological configurations under cost topology, direct otherness, boundary coding, withdrawal, and after-scene dignity. |
| [PMS-QC](https://github.com/tz-dev/PMS-QC) | Structural bridge mapping between PMS operators and quantum-computational workflows, circuits, algorithms, and agentic QC governance. |
| [PMS-VECTOR](https://github.com/tz-dev/PMS-VECTOR) | Bounded praxeological orientation under perspectival pressure, rival comparison, reversible inquiry, transformable possibility, and explicit reduction. |

### PMS Corpus-Form Repositories

| Resource | Description |
| --- | --- |
| [Maturity in Practice](https://github.com/tz-dev/Maturity-in-Practice) | Praxeological anthropology corpus for A–C–R–P–D maturity, inadult asymmetry, dignity-in-practice, examples, model files, and reader navigation. |
| [PMS-AXIOM](https://github.com/tz-dev/PMS-AXIOM) | Case-cartography corpus for classical closure-demands, Markdown/YAML case artifacts, schemas, indexes, overlays, prompts, templates, and reader navigation. |
| [PMS-STACK](https://github.com/tz-dev/PMS-STACK) | Architecture-specification corpus for PMS as OS, CPU, language, runtime, security, networking, distributed systems, reference layers, and reader navigation. |
| [PMS-EM](https://github.com/tz-dev/PMS-EMERGENCE_MODEL) | Emergence / developmental-architecture corpus for trace-backed regularity, measurement, projection, diary discipline, auditability, and reader navigation. |
| [PMS-STRATA](https://github.com/tz-dev/PMS-STRATA) | Transformation / granularity-discipline corpus for COMPOSE, DECOMPOSE, PROJECT_AS, admissibility, Loss, Stop, Non-Capture, schemas, cases, and reader navigation. |

### PMS Implementation and Workflow Tooling

| Resource | Description |
| --- | --- |
| [PMS-RUST](https://github.com/tz-dev/PMS-RUST) | Rust implementation workspace / executable evidence spine with deterministic kernel, model validation, REPL/script runner, JSONL traces, vFS surface, AI proposal gate, demos, tests, and acceptance gates. |
| [PMS-ORCHESTRATOR](https://github.com/tz-dev/PMS-ORCHESTRATOR) | Local workflow runner for PMS-DISCIPLINE case work, route state, raw-output preservation, structural YAML validation, handoff review, article routes, and confirmed stop enforcement. |

### PMS Application Discipline and Self-Critique

| Resource | Description |
| --- | --- |
| [PMS-DISCIPLINE](https://github.com/tz-dev/PMS-DISCIPLINE) | Application-discipline layer for Pre-Entry, Pre-Analysis, Core-entry gates, claim ceilings, add-on restraint, MIP/AHP routing, Case Records, Iteration Handoff, article boundaries, and stop-capability. |
| [PMS — UNDER LOAD](https://github.com/tz-dev/PMS-UNDER-LOAD) | Structural self-critique of PMS under calibration, coverage, stack drift, Φ drift, meta-normativity, publicness, self-application, workflow, stop, handoff, and STRATA pressure. |

### Interactive Assistants

| Resource | Description |
| --- | --- |
| [PMS Model Assistant](https://chatgpt.com/g/g-69358a2a4980819183da6a97893389cf-pms-model-assistant) | Interactive exploration of PMS model materials. |
| [Maturity in Action](https://chat.openai.com/g/g-693460d3def48191ad08647301645a2e-maturity-in-action-a-praxeological-anthropology) | Applied praxeological anthropology assistant. |

Project websites and book pages are maintained separately and will be refreshed after the repository README update pass. Where available, they include the [PMS Theory Site](https://pms-theory.netlify.app), the [PMS-STACK book website](https://pms-stack.netlify.app), the [Maturity in Practice website](https://maturity-in-practice.netlify.app), the [Reife im Vollzug website](https://reife-im-vollzug.netlify.app), and the corresponding Amazon book pages for PMS-STACK and Maturity in Practice.


---

## Citation

When citing this repository, cite the repository release and DOI corresponding to the version used. Do not cite this project as if it validates PMS Base, replaces neighboring PMS layers, or licenses claims beyond its declared scope.

---

## License

Unless otherwise noted, textual theory, papers, documentation, examples, prompts, diagrams, and non-executable model or specification materials are licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Source code, executable tools, scripts, validators, schemas, and software-adjacent technical files, where present, are licensed under the Apache License 2.0.
