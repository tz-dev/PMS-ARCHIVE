# PMS–EDEN

## *A Praxeological Grammar of Adult Reciprocity and Its Loss through False-Coordinated Real Asymmetry*

## 0. Frontmatter, Scope, Guardrails

### 0.1 Abstract

PMS–EDEN develops a praxeological account of reciprocity loss through false-coordinated real asymmetry. Its central claim is not that asymmetry is itself the failure, nor that reciprocity would require symmetry, sameness, or equal burden. The paper begins from the opposite premise:

Adult Reciprocity ≠ symmetry.
Adult Reciprocity = truthful coordination of real Ω (asymmetry).

Adult Reciprocity names a structural condition in which real asymmetry remains visible, responsibility can follow actual structuring effect, costs and exposures can be integrated, self-binding remains possible, revision remains open, and dignity-in-practice is preserved. Reciprocity Loss begins where this coordination fails: real Ω (asymmetry) is falsely coordinated, R (responsibility) is displaced, Σ (integration) / Ψ (self-binding) are blocked, and shared correctability erodes.

The paper therefore does not begin with Eden or treat comparison, pseudo-symmetry, or any regime account as an origin. It begins with the positive structure of Adult Reciprocity and the loss pattern that emerges when real asymmetry is coordinated through frames that displace responsibility and block integration or self-binding. False Comparison functions as an attractor, amplifier, and stabilizer. Postfeminist Override (PFO) names one downstream regime form in which reciprocity loss can stabilize. Eden functions as a minimal test scene for a grammar established independently of it. None of these supplies the paper’s origin or master mechanism.

EDEN is structural and praxeological. It presupposes biologically embodied human agents while leaving the causal explanation and evaluation of sexed biological conditions outside its functional scope.
It does not diagnose persons, infer hidden mental states, rank sexes, moralize role-positions, or provide therapeutic, political, forensic, or interpersonal prescriptions. Its object is not a person type or a sex truth, but a scene-bound drift in the coordination of real asymmetry. The paper asks how reciprocity can be lost where real Ω (asymmetry) remains active, responsibility no longer follows actual structuring effect, integration fails, self-binding is weakened or displaced, and correction itself becomes illegible, unsafe, one-sided, humiliating, immunized, or impossible.

One further clarification is needed from the start. Praxis is broader than strict Action / Enactment E (strict Action / Enactment). Strict Action / Enactment E requires integrated enactment: E = Σ (integration) ∘ Θ (temporality) ∘ ∇ (impulse), compactly represented as [Σ, Θ, ∇]. A scene may therefore be structurally shaped not only by overt action, but also by non-action, withholding, framing, legitimation, recognition, protection, exposure, cost distribution, timing, or non-binding. This does not mean that every absence is action. It means only that non-action can become praxeologically relevant where it structures a scene under real Ω (asymmetry) and affects responsibility, integration, self-binding, or correctability.

The aim of PMS–EDEN is thus narrow but demanding: to describe how real asymmetry can be falsely coordinated without turning the description into a diagnosis, a verdict, a moral tribunal, a theory of sexed essence, or an authorization for coercive use. Its guiding formula is simple:

Reciprocity Loss = false coordination of real Ω (asymmetry).

### 0.2 PMS Reference and Notation

PMS–EDEN is derived from the Praxeological Meta-Structure framework. It uses PMS as an operator grammar for describing praxis, asymmetry, temporality, integration, and self-binding. EDEN does not add, remove, or redefine any PMS operator. All EDEN terms remain paper-internal shorthand for operator-traceable configurations.

The PMS operator set used in this paper is:

Δ — difference / distinction / boundary
∇ — impulse / directional tension
□ — frame / context / scope
Λ — non-event / structured absence
Α — attractor / pattern / structural recurrence / stabilization
Ω — asymmetry / gradient of power, exposure, capacity, or obligation
Θ — temporality / sequence / accumulation / irreversibility
Φ — recontextualization / reframing / transfer
Χ — distance / separation / suspension / attenuation
Σ — integration / synthesis / incorporation / coherence
Ψ — self-binding / commitment / constraint / durable binding

The paper also uses five systematically derived PMS axes:

A (awareness) = Θ ∘ □ ∘ Δ
C (coherence) = Θ ∘ Λ ∘ □ ∘ ∇
R (responsibility) = Ψ ∘ Φ ∘ Θ ∘ Ω
E (strict Action / Enactment) = Σ ∘ Θ ∘ ∇
D (dignity-in-practice) = Ψ ∘ Χ ∘ Ω

These axes are derived constructs, not added primitives, and EDEN does not redefine them. The body may abbreviate the ordered E composition as [Σ, Θ, ∇]; this is compact operator-list notation, not an alternative derivation.

EDEN-specific labels such as False-Coordinated Real Asymmetry, False Comparison, Pseudo-Symmetry, Recognition-without-Responsibility, No Passive Praxis, Immunization, Overexposure, PFO, NRK, and EDEN-MAP are likewise not PMS operators. They are compression labels for possible operator-traceable configurations that must remain tied to scene, role-position, real Ω (asymmetry), structuring effect, responsibility distribution, Σ (integration) / Ψ (self-binding) status, and possible counter-scene. Their usefulness depends on whether they preserve operator traceability; they lose validity where they replace analysis with naming.

This distinction is especially important because EDEN deals with high-risk material. A label may make a pattern readable, but it does not by itself prove the pattern, diagnose a person, rank a group, authorize action, or settle the scene. Description may name structure. Application requires scene packet, counter-scene, Χ (distance), reversibility, D (dignity-in-practice), and contextual responsibility. Description does not authorize binding.

For the present paper, only minimal notation is required in the body. Full operator definitions, derived axes, and paper-internal term definitions belong to Appendix A. Chapter 0 provides just enough notation to keep the argument legible without turning the opening into a PMS primer.

One distinction, however, must be visible from the beginning: Praxis ≠ strict Action E (strict Action / Enactment). Strict Action / Enactment E = [Σ (integration), Θ (temporality), ∇ (impulse)]. Praxis names situated, meaningful structuring within a relevant field. This allows EDEN to ask whether a scene is structured not only by visible action, but also by non-events, frame control, withholding, legitimation, recognition, non-binding, or cost distribution. That question will be developed later under No Passive Praxis. Here it functions only as a guardrail: not every absence is praxis, and not every structuring effect appears as ordinary action.

### 0.3 Entry Condition

An EDEN reading may not begin from impression, irritation, ideological projection, isolated sentence, identity, or role suspicion. It begins only where a scene presents a real asymmetry field and a traceable structuring effect. The minimal entry condition is:

real Ω (asymmetry)

* praxis scene
* structuring effect
* traceable responsibility / recognition / protection / cost / legibility shift
* Σ (integration) / Ψ (self-binding) relevance
* possible counter-scene

No EDEN reading without real Ω (asymmetry). No EDEN reading without scene. No EDEN reading without structuring effect. No isolated sentence diagnosis.

Real Ω (asymmetry) means that asymmetry is operative in the scene: capacity, exposure, cost, protection, recognition, responsibility, access, timing, dependency, vulnerability, action-power, or legibility are unevenly structured in a way that matters for praxis. A praxis scene means that the pattern is not merely a thought, feeling, claim, or impression, but a situated configuration of roles, frames, effects, and possible responses. Structuring effect means that something in the scene shapes what can be done, said, carried, corrected, withheld, recognized, protected, or made costly.

Such structuring effect may include direct action. It may also include non-action, delay, silence, withholding, legitimation, framing, recognition, protection, exposure, cost distribution, or non-binding. But these are not automatically EDEN-relevant. They become relevant only where they structure the scene under real Ω (asymmetry) and affect responsibility, Σ (integration), Ψ (self-binding), dignity-in-practice, or shared correctability.

This is also EDEN’s biological-to-praxeological entry point. Biological conditioning remains outside the framework. Embodied conditions become EDEN-relevant only where they are praxeologically effective as real Ω (asymmetry), produce a traceable structuring effect within a scene, and satisfy the entry conditions stated here.

The entry condition also requires the possibility of counter-scene. EDEN must remain able to weaken, narrow, revise, or suspend its reading where another explanation fits better, where real Ω (asymmetry) is absent, where responsibility is not displaced, where Σ (integration) / Ψ (self-binding) are not blocked, or where the alleged drift is better understood as genuine vulnerability, genuine protection, legitimate hierarchy, functional comparison, neutral non-action, or ordinary non-capture. The threshold rule is therefore immediate: an EDEN reading that cannot name what would change it is already methodologically unsafe.

This entry condition separates description from application. EDEN may describe structural configurations sharply. It may name false coordination, responsibility displacement, blocked integration, weakened self-binding, or loss of correctability. But description is not yet application. Once a reading is used to bind, direct, obligate, confront, prescribe, intervene, enforce, or assign responsibility, it must satisfy the stronger validity gate: Χ (distance), reversibility, D (dignity-in-practice), scene packet, counter-scene, and contextual responsibility.

EDEN therefore begins cautiously, not because its claims are weak, but because its object is structurally sensitive. A theory of reciprocity loss must not produce its own loss of reciprocity at the point of use.

### 0.4 Scope and Non-Goals

EDEN is a structural, praxeological, scene-bound, operator-disciplined, and counter-scene exposed theoretical framework for analyzing reciprocity loss under real asymmetry. It is not an empirical typology or prevalence study. Its concepts identify structurally possible configurations; claims about their occurrence, recurrence, or distribution across persons, sexes, populations, institutions, cultures, or historical periods require independent empirical support. EDEN does not aim to provide a total anthropology, a theory of sexed essence, a moral psychology, a clinical model, a political program, or a general social diagnosis. Its claims remain strongest where a concrete scene shows real Ω (asymmetry), structuring effect, responsibility displacement, blocked Σ (integration) / Ψ (self-binding), and loss of shared correctability.

#### Embodied Preconditions and Scope Boundary

EDEN presupposes embodied human praxis. Human sexed embodiment has biological conditions that may contribute to persistent differences in thresholds, costs, directional tensions, vulnerabilities, capacities, and practical weighting across the human action spectrum. EDEN neither derives nor adjudicates these biological conditions. It does not determine their endocrine, neurological, developmental, or evolutionary mechanisms, measure their relative causal contribution, or translate them into a fixed individual destiny, exhaustive sexed essence, rank, or normative warrant.

The fact of biological conditioning is not itself produced by praxeological coordination, even though its concrete expression may be culturally, biographically, medically, and situationally modulated. EDEN therefore does not analyze or seek to correct biological sex difference as such. It begins only where embodied conditions become praxeologically effective as real Ω (asymmetry): where they shape capacity, exposure, dependency, vulnerability, action-cost, protection, responsibility, legibility, or the coordination of a concrete scene.

EDEN coordinates human praxis under conditions of embodied difference. It does not model, abolish, morally rank, or functionally intervene in the biological substrate that may condition those differences.

This also means that EDEN is not a diagnostic instrument. It does not identify personality types, pathologies, motives, hidden intentions, moral worth, or fixed role essences. It does not rank persons, sexes, groups, institutions, or ideological positions. It does not treat “man” or “woman” as moral types, psychological profiles, or explanatory verdicts. Where sexed praxis relations become relevant, they are treated as scene-bound configurations under Ω (asymmetry), not as sex-truth claims.

EDEN is also not a therapeutic, forensic, advisory, or intervention protocol. It does not tell agents what they must do, how a relationship should be repaired, how a conflict should be adjudicated, or how responsibility should be enforced. It can describe a structural configuration; it does not thereby authorize binding action. The distinction matters because a language of responsibility can itself become humiliating, coercive, or verdictive if it exits the conditions it claims to defend.

Nor does EDEN replace theology, sociology, psychology, feminism, masculinity studies, discourse theory, recognition theory, systems theory, or adjacent frameworks. Those frameworks may remain stronger where their object is different or where a rival explanation better fits the scene. EDEN isolates one structural dimension: how real asymmetry can be falsely coordinated such that responsibility is displaced, integration and self-binding are blocked, and correctability erodes.

The central scope rule is therefore simple: EDEN must not analyze reciprocity loss by exiting reciprocity. It may name structural drift, but it must not convert that naming into diagnosis, humiliation, rank, coercion, or immunity.

### 0.5 Methodological Restraint

EDEN begins with structure, not motive. Its first question is not what a person secretly wants, fears, avoids, resents, or intends, but how the scene is structured: which frames and asymmetries matter, which costs are visible or hidden, which responsibilities follow actual structuring effect, and where integration or self-binding fails. Psychological appearances may still matter, but they are not methodologically primary. The safer formulation asks how a role-position structures the scene under the operative frame, asymmetry, temporality, responsibility, and self-binding conditions.

Responsibility may be real without malicious intent. A role-position may structure cost, exposure, access, recognition, protection, timing, or correction without intending domination, evasion, humiliation, or harm. Conversely, good intention does not by itself integrate a cost, restore self-binding, or reattach responsibility to actual effect. EDEN therefore tracks structuring effect before speculating about motive.

The same restraint applies to non-action. Silence, delay, refusal, absence, withholding, or non-binding becomes relevant only where it structures the scene under □ (frame) / Λ (non-event) / Ω (asymmetry) / Θ (temporality); otherwise it remains outside EDEN’s concern. Structure critique is likewise not person threat. Naming displaced responsibility, blocked integration or self-binding, or weakened correctability does not condemn a person’s being, worth, sex, character, or inner state.

### 0.6 Discriminative Adequacy

A theory of false coordination must be able to distinguish false cases from genuine ones. EDEN therefore becomes weaker, not stronger, if it can explain every scene equally well. Its task is not to absorb all vulnerability, protection, hierarchy, superiority, non-action, equality, recognition, or conflict into its own drift vocabulary. Its task is to identify a specific structural failure: real Ω (asymmetry) falsely coordinated, R (responsibility) displaced, Σ (integration) / Ψ (self-binding) blocked, and correctability eroded.

For that reason, EDEN must distinguish genuine vulnerability from immunization; genuine protection from responsibility shield; genuine hierarchy from authority capture; genuine superiority from pseudo-superiority; real asymmetry from rank artifact; structure critique from person threat; functional comparison from false comparison; and neutral non-action from structuring non-event. These distinctions are not peripheral. They are what prevent EDEN from becoming a catch-all.

Protection can be real. Vulnerability can be real. Power can be real. Dependency can be real. Hierarchy can be real. Local superiority can be real. Responsibility can be real on more than one side. Bidirectionality is not symmetry, and non-symmetry is not one-sidedness. A reading that cannot preserve these distinctions has already flattened the scene it claims to analyze.

The same applies to non-action. Mere absence is not the same as a structuring non-event, and a structuring non-event is not the same as integrated abstention. Silence may be restraint. Delay may be legitimate. Non-binding may be honest openness. Openness may be real non-capture rather than evasion. These possibilities must remain available before EDEN names drift.

The governing principle is exact: an EDEN reading must be able to fail. If no counter-scene could change the reading, the reading is not methodologically disciplined; it has become self-confirming.

### 0.7 Paper-Wide Guardrail

EDEN is not outside the structures it analyzes. The analyst is not outside comparison susceptibility, partial legibility, Φ (recontextualization) risk, responsibility displacement, or the learned field in which scenes become visible in the first place. The paper therefore cannot treat its own framework as a pure standpoint from which others are merely mapped, corrected, or exposed.

This guardrail is not an ornamental humility clause. It follows from the theory itself. If reciprocity loss can occur through false coordination, responsibility displacement, blocked integration, weakened self-binding, and loss of correctability, then EDEN can also betray its own object when its language is used without distance, reversibility, dignity-in-practice, or counter-scene exposure. A theory about immunization must not immunize itself.

EDEN remains answerable to counter-scenes. It remains open to non-capture. It must preserve D (dignity-in-practice) while analyzing the loss of D. It must not use responsibility language to humiliate, recognition language to immunize, protection language to erase criticizability, or asymmetry language to rank persons or sexes. It must not turn structural description into verdict.

The paper’s final guardrail is therefore also its first methodological self-binding: a theory of reciprocity loss must remain answerable to reciprocity in its own use.

---

## 1. Core Thesis: Reciprocity Loss through False-Coordinated Real Asymmetry

### 1.1 Main Claim

After the guardrails are in place, the thesis of the paper can be stated directly. PMS–EDEN does not treat reciprocity as symmetry, sameness, harmony, equal burden, or formal parity. It treats reciprocity as the truthful coordination of real asymmetry.

Adult Reciprocity ≠ symmetry.
Adult Reciprocity = truthful coordination of real Ω (asymmetry).

The corresponding loss is therefore not the mere presence of conflict, difference, inequality, vulnerability, dependency, hierarchy, or unequal exposure. Reciprocity Loss begins where real asymmetry is no longer truthfully coordinated. It begins where a real Ω (asymmetry) field remains operative, but the scene is organized through a frame that misplaces responsibility, blocks integration, weakens self-binding, and erodes the possibility of shared correction.

Reciprocity Loss = false coordination of real Ω (asymmetry).

This is the central reversal of the paper. Asymmetry is not the failure. False coordination of asymmetry is the failure. A scene may be unequal, dependent, exposed, protective, hierarchical, sexed, vulnerable, or power-laden without already being a scene of reciprocity loss. The question is whether the asymmetry can be named, carried, integrated, corrected, and bound by the relevant role-positions without humiliation, denial, immunity, or displaced burden.

Adult reciprocity therefore does not require equal burdens. It requires non-externalization of unequal burdens. The decisive issue is not whether the scene is symmetrical, but whether those who structure it can remain answerable to their structuring effect. Where responsibility follows real effect, where costs remain integrable, where self-binding is possible, and where correction can occur without degradation, asymmetry does not destroy reciprocity. It becomes the field in which adult reciprocity is tested.

This also explains why PMS–EDEN cannot begin with Eden, Fall, comparison, Postfeminist Override (PFO), or pseudo-symmetry. These are derivative scenes, mechanisms, or regime forms rather than foundations. They matter only because the more basic structure has already been defined: real Ω (asymmetry) must be coordinated. When it is coordinated truthfully, Adult Reciprocity remains possible. When it is falsely coordinated, responsibility is displaced, Σ (integration) / Ψ (self-binding) are blocked, and reciprocity loss becomes structurally legible.

A final clarification follows from this thesis. Praxis is not reducible to overt action, and responsibility is not reducible to visible doing. Non-action, non-binding, withholding, legitimation, recognition, protection, timing, or cost distribution can matter where they structure real Ω (asymmetry). But this does not make every absence praxeologically relevant. It only means that the paper must track structuring effect rather than visible action alone.

### 1.2 Master Formula

The argument of PMS–EDEN follows a single structural trace:

coordinated Ω (asymmetry)
→ false-coordinated real Ω
→ displaced R (responsibility)
→ blocked Σ (integration) / Ψ (self-binding)
→ reciprocity loss

This trace gives the paper its order. It begins with coordinated Ω (asymmetry) because the paper does not treat asymmetry as a defect to be abolished. Real asymmetry is part of praxis. It appears wherever capacities, vulnerabilities, costs, exposures, obligations, forms of access, or possibilities for correction are unevenly distributed. The positive question is whether that asymmetry can be coordinated without denial, flattening, rank conversion, immunity, or total exposure.

The second step is false-coordinated real Ω (asymmetry). This does not mean that the asymmetry is unreal. It means that real asymmetry is organized through a frame that makes it falsely legible. The asymmetry remains operative, but responsibility no longer tracks the actual structuring effect of the scene. What is carried by one role-position may be named as neutral, natural, protective, equal, vulnerable, exceptional, superior, harmless, or unavailable to critique. What is made costly for one side may not appear as cost inside the operative frame.

This is the paper’s mechanism formula:

real Ω (asymmetry)

* false coordination frame
* displaced R (responsibility)
* blocked Σ (integration) / Ψ (self-binding)
  = false-coordinated real Ω

The third step is displaced R (responsibility). Within PMS, R = Ψ ∘ Φ ∘ Θ ∘ Ω is a formally derived structural axis, not moral guilt, inner blameworthiness, or a verdict on personhood. EDEN’s Responsibility Principle is the separate analytical and explicitly normative attribution rule that asks whether answerability follows real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality), and Ω cost or exposure conditions. The rule neither redefines R nor follows automatically from its formula. R is displaced where a role-position shapes the scene while another position carries the cost, explanation, self-binding, correction burden, or exposure produced by that structuring.

The fourth step is blocked Σ (integration) / Ψ (self-binding). Integration fails where the real cost, asymmetry, wound, exposure, or responsibility cannot be brought into a shared frame without being denied, inverted, immunized, overexposed, or converted into threat. Self-binding fails where the relevant actor or role-position does not bind itself to its own structuring effect, or where one side’s non-binding increases the Ψ-load on the other. The result is not simply disagreement. The result is a loss of the conditions under which disagreement could still be corrected.

Only then does the paper arrive at reciprocity loss. Reciprocity loss is not merely conflict. It is not merely inequality. It is not merely hurt, difference, dissatisfaction, failed communication, or asymmetrical burden. It is the erosion of shared correctability under real Ω (asymmetry).

This order also fixes the place of the paper’s dependent concepts. False Comparison is an attractor, amplifier, and stabilizer rather than a first cause. Pseudo-Symmetry is one switch form rather than the master mechanism. PFO is one downstream regime form in which reciprocity loss stabilizes rather than its origin. Eden is a test scene for the grammar rather than the paper’s foundation. None of these reverses the master trace into a derivative causal chain.

The core claim remains that reciprocity depends on truthful coordination of real Ω (asymmetry), and that its loss becomes legible where real Ω is falsely coordinated, responsibility is displaced, Σ (integration) / Ψ (self-binding) are blocked, and shared correctability erodes.

### 1.3 Why Asymmetry Is Not the Problem

The central distinction of the paper can now be sharpened: asymmetry is not the failure. False coordination of asymmetry is the failure.

Real Ω (asymmetry) is not an accident at the edge of praxis. It is part of how praxis is organized wherever bodies, roles, capacities, dependencies, vulnerabilities, exposures, obligations, access, timing, and costs are unevenly distributed. Such asymmetry may be uncomfortable, consequential, and difficult to name, but it is not therefore false. A theory that treats asymmetry itself as the problem has already lost the distinction on which adult reciprocity depends.

The question is not whether asymmetry can be eliminated. The question is whether it can be coordinated truthfully. Real Ω (asymmetry) requires truthful coordination, not denial, not flattening, not ranking, not immunity, and not total exposure. Denial makes asymmetry unspeakable. Flattening treats unequal conditions as if they were already equal. Ranking converts difference into higher and lower. Immunity protects one role-position from responsibility for its structuring effect. Total exposure forces one side to carry the entire legibility, cost, or correction burden. None of these is adult reciprocity.

This matters because many forms of asymmetry can be genuine. Power can be real. Vulnerability can be real. Protection can be real. Dependency can be real. Hierarchy can be real. Local superiority can be real in bounded, field-specific ways. Unequal responsibility can also be real without becoming domination, inferiority, immunity, or blame. EDEN does not need to deny these possibilities in order to name false coordination. On the contrary, it must preserve them, because false coordination can only be identified where genuine asymmetry remains distinguishable from its drift forms.

This also applies to sexed praxis relations. The claim is not that sexed asymmetry is essence, rank, destiny, or moral type. The claim is only that sexed praxis relations can become structurally relevant under Ω (asymmetry): embodied, socially framed, historically stabilized, asymmetrically exposed, and responsibility-relevant. Such relations will be developed later. Here they matter only as one domain in which asymmetry can be real without being reducible to hierarchy, diagnosis, or sex truth.

Nor does the paper assume that responsibility belongs only to the visibly stronger side or only to the formally more active side. Action-power is not identical with direct action. A role-position may structure a scene through timing, refusal, withholding, recognition, protection claims, vulnerability claims, legitimation, non-binding, or cost distribution. But this does not mean that every difference, every vulnerability, every silence, or every dependency is already drift. The question remains scene-bound: what structures the scene, what follows from it, who carries the cost, and whether responsibility remains coordinated with real effect.

The boundary of the claim is therefore as important as the claim itself. EDEN does not say that all asymmetry is valid, all hierarchy is justified, all vulnerability is immunizing, all protection is evasive, or all power is domination. It says that reciprocity requires real asymmetry to remain nameable, criticizable, integrable, and self-binding. Where that fails, the problem is not Ω (asymmetry). The problem is false coordination of Ω.

### 1.4 Reciprocity versus Equality

Because Adult Reciprocity is not symmetry, it must also be distinguished from formal equality. EDEN does not reject equality. It rejects equality when equality becomes a substitute for truthful coordination.

Formal equality can protect dignity, prevent domination, and interrupt unjust hierarchy. It can also, in some scenes, hide the asymmetry that still structures responsibility, cost, exposure, criticizability, and self-binding. Equality becomes false where it declares parity while real Ω (asymmetry) remains uncoordinated. In that case, the scene appears equal at the level of frame while unequal burdens remain displaced at the level of praxis.

This is why equal standing cannot mean recognition without responsibility. A relation may speak the language of equal recognition while preserving unequal criticizability, unequal burden, unequal exposure, or unequal correction costs. It may claim parity while one side must explain, absorb, organize, repair, or self-bind around the other side’s non-binding. When recognition is detached from responsibility, parity becomes fragile. When responsibility is detached from recognition, critique becomes degrading. Adult reciprocity requires both.

Equal standing therefore cannot be reduced to sameness, identical obligation, or formal symmetry. It requires a fuller structure:

Equal standing
= recognition

* answerability
* criticizability
* consequence attribution
* correctability

Recognition without answerability is not equal standing.

This formula does not make recognition secondary. It protects recognition from becoming hollow. To recognize an adult role-position is not to shield it from criticizability. It is to treat it as capable of responsibility without humiliation, correction without degradation, and self-binding without domination. Conversely, to hold a role-position responsible is not to deny its dignity. It is to refuse the split in which dignity becomes immunity and responsibility becomes threat.

The later drift analysis distinguishes several ways in which equality language can become detached from responsibility, criticizability, consequence attribution, correction, or self-binding, including scenes in which one role-position’s non-binding increases the Ψ (self-binding)-load on another. The present claim is narrower: formal parity does not by itself establish equal standing where recognition and answerability are differently distributed.

The present thesis is narrower: equality is not rejected, but equality-as-replacement-for-reciprocity is rejected. Adult Reciprocity is not achieved when asymmetry disappears from view. It is achieved when real Ω (asymmetry) can be coordinated without humiliation, denial, immunity, displaced responsibility, or blocked correction.

### 1.5 Structural Stakes

The stakes of the paper are therefore not reducible to disagreement, inequality, hurt, misunderstanding, or failed communication. Reciprocity loss is not conflict. It is the loss of shared correctability under real Ω (asymmetry).

A scene may contain disagreement and still remain reciprocal if correction remains possible. It may contain asymmetry and still remain reciprocal if responsibility follows real structuring effect. It may contain vulnerability, protection, dependence, hierarchy, or unequal exposure and still remain reciprocal if those conditions can be named, integrated, criticized, and self-bound without humiliation or immunity. Reciprocity loss begins where this shared correctability erodes: where the cost of naming the structure becomes too high, where responsibility no longer follows effect, where critique becomes threat, where recognition detaches from responsibility, where protection blocks criticizability, where one side’s non-binding increases the Ψ (self-binding) load on the other, and where the scene can no longer correct itself without reproducing the loss.

The later drift analysis specifies this erosion through configurations of underassigned responsibility, overassigned exposure, unequal access to legitimate explanatory language, and recognition detached from criticizability, self-binding, or consequence-bearing. These are not independent origins, but scene-bound specifications of the same core trace.

Non-action, non-binding, and legitimation also matter only within this trace. Their relevance is not that absence secretly equals action or that silence is automatically culpable. Their relevance appears where a non-event, a refusal to bind, a delayed response, a legitimating frame, or a protected absence structures real Ω (asymmetry) and shifts cost, exposure, responsibility, or correctability onto another role-position. Action-power therefore includes the power to structure conditions, not only the power to perform overt acts. But this broader view of praxis must remain scene-bound; otherwise it would become precisely the kind of overextension the paper rejects.

The theoretical burden of PMS–EDEN is thus double. It must be strong enough to name false coordination where real Ω (asymmetry) is being hidden, flattened, ranked, immunized, overexposed, or displaced. It must also be restrained enough to preserve genuine vulnerability, genuine protection, genuine hierarchy, genuine superiority, neutral non-action, functional comparison, and rival explanations. The paper’s concepts are useful only if they increase discriminative force rather than becoming a language in which every scene confirms the same drift.

The loss at stake is tragic rather than tribunal. Tragic, because reciprocity can fail even where no simple villain, intention, or moral essence explains the failure. Structural, because the paper tracks frames, effects, responsibilities, integrations, and self-bindings rather than condemning persons. Loss, because what disappears is not merely comfort or agreement, but the shared capacity to correct the scene under real asymmetry.

Tragedy, not guilt.
Structure, not verdict.
Loss, not accusation.

Having stated the thesis, the paper must now clarify how such scenes are to be read. The next chapter therefore turns from claim to method: how EDEN can describe structural drift without psychologizing it, diagnosing persons, applying labels by impression, or converting a theory of reciprocity into a verdict machine.

---

## 2. Method: Structural Legibility and PMS Discipline

### 2.1 Structural, Not Psychological Primary

The thesis stated in Chapter 1 requires a method. If reciprocity loss is the false coordination of real Ω (asymmetry), then EDEN cannot begin by inferring motives, diagnosing persons, or translating discomfort into verdict. It must first ask how the scene is structured.

The methodological rule is therefore:

Structure first.
Psychological appearances enter only as independently evidenced scene data; they are not PMS derivations or inferred mental states.

Fear, shame, aggression, resentment, withdrawal, guilt, hurt, avoidance, or control may appear in a scene and matter for its development. EDEN makes no PMS-based claim about them as inner states. It begins with praxeological structure: which □ (frame) organizes the scene, which Λ (non-event) matters, which Ω (asymmetry) is operative, which Θ (temporality) shapes consequence, which Φ (recontextualization) changes the meaning of what happened, which Α (attractor) stabilizes a pattern, and where Σ (integration) or Ψ (self-binding) fails.

This shift matters because psychological language can become too fast. “He avoids,” “she wants,” “he controls,” “she fears,” “he refuses,” or “she manipulates” may sometimes describe visible appearances, but EDEN does not treat such formulations as methodologically primary. The safer formulation asks what the role-position does structurally: how it shapes access, timing, cost, recognition, protection, exposure, correction, or self-binding under the operative frame and asymmetry conditions.

This restraint is especially important where non-action appears psychologically charged. A silence, delay, refusal, withholding, non-response, or non-binding posture may appear passive, evasive, hostile, protective, restrained, or confused. EDEN does not decide that question by appearance alone. It asks whether the non-event structures the scene under □ (frame) / Λ (non-event) / Ω (asymmetry) / Θ (temporality). If it does not, it remains outside EDEN’s concern. If it does, it may become praxeologically relevant without thereby becoming strict Action / Enactment E (strict Action / Enactment).

Responsibility also has to be handled at the structural level. Responsibility may be real without malicious intent. A role-position may distribute cost, exposure, access, timing, recognition, or correction burden without intending domination, evasion, humiliation, or harm. Conversely, good intention does not by itself integrate a cost, restore self-binding, or reattach responsibility to actual effect. EDEN therefore tracks structuring effect before it speculates about motive.

Structure critique is not person threat. To say that a configuration displaces responsibility, blocks Σ (integration) / Ψ (self-binding), weakens correctability, or externalizes cost is not to condemn a person’s being, worth, sex, character, or inner state. It is to name a praxeological configuration. EDEN can be sharp only if it remains restrained at this point: it must describe structure without converting structure into personhood.

### 2.2 Description versus Application

The same restraint governs the distinction between description and application. EDEN may describe structural configurations sharply. It may name false coordination, responsibility displacement, blocked integration, weakened self-binding, immunization, overexposure, or loss of correctability. But description is not yet application.

A description maps what may be structurally happening in a scene. It identifies role-positions, operative frames, real asymmetry, structuring effects, responsibility shifts, cost distributions, Σ (integration) / Ψ (self-binding) relevance, and possible counter-scenes. Such description can be critical, precise, and uncomfortable without yet authorizing any binding use.

Application begins only when a description is used to steer, bind, obligate, confront, prescribe, intervene, enforce, or assign responsibility. At that point, the methodological burden changes. A reading that remains valid as description may become invalid as application if it exits distance, reversibility, dignity-in-practice, or contextual responsibility.

Χ (distance) is therefore not a truth condition for structural description. EDEN can describe scenes in which Χ is absent, weak, simulated, or instrumentalized. If Χ were required for description itself, EDEN could not name many of the patterns it is designed to analyze. But Χ becomes required when description is used to bind. Once a structural reading becomes action-guiding, responsibility-assigning, obligatory, or corrective, it must pass a stronger gate.

That gate can be stated simply:

Description may name structure.
Application requires Χ (distance), reversibility, D (dignity-in-practice), and contextual responsibility.
Description does not authorize binding.

Reversibility means that the reading remains open to correction, narrowing, suspension, or defeat. Dignity-in-practice means that the reading must not humiliate, rank, degrade, or convert structural critique into person threat. Contextual responsibility means that responsibility must follow real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions.

This is the Description-to-Action Firewall. It prevents a structural vocabulary from becoming a shortcut to obligation, accusation, intervention, or verdict. It also prevents the opposite error: treating the possibility of misuse as a reason why structure may not be named. Description remains possible. Binding use requires more.

The firewall is not a weakening of EDEN’s claims. It is part of their discipline. A theory of reciprocity loss would contradict itself if it used the language of responsibility to produce humiliation, the language of recognition to produce immunity, or the language of asymmetry to produce rank. EDEN must therefore remain strongest where it is most restrained: it can name structure, but it cannot convert naming into binding without passing the conditions of application.

### 2.3 Scene Packet Method

Because description does not yet authorize application, EDEN must also specify the unit of description. EDEN does not analyze isolated statements, identities, impressions, ideological positions, or role suspicions. It analyzes scenes.

A scene is not merely an event. It is a situated configuration in which role-positions, frames, asymmetries, effects, costs, protections, recognitions, and possible responses become structurally related. EDEN therefore begins from a scene packet, not from a label. The minimal scene packet contains:

a scene
+ role-positions
+ real Ω (asymmetry)
+ structuring effect
+ traceable responsibility / recognition / protection / cost / legibility shift
+ Σ (integration) / Ψ (self-binding) relevance
+ possible counter-scene

This packet does not decide the reading. It only makes a reading methodologically admissible. A sentence may be provocative, a gesture may be irritating, a claim may be ideologically loaded, and a role-position may appear suspicious; none of that is enough. EDEN requires a scene in which real Ω (asymmetry) is operative and a structuring effect can be traced.

The role-position requirement matters because EDEN does not read persons as fixed types. It asks what positions within a scene do, carry, avoid, receive, legitimate, expose, protect, or make costly. A role-position may coincide with a person, but it is not identical with that person’s essence, psychology, sex, or moral worth. This is why EDEN can name structural responsibility without turning the person into a diagnosis.

The real Ω (asymmetry) requirement prevents EDEN from becoming a language for general dissatisfaction. There must be some uneven distribution of capacity, exposure, cost, protection, recognition, access, timing, dependency, vulnerability, action-power, or legibility. Without real Ω, EDEN has no object. Disagreement alone is not enough. Irritation alone is not enough. The presence of a politically or morally charged topic is not enough.

The structuring-effect requirement prevents EDEN from becoming interpretation by association. Something in the scene must shape what can be said, done, withheld, carried, corrected, recognized, protected, or made costly. This may include overt action, but it may also include non-action, framing, legitimation, silence, delay, recognition, protection, exposure, non-binding, or cost distribution. These factors become EDEN-relevant only where they structure the scene under real Ω (asymmetry).

The Σ (integration) / Ψ (self-binding) requirement keeps EDEN tied to reciprocity rather than mere inequality. EDEN asks whether the cost, exposure, responsibility, or correction burden can be integrated into a shared frame, and whether relevant role-positions remain self-bound to their own structuring effects. If no integration or self-binding question is at stake, the scene may still be unequal, painful, or contested, but it is not yet an EDEN scene.

Finally, the possible counter-scene requirement keeps the reading revisable from the start. A scene packet must include at least one way in which the reading could be weakened, narrowed, suspended, or defeated. Could the apparent drift instead be genuine vulnerability, genuine protection, legitimate hierarchy, functional comparison, neutral non-action, or ordinary non-capture? If no such possibility can even be named, the reading is not yet disciplined enough to proceed.

The scene packet therefore functions as a threshold, not as a verdict. It prevents EDEN-by-impression, PFO-by-impression, identity-based reading, and isolated-sentence diagnosis. It also prepares the later EDEN-MAP without already becoming it. Chapter 19 will operationalize scene mapping more fully. Here the methodological point is narrower: EDEN begins only where a scene packet makes structural reading possible.

### 2.4 Validity Gate

Once a scene packet exists, the reading still does not automatically become applicable. A scene may be structurally legible without authorizing any binding use. The validity gate determines when a description can be used in ways that steer, obligate, confront, prescribe, enforce, or assign responsibility.

The gate has five elements:

Χ (distance)
+ reversibility
+ D (dignity-in-practice)
+ counter-scene exposure
+ contextual responsibility

Χ (distance) means that the reading does not collapse into urgency, fusion, retaliation, humiliation, or verdict. It preserves reflective inhibition: the capacity to keep the reading at a distance from immediate enforcement. Without Χ, a structural description can become a weapon even when its content is partly accurate.

Reversibility means that the reading remains revisable. It can be corrected, narrowed, suspended, or abandoned if the scene changes, if a counter-scene fits better, if a rival explanation is stronger, or if the alleged structuring effect cannot be traced. Reversibility is not indecision. It is the methodological refusal to turn a scene-bound reading into an irreversible label.

D (dignity-in-practice) means that the reading must preserve the dignity of the role-positions it analyzes. It may name responsibility, but it may not humiliate. It may name false coordination, but it may not rank persons or sexes. It may name blocked criticizability, but it may not convert critique into degradation. D is therefore not softness. It is the restraint required when analysis moves under real Ω (asymmetry).

Counter-scene exposure means that the reading must remain answerable to possible failure. The question is not merely whether EDEN can explain the scene, but whether another reading can explain it better, or whether the scene lacks one of EDEN’s required conditions. A reading that cannot be changed by counter-scene is not stronger. It is methodologically unsafe.

Contextual responsibility means that responsibility must follow real structuring effect under the conditions actually available in the scene. It must consider legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure. Responsibility does not follow visibility alone, declared intention alone, formal role alone, or outcome alone. It follows structuring effect under conditions.

The validity gate does not make EDEN toothless. It makes EDEN usable without betraying its own object. A theory of reciprocity loss cannot authorize a use that produces humiliation, irreversible labeling, coercive application, or responsibility without scene conditions. It can describe sharply. It can name drift. It can identify false coordination. But when description is used to bind, it must pass the gate.

The methodological rule is narrower: description may become application only where distance, reversibility, dignity-in-practice, counter-scene exposure, and contextual responsibility remain intact.

### 2.5 Counter-Scene Protocol

The validity gate requires a further methodological discipline: an EDEN reading must be able to fail. If a reading cannot name what would weaken, narrow, suspend, or defeat it, then it is not yet a disciplined structural interpretation. It has become self-confirming.

A counter-scene is the name for this requirement. It is not an ornamental gesture toward complexity, and it is not a rhetorical concession added after the reading is already fixed. A counter-scene must be capable of changing the reading. Otherwise it is decorative, not methodological.

The first counter-scene question is whether real Ω (asymmetry) is actually present. If the scene contains disagreement, discomfort, irritation, or moral tension but no operative asymmetry of capacity, exposure, cost, protection, recognition, timing, dependency, access, or legibility, then EDEN has no object. Without real Ω, there may still be conflict, but there is not yet an EDEN scene.

The second question is whether responsibility is actually displaced. A role-position may be visible, active, affected, vulnerable, or powerful without thereby being the site of displaced R (responsibility). Responsibility must follow structuring effect under scene conditions. If the alleged displacement cannot be traced, or if the burden follows a real and legitimate distribution of role, capacity, exposure, or protection, the reading must be weakened.

The third question is whether Σ (integration) / Ψ (self-binding) are actually blocked. A scene may be painful without being structurally unintegrable. It may involve non-action without involving a structuring non-event. It may involve protection without immunization, vulnerability without responsibility evasion, hierarchy without authority capture, superiority without pseudo-superiority, comparison without false comparison, and openness without non-capture. These possibilities are not exceptions to EDEN. They are part of its method.

The fourth question is whether a rival explanation fits better. A scene may be better explained by genuine vulnerability, genuine protection, legitimate hierarchy, functional comparison, limited information, ordinary misunderstanding, conflicting obligations, or a local failure that does not amount to false-coordinated real asymmetry. EDEN becomes stronger, not weaker, when it can say: this is not an EDEN case, or this is only a partial EDEN case, or this reading must remain suspended.

The counter-scene protocol therefore protects EDEN from becoming a catch-all. It prevents the theory from absorbing every silence, asymmetry, conflict, comparison, vulnerability, protection claim, or recognition claim into its own drift vocabulary. It also prevents the opposite error: treating the risk of overreach as a reason why structural drift may never be named. The disciplined position is narrower: name structure where the scene supports it; revise, narrow, or suspend the reading where a counter-scene changes the pattern.

Contestation is part of this protocol. Every affected role-position whose effects, costs, exposure, protection, responsibility, or standing are being mapped retains standing to contest the scene packet, evidentiary selection, operative frame, responsibility trace, or proposed application. Other participants and rival analyses may likewise introduce relevant evidence or a stronger counter-scene. This standing does not require agreement with the reading, participation in continued engagement, or acceptance of EDEN’s vocabulary; nor does contestation by itself settle the interpretation.

A reading may be revised by new scene evidence, a stronger counter-scene, a better rival explanation, altered information about capacity or available alternatives, a corrected temporal sequence, a different cost or exposure distribution, or any specified falsifier. The analyst bears responsibility for recording such revision conditions and for narrowing, suspending, or defeating the reading when they are met. Disagreement alone neither defeats the reading nor confirms failed correctability, immunization, threat-coding, or any other EDEN mechanism.

Where agreement about the reading remains unavailable, the result must be recorded as contested, provisional, narrowed, or indeterminate. EDEN does not convert unresolved disagreement into confirmation of itself, and the framework supplies no binding authority merely because one interpretation remains structurally plausible. Correctability therefore concerns exposure to evidence, revision, and defeat conditions, not compulsory agreement with the analysis.

Chapter 18 will develop boundary conditions, rival explanations, and falsifiers in full. Here the methodological rule is enough: every EDEN reading must remain answerable to a counter-scene that could change it.

### 2.6 Analyst Guardrail

The counter-scene requirement also applies to the analyst. EDEN can identify drift without assuming that the analyst is drift-free. It can name false coordination without claiming total legibility. It can demand reciprocity without pretending already to stand outside the conditions under which reciprocity is lost.

The analyst does not stand outside Ω (asymmetry), □ (frame), Φ (recontextualization), Χ (distance), or Α (attractor). The analyst reads from within a learned field of visibility, comparison susceptibility, partial legibility, and possible responsibility displacement. This does not make analysis impossible. It makes self-binding necessary.

The guardrail is therefore not a humility decoration. It follows from EDEN’s own object. If reciprocity loss occurs where real asymmetry is falsely coordinated, responsibility is displaced, Σ (integration) / Ψ (self-binding) are blocked, and correctability erodes, then the use of EDEN can also become part of such a loss. A theory about immunization can immunize itself. A theory about false comparison can become a superiority frame. A theory about responsibility can become accusation. A theory about dignity-in-practice can become degradation if it abandons D (dignity-in-practice) in use.

This is why EDEN must remain revisable at the point of analysis. The analyst must remain able to ask whether the scene has been overread, whether a counter-scene fits better, whether responsibility has been assigned too quickly, whether vulnerability or protection is genuine, whether a rival explanation is stronger, and whether the language of structure has begun to function as a verdict. Analysis must remain answerable to the same reciprocity it describes.

This guardrail also protects the transition from method to theory. Chapter 2 has not supplied an application manual. It has supplied a disciplined way to read: begin with structure rather than psychology, distinguish description from application, require a scene packet, pass the validity gate before binding use, preserve counter-scene exposure, and keep the analyst within the field being analyzed.

With this method in place, the argument can return to the positive benchmark: Adult Reciprocity not as symmetry, harmony, or equal burden, but as the truthful coordination of real asymmetry under responsibility, integration, self-binding, revisability, and dignity-in-practice.

---

## 3. Adult Reciprocity: Coordinated Real Asymmetry, Not Symmetry

### 3.1 Definition of Adult Reciprocity

After the thesis and the method have been established, the positive benchmark can be stated in full. Adult Reciprocity is not symmetry, harmony, sameness, equal burden, or the disappearance of asymmetry. It is the truthful coordination of real Ω (asymmetry).

“Adult” is used stipulatively for structural answerability under real asymmetry, not for biological age, psychological maturity, moral superiority, or relationship advice. Adult Reciprocity is an operator-traceable EDEN definition and an explicitly normative benchmark, not a PMS-derived axis, empirical typology, or claim that such coordination ordinarily occurs. “Truthful coordination” means that the operative frame remains answerable to traceable asymmetry, structuring effect, cost, and responsibility; it does not claim total access or metaphysical truth. Reciprocity Loss and failure are correspondingly EDEN-definitional and evaluative relative to this benchmark, not natural dysfunctions or pathologies. Whether a particular scene realizes or fails the benchmark remains a descriptive claim requiring scene-bound evidence.

Adult Reciprocity ≠ symmetry.
Adult Reciprocity = truthful coordination of real Ω (asymmetry).

This means that Adult Reciprocity begins where real asymmetry can remain visible without being converted into rank, denied as irrelevant, hidden under formal equality, or displaced into one-sided burden. A reciprocal scene is not one in which the participants carry the same cost, possess the same capacity, occupy the same exposure, or bear identical responsibility. It is a scene in which real Ω (asymmetry) can be named, carried, integrated, revised, and self-bound without humiliation, immunity, or domination.

The full positive structure can be stated as follows:

Adult Reciprocity =
real Ω (asymmetry) visible
+ D (dignity-in-practice) preserved
+ R (responsibility) follows real structuring effect
+ Σ (integration) integrates costs and effects
+ Ψ (self-binding) binds relevant actors to their own effect
+ Χ (distance) keeps revision possible.

Each element matters. If real Ω (asymmetry) is not visible, the scene cannot coordinate what actually structures it. If D (dignity-in-practice) is not preserved, responsibility becomes degradation or protection becomes immunity. If R (responsibility) does not follow real structuring effect, burden and answerability separate. If Σ (integration) cannot integrate costs and effects, the scene may remain rhetorically coherent while its real consequences are displaced. If Ψ (self-binding) does not bind role-positions to their own structuring effects, one side may have to organize itself around the other side’s non-binding. If Χ (distance) is absent, correction collapses into fusion, urgency, threat, or verdict.

Adult reciprocity therefore does not require equal burdens. It requires non-externalization of unequal burdens. Unequal cost, unequal exposure, unequal vulnerability, unequal protection, unequal access, or unequal responsibility may be real. The decisive question is whether such unevenness can remain speakable and answerable inside the scene. False coordination begins where unequal burden remains operative while being made invisible, naturalized, moralized, protected from critique, or shifted onto another role-position.

This is why Adult Reciprocity is not an ideal of comfort. It may include conflict, correction, asymmetry, disappointment, limitation, and unequal responsibility. What makes it adult is not the absence of tension, but the presence of coordinated answerability under real Ω (asymmetry). The scene remains reciprocal where costs can be named, effects can be traced, responsibility can follow effect, integration remains possible, self-binding is not externalized, and revision remains open.

The positive structure of Adult Reciprocity also sets the standard for failure. Reciprocity is not lost because asymmetry appears. It is lost where real Ω (asymmetry) can no longer be truthfully coordinated: where dignity becomes immunity or degradation, responsibility no longer follows effect, integration becomes simulation, self-binding is displaced, and distance no longer keeps correction possible. The paper’s drift concepts become legible only against this positive benchmark.

### 3.2 Recognition plus Responsibility

Adult Reciprocity requires recognition, but recognition alone is not enough. A role-position is not fully recognized as adult if it is protected from criticizability, shielded from consequence, or exempted from answerability for its structuring effect. Recognition becomes hollow where it grants standing without responsibility.

The inverse is equally important. Responsibility without recognition becomes domination. If a role-position is held answerable without dignity, without agency, without the possibility of correction, or without protection from degradation, then responsibility becomes humiliation rather than adult coordination. Adult Reciprocity therefore requires recognition and responsibility together.

Recognition plus responsibility is the adult hinge.

Recognition without answerability is not equal standing.

This formulation does not make recognition secondary. It protects recognition from becoming merely symbolic. To recognize a role-position as adult is to treat it as capable of self-binding, capable of criticizability, and capable of carrying consequence without being reduced to guilt, essence, or inferiority. Recognition that cannot include responsibility does not fully recognize agency; it only protects appearance.

Nor does this formulation make responsibility punitive. Responsibility, in this structure, is not blame, moral worth, inner guilt, or person condemnation. It is the relation between real structuring effect and answerability under the conditions of a scene. A role-position can be responsible for an effect without being morally condemned as a person. Conversely, a role-position can be recognized without being excused from the effects it structures.

This hinge is especially important under real Ω (asymmetry). Where exposure, cost, access, protection, recognition, or correction are unevenly distributed, recognition and responsibility can easily split. One side may receive recognition without corresponding answerability; another may receive responsibility without sufficient recognition. Adult Reciprocity holds the two together: recognition must not become immunity, and responsibility must not become degradation.

Recognition-without-Responsibility and Pseudo-Equal Standing name negative shadows of this positive structure rather than the subject developed here. The benchmark is exact: adult recognition includes criticizability, and adult responsibility preserves dignity-in-practice.

The result is a sharper concept of equal standing. Equal standing is not sameness, identical obligation, formal symmetry, or protection from critique. It is the shared status of being recognizable and answerable without humiliation. In an adult reciprocal scene, no role-position is reduced to its burden, but no role-position is freed from its structuring effect merely because responsibility is costly to name.

### 3.3 Dignity-in-Practice

Dignity-in-practice belongs inside Adult Reciprocity because real asymmetry cannot be coordinated truthfully if the scene protects responsibility by degrading the person, or protects dignity by removing criticizability. D (dignity-in-practice) is not a metaphysical ranking of persons, and it is not a shield against structural critique. It is the praxeological restraint required when a scene is organized under real Ω (asymmetry).

Its formal, normative, and descriptive statuses must remain distinct. D = Ψ ∘ Χ ∘ Ω is a formally derived PMS axis; that derivation identifies a structural configuration but does not by itself establish normative authority, empirical universality, or a natural law. EDEN explicitly adopts the preservation of D as a definitional and normative condition of Adult Reciprocity. Where structural description becomes application, D also functions as an application-only validity condition. Whether dignity-in-practice is preserved or damaged in a particular scene remains a descriptive claim requiring scene-bound evidence.

The positive formula is:

Dignity-in-practice =
protection from degradation
+ recognition of agency
+ criticizability without humiliation
+ responsibility without domination.

Each element is necessary. Protection from degradation means that a role-position must not be reduced to worthlessness, essence, pathology, inferiority, or sexed moral type when its structuring effect is named. Recognition of agency means that the role-position is not treated as a mere object of protection, explanation, or management. Criticizability without humiliation means that structural responsibility can be named without converting critique into personal degradation. Responsibility without domination means that answerability must not become coercive control.

This gives dignity-in-practice its double edge. Dignity is not immunity. Responsibility is not degradation. A scene fails adult reciprocity if dignity becomes protection from all critique. It also fails if responsibility becomes permission to humiliate. Adult Reciprocity requires a middle structure: the role-position remains protected from degradation precisely while remaining open to criticizability.

The distinction matters because critique can be degrading, but critique is not degrading as such. A critique becomes degrading when it attacks personhood, moral worth, sex, essence, or standing rather than naming a scene-bound structuring effect. But a critique is not degrading merely because it names displaced responsibility, blocked Σ (integration) / Ψ (self-binding), or a failure of answerability. If dignity were defined as protection from all structural critique, dignity itself would become a responsibility shield.

Conversely, responsibility must remain dignity-preserving. To hold a role-position answerable is not to deny its agency, vulnerability, or standing. It is to treat that position as capable of carrying its own effect without being reduced to guilt or essence. Adult Reciprocity therefore refuses both false alternatives: responsibility without dignity and dignity without responsibility.

This also clarifies why structure critique is not person threat. EDEN may say that a configuration displaces responsibility, blocks integration, weakens self-binding, or externalizes cost. That is not the same as saying that a person is inferior, pathological, malicious, or morally defective. Dignity-in-practice protects this distinction. It allows EDEN to name structure sharply without turning the name into a wound.

This distinction also constrains immunization, overexposure, recognition drift, and their boundary conditions: dignity may not be used to block responsibility, and responsibility may not be used to damage dignity. The positive condition is exact: Adult Reciprocity requires dignity that remains criticizable and responsibility that remains non-degrading.

### 3.4 The Role of Σ

If dignity-in-practice protects the manner in which asymmetry is handled, Σ (integration) names the condition under which the real effects of a scene can be brought into shared coordination. Integration is not surface coherence, conflict suppression, agreement, narrative closure, or the appearance of order. It is the capacity of a scene to take in its real costs, exposures, responsibilities, and asymmetries without denial, displacement, or humiliation.

Σ (integration) integrates costs and effects.

This means that Adult Reciprocity requires more than the continued functioning of a scene. A relation may continue, a frame may hold, a role may be performed, and a conflict may be avoided while the real cost of the arrangement remains unintegrated. Where cost is carried but not named, where exposure is endured but not made legible, where responsibility is felt but not traceable, or where asymmetry remains active but cannot enter the shared frame, the scene may remain stable without being reciprocal.

Integration also differs from justification. A scene can justify its structure without integrating its effects. It can explain why a burden is necessary, why a role must carry more, why a protection is needed, or why a cost cannot be avoided, while still failing to integrate what that structure actually produces. Justification becomes insufficient where it leaves the affected cost outside the shared field of answerability.

For this reason, Σ (integration) is inseparable from R (responsibility). If responsibility does not follow real structuring effect, integration becomes partial or simulated. The scene may integrate the story it tells about itself, but not the cost it distributes. It may integrate recognition language while leaving answerability displaced. It may integrate protection language while making criticizability impossible. Adult Reciprocity requires the effect itself to become integrable, not merely the frame that explains it.

Σ (integration) is also inseparable from Ψ (self-binding). A cost can enter the shared frame only if the relevant role-positions can bind themselves to their own effects. Without self-binding, one side may be left to integrate what the other side refuses to carry. The result is not genuine integration, but transferred integration-load: one role-position stabilizes the scene by absorbing what another does not bind.

This is why integration cannot be reduced to peace, agreement, or affective calm. A scene may be calm because the cost has been silenced. It may be peaceful because one role-position has stopped naming the burden. It may appear coherent because the asymmetry has been naturalized. None of this is Σ (integration) in the adult sense. Integration requires that the relevant cost, effect, and responsibility can become speakable inside the scene without being converted into threat, humiliation, or immunity.

Integration may be simulated, replaced by legitimation, or blocked under false coordination. Those drift forms do not alter the positive requirement: Adult Reciprocity depends on a scene’s ability to integrate real Ω (asymmetry), real cost, and real structuring effect into shared answerability without losing dignity-in-practice.

### 3.5 The Role of Ψ

Adult Reciprocity requires more than the visibility of asymmetry, the preservation of dignity, and the integration of costs. It also requires Ψ (self-binding): the capacity of a role-position to bind itself to its own structuring effect. Without self-binding, responsibility may be recognized in principle while remaining displaced in practice.

Adult Ψ (self-binding) begins as self-binding, not other-binding.

This distinction is decisive. Self-binding does not mean that one role-position binds another into compliance, silence, repair, explanation, or emotional management. It means that a role-position takes up its own effect as something to which it remains answerable. In an adult reciprocal scene, one does not merely ask whether the other can absorb, understand, tolerate, or compensate for what one structures. One asks whether one remains bound to the cost, exposure, delay, withholding, recognition, protection, or burden one helps produce.

This does not make every effect culpable. Ψ (self-binding) is not guilt, confession, self-punishment, or moral self-condemnation. It is the praxeological capacity to remain attached to the consequences of one’s role-position without immediately externalizing them. A role-position may structure a cost unintentionally, under pressure, with limited knowledge, or without malicious aim. Adult Reciprocity does not require perfect control. It requires that the structuring effect not be disowned merely because it is costly to recognize.

The absence of self-binding has a relational consequence. Where one side does not bind itself to its own structuring effect, the other side often has to carry more than its own share of interpretation, integration, anticipation, repair, or restraint. The formula is simple:

low Ψ (self-binding) on one side
→ increased Ψ-load on the other.

This is not yet the full theory of non-binding, and it is not the full account of No Passive Praxis. Those later chapters will ask when non-action, withholding, delay, refusal, or openness becomes structurally relevant. Chapter 3 makes only the positive claim: Adult Reciprocity requires each relevant role-position to carry its own effect rather than making another position organize itself around one’s non-binding.

Ψ (self-binding) therefore protects reciprocity from a subtle displacement. A scene may preserve recognition language, dignity language, equality language, or even responsibility language while still leaving one side to stabilize what the other does not bind. In such a scene, the burden is not always visible as command or domination. It may appear as openness, fragility, uncertainty, exception, or non-decision. But if one role-position’s low self-binding increases the other’s self-binding load, Adult Reciprocity is already under strain.

Self-binding must also remain distinct from rigidity. Adult Ψ (self-binding) is not stubborn consistency, inflexible commitment, or refusal to revise. A role-position can bind itself to its own effect while also changing its understanding of that effect. In fact, self-binding requires this openness. To bind oneself adultly is not to defend one’s first interpretation; it is to remain answerable as the scene becomes more legible.

This is where Ψ (self-binding) requires Χ (distance). Without distance, self-binding can collapse into shame, fusion, defensiveness, or self-protection. With distance, a role-position can remain bound to its own effect without turning responsibility into self-condemnation or critique into threat. Adult Reciprocity therefore requires self-binding that is answerable, revisable, and dignity-preserving.

### 3.6 The Role of Χ

Χ (distance) is the condition that keeps Adult Reciprocity from collapsing into immediacy, fusion, threat, or verdict. It is not detachment from responsibility. It is the distance that allows responsibility to remain revisable, criticizable, and dignity-preserving.

In Adult Reciprocity, Χ (distance) keeps correction possible. A scene structured by real Ω (asymmetry) is never fully transparent to itself. Costs may become legible late. Effects may appear differently from different role-positions. A protection may later show a responsibility-displacing effect. A vulnerability may be genuine in one respect and immunizing in another. A silence may be restraint, avoidance, or a structuring non-event depending on the scene. Without distance, the first available reading can harden into verdict before the scene has become sufficiently legible.

Χ (distance) therefore serves both accuracy and restraint. It allows a reading to be held without being immediately enforced. It allows responsibility to be named without becoming humiliation. It allows critique to occur without becoming a threat to personhood. It allows a role-position to revise its self-understanding without losing standing. Distance is not a refusal to bind; it is what makes self-binding adult rather than reactive.

This is also why Χ (distance) belongs inside the positive structure of Adult Reciprocity, not only inside the method of application. Chapter 2 established that application requires Χ, reversibility, D (dignity-in-practice), and contextual responsibility. Chapter 3 adds the positive reason: adult coordination itself requires distance because real asymmetry, real cost, and real responsibility need time and space to become legible without being denied or weaponized.

Χ (distance) also protects recognition and responsibility from splitting. Without distance, recognition may become defensive protection from critique, and responsibility may become immediate accusation. With distance, recognition can include criticizability, and responsibility can preserve dignity. The scene can ask what has been structured without reducing the answer to guilt, motive, or personhood.

This does not mean that Adult Reciprocity suspends all judgment forever. Χ (distance) is not endless postponement, evasion, or neutrality. It keeps revision possible so that judgment, responsibility, and correction remain scene-bound rather than fused with urgency or identity. Distance allows a reading to become stronger where the scene supports it, weaker where counter-scene changes it, and suspended where the conditions are not yet sufficient.

The positive function of Χ (distance) can therefore be stated simply: it keeps Adult Reciprocity correctable. It prevents real Ω (asymmetry) from being flattened too quickly, responsibility from becoming verdict, dignity from becoming immunity, and self-binding from becoming shame. Where distance disappears, correction may still happen, but it becomes more likely to happen as force, withdrawal, humiliation, or defensive refusal rather than as shared adult coordination.

With Ψ (self-binding) and Χ (distance) in place, the positive structure is nearly complete. Adult Reciprocity requires real asymmetry to remain visible, dignity to be preserved, responsibility to follow structuring effect, integration to take in cost and consequence, self-binding to prevent displaced burden, and distance to keep correction revisable. The final step is to state the failure condition that follows from this structure.

### 3.7 Failure Condition

The positive structure of Adult Reciprocity now yields its failure condition. If Adult Reciprocity is the truthful coordination of real Ω (asymmetry), then its failure does not begin with asymmetry itself. It begins when real asymmetry continues to structure the scene while the conditions of adult coordination can no longer follow it.

The failure condition can be stated as follows:

Where real Ω (asymmetry) structures the scene
but D (dignity-in-practice) cannot be preserved,
R (responsibility) cannot follow real structuring effect,
Σ (integration) cannot integrate costs and effects,
Ψ (self-binding) cannot bind role-positions to their own effects,
and Χ (distance) cannot keep revision possible,
Adult Reciprocity begins to fail.

This formula does not yet describe the full mechanics of reciprocity loss. It identifies the threshold at which the positive benchmark begins to break down. A scene may remain formally equal, emotionally intense, morally serious, socially legitimate, or rhetorically coherent while adult coordination is already weakening. The question is whether real Ω (asymmetry) can still be named, carried, integrated, self-bound, corrected, and handled without degradation or immunity.

The failure signatures can therefore be grouped as follows:

recognition or protection without criticizability and responsibility;
responsibility or critique without dignity and self-restraint;
vulnerability or formal equality detached from cost-truth and self-binding;
structuring non-action or non-binding without ownership of effect;
legitimation without integration.

None of these elements is a failure by category. Recognition, protection, vulnerability, equality, non-action, openness, and legitimation may all be valid. They become failure signatures only where real structuring effect remains active while answerability, integration, self-binding, correction, or dignity-preserving restraint can no longer follow it. The later drift mechanisms remain dependent specifications of this benchmark rather than independent origins.

The failure condition also preserves the paper’s central restraint. A scene does not fail Adult Reciprocity because one side is morally defective, psychologically diagnosable, sexually fixed, or essentially superior or inferior. It begins to fail where real Ω (asymmetry) remains active while D (dignity-in-practice), R (responsibility), Σ (integration), Ψ (self-binding), and Χ (distance) can no longer coordinate it truthfully. The object remains structural, scene-bound, and revisable.

With the positive benchmark now established, the paper can turn to the field in which legibility itself is learned. Adult Reciprocity does not appear in an empty space. It depends on what a scene can recognize, name, protect, expose, compare, and correct. Chapter 4 therefore turns to the Garden: not as Eden, not as origin, but as the learned legibility-field in which real asymmetry first becomes coordinable or miscoordinable.

---

## 4. The Garden: Socialization into Stabilized Praxis

### 4.1 The Garden as Praxis Field

Adult Reciprocity does not appear in an empty space. It requires a field in which recognition, responsibility, correction, distance, and self-binding can become learnable at all. Chapter 4 names this field the Garden.

Chapter 4 develops the Garden as a theoretical reconstruction of socialization through stabilized praxis. It does not establish an empirically verified developmental sequence, a prevalence claim, or an exhaustive sociology of socialization. Its propositions specify structural relations within EDEN’s model; whether and how such configurations occur across particular persons, institutions, cultures, or histories requires independent empirical inquiry.

The Garden is not Eden. It is not paradise, innocence, pure reciprocity before society, or the paper’s origin. It is not a theological scene and not a fall narrative. The Garden is a learned legibility-field: the praxis field in which actors learn what can be seen, named, trusted, feared, protected, exposed, corrected, and carried.

Garden = learned legibility-field.

Within this reconstruction, the field is difficult to see because it is where seeing was learned. The account does not begin from actors standing outside praxis and then choosing how to enter it. It treats perception, response, shame, trust, distance, responsibility, recognition, role, exposure, and self-binding as learned inside already stabilized fields of action and expectation. What becomes obvious inside such a field may appear obvious because the field has already shaped how obviousness becomes available.

This is why the Garden matters for Adult Reciprocity. On this account, reciprocity is learned before the reciprocity of the structures that teach it can be examined. Actors learn how to recognize and be recognized, how to answer and be answered, how to trust correction or fear it, and how to carry cost or displace it before they can ask whether those learning structures were themselves reciprocal. The Garden is therefore not a lost origin. It is the modeled prior field of learned legibility through which later scenes become readable.

The Garden also explains why reciprocity cannot be treated as a purely individual achievement. A role-position does not invent recognition, responsibility, or correction alone. It inherits patterns for making them legible. These patterns may support Adult Reciprocity by making responsibility recognizable, dignity-in-practice learnable, and correction possible. They may also limit Adult Reciprocity by making some costs unspeakable, some burdens normal, some protections unquestionable, or some asymmetries invisible.

This does not make the Garden guilty. It makes it ambivalent. The same field that teaches coordination can also teach blindness. The same stabilized praxis that makes recognition possible can make some forms of responsibility hard to name. The same shared expectations that allow trust can also make unequal cost appear ordinary. Chapter 4 therefore does not accuse the Garden. It makes visible the condition under which later limited legibility can emerge.

The analyst is not outside this field. EDEN does not look at the Garden from a pure standpoint beyond learned visibility. It also reads from within a field that has taught it what counts as structure, responsibility, exposure, correction, and blindness. This is why the methodological guardrail from Chapter 2 continues to matter here: a theory of reciprocity loss must remain answerable to reciprocity in its own use.

### 4.2 Learning to Be Human

Human actors do not enter a neutral world. They enter stabilized praxis fields in which perception, response, expectation, shame, trust, distance, responsibility, and self-binding have already begun to take form. To learn to be human is not merely to acquire information or obey external rules. It is to be formed inside repeated structures of recognition, cost, protection, exposure, correction, and role.

This formation can be stated in two EDEN compression formulas:

Society = stabilized praxis.
Personality = internalized praxis.

These are theoretical structural compressions, not PMS equations or derived axes, an empirically established developmental sequence, an exhaustive sociology, or a personality psychology. Society names praxis that has become repeatable enough to orient action, store expectations, stabilize roles, and make responsibility recognizable. Personality here names a durable internalized praxis orientation through which expectations and response patterns become structurally available. It does not name an inner essence, a personality type, or an inferred mental state.

Internalized praxis is not mere obedience. It is not simply imitation, indoctrination, adaptation, or biological destiny. It is the formation of a world-sense: what appears possible, what appears shameful, what appears dangerous, what appears responsible, what appears normal, what appears criticizable, and what appears beyond question. Human formation occurs where repeated praxis becomes perception.

This is why human formation is structurally relevant without becoming developmental psychology. Chapter 4 does not ask how a person became this or that type. It asks how a praxis field forms the conditions under which role-positions can later recognize, misrecognize, carry, deny, or revise real Ω (asymmetry). The issue is not childhood, personality diagnosis, or individual defect. The issue is learned legibility.

Once praxis has been internalized, actors do not merely follow norms from the outside. They perceive through them. They expect through them. They fear and trust through them. They become capable of responsibility through them, but also limited by what those structures made responsibility mean. The field that makes coordination possible also marks the boundary of what appears coordinable.

This does not eliminate responsibility. It explains why responsibility becomes difficult to coordinate under stabilized fields. A role-position may inherit expectations it did not invent, but it may still structure effects through them. A scene may repeat a pattern no one consciously designed, while still distributing cost, protection, recognition, and exposure unevenly. Human formation therefore does not replace responsibility with causation. It gives responsibility a field.

The Garden is thus both condition of humanity and source of blindness. It is where actors learn to see, trust, fear, answer, withhold, repair, distance, and bind themselves. It is also where they learn not to see certain costs, not to name certain asymmetries, not to hear certain claims as claims, and not to experience certain burdens as burdens. This double structure prepares the next step: stabilization is necessary, but it is never innocent.

### 4.3 The Ambivalence of Stabilization

Stabilization is necessary because praxis cannot remain entirely improvised. Human actors need repeatable expectations, recognizable roles, learned forms of trust, shared memory, coordinated skills, and durable ways of making responsibility visible. Without stabilization, every scene would have to begin again from nothing; recognition, correction, and self-binding would have no reliable field in which to become learnable.

Stabilization is therefore ambivalent, not guilty.

It enables coordination, memory, roles, trust, skill, shared expectations, and recognizable responsibility. A stabilized praxis field allows actors to know what counts as a promise, a refusal, an obligation, a protection, a cost, a correction, or a role. It makes social life possible because it reduces the burden of having to renegotiate every meaning in every scene.

But stabilization also carries risk. What becomes repeatable can become difficult to question. What becomes normal can make its cost structure disappear. What becomes trusted can become protected from revision. What becomes a role can become a rank artifact. What becomes a shared expectation can make asymmetric burden appear natural, necessary, or invisible. Stabilization can therefore produce path-dependence, rigidity, invisible costs, blocked revision, asymmetric normality, and legibility poverty.

The ambivalence can be stated as follows:

Stabilized praxis increases coordination capacity,
but lowers dynamic reversibility once Α (attractor) patterns protect themselves under Ω (asymmetry) / Θ (temporality).

This does not mean that structure is the problem. Structure is the condition of learnable coordination. The danger begins when stabilized structure becomes insufficiently correctable: when a pattern continues to coordinate action while no longer integrating its cost, when it preserves roles while hiding what those roles distribute, or when it protects its own repetition against the real asymmetry it organizes.

The same stabilization that makes Adult Reciprocity possible can therefore make its failures difficult to see. A field may teach recognition while limiting what can count as responsibility. It may teach protection while making some costs unspeakable. It may teach trust while making some exposure normal. It may teach correction while defining only some role-positions as criticizable. Stabilization does not cause reciprocity loss by itself, but it can make later loss appear ordinary.

Limited Legibility is therefore not merely an individual lack of information. It can be formed by stabilized praxis fields that have already taught actors what is visible, what is doubtful, what is dangerous to name, and what is too normal to question. The recursive relation is decisive: the field forms actors, and actors reproduce the field that formed them.

### 4.4 Recursive Formation

The Garden is not simply prior to human actors, and human actors do not simply invent the Garden from outside. The relation is recursive. Actors are formed by stabilized praxis fields, and those fields are reproduced, modified, or hardened through the actions, expectations, omissions, recognitions, and adaptations of actors.

This recursion avoids two false explanations. It does not say that society alone produces the human being, as if actors were merely passive products of a field. It also does not say that human nature alone produces society, as if stabilized praxis were merely the outward expression of fixed inner essence. The relation is structural: role-positions are formed inside fields that they also help reproduce.

A compressed sequence is useful here:

anthropological disposition
→ repeated praxis
→ social frame
→ adaptive pressure
→ internalized disposition
→ reproduced praxis.

This sequence is not a causal origin story. It names a recursive loop. A disposition becomes socially meaningful only through repeated praxis. Repeated praxis becomes socially durable through frames, expectations, and roles. Those frames create adaptive pressure: actors learn what is rewarded, punished, trusted, ignored, protected, or made costly. Over time, adaptation becomes internalized disposition. What was first encountered as field becomes part of how the actor sees, expects, fears, trusts, answers, and withholds.

Recursive formation therefore operates under □ (frame), Α (attractor), Θ (temporality), and Ω (asymmetry). Frames make some meanings stable. Attractors make some repetitions easier than alternatives. Temporality allows earlier solutions to become later conditions. Asymmetry means that not all role-positions participate in the loop at equal cost, equal exposure, equal protection, or equal ability to revise what has been stabilized.

The human being produces the environment that produces the human being — but not symmetrically, not fully consciously, and not under equal costs.

This sentence is central. It prevents the Garden from becoming either destiny or accusation. Actors are not outside the structures that form them, but neither are they nothing but products of those structures. Fields are not innocent, but they are not villains. Recursive formation means that responsibility must be thought under conditions of inherited legibility, adaptive pressure, and uneven cost. It also means that correction is possible, but never from nowhere.

The recursive structure also explains why some social forms can remain stable even when they have become costly. A solution that once increased coordination may become a condition that later restricts revision. A role that once made responsibility recognizable may later distribute burden unevenly. A frame that once protected dignity may later protect a position from criticizability. A pattern that once solved a problem may become the reason the next problem cannot yet be named.

Chapter 4 does not turn this into a general social theory. Its claim is narrower: Adult Reciprocity is learned inside fields whose own reciprocity is not immediately transparent. Because formation is recursive, the structures that teach recognition, responsibility, and correction may also stabilize the blind spots that later make recognition, responsibility, and correction difficult. This is why society can now be described, in the next step, as stabilized praxis rather than as an external container around praxis.

### 4.5 Society as Stabilized Praxis

Society can now be described in the compressed terms already introduced: society is stabilized praxis. This does not mean that society is an external object placed around praxis, nor that society is a separate force acting on otherwise unformed individuals. It means that repeated praxis becomes durable enough to store expectations, roles, permissions, prohibitions, recognitions, burdens, protections, and forms of responsibility.

Society = stabilized praxis.
Personality = internalized praxis.

The two formulas belong together. Stabilized praxis gives actors a world in which action can become recognizable. Internalized praxis gives actors dispositions through which that world becomes expected from within. Society stores solutions; personality carries those solutions as perception, anticipation, shame, trust, confidence, hesitation, distance, responsibility, and self-binding.

This is not a theory of fixed personality types. Personality, in this usage, does not name a diagnostic category or an inner essence. It names the internalization of repeated praxis fields. A person becomes able to move in a world because some patterns have already become familiar enough to guide perception and response. What is learned is not only what to do, but what counts as possible, costly, exposed, responsible, shameful, safe, criticizable, or unavailable to critique.

Society stores solutions by making them repeatable. A role that solves a coordination problem can become normal. A frame that reduces uncertainty can become common sense. A protection that stabilizes trust can become expected. A distribution of responsibility that once made action possible can become the background through which later action is judged. This is how stabilized praxis lowers the burden of orientation: actors do not have to invent the field anew each time they enter a scene.

But stored solutions also store their cost structure. A solution may preserve coordination while hiding who carries the burden of that coordination. It may make one form of exposure recognizable while making another appear ordinary. It may make one role-position criticizable while treating another as protective, fragile, neutral, or unavailable. What becomes normal does not thereby become reciprocal. Normality can preserve real Ω (asymmetry) while making the asymmetry difficult to see.

This is why society is neither villain nor excuse. Stabilized praxis is necessary for coordination, but it can also make later correction difficult. The field may teach actors how to recognize responsibility, while also teaching them which responsibilities are not usually named. It may teach dignity, while also teaching which forms of degradation do not count as degradation. It may teach equality, while also making some unequal costs appear too normal to register.

The relation between society and personality therefore matters for the paper’s later argument. When reciprocity becomes difficult, the difficulty is not always located in a single intention, a single belief, or a single explicit rule. It may lie in stabilized praxis that has become perception itself. What is repeated becomes legible; what is carried may become invisible. This prepares the next problem: the very structures that solve coordination problems can later reduce the reversibility needed for correction.

### 4.6 Problem-Solving and Inflexibility

Praxis stabilizes because problems need solutions. A field that cannot repeat any solution cannot build trust, skill, role, memory, or recognizable responsibility. Stabilization therefore increases collective capacity: it allows actors to rely on prior coordination rather than rebuilding every scene from the beginning.

A solution becomes powerful when it can be repeated. Repetition makes the solution available before the problem is fully rethought. It allows a role to be performed, a frame to be recognized, a burden to be assigned, a protection to be trusted, or a correction to be expected. In this sense, stabilization is not merely conservative. It is the condition under which practical intelligence becomes socially available.

But repeatability has a cost. Once a solution becomes an Α (attractor), it can begin to protect its own repetition. The field becomes more capable because it no longer has to reconsider everything; it becomes less reversible because some arrangements now appear given before they are examined. Under Θ (temporality), what once solved a problem can become the condition that defines what later counts as a problem.

The sequence can be stated simply:

problem
→ repeated solution
→ stabilized expectation
→ Α (attractor)
→ path-dependence under Θ (temporality)
→ reduced reversibility.

This sequence does not make attractors bad. It shows why solutions can become difficult to revise. A pattern may continue to coordinate action long after its cost structure has changed. A role may still organize responsibility while no longer distributing it truthfully. A frame may still make the scene intelligible while blocking the terms needed to name what the scene now produces. In such cases, the problem is not stabilization as such, but stabilization that cannot remain answerable to its own effects.

Reduced reversibility matters for Adult Reciprocity because reciprocity requires correction. If a stabilized solution makes cost speakable, responsibility traceable, and self-binding possible, it can support adult coordination. If the same solution later makes cost unspeakable, responsibility displaced, or self-binding one-sided, it begins to obstruct the conditions that made it valuable. What once made coordination possible can later make correction harder.

This is the inflexibility of solved problems. A solved problem does not disappear; it becomes a structure. That structure may keep working, but it may also make new problems appear as deviations, threats, ingratitude, weakness, or illegibility. The more a solution has stabilized a field, the harder it can become to see the costs created by the solution itself.

Χ (distance) is therefore needed not only in interpersonal correction, but also in relation to stabilized praxis. A field needs enough distance from its own solutions to ask what they now distribute, what they hide, whose burden they normalize, and whether the responsibilities they organize still follow real effect. Without such distance, problem-solving becomes inflexibility: the field can still repeat its answer, but it can no longer hear the new question.

Chapter 4 does not turn this into a general theory of institutions. Its claim remains narrower. Adult Reciprocity depends on learned structures that make coordination possible, but those same structures can lower dynamic reversibility when their solutions become protected by repetition, role, expectation, and time. Where a need for change grows while the means of change weaken, the next problem appears: necessity becomes felt before it can be coordinated.

### 4.7 Necessity and Powerlessness

The inflexibility of solved problems produces a specific structural condition: the need for change can grow while the means of change weaken. A field may continue to repeat an inherited solution even after the problem it once solved has changed. The pressure for correction increases, but the available forms of recognition, language, trust, distance, and coordination may no longer be sufficient to carry that correction.

Structural powerlessness arises where necessity becomes felt but cannot yet be coordinated.

This is not weakness, passivity, failure of will, or psychological helplessness. It is a condition of praxis. A role-position may feel that something has become necessary before the scene has the concepts, roles, trust, distance, or shared responsibility needed to make that necessity coordinable. The pressure is real, but the field has not yet learned how to recognize it as a legitimate object of coordination.

A structurally relevant reason for change may become legible only after the means of change have already been damaged. A stabilized praxis field may still explain itself in inherited terms while failing to coordinate the new problem it now produces. Its older solutions may continue to name duty, protection, responsibility, equality, or loyalty, while leaving the emerging cost outside the shared field of answerability.

This is why structural powerlessness is closely tied to path-dependence. Under Α (attractor) / Θ (temporality), a repeated solution can become easier to reproduce than to revise. The field keeps returning to the old answer because the old answer is legible, trusted, and socially available. At the same time, the pressure that now requires a different answer may remain too diffuse, costly, or illegible to become a shared problem.

Old frames can also explain new pressures badly. A □ (frame) may still make the scene intelligible while translating a new cost into an older category: weakness, exaggeration, disloyalty, ingratitude, overreaction, failure, or exception. Φ (recontextualization) may then move the pressure away from the structure that produces it and toward the role-position that names it. The field remains coherent, but its coherence no longer coordinates the necessity it faces.

This does not remove responsibility. It changes the conditions under which responsibility can be traced. A role-position may reproduce a structure it did not invent, and a field may distribute cost without any single actor designing the distribution. Yet the effects remain real. Structural powerlessness names the gap between felt necessity and available coordinability; it does not turn that gap into innocence, excuse, or verdict.

The claim remains narrow. It does not develop overexposure, asymmetric explanatory poverty, or stabilized regime forms. It identifies the transition at which a field’s inherited solutions can no longer coordinate the pressure they generate and blind spots become structurally decisive.

### 4.8 Blind Spot Formation

Blind spots do not form outside learned legibility. They form inside it. A field teaches actors what to see, what to ignore, what to trust, what to fear, what to name, and what to treat as normal. For that reason, blindness is not ignorance alone. It is often the effect of having learned to see too well within a stabilized field.

The blind spot is not ignorance alone.
It is learned legibility under stabilized Ω (asymmetry), □ (frame), and Θ (temporality).

This formulation matters because it prevents a moralized account of blindness. A blind spot is not simply stupidity, bad faith, guilt, pathology, or refusal. It may arise where the field has made some costs ordinary, some asymmetries backgrounded, some responsibilities difficult to name, and some corrections appear dangerous or unintelligible. The actor does not merely fail to see; the field has taught what seeing is supposed to look like.

The Garden is therefore both condition of humanity and source of blindness. It makes recognition, trust, responsibility, shame, correction, distance, and self-binding possible. But it also stabilizes what counts as recognizable, trustworthy, responsible, shameful, correctable, distant, or binding. What the Garden makes learnable, it may also make difficult to question.

This double role does not excuse responsibility. A learned blind spot can still structure real effects. A role-position may fail to see a cost and still participate in distributing it. A field may make a burden invisible and still make someone carry it. Structural blindness explains why responsibility becomes difficult to coordinate; it does not erase the structuring effect that calls for responsibility.

Nor does blind spot formation make EDEN a superior standpoint outside the field. The analyst is not outside the Garden. The concepts of structure, responsibility, asymmetry, correction, and blindness are also learned within fields of legibility. This is why counter-scene, reversibility, distance, and dignity-in-practice remain necessary even when the analysis turns toward social formation.

The bridge to Chapter 5 follows directly. Limited Legibility is not merely an individual limitation or a lack of information. It is socially formed by praxis fields that make actors competent. The same field that teaches actors how to navigate the world also teaches them which parts of the world are difficult to see. Chapter 5 therefore turns from the Garden as learned legibility-field to the limits of legibility that such a field produces.

---

## 5. Limited Legibility and Comparison Susceptibility

### 5.1 Bounded Human Legibility

Chapter 4 reconstructed the Garden as both a condition of human competence and a possible source of blindness. Within that account, actors learn to recognize, trust, fear, correct, answer, withhold, and bind themselves inside stabilized praxis fields. Chapter 5 names the corresponding limitation as bounded legibility: the analysis does not assume that a role-position has complete access to the praxis field in which it participates.

Limited legibility is a theoretical-methodological premise of EDEN, not an empirical claim that every actor is limited in the same way or to the same degree. Whether particular costs, asymmetries, histories, or effects are available to a role-position remains a scene-bound descriptive question requiring evidence. Limited legibility is not innocence. It is not excuse. It is not stupidity. It is not guilt. It is the structural condition under which responsibility must be traced, coordinated, and corrected without pretending that all relevant structures are already fully visible.

This condition matters because praxis is lived before it is fully understood. A role-position acts within a scene whose consequences are only partly available to it. Costs may be felt before they are named. Responsibilities may be real before they are conceptually clear. Asymmetries may structure a scene before the available language can identify how they operate. Limited legibility therefore does not make structuring effects unreal. It makes their coordination more difficult.

Responsibility remains real under limited legibility.

This sentence is necessary because limited legibility can easily be misunderstood. If the actor did not fully see the structure, that does not mean that no structure was active. If the field did not yet provide a concept, that does not mean that no cost was carried. If an asymmetry was normalized, that does not mean that its effects were harmless. Limited legibility changes the conditions under which responsibility must be traced; it does not erase responsibility.

Limited legibility is also not merely individual limitation. It is socially formed by the praxis fields that make actors competent. A person may be able to move skillfully through a field precisely because the field has already taught what to notice, what to ignore, what to treat as normal, and what to experience as impossible to name. Competence and blindness can therefore arise from the same stabilized field.

The limits of legibility are embodied, social, conceptual, affective, historical, role-based, and linguistic. They include what a body has learned to expect, what a role-position has learned to fear, which costs a field has made normal, which claims it has made credible, which exposures it has made ordinary, and which forms of responsibility it has made speakable. They also include which burdens have become too familiar to appear as burdens.

This is why EDEN cannot treat limited legibility as either exoneration or accusation. It is not a reason to abandon responsibility, and it is not a reason to moralize limitation. It is a condition for careful coordination. The more limited the legibility of a scene, the more important it becomes to distinguish real Ω (asymmetry), structuring effect, displaced responsibility, missing concepts, and possible counter-scene without turning the reading into a verdict.

One major form of limited legibility appears when asymmetry is repeated over time. Real asymmetry may become difficult to see not because it is absent, but because it has become ordinary. Chapter 5 therefore turns next to asymmetry under temporality: how real Ω (asymmetry) can be stabilized, normalized, and made difficult to criticize without becoming unreal.

### 5.2 Asymmetry under Θ

Real Ω (asymmetry) becomes especially difficult to read when it is stabilized under Θ (temporality). A repeated asymmetry can begin to appear less like a structure and more like the way things are. Repetition does not make the asymmetry false, but it can make the asymmetry harder to identify as a coordinable problem.

The pattern can be stated as a scene-level operator trace:

real Ω operative across Θ
+ repeated praxis within □
→ Α (attractor) stabilization
→ Φ (recontextualization) as nature / culture / reality.

This trace does not derive a new PMS axis or alter the operators’ dependency relations. It describes a conditional legibility risk, not an empirical sequence or prevalence claim. Where the configuration is present, repeated asymmetry may cease to be treated as a distribution that could be named, criticized, or coordinated. Repetition can give the asymmetry the appearance of order. What is carried again and again may become background; what is protected again and again may become obvious; what is expected again and again may become reality-like.

This is why Chapter 5 must preserve several distinctions at once:

Historically stabilized does not mean unreal.
Real does not mean uncriticizable.
Constructed does not mean fake.
Naturalized does not mean justified.

Historically stabilized does not mean unreal because repeated praxis can produce real effects. A burden may be socially formed and still be materially carried. A role may be historically stabilized and still structure exposure, cost, recognition, or responsibility in the present. To call a pattern constructed, learned, or stabilized is not to say that it is merely imagined.

Real does not mean uncriticizable. If an asymmetry is operative, embodied, repeated, or socially stabilized, it may still require critique. Its reality only means that the analysis must take its effects seriously. It does not mean that the distribution is justified, reciprocal, dignified, or beyond revision.

Constructed does not mean fake. A praxis field can construct expectations, roles, exposures, and cost distributions that become real in their effects. The question is not whether a structure is natural or artificial in some simple sense. The question is how it structures a scene, who carries its effects, and whether those effects can be coordinated under conditions of responsibility, integration, self-binding, and correction.

Naturalized does not mean justified. A field may translate a repeated distribution into nature, culture, realism, tradition, necessity, or common sense. Φ (recontextualization) can move an asymmetry away from criticizable structure and toward what appears given. But the appearance of givenness is not the same as truthfulness of coordination.

Chapter 5 does not decide whether a particular asymmetry is genuine, justified, distorted, naturalized, or falsely coordinated. Such a judgment requires scene-level analysis and boundary testing. The point here is more limited: asymmetry under temporality changes what can be seen. Repetition can make a cost appear normal before it has ever been coordinated.

This matters for the movement toward comparison. When real Ω (asymmetry) becomes normalized under Θ (temporality), actors may lack the language to ask what the asymmetry is doing. The structure remains active, but its terms are not fully available. The next problem is therefore not yet false comparison. It is the absence, weakness, or instability of the concepts needed to name what the scene already carries.

### 5.3 Missing Concepts

Limited legibility becomes especially consequential where a structure lacks legitimate terms. When a scene has no available language for a cost, a burden, an asymmetry, a responsibility shift, or a form of self-binding load, the structure does not disappear. It becomes harder to coordinate.

When structure cannot be named,
it does not disappear.
It is carried affectively, morally, relationally, or bodily.

This is the basic problem of missing concepts. A role-position may carry a burden before the field has a recognized name for that burden. A cost may be real before it can appear as cost. A responsibility shift may be active before the scene can distinguish responsibility from blame, vulnerability from immunity, protection from responsibility shield, or non-action from mere absence. Missing concepts therefore do not make structure unreal. They make structure harder to render shareable.

Missing concepts may concern several different dimensions. A scene may lack responsibility vocabulary: terms for naming who is answerable to a structuring effect without reducing that answerability to guilt. It may lack asymmetry vocabulary: terms for naming uneven cost, exposure, capacity, protection, timing, or access without converting difference into rank. It may lack protection vocabulary: terms for distinguishing genuine protection from protection that blocks criticizability. It may lack vulnerability vocabulary: terms for recognizing real vulnerability without detaching that vulnerability from responsibility for effects.

It may also lack a vocabulary for non-action and Ψ (self-binding)-load. A silence, delay, refusal, withholding, non-response, or non-binding posture may structure a scene without appearing as action in the ordinary sense. If the field has no language for that kind of structuring effect, the burden may be displaced onto the side that must absorb, interpret, stabilize, or repair it. The point here is narrow: missing language can make a real structuring effect appear as mood, sensitivity, overreaction, or relational difficulty rather than as a coordinable feature of the scene.

When concepts are missing, structure is often translated into affective or moral residue. A burden may appear as shame. A cost may appear as irritation. A responsibility shift may appear as guilt. A blocked critique may appear as hostility. A lack of recognition may appear as personal failure. A structural asymmetry may appear as weakness, domination, ingratitude, threat, or exaggeration. The scene still carries the structure, but it carries it in distorted form because it cannot yet name what is being carried.

Asymmetric explanatory poverty becomes possible under these conditions. A role-position may lack legitimate language for naming its burden while still being required to carry that burden. It may be unable to describe a structuring effect without being recoded as controlling, weak, dangerous, overreactive, ungrateful, or hostile. The present analysis identifies only the prior condition: where concepts are missing, the burden of legibility itself can become asymmetrically distributed.

Missing concepts are not a total explanation. They do not explain every conflict, excuse every effect, or replace responsibility. They mark a legibility gap. The structure still has to be traced scene by scene: what is operative, who carries what, which costs can be named, which responsibilities remain speakable, and which possible counter-scene could change the reading. But where the necessary concepts are absent or unstable, the need for orientation increases.

### 5.4 Need for Orientation

Where real Ω (asymmetry) remains active but only partly legible, actors need orientation. They need some way to ask what kind of scene they are in, what is being carried, what is being protected, what is being exposed, and what kind of responsibility is at stake. This need is not itself false. It belongs to praxis under limited legibility.

Comparison can arise at this point as an attempt at orientation. A role-position may ask, implicitly or explicitly: who carries more cost, who may speak, who must adapt, who is protected, who is exposed, who is responsible, who can wait, who must explain, who can remain unclear, and whose burden counts as real? These questions are not automatically false comparisons. They may be attempts to locate a real asymmetry that the scene has not yet coordinated.

Comparison is not always false.

Comparison can be functional when it helps a scene clarify distribution, responsibility, capacity, exposure, or protection. A comparison may show that a burden is not evenly shared, that a role-position carries an invisible cost, that a protection is necessary, that a vulnerability is real, or that a responsibility has been displaced. In such cases, comparison does not replace coordination; it serves coordination.

Comparison becomes dangerous when it replaces coordination.

This replacement begins when comparison stops asking what needs to be coordinated and begins deciding what someone is worth, who is higher or lower, who counts as mature or deficient, who is credible or suspect, who is protected or dangerous, who is burden or value. The problem is not that actors compare. The problem is that comparison can become a substitute for the more difficult work of coordinating real asymmetry.

Under limited legibility, this substitution becomes tempting. If a scene cannot name the relevant cost, it may compare burdens. If it cannot name responsibility, it may compare innocence and guilt. If it cannot name asymmetry, it may compare strength and weakness. If it cannot name protection, it may compare fragility and danger. If it cannot name non-binding, it may compare effort, care, maturity, or emotional availability. Comparison supplies orientation where coordination vocabulary is missing.

This does not yet make the comparison false. It makes the scene susceptible. The decisive question is whether comparison remains a tool for clarifying a praxis relation, or whether it begins to replace that relation with a value relation. Chapter 5 therefore does not condemn comparison. It marks the pressure under which comparison can become more attractive than coordination.

Limited legibility, normalized asymmetry, missing concepts, recognition need, responsibility pressure, cost opacity, and weak or externalized Ψ (self-binding) can make comparison appear as the most available way to orient the scene. That condition is comparison susceptibility. It is not False Comparison; it names the conditions under which comparison can become plausible as a substitute for coordination.

### 5.5 Comparison Susceptibility

The need for orientation does not yet produce false comparison. It produces susceptibility. Comparison susceptibility names the condition in which comparison becomes more available than coordination because the scene remains only partly legible. It is not a moral failure, not a diagnostic category, and not a drift mechanism by itself.

The susceptibility formula can be stated as follows:

limited legibility + real Ω (asymmetry) + Θ (temporality) stabilization + missing concepts + recognition need + responsibility pressure + cost opacity + weak or externalized Ψ (self-binding) → comparison susceptibility.

This formula is not a linear causal chain. It does not say that limited legibility automatically produces false comparison, or that comparison susceptibility excuses what later happens. It says that certain conditions make comparison more likely to appear as an available orientation device. Where real Ω (asymmetry) is active but not fully nameable, where cost remains opaque, where responsibility pressure is felt but not yet well coordinated, and where self-binding is weak or displaced, comparison may become the easiest way to ask what the scene means.

Susceptibility is therefore different from drift. A susceptible scene may still use comparison functionally. It may compare burdens in order to clarify distribution. It may compare role-positions in order to identify responsibility. It may compare exposures in order to make protection more accurate. It may compare capacities in order to coordinate unequal burdens more truthfully. None of this is false comparison as such.

The danger begins when comparison becomes more available than coordination. Under limited legibility, comparison can appear to solve what coordination has not yet been able to name. It can offer rank where the scene needs responsibility. It can offer worth where the scene needs cost-truth. It can offer higher and lower where the scene needs differentiated answerability. It can offer simplicity where the scene requires integration.

This is why comparison susceptibility does not erase responsibility. If a scene is susceptible, responsibility becomes harder to coordinate, not unreal. The relevant question remains structural: what is active in the scene, which asymmetries matter, which costs remain opaque, which role-positions carry the burden of legibility, and whether comparison is still serving coordination or beginning to replace it.

Comparison susceptibility also does not make false comparison inevitable. A susceptible scene can still be corrected if real Ω (asymmetry) becomes more nameable, if responsibility can be traced without humiliation, if costs can enter a shared frame, if self-binding can be restored, and if comparison remains subordinate to coordination. The point of naming susceptibility is not to condemn the scene in advance, but to show why the next drift becomes plausible.

The precise threshold is the point at which comparison no longer helps a scene coordinate a praxis relation, but begins to convert that praxis relation into a value relation. That conversion belongs to False Comparison; comparison susceptibility names only the conditions that make it more available.

### 5.6 From Praxis Relation to Value Relation

Difference and asymmetry first appear as praxis relations. A Δ (difference) or Ω (asymmetry) relation may involve different roles, costs, exposures, capacities, vulnerabilities, dependencies, responsibilities, action-powers, or needs for protection. Such difference may be difficult, consequential, and unequal, but it is not already rank.

As a praxis relation, Δ (difference) / Ω (asymmetry) asks how the scene is structured. Who carries what? Who can act? Who must wait? Who is exposed? Who is protected? Who can name a cost? Who must integrate it? Who remains bound to the effect? These are questions of coordination, not yet questions of worth.

A value relation appears when difference is read as higher or lower, superior or inferior, worthy or unworthy, credible or suspect, mature or immature, valuable or burdensome, protected or dangerous. At that point, the scene no longer asks only how real asymmetry is to be coordinated. It begins to read the asymmetry as a value signal.

The central distinction is simple:

The problem is not that difference is seen.
The problem is that difference is read as rank where coordination is required.

This distinction protects the paper from two errors. First, it prevents a false egalitarian flattening in which all difference must disappear before reciprocity can exist. Adult Reciprocity does not require sameness. Second, it prevents a rank conversion in which every difference is allowed to become evidence of higher and lower standing. Adult Reciprocity requires real difference and real asymmetry to remain coordinable without becoming rank.

The shift from praxis relation to value relation is therefore a conversion of function. Comparison no longer asks what must be coordinated; it begins to imply what someone or some position is worth. A different burden becomes a sign of deficiency. A different exposure becomes a sign of weakness. A different protection need becomes a sign of lower capacity or higher danger. A different responsibility becomes a sign of moral superiority or inferiority. The scene moves from structuring effect to value reading.

This shift is not the single origin of drift. It is one conversion point. Limited legibility, missing concepts, cost opacity, and responsibility pressure can make it more likely, but they do not determine it in advance. A scene may remain susceptible without crossing this threshold. It crosses the threshold when comparison begins to replace the work of coordinating real Ω (asymmetry) with the easier work of assigning value.

This prepares the next chapter. Chapter 6 will define False Comparison not as comparison itself, and not as the first cause of reciprocity loss, but as a frame-attractor, amplifier, and stabilizer. Chapter 5 has only established the condition that makes it plausible: where a praxis relation becomes hard to coordinate under limited legibility, comparison can begin to convert difference into value before responsibility, integration, and self-binding have been truthfully coordinated.

---

## 6. False Comparison as Frame-Attractor

### 6.1 Definition

Chapter 5 established comparison susceptibility: the condition in which comparison becomes more available than coordination because a scene remains only partly legible. Chapter 6 now defines the drift that can emerge from that condition. This drift is False Comparison.

False Comparison is not the first cause. It is not the paper’s origin, not the master mechanism of reciprocity loss, and not a claim that comparison as such is false. False Comparison is an attractor, amplifier, and stabilizer: it draws a scene toward comparison when coordination is harder, amplifies the salience of rank or value, and stabilizes readings that make truthful coordination more difficult.

Comparison is not false because it compares. Comparison can clarify distribution, identify cost, reveal asymmetry, expose displacement, or make responsibility more traceable. It can serve coordination when it remains bounded, specific, revisable, and answerable to the scene it helps read.

Comparison becomes false when it substitutes for truthful coordination of real Ω (asymmetry). In that substitution, the scene no longer asks first what is structured, who carries what, which effects must be integrated, or how responsibility can follow real effect. It asks instead who is higher or lower, more or less credible, more or less valuable, more or less mature, more or less dangerous, more or less burdened, more or less entitled to recognition.

False Comparison does not create real Ω (asymmetry). It falsely coordinates real Ω. The asymmetry may already be operative in cost, exposure, capacity, timing, dependency, protection, or responsibility. False Comparison becomes dangerous because it gives that asymmetry a misleading frame: a frame in which rank, value, suspicion, idealization, threat, or defect begins to replace coordination.

This is why False Comparison becomes responsibility-relevant. Once comparison begins to substitute for coordination, R (responsibility) may no longer follow real structuring effect. Responsibility can be displaced toward the role-position that appears lower, weaker, needier, more suspicious, more dangerous, more exposed, or more difficult to integrate. At the same time, Σ (integration) and Ψ (self-binding) can be blocked: cost cannot enter the scene truthfully, and the relevant role-positions may no longer be bound to their own effects.

The definition can be compressed:

False Comparison =
comparison captured by a □ (frame) that makes rank, value, suspicion, idealization, threat, or defect more available than truthful coordination of real Ω (asymmetry).

This definition must remain limited. False Comparison is not equivalent to error, disagreement, judgment, discernment, critique, or ordinary comparison. It names a structural drift in which comparison begins to organize the scene in place of coordination. The next step is therefore to distinguish difference, asymmetry, comparison, rank, and value relation before the drift forms are described.

### 6.2 Difference versus Comparison

False Comparison depends on a distinction that must not be lost: difference is not rank, and asymmetry is not inferiority. Δ (difference) marks a distinction. Ω (asymmetry) marks an uneven relation of cost, exposure, capacity, dependency, protection, timing, vulnerability, responsibility, or action-power. Comparison relates distinctions or asymmetries. False Comparison begins when that relation is converted into rank, value, standing, suspicion, or distorted responsibility.

Difference can be real without being ranked. Two role-positions may differ in capacity, exposure, timing, vulnerability, knowledge, dependence, responsibility, or protection need. Such difference may matter deeply for coordination. But difference does not, by itself, say that one side is higher, lower, more worthy, less worthy, more credible, less credible, more mature, more defective, more dangerous, or more entitled to protection.

Asymmetry can be real without being domination. A scene may include real Ω (asymmetry) because one role-position carries more cost, has less capacity, faces more exposure, has fewer alternatives, bears more responsibility, or depends differently on the field. None of this automatically means that the asymmetry is false, unjustified, oppressive, or reciprocal. It means that the asymmetry must be read according to its real structuring effect.

Comparison can be functional when it helps this reading. It may ask whether one role-position carries a cost the other does not see, whether responsibility has been displaced, whether protection is accurate, whether vulnerability is real, whether action-power is uneven, or whether a scene’s distribution can be coordinated more truthfully. Functional comparison remains possible because comparison can support coordination.

False Comparison begins when comparison ceases to clarify structure and begins to assign value. A difference in exposure becomes a sign of weakness. A difference in dependency becomes a sign of inferiority. A difference in protection need becomes a sign of fragility, danger, or entitlement. A difference in responsibility becomes a sign of superiority or defect. A difference in timing becomes a sign of maturity or failure. What should have remained a praxis relation becomes a value relation.

The problem is therefore not that a difference is noticed. A theory that cannot notice difference cannot coordinate real scenes. Nor is the problem that asymmetry is recognized. A theory that cannot recognize asymmetry will confuse reciprocity with symmetry. The problem begins when difference or asymmetry is read as rank where coordination is required.

This distinction protects the analysis from two opposing errors. On one side, it prevents flattening: the attempt to treat all real difference as if it should vanish. On the other side, it prevents ranking: the attempt to treat real difference as evidence of higher and lower standing. Adult Reciprocity requires neither sameness nor rank. It requires truthful coordination of real asymmetry.

False Comparison therefore marks a conversion failure. It does not discover the truth of difference; it recodes difference before coordination has occurred. It does not reveal the essence of asymmetry; it gives asymmetry a value-frame before responsibility, integration, and self-binding have been traced. The next drift form is negative comparison, where difference begins to appear as deficiency, burden, suspicion, or lower standing.

### 6.3 Negative Comparison Drift

Negative Comparison Drift begins when difference is no longer read as a praxis relation but as evidence of lower standing, defect, burden, suspicion, or reduced credibility. The scene does not merely compare roles, costs, exposures, or responsibilities. It begins to read the compared difference as a sign that one position is less competent, less mature, less trustworthy, less valuable, or less entitled to recognition.

This drift continues the conversion named in Chapter 5. A praxis relation asks how Δ (difference) or Ω (asymmetry) is structured and how it should be coordinated. Negative Comparison Drift turns that relation into a value reading. Dependency becomes inferiority-risk. Vulnerability becomes weakness-risk. Need becomes defect-risk. Exposure becomes suspicion-risk. Different timing or capacity becomes lesser-agency-risk. The drift is not the truth of these differences; it is the comparison frame through which they begin to be read.

Negative Comparison Drift names the process by which a difference can become negatively value-coded before coordination has occurred. Inferiority and superiority misframing are the rank artifacts that follow when lower and higher standing become the dominant readings. The narrower point here is that negative comparison can begin before the scene has truthfully traced its real structure.

Negative Comparison Drift can become structurally available under limited legibility because it simplifies what coordination leaves difficult. If the scene cannot name a cost, it can compare who seems more burdened or less capable. If it cannot name responsibility, it can compare who seems more guilty or more innocent. If it cannot name exposure, it can compare who seems more fragile or more threatening. If it cannot name dependency, it can compare who seems more mature or less mature. Value-reading offers a quick orientation where praxis-reading remains hard.

The responsibility effect is serious. Once a role-position becomes negatively value-coded, R (responsibility) may be displaced away from real structuring effect and toward the role-position that appears deficient, difficult, needy, suspicious, or less credible. The question “what does this scene distribute?” is replaced by “what is wrong with this position?” That replacement makes responsibility easier to assign in appearance and harder to trace in reality.

The integration effect is equally serious. If a cost is carried by a role-position already read as lower, weaker, immature, suspect, or burdensome, Σ (integration) becomes harder. The cost may no longer enter the scene as a shared structural fact. It may enter as complaint, fragility, exaggeration, demand, incompetence, or threat. The comparison frame has already changed what the cost is allowed to mean.

Negative Comparison Drift also interferes with Ψ (self-binding). A role-position that benefits from the comparison frame may no longer need to bind itself to its own structuring effect, because the burden appears to belong to the negatively coded side. The one who suffers the cost may be expected to explain, stabilize, justify, adapt, or prove credibility, while the frame that distributes the cost remains insufficiently bound to its own effects.

The drift is therefore not merely evaluative. It reorganizes coordination. It can decide in advance whose claim is credible, whose burden is excessive, whose dependency is failure, whose vulnerability is weakness, whose critique is hostility, and whose need counts as evidence against them. At that point comparison no longer clarifies a scene. It prepares the scene to treat the bearer of a cost as the problem.

This remains a structural account, not a diagnostic one. Negative Comparison Drift does not name a kind of person. It names a way a scene can become organized when comparison converts difference into lowered standing before real Ω (asymmetry), responsibility, cost, integration, and self-binding have been coordinated. The next drift form shows that false comparison need not be negative in tone to become capturing.

### 6.4 Positive, Fixing, or Threat-Coding Comparison Drift

False Comparison is not only negative comparison. A scene can also drift through positive comparison, fixing comparison, or threat-coding comparison. These forms may sound protective, admiring, corrective, cautious, or responsible. Their danger lies not in their tone, but in the way they can replace coordination with a comparison frame.

Positive Comparison Drift begins when a role-position is idealized, elevated, purified, symbolized, or made too valuable to criticize. The comparison does not lower the position; it raises it. But elevation can still capture. A role-position may become too fragile, too noble, too necessary, too innocent, too exemplary, too vulnerable, or too symbolically important for its structuring effects to be questioned. Recognition then becomes protection from criticizability rather than recognition with responsibility.

Idealization can be capture.

This formula matters because positive comparison can appear generous while still blocking Adult Reciprocity. If a role-position is idealized, the scene may no longer be able to ask what costs that position distributes, what responsibilities it carries, what effects it produces, or where its protection becomes a responsibility shield. The elevated position is recognized, but not fully answerable. The comparison frame protects value while weakening coordination.

Fixing Comparison Drift operates differently. Here comparison defines one side as the side that must be corrected, improved, rescued, educated, contained, matured, regulated, or made ready before coordination can occur. The scene appears to aim at improvement, but the comparison has already decided where deficiency lies. Coordination is postponed until the supposedly deficient side becomes acceptable to the frame.

This drift can be subtle because it may borrow the language of care, help, realism, competence, or responsibility. Yet if the fixing frame is false, it displaces the question of real structure. The issue is no longer how the scene distributes cost, exposure, recognition, or responsibility. The issue becomes how one side must be adjusted so that the existing frame can continue. Fixing Comparison Drift can therefore preserve the frame by treating the burdened or disruptive position as the site of correction.

Threat-Coding Comparison Drift begins when difference is read as danger before structure has been traced. A role-position may become coded as dominating, contaminating, manipulative, destabilizing, unsafe, excessive, or inherently risky. In some scenes, danger may be real and must be taken seriously. Chapter 6 does not deny genuine danger. The drift begins where comparison turns difference into threat in advance of coordination, counter-scene exposure, and responsibility tracing.

Threat-coding can be capture.

It can capture because once a role-position is coded as threat, ordinary structural claims may become difficult to hear. A request for coordination can be heard as control. A demand for responsibility can be heard as domination. A claim about cost can be heard as manipulation. A need for boundaries can be heard as aggression. A critique can be heard as danger. The comparison frame organizes recognition, protection, and suspicion before the scene has traced what is actually being structured.

These three drift forms can also combine. Idealization may protect a role-position from critique; fixing may direct correction toward the other side; threat-coding may then interpret resistance to the fixing frame as danger. Or threat-coding may justify idealization of one side as pure protection, while the other side is placed under permanent suspicion. The forms are distinct, but in a scene they may reinforce one another.

The responsibility effect remains the same across the forms. In positive drift, responsibility may be blocked by idealized protection. In fixing drift, responsibility may be displaced into the side that must be corrected. In threat-coding drift, responsibility may be suspended because the coded threat appears to justify preemptive suspicion. In each case, comparison replaces coordination of real effects.

The guardrail is essential. Real vulnerability can exist. Real protection can be needed. Real danger can be present. Real correction can be justified. Chapter 6 does not deny these possibilities and does not decide them in advance. The point is narrower: vulnerability, protection, correction, and danger become drifted when a comparison frame organizes them before the scene has remained answerable to real Ω (asymmetry), responsibility, integration, self-binding, and possible counter-scene.

False Comparison therefore cannot be identified by tone alone. It may sound negative, admiring, helpful, cautious, protective, or critical. The question is whether comparison still serves coordination, or whether it has begun to organize the scene in place of coordination. Once the frame begins to protect itself through negative coding, idealization, fixing, or threat-coding, the drift can become self-reinforcing. The next section names that dynamic as the Comparison Loop.

### 6.5 Comparison Loop

Once False Comparison has begun to organize a scene, it can become self-reinforcing. It does not need to be the first cause in order to become powerful. Its force lies in the way it makes comparison increasingly available, coordination increasingly difficult, and responsibility increasingly displaced.

The loop begins from the conditions described in Chapter 5: limited legibility under Ω (asymmetry) and Θ (temporality). A scene is partly readable, but not fully coordinated. Real asymmetries are active, costs are not equally visible, concepts may be missing, and responsibility pressure is felt before it is well traced. In that condition, comparison can appear as the easiest available orientation device.

Comparison susceptibility is therefore the entry condition, not the drift itself. A susceptible scene may still use comparison functionally. The drift begins when comparison ceases to serve coordination and begins to organize the frame through which the scene is read. At that point, False Comparison becomes an Α (attractor) within a □ (frame): it makes rank, value, suspicion, idealization, fixing, or threat-coding more available than the harder work of coordinating real Ω (asymmetry).

Once the comparison frame is active, it changes what can be noticed. A cost may be read through the value of the role-position that carries it. A request for responsibility may be read through suspicion or threat. A need for protection may be read through idealization or fragility. A difference in timing, capacity, exposure, or dependency may be read as maturity, deficiency, entitlement, danger, or burden. The frame does not merely interpret the scene; it begins to reorganize what the scene can mean.

This is where False Comparison becomes both symptom and stabilizer. It is a symptom because it can appear where coordination has already become difficult under limited legibility. It is a stabilizer because, once active, it can protect the very difficulty that produced it. The scene compares because coordination is hard; comparison then makes coordination harder; the increased difficulty makes comparison still more attractive.

The responsibility effect is central. When comparison replaces coordination, R (responsibility) no longer reliably follows real structuring effect. Responsibility may move toward the role-position that appears weaker, more difficult, more suspicious, more demanding, more dangerous, more privileged, more fragile, or more deficient. The scene stops asking who or what structures the effect and begins asking which side the comparison frame has already made answerable.

This displacement blocks Σ (integration). Costs and effects cannot enter the scene as shared structural facts if they have already been filtered through rank, value, suspicion, idealization, fixing, or threat. What should be integrated as a real effect may appear instead as complaint, entitlement, danger, immaturity, fragility, domination, or failure. The comparison frame narrows what the scene can integrate before integration begins.

It also blocks Ψ (self-binding). A role-position protected by the comparison frame may not have to bind itself to its own structuring effects. Another role-position may have to absorb, explain, stabilize, prove, repair, or translate the effects the frame refuses to coordinate. In this way, weak or externalized Ψ can become both a condition for comparison susceptibility and an effect of False Comparison itself.

The loop can be stated as follows:

limited legibility under Ω (asymmetry) / Θ (temporality)
→ comparison susceptibility
↔ False Comparison
↔ false-coordinated real Ω
→ displaced R (responsibility)
→ blocked Σ (integration) / Ψ (self-binding)
→ reciprocity-loss pressure
→ increased comparison susceptibility.

This formula must be read as a loop, not as an origin chain. It does not say that limited legibility automatically produces False Comparison. It does not say that False Comparison creates real asymmetry. It does not say that reciprocity loss is already fully explained here. It says that once comparison begins to replace coordination, each element can reinforce the others: susceptibility invites comparison, comparison falsely coordinates real Ω (asymmetry), false coordination displaces responsibility, displaced responsibility blocks integration and self-binding, and blocked coordination increases susceptibility again.

The phrase false-coordinated real Ω is only introduced here as a bridge. Chapter 9 will give it its full mechanism. For now, it names the intermediate effect: real asymmetry remains active, but the scene coordinates it through a false comparison frame rather than through truthful responsibility, integration, and self-binding. The asymmetry is not invented by the comparison, but the comparison can determine how the asymmetry is handled.

The same restraint applies to reciprocity loss. False Comparison can become one stabilizing path toward it without constituting its origin or complete mechanism. When responsibility is displaced, when costs cannot be integrated, when self-binding is blocked, and when comparison becomes more available than coordination, the conditions of Adult Reciprocity begin to weaken. That weakening increases the pressure to compare again.

The loop is therefore powerful precisely because it can appear reasonable from inside itself. Each comparison may seem to clarify what the last failure of coordination left unresolved. Each new ranking, suspicion, idealization, fixing, or threat-code may seem to make the scene more legible. Yet the legibility produced by the loop is not the same as coordination. It may make the scene easier to read while making it harder to answer truthfully.

This is why Chapter 6 must keep functional comparison in view. A loop does not begin every time actors compare. It begins when comparison becomes the frame that protects itself against coordination. The next section therefore maps the levels at which comparison can operate, not to build a taxonomy of persons or scenes, but to show how many different aspects of a scene can either support coordination or become captured by False Comparison.

### 6.6 Comparison Levels

False Comparison can operate at several levels of a scene. These levels are not a taxonomy of persons, groups, or types. They are an orientation map: a way of noticing where comparison may either support coordination or begin to replace it.

Comparison may operate across four connected domains.

First, it may compare responsibility, recognition, credibility, and explanation burden: who is answerable, heard, trusted, required to explain, or permitted to remain unclear. Such comparison supports coordination when standing remains connected to real structuring effect. It becomes drifted when rank, suspicion, fragility, idealization, or threat-coding decides whose account and effects matter.

Second, comparison may clarify cost, dependency, exposure, vulnerability, protection need, and danger. It can identify unequal burdens, reliance, risks, alternatives, or requirements for protection. It becomes drifted when dependency becomes inferiority, exposure becomes suspicion, vulnerability becomes defect or immunity, protection need becomes rank, or danger is assigned before the scene has been tested.

Third, comparison may map agency, binding, and non-action: who can act, refuse, delay, remain open, withdraw, or structure conditions through absence. This can make uneven action-power and Ψ (self-binding)-load legible. It becomes drifted when agency is ranked before effect is traced, or when non-action is presumed innocent or guilty without establishing what it structures.

Fourth, comparison may clarify language access: which costs have recognized terms, whose burden can be named, and who must make the scene legible. It becomes drifted when missing language lowers credibility or when one role-position carries the explanatory burden while the operative frame remains exempt from explanation.

These levels do not imply symmetry. Bidirectionality is not symmetry. A comparison may be relevant in more than one direction without becoming equal in cost, exposure, capacity, or responsibility. Non-symmetry is not one-sidedness. A scene may be structured by several role-positions, while still requiring the analysis to distinguish who carries what, who can revise what, and whose burden increases when the other side remains unbound.

The levels also do not create person types. They do not define kinds of actors, sexes, groups, or moral characters. They name possible comparison sites within a scene. At each level, the question is the same: does comparison help coordinate the structure, or does it begin to replace coordination with rank, value, suspicion, idealization, fixing, or threat?

This is why the chapter must end by preserving the difference between functional and drifted comparison. Without that distinction, the theory would become anti-comparison and would lose discriminative adequacy. False Comparison is dangerous because comparison can be useful. The drift matters precisely because it can capture a function that scenes genuinely need.

### 6.7 Functional versus Drifted Comparison

Comparison is not false because it compares. It becomes false when it ceases to serve coordination and begins to organize the scene in place of coordination. The final distinction in this chapter is therefore not comparison versus no comparison, but functional comparison versus drifted comparison.

Functional comparison is bounded. It asks a specific question rather than turning a role-position into a general value. It is tied to a concrete scene, a traceable structure, and a revisable claim. It compares in order to clarify distribution, cost, exposure, dependency, responsibility, or protection need. It does not convert the compared difference into rank.

Functional comparison is also reversible. It can be corrected by counter-scene, additional evidence, changed conditions, or better tracing of structuring effect. It remains open to Χ (distance), rather than collapsing into urgency, accusation, fusion, or verdict. A functional comparison can say: this reading appears to hold here, under these conditions, unless a better scene-reading changes it.

Functional comparison is cost-aware and responsibility-compatible. It does not ask only who appears better, worse, stronger, weaker, safer, more dangerous, more credible, or more burdened. It asks what the scene distributes and whether R (responsibility) follows real effect. It remains compatible with answerability because it does not protect any role-position from criticizability merely by ranking it.

Functional comparison supports Σ (integration) and Ψ (self-binding). It helps cost and effect enter coordination without forcing one role-position to carry the whole burden of legibility. It can show where one side’s low Ψ increases another side’s Ψ-load, but it does not turn that finding into a person-label or verdict. It keeps the analysis bound to the scene.

Functional comparison preserves D (dignity-in-practice). It may name asymmetry, cost, dependency, vulnerability, responsibility, or danger without degrading a role-position into a type. It can criticize without humiliation, protect without immunity, recognize without sentimental elevation, and assign responsibility without domination. For that reason, functional comparison remains counter-scene exposed.

Drifted comparison has the opposite tendency. It is ranking, persona-forming, immunizing, overexposing, responsibility-displacing, Σ (integration) / Ψ (self-binding)-blocking, D (dignity-in-practice)-eroding, and critique-to-threat enabling. It does not merely compare a feature of the scene. It reorganizes the scene around the value of the compared position.

Drifted comparison is ranking when difference becomes evidence of higher or lower standing. It is persona-forming when a role-position becomes readable primarily as deficient, fragile, dangerous, noble, immature, manipulative, burdensome, or exemplary. It is immunizing when comparison protects a position from criticizability. It is overexposing when comparison makes another position permanently answerable, explainable, or suspect.

Drifted comparison displaces responsibility because the comparison frame decides where answerability belongs before the structuring effect has been traced. It blocks integration because costs cannot enter the scene except through the value assigned to their bearer. It blocks self-binding because the position protected by the frame need not bind itself to its own effects, while the other position may have to bind itself to effects it did not structure.

The difference between functional and drifted comparison can be stated compactly:

Functional comparison reopens coordination.
Drifted comparison replaces coordination.

This distinction supplies the necessary boundary: comparison must remain accurate, useful, bounded, counter-scene exposed, and coordination-supporting. The theory must be able to identify False Comparison without treating every comparison as false or condemning comparison itself.

This also prepares the next chapter. Before the paper can analyze inferiority and superiority as rank artifacts, it must first establish that real difference and real asymmetry can be coordinated without becoming rank. Chapter 7 therefore turns to the real sexed praxis relation under Ω (asymmetry): not as sex truth, not as hierarchy, and not as verdict, but as a field in which asymmetry must be read before comparison can distort it.

---

## 7. Real Sexed Praxis Relation under Ω

### 7.1 Man/Woman as Real Praxis Relation

False Comparison can convert difference into rank and asymmetry into value reading. Before the resulting rank artifacts can be analyzed, the real praxis relation that False Comparison may distort must be named. The point is not to begin from rank, essence, or sex truth. The point is to establish that sexed difference can be real without already being hierarchy.

“Man/Woman” is used here as a compressed label for sexed role-positions in a real praxis relation under Ω (asymmetry), not as an essence, ontology, archetype, or verdict about persons. After this initial definition, the chapter will speak mainly of sexed role-positions and the real sexed praxis relation. The terms name a structural relation within scenes, not a universal account of what persons are.

Within EDEN, Man/Woman names a possible real sexed praxis relation under Ω (asymmetry): embodied, socially framed, historically stabilized, asymmetrically exposed, and responsibility-relevant. This is an analytically reconstructed structural hypothesis, not an empirical typology, prevalence claim, or claim about distribution across populations. Whether and how such a relation structures a particular scene requires scene-bound evidence.

This relation is not merely symbolic coding. It includes bodies, roles, vulnerability, dependency, sexuality, reproduction, exposure, protection, recognition, responsibility, language, institutions, and history. None of these elements should be reduced to biological destiny, and none should be dissolved into mere discourse. Sexed praxis is real where it structures scenes; its interpretation remains revisable because claimed structuring effects can still be criticized, reinterpreted, and coordinated.

Within this chapter, “embodied” includes the possibility that biological and endocrine conditions contribute to the real sexed praxis relation. EDEN does not infer a particular disposition, capacity, motive, or action profile from sex or hormone status, nor does it determine the causal share of biology, social formation, and individual development. It records only the resulting asymmetry where that asymmetry becomes praxeologically effective and scene-relevant.

Biological conditioning may establish a field of tendencies, thresholds, and costs without fixing the conduct or capacity of an individual person. EDEN’s object is therefore not the biological condition itself, but the coordination or false coordination of its possible practical effects.

Sexed Ω (asymmetry) can be real without becoming essence, rank, diagnosis, group verdict, or sex truth. Embodiment does not mean destiny. Social framing does not mean fiction. Historical stabilization does not mean justification. Vulnerability does not mean immunity. Power does not mean total guilt. Protection does not mean the end of responsibility. Responsibility does not mean degradation.

This is the first guardrail of the chapter. The real sexed praxis relation must be readable as real without becoming naturalized into rank and without being flattened into interchangeable positions. The relation is not a claim that one role-position is higher, lower, more adult, less adult, more worthy, less worthy, more guilty, or more innocent. It is a claim that sexed role-positions may stand in real asymmetrical relations that structure cost, exposure, protection, dependency, language, and responsibility.

The relation must also remain scene-bound. Chapter 7 does not apply a verdict to persons, sexes, couples, institutions, or groups. It gives the paper a way to read sexed Ω (asymmetry) where it structures a scene. A scene may involve different kinds of embodiment, protection need, exposure, power, dependency, vulnerability, recognition, or responsibility. The question is not what a sex “is.” The question is what the sexed praxis relation structures in a given scene.

Because the relation is real, its distributions cannot be treated as decorative. Costs may not be equally visible. Protection may not be equally available. Responsibility may not be equally nameable. Exposure may not be equally speakable. Dependency may not be equally dignified. Power may not be equally criticizable. The next section therefore turns from the reality of the relation to the asymmetrical distribution of roles within it.

### 7.2 Asymmetrically Distributed Roles

The real sexed praxis relation distributes roles, costs, exposures, protections, dependencies, vulnerabilities, responsibilities, and available language asymmetrically. This does not mean that every scene contains the same distribution, that every role-position carries the same kind of burden, or that one side is structurally innocent while the other is structurally guilty. It means that sexed Ω (asymmetry) can organize a scene before the scene has truthfully coordinated what that organization distributes.

The distribution can be stated compactly:

asymmetrically distributed,
bidirectionally operative,
not equal,
not identical,
not guilt-totalizing,
not immunity-producing,
not rank-forming,
not symmetry-erasing.

Each term is necessary. The distribution is asymmetrical because costs, protections, exposures, dependencies, responsibilities, and available language may not be shared in the same way. It is bidirectionally operative because more than one role-position may structure effects. It is not equal or identical because bidirectionality does not make the burdens symmetrical. It is not guilt-totalizing because real asymmetry does not make one role-position totally guilty. It is not immunity-producing because vulnerability, exposure, or protection need does not remove responsibility. It is not rank-forming because difference is not higher or lower standing. It is not symmetry-erasing because the analysis must still notice where different role-positions affect one another.

Both role-positions may drift. Both may be harmed. Both may be responsible.

But not in the same way,
not under the same costs,
not through the same mechanisms,
and not with the same available language.

This is the high-sensitivity guardrail. Bidirectional operation does not establish equivalent burdens, exposure, power, criticizability, protection need, or language; non-symmetry does not make the scene structurally one-sided. The distribution must remain scene-bound. Chapter 7 therefore requires structural discrimination rather than rhetorical balance or a one-directional verdict.

The relation is also responsibility-relevant. A role-position may inherit a sexed structure it did not invent, but it may still participate in structuring effects through it. A field may distribute protection, dependency, exposure, credibility, or responsibility unevenly without any single actor designing that distribution. Yet the effects remain real. Responsibility does not require total authorship of the structure; it requires answerability where real structuring effect is present and coordinable.

This point is crucial for what follows. If sexed roles are treated as symmetrical, the analysis cannot see real asymmetry. If they are treated as one-sided, the analysis cannot see bidirectional structuring effect. If they are treated as rank, the analysis has already entered the comparison frame. The next step is therefore to reject symmetrizing flattening before turning to two common conversions: dependency into inferiority, and strength into superiority.

### 7.3 No Symmetrizing Flattening

The real sexed praxis relation cannot be read by flattening it into symmetry. Bidirectionality is not symmetry. Non-symmetry is not one-sidedness. These two sentences are necessary because sexed Ω (asymmetry) is easily misread in both directions.

The first error is symmetrizing flattening. It treats sexed role-positions as if they carried the same costs, the same exposure, the same protection need, the same responsibility conditions, the same language, and the same mechanisms of drift. This may appear fair because it refuses one-sided accusation. But it becomes false when it erases the very asymmetries that must be coordinated.

The second error is one-sided reduction. It treats non-symmetry as if only one role-position can structure effects, carry responsibility, drift, harm, depend, expose, protect, or be harmed. This may appear discriminating because it refuses false balance. But it becomes false when it turns asymmetry into a one-directional verdict and loses the bidirectional operation of the scene.

Adult Reciprocity requires a different discipline. It must be able to say that two role-positions affect one another without pretending that they do so equally. It must be able to say that one role-position may carry a greater cost in one dimension while the other carries greater exposure in another. It must be able to say that protection, dependency, vulnerability, power, credibility, and responsibility may all be real without collapsing them into equivalence.

This is why “both” language must be handled carefully. Both role-positions may drift, but not through the same mechanisms. Both may be harmed, but not under the same costs. Both may be responsible, but not with the same available language. Both may structure effects, but not with equal action-power, equal protection, equal exposure, or equal revisability.

Female vulnerability and female responsibility must remain jointly coordinable. If vulnerability is treated as immunity, the scene loses responsibility. If responsibility is treated as degradation, the scene loses dignity. The task is not to choose vulnerability or responsibility, but to coordinate both without turning either into rank.

Male power and male exposure must also remain jointly coordinable. If power is treated as total guilt, the scene loses legibility. If exposure is treated as innocence, the scene loses responsibility. The task is not to choose power or exposure, but to coordinate both without turning either into immunity, accusation, or reversal.

Protection and criticizability must remain jointly possible. A role-position may need real protection and still remain answerable to its structuring effects. A role-position may be criticizable and still require protection from degradation, humiliation, or overexposure. Protection without criticizability becomes immunity risk; criticizability without protection becomes degradation risk.

No symmetrizing flattening therefore means no rhetorical balance and no one-sided verdict. It means that the scene must remain open to real Ω (asymmetry) in its concrete distribution. The analysis must ask who carries what, who can name what, who is protected how, who is exposed how, who can revise what, and who becomes more burdened when the other role-position remains unbound.

This prepares a common conversion error. Once sexed asymmetry is present, dependency may be falsely read as lower standing. Dependency must therefore be separated from inferiority before the resulting rank artifact can be analyzed.

### 7.4 Dependency Is Not Inferiority

Dependency is a praxis relation, not a value relation. It may be embodied, material, temporal, social, affective, sexual, reproductive, protective, institutional, or linguistic. It may be intense, unequal, costly, and responsibility-relevant. But dependency does not make the dependent role-position lesser.

Dependency is not inferiority.

This sentence protects the real sexed praxis relation from a central possible rank conversion. A role-position may depend because bodies are vulnerable, because protection is needed, because reproduction and sexuality create exposure, because institutions distribute access unevenly, because timing matters, because recognition is mediated, because social language is incomplete, or because a scene organizes responsibility asymmetrically. None of this is, by itself, evidence of lower worth.

Dependency can increase exposure. A dependent role-position may have fewer alternatives, less control over timing, greater vulnerability to withdrawal, more need for recognition, or higher cost when protection fails. Such exposure must be readable without being degraded. If dependency is read as inferiority, then the very condition that requires coordination becomes evidence against the role-position that carries it.

Dependency can also structure responsibility. A role-position that depends is not thereby outside responsibility. Dependency may require self-binding, truthful participation, answerability to effects, and criticizability without humiliation. To say that dependency is not inferiority is not to say that dependency is innocence. It is to say that dependency must be coordinated as dependency, not ranked as lesser being.

This distinction is essential for Adult Reciprocity under sexed Ω (asymmetry). If dependency is denied, protection becomes difficult to justify and exposure becomes invisible. If dependency is ranked, protection becomes paternalistic, humiliating, or immunity-producing. If dependency is immunized, responsibility disappears. If dependency is degraded, dignity disappears. Adult Reciprocity requires dependency to remain visible without becoming either rank or exemption.

False Comparison distorts dependency when it turns a praxis relation into a value relation. It may read dependency as weakness, immaturity, deficiency, burden, entitlement, fragility, danger, or lesser agency. Once that conversion occurs, the scene stops asking how dependency should be coordinated and begins asking what the dependent position is worth. That conversion is inferiority misframing.

The task here is narrower: to keep dependency readable without letting it become rank. Dependency can be real, costly, protective, embodied, and responsibility-relevant without making a role-position inferior. The parallel distinction now has to be made on the other side of the comparison frame: strength is not superiority.

### 7.5 Strength Is Not Superiority

Strength is a praxis relation, not automatically superiority. In a real sexed praxis relation under Ω (asymmetry), strength may mean capacity, protection-capacity, action-power, exposure capacity, burden capacity, institutional access, bodily power, social expectation, or the ability to remain legible under pressure. These forms of strength may structure a scene. They may generate responsibility. They may also create exposure. None of that makes strength a higher worth.

Strength is not superiority.

This sentence is necessary because False Comparison can convert strength into rank. A role-position with more action-power may be treated as higher, more entitled, more authoritative, more credible, or less vulnerable. A role-position expected to protect may be treated as less entitled to protection. A role-position with greater capacity may be treated as if it cannot be harmed, cannot be exposed, or cannot require recognition. In each case, strength is no longer read as a praxis relation; it becomes a value relation.

Male power may be real. In sexed praxis relations, the male role-position may have forms of bodily, institutional, symbolic, economic, sexual, protective, or action-oriented power that structure cost and responsibility. To deny this would flatten real Ω (asymmetry) and make coordination less truthful. Real power can structure effects; where it structures effects, responsibility remains relevant.

But real power does not justify guilt-totalization. A role-position that has power is not thereby fully guilty, fully invulnerable, fully protected from exposure, or fully answerable for every structure in which it stands. Power can increase responsibility, but it does not erase vulnerability, dependency, burden, fear, exposure, or the need for dignity-preserving recognition. If power is read only as total guilt, the scene loses the ability to coordinate what the role-position actually carries.

Strength can also expose. The expectation of strength may make vulnerability less speakable, fear less credible, dependency less recognizable, and need for protection less legitimate. A role-position may be required to act, explain, protect, decide, endure, or absorb cost because strength is expected from it. This does not make strength false. It shows that strength can structure burden as well as capacity.

Superiority misframing begins when strength becomes rank, entitlement, immunity, or total authority. At that point, the scene stops asking how capacity, action-power, protection, exposure, and responsibility are distributed. It begins to ask who stands higher. The narrower point here is that strength must remain coordinable without becoming superiority.

This distinction protects both responsibility and dignity. If strength is denied, real power cannot be traced. If strength is ranked, the stronger position becomes superior or guilty by status rather than answerable to real structuring effect. If strength is immunized, responsibility disappears. If strength is degraded, D (dignity-in-practice) disappears. Adult Reciprocity requires strength to remain visible without becoming either rank or verdict.

The next step follows directly. If strength must not be read as superiority, then dependency, vulnerability, protection, and criticizability must also remain outside rank. This is especially important for female praxis. To protect female praxis by making it less answerable would be a false protection. To criticize it by making it lesser would be degradation. Chapter 7 must therefore hold female praxis as fully adult.

### 7.6 Female Praxis as Fully Adult

Female praxis must not be protected by infantilization. Protection may be real, vulnerability may be real, dependency may be real, and exposure may be real. But none of these requires female praxis to be treated as less adult, less criticizable, less responsible, or less capable of structuring effects.

To hold female praxis responsible is not to make it lesser;
it is to treat it as fully adult.

Adult here does not mean moral superiority, psychological maturity, or a ranking of persons. It means responsibility-bearing under real structuring effect. A role-position is treated as adult when its effects can be named without degradation, when its vulnerability can be protected without immunity, when its responsibility can be traced without humiliation, and when its self-binding can be expected without domination.

Female vulnerability can be real. A sexed role-position may face embodied exposure, dependency, social risk, reproductive burden, sexual vulnerability, credibility pressure, protection need, or historically stabilized asymmetry. These conditions must remain legible. If they are denied, the scene becomes brutalizing. If they are converted into inferiority, the scene becomes ranking. If they are converted into immunity, the scene loses responsibility.

Female protection can also be real. Protection may be required where exposure, dependency, bodily risk, sexual risk, reproductive asymmetry, or social vulnerability structures the scene. But protection does not cancel criticizability. Protection does not mean that a role-position cannot structure costs, displace responsibility, block integration, externalize self-binding, or participate in False Comparison. Real protection and real responsibility must remain jointly possible.

Critique of female praxis must therefore remain D (dignity-in-practice)-preserving. It must not turn vulnerability into lesser standing, protection into suspicion, responsibility into degradation, or criticizability into humiliation. To criticize a role-position as fully adult is not to strip it of protection. It is to refuse the false alternative between sentimental immunity and degrading accusation.

This point is also a guardrail against counter-drift. Chapter 7 does not license anti-female suspicion, does not claim that female praxis is immunized by nature, and does not turn protection into a hidden defect. Those would be new rank conversions. The chapter only insists that vulnerability, protection, responsibility, criticizability, and self-binding must remain coordinable within the real sexed praxis relation.

Female praxis is therefore neither lesser because it may be dependent, nor innocent because it may be vulnerable, nor immune because it may require protection. It is fully adult where it structures effects and remains answerable to those effects under conditions that preserve dignity. This prepares the corresponding distinction for the next section: male praxis may involve real power and still be exposed, vulnerable, and burdened in ways that must not be erased.

### 7.7 Male Praxis as Fully Exposed and Vulnerable

Male power may be real. Male overexposure may also be real. These do not cancel each other.

This sentence is necessary because sexed Ω (asymmetry) can be flattened in more than one direction. If male power is denied, the scene may lose access to real structuring effects: action-power, protection-capacity, institutional access, bodily threat, sexual asymmetry, authority expectation, or responsibility distribution. If male exposure is denied, the scene may lose access to other real effects: suspicion, burden of explanation, loss of vulnerability-language, restricted protection, or the expectation that the male role-position must remain answerable, strong, legible, and self-contained under pressure.

Power can structure responsibility. Where a role-position has greater action-power, greater protection-capacity, greater institutional access, or greater capacity to affect the field, its effects may require answerability. This does not mean total guilt. It means that power must remain traceable where it structures cost, exposure, recognition, protection, or responsibility.

Exposure can also structure cost. A role-position may be made more visible as danger, burden, suspect agency, possible domination, or expected responsibility. It may have less available language for vulnerability, less credible access to protection, and less room to name fear, dependency, confusion, or injury without being recoded as threat, weakness, manipulation, or failure. This does not erase power. It makes exposure part of the scene’s real distribution.

Male vulnerability does not erase male responsibility. If vulnerability becomes innocence, the scene loses answerability. If exposure becomes immunity, the scene repeats the error it was meant to correct. A role-position may be vulnerable, burdened, suspected, or overexposed and still structure effects that require responsibility.

Male responsibility does not erase male vulnerability. If responsibility becomes totalized guilt, the scene loses D (dignity-in-practice), protection, and accurate legibility. A role-position may have power, participate in asymmetrical structuring, or carry responsibility for effects while still being exposed to harm, burden, misrecognition, and loss of language.

This distinction does not turn Chapter 7 into a reversal theory. It does not claim that the male role-position is the real victim, that male power is unreal, or that exposure cancels responsibility. It only keeps the sexed praxis relation from becoming falsely coordinated by a comparison frame in which power means total guilt and vulnerability means total innocence.

The later discussion of overexposure will require more precision. Chapter 13 will distinguish the drift forms in which exposure pressure, immunization, and asymmetric explanatory poverty become stabilized. Chapter 7 does not develop that mechanism. Here the narrower point is that male praxis can be both powerful and exposed, both responsibility-bearing and vulnerable, both structurally relevant and dignity-relevant.

This prepares the closing distinction of the chapter. If female vulnerability must not become immunity, and male power must not become total guilt, then protection and responsibility have to remain jointly coordinable. Sexed Ω (asymmetry) cannot be read truthfully if protection erases responsibility or responsibility erases protection.

### 7.8 Real Protection, Real Responsibility

Protection can be real. Responsibility can remain real.

This is the closing rule for Chapter 7. A real sexed praxis relation under Ω (asymmetry) may require protection because bodies are exposed, dependency is real, vulnerability is real, sexuality and reproduction may structure risk, social language may be incomplete, and historically stabilized roles may distribute cost unevenly. But the need for protection does not erase responsibility. A protected role-position may still structure effects.

The reverse is also true. A role-position may be responsible for real effects without losing the need for protection. Responsibility does not authorize degradation, humiliation, overexposure, or loss of dignity. To hold a role-position responsible is not to make it available for contempt. It is to trace its effects under conditions that preserve answerability and dignity.

Protection without responsibility becomes immunity risk. Responsibility without protection becomes degradation or overexposure risk.

The first risk appears when vulnerability, dependency, exposure, or protection need makes a role-position unavailable to criticizability. In that case, protection may become a shield against answerability. The second risk appears when responsibility is assigned without preserving dignity, context, vulnerability, or real exposure. In that case, responsibility may become accusation, burden, or permanent exposure rather than truthful coordination.

Adult Reciprocity under sexed Ω (asymmetry) requires both. It requires real protection without immunity and real responsibility without degradation. It must be able to protect vulnerability while still tracing structuring effect. It must be able to name power without totalizing guilt. It must be able to name dependency without inferiority. It must be able to name strength without superiority. It must be able to coordinate asymmetry without converting it into rank.

The governing formula remains:

Asymmetry is not the failure.
False coordination of asymmetry is the failure.

Chapter 7 has shown why this formula matters for the real sexed praxis relation. Sexed asymmetry can be embodied, socially framed, historically stabilized, asymmetrically exposed, and responsibility-relevant without becoming essence, rank, diagnosis, or group verdict. It can structure roles, costs, protections, dependencies, vulnerabilities, and responsibilities without deciding in advance who is higher, lower, guilty, innocent, immune, or degraded.

Profiles are scene-bound drift patterns, not sex truths.

This sentence protects the drift analysis as a whole. Immunization, overexposure, asymmetric explanatory poverty, recognition without responsibility, and pseudo-equal standing must not be read backward into sexed essence. They are not truths about women or men. They are possible scene-bound configurations in which sexed Ω (asymmetry), limited legibility, False Comparison, protection, responsibility, and self-binding can become falsely coordinated.

The bridge to Chapter 8 is now clear. Real sexed praxis relation is not rank. Dependency is not inferiority. Strength is not superiority. Protection is not immunity. Responsibility is not degradation. But False Comparison can convert these relations into rank artifacts. Chapter 8 therefore turns to Inferiority and Superiority Misframing: the drift in which sexed difference and real asymmetry are read as lower and higher standing where coordination is required.

---

## 8. Inferiority / Superiority Misframing

Chapter 7 established that a real sexed praxis relation under Ω (asymmetry) is not already a rank order. Dependency is not inferiority. Strength is not superiority. Vulnerability, protection, exposure, embodiment, capacity, and responsibility may be asymmetrically distributed without thereby producing a hierarchy of worth. Chapter 8 turns to the point at which this distinction begins to fail: the point at which real difference or real Ω is read through rank.

The chapter therefore does not ask whether all claims of inferiority or superiority are false. They are not. Local dependence, limited capacity, greater skill, greater exposure, stronger leverage, and field-specific authority can be real. The issue is narrower: real praxis conditions become distorted when they are converted into value rank, adult-status rank, agency rank, or generalized authority. This is the function of Inferiority / Superiority Misframing.

### 8.1 Rank Artifacts

False Comparison does not merely compare. It becomes structurally decisive when comparison no longer helps coordinate real Ω (asymmetry), but substitutes rank for coordination. At that point, a real difference is not held as a condition to be carried, integrated, answered for, or corrected. It is translated into a position above or below. The scene then becomes easier to rank than to coordinate.

This produces a rank artifact. A rank artifact is not a real hierarchy, not a verified superiority, and not a demonstrated inferiority. It is the product of a frame in which a praxis condition is made to appear as a value position. Dependency becomes lower agency. Capacity becomes higher worth. Vulnerability becomes reduced adulthood, or alternatively interpretive privilege. Protection becomes either patronizing control or immunity from criticizability. In each case, something real may be present; the artifact lies in how it is ranked.

The basic movement is:

```text
False Comparison
→ Rank Artifact A: Inferiority Misframing
→ Rank Artifact B: Superiority Misframing
```

This formulation is deliberately limited. It does not say that comparison creates Ω (asymmetry). It does not say that all hierarchy is false, that all protection is domination, or that all vulnerability is immunization. It says that under False Comparison, real Ω can become legible through a rank frame before it is truthfully coordinated. Once this happens, the scene begins to organize around higher/lower, stronger/weaker, innocent/guilty, adult/less adult, authoritative/answerable, rather than around the more difficult question of how real asymmetry should be carried.

The issue is therefore not real inferiority or real superiority as such. The issue is false rank production under real Ω (asymmetry). A person may be less capable in a particular field without being of lower worth. A role-position may carry greater capacity without gaining ontological rank. A scene may contain real dependence without making the dependent side lesser, and real authority without making the authoritative side superior in being. Rank artifact begins where these distinctions collapse.

Misframing is therefore not merely a representation error. It is a coordination error. Once real Ω (asymmetry) is read as rank, R (responsibility) becomes easier to displace, Σ (integration) becomes harder to sustain, and Ψ (self-binding) becomes easier to weaken, simulate, or externalize. The scene no longer asks who is structurally affecting what, what costs must be integrated, or where self-binding is required. It asks instead who stands higher, lower, safer, weaker, more innocent, more rational, more vulnerable, more authoritative, or more entitled to define the scene.

This is why rank artifacts matter for Adult Reciprocity. Adult Reciprocity requires real Ω (asymmetry) to remain visible without being flattened, denied, immunized, overexposed, or converted into status. Rank artifacts do the opposite. They preserve the appearance of difference while falsifying the coordination of that difference. They do not remove asymmetry; they make it harder to answer for.

### 8.2 Inferiority Misframing

Inferiority Misframing occurs when limitation, dependency, vulnerability, need, exposure, criticizability, or responsibility is converted into lower rank or lower agency. It takes a situated praxis condition and turns it into a value verdict. The misframed side is no longer read as occupying a role-position under specific conditions of Ω (asymmetry), but as lesser, less adult, less authoritative, less rational, less responsible, or less capable of full participation.

This does not mean that all limitation is unreal. A role-position may lack capacity in a given field. A body may be more exposed in a specific situation. A person may depend on protection, translation, support, skill, timing, recognition, or access that another side can provide. A position may be unable to carry a cost that another position can carry. None of this is automatically false, and none of it needs to be hidden in order to preserve dignity-in-practice. The error begins when these limits are converted into diminished worth or diminished adulthood.

The structure of Inferiority Misframing can be stated simply:

```text
real dependency / vulnerability / limitation / exposure
→ lower rank or lower agency
```

This conversion is not neutral. Once dependency becomes inferiority, protection can become paternalism. Once vulnerability becomes lesser agency, recognition can become condescension. Once criticizability becomes degradation, responsibility becomes difficult to attach without appearing humiliating. Once exposure becomes lower status, the exposed side may be protected from responsibility rather than supported in carrying it. In each case, the rank artifact blocks truthful coordination of real Ω (asymmetry).

Inferiority Misframing is especially damaging because it can appear protective. A scene may seem to preserve dignity by shielding a vulnerable or dependent role-position from criticism, consequence attribution, or responsibility. But protection from degradation is not the same as protection from responsibility. To prevent humiliation is not to remove answerability. A role-position can require protection and still remain adult; it can require support and still remain responsible for its structuring effect where such effect is real.

The inverse danger also matters. A scene may reject protection in order to avoid inferiority. It may treat any need, vulnerability, dependency, or exposure as a threat to equal standing. In that case, real Ω (asymmetry) is flattened rather than coordinated. The vulnerable side may be overexposed in the name of parity, while the responsible side is denied the ability to protect without appearing superior. Inferiority Misframing therefore does not only produce paternalism; it can also produce abandonment disguised as equality.

The central distinction must remain intact: dependency is not inferiority. Vulnerability is not lower adulthood. Need is not lesser agency. Exposure is not diminished worth. These conditions may change what a scene requires; they do not by themselves establish rank. The task of Adult Reciprocity is not to deny dependency or vulnerability, but to coordinate them without converting them into lower standing.

This prepares the second rank artifact. If Inferiority Misframing converts limitation, dependency, or vulnerability into lower rank, Superiority Misframing converts capacity, status, sensitivity, protection-power, or attributed value into higher rank, priority, immunity, or generalized authority. The two artifacts are not simple opposites. They can reinforce each other, switch into each other, and appear on different sides of the same scene. Chapter 8 must therefore treat both before the coordination failure can be named fully.

### 8.3 Superiority Misframing

Superiority Misframing is the second rank artifact produced by False Comparison. It occurs when real or attributed capacity, sensitivity, protection-power, status, knowledge, rationality, vulnerability, or moral recognition is converted into higher rank, priority, immunity, or generalized authority. As with Inferiority Misframing, the issue is not that all superiority claims are false. The issue is the conversion of a situated difference into a rank position under real Ω (asymmetry).

Local superiority can be real. One role-position may know more, carry more, protect more effectively, understand a field better, act with greater competence, or bear a heavier structural exposure in a specific scene. A capacity difference may matter. A skill difference may matter. A protection asymmetry may matter. A difference in risk, access, timing, or consequence may matter. Adult Reciprocity does not require these differences to be denied. It requires them to be coordinated without turning them into ontological rank.

The structure of Superiority Misframing can be stated as follows:

```text
real or attributed capacity / sensitivity / vulnerability / status
→ higher rank, priority, immunity, or authority
```

The artifact begins where a local or field-specific advantage becomes generalized. Capacity becomes entitlement. Protection-power becomes command-right. Rationality becomes interpretive monopoly. Vulnerability becomes moral priority. Status becomes exemption. Competence becomes authority over the whole scene rather than responsibility for a specific structuring effect. Once this shift occurs, superiority no longer names a bounded difference in a bounded field. It becomes a rank device.

This is why Superiority Misframing can appear in more than one register. It can appear as dominance, but it can also appear as innocence, sensitivity, vulnerability, moral elevation, epistemic priority, or protective entitlement. A role-position may be treated as superior because it is strong; it may also be treated as superior because it is considered more vulnerable, more morally pure, more harmed, more reasonable, more burdened, or more deserving of protection. Superiority Misframing is therefore not reducible to overt domination. It names any conversion of a situated condition into generalized priority.

This conversion distorts R (responsibility). Where capacity contributes to real structuring effect under available legibility, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost/exposure conditions, responsibility should become more precise, not less. The role-position that structures more of the scene may have more to answer for, not more entitlement to escape answerability. Where vulnerability is real, protection may be required, but vulnerability does not by itself remove criticizability. Where competence is real, authority may be locally justified, but competence does not dissolve counter-scene exposure. Superiority Misframing reverses this discipline: what should increase answerability becomes a reason for priority, immunity, or control.

The effect on Σ (integration) and Ψ (self-binding) follows from this reversal. If one side’s capacity, vulnerability, status, or recognition becomes rank, the scene can no longer integrate cost and effect truthfully. The superiorized role-position may become less correctable precisely where its structuring effect is greatest. Self-binding can then be replaced by authority, privilege, moral insulation, protective exemption, or interpretive control. The scene still contains real Ω (asymmetry), but that Ω has become harder to coordinate because it is now organized as rank.

The central distinction is therefore this: strength is not superiority. Capacity increases responsibility where it structures effect. Capacity does not create ontological rank. Likewise, vulnerability can require protection without generating priority over the whole scene. Competence can justify local authority without creating generalized exemption. The task is not to deny capacity, vulnerability, or authority where they are real. The task is to prevent them from becoming rank artifacts.

### 8.4 Female Pseudo-Inferiority

Female Pseudo-Inferiority names a scene-bound drift pattern in which female-coded vulnerability, dependency, embodiment, exposure, relational need, or protection-relevance is converted into lower agency, lesser adulthood, reduced authority, or diminished criticizability. It is not a claim about women as persons, a biological essence, a psychological type, or a universal social rule. It names a possible misframing of a role-position under Ω (asymmetry).

The drift can begin from something real. Female-coded role-positions may carry forms of bodily exposure, social vulnerability, dependency risk, protection need, or recognition pressure that are not interchangeable with male-coded exposure. These asymmetries may matter for praxis. They may affect cost, timing, threat, access, support, protection, responsibility, and legibility. Chapter 7 established that such real Ω must not be flattened. Chapter 8 adds that it must also not be ranked.

Female Pseudo-Inferiority appears where protection-relevance becomes reduced adulthood. A role-position may be treated as needing protection in a way that quietly suspends its agency. Vulnerability becomes a reason not only to protect from harm, but to reduce expectation, soften criticizability, lower answerability, or exclude the role-position from full participation in consequence-bearing. What begins as protection can become condescension.

The same drift can occur through dependency. Dependency may be real in a specific field: material, bodily, institutional, temporal, relational, or situational. But when dependency is read as lower agency, the dependent role-position is no longer coordinated as an adult participant under real Ω (asymmetry). It is handled as lesser, fragile, secondary, or structurally incomplete. The problem is not that dependency is named. The problem is that dependency is converted into rank.

This conversion damages both recognition and responsibility. Recognition becomes paternalistic when it protects dignity by reducing agency. Responsibility becomes difficult to attach because answerability appears as degradation. Critique becomes risky because the role-position has already been placed lower; to criticize it seems to confirm inferiority. The result is a structurally unstable scene: either the female-coded position is protected from responsibility, or responsibility appears humiliating. Adult Reciprocity requires a third possibility: protection without de-adulting, responsibility without degradation.

Female vulnerability can be real. Female agency can be real. Female responsibility can be real. These must remain jointly coordinable. If vulnerability is denied, the scene becomes falsely symmetrical and may overexpose the vulnerable role-position. If agency is denied, the scene becomes paternalistic and may remove adult participation. If responsibility is denied, recognition becomes incomplete. Female Pseudo-Inferiority names the misframing in which one of these elements is preserved by sacrificing the others.

This is why the drift cannot be corrected by simple reversal. It is not enough to declare full equality if equality means ignoring real Ω (asymmetry). It is not enough to provide protection if protection lowers agency. It is not enough to affirm dignity if dignity becomes insulation from criticizability. The task is to hold vulnerability, agency, responsibility, and dignity-in-practice together without letting any one of them become a rank substitute for coordination.

Female Pseudo-Inferiority therefore prepares the opposite but related risk: female-coded vulnerability, recognition, or protection-relevance may also be converted not into lower rank, but into higher moral priority or immunity. That is not the same drift. It is the next rank artifact, and it must be handled separately.

### 8.5 Female Pseudo-Superiority

Female Pseudo-Superiority names a different rank artifact from Female Pseudo-Inferiority. It occurs where female-coded vulnerability, recognition, sensitivity, protection-relevance, relational exposure, or moral legibility is converted into higher priority, interpretive authority, exemption from criticizability, or reduced answerability under Ω (asymmetry). Like all pseudo-forms in this chapter, it is not a claim about women as persons, not a sex truth, and not a psychological diagnosis. It names a possible scene-bound drift pattern.

The drift often begins from conditions that may be real. Vulnerability may be real. Exposure may be real. Protection may be required. Recognition may be overdue. A role-position may indeed be placed under costs, risks, interpretive burdens, or embodied vulnerabilities that another role-position does not carry in the same way. EDEN does not treat these conditions as false merely because they can later be misframed. The error begins only where these conditions are converted into priority, immunity, or authority over the scene as such.

The structure can be stated as follows:

```text
female-coded vulnerability / recognition / sensitivity / protection-relevance
→ priority, immunity, interpretive authority, or suspension of criticizability
```

This conversion is easy to miss because it can appear as care. A scene may rightly seek to protect a vulnerable role-position from degradation, exposure, dismissal, or humiliation. But protection from harm is not the same as protection from responsibility. Recognition is not the same as immunity. Sensitivity is not the same as final interpretive authority. Once these distinctions collapse, the protected or recognized position may become less answerable precisely where its structuring effect remains real.

Female Pseudo-Superiority therefore does not consist in “being vulnerable.” It consists in the rank conversion of vulnerability. A vulnerable role-position may still structure timing, speech, recognition, emotional cost, access, permission, framing, or consequence distribution. Where that structuring effect is real, R (responsibility) cannot be suspended simply because vulnerability is also real. The question is not whether vulnerability deserves protection. The question is whether protection has been converted into exemption from answerability.

The same applies to recognition. A role-position may require recognition because it has been unseen, misread, underprotected, or exposed. Such recognition may be structurally necessary for D (dignity-in-practice). But recognition becomes a rank artifact when it removes criticizability. If a recognized position can define the scene, name injury, claim priority, assign blame, or block correction without remaining answerable to its own structuring effect, then recognition has drifted into pseudo-superiority. The scene still speaks the language of dignity, but its coordination of Ω (asymmetry) has become false.

This is why Female Pseudo-Superiority must be distinguished from misogynistic suspicion. The point is not that female vulnerability, sensitivity, or recognition claims are secretly manipulative. That would be a diagnostic and person-evaluative reading, and it would violate the method of this paper. The point is structural: any role-position can become falsely coordinated when a real condition is converted into rank. Female-coded vulnerability is not exempt from that possibility, just as male-coded strength is not exempt from responsibility.

The damage is also not one-sided. Where female-coded vulnerability becomes pseudo-superior, the female-coded role-position may lose adult participation because it is no longer required to remain answerable to its own effects. The male-coded or other counterpart may become overexposed, not because its vulnerability is unreal, but because its vulnerability becomes harder to name without appearing threatening, accusatory, or dominant. The scene then loses shared correctability: one side is protected from degradation by being shielded from responsibility, while the other is made answerable without equivalent access to recognition.

To protect vulnerability is not to suspend agency. To recognize dignity is not to remove responsibility. To preserve criticizability is not to license humiliation. Adult Reciprocity requires all three distinctions at once. If vulnerability is denied, protection fails. If agency is denied, recognition becomes incomplete. If responsibility is denied, dignity becomes immunity. Female Pseudo-Superiority names the drift in which protection and recognition are preserved by sacrificing answerability.

This prepares the male-coded counterpart. If female-coded vulnerability can be converted either into lower agency or into protected priority, male-coded vulnerability can be converted into weakness, threat, immaturity, control-attempt, or illegitimate need. That drift is not the same structure, and it cannot be reduced to a reversal. It must be named separately.

### 8.6 Male Pseudo-Inferiority

Male Pseudo-Inferiority names the rank artifact in which male-coded vulnerability, need, hurt, fear, uncertainty, dependency, or desire for recognition is translated into weakness, immaturity, threat, domination, control-attempt, or illegitimate demand under Ω (asymmetry). It is not a claim that male-coded role-positions are essentially vulnerable, morally innocent, or structurally powerless. It names a possible misframing in which male-coded exposure becomes less legible as vulnerability because it is pre-read through capacity, danger, responsibility, or power.

This point requires a specific clarification. Male-coded emotional life is not treated here as thinner, simpler, less deep, or less real. The misframing does not concern emotional depth. It concerns legibility, permission, handling, and coordination. Where male-coded hurt, fear, grief, dependency, shame, confusion, or need appears in a scene, it may be translated less readily into vulnerability and more readily into weakness, immaturity, threat, control, entitlement, or excessive demand. The problem is not fewer emotions. The problem is a distorted field of emotional legibility under real Ω (asymmetry).

The structure can be stated as follows:

```text
male-coded vulnerability / need / hurt / uncertainty / dependency
→ weakness, immaturity, threat, control-attempt, or illegitimate demand
```

This misframing can arise because male-coded capacity is treated as if it canceled male-coded exposure. If a role-position is read as stronger, more dangerous, more responsible, more physically capable, more socially empowered, or more structurally advantaged, then its vulnerability may appear less credible. Its fear may appear as aggression. Its hurt may appear as accusation. Its need for explanation may appear as control. Its uncertainty may appear as incompetence or immaturity. Its request for recognition may appear as a demand for authority.

None of this means that male-coded power is unreal. Male power may be real. Male threat may be real. Male leverage may be real. Male responsibility may be real. The point is that these realities do not erase vulnerability, need, exposure, or emotional depth. A role-position can carry real capacity and still be exposed. It can structure the scene and still require recognition. It can be responsible for its effects and still be vulnerable to misrecognition, overexposure, or illegible harm.

Male Pseudo-Inferiority becomes especially damaging where criticizability and vulnerability collapse into each other. If male-coded vulnerability is read as weakness, then admitting hurt can reduce standing. If it is read as threat, then naming pain can become unsafe for the scene. If it is read as control, then asking for explanation can be treated as domination. If it is read as immaturity, then need becomes evidence of lesser adulthood. The result is not adult responsibility. It is a rank artifact that makes responsibility harder to coordinate truthfully.

This drift also distorts R (responsibility). Where male-coded action-power or capacity structures an effect, R must remain attachable. But where all male-coded vulnerability is treated as suspect, R can become totalizing: the role-position is made answerable for effect while losing access to recognition, explanation, or repair of its own exposure. That is not Adult Reciprocity. Responsibility without vulnerability-legibility becomes overexposure; vulnerability without responsibility would become immunity. The point is to hold both together.

The same distortion blocks Σ (integration) and Ψ (self-binding). If the scene cannot integrate male-coded vulnerability without converting it into weakness, threat, or control, then costs remain unintegrated. If the role-position can only be self-bound as strong, stable, responsible, and non-needing, then Ψ becomes brittle or externalized. The scene may demand self-binding while denying the conditions under which self-binding can be shared, revised, or recognized.

Male Pseudo-Inferiority therefore does not reverse responsibility. It does not say that male-coded role-positions are secretly the lower or more injured side. It says that a real scene can falsely coordinate male-coded exposure by denying its vulnerability-legibility. Male power may be real. Male vulnerability may also be real. These do not cancel each other. Adult Reciprocity requires that both remain coordinable without turning capacity into rank or vulnerability into suspicion.

### 8.7 Male Pseudo-Superiority

Male Pseudo-Superiority is the opposite rank artifact only in appearance. It occurs where male-coded strength, force, rationality, performance, protection capacity, status, competence, endurance, or action-power is converted into higher worth, command-right, interpretive authority, exemption, or generalized superiority under Ω (asymmetry). It is not a claim that all male-coded capacity is false, oppressive, or illegitimate. It is a claim about the rank conversion of capacity.

The drift often begins from real differences. A male-coded role-position may carry physical strength, institutional leverage, economic access, technical competence, social authority, protective capacity, or field-specific skill. These differences can matter for praxis. They may create responsibility, exposure, obligation, or risk. They may make the role-position structurally more consequential in a given scene. Adult Reciprocity does not require these capacities to be denied. It requires them to remain answerable to the effects they structure.

The structure can be stated as follows:

```text
male-coded strength / force / rationality / performance / protection capacity / status
→ authority, command-right, higher worth, exemption, or generalized rank
```

The misframing begins when capacity becomes superiority. Strength becomes a reason to command rather than a condition that increases responsibility. Rationality becomes interpretive monopoly rather than a contribution to shared correction. Protection capacity becomes entitlement to define the protected side. Endurance becomes moral rank. Performance becomes worth. Status becomes exemption. The local fact of being able to do more, bear more, provide more, decide more, or impose more is converted into a general rank over the scene.

This conversion damages the very responsibility it appears to elevate. Where male-coded capacity structures real effects, R (responsibility) should become more precise. The role-position that can protect may need to answer for how protection is framed. The role-position that can decide may need to answer for what its decision makes possible or impossible. The role-position that can endure may need to answer for whether endurance becomes silence, domination, withdrawal, or overcontrol. Capacity increases responsibility where it structures effect. Capacity does not create ontological rank.

Male Pseudo-Superiority also distorts protection. Protection can be real. It may be necessary, valuable, and structurally adult. But protection becomes a rank artifact when it gives the protecting position authority over the protected position as such. The protected side is then no longer coordinated as fully adult under real Ω (asymmetry), and the protecting side is no longer bound to the limits of its own protective effect. What should be D (dignity-in-practice) becomes hierarchy; what should be responsibility becomes authority.

The same drift can appear through rationality or competence. A role-position may indeed understand a field better, perceive a risk earlier, or carry a decision more effectively. But local competence does not settle the whole scene. It does not remove the need for counter-scene, criticizability, recognition, or shared correction. When competence becomes generalized superiority, Σ (integration) is blocked because other costs and perspectives cannot enter. Ψ (self-binding) is weakened because the competent side is no longer required to bind itself to the limits of its own frame.

Male Pseudo-Superiority is therefore not corrected by denying male-coded capacity, strength, or protection-power. Denial would only produce another false coordination. The correction lies in refusing rank conversion. Strength can be real without becoming superiority. Protection can be real without becoming command. Rationality can be real without becoming monopoly. Status can be real without becoming exemption. Capacity can increase answerability without increasing worth.

This completes the four pseudo-forms needed for Chapter 8. Female-coded vulnerability can be misframed as lower agency or as protected priority. Male-coded capacity can be misframed as superior authority, while male-coded vulnerability can be misframed as weakness, threat, or illegitimate need. These are not sex truths and not person types. They are scene-bound rank artifacts. Their importance lies in what they do to coordination: they make real Ω harder to carry without displacing responsibility, blocking integration, or weakening self-binding.

### 8.8 Misframing as Coordination Failure

Inferiority and Superiority Misframing matter because they falsely coordinate real Ω (asymmetry). They do not merely misdescribe persons, roles, or capacities. They reorganize how responsibility, recognition, protection, cost, exposure, language access, and criticizability can move through a scene. Once a praxis condition is read as rank, the scene becomes less able to coordinate what is actually happening.

The shared structure can be stated in two movements:

```text
Inferiority Misframing:
real dependency / vulnerability / limitation / exposure
→ lower rank or lower agency

Superiority Misframing:
real or attributed capacity / sensitivity / vulnerability / status
→ higher rank, priority, immunity, or authority
```

Both movements distort R (responsibility). In Inferiority Misframing, R becomes difficult to attach because answerability appears as degradation. In Superiority Misframing, R becomes difficult to attach because capacity, vulnerability, status, or recognition is converted into priority or exemption. In both cases, responsibility no longer follows real structuring effect. It follows rank.

This also blocks Σ (integration). Real costs cannot be integrated if they first have to pass through a hierarchy of worth. A dependent role-position may be protected by being made less adult. A capable role-position may be burdened by being made less vulnerable. A vulnerable role-position may be shielded by becoming less criticizable. A competent role-position may be authorized beyond the limits of its competence. These scenes do not lack difference. They lack truthful integration of difference.

Misframing also weakens Ψ (self-binding). Where a role-position is placed lower, self-binding can become humiliation: to answer for one’s effect appears to confirm lesser standing. Where a role-position is placed higher, self-binding can become optional: to answer for one’s effect appears unnecessary because rank has already granted priority, authority, or immunity. In both cases, Ψ no longer binds the relevant actor to its own structuring effect in a stable and revisable way.

This is the decisive point: misframing becomes dangerous when it organizes coordination, not merely when it appears as an opinion. A scene may contain mistaken beliefs, crude stereotypes, or partial interpretations without yet becoming structurally governed by them. Misframing becomes praxeologically decisive when the rank frame begins to decide who may speak, who must explain, who is protected, who is exposed, who is criticizable, who is believed, who must absorb cost, and who can revise the scene without being degraded or immunized.

The four pseudo-forms developed in this chapter are therefore not a typology of persons. They are four ways rank artifact can interfere with Adult Reciprocity under real Ω (asymmetry). Female-coded vulnerability can be misframed as lesser agency. Female-coded vulnerability can also be misframed as protected priority. Male-coded vulnerability can be misframed as weakness, threat, or illegitimate demand. Male-coded capacity can be misframed as authority, command-right, or higher rank. None of these forms is a sex truth. Each names a possible drift in how a scene coordinates asymmetry.

The chapter has therefore added one step to the argument. Chapter 6 showed how False Comparison can become an attractor when comparison substitutes for coordination. Chapter 7 showed that real sexed praxis relation under Ω (asymmetry) is not itself rank. Chapter 8 has shown how False Comparison can convert that relation into rank artifacts. The next step is to show how these artifacts become more than misreadings: they become false coordination frames.

Chapter 9 begins where rank artifact becomes false coordination of real asymmetry. Its central question is no longer only whether a difference has been misread as lower or higher rank. It asks how a real Ω (asymmetry) field becomes organized through a false frame such that R (responsibility) is displaced, Σ (integration) is blocked, Ψ (self-binding) is weakened or externalized, and Adult Reciprocity becomes structurally harder to sustain.

---

## 9. False-Coordinated Real Asymmetry

Chapter 8 showed how real difference and real Ω (asymmetry) can be converted into rank artifacts. Dependency can be misread as inferiority; strength can be misread as superiority; vulnerability can be misread as either lesser agency or protected priority; capacity can be misread as higher rank or command-right. Chapter 9 now names the mechanism that makes those misframings structurally decisive: they become false coordination of real asymmetry.

### 9.1 Definition

False-Coordinated Real Asymmetry names the central mechanism of PMS–EDEN. It occurs where real Ω (asymmetry) remains operative, but is coordinated through a frame that displaces R (responsibility), blocks Σ (integration), weakens or externalizes Ψ (self-binding), and thereby makes Adult Reciprocity harder to sustain. The asymmetry is not necessarily false. The coordination is false.

The mechanisms and form families developed in Chapters 9–11 are analytically reconstructed conditional configurations. Frequency-marking language within these chapters states structural hypotheses about possible tendencies, not measured recurrence, prevalence, or population distribution. Whether a configuration occurs or repeats in a particular scene remains a descriptive claim requiring scene-bound evidence.

The mechanism can be stated in its minimal form:

```text
real Ω
+ false coordination frame
+ displaced R
+ blocked Σ/Ψ
= false-coordinated real Ω
```

This formula is deliberately not a claim that the asymmetry is invented. A scene may contain real vulnerability, real power, real dependency, real protection need, real capacity, real exposure, real history, real cost, or real inequality. EDEN does not become stronger by denying these realities. It becomes structurally precise only when it can ask how they are coordinated. The failure begins where real Ω (asymmetry) is organized through a frame that prevents responsibility from following actual structuring effect and prevents integration or self-binding from carrying the real cost of the scene.

A frame is not false simply because it is a frame. All praxis is framed. A scene must be made legible through some selection of relevance, boundary, timing, role, cost, and possible response. A protection frame may be locally valid. A vulnerability frame may be locally valid. A responsibility frame may be locally valid. A parity frame may be locally valid. A recognition frame may be locally valid. The question is not whether a frame is partial. All frames are partial. The question is whether the frame can still coordinate real Ω (asymmetry) truthfully.

A locally valid frame can still be false as coordination. Protection may be needed and still become false coordination if it removes criticizability or relocates responsibility away from actual effect. Equality may be formally justified and still become false coordination if it flattens real exposure or shifts unequal costs into invisibility. Vulnerability may be real and still become false coordination if it grants immunity from answerability. Responsibility may be real and still become false coordination if it becomes guilt-totalization, outcome-liability, or unilateral burden. The frame becomes false where it organizes real Ω (asymmetry) in a way that displaces R (responsibility) and blocks Σ (integration) / Ψ (self-binding).

False coordination therefore differs from simple error. It is not merely a wrong belief about a role-position. It is not merely a bad description, a crude stereotype, or an unfair comparison. These may contribute to it, but they do not exhaust it. False coordination names the structuring of a scene: who must answer, who may remain unexplained, who is protected, who is exposed, who can be criticized, who must integrate cost, who must self-bind, and who can avoid or externalize self-binding without the avoidance becoming legible.

This is why False-Coordinated Real Asymmetry is the technical center of the paper. False Comparison can attract a scene into rank. Rank artifacts can misframe dependency, strength, vulnerability, and capacity. But reciprocity is lost only where these frames begin to govern coordination: where R (responsibility) no longer follows real structuring effect, where Σ (integration) cannot integrate the actual cost or exposure, and where Ψ (self-binding) is weakened, simulated, avoided, or shifted elsewhere.

The aim is to define the central mechanism before differentiating its variants. Frame shifts, non-action and non-binding, the full Responsibility Principle, specific drift patterns, and regime stabilization remain dependent developments rather than parts of the mechanism’s definition. False-Coordinated Real Asymmetry is the hub relation that makes those forms structurally intelligible.

### 9.2 Asymmetry Misrepresentation versus False-Coordinated Real Asymmetry

False-Coordinated Real Asymmetry must be distinguished from Asymmetry Misrepresentation. The distinction is simple, but it is decisive for the whole argument:

```text
Asymmetry Misrepresentation:
real Ω is described falsely.

False-Coordinated Real Asymmetry:
real Ω is coordinated falsely.
```

Asymmetry Misrepresentation occurs when a real asymmetry field is described in the wrong terms. A dependency may be described as weakness. A capacity may be described as worth. A vulnerability may be described as innocence. A protection relation may be described as authority. A responsibility relation may be described as blame. A non-action may be described either as neutrality where it structures the scene, or as action where it does not. In each case, the description fails to carry the real structure of Ω (asymmetry).

Misrepresentation matters because descriptions can shape coordination. If dependency is described as inferiority, protection may become paternalistic. If capacity is described as superiority, answerability may become authority. If vulnerability is described as immunity, criticizability may become degradation. If parity is described as reciprocity, unequal costs may disappear. Description is not harmless. It can make some forms of responsibility, integration, self-binding, and correction easier or harder to see.

But EDEN does not stop at misdescription. Its central object is false coordination. False-Coordinated Real Asymmetry occurs when the scene does not merely describe real Ω (asymmetry) falsely, but organizes praxis around that false description or around a locally valid frame that cannot carry the whole coordination task. The issue is no longer only what is said about the asymmetry. The issue is how the asymmetry is carried: who bears cost, who receives recognition, who is shielded, who is exposed, who can correct, who must absorb, who must bind, and who can remain unbound.

This distinction prevents EDEN from becoming merely a theory of discourse or representation. A false description may be present without yet governing the scene. Conversely, a scene may use mostly acceptable descriptions while still coordinating Ω (asymmetry) falsely. A protection frame may sound respectful. A recognition frame may sound dignifying. A responsibility frame may sound adult. A parity frame may sound fair. None of this is sufficient. The decisive question is whether the frame allows R (responsibility) to follow real structuring effect, whether Σ (integration) can integrate the relevant costs and exposures, and whether Ψ (self-binding) remains possible for the actors whose effects structure the scene.

This also prevents EDEN from becoming a suspicion machine. A frame is not false because it names vulnerability, protection, equality, responsibility, recognition, autonomy, or harm. Each of these may be necessary. The frame becomes false coordination only where it carries real Ω (asymmetry) in a way that makes some structuring effects illegible, shifts responsibility away from where it belongs, simulates integration without integrating cost, or relocates self-binding onto another role-position.

The practical theoretical point is therefore narrow: naming an asymmetry more accurately may be necessary, but it is not sufficient. A scene can improve its description while leaving the coordination unchanged. It can adopt better vocabulary, acknowledge vulnerability, affirm equality, name responsibility, recognize harm, or reject hierarchy, while still distributing cost, criticizability, protection, recognition, and self-binding in the same false way. EDEN’s target is that deeper coordination failure.

This is why Chapter 9 proceeds from definition to frame analysis. The next question is not simply which descriptions are wrong. It is which frames can organize real Ω (asymmetry) so that R (responsibility) is displaced, Σ (integration) is blocked, and Ψ (self-binding) is weakened, simulated, externalized, or shifted elsewhere.

### 9.3 False Coordination Frames

A false coordination frame is not simply a false belief, a bad interpretation, or an ideological cover. It is a □ (frame) through which real Ω (asymmetry) is organized in a way that displaces R (responsibility), blocks Σ (integration), or weakens Ψ (self-binding). The frame may contain truths. It may name a real vulnerability, a real protection need, a real inequality, a real capacity difference, a real injury, or a real responsibility relation. It becomes false as coordination only where those truths are arranged so that the scene can no longer carry its actual structure.

This distinction is essential. EDEN does not treat protection, equality, vulnerability, responsibility, recognition, autonomy, or neutrality as suspect by default. Each can be necessary. Each can be locally valid. Each can help make a scene legible. A frame becomes false not because it is partial, but because its partiality begins to govern coordination in a way that prevents the relevant costs, effects, exposures, and answerabilities from being integrated.

The following frame families are therefore not a taxonomy of error. They are recurrent ways in which real Ω (asymmetry) can be falsely coordinated:

```text
comparison frame
protection frame
parity frame
superiority frame
vulnerability frame
responsibility frame
recognition frame
non-action / neutrality frame
legitimation frame
```

The comparison frame coordinates a scene through relative position. Its question is not first “what effect is being structured here?” but “who is higher, lower, stronger, weaker, more burdened, more innocent, more competent, more adult, or more entitled?” Comparison is not false by default. It can clarify differences. It becomes false coordination where comparison replaces the work of carrying real Ω (asymmetry). Then rank, not responsibility, begins to decide how the scene is held.

The protection frame coordinates a scene through exposure and shelter. It may be necessary where vulnerability, risk, bodily exposure, dependency, or threat is real. Protection becomes false coordination only where it reassigns adulthood, criticizability, or responsibility rather than protecting a role-position while keeping it answerable where its structuring effect is real. In that case, protection no longer protects a vulnerable adult within the scene; it reorganizes the scene so that protection substitutes for coordination.

The parity frame coordinates a scene through sameness, equality, mutuality, or equal standing. It may correct domination, condescension, or illegitimate hierarchy. But parity becomes false coordination where formal equality flattens real Ω (asymmetry), hides unequal cost, or makes protection, vulnerability, dependency, or differential exposure illegible. A parity frame can therefore appear fair while shifting unintegrated cost onto the role-position least able to make that cost visible.

The superiority frame coordinates a scene through greater capacity, status, rationality, endurance, knowledge, sensitivity, vulnerability, or moral standing. Local superiority may be real in a bounded field. It becomes false coordination where a local advantage becomes generalized rank, authority, priority, immunity, or exemption. In that case, what should specify R (responsibility) becomes a reason to reduce answerability.

The vulnerability frame coordinates a scene through injury, exposure, need, sensitivity, or protection-relevance. It may be indispensable where vulnerability is real. It becomes false coordination where vulnerability becomes final interpretive authority, immunity from criticizability, or unilateral access to recognition. A vulnerability frame can also become false in the opposite direction: where vulnerability is denied because it appears incompatible with capacity, strength, responsibility, or threat. In both cases, real Ω (asymmetry) is not carried truthfully.

The responsibility frame coordinates a scene through answerability, consequence, duty, role, or effect. It may be necessary where a role-position structures cost, harm, exposure, possibility, or correction. It becomes false coordination where R (responsibility) no longer follows real structuring effect. Responsibility can be underassigned, overassigned, totalized, moralized, displaced onto the more legible side, or removed from the side whose effects remain operative. Chapter 12 will develop this principle fully; here the point is only that responsibility can itself become a false frame when it stops tracking structure.

The recognition frame coordinates a scene through dignity, acknowledgement, visibility, repair of misrecognition, or protection from degradation. It may be necessary where a role-position has been unseen, humiliated, excluded, or made illegible. It becomes false coordination where recognition removes criticizability, prevents correction, or converts dignity into exemption. Recognition can also fail in the opposite direction: where the demand for answerability is treated as incompatible with dignity. In both cases, D (dignity-in-practice) is separated from real participation in responsibility.

The non-action or neutrality frame coordinates a scene through abstention, silence, delay, refusal, or claimed non-involvement. It may be valid where non-action does not structure the scene, where involvement would exceed one’s role, or where abstention preserves Χ (distance). It becomes false coordination where non-action structures cost, access, exposure, timing, or responsibility while remaining illegible as praxis. In that case, a role-position may avoid visible action while still shaping the scene through what it withholds, permits, delays, or leaves unbound.

The legitimation frame coordinates a scene by making its arrangement appear normal, fair, necessary, realistic, protective, autonomous, equal, responsible, or inevitable. Legitimation is not automatically deception. A scene may need reasons, norms, and justificatory frames to become stable. It becomes false coordination where Φ (recontextualization) stabilizes a displaced arrangement so that the relevant asymmetry no longer appears as something requiring responsibility, integration, or self-binding.

These frame families can combine. A scene may use parity language to hide unequal exposure, protection language to remove criticizability, recognition language to suspend answerability, responsibility language to overburden one role-position, and neutrality language to conceal structuring non-action. The mechanism is not the presence of one suspicious frame. The mechanism is the way a frame, or a combination of frames, coordinates real Ω (asymmetry) such that R (responsibility) no longer follows actual structuring effect, Σ (integration) cannot carry the real cost, and Ψ (self-binding) is weakened, simulated, or shifted elsewhere.

This is why frame analysis must remain bounded. Chapter 9 does not diagnose a scene by naming which frame appears. A protection frame does not prove false coordination. A parity frame does not prove flattening. A vulnerability frame does not prove immunization. A responsibility frame does not prove overburdening. A neutrality frame does not prove passive praxis. The question is always structural and revisable: does the frame coordinate real Ω (asymmetry) truthfully, or does it displace responsibility and block integration or self-binding?

False Coordination Frames therefore require three analytic steps. First, the analysis must ask how R (responsibility) is displaced. Second, it must ask how Σ (integration) is blocked or simulated. Third, it must ask how Ψ (self-binding) is weakened, avoided, externalized, or shifted. Only then can these frame failures be specified as switching, repeating, stabilizing, or becoming regime forms.

### 9.4 Responsibility Displacement

Responsibility Displacement is the point at which R (responsibility) no longer follows real structuring effect. The question is not who appears morally worse, who feels more burdened, who is easier to criticize, or who can be made most visible as the source of a problem. The question is which role-position actually structures cost, exposure, possibility, blockage, protection, recognition, or consequence within the scene.

The guiding formula is:

```text
R follows real structuring effect
under available legibility,
capacity,
alternative possibility,
Θ trajectory,
and Ω cost/exposure conditions.
```

This formula does not reduce R (responsibility) to blame. It also does not reduce R to intention, causal origin, outcome-liability, or moral guilt. A role-position can structure an effect without intending it. It can also intend an effect without being able to structure it. It can be visible without being decisive, or decisive without being visible. Responsibility therefore has to be read through the configuration of the scene, not through immediate appearance, accusation, or self-description.

The first condition is available legibility. R (responsibility) cannot be assigned truthfully where the relevant structuring effect cannot yet be seen. Limited legibility does not erase responsibility, but it changes how responsibility can be read. A role-position may be carrying cost without being able to name it. Another may be shaping the scene through a frame that appears neutral. Another may be absorbing exposure because no language exists for the burden it carries. False coordination often begins by making one structuring effect highly legible and another structurally invisible.

The second condition is capacity. R (responsibility) increases where a role-position has real capacity to structure, prevent, redirect, absorb, expose, or correct an effect. But capacity does not create ontological rank, and it does not create unlimited liability. Capacity specifies where answerability can attach. A role-position with greater leverage may have more to answer for in the relevant field, but only where that leverage actually structures the scene. Capacity without structuring effect is not responsibility; structuring effect without capacity requires a different reading.

The third condition is alternative possibility. R (responsibility) becomes unstable if a role-position is made answerable for effects it had no available way to alter. Alternative possibility does not require ideal freedom, full control, or unlimited options. It requires a structurally available difference that could have mattered under the conditions of the scene. False coordination can overassign responsibility by treating unavailable alternatives as if they were available; it can also underassign responsibility by pretending that available alternatives did not exist.

The fourth condition is Θ (temporality). Responsibility does not always attach at the moment of visible action. Some effects are prepared earlier, stabilized over time, delayed, normalized, or made irreversible by prior non-binding. A role-position may structure the present by what it previously withheld, permitted, postponed, framed, or left uncorrected. R (responsibility) therefore follows the temporal trajectory of structuring effect, not only the moment at which conflict becomes visible.

The fifth condition is Ω (asymmetry) cost and exposure. Responsibility must be read together with the cost, risk, and exposure borne by each role-position. A formally identical demand can be structurally different under unequal exposure. A refusal may be low-cost for one side and high-cost for another. A request for explanation may be legitimate in one configuration and excessive in another. R (responsibility) is displaced when these asymmetries are ignored, moralized, or reassigned to the more legible side.

Responsibility Displacement can therefore take several forms. It can underassign R (responsibility) by treating a structuring role-position as merely passive, vulnerable, neutral, protective, or already burdened. It can overassign R by making one role-position responsible for the entire scene because it is stronger, more visible, more articulate, more reactive, or easier to criticize. It can misassign R by attaching answerability to the side that expresses cost rather than the side that structured it. It can totalize R by converting a real responsibility relation into an unlimited burden.

These forms are not mutually exclusive. A scene may underassign responsibility to one role-position while overassigning it to another. It may remove criticizability from the protected side while making the protecting side answerable for every consequence. It may treat vulnerability as exemption and capacity as total liability. It may treat neutrality as non-involvement even where abstention structures the scene. In each case, real Ω (asymmetry) remains operative, but R (responsibility) no longer tracks the structuring effect that actually organizes the scene.

Responsibility Displacement is not the full Responsibility Principle. The hub relation needed here is narrower: false coordination occurs where R (responsibility) is relocated away from real structuring effect. Once that happens, integration cannot proceed truthfully. The scene may still speak about fairness, protection, equality, recognition, or accountability, but the question of who actually structures what has already been displaced.

### 9.5 Blocked Σ

Blocked Σ (integration) names the failure of a scene to integrate the real costs, exposures, responsibilities, vulnerabilities, protections, dependencies, and consequences that its own structure produces. It is not the absence of harmony, agreement, emotional closure, or narrative coherence. A scene can feel coherent while integration is blocked. It can reach agreement while relevant costs remain displaced. It can stabilize a shared story while failing to carry the real structure of Ω (asymmetry).

Σ (integration) is blocked where the scene cannot bring its relevant elements into accountable relation. A vulnerability may be named without integrating the responsibility it still carries. A capacity may be acknowledged without integrating the exposure that accompanies it. A protection need may be recognized without integrating the agency of the protected role-position. A demand for equality may be affirmed without integrating unequal cost. The failure is not that something remains complicated. The failure is that the scene cannot hold the relevant complexity without suppressing one of its structuring elements.

The central warning is:

```text
Σ-simulation is not integration.
```

Σ-simulation (integration-simulation) occurs when a scene appears to have integrated its conflict because it has produced a stable description, a recognized victim-position, a responsible side, a protected side, a fairness language, or an agreed frame. But stability is not integration. Recognition is not integration. Explanation is not integration. Naming asymmetry is not integration. A scene integrates only where the relevant cost, exposure, responsibility, criticizability, protection, and self-binding can remain jointly coordinable.

Blocked Σ (integration) often follows Responsibility Displacement. If R (responsibility) has been moved away from real structuring effect, then the scene cannot integrate what is actually happening. It can only integrate the displaced version of the scene. The side made responsible may integrate costs it did not structure. The side shielded from responsibility may remain unintegrated precisely where its effects matter. The scene may then appear orderly, but its order rests on a false distribution of answerability.

Blocked Σ (integration) can also occur where one valid element is allowed to absorb the others. Vulnerability absorbs agency. Protection absorbs criticizability. Equality absorbs exposure. Responsibility absorbs recognition. Autonomy absorbs dependency. Harm absorbs counter-effect. Capacity absorbs vulnerability. In each case, something real is preserved, but it is preserved by preventing other real elements from entering the coordination. The result is not integration but reduction.

This is especially important for Chapter 9 because false coordination rarely looks like simple denial. It often integrates one part of the scene very well. It may integrate vulnerability while blocking responsibility. It may integrate responsibility while blocking vulnerability. It may integrate equality while blocking asymmetry. It may integrate protection while blocking adult participation. It may integrate recognition while blocking correction. The problem is not that the frame contains nothing true. The problem is that the frame integrates selectively.

Blocked Σ (integration) therefore weakens Adult Reciprocity. Adult Reciprocity requires real Ω (asymmetry) to be coordinated without converting it into rank, immunity, total liability, or invisibility. Where integration is blocked, reciprocity becomes partial. One side may be recognized but not answerable. Another may be answerable but not recognized. One cost may become visible while another disappears. One vulnerability may be protected while another becomes unspeakable. The scene still functions, but it functions by excluding what would have to be integrated.

This is why Chapter 9 must keep Σ (integration) distinct from reconciliation or repair. Integration does not mean that all conflict is resolved, that all actors agree, or that all costs can be made symmetrical. It means that the scene can carry its relevant structure without displacing responsibility, hiding exposure, denying vulnerability, suspending criticizability, or externalizing self-binding. Integration is a condition of truthful coordination, not a promise of closure.

Blocked Σ (integration) prepares the next step. If the scene cannot integrate real cost and responsibility, then self-binding will also be affected. A role-position may be asked to bind itself to a false distribution. Another may be released from binding because its structuring effect has been made illegible. Another may simulate binding by affirming the frame while leaving the relevant cost elsewhere. Chapter 9 therefore turns next from blocked integration to blocked Ψ.

### 9.6 Blocked Ψ

Blocked Ψ (self-binding) names the failure of a role-position to remain bound to the effects it structures, the costs it helps distribute, or the frame through which it participates in coordination. It is not the absence of sincerity, emotion, good intention, or verbal commitment. A scene can contain sincere actors and still contain blocked Ψ. The question is whether the relevant role-positions remain bound to their own structuring effects under real Ω (asymmetry).

Ψ (self-binding) can be blocked in several ways. It can be avoided, where a role-position does not bind itself to an effect it nevertheless helps structure. It can be simulated, where a role-position adopts the language of responsibility without carrying the cost that would make responsibility real. It can be externalized, where one role-position’s binding-load is shifted onto another. It can be weakened, where binding remains verbal but no longer constrains timing, correction, exposure, or consequence. In each case, the scene may still appear coordinated, but the binding relation is no longer truthful.

The minimal warning is:

```text
Non-binding can shift Ψ-load.

low Ψ on one side
→ increased Ψ-load on the other
```

This formula does not mean that every failure to act, speak, decide, or respond is already praxis. Nor does it mean that every unbound role-position is blameworthy. The hub relation is narrower: where a role-position remains unbound while its non-binding structures cost, exposure, timing, or responsibility, the Ψ (self-binding)-load does not disappear. It is often shifted elsewhere.

Blocked Ψ (self-binding) therefore often follows blocked Σ (integration). If the scene cannot integrate real cost and responsibility, it also cannot bind the relevant role-positions to those costs and responsibilities. One side may be required to absorb uncertainty, regulate affect, maintain continuity, interpret silence, carry explanation, or preserve the frame. Another side may remain formally innocent because it has not visibly acted, even though its refusal, delay, withdrawal, ambiguity, or non-response structures the scene. The visible side then appears more responsible because it is carrying more of the binding-load.

This is why blocked Ψ (self-binding) cannot be reduced to hypocrisy. Hypocrisy may be present, but it is not the mechanism. The mechanism is structural: the scene allows a role-position to avoid or simulate binding while another role-position must bind more tightly in order for the scene to remain livable, legible, or continuous. A non-binding position may therefore increase the other side’s burden without appearing to act upon it. The asymmetry remains real, but its self-binding distribution becomes false.

Blocked Ψ (self-binding) also affects criticizability. Where a role-position is not bound to its own structuring effect, criticism may miss its object. The criticizable side becomes the side that reacts, explains, presses, repairs, names, or absorbs. The less-bound side can remain protected by ambiguity, passivity, vulnerability, status, neutrality, or formal non-involvement. In such a scene, the question “who acted?” may obscure the deeper question: whose binding or non-binding structured the coordination?

This does not authorize a reverse verdict. A role-position may remain silent for valid reasons. It may refrain in order to preserve Χ (distance), avoid escalation, respect boundary, or because no alternative possibility is structurally available. Non-binding is not automatically false coordination. It becomes relevant only where it structures the scene while remaining illegible as structuring effect. The point is to keep the mechanism visible without turning it into accusation.

Blocked Ψ (self-binding) weakens Adult Reciprocity because reciprocity requires more than mutual presence, stated recognition, or formal equality. It requires role-positions to remain bound to the effects they help produce under real Ω (asymmetry). If one side can structure cost without binding itself to that cost, while another side must bind itself to the resulting instability, reciprocity has already begun to fail. The scene may still use the language of fairness, protection, autonomy, or recognition, but the distribution of self-binding is no longer reciprocal in the adult sense.

The next question is how such distributions become stable. A scene can contain displaced responsibility, blocked integration, and shifted self-binding without yet becoming durable. It becomes durable when those arrangements are recontextualized as normal, fair, necessary, protective, autonomous, equal, responsible, or realistic. That is the function of Φ Recontextualization and Legitimation.

### 9.7 Φ Recontextualization and Legitimation

Φ Recontextualization names the process by which a false coordination becomes recontextualized as a legitimate order of the scene. Under Φ (recontextualization), this does not merely add a story after the fact. It can change what the scene appears to be: protection appears as care, parity appears as fairness, vulnerability appears as authority, responsibility appears as unilateral burden, neutrality appears as non-involvement, and non-binding appears as freedom. The false coordination becomes harder to contest because it no longer appears as coordination at all.

Legitimation is the stabilizing side of this process. A scene may justify its arrangement by invoking equality, protection, autonomy, realism, maturity, dignity, vulnerability, harm, responsibility, or necessity. None of these legitimations is false by default. Each can be real. Each can be required. The question is whether the legitimation makes the real structure of Ω (asymmetry) more answerable, more integrable, and more self-binding, or whether it hides displaced R (responsibility), blocked Σ (integration), and shifted Ψ (self-binding).

The local formula is:

```text
Legitimation is action-power at the level of □/Φ.
```

At the level of □ (frame) and Φ (recontextualization), legitimation does something. It does not merely describe an arrangement; it gives that arrangement force, endurance, and apparent necessity. A role-position may not need to coerce, command, or visibly act if the frame itself makes its position appear natural or justified. In this sense, legitimation can function as action-power without becoming strict Action or Enactment. It structures what can be said, who must explain, which costs count, and which forms of non-binding remain invisible.

This is why false coordination often survives correction at the level of description. A scene may acknowledge asymmetry, name harm, affirm equality, recognize vulnerability, or accept responsibility in words, while Φ (recontextualization) continues to stabilize the same distribution of cost and self-binding. The scene appears revised, but its coordination remains intact. The language changes; the binding distribution does not.

Φ Recontextualization, as recontextualization, can occur through moral language. A displaced arrangement may become legitimate because it is framed as compassionate, respectful, protective, fair, adult, or necessary. It can also occur through realism: the scene is said to be simply how things work, what must be accepted, what mature actors tolerate, or what cannot be changed. It can occur through autonomy, where non-binding becomes freedom from obligation even where non-binding structures another’s cost. It can occur through responsibility, where one role-position’s greater capacity becomes the reason it must integrate costs that another position continues to produce.

The decisive feature is not the content of the justification, but its coordination effect. A justification becomes stabilizing where it makes displaced R (responsibility) appear proper, blocked Σ (integration) appear resolved, and shifted Ψ (self-binding) appear voluntary, fair, or inevitable. The scene becomes harder to challenge because contesting the arrangement now appears to contest protection, equality, dignity, autonomy, responsibility, realism, or care itself.

This is also why legitimation must not be treated as mere deception. Actors may sincerely inhabit the legitimating frame. A scene may have good reasons for protection, parity, recognition, or caution. False coordination does not require cynical manipulation. It requires a frame that makes a displaced arrangement durable. The failure lies in what the legitimation does to coordination, not in whether every actor consciously intends the displacement.

Φ Recontextualization can support stabilization without replacing Α (attractor) or the distinct mechanisms involved. Non-action and non-binding, responsibility attribution, immunization and overexposure, asymmetric explanatory poverty, recognition drift, and downstream regime stabilization retain their own conditions and explanatory homes. The common point is narrower: recontextualization can make displaced responsibility, blocked integration, and shifted self-binding appear legitimate, necessary, protective, equal, autonomous, or realistic; recurrent stabilization of that arrangement belongs to Α.

The hub relation is now complete. False-Coordinated Real Asymmetry begins with real Ω (asymmetry). It passes through a frame that becomes false as coordination. It displaces R (responsibility), blocks Σ (integration), weakens or shifts Ψ (self-binding), and is recontextualized through Φ (recontextualization); where that arrangement becomes recurrently stabilized, it functions as Α (attractor). The final step of Chapter 9 is to show why this mechanism requires a transition to frame-shift mechanics: the Switch Family.

### 9.8 Transition to Switch Family

False-Coordinated Real Asymmetry is not necessarily static. A scene may move from vulnerability to protection, from parity to exit, from responsibility to authority, or from neutrality to non-binding while the same real Ω (asymmetry) and displaced coordination remain operative.

The Switch Family names these frame-shift mechanics. It is not a new origin of reciprocity loss, but a dependent account of how false coordination can change form while R (responsibility), Σ (integration), and Ψ (self-binding) remain displaced.

The transition can be stated in minimal form:

```text
same real Ω
→ different frame
→ different responsibility distribution
→ different critique access
→ different Σ/Ψ blockage
```

A switch is not merely a change of topic, but neither is it evidence of manipulation, bad faith, or person type. It names a possible structural movement in which the frame changes while the underlying coordination failure persists. The hub has now been specified; the next chapter examines its movement.

---

## 10. The Switch Family

False coordination does not always remain in one frame. A scene may preserve the same real Ω (asymmetry) while changing the frame through which that asymmetry becomes legible. What first appears as protection may later appear as autonomy. What first appears as equality may later appear as exit. What first appears as responsibility may later appear as authority. Chapter 10 names this mobility: the Switch Family.

### 10.1 Switch Logic

A switch occurs when real Ω (asymmetry) remains operative, but the scene changes the frame through which that Ω is coordinated. The underlying asymmetry need not disappear, and the scene need not become more truthful merely because its language changes. A switch matters where the frame shift changes who must answer, who may criticize, which costs become visible, which exposures become protected, and how Σ (integration) or Ψ (self-binding) can reopen or remain blocked.

The basic structure is:

```text
Switch =
real Ω remains
+ operative frame changes
+ responsibility distribution changes
+ critique access changes
+ Σ/Ψ status changes
```

This formula does not make every frame change suspicious. A scene may shift frames because new information appears, because a risk becomes visible, because protection becomes necessary, because parity becomes possible, because a boundary must be respected, or because an earlier description was inadequate. Switching is not automatically drift. A frame change may correct a false coordination rather than preserve it.

The decisive question is therefore structural. A switch becomes relevant when it preserves false coordination while appearing to revise the scene. The language may change, but R (responsibility) remains displaced. The frame may soften, but Σ (integration) remains blocked. The scene may become more acceptable, more caring, more equal, more autonomous, or more responsible in appearance, while Ψ (self-binding) remains shifted away from the role-position whose effects continue to structure cost.

Switches are identified by their structural scene effects, not by presumed intention or person type. A switch does not prove manipulation. It does not prove bad faith. It does not diagnose a role-position. The question is not whether an actor “uses” a switch as a strategy. The question is whether the scene moves from one frame to another in a way that changes responsibility distribution, critique access, and Σ (integration) / Ψ (self-binding) status while leaving the underlying false coordination intact.

This matters because false coordination can become resilient precisely by changing its appearance. If a protection frame is criticized for suspending responsibility, it may become an autonomy frame: no one is being protected; a choice is simply being respected. If a parity frame is criticized for flattening exposure, it may become an exception frame: equality applies, but not here. If a responsibility frame is criticized for overburdening one side, it may become an authority frame: the burdened side is now entitled to decide. The switch preserves the displaced coordination while making the objection harder to formulate.

Switch drift is not established by one frame change. A single movement may be valid, corrective, or necessary; Adult coordination often requires shifts that reopen Σ (integration) and Ψ (self-binding). The dedicated drift test below therefore requires the convergence of pattern, consequence, and responsibility displacement. Only where movement preserves blockage while appearing to resolve it does the switch become drift-relevant.

The Switch Family is therefore not a taxonomy of personalities or tactics. It is a family of frame movements. Its members name recurring ways in which false coordination can move: into formal equality, into apparent subordination, into generalized superiority, into exception, into authority, or into exit. Each must be handled carefully, because each has a legitimate form. The task is not to condemn the frame. The task is to identify the scene effect when the frame changes.

The first member is Pseudo-Symmetry. It comes first not because it is the master mechanism, but because it is a particularly easy switch to confuse with adult reciprocity. Formal parity can be real and useful. It becomes pseudo-symmetrical only when parity covers over real Ω (asymmetry), displaced R (responsibility), and blocked Σ (integration) / Ψ (self-binding).

### 10.2 Pseudo-Symmetry

Pseudo-Symmetry is not the master mechanism of EDEN. It is one switch form within the Switch Family. It occurs when a scene shifts into the appearance of equality, parity, reciprocity, or mutuality while real Ω (asymmetry) remains unintegrated and the distribution of R (responsibility), Σ (integration), or Ψ (self-binding) remains false.

The structure can be stated as follows:

```text
Pseudo-Symmetry =
formal equality
+ unintegrated real Ω
+ displaced R
+ blocked Σ/Ψ
```

The key is not the presence of symmetry language. Symmetry, parity, equality, and equal standing can be necessary. They can correct domination, condescension, hierarchy, paternalism, or one-sided exposure. They can reopen Σ (integration) where a scene had previously been organized through rank. They can also support Ψ (self-binding) by making each role-position answerable as adult. Pseudo-Symmetry begins only where formal parity replaces the work of coordinating real Ω (asymmetry).

In Pseudo-Symmetry, the scene appears mutual before it has integrated its asymmetry. Both sides may be told that they are equally free, equally responsible, equally exposed, equally criticizable, or equally able to leave. But the formal equality does not ask whether cost, capacity, exposure, timing, dependency, or consequence are actually distributed equally. Parity becomes a frame that makes the asymmetry harder to name.

This switch can be especially powerful because it sounds adult. It avoids overt hierarchy. It refuses obvious paternalism. It speaks the language of equality rather than rank. Yet this is precisely why it can stabilize false coordination. A role-position that names unequal cost may now appear to reject equality. A role-position that asks for protection may appear to ask for privilege. A role-position that identifies greater structuring effect may appear to impose blame. Pseudo-Symmetry makes the objection look less adult than the false parity that produced it.

Pseudo-Symmetry also changes critique access. Under an openly hierarchical frame, the problem may be visible as hierarchy. Under a pseudo-symmetrical frame, the same asymmetry can be harder to criticize because the scene already claims equality. The critic must now overcome the appearance that the issue has already been solved. This increases the cost of naming real Ω (asymmetry), especially where the frame treats further asymmetry-talk as regression, resentment, dependency, or refusal of adult parity.

The effect on R (responsibility) is direct. If the scene treats the parties as formally symmetrical while their structuring effects remain asymmetrical, responsibility is displaced. One side may be made answerable for costs it cannot structure. Another may be released from answerability because the frame says both sides stand equally. Formal equality then masks the question that matters: who structures what, under which capacity, exposure, timing, and alternative possibility?

The effect on Σ (integration) is equally direct. Pseudo-Symmetry simulates integration by declaring the scene equal. But equality language is not integration. Parity does not by itself carry cost, vulnerability, protection, dependency, criticizability, or self-binding. If these remain unintegrated, then the scene has not become reciprocal. It has become formally balanced over an unresolved asymmetry.

The effect on Ψ (self-binding) follows from this. A role-position may be required to bind itself to a parity frame that does not carry its actual exposure. Another role-position may be released from deeper binding because the frame declares mutuality already achieved. In that case, the appearance of shared responsibility can conceal unequal binding-load. Low Ψ on one side may continue to increase Ψ-load on the other, even while the scene describes itself as equal.

This does not mean that symmetry should be rejected. Symmetry or parity can be useful when it reopens Σ (integration) and Ψ (self-binding). It can make previously protected, subordinated, superiorized, or exempted role-positions answerable again. It can prevent vulnerability from becoming immunity, capacity from becoming rank, or protection from becoming command. Parity is false only where it replaces truthful coordination rather than enabling it.

Pseudo-Symmetry is therefore a switch, not an origin. It does not explain all reciprocity loss. It does not create Ω (asymmetry). It does not replace false coordination as the central mechanism. Its function is narrower: it shows how a scene can move into equality language while preserving displaced R (responsibility), blocked Σ (integration), and distorted Ψ (self-binding). The next switch turns in a different direction: not into equality, but into apparent lower position, dependence, vulnerability, or weakness.

### 10.3 Pseudo-Subordination

Pseudo-Subordination names a switch in which apparent weakness, dependence, vulnerability, passivity, injury, or lower position begins to function as a coordination frame while real Ω (asymmetry) remains operative. It is not a claim that vulnerability is false. It is not a suspicion of dependence. It is not a diagnosis of strategy. It names a structural movement: a role-position appears less powerful, less active, or more exposed, while the scene’s responsibility distribution, critique access, and Σ (integration) / Ψ (self-binding) status are reorganized through that appearance.

The first guardrail is therefore absolute: genuine vulnerability, protection need, dependence, injury, and exposure are real. They may require recognition, shelter, patience, altered timing, reduced demand, or protection from degradation. A dependent or vulnerable role-position is not thereby suspicious. The “pseudo” in Pseudo-Subordination does not mean that the vulnerability is invented. It means that apparent subordination can become a frame through which real Ω (asymmetry) is coordinated falsely.

The structure can be stated as follows:

```text
Pseudo-Subordination =
apparent weakness / vulnerability / passivity / lower position
+ real structuring effect
+ lowered criticizability
+ displaced R
+ blocked Σ/Ψ
```

Pseudo-Subordination begins where apparent lower position changes how the scene can assign R (responsibility). A role-position may appear unable to structure the scene because it is vulnerable, dependent, silent, hurt, overwhelmed, passive, or in need of protection. Yet that same role-position may still structure timing, speech, access, permission, emotional cost, recognition, correction, or consequence distribution. The issue is not whether the position is “really” weak or secretly strong. The issue is whether its structuring effect remains answerable.

This switch is especially difficult because it can look like care to leave the subordinate appearance unquestioned. A scene may avoid critique in order not to humiliate. It may soften responsibility in order not to overburden. It may protect the vulnerable position from exposure in order to preserve dignity. These may be valid responses. Pseudo-Subordination appears only where the protection of apparent weakness prevents the scene from coordinating the role-position’s actual effects. Protection then shields not only from degradation, but from answerability.

The switch can also operate through passivity. A role-position may not visibly command, decide, impose, or act. It may appear only to receive, suffer, wait, withdraw, or need. But if its passivity structures what others must do, what they may say, what they must absorb, what they must explain, or how tightly they must bind themselves, then passivity is no longer merely absence from the scene. This does not yet mean passive praxis in the full sense. It means that the apparent lack of action may become part of a false coordination frame.

Pseudo-Subordination therefore alters critique access. To criticize the role-position may appear cruel, excessive, dominating, or humiliating because the position is framed as weaker. But if criticism is blocked wherever a structuring effect is real, then criticizability no longer follows structure. It follows appearance. The more subordinate the role-position appears, the less available critique becomes, even where its effects still organize cost, timing, or responsibility for others.

The effect on Σ (integration) is direct. The scene may integrate vulnerability while failing to integrate agency. It may integrate protection while failing to integrate responsibility. It may integrate injury while failing to integrate counter-effect. It may integrate dependence while failing to integrate the costs imposed by dependence. In each case, one true element is preserved by excluding another. That is not integration; it is selective coordination.

The effect on Ψ (self-binding) follows from the same structure. If the apparently subordinate role-position is not required to bind itself to the effects it helps produce, another role-position must often bind more tightly. The other side may have to absorb uncertainty, regulate speech, carry explanation, avoid critique, maintain continuity, or preserve the protective frame. Low Ψ on one side can therefore increase Ψ-load on the other, even when the low-binding side appears weaker.

This is why Pseudo-Subordination must not be confused with a reversal of power. It does not say that the apparently weaker side is secretly the dominant side. It does not say that vulnerability is a tactic. It does not say that dependence is manipulation. It says that apparent subordination can become structurally relevant where it changes responsibility distribution, reduces critique access, blocks integration, or shifts self-binding while real Ω (asymmetry) remains operative.

The valid form must remain visible. Vulnerability may rightly limit demand. Dependence may rightly require support. Injury may rightly change timing. Protection may rightly suspend certain forms of exposure. A scene is not falsely coordinated because it responds to weakness. It becomes falsely coordinated only where weakness, dependence, injury, or passivity becomes the frame through which a structuring effect is removed from answerability.

Pseudo-Subordination therefore belongs inside the Switch Family because it describes a movement in frame, not a person type. A scene may move from parity into protection, from responsibility into vulnerability, from critique into harm-avoidance, or from shared correction into shelter. These movements can be valid. They become drift only where the move preserves displaced R (responsibility), blocked Σ (integration), or shifted Ψ (self-binding). The next switch moves in the opposite direction: from local capacity, authority, virtue, or status into generalized superiority.

### 10.4 Pseudo-Superiority

Pseudo-Superiority names a switch in which local capacity, authority, status, competence, virtue, vulnerability, responsibility, or protection-power becomes generalized into higher rank, priority, command-right, or exemption while real Ω (asymmetry) remains falsely coordinated. It is not a denial that local superiority can be real. A role-position may indeed know more, carry more, protect more effectively, act with greater competence, or bear greater responsibility in a bounded field. The switch begins where that local condition becomes a general frame for authority, priority, or reduced answerability.

The structure can be stated as follows:

```text
Pseudo-Superiority =
local capacity / authority / virtue / status / protection-power
+ generalized rank or priority
+ displaced R
+ blocked Σ/Ψ
```

The first guardrail is simple: superiority in a bounded field is not automatically pseudo-superiority. Expertise can be real. Hierarchy can be functional. Authority can be legitimate. Protection-power can be necessary. A scene may need someone to decide, lead, protect, interpret risk, carry consequence, or act under time pressure. The question is not whether one role-position has greater capacity. The question is whether greater capacity remains bound to its field, its cost, its limits, and its R (responsibility).

Pseudo-Superiority begins where local capacity escapes its bounds. Strength becomes a right to define the whole scene. Competence becomes immunity from correction. Protection becomes authority over the protected side. Moral recognition becomes priority over critique. Responsibility becomes entitlement to govern. Status becomes exemption. In each case, a real or attributed advantage no longer specifies answerability; it becomes a frame that reorganizes answerability away from itself.

This switch changes critique access. A role-position framed as superior may become harder to criticize precisely because it is treated as more competent, more responsible, more burdened, more morally serious, more protective, or more necessary. Critique then appears ungrateful, irrational, immature, unsafe, or destabilizing. The superiorized position does not need to deny criticism directly. The frame can make criticism seem inappropriate before the criticism is heard.

The effect on Σ (integration) is selective. The scene may integrate capacity while failing to integrate the costs produced by capacity. It may integrate authority while failing to integrate the vulnerability of those affected by authority. It may integrate protection while failing to integrate the agency of the protected side. It may integrate responsibility while failing to integrate the limits of responsibility. A superiorized frame can therefore appear ordered while excluding the very elements that would make coordination truthful.

The effect on Ψ (self-binding) follows from this. A superiorized role-position may be less required to bind itself to the limits of its own frame, because its frame already appears competent, necessary, protective, or authoritative. Another role-position may have to bind itself more tightly: to accept the decision, absorb the cost, regulate objection, prove maturity, or remain grateful for protection. Low Ψ on the superiorized side can therefore increase Ψ-load on the other, even where the superiorized side appears to be carrying more responsibility.

Pseudo-Superiority must therefore be distinguished from real responsibility. Greater responsibility under Ω (asymmetry) does not create a right to govern the other. It may create a stronger requirement to answer for how one’s capacity structures the scene. The more a role-position can decide, protect, expose, delay, authorize, or define, the more precisely its effects may need to remain criticizable. Capacity increases answerability where it structures effect; it does not create ontological rank.

This also protects genuine authority. A scene is not falsely coordinated because authority exists. It becomes falsely coordinated where authority no longer remains answerable to the structuring effects it produces. Authority can reopen Σ (integration) when it clarifies responsibility, protects without de-adulting, limits harm, or coordinates a real risk. It becomes pseudo-superior where it blocks critique, suspends reciprocity, or treats local competence as general permission.

Pseudo-Superiority is therefore a switch in frame, not a claim about a superior person. A scene may move from responsibility into authority, from protection into command, from competence into exemption, or from moral seriousness into priority. These movements can be valid in bounded cases. They become drift only where they preserve displaced R (responsibility), blocked Σ (integration), or shifted Ψ (self-binding) while making the superiorized frame appear necessary, mature, or self-justifying.

### 10.5 Exception Switch

The Exception Switch occurs when a scene moves from an ordinary coordination frame into an exception frame that suspends, alters, or defers ordinary responsibility, criticizability, cost-truth, or self-binding under real Ω (asymmetry). It is one of the most delicate switches because exceptions can be legitimate. Crisis, injury, danger, trauma, exhaustion, emergency, asymmetrical exposure, or acute vulnerability may require altered timing, reduced demand, protection, or temporary suspension of normal expectations.

The first guardrail is therefore explicit: exception can be legitimate. A scene is not falsely coordinated because it recognizes that ordinary demands cannot apply unchanged. Protection can be necessary. Delay can be necessary. Lowered demand can be necessary. A role-position may need shelter from exposure, time to recover, or a temporary change in criticizability because the immediate cost of ordinary coordination would be excessive. The switch becomes relevant only where the exception frame reorganizes responsibility without remaining answerable to the conditions that justified it.

The structure can be stated as follows:

```text
Exception Switch =
ordinary coordination suspended
+ exception frame introduced
+ responsibility / criticizability / cost-truth altered
+ conditions of return or answerability become unclear
```

An exception frame becomes false coordination when it stops being bounded. The issue is not that the scene changes its demands. The issue is that the change no longer remains tied to legible conditions, proportional limits, or revisable return. An exception may begin as protection from overexposure, but drift into immunity from critique. It may begin as time for recovery, but drift into permanent non-answerability. It may begin as danger response, but drift into authority. It may begin as care, but drift into a frame that others cannot question without appearing cruel.

The Exception Switch therefore changes critique access sharply. To question the exception may appear to deny harm, dismiss vulnerability, ignore risk, or attack protection itself. This can be appropriate where the exception is real and fragile. But it becomes false coordination where the exception frame prevents any question about its scope, cost, duration, or effects. The critic is then not merely challenging a frame; the critic is positioned as threatening the vulnerable condition that justified the frame.

The effect on R (responsibility) depends on whether the exception remains answerable to its own conditions. A bounded exception can clarify responsibility: ordinary expectations are suspended here, for this reason, under these limits, with this cost acknowledged. A drifting exception displaces R: one role-position may be released from answerability while another must absorb the continuing costs of suspension. The exception then no longer protects a scene under pressure; it redistributes responsibility without naming the redistribution.

The effect on Σ (integration) is equally important. A legitimate exception must integrate both the need for suspension and the costs produced by suspension. If only the need is integrated, the costs disappear. If only the costs are integrated, the vulnerability is denied. The exception frame becomes false where one side’s exposure, delay, uncertainty, protection need, or burden is preserved by excluding another side’s exposure, delay, uncertainty, protection need, or burden. Integration fails when exception becomes one-sided cost-truth.

The effect on Ψ (self-binding) follows from the same problem. In a bounded exception, a role-position may be temporarily less bound to ordinary expectations while still bound to the exception’s limits, reasons, and effects. In a drifting exception, the role-position becomes less bound without the binding-load being integrated elsewhere. Another side may then have to bind more tightly: waiting, absorbing uncertainty, maintaining care, avoiding critique, or preserving the exception frame. Low Ψ under exception can therefore shift Ψ-load while appearing compassionate or necessary.

This does not mean that exception claims should be treated with suspicion. That would make EDEN itself a verdict machine. The question is not whether the exception is “really” valid in the abstract. The question is structural: does the exception remain tied to the conditions that make it necessary, and can the scene still coordinate responsibility, cost, criticizability, and self-binding while the exception holds? If yes, the exception may support truthful coordination. If no, the exception may become a switch that preserves false coordination.

The Exception Switch is therefore not anti-care, anti-trauma, anti-protection, or anti-boundary. It protects care by refusing to let care become immunity. It protects vulnerability by refusing to let vulnerability erase the costs that vulnerability may still structure. It protects exception by requiring exception to remain bounded, answerable, and revisable. Where this fails, the scene does not merely make an exception. It changes the frame in a way that can preserve displaced R (responsibility), blocked Σ (integration), and shifted Ψ (self-binding).

This prepares the next switch. If exception can suspend ordinary coordination, responsibility itself can also change frame: a role-position may begin with greater responsibility under real Ω (asymmetry), but that responsibility can drift into authority over the other. The next section names that movement.

### 10.6 Responsibility-to-Authority

Responsibility-to-Authority names a switch in which greater responsibility under real Ω (asymmetry) becomes a claim to govern, define, control, or overrule another role-position. It begins from a condition that may be real. One side may indeed carry more cost, more exposure, greater capacity, greater consequence, or a larger share of the scene’s structuring burden. The switch begins only where that responsibility is converted into authority over the other rather than answerability for one’s own structuring effect.

The central guardrail is:

```text
Greater responsibility under Ω
does not create a right
to govern the other.
```

Responsibility can justify action. It can justify protection, refusal, limit-setting, decision, intervention in a bounded field, or increased answerability. It can require a role-position to act rather than remain passive. But responsibility does not automatically create command-right. A role-position may be responsible for what it structures without gaining authority to define the other role-position as such.

The switch usually occurs through burden. The responsible role-position may say, implicitly or explicitly: because I carry more, I decide more; because I bear the consequence, I define the terms; because I protect, I govern; because I integrate the cost, I control the scene. This may appear reasonable where the burden is real. But the shift becomes false coordination when the real burden is used to reorganize R (responsibility) into rank, command, or exemption.

Responsibility-to-Authority changes critique access. The role-position that bears more responsibility may become harder to criticize because criticism appears to deny its burden. The other side may be told that it cannot object unless it can carry the same cost, risk, or consequence. Objection then becomes ingratitude, immaturity, dependence, or lack of realism. What began as answerability for a real structuring effect becomes authority protected by the very responsibility that should have made it more answerable.

The effect on Σ (integration) is selective. The scene integrates the burden of the responsible role-position while failing to integrate the agency, exposure, or criticizability of the other. It may integrate protection while failing to integrate the protected side’s adulthood. It may integrate consequence while failing to integrate the cost of being governed. It may integrate decision-pressure while failing to integrate the effects of decision-power. The result is not responsible coordination, but a frame in which responsibility absorbs participation.

The effect on Ψ (self-binding) follows directly. The role-position whose responsibility becomes authority may no longer bind itself to the limits of that responsibility. It may act as if carrying cost authorizes control. The other role-position must then bind itself more tightly: accept decisions, reduce objection, justify dissent, or prove maturity before critique becomes admissible. Low Ψ on the responsible-authorized side can therefore increase Ψ-load on the governed side.

This switch must be distinguished from legitimate authority. Some scenes require bounded authority. A doctor, parent, teacher, commander, caretaker, expert, emergency responder, or institution may have authority within a defined field. A role-position may need to decide because delay would produce harm. Authority becomes false coordination only where it exceeds its field, loses answerability to its effects, or converts responsibility into rank over the other. Functional hierarchy is not the problem. Unbounded authority from responsibility is the problem.

Responsibility-to-Authority is therefore not anti-responsibility. It protects responsibility by keeping it tied to answerability. Where the conditions of R (responsibility) are met, greater responsibility should increase precision, not domination. It should clarify who must answer for what under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost/exposure conditions. It should not become a general right to define another role-position’s agency, dignity, vulnerability, or participation.

The switch becomes drift when this conversion repeats: responsibility is invoked at decisive points, authority expands, critique becomes harder, and the other role-position’s participation narrows. The issue is not one difficult decision under pressure. The issue is a pattern in which responsibility repeatedly becomes command-right while real Ω (asymmetry), displaced R (responsibility), blocked Σ (integration), and shifted Ψ (self-binding) remain in place.

### 10.7 Parity-to-Exit

Parity-to-Exit names a switch in which formal equality, autonomy, mutuality, or parity becomes a frame for exiting cost-truth under real Ω (asymmetry). It begins from a valid possibility. Equality can be real. Autonomy can be valid. Parity can correct hierarchy, paternalism, dependency capture, or unilateral burden. A role-position may genuinely have the right to refuse, withdraw, leave, decline, or choose otherwise. The switch begins only where formal equality is used to exit the actual distribution of cost, exposure, dependency, responsibility, or consequence.

The central formula is:

```text
Parity-to-Exit begins when formal equality replaces cost-truth.
```

This does not mean that exit is false. Exit can be necessary. A role-position may need distance, refusal, privacy, boundary, or non-participation. Leaving a scene, declining a demand, or refusing further involvement may be a valid way to preserve Χ (distance), prevent overexposure, or avoid false binding. Parity-to-Exit becomes relevant only where the language of equal freedom hides the unequal cost of exit.

The switch often appears as a formally symmetrical claim: both sides are free; either side can leave; no one owes participation; each role-position chooses for itself. These claims may be true at the level of formal possibility. But formal possibility is not yet cost-truth. If exit costs one side far more, if one side’s withdrawal structures the other’s exposure, if one side can leave without integrating what its exit produces, then parity has become a frame that conceals asymmetry rather than coordinating it.

Parity-to-Exit changes responsibility distribution. The exiting role-position may appear non-responsible because it merely exercises equal freedom. The remaining role-position may be left to integrate the cost, absorb the uncertainty, maintain continuity, repair the frame, or carry the consequence of withdrawal. R (responsibility) is displaced when exit is treated as costless autonomy despite structuring real effects for another side.

The effect on critique access is also strong. To criticize exit may appear controlling, dependent, anti-autonomous, or hostile to equality. This can be appropriate where the critique seeks to deny legitimate freedom. But it becomes false coordination where any question about cost, timing, consequence, or prior structuring effect is blocked by the parity frame. Autonomy then becomes unavailable to critique even where it structures another role-position’s cost.

Parity-to-Exit also blocks Σ (integration). The scene may integrate formal equality while failing to integrate unequal exposure. It may integrate autonomy while failing to integrate dependence. It may integrate refusal while failing to integrate the consequences of withdrawal. It may integrate non-obligation while failing to integrate the cost produced by earlier involvement. The result is a frame that appears adult because it respects freedom, but does not coordinate the cost-truth of that freedom.

The effect on Ψ (self-binding) is central. Exit may be a valid release from false binding. But exit can also externalize binding-load. One role-position stops binding itself to continuity, explanation, consequence, or repair, while another must bind itself more tightly to manage what remains. Low Ψ on the exiting side can increase Ψ-load on the side left with the scene’s residue. This is not a claim that exit is wrong. It is a claim that exit may structure cost and therefore cannot always be treated as structurally empty.

Parity-to-Exit must therefore be distinguished from legitimate autonomy. Autonomy may require refusal. Equality may require the right to leave. Distance may be necessary for dignity-in-practice. A scene is not falsely coordinated because someone exits. It becomes falsely coordinated where exit is framed as pure equality while its asymmetrical effects are made illegible. The issue is not whether one may leave. The issue is whether the scene can still name what leaving structures.

Parity-to-Exit becomes drift when formal equality repeatedly appears at the point where cost-truth would have to be integrated. A role-position may invoke parity whenever responsibility becomes precise, autonomy whenever consequence is named, or mutual freedom whenever unequal exposure becomes visible. The pattern matters. One exit may be valid. Repeated exit that preserves displaced R (responsibility), blocked Σ (integration), and shifted Ψ (self-binding) becomes a switch drift signal.

Together, Responsibility-to-Authority and Parity-to-Exit show how false coordination can move through apparently adult frames. One converts responsibility into command. The other converts equality into cost-exit. Both can begin from valid conditions. Both become switch drift only where frame change preserves displaced responsibility, blocked integration, or shifted self-binding under real Ω (asymmetry).

### 10.8 Switch Drift Signals

Switch Drift Signals are not diagnostic criteria. They do not prove manipulation, bad faith, pathology, or person type. They name structural indicators that a frame change may be preserving false coordination rather than correcting it. The question is not whether a switch occurred. Switching can be valid. The question is whether the switch produces a recurring scene effect under real Ω (asymmetry): responsibility is redistributed, critique access changes, Σ (integration) remains blocked, and Ψ (self-binding) remains shifted.

The minimal formula is:

```text
Switch drift requires:
pattern,
consequence,
and responsibility displacement.
```

The first signal is repeatability. A single frame shift may be necessary, corrective, or harmless. Drift becomes more plausible where the same movement, or the same family of movements, becomes available at decisive points. Protection appears when responsibility is requested. Autonomy appears when cost is named. Equality appears when asymmetry becomes visible. Exception appears when criticizability is introduced. Authority appears when burden is questioned. The repeated availability of the switch matters more than the mere fact that a switch occurred.

The second signal is asymmetric availability. If only one role-position can shift frames without cost, while another role-position is held to the previous frame, the switch may be structuring false coordination. One side may move from vulnerability to authority, from parity to exception, from protection to autonomy, or from responsibility to command, while the other is treated as inconsistent, demanding, controlling, immature, or unsafe if it attempts a similar movement. Switch drift becomes visible where frame mobility itself is unequally distributed.

The third signal is critique-cost increase. A switch may preserve false coordination by making the same objection harder to state. Under one frame, critique appears insensitive. Under another, it appears unequal. Under another, it appears anti-autonomous. Under another, it appears disrespectful of responsibility, protection, or harm. If each frame shift raises the cost of asking how real Ω (asymmetry) is being coordinated, then the switch is not merely changing language. It is changing critique access.

The fourth signal is responsibility redistribution. A switch drift is likely where each movement changes who must answer while the underlying structuring effect remains unresolved. The scene may move from equality to exit, from vulnerability to immunity, from responsibility to authority, or from protection to non-answerability. In each case, R (responsibility) no longer follows the real structuring effect. It follows the currently available frame.

The fifth signal is integration failure beneath surface revision. A scene may look more careful, more fair, more compassionate, more equal, or more realistic after a switch. But if the relevant cost, exposure, dependency, protection need, criticizability, or consequence still cannot be held together, then Σ (integration) remains blocked. The switch has revised the scene’s appearance without integrating what the scene actually carries.

The sixth signal is binding-load displacement. A switch may leave one role-position less bound while another becomes more tightly bound. One side may gain ambiguity, exception, autonomy, or authority; the other may have to absorb uncertainty, maintain continuity, reduce critique, carry explanation, or preserve the frame. Where Ψ (self-binding) decreases on one side while Ψ-load increases on the other, switch drift may be present.

The seventh signal is legitimation replacing integration. A switch drift often stabilizes when the new frame becomes self-justifying. The arrangement is no longer merely protected; it is compassionate. It is no longer merely asymmetrical; it is realistic. It is no longer merely non-binding; it is autonomous. It is no longer merely authoritative; it is responsible. Legitimation replaces integration when the frame explains why the arrangement must stand instead of integrating the costs and effects that the arrangement produces.

These signals must be read together. Repeatability without consequence is not enough. Consequence without responsibility displacement may be a legitimate cost of coordination. Responsibility displacement without pattern may be a difficult local failure rather than drift. Switch drift requires the convergence of pattern, consequence, and responsibility displacement under real Ω (asymmetry). Without that convergence, switch analysis risks becoming a verdict machine.

The same caution applies to counter-scenes. A frame shift may look like drift from one vantage point and like correction from another. A switch into exception may protect against overexposure. A switch into parity may restore adult standing. A switch into authority may prevent harm. A switch into exit may preserve Χ (distance) or dignity-in-practice. The signal is not the frame itself, but whether the movement reopens or blocks R (responsibility), Σ (integration), and Ψ (self-binding) under the actual conditions of the scene.

Chapter 10 therefore closes with a double guardrail. First, the Switch Family names movement, not motive. Second, switch drift is structural, not diagnostic. Its role is to show how false coordination can survive by changing frames: the scene moves, but responsibility remains displaced; the language changes, but integration remains simulated; the frame becomes more legitimate, but self-binding remains shifted.

The next problem follows directly from this. Some switches occur through visible reframing. Others occur through non-action, non-event, delay, omission, silence, or non-binding. These are harder to analyze because they can structure a scene while appearing not to act at all. The next chapter therefore turns to No Passive Praxis.

---

## 11. No Passive Praxis: Indirect Enactment and Non-Event Power

Some switches occur through visible reframing. Others occur through what does not visibly happen: silence, delay, non-response, withholding, non-clarification, non-binding, non-involvement, or the appearance of neutrality. Chapter 11 names the structural problem this creates. A scene may be shaped not only by direct action, but also by the organization of conditions under which others must act.

### 11.1 Definition

No Passive Praxis does *not mean* that every non-action is action. It does not mean that every silence is control, every delay is manipulation, every refusal is drift, every absence is responsibility, or every openness is evasion. The first rule of this chapter is therefore negative:

```text
No Passive Praxis ≠ every non-action is action.
```

The positive claim is narrower. Non-action becomes praxis only where it structures a scene under □ (frame), Λ (non-event), Ω (asymmetry), and Θ (temporality). A silence may matter if it changes what another role-position must carry. A delay may matter if it alters timing, exposure, or available alternatives. A refusal to clarify may matter if it makes another side organize itself around ambiguity. A non-response may matter if it shifts cost, responsibility, or Ψ (self-binding)-load. But none of these matters merely because something did not happen.

The core formula is:

```text
No Passive Praxis =
non-action becomes praxis
when it structures a scene under □/Λ/Ω/Θ.
```

The point can be stated directly: where a role-position structures another role-position’s action conditions through non-action, the non-action becomes praxeologically relevant. This does not mean that the role-position acted in the narrow sense of direct performance. It means that the scene has been structured through a non-event, and that the structuring effect may become responsibility-relevant if the relevant conditions are met.

This distinction matters because non-action can be genuinely neutral, limited, uncertain, restrained, protective, exhausted, unavailable, or outside the scene. A role-position may remain silent because speech would overexpose another, because no alternative is available, because Χ (distance) is needed, because the situation is not yet legible, or because non-involvement is genuinely appropriate. EDEN must not convert absence into accusation. No Passive Praxis begins only where the absence itself helps structure the conditions under which the scene must continue.

A non-action becomes structurally relevant where it changes the action conditions of others. It may make another role-position wait, explain, interpret, absorb, stabilize, adapt, prove, regulate, or choose without enough information. It may keep one option open by making another side carry the cost of openness. It may preserve ambiguity by requiring others to act around that ambiguity. It may avoid visible command while still setting the field within which others must move.

The object is therefore not motive. EDEN does not ask whether a role-position intended to steer, avoid, punish, manipulate, or control. It asks whether the scene was structured through □ (frame), Λ (non-event), Ω (asymmetry), and Θ (temporality) in a way that changed cost, exposure, timing, responsibility, integration, self-binding, or correctability. No Passive Praxis is structural rather than psychological: no motive or mental state follows from the structural reading, and responsibility remains scene-bound and separately conditional.

This chapter therefore extends, but also limits, the analysis of praxis. It extends it because visible action is not the only way a scene can be structured. It limits it because absence is not enough. A missing action, a silence, a delay, a refusal, an unfinished clarification, or a posture of openness becomes praxeologically relevant only where it shapes the scene under real Ω (asymmetry) and affects the distribution of cost, responsibility, Σ (integration), Ψ (self-binding), or possible correction.

### 11.2 Praxis ≠ Strict Action E

The distinction between praxis and strict Action / Enactment E is necessary because Chapter 11 would otherwise become confused. Praxis names structurally relevant conduct within a scene. It includes the ways a scene is shaped by action, non-action, framing, timing, withholding, recognition, protection, legitimation, cost distribution, and self-binding. Strict Action / Enactment E (strict Action / Enactment) is narrower. It names integrated enactment.

The distinction can be stated as follows:

```text
Praxis ≠ strict Action E.

Strict Action / Enactment E = Σ ∘ Θ ∘ ∇.
Compactly: E = [Σ, Θ, ∇].
```

Strict Action / Enactment E requires Σ (integration), Θ (temporality), and ∇ (impulse). It is not merely that something happens. It is that an impulse or direction becomes integrated into enactment across time. In that strong sense, not every structuring non-event is strict Action. A silence may structure a scene without becoming strict Action / Enactment E. A delay may shift cost without being integrated enactment. A refusal to clarify may change the action conditions of others without taking the form of overt doing.

This is why the chapter uses praxis as the broader term. Praxis can include structurally relevant non-action without erasing the difference between non-event and direct enactment. A Λ (non-event) may matter because it structures a field of response, not because it is secretly the same thing as visible action. To say that non-action can become praxis is not to collapse absence into action. It is to say that praxis includes structuring effects that visible-action vocabulary alone cannot capture.

Visible action remains responsibility-relevant. Direct force, explicit command, institutional decision, overt refusal, speech, coercion, protection, abandonment, and material action can structure a scene in obvious and powerful ways. Chapter 11 does not demote visible action. It adds that responsibility is not exhausted by visible action where non-action, framing, timing, recognition, protection, legitimation, or non-binding also structure the scene.

This point protects the theory from two symmetrical errors. The first error says only direct action matters. It misses the ways scenes can be organized through silence, delay, non-clarification, non-binding, or legitimation. The second error says all absence is action. It turns EDEN into an accusation machine. The correct distinction is narrower: visible action is one responsibility vector; structuring non-action is another.

This distinction also protects responsibility from becoming moralized too quickly. A structuring non-event may become responsibility-relevant, but it is not automatically blameworthy. It must still be read under legibility, capacity, alternative possibility, Θ (temporality), and Ω (asymmetry) cost or exposure conditions. A role-position cannot be made responsible merely because something was absent. It can become answerable where its absence structures the scene under conditions that make answerability traceable.

Chapter 11 therefore does not redefine action. It clarifies praxis. Praxis is the broader scene category. Strict Action / Enactment E is the narrower category of integrated enactment. Non-action may become praxis where it structures a scene under □ (frame), Λ (non-event), Ω (asymmetry), and Θ (temporality). But non-action does not become strict Action merely because it has effects, and it does not become responsibility merely because someone can point to what did not happen.

### 11.3 Three Levels of Non-Action

No Passive Praxis requires a discriminating account of non-action. If every absence were treated as praxis, the theory would become accusatory and unusable. If only visible action mattered, the theory would miss many ways in which scenes are actually structured. Chapter 11 therefore distinguishes three levels: mere absence, structuring non-event, and integrated abstention.

The distinction can be stated compactly:

```text
Mere absence ≠ structuring non-event ≠ integrated abstention.
```

The first level is mere absence. Mere absence means that something did not happen, but the absence does not structure the relevant scene under □ (frame), Λ (non-event), Ω (asymmetry), or Θ (temporality). A person did not speak, did not decide, did not clarify, did not intervene, or did not respond, but the absence does not organize cost, exposure, timing, responsibility, integration, self-binding, or correctability in the scene. Mere absence may be irrelevant, accidental, unknown, unavailable, outside the role-position’s field, or outside the scene.

Mere absence is therefore not praxis merely because it can be noticed. A missing action may matter emotionally without becoming structurally relevant. A silence may be felt without structuring the scene. A delay may be inconvenient without altering responsibility distribution. A non-response may be frustrating without becoming a non-event in the praxeological sense. EDEN must not infer praxis from absence alone.

The second level is structuring non-event. A structuring non-event occurs where what does not happen becomes part of how the scene is organized. The absence is not merely missing; it shapes what others must do, carry, infer, avoid, absorb, explain, or stabilize. Here Λ (non-event) is not an empty nothing. It is an absence that becomes structurally relevant because it operates within a □ (frame), under real Ω (asymmetry), across Θ (temporality), and with traceable effects on the scene.

A structuring non-event may appear as silence that makes another role-position interpret the scene alone, delay that shifts timing costs, non-clarification that forces adaptive guessing, non-response that makes another side carry continuity, or withholding that preserves ambiguity while others must act around it. The point is not that silence, delay, non-clarification, or withholding are false by default. The point is that they can become praxis-relevant where they structure the action conditions of others.

Structuring non-event is praxis-relevant, but it is not automatically strict Action / Enactment E (strict Action / Enactment). This distinction matters. A non-event can structure the scene without taking the form of integrated enactment. It can change the field of response without becoming a direct act, command, decision, or completed performance. The theory therefore needs a broader concept of praxis without collapsing that broader concept into strict E.

The third level is integrated abstention. Here non-action is not merely absence and not merely a structuring non-event. It may itself become integrated enactment where restraint, refusal, silence, non-intervention, or delay is structurally traceable as directionality integrated across time. This classification does not infer an unobserved intention or mental state; it requires scene-bound evidence for the configuration of Σ (integration), Θ (temporality), and ∇ (impulse). Where that configuration is established, abstention may count as strict Action / Enactment E.

The distinction can be stated as follows:

```text
Mere absence:
no relevant □/Λ/Ω/Θ structuring
→ no praxeological relevance.

Structuring non-event:
□/Λ/Ω/Θ structuring effect
→ praxis-relevant, not automatically strict E.

Integrated abstention:
restraint or non-intervention integrated across Σ/Θ/∇
→ may count as strict Action / Enactment E.
```

Integrated abstention is not drift by default. It may be ethical restraint, disciplined non-intervention, respect for boundary, preservation of Χ (distance), refusal to escalate, protection from overexposure, or acceptance that no legitimate role is available. A role-position may refrain precisely because acting would falsely coordinate the scene. In such cases, abstention can support Adult Reciprocity rather than undermine it.

This is why the three levels must remain separate. Mere absence should not be inflated into praxis. Structuring non-event should not be erased because it lacks visible action. Integrated abstention should not be treated as passive merely because it appears as non-action. The question is always what the absence does within the scene: whether it remains outside the relevant structure, whether it structures the conditions under which others must act, or whether it is itself integrated as a disciplined form of restraint.

The distinction also prevents No Passive Praxis from becoming a suspicion machine. A scene cannot be read by asking only what failed to happen. It must ask whether the absence is framed, temporally consequential, asymmetrically distributed, and structurally effective. Without those conditions, the absence remains absence. With those conditions, the non-event may become praxeologically relevant. With integration, restraint may even become a form of strict enactment.

This prepares the more precise formula that follows. Once the three levels are separated, Chapter 11 can ask when a non-action crosses the threshold into passive praxis. The answer cannot be impression, frustration, or isolated non-response. It must be a structural formula: a non-action becomes praxis only where it structures a scene through frame, non-event, asymmetry, temporality, and traceable effect.

### 11.4 Passive Praxis Formula

The three levels of non-action make the threshold visible. Mere absence does not matter by itself. Integrated abstention may be strict Action / Enactment E. Between them lies the structurally delicate case: a non-event that is not direct action, but nevertheless organizes the conditions under which others must act. The Passive Praxis Formula names this threshold.

The formula is:

```text
Passive Praxis Formula =
non-action
+ □/Λ/Ω/Θ structuring
+ traceable scene effect
→ praxis-relevant non-event
```

The formula begins with non-action, but non-action is not enough. Something must be absent, withheld, delayed, left open, not clarified, not answered, not decided, or not bound. Yet the absence becomes praxeologically relevant only when it enters a □ (frame), appears as Λ (non-event), operates under real Ω (asymmetry), and accumulates through Θ (temporality). Without these conditions, the absence may be noticeable, frustrating, unfortunate, or emotionally meaningful, but it is not yet passive praxis.

The second element is structuring. A non-action structures a scene where it changes the action conditions of others. It may make something harder, easier, slower, less legible, more costly, more exposed, more urgent, or more dependent on another role-position’s adaptation. It may shift the burden of interpretation, timing, explanation, continuity, or restraint. The question is not simply whether something did not happen. The question is what the non-event makes others carry.

The third element is traceable scene effect. A passive praxis reading requires more than an impression that silence, delay, or non-clarification “felt” consequential. The effect must be traceable within the scene: which role-position had to adapt, which cost increased, which alternative narrowed, which uncertainty accumulated, which exposure changed, which form of Σ (integration) or Ψ (self-binding) was blocked or shifted. No traceable effect, no passive praxis reading.

This is why the formula remains scene-bound. A silence in one scene may be mere absence. In another, it may be restraint. In another, it may be a structuring non-event. The same outward non-action cannot be read by label. It must be read by its placement within □ (frame), Λ (non-event), Ω (asymmetry), Θ (temporality), and traceable effect. EDEN therefore does not ask whether silence, delay, or openness is “really” passive praxis in general. It asks what the non-action does in this scene.

The responsibility implication is real but limited. A structuring non-event may become responsibility-relevant where it organizes cost, exposure, timing, criticizability, integration, or self-binding. But Chapter 11 does not yet supply the full responsibility calculus. The point here is only that responsibility is not exhausted by visible action. A role-position may structure a scene by not clarifying, not deciding, not responding, not binding, or not closing a frame, if that non-action changes what others must carry.

At the same time, passive praxis is not blame by another name. A role-position may refrain because no legitimate alternative is available, because restraint is required, because Χ (distance) must be preserved, because acting would overexpose another, or because the scene is genuinely not yet legible. The formula does not authorize accusation from absence. It only makes a threshold visible: non-action becomes praxis-relevant where it structures the scene under the relevant conditions.

Legitimation can also participate in passive praxis. A scene may be structured not only by what is absent, but by the frame that makes the absence appear neutral, mature, respectful, autonomous, protective, or inevitable. At the level of □ (frame) and Φ (recontextualization), legitimation can give a non-event endurance. It can make continued non-clarification, delayed answerability, or non-binding appear proper before the scene has integrated what those absences distribute.

This point must remain limited. Legitimation is not suspicious by default. A frame may rightly explain why restraint, silence, openness, delay, or non-intervention is needed. It becomes relevant for passive praxis only where the legitimating frame stabilizes a non-event that continues to structure cost, exposure, responsibility, Σ (integration), or Ψ (self-binding). The question is not whether the legitimation sounds convincing. The question is whether it helps coordinate the scene truthfully or protects the non-event from being read as structuring.

The minimal gate can therefore be stated sharply:

```text
No scene, no passive praxis.
No real Ω, no passive praxis.
No traceable structuring effect, no passive praxis.
No □/Λ/Ω/Θ relevance, no passive praxis.
```

This gate protects Chapter 11 from overreach. A non-action is not praxeologically relevant because someone can point to an absence. It becomes relevant only where the absence structures a scene, under real Ω (asymmetry), through a meaningful Λ (non-event), within an operative □ (frame), across Θ (temporality), and with traceable effects on cost, exposure, responsibility, Σ (integration), Ψ (self-binding), or correctability.

The Passive Praxis Formula therefore completes the threshold established by the previous sections. Chapter 11 can now ask how such structuring occurs. The next step is indirect action-power: the capacity to shape another role-position’s action conditions without necessarily acting through direct command, visible force, or explicit decision.

### 11.5 Indirect Action-Power

Indirect action-power names the capacity to structure another role-position’s action conditions without necessarily acting through direct command, visible force, explicit decision, or overt prohibition. It is not a new operator and not a synonym for strict Action / Enactment E. It is a scene-bound name for the power to shape what becomes available, costly, delayed, recognizable, embarrassing, permissible, or practically unavailable within a praxis field.

The structure can be stated as follows:

```text
Indirect action-power =
capacity to structure another role-position’s action conditions
through access, timing, recognition, withholding, framing, legitimation, or non-binding
without necessarily issuing a direct command.
```

This does not demote direct action. Visible action remains one of the clearest ways to structure a scene: command, force, decision, refusal, institutional rule, material action, speech, protection, abandonment, or intervention may all be responsibility-relevant. Chapter 11 only adds that action conditions can also be structured indirectly. A role-position may not visibly command another, but may still shape what the other can do, say, risk, explain, wait for, or carry.

Indirect action-power often works by controlling the conditions of access. A role-position may not say “do this,” but it may make recognition, clarification, permission, continuity, participation, or timing depend on another side’s adaptation. It may leave a frame open in a way that others must stabilize. It may withhold explanation while others must guess. It may delay response while others must preserve continuity. It may treat one path as normal and another as socially expensive. In such cases, the issue is not direct command, but structured availability.

This is the Chapter-4 point under Chapter-11 conditions: stabilized praxis can steer without issuing a direct command. A learned field may guide role-positions not only through explicit norms, but also through patterned omissions, withheld recognition, delayed access, implicit cost distributions, and normalized paths of participation. The Garden returns here only as background: a field can make one direction appear natural, mature, safe, or expected, while making deviation costly, embarrassing, unclear, or hard to legitimate.

Indirect action-power therefore names a structural possibility, not a guilty status. Not every influence is action-power. Not every access point is domination. Not every delay, silence, omission, or asymmetrical access condition is false coordination. Many access structures are necessary: institutions must sequence access, roles must define permissions, boundaries may limit participation, and timing may require restraint. Indirect action-power becomes relevant for EDEN only where it structures real Ω (asymmetry), changes cost or exposure, and affects responsibility, Σ (integration), Ψ (self-binding), or correctability.

The most important feature of indirect action-power is that it can remain under-visible. The role-position that structures the action conditions may appear passive, neutral, patient, restrained, unavailable, or simply not yet decided. Meanwhile another role-position must organize itself around those conditions: wait, adapt, explain, avoid, anticipate, prove readiness, reduce demand, or keep the scene viable. The power lies less in what is visibly done than in how the conditions of doing are arranged.

This does not mean that indirect action-power should be read by suspicion. It must be traced. What exactly is being made available or unavailable? Who must adapt? Which cost increases? Which alternative narrows? Which timing becomes decisive? Which form of recognition, access, or clarification is withheld or delayed? Without a traceable scene effect, indirect action-power remains an impression. With such an effect, it can become part of the analysis of passive praxis.

Indirect action-power also clarifies why non-action can matter without becoming strict Action / Enactment E (strict Action / Enactment). A role-position may structure the field of another’s action without integrating its own directionality into overt enactment. It may not act in the strong sense, but it may still organize the space in which action by others becomes possible, costly, illegible, delayed, or necessary. This is why praxis must remain broader than strict E while strict E remains a narrower and protected category.

### 11.6 Under-Explained Adaptive Steering

Under-Explained Adaptive Steering names a scene effect in which one role-position adapts around ambiguity, delay, silence, non-clarification, non-response, or non-binding while the source of that adaptation remains insufficiently named. The steering is not necessarily intentional. It is not a diagnosis of passive-aggression, manipulation, avoidance, or hidden control. It names a structural condition: conduct becomes organized around something that remains under-explained.

The structure can be stated as follows:

```text
Under-Explained Adaptive Steering =
adaptive behavior induced by ambiguity, delay, silence, non-clarification, or non-binding
while the steering source remains insufficiently named.
```

The term “steering” must be handled carefully. It does not imply that someone consciously steers. It means that the scene begins to move in a direction because one side must adapt to an under-explained condition. A role-position may wait because no answer comes. It may soften speech because clarification is unavailable. It may reduce demand because the other side remains undefined. It may carry continuity because non-response makes discontinuity too costly. The adaptation is real even where intention is not inferred.

Ordinary language may be tempted to call such scenes passive-aggressive. EDEN should not do that. Passive-aggressive language too easily becomes psychological, diagnostic, and person-directed. Chapter 11 instead asks whether the scene is structured under □ (frame), Λ (non-event), Ω (asymmetry), and Θ (temporality) in a way that induces adaptation while leaving the structuring condition under-explained. The question is not “what kind of person is this?” but “what action conditions does this under-explained non-event create?”

Under-Explained Adaptive Steering often works through uncertainty. Uncertainty may be genuine, and uncertainty is not drift by default. A role-position may not know yet, may be unable to answer, may need time, may require Χ (distance), or may be preserving a legitimate openness. The drift risk begins only where uncertainty becomes a stable condition around which another role-position must organize itself while the cost of that organization remains unintegrated.

The adaptation may be practical. One side waits, prepares alternatives, keeps options open, avoids certain actions, or absorbs delay. It may be communicative: one side explains more, asks less, softens tone, translates itself, or anticipates possible objections. It may be affective: one side regulates disappointment, suppresses irritation, maintains calm, or carries the burden of not escalating. It may be interpretive: one side must infer what the silence, delay, openness, or non-clarification means. In each case, the steering lies in the adaptive field that forms around the under-explained condition.

This is why under-explained steering can affect Σ (integration). If the adaptive burden remains unnamed, the scene may integrate the need for patience, caution, openness, or non-pressure while failing to integrate the cost carried by the adapting side. One true element is preserved: perhaps uncertainty, fragility, complexity, or restraint. But another true element is excluded: the burden created by having to adapt around what remains undefined.

The effect on Ψ (self-binding) follows from this. The role-position that remains under-explained may not bind itself to the effects of its ambiguity, delay, or non-clarification. Another role-position may then have to bind more tightly: maintain continuity, hold open possibilities, manage timing, regulate critique, or absorb uncertainty. Low Ψ on one side can therefore increase Ψ-load on the other without the scene ever appearing to contain direct command.

This does not make adaptive steering false by default. Some adaptation is ordinary coordination. Some uncertainty is legitimate. Some delay is necessary. Some silence preserves dignity. Some non-clarification prevents premature closure. The question is whether the adaptation remains reciprocal and integrable, or whether one role-position repeatedly organizes itself around an under-explained condition while the condition itself remains unavailable to responsibility, integration, or self-binding.

Under-Explained Adaptive Steering therefore belongs in Chapter 11 because it shows how passive praxis can operate without visible domination. The scene may contain no explicit order, no coercive statement, no overt refusal, and no declared demand. Yet action conditions can still be shaped. If those conditions remain under-explained while another side adapts around them, the non-event may become part of the scene’s praxeological structure.

The next section turns to the most compact form of this problem: non-binding. There, the issue is not only that one role-position adapts around ambiguity, but that one side’s low Ψ (self-binding) may directly increase the Ψ-load of another.

### 11.7 Non-Binding as Ψ-Load Shift

Non-binding is the most compact form of the problem named in Chapter 11. It occurs where a role-position does not bind itself to the effects of its ambiguity, delay, openness, refusal, silence, non-clarification, or non-decision, while another role-position must organize itself around that lack of binding. The issue is not uncertainty as such. The issue is the distribution of Ψ (self-binding)-load under real Ω (asymmetry).

The formula is:

```text
low Ψ on one side
→ increased Ψ-load on the other.
```

This formula does not mean that every open situation is drift. Openness may be real. Uncertainty may be real. A role-position may not yet know, may need more time, may lack sufficient legibility, may preserve Χ (distance), may avoid premature closure, or may refuse to bind because no legitimate commitment is available. Non-binding becomes structurally relevant only where the cost of remaining unbound is shifted onto another role-position.

The stronger sentence is:

```text
I do not bind myself,
but you must organize yourself around my non-binding.
```

This is not a psychological accusation. It does not say that a person intends to evade, manipulate, punish, control, or remain unavailable. It names a structural distribution. One role-position remains unbound, while another must bind more tightly in order to preserve continuity, timing, interpretation, restraint, coordination, or practical possibility. The non-binding side may appear passive, open, careful, uncertain, fragile, or neutral. The other side may appear pressing, impatient, demanding, controlling, or overactive because it has to carry the missing binding.

Non-binding can structure a scene through timing. If one role-position does not decide, does not answer, or does not clarify, another may have to hold options open, delay alternatives, absorb uncertainty, or act without knowing which frame will later be recognized. The relevant question is not whether delay is automatically false. It is whether Θ (temporality) makes the delay accumulate as cost for one side while the source of that cost remains insufficiently bound to its effect.

Non-binding can also structure a scene through interpretation. If one side remains ambiguous, another may have to infer meaning, manage possible reactions, soften speech, preserve multiple possibilities, or translate itself in advance. The ambiguity may be genuine, and interpretation may be part of ordinary coordination. But where one role-position repeatedly carries the interpretive burden of another’s non-binding, Ψ (self-binding) has shifted. One side remains open; the other must become more self-organizing around that openness.

Non-binding can structure responsibility. A role-position may not visibly act, command, or refuse, yet its non-commitment may shape what another role-position must carry. If the unbound side later remains unavailable to the effects of its own ambiguity, R (responsibility) begins to lose contact with structuring effect. Responsibility then attaches more easily to the side that reacts, asks, explains, presses, stabilizes, or names the burden, while the side whose non-binding shaped the scene remains under-described.

Non-binding can also block Σ (integration). A scene may integrate the value of openness, patience, caution, autonomy, uncertainty, or non-pressure while failing to integrate the cost imposed by the unbound condition. One true element is preserved, but not the whole structure. The scene may rightly avoid premature closure, yet still fail to integrate who must carry the cost of remaining open.

This is why non-binding must be distinguished from freedom. Freedom from premature commitment may be legitimate. Freedom from coercive binding may be necessary. Freedom from false closure may preserve dignity and reversibility. But freedom becomes structurally unstable where one role-position’s freedom from binding becomes another role-position’s obligation to absorb the costs of that freedom. Adult Ψ (self-binding) begins as self-binding, not other-binding.

The distinction also protects against reverse overreach. A role-position may not demand another’s binding merely because uncertainty is uncomfortable. Ψ (self-binding) is not compliance, reassurance, availability, emotional labor, or surrender of distance. To say that low Ψ can shift Ψ-load is not to say that every request for clarity is justified, every discomfort with openness is structurally valid, or every non-answer creates responsibility. The scene still requires traceable effect, real Ω (asymmetry), and a counter-scene that could change the reading.

Non-binding becomes praxeologically relevant only where it shapes action conditions. Does one role-position have to wait, adapt, interpret, explain, stabilize, hold open alternatives, absorb timing costs, or regulate critique because another remains unbound? Does the unbound position remain unavailable to the costs its non-binding produces? Does the scene make the adapting side appear excessive while leaving the non-binding side neutral? If these conditions hold, the problem is not mere absence. It is shifted Ψ-load.

No Passive Praxis therefore cannot be reduced to visible action. Non-binding can function as passive praxis without becoming strict Action / Enactment E or a diagnosis of motive where its traceable effect shifts Ψ (self-binding)-load onto another role-position.

The boundary remains decisive. Non-binding may be legitimate where no commitment is available, restraint is necessary, the scene is not yet legible, distance must be preserved, or binding would itself become coercive. It becomes relevant to Adult Reciprocity only where one side’s low Ψ increases another side’s Ψ-load while the resulting cost remains unintegrated, under-described, or unavailable to responsibility. Where that threshold is not met, non-binding remains outside the chapter’s claim.

### 11.8 Neutrality Test

The final task of Chapter 11 is to protect No Passive Praxis from overreach. If non-action can structure a scene, neutrality cannot be accepted merely because a role-position says it did nothing. But neutrality also cannot be rejected merely because something was absent. The correct position is narrower: neutrality must be tested, not presumed false.

The rule can be stated as follows:

```text
Neutrality must be tested, not presumed false.
```

A neutrality test begins by asking whether there is an operative □ (frame) in which the non-action has meaning. A silence, delay, non-response, or refusal to clarify does not become structurally relevant in the abstract. It becomes relevant only if the scene gives that non-action a role: making one path appear normal, making another costly, preserving ambiguity, delaying recognition, protecting a position from criticizability, or requiring another role-position to adapt around what remains absent.

The second question is whether there is a meaningful Λ (non-event). Something must be absent in a way that matters for the scene. This may be a missing answer, missing clarification, missing decision, missing recognition, missing boundary, missing commitment, or missing correction. But a missing element is not enough. The absence must structure what can be done, said, carried, revised, or recognized. Without such structuring, the non-event remains mere absence.

The third question is whether real Ω (asymmetry) is affected. No Passive Praxis requires more than inconvenience or frustration. It requires a scene in which cost, exposure, timing, access, recognition, responsibility, or available alternatives are unevenly affected by the non-action. If the absence does not alter the asymmetry field, then EDEN has no reason to treat it as passive praxis. If it does alter the asymmetry field, the question becomes how that alteration is carried and by whom.

The fourth question is whether Θ (temporality) makes the absence accumulate. A single delay may be ordinary. A silence may be temporary. An unanswered question may not yet structure the scene. But temporality can change the significance of non-action. Delay may narrow alternatives over time. Ambiguity may force repeated adaptation. Non-clarification may make one role-position continue to organize itself around uncertainty. A non-event becomes more structurally relevant when its effects accumulate, stabilize, or become difficult to reverse.

The fifth question is whether Σ (integration) or Ψ (self-binding) is affected. Does the non-action make it harder to integrate the real cost of the scene? Does it shift self-binding load from the unbound role-position onto another? Does one side remain open, silent, delayed, or undefined while another side must stabilize continuity, manage timing, regulate critique, hold open alternatives, or absorb uncertainty? If no integration or self-binding effect can be traced, the passive praxis reading weakens.

The sixth question is whether R (responsibility) can be traced without becoming accusation. A structuring non-event may become responsibility-relevant, but responsibility must not be inferred from absence alone. The reading must ask whether the role-position had available legibility, capacity, alternative possibility, and relevant exposure conditions. The threshold is exact: responsibility may follow structuring non-action, but it does not follow mere non-action.

The seventh question is whether a counter-scene can change the reading. The apparent non-action may be genuine restraint, legitimate boundary, uncertainty, incapacity, exhaustion, grief, protection from overexposure, preservation of Χ (distance), or real non-capture. It may be outside the role-position’s responsibility field. It may be a refusal to participate in a false coordination. It may be a necessary non-intervention. If these counter-scenes fit better, the passive praxis reading must be weakened, narrowed, or suspended.

The test can be summarized compactly:

```text
Neutrality Test:

Is there an operative □?
Is there a meaningful Λ?
Is real Ω affected?
Does Θ accumulate the effect?
Are cost, exposure, access, timing, recognition, or alternatives shifted?
Are Σ or Ψ blocked, displaced, or externalized?
Can responsibility be traced without accusation?
Is there a stronger counter-scene?
```

This test prevents two mistakes. The first mistake is neutrality by declaration: “I did nothing, therefore I did not structure the scene.” That is not sufficient. A role-position may structure a scene through non-action where the conditions of □ (frame), Λ (non-event), Ω (asymmetry), Θ (temporality), traceable effect, and shifted cost are present. The absence of visible action does not by itself prove neutrality.

The second mistake is accusation by absence: “something did not happen, therefore the absence is praxis.” That is also not sufficient. A non-action may be neutral, legitimate, unavailable, restrained, or outside the relevant field. Without real Ω (asymmetry), without traceable structuring effect, without meaningful Λ (non-event), and without effects on cost, responsibility, Σ (integration), Ψ (self-binding), or correctability, the absence remains outside No Passive Praxis.

The Neutrality Test therefore completes the chapter’s central discipline. No Passive Praxis expands the field of structural analysis beyond visible action, but it does not collapse absence into action. It makes indirect structuring visible while preserving the possibility of genuine neutrality, legitimate restraint, non-capture, and non-involvement. It can name a structuring non-event without diagnosing motive, assigning a person type, or treating silence as guilt.

Chapter 11 can now hand the problem forward. Once non-action, non-event, delay, withholding, non-binding, and legitimation can become praxeologically relevant, responsibility must be defined with greater precision. The next chapter therefore turns to the Responsibility Principle: how R (responsibility) follows real structuring effect under legibility, capacity, alternative possibility, temporality, and asymmetry cost or exposure conditions.

---

## 12. Responsibility Principle

Chapter 11 showed why responsibility cannot be limited to visible action. A scene may be structured by non-action, non-event, delay, withholding, non-binding, legitimation, or indirect action-power without thereby turning every absence into action or every silence into guilt. Chapter 12 now defines the responsibility principle that follows from that distinction. If structuring effect can exceed visible action, then responsibility must be traced more carefully, not more punitively.

### 12.1 Main Principle

The Responsibility Principle states that R (responsibility) follows real structuring effect. It does not follow visibility alone, declared intention alone, formal role alone, outcome alone, identity alone, vulnerability alone, protection claim alone, or visible action alone. Responsibility becomes structurally relevant where a role-position helps organize the conditions, costs, alternatives, exposures, recognitions, protections, timings, or self-binding demands through which a scene continues.

The status of the principle must remain distinct from the status of R. R = Ψ ∘ Φ ∘ Θ ∘ Ω is a formally derived PMS axis. The Responsibility Principle is EDEN’s analytical, attributive, and explicitly normative rule for connecting answerability to real structuring effect; it is not an automatic entailment of the formula or a universally established moral law. Whether responsibility attaches to a particular role-position, effect, or degree remains a descriptive and evidentiary question governed by the scene conditions stated below.

The principle can be stated as follows:

```text
R (responsibility) follows real structuring effect
under available legibility,
capacity,
alternative possibility,
Θ (temporality) trajectory,
and Ω (asymmetry) cost/exposure conditions.
```

Each term limits the principle as much as it strengthens it. Real structuring effect means that something in the scene is actually shaped: what can be done, said, withheld, recognized, protected, corrected, integrated, delayed, or made costly. Available legibility means that the structure is not assigned from omniscience. Capacity means that a role-position had some real ability to structure, prevent, redirect, absorb, or correct an effect. Alternative possibility means that a materially relevant difference was available under the scene’s conditions. Θ (temporality) trajectory means that responsibility may accumulate, weaken, appear late, or depend on prior structuring over time. Ω (asymmetry) cost or exposure conditions mean that the cost of acting, not acting, naming, correcting, or carrying a burden is not evenly distributed.

This principle separates responsibility from guilt. R (responsibility) is not blame, not moral worth, not person condemnation, not psychological diagnosis, and not proof of malicious intent. A role-position may be responsible for a structuring effect without having intended harm, domination, evasion, humiliation, or control. Conversely, the absence of malicious intent does not by itself dissolve responsibility. Good intention does not integrate cost, restore self-binding, or undo a responsibility-displacing structure.

The negative formulas must therefore remain visible:

```text
R is not blame.
R is not guilt.
R is not moral worth.
R is not person condemnation.
R is not mere causality.
R is not outcome-liability alone.
```

Responsibility also differs from mere causality. A scene may have many causes, conditions, pressures, histories, and background formations. Not all of them become responsibility in the relevant sense. R (responsibility) attaches where a role-position’s structuring effect remains traceable under legibility, capacity, alternatives, Θ (temporality), and Ω (asymmetry) cost or exposure conditions. Cause is broader than responsibility. Outcome is broader than responsibility. Responsibility is the structured relation between effect and answerability under conditions.

This also protects the principle from outcome-liability. A role-position is not responsible for everything that follows from a scene merely because a bad outcome occurred, because it was more visible, because it had more capacity in one dimension, or because another side suffered cost. Outcome may reveal a structuring effect, but outcome alone does not prove responsibility. The relevant question is whether responsibility follows the actual structure of the scene, not whether the outcome is painful, unequal, or morally serious.

The principle is therefore double:

```text
Responsibility remains real
even without malice.

Responsibility remains limited
by legibility,
capacity,
available alternatives,
Θ,
and Ω.
```

Both sides are necessary. If responsibility requires malice, many real structuring effects disappear from analysis. A role-position may shape cost, exposure, access, timing, recognition, or self-binding without intending the effect. If responsibility ignores legibility, capacity, alternatives, temporality, and asymmetry, then responsibility becomes totalizing. It no longer traces structure; it becomes accusation, moral burden, or outcome-liability.

This is why Chapter 12 must remain structural. It does not ask first who is guilty. It asks what structured the scene, what conditions were available, who or what had capacity to affect the structure, which alternatives were materially possible, how the effect accumulated over time, and how asymmetrical cost or exposure shaped the possibility of response. Responsibility is not softened by being structural. It is made more precise.

The principle also protects Adult Reciprocity. A reciprocal scene does not require identical responsibility. It requires responsibility to remain truthfully coordinated with real effect. One role-position may carry more responsibility in one dimension because it has more capacity, more access, more timing control, greater protective capacity, greater capacity to structure exposure, or more ability to alter the field. Another role-position may carry responsibility in a different dimension because its non-binding, withholding, recognition claim, protection claim, or vulnerability frame also structures the scene. The responsibilities need not be equal. They must be traceable.

This is the first major implication of the chapter: responsibility is neither direct-action-only nor everywhere. It is neither erased by good intention nor proven by bad outcome. It is neither guilt nor innocence. It is a structural relation between real effect and answerability under conditions. Chapter 12 now has to clarify the vectors through which such structuring can occur, beginning with the relation between responsibility and action.

### 12.2 Responsibility and Action

Responsibility is not exhausted by visible action. This does not make visible action secondary. Direct force, explicit command, speech, institutional decision, material intervention, protection, abandonment, refusal, and overt enactment may all structure a scene with great clarity. Where they do, they remain responsibility-relevant. Chapter 12 does not weaken visible action. It prevents visible action from becoming the only recognizable responsibility vector.

The basic distinction is:

```text
Visible action is one responsibility vector.
Structuring non-action is another.
```

A responsibility vector is a way in which a role-position can help structure the conditions of a scene. Visible action is often the clearest vector because it produces an identifiable act, decision, statement, intervention, or refusal. But Chapter 11 showed that a scene can also be structured through non-action, non-event, delay, withholding, non-clarification, non-binding, legitimation, and indirect action-power. These do not become responsibility-relevant merely because they are present. They become relevant only where they structure the scene under traceable conditions.

Responsibility vectors may therefore include direct action, indirect action-power, framing, timing control, withholding, recognition allocation, protection allocation, access control, cost distribution, legitimation, non-binding, and structuring non-action. This list is not a taxonomy of guilt. It is a map of possible routes by which a scene can be shaped. Each vector must still be tested by the Responsibility Principle: real structuring effect, available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions.

This distinction protects the analysis from two errors. The first error is direct-action reduction. It says that responsibility exists only where a role-position visibly acted, commanded, decided, or caused an outcome. That error misses responsibility-displacing frames, structuring non-events, delayed answerability, non-binding, and legitimation effects. It can make passive praxis invisible precisely where another role-position must carry its cost.

The second error is total responsibility expansion. It says that because non-action can structure a scene, every silence, delay, absence, uncertainty, openness, or non-response becomes responsibility. That error turns Chapter 11 into accusation by absence. The Responsibility Principle blocks this expansion. Structuring non-action is a responsibility vector only where real structuring effect can be traced under the relevant conditions. Without those conditions, absence remains outside the responsibility claim.

Responsibility and action therefore have an asymmetrical relation. Action may create responsibility, but responsibility is not identical with action. Non-action may create responsibility-relevant effects, but non-action is not automatically responsibility. A visible act may be insufficient to establish R (responsibility) if the role-position lacked capacity, legibility, or available alternatives. A non-event may become responsibility-relevant if it structures cost, exposure, timing, integration, or self-binding under real Ω (asymmetry) and Θ (temporality).

This also clarifies the relation to strict Action / Enactment E (strict Action / Enactment). E remains the narrower category of integrated enactment. A responsibility vector does not have to be strict E in order to be structurally relevant. Non-binding, delay, or legitimation may shape a scene without becoming strict Action / Enactment E. Conversely, strict E may structure a scene so directly that responsibility becomes highly visible. The categories must remain distinct: action is one way of structuring; responsibility follows structuring effect under conditions.

The result is a more careful responsibility grammar. EDEN does not ask only, “who acted?” It asks: what structured the scene, through which vector, under what conditions, with what legibility, capacity, alternatives, temporality, and asymmetrical cost? This grammar preserves visible action, makes passive structuring legible, and blocks the slide from absence into accusation.

### 12.3 Awareness and Availability

Responsibility attribution requires available legibility, but not omniscience. “Awareness” here is ordinary-language shorthand for such legibility; it does not add the formally derived PMS axis A = Θ ∘ □ ∘ Δ to R or make A an automatic responsibility condition. A role-position cannot be made responsible as if it had total access to the scene, perfect knowledge of all effects, or unlimited ability to foresee every consequence. At the same time, limited legibility does not erase responsibility wherever a structuring effect was available enough to be recognized, anticipated, corrected, or answered for.

Available legibility means that a structure could become sufficiently visible within the scene for responsibility to attach. It may be available through repeated effects, explicit feedback, role knowledge, foreseeable cost, prior history, institutional position, bodily exposure, dependency relations, or the accumulation of consequences over time. Responsibility does not require omniscience; it requires enough legibility for answerability to be structurally possible.

Capacity is the second condition. A role-position may see an effect without having meaningful capacity to alter it. Capacity may include action-power, access, timing control, institutional role, communicative ability, protection capacity, ability to clarify, ability to refrain, or ability to revise a frame. Where no relevant capacity exists, responsibility weakens. Where capacity exists and structures effect, responsibility becomes more traceable. Capacity specifies responsibility; it does not create unlimited liability.

Alternative possibility is the third condition. A role-position should not be made responsible for failing to choose an alternative that was not structurally available. Alternative possibility does not require ideal freedom or perfect conditions. It requires a materially relevant difference the role-position could have made under the scene’s actual constraints. If no alternative was available, responsibility weakens. If an available alternative could have changed the structuring effect, responsibility becomes stronger.

Θ (temporality) is the fourth condition. Responsibility may not appear at the moment of visible action alone. Some responsibilities accumulate through delay, repetition, stabilization, prior non-binding, or earlier missed correction. A role-position may become answerable over time because an effect became more legible, because alternatives narrowed, because a pattern repeated, or because the cost of non-correction increased. Temporality can make responsibility stronger, weaker, later, earlier, distributed, or path-dependent.

Ω (asymmetry) cost and exposure are the fifth condition. Responsibility must be traced under uneven cost. The same action, silence, delay, or refusal may have different responsibility implications depending on who bears risk, who has alternatives, who is exposed to consequence, who can withdraw, who must remain legible, and who carries the cost of naming the structure. A formally identical act is not necessarily structurally identical under unequal Ω.

The discriminative rule can be stated as follows:

```text
Responsibility attribution must track
available legibility,
relevant capacity,
and materially available alternatives.

Limits in these conditions limit the attribution;
they do not erase every responsibility relation by default.
```

This rule prevents two opposite mistakes. The first is overassignment: treating a role-position as responsible for effects it could not see, could not alter, or could not reasonably answer for under the scene’s conditions. Overassignment turns responsibility into guilt, outcome-liability, or moral burden. It collapses structural analysis into accusation.

The second mistake is underassignment: treating limited awareness, limited intention, vulnerability, uncertainty, or indirectness as if they erased all responsibility. Underassignment makes real structuring effects disappear because they were not malicious, not direct, not fully visible, or not consciously intended. It collapses responsibility into intention and thereby loses many of the scenes EDEN is designed to read.

Available legibility must therefore be read dynamically. A role-position may not know at first what it structures. Later, repeated effects, feedback, cost accumulation, or counter-scene may make the structure more visible. At that point, responsibility may change. The question is not whether the role-position knew everything from the beginning. The question is whether, at the relevant point in the Θ (temporality) trajectory, enough became available for answerability to attach.

The same is true of capacity and alternatives. A role-position may have no capacity at one point and greater capacity later. An alternative may be unavailable early and available after the frame changes. A cost may be invisible until another role-position names it, or until the scene repeats often enough that the pattern can no longer be treated as incidental. Responsibility follows this movement. It is not frozen at the first moment of ignorance, but neither is it assigned from hindsight omniscience.

This is why the Responsibility Principle remains both strong and limited. It is strong because it refuses to let real structuring effect disappear behind good intention, limited awareness, indirect action, or formal non-involvement. It is limited because it refuses to assign responsibility where legibility, capacity, alternatives, temporality, and asymmetry conditions do not support answerability. Responsibility is therefore neither suspicion nor excuse. It is structural tracing under conditions.

### 12.4 Protection Does Not Cancel Responsibility

Protection is a real structural need. A scene may contain vulnerability, exposure, dependence, prior harm, limited capacity, unequal risk, or a genuine need for restraint. EDEN does not treat protection as weakness, evasion, or immunity by default. Protection can be required in order for dignity, distance, reversibility, and continued participation to remain possible.

The problem begins only when protection is made to cancel responsibility as such. A role-position may need protection from degradation, humiliation, coercion, overexposure, or false attribution. That does not mean it must also be protected from every form of criticizability, answerability, or structural description. Protection can limit how responsibility is named. It does not automatically erase that responsibility.

The distinction can be stated as follows:

```text
Protection from degradation does not mean protection from responsibility.
Protection against harm ≠ protection against criticizability.
```

This distinction is necessary because responsibility language can itself become harmful if it is used as accusation, exposure, domination, or moral verdict. A role-position may be made too exposed by premature naming, excessive demand, public attribution, or a frame that turns structural answerability into personal condemnation. In such cases, protection is not a refusal of responsibility. It may be a condition under which responsibility can be named without degrading the role-position.

At the same time, protection can become false if it prevents any contact between a role-position and its structuring effects. If every description of cost becomes harm, every account of burden becomes attack, every request for answerability becomes coercion, or every naming of structure becomes degradation, then protection no longer preserves dignity. It immunizes the role-position from the scene it helps structure.

D (dignity-in-practice) holds these two demands together. Dignity-in-practice protects a role-position from degradation while preserving agency, criticizability, and responsibility under real structuring effect. It does not require humiliation in order for responsibility to be real. It also does not require immunity in order for protection to be real. A protected role-position can still be answerable for the way it structures cost, access, recognition, timing, integration, self-binding, or correctability.

This matters especially under Ω (asymmetry). Where exposure, capacity, cost, and alternatives are unevenly distributed, responsibility must be named without pretending that every role-position can bear the same form of critique. A responsibility claim may need distance, timing, limitation, privacy, reversibility, or reduced exposure. But those conditions shape how responsibility is handled; they do not prove that no responsibility exists.

Protection therefore modifies the form of responsibility, not its existence by default. A scene may require slower naming, narrower attribution, reduced exposure, more careful framing, or more distance. It may require that critique remain structural and revisable. But if a role-position’s conduct, non-action, claim, protection status, recognition demand, or non-binding helps structure the scene, responsibility cannot be cancelled merely because naming it is difficult.

The chapter must therefore avoid two opposed errors. The first error is harsh responsibility: treating vulnerability or protection needs as excuses to ignore dignity, exposure, and capacity. The second error is protective erasure: treating vulnerability or protection needs as if they remove all answerability. Adult Reciprocity requires neither harsh exposure nor protected immunity. It requires responsibility to be named in a form that remains truthful to real effect and protective against degradation.

Where protection cancels responsibility, immunization risk appears. Where responsibility ignores protection, overexposure risk appears. The governing hinge is that protection and responsibility are not opposites. They must be coordinated under dignity-in-practice.

### 12.5 Structure Critique Is Not Person Threat

Responsibility becomes unstable when critique of a structure is experienced, framed, or received as a threat to personhood. If naming a responsibility-displacing structure is treated as an attack on being, worth, identity, sex, dignity, or basic legitimacy, then structural critique becomes difficult to sustain. The scene can then protect a role-position from degradation only by preventing description of the role-position’s structuring effects.

The distinction must therefore be explicit:

```text
Structure critique is not person threat.
```

A structure critique does not say that a role-position is bad, defective, inferior, guilty in essence, or unworthy of dignity. It says that a scene is being structured in a way that may displace cost, responsibility, integration, self-binding, recognition, or correctability. The object of critique is the structuring relation, not the personhood of the role-position.

This matters because responsibility language can easily be misheard or misused. It can be misused when it becomes accusation, shame, ranking, humiliation, or moral verdict. It can be misheard when any structural description is received as degradation. EDEN must refuse both movements. It must not turn responsibility into personal condemnation. It also must not allow personhood-protection to make structure critique impossible.

The sharper distinction is:

```text
Critique of personhood ≠ critique of a responsibility-displacing structure.
```

A responsibility-displacing structure may be named without claiming that a role-position is malicious, morally inferior, psychologically deficient, or essentially wrong. A role-position may be implicated in a structure without being reduced to that structure. It may have helped organize cost or exposure without intending harm. It may have benefited from a frame without designing it. It may have remained unbound without understanding the load shifted onto another. Responsibility can remain real under these conditions without becoming a theory of character.

This is why Chapter 12 must keep critique scene-bound. The claim is not “this is what the person is.” The claim is “this is what the scene does, and this role-position participates in that structuring effect under the relevant conditions.” The distinction preserves reversibility. If the scene changes, if legibility changes, if capacity changes, if alternatives become unavailable, or if a counter-scene fits better, the responsibility reading must also be revised.

D (dignity-in-practice) again provides the constraint. A structure critique must preserve the role-position’s dignity while keeping its structuring effects criticizable. Dignity does not require silence about responsibility. Criticizability does not require degradation. The scene must be able to say that a structure displaces responsibility without making that sentence a verdict on the person’s worth.

This is also why EDEN cannot become a threat language. It cannot be used to classify persons, rank sexes, declare moral essence, or convert a scene reading into an identity claim. A responsibility analysis that cannot be revised, tested, bounded, or separated from personhood has already left the method. It no longer describes a structure; it produces a verdict.

Structure critique therefore protects responsibility from two failures at once. It protects responsibility from humiliation by refusing person condemnation. It protects responsibility from disappearance by refusing the claim that all critique is person threat. The adult form is narrower and stronger: a role-position remains dignified, while its structuring effects remain answerable.

This prepares the next step. If responsibility is not person condemnation, then the adult response cannot begin by controlling the other. It must begin with the relation between responsibility and self-binding: the capacity to remain answerable to one’s own structuring effects without turning that answerability into imposed binding on another role-position.

### 12.6 Self-Control over Other-Control

If responsibility is not person condemnation, then its adult form cannot begin as control of the other. Responsibility begins as the capacity of a role-position to remain answerable to its own structuring effects. This is why Chapter 12 must distinguish self-binding from other-binding.

The principle can be stated directly:

```text
Adult Ψ begins as self-binding,
not as other-binding.
```

Ψ (self-binding) does not mean compliance, reassurance, availability, obedience, confession, emotional labor, or submission to another role-position’s demand. It means that a role-position can remain bound to the effects of its own participation in a scene. It can ask what it structures, what it externalizes, what it withholds, what it makes costly, what it makes legible or illegible, and what it requires another role-position to carry.

This distinction matters because responsibility language can easily become displaced into other-control. A role-position may try to secure its own stability by demanding that another explain more, expose more, bind more, soften more, wait more, prove more, or absorb more. Such demands may sometimes be legitimate within a specific scene, but they are not the primary form of adult responsibility. The primary form is not “you must bind yourself for me.” It is “I must remain bound to what I structure.”

EDEN may therefore describe absent or externalized self-binding, but it cannot convert that description into imposed binding of the other. It may name where Ψ (self-binding) is low, displaced, avoided, or carried by another role-position. It may show that one side’s non-binding increases another side’s Ψ-load. But description does not authorize coercion. Naming a shifted load is not the same as gaining the right to force the other role-position into availability, confession, exposure, or compliance.

The distinction can be stated as a methodological firewall:

```text
EDEN may describe where self-binding is absent or externalized.
It cannot convert that description into imposed binding of the other.
```

Self-control, in this chapter, does not mean suppression, moral discipline, or emotional policing. It means structural answerability to one’s own effect. A role-position exercises adult self-binding when it can remain in contact with the cost, exposure, timing, recognition, protection, or integration effects it helps produce. It does not have to become guilty in order to become answerable. It does not have to become degraded in order to become responsible.

This is especially important after Chapter 11. If a role-position’s non-binding shifts Ψ (self-binding)-load onto another, the answer is not automatically to demand counter-binding from the other side. The first question is whether the role-position whose non-binding structures the scene can become answerable to that effect. Can it name the cost it externalizes? Can it revise the frame it keeps open? Can it integrate the burden it creates? Can it remain bound to the consequences of its own openness, silence, delay, or non-clarification?

The same applies to visible action. A role-position that acts directly may still displace responsibility if it treats the other side’s reaction as the whole problem. Direct action does not guarantee self-binding. A visible decision, command, refusal, protection claim, or intervention may still require another side to absorb cost while the acting side remains unavailable to its own structuring effect. Adult responsibility therefore requires self-binding in both action and non-action.

Self-control over other-control protects responsibility from becoming domination. It also protects responsibility from becoming disappearance. If all responsibility is shifted onto the other’s reaction, the role-position’s own structuring effect disappears. If responsibility becomes forced binding of the other, the analysis becomes coercive. The adult form holds both limits: remain answerable to what one structures, without turning that answerability into a demand that another role-position surrender distance, dignity, or legitimate non-binding.

This does not mean that other role-positions never have responsibilities. Chapter 12 does not replace asymmetrical responsibility with private self-concern. It says only that responsibility cannot mature by first controlling the other’s response. Each role-position must be read according to its real structuring effect, available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions.

Self-binding is therefore the hinge between responsibility and reciprocity. Adult Reciprocity requires that a role-position not externalize its own structuring effects as another’s burden. It also requires that responsibility remain bounded, traceable, and non-degrading. Self-control over other-control names that hinge: answerability begins with one’s own structuring effect before it becomes a claim about what another must carry.

### 12.7 Responsibility under Real Asymmetry

Responsibility may be asymmetrically distributed where real Ω (asymmetry) differentiates structuring effect, available legibility, capacity, alternative possibility, temporal trajectory, or cost and exposure conditions. Ω does not by itself determine the distribution of R (responsibility). Where these conditions are uneven, a symmetry requirement may misread the scene. Adult Reciprocity does not require equal responsibility. It requires responsibility to remain truthfully coordinated with real effect.

The formula is:

```text
Real Ω may produce asymmetrical responsibility conditions.
But Ω alone does not determine R,
and asymmetrical responsibility is not absent responsibility.
```

This formula protects against two errors. The first error treats asymmetry as if it automatically cancels responsibility for the more exposed, more vulnerable, less legible, or less powerful role-position. That may be true in some dimensions, but it cannot be presumed. A role-position may be exposed in one respect and still structure cost in another. It may have limited capacity to shape action conditions in one dimension while still significantly shaping recognition, timing, withholding, or protection conditions in another. Asymmetry modifies responsibility; it does not erase it by default.

The second error treats asymmetry as if it automatically totalizes responsibility for the more powerful, more visible, more active, or more institutionally positioned role-position. That may also be true in some dimensions, but it cannot be presumed. Greater capacity may increase responsibility where it creates or could alter structuring effect. But capacity does not make a role-position responsible for every outcome, every burden, every reaction, or every cost in the scene. Responsibility follows real structuring effect under conditions, not generalized status.

Responsibility under real Ω (asymmetry) is therefore dimensional. One role-position may carry responsibility for timing because it controls delay. Another may carry responsibility for recognition because it controls whether a burden becomes nameable. Another may carry responsibility for protection because it can reduce degradation. Another may carry responsibility for non-binding because its openness shifts Ψ (self-binding)-load. Another may carry responsibility for direct action because its visible intervention reorganizes the scene. These responsibilities need not be equal in order to be real.

This is why symmetrical responsibility can become false. If the scene insists that “both sides are equally responsible” where cost, exposure, access, and capacity are not equal, the responsibility reading may become a form of false coordination. It can distribute answerability evenly while real Ω (asymmetry) remains uneven. The result is not Adult Reciprocity, but a formal balance that hides the actual structure of responsibility.

The opposite error is also false. If the scene insists that only one side can ever be responsible because one side is more powerful, more visible, more active, or more institutionally exposed, then responsibility may become totalized. This may protect one true asymmetry while erasing other real structuring effects. A structurally weaker role-position may still withhold recognition, externalize self-binding, stabilize ambiguity, use protection as immunity, or shift cost through non-action. Naming this is not person threat. It is the consequence of reading responsibility by structuring effect rather than by status alone.

The adult standard is therefore not equal responsibility, but truthful responsibility. Truthful responsibility asks which role-position structured which dimension of the scene, under which conditions, with which legibility, capacity, alternatives, temporality, and asymmetrical cost. It can say “more here, less there,” “earlier here, later there,” “directly here, indirectly there,” “visible here, passive there,” or “not responsibility under these conditions.” It does not need a symmetrical verdict.

This point also protects dignity. D (dignity-in-practice) does not require that a role-position be shielded from all responsibility because it is vulnerable, nor that it be overloaded with responsibility because it is capable. Dignity requires that responsibility be named without degradation, and limited without erasure. A dignified role-position remains more than its structuring effect, but its structuring effect remains available to critique.

Responsibility under real asymmetry also clarifies the relation between Adult Reciprocity and false coordination. Adult Reciprocity is truthful coordination of real Ω (asymmetry). If responsibility is assigned symmetrically where asymmetry is real, coordination becomes false. If responsibility is erased because asymmetry is real, coordination also becomes false. The task is neither equalization nor exemption. The task is to let responsibility follow real structuring effect under real conditions.

Once responsibility can be underassigned, overassigned, or made illegible under asymmetry, three downstream risks become visible:

```text
Where responsibility is underassigned,
immunization forms.

Where responsibility is overassigned,
overexposure forms.

Where language for the distribution is missing,
asymmetric explanatory poverty forms.
```

Chapter 12 does not develop those risks. It only gives them their responsibility basis. If R (responsibility) does not follow real structuring effect, the scene may protect a role-position from all answerability, expose a role-position to too much answerability, or lack language for the unequal distribution altogether. Chapter 13 turns to these downstream forms: Immunization, Overexposure, and Asymmetric Explanatory Poverty.

Chapter 12 therefore closes with the principle it began from. Responsibility is not guilt, blame, moral worth, person condemnation, mere causality, or outcome-liability alone. It is the traceable relation between real structuring effect and answerability under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. Under Adult Reciprocity, that relation need not be symmetrical. It must be truthful.

---

## 13. Immunization, Overexposure, and Asymmetric Explanatory Poverty

Chapter 12 defined responsibility as a traceable relation between real structuring effect and answerability under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. Chapter 13 asks what happens when that relation drifts. The problem is no longer simply whether responsibility exists. The problem is how R (responsibility) becomes underassigned, overassigned, or deprived of legitimate language under false coordination of real asymmetry.

### 13.1 Coupled Drift

Responsibility drift begins where R (responsibility) no longer follows real structuring effect. A scene may preserve the appearance of fairness, protection, recognition, vulnerability, equality, or accountability while distributing answerability away from the effects that actually structure the scene. Some effects then remain too protected from responsibility. Other role-positions become too exposed to responsibility. Still others lack legitimate language to describe the distribution at all.

The basic drift can be stated as follows:

```text
Where responsibility is underassigned,
immunization forms.

Where responsibility is overassigned,
overexposure forms.

Where language for the distribution is missing,
asymmetric explanatory poverty forms.
```

Immunization names a drift in which a real structuring effect becomes insufficiently answerable. The effect may still be present. It may shape timing, recognition, access, cost, exposure, integration, self-binding, or correctability. But the responsibility relation is softened, displaced, blocked, moralized away, or rendered unavailable. In this sense, immunization is not the absence of effect. It is effect without full responsibility.

Overexposure names the opposite drift. A role-position may become overly available to responsibility, suspicion, correction, blame, explanation demand, or exposure before the scene has granted full legibility, protection, or distance. Here R (responsibility) is not absent; it is intensified beyond what the scene can justly trace. Overexposure is not responsibility as such. It is responsibility without full legibility or protection.

The coupled formula is therefore:

```text
immunization:
effect without full responsibility

overexposure:
responsibility without full legibility / protection
```

These drifts are coupled because underassigned responsibility in one place often produces overassigned responsibility elsewhere. If one role-position’s structuring effect becomes difficult to name, another role-position may have to carry more explanation, more caution, more self-binding, more exposure, or more responsibility for keeping the scene intelligible. Conversely, if one role-position is already overexposed, it may lack the legitimate language needed to name where another role-position’s effect has been immunized.

The coupling does not make the two drifts identical. Immunization is not simply privilege, innocence, vulnerability, protection, or recognition. Overexposure is not simply suffering, victimhood, powerlessness, or moral superiority. Each drift must be read by the same standard established in Chapter 12: real structuring effect under legibility, capacity, alternative possibility, Θ (temporality), and Ω (asymmetry) cost or exposure conditions. Without that standard, Chapter 13 would collapse into competing moral claims.

The anti-essentialist guardrail must therefore be stated at the beginning:

```text
Immunization and overexposure are coupled,
but not fixed to the same sex or role-position.
```

This is decisive. Chapter 13 does not say that one sex is immunized and the other is overexposed by nature. It does not define men as responsible and women as protected, or women as evasive and men as innocent. It names drift patterns within scenes. A role-position may be immunized in one dimension and overexposed in another. It may be protected in one scene and overburdened in another. It may structure cost in one relation while carrying disproportionate responsibility in another.

The second guardrail follows:

```text
Profiles are scene-bound drift patterns,
not sex truths.
```

The analytical status of the chapter must remain explicit. Immunization, overexposure, Asymmetric Explanatory Poverty, and the sex-coded profiles are analytically reconstructed, scene-bound configurations that may become relevant under specified arrangements of responsibility, recognition, vulnerability, protection, action-power, exposure, and language. They function as structural hypotheses, not as empirically established claims about recurrence, prevalence, or sexed distribution. Any claim that a configuration occurs or recurs in a particular scene requires scene-bound evidence; any broader empirical claim requires evidence beyond the present framework. A male-coded overexposure profile is not a truth about men, and a female-coded immunization profile is not a truth about women. None of these concepts authorizes diagnosis, ranking, or identity attribution.

The same role-position can therefore move across drift locations. A role-position may be immunized when its effects are protected from criticizability, and overexposed when its own burden cannot be named without appearing threatening, evasive, or guilty. Another role-position may be overexposed in public accountability and immunized in intimate non-binding. Drift is not a permanent status. It is a scene relation.

The point can be formulated directly:

```text
The same person or role-position can be immunized in one scene
and overexposed in another.
```

This protects the chapter from reversal. Naming immunization does not grant immunity to the critic. Naming overexposure does not erase responsibility. Naming asymmetric explanatory poverty does not prove innocence. The correction of one false distribution must not produce another false distribution. Chapter 13 therefore has to name responsibility drift without turning drift analysis into counter-immunity.

Asymmetric Explanatory Poverty is the third form in the coupled drift. It appears where a role-position bears high exposure or responsibility load but lacks legitimate language to describe how the load is produced. The problem is not mere silence, ignorance, or lack of intelligence. It is a structural poverty of available terms: the scene may allow accusation, explanation demand, or responsibility assignment, but not a legitimate account of how responsibility has been underassigned elsewhere or overassigned here.

This is why AEP cannot be treated as a psychological defect. It is not stupidity, incapacity, moral inferiority, or epistemic defect of a sex. It is a scene condition in which exposure, responsibility, and language are asymmetrically distributed. A role-position may be able to feel the burden, react to it, compensate for it, or even explain parts of it, while still lacking a legitimate frame in which that explanation can be heard without being converted into evasion, threat, self-pity, domination, or refusal of responsibility.

Chapter 13 therefore begins with a coupled architecture. Immunization names underassigned responsibility. Overexposure names overassigned responsibility. Asymmetric Explanatory Poverty names the loss of legitimate language for describing that distribution. The chapter now separates these forms in sequence: first immunization drift, then overexposure drift, then the explanatory poverty that can bind them together.

### 13.2 Immunization Drift

Immunization drift begins where a real structuring effect remains less answerable than its role in the scene permits. Something has effect: it shapes cost, timing, recognition, exposure, access, integration, self-binding, or correctability. Yet R (responsibility) does not fully follow that effect. It is softened, displaced, protected from critique, reframed as harm, or made difficult to name without appearing excessive.

The compact formula is:

```text
Immunization =
effect without full responsibility.
```

This does not mean that the immunized role-position has no vulnerability, no exposure, no protection need, or no legitimate claim. Immunization is not the same thing as protection. A role-position may need protection from degradation, coercion, humiliation, overexposure, or false attribution. The drift begins only where protection no longer protects dignity but instead interrupts the relation between structuring effect and answerability.

The structure can be stated more precisely:

```text
real structuring effect
→ critique arises
→ critique is framed as harm
→ correction is blocked
→ R is displaced
```

The crucial step is not vulnerability itself. Vulnerability may be real. Harm may be real. Protection may be real. The crucial step is the conversion of critique into harm in such a way that the role-position’s effect becomes unavailable to responsibility. A scene may then preserve the language of care, safety, recognition, equality, or protection while losing contact with what the protected role-position actually structures.

Immunization can operate through several frames. A vulnerability frame may make a role-position’s exposure visible while making its structuring effect difficult to name. A protection frame may correctly block degradation but also incorrectly block criticizability. A recognition frame may rightly insist that a role-position be seen, but may also make answerability appear like a withdrawal of recognition. A care frame may treat burden, hurt, or need as morally central while obscuring how those claims shape the scene for others.

These frames are not false by default. Vulnerability, protection, recognition, and care can all be structurally real. The question is whether they remain coordinated with R (responsibility), or whether they begin to protect a role-position from the effects it helps produce. Immunization drift appears only where the frame blocks responsibility that should remain traceable under available legibility, capacity, alternative possibility, Θ (temporality), and Ω (asymmetry) cost or exposure conditions.

This is why immunization must be distinguished from dignity. D (dignity-in-practice) protects a role-position from degradation while preserving criticizability and responsibility under real structuring effect. Immunization does the opposite. It may use the language of dignity, but it turns protection into reduced answerability. It treats the naming of structure as if it were already degradation, even when the critique remains scene-bound, revisable, and non-condemning.

Immunization also affects Σ (integration). A scene may integrate one true element while excluding another. It may integrate the truth that a role-position is vulnerable, harmed, exposed, or in need of recognition. But it may fail to integrate the truth that this same role-position also structures cost, timing, access, non-binding, recognition, or self-binding load for others. The result is partial truth protected from completion.

The effect on Ψ (self-binding) follows from this partial integration. Where immunization stabilizes, a role-position may not have to remain bound to its own structuring effects. Another role-position may instead carry the burden of adaptation, explanation, restraint, or silence. The immunized position can remain morally protected while the adapting position becomes more responsible for keeping the scene viable. Low or displaced Ψ (self-binding) may then appear as vulnerability, openness, fragility, or need rather than as a shifted responsibility load.

Immunization may also work through Φ (recontextualization). A critique of structuring effect may be recontextualized as hostility, harshness, domination, insensitivity, lack of care, or refusal of recognition. The original question was structural: what effect does this role-position help produce? After recontextualization, the question becomes moralized: why is the critic threatening, unkind, punitive, or unsafe? Once this switch occurs, the structuring effect becomes harder to discuss.

This does not mean that all claims of harm are immunizing. A critique can be badly framed, premature, humiliating, excessive, inaccurate, or itself overexposing. A role-position may rightly say that a responsibility claim is too broad, too public, too harsh, too early, or not supported by the scene. Immunization drift is not the existence of a protection claim. It is the use of protection to prevent any adequate contact between real structuring effect and responsibility.

The limiting formula must therefore remain visible:

```text
Critique of false protection
≠ rejection of protection.
```

This formula is essential. EDEN must be able to say that some protection is false without becoming anti-protection. It must be able to say that some vulnerability is real without making vulnerability uncriticizable. It must be able to name immunization without denying harm, dependency, exposure, or dignity. Otherwise the analysis would merely replace one false coordination with another.

Immunization is especially difficult to read because it often appears as moral sensitivity rather than power. The immunized position may not look dominant. It may appear fragile, careful, hurt, overwhelmed, morally attentive, socially protected, or in need of recognition. None of these appearances is false by default. But if the appearance prevents the scene from tracing actual structuring effect, then responsibility has drifted. The issue is not what the role-position is. The issue is what the frame prevents from being answerable.

This also explains why immunization is not a sex truth. A role-position can be immunized in one scene and overexposed in another. A vulnerability frame can protect one person in one relation and expose the same person elsewhere. Immunization names the drift between effect and responsibility, not the essence of a person, group, or sex. No profile in this chapter overrides this rule.

Immunization is therefore a responsibility problem, not a moral accusation. The immunized role-position may still be vulnerable. It may still need protection. It may still be exposed in other dimensions. The claim is narrower: where its real structuring effect is protected from adequate answerability, responsibility has been underassigned. Its paired drift is overexposure, where responsibility is assigned beyond full legibility, protection, or traceable structuring effect.

### 13.3 Overexposure Drift

Overexposure drift is the paired form of immunization drift. It begins where a role-position becomes too available to responsibility, suspicion, explanation demand, correction duty, or blame before the scene has provided adequate legibility, protection, distance, or traceable connection to real structuring effect. In immunization, R (responsibility) is underassigned relative to effect. In overexposure, R is overassigned relative to what can yet be legibly, protectively, and structurally traced.

The compact formula is:

```text
Overexposure =
responsibility without full legibility / protection.
```

Overexposure does not mean that the role-position has no responsibility. It does not mean that power is unreal, that visible action is irrelevant, that harm did not occur, or that critique is illegitimate. It means that the scene assigns responsibility in a way that outruns the available conditions for answerability. A role-position may be made responsible as danger, burden, guilt, correction duty, emotional stabilizer, explanation source, or presumed cause before the actual structure of the scene has been adequately read.

The drift can be stated as a sequence:

```text
reaction or power-coded presence
→ heightened scrutiny
→ motive is presumed before structure is traced
→ protection is reduced
→ responsibility load increases
```

The crucial step is not responsibility itself. Responsibility remains necessary wherever real structuring effect is traceable. The drift begins when the role-position becomes exposed to responsibility before legibility, capacity, alternative possibility, Θ (temporality), and Ω (asymmetry) cost or exposure conditions have been adequately considered. Overexposure is not the presence of responsibility. It is the intensification of responsibility without sufficient protection against misreading, moralization, or premature attribution.

Overexposure can operate through danger frames. A role-position may be read first as threat, dominance, intrusion, control, aggression, burden, or potential harm. Sometimes such readings may be structurally justified. A role-position may indeed have power, capacity, timing control, institutional backing, physical presence, or historical advantage. But where danger framing precedes the analysis of the actual scene, it can reduce legibility. The role-position becomes more available to suspicion than to description.

Overexposure can also operate through control frames. A request for clarity may be read as coercion. A critique may be read as domination. A boundary may be read as abandonment. A need may be read as immaturity. An explanation may be read as manipulation. A refusal may be read as threat. Again, none of these readings is false by default. The problem is the premature closure of meaning: the scene treats the role-position’s action or speech as already suspect before its structuring effect has been traced.

This makes overexposure a problem for D (dignity-in-practice). Responsibility without protection can become degradation. If a role-position is made answerable without adequate distance, reversibility, criticizability of the reading itself, or protection from moral verdict, then responsibility no longer functions as structural answerability. It becomes exposure. The role-position may still be responsible in some dimension, but the form of responsibility damages the conditions under which that responsibility can be truthfully named.

Overexposure also affects Σ (integration). A scene may integrate the truth that a role-position has power, visibility, capacity, history, or impact, while failing to integrate the truth that this same role-position also needs legibility, protection, distance, and a non-degrading account of its own exposure. One true element is preserved, but not the whole structure. The result is not adult responsibility. It is partial integration under heightened exposure.

The effect on Ψ (self-binding) is also important. An overexposed role-position may be required to bind itself more tightly than the scene can justify: explain more, soften more, absorb more, anticipate more, regulate more, apologize earlier, or prove non-threat before its actual structuring effect has been established. This does not mean that self-binding is unnecessary. Adult Ψ (self-binding) remains central. The drift appears where the demand for self-binding becomes disproportionate to the legible structure and protective conditions of the scene.

Overexposure may therefore produce a paradox. The role-position most intensely assigned responsibility may have the least legitimate language for describing how that responsibility load is produced. If it names the burden, it may appear evasive. If it asks for protection, it may appear fragile, entitled, or dangerous. If it objects to the frame, it may confirm the suspicion that it resists accountability. The more it tries to clarify, the more it may become readable as the problem.

This is where overexposure approaches Asymmetric Explanatory Poverty, but Chapter 13 must keep the terms distinct. Overexposure is the responsibility drift: too much responsibility, suspicion, or exposure relative to legibility and protection. Asymmetric Explanatory Poverty is the language condition that can make that drift hard to name. The two often appear together, but they are not identical.

The limiting guardrail must remain clear:

```text
Male power may be real.
Male overexposure may also be real.
These do not cancel each other.
```

This formula does not make Chapter 13 a male innocence chapter. It prevents a false alternative. A male-coded role-position may have real power, real capacity, real responsibility, and real structuring effect. It may also be overexposed in the way its motives, speech, needs, vulnerability, or reactions become legible. The presence of power does not erase overexposure. The presence of overexposure does not erase responsibility.

The same logic applies beyond male-coded scenes. A role-position can be overexposed wherever it is made too available to responsibility before the scene has supplied adequate legibility, protection, and traceable connection to effect. This may occur through institutional role, social visibility, physical presence, prior history, group-coded suspicion, relational expectations, or responsibility for protection. Overexposure is a scene relation, not an essence.

Overexposure must also be distinguished from criticism. Critique may be justified. Responsibility may be real. A role-position may need to answer for action, non-action, harm, omission, withholding, recognition failure, or non-binding. The drift is not that critique exists. The drift is that critique becomes exposure without sufficient legibility or protection, such that the role-position is treated as answerable before the structure of answerability has been adequately established.

For this reason, overexposure is not a counter-claim against accountability. It is a condition of false responsibility distribution. If responsibility is assigned too broadly, too early, too publicly, too asymmetrically, or with too little protection against degradation, then responsibility itself becomes distorted. The task is not to remove responsibility. The task is to let R (responsibility) follow real structuring effect under the conditions defined in Chapter 12.

Overexposure is therefore a responsibility problem, not a form of innocence. The overexposed role-position may still structure cost, harm, fear, delay, exposure, or non-binding. It may still need to answer for what it shapes. The claim is narrower: where responsibility is intensified beyond full legibility and protection, responsibility has been overassigned. Asymmetric Explanatory Poverty names the language condition that can make this drift difficult to describe.

### 13.4 Asymmetric Explanatory Poverty

Asymmetric Explanatory Poverty names the language condition that can bind immunization and overexposure together. A role-position may carry high exposure, high responsibility load, or high demand for explanation while lacking legitimate terms for describing how that load is produced. The problem is not that nothing can be said. The problem is that the available language does not allow the distribution of responsibility to be named without converting the speaker into the problem.

The formula is:

```text
AEP =
high exposure
+ low legitimate language
+ critique-to-threat switch
+ responsibility overload.
```

High exposure means that a role-position is strongly available to scrutiny, suspicion, correction, explanation demand, or responsibility assignment. It may be highly visible because of action, role, history, institutional position, body, sex-coded expectation, protection duty, prior harm, or perceived capacity. High exposure is not false by default. A role-position may indeed have real power, real capacity, or real responsibility. AEP begins where that exposure is paired with low legitimate language for naming the way responsibility is distributed.

Low legitimate language means that the role-position lacks acceptable terms for describing its own exposure without being read as evasive, threatening, self-pitying, controlling, fragile, resentful, or irresponsible. It may be able to feel the burden. It may even be able to describe parts of it. But the scene does not grant that description legitimacy. The explanation is heard not as a possible account of the structure, but as a refusal of accountability.

The critique-to-threat switch is the point at which a structural description becomes recoded as danger. A role-position may attempt to name non-action, non-binding, immunization, unequal responsibility load, or the cost of being required to explain. The scene may then hear that naming as domination, attack, evasion, emotional demand, refusal of care, or lack of recognition. The switch does not need to be intentional. It can occur as a frame effect: the attempt to describe the distribution becomes evidence against the speaker.

The fourth component is responsibility overload. A role-position under AEP may have to answer not only for what it actually structures, but also for the discomfort produced by naming the structure, the risk of being misread, the need to remain calm under suspicion, the burden of making its claim harmless, and the demand to preserve the scene’s moral frame while carrying disproportionate exposure. Responsibility becomes heavier because the language needed to distinguish real responsibility from overassignment is itself unstable.

AEP therefore differs from simple misunderstanding. It is not merely that two sides use different words. It is a structural mismatch between exposure and legitimate explanation. The role-position is answerable enough to be scrutinized, but not legible enough to be heard. It is visible enough to be corrected, but not protected enough to describe its exposure. It is responsible enough to be burdened, but not linguistically authorized to distinguish responsibility from overload.

This is why AEP must not be psychologized. It is not stupidity, incapacity, emotional immaturity, lack of articulation, moral inferiority, or an epistemic defect of a sex. A role-position under AEP may be highly articulate and still lack legitimate language. It may be structurally accurate and still be heard as dangerous. It may be capable of self-binding and still be unable to name the responsibility distribution without being treated as evading responsibility.

The negative formula should remain explicit:

```text
Asymmetric Explanatory Poverty is not stupidity,
not incapacity,
not moral inferiority,
and not epistemic defect of a sex.
```

AEP is related to limited legibility, but it is not identical with it. Limited legibility means that a scene lacks adequate concepts, distance, or available structure for reading what occurs. AEP is more specific. It names the condition in which the missing or delegitimated language is asymmetrically distributed: one role-position may be highly available to responsibility while lacking legitimate terms to describe how responsibility has been underassigned elsewhere, overassigned here, or made difficult to trace.

This makes AEP a responsibility problem. R (responsibility) cannot follow real structuring effect if the language for tracing that effect is blocked, moralized, or made unavailable to one side. The result is not merely confusion. It is drift. Immunized effects remain less answerable because they cannot be named without appearing harmful. Overexposed positions carry more responsibility because they cannot describe the overload without appearing evasive. The language gap stabilizes both directions at once.

AEP may take several possible forms. A role-position may lack legitimate language for naming non-action, non-binding, immunization, protection-as-responsibility-shield, its own vulnerability, or overexposure without being heard as suspicious, controlling, punitive, anti-protection, weak, or responsibility-averse.

The same condition can affect Χ (distance) and create a self-reinforcing speech problem. A request for distance may be read as abandonment or evasion; strained or highly careful speech may be treated as evidence of threat; silence may be read as guilt, withdrawal, or refusal to self-bind. The available options are then already structured by high exposure and low legitimate language.

This does not validate every claim of unspeakability. AEP must still be tested under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. It does not create innocence or cancel responsibility for real structuring effect.

In profile analysis, AEP is one possible component of a male-coded overexposure configuration, not a claim about male essence, recurrence, prevalence, or distribution. It can apply wherever high exposure is coupled with low legitimate language for describing responsibility distribution.

AEP is therefore the hinge between responsibility drift and profile formation. Immunization underassigns R (responsibility), overexposure overassigns it, and AEP makes that distribution difficult to name without intensifying the drift.

### 13.5 Male Overexposure Profile

The male overexposure profile names a possible, analytically reconstructed scene-bound configuration. It is not a claim about male essence, male innocence, male superiority, male victimhood, or male moral exemption, and it does not assert that the configuration recurs among men or male-coded role-positions. It does not say that male power is unreal or that male responsibility should be reduced by default. It identifies conditions under which male-coded presence, action, speech, need, hurt, or critique may become available to heightened suspicion, responsibility load, and reduced protection.

The guardrail must stand before the profile is described:

```text
Male power may be real.
Male overexposure may also be real.
These do not cancel each other.
```

This formula prevents a false choice. A male-coded role-position may have real power, real capacity, real access, real history, real ability to shape action conditions, or real responsibility for structuring a scene. It may also be overexposed in the way its motives, reactions, needs, vulnerability, or attempts at explanation are read. To name overexposure is not to deny power. To name power is not to deny overexposure.

The profile becomes visible where male-coded action is read first as danger. A direct act may be treated as domination before its actual structuring effect is traced. A refusal may be read as aggression. A boundary may be read as abandonment. A request may be read as pressure. A correction may be read as control. A silence may be read as threat or withdrawal. In some scenes these readings may be justified. The profile begins where the reading hardens before the scene has tested legibility, capacity, alternatives, temporality, and real structuring effect.

Male-coded speech is especially exposed to this drift. Explanation may be read as self-exoneration. Precision may be read as emotional evasion. Critique may be read as domination. Naming a burden may be read as reversal. Asking for fairness may be read as entitlement. Requesting protection from degradation may be read as refusal of responsibility. The role-position then becomes answerable not only for what it says, but also for the suspected motive assigned to the act of saying it.

Male-coded hurt may also become difficult to integrate. Hurt may be read as weakness, manipulation, resentment, fragility, immaturity, or a concealed demand for care. If the hurt is expressed, it may become suspicious. If it is withheld, it may become avoidance. If it is explained, it may become control. If it is minimized, it may become emotional absence. The profile does not claim that every expression of hurt is valid. It claims that, in some scenes, male-coded hurt enters with reduced legitimate language and heightened responsibility load.

This is where the profile connects to Asymmetric Explanatory Poverty. A male-coded role-position may be highly available to responsibility while lacking legitimate language to describe the burden of that availability. If it names overexposure, it may appear to deny responsibility. If it names vulnerability, it may lose status or credibility. If it names another role-position’s immunization, it may appear punitive. If it asks for distance, it may appear avoidant or threatening. The language needed to distinguish responsibility from overassignment becomes unstable.

The profile also affects Ψ (self-binding). A male-coded role-position may be expected to bind itself early, strongly, and visibly: regulate tone, clarify motive, absorb uncertainty, avoid escalation, protect the other, preserve the scene, and remain available for explanation. These demands may be legitimate in some dimensions. They become overexposing where the requirement to self-bind outruns the traceable responsibility of the role-position, or where another role-position’s non-binding remains comparatively less answerable.

Overexposure can therefore increase responsibility load while reducing protection. A male-coded role-position may remain fully criticizable for direct action, harm, coercion, abandonment, or non-binding. Nothing in this profile removes that. But if every attempt to name reduced protection is read as evasion, the role-position loses the conditions under which responsibility could be stated without degradation. Responsibility without protection damages D (dignity-in-practice), even when responsibility itself remains real.

This point must be held carefully. Male-coded overexposure is not a counter-victimhood claim. It does not say that male-coded role-positions are the real victims of every scene. It does not make female-coded vulnerability false. It does not convert male burden into innocence. The profile only says that responsibility can be overassigned to male-coded positions in specific scenes, especially where danger frames, motive suspicion, and low legitimate language precede structural tracing.

The profile also does not deny real harm produced by male-coded action. Direct force, coercion, abandonment, domination, intimidation, sexualized threat, material control, institutional power, and visible violence can all be real. Where they structure the scene, responsibility must remain fully traceable. Overexposure analysis must never become a shield against actual responsibility. It is a correction of responsibility overload, not an exemption from answerability.

The adult reading therefore remains dimensional. A male-coded role-position may carry strong responsibility for direct action and still be overexposed in the interpretation of its hurt. It may carry responsibility for institutional power and still lack legitimate language for relational vulnerability. It may need to answer for coercive effect and still need protection from person condemnation. It may structure cost in one dimension while being overassigned responsibility in another. The profile only becomes usable if these dimensions remain separate.

This is why the chapter must not turn the profile into a sex truth. The profile names a possible configuration in the distribution of exposure, responsibility, protection, and language. It does not establish that configuration as recurrent among men, male-coded role-positions, or scenes involving male vulnerability. It remains scene-bound, revisable, and conditional. If the scene does not show overassigned responsibility, reduced protection, and low legitimate language, the profile does not apply.

The male overexposure profile therefore clarifies one side of the coupled drift. It shows how responsibility can become too available where the role-position is read through danger, suspicion, control, or presumed burden before the structure is traced. The paired profile is female immunization, where vulnerability, recognition, protection, or hurt may protect real structuring effect from adequate responsibility without becoming a claim about female essence.

### 13.6 Female Immunization Profile

The female immunization profile names a possible, analytically reconstructed scene-bound configuration. It is not a claim about female essence, female guilt, female manipulation, female moral inferiority, or female exemption from agency, and it does not assert that the configuration recurs among women or female-coded role-positions. It does not say that female vulnerability is false or that protection should be withdrawn. It identifies conditions under which female-coded vulnerability, hurt, recognition, protection, care, non-action, or non-binding may become less available to responsibility than its structuring effect warrants.

The guardrail must stand before the profile is described:

```text
Female vulnerability can be real.
Female agency can be real.
Female responsibility can be real.
These must remain jointly coordinable.
```

This formula prevents a false choice. If female vulnerability is treated as unreal, the analysis becomes harsh, degrading, and structurally false. If female agency is treated as unreal, the analysis becomes paternalizing and removes adult praxis from the role-position. If female responsibility is treated as unreal, the scene can no longer coordinate R (responsibility) with real structuring effect. The adult standard requires that vulnerability, agency, and responsibility remain jointly thinkable.

The profile becomes visible where female-coded hurt acquires interpretive priority before the scene has traced what the hurt also structures. Hurt may be real. It may require protection, distance, care, or restraint. But hurt can also shape timing, speech, access, self-binding, recognition, and criticizability. Immunization drift begins where the scene can recognize hurt but cannot ask what the hurt makes others carry without treating that question as harm.

Female-coded vulnerability can also become a responsibility shield. A role-position may be genuinely exposed, fragile, dependent, previously harmed, or at risk of degradation. Those conditions matter. But where vulnerability blocks any adequate description of the role-position’s effect, protection becomes responsibility-displacing. The issue is not vulnerability itself. The issue is the frame that makes vulnerability incompatible with answerability.

Recognition can participate in the same drift. A female-coded role-position may rightly require recognition of dignity, burden, history, fear, harm, or voice. But recognition can become immunizing where it must be granted without criticizability, reciprocity, or responsibility. In that case, the scene may treat answerability as a withdrawal of recognition. The demand to be seen then becomes difficult to coordinate with the demand to remain answerable for what one structures.

Care can also become ambiguous. A care frame may rightly identify real need, relational burden, dependency, or asymmetrical exposure. But care can also make critique appear cruel, cold, selfish, unsafe, or insufficiently attentive before the structuring effect has been traced. The role-position that asks for responsibility may then appear uncaring, while the role-position whose effect is being named remains protected by the moral grammar of care.

Non-action is especially important in this profile. A female-coded role-position may structure a scene through silence, delay, non-clarification, withdrawal, fragility, openness, or non-binding without appearing to act in a responsibility-relevant way. The non-action may be genuine restraint, protection, uncertainty, or distance. But it may also shift Ψ (self-binding)-load, interpretive burden, timing cost, or emotional regulation onto another role-position. Immunization appears where the non-action’s effect is harder to name because it is coded as harmless, vulnerable, or non-dominant.

Non-binding can take a particularly stabilized form. A female-coded role-position may remain open, undecided, unclarified, emotionally undefined, or protected from commitment, while another role-position must organize itself around that openness. This does not mean that openness is false. It means that openness becomes immunizing where its costs are externalized and where naming those costs appears controlling, insensitive, or threatening. The issue is shifted Ψ (self-binding), not a diagnosis of motive.

The profile also affects Σ (integration). A scene may integrate the truth that female-coded vulnerability, fear, hurt, or exposure is real. But it may fail to integrate the truth that the same role-position can also shape action conditions, allocate recognition, withhold clarification, produce non-binding effects, or carry responsibility for the cost it produces. One true element is preserved, but another is excluded. The result is not protection with responsibility. It is partial integration under an immunizing frame.

This is why female immunization must be distinguished from protection. Protection from degradation remains necessary. Protection from coercion remains necessary. Protection from humiliation, public exposure, false attribution, or unsafe demand remains necessary. But protection does not require that a role-position’s structuring effects become uncriticizable. D (dignity-in-practice) protects the role-position from degradation while preserving agency, criticizability, and responsibility.

The profile must also be distinguished from a manipulation claim. EDEN does not say that a female-coded role-position intends to evade responsibility, weaponize vulnerability, exploit care, or control the scene through weakness. Such language would be diagnostic, psychological, and person-directed. The profile names a structural possibility: under some scene conditions, vulnerability, protection, care, recognition, hurt, or non-action may block adequate contact between effect and responsibility.

This also means that critique of female immunization is not anti-female critique. To treat female-coded praxis as responsibility-relevant is to treat it as fully adult. Adult agency includes the capacity to structure scenes, to affect others, to withhold, to bind or not bind, to protect, to expose, to recognize, to misrecognize, and to become answerable. Removing responsibility in the name of protection may appear generous, but it can also reduce the role-position to vulnerability rather than adult praxis.

The profile remains conditional. It applies only where a scene shows underassigned R (responsibility) relative to real structuring effect. It does not apply merely because a female-coded role-position is hurt, protected, recognized, vulnerable, silent, or non-binding. It does not apply by sex, identity, appearance, or isolated statement. It requires a scene reading: what effect is produced, how responsibility is displaced, what protection does, what language is available, and whether counter-scenes fit better.

A counter-scene may indeed fit better. The role-position may be genuinely harmed. The critique may be premature, overbroad, humiliating, coercive, or inaccurate. The non-action may be necessary restraint. The vulnerability may be the central structuring fact. The protection may be fully justified. Chapter 13 must leave these possibilities open. Without them, the female immunization profile would become suspicion by identity, which would violate the method.

The profile therefore clarifies one side of the coupled drift without turning it into a verdict. Female vulnerability can be real, female agency can be real, and female responsibility can be real. The profile becomes relevant only where those truths are no longer jointly coordinable because vulnerability, recognition, protection, care, hurt, non-action, or non-binding prevents responsibility from following real structuring effect. The necessary guardrail is that naming immunization must not immunize the critic, and naming overexposure must not erase responsibility.

### 13.7 No Reversal into Counter-Immunity

The final task of Chapter 13 is to prevent its own analysis from becoming another form of responsibility drift. Immunization, overexposure, and Asymmetric Explanatory Poverty can be named only if the naming itself remains scene-bound, revisable, and answerable. If critique of one false distribution becomes protection from critique for the critic, the chapter has failed. It has merely reversed the drift.

Counter-immunity names this risk. A role-position may name another role-position’s immunization and then treat that naming as proof of its own innocence. It may name overexposure and then treat that naming as exemption from responsibility. It may name false protection and then treat that naming as rejection of protection altogether. It may name Asymmetric Explanatory Poverty and then treat lack of language as if it erased its own structuring effects. In each case, critique becomes a new shield.

The first guardrail is therefore:

```text
Critique of female immunization
≠ male immunity.

Critique of male overexposure
≠ denial of male responsibility.

Critique of false protection
≠ rejection of protection.
```

These distinctions are not rhetorical. They are the condition under which Chapter 13 can remain methodologically valid. If critique of female-coded immunization becomes male-coded immunity, the analysis has reproduced the drift it claimed to expose. If critique of male-coded overexposure becomes denial of male-coded responsibility, the analysis has converted overexposure into innocence. If critique of false protection becomes rejection of protection, the analysis has abandoned dignity rather than defending responsibility.

The second guardrail extends the same logic:

```text
Critique of overexposure
≠ exemption from answerability.

Critique of responsibility overload
≠ refusal of responsibility.

Critique of recognition without responsibility
≠ permission to humiliate.
```

The point is not to balance accusations. It is to keep responsibility tied to real structuring effect. A role-position that is overexposed may still be responsible for what it structures. A role-position that lacks legitimate language may still have effects that require answerability. A role-position that criticizes immunization may still externalize cost, withhold recognition, overassign responsibility, or use its critique to avoid Ψ (self-binding). No drift analysis cancels the need for structural tracing.

This is why the correction of false asymmetry must not become a new false asymmetry:

```text
The correction of false asymmetry
must not become a new false asymmetry.
```

A scene may falsely protect one role-position from responsibility. Correcting that error does not justify exposing that role-position without protection. A scene may overassign responsibility to another role-position. Correcting that error does not justify removing responsibility from that role-position altogether. A scene may lack legitimate language for one burden. Correcting that absence does not justify treating the speaker as automatically right, innocent, or structurally central.

Counter-immunity often appears as methodological impatience. Once a drift has been named, the scene may want to convert it into a stable verdict: this side is immunized, that side is overexposed, this side cannot speak, that side must answer. EDEN must refuse that conversion. Immunization, overexposure, and AEP are scene relations, not identity claims. They require reading, counter-reading, boundary testing, and revision under changing conditions.

This is especially important for the profile sections. The male overexposure profile does not make male-coded role-positions innocent. The female immunization profile does not make female-coded role-positions guilty. Neither profile authorizes suspicion by identity, exemption by identity, or correction by reversal. A profile is usable only where the scene shows the relevant distribution of responsibility, exposure, protection, and language. Without that distribution, the profile does not apply.

Counter-immunity also threatens D (dignity-in-practice). If critique becomes a license to degrade, the method has left its own conditions. A role-position may be responsible without being humiliated. It may be protected without being immunized. It may be exposed without being condemned. Dignity-in-practice requires that responsibility remain criticizable without becoming a verdict on personhood, sex, worth, or moral essence.

The same holds for vulnerability. Critique of immunization must not become contempt for vulnerability. Vulnerability may be real, and protection may be required. The problem is not vulnerability, but the use of vulnerability to block responsibility where real structuring effect remains traceable. Conversely, critique of overexposure must not become dismissal of harm. Harm may be real, and responsibility may be required. The problem is not responsibility, but responsibility that outruns legibility, protection, and traceable effect.

The same holds for language. AEP does not mean that a role-position is right because it lacks legitimate terms. It means that the distribution of exposure and legitimacy may prevent truthful description from becoming available. A claim of unspeakability can itself become immunizing if it blocks responsibility. A claim of overexposure can become evasive if it refuses real structuring effect. A claim of immunization can become punitive if it turns another role-position’s vulnerability into guilt. Each claim must remain answerable to the scene.

The methodological consequence is strict. Chapter 13 cannot be applied by sex, role, profile, affect, or isolated statement. It cannot say: male-coded equals overexposed, female-coded equals immunized, vulnerable equals immunized, powerful equals guilty, hurt equals innocent, critique equals domination, or silence equals evasion. It can only ask how responsibility, exposure, protection, language, and structuring effect are distributed in this scene.

This preserves the chapter’s central grammar. Immunization names underassigned responsibility. Overexposure names overassigned responsibility. Asymmetric Explanatory Poverty names low legitimate language under high exposure and responsibility load. None of these terms is a verdict. Each is a revisable description of a scene relation under Ω (asymmetry), available legibility, capacity, alternative possibility, and temporal development.

No reversal into counter-immunity also protects Adult Reciprocity. Adult Reciprocity does not require that every responsibility drift be answered by an opposite drift. It requires responsibility to return to truthful coordination with real effect. If one side was falsely protected, the answer is not false exposure. If one side was falsely exposed, the answer is not immunity. If one side lacked language, the answer is not automatic authority. The answer is more precise coordination.

This is why Chapter 13 must end by refusing counter-victimhood. Naming male-coded overexposure must not create a new protected innocence. Naming female-coded immunization must not create a new generalized suspicion. Naming AEP must not create a hierarchy of whose suffering is more real. The problem is not which side wins the status of victim. The problem is whether R (responsibility) can again follow real structuring effect without degradation, erasure, or overload.

The chapter therefore hands forward a specific problem. Responsibility drift becomes more stable when recognition is separated from criticizability and responsibility. A role-position may be recognized without becoming answerable, or made answerable without being recognized. Chapter 14 turns to that configuration: recognition without responsibility, pseudo-equal-standing, and the ways critique can be converted into threat when recognition frames no longer remain coordinated with responsibility.

---

## 14. Recognition-without-Responsibility and Pseudo-Equal-Standing

Chapter 13 showed how R (responsibility) can drift when responsibility is underassigned, overassigned, or deprived of legitimate language under real Ω (asymmetry). Chapter 14 turns to a more specific stabilization of that drift: recognition itself can become separated from answerability. The problem is not recognition. Recognition remains necessary for Adult Reciprocity. The problem begins where recognition is claimed, granted, or protected in a way that reduces criticizability, weakens self-binding, blocks correction, or discounts responsibility for real structuring effect.

### 14.1 Definition

Recognition is not the enemy of responsibility. Equal dignity, protection from degradation, voice, visibility, and acknowledgment remain necessary wherever real Ω (asymmetry) structures a scene. A role-position may be misrecognized, degraded, exposed, silenced, or made illegible. Such injury can be real. A demand for recognition can therefore be structurally valid and dignity-preserving. Chapter 14 does not criticize recognition as such.

The opening guardrail is therefore:

```text
The problem is not recognition.
The problem is recognition decoupled from responsibility.
```

Recognition decouples from responsibility when a role-position claims or receives recognition while its real structuring effect becomes less available to answerability, criticizability, consequence attribution, or correction. The role-position may be recognized as dignified, vulnerable, injured, equal, morally serious, or in need of protection. None of that is false by default. The drift begins only where that recognition makes the role-position less answerable for what it structures.

Recognition-without-Responsibility names this drift:

```text
Recognition-without-Responsibility =
recognition claim
+ responsibility discount
+ critique-to-threat switch.
```

The formula does not mean that every recognition claim discounts responsibility. It means that recognition becomes drifted when a claim to dignity, voice, protection, moral standing, or equal status is linked to a reduced capacity to criticize the role-position’s structuring effect. What should have preserved dignity begins to interrupt answerability. What should have made participation more adult begins to weaken the conditions of adult reciprocity.

The expanded structure can be stated more precisely:

```text
A role-position claims equal dignity,
recognition,
voice,
protection,
or moral standing,
while its real structuring effect is shielded from proportionate criticism,
correction,
self-binding,
or consequence.
```

This drift is subtle because it often preserves a true element. Recognition may indeed be owed. A role-position may indeed have been ignored, degraded, silenced, exposed, or denied standing. Protection may indeed be necessary. But a true recognition claim can still become false as coordination if it blocks the relation between effect and responsibility. The question is not whether recognition is valid in abstraction. The question is whether recognition remains coordinated with answerability for real structuring effect.

Recognition-without-Responsibility therefore belongs to the same family as immunization, but it is not identical with Chapter 13’s full immunization analysis. Immunization names the broader drift in which effect remains insufficiently answerable. Recognition-without-Responsibility names one specific recognition-mode version of that drift: recognition becomes the frame through which responsibility is discounted, critique is recoded, and correction becomes difficult to sustain.

The drift can occur through several recognition-adjacent frames. A dignity frame may rightly protect a role-position from humiliation, but may also make structural critique appear degrading. A vulnerability frame may rightly name exposure, but may also make answerability appear unsafe. A protection frame may rightly prevent harm, but may also interrupt criticizability. An equality frame may rightly resist rank, but may also make unequal responsibility conditions difficult to name. In each case, the frame may contain truth. The question is whether it remains coordinated with responsibility.

This is why recognition must be distinguished from immunity. Recognition protects a role-position from degradation; immunity protects a role-position from responsibility. Recognition preserves dignity while leaving criticizability possible; immunity treats criticizability as if it were already degradation. Recognition makes adult participation possible; immunity weakens adult answerability. The difference is decisive for everything that follows in this chapter.

The same distinction protects critique from becoming too easy. Critique can be degrading. It can be premature, excessive, humiliating, inaccurate, coercive, or insufficiently protected by distance. A role-position may rightly reject a criticism that attacks personhood, worth, sex, dignity, or moral essence rather than naming a scene-bound structuring effect. Chapter 14 must therefore not imply that all critique is safe, legitimate, or adult merely because it calls itself structural.

But critique is not degrading as such. A responsibility claim is not automatically an attack on dignity. A correction attempt is not automatically a threat to recognition. A request for answerability is not automatically domination, humiliation, or refusal of care. If every critique of structuring effect becomes readable as threat, recognition has begun to block the very adult participation it was meant to secure.

This creates the central instability of Recognition-without-Responsibility. The recognized role-position may remain highly protected at the level of dignity language while becoming less bound to its own structuring effects. Another role-position may then carry more caution, more explanation, more restraint, more self-binding, or more burden for preserving the recognition frame. Recognition remains visible; responsibility becomes displaced.

The drift is not reducible to motive. EDEN does not say that the recognized role-position intends to evade responsibility, weaponize dignity, manipulate vulnerability, or exploit protection. Such claims would be psychological and person-directed. The structural claim is narrower: under some frames, recognition can function in a way that reduces criticizability and weakens the relation between real effect and answerability, regardless of the actor’s intention.

Recognition-without-Responsibility, Pseudo-Equal-Standing, the Critique-to-Threat Switch, and the female-coded recognition profile are analytically reconstructed, scene-bound configurations. They are not empirical typologies or claims about recurrence, prevalence, or distribution, and they do not belong by nature to any sex, group, personality, or identity. Whether any configuration occurs or recurs in a particular scene requires scene-bound evidence. The female-coded profile remains conditional rather than sex-defining and applies only where the scene shows the relevant distribution of recognition, responsibility discount, critique-to-threat switching, weakened self-binding, and blocked correction.

The task is therefore to preserve recognition while refusing its drift form. Recognition remains necessary. Equal dignity remains necessary. Protection remains necessary. But adult recognition cannot mean protection from all criticizability. It must remain compatible with answerability, self-binding, correction, and responsibility for real structuring effect. Genuine equal standing supplies the positive standard against which pseudo-equal-standing becomes legible.

### 14.2 Equal Standing as Recognition plus Responsibility

Before pseudo-equal-standing can be named, genuine equal standing has to be defined. Equal standing is not merely being seen, affirmed, protected, or granted voice. It is also not formal symmetry, identical burden, identical exposure, or identical role. Equal standing is an adult relation in which recognition and responsibility remain joined.

The formula is:

```text
Equal standing =
recognition
+ answerability
+ criticizability
+ consequence attribution
+ correctability
+ Dignity-in-practice.
```

Recognition is the first element because a role-position must not be degraded, erased, silenced, or treated as lesser before responsibility can be adultly assigned. Without recognition, responsibility easily becomes domination, humiliation, or person threat. A role-position that is not recognized as dignified cannot be held answerable in a way that preserves Adult Reciprocity. It can only be managed, blamed, corrected, or exposed.

But recognition alone is not equal standing. A role-position is not fully recognized as adult if its structuring effects cannot be criticized, corrected, or attributed as consequences. To recognize an adult role-position is not to protect it from all answerability. It is to treat it as capable of bearing responsibility without being reduced to guilt, inferiority, pathology, or essence.

This gives the first limiting formula:

```text
Recognition without answerability is not equal standing.
```

Answerability is the second element because real participation in a scene includes answerability for real structuring effect. A role-position may shape timing, protection, cost, access, recognition, exposure, non-binding, or correction conditions. Where such effect is real and sufficiently legible, the role-position must remain answerable to it. Otherwise recognition becomes incomplete. It protects the appearance of adult standing while withholding one of adulthood’s central conditions.

Answerability, however, must remain dignity-preserving. If a role-position is made answerable without protection from degradation, responsibility turns into overexposure. The role-position may be corrected, accused, explained, or burdened before the scene has preserved the conditions under which answerability can be adult rather than humiliating. Equal standing therefore also requires the inverse formula:

```text
Answerability without Dignity-in-practice is overexposure.
```

These two formulas belong together. Recognition without answerability becomes immunity risk. Answerability without Dignity-in-practice becomes overexposure risk. Adult equal standing requires the middle structure: the role-position remains protected from degradation while remaining open to responsibility for what it structures.

Criticizability is the third element. A recognized role-position must be criticizable without that criticizability becoming humiliation. Criticizability does not mean that every criticism is valid, proportionate, well-timed, or dignity-preserving. It means that criticism is not blocked in advance merely because it names a real structuring effect. If criticizability is removed, recognition can no longer function as adult recognition; it becomes protection from correction.

Consequence attribution is the fourth element. This does not mean blame, guilt, or total outcome-liability. It means that the consequences of a role-position’s structuring effect can be traced without being moralized into a verdict on personhood. A role-position may not have intended an effect. It may have acted under limited legibility, pressure, inherited frame, or constrained alternatives. Yet if it structures cost, exposure, access, or responsibility conditions, the consequence relation must remain nameable.

Correctability is the fifth element. Equal standing requires that a scene remain able to correct what it recognizes. Recognition that cannot be corrected becomes frozen. Responsibility that cannot be corrected becomes punitive. Correctability means that the scene can revise its reading, adjust responsibility, integrate cost, restore criticizability, and preserve dignity without turning correction into force, humiliation, or reversal. It is not an intervention protocol. It is a condition of adult coordination.

Dignity-in-practice is the sixth element because equal standing cannot survive if responsibility destroys dignity or if dignity destroys responsibility. Dignity-in-practice protects a role-position from degradation, but it does not protect the role-position from criticizability. It keeps responsibility from becoming domination, and it keeps recognition from becoming immunity. It is the restraint that allows adult answerability to remain non-degrading.

Equal standing therefore differs from formal equality. Formal equality may be necessary in some scenes, but it does not by itself coordinate real Ω (asymmetry). A scene may declare equal status while distributing unequal cost, unequal exposure, unequal protection, unequal responsibility, or unequal language access. If those differences cannot be named, the scene may appear equal while failing adult reciprocity.

The distinction can be stated directly:

```text
Equal dignity
≠ identical role
≠ identical exposure
≠ identical cost
≠ identical responsibility.
```

Equal dignity does not mean that all role-positions carry the same burden or face the same risk. It means that unequal burdens can be named without ranking the role-positions that carry them. A role-position may require more protection in one dimension and carry more responsibility in another. Another may have more capacity in one dimension and more exposure in another. Equal standing is not sameness. It is the ability to coordinate these differences without degradation, immunity, or false symmetry.

This point is crucial under real Ω (asymmetry). Where asymmetry is operative, identical treatment may not be truthful. One role-position may have more capacity, another more vulnerability; one may have more visible action-power, another more protected influence; one may be more exposed to responsibility, another less available to criticizability. Equal standing does not erase these differences. It requires that recognition and responsibility remain coordinated across them.

Equal standing also differs from mere recognition language. A scene may speak the language of dignity, equality, voice, inclusion, or acknowledgment while responsibility remains asymmetrically distributed. One role-position may be recognized as equal, but not equally criticizable. Another may be made answerable, but not equally protected from degradation. Such a scene does not lack recognition language. It lacks the full structure of equal standing.

This is why equal standing cannot be separated from R (responsibility). Responsibility is not an external addition to recognition; it is part of adult recognition. To recognize a role-position as adult is to treat it as capable of self-binding, criticizability, consequence-bearing, and correction. A recognition claim that cannot carry responsibility does not establish equal standing. It suspends one of its conditions.

At the same time, equal standing cannot be separated from D (dignity-in-practice). A responsibility claim that does not preserve dignity is not adult answerability. It may be punishment, exposure, domination, humiliation, or moral verdict. If Chapter 14 only insisted on responsibility, it would become anti-recognition. If it only insisted on recognition, it would become unable to name recognition drift. Equal standing holds both together.

The positive standard is therefore narrow and demanding. Equal standing means that a role-position can be recognized without being immunized, criticized without being degraded, protected without being exempted, held answerable without being humiliated, and corrected without being reduced to a person verdict. It is recognition plus responsibility under dignity-preserving conditions.

Pseudo-equal-standing imitates the language of equal standing while separating recognition from reciprocal answerability. It claims equality at the level of recognition while blocking criticizability, discounting responsibility, or making correction appear as threat.

### 14.3 Pseudo-Equal-Standing

Pseudo-equal-standing appears where the language of equal standing is preserved while the structure of equal standing is weakened. A role-position may claim recognition, voice, dignity, protection, or equal status, yet remain less available to criticizability, consequence attribution, self-binding, or correction than genuine equal standing requires. The scene speaks equality while distributing answerability unequally.

The formula is:

```text
Pseudo-equal-standing =
equal recognition claim
+ unequal criticizability
+ responsibility discount
+ protected frame
+ blocked correction.
```

The first element is the equal recognition claim. It may be valid in itself. A role-position may indeed require recognition, protection from degradation, acknowledgment of harm, or restoration of standing. Pseudo-equal-standing does not begin because recognition is claimed. It begins where the recognition claim becomes structurally detached from the conditions that make recognition adult: answerability, criticizability, consequence attribution, correctability, and D (dignity-in-practice).

The second element is unequal criticizability. A pseudo-equal-standing scene may allow one role-position to criticize while making critique of that same role-position appear degrading, unsafe, insensitive, excessive, or threatening. The problem is not that critique should be symmetrical in amount, tone, timing, or burden. Equal standing does not mean identical exposure. The problem is that criticizability itself becomes asymmetrically available: one role-position may name the scene, while another must make its naming harmless before it can be heard.

The third element is responsibility discount. R (responsibility) is not removed entirely; it is softened, delayed, moralized away, or relocated. A role-position may still speak as an adult participant, but its real structuring effect becomes less answerable than the scene requires. It may shape recognition, timing, protection, access, cost, exposure, non-binding, or correction conditions, while the responsibility relation to those effects remains weak. The scene does not deny adulthood in words; it discounts the responsibilities that belong to adult participation.

The fourth element is a protected frame. The frame may be dignity, vulnerability, safety, recognition, injury, equality, care, or protection. Each of these can be valid. Each can be necessary. The drift begins only where the protected frame blocks proportionate contact between structuring effect and answerability. The role-position is not merely protected from degradation; its effects become difficult to criticize without appearing to threaten the very value the frame protects.

The fifth element is blocked correction. Pseudo-equal-standing becomes stable when the scene can no longer correct the asymmetry between recognition and answerability. A criticism may be recoded as harm. A request for responsibility may be recoded as domination. A demand for consistency may be recoded as lack of care. A description of unequal self-binding may be recoded as attack. Correction becomes difficult not because no one can speak, but because the available speech is preloaded with threat.

The compressed drift can be stated as follows:

```text
equal recognition claim
→ critique becomes costly
→ responsibility is discounted
→ self-binding weakens
→ correction is blocked
→ adult reciprocity is simulated.
```

The word “simulated” is important. Pseudo-equal-standing does not simply reject equality. It often uses equality language intensely. It may insist on equal dignity, equal voice, equal recognition, equal moral seriousness, or equal participation. But the equality remains incomplete because equal recognition is not matched by equal availability to responsibility. The scene therefore appears adult at the level of standing while losing adult reciprocity at the level of answerability.

Pseudo-equal-standing is therefore related to Pseudo-Symmetry, but it is not identical with it. Pseudo-Symmetry names the broader parity switch in which real Ω (asymmetry) is framed as formal equality while cost, exposure, responsibility, or self-binding remain asymmetrically distributed. Pseudo-equal-standing names the recognition-specific form of that problem: equality is claimed at the level of dignity, recognition, or standing, while criticizability and responsibility for real structuring effect are discounted or blocked.

A direct formulation is useful here:

```text
Where a role-position is recognized as equal
while remaining less answerable for its own structuring effects,
recognition is granted without full equal standing.
```

This does not mean that every resistance to critique is pseudo-equal-standing. A critique may be degrading, inaccurate, badly timed, coercive, overbroad, or insufficiently protected by Χ (distance). A role-position may rightly reject criticism that attacks personhood, dignity, sex, worth, vulnerability, or moral essence. Pseudo-equal-standing appears only where critique of a responsibility-displacing structure is treated as if it were already critique of personhood.

This distinction protects the chapter from becoming anti-recognition. Equal standing requires that a role-position can reject degrading criticism. But it also requires that the same role-position remain open to non-degrading criticism of its own structuring effects. If every structural critique becomes degrading by definition, recognition has become immunity. If every responsibility claim becomes threat, equal standing has become pseudo-equal-standing.

Pseudo-equal-standing can also appear as selective adulthood. A role-position may claim adult recognition in matters of dignity, voice, autonomy, or moral seriousness, while being treated as less adult in matters of criticizability, consequence attribution, or self-binding. This selectivity may appear protective, but it weakens recognition itself. To recognize a role-position as adult only where recognition is affirming, and not where recognition requires responsibility, is not full adult recognition.

The reverse selectivity is also possible. Another role-position may be treated as fully adult in matters of responsibility, restraint, explanation, and self-binding, but less recognized in matters of vulnerability, protection, exposure, or need for dignity-preserving correction. In that case, pseudo-equal-standing does not merely immunize one side; it may overexpose another. The same scene can contain recognition without responsibility in one place and responsibility without sufficient recognition in another.

Pseudo-equal-standing specifies a recognition-mode distortion of responsibility drift. Immunization may occur where a role-position’s effect is protected from responsibility. Overexposure may occur where another role-position is made too answerable without full legibility or protection. Pseudo-equal-standing names the recognition form in which these drifts can be stabilized while the scene still speaks the language of equality.

The decisive issue is not whether a role-position asks to be recognized. Recognition remains necessary. The issue is whether the recognition claim remains tied to responsibility for what the role-position structures. Where recognition is claimed without criticizability, answerability, self-binding, or correction, equal standing becomes only a frame. The role-position is equal as recognized, but not equal as answerable.

This makes pseudo-equal-standing dangerous for Adult Reciprocity. Adult Reciprocity requires truthful coordination of real Ω (asymmetry), not formal parity at the level of recognition alone. If a scene declares equal standing while real responsibility, exposure, criticizability, and self-binding remain unequally distributed, the equality language can hide the asymmetry it should help coordinate. The result is not open hierarchy. It is false equality under blocked correction.

The local conclusion is therefore:

```text
Equal standing without reciprocal answerability
is not equal standing;
it can become immunization in recognition mode.
```

This sentence must not be overread. “Reciprocal” does not mean identical. It does not require equal burden, equal exposure, equal vulnerability, equal role, or identical responsibility. It means that no role-position can claim adult recognition while its real structuring effects are made unavailable to proportionate answerability. Equal standing remains real only where recognition, responsibility, criticizability, consequence attribution, correctability, and D (dignity-in-practice) remain jointly coordinated.

Once a recognition claim is protected from responsibility, critique itself may become difficult to sustain. The scene may begin to hear structural criticism not as an attempt to restore answerability, but as danger to dignity, safety, recognition, or personhood. That recontextualization is the Critique-to-Threat Switch.

### 14.4 Critique-to-Threat Switch

The Critique-to-Threat Switch is the mechanism by which a critique of real structuring effect is recontextualized as a threat to dignity, safety, recognition, or personhood. The critique may begin as a question of R (responsibility): what does this role-position structure, which consequences follow, and what answerability belongs to that effect? After the switch, the question changes. The critic is no longer heard primarily as naming a structure, but as endangering the recognized role-position.

The switch can be stated as follows:

```text
structure critique
→ threat frame
→ critic becomes danger
→ responsibility becomes harm
→ correction blocked
→ immunization stabilizes.
```

This sequence does not say that threat is always false. A critique can in fact be threatening, degrading, coercive, humiliating, excessive, badly timed, or structurally unsafe. A role-position may rightly reject a critique that attacks personhood, moral worth, sex, dignity, or standing rather than naming a scene-bound effect. The switch becomes drifted only where critique of a responsibility-displacing structure is treated as if it were already degradation or threat.

The distinction is therefore central:

```text
Critique can be degrading.
But critique is not degrading as such.
```

A theory of recognition must preserve both sides of this distinction. If critique is treated as harmless by default, the theory becomes brutalizing. It loses D (dignity-in-practice), because it cannot protect role-positions from humiliation, exposure, or coercive correction. But if critique is treated as threat by default, recognition becomes immunity. It protects the recognized position from the answerability that belongs to adult participation.

The Critique-to-Threat Switch often works through Φ (recontextualization). A structural claim is moved into another meaning-field. A request for answerability becomes a lack of care. A critique of non-binding becomes control. A description of cost becomes accusation. A demand for correction becomes domination. A question about responsibility becomes harm. The original structure may remain active, but the language available for naming it has been changed.

This is why the switch is especially powerful under recognition frames. Recognition language rightly protects against degradation. But once recognition becomes fused with protection from critique, every attempt to name structuring effect can appear as a withdrawal of recognition. The role-position is not merely protected from humiliation; it becomes protected from the kind of criticizability that equal standing requires. Recognition remains visible, while responsibility becomes harder to attach.

The switch can also operate through safety language. Safety may be real, and danger may be real. A scene may involve genuine intimidation, coercion, exposure, trauma, or threat. Chapter 14 does not deny these possibilities. But safety language becomes a false coordination frame when it treats responsibility claims as unsafe before the scene has tested whether the critique is actually degrading, coercive, or structurally overreaching. Safety then no longer protects dignity alone; it blocks correction.

The same structure appears through vulnerability language. Vulnerability may be real and may require protection. Yet vulnerability can become the route by which criticizability is suspended. A role-position may be vulnerable in one dimension and still structure cost, recognition, timing, access, or self-binding load in another. If naming those effects is treated as threat because vulnerability is present, then vulnerability has been separated from adult answerability.

This is the point at which structure critique must be distinguished from person threat:

```text
Critique of personhood
≠ critique of a responsibility-displacing structure.
```

The first attacks being, worth, identity, sex, moral essence, or standing. The second names a scene-bound configuration: responsibility is displaced, criticizability is blocked, self-binding is weakened, correction is made costly, or a real structuring effect is shielded from answerability. The two can be confused in practice, and critique can indeed slide from the second into the first. But they are not identical. If the distinction collapses, no structural responsibility can be named without appearing to wound personhood.

The local formulation is:

```text
The proper object of structural critique
is not the person’s worth or standing,
but the frame that makes answerability appear as attack.
```

This formulation does not deny that a person can feel threatened. It distinguishes the felt threat from the structural object of critique. A role-position may experience correction as destabilizing because the frame that protected recognition from answerability is being challenged. That experience may be real. But the reality of the experience does not by itself decide whether the critique is degrading or whether it names a real responsibility-displacing structure.

The switch therefore changes the burden of speech. Once critique becomes threat, the critic must first prove harmlessness before the structure can be discussed. The critic may need to soften, translate, reassure, apologize in advance, demonstrate care, avoid intensity, and protect the recognition frame before the responsibility claim can be heard. Some of this may be appropriate where exposure is high. It becomes drifted where the demand for harmlessness prevents any proportionate critique from reaching its object.

The responsibility effect is serious. R (responsibility) can no longer follow real structuring effect if every path toward naming that effect is blocked by threat attribution. The scene may then overassign responsibility to the critic for producing discomfort, and underassign responsibility to the role-position whose effect remains protected by the threat frame. The critique-to-threat switch therefore links recognition drift to the coupled drift from Chapter 13: one side’s effect becomes less answerable, while another side becomes more responsible for how carefully the effect is named.

The integration effect is equally serious. Σ (integration) becomes blocked because one real element absorbs the others. The scene may integrate the truth that a role-position feels exposed, hurt, vulnerable, or threatened. But it may fail to integrate the truth that the same role-position also structures cost, recognition, timing, protection, or self-binding conditions. The result is partial integration: a true vulnerability is preserved, while a true responsibility relation is excluded.

The self-binding effect follows from this. If a role-position’s recognition claim is protected by the threat frame, its own Ψ (self-binding) may weaken: it need not bind itself fully to the effects it structures because critique of those effects appears harmful. Another role-position may then have to bind itself more tightly around the protected frame. It must regulate speech, carry explanation burden, anticipate threat attribution, and preserve recognition while trying to name responsibility.

This does not mean that the critic is automatically right. A critic can misuse the language of structure. A critic can call humiliation “answerability,” call domination “correction,” call impatience “truth,” or call retaliation “responsibility.” The Critique-to-Threat Switch must therefore remain counter-scene exposed.

The narrower task is to name the drift mechanism. Recognition becomes unstable where critique of structuring effect is routinely recontextualized as threat to dignity, safety, recognition, or personhood. At that point, the scene may still speak the language of equal standing, but correction is blocked. Recognition, protection, weak self-binding, and critique-to-threat switching can then increase the self-binding burden on another role-position.

### 14.5 Recognition, Protection, and Ψ-Load

Recognition drift does not only affect criticizability. It also redistributes Ψ (self-binding)-load. When recognition, protection, vulnerability, or dignity frames become decoupled from answerability, one role-position may remain less bound to its own structuring effects while another role-position must bind itself more tightly around the protected frame. The result is not merely unequal recognition. It is unequal self-binding under the appearance of care, safety, or equal standing.

The compact formula is:

```text
Recognition
+ weak Ψ
+ critique-to-threat
→ increased Ψ-load on the other.
```

This formula does not mean that recognition itself weakens Ψ (self-binding). In Adult Reciprocity, recognition can strengthen self-binding because it allows a role-position to remain answerable without being humiliated. A recognized role-position can acknowledge its effects without losing dignity. The drift begins only where recognition protects the role-position from the self-binding that adult recognition would normally require.

Protection can produce the same ambiguity. Protection may be necessary where a role-position is exposed, vulnerable, threatened, degraded, or at risk of humiliation. Protection can preserve D (dignity-in-practice) by preventing responsibility from becoming overexposure. But protection becomes drifted where it no longer protects dignity while preserving answerability, but instead shields the role-position from criticizability, consequence attribution, or correction.

The difference can be stated sharply. Dignity protects against degradation. Immunization protects against responsibility. Dignity says: do not humiliate this role-position when naming its effect. Immunization says: do not name this role-position’s effect as responsibility-relevant. The two can be confused because both may use the language of care, safety, vulnerability, or recognition. But structurally they do opposite things.

Where the confusion stabilizes, Ψ (self-binding)-load shifts. The recognized or protected role-position may not have to bind itself fully to its own effects, because critique of those effects appears as threat, harm, withdrawal of recognition, or failure of care. Another role-position must then bind itself around that protected recognition claim. It must regulate tone, manage timing, soften critique, anticipate injury, preserve safety language, and keep the scene intelligible without appearing to attack the protected position.

The drift can be formulated in ordinary speech:

```text
I am recognized without binding myself,
while you must bind yourself around my recognition claim.
```

This sentence is not a psychological accusation. It does not say that the recognized role-position intends to evade responsibility or exploit protection. It names a distribution: one side receives recognition with reduced self-binding, while the other side receives increased self-binding in order to preserve that recognition. The problem lies in the scene relation, not in a hidden motive.

This drift often appears as asymmetrical carefulness. One role-position may have to be careful with critique, careful with tone, careful with timing, careful with wording, careful with affect, careful with distance, careful with interpretation, and careful not to trigger the threat frame. Some carefulness may be necessary. A scene structured by real exposure may require restraint. The drift begins where carefulness becomes a one-sided condition for allowing any responsibility claim to be heard.

The same pattern can appear through emotional labor, but Chapter 14 should avoid turning this into an advice or burden-balancing vocabulary. The structural point is narrower: when one role-position’s recognition frame makes critique costly, another role-position may carry more of the work of keeping correction non-threatening. It must not only name the structure; it must also protect the frame that makes naming the structure difficult.

This creates a double bind. If the burdened role-position speaks directly, it may appear harsh, unsafe, coercive, or insufficiently recognizing. If it softens too much, the responsibility claim may lose force. If it withdraws, it may appear avoidant or uncaring. If it continues to explain, it may appear controlling. The problem is not merely communicative difficulty. The problem is that recognition drift has altered the conditions under which correction can appear legitimate.

The effect on R (responsibility) is therefore indirect but serious. Responsibility may remain formally affirmed, yet practically displaced. The recognized role-position remains symbolically adult, but less bound to the effects it structures. The other role-position becomes more responsible not only for its own effects, but also for the safety, tone, timing, and recognitional acceptability of any critique. Responsibility is not denied; it is redistributed through the recognition frame.

The effect on Σ (integration) is equally important. The scene may integrate the truth that one role-position needs recognition, protection, or safety. But it may fail to integrate the truth that preserving that recognition has imposed a self-binding load on another role-position. One true element becomes integrated at the cost of another. The result is partial integration under recognition language.

Recognition, protection, and Ψ (self-binding)-load can therefore produce a hidden asymmetry. The scene may appear equal because both role-positions are formally recognized. Yet only one role-position may be permitted to remain less bound without losing standing, while the other must preserve the conditions of recognition before it can name responsibility. The equality language remains, but the self-binding distribution is no longer equally available to correction.

This does not mean that all recognition frames are suspicious. A recognition frame may be exactly what allows a vulnerable role-position to speak, recover dignity, refuse humiliation, and become answerable without fear. A protection frame may be what prevents critique from becoming degradation. The question is not whether recognition or protection exists. The question is whether recognition and protection remain coordinated with self-binding and responsibility.

The boundary is therefore simple:

```text
Protection of dignity
≠ protection from responsibility.
```

Protection of dignity preserves the conditions under which a role-position can remain adultly answerable. Protection from responsibility removes the role-position from the answerability that adult recognition entails. The first supports equal standing. The second produces recognition drift.

This distinction also prevents the opposite error. If the burdened role-position uses the language of Ψ-load to demand immediate access, correction, or confession from the other, the analysis has become coercive. A shifted self-binding load may be real, but naming it does not authorize forced correction, therapeutic intervention, or interpersonal command. Description may name the structure; application still requires distance, reversibility, dignity-in-practice, and contextual responsibility.

The point of Chapter 14 is therefore not to reduce recognition, but to make recognition more adult. Recognition that cannot include self-binding remains fragile. Protection that cannot include criticizability becomes immunizing. Critique that cannot preserve dignity becomes overexposing. Adult recognition must keep these elements coordinated: the role-position remains protected from degradation, open to responsibility, and bound to its own structuring effects.

Recognition and protection frames can enter sexed configurations without becoming sex truths. Any proposed female-coded drift under such frames remains a conditional, scene-bound structural hypothesis and does not establish recurrence or distribution. It also does not deny genuine vulnerability, genuine protection need, or dignity.

### 14.6 Female-Coded Drift under Recognition Frames

A female-coded drift under recognition frames names a possible, analytically reconstructed scene-bound configuration, not a claim about female essence or empirical distribution. It does not say that female-coded role-positions demand recognition without responsibility by nature, that female vulnerability is false, that protection should be withdrawn, or that recognition claims are suspect when they are female-coded. The profile names a narrower possibility: under specified frames, female-coded vulnerability, injury, dignity, care, or protection need may become the route through which real structuring effect is made less criticizable.

The opening guardrail must therefore remain explicit:

```text
This is not a claim about female essence.
It is a claim about role-position under specific frames.
```

The profile begins from conditions that may be real. Female-coded vulnerability can be real. Female-coded protection need can be real. Female-coded injury, exposure, dependency, fear, sexual risk, bodily risk, credibility pressure, or relational burden can be real. Chapter 14 does not deny these conditions, and it does not treat them as merely strategic. Recognition and protection may be necessary precisely because real Ω (asymmetry) can distribute exposure unevenly.

The required coordination is therefore:

```text
Female vulnerability can be real.
Female protection need can be real.
Female agency can be real.
Female responsibility can be real.
These must remain jointly coordinable.
```

The drift begins where these elements stop being jointly coordinable. A female-coded role-position may be recognized as vulnerable, hurt, morally serious, dignified, exposed, or in need of protection, while its own structuring effect becomes harder to name. The problem is not that vulnerability is recognized. The problem is that recognition may make answerability appear incompatible with care, dignity, or safety. In that case, recognition no longer supports equal standing; it reduces criticizability.

A compact profile formula is possible:

```text
female-coded vulnerability / recognition claim / protection frame
+ critique-to-threat switch
+ responsibility discount
→ reduced criticizability of real structuring effect.
```

This formula must not be read as a verdict. It does not apply wherever a female-coded role-position is vulnerable, hurt, protected, critical, silent, or uncertain. It applies only where the scene shows a traceable pattern: recognition is claimed or granted, critique becomes threat-coded, R (responsibility) is discounted, and a real structuring effect becomes less available to proportionate criticism or correction.

One possible form is hurt as interpretive priority. Hurt may be real and may require care. But hurt can also organize the scene so strongly that the question of what the hurt structures becomes unavailable. A role-position may shape timing, speech, caution, apology, recognition, distance, access, or self-binding load through hurt. If naming that effect is treated as further injury, the scene can recognize hurt while losing responsibility.

A second possible form is vulnerability as critique-block. Vulnerability may require protection from degradation, coercion, humiliation, or unsafe exposure. Yet vulnerability becomes drifted where it blocks any non-degrading critique of the role-position’s own effect. A vulnerable role-position may still withhold, delay, frame, expose, demand, recognize, misrecognize, or remain unbound in ways that structure the scene. Recognition drift begins where those effects cannot be named because vulnerability has become incompatible with criticizability.

A third form is recognition as moral priority. A female-coded role-position may rightly require recognition of dignity, harm, burden, or voice. But recognition becomes pseudo-equal-standing when the claim to be seen also becomes a claim to be less answerable. The role-position is recognized as equal in dignity, but not equally available to consequence attribution, correction, or self-binding. The scene then preserves recognition language while weakening adult reciprocity.

A fourth form is care as responsibility shield. Care may be necessary, and a scene may be brutal if it refuses care where exposure is real. But care becomes drifted where the one who asks for responsibility appears uncaring merely by asking. A critique of structuring effect may be heard as coldness, cruelty, abandonment, lack of empathy, or refusal of protection before the scene has asked whether the effect is real. Care then protects the frame from answerability rather than protecting dignity within answerability.

A fifth form is non-action as harmlessness. A female-coded role-position may structure a scene through silence, delay, hesitation, fragility, non-clarification, emotional openness, or non-binding without appearing to act in a responsibility-relevant way. This non-action may be legitimate restraint, uncertainty, distance, or protection. But if it shifts Ψ (self-binding)-load, timing burden, interpretive burden, or emotional regulation onto another role-position, it cannot be treated as harmless merely because it is non-dominant or non-overt.

A sixth form is non-binding as openness. Openness can be genuine. Uncertainty can be honest. A role-position may not yet be able to bind itself without falsifying the scene. But non-binding becomes recognition drift where it is protected as openness while another role-position must organize itself around its costs. The other side must wait, interpret, soften, explain, stabilize, or avoid pressure, while the non-binding position remains recognized as vulnerable or free rather than answerable to the burden its openness distributes.

These forms can combine. Hurt may supply interpretive priority. Vulnerability may block critique. Care may make correction appear cruel. Non-action may appear harmless. Non-binding may appear as openness. Recognition may then stabilize the whole configuration by making answerability look like a withdrawal of dignity. The resulting scene is not one in which recognition is absent. It is one in which recognition has become separated from responsibility.

The effect on Σ (integration) is partial integration. The scene may integrate the truth that a female-coded role-position is vulnerable, hurt, exposed, or in need of protection. But it may fail to integrate the truth that the same role-position also structures cost, timing, recognition, access, criticizability, or Ψ (self-binding)-load for others. One true element is preserved; another is excluded. The result is not care with responsibility, but care that blocks completion.

The effect on D (dignity-in-practice) is equally important. Dignity-in-practice requires protection from degradation, but it also requires recognition of agency and criticizability without humiliation. If a female-coded role-position is protected by reducing its answerability, dignity becomes incomplete. The role-position is protected as vulnerable, but not fully recognized as adult. Genuine dignity requires that vulnerability, agency, and responsibility remain together.

This is why critique of female-coded recognition drift is not anti-female critique. It is also not anti-vulnerability, anti-protection, or anti-care. To name the drift is to refuse the paternalizing split in which a female-coded role-position can be protected only by being made less answerable. Adult recognition treats the role-position as capable of both protection and responsibility, both vulnerability and agency, both dignity and criticizability.

The profile must also be distinguished from manipulation language. EDEN does not say that the role-position weaponizes recognition, exploits care, fabricates vulnerability, or intends to avoid responsibility. Such claims would psychologize the scene and turn a structural profile into a diagnosis. The claim is only that recognition frames can distribute criticizability and responsibility unevenly, even where the actors involved sincerely inhabit the frame.

Nor does the profile deny genuine threat. A critique may be degrading. A demand for responsibility may be coercive. A request for correction may be badly timed, excessive, humiliating, or unsafe. A female-coded role-position may rightly require protection from precisely those forms of exposure. The drift condition is narrower: protection from degradation must not become protection from all responsibility for real structuring effect.

The profile remains conditional. It does not apply by sex, identity, role, affect, or isolated statement. It applies only where a scene shows the relevant configuration: female-coded recognition or protection framing, critique-to-threat switching, discounted responsibility, weakened self-binding, and reduced criticizability of real effect. Without that configuration, the profile does not apply.

This conditionality also prevents reversal. Naming female-coded recognition drift must not create male immunity. A male-coded or otherwise burdened role-position may use critique of recognition drift to avoid its own responsibility, dismiss real vulnerability, refuse care, or demand unprotected correction. That would simply reproduce counter-immunity. The critique remains valid only if it remains scene-bound, dignity-preserving, and answerable to counter-scene.

Female-coded recognition drift is therefore a methodologically high-risk and tightly bounded profile. It names a possible configuration in which recognition, protection, vulnerability, care, non-action, and non-binding may reduce criticizability without becoming claims about women, motives, recurrence, or moral essence. Its positive boundary is recognition with responsibility, where dignity, criticizability, self-binding, protection, and correction remain jointly possible.

### 14.7 Boundary: Recognition-with-Responsibility

Chapter 14 must end by returning to its positive boundary. Recognition remains necessary. Equal dignity remains necessary. Protection remains necessary. Vulnerability may be real. Injury may be real. Threat may be real. The chapter has not argued for less recognition, less protection, or less care. It has argued against a drift form in which recognition becomes separated from responsibility, criticizability, self-binding, and correction.

The positive counter-form is Recognition-with-Responsibility:

```text
Recognition-with-Responsibility =
recognition
+ criticizability
+ self-binding
+ proportionate responsibility
+ dignity-preserving correction
+ Σ (integration) / Ψ (self-binding) openness.
```

Recognition-with-Responsibility begins where a role-position can be recognized without being immunized. Its dignity is protected, but its structuring effects remain available to answerability. Its vulnerability can be named, but its agency is not suspended. Its protection need can be honored, but its responsibility is not removed. Its voice can be heard, but its claims remain criticizable. Recognition becomes adult only where it can include the role-position’s participation in responsibility.

Criticizability is therefore not an attack on recognition. It is one of recognition’s adult forms. To treat a role-position as criticizable is to treat it as capable of participating in correction without being reduced to guilt, essence, inferiority, or pathology. Criticizability can become degrading if it attacks personhood, dignity, sex, worth, or moral standing. But criticizability as such is not degradation. Without criticizability, recognition becomes fragile because it cannot remain connected to real structuring effect.

Self-binding is the second positive condition. Ψ (self-binding) means that a role-position remains bound to the effects it helps structure. Recognition-with-Responsibility does not ask another role-position to bind itself around a recognition claim while the recognized position remains unbound. It requires the recognized position to carry its own effect as part of its dignity. Adult recognition does not mean “see me without asking what I structure.” It means “see me as capable of answerability without humiliation.”

Proportionate responsibility is the third condition. R (responsibility) must follow real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. Recognition-with-Responsibility therefore does not totalize responsibility. It does not convert recognition into blame, guilt, outcome-liability, or moral verdict. It asks only that responsibility remain proportionate to what the role-position actually structures under the conditions of the scene.

Dignity-preserving correction is the fourth condition. Correction must not become humiliation, domination, coercion, or person threat. A responsibility claim may be valid in content and still fail in form if it destroys D (dignity-in-practice). Recognition-with-Responsibility therefore protects the role-position from degradation while preserving the possibility of correction. It refuses both false alternatives: correction without dignity and dignity without correction.

Σ/Ψ openness is the fifth condition. Σ (integration) requires that the scene can take in the real costs, exposures, vulnerabilities, protections, responsibilities, and effects it contains. Ψ (self-binding) requires that relevant role-positions remain bound to their own part in structuring those effects. Recognition-with-Responsibility keeps both open. It does not allow one true element, such as vulnerability or harm, to exclude another true element, such as agency or responsibility.

This boundary also clarifies what Chapter 14 does not decide. It does not decide that every threat claim is false. It does not decide that every critique is legitimate. It does not decide that every protection claim is immunizing. It does not decide that every recognition demand discounts responsibility. Those would be reversals into suspicion. The chapter names a drift condition, not a presumption against recognition.

A genuine boundary remains necessary. A role-position may be genuinely harmed by critique. A responsibility claim may be premature, excessive, inaccurate, public in a degrading way, or coercively timed. A demand for self-binding may ignore limited legibility, capacity, alternatives, Θ (temporality), or Ω (asymmetry) cost. A request for correction may become domination. In such cases, recognition and protection may rightly limit, slow, redirect, or suspend the critique.

The inverse boundary is equally necessary. A role-position may invoke dignity, harm, safety, recognition, or vulnerability in a way that blocks all answerability for its real structuring effect. A protection claim may prevent not degradation, but criticizability. A recognition claim may make correction appear hostile before the scene has tested the structure. In such cases, recognition has drifted from adult standing into responsibility discount.

Chapter 18 will later develop the full boundary and falsifier logic. Chapter 14 only fixes the recognition-specific rule: neither recognition nor critique may decide the scene by itself. Recognition must remain answerable to real structuring effect. Critique must remain answerable to dignity, distance, proportionality, and counter-scene. If either side exits answerability, equal standing fails.

Recognition-with-Responsibility therefore also protects against counter-immunity. A role-position that names recognition drift does not thereby become innocent. It may still overassign responsibility, degrade vulnerability, dismiss protection, demand access, or use critique to avoid its own Ψ (self-binding). Naming pseudo-equal-standing does not create immunity for the critic. It only reopens the question of whether recognition and responsibility are truthfully coordinated.

The same protection applies to the recognized role-position. A role-position that requires recognition is not thereby evasive. It may need dignity restored before responsibility can be carried adultly. It may need protection from degradation before criticizability can become possible. It may need distance before correction can be heard without threat. Recognition-with-Responsibility does not rush past these needs. It asks that they remain coordinated with answerability rather than replacing it.

This is why Chapter 14 should not be read as a critique of equality. Equal standing is not rejected. It is sharpened. Equal standing cannot mean identical burden, identical exposure, identical role, or identical responsibility. It means that each role-position remains recognized and answerable under the actual structure of the scene. Where real Ω (asymmetry) is present, equal standing requires truthful coordination of unequal conditions, not the disappearance of difference.

The closing formula is therefore:

```text
The aim is not less recognition.
The aim is recognition that can remain adult under real Ω.
```

Recognition that remains adult under real Ω (asymmetry) does not protect dignity by removing responsibility. It does not preserve responsibility by destroying dignity. It holds the two together. It allows a role-position to be seen, protected from degradation, criticized without humiliation, answerable without totalization, and corrected without being reduced to personhood, sex, or moral essence.

This gives Chapter 14 its final contribution to the larger argument. Chapter 13 showed how responsibility can drift into immunization, overexposure, or asymmetric explanatory poverty. Chapter 14 has shown how recognition can stabilize such drift when it separates equal standing from answerability. The next chapter turns to one downstream regime form in which recognition, protection, parity, exception, and responsibility displacement can become more durable: PFO as regime stabilization.

---

## 15. PFO as Regime Stabilization

### 15.1 Definition

Postfeminist Override (PFO) is not the origin of reciprocity loss. In this paper, PFO does not name a person type, an ideology diagnosis, a political verdict, or a general theory of postfeminism. It names one downstream regime form in which reciprocity loss stabilizes. This demotion is decisive. The preceding chapters have already developed the primary grammar: real Ω (asymmetry) can be falsely coordinated, R (responsibility) can become displaced, Σ (integration) and Ψ (self-binding) can become blocked, switch patterns can become available, responsibility can drift into immunization and overexposure, and recognition can separate from answerability. PFO names a downstream stabilization of these mechanisms, not their first cause.

The opening guardrail is therefore:

```text
PFO is not the origin of reciprocity loss.
PFO is one regime form in which reciprocity loss stabilizes.
```

PFO names a regime stabilization rather than a master explanation. It is not the hidden source of false comparison, not the source of false-coordinated real Ω (asymmetry), not the source of recognition drift, and not the cause of reciprocity loss as such. It appears only when already established drift mechanisms become repeatedly available under recognizable frames of recognition, protection, parity, or exception.

The core definition is:

```text
PFO =
regime stabilization
of false-coordinated real Ω
under recognition / protection / parity / exception frames
with displaced R
and blocked Σ/Ψ.
```

This definition contains several constraints. First, PFO requires false-coordinated real Ω (asymmetry). The asymmetry must be real enough to structure cost, exposure, protection, criticizability, timing, responsibility, or self-binding conditions, but falsely coordinated enough that the scene cannot truthfully integrate it. Second, PFO requires displaced R (responsibility). Responsibility does not follow real structuring effect; it is softened, redirected, moralized away, overassigned elsewhere, or made difficult to attribute. Third, PFO requires blocked Σ (integration) / Ψ (self-binding). The scene cannot integrate the real distribution it contains, and relevant role-positions do not remain evenly bound to their own structuring effects.

The downstream sequence can be stated compactly:

```text
false-coordinated real Ω
→ displaced R
→ blocked Σ/Ψ
→ switch drift
→ immunization / overexposure
→ recognition-without-responsibility
→ possible regime stabilization
= PFO
```

The word “possible” matters. Not every false coordination becomes PFO. Not every switch becomes regime. Not every recognition drift becomes PFO. Not every responsibility displacement belongs to PFO. PFO appears only where the prior mechanisms become stabilized as repeatable frame availability. A scene may contain false-coordinated real Ω (asymmetry) without PFO. It may contain immunization without PFO. It may contain recognition-without-responsibility without PFO. PFO is narrower: a regime form in which these patterns become durable, available, and self-protecting.

A regime, in this sense, is not a person, not a belief, and not a conscious plan. It is a repeatable availability of frames that make some descriptions easy, some descriptions costly, some responsibilities visible, and other responsibilities difficult to assign. In PFO, recognition, protection, parity, and exception frames can be repeatedly used to keep real Ω (asymmetry) operational while making its naming appear regressive, threatening, dominating, harmful, or illegitimate.

This is why PFO must not be treated as a diagnosis. EDEN does not ask whether a person “has” PFO, “believes in” PFO, or “is” PFO. Such language would collapse a structural regime reading into a person label. PFO names a scene-level stabilization pattern. A role-position may participate in it without intending it, endorsing it, theorizing it, or consciously knowing it. Conversely, a person may use language associated with recognition, protection, equality, or vulnerability without participating in PFO at all.

The regime character also distinguishes PFO from an isolated switch. A single critique-to-threat switch does not prove PFO. A single recognition claim does not prove PFO. A single protection claim does not prove PFO. A single equality frame does not prove PFO. A single instance of false parity, exception, or responsibility displacement may matter structurally, but PFO requires repeatability: the frame must be available again, carry similar effects again, and stabilize displacement rather than merely appear once.

PFO therefore explains persistence rather than origin. It explains why a responsibility-displacing scene can become difficult to correct after several drift mechanisms have already converged. Recognition may remain necessary, but become less criticizable. Protection may remain valid, but become harder to distinguish from immunity. Parity may remain morally attractive, but become a route for exiting real Ω (asymmetry). Exception may remain justified in some scenes, but become repeatably available as a way to suspend consequence, self-binding, or correction.

The stabilizing effect lies in availability. A role-position does not need to invent a new justification each time responsibility becomes difficult. The scene already has frames ready to use. A critique can be recoded as threat. A responsibility claim can be recoded as domination. Naming asymmetry can be recoded as regression. Asking for self-binding can be recoded as control. Protection can be invoked where dignity is at stake, but also where criticizability is at stake. PFO exists where such recodings become durable enough to organize scenes.

This does not make PFO total. It is one stipulated regime form among other possible stabilizations of false-coordinated real Ω (asymmetry). PFO isolates a configuration organized around recognition, protection, parity, and exception frames; it does not establish its prevalence or distribution, exhaust reciprocity loss, or function as a universal key.

The definition also protects the chapter from a culture-war reading. PFO is not a synonym for feminism, equality discourse, recognition politics, protection claims, vulnerability language, criticism of male power, or modern gender arrangements as such. Any of these can be valid, necessary, and dignity-preserving. PFO begins only where such frames stabilize false-coordinated real Ω (asymmetry), displaced R (responsibility), and blocked Σ (integration) / Ψ (self-binding) in a repeatable way.

PFO is therefore a downstream regime label with strict conditions. It requires real asymmetry that remains operational, responsibility displacement that becomes repeatable, integration and self-binding blockages that become stable, and frame availability that protects the arrangement from correction. Without those conditions, the label does not apply. With those conditions, PFO names not the beginning of the problem, but one way the problem becomes durable.

The regime label must first be separated from belief, intention, ideology, or conscious endorsement; otherwise it becomes diagnostic and person-directed. This distinction also clarifies how Ω (asymmetry) can remain operational while becoming hard to name.

### 15.2 PFO Is Not Primarily Belief

PFO is not primarily belief. PFO is repeatable frame availability under real Ω (asymmetry). This distinction prevents the concept from becoming diagnostic. The question is not first whether a person believes in PFO, endorses PFO, intends PFO, or consciously identifies with PFO. The question is whether a scene makes certain frames repeatably available in ways that stabilize false-coordinated real Ω, displaced R (responsibility), and blocked Σ (integration) / Ψ (self-binding).

The guardrail can be stated directly:

```text
PFO is not primarily belief.
PFO is repeatable frame availability under real Ω.
```

A role-position may participate in PFO without intending, endorsing, or consciously knowing the regime form. This does not remove responsibility for real structuring effect. It prevents EDEN from converting structural participation into hidden motive, ideology diagnosis, or person label.

The corresponding formula is:

```text
A role-position may participate in PFO
without intending,
endorsing,
or consciously knowing the regime form.
```

This matters because belief language changes the object of analysis. If PFO is treated as belief, the analysis begins to ask who holds the belief, who secretly agrees with it, who is guilty of it, or who belongs to it. That movement is already too person-directed. PFO is not identified by inward conviction. It is identified by repeatable scene effects: which frames become available, which descriptions become costly, which responsibilities are displaced, and which integrations or self-bindings remain blocked.

The question is therefore not:

```text
Who believes PFO?
```

The question is:

```text
Which frames become available?
What do they make speakable?
What do they make unspeakable or costly?
How do they distribute R?
What happens to Σ/Ψ?
```

PFO can overlap with belief, discourse, social norms, institutional habits, affective expectations, political vocabulary, or moral self-understanding. But it is not reducible to any one of these. A person may sincerely value recognition, equality, protection, care, or vulnerability language and still participate in a frame that displaces responsibility. Another person may reject the vocabulary explicitly and still reproduce the same displacement through different means. The analytic object is not declared belief, but structuring effect.

The same point applies to ideology. PFO may become ideologically articulated in some settings, but Chapter 15 does not define it as ideology. If PFO becomes an ideology diagnosis, it becomes too broad and too accusatory. It would allow a scene to be read by political association, vocabulary, identity, or declared alignment rather than by the actual distribution of Ω (asymmetry), R (responsibility), Σ (integration), and Ψ (self-binding). That would violate the scene-bound discipline of EDEN.

Nor is PFO a synonym for postfeminism, feminism, anti-feminism, equality discourse, recognition politics, protection language, or criticism of male power. The acronym marks a paper-internal regime label, not a verdict on an external field. A feminist claim may be structurally valid. A protection claim may be necessary. A recognition claim may be dignity-preserving. A criticism of male power may be correct. None of these becomes PFO by vocabulary, identity, or political location alone.

This also prevents reversal into male immunity. If PFO is treated as a belief held by others, a male-coded or otherwise burdened role-position could use the label to avoid its own responsibility, dismiss genuine protection needs, or treat recognition claims as suspect. That would be a misuse of the concept. PFO names a regime pattern only where the scene shows repeatable frame availability, responsibility displacement, and blocked integration or self-binding. It does not make the critic innocent.

The belief distinction also keeps responsibility proportionate. If a role-position participates in PFO without conscious endorsement, responsibility cannot be assigned as guilt for hidden belief. R (responsibility) must still follow real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. Participation matters, but it must be read structurally rather than psychologized.

This means that PFO analysis begins with availability rather than accusation. It asks what the scene repeatedly permits, protects, delegitimates, or recodes. Does recognition make criticizability costly? Does protection become difficult to distinguish from immunity? Does parity make real asymmetry hard to name? Does exception become a route for suspending consequence, self-binding, or correction? These are regime questions, not belief questions.

PFO is therefore not primarily about what someone thinks. It is about what a scene can keep doing. A frame becomes available, carries a responsibility-displacing effect, survives correction, and remains available again. At that point, the issue is no longer merely episodic error. It is regime stabilization.

If PFO is repeatable frame availability rather than belief, its main operation is not inward conviction but patterned legibility. PFO stabilizes situations in which Ω (asymmetry) remains operational while becoming difficult to name.

### 15.3 Ω-Illegibility and Operational Asymmetry

Ω-illegibility means that Ω (asymmetry) remains operational while becoming difficult to name. The asymmetry still structures cost, exposure, protection, criticizability, recognition, timing, responsibility, or self-binding. It has not disappeared. What changes is the scene’s ability to describe it without the description being recoded as threat, regression, domination, harm, or refusal of recognition.

The formula is:

```text
Ω remains operational.
Ω becomes hard to name.
Naming Ω becomes threat, regression, domination, or harm.
Σ remains blocked.
Ψ remains asymmetrically distributed.
```

This formula is central because PFO does not require asymmetry to vanish. It requires asymmetry to remain operative while becoming illegible in the terms needed for correction. A scene may still distribute cost unequally. It may still place greater restraint, caution, explanation burden, exposure, or self-binding load on one role-position. It may still protect another role-position from criticizability. Yet if naming that distribution appears hostile or regressive, Ω (asymmetry) remains real while becoming difficult to coordinate.

Operational asymmetry is the first side of the structure. Real differences continue to matter. One role-position may carry more exposure to accusation. Another may carry more protection from critique. One may need to explain more, soften more, wait more, or make itself safer to hear. Another may remain less bound to the effects it structures. These distributions may be subtle, indirect, and partly non-evental, but they still shape the scene.

Illegibility is the second side. The scene may lack acceptable language for naming the distribution. A claim about asymmetrical responsibility may sound like domination. A description of unequal criticizability may sound like resentment. A question about protection and immunity may sound like cruelty. A request for self-binding may sound like control. The asymmetry remains active, but the terms that could name it are preloaded with disqualification.

This is not the same as merely having limited concepts. Chapter 5 already developed limited legibility as a general condition: scenes can lack sufficient language for what they structure. PFO is narrower. It is a regime-stabilized illegibility in which recognition, protection, parity, and exception frames make real Ω (asymmetry) difficult to name specifically because naming it threatens the frame that keeps responsibility displaced.

Nor is Ω-illegibility identical with asymmetric explanatory poverty. Chapter 13 named the condition in which a role-position may have high exposure, low legitimate language, critique-to-threat switching, and responsibility overload. PFO can intensify that condition, but it is not the same concept. Ω-illegibility names the regime feature: real asymmetry remains operational, while the language for naming it is repeatedly blocked, delegitimated, or made costly.

The practical effect is a split between operation and description. Operationally, the scene continues to distribute responsibility, criticizability, protection, exposure, and self-binding unequally. Descriptively, the scene may present itself as equal, caring, protective, progressive, safe, or dignity-preserving. The conflict between operation and description is where PFO gains stabilizing force. The scene can continue to do one thing while saying another.

This split can be especially strong under parity frames. Parity language may declare that the scene is equal, mutual, reciprocal, or symmetrical. Sometimes such language is truthful. But under Ω-illegibility, parity language can make asymmetry harder to name. The problem is not parity as such. The problem is parity language that prevents the scene from integrating the unequal cost, exposure, protection, criticizability, or responsibility distribution it still contains.

Protection frames can produce the same split. Protection may be necessary where dignity, vulnerability, or safety is genuinely at stake. But under Ω-illegibility, protection language may make it difficult to distinguish protection from responsibility discount. A role-position may be protected from degradation, which is necessary, while also becoming protected from criticizability, which is drift. If the distinction cannot be named, protection becomes part of the illegibility structure.

Recognition frames can also stabilize illegibility. Recognition may be owed and dignity-preserving. But where recognition is separated from responsibility, naming the responsibility relation can appear as a refusal of recognition. The scene then preserves recognition language while blocking the integration of real effect. Recognition remains visible; answerability becomes difficult to articulate.

Exception frames complete the structure. An exception may be legitimate where real vulnerability, risk, harm, or unequal capacity requires non-identical treatment. But if exception becomes repeatably available without correction, the exception begins to stabilize responsibility displacement. A role-position may be treated as an exception to ordinary criticizability, self-binding, or consequence attribution while the asymmetry created by that exception becomes hard to name.

In each case, Ω (asymmetry) does not disappear. It becomes operationally active and descriptively unstable. The scene may continue to distribute burdens, permissions, risks, costs, and protections, but the description of that distribution becomes difficult to sustain. This is why PFO cannot be reduced to formal equality language or protection language alone. The issue is the combination: real asymmetry remains, responsibility is displaced, and the available frames make naming the displacement costly.

The integration failure follows. Σ (integration) remains blocked because the scene cannot hold together the truths it contains. It may integrate the truth that recognition is necessary, but not the truth that recognition can discount responsibility. It may integrate the truth that protection is necessary, but not the truth that protection can become immunity. It may integrate the truth that parity resists hierarchy, but not the truth that parity language can hide real asymmetry. One true element absorbs the others.

The self-binding failure follows as well. Ψ (self-binding) remains asymmetrically distributed because some role-positions must bind themselves around the frame, while others remain less bound to the effects the frame protects. One side may have to speak more carefully, absorb more ambiguity, preserve recognition, avoid threat attributions, and carry more explanatory burden. Another may remain less answerable to the costs produced by the protected frame. The asymmetry is real even if the language for it remains unstable.

Ω-illegibility is therefore not ignorance. It is not stupidity, confusion, or conceptual poverty in a personal sense. It is a regime condition in which real asymmetry is repeatedly made difficult to name without triggering disqualification. This is what makes PFO durable. It is not that no one can ever see the asymmetry. It is that the scene has recurring ways to make naming it costly, suspect, or morally dangerous.

This also explains why PFO is difficult to correct. Correction requires that the scene can name what is miscoordinated. But if naming Ω (asymmetry) is already recoded as domination, regression, harm, or refusal of recognition, correction becomes structurally expensive before it even begins. The cost does not prove the critique is correct. It shows why counter-scene testing is necessary: the reading must remain able to fail, but it must also be allowed to be named.

Ω-illegibility is therefore a regime feature, not a general complaint about modern language. The problem is not that recognition, protection, parity, or exception frames exist. The problem is that, under PFO, these frames can make operational asymmetry difficult to name while continuing to organize responsibility, integration, and self-binding. The corresponding availability mechanism is the stabilization of the Switch Family at regime level rather than merely episodic switching.

### 15.4 Switch Family as Regime

Chapter 10 defined the Switch Family as a set of drift patterns through which a scene can move from one frame to another when responsibility, asymmetry, or correction becomes difficult to sustain. Chapter 15 does not redevelop that taxonomy. Its question is narrower: what happens when such switches cease to be merely episodic and become regime-available?

The shift can be stated simply. An episodic switch occurs when a scene, under pressure, reclassifies a responsibility-relevant structure through another frame. A regime switch pattern exists when such reclassification becomes repeatably available, socially legible, and difficult to correct. PFO is not the switch itself. PFO is the stabilization of switch availability under recognition, protection, parity, and exception frames.

The formula is:

```text
switch available
+ critique cost high
+ responsibility displacement repeatable
+ Σ/Ψ blockage stable
+ Α (attractor) stabilization
= regime stabilization
```

Here, “switch available” means that the scene does not have to invent a new path each time responsibility becomes costly. Recognition can become the frame through which criticizability is reduced. Protection can become the frame through which consequence attribution is delayed. Parity can become the frame through which real Ω (asymmetry) is made difficult to name. Exception can become the frame through which ordinary self-binding or correction is suspended.

“Critique cost high” means that attempts to name the structure become expensive before their content is tested. A critic may need to prove that the critique is not threat, domination, regression, cruelty, lack of care, or refusal of recognition. Some cost may be appropriate where vulnerability, exposure, or harm are real. The regime effect begins where the cost of critique is repeatably high enough to prevent proportionate correction.

“Responsibility displacement repeatable” means that R (responsibility) no longer fails only once. The scene repeatedly has ways to move responsibility away from real structuring effect. Responsibility may be recoded as harm, displaced onto the critic, softened into care language, suspended through exception, or made unnameable through parity. The important point is not which switch appears in isolation, but whether responsibility repeatedly fails to follow effect.

“Σ/Ψ blockage stable” means that Σ (integration) and Ψ (self-binding) do not merely fail momentarily. The scene repeatedly cannot integrate the real distribution it contains, and relevant role-positions repeatedly do not remain bound to their own structuring effects. One true element may absorb others: recognition absorbs responsibility, protection absorbs criticizability, parity absorbs asymmetry, exception absorbs correction. The blockage becomes a stable feature of the scene.

“Α (attractor) stabilization” means that repeated frame availability makes the switch increasingly available, normal, expected, or procedurally legitimate within the scene. Certain language lowers critique cost, other language raises it, and particular frames repeatedly interrupt correction or preserve standing. The switch is no longer merely episodic. It becomes protocol-like: not formal law or a new operator function, but recurrent scene logic stabilized as Α.

This is why PFO cannot be inferred from a single switch. A single recognition-to-immunity drift may be serious, but it does not by itself establish PFO. A single critique-to-threat switch may block correction, but it does not by itself establish regime stabilization. A single parity-to-exit move may falsely coordinate real Ω (asymmetry), but it may still be episodic. PFO requires repeatable availability and stabilizing effect.

The single-event guardrail must therefore remain visible:

```text
A single switch does not prove PFO.
A single recognition claim does not prove PFO.
A single protection claim does not prove PFO.
A single equality frame does not prove PFO.
```

This guardrail protects the concept from becoming a verdict machine. If every switch, claim, protection demand, recognition demand, equality appeal, or vulnerability frame could be labeled PFO, the concept would lose analytic discipline. It would become a way to confirm suspicion rather than a way to test regime stabilization. PFO begins only where repeated frame availability stabilizes responsibility displacement under real Ω (asymmetry).

The Switch Family enters Chapter 15 as a cluster, not as a catalogue. Pseudo-Symmetry may contribute where parity language makes real asymmetry difficult to name. Pseudo-Subordination may contribute where protection or vulnerability frames reverse criticizability. Pseudo-Superiority may contribute where moral or interpretive authority shields a role-position from consequence. Exception switches may contribute where ordinary responsibility is suspended under special conditions. But Chapter 15 does not need to re-explain each switch. It needs to show that the family can become regime-available.

Recognition frames provide one route. Chapter 14 showed how recognition can separate from responsibility. At regime level, this separation becomes easier to repeat. A role-position can be recognized in ways that make criticizability costly; critique can be heard as withdrawal of recognition; answerability can appear as threat. Recognition remains necessary, but the switch makes responsibility harder to attach.

Protection frames provide another route. Protection may be necessary and dignity-preserving. But at regime level, protection can become repeatedly available as a way to suspend criticizability. A role-position may be protected not only from degradation, but from responsibility-relevant naming. The switch does not require protection to be false. It requires protection to become repeatedly difficult to distinguish from immunity.

Parity frames provide a third route. Parity language may rightly resist hierarchy, rank, domination, or unilateral authority. But at regime level, parity can become a way to exit real Ω (asymmetry). If naming asymmetrical cost, exposure, responsibility, or self-binding appears to violate equality, then parity no longer coordinates difference. It blocks its description.

Exception frames provide a fourth route. Exceptions can be legitimate where capacity, vulnerability, harm, timing, or exposure conditions require non-identical treatment. But at regime level, exception can become a repeatable suspension of consequence, correction, or self-binding. What should have remained conditional becomes available as a stabilizing exit from responsibility.

These routes can reinforce one another. Recognition may make critique costly. Protection may make critique appear harmful. Parity may make asymmetry appear regressive. Exception may suspend ordinary correction. Together, they can create a regime environment in which responsibility displacement does not need a single master justification. The scene has several mutually reinforcing routes for keeping real Ω (asymmetry) operational while making it difficult to name.

This cluster character is what distinguishes PFO from a single-switch problem. PFO is not one move. It is a regime field in which several moves can become available in compatible ways. A critique blocked by recognition can be further blocked by protection. A responsibility claim resisted through parity can be further suspended through exception. A request for self-binding can be recoded as control, then as threat, then as failure of care. The regime does not require one switch to do all the work.

The result is not necessarily explicit coordination. No actor needs to say, “we will now preserve the regime.” The stability comes from repeated paths of least resistance. When responsibility becomes costly, familiar reclassification frames are already available. When asymmetry becomes visible, parity language may already provide an available redescription. When criticizability becomes necessary, protection language may already make it suspect. When correction becomes possible, exception language may already suspend it.

This is also why PFO can be sincere. A role-position may sincerely care about recognition, protection, parity, or exception. It may sincerely reject degradation, domination, or harm. Those commitments may be valid. PFO does not require cynicism. It requires that valid frames become available in ways that repeatedly stabilize false coordination. Sincerity does not prevent regime effect.

The damage begins when the family of switches becomes correction-resistant. If a critique fails, the scene may not return to the structure. It may move to another protective frame. If recognition is challenged, protection can appear. If protection is challenged, vulnerability can appear. If vulnerability is challenged, parity can appear. If parity is challenged, exception can appear. Each move may contain truth, but the sequence can prevent responsibility from returning to real structuring effect.

This sequence does not prove PFO by itself. It must be tested against counter-scenes. A scene may contain valid recognition, genuine vulnerability, necessary protection, truthful parity, and justified exception without PFO. Chapter 15 only names the regime condition: switches become repeatedly available, critique cost remains high, responsibility displacement repeats, Σ (integration) / Ψ (self-binding) blockage stabilizes, and Α (attractor) conditions make the pattern feel normal.

The Switch Family as regime therefore explains how PFO can persist without becoming a conspiracy, doctrine, or personality type. It persists because frame availability itself becomes stabilized. Once routes away from responsibility through recognition, protection, parity, or exception become recurrently available, correction must work against not just one error, but a repeatable cluster of legitimate-looking exits. Such persistence does not require conscious bad faith.

### 15.5 Why It Persists

PFO persists because regime stability does not require conscious bad faith. It requires repeatable frame availability. A scene can stabilize responsibility displacement without any role-position needing to intend the regime, believe in it as doctrine, or coordinate it as a plan. The stabilizing force lies in the fact that certain frames are already available when real Ω (asymmetry), R (responsibility), or correction becomes difficult to sustain.

The persistence formula is:

```text
Regime stability does not require conscious bad faith.
It requires repeatable frame availability.
```

This formula protects the analysis from psychologizing the scene. PFO does not persist because actors must be dishonest, manipulative, or secretly committed to responsibility evasion. It persists because recognition, protection, parity, and exception frames can become available as low-friction routes away from difficult responsibility questions. A role-position may sincerely inhabit the frame and still help stabilize the displacement it produces.

The first persistence condition is frame availability. When a responsibility claim becomes costly, the scene already has possible reclassifications. Critique can be heard as threat. Naming Ω (asymmetry) can be heard as regression. Asking for Ψ (self-binding) can be heard as control. Requesting correction can be heard as domination. Questioning protection can be heard as cruelty. The scene does not need to invent these meanings each time; they are available before the conflict begins.

The second persistence condition is legitimation. The available frames do not appear as merely defensive. They appear morally legitimate. Recognition is morally serious. Protection is morally serious. Equality is morally serious. Exception may be morally serious where real vulnerability, risk, harm, or limited capacity exists. This is why PFO is difficult to correct: its stabilizing frames often preserve truths. The regime does not persist by pure falsehood. It persists by allowing true elements to block fuller integration.

The third persistence condition is critique cost. Once recognition, protection, parity, or exception frames are available, critique may have to pass through additional burdens before its content can be tested. The critic may have to prove that naming a structure is not threat, domination, regression, lack of care, punishment, or refusal of dignity. Some such burden may be appropriate where exposure is real. It becomes regime-stabilizing where the cost of critique repeatedly prevents responsibility from returning to real structuring effect.

A specific form of this cost appears when critique comes from a role-position that would be expected to be protected by, or aligned with, the regime frame itself. Such internal counter-witnesses can become especially costly for the regime because they disturb the expected distribution of recognition and protection. The response may therefore recode them as betrayal, regression, contamination, exceptional pathology, disloyalty, or complicity with domination. The structural point is not that such dissent is automatically true. It is that, under PFO, even an internal counter-scene may be made expensive to sustain before its content can test the regime.

The fourth persistence condition is responsibility displacement. R (responsibility) does not need to disappear; it only needs to move. Responsibility can move from the structuring role-position to the critic who names the structure. It can move from the effect to the discomfort caused by naming the effect. It can move from correction to the alleged harm of correction. It can move from real asymmetry to the impropriety of mentioning asymmetry. The displacement persists when the scene repeatedly treats the naming of the problem as more responsibility-relevant than the problem named.

The fifth persistence condition is chronic Λ (non-event). Some of the stabilizing work happens through what does not happen. The correction is not made. The cost is not integrated. The responsibility relation is not named. The asymmetry is not tested. The protected frame is not revised. These non-events can become structurally active without appearing as decisive acts. PFO persists partly because what would interrupt it repeatedly fails to occur.

The sixth persistence condition is erosion of the correction window across Θ (temporality). Correction depends on timing. A scene must still be able to return to what happened, hold a responsibility relation open, and revise its frame before the structure disappears into ambiguity. Under PFO, however, accumulated time can work against correction. The longer the protected frame remains unchallenged, the more costly challenge becomes. The moment for naming Ω (asymmetry) can pass; later naming can appear untimely, resentful, excessive, or regressive. The regime persists where correction becomes increasingly difficult to introduce as temporally legitimate.

The seventh persistence condition is Α (attractor) stabilization. Across repeated scenes or repeated moments within a scene, particular frames may become increasingly available for reducing critique, preserving recognition, suspending consequence, or blocking the naming of asymmetry. This is not a formal protocol or a new operator function. It is recurrent scene logic stabilized as Α.

These conditions can reinforce one another. Frame availability supplies a route. Legitimation gives the route moral cover. Critique cost makes the route difficult to challenge. Responsibility displacement redirects pressure away from real structuring effect. Chronic Λ (non-event) prevents interruption. Erosion of the correction window across Θ makes delayed correction appear illegitimate. Α (attractor) stabilization makes the recurrent route increasingly normal and available. Persistence emerges from the cluster, not from a single intention.

This is why PFO can survive sincere criticism. A role-position may point out that responsibility is being displaced, but the scene may reclassify that very critique as domination, regression, threat, or lack of care. The critique is then absorbed into the regime’s own logic. Instead of opening the structure, it confirms the need for the protective frame. PFO persists when attempted correction becomes material for further stabilization.

The persistence is also strengthened by partial truth. If recognition were simply false, protection simply false, parity simply false, or exception simply false, correction would be easier. The problem is that the frames may be true in part. Recognition may be owed. Protection may be necessary. Equality may matter. Exception may be justified. PFO persists where those truths become unavailable for integration with other truths: real Ω (asymmetry), displaced R (responsibility), blocked Σ (integration), and asymmetric Ψ (self-binding).

This explains why PFO cannot be defeated by suspicion. To treat every recognition claim, protection demand, equality appeal, vulnerability claim, or exception as PFO would merely reverse the error. It would make the critic immune and destroy D (dignity-in-practice). The problem is not that these frames exist. The problem is repeatable availability under conditions where they stabilize responsibility displacement and block correction.

PFO therefore persists through an economy of legitimacy, cost, and non-correction. It does not need to announce itself. It only needs the scene to keep finding available, legitimate-looking routes away from responsibility when responsibility becomes difficult. This persistence is what makes PFO more than an episode. It is also what makes its damage broader than any single conflict.

### 15.6 Why It Damages Reciprocity

PFO does not merely harm one side. It damages the possibility of adult reciprocity itself. This point is necessary because PFO can easily be misread as a reversal claim: one side loses, another side wins; one side is exposed, another side is protected; one side is innocent, another side is guilty. That is not the argument. The deeper damage is structural. PFO makes truthful coordination of real Ω (asymmetry) harder to sustain.

The damage formula is:

```text
PFO does not merely harm one side.
It damages the possibility of adult reciprocity itself.
```

Adult Reciprocity requires that real Ω (asymmetry) can be named, coordinated, and integrated without being falsely converted into rank, domination, immunity, or threat. PFO damages that possibility by keeping Ω operational while making its naming costly. The scene may still distribute burden, exposure, protection, criticizability, and responsibility unevenly, but it loses the language and correction pathways needed to coordinate that distribution truthfully.

The first damage is responsibility displacement. R (responsibility) no longer follows real structuring effect reliably. A role-position may structure cost, timing, recognition, protection, exception, criticizability, or self-binding load while remaining less answerable to those effects. Another role-position may become more responsible for how carefully, safely, or recognitionally it names the displacement. Responsibility remains active, but its attachment to effect becomes unstable.

The second damage is blocked integration. Σ (integration) cannot hold the scene’s real elements together. Recognition may be integrated without responsibility. Protection may be integrated without criticizability. Parity may be integrated without asymmetry. Exception may be integrated without correction. Each true element can become partial and dominating because the scene cannot integrate the other true elements it excludes.

The third damage is asymmetric self-binding. Ψ (self-binding) becomes unevenly distributed. One role-position may have to regulate speech, soften critique, absorb ambiguity, preserve recognition, respect exception, and protect the frame before responsibility can be named. Another may remain less bound to the effects that frame protects. Adult Reciprocity weakens because mutual recognition no longer carries mutual answerability.

The fourth damage is correction fragility. Correction becomes difficult not only because someone resists it, but because the scene’s available frames make correction appear morally suspect before it can be tested. A correction attempt may be heard as threat, domination, regression, cruelty, refusal of recognition, or attack on protection. Correction then requires not only evidence, but repeated proof of harmlessness. The path back to structure becomes fragile.

The fifth damage is loss of counter-scene availability. A scene remains adult only if its reading can be challenged, revised, and defeated by counter-evidence. Under PFO, counter-scenes may be absorbed rather than allowed to test the regime. Evidence of asymmetry can be recoded as resentment. Evidence of responsibility displacement can be recoded as control. Evidence of blocked self-binding can be recoded as pressure. Internal counter-witnesses may carry an additional Ψ (self-binding)-load: they must not only name the structure, but also prove that their dissent is not betrayal, regression, pathology, or complicity. When counter-scenes cannot alter the reading, the scene loses reversibility.

This damage is not reducible to male overexposure or female immunization, even when those profiles appear. PFO may overexpose one role-position by making it carry excessive responsibility for critique, tone, safety, timing, and recognition. It may immunize another by making its structuring effects less criticizable under protection or recognition frames. But the theoretical point is not that one side simply suffers and the other benefits. The point is that the reciprocity structure itself becomes less available.

The damage also affects the role-position that appears protected. A role-position protected from degradation may need that protection. But if protection becomes protection from responsibility, adult recognition weakens. The role-position is no longer fully recognized as capable of answerability, criticizability, self-binding, and correction. What appears as protection can become a diminished form of adult standing.

The role-position that appears burdened is also structurally damaged. It may remain responsible for its own effects, but also become responsible for preserving the recognitional conditions under which any critique can be heard. It may carry additional explanatory burden, caution, restraint, timing pressure, and risk of misrecognition. This can produce overexposure, but the key point remains broader: adult reciprocity is no longer distributed through truthful coordination of real effect.

PFO therefore damages both recognition and responsibility. Recognition becomes less adult because it cannot reliably include answerability. Responsibility becomes less adult because it becomes either displaced, overassigned, or made unsafe to name. Protection becomes less adult because it cannot always be distinguished from immunity. Parity becomes less adult because it may hide the unequal conditions it should help coordinate. Exception becomes less adult because it may suspend correction without remaining answerable to the scene.

The resulting loss is not merely moral. It is structural. A scene that cannot name real Ω (asymmetry), assign R (responsibility) proportionately, sustain Σ (integration), and distribute Ψ (self-binding) without distortion cannot maintain Adult Reciprocity. It may preserve language of recognition, equality, protection, or care, but the structural conditions of adult coordination have weakened.

This is why Chapter 15 must remain downstream. PFO is damaging because it stabilizes mechanisms already developed earlier: false-coordinated real Ω (asymmetry), displaced R (responsibility), blocked Σ (integration), blocked or shifted Ψ (self-binding), switch drift, immunization, overexposure, and recognition-without-responsibility. It does not create reciprocity loss from nothing. It gives that loss a durable regime form.

The damage points toward reciprocity loss as tragedy: the loss of adult relational possibility, not merely the victory of one side over another. The argument here remains narrower by showing one way reciprocity loss becomes stable before it becomes fully visible as loss.

Because PFO is serious, the concept must remain bounded. A powerful regime label without failure conditions becomes a verdict frame. Its boundary must therefore specify what PFO is not, when the label must not apply, and why a PFO reading must remain defeasible.

### 15.7 Boundary

The seriousness of PFO requires a strict boundary. A regime label that cannot fail becomes a verdict frame. Chapter 15 has defined PFO as downstream regime stabilization, but that definition must not become a permission to read every recognition claim, protection demand, equality appeal, vulnerability claim, feminist argument, or criticism of male power as PFO. If the concept becomes too easy to apply, it destroys the analytic discipline it was meant to protect.

The first boundary is therefore:

```text
False-coordinated real Ω can occur without PFO.
PFO is only one regime stabilization form.
```

False coordination of Ω (asymmetry) is broader than PFO. A scene may falsely coordinate real asymmetry through family tradition, religious order, bureaucratic procedure, economic dependency, institutional hierarchy, therapeutic vocabulary, legal classification, political loyalty, or ordinary avoidance. Such scenes may displace R (responsibility), block Σ (integration), or shift Ψ (self-binding) without becoming PFO. PFO applies only where false-coordinated real Ω stabilizes under repeatable recognition, protection, parity, or exception frames.

The second boundary concerns isolated evidence. A single switch does not prove PFO. A single recognition claim does not prove PFO. A single protection claim does not prove PFO. A single equality frame does not prove PFO. A single critique-to-threat movement, parity appeal, vulnerability claim, or exception demand may be important, but it remains insufficient. PFO requires repeated frame availability and stabilizing effect.

The guardrail should remain explicit:

```text
A single switch does not prove PFO.
A single recognition claim does not prove PFO.
A single protection claim does not prove PFO.
A single equality frame does not prove PFO.
```

This boundary prevents PFO-by-vibe. The concept cannot be applied because a scene “sounds like” PFO, because a role-position uses recognition language, because a protection claim feels excessive, because equality language appears, or because a critic experiences frustration. PFO requires a scene-bound pattern: operational Ω (asymmetry), displaced R (responsibility), blocked Σ (integration) / Ψ (self-binding), repeated switch availability, and correction-resistant stabilization.

The third boundary concerns valid frames. Recognition is not PFO. Protection is not PFO. Equality is not PFO. Feminist critique is not PFO. Vulnerability language is not PFO. Criticism of male power is not PFO. Any of these may be truthful, necessary, dignity-preserving, and structurally corrective. The question is never whether such language appears. The question is whether it repeatedly stabilizes false-coordinated real Ω, responsibility displacement, and blocked correction.

This matters especially because PFO analysis can itself become abusive if it turns into suspicion of protection, recognition, or equality as such. A role-position may need recognition before responsibility can be carried adultly. It may need protection before criticizability can become non-degrading. It may need exception because real capacity, exposure, timing, or harm conditions differ. PFO does not authorize the critic to treat those needs as evasion.

The fourth boundary concerns internal counter-witnesses. A dissenting insider may expose a regime pattern by speaking from a position that the regime frame would be expected to protect or represent. Such dissent can matter because it disturbs the expected distribution of recognition, protection, and criticizability. But internal dissent does not automatically prove PFO. It may be partial, mistaken, overgeneralized, captured by another frame, or insufficiently protected by Χ (distance). Its force lies not in identity, but in whether it opens a counter-scene that can test the regime reading.

The inverse is also true. A regime cannot dismiss internal counter-witnesses merely by recoding them as betrayal, regression, pathology, contamination, or complicity. Such recodings may themselves become part of the critique cost. But the proper conclusion is not that the dissenting role-position is automatically right. The conclusion is that the scene must remain able to test the dissent without making its existence illegitimate in advance.

The fifth boundary is counter-scene defeasibility. A PFO reading must be able to fail. Counter-scenes must be capable of changing the reading if they show that recognition is genuinely dignity-preserving, that protection is necessary, that parity is truthful, that exception is justified, that critique is degrading, that responsibility is being overassigned, or that the supposed stabilization is not repeatable. Without this defeasibility, PFO becomes a closed verdict.

The central boundary formula is therefore:

```text
A PFO reading must be able to fail.
If counter-scenes cannot change the reading,
PFO has become a verdict frame,
not an analytic category.
```

This rule protects both sides of the analysis. It protects recognized or protected role-positions from being captured by a suspicious label. It also protects burdened or overexposed role-positions from having every counter-scene absorbed back into the regime. A counter-scene must be allowed to disconfirm PFO, but it must also be allowed to name the conditions under which PFO-like stabilization is actually present.

The sixth boundary concerns application. Chapter 15 defines PFO; it does not authorize application to persons, couples, institutions, sexes, groups, political positions, or cases. Application requires more than a label. It requires a scene packet, role-position analysis, real Ω (asymmetry), traceable structuring effect, responsibility distribution, counter-scene testing, Χ (distance), reversibility, and D (dignity-in-practice). Without these conditions, PFO is not analysis. It is verdict.

This application firewall is especially important because PFO is a powerful regime label. Powerful labels attract overuse. They can make complex scenes feel instantly legible. They can give the critic premature certainty. They can turn structural reading into moral possession of the scene. EDEN must resist that temptation. Description may name a possible regime stabilization; it does not authorize coercive action, person ranking, sex ranking, or diagnostic closure.

The seventh boundary concerns rival explanations. A scene that resembles PFO may be better explained by other forms of false coordination, limited legibility, institutional role conflict, fear, trauma, capacity limits, economic dependency, inherited scripts, status anxiety, religious norms, bureaucratic incentives, or ordinary interpersonal avoidance. These explanations do not automatically defeat PFO, but they must be allowed to compete with it. If no rival explanation can matter, the reading has become immune.

This means that PFO remains a conditional category. It applies only where the scene shows repeatable recognition, protection, parity, or exception frame availability that stabilizes false-coordinated real Ω (asymmetry), displaced R (responsibility), blocked Σ (integration) / Ψ (self-binding), and correction resistance. Where those conditions are absent, the category must not be used. Where counter-scenes defeat them, the category must be withdrawn.

The final boundary returns to the chapter’s opening demotion. PFO is not the origin of reciprocity loss. PFO is not the master cause of the paper. PFO is not the secret name for modern gender order. PFO is one regime form in which reciprocity loss may stabilize after prior drift mechanisms have already become available. It explains one route by which loss becomes durable, not the whole grammar of the loss itself.

This prepares the transition. Chapter 16 will not return to an Eden-first architecture. Eden now enters late, as a test scene for the grammar already developed. Chapter 17 will then unfold reciprocity loss as tragedy, not as the victory of one side or the exposure of one culprit. PFO has done its work if it shows how recognition, protection, parity, and exception frames can stabilize reciprocity loss without becoming its origin, center, or verdict machine.

---

## 16. Eden Scene, Negative Responsibility Kernel (NRK), and Fig Leaves as Minimal Test Case

### 16.1 Eden as Minimal Praxis Scene

Eden is not the paper’s origin. Eden is a test scene for the paper’s grammar. This distinction governs the whole reading. Eden is not used here to found the argument, supply a proof path, or provide a mythic origin for later mechanisms. It enters late because the grammar has already been built elsewhere. Its function is demonstrative: to show whether the paper can read a minimal praxis scene without moralization, diagnosis, or origin mythology.

The preceding chapters have already established Adult Reciprocity, real Ω (asymmetry), false coordination, displaced R (responsibility), blocked Σ (integration) / Ψ (self-binding), switch drift, responsibility drift, recognition drift, and possible regime stabilization. Eden now tests whether those relations can illuminate a compact scene in which boundary, exposure, consequence, and responsibility become structurally legible. The scene receives the grammar; it does not generate it.

The opening guardrail is therefore:

```text
Eden is not the paper’s origin.
Eden is a test scene for the paper’s grammar.
```

The same point can be stated more sharply:

```text
Eden is not foundation.
Eden is demonstration.
```

A minimal praxis scene is a scene in which the elementary conditions of praxis become legible without requiring a developed social regime. Eden functions here because it stages a small number of structural elements with unusual clarity: a frame, a boundary, a difference, an asymmetry, a possible action or non-action, an exposure shift, a consequence field, and a trace of responsibility. The scene is minimal not because its meaning is simple, but because it allows the grammar to be tested with few moving parts.

This does not make Eden a proof path. The paper does not claim that its theory follows from Eden, that Eden explains gender, or that Eden reveals the origin of reciprocity loss. Such readings would reverse the order of the argument. The theory does not derive itself from the scene. The scene tests whether the theory can describe a compact configuration of praxis, exposure, responsibility, and legibility without collapsing into moral blame.

The word “scene” is important. Eden is not treated here as universal history, literal anthropology, theological anthropology, or symbolic totalization. It is read as a scene-bound configuration. A scene-bound reading asks what becomes structurally visible within the configuration: which □ (frame) holds, which Δ (difference) matters, where Ω (asymmetry) is present, what boundary or option is meaningful, what consequence becomes active, and how R (responsibility) becomes traceable. The reading does not require the scene to carry the entire argument.

This also means that Eden is not used as a sex-truth machine. The reading does not infer fixed truths about women, men, desire, guilt, or human relations as such. It does not convert Adam, Eve, or any role-position into an essence. If the scene is useful, it is useful because it makes certain relations minimally visible: coordinated Ω (asymmetry), breach, exposure, legibility management, and responsibility trace. These relations must remain structural, not ontological.

Eden is also not introduced to restore a hidden chain in which the scene produces breach, breach produces comparison, comparison produces a downstream regime form, and that regime form produces reciprocity loss. Such a chain would make Eden the source and make downstream mechanisms appear as if they were already latent in the scene. The present argument requires the opposite order. The general grammar has already been built, and Postfeminist Override (PFO) has already been defined as downstream regime stabilization. Eden therefore cannot become the hidden origin of the paper.

The correct hierarchy is:

```text
Adult Reciprocity
→ false-coordinated real Ω
→ R / Σ / Ψ
→ drift mechanics
→ regime stabilization
→ Eden scene as minimal test case
```

The incorrect hierarchy is:

```text
Eden scene
→ derive everything
```

A minimal praxis scene does not need to contain a full regime. Eden does not yet contain the full Switch Family or the full tragedy of reciprocity loss. It shows something earlier and smaller: a relation can have coordinated Ω (asymmetry), a boundary can become meaningful, a breach can activate a consequence field, exposure can become newly legible, and responsibility can become traceable without becoming moral guilt.

The present reading therefore treats Eden structurally, not devotionally or polemically. A theological, mythic, symbolic, anthropological, or literary reading may be possible in adjacent frameworks, but the argument here does not depend on any of them. Its question is narrower: can the paper’s grammar read the scene without turning it into a moral tribunal, a gender blame story, a theological proof, or a universal account of human history?

This narrowness is what allows the Eden material to remain useful. Eden no longer explains the paper. The paper explains why Eden can be read as a minimal test scene. That reversal is not cosmetic. It protects the whole argument from returning to an origin story.

The first task is therefore to establish the ground state. Before breach, before exposure management, before responsibility contestation, the scene must not be imagined as pure symmetry. The ground state matters because it already contains difference and asymmetry. Its significance lies not in the absence of Ω (asymmetry), but in the coordination of Ω. The ground state is not symmetry; it is coordinated asymmetry.

### 16.2 Ground State: Coordinated Ω

The ground state is not symmetry. It is coordinated Ω (asymmetry). This matters because a false Eden reading would imagine the initial scene as the absence of difference, exposure, cost, role, or responsibility. The present argument does not require such an innocence myth. The ground state is not pure sameness. It is a relation in which real difference and asymmetry are present but not yet falsely coordinated.

The formula is:

```text
The ground state is not symmetry.
It is coordinated Ω.
```

In the ground state, Ω (asymmetry) is present without yet becoming rank, threat, immunity, total exposure, or responsibility displacement. Difference is real, but it is not yet organized as comparison. A boundary may be meaningful, but it is not yet primarily defensive. A role-position may stand in relation to another, but the relation is not yet governed by false parity, false subordination, false superiority, or exit from responsibility.

The coordinated structure can be stated compactly:

```text
Ω present but coordinated.
□ stable but not comparative.
Σ not yet represented as blocked.
Ψ not yet represented as displaced.
Χ not yet defensive.
Λ not yet structurally dominant.
Θ not yet erosion trajectory.
```

Ω (asymmetry) is present because the scene is not made of interchangeable positions. There is difference, exposure possibility, boundary, option, and the possibility that one role-position’s action or non-action may matter for another. But this Ω does not yet need to be denied, moralized, ranked, or neutralized through false equality. It is simply part of the scene’s real structure.

The □ (frame) is stable but not comparative. The scene has a frame: relations, boundaries, permissions, prohibitions, possibilities, and expectations are not formless. Yet the frame has not yet become a comparison machine. It does not yet organize difference as inferiority, superiority, competition, threat, or status anxiety. Difference can be present without becoming a ranking structure.

Within this reading, Σ (integration) is not yet represented as blocked. Difference, boundary, relation, exposure possibility, and responsibility can still be modeled together without one element excluding another.

Likewise, Ψ (self-binding) is not yet represented as displaced. This does not establish an intact inner state. It means only that the scene has not yet made refusal, externalization, or unequal self-binding load structurally legible.

Χ (distance) is not yet defensive. Distance may exist as boundary, distinction, or relation, but it has not yet become withdrawal, suspicion, protective separation, or interpretive defense. The ground state does not eliminate distance. It holds distance without making it the organizing answer to threat. This is why the ground state should not be romanticized as fusion. It is relation with coordinated difference, not relation without distinction.

Λ (non-event) is not yet structurally dominant. What does not happen may always matter in some minimal sense, but the ground state is not yet organized by a decisive non-event: a responsibility not carried, a correction not made, a boundary not honored, an effect not integrated. Λ has not yet become the central carrier of drift. It remains background possibility rather than dominant structure.

Θ (temporality) is not yet an erosion trajectory. Time is present because praxis always unfolds temporally, but the scene is not yet governed by delayed correction, accumulated exposure, deferred responsibility, or path-dependent drift. There is sequence, but not yet erosion. There is possibility, but not yet a trajectory of loss.

This is why the ground state must not be described as innocence in a moral or theological sense. The point is not that nothing consequential can happen, that no boundary matters, or that no responsibility is possible. The point is that difference, boundary, and asymmetry are still coordinated. The scene can contain meaningful structure without that structure having become false coordination.

The ground state also prevents the later breach from being misread as the arrival of difference itself. Difference is already there. Asymmetry is already there. Boundary is already there. The breach does not create structure from nothing. It changes the scene’s relation to the structure it already contains. What was coordinated becomes exposed differently; what was background becomes consequence-bearing; what was implicit becomes traceable.

This distinction is decisive. If the ground state were pure symmetry, then breach would have to explain the origin of asymmetry. If the ground state were pure innocence, then breach would have to explain the origin of responsibility. If the ground state were pure fusion, then breach would have to explain the origin of distance. The present argument avoids these origin myths. The scene already contains Ω (asymmetry), boundary, relation, and possibility. The breach changes their legibility and consequence.

The ground state is therefore neither paradise nostalgia nor moral innocence. It is coordinated Ω (asymmetry) before false coordination. It gives Eden its test value because it allows the paper to show a central claim in miniature: asymmetry is not the failure. False coordination of asymmetry is the failure.

The relevant question is therefore not, “How does knowledge begin?” It is, “How does a coordinated praxis relation become interrupted such that consequence, exposure, and responsibility become newly legible?” The breach is read not as knowledge gain, but as consequence activation.

### 16.3 Breach: Not Knowledge Gain

The breach should not be read as the moment when knowledge begins. It should not be read as the origin of humanity, guilt, sexuality, gender conflict, or moral consciousness. Those readings may belong to other theological, symbolic, or anthropological frameworks, but they are not the function of the scene in this paper. In the present argument, the breach matters because it interrupts a coordinated praxis relation and activates a consequence field.

The corrective formula is:

```text
not:
knowledge gained → humanity begins

but:
praxis relation interrupted
→ consequence field activated
→ Ω becomes differently legible
→ R becomes contested.
```

This reframing is necessary because the knowledge-gain reading makes the scene too large. If knowledge itself begins at the breach, Eden becomes an origin story for human consciousness. If guilt begins there, Eden becomes a moral tribunal. If sexed difference begins there, Eden becomes a gender-origin myth. The present argument requires a narrower reading. Difference, boundary, relation, and Ω (asymmetry) are already present in the ground state. The breach changes how they become legible and consequential.

The body is therefore not newly known. It is newly framed. The scene does not require the claim that embodied difference was absent before the breach or that sexed embodiment suddenly appears through knowledge. What changes is exposure: the body becomes readable under a changed Ω (asymmetry) condition. It becomes an object of management, concealment, and altered relation.

The body formula is:

```text
The body is not newly known.
It is newly framed as exposed under Ω.
```

This protects the reading from a shame-psychology reduction. The issue is not first an inner feeling of shame, nor a moral discovery of nakedness as guilt. The issue is the structural transformation of legibility. What was present but coordinated becomes present under exposure. What could be lived within the prior frame now appears as something that must be managed. The scene has changed not because a body appears, but because the body becomes framed as exposed.

The breach also changes the status of consequence. Before the breach, boundary, option, and responsibility are present as possible structure. After the breach, consequence becomes active. The scene is no longer only framed by a meaningful boundary; it now contains a responsibility-relevant interruption of that boundary. The breach therefore does not create praxis from nothing. It activates the traceability of praxis.

This is why the breach should not be moralized too quickly. To say that consequence becomes active is not to say that guilt has already been assigned. It is to say that the scene now contains a traceable relation between available legibility, meaningful boundary or option, action or non-action, and effect. R (responsibility) becomes possible to contest because the relation between breach and consequence becomes structurally visible.

The phrase “becomes possible to contest” matters. Responsibility is not totalized here. The breach does not by itself decide blame, guilt, essence, punishment, or moral worth. It creates a condition under which responsibility can become readable and disputed. What was previously coordinated as background relation becomes foregrounded as consequence. That is enough for the scene to become analytically useful without becoming a moral origin story.

The breach also changes the status of Ω (asymmetry). In the ground state, Ω was present but coordinated. After the breach, Ω becomes differently legible. Exposure, boundary, access, and consequence now appear under altered conditions. The scene does not yet need false comparison or a full regime. It needs only the minimal shift through which coordinated asymmetry becomes exposed asymmetry.

This is why Eden remains a minimal test case. The scene does not yet contain all later drift mechanisms. It tests whether the paper can read a compact transition: coordinated Ω (asymmetry) becomes newly exposed; consequence becomes active; R (responsibility) becomes contestable; and the scene begins to manage legibility. If the theory can read this without turning it into guilt-origin, sex-truth, or theology-primary explanation, the test succeeds.

The breach therefore marks a structural interruption of praxis relation. It is not the birth of knowledge. It is not the birth of shame. It is not the birth of sexed difference. It is the activation of consequence under conditions in which real Ω (asymmetry) becomes differently framed. In the field opened by this activation, Λ, Ω, and Θ become jointly relevant.

### 16.4 Activation of Λ/Ω/Θ

The breach activates a consequence field. This means that the scene can no longer be read only as a stable frame with coordinated difference. It must now be read as a field in which what happened, what did not happen, what became exposed, and what now unfolds across time acquire structural relevance. In PMS terms, Λ (non-event), Ω (asymmetry), and Θ (temporality) become jointly active.

Λ (non-event) becomes relevant because the scene is not structured only by what is done. It is also structured by what is not carried, not integrated, not maintained, not protected, or not kept within the prior coordination. This does not yet mean that every non-action is praxis. Chapter 11 already set that boundary. Here the point is minimal: once the breach occurs, absences, non-carryings, and failures of integration can become responsibility-relevant because they shape the consequence field.

Ω (asymmetry) becomes relevant because exposure is no longer merely possible; it is differently distributed and differently legible. The scene now contains a changed relation to body, boundary, access, and vulnerability. But this Ω is still not yet the whole tragedy of reciprocity loss. It is the activation of exposed asymmetry as a field condition. How the scene coordinates or fails to coordinate this exposure remains the decisive question.

Θ (temporality) becomes relevant because the breach creates sequence. A consequence field is not only a fact; it unfolds. What was interrupted must now be carried, concealed, repaired, denied, explained, or managed over time. The scene has moved from stable coordination into a trajectory. That trajectory need not yet be irreversible, but it introduces timing, delay, anticipation, and the possibility of erosion.

The field can be stated compactly:

```text
breach
→ consequence field
→ Λ / Ω / Θ activation
→ R becomes traceable and contested.
```

R (responsibility) becomes traceable because the scene now contains a relation between boundary, option, enactment or non-enactment, exposure, and consequence. It becomes contested because traceability does not automatically decide assignment. The scene may ask: who carried what, who failed to carry what, what was legible, what option mattered, what effect followed, and how exposure alters the responsibility relation. These are structural questions, not moral verdicts.

This activation should remain minimal. The reading does not repeat the full No Passive Praxis argument or the full Responsibility Principle. The Eden scene only tests whether those principles can read a small configuration. It shows that non-event, asymmetry, temporality, consequence, and responsibility can become structurally linked without turning that linkage into total blame.

The field also prepares the Fig Leaves. Once Ω (asymmetry) becomes newly exposed, the scene begins to manage how exposure is legible. That management is not yet a full regime, recognition drift, or responsibility drift in developed form. It is a minimal response to newly exposed asymmetry: something has become visible under altered conditions, and the scene attempts to manage that visibility.

This is why the activation of Λ (non-event), Ω (asymmetry), and Θ (temporality) matters. It shows that the breach is not a mere event inside an unchanged scene. It changes the field in which action, non-action, exposure, consequence, and responsibility can be read. The body becomes newly framed as exposed; the boundary becomes consequence-bearing; non-carrying becomes relevant; temporality opens a trajectory; R (responsibility) becomes traceable but not yet morally totalized.

Fig Leaves are the most visible marker of this shift. They should not be read first as shame psychology or moral symbolism, but as the scene’s minimal act of legibility management under newly exposed Ω (asymmetry).

### 16.5 Fig Leaves: Legibility Management

Fig Leaves are not read here primarily as shame psychology. They mark legibility management under newly exposed Ω (asymmetry). The scene has changed: the body is not newly known, but it is newly framed as exposed. Once exposure becomes legible under altered asymmetry conditions, the scene begins to manage how that exposure can appear.

The formula is:

```text
Fig Leaves = legibility management under newly exposed Ω.
```

This formulation does not deny that shame, embarrassment, fear, moral awareness, or symbolic self-consciousness may be relevant in other readings. It only fixes the function of Fig Leaves in this paper. They are not the origin of shame, not the proof of guilt, and not the psychological center of the scene. They are the minimal visible sign that legibility itself has become a problem.

Legibility management begins where a scene attempts to regulate how exposure can be seen. The exposed body is not merely a body; it has become framed under Ω (asymmetry). It can now be seen as vulnerable, available, separate, comparable, hidden, disclosed, or in need of management. Fig Leaves therefore do not create exposure. They respond to exposure that has become newly organized by the breach.

This response is structurally important because it shows that the scene is no longer simply coordinating difference. It is managing the visibility of difference after coordination has been interrupted. The body becomes an object of presentation and concealment. Relation becomes mediated by what can be shown and what must be covered. Visibility itself becomes a field of praxis.

The body formula remains decisive:

```text
The body is not newly known.
It is newly framed as exposed under Ω.
```

Fig Leaves should therefore not be treated as a merely private reaction. They are also not yet a social regime. They occupy a minimal middle position: exposure is newly legible, and the scene responds by managing legibility. This response does not yet require false comparison, full recognition drift, or a developed Switch Family. It is earlier and smaller. It shows how exposure management can begin before later regimes exist.

Nor should Fig Leaves be read as simple concealment. Concealment is part of the gesture, but the structural function is broader. To cover is also to mark what now needs covering. The attempt to reduce exposure confirms that exposure has become legible. The gesture manages visibility, but it also indicates that visibility has changed. Fig Leaves therefore both respond to and disclose the new field.

This is why Fig Leaves are not merely an object but a structural marker. They mark a shift from coordinated embodiment to managed exposure. Before the breach, difference could remain coordinated inside the ground state. After the breach, difference appears under altered legibility conditions. The scene now has to handle how embodiment is seen, how exposure is distributed, and how relation is affected by that visibility.

This does not mean that Fig Leaves already produce guilt. They make responsibility traceable in a limited way because they show that the scene has registered a change. Something now requires management. But that trace is not the same as moral guilt. It is a sign that exposure, boundary, and consequence have become active enough to elicit a response.

The gesture also introduces Χ (distance) in a new form. Earlier, distance was not yet defensive. With Fig Leaves, distance begins to appear as exposure management. Covering creates separation between body and gaze, between exposure and access, between what is present and what is made visible. This distance may be protective, but it is also reactive. The scene is no longer merely in coordinated relation; it is regulating relation through visibility.

Fig Leaves also clarify the relation between Λ (non-event) and exposure. What is covered is not erased. What is not shown may still structure the scene. Concealment can make the unshown newly relevant. A non-evental dimension appears: what is withheld from visibility, what is no longer simply available, what is now mediated by covering. This does not make every concealment a drift. It only shows that visibility and non-visibility have become structurally meaningful.

The temporality of the gesture matters as well. Θ (temporality) is active because Fig Leaves are not just a state; they are a response after breach and before later coordination. They belong to a sequence: coordinated Ω (asymmetry), breach, exposure, legibility management. This sequence introduces the possibility that exposure management may either be integrated, revised, stabilized, or later absorbed into broader drift. The reading does not decide that trajectory here; it only marks its minimal beginning.

This is why Fig Leaves should not be imported into regime logic. They are not PFO. They are not yet recognition-without-responsibility. They are not yet immunity. They are not yet pseudo-equal-standing. They are a minimal marker that the scene has begun to manage exposure under altered Ω (asymmetry). Later regimes may build on such legibility shifts, but the Fig Leaves themselves remain a smaller structural sign.

The risk of overreading is high. If Fig Leaves become shame psychology, the reading turns inward too quickly. If they become moral guilt, the reading becomes tribunal. If they become a full regime, the chronology collapses. If they become sex-truth, the scene becomes ontology. The disciplined reading is narrower: Fig Leaves show that newly exposed asymmetry requires legibility management before the scene has yet developed a full drift regime.

The connection to responsibility is therefore limited but important. Fig Leaves do not decide responsibility, but they show that the scene has entered a condition in which responsibility can become traceable. An exposure shift has occurred. A response has been made. Visibility has been managed. The relation between breach, consequence, body, distance, and non-visibility can now be read. This establishes the compact responsibility question addressed by the Negative Responsibility Kernel.

Fig Leaves therefore perform a test function inside the test scene. They test whether the paper can read concealment without reducing it to shame, guilt, manipulation, or regime stabilization. They show that legibility management can be structurally meaningful before it becomes morally totalized. The Negative Responsibility Kernel names the narrow responsibility trace that becomes visible here.

### 16.6 Negative Responsibility Kernel

The narrow responsibility trace that becomes visible in the Eden scene can be named the Negative Responsibility Kernel (NRK). The acronym must be handled carefully. NRK is not a PMS operator. It adds no axiom. It is a paper-internal shorthand for a compact responsibility configuration inside the Eden test scene.

The demotion must remain explicit:

```text
NRK is not a PMS operator.
NRK adds no axiom.
NRK is a paper-internal shorthand.
```

The term “negative” does not mean morally bad, guilty, inferior, or corrupt. It does not name a stain in the person. It names a responsibility trace that becomes legible where something was not carried, not integrated, not maintained, or not bound under conditions where a meaningful boundary or option was available. The negative dimension is structural: it concerns non-carrying under consequence, not moral negativity.

NRK can be stated compactly:

```text
NRK =
available legibility
+ meaningful boundary / option
+ consequential effect under Ω/Θ
+ enactment or non-enactment not carried by Σ/Ψ
+ responsibility trace.
```

The first element is available legibility. A responsibility trace cannot be formed where nothing could be read, no boundary could be recognized, no option mattered, and no effect could become visible. NRK therefore does not assign R (responsibility) from mere outcome. It requires that the scene contain some available legibility: a frame, boundary, option, or relation through which the consequence can become traceable.

The second element is a meaningful boundary or option. In Eden, the boundary matters because it gives the scene a structure in which action and non-action can become responsibility-relevant. A boundary is not automatically domination, prohibition, punishment, or moralism. In a minimal praxis scene, a boundary makes the difference between mere occurrence and consequence-bearing relation legible. It allows the scene to ask what was available, what was carried, and what was not carried.

The third element is consequential effect under Ω (asymmetry) and Θ (temporality). The breach matters because it changes how exposure, relation, and consequence unfold. Ω becomes differently legible; Θ gives the consequence a trajectory. NRK does not require a final judgment about guilt. It requires that an effect become traceable under asymmetry and time: something now follows, and that following changes the scene.

The fourth element is enactment or non-enactment not carried by Σ (integration) / Ψ (self-binding). The responsibility trace emerges where what happened, or what failed to be carried, does not become integrated and self-bound. The scene contains an effect, but the effect is not yet held in a way that restores coordination. This is where NRK touches the earlier grammar of No Passive Praxis without repeating it: non-action matters only where it structures a scene under legible conditions.

The fifth element is responsibility trace. NRK does not decide total responsibility. It does not assign guilt, essence, blame, or moral worth. It only marks that a trace has become available: a relation between legibility, boundary, option, consequence, and non-carrying can now be read. The trace is enough to make R (responsibility) contestable, but not enough to totalize the role-position.

NRK remains subordinate to the Responsibility Principle stated in Chapter 12:

```text
NRK is a special case of the Responsibility Principle,
not the general responsibility theory.
```

It names a compact responsibility trace without becoming a new operator, axiom, moral theory, or hidden center of the argument:

```text
NRK supports responsibility trace without moral guilt.
```

Fig Leaves prepare this trace by showing that exposure has become legible enough to elicit a response without deciding its moral meaning. NRK therefore names neither sin, shame, guilty essence, nor a diagnostic or application tool. Its function remains local and demonstrative; application elsewhere still requires scene analysis, counter-scene testing, Χ (distance), reversibility, and D (dignity-in-practice).

The compact payoff is this: NRK marks the point at which consequence becomes traceable without becoming a verdict. The scene has enough structure for responsibility to become readable, but not enough for responsibility to become total. A boundary mattered. An effect followed. Exposure changed. Something was not carried by Σ (integration) / Ψ (self-binding). A trace appears.

This is why NRK belongs in the Eden reading but must remain demoted. It helps the scene function as a minimal test case. It does not found EDEN. It does not modify PMS. It does not compete with the Responsibility Principle. It simply names the small kernel of traceable responsibility that becomes visible once coordinated Ω (asymmetry) is interrupted and exposure begins to require legibility management.

Eden thereby tests the paper’s grammar as a whole. It shows coordinated Ω (asymmetry), breach as consequence activation, Fig Leaves as legibility management, and NRK as responsibility trace. But it does so as demonstration, not foundation.

### 16.7 Eden as Minimal Test of the Paper’s Grammar

Eden now functions as a minimal test of the paper’s grammar. It does not found the theory; it tests whether the theory can read a compact praxis shift without importing moral origin, theological proof, sex truth, or regime logic too early. If the preceding grammar is sound, the Eden scene should be readable as a small configuration in which coordinated Ω (asymmetry), breach, consequence activation, legibility management, and responsibility trace become visible without becoming a total explanation of later history.

The test can be stated as a set of questions. Can Ω (asymmetry) be present without being falsely coordinated? Can a breach activate consequence without being read as the birth of knowledge or guilt? Can R (responsibility) become traceable without becoming moral totalization? Can exposure become newly legible without becoming shame psychology? Can concealment manage visibility without already becoming a full regime? Can Λ (non-event), Ω, and Θ (temporality) become active without turning the scene into a full regime?

These questions show why Eden appears only here. The preceding chapters built the grammar needed to ask them: Adult Reciprocity, coordinated and false-coordinated Ω (asymmetry), the Responsibility Principle, No Passive Praxis, switch drift, responsibility drift, recognition drift, and downstream regime stabilization. Eden does not supply these concepts. It receives them. It is a scene on which the already-developed grammar is tested.

The local result is compact:

```text
Eden is a minimal test case,
not the explanatory origin of all later gender dynamics.
```

Eden tests whether real Ω (asymmetry) can be coordinated before it becomes falsely coordinated. The ground state showed that asymmetry need not be failure. Difference, boundary, exposure possibility, and role relation can be present without ranking, threat, immunity, responsibility displacement, or false parity. This confirms a core claim of the paper in miniature: asymmetry is not the failure; false coordination of asymmetry is the failure.

Eden also tests whether breach can activate consequence without creating a moral origin story. The breach matters because it interrupts praxis relation and changes the field in which consequence, exposure, and responsibility can be read. It does not need to produce knowledge from nothing. It does not need to create embodiment. It does not need to explain human guilt. It only needs to make a consequence field active.

Eden tests whether exposure can become newly legible without becoming psychological essence. Fig Leaves show that the body is not newly known, but newly framed as exposed under Ω (asymmetry). The gesture of covering marks legibility management. It shows that the scene has begun to regulate visibility after the breach. But it does not establish shame as the primary theory, guilt as the primary explanation, or concealment as a regime.

Eden also tests whether responsibility trace can appear without verdict. The Negative Responsibility Kernel (NRK) marks a compact relation between available legibility, meaningful boundary or option, consequential effect under Ω (asymmetry) and Θ (temporality), enactment or non-enactment not carried by Σ (integration) / Ψ (self-binding), and responsibility trace. This trace makes R (responsibility) contestable, but not total. It supports responsibility without moral guilt.

Finally, Eden tests whether a scene can remain analytically small. It contains enough structure to show praxis, consequence, exposure, and responsibility trace. It does not contain enough to explain later reciprocity loss, recognition drift, regime stabilization, or sexed social order. That limitation is not a weakness. It is the point of the test. A minimal scene should illuminate the grammar without replacing the argument.

The test therefore succeeds only if Eden remains subordinate. The scene helps demonstrate that the paper can read a minimal interruption of coordinated Ω (asymmetry). It does not authorize a return to Eden-first argument or let the paper derive Adult Reciprocity, regime stabilization, or reciprocity loss from the scene. It shows that the grammar works at small scale.

The placement of Eden after the regime analysis prevents the scene from being mistaken for the origin of regime stabilization. Eden contains no need for such stabilization. The order protects the theory: Eden can demonstrate without founding.

The chapter’s result is therefore modest but important. Eden shows coordinated Ω (asymmetry), breach as consequence activation, Λ (non-event) / Ω / Θ (temporality) field formation, Fig Leaves as legibility management, and NRK as responsibility trace. It demonstrates that a non-moral structural reading can preserve the force of the scene without turning it into origin myth, guilt theory, sex truth, or verdict.

### 16.8 Non-Moral Reading and Boundary

The Eden reading must close with a boundary. The scene is not being used to explain human guilt, female guilt, male guilt, sexual shame, gender conflict, postfeminist order, or the origin of reciprocity loss. It is not a moral tribunal. It is not a theology-primary proof path. It is not an anthropology of the sexes. It is a minimal praxis scene read under the grammar already developed in the preceding chapters.

The boundary can be stated directly:

```text
Eden supports the paper’s discipline.
It does not replace the paper’s architecture.
```

A non-moral reading does not mean that moral, theological, or symbolic readings are invalid in their own domains. It means that this paper does not need them as its explanatory foundation. The Eden scene can be read structurally: coordinated Ω (asymmetry), breach, consequence field, exposure shift, legibility management, responsibility trace. That is enough for the function of the scene.

The first boundary is against knowledge-origin. The breach is not treated as the birth of knowledge. The body is not newly known. Difference is not created by the breach. The scene is not valuable because it explains how humans become conscious. Its value lies in showing how a coordinated relation can become interrupted such that consequence, exposure, and R (responsibility) become newly traceable.

The second boundary is against guilt-origin. NRK does not name original guilt. It does not say that a role-position becomes morally stained. It does not attach guilt to sex, personhood, embodiment, or desire. It supports responsibility trace without moral guilt. That trace is structural: a meaningful boundary or option, a consequence field, enactment or non-enactment, and non-carrying under Σ (integration) / Ψ (self-binding).

The third boundary is against sex-truth. The scene does not say what follows essentially from sexed identity or sexed embodiment. Adam and Eve, if referenced as role-positions, do not function as ontological claims about male and female essence. The chapter reads the scene through structural relations: boundary, exposure, asymmetry, consequence, legibility, and responsibility.

The fourth boundary is against regime-import. Eden does not already contain PFO. It does not already contain the full Switch Family. It does not already contain recognition-without-responsibility, pseudo-equal-standing, or reciprocity loss as tragedy. Later drift mechanisms may become more intelligible after Eden is tested, but they are not derived from Eden. The scene shows minimal activation, not full stabilization.

The fifth boundary is against application. The Eden reading does not authorize the use of Eden as a template for diagnosing persons, couples, sexes, institutions, or modern scenes. It does not support application by mythic resemblance. It does not allow one to say that a scene is “Edenic” and therefore already understood. Application belongs to EDEN-MAP and requires scene packet, counter-scene testing, Χ (distance), reversibility, and D (dignity-in-practice).

The sixth boundary is against theological dependency. The paper may be compatible with theological, literary, mythic, or symbolic readings, but it does not depend on them. Adjacent frameworks can be discussed elsewhere. The scene is used here as a minimal structural configuration, not as doctrinal authority. Its claim is analytic: the scene can test the grammar.

The positive reading is therefore:

```text
coordinated Ω
→ breach as consequence activation
→ Λ/Ω/Θ field formation
→ legibility management
→ responsibility trace
```

This reading remains subordinate to the paper’s central thesis:

```text
Adult Reciprocity is truthful coordination of real Ω.
Reciprocity Loss begins where real Ω is falsely coordinated.
```

Eden supports this thesis by showing a minimal scene in which Ω (asymmetry) is first coordinated, then exposed differently through breach and consequence activation. It does not complete the story of reciprocity loss. It shows why the distinction between asymmetry and false coordination matters.

The final discipline is therefore simple. Eden may demonstrate. It may not found. It may clarify. It may not totalize. It may test. It may not replace. If Eden becomes the hidden origin again, the reading fails. If Eden remains a minimal test scene subordinate to the paper’s grammar, the material is preserved without restoring an origin structure.

The following chapter can now name the larger loss. The Eden scene has shown how a minimal scene can move from coordinated Ω (asymmetry) into consequence activation, exposure management, and responsibility trace. Reciprocity Loss as Tragedy will develop the loss of adult relational possibility under false-coordinated real Ω: not as the triumph of one side, not as the exposure of one culprit, and not as the moral of Eden, but as the tragedy of shared correctability becoming unavailable.

---

## 17. Reciprocity Loss as Tragedy

### 17.1 Definition

A traceable breach is not yet reciprocity loss. Neither are consequence, exposure, disagreement, unequal burden, or responsibility by themselves. Reciprocity loss begins only when real Ω (asymmetry) continues to structure a relation while the channels through which that asymmetry could be truthfully coordinated become unavailable.

Its full structure is:

```text
Reciprocity Loss =
real Ω remains
+ R displaced
+ Σ blocked
+ Ψ weakened / externalized
+ Χ reduced
+ D damaged
+ correctability lost
```

This formulation is an EDEN theoretical compression, not a formally derived PMS axis, an empirically established developmental sequence, or a prevalence claim. It does not entail that every damaged relation contains every listed element or follows a single trajectory. Whether reciprocity loss is present in a particular scene remains a descriptive hypothesis requiring evidence, counter-scene exposure, and defeat conditions.

Real Ω (asymmetry) remains because differences in capacity, exposure, obligation, protection, dependency, timing, access, or consequence do not disappear merely because a relation cannot name them. They continue to shape what each role-position can do, what it must carry, what it may avoid, and what costs follow from its enactments or non-enactments. Reciprocity loss is therefore not the disappearance of structure. It is the persistence of structure without adequate coordination.

R (responsibility) becomes displaced when responsibility no longer follows real structuring effect. A role-position may remain consequential while its effect is discounted, protected, reframed, or assigned elsewhere. Another position may become answerable for costs it did not fully generate, for integration it cannot produce alone, or for consequences whose conditions it cannot legitimately name. Responsibility has not vanished. Its relation to effect has become distorted.

Σ (integration) is blocked when the relation can no longer receive its own asymmetry, costs, effects, and responsibilities into a coherent praxis relation. The relevant structure may remain visible in fragments, but those fragments cannot be held together without denial, rank, threat, humiliation, or premature closure. Surface coherence may remain. Actual integration does not.

Ψ (self-binding) is weakened or externalized when relevant actors are no longer durably bound to their own structuring effects. Binding may instead be demanded from the other role-position: the other must wait, explain, absorb, protect, repair, remain available, or carry the unresolved remainder. Low Ψ on one side can thereby increase the Ψ-load on the other without producing mutual coordination.

Χ (distance) is reduced when the relation loses the reflective space required for revision. Critique becomes difficult to receive without fusion, retaliation, withdrawal, or frame reversal. A claim about structure is heard as a total claim about personhood; a request for responsibility is heard as domination; an attempt to name asymmetry is treated as an attack on equality or dignity. The relation becomes less able to examine its own organization without reproducing the very threat it is trying to examine.

D (dignity-in-practice) is damaged when asymmetry can no longer be handled through self-bound restraint and protection of standing. One role-position may be devalued, overexposed, reduced to danger, or denied legitimate vulnerability. Another may be protected from criticizability in ways that diminish its full adult agency. In both cases, dignity-in-practice is lost through the handling of asymmetry, not through any judgment about ontological worth.

The final term, correctability lost, names the cumulative result. Correctability is the relational capacity to receive, test, and integrate correction while keeping responsibility connected to real effect and preserving dignity-in-practice. It does not require agreement. It does not require the absence of conflict. It does not require equal capacities, equal burdens, or symmetrical positions. It requires that the relation remain capable of recognizing when its coordination has become false and of allowing that recognition to matter.

Reciprocity loss is not merely conflict. It is the erosion of shared correctability under real asymmetry.

Conflict can remain compatible with reciprocity. A reciprocal relation may contain serious disagreement, painful criticism, unequal obligations, uneven exposure, or irreducible differences in capacity. Conflict may even be necessary where real effects have been denied or costs have been displaced. What matters is whether the conflict can still enter a shared field of responsibility, integration, self-binding, revision, and dignity-preserving correction.

Nor is reciprocity loss identical with inequality. Unequal capacities, protections, dependencies, or responsibilities may be real and functionally relevant. Treating their mere presence as failure would collapse Adult Reciprocity back into symmetry. The decisive question is not whether Ω exists, but whether it can be truthfully coordinated.

```text
Adult Reciprocity ≠ symmetry.
Adult Reciprocity = truthful coordination of real Ω.
Reciprocity Loss = false coordination of real Ω.
```

Adult Reciprocity can survive difference, conflict, critique, and unequal burdens where real Ω remains visible, R follows real structuring effect, Σ can integrate costs and consequences, relevant role-positions remain self-bound through Ψ to their own effects, Χ preserves the possibility of revision, and D remains protected. Asymmetry is not the failure. False coordination of asymmetry is the failure.

False coordination does not mean that every participant must explicitly deny the structure. A relation may acknowledge some differences while making their consequences unspeakable. It may recognize vulnerability while obscuring effect, affirm equality while displacing responsibility, or preserve protection while blocking criticizability. It may allow asymmetry to operate in practice while refusing the language needed to coordinate it. The falsehood lies in the mismatch between the structure that organizes the scene and the frame through which responsibility, recognition, protection, and cost are distributed.

The compact relation is:

```text
real Ω
+ false coordination frame
+ displaced R
+ blocked Σ/Ψ
= false-coordinated real Ω
```

Reciprocity loss begins when correction itself becomes illegible, unsafe, one-sided, humiliating, immunized, or impossible. In that condition, the configuration ceases to be locally correctable. The relation can no longer reliably name the asymmetry it enacts, carry the costs it generates, assign responsibility according to effect, integrate criticism, or bind relevant actors to the consequences of their own praxis.

This erosion may begin before overt conflict. Non-action can shift timing, exposure, or decision costs where it structures the scene under □ (frame), Λ (non-event), Ω, and Θ (temporality). Non-binding can relocate waiting, explanation, protection, or repair burdens. Legitimation can stabilize a frame in which those shifts appear neutral or necessary. Under-explained adaptive steering can preserve immediate coordination while weakening the shared language through which that coordination could later be questioned. None of these elements constitutes reciprocity loss by itself. They contribute where they displace responsibility, block integration or self-binding, and erode the relation’s capacity for correction.

Postfeminist Override (PFO) is not the origin of reciprocity loss. PFO is one regime form in which reciprocity loss stabilizes. It does not exhaust the phenomenon. Reciprocity can be damaged without that regime, and the loss can stabilize through other combinations of silence, devaluation, protection, overexposure, non-binding, role-hardening, or blocked criticism. PFO matters here only as one possible stabilization of a more general structural loss.

The result is neither the triumph of one role-position nor proof that all positions lose in the same way. Reciprocity loss concerns the destruction of a shared relational capacity, but its costs may be distributed asymmetrically. One position may retain protection while losing full criticizability and adult agency. Another may carry greater responsibility, exposure, explanation burden, or dignity cost. Shared loss does not imply equal loss. Bidirectionality is not symmetry.

The tragic structure lies precisely here. Real asymmetry continues to generate effects, obligations, vulnerabilities, and costs, but the relation loses the means to coordinate them without denial, displacement, immunity, overexposure, or degradation. Responsibility remains possible without malice. Harm remains real without requiring a simplified villain. The loss is structural without becoming morally neutral.

The definition can therefore be compressed into one sequence:

```text
coordinated Ω
→ false-coordinated real Ω
→ displaced R
→ blocked Σ/Ψ
→ reciprocity loss
```

This sequence names the result, but not yet the full path by which it forms. That path is neither a strict chronology nor a single-origin chain. The collapse sequence is a structural trace whose elements can overlap, loop, and stabilize one another.

### 17.2 Collapse Sequence

The definition of reciprocity loss identifies a structural result. One possible path into that result can be represented by the following non-mandatory trace:

```text
limited legibility
→ comparison susceptibility
→ false comparison
→ inferiority/superiority misframing
→ false-coordinated real Ω
→ switch drift
→ displaced R
→ blocked Σ/Ψ
→ reciprocity loss
```

This is neither a strict chronology nor a universally required chain. Its elements may overlap, loop, stabilize one another, arise in another order, or remain absent from a particular scene. False Comparison remains an attractor, amplifier, and stabilizer rather than a necessary first cause.

Its first term, limited legibility, is not itself a failure of reciprocity. Human actors do not enter scenes with complete access to every relevant cost, history, exposure, dependency, obligation, or structuring effect. Real Ω (asymmetry) may organize a scene before the available language can adequately name it. Responsibilities may be active before their distribution becomes conceptually clear. Costs may be carried before they can be recognized as costs.

Limited legibility is therefore neither innocence nor guilt. It describes the condition under which coordination must occur without total knowledge. Reciprocity remains possible under that condition. It can become more difficult where real Ω (asymmetry) recurs across Θ (temporality) and begins to stabilize as Α (attractor), while relevant concepts remain missing, costs remain opaque, recognition remains uncertain, responsibility pressure increases, and Ψ (self-binding) is weak or externalized.

The resulting condition is comparison susceptibility:

```text
limited legibility
+ real Ω recurring across Θ
+ Α (attractor) stabilization
+ missing concepts
+ recognition need
+ responsibility pressure
+ cost opacity
+ weak or externalized Ψ
→ comparison susceptibility
```

Comparison susceptibility is not yet false comparison. It names a scene in which comparison becomes more readily available than direct coordination. Actors need orientation: who carries which burden, who is protected, who is exposed, who may refuse, who must explain, whose effect is consequential, and whose responsibility can be named. Comparison can help answer such questions. It can clarify differences in capacity, cost, exposure, or obligation and thereby support coordination.

The drift begins when comparison ceases to serve that coordination and starts replacing it. Instead of asking what a real asymmetry requires from the relevant role-positions, the scene begins asking who stands higher or lower, who is more valuable, more mature, more credible, more vulnerable, more dangerous, or more deserving of protection. A praxis relation becomes reorganized as a value relation.

False Comparison is therefore not a first cause. It is an attractor, amplifier, and stabilizer. It attracts scenes that lack sufficient language for their own asymmetries. It amplifies partial differences into broader evaluative claims. It stabilizes those claims by making rank appear more legible than responsibility, cost, or self-binding. The comparison supplies apparent orientation, but it does so by displacing the structure that required coordination.

This displacement generates rank artifacts. A real difference in capacity, performance, vulnerability, protection, exposure, or responsibility may be converted into Inferiority Misframing or Superiority Misframing. The artifact does not require the underlying difference to be unreal. It arises when a bounded difference is generalized into a claim about overall standing.

Inferiority Misframing converts a local limitation, burden, dependence, injury, or reduced capacity into generalized lower standing. Superiority Misframing converts local competence, protection, authority, resilience, moral credibility, or responsibility into generalized higher standing. In either case, the rank claim exceeds the structure from which it arose.

The two misframings can reinforce one another without becoming symmetrical. A role-position framed as inferior may receive protection while losing criticizability or adult agency. A role-position framed as superior may receive authority while carrying increased responsibility, exposure, or integration burden. The same rank frame can therefore distribute different forms of loss across different positions.

Rank artifacts matter because they reorganize how real Ω is coordinated. Once a local difference has become a generalized value relation, responsibility no longer follows structuring effect with sufficient precision. Critique access changes. Protection may attach to attributed standing rather than actual vulnerability. Exposure may attach to attributed strength rather than available capacity. Recognition, obligation, and self-binding begin to follow the artifact rather than the scene.

At this point, real asymmetry has not disappeared. It has become falsely coordinated:

```text
real Ω
+ false coordination frame
+ displaced R
+ blocked Σ/Ψ
= false-coordinated real Ω
```

False-coordinated real Ω is the central hinge of the collapse trace. Before this point, partial legibility and comparison susceptibility may still be corrected through more accurate naming, differentiated responsibility, and functional comparison. Once the false frame begins organizing responsibility, integration, and self-binding, the relation no longer merely misunderstands an isolated feature. It coordinates its actual asymmetry through a frame that systematically mislocates effect, burden, protection, and answerability.

This false coordination enables switch drift. A scene may move between parity and asymmetry, autonomy and dependence, protection and responsibility, vulnerability and authority, participation and exit. Such movement is not inherently false. Real scenes require changing responses to capacity, exposure, danger, obligation, and timing. A valid switch remains bounded, legible, answerable to its effects, and capable of re-entering shared coordination.

Switch drift occurs when the available frame changes selectively while the underlying cost and responsibility structure remains unintegrated. Parity may become available when responsibility becomes costly. Vulnerability may become available when criticizability approaches. Protection may become immunity. Responsibility may become authority. Local competence may become generalized superiority. Formal equality may become exit from unequal cost. The issue is not movement between frames as such. It is movement that preserves displaced R (responsibility), blocked Σ (integration), or shifted Ψ (self-binding).

The trace places displaced R after switch drift to show how such movement can consolidate responsibility distortion. It does not imply that responsibility displacement first appears only at that point. R may already be partially displaced under limited legibility, false comparison, or rank misframing. Switch drift makes that displacement more repeatable by allowing responsibility to be rerouted whenever one frame becomes difficult to sustain.

The same qualification applies to blocked Σ/Ψ. Integration and self-binding may weaken throughout the trace. Missing concepts already make integration harder. False Comparison already substitutes rank for coordination. Misframing already binds recognition and responsibility to artifacts. Switch drift further blocks consolidation by repeatedly changing the terms under which costs and effects could enter a shared frame.

The later position of blocked Σ/Ψ therefore marks deepening structural consolidation, not a single moment of onset. Σ is blocked when the relation cannot integrate real asymmetry, cost, responsibility, exposure, and consequence without reverting to the false frame. Ψ is weakened or externalized when relevant role-positions are not durably bound to their own effects and the resulting binding load is shifted elsewhere.

Several feedback movements can then occur. Blocked integration increases the need for orientation, which can intensify comparison susceptibility. Rank misframing can make real Ω less legible, which deepens dependence on the rank frame. Switch drift can protect the false coordination from correction. Displaced responsibility can increase non-binding, while non-binding shifts further costs onto the position already carrying integration. The elements do not merely follow one another. They can reproduce the conditions that keep one another active.

This is also why no single element explains reciprocity loss by itself. Limited legibility does not necessarily produce false comparison. Comparison does not necessarily produce rank artifacts. Misframing does not necessarily become durable false coordination. Switches can remain functional. Responsibility can be reattached. Integration and self-binding can reopen. At every stage, alternative developments remain structurally possible.

Nor must every scene contain every element with equal strength. Some scenes may move quickly from missing concepts into responsibility displacement without pronounced rank language. Others may stabilize around false comparison without developing a full regime. Some may involve blocked self-binding more strongly than blocked integration. Others may preserve surface integration while excluding the costs that would make that integration truthful. The trace identifies a family of mutually reinforcing structural movements, not a mandatory script.

PFO can make parts of this trace repeatedly available by stabilizing a regime in which real Ω remains operative while its legibility, responsibility implications, or cost distribution are selectively blocked. It remains one downstream stabilization form. It is not a necessary stage, the origin of the trace, or an exhaustive account of reciprocity loss.

Pseudo-Symmetry likewise does not govern the whole sequence. It can describe a surface on which parity is asserted while real asymmetry continues to structure effects. But reciprocity loss can involve other false coordination frames, including rank, protection, vulnerability, authority, autonomy, neutrality, or necessity. No single rhetorical surface functions as the master mechanism.

The trace is not a fall narrative. It does not begin from Eden, and the Eden scene does not occupy a causal position within it. Eden demonstrated that coordinated Ω can be interrupted without supplying the origin of later comparison, misframing, regime stabilization, or reciprocity loss. The collapse sequence stands on its own structural terms.

Within this possible trace, the cumulative claim can be stated as follows:

```text
Reciprocity loss may become more durable through the interaction of
limited legibility,
false comparison,
misframing,
false coordination,
responsibility displacement,
and blocked integration / self-binding.
```

These elements are neither universally necessary nor jointly sufficient in every scene. Their cumulative relevance lies in the loss of several correction channels at once: legibility narrows, comparison may redirect orientation into value, misframing may convert difference into rank, false coordination displaces responsibility, and blocked Σ/Ψ prevents correction from reopening the relation.

The result is reciprocity loss because the relation no longer has reliable access to its own structuring conditions. Real Ω continues to operate, but the actors cannot truthfully coordinate what it does. Costs remain active but become difficult to attribute. Protection and exposure become difficult to distinguish from immunity and overloading. Critique becomes difficult to separate from threat. Responsibility becomes difficult to separate from guilt, domination, authority, or burden transfer.

This is the transition from structural collapse to loss of orientation. The trace does not only damage coordination from the outside. It changes what the scene can know about itself. Once real Ω is falsely coordinated and Σ/Ψ are blocked, actors lose stable access to what protection, responsibility, equality, agency, silence, and correction mean within the relation.

### 17.3 Loss of Orientation

Once real Ω (asymmetry) is falsely coordinated, the relation does not merely acquire an inaccurate account of itself. It begins to lose stable access to what its own structures mean. Protection, responsibility, equality, agency, critique, silence, and withdrawal remain available as words and practices, but their relational significance becomes uncertain.

The compact structure is:

```text
unclear Ω
+ blocked Σ
+ displaced R
→ orientation failure
```

Unclear Ω does not mean that asymmetry is absent. It means that the operative differences in capacity, exposure, protection, obligation, timing, dependency, or consequence cannot be named with sufficient precision. The scene still responds to those differences, but it does so indirectly. Actors adjust, protect, withdraw, compensate, wait, explain, control, or absorb costs without a shared account of what makes those responses necessary.

Blocked Σ (integration) prevents these fragments from entering a coherent praxis relation. A burden may be recognized without its source being integrated. Vulnerability may be acknowledged while its structuring effects remain outside responsibility. Protection may be offered without clarifying whether it preserves agency or blocks criticizability. Costs may be felt while the frame continues to deny the asymmetry through which they are distributed.

Displaced R (responsibility) further destabilizes orientation because effect and answerability no longer align. A role-position may be made responsible for holding the scene together while lacking legitimate language for naming what it carries. Another may retain consequential influence while remaining legible primarily as vulnerable, autonomous, passive, protective, or non-involved. The scene then contains not only disagreement about responsibility but instability in what responsibility can legitimately mean and where it can attach.

The resulting loss can appear as a series of practical ambiguities:

```text
protection becomes unclear
responsibility becomes unclear
critique becomes risky
recognition becomes conditional
silence becomes ambiguous
repair becomes unavailable
cost becomes unspeakable
agency becomes misread
```

Protection becomes unclear because the scene cannot reliably distinguish protection that preserves agency from protection that shields effect from criticizability. Responsibility becomes unclear because answerability may appear as blame, domination, control, or moral condemnation. Critique becomes risky because naming a structure may be recoded as an attack on vulnerability, equality, recognition, or personhood.

Recognition becomes conditional where a role-position must accept a false account of the scene in order to remain recognizable as legitimate, caring, autonomous, responsible, or safe. Silence becomes ambiguous because it may signify restraint, uncertainty, incapacity, withdrawal, refusal, non-binding, fear, or strategic non-participation. Without adequate scene conditions, neither speech nor silence carries a stable meaning.

Repair becomes unavailable before any explicit repair attempt has necessarily failed. If the scene cannot agree on what happened structurally, which asymmetry mattered, whose effect shaped the outcome, or which cost remains unintegrated, then even sincere attempts at correction may reproduce the same confusion. The relation may possess willingness without legibility, explanation without integration, or recognition without responsibility.

Cost becomes unspeakable where naming a burden threatens the frame through which the scene remains coherent. A position may be able to carry a cost only so long as it does not describe that cost as structurally distributed. Once named, the burden may be reframed as weakness, resentment, entitlement, control, ingratitude, avoidance, or lack of care. The scene thereby preserves its account of itself by making the cost-carrier less credible.

Agency becomes misread in both directions. A consequential role-position may be read as passive because its structuring effect occurs through silence, delay, non-binding, protection, withdrawal, or legitimation. Another may be read as fully agentic because its efforts are more visible, even where much of that activity is adaptive steering under conditions it did not establish. Visibility of action and degree of structuring power can therefore diverge.

This is why orientation loss should not be psychologized:

```text
Disorientation is not stupidity.
It is a structural effect of blocked Σ/Ψ under real Ω.
```

A role-position may understand many local features of the scene and still lack a legitimate, shareable account of how those features fit together. It may recognize that something is costly without being able to identify the responsibility structure. It may know that a response is necessary without being able to make the necessity mutually coordinable. It may speak accurately about one effect while remaining unable to place that effect within the larger asymmetry.

Limited legibility becomes more damaging where the relation loses shared means to name and coordinate its own costs. When structure cannot be named, it does not disappear. It is carried affectively, morally, relationally, or bodily. Irritation may carry unarticulated cost. Resentment may carry displaced responsibility. Withdrawal may carry failed protection. Overcontrol may carry integration pressure. Silence may carry exposure risk. Moralization may carry the absence of a workable structural vocabulary.

Under these conditions, substitute forms of orientation may become structurally available:

```text
comparison
status
protection
moralization
exit
control
silence
withdrawal
role-hardening
blame
```

These responses are not inherently drifted. Comparison can clarify a real distribution. Protection can answer genuine vulnerability. Exit can preserve distance or dignity-in-practice. Control can be necessary within bounded responsibility. Silence can be restraint. Withdrawal can prevent escalation. Roles can provide legitimate coordination, and blame may sometimes accompany real wrongdoing.

Their compensatory function becomes relevant when they replace access to the structure rather than responding to it. Comparison supplies rank where responsibility remains unclear. Status supplies standing where recognition is unstable. Protection supplies exemption where criticizability cannot be coordinated. Moralization supplies certainty where integration has failed. Exit removes a role-position from an unmanageable field while leaving the cost of departure unintegrated. Control supplies local order where shared self-binding is unavailable.

These compensations can harden the frame. The more they organize the scene, the more costly it becomes to question whether they still fit. Protection must continue to appear necessary. Control must continue to appear responsible. Silence must continue to appear neutral or prudent. Exit must continue to appear costless. The compensatory response begins to determine which descriptions remain legitimate.

Asymmetric Explanatory Poverty intensifies this orientation loss where one role-position carries high exposure and responsibility load while lacking legitimate language for describing how that load is produced. The position may be highly available to scrutiny but poorly equipped to distinguish real responsibility from overassignment. Its attempt to name the distribution may itself be recoded as threat, evasion, self-pity, control, or refusal of accountability.

This language condition creates a particularly severe orientation problem. The role-position must explain the scene through terms that already misdescribe its place within it. If it speaks, its account may increase exposure. If it remains silent, silence may confirm suspicion, indifference, or non-binding. The problem is not a lack of intelligence or articulation. It is the asymmetrical availability of legitimate description.

Orientation loss is relational rather than a psychological diagnosis. It concerns what the scene makes available to participants for naming, contesting, and integrating the structure they jointly inhabit. Confusion, dissatisfaction, resentment, avoidance, overcontrol, silence, or moral urgency may enter the analysis only where independently evidenced as scene data. None of these appearances identifies a deficient person or a defective sex. The structural claim is limited to possible failure in the relation’s means of orientation.

The loss also distributes an additional burden: someone must still navigate the scene. Where shared orientation declines, one or more role-positions must compensate by interpreting ambiguity, anticipating reactions, maintaining continuity, translating unrecognized costs, or deciding without adequate coordination. Orientation failure therefore leads directly into cost distribution.

### 17.4 Cost Distribution

Reciprocity loss does not affect all positions in the same way. It redistributes costs through visibility, protection, exposure, explanation burden, criticizability, and binding load.

The principal cost vectors include:

```text
visibility cost
explanation cost
reaction cost
waiting cost
binding cost
protection cost
speech cost
repair cost
dignity cost
exposure cost
recognition cost
legibility cost
Χ cost
option loss
```

These vectors do not rank suffering or allocate moral standing. They identify where the work of carrying a falsely coordinated scene accumulates. Option loss concerns the alternatives that disappear under delay, dependency, or stabilized drift.

Visibility cost concerns who becomes available to scrutiny and who remains comparatively opaque. A highly visible role-position may have its speech, motives, reactions, omissions, and vulnerabilities interpreted as structurally consequential before the scene has adequately traced their effects. A less visible position may still shape the scene, but its influence may appear indirect, private, passive, protected, or non-causal.

Explanation cost concerns who must make the structure intelligible. One role-position may be required to explain what happened, why it matters, why its response is proportionate, and why naming the burden is not itself a threat. Another may be allowed to remain uncertain, silent, affectively legible without structural explanation, or protected from the demand to account for its effects.

Reaction cost concerns who must regulate not only an initial event but also the consequences of responding to it. A position may bear a real burden and still become responsible for ensuring that its objection remains calm, non-threatening, recognizable, and easy to receive. The reaction becomes more criticizable than the structure to which it responds.

Waiting cost accumulates where timing remains controlled by non-decision, uncertainty, delayed commitment, withdrawal, or unresolved exception. The position that can remain unbound may experience the scene as open. The position that must preserve continuity carries the duration of that openness as obligation, anticipation, suspended action, or accumulating exposure.

Binding cost concerns the unequal distribution of Ψ (self-binding). Where one side does not remain bound to its own structuring effect, another may have to absorb more interpretation, continuity, restraint, explanation, anticipation, or repair:

```text
low Ψ on one side
→ increased Ψ-load on the other.
```

This shift may remain hidden because the additional binding appears voluntary, caring, mature, responsible, or simply necessary. Yet the relation becomes less reciprocal where one position’s flexibility depends on another position carrying the stability that flexibility leaves unresolved.

Protection cost has more than one direction. A protected position may lose criticizability or full recognition as an adult agent. The protecting position may carry increased responsibility, risk, restraint, vigilance, or exposure. Protection may therefore be necessary and costly without being false. Drift begins where its costs and effects cannot be named, bounded, or integrated.

Speech cost concerns who can describe the scene without losing standing. Some descriptions may be recognized as testimony, vulnerability, or legitimate self-account. Others may be heard as domination, threat, complaint, weakness, hostility, or evasion. Where access to legitimate speech is uneven, the ability to name cost becomes part of the cost distribution itself.

Repair cost concerns who must reopen communication, supply language, restore continuity, reduce threat, integrate competing accounts, or make correction possible after a rupture. A position that did not generate the full structure may nevertheless become responsible for making the structure workable again. Repair then becomes another site at which displaced R (responsibility) and shifted Ψ can consolidate.

Dignity cost concerns the loss of standing-in-practice through overexposure, devaluation, blocked criticizability, partial agency, or reduction to a single function. A role-position may be made only dangerous, only vulnerable, only useful, only responsible, only protected, or only burdensome. Each reduction damages D (dignity-in-practice) because it narrows how the position may participate under real Ω (asymmetry).

Exposure cost concerns who remains open to consequence, accusation, demand, physical risk, relational instability, or public interpretation. Recognition cost concerns whose standing depends on conforming to the scene’s dominant account. Legibility cost concerns who must translate structures that the shared frame has failed to name. Χ (distance) cost concerns who must create reflective space, restrain escalation, preserve revisability, or absorb the suspicion that distance itself signifies withdrawal or guilt.

These costs are relationally connected, but they are not interchangeable. Greater visibility does not automatically imply greater responsibility. Greater protection does not automatically imply immunity. Greater exposure does not establish innocence. Greater explanation burden does not prove that the speaker’s interpretation is correct. Each vector still requires scene-bound tracing.

The central guardrail is:

```text
Bidirectionality is not symmetry.
Different positions may carry different losses under the same drift.
```

Non-symmetry is not one-sidedness. Several role-positions may contribute to a drift, carry its effects, or lose important capacities without contributing in the same way or losing the same things. Shared involvement does not establish equal responsibility. Shared damage does not establish equal cost. A bidirectional account must remain capable of distinguishing capacity, effect, exposure, alternatives, timing, and available protection.

The distinction between immunized and overexposed positions provides one compact map:

```text
immunized position:
effect remains partially protected from responsibility

overexposed position:
responsibility becomes heavier than legibility or protection allows
```

Immunization can diminish adult agency by separating recognition or protection from full answerability. A role-position may retain real effect while becoming less criticizable because questioning that effect appears degrading, threatening, or insufficiently protective. The loss is not that the position receives recognition. The loss is that recognition no longer includes responsibility for structuring effect.

Overexposure distorts responsibility in the other direction. A role-position may be made answerable before effect has been adequately traced, beyond its available capacity, or without sufficient protection against degradation. Its visibility, role, strength, speech, prior history, or perceived competence may make it responsible for more than the scene can structurally justify. The loss is not that responsibility exists. The loss is that responsibility becomes heavier than legibility and protection permit.

These positions can coexist within the same drift, but they do not form a simple pair of equal harms. Immunization and overexposure can differ in severity, duration, material consequence, reversibility, and relation to real capacity. A scene may also distribute both conditions across the same role-position in different domains. Someone may be protected from one form of criticism while overexposed to another. The concepts map structural positions, not permanent identities.

Previously developed sexed profiles can therefore be recalled only in bounded form. A male-coded overexposure profile may involve loss of legitimate vulnerability, action-space, dignity-in-practice, and explanatory language. A female-coded immunization profile may involve loss of full adult agency where protection or recognition shields structuring effect from criticizability.

These are scene-bound profile references, not sex truths. They do not claim that male role-positions are inherently overexposed, that female role-positions are inherently immunized, or that either profile captures every sexed scene. They identify possible configurations whose applicability remains dependent on actual capacity, exposure, role, frame, history, effect, and counter-scene.

Cost distribution is therefore not moral balancing. It is not victim competition. It is not proof that both sides lose equally. It is not fixed sex-role assignment.

Its purpose is narrower and more demanding: to show that reciprocity loss consumes different channels in different positions. One position may lose legitimate protection. Another may lose criticizability. One may lose speech. Another may lose full agency. One may carry excessive responsibility. Another may become insufficiently bound to its effects. One may be denied vulnerability. Another may be confined to vulnerability. One may be devalued as dangerous. Another may be diminished through protection.

The relation does not become reciprocal merely because every position can identify a loss. Nor does one loss cancel another. The question is whether the scene can still name these differentiated costs, connect responsibility to real structuring effect, preserve dignity-in-practice, and permit correction to alter the coordination.

Where it cannot, cost distribution becomes more than unequal burden. It becomes part of the loss of correctability. The deepest damage appears when the relation can no longer receive a proportionate account of these costs without translating critique into threat, responsibility into domination, protection into immunity, or equality into exit.

### 17.5 Loss of Correctability

The differentiated costs of reciprocity loss converge on a deeper failure. A relation may remain active, emotionally significant, institutionally durable, or practically interdependent while losing the capacity through which its own distortions could still be received and corrected.

The worst loss is not conflict. The worst loss is the loss of shared correctability.

Correctability is the possibility that a relation can receive, test, and integrate correction without destroying D (dignity-in-practice), evading R (responsibility), or further blocking Σ (integration) and Ψ (self-binding). It does not guarantee agreement. It does not guarantee reconciliation. It does not require every criticism to be accepted or every relation to be preserved. It names the more basic capacity through which a structural claim can remain answerable to the scene and consequential for how the scene is coordinated.

Correctability is an EDEN-definitional relational capacity and an explicitly normative criterion of Adult Reciprocity. It is not a PMS operator, a formally derived natural law, or an empirical universal. Whether correctability is available, damaged, or lost in a particular scene remains a descriptive hypothesis that must be supported by evidence, counter-scene exposure, and defeat conditions.

Correctability is not agreement. Two role-positions may disagree about interpretation, responsibility, proportion, timing, or available alternatives while remaining capable of testing their accounts against structuring effects. Agreement can also occur without correctability if one side concedes under pressure, if conflict is suppressed, if the dominant frame cannot be questioned, or if apparent consensus depends on an unintegrated cost.

Correctability is not peace. A quiet relation may be unable to receive correction because silence, avoidance, devaluation, or threat attribution protects its surface order. A conflictual relation may remain highly correctable if criticism can be heard, responsibility remains traceable, effects can enter a shared frame, and relevant actors remain bound to what they structure.

Correctability is not forced harmony. It does not require a role-position to remain indefinitely available, abandon legitimate boundaries, accept degrading criticism, or surrender distance. A relation is not more correctable merely because it compels continued engagement. Coerced openness can itself destroy the distance and dignity required for correction to function as praxis.

The central distinction is therefore:

```text
A relation can survive conflict;
it cannot sustain reciprocity when correction itself becomes illegible.
```

Conflict may disclose a structure that surface order concealed. Critique may make an unrecognized cost speakable. Correction may interrupt a responsibility distribution that had become normalized. Discomfort can therefore accompany correctability rather than signal its absence. Reciprocity does not depend on avoiding these experiences. It depends on whether they can still alter the relation without being converted into humiliation, immunity, domination, or exit from responsibility.

The loss becomes visible through a recurrent set of transformations:

```text
Critique cannot land.
Correction appears as threat.
Responsibility appears as domination.
Protection appears as immunity.
Equality appears as exit.
Silence appears as neutrality.
Non-binding appears as autonomy.
Legitimation replaces repair.
```

Critique cannot land where a claim about structuring effect is unable to reach its object. The words may be heard, but the responsibility relation they name cannot enter the scene. Attention shifts to the critic’s tone, standing, motive, identity, emotional state, or legitimacy before the structure itself can be examined. The critique becomes an event to manage rather than information the relation must test.

This does not mean that tone, timing, standing, or form are irrelevant. Critique can humiliate, exaggerate, dominate, retaliate, or misread. A structural vocabulary does not make a criticism valid. But correctability is impaired where every proportionate attempt to name a real effect is displaced into a prior contest over whether the critic is safe enough, harmless enough, authorized enough, or sufficiently unaffected to speak.

Correction appears as threat when a challenge to the coordination frame is interpreted as a threat to personhood, recognition, safety, equality, or dignity. The experience of threat may be real. Yet the reality of that experience does not settle whether the correction is degrading or whether it identifies a genuine responsibility-displacing structure. If felt threat automatically defeats structural examination, the frame becomes protected by the reaction it produces when questioned.

Responsibility appears as domination when answerability for effect is translated into another role-position’s attempt to govern, shame, control, or subordinate. Such translation may sometimes be accurate. Responsibility language can indeed be used coercively. Drift arises where the translation occurs before the scene can distinguish a proportionate responsibility claim from domination. R then becomes difficult to name without activating the very frame that blocks it.

Protection appears as immunity where a valid need for safety, restraint, timing, care, or reduced exposure expands into reduced criticizability. The protected position retains real effect, but the cost of questioning that effect becomes too high. Protection no longer preserves an adult role-position within reciprocity. It separates recognition from answerability.

Equality appears as exit where formal parity, autonomy, or mutual freedom becomes a way to leave unequal effects unintegrated. A role-position may retain a legitimate right to refuse or withdraw. Correctability is damaged where the equality frame makes the cost of that refusal structurally unspeakable. The right to exit is then treated as if it settled responsibility for what the exit organizes.

Silence appears as neutrality where non-response, non-clarification, delay, or withholding is treated as structurally empty despite shaping timing, exposure, options, or binding load. Silence may genuinely be neutral, restrained, unavailable, or necessary. It becomes relevant to correctability only where it structures the scene while remaining unavailable to responsibility.

Non-binding appears as autonomy where freedom from commitment is treated as costless even though another role-position must carry the continuity, uncertainty, anticipation, explanation, or repair burden that non-binding leaves open. Autonomy remains legitimate. The loss occurs where its real effects cannot enter shared coordination because naming them appears to deny freedom itself.

Legitimation replaces repair where a structure acquires sufficient reasons to continue without integrating what it costs. The reasons may be morally serious, protective, practical, institutional, historical, or emotionally intelligible. They may explain why the configuration exists. But explanation is not integration. A frame can be justified repeatedly while the responsibility displacement it stabilizes remains untouched.

These transformations do not prove reciprocity loss by isolated appearance. A claim of threat may be accurate. Protection may be fully justified. Exit may be necessary. Silence may be neutral. Autonomy may require non-binding. Legitimation may correctly describe a functional arrangement. Correctability cannot be assessed by treating every defense, boundary, or refusal as evidence against the scene.

The decisive question is whether a proportionate, revisable, counter-scene-exposed, dignity-preserving correction can still reach the relevant structuring effect. If the answer is no regardless of how carefully the claim is bounded, the problem is no longer only disagreement about a particular correction. The scene has begun to lose the conditions under which correction could matter.

Those conditions can be stated compactly:

```text
Correctability requires Χ, Σ, Ψ, and D.
Without them,
even accurate criticism may fail as praxis.
```

Χ (distance) allows correction to remain distinct from immediate fusion, retaliation, panic, or enforcement. It creates the reflective interval in which a claim can be considered, narrowed, revised, or rejected without becoming an irreversible judgment. Distance applies to critic and recipient alike. The critic must remain able to revise the claim; the recipient must remain able to encounter it without the claim becoming a total definition of personhood.

Σ (integration) allows the scene to hold several relevant truths together. Vulnerability may be real, and the vulnerable position may still structure effects. Protection may be necessary, and protection may still distribute cost. A critic may be accurate about one mechanism and inaccurate about another. A role-position may carry real responsibility while also being overexposed. Integration prevents one true element from excluding every other true element.

Ψ (self-binding) binds relevant actors to their actual structuring effects. Without it, correction remains external demand. Each position can explain why another should change while remaining detached from the costs, protections, silences, delays, frames, or reactions it contributes. Shared correctability does not require identical self-binding. It requires that no consequential position treat its own effect as belonging only to the other side’s problem.

D (dignity-in-practice) preserves criticizability without humiliation. Correction cannot function reciprocally if it lowers standing, converts structure into essence, ranks persons or sexes, or makes degradation the price of answerability. D does not protect a role-position from responsibility. It protects the distinction between responsibility and degradation.

R is the responsibility relation that correction seeks to restore: answerability should follow real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. Χ, Σ, Ψ, and D make that restoration structurally possible. Where they are blocked, responsibility may be asserted, but it cannot be coordinated with sufficient precision.

Accuracy alone is therefore insufficient. A criticism may correctly identify an effect while failing as praxis because it humiliates, totalizes, ignores alternatives, refuses revision, or bypasses the conditions under which responsibility can be received. Conversely, the failure of a criticism to land does not prove that the criticism was false. A structurally accurate claim can fail because the scene has lost the channels required to integrate it.

The guardrail must remain explicit:

```text
Not all critique is valid.
Not all correction is dignity-preserving.
But a relation loses reciprocity when even proportionate,
counter-scene-exposed,
dignity-preserving correction cannot land.
```

This criterion prevents correctability from becoming a right to compel agreement. A critic does not gain authority merely by claiming structural accuracy. Nor does a recipient gain immunity merely by experiencing correction as uncomfortable. Both the claim and the conditions of reception remain answerable.

Loss of correctability is thus more precise than failed communication. Communication may continue extensively. Actors may explain, argue, reassure, justify, apologize, negotiate, or repeat their accounts. The deeper question is whether those exchanges can change the relation between real effect and responsibility. Communication without that possibility may manage tension while leaving reciprocity loss intact.

It is also more precise than relationship breakdown. A relation can end while retaining correctability: its participants may still name what occurred, accept differentiated responsibility, preserve dignity, and integrate the significance of the ending. A relation can continue while becoming uncorrectable: its routines remain stable, but no admissible speech can alter their responsibility structure.

Correctability therefore identifies the deepest relational capacity at stake. Once it is lost, the scene may still produce order, attachment, protection, continuity, or recognizable roles. What it can no longer produce reliably is truthful self-correction under real asymmetry. That is why reciprocity loss is tragic rather than merely conflictual.

### 17.6 Tragedy, Not Guilt

To call reciprocity loss tragic is to describe a structural form of damage, not to suspend responsibility. Real harm may emerge through agency, wrongdoing, negligence, self-binding failure, protection failure, overreach, withdrawal, non-action, or responsibility displacement without the entire field becoming reducible to guilt.

The required distinctions are:

```text
responsibility without guilt-totalization
harm without villain simplification
agency without essence blame
structure without exculpation
tragedy without innocence theater
```

A guilt-totalizing account asks the structural analysis to end in a morally complete allocation: one side becomes the source of the loss, another its recipient, and the relation becomes legible through accusation. Such closure can appear clarifying because it reduces ambiguity. But it often destroys the differentiated conditions under which R (responsibility) must actually be traced.

Responsibility is not guilt. It is not blame, moral worth, person condemnation, mere causality, or outcome-liability alone. R follows real structuring effect under the legibility, capacity, alternatives, temporality, and asymmetry conditions available in the scene. This allows responsibility to remain real without becoming unlimited.

Malice is therefore neither required nor irrelevant. A role-position may structure harm without intending it. Limited legibility, inherited frames, normalized burdens, local necessity, fear, protective concern, or sincere moral conviction may help explain how the effect became possible. None of these conditions automatically erases responsibility. At the same time, deliberate exploitation, coercion, neglect, humiliation, or refusal of self-binding may be present and must not be dissolved into neutral structure.

The tragic frame holds both possibilities:

```text
Responsibility remains possible without malice.
Structure remains real without erasing agency.
Agency remains real without essence blame.
```

Structure without agency would become fatalism. Agency without structure would become blame simplification. The tragic account refuses both reductions. It examines how agents act within fields of partial legibility, unequal capacity, inherited framing, real exposure, and temporally stabilized expectations while remaining answerable for what they can actually structure.

This answerability is differentiated. One role-position may have greater capacity to decide, expose, protect, define, delay, or alter the scene. Another may structure the scene through non-binding, recognition allocation, withdrawal, vulnerability framing, or refusal of clarification. Their responsibilities need not be equal, simultaneous, or comparable along a single scale. Tragedy does not mean that everyone is equally responsible.

Nor does tragedy mean that every role-position is innocent because the structure is complex. Structural explanation is not an innocence certificate. To explain how a drift became locally intelligible does not make its effects reciprocal. A move may be understandable under pressure and still displace responsibility. A protection response may be sincere and still immunize effect. An attempt to stabilize the scene may be necessary in the short term and still externalize cost. A role-position may lack malicious intent and still fail to bind itself to what it structures.

The central guardrail is:

```text
Tragedy does not erase responsibility.
Responsibility does not require total guilt.
Calling a drift tragic does not remove responsibility.
Calling a drift responsible does not require total guilt.
```

Tragedy is not fatalism. The collapse sequence is not inevitable, and its elements do not form a closed destiny. Legibility can improve. Comparison can remain functional. Misframing can be corrected. Responsibility can be reattached. Integration and self-binding can reopen. To describe a tragic outcome is not to claim that no alternative was ever possible.

Tragedy is not exculpation. Structural conditions may constrain available action without eliminating all alternatives. Limited legibility may narrow responsibility without erasing it. High cost may explain non-action without making every non-action neutral. Vulnerability may justify protection without making every effect uncriticizable. The Responsibility Principle remains active precisely because scene conditions affect how much responsibility can truthfully be assigned.

Tragedy is not “everyone equally responsible.” Mutual involvement can coexist with radical differences in capacity, effect, exposure, and available alternatives. One position may have produced direct harm while another contributed only to persistence. One may have had greater opportunity to correct the scene. Another may have carried a heavier cost for speaking or acting. Tragic framing does not flatten these distinctions.

Tragedy is not innocence theater. A claim of overexposure does not create immunity. A claim of immunization does not make the critic innocent. A claim of vulnerability does not settle responsibility. A claim of structural accuracy does not authorize humiliation. No role-position escapes scene-bound examination merely because another position’s drift has been identified.

This prevents reversal into counter-immunity. Critique of an immunized position cannot become protection from responsibility for the critic. Critique of overexposure cannot become denial of the overexposed position’s real effects. Critique of false protection cannot become rejection of protection. The correction of one false asymmetry must not produce another.

The tragedy lies in the possibility that locally intelligible moves can jointly erode the channels through which their effects could still be corrected. Protection can become immunity without beginning as evasion. Responsibility can become authority without beginning as domination. Autonomy can externalize cost without beginning as abandonment. Silence can structure the scene without beginning as manipulation. Attempts to reduce immediate conflict can stabilize a relation that is progressively less reciprocal.

This is not a claim that motives never matter. Motive may affect legibility, available alternatives, responsibility, repetition, and the interpretation of action. The narrower claim is that motive does not exhaust structure. Benevolent intention cannot by itself integrate cost. Harmful intention does not by itself explain every consequence. A tragic account keeps intention within the scene without making it the sole measure of responsibility.

The same discipline applies to wrongdoing. Naming structural drift does not deny that some acts may be wrong, negligent, coercive, degrading, or destructive. It prevents those judgments from replacing the analysis of how the scene distributes capacity, effect, cost, protection, and correctability. Moral seriousness remains possible without turning the entire relation into a tribunal.

The tragic frame therefore preserves a difficult middle:

```text
Tragedy, not guilt.
Structure, not verdict.
Loss, not accusation.
```

These formulations do not weaken the claim that reciprocity has failed. They specify the level of the claim. What has been lost is a shared structural capacity: the ability to coordinate real asymmetry truthfully and to correct false coordination without displacement, humiliation, or immunity.

Because this loss does not depend on a single malicious intention, it can persist through ordinary routines, locally plausible justifications, protective frames, and repeated attempts to preserve order. A damaged relation may therefore become stable without becoming reciprocal. Devaluation and related stabilizers can hold such a system together after correctability has begun to fail.

### 17.7 Stability through Devaluation

Loss of correctability does not necessarily produce immediate collapse. A relation, institution, or social arrangement may continue functioning after reciprocity has been damaged. Roles remain recognizable. Expectations remain enforceable. Conflicts may become less visible. Daily coordination may even become more predictable.

The central distinction is:

```text
Stability is not reciprocity.
Order is not integration.
Peace is not correctability.
Predictability is not Adult Reciprocity.
```

A system is stable when its patterns remain sufficiently repeatable to organize expectation and action across Θ (temporality). Reciprocity asks a different question: whether those patterns truthfully coordinate real Ω (asymmetry), keep responsibility attached to structuring effect, preserve self-binding, integrate costs, protect dignity-in-practice, and remain correctable.

The two conditions can coincide. Stable routines can support recognition, responsibility, trust, protection, and correction. But stability can also preserve a configuration in which the costs required for that stability remain displaced, silenced, naturalized, or devalued.

Stability without reciprocity is possible. Devaluation can stabilize a relation after reciprocity has already failed.

A reciprocity-damaged system can remain stable by devaluing, overexposing, immunizing, silencing, or misrecognizing one or more role-positions.

The resulting movement can be compressed as follows:

```text
stability without reciprocity
→ devaluation as glue
→ role-hardening
→ speech loss
→ responsibility distortion
→ repeated pseudo-resolution
```

Devaluation becomes a stabilizer where the scene can reduce the standing of a cost, claim, burden, or signal-carrier more easily than it can integrate the structure being named. Instead of coordinating the real asymmetry, the system lowers the relevance, credibility, maturity, legitimacy, or recognizability of the position through which the asymmetry becomes visible.

The devaluation may be direct. A role-position can be framed as inferior, dangerous, weak, selfish, controlling, immature, ungrateful, burdensome, or incapable of understanding the larger necessity. But devaluation may also be indirect. A claim may be acknowledged while being treated as untimely, excessive, too emotional, insufficiently protective, insufficiently realistic, or incompatible with the frame through which the system understands itself.

In either form, devaluation lowers the immediate cost of coordination. If the signal-carrier can be discounted, the system does not need to reopen its responsibility distribution. If the burden can be reframed as personal dissatisfaction, the asymmetry does not need to enter Σ (integration). If critique can be interpreted as threat, the protected frame does not need to become more answerable.

Devaluation is therefore not only an expression of rank. It can function as a low-cost substitute for correction. The system preserves local order by reducing the force of whatever would require that order to change.

This does not require conscious bad faith. A system can devalue through routines that appear protective, fair, practical, caring, neutral, realistic, or necessary. Participants may sincerely believe that they are reducing conflict, preserving safety, respecting autonomy, or protecting dignity. The stabilizing effect lies in what the frame makes repeatably possible, not in a hidden motive that must be attributed to particular persons.

Role-hardening follows because stable false coordination requires predictable carriers. One role-position becomes the protector, stabilizer, danger, burden, vulnerable side, competent side, integrating side, or side responsible for repair. These roles may begin from real differences in capacity, exposure, or obligation. They harden when the system can no longer revise them in response to changing effects.

Role-hardening narrows criticizability. A protected role-position may become difficult to hold responsible without appearing to withdraw recognition or safety. A responsibility-bearing position may become difficult to protect without appearing to deny its capacity or obligations. The role begins to determine in advance which costs can count, which effects can be named, and which corrections remain admissible.

Speech loss follows because descriptions that do not fit the stabilized roles become increasingly expensive. A role-position may still speak, but only through the vocabulary the system already recognizes. A burden must be translated into an accepted moral language. A responsibility claim must be made harmless before it can be heard. A vulnerability must fit the role to which vulnerability has been assigned. A cost that does not fit may remain affectively present while losing legitimate expression.

Speech loss therefore does not require literal silence. A system may contain extensive communication while excluding the descriptions that could alter its organization. Participants can discuss feelings, intentions, events, needs, or principles without gaining shared access to the real distribution of cost, exposure, responsibility, and self-binding.

Responsibility distortion then becomes easier to reproduce. If roles determine whose effect is visible and whose account is legitimate, R (responsibility) no longer has to be traced anew. It can be assigned through the stabilized frame. One position becomes presumptively responsible because it is more visible, capable, active, or structurally exposed. Another becomes presumptively less responsible because it is protected, vulnerable, less visible, non-acting, or recognized primarily through need.

This creates repeated pseudo-resolution. The system appears to resolve conflict because it has a familiar way to close the scene. Responsibility is reassigned to the expected position. The signal-carrier is discounted. Protection is restored without renewed criticizability. Equality is invoked without integrating unequal cost. Silence ends the dispute without clarifying the non-event. Legitimation supplies a reason for continuation.

The immediate problem may subside, but the underlying coordination remains unchanged. What repeats is not resolution but a procedure for avoiding the conditions of resolution.

The formula can therefore be sharpened:

```text
A system can become stable
because correction is no longer allowed to work.
```

“Allowed” here does not imply a conscious prohibition. Correction may be blocked through accumulated cost rather than explicit rule. A critic may anticipate threat attribution and remain silent. A burdened position may stop explaining because explanation increases exposure. A protected position may never encounter its effect as responsibility because the frame translates criticism before it can land. A role may become so normalized that alternatives no longer appear realistic.

The system then produces a display of coherence without full integration. Its account of itself remains orderly, but relevant costs and effects remain outside that account. Σ (integration) is simulated by continuity, justification, agreement, or conflict suppression. The system can explain why it persists without integrating what persistence requires from its role-positions.

Several stabilizers may contribute:

```text
devaluation
avoidance
legitimation
immunization
overexposure
silence
pseudo-protection
non-binding
critique-to-threat
role-hardening
moralization
```

None of these is sufficient by itself. Avoidance may be temporary restraint. Legitimation may accurately explain a necessary structure. Protection may preserve dignity. Silence may be neutral. Non-binding may be legitimate openness. Moral language may clarify real responsibility. Their stabilizing function becomes relevant only where they repeatedly preserve false coordination and make proportionate correction less available.

PFO is one regime form in which damaged stability can become repeatably available. It can stabilize recognition, protection, parity, and exception frames in ways that preserve responsibility displacement under real Ω (asymmetry). But stability through devaluation can occur beyond PFO. It can appear wherever a system lowers the standing of correction, overexposes one position, immunizes another, or hardens roles more cheaply than it can rebuild shared correctability.

The guardrail against an anti-stability reading must remain explicit:

```text
Not all stability is devaluation.
Some stability is genuine coordination.
Some routines support reciprocity.
Some institutions preserve correctability.
```

Stable expectations can reduce arbitrary exposure, make responsibility legible, protect vulnerable positions, preserve continuity, and distribute burdens more truthfully. Institutions can create reliable routes for criticism, revision, appeal, and correction. Roles can clarify obligation without becoming rank. Repetition can strengthen self-binding rather than block it.

The problem is therefore not structure, routine, institution, or stability. The problem is stability purchased through the loss of correctability. A stable system becomes reciprocity-damaged where its continuity depends on preventing real costs from entering shared integration, shielding effects from responsibility, externalizing self-binding, or lowering the standing of those through whom correction becomes possible.

Such stability can persist because it remains locally useful. It reduces uncertainty. It supplies recognizable roles. It lowers immediate conflict. It allows participants to anticipate how a difficult scene will close. The tragedy is that this local usefulness can consume the very capacities through which the system could become more truthful.

The resulting order is not unreal. It may coordinate many practical demands effectively. But it remains partial. It coordinates around the excluded cost rather than integrating it. It stabilizes the relation by making some effects less speakable, some responsibilities less traceable, and some forms of correction less admissible.

Once this distinction is clear, the question of recovery can be stated without converting the analysis into a program. The opposite of damaged stability is not instability. The opposite of false coordination is not the abolition of structure. The relevant contrast is a configuration in which real asymmetry can again become nameable, answerable, integrable, self-bound, revisable, and dignity-preserving.

### 17.8 Minimal Recovery Signature

A structural account of reciprocity loss can identify the minimum conditions under which shared correctability is no longer fully blocked. It cannot infer from those conditions a sequence of actions, a duty to reconcile, a requirement to preserve a relation, or a guarantee that repair will occur.

The Minimal Recovery Signature is:

```text
Ω named
R reattached to real effect
Λ made speakable
Χ restored
Σ reopened
Ψ self-bound
D protected
```

These elements are not steps. They do not form a prescribed order. They describe a configuration in which the channels required for Adult Reciprocity have become structurally available again.

Ω named means that the relevant asymmetry can enter the scene as a coordinable fact. Differences in capacity, exposure, obligation, protection, dependency, timing, access, or cost no longer have to appear only as rank, threat, vulnerability, resentment, necessity, or personal deficiency. Naming Ω does not justify the asymmetry. It makes its effects available to examination.

The asymmetry need not be abolished for recovery to become possible. Some asymmetries are temporary, some durable, some functional, some harmful, some imposed, some unavoidable, and some open to transformation. The recovery condition is that their reality and consequences can be named without automatically converting difference into inferiority, superiority, domination, immunity, or guilt.

R reattached to real effect means that responsibility again follows what role-positions actually structure. This reattachment remains limited by available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω cost or exposure conditions. It does not assign responsibility by identity, visibility, formal role, declared intention, suffering, or outcome alone.

Reattachment can alter responsibility in more than one direction. It may increase answerability where effect had been immunized. It may reduce overassignment where visibility or role had carried more responsibility than effect justified. It may differentiate responsibility across action, non-action, framing, timing, protection, recognition, non-binding, and legitimation. The signature requires precision, not maximal attribution.

Λ (non-event) made speakable means that relevant absences can enter the scene without being treated as either empty or guilty by default. Silence, delay, withholding, non-clarification, non-response, non-decision, or non-binding may remain neutral, legitimate, constrained, protective, or unavailable. Where they structure cost, exposure, timing, or responsibility, their effects can nevertheless be described.

Making Λ speakable does not convert every absence into praxis. It restores the possibility of asking whether a non-event matters without deciding the answer through suspicion or innocence. The structural condition is legibility, not accusation.

Χ (distance) restored means that interpretation and correction regain revisability. A reading can be held without immediate enforcement. A claim can be examined without becoming a total judgment. A role-position can encounter responsibility without collapsing responsibility into shame, fusion, retaliation, or person threat. The scene can pause long enough to distinguish effect from intention, responsibility from guilt, protection from immunity, and criticism from degradation.

Restored distance applies equally to the analysis itself. A structural interpretation remains capable of being narrowed, corrected, suspended, or defeated. Recovery cannot be grounded in an irreversible label because irreversible labeling would reproduce the loss of correctability it claims to overcome.

Σ (integration) reopened means that real costs, effects, exposures, protections, responsibilities, and asymmetries can again enter a shared praxis relation. Reopening does not require complete agreement or immediate coherence. It means that one true element no longer has to exclude another: vulnerability can remain real alongside agency; protection can remain necessary alongside criticizability; capacity can remain unequal alongside dignity; responsibility can remain real alongside limited legibility.

Integration is reopened rather than completed because no scene becomes totally legible. New effects may appear under Θ. Costs may change. A structure that once coordinated well may become inadequate. Σ remains reciprocal only where it can continue receiving what the scene reveals rather than hardening its first resolution into permanent closure.

Ψ (self-binding) means that relevant role-positions remain attached to their own structuring effects. They do not require another position to carry the full burden of interpretation, continuity, restraint, explanation, or correction. Self-binding does not mean inflexible commitment or self-condemnation. It means that a role-position does not disown its effect merely because that effect becomes costly to recognize.

This condition is not satisfied by declarations of responsibility alone. A role-position may acknowledge responsibility while continuing to externalize its practical load. Ψ becomes relevant where acknowledgment persists across time, recontextualization, discomfort, and changing legibility. It binds the position to answerability while remaining open to revision through Χ.

D (dignity-in-practice) protected means that renewed criticizability does not become humiliation. Naming effect does not authorize degradation. Reattaching responsibility does not rank persons, sexes, or groups. Making non-events speakable does not convert silence into guilt. Reopening integration does not require coerced intimacy, surrender of legitimate protection, or removal of boundaries.

D also prevents recognition from becoming immunity. To protect standing is to preserve the role-position as an adult participant in responsibility, not to remove it from answerability. Dignity-in-practice therefore protects both sides of correctability: the right not to be degraded and the capacity not to be de-adulted through protection from all critique.

The elements can be restated through the positive structure of Adult Reciprocity:

```text
Adult Reciprocity =
real Ω visible
+ D preserved
+ R follows real structuring effect
+ Σ integrates costs and effects
+ relevant role-positions remain self-bound through Ψ to their own effects
+ Χ keeps revision possible.
```

The Minimal Recovery Signature adds explicit attention to Λ because non-events, non-action, and non-binding may have become part of the damaged configuration. Where such absences structure the scene, shared correctability cannot reopen while their effects remain either invisible or presumptively guilty.

The central distinction is:

```text
Recovery is not the abolition of asymmetry.
Recovery is the truthful,
criticizable,
self-bound coordination of asymmetry.
```

Abolishing every asymmetry is neither possible nor identical with reciprocity. Formal equality can coexist with unequal cost, exposure, dependency, or action-power. Conversely, a relation can contain real asymmetry while preserving differentiated answerability, integration, revision, and dignity-in-practice.

Recovery therefore does not mean a return to an imagined condition without difference, burden, conflict, or vulnerability. It means that these conditions no longer have to be coordinated through rank artifacts, responsibility displacement, blocked integration, externalized self-binding, or uncorrectable protection.

The signature also does not establish that repair will happen. A relation may regain legibility without regaining trust. Responsibility may become clear after continuation is no longer possible or appropriate. Costs may be integrated without becoming reversible. Some consequences may remain. Some alternatives may have disappeared under Θ. Tragedy is not cancelled merely because the structure becomes more truthful.

The precise claim is narrower:

```text
A minimal recovery signature does not mean repair will happen.
It means the structural conditions of shared correctability
are no longer fully blocked.
```

No element alone is sufficient. Naming Ω without D can become rank or domination. Reattaching R without Χ can become accusation. Making Λ speakable without counter-scene exposure can turn absence into presumed guilt. Reopening Σ without Ψ can leave one position to integrate what another still refuses to carry. Self-binding without distance can become shame or rigidity. Protection of D without responsibility can return to immunity.

Their conjunction matters because Adult Reciprocity is not a single virtue or attitude. It is a structural relation among legibility, responsibility, integration, self-binding, revision, and dignity under real asymmetry.

The status of the signature must therefore remain explicit:

```text
This is a viability signature,
not a therapeutic program,
not a moral recipe,
and not a guarantee of repair.
```

It offers no instructions for changing another person, no sequence for restoring a relationship, no demand for confrontation, and no authorization to bind action through structural vocabulary. It identifies only the conditions under which reciprocity becomes structurally thinkable again.

This non-prescriptive limit follows from the object itself. A theory of correctability would contradict itself if it converted its own description into an irreversible demand. A theory of dignity-in-practice would contradict itself if it authorized humiliation in the name of truth. A theory of self-binding would contradict itself if it primarily became a means of binding others.

The chapter can therefore close without either despair or solutionism. Reciprocity loss is the erosion of shared correctability under real asymmetry. Its tragic form does not erase responsibility. Its stability does not make it reciprocal. Its possible recovery does not abolish asymmetry or guarantee repair.

Before this account can be used to map scenes, it must be exposed to its limits. The next task is to identify where the loss reading weakens, where genuine vulnerability or protection explains more, where non-action remains neutral, where hierarchy or superiority is real and functional, where a rival explanation is stronger, and what evidence would defeat the analysis. Boundary conditions, counter-scenes, and falsifiers therefore follow before application.

---

## 18. Boundary Conditions, Counter-Scenes, and Falsifiers

### 18.1 Boundary Purpose

A theory of reciprocity loss becomes methodologically serious only where it can say when its own reading does not hold. The preceding analysis identified what is lost when real asymmetry remains operative while responsibility, integration, self-binding, distance, dignity-in-practice, and shared correctability erode. That account now requires exposure to conditions that can weaken it, redirect it, or defeat it.

Boundary conditions do not soften the claim. They specify its reach. A framework that cannot distinguish a scene it explains from one it merely resembles does not gain strength from broad applicability. It loses discriminative force. The relevant question is therefore not whether EDEN can be made to fit a scene, but whether scene-bound evidence supports the particular structure EDEN names.

The governing condition is:

```text
EDEN must remain falsifiable,
bounded,
scene-bound,
counter-scene exposed,
and discriminative.
```

Falsifiable means that an EDEN reading can name conditions under which it would fail. Bounded means that the framework does not claim every conflict, asymmetry, injury, hierarchy, silence, or recognition problem as its object. Scene-bound means that the reading remains attached to a specified configuration of role-positions, effects, costs, protections, alternatives, and temporal development rather than becoming a label for persons or groups.

Counter-scene exposure means that the same available facts must be placed against at least one materially different structural reading. That reading cannot be included merely to display caution. It must be capable of changing the result. Discriminative means that EDEN must distinguish false coordination from genuine vulnerability, genuine protection, functional hierarchy, local superiority, neutral non-action, legitimate openness, accurate legitimation, and non-capture.

These requirements place four limits on conceptual use:

```text
No concept may replace judgment.
No pattern may replace evidence.
No frame may replace scene analysis.
No EDEN label may replace scene analysis.
```

Concepts remain necessary. They make structures visible that ordinary description may leave fragmented or unnamed. Patterns can reveal relations among asymmetry, responsibility, integration, self-binding, protection, exposure, and correction. Frames can show how a scene organizes relevance. But none of them establishes its own applicability. A concept identifies a question; it does not answer that question merely by being available.

The same discipline applies to pattern recognition. Similarity between a scene and a developed drift pattern may justify closer examination, but similarity is not evidence that the relevant mechanism is active. A protection claim does not establish immunization. A power difference does not establish false coordination. A silence does not establish structuring non-action. A shift in framing does not establish a stabilized regime. Each claim still requires evidence of effect, responsibility distribution, cost, temporal consequence, and blocked or preserved correctability.

A scene packet provides the minimum descriptive threshold: a scene, relevant role-positions, operative asymmetry, traceable structuring effects, responsibility and cost distribution, integration and self-binding relevance, and at least one possible counter-scene. The threshold does not decide the reading. It prevents isolated statements, identities, affects, or ideological associations from substituting for an adequately specified scene.

Boundary conditions, counter-scenes, rival explanations, non-capture cases, and falsifiers perform different tasks. Boundary conditions identify the limits of applicability. Counter-scenes test whether the same facts support another structural reading. Rival explanations ask whether another framework explains the decisive features more specifically or with better evidence. Non-capture names the legitimate result that EDEN may not be the right account. Falsifiers state what would weaken or defeat the reading rather than merely complicate it.

This distinction matters because a framework can appear open while remaining insulated. It may list alternatives but never allow them to win. It may mention counterexamples while interpreting each one as another form of the same pattern. It may treat resistance to the reading as evidence of immunization, disagreement as evidence of threat, or requests for proof as evidence that the structure is difficult to name. Such a framework would reproduce the loss of correctability it seeks to describe.

The anti-immunity requirement is direct:

```text
EDEN must not become a model
that always finds itself.
```

An EDEN reading therefore remains answerable not only to the facts it includes but also to facts it may have misclassified, omitted, or organized through the wrong frame. The analyst is not outside limited legibility, comparison susceptibility, responsibility displacement, or the desire for explanatory closure. Model use must remain subject to the same distance, self-binding, and correctability that the model treats as conditions of reciprocity.

This is not an apology for making a strong claim. It is the condition under which a strong claim remains methodologically admissible. A theory becomes stronger, not weaker, when it can say where it does not apply.

The first task is therefore negative and concrete: identify the conditions under which an EDEN reading lacks sufficient structural support.

### 18.2 When EDEN Does Not Apply Strongly

An EDEN reading weakens or fails where the scene lacks the structure required by the claim. The strongest boundaries concern the absence of real asymmetry, structuring effect, false coordination, responsibility displacement, blocked integration or self-binding, consequential drift, or sufficient evidence against a stronger rival explanation.

The compact boundary is:

```text
EDEN weakens where there is:
no real Ω
no structuring effect
no responsibility displacement
no blocked Σ/Ψ
no repeated or consequential drift
no false coordination
better rival explanation
```

The absence of real Ω (asymmetry) removes the principal structural object. A scene may contain disagreement, difference, discomfort, status concern, or emotional intensity without an action-relevant asymmetry of capacity, exposure, obligation, protection, dependency, timing, access, or cost. Where no such asymmetry structures consequences, EDEN has little explanatory work to do.

Even where real Ω (asymmetry) exists, there must be a traceable structuring effect. A difference in position or capacity is not enough. Something must shape what can be done, withheld, recognized, protected, corrected, delayed, or made costly. If the alleged effect cannot be connected to the scene’s organization, the reading rests on association rather than structural evidence.

The same limit applies to R (responsibility). If responsibility remains proportionately attached to real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions, then responsibility displacement is not established. Unequal responsibility may still be appropriate. EDEN weakens where the analysis mistakes differentiated answerability for distortion.

Robust Σ (integration) and Ψ (self-binding) also weaken the drift claim. Where relevant costs and effects enter a shared frame, and where the consequential role-positions remain durably bound to what they structure, asymmetry may be difficult without being falsely coordinated. Conflict can remain intense while integration and self-binding continue to work.

Consequential drift must likewise be shown rather than inferred from one uncomfortable event. A single misunderstanding, delayed response, protective move, framing error, or failed correction may matter greatly without constituting a repeated or stabilized pattern. If the scene corrects the effect, revises responsibility, restores criticizability, or prevents recurrence, the stronger drift reading loses support.

False coordination remains the decisive frame condition. EDEN weakens where the dominant □ (frame) does not falsely coordinate real Ω (asymmetry). The relevant test is not whether comparison language appears. A scene may coordinate asymmetry falsely through protection, recognition, parity, autonomy, vulnerability, authority, non-action, non-binding, or legitimation; it may also use any of those frames accurately. What matters is whether the frame mislocates effect, responsibility, cost, criticizability, or self-binding.

A stronger rival explanation can also displace EDEN. Institutional constraint, economic pressure, legal obligation, illness, trauma, direct violence, acute crisis, ordinary misunderstanding, task-specific incapacity, conflicting duties, or external coercion may explain the decisive structure more accurately. EDEN may retain partial relevance, but partial relevance does not establish explanatory priority.

Several common appearances therefore remain insufficient:

```text
Discomfort alone is not EDEN.
Conflict alone is not EDEN.
Difference alone is not EDEN.
Power difference alone is not EDEN.
Vulnerability alone is not EDEN.
```

Discomfort may accompany criticism, uncertainty, incompatible needs, or legitimate boundary-setting. Conflict may arise within reciprocal coordination. Difference may be functionally important without becoming rank. Power differences may be real, bounded, answerable, and necessary to a task. Vulnerability may be genuine and may require asymmetric protection. None of these appearances proves false coordination by itself.

The boundary must also remain specific to the mechanism being claimed. If a reading depends on Λ (non-event), the alleged absence must be meaningful rather than empty. If it depends on Θ (temporality), accumulation or trajectory must be present. If it depends on a critique-to-threat switch, proportionate structure critique must actually have been recoded as threat. If it depends on immunization and overexposure, the scene must show underassigned responsibility in one position and responsibility heavier than legibility or protection permits in another.

The mechanism-specific weakening conditions can be stated as follows:

```text
a meaningful Λ is absent
Θ accumulation is absent
the alleged critique-to-threat switch is absent
the alleged immunization / overexposure coupling is absent
```

These absences defeat the corresponding mechanism claim. They are not universal requirements for every form of false coordination. A scene may contain responsibility displacement without a critique-to-threat switch, or false coordination without an immunization and overexposure coupling. Boundary discipline narrows the reading to what the evidence supports instead of requiring every scene to instantiate the entire framework.

The positive countercondition is equally important. Where real Ω (asymmetry) is acknowledged, R (responsibility) follows structuring effect, Σ (integration) receives relevant costs, Ψ (self-binding) remains attached to effect, and counter-scenes remain possible, the stronger drift claim weakens:

```text
If real Ω is acknowledged,
R follows structuring effect,
Σ integrates cost,
Ψ is self-bound,
and counter-scenes remain possible,
then EDEN’s drift claim weakens.
```

This conclusion does not establish that the scene is comfortable, equal, harmless, or fully reciprocal. It establishes only that the core conditions of the proposed drift have not been shown strongly enough. EDEN must then narrow its claim, yield to a stronger explanation, or release the scene from the reading.

Two domains are especially vulnerable to suspicion: vulnerability and protection. Both can participate in false coordination, but neither is false by default.

### 18.3 Genuine Vulnerability and Genuine Protection

The absence of sufficient support for an EDEN reading is not merely a technical possibility. It is especially important where vulnerability and protection are present. A framework concerned with immunization, recognition, and responsibility displacement can become overextended if it treats every protected position as insufficiently answerable or every vulnerability claim as a shield. That inference is not warranted.

The governing distinction is:

```text
Vulnerability and protection are not false as such.

EDEN applies only where vulnerability or protection frames
block proportionate responsibility,
criticizability,
or integration of real effect.
```

Vulnerability is genuine where exposure, dependency, injury, incapacity, danger, or limited alternatives materially alter what a role-position can bear or do. Such conditions are not rhetorical surfaces imposed on an otherwise unchanged scene. They are part of the scene’s real structure and can change the distribution of demand, timing, protection, and responsibility.

A compact signature is:

```text
Genuine Vulnerability:
real exposure
real harm risk
real protection need
responsibility still proportionately possible
D preserved
```

Real exposure means that a role-position is materially open to injury, loss, coercion, degradation, dependency, or consequences it has limited capacity to absorb. Exposure can be physical, institutional, economic, relational, social, or temporal. Its reality does not depend on whether the exposure is immediately visible to every participant.

Real harm risk means that a demand, criticism, disclosure, decision, confrontation, or continuation of ordinary expectations may carry consequences beyond discomfort. The distinction matters because discomfort can remain compatible with correction, while a credible risk of harm may require a different distribution of timing, burden, distance, or protection.

Real protection need follows where unmodified participation would expose a role-position to harm it cannot reasonably absorb under the scene’s conditions. Protection may therefore reduce demand, change timing, restrict access, preserve distance, allocate authority asymmetrically, or suspend ordinary expectations. None of these changes constitutes false coordination merely because the resulting positions are unequal.

Responsibility remains proportionate rather than mechanically constant. R (responsibility) follows real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. Genuine vulnerability can reduce capacity, remove alternatives, increase the cost of response, or alter what could reasonably have been understood at a given point. A responsibility account that ignores those conditions becomes overassigned rather than precise.

Proportionality does not mean that vulnerability erases every structuring effect. A vulnerable role-position may still shape timing, access, recognition, protection, cost, or another position’s available alternatives. The relevant question is whether responsibility can be attached to those effects without denying the vulnerability, exceeding available capacity, or making exposure itself the basis of accusation.

D (dignity-in-practice) remains active in both directions. Vulnerability must not be used to reduce a role-position to helplessness, partial agency, or permanent exemption from adult standing. Responsibility must not be used to force exposure, remove necessary protection, or make degradation the price of criticizability. Genuine vulnerability remains compatible with agency precisely because agency is assessed under actual conditions rather than imagined independence.

Some scenes require strongly asymmetric responses. Acute danger may require immediate protection. Injury may alter timing. Trauma may narrow tolerable exposure. Illness may limit available action. Dependency may make formally equal options materially unequal. These conditions do not need to be redescribed as hidden power, avoidance, or responsibility displacement in order to become structurally legible.

The possibility of genuine vulnerability also changes how silence, withdrawal, delay, or non-participation are read. A reduced response may reflect incapacity, protective distance, shock, uncertainty, or lack of a safe alternative rather than structuring non-action. The effect still has to be traced, but the mere presence of an effect does not settle whether proportionate responsibility attaches to it.

Protection is the corresponding structural response. Genuine protection does not remove a role-position from reciprocity. It changes the conditions under which participation, exposure, responsibility, and correction can occur without producing avoidable harm or degradation.

Its compact signature is:

```text
Genuine Protection:
bounded
specific
cost-aware
revisable
responsibility-compatible
Σ/Ψ-opening
```

Bounded protection has a defined relation to the exposure it addresses. It does not expand automatically from protection against a particular harm into protection from every demand, disagreement, consequence, or criticism. The boundary may concern time, subject matter, access, role, intensity, or type of engagement. What matters is that protection remains connected to the vulnerability that warrants it.

Specific protection distinguishes the relevant risk from generalized fragility. A role-position may need protection from public exposure without needing protection from all private correction. It may require distance from a particular actor without losing all answerability for effects elsewhere. It may be unable to participate at one moment without becoming permanently unavailable to responsibility.

Cost-aware protection recognizes that protection itself distributes burdens. Reduced exposure for one position may increase waiting, uncertainty, vigilance, decision pressure, material cost, or protective responsibility elsewhere. Those costs do not make the protection false. They do, however, remain part of the scene and cannot be treated as structurally empty merely because the protective need is genuine.

Revisable protection remains responsive to changing capacity, danger, information, and consequence across Θ (temporality). Revision does not mean that protection must be continually challenged or prematurely withdrawn. It means that a protective arrangement is not converted into an irreversible statement about agency, responsibility, or standing.

Responsibility-compatible protection distinguishes safety from immunity. It preserves the possibility that real structuring effects can become answerable under conditions proportionate to capacity, timing, exposure, and available alternatives. Responsibility may be delayed, narrowed, redistributed, or expressed through another channel without being categorically erased.

Protection is Σ/Ψ-opening where it supports later integration and self-binding rather than making them impossible. Σ (integration) remains open when vulnerability, protection, costs, and effects can eventually enter the same account without one truth excluding the others. Ψ (self-binding) remains open when relevant role-positions can remain attached to what they structure without being forced into exposure, shame, or degradation.

This yields the central boundary:

```text
Protection becomes drift only where it categorically suspends
responsibility,
criticizability,
self-binding,
or correction for real structuring effect.
```

“Categorically” is decisive. A temporary suspension of demand during acute danger, incapacity, injury, or overwhelming exposure is not the same as a frame in which structuring effects can never become answerable. Nor is altered criticizability the same as absent criticizability. Protection may legitimately change when, where, by whom, and in what form a responsibility claim can be raised.

Protection from degradation does not mean protection from responsibility. Protection against harm does not mean protection against criticizability. These distinctions prevent two opposite errors: removing adult agency in the name of care, and removing necessary care in the name of adult agency.

Critique can be degrading. It can overassign responsibility, ignore incapacity, expose a role-position unsafely, convert structural claims into judgments of worth, or use the language of answerability to authorize control. But critique is not degrading as such. Proportionate criticism can preserve dignity by treating a role-position as capable of agency, revision, and self-binding.

Criticizability therefore does not mean permanent accessibility to criticism, immediate response, compulsory confrontation, or the absence of protective boundaries. It means that protection does not become a categorical separation between real effect and possible answerability. The form and timing of criticism remain constrained by harm risk, capacity, distance, reversibility, and dignity-in-practice.

The distinction also prevents a reflexive suspicion toward trauma or harm. A claim of trauma may be accurate. A danger may be real. A protective response may be necessary. EDEN cannot infer immunization merely because responsibility becomes harder to address under those conditions. Increased difficulty may reflect the real cost of preserving dignity and safety rather than a responsibility-displacing frame.

Conversely, the reality of vulnerability does not decide every structural question. A role-position can be genuinely vulnerable and still have consequential effects. Protection can be justified and still impose costs. The scene may need to hold both truths without allowing either to erase the other. This is an integration problem, not evidence that vulnerability was false.

The counter-scene question is therefore substantive: is the alleged immunized position actually protected because exposure, harm, incapacity, or danger is real? If so, the EDEN reading must narrow or yield unless it can also establish that the protective frame categorically blocks proportionate responsibility for real effect.

The governing guardrails remain:

```text
No suspicion toward vulnerability as such.
No anti-protection stance.
No trauma skepticism.
No punitive criticizability.
No denial of real harm.
```

Genuine vulnerability and genuine protection show why asymmetrical treatment cannot itself establish false coordination. The same discipline applies to unequal competence, authority, and role structure. Local superiority and functional hierarchy can also be real without becoming generalized rank.

### 18.4 Genuine Superiority and Genuine Hierarchy

The possibility of genuine protection already shows that asymmetrical treatment is not necessarily false coordination. The same applies to unequal capacity, competence, authority, and responsibility. A framework that treats every local superiority as generalized rank or every hierarchy as authority capture would collapse asymmetry back into suspicion.

The governing distinction is:

```text
Local superiority and hierarchy can be real,
functional,
bounded,
and responsibility-compatible.

They become drift only when they convert into general rank,
authority capture,
or blocked criticizability.
```

Local superiority names a demonstrable difference in capacity within a specified field. One role-position may know more, perceive a risk more accurately, perform a task more effectively, possess greater physical capacity, hold relevant experience, or have better access to information. Denying such differences does not preserve equality. It makes the distribution of capacity less legible.

Genuine superiority has a bounded signature:

```text
Genuine Superiority:
local
bounded
field-specific
responsibility-increasing
D-preserving
criticizable
```

Local means that the difference concerns a particular task, risk, decision, or domain. Greater competence in one field does not establish greater standing in every field. Bounded means that the relevance of the difference ends where its evidentiary or practical basis ends. A local capacity cannot be converted into a general claim about maturity, worth, authority, or entitlement.

Field-specific means that superiority must be identified relative to the structure at issue. Technical expertise may justify greater influence over a technical judgment without settling moral standing, relational authority, or another role-position’s experience. Physical capacity may create a protective obligation without creating a general right to command. Institutional knowledge may support a decision without making its holder uncriticizable.

The responsibility consequence is central:

```text
Capacity increases responsibility where it structures effect.
Capacity does not create ontological rank.
```

Greater capacity can increase R (responsibility) because it changes what a role-position can foresee, prevent, decide, expose, protect, or correct. The increase remains conditioned by available legibility, actual authority, viable alternatives, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure. Capacity does not produce unlimited liability, but neither is it structurally empty.

Responsibility-increasing superiority therefore differs from privilege without answerability. The more strongly a role-position can organize access, timing, protection, information, or consequence, the more precisely its effects may need to remain traceable. Genuine superiority carries a tighter relation to effect; pseudo-superiority converts capacity into exemption, priority, or generalized rank.

D-preserving superiority protects D (dignity-in-practice) while recognizing real differences in capacity. The less capable position is not reduced to inferiority, dependency as essence, or diminished adult standing. The more capable position is not reduced to pure burden, danger, utility, or permanent responsibility. The capacity difference remains real without becoming a ranking of persons.

Criticizable superiority remains open to questions about scope, accuracy, cost, and effect. Expertise can be mistaken. Strength can be overextended. Protection can become control. Authority can exceed its task. A real capacity does not authenticate every use of that capacity, and criticism of its use does not require denial that the capacity is real.

Hierarchy concerns the organization of roles rather than a single comparative capacity. Some scenes require differentiated authority, decision rights, obligations, access, or responsibility. Emergency response, care, education, governance, technical coordination, institutional procedure, and high-risk action may become less safe or less integrable where every role is treated as interchangeable.

Genuine hierarchy has a corresponding signature:

```text
Genuine Hierarchy:
role-bounded
task-relevant
transparent
revisable
cost-aware
non-humiliating
Σ/Ψ-compatible
```

Role-bounded hierarchy attaches authority to a function rather than to the total standing of its holder. The authority concerns what the role is responsible for and does not automatically extend to unrelated domains. Task relevance keeps the hierarchy connected to the coordination problem that warrants unequal authority.

Transparency makes the source, scope, and responsibility implications of hierarchy legible. It does not require that every decision be negotiated symmetrically. It requires that unequal authority not be disguised as natural worth, moral superiority, or consequence-free competence.

Revisability preserves the possibility that a hierarchy can change when capacity, role, risk, information, or institutional conditions change. A hierarchy may be durable without becoming ontological. What matters is that duration does not make its scope immune to correction.

Cost-awareness keeps hierarchy answerable to what it distributes. Concentrated authority may reduce uncertainty while increasing exposure to error, dependence, obedience costs, or the burden carried by those with less decision power. These costs do not by themselves invalidate the hierarchy, but they remain part of the structure it must coordinate.

Non-humiliating hierarchy preserves standing across unequal roles. Direction, correction, refusal, or command within a bounded field need not become degradation. Hierarchy becomes dignity-damaging where task difference is translated into lesser worth, generalized incapacity, childlike status, or loss of legitimate voice.

Compatibility with Σ (integration) and Ψ (self-binding) distinguishes functional hierarchy from authority capture. Integration remains open where the hierarchy can receive the costs and effects it produces. Self-binding remains active where the authority-bearing position is durably attached to the consequences and limits of its decisions rather than binding only those below it.

Genuine hierarchy becomes drift where bounded responsibility converts into general authority, critique closure, D (dignity-in-practice) erosion, or other-control without corresponding Ψ (self-binding). The problem is not that one role-position directs another. The problem is that task-relevant authority expands beyond its field while responsibility for its effects becomes weaker rather than stronger.

This distinction preserves legitimate authority without immunizing it. Some scenes require decisions under unequal information or risk. Delay may itself produce harm. A role-position may therefore have authority to decide, refuse, restrict, protect, or intervene within a defined field. That authority remains functional where it is proportionate to the task, answerable to consequence, and open to correction.

The boundary can be stated directly:

```text
EDEN is anti-false-coordination,
not anti-asymmetry,
anti-competence,
anti-authority,
or anti-hierarchy as such.
```

This boundary also prevents equalization through suspicion. Refusing to recognize real competence can impose costs on the very positions that require accurate coordination. Treating every exercise of strength as domination can make protection unavailable. Treating every hierarchy as capture can hide who actually carries decision risk and responsibility. Critique remains necessary, but it must address the use and coordination of capacity rather than devalue capacity itself.

Genuine superiority and genuine hierarchy therefore remain possible where difference is local, functionally relevant, responsibility-increasing, dignity-preserving, and criticizable. The opposite appearance requires the same boundary discipline: silence, delay, openness, and non-action.

### 18.5 Genuine Non-Action, Legitimate Openness, and Neutrality

Not every absence is a structuring non-event. Not every silence allocates responsibility. Not every delay shifts cost, and not every refusal to bind transfers self-binding load. A framework that makes indirect structuring visible must also preserve genuine absence, restraint, incapacity, uncertainty, and non-capture.

The core boundary is:

```text
Non-action,
silence,
delay,
and openness
are not automatically praxis-drift.

They become EDEN-relevant only where they structure
□/Λ/Ω/Θ costs,
options,
responsibility,
or binding load.
```

Non-action becomes structurally relevant only within a scene that gives the absence significance. A missing response may matter because a commitment, role, expectation, dependency, risk, or available alternative made the response consequential. Without that structure, absence remains absence rather than a hidden form of action.

The neutrality boundary can be tested through the following conditions:

```text
Genuine non-action / neutrality:
no relevant frame expectation
no meaningful Λ
no affected Ω
no Θ accumulation
no shifted cost
no shifted option burden
no presupposed Ψ
no available alternative
```

No relevant □ (frame) expectation means that the scene contains no role, commitment, norm, or established dependency that makes the omitted event structurally expected. A reply that was never promised, a decision outside a role-position’s authority, or participation never undertaken cannot be treated as equivalent to withholding an expected act.

No meaningful Λ (non-event) means that the absence does not acquire structural significance through expectation. A non-event is not simply something that did not happen. It becomes meaningful where the scene was organized around its possible occurrence, where its omission changes available action, or where unresolved expectation continues to structure the relation.

No affected Ω (asymmetry) means that the absence does not alter an operative distribution of capacity, exposure, obligation, protection, dependency, timing, access, or cost. Silence may occur without increasing another position’s exposure. Delay may occur without controlling timing. Non-participation may remain outside the field that distributes responsibility.

No Θ (temporality) accumulation means that an isolated absence does not become a trajectory merely because it can be retrospectively interpreted. A delayed response may be accidental, constrained, or inconsequential. Repetition and duration matter only where they accumulate effects rather than merely recur as similar appearances.

No shifted cost or option burden means that the absence does not force another role-position to absorb uncertainty, maintain continuity, forgo alternatives, increase vigilance, or carry additional decision pressure. An absence can be noticeable without reorganizing what others must bear or can still choose.

No presupposed Ψ (self-binding) means that the scene contains no prior commitment, role obligation, or self-adopted relation that would make continued binding structurally relevant. Openness is not non-binding drift merely because commitment is absent. Where no binding was undertaken or reasonably presupposed, another role-position cannot treat the absence of commitment as a displaced obligation.

No available alternative limits responsibility without making every effect unreal. If a role-position could not act, respond, decide, disclose, remain, or withdraw differently under the actual conditions, then non-action cannot be interpreted as strategic choice merely from its consequences. Capacity and alternative possibility remain necessary to responsibility attribution.

The three levels must remain distinct:

```text
mere absence
≠ structuring non-event
≠ integrated abstention
```

Mere absence has no relevant structuring role. A structuring non-event shapes the scene through expectation, asymmetry, temporality, cost, options, or binding load. Integrated abstention is a deliberate or role-coordinated non-enactment that enters shared responsibility and remains answerable to its effects. Structural relevance therefore does not collapse all three levels into action.

Even where non-action becomes praxis-relevant, it does not thereby become E (strict Action / Enactment). Silence, delay, refusal, or withholding may shape a scene without possessing the integrated directedness required by strict enactment. The distinction protects the breadth of praxis analysis without silently redefining action.

The practical guardrails remain concise:

```text
Silence can be restraint.
Delay can be legitimate.
Non-binding can be honest openness.
Non-action can be mere absence.
```

Silence can preserve Χ (distance), prevent escalation, protect confidentiality, or mark uncertainty where speech would overstate available knowledge. It can also result from incapacity, fear, shock, divided obligation, or lack of a safe channel. None of these possibilities proves neutrality, but each defeats an automatic inference from silence to steering or evasion.

Delay can be legitimate where information is incomplete, capacity is temporarily reduced, several duties conflict, or premature action would increase harm. Delay becomes structurally relevant where control over timing shifts costs or options under conditions in which another response was available. Duration alone does not decide the question.

Non-binding can be honest openness where no commitment has been represented, implied, or structurally relied upon. A role-position may remain uncertain, decline premature closure, refuse an unsuitable obligation, or preserve revisability without shifting a binding burden onto another. Formal openness becomes drift only where its practical costs depend on another position carrying the continuity it leaves unresolved.

Legitimate openness has a bounded signature:

```text
Legitimate openness:
bounded
communicated where needed
not cost-shifting
not indefinitely Λ-producing
not responsibility-evading
not blocking Σ/Ψ
```

Bounded openness has a legible domain. It does not turn uncertainty in one respect into indefinite suspension of every related responsibility. Communication matters where another role-position’s options, exposure, or commitments depend on knowing that openness remains. This is a structural condition of coordinability, not a demand for disclosure without limit.

Openness is not cost-shifting where its uncertainty is not maintained by another position’s waiting, explanation, continuity, or restraint. It is not indefinitely Λ (non-event)-producing where unresolved expectation does not become the durable organization of the scene. It is not responsibility-evading where effects remain answerable despite the absence of commitment.

Openness does not block Σ/Ψ where costs and consequences can still enter Σ (integration), and where relevant role-positions remain capable of Ψ (self-binding) to the effects they actually structure. The scene need not force closure in order to remain reciprocal. It must only avoid making uncertainty possible through another position’s unacknowledged burden.

The decisive rule is therefore limited:

```text
No Passive Praxis applies only where non-action structures a scene under □/Λ/Ω/Θ.
```

This rule does not infer motive. Structuring silence may be intentional, confused, constrained, protective, or only partly understood. Its relevance depends on what it does within the scene, while responsibility still depends on legibility, capacity, alternatives, temporality, and asymmetrical cost. Structural effect cannot be reduced to strategy attribution.

The boundary also protects refusal and non-participation. A role-position may legitimately decline a demand, exit an arrangement, preserve privacy, refuse overbinding, or remain outside a scene. Such moves can have effects without becoming drift by default. The analysis must still ask whether the role-position had entered a responsibility-bearing relation and whether its withdrawal falsely coordinates the resulting cost.

The governing prohibitions follow:

```text
No guilt-by-silence.
No “all non-response is steering.”
No moralization of delay.
No erasure of restraint.
No overextension.
```

Genuine non-action, legitimate openness, and neutrality establish that EDEN does not own every consequential absence. Where the required structure is missing, the reading must release the absence. Where another account explains the scene more accurately, that account must be allowed to prevail.

### 18.6 Rival Explanations

Genuine non-capture becomes methodologically consequential only where another account is allowed to explain the scene better. A rival explanation is not an ornamental alternative added after an EDEN reading has already been secured. It identifies a different structure that may account for the decisive effects with greater specificity, stronger evidence, fewer unsupported inferences, or less distortion.

The governing principle is:

```text
EDEN weakens where a rival framework explains the scene better.
```

“Better” does not mean more familiar, more comforting, or less critical. It means that the rival account identifies the operative conditions more accurately, explains more of the relevant evidence, distinguishes causes from appearances more carefully, and requires fewer assumptions that the scene cannot support. A rival explanation may be severe while still being more accurate than EDEN.

Rival explanations can concern several different explanatory levels:

```text
institutional role or constraint
economic pressure
law
trauma
illness
direct violence
acute crisis
ordinary misunderstanding
asymmetric information
task-specific skill limitation
fatigue or incapacity
material constraint
developmental constraint
external coercion
conflicting duties
cultural mismatch
```

Institutional explanations become stronger where formal roles, procedures, sanctions, workload, or access rules organize the scene more directly than a local drift configuration. A role-position may appear controlling because it carries a non-negotiable legal or institutional obligation. Another may appear non-binding because its authority is formally limited. The resulting costs can be real without arising primarily from false coordination within the local relation.

Economic and material explanations become stronger where scarcity, housing, employment, debt, care burden, time pressure, or unequal access to resources constrains the available options. Such pressure may intensify asymmetry, waiting, dependence, or exposure. But an explanation centered on material constraint may account for those effects more precisely than one centered on recognition, protection, or comparison drift.

Legal explanations become stronger where rights, duties, liability, confidentiality, procedural limits, or mandated protection determine what role-positions can do. A legal structure may itself remain criticizable, but its effects should not be redescribed as local responsibility evasion merely because the participants cannot alter them from within the scene.

Trauma, illness, and acute crisis can alter perception, capacity, timing, exposure, and available alternatives. These conditions may explain withdrawal, reduced responsiveness, heightened protection, inconsistent participation, or narrowed self-binding without making those effects fictitious. EDEN becomes overextended if it translates every such limitation into immunity, steering, or responsibility displacement before the rival account has been tested.

Direct violence or coercion can dominate the explanatory field. Where a role-position acts under threat, force, confinement, or credible danger, the primary structure may be coercion rather than false coordination through parity, recognition, or non-binding. A reciprocity analysis may still identify consequences, but it must not blur the difference between indirect drift and direct constraint.

Ordinary misunderstanding remains possible. Participants may hold inaccurate but revisable beliefs about what was promised, intended, known, or expected. If clarification corrects the scene without persistent responsibility displacement, blocked integration, or weakened self-binding, a stronger drift account adds complexity without improving explanation.

Asymmetric information may produce similar appearances. One role-position may know about a risk, cost, decision, or prior event that another cannot see. The resulting asymmetry can make action appear arbitrary, protection excessive, delay evasive, or criticism uninformed. If the distribution of information explains the divergence, the analysis should not infer a value frame or responsibility shield without further evidence.

Task-specific skill limitation differs from generalized incapacity. A role-position may fail to coordinate, explain, decide, or respond effectively because it lacks a relevant skill or because the task exceeds its present capacity. That limitation may still generate costs and responsibility questions. It does not by itself establish a drift identity, deficient personhood, or stabilized frame.

Fatigue and incapacity can narrow attention, patience, integration, and response capacity. A delayed answer, reduced self-binding, or failed correction may arise because the role-position lacks sufficient resources at that point in Θ (temporality), not because it is strategically preserving ambiguity. Temporality matters, but temporal consequence alone does not decide which explanation is primary.

Conflicting duties can produce apparent non-binding or inconsistency. A role-position may remain bound to several obligations that cannot all be enacted simultaneously. What appears as withdrawal from one relation may be the cost of responsibility elsewhere. The scene still requires cost tracing, but responsibility should not be assigned as if only one obligation existed.

Cultural mismatch can organize expectations about speech, authority, care, timing, privacy, protection, and disagreement without necessarily producing false coordination. Cultural explanation must not become a blanket excuse or an essence claim about groups. It becomes relevant where differing learned conventions explain the scene more accurately than a claim of deliberate rank, immunity, or evasion.

Developmental constraints can alter capacity, dependency, foresight, self-binding, and responsibility without becoming a global maturity ranking. Stage-specific capacity may require asymmetrical protection or authority. The relevant analysis remains tied to actual ability, alternatives, exposure, and effect rather than converting developmental difference into lesser standing.

Theological, symbolic, feminist, masculinity, sociological, historical, or phenomenological accounts may also be stronger in particular scenes. Their inclusion as rivals does not require their full development here. It requires only that EDEN not claim explanatory priority where another framework preserves decisive distinctions or evidence that EDEN would flatten.

Rival explanations need not be mutually exclusive. Institutional pressure may intensify an already difficult relation. Trauma may coexist with responsibility displacement. Material scarcity may increase comparison susceptibility. Direct power and false coordination may operate together. The methodological task is not to select one explanation by rule, but to determine which account carries the decisive explanatory burden and which remains secondary.

Partial fit therefore requires restraint. EDEN may illuminate one feature of a scene while failing to explain its central cause. It may identify cost externalization without explaining why the cost arose. It may identify blocked correction while another framework better explains the blockage. Explanatory contribution does not establish explanatory primacy.

Several distinctions keep the regime claim proportionate. Postfeminist Override (PFO) is one possible stabilization of reciprocity loss, not a requirement for every local drift. False-coordinated real Ω (asymmetry) can occur without PFO, and the presence of a switch does not establish regime-level stabilization.

The distinctions can be stated compactly:

```text
False-coordinated real Ω can occur without full PFO.
A switch may be present without regime stabilization.
Drift may occur without humiliation.
External stress may explain the cost distribution better.
```

Local drift without a full regime may arise where a scene repeatedly miscoordinates responsibility and self-binding but has not stabilized a broader frame. The stronger local claim may be supported while the regime claim fails. Refusing that distinction would make every recurring switch evidence for a structure larger than the scene can establish.

Drift may also stabilize without humiliation or devaluation. Exit, isolation, reduced contact, withdrawn obligation, or procedural separation may preserve a damaged configuration without lowering a role-position’s standing. If the analysis requires devaluation where the scene instead stabilizes through separation, it has specified the wrong mechanism even if reciprocity remains impaired.

External institutional stress can create responsibility overload, delayed correction, reduced integration, and weakened self-binding without local regime logic being primary. Throughput pressure, administrative failure, scarcity, or incompatible role demands may organize the same observable costs. The rival explanation becomes stronger where those external conditions change the scene more directly than its internal recognition or protection frames.

Real Ω (asymmetry) can also be mishandled by the position with greater capacity or leverage. In such a scene, the decisive movement may begin with overextension, unsafe authority, or failure of restraint rather than with the vulnerability, protection, or non-binding of another position. An account that starts from the more exposed or less powerful position would then invert the responsibility structure it is meant to clarify.

Non-capture cases remain equally important. Comparison can be functional. Vulnerability can be genuine without immunization. Protection can remain responsibility-compatible. Hierarchy can remain bounded. Local superiority can increase answerability without becoming rank. Non-action can remain neutral. Openness can remain honest. A legitimating frame can accurately describe the structure rather than conceal it.

These alternatives do not disprove EDEN in general. They defeat or narrow a particular reading where they explain the scene better. Boundary discipline concerns the validity of the actual claim, not the survival of the framework at all costs.

A rival check fails methodologically if every alternative is redescribed as a hidden instance of EDEN. Institutional pressure cannot automatically become an expression of false coordination. Trauma cannot automatically become immunization. Cultural difference cannot automatically become rank drift. Requests for evidence cannot automatically become resistance to criticizability. A framework that absorbs every rival ceases to have rivals.

The admissible outcomes are therefore plural. The EDEN reading may remain strongest. It may need to be narrowed to one mechanism. It may become secondary to another explanation. It may need to be suspended pending evidence. Or the scene may not belong to EDEN at all.

Rival explanations become operational through counter-scenes. The relevant question is not merely whether another account can be named, but what evidence would support it, what evidence would weaken the EDEN reading, and whether the alternative is genuinely allowed to change the result.

### 18.7 Counter-Scene Protocol

A rival explanation becomes methodologically effective only when it can be placed against the proposed reading as a genuine alternative. Naming several possible causes is not enough. The analysis must specify a counter-scene in which the available facts support a materially different structural account.

The entry condition is:

```text
Every strong EDEN reading must test at least one counter-scene
where the same facts do not imply false-coordinated real Ω.
```

A counter-scene is not simply an imagined situation in which different facts would produce a different outcome. It uses the relevant evidence already available and asks whether that evidence can be organized more accurately through another configuration. Additional evidence may later discriminate between the readings, but the counter-scene begins by refusing to treat the first interpretation as self-validating.

The counter-scene must be plausible enough to compete. An implausibly weak alternative only strengthens the initial reading by design. A protection claim cannot be tested against the suggestion that nothing matters. A responsibility-displacement claim cannot be tested against an account that ignores every structuring effect. The strongest counter-scene preserves the difficult facts while explaining them differently.

The governing rule is:

```text
A counter-scene must be able to change the reading.
Otherwise it is decorative, not methodological.
```

Change can take several forms. The counter-scene may defeat the EDEN reading entirely. It may narrow the reading to one local mechanism. It may redirect responsibility toward a different structuring effect. It may show that a regime claim exceeds the evidence. It may preserve the descriptive relevance of EDEN while assigning explanatory priority to another framework.

The core questions are:

```text
Could this be genuine vulnerability?
Could this be genuine protection?
Could this be genuine hierarchy?
Could this be genuine superiority?
Could this be genuine non-capture?
Could this be neutral non-action?
Could non-binding be legitimate openness?
Could the legitimation frame be accurate?
Is responsibility truly displaced?
Is Σ/Ψ truly blocked?
Is the alleged immunized side actually exposed?
Is the alleged overexposed side actually exerting unchecked power?
Is a rival explanation stronger?
```

The first group tests whether a drift category has absorbed a genuine case. Vulnerability may be real rather than immunizing. Protection may preserve dignity and responsibility rather than shielding effect. Hierarchy may be role-bounded and functional. Superiority may remain local, field-specific, and responsibility-increasing. If any of these counter-scenes explains the structure better, suspicion cannot substitute for further evidence.

Genuine non-capture is broader. It asks whether the scene belongs to another explanatory field or resists the available categories altogether. Non-capture is not analytical failure. It is a valid outcome where the scene lacks sufficient evidence of false coordination, where the decisive structure lies elsewhere, or where translation into EDEN would erase distinctions the scene requires.

The non-action questions test whether absence has been overread. Silence may be restraint, incapacity, uncertainty, or non-involvement. Delay may be legitimate. Non-binding may be honest openness. A missing event may lack the expectation, asymmetry, temporal accumulation, shifted cost, option burden, or available alternative required for structural relevance.

The legitimation question asks whether the frame accurately describes a real constraint, duty, protection need, authority relation, or distribution of capacity. Legitimation can stabilize evasion, but it can also make a functional structure intelligible. The existence of a justification does not prove either integration or concealment. Its relation to real effects must be tested.

The responsibility question returns the analysis to R (responsibility). Is responsibility actually displaced, or does it follow real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions? A counter-scene may reveal that unequal responsibility is proportionate rather than distorted.

The integration and self-binding question must likewise remain evidentiary. Are Σ (integration) and Ψ (self-binding) actually blocked, or are costs entering a shared frame while relevant role-positions remain attached to their effects? Conflict, delay, or imperfect coordination does not establish blockage where correction remains possible and consequential.

The position-reversal questions prevent one-directional closure. An allegedly immunized role-position may in fact be highly exposed, insufficiently protected, or carrying responsibility beyond available legibility. An allegedly overexposed position may possess unchecked capacity, control access, or externalize costs while using its own burden as protection from criticism. Neither reversal is presumed. Each is a counter-scene that must be tested against evidence.

The rival-explanation question asks whether another framework carries the decisive burden more successfully. Institutional constraint, trauma, direct violence, material pressure, legal obligation, ordinary misunderstanding, conflicting duties, or another adjacent framework may account for the scene more precisely. A counter-scene becomes stronger where it preserves more evidence while requiring fewer speculative inferences.

The minimum protocol is:

```text
Name the EDEN reading.
Name the strongest counter-scene.
Specify what evidence would support it.
Specify what evidence would defeat the EDEN reading.
Do not proceed if the counter-scene cannot matter.
```

Naming the EDEN reading requires precision about what is actually being claimed. A claim of false coordination is not identical with a claim of responsibility displacement. A local switch is not a regime. Immunization is not the same as genuine protection. The reading cannot be tested if its scope changes whenever contrary evidence appears.

The same condition binds regime-level claims about Postfeminist Override (PFO):

```text
A PFO reading must be able to fail.
If counter-scenes cannot change the reading,
PFO has become a verdict frame,
not an analytic category.
```

Naming the strongest counter-scene means selecting the alternative most capable of explaining the difficult evidence, not the one easiest to dismiss. The counter-scene may preserve real harm, unequal capacity, consequential non-action, or asymmetric cost while contesting the mechanism through which those facts have been organized.

Evidence supporting the counter-scene must be specified before the alternative is rejected. Relevant evidence may concern actual capacity, credible danger, legal constraint, role obligation, available alternatives, communication, cost distribution, repeated trajectory, correction history, or the effects of changed conditions. The required evidence depends on the competing structural claims.

Evidence that would defeat the EDEN reading must be more than a request for additional information. It must identify a condition whose presence would materially weaken or reverse the claim: responsibility remains attached to effect, protection remains bounded, non-action does not structure options, integration remains open, the alleged pattern does not recur, or a rival explanation fits better.

The final protocol line prevents token testing. If no possible answer to the counter-scene could change the reading, the initial account has been insulated from correction. The alternative has been mentioned, but it has not been admitted as a methodological competitor.

Counter-scenes also bind the analyst. A reading may become attractive because it organizes many prior observations, names an otherwise obscure burden, or appears to explain recurring asymmetry. Those strengths can increase commitment to the reading. They do not reduce the obligation to test whether the framework is overfitting the scene.

The discipline can be stated directly:

```text
Counter-scene is not politeness.
Counter-scene is a methodological exposure to non-capture.
```

Counter-scene exposure does not require EDEN to accept every objection. An alternative may fail because it ignores evidence, cannot explain responsibility distribution, depends on an implausible account of capacity, or leaves blocked correction unexplained. The requirement is not deference to objection. It is genuine vulnerability to a stronger reading.

The counter-scene protocol becomes decisive only when paired with explicit falsifiers. Its decisive question is not whether an alternative has been considered, but what conditions would make the EDEN reading fail.

### 18.8 Falsifiers

A falsifier identifies a condition under which a specified EDEN reading cannot retain its original strength. It is stronger than general uncertainty, incomplete information, or the possibility that more evidence may appear. It states what the reading depends on and what would happen if that dependency were absent or contradicted.

The principal falsifiers are:

```text
Ω is minimal or absent.
The alleged non-action does not structure costs or options.
Responsibility remains properly attached to effect.
Critique remains possible.
Σ/Ψ are robustly open.
Protection is bounded and responsibility-compatible.
Vulnerability remains criticizable without degradation.
Hierarchy is bounded and functional.
Rival explanation is stronger.
The alleged pattern is not repeated or consequential.
Counter-scene explains the scene better.
```

Minimal or absent Ω (asymmetry) defeats a reading that depends on action-relevant asymmetry. Difference, disagreement, discomfort, or symbolic contrast cannot substitute for a consequential gradient of capacity, exposure, obligation, protection, dependency, timing, access, or cost. If such a gradient is not present, the framework lacks its central object.

An alleged non-action fails as an EDEN mechanism where it does not structure costs or options. Silence, delay, non-response, refusal, or absence may be noticeable without changing another role-position’s exposure, choices, obligations, timing, or binding load. Without that effect, structural relevance has not been established.

Properly attached R (responsibility) defeats a responsibility-displacement claim. If answerability follows real structuring effect under available legibility, capacity, alternatives, Θ (temporality), and Ω (asymmetry) cost or exposure, then unequal responsibility may remain accurate. The analysis cannot infer distortion merely because the distribution is asymmetrical.

Possible critique weakens a claim of lost correctability. Critique need not be comfortable, immediately accepted, or conflict-free. It remains possible where proportionate correction can reach the relevant effect, where disagreement can alter the account, and where criticism does not automatically become threat, degradation, or expulsion.

Robustly open Σ (integration) and Ψ (self-binding) defeat a claim that the scene cannot coordinate its own costs and effects. Integration may remain incomplete while still receiving relevant truths. Self-binding may remain contested while consequential role-positions continue to attach themselves to what they structure. Imperfection is not blockage.

Bounded and responsibility-compatible protection defeats a claim of immunization where the protective frame remains specific, cost-aware, revisable, and open to proportionate answerability. Genuine vulnerability remains a falsifier where it can be criticized without degradation and protected without categorical exemption from responsibility.

Bounded and functional hierarchy defeats a claim of authority capture where unequal roles remain task-relevant, transparent, revisable, non-humiliating, and answerable to their effects. Local superiority does not become rank merely because it affects who decides or carries greater responsibility.

A stronger rival explanation defeats explanatory priority. EDEN may still illuminate a secondary feature, but it cannot remain the governing account where another framework explains the decisive evidence more specifically and with fewer unsupported assumptions.

Lack of repetition or consequence defeats claims that depend on drift, accumulation, or stabilization. A single event may be harmful, mistaken, or structurally relevant without constituting a recurring pattern. The analysis must reduce its scope where the temporal claim is not supported.

A counter-scene that explains the scene better defeats the original reading rather than merely supplementing it. This is the practical meaning of non-capture. The framework must be able to release a claim when its own counter-test succeeds.

The strongest positive falsifier gathers the central conditions:

```text
If real Ω is acknowledged,
R follows structuring effect,
Σ integrates cost,
Ψ is self-bound,
Χ remains available,
D is preserved,
and counter-scenes remain possible,
then the EDEN drift claim weakens or fails.
```

This formula does not require a scene without asymmetry, conflict, pain, hierarchy, vulnerability, or unequal burden. It requires that real structure remain nameable, responsibility remain attached to effect, costs remain integrable, consequential positions remain self-bound, revision remain possible, dignity remain protected, and alternative readings remain capable of changing the analysis. Under those conditions, the defining drift is not established strongly enough.

The evidentiary limits are correspondingly strict:

```text
No concept may replace evidence.
No pattern may replace scene-bound evidence.
No protection frame may replace responsibility.
No performance may replace dignity.
No EDEN label may replace scene analysis.
```

These limits work in more than one direction. A protection frame cannot erase responsibility, but a responsibility claim cannot erase genuine protection. Performance cannot compensate for degradation, but dignity cannot become immunity from criticizability. A pattern may guide attention, but it cannot establish the facts it requires.

D (dignity-in-practice) has two distinct statuses here. Within a scene, actual or credibly anticipated degradation may support an EDEN reading only where it forms part of a traceable configuration of false coordination, responsibility displacement, blocked integration or self-binding, and weakened correctability. D-erosion alone neither establishes nor falsifies EDEN.

As a methodological condition, D is stricter. An analysis that shames, ranks, humiliates, or ontologically devalues a role-position is not admissible as an EDEN analysis. Where an EDEN reading is used to steer, bind, obligate, prescribe, confront, accuse, intervene, or enforce, suspension of dignity-in-practice makes that application methodologically invalid.

```text
D-erosion within a scene is evidence only within a traceable configuration.
D-erosion alone does not establish EDEN.
Humiliation by the analysis is a method failure.
Application without dignity-in-practice is methodologically invalid.
```

The model-risk condition is therefore explicit:

```text
If no falsifier can be named,
the EDEN reading is methodologically unsafe.
```

And:

```text
If EDEN cannot name what would defeat its reading,
EDEN is not being used methodologically.
```

A model of reciprocity loss must not immunize itself against reciprocity in its own use. It cannot criticize blocked correction while making itself uncorrectable. It cannot criticize recognition without responsibility while demanding recognition without evidentiary answerability. It cannot criticize externalized self-binding while requiring every rival framework to carry the burden of disproving a claim that EDEN itself has left unfalsifiable.

The boundary sequence is now complete. Genuine vulnerability, protection, superiority, hierarchy, non-action, openness, neutrality, and rival explanation remain possible. Counter-scenes can redirect the reading. Falsifiers can defeat it. EDEN therefore remains a scene-bound framework rather than a label that always confirms itself.

The final test is:

```text
The final test of EDEN is whether it can release a scene
when the scene does not belong to it.
```

Only after that release remains genuinely possible can EDEN-MAP, the paper’s scene-mapping protocol, organize an application without becoming a predetermined conclusion. The next stage therefore maps scenes under the boundary, counter-scene, and falsifier conditions established here.

---

## 19. EDEN-MAP: Application Protocol

### 19.1 Purpose and Status

The preceding boundary analysis established a necessary condition for application: EDEN must be able to release a scene when the scene does not belong to it. EDEN-MAP, the paper’s scene-mapping protocol, begins from that condition. It does not convert the framework into a device for identifying predetermined patterns. It organizes a bounded inquiry into whether a specified scene supports an EDEN reading and where that reading remains uncertain, revisable, or defeated.

EDEN-MAP is a scene-bound structural mapping protocol for testing whether false-coordinated real Ω (asymmetry), displaced R (responsibility), and blocked Σ (integration) or Ψ (self-binding) are present. It orders questions that the theory has already established. It adds no mechanism and no explanatory shortcut.

Its status can be stated directly:

```text
EDEN-MAP maps scenes.
It does not diagnose persons.
It does not rank sexes.
It does not authorize coercive action.
It does not replace counter-scene testing.
```

Mapping scenes means specifying role-positions, conditions, effects, costs, protections, alternatives, and temporal development. A role-position may participate in several scenes and occupy different structural locations across them. No result therefore becomes a global statement about a person, identity, group, or sex.

The same restraint applies to motive. EDEN-MAP may identify a frame that organizes costs or displaces responsibility without claiming that a participant consciously designed, intended, or endorsed that frame. It may show that non-action structures available options without translating structural effect into hidden strategy. It may map a recurring configuration without converting recurrence into character.

EDEN-MAP can make a structural reading more explicit. It cannot by itself make that reading binding. Structural clarity does not silently create permission to confront, accuse, prescribe, intervene, punish, or enforce. The transition from description to application remains separately constrained:

```text
Description may name structure.
Application requires Χ, reversibility, D, scene packet discipline, and contextual responsibility.
```

Here Χ (distance) requires that the reading remain distinct from urgency, verdict, enforcement, and person-level attribution. Reversibility requires that the account remain scene-bound, revisable, and non-final. D (dignity-in-practice) requires restraint under asymmetry: no shaming, ranking, humiliation, or ontological evaluation of persons or groups. Scene packet discipline requires sufficient structural information before the framework is applied at all.

These requirements do not make description weak. EDEN-MAP may identify consequential asymmetry, trace responsibility displacement, distinguish genuine protection from responsibility shielding, or show that one position carries costs generated elsewhere. It may also conclude that the evidence supports only a narrow mechanism, that another explanation is stronger, or that the scene cannot presently be mapped with sufficient confidence.

The protocol is therefore practical in a limited sense. It provides a disciplined order of inquiry. It does not provide a recommendation engine, therapeutic sequence, moral court, or verdict system. Its practical value lies in making structural questions answerable without making the resulting account self-authorizing.

The distinction is essential because the concepts used here are interpretively powerful. A label such as false coordination, immunization, overexposure, or non-binding can gather dispersed effects into a coherent pattern. That power creates a corresponding risk: the label may begin to replace the evidence it was meant to organize. EDEN-MAP counters that risk by beginning with a scene packet rather than a theory label.

### 19.2 Scene Packet

A scene packet defines the minimum input for EDEN-MAP. It prevents the protocol from being applied to an isolated sentence, a decontextualized action, a personal identity, a political affiliation, or an impression of resemblance. The packet does not prove that EDEN applies. It establishes whether there is enough structured material for the inquiry to begin.

The entry rule is:

```text
EDEN-MAP begins with a scene packet,
not a theory label.
```

The standard packet contains:

```text
actors / role-positions
dominant □
real Ω
relevant Λ
Θ trajectory
visible costs
available language
recognition structure
protection structure
responsibility distribution
Σ/Ψ status
counter-scene possibility
```

Additional fields become relevant where the scene involves indirect structuring:

```text
non-action relevance
non-binding relevance
legitimation frame
immunization / overexposure signals
asymmetric explanatory poverty signals
action-power distribution
```

Actors are recorded as role-positions because the relevant question is not who a person is in general, but what a position can structure within the specified scene. A participant may control timing in one relation while lacking language, protection, or access in another. Role-position language preserves this variability and prevents structural mapping from becoming identity attribution.

The dominant □ (frame) identifies the organization through which the scene becomes intelligible to its participants. Real Ω (asymmetry) identifies consequential differences in capacity, exposure, dependency, protection, timing, access, obligation, language, or cost. Relevant Λ (non-event) records absences that may matter because the scene was organized around an expected event. The Θ (temporality) trajectory records whether effects accumulate, recur, stabilize, weaken, or change across time.

These fields must remain connected. An absence is not structurally relevant merely because it can be named. An asymmetry is not consequential merely because two positions differ. A frame is not false merely because it is partial. The packet must make it possible to trace how conditions alter options, costs, exposure, responsibility, criticizability, or correction.

Visible costs include more than material loss. They may include waiting, uncertainty, explanation burden, vigilance, restricted options, delayed correction, exposure, self-control, or the need to preserve continuity. These costs must be attached to the scene rather than inferred from a preferred theory. A cost that cannot be connected to an identifiable condition remains an unsupported attribution.

Available language concerns whether a role-position can name its experience, burden, responsibility, or limitation in terms that remain legitimate within the scene. Missing language can make effects difficult to integrate without proving that another position has deliberately silenced them. The packet records both the available descriptions and the structural consequences of their absence.

Recognition and protection structures identify what each role-position is permitted to claim, contest, refuse, or require. Recognition may preserve standing while still discounting responsibility. Protection may preserve dignity while remaining compatible with criticizability. Neither category is treated as false in advance. Their relation to effect, cost, and responsibility must be mapped before any drift conclusion is drawn.

Responsibility distribution records where answerability is currently attached and where it is absent, delayed, displaced, or excessive. This is not yet the final responsibility assessment. The packet records the scene’s operative distribution so that later steps can compare it with real structuring effect under actual legibility, capacity, alternatives, temporality, and exposure.

The status of Σ (integration) concerns whether relevant effects and costs can enter a shared account. The status of Ψ (self-binding) concerns whether consequential role-positions remain attached to what they structure. The packet does not need to settle whether either is blocked. It must identify what evidence would support openness, blockage, simulation, avoidance, or externalization.

Counter-scene possibility belongs in the input rather than being added only after an EDEN reading has formed. The packet must preserve at least one plausible alternative organization of the evidence. Genuine vulnerability, genuine protection, legitimate hierarchy, ordinary misunderstanding, material constraint, direct coercion, or neutral non-action may explain the scene more accurately. If no alternative could matter from the beginning, the packet has already been organized as a conclusion.

The additional fields prevent visible action from monopolizing the map. Non-action may structure waiting or options. Non-binding may transfer ambiguity and self-regulation burdens. A legitimation frame may make a costly arrangement appear natural, fair, protective, autonomous, equal, or necessary. Immunization and overexposure signals may indicate coupled responsibility distortion. Asymmetric explanatory poverty may indicate that one position carries high exposure while lacking legitimate language for describing it. Action-power distribution records who can structure framing, timing, access, recognition, explanation, protection, cost, and binding.

None of these signals establishes a result. Their inclusion means only that the later protocol must test them. A non-action signal may prove to be mere absence. A protection structure may be genuinely necessary. Unequal responsibility may accurately follow unequal capacity. A legitimation frame may describe a real constraint. The packet preserves these possibilities so that mapping remains discriminative.

Χ (distance) and D (dignity-in-practice) are not merely additional descriptive fields. They govern whether a structural reading can be used beyond description. A packet may record that distance is costly or that dignity has been damaged within the scene. But the application itself must still preserve reflective distance, reversibility, and dignity-in-practice. Damage within the object of analysis cannot authorize the same damage in the method.

The hard input limits are therefore:

```text
No isolated-statement diagnosis.
No identity-based application.
No application by impression.
No theory label in place of a scene.
No frame-only reading without effects and costs.
No actor-only reading without asymmetry and temporality.
```

A completed scene packet remains a threshold, not a verdict. It establishes the material to be mapped and the alternatives that must remain possible. The first mapping task can then begin: identifying what real asymmetry structures the scene before asking whether that asymmetry has been falsely coordinated.

### 19.3 Real Ω Mapping

A scene packet establishes that there is enough structured material to begin. The first mapping task is to identify what real Ω (asymmetry) is present before asking whether its coordination has failed. This order prevents the framework from treating difference, inequality, vulnerability, authority, or unequal burden as evidence of drift in themselves.

The governing rule is:

```text
Map real Ω before evaluating false coordination.
```

Real asymmetry concerns consequential differences between role-positions. These differences may involve capacity, exposure, dependency, protection, obligation, access, timing, language, recognition, risk, or cost. They become relevant where they alter what a position can do, refuse, delay, absorb, contest, name, or require from another position.

The initial questions are:

```text
What asymmetry is real?
Who has capacity?
Who has exposure?
Who has protection?
Who has dependency?
Who has timing control?
Who has frame control?
Who has recognition control?
Who has binding control?
Who carries risk?
Who carries explanation burden?
Who can wait?
Who must respond?
Who can remain unclear?
Who must clarify?
Who pays for ambiguity?
```

These questions do not presuppose that the more capable position is always dominant, that the more exposed position is always passive, or that direct power exhausts structural effect. A role-position may possess material authority while carrying little control over recognition. Another may lack direct authority while controlling timing, access, explanation, or continued binding. The map must preserve such differences rather than compressing them into a single hierarchy.

Capacity includes the ability to act, decide, understand, prevent, communicate, withdraw, protect, or correct. Exposure includes susceptibility to harm, dependency, loss, public scrutiny, material cost, relational disruption, or consequences that cannot easily be absorbed. Protection concerns both available safeguards and the ability to claim them legitimately. Dependency concerns which options remain unavailable without another position’s cooperation.

Timing control matters because waiting is not distributed neutrally. One position may delay without significant cost while another must organize around uncertainty. One may control when clarification becomes possible, when a decision becomes binding, or when an unresolved effect can be revisited. Θ (temporality) becomes relevant where these differences accumulate into a trajectory rather than remaining incidental.

Frame control concerns the ability to define what the scene is about, which effects count, and which descriptions remain legitimate. Recognition control concerns whose standing, vulnerability, competence, injury, or responsibility can be acknowledged. Binding control concerns who can remain open, provisional, or uncommitted and who must nevertheless organize around that openness.

Language access is part of real asymmetry where one position can describe its burden in terms already recognized by the scene while another must first establish that its burden is intelligible. Explanation burden becomes asymmetric where one position’s account is presumed credible and another must continually justify its perception, restraint, reaction, or need for distance.

Cost distribution must be mapped independently of moral visibility. Highly visible action may carry less structural consequence than a delayed decision, withheld clarification, restricted access, or unacknowledged dependency. Conversely, indirect influence must not be presumed simply because visible power appears uneven. The map must show how an asymmetry changes options, costs, exposure, or responsibility.

Real Ω (asymmetry) may be embodied, institutional, economic, legal, relational, temporal, linguistic, or role-based. Several forms may operate at once. Their coexistence does not establish that they point in the same direction. One position may have greater formal authority while another has greater exit capacity. One may carry physical exposure while another carries explanation or continuity burden. Mapping must remain multidimensional enough to preserve these crossed asymmetries.

Sexed embodiment or sexed social positioning may be structurally relevant where it changes capacity, exposure, vulnerability, protection, expectation, or cost. It does not determine the complete responsibility distribution in advance. Bidirectionality is not symmetry, and non-symmetry is not one-sidedness. The map must remain tied to the actual scene rather than deriving role-position from sex alone.

The same restraint applies to vulnerability and protection. Genuine vulnerability can reduce capacity, narrow alternatives, increase response cost, or require asymmetrical protection. Genuine protection can change timing, access, criticizability, or responsibility without becoming false coordination. The map records these effects before deciding whether protection remains bounded and responsibility-compatible.

Action-power is likewise descriptive at this stage. The map asks who can structure conditions, not who should be blamed for possessing capacity. Greater capacity may later increase responsibility where it structures real effect, but capacity does not create ontological rank. Reduced capacity may limit responsibility without erasing every consequence a position produces.

The boundary condition is explicit:

```text
Asymmetry is not yet failure.
Real Ω must be mapped before it is judged.
```

If no real asymmetry is present, or if the identified difference is minimal and non-consequential, the EDEN reading weakens. Disagreement, discomfort, injury, unequal preference, symbolic contrast, or power difference alone cannot substitute for an asymmetry that structures the scene.

```text
If no real Ω structures the scene,
EDEN weakens or does not apply strongly.
```

A completed asymmetry map should therefore identify not only what is unequal, but what the inequality changes. It should show which options become available or unavailable, which costs become transferable, which exposures become protected or intensified, and which role-positions gain or lose access to correction. Only then can the protocol ask whether the scene coordinates those realities truthfully.

### 19.4 False Coordination Frame

After real asymmetry has been mapped, EDEN-MAP asks how the scene organizes it. The relevant question is not whether a frame exists. Every scene depends on frames that make roles, expectations, protections, responsibilities, and effects intelligible. The question is whether the operative frame coordinates real Ω (asymmetry) in a way that displaces R (responsibility) and blocks Σ (integration) or Ψ (self-binding).

The core configuration is:

```text
real Ω
+ false coordination frame
+ displaced R
+ blocked Σ/Ψ
= false-coordinated real Ω
```

A false-coordination frame does not make asymmetry unreal. It organizes real differences through a description that mislocates their effects, costs, responsibilities, or conditions of correction. The asymmetry remains operative while becoming difficult to name, integrate, criticize, or bind to the positions that structure it.

Relevant frame families include:

```text
comparison
protection
parity
superiority
vulnerability
responsibility
recognition
non-action / neutrality
non-binding / autonomy
legitimation
authority
```

None is false by category. Comparison can clarify a functional difference. Protection can preserve safety and dignity. Parity can secure equal standing. Superiority can name bounded competence. Vulnerability can identify real exposure. Responsibility can follow real effect. Recognition can preserve agency. Non-action can be restraint. Non-binding can be honest openness. Legitimation can accurately describe a lawful or functional arrangement. Authority can remain task-bound and answerable.

The governing boundary is therefore:

```text
A frame is not false simply because it is a frame.
A frame becomes false coordination when it organizes real Ω
in a way that displaces R and blocks Σ/Ψ.
```

The frame check asks:

```text
What frame organizes the scene?
Does it make real Ω speakable or unspeakable?
Does it attach R to real structuring effect?
Does it block proportionate critique?
Does it simulate Σ?
Does it support or externalize Ψ?
Does it preserve D?
Does it make costs appear fair, natural, protective,
equal, autonomous, or necessary?
Can the frame be revised?
Can a counter-scene change the reading?
```

A comparison frame becomes suspect where relative ranking replaces coordination of actual capacities, costs, or obligations. A protection frame becomes suspect where necessary protection expands into categorical exemption from responsibility for real effect. A parity frame becomes suspect where equal recognition conceals unequal burden, access, exposure, or binding load.

A vulnerability frame becomes suspect where real exposure is used to make consequential effects uncriticizable. This does not make the vulnerability false. It means that one truth has been organized so that another truth cannot enter the account. The test must therefore preserve the vulnerability while asking whether responsibility remains proportionately possible.

A responsibility frame can also become false coordination. Responsibility may be attached to visible reaction rather than prior structuring effect, to formal role rather than actual capacity, or to outcome alone rather than available legibility and alternatives. It may become authority over another position rather than self-binding to one’s own effect.

A recognition frame becomes false where acknowledged standing is separated from answerability. Recognition may remain genuine while responsibility is discounted, criticism is threat-coded, or another position carries the integration burden. Equal recognition does not require equal burden, but it does require that real effects remain nameable and criticizable.

A neutrality frame may conceal that non-action structures timing, access, uncertainty, or cost. An autonomy frame may conceal that one position’s non-binding requires another position to carry waiting, ambiguity, continuity, or self-control. These frames remain accurate where the absence is merely absence or the openness is genuinely bounded and communicated. Their falsity must be shown through effect, not inferred from non-action itself.

Legitimation operates where □ (frame) and Φ (recontextualization) make an arrangement appear fair, protective, equal, autonomous, neutral, necessary, or non-responsible. Legitimation is not automatically evasion. It becomes drift-relevant where the legitimating account stabilizes real structural effects while costs remain unintegrated and responsibility becomes less visible.

D (dignity-in-practice) is both a mapped scene condition and a constraint on interpretation. Actual or credibly anticipated degradation becomes EDEN-relevant only where scene-bound evidence shows that it changes criticizability, recognition, responsibility, integration, self-binding, or access to revision within an otherwise supported configuration.

The map must not infer fear, motive, or inner state from threatened degradation. Dignity erosion alone does not establish EDEN and is not an independent reciprocity-loss mechanism.

A frame may therefore be partial without being false. It may emphasize protection because danger is acute, authority because coordination is urgent, or autonomy because commitment has not been undertaken. Partiality becomes false coordination only where the frame systematically excludes structurally relevant effects and prevents their integration or self-binding.

The positive countercondition remains active:

```text
If the frame names real Ω,
keeps R attached to structuring effect,
keeps Σ/Ψ open,
preserves D,
and permits counter-scenes,
the false-coordination reading weakens.
```

The frame check produces a hypothesis, not a conclusion. It identifies how a scene may be coordinating real asymmetry and what evidence would support or weaken that reading. Responsibility and action-power must therefore be traced directly: who structures the relevant conditions, who has alternatives, who carries costs, and where answerability is currently attached.

### 19.5 Responsibility Mapping and Action-Power Check

Once real asymmetry and the possible coordination frame have been identified, EDEN-MAP must trace responsibility rather than infer it from visibility, identity, formal role, or declared intention. R (responsibility) follows real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions.

The governing formula is:

```text
R follows real structuring effect
under available legibility,
capacity,
alternative possibility,
Θ trajectory,
and Ω cost/exposure conditions.
```

Structuring effect concerns the conditions a role-position materially shapes: options, timing, access, exposure, protection, recognition, language, cost, criticizability, or binding. An effect may arise through direct action, but direct action is not the only way a scene is structured.

The action-power principle is:

```text
Power ≠ direct action alone.
Action-power = capacity to structure praxis conditions.
```

Action-power is not a new operator and not a general theory of power. It is a mapping term for identifying which role-positions can alter the conditions under which praxis occurs. It includes both overt capacity and less visible control over framing, timing, access, recognition, explanation, protection, or continued uncertainty.

The primary questions are:

```text
Who acted directly?
Who structured the frame?
Who controlled timing?
Who controlled recognition?
Who withheld recognition?
Who controlled access?
Who controlled explanation?
Who distributed costs?
Who benefited from ambiguity?
Who could bind?
Who refused or delayed binding?
Who had capacity?
Who had legibility?
Who had alternatives?
Who carried Ω cost or exposure?
```

These questions must be answered separately. A position that acts directly may not control the frame. A position that controls the frame may not control exit. A position that carries material risk may still control recognition or timing. A position with formal authority may be constrained by law, institutional duty, dependency, or limited alternatives. Collapsing these distinctions would replace mapping with a rank judgment.

The main action-power vectors are:

```text
direct action
non-action
frame control
timing control
recognition withholding
non-binding
gatekeeping
legitimation
protection framing
explanation withholding
cost distribution
access control
language control
binding control
```

Direct action includes decisions, demands, refusals, disclosures, restrictions, allocations, and other enactments that visibly alter the scene. Its visibility makes it easier to identify, but not automatically more consequential than indirect structuring. Direct action must still be assessed under actual capacity, knowledge, alternatives, timing, and exposure.

Non-action becomes an action-power vector only where an absence changes available options, costs, timing, exposure, or another position’s obligations. The present step records that possibility without deciding whether the absence is merely absent, structurally consequential, or integrated restraint.

Frame control concerns the capacity to define what kind of situation is occurring and which descriptions remain admissible. A position may be able to name an arrangement as equal, protective, autonomous, necessary, or neutral. That capacity becomes responsibility-relevant where the description changes what can be criticized, whose costs become visible, or which alternatives remain thinkable.

Timing control concerns the ability to initiate, postpone, accelerate, suspend, or indefinitely defer a consequential event. It includes control over decisions, clarification, commitment, correction, and access to review. Timing becomes action-power where one position can wait at low cost while another must organize around delay.

Recognition control concerns the ability to affirm or withhold another position’s standing, competence, vulnerability, injury, contribution, or responsibility claim. Recognition withholding may structure access to protection, credibility, correction, or participation. Recognition itself may also become a form of control where it is granted only under conditions that detach standing from responsibility or require another position to absorb the costs of recognition.

Non-binding becomes action-power where one position can remain open, ambiguous, provisional, or uncommitted while another must organize around that condition. The structural effect may include waiting, continuity work, self-control, reduced alternatives, or increased explanation burden. Non-binding does not become drift merely because commitment is absent. Its responsibility relevance depends on whether it structures the scene.

Gatekeeping includes control over participation, information, resources, institutional entry, channels of complaint, or access to decision-making. Formal gatekeeping may be legitimate and role-bound. It becomes responsibility-relevant because it changes what other positions can do, not because every restriction is false coordination.

Legitimation becomes an action-power vector where making a structure appear fair, protective, equal, autonomous, neutral, or necessary helps stabilize its effects. The relevant responsibility does not depend on proving bad faith. It depends on whether the legitimating account shapes costs, recognition, protection, options, or correctability.

Protection framing concerns the capacity to define which exposures count as harm, whose distance is legitimate, and which demands become impermissible. Such framing may be necessary and accurate. Its action-power lies in its ability to reorganize access, criticizability, timing, and responsibility. The map must therefore preserve genuine protection while tracing the effects of the protective arrangement.

Explanation withholding concerns more than silence. It concerns whether one position can withhold information necessary for another position to understand risk, expectation, cost, or available choice. A duty to explain cannot be presumed in every scene. Explanation becomes responsibility-relevant where relevant knowledge, role obligation, or dependency makes the withholding structurally consequential.

Cost distribution concerns who absorbs the consequences of action, delay, ambiguity, protection, correction, or non-binding. Costs may be material, temporal, relational, institutional, linguistic, or exposure-based. A role-position may not create the original difficulty yet still structure how its costs are transferred, concealed, concentrated, or left unbound.

Access and language control concern who can enter the relevant forum and whose descriptions are intelligible within it. A position may possess experience without having legitimate terms for naming it. Another may possess established language that makes its account immediately recognizable. This difference can affect criticizability and responsibility without proving deliberate exclusion.

Binding control concerns who can determine when commitment, self-limitation, or answerability becomes necessary. A position may bind another through rule, expectation, dependency, or cost while remaining less bound to its own effects. The map must distinguish legitimate coordination from a distribution in which other-binding expands as self-binding weakens.

The responsibility check therefore asks:

```text
Is R underassigned?
Is R overassigned?
Does R follow visibility rather than effect?
Does R follow identity coding rather than structuring effect?
Does R follow protection status rather than effect?
Does R follow reaction rather than prior condition?
Does R follow direct action only?
Does R ignore non-action or non-binding effects?
```

Underassigned responsibility occurs where a position’s real structuring effect remains weakly attached to answerability. Overassigned responsibility occurs where a position carries answerability beyond its legibility, capacity, alternatives, or contribution to the relevant effect. These two distortions may coexist. One position’s reduced answerability may increase the explanatory, regulatory, or corrective burden carried elsewhere.

Responsibility does not follow benefit alone. A role-position may benefit from an arrangement without having created, controlled, understood, or been able to alter it. Benefit becomes relevant where it is connected to capacity, available alternatives, continued participation, legitimation, or the ability to correct an effect.

Responsibility also does not follow intention alone. Harmful effects can remain responsibility-relevant without malicious purpose, while harmful intent without structuring capacity may fail to explain the scene’s actual organization. Intention may matter where evidence supports it, but it cannot substitute for effect tracing.

The same applies to causality. A position may contribute causally to an outcome without carrying responsibility for every consequence. Another may not initiate the event yet structure the conditions under which its costs persist. EDEN-MAP therefore distinguishes causal contribution, structuring effect, capacity, available alternatives, and responsibility rather than treating them as interchangeable.

The limits are explicit:

```text
R is not blame.
R is not guilt.
R is not mere causality.
R is not outcome-liability alone.

Responsibility remains real.
Responsibility remains bounded.
```

Available legibility limits responsibility where a role-position could not reasonably identify the relevant structure or consequence. Capacity limits responsibility where action, correction, restraint, or explanation was not possible. Alternative possibility limits responsibility where no viable option existed. Temporal trajectory limits responsibility according to what could have been understood at the relevant time. Exposure conditions limit responsibility where response would carry disproportionate danger or cost.

These limits are not automatic erasures. Limited legibility does not remove responsibility for effects that were partly visible or became visible over time. Reduced capacity does not make every remaining option irrelevant. High exposure may narrow what can reasonably be demanded without making all structuring effects non-answerable.

The boundary is:

```text
Responsibility attribution must track
available legibility,
relevant capacity,
and materially available alternatives.

Limits in these conditions limit the attribution;
they do not erase every responsibility relation by default.
```

Action-power can therefore increase or reduce responsibility without establishing rank. Greater capacity may increase responsibility where it enables prevention, correction, restraint, clarification, or protection. Reduced capacity may narrow responsibility where the same possibilities are unavailable. Neither movement establishes greater or lesser human worth.

Χ (distance) also affects action-power where one position can step back, revise, or suspend judgment while another’s distance is costly, unavailable, or delegitimized. The map may record this asymmetry. It must not infer that every demand for distance is avoidance or that every lack of distance is immaturity.

Responsibility mapping remains compatible with D (dignity-in-practice). Naming real structuring effect does not authorize humiliation. Protection from degradation does not erase responsibility, and responsibility does not require degradation. If responsibility can be asserted only by shaming, ranking, or ontologically diminishing a role-position, the analysis has left the application conditions of the framework.

The result of this stage is a distribution, not a sentence. It identifies where action-power appears, which effects it structures, what constraints limit responsibility, and where answerability may be underassigned or overassigned. It does not yet decide whether non-action or non-binding is genuinely praxis-relevant, nor whether the resulting distribution forms immunization or overexposure.

The most easily overextended vectors therefore require direct testing: what did not happen, whether the absence mattered, who organized around it, and whether non-binding shifted costs or self-binding load.

### 19.6 Non-Passivity and Non-Binding Check

Responsibility mapping identifies non-action and non-binding as possible action-power vectors. The present step determines whether either actually structures the scene. It prevents two opposite errors: treating only visible action as praxis, and treating every absence, silence, delay, uncertainty, or lack of commitment as hidden action.

The governing distinction is:

```text
No Passive Praxis ≠ every non-action is action.

Non-action becomes praxis only when it structures a scene
under □/Λ/Ω/Θ.
```

A non-action becomes structurally relevant where a □ (frame) establishes an expectation, a Λ (non-event) acquires consequence through its absence, an Ω (asymmetry) distributes the resulting options or costs unequally, and a Θ (temporality) trajectory allows the effect to accumulate or persist. The presence of one element alone is insufficient.

The operational questions are:

```text
What did not happen?
Was it expected?
Was the absence meaningful under the frame?
Did it affect real Ω?
Did it accumulate under Θ?
Who carried the absence?
Who had to adapt?
Who had to wait?
Who had to infer?
Who had to explain?
Who had to self-bind?
Was there a real alternative?
Could a counter-scene make it mere absence?
```

The first question is descriptive. It identifies an omitted response, decision, clarification, protection, correction, refusal, commitment, or other event without assigning meaning to the omission. The second asks whether the scene contained a role, promise, dependency, norm, or established expectation that made the event structurally relevant.

Expectation must be evidenced rather than projected. A response cannot be treated as withheld where none was promised or reasonably presupposed. A role-position cannot be assigned responsibility for a decision outside its authority. Participation that was never undertaken cannot silently become an obligation through another position’s preference.

A meaningful non-event exists where absence changes the scene. It may narrow options, prolong exposure, transfer decision pressure, maintain uncertainty, increase waiting, or require another position to preserve continuity. If nothing changes except retrospective interpretation, the absence has not yet been shown to structure praxis.

The asymmetry question asks whether the absence distributes its consequences unevenly. One position may remain free to delay while another must adapt immediately. One may remain unclear while another carries planning or exposure costs. One may withhold recognition without losing standing while another depends on recognition for access, credibility, or correction.

Temporality distinguishes an isolated omission from an accumulating trajectory. A missed response may be accidental, constrained, or inconsequential. Repetition alone is also insufficient. The relevant question is whether repeated or prolonged absence stabilizes a distribution of cost, responsibility, access, or binding load.

Alternative possibility remains necessary for responsibility. An omitted event cannot carry the same significance where incapacity, danger, legal restriction, missing information, conflicting duties, or lack of a safe channel removed the relevant option. Limited alternatives do not make the consequences unreal, but they constrain what responsibility can be attached to them.

The three-level distinction is:

```text
1. mere absence

2. structuring non-event

3. integrated abstention
```

Mere absence lacks the relevant scene conditions. No established frame makes the event expected, no meaningful non-event structures options, no consequential asymmetry distributes its costs, and no temporal accumulation turns it into a trajectory. It may remain noticeable without becoming praxeologically significant.

A structuring non-event changes the scene through its absence. It may become praxis-relevant because another position must wait, adapt, infer, decide, explain, or absorb costs. This does not make the absence equivalent to E (strict Action / Enactment). Praxis relevance is broader than integrated enactment.

Integrated abstention is a carried refusal or restraint with an organized relation among impulse, temporality, and integration. It may qualify as strict enactment where ∇ (impulse), Θ (temporality), and Σ (integration) form a coherent structure. Silence used to preserve confidentiality, refusal used to prevent harm, or restraint maintained under pressure may be active without being drift.

The distinctions can be stated more formally:

```text
mere absence
≠ structuring non-event
≠ integrated abstention
```

Non-binding requires a related but separate check. A role-position may remain open, undecided, provisional, or uncommitted without structuring another position’s praxis. Non-binding becomes relevant where another position must organize around it.

The questions are:

```text
Who remained open?
Who did not clarify?
Who did not decide?
Who did not answer?
Who did not bind?
Who carried the uncertainty?
Who organized around the non-binding?
Who bore timing cost?
Who bore risk?
Who had to regulate or explain?
```

Non-binding may shift Ψ (self-binding) load. One position remains less attached to the effects of continued ambiguity while another must increase planning, restraint, explanation, continuity work, or self-regulation.

```text
low Ψ on one side
→ increased Ψ-load on the other
```

The shift can be summarized as a structural relation:

```text
I do not bind myself,
but you must organize yourself around my non-binding.
```

This formula does not attribute intention. A role-position may be unaware of the shifted load, unable to bind, or operating under legitimate uncertainty. The claim concerns the distribution of effects. Intention becomes relevant only where independently supported.

Non-binding may be legitimate openness. Commitment may be premature, unsafe, impossible, or outside the relation’s established terms. Consent may require the continued possibility of non-binding. A role-position may need time, distance, information, or protection before binding becomes responsible.

Communication also has limits. Legitimate openness does not require exhaustive disclosure, constant availability, immediate decision, or compulsory explanation. The relevant question is whether the uncertainty remains bounded and whether its costs can become visible without turning openness into accusation.

The principal guardrails are:

```text
Non-action is not automatically drift.
Silence can be restraint.
Delay can be legitimate.
Non-binding can be honest openness.
Non-action can be mere absence.
Consent can require non-binding.
Boundaries can be legitimate.
```

Silence may preserve Χ (distance), prevent escalation, protect confidentiality, mark uncertainty, or reflect incapacity. Delay may be required by complexity, safety, conflicting duties, or insufficient information. Withdrawal may remove a role-position from a scene rather than secretly control it. Each possibility must remain available as a counter-scene.

The negative boundary is equally important:

```text
If there is no relevant □,
no meaningful Λ,
no real Ω affected,
no Θ accumulation,
no shifted cost,
and no Ψ-load displacement,
the No Passive Praxis reading weakens.
```

The result of this check should identify whether the scene contains mere absence, a structuring non-event, or integrated abstention; whether non-binding shifts costs or self-binding load; and which counter-scene could weaken that account. It should not classify a person as passive, evasive, uncommitted, or controlling.

### 19.7 Immunization / Overexposure Check

Once responsibility, action-power, non-action, and non-binding have been mapped, EDEN-MAP can test whether responsibility has become coupled unevenly with legibility and protection. Immunization and overexposure name scene-bound drift patterns, not identities or fixed role profiles.

Their compact definitions are:

```text
immunization:
effect without full responsibility

overexposure:
responsibility without full legibility / protection
```

Immunization concerns a configuration in which a role-position continues to structure real effects while those effects become categorically less criticizable or less connected to responsibility. Overexposure concerns a configuration in which a role-position carries responsibility, explanation burden, correction demand, or danger coding beyond available legibility, capacity, alternatives, or protection.

The immunization questions are:

```text
Is real effect shielded from responsibility?
Is critique reframed as harm?
Is vulnerability used to suspend criticizability?
Is protection cancelling agency?
Is recognition cancelling responsibility?
Is non-action appearing harmless while structuring?
Is non-binding appearing open while shifting Ψ-load?
Is the hurt-frame blocking proportionate correction?
```

A positive answer to one question is not sufficient. Critique may genuinely be harmful. Vulnerability may materially limit capacity. Protection may need to suspend ordinary demands. Recognition may correct prior degradation. The immunization reading requires a coupled pattern in which real effect remains operative while proportionate answerability becomes structurally unavailable.

The overexposure questions are:

```text
Is responsibility assigned beyond legibility?
Is responsibility assigned beyond capacity?
Is responsibility assigned beyond available alternatives?
Is reaction more accountable than prior structuring effect?
Is visible power replacing effect tracing?
Is explanation recoded as control?
Is boundary-setting recoded as threat?
Is Χ delegitimized?
Is legitimate language unavailable?
```

Here Χ (distance) becomes relevant where a role-position’s attempt to step back, qualify a claim, suspend judgment, or preserve a boundary is made structurally costly or illegitimate. Loss of distance can increase both exposure and the risk that responsibility language becomes coercive.

Immunization and overexposure may reinforce each other. When one position’s effects become difficult to criticize, another may carry more explanation, restraint, correction, or continuity work. When one position becomes overexposed, its reactions may become more visible and more accountable than the conditions to which it responds.

Asymmetric explanatory poverty names one possible component:

```text
high exposure
+ low legitimate language
+ critique-to-threat switch
+ responsibility overload
= asymmetric explanatory poverty
```

High exposure alone does not establish this configuration. The position must also lack legitimate language for naming the structure, encounter increased threat coding when it attempts to explain, and carry responsibility beyond what the scene makes legible or protected. The pattern remains evidentiary and scene-bound.

Recognition-without-responsibility can function as immunization in recognition mode. A position may receive recognition of standing, vulnerability, or injury while its consequential effects remain weakly attached to criticizability and self-binding. Recognition remains genuine, but it becomes falsely coordinated where responsibility is discounted as incompatible with that recognition.

D (dignity-in-practice) must be preserved in both directions. Immunization cannot be criticized through humiliation, and overexposure cannot be corrected by granting counter-immunity. Responsibility remains compatible with protection from degradation. Protection remains compatible with proportionate criticizability.

Actual or credibly anticipated dignity loss may support a coupled-drift reading only where its scene effects are traceable. The map may show that criticism is coordinated as degradation and thereby blocks correction, or that an attempt to preserve standing is coordinated as aggression, control, or threat and thereby increases exposure. Dignity loss alone does not establish the pattern, and no subjective fear or motive may be inferred from it.

The profile guardrail is categorical:

```text
Do not assign immunization or overexposure by sex in advance.
Profiles are scene-bound drift patterns,
not sex truths.
```

The accompanying restraint is:

```text
critique of female immunization
≠ male immunity

critique of male overexposure
≠ denial of male responsibility
```

These formulas prevent reversal. Showing that a female role-position is immunized in a specified scene does not establish male innocence, universal female immunity, or a general sex claim. Showing that a male role-position is overexposed does not erase male capacity, direct power, or responsibility. Every distribution remains scene-bound.

Counter-immunity occurs where criticism of one responsibility shield is used to create another. A position may respond to overexposure by claiming categorical exemption from criticizability, or respond to immunization by treating all vulnerability as manipulation. Such reversals reproduce the structure they claim to correct.

The boundary check is therefore:

```text
Is genuine vulnerability present?
Is genuine protection needed?
Is actual power present?
Is actual exposure present?
Is counter-immunity forming?
```

The positive falsifier remains active:

```text
If vulnerability is genuine,
protection is bounded,
R follows structuring effect,
Σ/Ψ remain open,
D is preserved,
and counter-scenes remain possible,
the immunization / overexposure reading weakens.
```

Here R (responsibility) remains attached to actual effect, Σ (integration) remains capable of receiving the relevant costs and protections, Ψ (self-binding) remains attached to consequential positions, and D (dignity-in-practice) constrains both criticism and protection. Under those conditions, unequal burden may remain difficult without constituting the coupled drift.

The result of this stage should identify whether responsibility is underassigned or overassigned, whose effects remain criticizable, whose exposure remains legible, what protection is genuine, and what evidence could reverse the reading. It must not output an immunized person, an overexposed identity, or a sex-based profile.

The map is now structurally complete enough to face its decisive test. Before any output is formulated, the proposed reading must be placed against the strongest counter-scene and explicit conditions under which it would weaken or fail.

### 19.8 Counter-Scene and Falsifier Step

The preceding stages produce a structured reading of the scene. They identify real asymmetry, a possible false-coordination frame, responsibility and action-power distributions, non-action or non-binding effects, and possible immunization or overexposure. None of these results becomes admissible output until the reading has been exposed to a counter-scene and explicit falsifiers.

The governing rule is:

```text
A counter-scene must be able to change the reading.
Otherwise it is decorative, not methodological.
```

A counter-scene reorganizes the relevant evidence through a materially different structural account. It does not merely imagine different facts, add a token objection, or name an implausibly weak alternative. It preserves the difficult evidence while testing whether another explanation accounts for it more accurately.

The minimum protocol is:

```text
Name the EDEN reading.
Name the strongest counter-scene.
Specify what evidence would support the counter-scene.
Specify what evidence would defeat the EDEN reading.
Do not proceed if the counter-scene cannot matter.
```

Naming the EDEN reading requires a bounded claim. A claim of false coordination is not identical with responsibility displacement. Responsibility displacement is not identical with blocked integration. A local switch is not a stabilized regime. The reading must specify what configuration is being proposed so that contrary evidence cannot be absorbed by silently changing the claim.

Naming the strongest counter-scene means selecting the alternative that explains the difficult evidence most effectively. The alternative may preserve real harm, unequal capacity, consequential non-action, asymmetric burden, or responsibility conflict while contesting the proposed mechanism. A counter-scene that ignores the central evidence is not a genuine competitor.

The required questions are:

```text
Could this be genuine vulnerability?
Could this be genuine protection?
Could this be genuine hierarchy?
Could this be genuine superiority?
Could this be genuine non-capture?
Could this be neutral non-action?
Could non-binding be legitimate openness?
Could the legitimation frame be accurate?
Is responsibility truly displaced?
Is Σ/Ψ truly blocked?
Is the alleged immunized side actually exposed?
Is the alleged overexposed side actually exerting unchecked power?
Is a rival explanation stronger?
```

The genuine-case questions test whether a drift category has absorbed a legitimate structure. Vulnerability may materially limit capacity. Protection may preserve dignity and responsibility. Hierarchy may remain task-bound and revisable. Superiority may remain local, field-specific, and responsibility-increasing. If those accounts fit the evidence better, the EDEN reading must narrow or yield.

Genuine non-capture remains a valid outcome. The scene may belong primarily to law, institutional constraint, economic pressure, illness, trauma, direct violence, conflicting duties, ordinary misunderstanding, cultural mismatch, or another explanatory field. EDEN may illuminate a secondary effect without carrying the scene’s principal explanatory burden.

The non-action counter-scene asks whether the alleged absence was actually expected, consequential, asymmetrically distributed, and temporally accumulating. The non-binding counter-scene asks whether openness was bounded, honest, and compatible with another position’s freedom rather than sustained through unacknowledged waiting or self-binding load.

The legitimation counter-scene asks whether the frame accurately describes a real constraint, duty, protection need, authority relation, or distribution of capacity. A structure may appear necessary because it is necessary under the available conditions. Justification does not prove either integration or evasion.

The responsibility counter-scene returns to R (responsibility). Responsibility may be unequal because capacity, legibility, alternatives, Θ (temporality), and Ω (asymmetry) exposure are unequal. An asymmetrical distribution does not establish displacement where answerability remains proportionately attached to real structuring effect.

The integration and self-binding counter-scene asks whether Σ (integration) and Ψ (self-binding) are actually blocked. Costs may remain difficult to integrate without being excluded. Self-binding may remain contested without being externalized. Conflict and delay do not establish blockage where revision remains possible and consequential positions remain attached to their effects.

Position reversal prevents the map from fixing profiles. An allegedly immunized position may be highly exposed or insufficiently protected. An allegedly overexposed position may possess unchecked action-power, control access, externalize costs, or use its own burden as protection from criticism. Neither reversal is presumed. Each must be tested against the scene packet.

The counter-scene must produce an effect on the reading. It may defeat the claim, narrow it to one mechanism, redirect responsibility, reduce confidence, make another explanation primary, or suspend judgment pending evidence. A counter-scene that leaves every possible output unchanged has not been admitted methodologically.

Falsifiers make this exposure explicit. They state conditions under which the proposed reading cannot retain its original strength:

```text
Ω is minimal or absent.
The alleged non-action does not structure costs or options.
Responsibility remains properly attached to effect.
Critique remains possible.
Σ/Ψ are robustly open.
Protection is bounded and responsibility-compatible.
Vulnerability remains criticizable without degradation.
Hierarchy is bounded and functional.
Rival explanation is stronger.
The alleged pattern is not repeated or consequential.
Counter-scene explains the scene better.
```

A falsifier need not disprove the framework in general. It defeats or weakens the specified application. If responsibility remains properly attached, the displacement claim fails. If protection remains bounded and criticizable, the immunization claim weakens. If non-action does not alter costs or options, the non-passivity claim fails.

The strongest positive falsifier gathers the central conditions:

```text
If real Ω is acknowledged,
R follows structuring effect,
Σ integrates cost,
Ψ is self-bound,
Χ remains available,
D is preserved,
and counter-scenes remain possible,
then the EDEN drift claim weakens or fails.
```

Here Χ (distance) preserves the capacity for reflective revision, while D (dignity-in-practice) keeps criticizability compatible with protection from degradation. A difficult, painful, asymmetrical, or conflictual scene may satisfy these conditions. EDEN does not require the absence of difficulty. It requires evidence of false coordination and damaged correctability.

The hard limit is:

```text
If no falsifier can be named,
the EDEN reading is methodologically unsafe.
```

A methodologically admissible result must therefore record both the strongest counter-scene and the evidence that would revise the reading. Only then may EDEN-MAP formulate an output, and even then the output remains description rather than authorization.

### 19.9 Description-to-Action Firewall and Output Format

EDEN-MAP ends by separating what the mapping may describe from what anyone may do with that description. This separation is not an optional disclaimer. It is the condition that prevents structural clarity from becoming accusation, prescription, confrontation, intervention, or enforcement by conceptual momentum alone.

The firewall is:

```text
Description may name structure.
Application requires Χ, reversibility, D, and contextual responsibility.
Description does not authorize binding.
```

Description is operator-traceable mapping without obligation. It may identify real asymmetry, displaced responsibility, blocked integration, unequal self-binding load, or a responsibility shield. It may state that one reading currently fits the evidence better than another. It does not thereby require a participant to accept the reading or authorize another person to act upon it.

Application begins where a structural reading is used to steer, bind, obligate, prescribe, confront, accuse, intervene, or enforce. At that point, Χ (distance), reversibility, D (dignity-in-practice), and contextual responsibility become mandatory validity conditions rather than desirable additions.

```text
Description:
operator mapping without obligation.

Application:
operator mapping used to steer,
bind,
obligate,
prescribe,
confront,
accuse,
intervene,
or enforce.
```

Distance requires separation between the reading and the urgency to impose it. The analyst or participant must remain able to distinguish structural evidence from certainty, interpretation from verdict, and disagreement from proof of the model. A reading fused with enforcement has lost reflective distance.

Reversibility requires that the reading remain scene-bound, revisable, and non-final. New evidence must be able to alter its scope, responsibility distribution, confidence, or explanatory priority. No EDEN-MAP output becomes an irreversible identity claim or global statement about a person, group, or sex.

Dignity-in-practice requires enacted restraint under asymmetry. An analysis that shames, ranks, humiliates, or ontologically devalues a role-position is not admissible as an EDEN analysis. Responsibility may be named without degradation, and protection from degradation remains compatible with criticizability.

Humiliation within the scene may be relevant evidence. It may indicate damaged dignity-in-practice, overexposure, recognition loss, or closure against correction. Humiliation produced by the analysis is different: it is a method failure. Where an EDEN reading is used to bind or enforce while dignity-in-practice is suspended, the application is methodologically invalid.

```text
Humiliation within the scene may be evidence.
Humiliation by the analysis is a method failure.
Application without dignity-in-practice is methodologically invalid.
```

Contextual responsibility requires attention to who is using the map, under what authority, with what information, against which role-position, and with what foreseeable effects. A structurally coherent description may remain inappropriate for application where the user lacks standing, evidence, accountability, or protection against misuse.

Application therefore requires:

```text
scene packet
counter-scene
Χ
reversibility
D
contextual responsibility
```

No element can be replaced by confidence in the framework. A detailed map cannot replace distance. A counter-scene cannot replace dignity. Good intentions cannot replace reversibility. Structural coherence cannot supply authority that the scene does not provide.

The application boundary can be stated directly:

```text
EDEN-MAP can describe structure.
It does not automatically authorize intervention,
accusation,
confrontation,
prescription,
or coercive action.
```

The output format preserves the protocol’s sequence:

```text
1. Scene packet summary
2. Real Ω
3. Dominant false-coordination frame
4. Responsibility / action-power distribution
5. Σ / Ψ status
6. Non-action / non-binding relevance
7. Immunization / overexposure result
8. Counter-scene / falsifier result
9. Description/Application status
10. Revision point / open question
```

The scene packet summary identifies the bounded scene, relevant role-positions, temporal limits, principal effects, and evidentiary constraints. It does not restate the entire packet or begin with a theory label.

The real-asymmetry field records the consequential differences that organize capacity, exposure, protection, timing, access, language, responsibility, or cost. It must distinguish mapped asymmetry from evaluation.

The false-coordination field names the dominant frame only where evidence shows that it displaces responsibility or blocks integration and self-binding. Where no such frame is established, the output must say so rather than filling the category by default.

The responsibility and action-power field records who structures relevant conditions and what limits apply to answerability. It includes direct and indirect effects without converting capacity into rank or responsibility into blame.

The Σ (integration) and Ψ (self-binding) field records whether costs and effects can enter a shared account and whether consequential role-positions remain attached to what they structure. It may record partial openness, uncertainty, or mixed evidence rather than forcing a binary result.

The non-action and non-binding field distinguishes mere absence, structuring non-event, integrated abstention, and legitimate openness. It identifies shifted cost or self-binding load only where the scene conditions support that finding.

The immunization and overexposure field records coupled responsibility distortion without assigning fixed profiles. It must include genuine vulnerability, genuine protection, actual power, actual exposure, and counter-immunity checks where relevant.

The counter-scene and falsifier field states the strongest competing account, the evidence supporting it, and the condition that would weaken or defeat the EDEN reading. A token alternative does not satisfy this requirement.

The Description/Application status field records whether the result remains structural description or is being used to bind. It must also record whether an affected role-position contests the scene packet, evidentiary selection, operative frame, responsibility distribution, or proposed application, and what evidence or counter-scene could alter the result. Contestation remains admissible without becoming either automatic defeat of the reading or evidence that the model has been confirmed.

If disagreement remains unresolved, the output must mark the reading as contested, provisional, narrowed, or indeterminate and preserve the relevant Revision Point or Open Question. EDEN-MAP may not recode disagreement as failed correctability, immunization, threat-coding, or resistance to truth by default. The analyst remains responsible for revising the output when new evidence, a stronger counter-scene, a rival explanation, or a stated falsifier changes the reading.

If application is proposed, the output must state whether distance, reversibility, dignity-in-practice, contextual responsibility, affected-role standing, and an independently legitimate application context are present. Their absence blocks binding use. EDEN-MAP itself supplies neither application authority nor a recommendation for how to repair, confront, adjudicate, or enforce the scene.

The final field is mandatory:

```text
Revision point / open question
```

A revision point identifies what evidence, changed condition, counter-scene, or unresolved distinction could alter the map. An open question identifies what remains structurally undecided. Neither should be replaced by a conclusion that merely restates the preferred reading.

The output-level guardrails are:

```text
No recommendation engine.
No verdict machine.
No diagnostic language.
No intervention protocol.
No moral sentencing.
No final person label.
No sex ranking.
No coercive authorization.
```

These limits do not prevent a clear result. EDEN-MAP may conclude that a specified reading is strongly supported, weakly supported, secondary, presently indeterminate, or defeated. What it cannot do is convert that evidentiary status into a person verdict or action command.

The final discipline is:

```text
No concept or pattern may replace scene-bound evidence.
No EDEN label may replace scene analysis.
No structural description may authorize binding by itself.
```

EDEN-MAP therefore ends not by closing the scene, but by making its structural reading explicit, bounded, counter-tested, and revisable. Its usefulness lies in disciplined legibility without conceptual enforcement. The concluding chapter can now return to the theoretical payoff: what becomes visible when real asymmetry can be named without being denied, falsely coordinated, or converted into a verdict.

---

## 20. Conclusion and Theoretical Payoff

### 20.1 What EDEN Establishes

The preceding analysis has developed a praxeological account of reciprocity loss through false-coordinated real Ω (asymmetry). Its central claim is not that asymmetry is itself defective. Relations differ in capacity, exposure, dependency, timing, protection, obligation, access, and cost. The decisive question is whether those differences remain truthfully coordinated.

The thesis can be stated compactly:

```text
Adult Reciprocity = truthful coordination of real Ω.
Reciprocity Loss = false coordination of real Ω.
```

The paper therefore does not explain reciprocity loss by denying asymmetry. It explains reciprocity loss by showing how real asymmetry becomes falsely coordinated. A scene begins to drift where its operative differences remain consequential but are organized through frames that mislocate effect, responsibility, cost, criticizability, or self-binding.

The central movement is:

```text
real Ω
→ false coordination frame
→ displaced R
→ blocked Σ/Ψ
→ erosion of shared correctability
→ reciprocity loss
```

This sequence identifies a structural relation rather than a universal chronology. Real asymmetry does not automatically produce false coordination. False coordination does not require every mechanism developed in the paper. The sequence specifies the elements that must become traceable before a strong reciprocity-loss claim can be sustained.

R (responsibility) follows real structuring effect under available legibility, capacity, alternative possibility, Θ (temporality) trajectory, and Ω (asymmetry) cost or exposure conditions. This prevents responsibility from collapsing into blame, intention, visible action, formal role, or outcome-liability. It also prevents limited legibility or vulnerability from erasing every consequential effect.

Σ (integration) concerns whether relevant costs and effects can enter a shared account. Ψ (self-binding) concerns whether consequential role-positions remain attached to what they structure. Reciprocity loss becomes more than disagreement where integration is blocked, self-binding is externalized, and correction can no longer reach the structure that distributes the burden.

The framework has therefore distinguished conflict from loss of correctability. Conflict can remain reciprocal where effects are nameable, responsibility remains proportionate, and correction can alter the scene. Reciprocity loss occurs where the scene becomes organized so that its own costs and asymmetries cannot be jointly carried, criticized, or revised.

False comparison contributes to this process without becoming its first cause. Comparison can amplify, stabilize, or legitimize a drift by replacing coordination of real conditions with relative rank, parity, protection, or superiority frames. Functional comparison remains possible where it clarifies rather than displaces the structure being compared.

Non-action and non-binding have also become structurally legible without being treated as hidden action by default. An absence becomes praxis-relevant only where it structures a scene through expectation, consequence, asymmetry, and temporality. Silence can remain restraint, delay can remain legitimate, and non-binding can remain honest openness.

Immunization and overexposure name coupled responsibility distortions rather than identities. One position’s effects may become less criticizable while another carries responsibility beyond available legibility or protection. The distribution cannot be assigned by sex, identity, or ideological affiliation in advance. It must be established scene by scene.

Recognition can preserve standing without dissolving responsibility. Protection can preserve dignity without creating categorical immunity. Authority and superiority can remain local, functional, criticizable, and responsibility-increasing. These distinctions keep the account directed against false coordination rather than against asymmetry, competence, vulnerability, protection, or hierarchy as such.

Postfeminist Override (PFO) therefore appears as one possible downstream regime stabilization, not as the origin or center of reciprocity loss. False-coordinated real asymmetry can occur without PFO, and a local switch does not by itself establish a regime. The regime concept remains subordinate to the broader grammar.

Eden occupies a similarly bounded position. It functions as a late test scene for the developed grammar, not as the paper’s foundation, proof path, or account of gender origins. Its value lies in showing that coordinated asymmetry, consequence activation, exposure management, and responsibility trace can be read without restoring an origin narrative.

The argument has also bound itself to limits. A scene may involve genuine vulnerability, protection, hierarchy, superiority, non-action, openness, or rival explanation. A counter-scene must be able to change the reading. If no falsifier can be named, the reading is methodologically unsafe.

EDEN thus offers neither a total explanation nor a verdict vocabulary. Its strongest domain is a scene in which real asymmetry is falsely coordinated, responsibility is displaced, integration or self-binding is blocked, and shared correctability erodes. Outside that domain, the reading must narrow, yield to a stronger explanation, or release the scene.

### 20.2 The Positive Counter-Proposal

The alternative to reciprocity loss is not symmetry. Equal standing does not require identical capacity, exposure, obligation, protection, or burden. Adult reciprocity concerns the truthful coordination of differences that remain real.

The positive counter-proposal is:

```text
The task is not to abolish asymmetry.
The task is to make asymmetry criticizable,
responsible,
integrated,
self-bound,
and dignity-preserving.
```

This formulation does not prescribe a social arrangement or guarantee relational harmony. It names the structural conditions under which real differences can remain compatible with adult standing and shared correctability.

The positive configuration can be compressed as follows:

```text
Ω visible
R follows real structuring effect
Σ integrates costs and effects
consequential role-positions remain self-bound through Ψ to their own effects
Χ keeps revision possible
D remains protected
```

Ω (asymmetry) remains visible where consequential differences can be named without being converted into rank or denied through false parity. Visibility does not mean constant exposure. It means that the scene does not depend on making its operative differences unspeakable.

R (responsibility) follows effect where answerability remains proportionate to legibility, capacity, alternatives, temporality, and exposure. Unequal responsibility may therefore be accurate. What matters is that responsibility is neither erased by recognition nor expanded beyond what a position could understand, carry, or alter.

Σ (integration) remains open where costs, protections, vulnerabilities, and effects can enter the same account without one truth categorically excluding another. Integration does not eliminate disagreement. It prevents disagreement from being stabilized through systematic exclusion of structurally relevant effects.

Ψ (self-binding) remains active where consequential positions attach themselves to what they structure. Self-binding does not require unlimited responsibility or permanent availability. It requires that a position’s freedom, protection, authority, or openness not depend on another position carrying its unacknowledged effects.

Χ (distance) keeps revision possible by preventing interpretation from fusing with urgency, identity, verdict, or enforcement. Distance allows a reading to remain strong without becoming final. It preserves the difference between naming structure and compelling another position to accept the account.

D (dignity-in-practice) keeps responsibility compatible with protection from degradation. It requires criticizability without humiliation and responsibility without domination. Dignity is not immunity from criticism, and responsibility is not permission to shame, rank, or ontologically diminish a role-position.

Adult reciprocity does not require equal burdens. It requires the non-externalization of unequal burdens. A role-position may legitimately carry more because it has greater capacity, authority, knowledge, protection, or control. Reciprocity is preserved where that difference remains visible, answerable, integrated, and self-bound rather than silently transferred elsewhere.

```text
Adult reciprocity does not require equal burdens.
It requires non-externalization of unequal burdens.
```

Non-externalization does not mean that every cost can be eliminated or evenly distributed. Some asymmetries are unavoidable, and some burdens cannot be shared without distortion. The positive condition is that these burdens do not disappear from the account merely because one position is expected to absorb them.

This leaves room for tragedy. Mature coordination cannot guarantee safety, agreement, repair, equal outcome, or freedom from loss. It can preserve truthful relation to the asymmetry under which difficult outcomes occur. Reciprocity may remain adult even where no available arrangement removes every cost.

The positive counter-proposal is therefore demanding without becoming programmatic. It does not specify what participants should do in a particular scene. It identifies what must remain structurally possible if asymmetry is to be coordinated without reciprocity loss: legibility, proportionate responsibility, integration, self-binding, distance, dignity, and correction.

The same structures through which people learn recognition, protection, responsibility, and coordination can preserve adult reciprocity or make its erosion difficult to see. The question is therefore not only whether a relation remains stable, but what kind of reciprocity its stability permits.

### 20.3 The Social Payoff

The social significance of EDEN lies in its structural account of how reciprocity can be learned, stabilized, and made difficult to examine within already organized relations. On this account, recognition, protection, responsibility, comparison, self-binding, and correction are not treated as arising from a complete prior understanding of reciprocity. This is a theoretical compression, not an empirically established developmental sequence or an exhaustive theory of socialization; claims about actual learning patterns, recurrence, or distribution require independent empirical support.

The compressed social formulas are:

```text
Society = stabilized praxis.
Personality = internalized praxis.
Blind spot = learned legibility condition.
```

These formulas are structural, not diagnostic. They do not reduce society to a single mechanism or personality to passive social reproduction. They identify how recurrent practices can become durable social expectations and how those expectations can organize later scene participation. “Personality” remains a structural compression for durable internalized praxis orientation, not an inner essence, personality type, or inferred mental state.

Stabilized praxis makes coordination possible. Shared frames reduce uncertainty, preserve expectations, distribute responsibilities, and make complex relations manageable. Without stabilization, every scene would require its own complete reconstruction of roles, language, obligations, protections, and acceptable conduct.

Internalized praxis likewise supports agency. Learned patterns allow participants to recognize demands, anticipate consequences, regulate conduct, and coordinate without beginning from nothing. Internalization is therefore not itself loss of freedom or evidence of false coordination.

The difficulty is that the structures through which reciprocity becomes learnable also shape what can be recognized as reciprocal. A practice may teach participants how to coordinate while limiting their capacity to examine the burdens, asymmetries, or exclusions through which that coordination is maintained.

```text
We learn reciprocity through structures
whose reciprocity we cannot yet fully examine.
```

A blind spot is therefore not merely missing information. It is a learned condition of legibility. Some effects become immediately recognizable, while others lack accepted language. Some vulnerabilities become protected, while others remain difficult to name. Some responsibilities appear obvious, while others disappear into normality, role expectation, or the presumed neutrality of non-action.

This explains why social order cannot be equated with adult reciprocity. A practice may be widely accepted, internally coherent, and durable while coordinating real asymmetry falsely. Normality can stabilize responsibility displacement as effectively as explicit coercion where costs remain difficult to name and correction cannot reach the operative frame.

```text
Social order is not automatically adult reciprocity.
Normality is not automatically truthful coordination.
Stability is not automatically correctability.
```

EDEN’s social payoff is to make these distinctions speakable without turning them into person judgments. It provides terms for examining real asymmetry, consequential non-action, non-binding, recognition drift, protection frames, and responsibility displacement while preserving the difference between structural effect and personal essence.

This vocabulary can also recover burdens that visible-action accounts overlook. Waiting, explanation, self-regulation, continuity work, restricted options, and the cost of another position’s non-binding may structure a scene without appearing as conventional power. Naming these effects does not prove drift, but it prevents their invisibility from functioning as evidence of their absence.

The same framework protects genuine differences from automatic suspicion. Vulnerability, protection, authority, hierarchy, unequal capacity, and unequal responsibility can remain real and legitimate. The social aim is not to flatten these differences, but to keep their effects, costs, and responsibility distributions available to shared correction.

Stabilization is therefore not the enemy. Stable practices can carry trust, memory, protection, competence, and coordination across time. The danger begins where stabilization makes its own costs illegible and protects itself against the correction required to remain reciprocal.

```text
Stabilization is not the enemy.
Uncorrectable stabilization is the danger.
```

The social payoff is consequently discriminative rather than accusatory. EDEN can distinguish stable coordination from stabilized reciprocity loss, unequal responsibility from responsibility displacement, protection from immunization, and restraint from structuring non-action. It gives social stability no automatic innocence, but it also treats instability as no automatic virtue.

### 20.4 The Structural Warning

The concluding warning follows from this social payoff: stability can persist after reciprocity has weakened. A relation, practice, institution, or regime may continue to coordinate behavior even where responsibility is displaced, relevant costs cannot be integrated, and correction has become structurally difficult.

```text
Stability without reciprocity is possible.
```

Stabilized praxis increases coordination capacity because expectations become repeatable and less costly to reproduce. The same repetition can reduce dynamic reversibility where patterns stabilize as Α (attractor) under real Ω (asymmetry) across Θ (temporality) and become resistant to correction. What once coordinated action can become a condition under which alternative coordination is no longer legible.

The danger does not lie in repetition alone. A stable pattern may remain revisable, criticizable, and responsive to changed conditions. Drift becomes harder to correct where the pattern begins to determine which objections count, whose costs appear reasonable, and which descriptions remain admissible.

A stabilized scene can preserve the appearance of integration while excluding the effects that would revise it. Σ (integration) is then simulated through apparent coherence rather than achieved through reception of relevant costs. Ψ (self-binding) is externalized where continuity depends on one position carrying the restraint, explanation, or adaptation that another position no longer attaches to its own effects.

R (responsibility) may remain formally assigned while becoming structurally displaced. A role-position can be answerable in name but insulated from the specific effects it produces. Another can appear free while carrying the costs that make the first position’s freedom sustainable.

The warning can be stated directly:

```text
A relation, practice, or regime can remain stable
while correction becomes illegible,
responsibility displaced,
Σ simulated,
and Ψ externalized.
```

Such stability can make change most difficult when the need for change becomes clearest. The same trajectory that reveals accumulated cost may already have weakened the language, trust, distance, or self-binding through which correction could occur.

```text
A structurally relevant reason for change may become legible
after the means of change have already been damaged.
```

This is not a prediction of inevitable collapse. Stabilized drift may persist, weaken, be interrupted, or become newly correctable. The claim is narrower: coordination capacity and correctability are not identical, and the durability of a structure does not prove the reciprocity of its operation.

The warning also turns toward the framework itself. EDEN cannot criticize uncorrectable stabilization while treating its own concepts as immune from revision. It cannot identify responsibility displacement in a scene while externalizing responsibility for the effects of its own interpretation.

```text
A theory of reciprocity loss must not become
a new technology of reciprocity loss.
```

Drift terms therefore name structural tendencies, not person types. A framework that turns immunization, overexposure, non-binding, or false coordination into identities reproduces the closure it was developed to analyze. It replaces scene-bound inquiry with stabilized attribution.

The same applies to conceptual authority. The internal coherence of EDEN cannot replace evidence, counter-scenes, or rival explanations. A theory about lost correctability must remain exposed to correction precisely where its vocabulary appears most explanatory.

```text
EDEN must not analyze reciprocity loss
by exiting reciprocity.

If EDEN cannot be corrected,
it has betrayed its own account of correctability.
```

This reflexive warning is not a retreat from the argument. It is the final consequence of its central claim. Truthful coordination requires responsibility for structuring effect, and theoretical description also has structuring effects. The framework must therefore remain revisable, dignity-preserving, and answerable to the scenes it maps.

### 20.5 Reflexive Self-Binding

The structural warning applies to EDEN itself. A framework that analyzes false stabilization cannot treat its own categories as self-validating. A theory that traces responsibility displacement cannot place responsibility for interpretive error entirely outside itself.

EDEN is produced within the same field of stabilized praxis that it examines. Its distinctions depend on inherited language, learned salience, established concepts, and prior structures of recognition. The framework may clarify these conditions, but it does not occupy a position beyond them.

The analyst is likewise situated within the scene of interpretation. Attention may be drawn toward familiar burdens and away from unfamiliar ones. A persuasive pattern may become easier to recognize than evidence that weakens it. Conceptual fluency may create premature certainty, and repeated explanatory success may reduce sensitivity to non-capture.

Comparison susceptibility also remains active. EDEN may begin to secure its value by appearing more comprehensive, critical, or structurally precise than rival accounts. When theoretical standing becomes dependent on comparative superiority, a framework can begin to preserve itself through the same relative logic it criticizes elsewhere.

Φ (recontextualization) creates a related risk. Recontextualization can reveal an overlooked structure, but it can also make every objection appear to confirm the framework at a deeper level. A rival explanation may be redescribed as limited legibility, resistance may be redescribed as immunization, and requests for evidence may be redescribed as blocked criticizability. If every response becomes confirmatory, correction has been removed in advance.

Responsibility displacement can also occur within interpretation. The framework may assign all evidentiary burden to the scene, the critic, or the rival explanation while leaving its own claim insufficiently specified. It may require others to disprove what it has not made falsifiable. Such a use would externalize the self-binding demanded by its own method.

The reflexive condition is therefore:

```text
EDEN is not outside the garden.
EDEN is not outside comparison susceptibility.
EDEN is not outside Φ-risk.
EDEN is not outside responsibility displacement.
```

This condition does not make structural analysis impossible or reduce every claim to standpoint. It requires that explanatory strength remain compatible with correction. A framework may defend a reading, reject an objection, or show that a rival explanation fails. It may not secure itself by making failure conceptually unavailable.

Counter-scenes and falsifiers therefore bind the framework as well as the scenes it maps. A counter-scene must be capable of redirecting the reading. A falsifier must identify conditions under which a specified claim weakens or fails. Revision must remain possible not merely in principle, but in the organization of the analysis.

D (dignity-in-practice) also constrains theoretical use. EDEN cannot preserve its authority through shaming, ranking, humiliation, or ontological evaluation of persons or groups. It cannot analyze damaged dignity by reproducing degradation in its own language. Responsibility remains nameable, but truth does not become permission to humiliate.

The theory’s self-binding can be stated directly:

```text
A theory of reciprocity loss must remain answerable
to reciprocity in its own use.
```

Answerability requires more than acknowledging fallibility. It requires scene-bounded claims, proportionate confidence, operator discipline, counter-scene exposure, and willingness to release a reading when the evidence no longer supports it. These are not external restraints imposed on the framework. They follow from its own account of adult reciprocity.

The theory therefore closes without claiming immunity, universality, or final explanatory authority. Its contribution is bounded but substantive: it makes false-coordinated real asymmetry, responsibility displacement, blocked integration, externalized self-binding, and eroded correctability structurally legible while preserving genuine asymmetry, protection, vulnerability, hierarchy, non-action, and non-capture.

This is the point at which the argument can end. Its positive claim does not require symmetry, the abolition of difference, or a promise that every loss can be repaired. It requires that real asymmetry remain visible, criticizable, responsible, integrated, self-bound, and compatible with dignity.

### 20.6 Final Formula

The final formulation returns to real Ω (asymmetry) and the distinction on which the argument has rested:

```text
Adult Reciprocity is the truthful coordination of real Ω.

Reciprocity Loss begins where real Ω is falsely coordinated
through comparison,
protection,
parity,
superiority,
vulnerability,
responsibility,
recognition,
or non-action frames.

The task is not to abolish asymmetry,
but to make asymmetry criticizable,
responsible,
integrated,
self-bound,
and dignity-preserving.
```

---

## Appendix A. Structural Glossary

### A.1 Glossary Status and Guardrails

This glossary consolidates the paper’s structural vocabulary. The main text retains local definitions where they are necessary for the argument; the appendix provides a common reference point for terms used across several chapters. Its function is terminological discipline, not theoretical expansion.

Every entry names a structural possibility. No entry is, by itself, an empirical prevalence claim, a diagnosis of a person, a moral verdict, a form of collective sentencing, a clinical label, or proof of an interpretation. A term becomes analytically relevant only where its defining relations can be traced within a sufficiently specified scene.

Drift terms name structural tendencies, not person types. They do not establish fixed dispositions, hidden motives, sex-specific essences, or stable identities. A drift term may describe how a scene is organized without determining what any participant is, intends, or will do elsewhere.

Naming a term does not prove that the corresponding structure is present. No glossary entry replaces evidence, contextual judgment, rival explanations, or counter-scene testing. No entry authorizes coercive action or converts a structural description into an obligation for another person. Where the available evidence changes, the application of the term must remain revisable.

Boundary terms have a limiting function. They must be capable of constraining or defeating a proposed reading rather than merely decorating it with caution. If a concept cannot specify what would weaken its application, distinguish it from a genuine counter-case, or remain open to correction, it is not being used methodologically.

The glossary therefore supports scene-bound analysis while withholding verdictive force. It makes distinctions available; it does not decide scenes by naming them.

### A.2 PMS Operators

Praxeological Meta-Structure (PMS) provides the base operators used by the paper. The operators describe elementary structural relations. They are neither person attributes nor independent judgments, and their appearance in a scene does not establish drift, failure, or responsibility by itself.

**Δ (difference)** denotes the minimal structural distinction that makes differentiation possible. Difference does not by itself imply asymmetry, hierarchy, rank, opposition, or conflict.

**∇ (impulse)** denotes directional tension or drive arising from difference. Impulse does not require a conscious intention, a completed act, or an integrated course of action.

**□ (frame)** denotes the contextual structure that constrains, organizes, or gives meaning to impulses and relations. A frame may be explicit or implicit, but it must be traceable through its structuring effects rather than inferred from atmosphere alone.

**Λ (non-event)** denotes a structured absence: a meaningful failure, omission, interruption, or delay of an expected occurrence within a frame. Mere absence is not automatically a non-event; the absence must acquire structural significance within the scene.

**Α (attractor)** denotes a recurrent pattern or stabilization produced through repeated structural interaction. An attractor makes some trajectories more available or repeatable without determining them or eliminating alternative possibilities.

**Ω (asymmetry)** denotes a structural imbalance that gives direction to power, exposure, capacity, dependency, obligation, protection, access, or cost. Asymmetry is not inherently domination, inferiority, superiority, or relational failure.

**Θ (temporality)** denotes the temporal organization through which trajectories, commitments, consequences, development, and longer-form self-relation become possible. Temporality concerns structured continuation and sequence, not chronology alone.

**Φ (recontextualization)** denotes the transformation of an existing structure through its placement within a different frame. Recontextualization can alter the meaning or practical force of an arrangement without changing every element of the arrangement itself.

**Χ (distance)** denotes reflective withdrawal from immediate impulses, demands, or stabilized patterns. Distance can support revision and restraint, but it is not identical with indifference, abandonment, or disengagement.

**Σ (integration)** denotes the synthesis of disparate or conflicting elements into a coherent whole. Integration is not mere agreement, suppression of conflict, or the appearance of coherence.

**Ψ (self-binding)** denotes self-relation through commitment to integrated structures across time. Self-binding concerns the capacity to remain answerable to a direction, boundary, commitment, or consequence; it is not mere compliance with another role-position’s demand.

These operators constitute the paper’s inherited structural grammar. The paper adds no operator and does not convert its own descriptive labels into primitives. Its more specific concepts compress configurations that can be described through the operators; they do not modify the base grammar. The derived axes collected in A.3 are composed from this operator set and remain distinct from it.

### A.3 Derived PMS Axes

The following axes are higher-order constructs composed from the base operators. They organize recurring structural relations without adding primitives to Praxeological Meta-Structure. Their compositions identify the operators required for each axis; they do not claim that every possible higher-order construct has been exhausted. In the formulas below, composition notation states the formal derivation; bracket notation is retained only as a compact inventory of components.

**A (awareness)** is composed of Θ (temporality), □ (frame), and Δ (difference). Awareness denotes sustained differentiation within a frame across time: the capacity for a distinction to remain available rather than disappearing into immediate impulse or undifferentiated experience.

```text
A = Θ ∘ □ ∘ Δ
Compactly: A = [Θ, □, Δ]
```

**C (coherence)** is composed of Θ (temporality), Λ (non-event), □ (frame), and ∇ (impulse). Coherence denotes the temporally stabilized organization of impulse, expectation, and meaningful non-occurrence within a frame. It does not require harmony or the absence of contradiction.

```text
C = Θ ∘ Λ ∘ □ ∘ ∇
Compactly: C = [Θ, Λ, □, ∇]
```

**R (responsibility)** is composed of Ψ (self-binding), Φ (recontextualization), Θ (temporality), and Ω (asymmetry). Responsibility denotes a self-binding orientation toward structuring effects under asymmetrical and changing conditions across time. It is not identical with blame, guilt, causality, or liability for every outcome.

```text
R = Ψ ∘ Φ ∘ Θ ∘ Ω
Compactly: R = [Ψ, Φ, Θ, Ω]
```

**E (strict Action / Enactment)** is composed of Σ (integration), Θ (temporality), and ∇ (impulse). Strict Action or Enactment denotes the integrated realization of directionality across time. It is narrower than praxis and should not be used as a synonym for every event, effect, omission, or structurally relevant form of conduct.

```text
E = Σ ∘ Θ ∘ ∇
Compactly: E = [Σ, Θ, ∇]
```

**D (dignity-in-practice)** is composed of Ψ (self-binding), Χ (distance), and Ω (asymmetry). Dignity-in-practice denotes self-bound reflective restraint and protection of standing within asymmetrical relations. It preserves agency and criticizability while preventing responsibility from becoming degradation.

```text
D = Ψ ∘ Χ ∘ Ω
Compactly: D = [Ψ, Χ, Ω]
```

Praxis is the broader category. It includes conduct, framing, timing, withholding, non-action, recognition, legitimation, and other scene-bound contributions where they produce a traceable structuring effect. Praxis can therefore be structurally relevant without satisfying the conditions of E (strict Action / Enactment).

Strict Action or Enactment requires Σ (integration), Θ (temporality), and ∇ (impulse). A non-event may shape a scene without becoming integrated enactment. Conversely, a sustained abstention may approach strict enactment where directionality, temporal continuity, and integration are present. The distinction prevents structural relevance from being confused with overt action while also preventing every effect from being redescribed as action.

The five axes remain derived constructs. They organize relations among the operators but do not alter the operator set, function as independent moral standards, or establish responsibility merely by being named.

### A.4 EDEN Core Terms

The EDEN core terms in this section are paper-internal analytical definitions, not additional PMS operators or derived axes. Their evaluative terms, including “Adult,” “truthful,” “false,” “failure,” and “loss,” state EDEN’s explicit definitional and normative benchmarks rather than empirical discoveries or natural laws. Whether a defined configuration occurs in a particular scene remains an evidentiary question.

**Adult Reciprocity** denotes a structural condition in which real asymmetry remains visible, responsibility can follow actual structuring effect, costs and exposures can enter integration, self-binding remains possible, revision remains open, and dignity-in-practice is preserved. It does not require sameness, identical roles, equal burdens, or formal symmetry.

Here, Ω (asymmetry) names the real unevenness that must be coordinated rather than abolished.

```text
Adult Reciprocity ≠ symmetry.
Adult Reciprocity = truthful coordination of real Ω.
```

**Real Ω (asymmetry)** denotes an operative unevenness in capacity, exposure, cost, dependency, protection, recognition, timing, access, responsibility, action-power, or legibility. Its reality does not establish that it is natural, justified, permanent, reciprocal, or beyond criticism. Asymmetry is not the failure; its false coordination is the failure.

**Limited Legibility** denotes the structural condition in which actors cannot see the whole praxis field at once. Relevant costs, histories, effects, alternatives, and asymmetries may remain only partly available even while they continue to structure the scene. Limited legibility is neither innocence nor guilt, and it neither removes responsibility nor licenses retrospective certainty.

**Comparison Susceptibility** denotes a condition in which comparison becomes more available than coordination because a scene remains only partly legible. Missing concepts, opaque costs, recognition needs, responsibility pressure, stabilized asymmetry, and weak or externalized self-binding may contribute to this susceptibility. It is not itself False Comparison and does not make subsequent drift inevitable.

**False Comparison** denotes comparison that ceases to clarify a praxis relation and instead converts difference or asymmetry into a relation of rank, worth, standing, maturity, credibility, danger, or defect. Comparison is not false merely because it distinguishes or evaluates. It becomes false where it substitutes value assignment for truthful coordination. False Comparison is an attractor, amplifier, and stabilizer, not a first cause.

**Rank Artifact** denotes an appearance of higher or lower standing produced when a praxis relation is converted into a value relation. Dependency may then appear as inferiority, capacity as superiority, vulnerability as diminished agency or protected priority, and responsibility as evidence of moral rank. The artifact concerns the framing of the relation; it does not establish the worth of a role-position.

**False-Coordinated Real Asymmetry** denotes the paper’s central coordination failure. Real asymmetry remains operative, but the scene organizes it through a frame that displaces responsibility, blocks integration, weakens or externalizes self-binding, and reduces shared correctability. The asymmetry need not be false. The coordination is false.

Using Ω (asymmetry), R (responsibility), Σ (integration), and Ψ (self-binding), the minimal structure is:

```text
real Ω
+ false coordination frame
+ displaced R
+ blocked Σ/Ψ
= false-coordinated real Ω
```

A frame is not false merely because it is partial. Every frame selects what is relevant. A frame becomes false as coordination where it prevents responsibility from following real structuring effect or excludes relevant cost, exposure, protection, and self-binding from integration.

**Displaced Responsibility** denotes a distribution in which answerability no longer follows real structuring effect under the relevant conditions of legibility, capacity, alternative possibility, temporality, and asymmetrical cost or exposure. Responsibility may be erased, redirected, overassigned, converted into authority, or externalized onto another role-position.

**Blocked Σ (integration)** denotes the failure or prevention of a scene’s capacity to hold together relevant costs, exposures, vulnerabilities, responsibilities, and countervailing truths. Blocked integration is not disagreement. It occurs where the scene cannot incorporate relevant structure without excluding, flattening, or disqualifying part of what must be coordinated.

**Blocked Ψ (self-binding)** denotes the weakening, avoidance, simulation, or externalization of commitment to one’s own structuring effects. Self-binding is blocked where a consequential role-position remains able to affect the scene while treating the resulting cost, continuity, uncertainty, or correction burden as belonging primarily to others.

**Reciprocity Loss** denotes the erosion of shared correctability under real asymmetry. It is not identical with conflict, hurt, inequality, disagreement, failed communication, or unequal burden. It becomes structurally legible where real asymmetry is falsely coordinated, responsibility is displaced, integration or self-binding is blocked, and the scene loses the capacity to receive and incorporate proportionate correction.

The central transition can be stated as follows:

```text
coordinated Ω
→ false-coordinated real Ω
→ displaced R
→ blocked Σ/Ψ
→ reciprocity loss
```

**Correctability** denotes the capacity of a scene to receive, test, revise, and integrate correction without destroying dignity-in-practice, evading responsibility, or further blocking integration and self-binding. Correctability does not require agreement, reconciliation, continued engagement, or acceptance of every criticism. It requires that structural claims remain answerable to evidence, counter-scenes, proportion, and revision.

Shared correctability is lost where no proportionate and dignity-preserving correction can reach the relevant structuring effect, regardless of how carefully the claim is bounded. A quiet scene may lack correctability, while a conflictual scene may retain it. The criterion is not surface harmony but whether correction can still alter the reading and coordination of the scene without becoming humiliation, immunity, domination, or coerced openness.

These terms form a dependency structure rather than a chronology or universal causal sequence. Limited legibility can increase Comparison Susceptibility; susceptibility can make False Comparison more available; False Comparison can amplify rank artifacts. Reciprocity Loss occurs only where such frames begin to govern the coordination of real asymmetry by displacing responsibility, blocking integration or self-binding, and eroding shared correctability.

**Eden Scene as Minimal Test Case** denotes the paper’s bounded use of the Eden narrative as a scene on which an already established grammar is tested. The scene does not originate the concepts, prove the framework, establish a universal anthropology, explain sexed relations in general, or supply a master history of reciprocity loss.

Within this limited function, the scene tests whether coordinated asymmetry, breach, consequence activation, exposure management, non-event structure, and responsibility trace can be described without collapsing into guilt-totalization, psychological essence, or person verdict.

**Negative Responsibility Kernel (NRK)** denotes a compact responsibility configuration within the Eden test scene. “Negative” refers to non-carrying or non-integration under consequence; it does not mean morally bad, guilty, corrupt, or inferior.

```text
NRK =
available legibility
+ meaningful boundary or option
+ consequential effect under Ω (asymmetry) and Θ (temporality)
+ enactment or non-enactment not carried by Σ (integration) or Ψ (self-binding)
+ responsibility trace.
```

NRK is not an operator of Praxeological Meta-Structure, adds no axiom, and does not replace the Responsibility Principle. It is paper-internal shorthand for a limited responsibility trace, not an application label or general account of guilt.

**Fig Leaves / Legibility Management** denotes the management of visibility after exposure has become structurally salient within the Eden scene.

```text
Fig Leaves =
legibility management under newly exposed Ω (asymmetry).
```

The term does not establish shame as the primary psychology, guilt as the scene’s meaning, concealment as manipulation, or regime stabilization as already present. Fig Leaves mark a minimal shift from coordinated embodiment to managed exposure: visibility and non-visibility have become structurally consequential.

### A.5 Responsibility and Dignity Terms

The terms in this section distinguish formally derived PMS structures from EDEN’s definitional and normative coordination rules. R and D remain derived axes; the Responsibility Principle, criticizability requirements, and preservation of D within Adult Reciprocity and application are explicitly adopted EDEN conditions. Their application to a particular scene remains descriptive, evidentiary, and revisable.

**Responsibility Principle** denotes the rule that answerability follows real structuring effect rather than visibility, intention, identity, formal role, vulnerability, protection status, or outcome alone. R (responsibility) remains conditioned by Θ (temporality) and Ω (asymmetry):

```text
R (responsibility) follows real structuring effect
under available legibility,
capacity,
alternative possibility,
Θ (temporality) trajectory,
and Ω (asymmetry) cost/exposure conditions.
```

The principle is both attributive and limiting. It preserves responsibility where effects are indirect or unintended, but withholds responsibility where sufficient legibility, capacity, alternatives, or relevant structuring effect are absent.

```text
R is not blame.
R is not guilt.
R is not moral worth.
R is not person condemnation.
R is not mere causality.
R is not outcome-liability alone.
```

**Recognition-without-Responsibility** denotes a drift in which recognition, dignity, protection, voice, or standing becomes detached from criticizability, consequence attribution, self-binding, and correction. Recognition remains visible while answerability for real structuring effect is discounted or displaced. The term does not imply that recognition claims are false or that protection is illegitimate.

```text
Recognition-without-Responsibility =
recognition claim
+ responsibility discount
+ reduced criticizability
+ weakened self-binding
+ blocked correction.
```

**Pseudo-Equal-Standing** denotes a recognition-specific configuration in which the language of equal standing remains present while the conditions of adult equal standing are weakened. Equality is affirmed at the level of recognition, but answerability remains unequally available.

```text
Pseudo-Equal-Standing =
equal recognition claim
+ unequal criticizability
+ responsibility discount
+ protected frame
+ blocked correction.
```

Pseudo-Equal-Standing does not begin with the demand for recognition. It begins where recognition becomes structurally detached from responsibility, criticizability, consequence attribution, and correctability. It is not identical with formal inequality or with every resistance to critique.

**Dignity-in-Practice** denotes the preservation of adult standing within the actual handling of responsibility and asymmetry. D (dignity-in-practice) protects a role-position from degradation while preserving agency, criticizability, and proportionate answerability.

```text
Dignity-in-Practice =
protection from degradation
+ recognition of agency
+ criticizability without humiliation
+ responsibility without domination.
```

D = Ψ ∘ Χ ∘ Ω identifies Dignity-in-Practice as a formally derived PMS axis. Formal derivation does not by itself make D a natural law, empirical universal, or normatively binding standard. EDEN explicitly adopts its preservation as a definitional and normative condition of Adult Reciprocity and as an application-only validity condition. Whether D is preserved or damaged in a particular scene remains an evidentiary question.

Dignity-in-Practice does not mean protection from responsibility or immunity from criticizability. Conversely, responsibility does not remain adult where humiliation, exposure, coercion, or person condemnation becomes the price of answerability.

**Self-Control** denotes answerability directed first toward one’s own structuring effects. It begins with Ψ (self-binding): the capacity to remain bound to the costs, conditions, frames, delays, recognitions, protections, or consequences one helps produce. Self-Control does not mean emotional suppression, obedience, confession, or moral self-punishment.

**Other-Control** denotes an attempt to secure coordination primarily by binding, directing, exposing, or regulating another role-position. Requests, boundaries, authority, and protection are not automatically Other-Control. The term becomes relevant where responsibility for one’s own structuring effect is displaced into demands that another role-position explain more, bind more, wait more, disclose more, absorb more, or surrender legitimate distance.

```text
Adult Ψ begins as self-binding,
not as other-binding.
```

**Critique-to-Threat Switch** denotes the recontextualization of a critique of real structuring effect as a threat to dignity, safety, recognition, or personhood. Through Φ (recontextualization), a responsibility question may be received instead as accusation, domination, control, lack of care, or harm. The switch is not established merely because critique produces distress; the critique itself may be degrading, inaccurate, coercive, or disproportionate.

**Structure Critique** denotes a revisable claim about how a scene distributes cost, exposure, responsibility, integration, self-binding, recognition, or correctability. Its object is a structuring relation, not the worth, essence, identity, or total character of a role-position.

```text
Structure critique is not person threat.
Critique of personhood ≠ critique of a responsibility-displacing structure.
```

**Person Threat** denotes a challenge directed at, or reasonably received as directed at, a role-position’s personhood, dignity, worth, basic legitimacy, or protected standing. A structural vocabulary does not make a criticism non-threatening by definition. The distinction between Structure Critique and Person Threat must remain open to evidence, form, timing, proportionality, and counter-scene testing.

**Recognition-with-Responsibility** denotes the positive coordination of recognition with adult answerability. Recognition protects dignity without suspending agency; responsibility remains proportionate without becoming degradation.

```text
Recognition-with-Responsibility =
recognition
+ criticizability
+ self-binding
+ proportionate responsibility
+ dignity-preserving correction
+ Σ (integration) / Ψ (self-binding) openness.
```

Recognition-with-Responsibility also binds the critic. Naming recognition drift does not make the critic innocent, authorize coercive correction, or remove the critic’s own responsibility for form, proportionality, distance, and real structuring effect.

### A.6 Switch Terms

**Switch** denotes a change in the operative frame through which a continuing asymmetry is coordinated. A switch becomes analytically relevant where the frame change alters responsibility distribution, access to critique, and the status of integration or self-binding.

```text
Switch =
real Ω (asymmetry) remains
+ operative frame changes
+ responsibility distribution changes
+ critique access changes
+ Σ (integration) / Ψ (self-binding) status changes.
```

A frame change may be valid, corrective, or necessary. Switches are identified by structural scene effects, not by presumed intention, strategy, bad faith, or person type.

**Pseudo-Symmetry** denotes a switch into the appearance of equality, parity, reciprocity, or mutuality while real Ω (asymmetry) remains unintegrated, R (responsibility) remains displaced, or Σ (integration) and Ψ (self-binding) remain blocked. Formal parity is not itself pseudo-symmetrical. The term applies only where parity replaces the truthful coordination of unequal conditions.

**Pseudo-Subordination** denotes a switch in which apparent weakness, dependence, vulnerability, injury, passivity, or lower position reorganizes responsibility and criticizability while real asymmetry remains operative. The vulnerability may be genuine. The “pseudo” qualifier concerns the coordination produced through the subordinate appearance, not the reality of need, injury, dependence, or exposure.

**Pseudo-Superiority** denotes a switch in which bounded capacity, competence, authority, responsibility, protection-power, status, or recognized standing becomes generalized into higher rank, priority, command-right, or exemption. Local superiority may be real within a specific domain. The switch begins where that local difference becomes a broader authorization to govern the scene or evade correction.

**Exception Switch** denotes movement into a frame that suspends, alters, or defers ordinary responsibility, criticizability, cost-truth, or self-binding. Exceptions may be required by crisis, injury, danger, exhaustion, trauma, or acute vulnerability. Drift begins only where the exception loses relevant limits of scope, duration, cost, answerability, or revision.

**Responsibility-to-Authority** denotes the conversion of greater responsibility into a claim to govern, define, control, or overrule another role-position. Greater capacity or burden may increase answerability where it structures effect. It does not by itself create authority over another person’s agency, dignity, vulnerability, or participation.

**Parity-to-Exit** denotes a switch in which equality, autonomy, mutual freedom, or parity becomes a frame for exiting cost-truth. Exit, refusal, distance, and non-participation may be legitimate or necessary. The switch becomes relevant only where formal freedom renders the unequal consequences of exit unavailable to responsibility or integration.

```text
Parity-to-Exit begins
when formal equality replaces cost-truth.
```

**Switch Drift** denotes a recurring pattern in which frame changes preserve false coordination while appearing to revise it. A single switch does not establish drift. The minimal threshold is convergence among repeatability, consequential scene effects, and responsibility displacement.

```text
Switch drift requires:
pattern,
consequence,
and responsibility displacement.
```

Switch Drift remains structural rather than diagnostic. Relevant signals include asymmetric frame mobility, increasing critique cost, recurring responsibility redistribution, integration failure beneath surface revision, displaced self-binding load, and legitimation replacing integration. None proves drift in isolation.

**Switch Availability** denotes the availability of a particular frame change when responsibility, asymmetry, cost, or correction becomes difficult to sustain. Availability does not imply conscious selection or manipulation. It identifies a structural option that the scene can repeatedly enter under relevant pressure.

**Regime Availability** denotes the stabilization of switch options as repeatable, socially legible, and correction-resistant features of a scene or field. An episodic switch becomes regime-available only where the relevant frame movements acquire durability and repeatedly preserve displaced responsibility or blocked integration and self-binding.

```text
A single switch does not prove regime stabilization.
A single recognition claim does not prove regime stabilization.
A single protection claim does not prove regime stabilization.
A single equality frame does not prove regime stabilization.
```

These terms identify movements among frames. Non-events, non-binding, indirect action-power, legitimation, and stabilized drift provide additional channels through which coordination can shift.

### A.7 Drift and Non-Event Terms

**Inferiority Misframing** denotes the conversion of a situated limitation, dependency, vulnerability, need, exposure, or reduced capacity into lower rank, lower agency, or diminished adult standing. The underlying condition may be real. The misframing lies in treating a bounded praxis condition as a generalized value verdict.

**Superiority Misframing** denotes the conversion of situated capacity, competence, status, protection-power, sensitivity, vulnerability, recognition, or authority into higher rank, generalized priority, immunity, or command-right. Local superiority may be real within a bounded field. The misframing occurs where that local difference is generalized beyond its relevant domain or used to reduce answerability.

Inferiority and Superiority Misframing are rank artifacts. They do not merely misdescribe a role-position; they alter how responsibility, recognition, protection, cost, criticizability, and participation can be distributed within a scene.

**Immunization** denotes a drift in which a real structuring effect becomes insufficiently answerable. The effect remains active, but responsibility is discounted, displaced, protected from critique, or made difficult to name.

```text
Immunization =
effect without full responsibility.
```

Immunization is not identical with protection, recognition, vulnerability, innocence, or reduced exposure. Protection becomes immunizing only where it interrupts an otherwise traceable relation between structuring effect and answerability.

**Overexposure** denotes a drift in which a role-position becomes excessively available to responsibility, suspicion, explanation demand, correction, or blame before the scene has established adequate legibility, protection, distance, alternatives, or a traceable connection to real structuring effect.

```text
Overexposure =
responsibility without full legibility or protection.
```

Overexposure does not imply absence of responsibility. It identifies a responsibility assignment that outruns the conditions under which answerability can be specified without premature attribution, moralization, or degradation.

**Asymmetric Explanatory Poverty (AEP)** denotes a scene condition in which a role-position bears substantial exposure or responsibility load while lacking legitimate language for describing how that load is produced. The problem is not an individual inability to speak or understand. It is an asymmetrical distribution of explanatory legitimacy.

```text
Asymmetric Explanatory Poverty is not stupidity,
not incapacity,
not moral inferiority,
and not an epistemic defect of a sex.
```

AEP may be present where a role-position is sufficiently legible to be scrutinized but insufficiently authorized to describe its own exposure without being recoded as evasive, controlling, threatening, self-exculpating, or resistant to responsibility. Naming AEP does not establish innocence or remove answerability.

**No Passive Praxis** denotes the principle that visible action does not exhaust the ways in which a scene can be structured. Its scope is limited by a strict threshold:

```text
No Passive Praxis ≠ every non-action is action.

Non-action becomes praxis only when it structures a scene
under □ (frame),
Λ (non-event),
Ω (asymmetry),
and Θ (temporality).
```

Silence, delay, non-response, withholding, non-clarification, openness, or non-involvement is not praxis merely because it is noticed or experienced as difficult. A non-action becomes praxis-relevant only where it produces a traceable effect on action conditions, cost, exposure, timing, responsibility, integration, self-binding, or correctability.

**Passive Praxis** denotes the threshold case in which a non-action becomes praxeologically relevant without necessarily becoming direct action or integrated enactment.

```text
Passive Praxis =
non-action
+ □/Λ/Ω/Θ structuring
+ traceable scene effect
→ praxis-relevant non-event.
```

Passive Praxis is not a synonym for guilt, manipulation, passive aggression, or hidden intention. It describes how a non-action structures a scene before any responsibility claim is made.

**Mere Absence** denotes something that does not occur but does not structure the relevant scene. The absence may be accidental, unavailable, irrelevant, outside the role-position’s field, or without a traceable effect on cost, exposure, timing, responsibility, integration, self-binding, or correctability.

**Structuring Non-Event** denotes an absence that becomes part of how a scene is organized. Λ (non-event) becomes structurally relevant where silence, delay, non-clarification, withholding, non-response, or another absence changes what relevant role-positions must do, carry, infer, absorb, stabilize, or leave unresolved.

**Integrated Abstention** denotes restraint, refusal, silence, delay, or non-intervention that is structurally traceable as directionality integrated across time. Where the configuration E = Σ ∘ Θ ∘ ∇ is supported by scene-bound evidence, abstention may count as strict Action / Enactment. This classification does not infer an unobserved intention or mental state. Integrated Abstention may preserve distance, respect a boundary, prevent escalation, or refuse illegitimate participation; it is not drift by category.

```text
Mere Absence
≠ Structuring Non-Event
≠ Integrated Abstention.
```

The distinction prevents two opposed errors: inflating every absence into praxis and erasing structuring non-events because they lack visible action.

**Non-Binding as a Ψ (Self-Binding)-Load Shift** denotes a configuration in which reduced commitment, clarification, continuity, or consequence-bearing on one side increases the burden of anticipation, stabilization, interpretation, or self-regulation elsewhere.

```text
low Ψ on one side
→ increased Ψ-load on the other.
```

Non-binding may also be legitimate openness, uncertainty, refusal, or preservation of distance. It becomes structurally relevant only where the resulting load shift is traceable and consequential within the scene. Naming that shift does not authorize imposed commitment.

**Action-Power** denotes the capacity to structure praxis conditions. It includes but is not limited to direct action, command, force, decision, or institutional authority.

```text
Action-Power ≠ direct action alone.
Action-Power = capacity to structure praxis conditions.
```

**Indirect Action-Power** denotes the capacity to structure another role-position’s action conditions through access, timing, recognition, withholding, framing, legitimation, or non-binding without necessarily issuing a direct command. It is a scene-bound capacity, not an operator, person attribute, or presumption of domination.

```text
Indirect Action-Power =
capacity to structure another role-position’s action conditions
without necessarily acting through direct command.
```

The concept requires a traceable effect. Influence, silence, delay, or asymmetrical access does not establish Indirect Action-Power unless it materially changes what becomes available, costly, delayed, permissible, recognizable, or practically unavailable.

**Legitimation as Frame/Recontextualization Praxis** denotes the capacity of a justificatory account to recontextualize a scene through □ (frame) and Φ (recontextualization) in a way that may support stabilization. Φ does not itself replace Α (attractor). Legitimation may make an arrangement appear fair, protective, equal, autonomous, neutral, necessary, or non-responsible and thereby alter what can be criticized or revised.

Legitimation is not automatically evasion. It may accurately describe a lawful, necessary, protective, or functional arrangement. It becomes drift-relevant where repeated recontextualization supports stabilization as Α while costs remain unintegrated and responsibility becomes less traceable.

**Under-Explained Adaptive Steering** denotes a scene effect in which one role-position repeatedly adapts around ambiguity, delay, silence, non-clarification, non-response, or non-binding while the source and cost of that adaptation remain insufficiently named.

```text
under-explained ambiguity or non-event
+ adaptation by another role-position
+ unintegrated cost
= Under-Explained Adaptive Steering.
```

The steering need not be intentional. The term does not diagnose manipulation, avoidance, passive aggression, or hidden control. It identifies the organization of conduct around a condition that remains insufficiently available to shared explanation.

**Postfeminist Override (PFO)** denotes one downstream regime form in which false-coordinated real asymmetry stabilizes under recurring recognition, protection, parity, or exception frames. It is not a person type, ideology diagnosis, political verdict, or general theory of postfeminism.

Using Ω (asymmetry), R (responsibility), Σ (integration), and Ψ (self-binding), its bounded definition is:

```text
PFO =
regime stabilization
of false-coordinated real Ω
under recognition, protection, parity, or exception frames
with displaced R
and blocked Σ/Ψ.
```

```text
PFO is not the origin of reciprocity loss.
PFO is one regime form in which reciprocity loss stabilizes.
```

PFO requires more than a single switch, recognition claim, protection claim, equality frame, or local responsibility displacement. The regime claim requires repeatable frame availability, stabilized false coordination, and resistance to proportionate correction.

**Profile** denotes a scene-bound grouping of mutually reinforcing drift tendencies. A profile is an analytic compression of a specified configuration, not a person type, diagnosis, sex essence, stable identity, or claim about population distribution.

```text
Profiles are scene-bound drift patterns,
not sex truths.
```

A role-position may be immunized in one scene and overexposed in another. No profile establishes a permanent property of a person, sex, group, or identity. The boundary and application terms in A.8 specify the counter-cases and methodological limits required before any such vocabulary can be applied.

### A.8 Boundary and Application Terms

The terms in this section constrain the framework’s reach and use. Their purpose is not to expand the number of scenes the framework can capture, but to preserve distinctions through which a proposed reading can be weakened, redirected, or defeated.

```text
Discomfort alone is not EDEN.
Conflict alone is not EDEN.
Difference alone is not EDEN.
Power difference alone is not EDEN.
Vulnerability alone is not EDEN.
```

**Genuine Vulnerability** denotes a condition in which exposure, dependency, injury, incapacity, danger, or limited alternatives materially affect what a role-position can bear or do. Vulnerability is not merely a rhetorical surface; it forms part of the scene’s real structure.

```text
Genuine Vulnerability:
real exposure
real harm risk
real protection need
responsibility still proportionately possible
dignity-in-practice preserved.
```

Genuine Vulnerability can reduce capacity, remove alternatives, increase the cost of response, or alter what could reasonably have been understood. It does not necessarily eliminate every structuring effect or every form of proportionate responsibility.

**Genuine Protection** denotes a bounded response to real vulnerability, exposure, danger, dependency, or limited capacity. It modifies the conditions of participation and responsibility without categorically removing criticizability or adult standing.

```text
Genuine Protection:
bounded
specific
cost-aware
revisable
responsibility-compatible
integration- and self-binding-opening.
```

Protection may alter timing, access, exposure, authority, or demand. The costs it distributes remain part of the scene, but those costs do not make the protection false. Protection becomes drift-relevant only where it categorically suspends responsibility, criticizability, self-binding, or correction for real structuring effect.

**Genuine Superiority** denotes a demonstrable difference in capacity within a specified field. One role-position may possess greater competence, strength, experience, information, perception, or task-specific ability without acquiring higher general standing.

```text
Genuine Superiority:
local
bounded
field-specific
responsibility-increasing
dignity-preserving
criticizable.
```

Capacity increases responsibility where it structures effect. It does not create ontological rank, unlimited authority, or exemption from correction.

**Genuine Hierarchy** denotes a differentiated organization of roles, authority, access, decision rights, obligations, or responsibility that remains connected to a defined coordination task.

```text
Genuine Hierarchy:
role-bounded
task-relevant
transparent
revisable
cost-aware
non-humiliating
integration- and self-binding-compatible.
```

Hierarchy becomes drift-relevant where task-bound authority expands into generalized rank, authority capture, blocked criticizability, dignity erosion, or control without corresponding answerability. The framework is directed against false coordination, not against asymmetry, competence, authority, or hierarchy as such.

**Genuine Non-Action** denotes an absence that does not structure the relevant scene or an abstention whose structural role remains legitimate, bounded, and answerable. Non-action is not rendered false merely because it has been noticed, produces discomfort, or leaves another preference unmet.

A strong neutrality signature includes:

```text
no relevant □ (frame) expectation
no meaningful Λ (non-event)
no affected Ω (asymmetry)
no Θ (temporality) accumulation
no shifted cost
no shifted option burden
no presupposed self-binding
no available alternative.
```

These conditions are discriminative rather than mechanically cumulative. Their function is to test whether an alleged non-action actually structures costs, options, responsibility, or binding load.

**Legitimate Openness** denotes uncertainty, non-commitment, delay, or preservation of alternatives that does not depend on another role-position carrying an unacknowledged burden of waiting, interpretation, continuity, or self-regulation.

```text
Legitimate Openness:
bounded
communicated where needed
not cost-shifting
not indefinitely non-event-producing
not responsibility-evading
not blocking integration or self-binding.
```

Legitimate Openness does not require premature closure. It preserves uncertainty without making another role-position responsible for maintaining the conditions under which that uncertainty remains possible.

**Neutrality** denotes the absence of a relevant structuring contribution within the specified scene. Neutrality must be tested rather than presumed either true or false. Silence, delay, refusal, or non-involvement may be neutral where no relevant expectation, alternative, asymmetrical effect, accumulated cost, or responsibility-bearing relation makes the absence structurally consequential.

**EDEN-MAP**, the paper’s scene-mapping protocol, denotes a bounded sequence for testing whether false-coordinated real asymmetry, displaced responsibility, and blocked integration or self-binding are present. It orders questions already established by the paper and adds no new mechanism.

**Real Ω Mapping** denotes the step that identifies the scene’s operative unevenness in capacity, exposure, cost, dependency, protection, access, timing, responsibility, action-power, or legibility before evaluating how it is coordinated. Mapping a real asymmetry does not naturalize, justify, rank, or make it permanent.

**Responsibility Mapping** denotes the step that traces answerability to real structuring effect under available legibility, capacity, alternative possibility, temporal trajectory, and asymmetrical cost or exposure. It does not infer blame, motive, moral worth, or outcome liability from effect alone.

**Non-Passivity and Non-Binding Check** denotes the step that tests whether a non-action crosses the Passive Praxis threshold and whether reduced self-binding produces a traceable load shift elsewhere. Without a traceable change in another role-position’s options, costs, exposure, timing, or binding load, the Passive Praxis reading fails.

**Immunization / Overexposure Check** denotes the coupled test of whether structuring effect is insufficiently answerable on one side while responsibility or explanation demand outruns legibility and protection on another. The check maps a scene relation; it does not classify persons or establish a sexed profile.

```text
EDEN-MAP maps scenes.
It does not diagnose persons.
It does not rank sexes.
It does not authorize coercive action.
It does not replace counter-scene testing.
```

A mapping result may be strongly supported, weakly supported, secondary, indeterminate, or defeated. None of these evidentiary statuses becomes a global statement about a person, group, identity, or sex.

```text
The final test of EDEN is whether it can release a scene
when the scene does not belong to it.
```

**Rival Explanation** denotes an alternative account that may explain the decisive evidence with greater specificity, stronger support, fewer unsupported inferences, or less distortion. A rival explanation is a methodological competitor, not an ornamental disclaimer.

Institutional constraint, economic pressure, legal obligation, illness, trauma, direct violence, acute crisis, material limitation, conflicting duties, ordinary misunderstanding, task-specific incapacity, asymmetric information, or external coercion may provide stronger explanations. The framework may retain partial relevance without retaining explanatory priority.

```text
EDEN weakens where a rival framework explains the scene better.
```

**Counter-Scene** denotes a materially different structural organization of the available evidence. It must be capable of changing the proposed reading rather than merely showing that alternatives were mentioned.

```text
Name the proposed reading.
Name the strongest counter-scene.
Specify what evidence would support it.
Specify what evidence would defeat the proposed reading.
Do not proceed if the counter-scene cannot matter.
```

A strong counter-scene preserves the difficult evidence while contesting the mechanism through which that evidence has been organized. Counter-scene testing binds the analyst as well as the scene.

```text
Counter-scene is not politeness.
Counter-scene is methodological exposure to non-capture.
```

**Falsifier** denotes a condition under which a specified reading cannot retain its original scope or strength. A falsifier is more precise than general uncertainty or the possibility that additional evidence may appear. It identifies a dependency of the claim and states what follows if that dependency is absent or contradicted.

Relevant falsifiers include minimal or absent asymmetry, absence of traceable structuring effect, responsibility remaining properly attached to effect, open criticizability, robust integration or self-binding, bounded protection, genuine vulnerability, functional hierarchy, lack of repetition or consequence, a stronger rival explanation, or a counter-scene that explains the evidence better.

The strongest positive falsifier gathers the framework’s central conditions:

```text
If real Ω (asymmetry) is acknowledged,
R (responsibility) follows structuring effect,
Σ (integration) integrates cost,
Ψ (self-binding) remains attached to effect,
Χ (distance) remains available,
D (dignity-in-practice) is preserved,
and counter-scenes remain possible,
then the EDEN drift claim weakens or fails.
```

A proposed reading is methodologically unsafe if it cannot identify what would weaken or defeat it.

```text
If no falsifier can be named,
the EDEN reading is methodologically unsafe.

If EDEN cannot name what would defeat its reading,
EDEN is not being used methodologically.
```

Loss or anticipated loss of dignity-in-practice requires a further distinction. It may contribute to reciprocity loss where threatened degradation is coordinated through self-justifying frames, reduced recognition of another role-position’s standing, or closure against destabilizing correction. Dignity erosion alone does not establish the framework’s core mechanism.

```text
Actual or anticipated loss of dignity-in-practice
may reinforce reciprocity loss.

Loss of dignity-in-practice alone
does not establish EDEN.

Humiliation by the analysis is a method failure.

Application without dignity-in-practice
is methodologically invalid.
```

**Scene Packet** denotes the minimum structured input required before a scene-mapping inquiry can begin. It prevents application to isolated statements, decontextualized acts, identities, affiliations, or impressions of resemblance.

```text
A scene packet includes:
actors or role-positions
dominant frame
real asymmetry
relevant non-events
temporal trajectory
visible costs
available language
recognition structure
protection structure
responsibility distribution
integration and self-binding status
counter-scene possibility.
```

Where relevant, the packet also records non-action, non-binding, legitimation, action-power, immunization, overexposure, and asymmetric explanatory poverty. The packet is an entry threshold, not a finding.

```text
EDEN-MAP begins with a scene packet,
not a theory label.
```

**Description-to-Action Firewall** denotes the separation between structural description and any use of that description to steer, bind, obligate, prescribe, confront, accuse, intervene, punish, or enforce.

```text
Description may name structure.
Application requires Χ (distance),
reversibility,
D (dignity-in-practice),
and contextual responsibility.

Description does not authorize binding.
```

Description is an operator-traceable account without obligation. Application begins where that account is used to alter another role-position’s options, duties, exposure, standing, or conduct. At that point, reflective distance, reversibility, dignity-in-practice, contextual responsibility, scene-packet sufficiency, and counter-scene exposure become validity conditions.

```text
EDEN-MAP can describe structure.
It does not automatically authorize intervention,
accusation,
confrontation,
prescription,
or coercive action.
```

Contextual responsibility concerns who is using the map, with what evidence and authority, against which role-position, under what asymmetry, and with what foreseeable effects. Confidence in the framework cannot supply standing or authority that the scene does not provide.

**Revision Point** denotes the specific evidence, changed condition, alternative explanation, or unresolved distinction that could alter the scope, confidence, responsibility distribution, or explanatory priority of a reading.

**Open Question** denotes a structurally relevant matter that the available scene packet cannot presently decide. An open question is not a concealed conclusion or an invitation to fill uncertainty with the preferred interpretation.

Every mapping output must retain at least one Revision Point or Open Question. Their presence preserves correctability at the level of the analysis itself.

The governing limits of boundary and application vocabulary are therefore:

```text
No concept may replace judgment.
No pattern may replace evidence.
No frame may replace scene analysis.
No label may replace scene analysis.
No structural description may authorize binding by itself.
```

These limits complete the glossary. Appendix B extends the rival-explanation boundary by locating the paper beside adjacent frameworks without deriving the argument from them or treating adjacency as proof.

---

## Appendix B. Adjacent Frameworks

### B.1 Purpose and Status

This appendix locates the paper’s EDEN analysis, grounded in Praxeological Meta-Structure (PMS), beside adjacent fields of inquiry. Its purpose is scholarly orientation. It identifies conceptual neighborhoods, clarifies differences in explanatory target, and preserves the possibility that another framework may account for a scene more adequately.

The argument does not depend on deriving PMS–EDEN from these neighboring approaches. Nor does adjacency validate the argument by association. The framework must stand or fall through the coherence of its concepts, the traceability of its claims, its ability to discriminate relevant scenes from counter-cases, and its exposure to rival explanations.

The governing relation is therefore:

```text
Positioning without dependence.
```

Positioning without dependence means that conceptual overlap can be acknowledged without treating another framework as the foundation, confirmation, or hidden equivalent of EDEN. It also means that difference can be specified without converting difference into superiority.

Adjacent frameworks may illuminate practices, roles, power, embodiment, recognition, vulnerability, institutions, social reproduction, interaction, interpretation, or temporal stabilization. Their relevance does not imply that they share the same unit of analysis, operator grammar, responsibility account, or concept of reciprocity loss. Conversely, EDEN’s different formal target does not make those frameworks preliminary, incomplete, or replaceable.

This appendix therefore performs neither a comprehensive literature review nor a genealogy of the paper’s concepts. It does not attempt to settle disputes within the adjacent fields it names. It offers a bounded map of affinities and differences sufficient to prevent three errors: isolation from existing scholarship, collapse into an already established framework, and novelty claims based on renaming familiar objects.

The position can be stated compactly:

```text
PMS–EDEN is positioned beside adjacent frameworks.
It is not derived from them.
It does not replace them.
```

This status also preserves explanatory competition. An adjacent framework is not merely a source of vocabulary that can be translated into EDEN’s terms. It may identify a different object, operate at a different explanatory level, or show that a proposed EDEN reading has assigned priority to the wrong mechanism. Responsible positioning therefore requires neighboring approaches to remain capable of disagreement rather than being absorbed as partial expressions of the present framework.

### B.2 Overlap without Equivalence

The central relation between EDEN and adjacent frameworks is overlap without equivalence.

```text
Overlap without equivalence.
```

**Overlap** concerns objects, problems, or relations that more than one framework can help render visible. Several approaches may examine patterned practice, unequal power, role formation, recognition, vulnerability, institutional constraint, symbolic order, interactional framing, responsibility, embodiment, or the reproduction of social expectations.

**Non-equivalence** concerns differences in analytical level, formal target, explanatory mechanism, method, and evidentiary demand. Two frameworks may address the same scene while organizing its decisive features differently. Similar vocabulary does not establish theoretical identity, and a shared object does not imply a shared explanation.

EDEN’s distinct move is to describe false-coordinated real asymmetry as a praxeological mechanism of reciprocity loss. Its analysis asks whether a real asymmetry structures a scene, whether the operative frame coordinates that asymmetry truthfully, whether responsibility follows actual structuring effect, whether relevant costs can be integrated, whether consequential role-positions remain self-bound, and whether shared correctability remains possible.

```text
EDEN’s distinct move is:
false-coordinated real asymmetry
as a praxeological reciprocity-loss mechanism.
```

This formulation identifies a specific conjunction. Real asymmetry alone is insufficient. Power difference alone is insufficient. Recognition conflict, vulnerability, institutional hierarchy, non-action, comparison, or unequal burden alone is insufficient. The stronger EDEN claim requires a scene in which asymmetry is falsely coordinated, responsibility is displaced, integration or self-binding is blocked, and correctability erodes.

Neighboring frameworks may explain any part of this conjunction more precisely. Practice theory may provide a richer account of habituated conduct. Recognition theory may clarify injuries to standing. Feminist or masculinity scholarship may offer stronger historical and empirical accounts of sexed institutions and discourse. Psychology may explain perception, affect, motivation, attachment, or trauma. Sociology may account for organizations, roles, norms, and material constraint. Theology may interpret the Eden narrative through traditions and questions that the present structural reading does not address.

Acknowledging these strengths does not dissolve EDEN’s formal target. It prevents that target from becoming imperial. The framework’s distinctiveness lies in how it composes its question, not in exclusive ownership of every phenomenon it encounters.

Distinctiveness should therefore not be confused with unprecedented discovery. A concept may make a legitimate contribution by reorganizing known problems, specifying a previously diffuse relation, or establishing a more discriminating conjunction. None of these contributions requires the claim that no adjacent framework has seen the relevant field before.

```text
Difference is not superiority.
Adjacency is not derivation.
Overlap is not equivalence.
```

The same discipline applies in the opposite direction. Similarity to an established framework does not show that EDEN merely restates it. Equivalence would require more than thematic overlap. It would require correspondence in analytical object, formal relations, responsibility logic, boundary conditions, and explanatory work.

The appropriate comparison therefore has three parts:

```text
Overlap:
what both approaches help make visible.

Non-equivalence:
what differs in object, mechanism, level, or method.

Risk:
what EDEN would distort by over-assimilating the adjacent framework.
```

The risk component is necessary because conceptual translation can erase meaningful differences. Institutional power should not automatically be redescribed as interpersonal false coordination. Trauma should not be reduced to blocked self-binding. Recognition injury should not be treated as responsibility evasion. Theological interpretation should not be translated into structural operators as if symbolic or doctrinal meaning were merely an undeveloped form of praxis analysis.

Overlap without equivalence thus protects both sides of the comparison. It allows EDEN to enter scholarly conversation without claiming replacement, and it allows adjacent frameworks to remain theoretically independent rather than becoming evidence for EDEN by retrospective translation.

The following map applies this discipline across the principal adjacent areas. It identifies limited points of contact, specifies non-equivalence, and marks the risks of over-assimilation without attempting a full literature review.

### B.3 Adjacent Areas Map

The following map identifies conceptual neighborhoods rather than theoretical equivalents. Each area is described through a limited point of overlap, a difference in explanatory target, and a risk that would arise if the adjacent approach were absorbed into EDEN’s vocabulary.

**Practice theory.** The overlap concerns socially situated conduct, recurrent patterns, practical intelligibility, and the reproduction of fields through what actors do. EDEN differs by isolating a narrower coordination problem: how real asymmetry, responsibility, integration, self-binding, and correctability are organized within a specified scene. Over-assimilation would make every practice pattern an instance of reciprocity loss or treat EDEN as a general theory of practice.

**Habitus and symbolic power.** The overlap concerns learned dispositions, normalized classifications, embodied expectations, and forms of power that operate without requiring explicit command. EDEN does not provide a general account of social position, symbolic capital, class reproduction, or durable disposition. Over-assimilation would reduce historically formed social structures to local frame effects or translate every normalized difference into false-coordinated asymmetry.

**Structuration.** The overlap concerns the recursive relation between situated conduct and the conditions that conduct reproduces. EDEN similarly treats actors as formed within praxis fields that they may also help stabilize. Its narrower target is the coordination of asymmetry and responsibility within scenes rather than a general account of the relation between agency and social structure. Over-assimilation would inflate a bounded reciprocity analysis into a comprehensive theory of social reproduction.

**Interaction order.** The overlap concerns situated roles, framing, recognition, face, participation, timing, and the practical organization of encounters. EDEN adds an operator-disciplined account of asymmetry, responsibility distribution, non-events, self-binding, and correctability. Over-assimilation would treat every interactional disruption, face threat, or framing conflict as evidence of reciprocity loss without establishing the required structural mechanism.

**Systems theory.** The overlap concerns patterned communication, self-stabilization, observation, expectation, recursive reproduction, and the limits imposed by a system’s own distinctions. EDEN remains focused on praxeological scenes and responsibility-bearing role-positions rather than treating communication systems as its primary object. Over-assimilation would either dissolve responsibility into system reproduction or anthropomorphize systems by assigning them person-like answerability.

**Governmentality.** The overlap concerns indirect conduct-shaping, normalization, self-regulation, legitimation, and forms of power that organize possible action without relying only on direct coercion. EDEN’s concepts of framing, legitimation, non-binding, and indirect action-power may intersect with these concerns, but its central object remains reciprocity loss through false coordination of real asymmetry. Over-assimilation would redescribe every scene of self-regulation as governmentality or turn EDEN into a general account of political rationality.

**Recognition theory.** The overlap concerns standing, misrecognition, dignity, social visibility, and the conditions under which persons can participate as adults. EDEN places additional emphasis on the relation between recognition and responsibility: recognition remains incomplete where criticizability, self-binding, consequence attribution, or correction is categorically suspended. Over-assimilation would treat recognition theory as if it were implicitly about responsibility displacement or recode every recognition injury as pseudo-equal-standing.

**Action theory and responsibility frameworks.** The overlap concerns agency, omission, intention, capacity, answerability, consequence, and the relation between action and responsibility. EDEN’s narrower contribution is to distinguish praxis from strict enactment, trace responsibility through scene-bound structuring effect, and include qualifying conditions of legibility, capacity, alternatives, temporality, and asymmetrical cost or exposure. Over-assimilation would treat EDEN as a general theory of action or responsibility, collapse structural answerability into moral or legal liability, or assume that adjacent responsibility frameworks already share its operator grammar.

**Feminist theory.** The overlap concerns sexed power, dependency, embodiment, vulnerability, care, recognition, unequal exposure, institutional history, and the distribution of social responsibility. EDEN does not treat symmetry as the default endpoint of sexed relations. Its narrower contribution is to ask how real sexed asymmetries can remain truthfully coordinable without becoming rank artifacts, responsibility displacement, blocked integration or self-binding, immunization, or overexposure. The relevant standard is therefore not maximal symmetry or a theoretically asserted optimum of cost distribution, but whether capacities, protections, costs, and responsibilities remain legible, proportionately attributable, integrable, dignity-preserving, and open to correction. Feminist theories are internally diverse and often operate at historical, political, material, legal, or epistemic levels that EDEN does *not* replace. Over-assimilation would flatten those differences, detach sexed scenes from empirical history, or use EDEN as a substitute for feminist analysis.

**Masculinity studies.** The overlap concerns male-coded role expectations, responsibility burdens, vulnerability constraints, protection demands, authority, exposure, and the social legibility of male conduct. EDEN contributes scene-bound concepts for overexposure, explanatory poverty, responsibility distribution, and asymmetrical protection without offering a comprehensive sociology or psychology of masculinity. Over-assimilation would convert conditional role-position patterns into truths about men or treat masculinity scholarship as confirmation of a fixed profile.

**Postfeminism and adjacent discourse analysis.** The overlap concerns the circulation of equality, autonomy, empowerment, choice, recognition, protection, and exception frames after formal commitments to equality have become culturally established. Postfeminist Override (PFO) is narrower: it names one possible downstream regime stabilization of false-coordinated real asymmetry. It is not a synonym for postfeminism or a label for persons, beliefs, movements, or political identities. Over-assimilation would collapse structural analysis into ideology attribution or make recognition and equality language suspicious by category.

**Psychology and moral psychology.** The overlap concerns perception, affect, intention, motivation, attribution, agency, responsibility, conflict, and the conditions of correction. EDEN does not infer hidden mental states or provide an account of personality, cognition, attachment, moral development, or psychopathology. Over-assimilation would psychologize structural relations, treat operator configurations as mental mechanisms, or mistake a scene-bound responsibility trace for a claim about character.

**Theological and Eden-related readings.** The overlap concerns the Eden narrative, breach, embodiment, exposure, consequence, responsibility, relation, concealment, and altered conditions of human coordination. EDEN uses the narrative as a minimal praxis scene on which an already established structural grammar is tested. It does not replace exegesis, doctrine, theological anthropology, historical interpretation, or symbolic reading. Over-assimilation would treat theological meanings as undeveloped structural concepts or present the Eden scene as the origin or proof of the framework.

**Trauma and vulnerability frameworks.** The overlap concerns exposure, impaired capacity, protective distance, altered temporality, constrained alternatives, heightened threat, and the conditions under which participation or correction becomes possible. Trauma or acute vulnerability may explain withdrawal, silence, inconsistent participation, protection needs, or narrowed self-binding more accurately than an EDEN reading. Over-assimilation would redescribe protective responses as immunization, interpret incapacity as non-binding drift, or treat distress under critique as evidence that a Critique-to-Threat Switch has occurred.

These areas are not exhaustive. They identify the principal points at which EDEN may encounter an adjacent explanation, borrow a familiar object without borrowing the same theory, or need to yield explanatory priority. The map therefore supports comparison while preserving the heterogeneity and independence of the fields it names.

### B.4 Non-Goals

EDEN is not intended to function as:

```text
a comprehensive social theory
a psychology
a theology
a sex metaphysics
a general ideology critique
an empirical prevalence study
a therapy model
a relationship manual
a political program.
```

It is not a comprehensive social theory because its object is bounded. It examines a specific family of scenes in which real asymmetry may be falsely coordinated, responsibility displaced, integration or self-binding blocked, and shared correctability eroded. It does not attempt to explain social order, institutions, culture, history, or power in their entirety.

It is not a psychology because it does not infer motive, personality, cognition, attachment style, pathology, or hidden mental states from structural effects. Psychological findings may clarify a scene, but EDEN’s principal claims concern the organization of praxis rather than the interior constitution of actors.

It is not a theology because its use of Eden does not establish doctrine, interpret revelation, reconstruct theological anthropology, or settle exegetical questions. The narrative functions as a bounded test scene, not as the origin or foundation of the argument.

It is not a sex metaphysics because sexed role-positions and coded profiles remain conditional, overlapping, and scene-bound. The framework does not derive fixed capacities, moral qualities, responsibilities, vulnerabilities, or drift tendencies from sex as essence.

It is not a general ideology critique because it does not classify persons or groups by worldview, decode every recognition claim as concealed power, or treat political language as self-invalidating. Postfeminist Override names a specific regime configuration only where its structural conditions can be traced.

It is not an empirical prevalence study because it does not establish how frequently its configurations occur across populations, institutions, sexes, cultures, or historical periods. Structural possibility and internal coherence do not by themselves demonstrate distribution, recurrence, or statistical significance.

It is not a therapy model or relationship manual because structural description does not provide a sequence of repair, reconciliation, confrontation, disclosure, or behavioral change. The framework may clarify a scene without determining what any participant should do.

It is not a political program because identifying false coordination does not prescribe legislation, institutional design, collective strategy, enforcement, or ideological alignment. Political and legal implications require additional normative, empirical, and institutional argument.

The framework’s positive status is narrower:

```text
EDEN is structural and praxeological.
EDEN is scene-bound.
EDEN is application-gated.
EDEN remains falsifiable.
EDEN does not replace rival frameworks.
```

This limitation is substantive rather than defensive. A framework gains discriminative force by specifying the object it can explain and the domains it does not claim. The Related Work Spine can therefore position the framework more precisely without converting adjacency into dependence or breadth into authority.

### B.5 Related Work Spine

The adjacent fields can be organized into five reference classes. This organization does not rank those fields or turn them into stages leading toward EDEN. It identifies the principal scholarly conversations within which the framework’s object, limits, and distinctive conjunction can be located.

**Praxis, field formation, and social reproduction.** Practice theory, accounts of habitus and symbolic power, structuration, and related approaches explain how conduct becomes patterned, how actors acquire practical competence, and how stabilized fields reproduce expectations and limitations (Bourdieu 1977; Giddens 1984). This literature provides a broad context for the paper’s account of learned legibility and stabilized praxis. EDEN’s narrower contribution is to trace how a specified scene coordinates real asymmetry, responsibility, integration, self-binding, and correctability. The two levels should remain connected without being collapsed.

**Interaction, framing, and indirect power.** Work on interaction order and framing helps clarify how situated expectations and symbolic organization can operate without direct command (Goffman 1974). Work on relational power and conduct-shaping similarly clarifies normalization, legitimacy, and the organization of possible action (Foucault 1982). Systems approaches add questions of communication, recursive reproduction, and system-specific distinctions. These neighboring literatures are relevant to the paper’s treatment of frame shifts, non-events, legitimation, and indirect action-power. Non-equivalence remains necessary because EDEN does not offer a general theory of communication, normalization, governance, or symbolic domination. It asks a more specific question about the praxeological coordination of asymmetry and responsibility.

**Recognition, sexed relations, and responsibility.** Recognition theory addresses standing, dignity, social visibility, and participatory status (Fraser 2000; Honneth 1996). Feminist theory, masculinity studies, and postfeminism-related scholarship provide historical, political, institutional, and normative accounts of sexed power, embodiment, vulnerability, care, protection, agency, and unequal social burdens (Connell 2005; Gill 2007; Scott 1986; Tronto 1993). Action and responsibility theory supplies distinctions among agency, omission, capacity, and answerability that are especially relevant to No Passive Praxis and the Responsibility Principle (Clarke 2014). EDEN contributes a narrower structural distinction: recognition remains incomplete where it is detached from criticizability, proportionate responsibility, self-binding, and correction, while responsibility becomes distorted where it is detached from recognition and dignity-in-practice.

This contribution does not establish an alternative sex theory. It does not claim that asymmetry should disappear or that symmetry is the final measure of reciprocity. It asks whether real sexed asymmetries can remain visible and truthfully coordinated without becoming rank, immunity, overexposure, displaced responsibility, or blocked correctability. Empirical claims about the distribution or recurrence of such configurations require evidence beyond the structural account itself.

**Psychological, moral-psychological, trauma, and vulnerability accounts.** Psychological approaches may explain perception, attribution, affect, intention, motivation, attachment, threat response, moral judgment, or impaired capacity more specifically than a praxeological analysis. Trauma and vulnerability frameworks may account for withdrawal, protective distance, inconsistent participation, reduced alternatives, or altered temporality without those effects primarily constituting reciprocity drift. EDEN should therefore retain structural description without translating psychological or trauma-related phenomena into operator configurations by default.

**Theological, symbolic, and Eden-related interpretation.** Theological and symbolic approaches engage questions of creation, embodiment, breach, shame, responsibility, concealment, relation, and consequence that exceed the paper’s structural use of Eden; feminist rhetorical interpretation of Genesis constitutes one especially relevant neighboring tradition (Trible 1978). The Eden scene serves here as a minimal test case for an independently developed grammar. It does not replace doctrinal, exegetical, historical, literary, or theological interpretation, and those traditions should not be treated as incomplete versions of praxeological analysis.

Across these reference classes, the relevant comparison remains stable:

```text
Shared object does not establish shared theory.
Shared vocabulary does not establish shared mechanism.
Distinct mechanism does not establish superiority.
```

The Related Work Spine therefore has a limited function. It locates the framework within existing fields while keeping three distinctions visible: thematic overlap is not derivation, formal difference is not novelty proof, and explanatory contribution is not replacement authority.

### B.6 Boundary: EDEN Does Not Replace Rival Frameworks

The final boundary concerns explanatory priority. EDEN may illuminate a scene without providing its governing explanation. Partial relevance does not establish primary relevance, and structural resemblance does not establish capture.

```text
EDEN weakens where a rival framework explains the scene better.
```

A rival explanation is stronger where it accounts for the decisive evidence more specifically, preserves more of the scene’s relevant structure, requires fewer unsupported inferences, and distinguishes operative conditions from superficial resemblance more accurately.

A scene may primarily involve trauma, illness, institutional pressure, economic constraint, legal obligation, material scarcity, direct violence, acute danger, ordinary conflict, asymmetric information, task-specific incapacity, conflicting duties, cultural mismatch, or functional role hierarchy. Any of these conditions may produce asymmetry, silence, protection, unequal burden, reduced alternatives, or impaired correction without the scene primarily instantiating EDEN’s mechanism.

Institutional constraint may determine what participants can do independently of their local recognition or responsibility frames. Economic pressure may distribute dependency and cost more directly than interpersonal false coordination. Legal duties may require unequal authority or restricted disclosure. Trauma or illness may alter capacity, timing, exposure, and participation. Direct violence may make protection and coercion the primary objects of analysis. Ordinary conflict may persist without responsibility displacement or blocked correctability.

In such cases, EDEN may retain a secondary role. It may clarify how the primary condition is coordinated, framed, or made answerable. It may show that a legal, institutional, psychological, or material structure is later accompanied by recognition drift or unequal self-binding. But it cannot displace the primary explanation merely because its vocabulary can describe part of the scene.

The replacement boundaries are explicit:

```text
EDEN does not replace theology.
EDEN does not replace sociology.
EDEN does not replace psychology.
EDEN does not replace feminism or masculinity studies.
EDEN does not replace adjacent frameworks.
```

These limits do not make EDEN explanatorily empty. They specify its strongest domain:

```text
EDEN is strongest where real asymmetry is falsely coordinated,
responsibility is displaced,
integration or self-binding is blocked,
shared correctability erodes,
and counter-scenes or rival explanations
do not explain the scene better.
```

Each component is necessary to the stronger reading. Real asymmetry provides the structural object. False coordination specifies the relevant failure. Responsibility displacement identifies the altered relation between effect and answerability. Blocked integration or self-binding explains why costs and consequences cannot be adequately carried. Eroded correctability identifies the deeper relational loss. Counter-scenes and rival explanations determine whether this account retains explanatory priority.

The framework must therefore be capable of three outcomes. It may retain the scene where the full conjunction is strongly supported. It may narrow its claim where only one mechanism is established. It must release the scene where required conditions are absent or another explanation is stronger.

```text
Retain where the mechanism is supported.
Narrow where only a partial mechanism is supported.
Release where the scene is better explained otherwise.
```

This is the practical meaning of overlap without equivalence. Adjacent frameworks can share objects with EDEN without becoming equivalent to it, and they can defeat an EDEN reading without invalidating the framework as a whole. Explanatory competition remains local to the scene and proportionate to the available evidence.

The final positioning is therefore neither isolation nor absorption:

```text
Positioning without dependence.
Overlap without equivalence.
Contribution without replacement.
Difference without superiority.
```

### B.7 References

Bourdieu, Pierre. 1977. *Outline of a Theory of Practice*. Translated by Richard Nice. Cambridge: Cambridge University Press. https://doi.org/10.1017/CBO9780511812507.

Clarke, Randolph. 2014. *Omissions: Agency, Metaphysics, and Responsibility*. New York: Oxford University Press. https://doi.org/10.1093/acprof:oso/9780199347520.001.0001.

Connell, R. W. 2005. *Masculinities*. 2nd ed. Berkeley: University of California Press.

Foucault, Michel. 1982. “The Subject and Power.” *Critical Inquiry* 8 (4): 777–795. https://doi.org/10.1086/448181.

Fraser, Nancy. 2000. “Rethinking Recognition.” *New Left Review* II/3: 107–120.

Giddens, Anthony. 1984. *The Constitution of Society: Outline of the Theory of Structuration*. Cambridge: Polity Press.

Gill, Rosalind. 2007. “Postfeminist Media Culture: Elements of a Sensibility.” *European Journal of Cultural Studies* 10 (2): 147–166. https://doi.org/10.1177/1367549407075898.

Goffman, Erving. 1974. *Frame Analysis: An Essay on the Organization of Experience*. Cambridge, MA: Harvard University Press.

Honneth, Axel. 1996. *The Struggle for Recognition: The Moral Grammar of Social Conflicts*. Translated by Joel Anderson. Cambridge, MA: MIT Press.

Scott, Joan W. 1986. “Gender: A Useful Category of Historical Analysis.” *American Historical Review* 91 (5): 1053–1075. https://doi.org/10.1086/ahr/91.5.1053.

Trible, Phyllis. 1978. *God and the Rhetoric of Sexuality*. Philadelphia: Fortress Press.

Tronto, Joan C. 1993. *Moral Boundaries: A Political Argument for an Ethic of Care*. New York: Routledge.
